/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

    Name:      message functions

    Type:      C source file

    Desc:      Message Processing Functions

    File:      si_mf.c
  
    Sid:      si_mf.c@@/main/8 - Wed Jul 25 13:20:24 2001
  
    Prg:       rs

*********************************************************************21*/


/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.             description
*     --------    ----------------------------------------------
*     1000009     Network Layer - Q.930/Q.931
*     1000017     Data Link Layer - Basic Frame Relay
*     1000018     Data Link Layer - Extended Frame Relay
*     1000023     X.31
*     1000029     SS7 - ISUP
*     1000043     Network Layer - Q.93B
*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* general SS7 layer */
#include "cm_hash.h"       /* hash-list header */
#include "lsi.h"           /* layer management */
#include "si_mf.h"         /* message functions */
#include "cm5.h"           /* timers */
#include "ci_db.h"         /* ISUP data base */
#include "sit.h"           /* ISUP */
#include "snt.h"           /* MTP3 */
#ifdef SI_SPT
#include "spt.h"           /* SCCP */
#endif
#ifdef SI_FTHA
#include "sht.h"           /* sht interface */
#endif
#include "si.h"            /* ISUP */
#include "si_err.h"        /* ISUP error */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* general SS7 layer */
#include "cm_lib.x"        /* common library functions */
#include "cm_hash.x"       /* hash-list structure */
#include "lsi.x"           /* layer management */
#include "si_mf.x"            /* message functions */
#include "cm5.x"           /* timers */
#include "ci_db.x"         /* ISUP data base */
#include "sit.x"           /* ISUP */
#include "snt.x"           /* MTP3 */
#ifdef SI_SPT
#include "spt.x"           /* SCCP */
#endif
#ifdef SI_FTHA
#include "sht.x"           /* sht interface */
#endif
#include "si.x"            /* ISUP */


/* local defines */

/* local typedefs */

/* local externs */

/* forward references */

PRIVATE S16 siMfReinitMsgCtl ARGS((SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfPushFlag ARGS((U8 flag));
PRIVATE S16 siMfChkFlag ARGS((U8 cnt));
/* si010.220: Deletion - delete siMfSkipTkns declaration */
PRIVATE S16 siMfSetExt ARGS((Buffer *mp,U8 val));
PRIVATE S16 siMfSetFlag ARGS((U8 reg,Buffer *mp));
PRIVATE S16 siMfDecMsgType ARGS((SiMfMsgCtl *msgCtlp, Data val));
PRIVATE S16 siMfEncMsgType ARGS((SiMfMsgCtl *msgCtlp, Data val));
PRIVATE S16 siMfDecU8 ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep, 
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfEncU8 ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep,
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfDecBits ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep,
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfEncBits ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep,
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfDecU16 ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep,
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfDecU16Ext ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep,
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfEncU16 ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep,
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfEncU16Ext ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep,
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfDecU24 ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep,
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfEncU24 ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep,
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfDecU32 ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep,
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfEncU32 ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep,
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfDecU8Enum ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep,
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfEncU8Enum ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep,
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfDecStr ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep,
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfEncStr ARGS((Buffer *mp, CONSTANT SiTknElmtDef *tep,
        SiMfMsgCtl *msgCtlp));
/* si010.220: Modification - replace telp with mep in the function arguments */
PRIVATE S16 siMfDecTkns ARGS((Buffer *mp, CONSTANT SiMsgElmtDef *mep, 
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfEncTkns ARGS((Buffer *mp, CONSTANT SiTknElmtDef *CONSTANT *telp,
        SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfInitElmts ARGS((SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfInitTkns ARGS((TknHdr **scmsp,TknHdr **dcmsp, 
        CONSTANT SiTknElmtDef *CONSTANT *telp,U8 mode,Swtch swtch,U32 *flags));

PRIVATE  S16 siMfBcopy ARGS((U8 *src,U8 *dest,U32 count));
PRIVATE  U32 siMfStrlen ARGS((U8 *src));
#ifdef SS7
PRIVATE S16 siMfDecSS7Elmts ARGS((SiMfMsgCtl *msgCtlp));
PRIVATE S16 siMfEncSS7Elmts ARGS((SiMfMsgCtl *msgCtlp));
#endif

PRIVATE S16 siChkMsgFor ARGS((MsgLen mlen, U8 msgIdx, Swtch swtch));
/* si009.220, ADDED: function to get the cause default value base on 
 * cause class indicated in the cause indicator element
 */
PRIVATE S16 siMfGetCauseDef ARGS((U8 val));

/* public variable declarations */

PUBLIC Bool siMfDecCont;
PUBLIC U8 siMfExt;
PUBLIC U8 siInfoTranRate;
/* Public variable to store user information layer 1 protocol */
PUBLIC U8 siUsrInfoLyr1;

/* token value enumeration lists */

SiTknEnum siMfCauseValEnums0[] = 
  { 5, MFCCINVMSG, MFCCINFOELMSSG, MFCCNOMSGTYP, MFCCNOINFOEL, MFCCINVINFOEL,};

SiTknEnum *siMfTeCauseValEnums[1] = 
{
   siMfCauseValEnums0,    /* message functions */
};

/* token flag sets */

U32 siMfTf0 = 0;          /* flags */
U32 siMfTf1 = TF_EREM;    /* flags */
U32 siMfTf2 = TF_NEXT;    /* flags */

/* element flag sets */

U32 siMfEf0[] =
{
   0,                   /* flags */
};

/* internal cause & diagnostic error element */

SiTknElmtDef siMfTeCauseVal = /* cause value */
{
   TET_U8_ENUM,         /* token element type */
   7,                   /* minimum length */
   7,                   /* maximum length */
   0x7f,                /* bit mask */
   0,                   /* minimum value */
   0,                   /* maximum value */
   NULLP,               /* pointer default value switch list */
   0,                   /* bit offset */
   &siMfTf2,              /* flags */
   0,                   /* general register value */
   NULLP,               /* escape to function */
   &siMfTeCauseValEnums[0],  /* pointer to enumerated list */
};

SiTknElmtDef siMfTeDgnVal = /* diagnostic value */
{
   TET_STR,             /* token element type */
   0,                   /* minimum length */
   3,                   /* maximum length */
   0,                   /* bit mask */
   0,                   /* minimum value */
   0,                   /* maximum value */
   NULLP,               /* pointer default value switch list */
   0,                   /* bit offset */
   &siMfTf1,              /* flags */
   0,                   /* general register value */
   NULLP,               /* escape to function */
   /* enumerated values, length in first byte */
   NULLP,               /* pointer to enumerated list */
};

CONSTANT SiTknElmtDef *siMfCauseDgnTkns[] = /* cause and diagnostic tokens */
{
   &siMfTeCauseVal,             /* cause value */
   &siMfTeDgnVal,               /* diagnostics */
   NULLP,
};

SiMsgElmtDef siMfMeCauseDgn =     /* Cause and Diagnostic element */
{
   MET_VARIABLE,              /* element type */
   MFME_CAUSE,                /* element id */
   MFMEI_CAUSE,               /* internal element index */
   2,                         /* minimum length */
   7,                         /* maximum length */
   0,                         /* element error code */
   siMfEf0,                     /* pointer switch flag list */
   &siMfCauseDgnTkns[0],        /* pointer to token list */
};


/* message decode/encode variables */

PUBLIC  U8 siMfLen;
PRIVATE Bool siMfInitFlag = FALSE;
PRIVATE U8 siMfStk[MF_STKSIZE];
PRIVATE U8 siMfSp;
PUBLIC  U8 siMfOctet;
PUBLIC  U8 siMfTmpOctet;
PRIVATE S16 siMfCodeSet;
PRIVATE U8 siMfShftLock;
PRIVATE Bool siMfBackOut;
PRIVATE U16 siMfMaxRepElmt;
PRIVATE SiMsgForTbl siMsgForTbl[MF_MAX_MSGTYPE][SI_MAX_SWITCH];


/*
 *     support functions
 */

/* message processing functions */

  
/*
*
*       Fun:   fpAdd
*
*       Desc:  message function - add far pointers
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/

#ifdef ANSI
PUBLIC S16 fpAdd
(
REG1 PTR *adrp,     /* address pointer */
REG2 U32 len        /* length */
)
#else
PUBLIC S16 fpAdd(adrp, len)
REG1 PTR *adrp;     /* address pointer */
REG2 U32 len;       /* length */
#endif
{
#ifdef DOS
#ifdef PTRFAR
   REG3 U32 seg;
   REG4 U32 off;

   TRC2(fpAdd)
   seg = *adrp & 0xffff0000;
   off = (*adrp & 0xffff);

   off += len;
   seg += ((off & 0xffff0000) << 12);
   *adrp = seg | (off & 0xffff);
#else
   *adrp += len;
#endif
#else
   TRC2(fpAdd)
   *adrp += len;
#endif

   RETVALUE(ROK);
} /* end of fpAdd */

  
/*
*
*       Fun:   siMfInit
*
*       Desc:  message function - initialization
*
*       Ret:   MFROK      - ok
*
*       Notes: Needs to be called once at startup
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siMfInit
(
void
)
#else
PUBLIC S16 siMfInit()
#endif
{
   TRC2(siMfInit)
   siMfInitFlag = 1;
   siMfBackOut = 0;
   siMfDecCont = FALSE;
   siMfLen = 0;
   for (siMfSp = 0; siMfSp < MF_STKSIZE; siMfSp++)
      siMfStk[siMfSp] = 0;
   siMfSp = MF_STKSIZE; 
   siMfOctet = 0;
   siMfCodeSet = 0;
   siMfShftLock = 0;
   RETVALUE(MFROK);
} /* end of siMfInit */

  
/*
*
*       Fun:   siMfReinitMsgCtl
*
*       Desc:  message function - reinit message control structure
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfReinitMsgCtl
(
SiMfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 siMfReinitMsgCtl(msgCtlp)
SiMfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
   U16 i;                 /* counter */

   TRC2(siMfReinitMsgCtl)
   siMfBackOut = 0;
   if (msgCtlp)
   {
      msgCtlp->mdbp = NULLP;
      msgCtlp->errCnt = 0;
      msgCtlp->octIdx = 0;
      msgCtlp->bitIdx = 0;
      msgCtlp->msgType = M_UNKNOWN;
      msgCtlp->msgIdx = MI_UNKNOWN;
      msgCtlp->smelp1 = NULLP;
      for (i = 0; i < MF_MAX_ERRORS; i++)
      {
         msgCtlp->ee[i].elmtId  = ME_UNKNOWN;
         msgCtlp->ee[i].elmtIdx = MEI_UNKNOWN;
         msgCtlp->ee[i].tknIdx  = MEI_UNKNOWN;
         msgCtlp->ee[i].siMfCauseDgn.eh.pres = NOTPRSNT;
         msgCtlp->ee[i].siMfCauseDgn.causeVal.pres = NOTPRSNT;
      }
   }
   RETVALUE(MFROK);
} /* end of siMfReinitMsgCtl */

  
/*
*
*       Fun:   siMfInitMsgCtl
*
*       Desc:  message function - init message control structure
*
*       Ret:   MFROK      - ok
*
*       Notes: 
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siMfInitMsgCtl
(
SiMfMsgCtl *msgCtlp           /* pointer to message control structure */
)
#else
PUBLIC S16 siMfInitMsgCtl(msgCtlp)
SiMfMsgCtl *msgCtlp;          /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;                   /* counter */

   TRC2(siMfInitMsgCtl)
   siMfBackOut = 0;
   msgCtlp->mdbp = NULLP;
   msgCtlp->mode = NOTPRSNT;
   msgCtlp->swtch = 0;
   msgCtlp->flags = 0;
   msgCtlp->errCnt = 0;
   msgCtlp->octIdx = 0;
   msgCtlp->bitIdx = 0;
   msgCtlp->msgType = M_UNKNOWN;
   msgCtlp->msgIdx = MI_UNKNOWN;
   msgCtlp->smelp1 = NULLP;
   for (i = 0; i < MF_MAX_ERRORS; i++)
   {
      msgCtlp->ee[i].elmtId  = ME_UNKNOWN;
      msgCtlp->ee[i].elmtIdx = MEI_UNKNOWN;
      msgCtlp->dup1 = (ElmtHdr *) NULLP;
      msgCtlp->dup2 = (ElmtHdr *) &msgCtlp->ee[i].siMfCauseDgn;
      msgCtlp->mep = &siMfMeCauseDgn;
      ret = siMfInitElmt(msgCtlp);
   }      
#ifdef SI
      msgCtlp->uBuf = NULLP;
#endif /* SI */
   RETVALUE(ret);
} /* end of siMfInitMsgCtl */

  
/*
*
*       Fun:   siMfMsgRet
*
*       Desc:  message function - return error structure
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siMfMsgRet
(
SiMfMsgCtl *msgCtlp,          /* pointer to message control structure */
U16 err,                    /* error */
U16 line                    /* line number */
)
#else
PUBLIC S16 siMfMsgRet(msgCtlp, err, line)
SiMfMsgCtl *msgCtlp;          /* pointer to message control structure */
U16 err;                    /* error */
U16 line;                   /* line number */
#endif
{
   U8 errCnt;               /* error counter */
#ifdef DBG4
   Txt prntBuf[PRNTSZE];    /* print buffer */
#endif

   TRC2(siMfMsgRet)
   if ((err != MFROK) && (siMfBackOut == 0))
   { 
#ifdef DBG4
      sprintf(prntBuf, "siMfMsgRet: err: %04d, line: %05d\n", err, line);
      SPrint(prntBuf);
#endif
      siMfBackOut = 1;
      /* the following check is needed to keep index, errCnt, within bounds
       * i.e. when msgCtlp->errCnt equals MF_MAX_ERRORS
       */
      errCnt = (U8) MIN((U8) msgCtlp->errCnt, (U8) (MF_MAX_ERRORS - 1));
      msgCtlp->line = line;
      msgCtlp->ee[errCnt].siMfCauseDgn.eh.pres = PRSNT_NODEF; 
      msgCtlp->ee[errCnt].siMfCauseDgn.causeVal.pres = PRSNT_NODEF; 
      msgCtlp->ee[errCnt].siMfCauseDgn.causeVal.val = (U8) err; 
      if (err == MFCCNOMSGTYP)
      { 
         msgCtlp->ee[errCnt].siMfCauseDgn.dgnVal.pres = PRSNT_NODEF; 
         msgCtlp->ee[errCnt].siMfCauseDgn.dgnVal.len = 1; 
         msgCtlp->ee[errCnt].siMfCauseDgn.dgnVal.val[0] 
            = msgCtlp->msgType; 
      } 
      else if (err != MFCCINVMSG) 
      { 
         msgCtlp->ee[errCnt].siMfCauseDgn.dgnVal.pres = PRSNT_NODEF; 
         msgCtlp->ee[errCnt].siMfCauseDgn.dgnVal.len = 1;
         msgCtlp->ee[errCnt].siMfCauseDgn.dgnVal.val[0] = 
            (U8) msgCtlp->ee[errCnt].elmtId; 
      } 
      
      /* call users error mapping function */
      if (msgCtlp->cfgp->errMapFunc != NULLP)
         (*msgCtlp->cfgp->errMapFunc)
            (msgCtlp, msgCtlp->usrErrStP);

      /* bump error counter */
      if (errCnt < MF_MAX_ERRORS) 
         msgCtlp->errCnt++; 
   } 
   RETVALUE(err); 
} /* end of siMfMsgRet */

  
/*
*
*       Fun:   siMfInitProf
*
*       Desc:  message function - initialization of profiles
*
*       Ret:   MFROK      - ok
*
*       Notes: Initializes one or more profiles, called at startup.
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siMfInitProf
(
SiMfCfgProf *siMfCfgProfPtr     /* pointer to configuration profile */
)
#else
PUBLIC S16 siMfInitProf(siMfCfgProfPtr)
SiMfCfgProf *siMfCfgProfPtr;    /* pointer to configuration profile */
#endif
{
   S16 ret;                 /* return code */
   SiMfCfgProf *siMfCp;         /* pointer to configuration profile */

   TRC2(siMfInitProf)
   ret = MFROK;
   siMfCp = siMfCfgProfPtr;
   siMfMaxRepElmt = (U16)siMfCp->maxRepElmt;
   if (siMfInitFlag == FALSE)
      siMfInit();
   RETVALUE(ret);
} /* end of siMfInitProf */


  
/*
*
*       Fun:   siMfDecMsgType
*
*       Desc:  message function - decode message type
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfDecMsgType
(
SiMfMsgCtl *msgCtlp,          /* pointer to message control structure */
Data c                      /* message type octet */
)
#else
PRIVATE S16 siMfDecMsgType(msgCtlp, c)
SiMfMsgCtl *msgCtlp;          /* pointer to message control structure */
Data c;                     /* message type octet */
#endif
{
   CONSTANT SiMsgElmtDef *CONSTANT *melp;  /* pointer to message element list 
                                            pointers */
   U16 i;                                /* counter */
   U16 swtch;                            /* switch index */
   CONSTANT SiMsgDef *allPduDefs;          /* pointer to all pdu definition 
                                            structure */

   TRC2(siMfDecMsgType)
   swtch = msgCtlp->swtch;
   allPduDefs = msgCtlp->cfgp->pduDefs;
   melp = NULLP;

   /* validate msg type */

   for (i = 0; allPduDefs[i].melp; i++)
   {
      if ((c == allPduDefs[i].id) && (msgCtlp->protDisc 
         == allPduDefs[i].protDisc[swtch]))
      {
         if (!(i == allPduDefs[i].idx))
         {
            MSGRET(msgCtlp, MFCCNOMSGTYP);
         }
         if (msgCtlp->validate)
         {
            /* check if message applicable for ckt/pkt/usr */
            if (!allPduDefs[i].flagp)
            {
               MSGRET(msgCtlp, MFCCNOMSGTYP);
            }
            
            if (allPduDefs[i].flagp[swtch] & MF_NA)
               continue;
         }

         melp = allPduDefs[i].melp;
         break;
      }
   }

   msgCtlp->msgType = c;
   if (melp == NULLP)
      MSGRET(msgCtlp, MFCCNOMSGTYP);

   if (i >= msgCtlp->cfgp->numPdus)
      MSGRET(msgCtlp, MFCCNOMSGTYP);

   if (msgCtlp->validate)
   {
      /* check if message applicable for ckt/pkt/usr */
      if (!allPduDefs[i].flagp)
      {
         MSGRET(msgCtlp, MFCCNOMSGTYP);
      }

      if (allPduDefs[i].flagp[swtch] & MF_NA)
      {  
         MSGRET(msgCtlp, MFCCNOMSGTYP);
      } 

   }

   msgCtlp->msgIdx = allPduDefs[i].idx;
   msgCtlp->smelp1 = melp;   
   msgCtlp->mdbp = &allPduDefs[i];

   RETVALUE(MFROK);
} /* end of siMfDecMsgType */

  
/*
*
*       Fun:   siMfEncMsgType
*
*       Desc:  message function - encode message type
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfEncMsgType
(
SiMfMsgCtl *msgCtlp,          /* pointer to message control structure */
Data c                      /* message type octet */
)
#else
PRIVATE S16 siMfEncMsgType(msgCtlp, c)
SiMfMsgCtl *msgCtlp;          /* pointer to message control structure */
Data c;                     /* message type octet */
#endif
{
   U16 i;                                /* counter */
   U16 swtch;                            /* switch index */
   CONSTANT SiMsgElmtDef *CONSTANT *melp;  /* pointer to message element list 
                                            pointers */
   CONSTANT SiMsgDef *allPduDefs;          /* pointer to all pdu definition 
                                            structure */

   TRC2(siMfEncMsgType)
   swtch = msgCtlp->swtch;
   allPduDefs = msgCtlp->cfgp->pduDefs;
   melp = NULLP;

   /* validate msg type */

   for (i = 0; allPduDefs[i].melp; i++)
   {
      if ((c == allPduDefs[i].id) && (msgCtlp->protDisc == 
         allPduDefs[i].protDisc[swtch]))
      {
         if (!(i == allPduDefs[i].idx))
         {
            MSGRET(msgCtlp, MFCCNOMSGTYP);
         }

         melp = allPduDefs[i].melp;
         break;
      }
   }

   msgCtlp->msgType = c;
   if (melp == NULLP)
   {  
      MSGRET(msgCtlp, MFCCNOMSGTYP);
   } 


   if (msgCtlp->validate)
   {
      /* check if message applicable for ckt/pkt/usr */
      if (!(allPduDefs[i].flagp))
      {
         MSGRET(msgCtlp, MFCCNOMSGTYP);
      }
      if (allPduDefs[i].flagp[swtch] & MF_NA)
      {  
         MSGRET(msgCtlp, MFCCNOMSGTYP);
      } 

   }

   msgCtlp->msgIdx = (U8) i;
   msgCtlp->smelp1 = melp;   
   msgCtlp->mdbp = &allPduDefs[i];

   RETVALUE(MFROK);
} /* end of siMfEncMsgType */

  
/*
*
*       Fun:   siMfChkEnum
*
*       Desc:  message function - check enumerated list
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siMfChkEnum
(
REG1 U32 val,               /* enumerated value */
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
Swtch swtch                 /* switch */
)
#else
PUBLIC S16 siMfChkEnum(val, tep, swtch)
REG1 U32 val;               /* enumerated value */
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
Swtch swtch;                /* switch */
#endif
{
   REG2 SiTknEnum *elistp;    /* enum list pointer */
   REG3 U32 i;              /* counter */
   REG4 U32 ecnt;           /* enumerated element count */

   TRC2(siMfChkEnum)
   elistp = tep->elist[swtch];

   if (!elistp)
   {
      RETVALUE(MFCCINVINFOEL);
   }

   ecnt = (U16) *elistp;
   elistp++;

   for (i = 0; i < ecnt; i++)
   {
      if (val == *elistp)
         RETVALUE(MFROK);
      elistp++;
   } 
   RETVALUE(MFCCINVINFOEL);
} /* end of siMfChkEnum */

  
/*
*
*       Fun:   siMfPushFlag
*
*       Desc:  message function - push flag
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfPushFlag
(
Bool flag                   /* flag to push, true or false */
)
#else
PRIVATE S16 siMfPushFlag(flag)
Bool flag;                  /* flag to push, true or false */
#endif
{
   TRC2(siMfPushFlag)
   siMfStk[--siMfSp] = flag;
   if (siMfSp == 0)
      siMfSp = MF_STKSIZE;
   RETVALUE(MFROK);
} /* end of siMfPushFlag */

  
/*
*
*       Fun:   siMfChkFlag
*
*       Desc:  message function - check flag
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfChkFlag
(
U8 idx                      /* stack backward index */
)
#else
PRIVATE S16 siMfChkFlag(idx)
U8 idx;                     /* stack backward index */
#endif
{
   U16 sidx;                /* absolute stack index */

   TRC2(siMfChkFlag)
   sidx = (siMfSp + idx) & (MF_STKSIZE - 1);
   RETVALUE(siMfStk[sidx]);
} /* end of siMfChkFlag */

/* si010.220: Deletion - delete function siMfSkipTkns definition */

  
/*
*
*       Fun:   siMfSetExt
*
*       Desc:  message function - set extension
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfSetExt
(
Buffer *mp,                /* pointer to buffer */
U8 val                     /* value */
)
#else
PRIVATE S16 siMfSetExt(mp, val)
Buffer *mp;                /* pointer to buffer */
U8 val;                    /* value */
#endif
{
   Data c;                 /* data character */
   S16 ret;

   TRC2(siMfSetExt)
   SRemPstMsg(&c, mp);
   c &= 0x7f;
   if (val)
      c |= 0x80;
   ret = SAddPstMsg(c, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
   if (ret != ROK)
   {  
      RETVALUE(MFRESFAILURE);
   } 

#endif
   RETVALUE(MFROK);
} /* end of siMfSetExt */

  
/*
*
*       Fun:   siMfSetFlag
*
*       Desc:  message function - set flag
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfSetFlag
(
U8 reg,                    /* register value */
Buffer *mp                 /* message pointer */
)
#else
PRIVATE S16 siMfSetFlag(reg, mp)
U8 reg;                    /* register value */
Buffer *mp;                /* message pointer */
#endif
{
   U8 treg;                /* register value */
   Buffer *tmp;            /* message pointer */

   TRC2(siMfSetFlag)

   /* RG: only dynamic variables initialized! */
   treg = reg;
   tmp = mp;

   RETVALUE(MFROK);
} /* end of siMfSetFlag */

  
/*
*
*       Fun:   siMfDecU8
*
*       Desc:  message function - decode unsigned 8 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfDecU8
(
Buffer *mp,
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
SiMfMsgCtl *msgCtlp           /* pointer to message control structure */
)
#else
PRIVATE S16 siMfDecU8(mp, tep, msgCtlp)
Buffer *mp;
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
SiMfMsgCtl *msgCtlp;          /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   S16 ret1;                 /* return code */
   Data c;                  /* data character */
   U8 val;                  /* token value */
   TknU8 *tp;               /* token pointer */

   TRC2(siMfDecU8)
   ret = 0xff;
   ret1 = MFROK;
   /* if token present based on last ext flag and not extended */
   tp = (TknU8 *) msgCtlp->dup1;
   tp->pres = NOTPRSNT;
   /* bump message structure ptr */
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */   
   ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU8));
   if (msgCtlp->elen == 0)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
      {  
         MSGRET(msgCtlp, MFCCINVINFOEL);
      } 

      if (*tep->flagp & TF_PEXTN)
      {
         if (siMfChkFlag(tep->reg))
         {  
            MSGRET(msgCtlp, MFCCINVINFOEL);
         } 

      }
      else if ((*tep->flagp & TF_PEXT) && (siMfExt == 0))
      {  
         MSGRET(msgCtlp, MFCCINVINFOEL);
      } 

      RETVALUE(MFROK);
   }

   if (*tep->flagp & TF_PEXTN) 
   {
      if (siMfChkFlag(tep->reg) == 0)
         RETVALUE(MFROK);
   }
   else if ((*tep->flagp & TF_PEXT) && (siMfExt))
      RETVALUE(MFROK);
   else if ((*tep->flagp & TF_PLEN) && (siMfLen < 1))
      RETVALUE(ROK);

   /* token must be present, check it */
   if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
   {  
      MSGRET(msgCtlp, MFCCINVMSG);
   } 

   val = (U8)(c >> tep->offset);
   if (tep->mask)
      val &= (U8) tep->mask;

   /* if token is a message type field */
   if (*tep->flagp & TF_MSGTYP)
   {
      if ((ret = siMfDecMsgType(msgCtlp, val)) != MFROK)
         RETVALUE(ret);
   }
   else if (msgCtlp->validate)
      if ((val < (U8) tep->minVal) || (val > (U8) tep->maxVal))
      {  
         MSGRET(msgCtlp, MFCCINVINFOEL);
      } 


   /* if there is a user function, execute it */
   if (tep->func)
   {
      ret = (*tep->func)(msgCtlp, (PTR) &val);
      switch (ret)
      {
         case MFREOM:
         case MFRFAILED:
         case MFCCINVMSGLEN:
         case MFROK:
            break;
         case MFSKIP1TKNSEXT:
         case MFSKIP2TKNSEXT:
         /* Skip 5 and 6 tokens, as returned by escape function */
         case MFSKIP5TKNS:
         case MFSKIP6TKNS:
         /* si032.220: addition - added cases of skip token 11 and 16 */
         case MFSKIP16TKNS:
         case MFSKIP11TKNS:
         /* si032.220: modification - moved skip 20 and 1 to here, since 
          * the decoded token still needs to be stored in the data structure */
         case MFSKIP20TKNS:
         case MFSKIP1TKNS:
            ret1 = ret;
            break;

         default:
            MSGRET(msgCtlp, ret);
      }
   }

   if (ret == MFREOM)
   {
      if ((msgCtlp->validate) && ((ret = siMfChkEnum((U32) val, tep, 
           msgCtlp->swtch)) != MFROK))
      {  
         MSGRET(msgCtlp, ret);
      } 

   }
   else
      if (ret == MFRFAILED)
      {
         siMfExt = 1;
         RETVALUE(MFROK);
      }

   /* if last token in octet */
   msgCtlp->bitIdx += tep->maxLen;
   if (*tep->flagp & TF_EXT)
   {
      siMfExt = (U8)(c & 0x80);
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
      if (*tep->flagp & TF_PLEN)
         siMfLen--;
   }
   else if (*tep->flagp & TF_NEXT)
   {
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
      if (*tep->flagp & TF_PLEN)
         siMfLen--;
   }
#ifdef SS7
   else if ( ((msgCtlp->cfgp->flags & MF_ISUP) || 
              (msgCtlp->cfgp->flags & MF_TUP) ||
              (msgCtlp->cfgp->flags & MF_SCCP)) 
              && (*tep->flagp & TF_LAST) )
   {
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
   }
#endif /* SS7 */

   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         siMfPushFlag(1);
      else siMfPushFlag(0);      
   }

   /* if token is a length field, save it */
   if (*tep->flagp & TF_LEN)
     siMfLen = val;

   /* save token info in msg struct */
   if (msgCtlp->decode)
   {
      tp->pres = PRSNT_NODEF;
      tp->val  = val;
   }

   /* si032.220: modification - make return logic simple */
   /* Return correct RETVALUE so that tokens can be skipped */
   switch (ret1)
   {
      case MFSKIP2TKNSEXT:
         RETVALUE(MFSKIP2TKNS);

      case MFSKIP1TKNSEXT:
         RETVALUE(MFSKIP1TKNS);

      case MFSKIP5TKNS:
      case MFSKIP6TKNS:
      case MFSKIP20TKNS:
      case MFSKIP1TKNS:
      case MFSKIP16TKNS:
      case MFSKIP11TKNS:
         RETVALUE(ret1);

      default:
         break;
   }

   RETVALUE(MFROK);
} /* end of siMfDecU8 */

  
/*
*
*       Fun:   siMfEncU8
*
*       Desc:  message function - encode unsigned 8 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfEncU8
(
Buffer *mp,
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
SiMfMsgCtl *msgCtlp           /* pointer to message control structure */
)
#else
PRIVATE S16 siMfEncU8(mp, tep, msgCtlp)
Buffer *mp;
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
SiMfMsgCtl *msgCtlp;          /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   S16 ret1;                 /* return code */
   U8 val;                  /* token value */
   TknU8 *tp;               /* token pointer */

   TRC2(siMfEncU8)
   ret1 = MFROK;
   /* check mandatory dependencies */
   tp = (TknU8 *) msgCtlp->dup1;
   /* bump message structure ptr */
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */   
   ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU8));
   if (!tp->pres)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
      {  
         MSGRET(msgCtlp, MFCCINVINFOEL);
      } 
      else 
         RETVALUE(MFROK);
   }

   /* token is present, check dependencies */
   if (*tep->flagp & TF_PEXTN)
   {
      if (msgCtlp->encode)
         siMfSetFlag(tep->reg, mp);
   }
   else if (*tep->flagp & TF_PEXT)
   {
      if (msgCtlp->encode)
      {
         siMfExt = 0;
         ret = siMfSetExt(mp, siMfExt);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret)
         {  
            MSGRET(msgCtlp, ret);
         } 

#endif
      }
   }

   /* token is present, check it */
   val = tp->val;      

   /* if token is a message type field */
   if (*tep->flagp & TF_MSGTYP)
   {
      if ((ret = siMfEncMsgType(msgCtlp, val)) != MFROK)
         RETVALUE(ret);
   }
   else if (msgCtlp->validate)
      if ((val < (U8) tep->minVal) || (val > (U8) tep->maxVal))
      {  
         MSGRET(msgCtlp, MFCCINVINFOEL);
      } 


   siMfOctet |= val << tep->offset;

   /* if there is a user function, execute it */
   if (tep->func)
   {  
      ret = (*tep->func)(msgCtlp, (PTR) &val);
/* KRP - for FN lyr identifiers */
#ifdef FN
      if((msgCtlp->cfgp->flags & FN_MF) && (ret == FN_MFRET))
         siMfOctet = val;
      else
#endif
      {
         switch( ret )
         {
            case MFSKIP1TKNSCPY:
            case MFSKIP1TKNSEXT:
               ret1 = ret;
               break;
            case MFSKIP2TKNSCPY:
               siMfOctet |= val;
               ret1 = ret;
               break;
            case MFROK:
               break;
            default:
               MSGRET(msgCtlp, ret);
         }
      }
   }
   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         siMfPushFlag(1);
      else siMfPushFlag(0);      
   }

   /* if last token in octet */
   msgCtlp->bitIdx += tep->maxLen;
   if ((*tep->flagp & TF_EXT) || (*tep->flagp & TF_NEXT))
   {
      if ((U8 )(tep->offset + tep->maxLen) < (U8 )8)
            siMfOctet |= 0x80;
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg(siMfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
         {  
            MSGRET(msgCtlp, MFRESFAILURE);
         } 

#endif
      }

      siMfOctet = 0;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }
#ifdef SS7
   else if ( ((msgCtlp->cfgp->flags & MF_ISUP) || 
              (msgCtlp->cfgp->flags & MF_TUP) ||
              (msgCtlp->cfgp->flags & MF_SCCP))
              && (*tep->flagp & TF_LAST) )
   {
      U8 diff;
      diff = (U8)(tep->offset + tep->maxLen);
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg(siMfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
         {  
            MSGRET(msgCtlp, MFRESFAILURE);
         } 

#endif
      }

      if  (diff < (U8)8)
         msgCtlp->bitIdx += diff;
      siMfOctet = 0;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }
#endif /* SS7 */
   if ((ret1 == MFSKIP1TKNSEXT) || (ret1 == MFSKIP1TKNSCPY))
      RETVALUE(ret1);

   if (ret1 == MFSKIP2TKNSCPY)
   {  
      /* Code to add one byte to the buffer only for the non-extension token
       */
      if ((msgCtlp->encode) &&
          (!(*tep->flagp & TF_EXT) || (*tep->flagp & TF_NEXT)))
      {
         ret = SAddPstMsg(siMfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
      siMfOctet = 0;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
      RETVALUE(ret1);
   }
   RETVALUE(MFROK);
} /* end of siMfEncU8 */

  
/*
*
*       Fun:   siMfDecU8Enum
*
*       Desc:  message function - decode unsigned 8 bit enumerated list
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfDecU8Enum
(
Buffer *mp,                /* message pointer */
CONSTANT SiTknElmtDef *tep,  /* token element definition pointer */
SiMfMsgCtl *msgCtlp          /* message control pointer */
)
#else
PRIVATE S16 siMfDecU8Enum(mp, tep, msgCtlp)
Buffer *mp;                /* message pointer */
CONSTANT SiTknElmtDef *tep;  /* token element definition pointer */
SiMfMsgCtl *msgCtlp;         /* message control pointer */
#endif
{
   S16 ret;                /* return code */
   Data c;                 /* data character */
   U8 val;                 /* token value */
   TknU8 *tp;              /* token pointer */
   S16 ret1;               /* REturn code */
   U8 XchgType;            /* type of exchange */
   U32 ActIndVal;           /* Action indicator - specifies action to
                              take in case the token value is bad */

   TRC2(siMfDecU8Enum)

   ret = MFROK;
   XchgType = msgCtlp->xchgType;
   ActIndVal = NULLP;

   /* if token present based on last ext flag and not extended */
   tp = (TknU8 *) msgCtlp->dup1;
   tp->pres = NOTPRSNT;
   /* bump message structure ptr */
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */   
   ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU8));
   if (msgCtlp->elen == 0)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
      {  
         MSGRET(msgCtlp, MFCCINVINFOEL);
      } 

      if (*tep->flagp & TF_PEXTN) 
      {
         if (siMfChkFlag(tep->reg))
         {  
            MSGRET(msgCtlp, MFCCINVINFOEL);
         } 

      }
      else if ((*tep->flagp & TF_PEXT) && (siMfExt == 0))
      {  
         MSGRET(msgCtlp, MFCCINVINFOEL);
      } 

      RETVALUE(MFROK);
   }

   if (*tep->flagp & TF_PEXTN) 
   {
      if (siMfChkFlag(tep->reg) == 0)
         RETVALUE(MFROK);
   }
   else if ((*tep->flagp & TF_PEXT) && (siMfExt))
      RETVALUE(MFROK);
   else if ((*tep->flagp & TF_PLEN) && (siMfLen < 1))
      RETVALUE(ROK);

   /* token must be present, check it */
   if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
   {  
      MSGRET(msgCtlp, MFCCINVMSG);
   } 

   val = (U8)(c >> tep->offset);
   if (tep->mask)
      val &= (U8) tep->mask;

   /* if token is a message type field */
   if (*tep->flagp & TF_MSGTYP)
   {
      if ((ret = siMfDecMsgType(msgCtlp, val)) != MFROK)
         RETVALUE(ret);
   }
   else if ((msgCtlp->validate) && ((ret1 = siMfChkEnum((U32) val, tep, 
             msgCtlp->swtch)) != MFROK))
         {
            if (XchgType & TOXA) 
            {
               if (tep->teActIndA != NULLP)
                   ActIndVal = tep->teActIndA[msgCtlp->swtch];
            }
            else 
            {
               if (tep->teActIndB != NULLP)
                   ActIndVal = tep->teActIndB[msgCtlp->swtch];
            }
            if (ActIndVal == NULLP)
            {  
               MSGRET(msgCtlp, ret1);
            } 
            else
            {
               switch (ActIndVal)
               {
                  case SIMF_DISCPARM:
                     MSGRET(msgCtlp, SIMF_DISCPARM);
                  case SIMF_DISCMSG:
                     MSGRET(msgCtlp, SIMF_DISCMSG);
                  case SIMF_REL_CAUSE28:
                     MSGRET(msgCtlp, SIMF_REL_CAUSE28);
                  case SIMF_REL_CAUSE111:
                     MSGRET(msgCtlp, SIMF_REL_CAUSE111);
                  case SIMF_REL_CAUSE65:
                     MSGRET(msgCtlp, SIMF_REL_CAUSE65);
                  case SIMF_DISCMSG_CFN_CAUSE110:
                     MSGRET(msgCtlp, SIMF_DISCMSG_CFN_CAUSE110);
                  case SIMF_REL_CCPROTERR:
                     MSGRET(msgCtlp, SIMF_REL_CCPROTERR);
                  default:  /* Check in end if action=DFLT,NODFLT,IGNORE */
                     break;
               }
            }
         }

   /* if there is a user function, execute it */
   if (tep->func)
   {
      ret = (*tep->func)(msgCtlp, (PTR) &val);
      switch ( ret )
      {
         case MFSKIPNXTU8LSTTKN:
         /* Skip 19 tokens, as returned by escape function */ 
         case MFSKIP19TKNS:
         case MFSKIP6TKNS:
         case MFSKIP5TKNS:
         case MFSKIP3TKNS:
         case MFSKIP2TKNS:
         case MFSKIP1TKNS:
         case MFROK:
         /* si009.220, ADDED: added one case to handle the cause value */
         case MFCAUSEVAL:
            break;
         default:
            MSGRET(msgCtlp, ret);
      }
   }


   /* if last token in octet */
   msgCtlp->bitIdx += tep->maxLen;
   if (*tep->flagp & TF_EXT)
   {
      siMfExt = (U8)(c & 0x80);
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
      if (*tep->flagp & TF_PLEN)
         siMfLen--;
   }
   else if (*tep->flagp & TF_NEXT)
   {
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
      if (*tep->flagp & TF_PLEN)
         siMfLen--;
   }
#ifdef SS7
   else if ( ((msgCtlp->cfgp->flags & MF_ISUP) || 
              (msgCtlp->cfgp->flags & MF_TUP) ||
              (msgCtlp->cfgp->flags & MF_SCCP))
              && (*tep->flagp & TF_LAST) )
   {
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
   }
#endif /* SS7 */

   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         siMfPushFlag(1);
      else siMfPushFlag(0);      
   }

   /* if token is a length field, save it */
   if (*tep->flagp & TF_LEN)
     siMfLen = val;

   /* save token info in msg struct */
   if (msgCtlp->decode)
   {
      tp->pres = PRSNT_NODEF;
#if SI_ALLOW_PRSNT_INVALID
      if ((ActIndVal == SIMF_NODFLT) ||
         (ActIndVal == SIMF_DFLT) ||
         (ActIndVal == SIMF_IGNORE))
         tp->pres = PRSNT_INVALID;

      tp->val = val;
#else
      if( (ActIndVal == SIMF_DFLT) && (tep->defs) )
      /* si009.220, MODIFIED: need to take action if the token is cause value
       */
      {
         if (ret == MFCAUSEVAL)
            tp->val = (U8 ) siMfGetCauseDef(val);
         else
            tp->val = (U8 ) tep->defs[msgCtlp->swtch];
      }
      else
         tp->val = val;
#endif /* SI_ALLOW_PRSNT_INVALID */
   }
   if( ret == MFSKIPNXTU8LSTTKN )
   {
      /* as next token is U8 */
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */      
      ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU8));
      /* as it is the last token */
      msgCtlp->octIdx += 1;
      msgCtlp->elen  -= 1;
   }
   RETVALUE(ret);
} /* end of siMfDecU8Enum */

  
/*
*
*       Fun:   siMfEncU8Enum
*
*       Desc:  message function - encode unsigned 8 bit enumerated list
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfEncU8Enum
(
Buffer *mp,
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
SiMfMsgCtl *msgCtlp           /* pointer to message control structure */
)
#else
PRIVATE S16 siMfEncU8Enum(mp, tep, msgCtlp)
Buffer *mp;
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
SiMfMsgCtl *msgCtlp;          /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U8 val;
   TknU8 *tp;

   TRC2(siMfEncU8Enum)
   ret = MFROK;
   /* check mandatory dependencies */
   tp = (TknU8 *) msgCtlp->dup1;
   /* bump message structure ptr */
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */   
   ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU8));
   if (!tp->pres)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
      {  
         MSGRET(msgCtlp, MFCCINVINFOEL);
      } 
      else
         RETVALUE(MFROK);
   }

   /* token is present, check dependencies */
   if (*tep->flagp & TF_PEXTN)
   {
      if (msgCtlp->encode)
         siMfSetFlag(tep->reg, mp);
   }
   else if (*tep->flagp & TF_PEXT)
   {
      if (msgCtlp->encode)
      {
         siMfExt = 0;
         ret = siMfSetExt(mp, siMfExt);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret)
            MSGRET(msgCtlp, ret);
#endif
      }
   }

   /* token is present, check it */
   val = tp->val;      

   /* if token is a message type field */
   if (*tep->flagp & TF_MSGTYP)
   {
      if ((ret = siMfEncMsgType(msgCtlp, val)) != MFROK)
         RETVALUE(ret);
   }
   else if (msgCtlp->validate) 
        {
           if ((tp->pres != PRSNT_INVALID) && 
              ((ret = siMfChkEnum((U32) val, tep, msgCtlp->swtch)) != MFROK))
           MSGRET(msgCtlp, ret);
        }
   siMfOctet |= val << tep->offset;

   /* if there is a user function, execute it */
   if (tep->func)
   {
      ret = (*tep->func)(msgCtlp, (PTR) &val);
      switch( ret )
      {
         case MFCPYVAL:
            siMfOctet = val;
            break;
         case MFROK:
         case MFSKIPNXTU8LSTTKN:
/* si013.220, REMOVED: Deleted errors introduced by si012.220 */
/*  si012.220 : ADDIITON, Added the case for Telcordia */
            break;
         default:
            MSGRET(msgCtlp, ret);
      }
   }

   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         siMfPushFlag(1);
      else siMfPushFlag(0);      
   }

   /* save token info in msg struct */
   /* if last token in octet */
   msgCtlp->bitIdx += tep->maxLen;
   if ((*tep->flagp & TF_EXT) || (*tep->flagp & TF_NEXT))
   {
      if ((U8 )(tep->offset + tep->maxLen) < (U8 )8)
         siMfOctet |= 0x80;
/* si013.220, REMOVED: Deleted errors introduced by si012.220 */
/* si012.220 , ADDITION: Added cause value for Telcordia variant to reset the last
                         bit to 0 */
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg(siMfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
      siMfOctet = 0;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }
#ifdef SS7
   else if ( ((msgCtlp->cfgp->flags & MF_ISUP) || 
              (msgCtlp->cfgp->flags & MF_TUP) ||
              (msgCtlp->cfgp->flags & MF_SCCP))
              && (*tep->flagp & TF_LAST) )
   {
      U8 diff;
      diff = (U8)(tep->offset + tep->maxLen);
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg(siMfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }

      if  (diff < (U8)8)
         msgCtlp->bitIdx += diff; /* step past spare bits */
      siMfOctet = 0;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }
#endif /* SS7 */
   if( ret == MFSKIPNXTU8LSTTKN )
   {
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg(siMfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */      
      ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU8));
      siMfOctet = 0;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
      RETVALUE(MFSKIPNXTU8LSTTKN);
   }
   RETVALUE(MFROK);
} /* end of siMfEncU8Enum */


/*
*
*       Fun:   siMfDecBits
*
*       Desc:  message function - decode bit string (portable version)
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/

#ifdef ANSI
PRIVATE S16 siMfDecBits
(
Buffer *mp,
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
SiMfMsgCtl *msgCtlp           /* pointer to message control structure */
)
#else
PRIVATE S16 siMfDecBits(mp, tep, msgCtlp)
Buffer *mp;
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
SiMfMsgCtl *msgCtlp;          /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   Data c;                  /* data character */
   TknU16 *tp;
   TknU32 *tp1;
   U16 word, word1;
   U32 val;
   
   TRC2(siMfDecBits);

   /* initialize token structure */
   tp = NULLP;
   tp1 = NULLP;


   switch(tep->maxLen)
   {
      case 2:                              /* 16 Bits */
         tp = (TknU16 *) msgCtlp->dup1;
         tp->pres = NOTPRSNT;

         word = 0;

/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */         
         ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU16));

         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word = (U16) PutLoByte(word, c);
         msgCtlp->octIdx++;

         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word = (U16) PutHiByte(word, c);
         msgCtlp->octIdx++;

         if (tep->mask)
         word &= tep->mask;

         if ( msgCtlp->validate && 
            ((word < (U16) tep->minVal) || (word > (U16) tep->maxVal)) )
               MSGRET(msgCtlp, MFCCINVINFOEL);

         if ((tep->type == TET_BITS_ENUM) && (msgCtlp->validate))
         {
            if ((ret = siMfChkEnum((U32) word, tep, msgCtlp->swtch)) != MFROK)
               MSGRET(msgCtlp, ret);
         }
         tp->val = (U16)word;
         tp->pres = PRSNT_NODEF;
         msgCtlp->elen -=2;
         break;
      case 3:                  /* 24 Bits */
         tp1 = (TknU32 *) msgCtlp->dup1;
         tp1->pres = NOTPRSNT;
         word = 0;
         val = 0;

/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */         
         ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU32));

         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word = (U16) PutLoByte(word, c);
         msgCtlp->octIdx++;

         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word = (U16) PutHiByte(word, c);
         msgCtlp->octIdx++;

         word1=0;
         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word1 = (U16) PutLoByte(word1, c);
         msgCtlp->octIdx++;

         val = PutLoWord(val, word);
         val = PutHiWord(val, word1);

         if (tep->mask)
         val &= tep->mask;
         if ( msgCtlp->validate && 
            ((val < (U32) tep->minVal) || (val > (U32) tep->maxVal)) )
               MSGRET(msgCtlp, MFCCINVINFOEL);
         if ((tep->type == TET_BITS_ENUM) && (msgCtlp->validate))
         {
            if ((ret = siMfChkEnum((U32)val, tep, msgCtlp->swtch)) != MFROK)
               MSGRET(msgCtlp, ret);
         }
         tp1->val = val;
         tp1->pres = PRSNT_NODEF;
         msgCtlp->elen -=3;
         break;
      case 4:                  /* 32 Bits */
         tp1 = (TknU32 *) msgCtlp->dup1;
         tp1->pres = NOTPRSNT;

         word = 0;
         val = 0;  /* RG: added initialization */

/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
         ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU32));

         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word = (U16) PutLoByte(word, c);
         msgCtlp->octIdx++;

         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word = (U16) PutHiByte(word, c);
         msgCtlp->octIdx++;

         word1 = 0;
         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word1 = (U16) PutLoByte(word1, c);
         msgCtlp->octIdx++;

         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word1 = (U16) PutHiByte(word1, c);
         msgCtlp->octIdx++;

         val = PutLoWord(val, word);
         val = PutHiWord(val, word1);

         if (tep->mask)
         val &= tep->mask;

         if ( msgCtlp->validate && ((val < (U32) tep->minVal) || 
               (val > (U32) tep->maxVal)) )
            MSGRET(msgCtlp, MFCCINVINFOEL);

         if ((tep->type == TET_BITS_ENUM) && (msgCtlp->validate))
         {
            if ((ret = siMfChkEnum((U32) val, tep, msgCtlp->swtch)) != MFROK)
               MSGRET(msgCtlp, ret);
         }

         tp1->val = val;
         tp1->pres = PRSNT_NODEF;
         msgCtlp->elen-=4;

         break;
      default:
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }
   if (tep->func)
   {
      if (tep->maxLen <= 2)
      {
         ret = (*tep->func)(msgCtlp,  (PTR) &tp->val);
         if (ret != MFROK)
            MSGRET(msgCtlp, ret);
      }
      else
      {
         ret = (*tep->func)(msgCtlp, (PTR) &tp1->val);
         if (ret != MFROK)
            MSGRET(msgCtlp, ret);
      }
   }
      RETVALUE(MFROK);
} /* end of siMfDecBits */


/*
*
*       Fun:   siMfEncBits
*
*       Desc:  message function - encode bit string
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
#ifdef ANSI
PRIVATE S16 siMfEncBits
(
Buffer *mp,
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
SiMfMsgCtl *msgCtlp           /* pointer to message control structure */
)
#else
PRIVATE S16 siMfEncBits(mp, tep, msgCtlp)
Buffer *mp;
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
SiMfMsgCtl *msgCtlp;          /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   TknU16 *tp16;
   TknU32 *tp32;
   U16 val16;               /* 32 bit value */
   U32 val32;               /* 32 bit value */
/* bn */
   U8 octet;

   TRC2(siMfEncBits)
   /* check mandatory dependencies */
   switch( tep->maxLen)
   {
      case 2:
         tp16 = (TknU16 *) msgCtlp->dup1;
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
         ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU16));
         if (!tp16->pres)
         {
            if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
            {  
               MSGRET(msgCtlp, MFCCINVINFOEL);
            } 
            else
               RETVALUE(MFROK);
         }
         val16 = (U16) tp16->val;
         if ( (tep->type == TET_BITS) && (msgCtlp->validate) )
         {
            if ((val16 < (U16) tep->minVal) || (val16 > (U16) tep->maxVal))
               MSGRET(msgCtlp, MFCCINVINFOEL);
         }
         else if ( (tep->type == TET_BITS_ENUM) && (msgCtlp->validate) )
         {
            if ((ret = siMfChkEnum((U32)val16, tep, msgCtlp->swtch)) != MFROK)
               MSGRET(msgCtlp, ret);
         }
         if (tep->func)
         if ((ret = (*tep->func)(msgCtlp, (PTR) &tp16->val)) 
               != MFROK)
            MSGRET(msgCtlp, ret);

/* bn */
         if (!tep->offset)
         {
            siMfOctet = (U8)GetLoByte(val16);
            octet = 0;
         }
         else  /* not the first token in the octet */
         {
            octet = (U8)GetLoByte(val16);
            siMfOctet = (U8) (((octet << tep->offset) & 0xf0) | siMfOctet);
         }
/* bn */

         if (msgCtlp->encode)
         {
            ret = SAddPstMsg(siMfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
         }

         msgCtlp->octIdx += 1;
         msgCtlp->bitIdx += 8;
         msgCtlp->elen += 1;

         siMfOctet = (U8)GetHiByte(val16);
/* bn */
         if (tep->offset)
            siMfOctet = (U8) (((siMfOctet << tep->offset) & 0xf0) |
                            ((octet >> tep->offset) & 0x0f));

/* bn */
         if (msgCtlp->encode)
         {
            ret = SAddPstMsg(siMfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
         }

         msgCtlp->octIdx += 1;
         msgCtlp->bitIdx += 8;
         msgCtlp->elen += 1;

         siMfOctet = 0;
         break;
      case 3:
      case 4:
         tp32 = (TknU32 *) msgCtlp->dup1;
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
         ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU32));
         if (!tp32->pres)
         {
            if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
            {  
               MSGRET(msgCtlp, MFCCINVINFOEL);
            } 
            else
               RETVALUE(MFROK);
         }
         val32 = (U32) tp32->val;
         if ( (tep->type == TET_BITS) && (msgCtlp->validate) )
         {
            if ((val32 < (U32) tep->minVal) || (val32 > (U32) tep->maxVal))
               MSGRET(msgCtlp, MFCCINVINFOEL);
         }
         else if ( (tep->type == TET_BITS_ENUM) && (msgCtlp->validate) )
         {
            if ((ret = siMfChkEnum((U32)val32, tep, msgCtlp->swtch)) != MFROK)
               MSGRET(msgCtlp, ret);
         }
         /* if there is a user function, execute it */
         if (tep->func)
            if ((ret = (*tep->func)(msgCtlp, (PTR) &tp32->val)) 
                  != MFROK)
               MSGRET(msgCtlp, ret);

         siMfOctet = (U8)GetLoByte(GetLoWord(val32));
         if (msgCtlp->encode)
         {
            ret = SAddPstMsg(siMfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
         }

         msgCtlp->octIdx += 1;
         msgCtlp->bitIdx += 8;
         msgCtlp->elen += 1;

         siMfOctet = (U8)GetHiByte(GetLoWord(val32));
         if (msgCtlp->encode)
         {
            ret = SAddPstMsg(siMfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
         }

         msgCtlp->octIdx += 1;
         msgCtlp->bitIdx += 8;
         msgCtlp->elen += 1;

         siMfOctet = (U8)GetLoByte(GetHiWord(val32));
         if (msgCtlp->encode)
         {
            ret = SAddPstMsg(siMfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
         }

         msgCtlp->octIdx += 1;
         msgCtlp->bitIdx += 8;
         msgCtlp->elen += 1;

         if (tep->maxLen == 4)
         {
            siMfOctet = (U8)GetHiByte(GetHiWord(val32));
            if (msgCtlp->encode)
            {
               ret = SAddPstMsg(siMfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif
            }

            msgCtlp->octIdx += 1;
            msgCtlp->bitIdx += 8;
            msgCtlp->elen += 1;
         }
         siMfOctet = 0;
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         MSGRET(msgCtlp, MFDEBUGERR);
#endif
   }
   RETVALUE(MFROK);
} /* end of siMfEncBits */

  
/*
*
*       Fun:   siMfDecU16
*
*       Desc:  message function - decode unsigned 16 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfDecU16
(
Buffer     *mp,
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 siMfDecU16(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;                   /* counter */
   Data c;                  /* data character */
   U16 len;                  /* token length */
   TknU16 *tp;
   U16 val;

   TRC2(siMfDecU16)

   /* if token present based on last ext flag and not extended */
   tp = (TknU16 *) msgCtlp->dup1;
   tp->pres = NOTPRSNT;
   /* bump message structure ptr */
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
   ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU16));
   if (msgCtlp->elen == 0)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if (*tep->flagp & TF_PEXTN) 
      {
         if (siMfChkFlag(tep->reg))
            MSGRET(msgCtlp, MFCCINVINFOEL);
      }
      else if ((*tep->flagp & TF_PEXT) && (siMfExt == 0))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      RETVALUE(MFROK);
   }

   if (*tep->flagp & TF_PEXTN) 
   {
      if (siMfChkFlag(tep->reg) == 0)
         RETVALUE(MFROK);
   }
   else if ((*tep->flagp & TF_PEXT) && (siMfExt))
      RETVALUE(MFROK);

   /* token must be present, check it */
   val = 0;
   if (*tep->flagp & TF_EREM)
      len = msgCtlp->elen;
   else len = 2;
   for (i = 0; (i < len) && msgCtlp->elen; i++)
   {
      if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
         MSGRET(msgCtlp, MFCCINVMSG);
      val = (U16 )((val << 8) | c);
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
   }

   if (tep->mask)
      val &= (U16) tep->mask;

   msgCtlp->bitIdx += (U16 )(len << 3);

   if (msgCtlp->validate)
   {
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if ((val < (U16) tep->minVal) || (val > (U16) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* if there is a user function, execute it */
   if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK)
         MSGRET(msgCtlp, ret);

   /* if last token in octet */
   if (*tep->flagp & TF_EXT)
   {
      siMfExt = (U8)(c & 0x80);
   }

   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         siMfPushFlag(1);
      else siMfPushFlag(0);      
   }

   /* save token info in msg struct */
   if (msgCtlp->decode)
   {
      tp->pres = PRSNT_NODEF;
      tp->val = val;
   }

   RETVALUE(MFROK);
} /* end of siMfDecU16 */

  
/*
*
*       Fun:   siMfDecU16Ext
*
*       Desc:  message function - decode unsigned 16 bit extended
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfDecU16Ext
(
Buffer     *mp,
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 siMfDecU16Ext(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;                   /* counter */
   Data c;                  /* data character */
   U16 len;                 /* maximum length */
   U8 shf;
   TknU16 *tp;
   U16 val;

   TRC2(siMfDecU16Ext)

   /* if token present based on last ext flag and not extended */
   tp = (TknU16 *) msgCtlp->dup1;
   tp->pres = NOTPRSNT;
   /* bump message structure ptr */
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
   ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU16));
   if (msgCtlp->elen == 0)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if (*tep->flagp & TF_PEXTN) 
      {
         if (siMfChkFlag(tep->reg))
            MSGRET(msgCtlp, MFCCINVINFOEL);
      }
      else if ((*tep->flagp & TF_PEXT) && (siMfExt == 0))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      RETVALUE(MFROK);
   }

   if (*tep->flagp & TF_PEXTN) 
   {
      if (siMfChkFlag(tep->reg) == 0)
         RETVALUE(MFROK);
   }
   else if ((*tep->flagp & TF_PEXT) && (siMfExt))
      RETVALUE(MFROK);

   /* token must be present, check it */
   val = 0;
   if (*tep->flagp & TF_EREM)
      len = msgCtlp->elen;
   else len = 3;
   for (i = 0; (i < len) && msgCtlp->elen; i++)
   {
      if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
         MSGRET(msgCtlp, MFCCINVMSG);

      /* RG: either the shf values are wrong or val should 
       * be computed as val = (c << shf) | val;
       */

      if (i == 0)
      {
         shf = 0;
         c &= 0x3;
      }
      else if (i == 1)
      {
         shf = 2;
         c &= 0x7f;
      }
      else
      {
         shf = 7;
         c &= 0x7f;
      }
      val = (U16 )((val << shf) | c);
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
   }

   msgCtlp->bitIdx += (U16 )(len << 3);

   if (msgCtlp->validate)
   {
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if ((val < (U16) tep->minVal) || (val > (U16) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* if there is a user function, execute it */
   if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK)
         MSGRET(msgCtlp, ret);

   /* if last token in octet */
   if (*tep->flagp & TF_EXT)
   {
      siMfExt = (U8)(c & 0x80);
   }

   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         siMfPushFlag(1);
      else siMfPushFlag(0);      
   }

   /* save token info in msg struct */
   if (msgCtlp->decode)
   {
      tp->pres = PRSNT_NODEF;
      tp->val = val;
   }

   RETVALUE(MFROK);
} /* end of siMfDecU16Ext */

  
/*
*
*       Fun:   siMfEncU16
*
*       Desc:  message function - encode unsigned 16 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfEncU16
(
Buffer     *mp,
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 siMfEncU16(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;
   U16 val;
   U16 shf;
   U16 len;
   TknU16 *tp;

   TRC2(siMfEncU16)
   /* check mandatory dependencies */
   tp = (TknU16 *) msgCtlp->dup1;
   /* bump message structure ptr */
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
   ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU16));
   if (!tp->pres)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
      {  
         MSGRET(msgCtlp, MFCCINVINFOEL);
      } 
      else
         RETVALUE(MFROK);
   }

   /* token is present, check dependencies */
   if (*tep->flagp & TF_PEXTN)
   {
      if (msgCtlp->encode)
         siMfSetFlag(tep->reg, mp);
   }
   else if (*tep->flagp & TF_PEXT)
   {
      if (msgCtlp->encode)
      {
         siMfExt = 0;
         ret = siMfSetExt(mp, siMfExt);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret)
            MSGRET(msgCtlp, ret);
#endif
      }
   }

   /* token is present, check it */
   len = 2;
   val = tp->val;      
   if (msgCtlp->validate)
   {
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if ((val < (U16) tep->minVal) || (val > (U16) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* add octets to message */
   msgCtlp->bitIdx += (U16 )(len << 3);
   for (i = 0, shf = 8; i < len; i++)
   {
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg((U8) (val >> shf), mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
      shf -= 8;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }

   /* if there is a user function, execute it */
   if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK)
         MSGRET(msgCtlp, ret);

   RETVALUE(MFROK);
} /* end of siMfEncU16 */

  
/*
*
*       Fun:   siMfEncU16Ext
*
*       Desc:  message function - encode unsigned 16 bit extended
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfEncU16Ext
(
Buffer     *mp,
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 siMfEncU16Ext(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;
   U16 val;
   U16 shf;
   U16 len;
   TknU16 *tp;

   TRC2(siMfEncU16Ext)
   /* check mandatory dependencies */
   tp = (TknU16 *) msgCtlp->dup1;
   /* bump message structure ptr */
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
   ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU16));
   if (!tp->pres)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
      {  
         MSGRET(msgCtlp, MFCCINVINFOEL);
      } 
      else
         RETVALUE(MFROK);
   }

   /* token is present, check dependencies */
   if (*tep->flagp & TF_PEXTN)
   {
      if (msgCtlp->encode)
         siMfSetFlag(tep->reg, mp);
   }
   else if (*tep->flagp & TF_PEXT)
   {
      if (msgCtlp->encode)
      {
         siMfExt = 0;
         ret = siMfSetExt(mp, siMfExt);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret)
            MSGRET(msgCtlp, ret);
#endif
      }
   }

   /* token is present, check it */
   /* KRP - len = 2 - Error value originally here */
   len = 3;
   val = tp->val;      
   if (msgCtlp->validate)
   {
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if ((val < (U16) tep->minVal) || (val > (U16) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* add octets to message */
   msgCtlp->bitIdx += (U16 )(len << 3);
   for (i = 0, shf = 14; i < len; i++)
   {
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg((U8) (val >> shf), mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
      shf -= 7;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }

   /* if there is a user function, execute it */
   if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK)
         MSGRET(msgCtlp, ret);

   RETVALUE(MFROK);
} /* end of siMfEncU16Ext */

  
/*
*
*       Fun:   siMfDecU24
*
*       Desc:  message function - decode unsigned 24 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfDecU24
(
Buffer     *mp,
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 siMfDecU24(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   U16 i;                   /* counter */
   Data c;                  /* data character */
   U8 len;                  /* token length */
   TknU32 *tp;
   U32 val;

   TRC2(siMfDecU24)

   /* if token present based on last ext flag and not extended */
   tp = (TknU32 *) msgCtlp->dup1;
   tp->pres = NOTPRSNT;
   /* bump message structure ptr */
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
   ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU32));
   if (msgCtlp->elen == 0)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if (*tep->flagp & TF_PEXTN) 
      {
         if (siMfChkFlag(tep->reg))
            MSGRET(msgCtlp, MFCCINVINFOEL);
      }
      else if ((*tep->flagp & TF_PEXT) && (siMfExt == 0))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      RETVALUE(MFROK);
   }

   if (*tep->flagp & TF_PEXTN) 
   {
      if (siMfChkFlag(tep->reg) == 0)
         RETVALUE(MFROK);
   }
   else if ((*tep->flagp & TF_PEXT) && (siMfExt))
      RETVALUE(MFROK);

   /* token must be present, check it */
   val = 0;
#ifdef SS7
#ifdef SP
   if (msgCtlp->elen == 3)
      len = 3;
   else
#endif /* SP */
#endif /* SS7 */
#ifdef V5X
   if (msgCtlp->elen == 3)
      len = 3;
   else
#endif /* V5X */
   if ((msgCtlp->elen == 3) || (msgCtlp->elen == 6))
      len = 2;
   else if ((msgCtlp->elen == 7) || (msgCtlp->elen == 4))
      len = 3;
   else
      len = 4;
   

   for (i = 0; (i < len) && msgCtlp->elen; i++)
   {
      if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
         MSGRET(msgCtlp, MFCCINVMSG);
      val = (val << 8) | c;
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
   }

   if (tep->mask)
      c &= tep->mask;

   msgCtlp->bitIdx += (U16 )(len << 3);

   if (msgCtlp->validate)
   {
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if ((val < (U32) tep->minVal) || (val > (U32) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* if last token in octet */
   if (*tep->flagp & TF_EXT)
   {
      siMfExt = (U8)(c & 0x80);
   }

   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         siMfPushFlag(1);
      else siMfPushFlag(0);      
   }

   /* save token info in msg struct */
   if (msgCtlp->decode)
   {
      tp->pres = PRSNT_NODEF;
      tp->val = val;
   }

   RETVALUE(MFROK);
} /* end of siMfDecU24 */

  
/*
*
*       Fun:   siMfEncU24
*
*       Desc:  message function - encode unsigned 24 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfEncU24
(
Buffer     *mp,
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 siMfEncU24(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;
   U16 shf;
   U16 len;
   TknU32 *tp;
   U32 val;

   TRC2(siMfEncU24);

   len = 0;

   /* check mandatory dependencies */
   tp = (TknU32 *) msgCtlp->dup1;
   /* bump message structure ptr */
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
   ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU32));
   if (!tp->pres)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
      {  
         MSGRET(msgCtlp, MFCCINVINFOEL);
      } 
      else
         RETVALUE(MFROK);
   }

   /* token is present, check dependencies */
   if (*tep->flagp & TF_PEXTN)
   {
      if (msgCtlp->encode)
         siMfSetFlag(tep->reg, mp);
   }
   else if (*tep->flagp & TF_PEXT)
   {
      if (msgCtlp->encode)
      {
         siMfExt = 0;
         ret = siMfSetExt(mp, siMfExt);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret)
            MSGRET(msgCtlp, ret);
#endif
      }
   }

   val = 0;
#ifdef SS7
#ifdef SP
   if (msgCtlp->cfgp->flags & MF_SCCP)
      len = 3;
#endif /* SP */
#endif /* SS7 */
#ifdef V5X
   len = tep->minLen;
#endif /* V5X */
   if (tep->func)
      len = (*tep->func)(msgCtlp, (U32) 0);

   val = tp->val;      
   
   if (msgCtlp->validate)
   {
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if ((val < (U32) tep->minVal) || (val > (U32) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* add octets to message */
   msgCtlp->bitIdx += (U16 )(len << 3);
   shf = 8 * (len - 1);
   for (i = 0; i < len; i++)
   {
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg((U8) (val >> shf), mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
      shf -= 8;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }

   RETVALUE(MFROK);
} /* end of siMfEncU24 */

  
/*
*
*       Fun:   siMfDecU32
*
*       Desc:  message function - decode unsigned 32 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfDecU32
(
Buffer     *mp,
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 siMfDecU32(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;                   /* counter */
   Data c;                  /* data character */
   U16 len;                 /* token length */
   TknU32 *tp;
   U32 val;

   TRC2(siMfDecU32)

   /* if token present based on last ext flag and not extended */
   tp = (TknU32 *) msgCtlp->dup1;
   tp->pres = NOTPRSNT;
   /* bump message structure ptr */
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
   ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU32));
   if (msgCtlp->elen == 0)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if (*tep->flagp & TF_PEXTN) 
      {
         if (siMfChkFlag(tep->reg))
            MSGRET(msgCtlp, MFCCINVINFOEL);
      }
      else if ((*tep->flagp & TF_PEXT) && (siMfExt == 0))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      RETVALUE(MFROK);
   }

   if (*tep->flagp & TF_PEXTN) 
   {
      if (siMfChkFlag(tep->reg) == 0)
         RETVALUE(MFROK);
   }
   else if ((*tep->flagp & TF_PEXT) && (siMfExt))
      RETVALUE(MFROK);

   /* token must be present, check it */
   val = 0;
   if (*tep->flagp & TF_EREM)
      len = msgCtlp->elen;
   else len = 4;
   for (i = 0; (i < len) && msgCtlp->elen; i++)
   {
      if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
         MSGRET(msgCtlp, MFCCINVMSG);
      val = (val << 8) | c;
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
   }

   if (tep->mask)
      c &= tep->mask;

   msgCtlp->bitIdx += (U16 )(len << 3);

   if (msgCtlp->validate)
   {
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if ((val < (U32) tep->minVal) || (val > (U32) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* if there is a user function, execute it */
   if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK)
         MSGRET(msgCtlp, ret);

   /* if last token in octet */
   if (*tep->flagp & TF_EXT)
   {
      siMfExt = (U8)(c & 0x80);
   }

   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         siMfPushFlag(1);
      else siMfPushFlag(0);      
   }

   /* save token info in msg struct */
   if (msgCtlp->decode)
   {
      tp->pres = PRSNT_NODEF;
      tp->val = val;
   }

   RETVALUE(MFROK);
} /* end of siMfDecU32 */

  
/*
*
*       Fun:   siMfEncU32
*
*       Desc:  message function - encode unsigned 32 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfEncU32
(
Buffer     *mp,
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 siMfEncU32(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;
   U16 shf;
   U16 len;
   TknU32 *tp;
   U32 val;

   TRC2(siMfEncU32)
   /* check mandatory dependencies */
   tp = (TknU32 *) msgCtlp->dup1;
   /* bump message structure ptr */
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
   ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU32));
   if (!tp->pres)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
      {  
         MSGRET(msgCtlp, MFCCINVINFOEL);
      } 
      else
         RETVALUE(MFROK);
   }

   /* token is present, check dependencies */
   if (*tep->flagp & TF_PEXTN)
   {
      if (msgCtlp->encode)
         siMfSetFlag(tep->reg, mp);
   }
   else if (*tep->flagp & TF_PEXT)
   {
      if (msgCtlp->encode)
      {
         siMfExt = 0;
         ret = siMfSetExt(mp, siMfExt);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret)
            MSGRET(msgCtlp, ret);
#endif
      }
   }

   /* token is present, check it */
   len = 4;
   shf = 24;
   val = tp->val;      
   /* if there is a user function, execute it */
   if (tep->func)
   {
      switch (ret = (*tep->func)(msgCtlp, (PTR) &val))
      {
         case MFME_SHIFT:
            len = 3;
            shf = 16;
            break;
         case MFROK:
            break;
         default:
            MSGRET(msgCtlp, ret);
      }
   }
   if (msgCtlp->validate)
   {
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if ((val < (U32) tep->minVal) || (val > (U32) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* add octets to message */
   msgCtlp->bitIdx += (U16 )(len << 3);
   for (i = 0; i < len; i++)
   {
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg((U8) (val >> shf), mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
      shf -= 8;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }

   RETVALUE(MFROK);
} /* end of siMfEncU32 */

  
/*
*
*       Fun:   siMfDecStr
*
*       Desc:  message function - decode string
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfDecStr
(
Buffer     *mp,
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 siMfDecStr(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16        ret;                 /* return code */
   Data       c;
   U16        len;
   TknStr     *tp;
   U16        i;
   U16        size;
   U8         length;
   Cntr       noBytesDec;    /* No. of bytes decoded from the message */

   TRC2(siMfDecStr);


   size = 0;
   length = 0;

   /* if token present based on last ext flag and not extended */
   tp = (TknStr *) msgCtlp->dup1;
   tp->pres = NOTPRSNT;
   switch (tep->type)
   {
      case TET_STRS:
      case TET_STRS_IA5:
         size = sizeof(TknStrS);
         length = MF_SIZE_TKNSTRS;
         break;
      case TET_STRM:
         size = sizeof(TknStrM);
         length = MF_SIZE_TKNSTRM;
         break;
      case TET_STR:
      case TET_STR_IA5:
         size = sizeof(TknStr);
         length = MF_SIZE_TKNSTR;
         break;
      case TET_STRL:
         size = sizeof(TknStrE);
         length = MF_SIZE_TKNSTRE;
         break;

   }
   /* bump message structure ptr */
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
   ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) size);
   tp->len = 0;
   if (msgCtlp->elen == 0)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if (*tep->flagp & TF_PEXTN) 
      {
         if (siMfChkFlag((U8)(tep->reg & 0xf)))
            MSGRET(msgCtlp, MFCCINVINFOEL);
      }
      else if ((*tep->flagp & TF_PEXT) && (siMfExt == 0))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      RETVALUE(MFROK);
   }

   if (*tep->flagp & TF_PEXTN) 
   {
      if (siMfChkFlag((U8)(tep->reg & 0xf)) == 0)
         RETVALUE(MFROK);
   }
   else if ((*tep->flagp & TF_PEXT) && (siMfExt))
      RETVALUE(MFROK);

   /* if there is a user function, execute it */
   if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) tp)) != MFROK)
         MSGRET(msgCtlp, ret);

   /* token must be present, check it */
   if (*tep->flagp & TF_PLEN)
   {
      len = siMfLen;
      siMfLen = 0;
      if (len < 1)
         RETVALUE(ROK);
   }
   else
      len = msgCtlp->elen;
   
   if (msgCtlp->validate)
      if ((len < tep->minLen) || (len > tep->maxLen) || (len > length))
         MSGRET(msgCtlp, MFCCINVINFOEL);

   /* read in bytes. noBytesDec is used to record the exact number
    * of bytes decoded from the message buffer. It may so happen that
    * the token does not have TF_PLEN flag set and thus taken the
    * length of this token to be all the remaining bytes in the
    * parameter. However, this token may span only some of the
    * remaining octets for this parameter and rest of the octets
    * may be for a different token. In that scenario, actual number
    * of bytes decoded will be less than "len".
    */
   for (i = 0, noBytesDec = 0; i < len; i++)
   {
      if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
         MSGRET(msgCtlp, MFCCINVMSG);
      siMfExt = 0;
      noBytesDec++;
      if (*tep->flagp & TF_PEXTN0)
      {
         if (siMfChkFlag((U8)(tep->reg >> 4)) == 0)
         {
            siMfExt = (U8)(c & 0x80);
            c &= 0x7f;
         }
      }
      else
      {
         /* If this token has the extension flag set. Get the
          * extension bit from this octet.
          */
         if (*tep->flagp & TF_EXT)
         {
            siMfExt = (U8)(c & 0x80);
            c &= 0x7f;
         }
      }
      if ((msgCtlp->validate) && ((tep->type == TET_STR_IA5) || 
              (tep->type == TET_STRS_IA5)) && (c > (U8)0x7f)) 
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if (msgCtlp->decode)
         tp->val[i] = c;
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
      if (siMfExt)
         break;
   }

   msgCtlp->bitIdx += (U16 )(len << 3);

   if (msgCtlp->decode)
   {
      tp->pres = PRSNT_NODEF;
      tp->len = (U8) noBytesDec;
   }

   RETVALUE(MFROK);
} /* end of siMfDecStr */

  
/*
*
*       Fun:   siMfEncStr
*
*       Desc:  message function - encode string
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfEncStr
(
Buffer     *mp,
CONSTANT SiTknElmtDef *tep,   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 siMfEncStr(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
SiMfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   Data c;
   TknStr *tp;
   U16 i;                   /* counter */
   U16 len;
   U16 size;
   U8 length;

   TRC2(siMfEncStr);

   size = 0;
   length = 0;
   /* check mandatory dependencies */
   tp = (TknStr *) msgCtlp->dup1;
   switch (tep->type)
   {
      case TET_STRS:
      case TET_STRS_IA5:
         size = sizeof(TknStrS);
         length = MF_SIZE_TKNSTRS;
         break;
      case TET_STRM:
         size = sizeof(TknStrM);
         length = MF_SIZE_TKNSTRM;
         break;
      case TET_STR:
      case TET_STR_IA5:
         size = sizeof(TknStr);
         length = MF_SIZE_TKNSTR;
         break;
      case TET_STRL:
         size = sizeof(TknStrE);
         length = MF_SIZE_TKNSTRE;
         break;

   }
   /* bump message structure ptr */
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
   ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) size);
   if (!tp->pres)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
      {  
         MSGRET(msgCtlp, MFCCINVINFOEL);
      } 
      else
         RETVALUE(MFROK);
   }

   /* token is present, check dependencies */
   if (*tep->flagp & TF_PEXTN)
   {
      if (msgCtlp->encode)
         siMfSetFlag((U8)(tep->reg & 0xf), mp);
   }
   else if (*tep->flagp & TF_PEXT)
   {
      if (msgCtlp->encode)
      {
         siMfExt = 0;
         ret = siMfSetExt(mp, siMfExt);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret)
            MSGRET(msgCtlp, ret);
#endif
      }
   }

   /* token is present, check it */
   len = tp->len;
   if (msgCtlp->validate)
      if ((len < tep->minLen) || (len > tep->maxLen) || (len > length))
         MSGRET(msgCtlp, MFCCINVINFOEL);

   /* write octets to msg */
   msgCtlp->bitIdx += (U16 )(len << 3);
   for (i = 0; i < len; i++)
   {
      c = tp->val[i];
      if ((msgCtlp->validate) && ((tep->type == TET_STR_IA5)  ||
                (tep->type == TET_STRS_IA5)) && ((U8)c  > (U8)0x7f)) 
          MSGRET(msgCtlp, MFCCINVINFOEL);

      siMfExt = 0;
      if (*tep->flagp & TF_PEXTN0)
      {
         if (siMfChkFlag((U8)(tep->reg >> 4)) == 0)
         {
            if ((i == (len - 1)) && (len == 1))
               siMfExt = 0x80;
         }
      }
      else
      {
         /* If this token has the extension flag set and this is
          * the last octet in this token then set the extension
          * bit to indicate the end of token.
          */
         if (*tep->flagp & TF_EXT)
         {
            if (i == (len - 1))
               siMfExt = 0x80;
         }
      }

      c |= siMfExt;
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg(c, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }

   /* if there is a user function, execute it */
   if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) tp)) != MFROK)
         MSGRET(msgCtlp, ret);

   RETVALUE(MFROK);
} /* end of siMfEncStr */

  
/*
*
*       Fun:   siMfInitTkns
*
*       Desc:  message function - init tokens
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
/* XCHGTYPE should be passed to identify the action before setting
   default for TET_U8 */ 
#ifdef ANSI
PRIVATE S16 siMfInitTkns
(
TknHdr **cmsp1,
TknHdr **cmsp2,
CONSTANT SiTknElmtDef *CONSTANT *telp,
U8 mode,
Swtch swtch,
U32 *flags 
)
#else
PRIVATE S16 siMfInitTkns(cmsp1, cmsp2, telp, mode, swtch, flags)
TknHdr **cmsp1;
TknHdr **cmsp2;
CONSTANT SiTknElmtDef *CONSTANT *telp;
U8 mode;
Swtch swtch;
U32 *flags;
#endif
{
   CONSTANT SiTknElmtDef *tep;         /* token element definition pointer */
   TknU8 *tpu8s;
   TknU8 *tpu8d;
   TknU16 *tpu16s;
   TknU16 *tpu16d;
   TknU32 *tpu32s;
   TknU32 *tpu32d;
   TknStr *tpstrs;
   TknStr *tpstrd;
   TknStrE *tpstrsE;
   TknStrE *tpstrdE;
   TknStrS *tpstrsS;
   TknStrS *tpstrdS;
   TknStrM *tpstrsM;
   TknStrM *tpstrdM;


   TRC2(siMfInitTkns)
   UNUSED(flags);

   /* loop thru token elements and init to done or error */
   while (*telp)
   {
      tep = *telp;

      telp += 1;

      switch (tep->type)
      {
         case TET_U8:
         case TET_U8_ENUM:
            tpu8d = (TknU8 *) *cmsp2;
            if (mode == PRSNT_DEF)
            {
               /* copy from database default to token */
               if (tep->defs != NULLP)
               {
                  tpu8d->pres = PRSNT_DEF;
                  tpu8d->val = (U8) tep->defs[swtch];
               }
               else 
                  tpu8d->pres = NOTPRSNT;
            }
            else if (mode == PRSNT_NODEF)
            {
               /* copy from src to dst token */
               tpu8s = (TknU8 *) *cmsp1;


               /* validate present flag */
               if ( ((tpu8s->pres != NOTPRSNT) && (tpu8s->pres != PRSNT_NODEF) 
                  && (tpu8s->pres != PRSNT_DEF) && (tpu8s->pres != PRSNT_INVALID)) )
               {
                  tpu8d->pres = NOTPRSNT;
               }
               else
               {
                  tpu8d->pres = tpu8s->pres;
                  tpu8d->val = tpu8s->val;
               }
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
               ADDFARPTR((PTR *) cmsp1, (U32) sizeof(TknU8));
            } 
            else
               tpu8d->pres = NOTPRSNT;

/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
            ADDFARPTR((PTR *) cmsp2, (U32) sizeof(TknU8));
            break;

         case TET_BITS:
            switch(tep->maxLen)
            {
               case 2:
                  tpu16d = (TknU16 *) *cmsp2;
                  if (mode == PRSNT_DEF)
                  {
                     /* copy from database default to token */
                     if (tep->defs != NULLP)
                     {
                        tpu16d->pres = PRSNT_DEF;
                        tpu16d->val = (U16) tep->defs[swtch];
                     }
                     else 
                        tpu16d->pres = NOTPRSNT;
                  }
                  else if (mode == PRSNT_NODEF)
                  {
                     /* copy from src to dst token */
                     tpu16s = (TknU16 *) *cmsp1;
                     tpu16d->pres = tpu16s->pres;
                     tpu16d->val = tpu16s->val;
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
                     ADDFARPTR((PTR *) cmsp1, (U32) sizeof(TknU16));
                  } 
                  else
                     tpu16d->pres = NOTPRSNT;

/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
                  ADDFARPTR((PTR *) cmsp2, (U32) sizeof(TknU16));
                  break;
            case 3:
            case 4:
               tpu32d = (TknU32 *) *cmsp2;
               if (mode == PRSNT_DEF)
               {
                  /* copy from database default to token */
                  if (tep->defs != NULLP)
                  {
                     tpu32d->pres = PRSNT_DEF;
                     tpu32d->val = (U32) tep->defs[swtch];
                  }
                  else 
                     tpu32d->pres = NOTPRSNT;
               }
               else if (mode == PRSNT_NODEF)
               {
                  /* copy from src to dst token */
                  tpu32s = (TknU32 *) *cmsp1;
                  tpu32d->pres = tpu32s->pres;
                  tpu32d->val = tpu32s->val;
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
                  ADDFARPTR((PTR *) cmsp1, (U32) sizeof(TknU32));
               } 
               else
                  tpu32d->pres = NOTPRSNT;

/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
               ADDFARPTR((PTR *) cmsp2, (U32) sizeof(TknU32));
               break;
            }
            break;

         case TET_U16:
         case TET_U16_EXT:
            tpu16d = (TknU16 *) *cmsp2;
            if (mode == PRSNT_DEF)
            {
               /* copy from database default to token */
               if (tep->defs != NULLP)
               {
                  tpu16d->pres = PRSNT_DEF;
                  tpu16d->val = (U16) tep->defs[swtch];
               }
               else 
                  tpu16d->pres = NOTPRSNT;
            }
            else if (mode == PRSNT_NODEF)
            {
               /* copy from src to dst token */
               tpu16s = (TknU16 *) *cmsp1;
               tpu16d->pres = tpu16s->pres;
               tpu16d->val = tpu16s->val;
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
               ADDFARPTR((PTR *) cmsp1, (U32) sizeof(TknU16));
            } 
            else
               tpu16d->pres = NOTPRSNT;

/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
            ADDFARPTR((PTR *) cmsp2, (U32) sizeof(TknU16));
            break;

         case TET_U24:
         case TET_U32:
            tpu32d = (TknU32 *) *cmsp2;
            if (mode == PRSNT_DEF)
            {
               /* copy from database default to token */
               if (tep->defs != NULLP)
               {
                  tpu32d->pres = PRSNT_DEF;
                  tpu32d->val = (U32) tep->defs[swtch];
               }
               else 
                  tpu32d->pres = NOTPRSNT;
            }
            else if (mode == PRSNT_NODEF)
            {
               /* copy from src to dst token */
               tpu32s = (TknU32 *) *cmsp1;
               tpu32d->pres = tpu32s->pres;
               tpu32d->val = tpu32s->val;
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
               ADDFARPTR((PTR *) cmsp1, (U32) sizeof(TknU32));
            } 
            else
               tpu32d->pres = NOTPRSNT;

/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
            ADDFARPTR((PTR *) cmsp2, (U32) sizeof(TknU32));
            break;

         case TET_STR:
         case TET_STR_IA5:
            tpstrd = (TknStr *) *cmsp2;
            if (mode == PRSNT_DEF)
            {
               /* copy from database default to token */
               if (tep->defs != NULLP)
               {
                  if (!(U8 *)tep->defs[swtch] )
                  {
                     tpstrd->pres = NOTPRSNT;
                     tpstrd->len = 0;
                  }
                  else
                  {
                     tpstrd->pres = PRSNT_DEF;
                     tpstrd->len = (U8) siMfStrlen((U8 *)tep->defs[swtch]);
                     if (tpstrd->len > 0)
                        siMfBcopy((U8 *)tep->defs[swtch], tpstrd->val, 
                                (U32) tpstrd->len);
                     else 
                        tpstrd->pres = NOTPRSNT;
                  }
               }
               else
               {
                  tpstrd->pres = NOTPRSNT;
                  tpstrd->len = 0;
               }
            }
            else if (mode == PRSNT_NODEF)
            {
               /* copy from src to dst token */
               tpstrs = (TknStr *) *cmsp1;
               tpstrd->pres = tpstrs->pres;
               /* if present, copy */
               if (tpstrs->pres)
               {
                  siMfBcopy(tpstrs->val, tpstrd->val, (U32) tpstrs->len);
                  tpstrd->len = tpstrs->len;
               }
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
               ADDFARPTR((PTR *) cmsp1, (U32) sizeof(TknStr));
            } 
            else 
            {
               tpstrd->pres = NOTPRSNT;
               tpstrd->len = 0;
            }
            switch (tep->type)
            {
            }
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
            ADDFARPTR((PTR *) cmsp2, (U32) sizeof(TknStr));
            break;

         case TET_STRL:
            tpstrdE = (TknStrE *) *cmsp2;
            if (mode == PRSNT_DEF)
            {
               /* copy from database default to token */
               if (tep->defs != NULLP)
               {
                  if (!(U8 *)tep->defs[swtch] )
                  {
                     tpstrdE->pres = NOTPRSNT;
                     tpstrdE->len = 0;
                  }
                  else
                  {
                     tpstrdE->pres = PRSNT_DEF;
                     tpstrdE->len = (U8) siMfStrlen((U8 *)tep->defs[swtch]);
                     if (tpstrdE->len > 0)
                        siMfBcopy((U8 *)tep->defs[swtch], tpstrdE->val, 
                                (U32) tpstrdE->len);
                     else 
                        tpstrdE->pres = NOTPRSNT;
                  }
               }
               else
               {
                  tpstrdE->pres = NOTPRSNT;
                  tpstrdE->len = 0;
               }
            }
            else if (mode == PRSNT_NODEF)
            {
               /* copy from src to dst token */
               tpstrsE = (TknStrE *) *cmsp1;
               tpstrdE->pres = tpstrsE->pres;
               /* if present, copy */
               if (tpstrsE->pres)
               {
                  siMfBcopy(tpstrsE->val, tpstrdE->val, (U32) tpstrsE->len);
                  tpstrdE->len = tpstrsE->len;
               }
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
               ADDFARPTR((PTR *) cmsp1, (U32) sizeof(TknStrE));
            } 
            else 
            {
               tpstrdE->pres = NOTPRSNT;
               tpstrdE->len = 0;
            }

/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
            ADDFARPTR((PTR *) cmsp2, (U32) sizeof(TknStrE));
            break;

         case TET_STRM:
            tpstrdM = (TknStrM *) *cmsp2;
            if (mode == PRSNT_DEF)
            {
               /* copy from database default to token */
               if (tep->defs != NULLP)
               {
                  if (!(U8 *)tep->defs[swtch] )
                  {
                     tpstrdM->pres = NOTPRSNT;
                     tpstrdM->len = 0;
                  }
                  else
                  {
                     tpstrdM->pres = PRSNT_DEF;
                     tpstrdM->len = (U8) siMfStrlen((U8 *)tep->defs[swtch]);
                     if (tpstrdM->len > 0)
                        siMfBcopy((U8 *)tep->defs[swtch], tpstrdM->val, 
                                (U32) tpstrdM->len);
                     else 
                        tpstrdM->pres = NOTPRSNT;
                  }
               }
               else
               {
                  tpstrdM->pres = NOTPRSNT;
                  tpstrdM->len = 0;
               }
            }
            else if (mode == PRSNT_NODEF)
            {
               /* copy from src to dst token */
               tpstrsM = (TknStrM *) *cmsp1;
               tpstrdM->pres = tpstrsM->pres;
               /* if present, copy */
               if (tpstrsM->pres)
               {
                  siMfBcopy(tpstrsM->val, tpstrdM->val, (U32) tpstrsM->len);
                  tpstrdM->len = tpstrsM->len;
               }
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
               ADDFARPTR((PTR *) cmsp1, (U32) sizeof(TknStrM));
            } 
            else 
            {
               tpstrdM->pres = NOTPRSNT;
               tpstrdM->len = 0;
            }

/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
            ADDFARPTR((PTR *) cmsp2, (U32) sizeof(TknStrM));
            break;

         case TET_STRS:
         case TET_STRS_IA5:
            tpstrdS = (TknStrS *) *cmsp2;
            if (mode == PRSNT_DEF)
            {
               /* copy from database default to token */
               if (tep->defs != NULLP)
               {
                  if (!(U8 *)tep->defs[swtch] )
                  {
                     tpstrdS->pres = NOTPRSNT;
                     tpstrdS->len = 0;
                  }
                  else
                  {
                     tpstrdS->pres = PRSNT_DEF;
                     tpstrdS->len = (U8) siMfStrlen((U8 *)tep->defs[swtch]);
                     if (tpstrdS->len > 0)
                        siMfBcopy((U8 *)tep->defs[swtch], tpstrdS->val, 
                                (U32) tpstrdS->len);
                     else 
                        tpstrdS->pres = NOTPRSNT;
                  }
               }
               else
               {
                  tpstrdS->pres = NOTPRSNT;
                  tpstrdS->len = 0;
               }
            }
            else if (mode == PRSNT_NODEF)
            {
               /* copy from src to dst token */
               tpstrsS = (TknStrS *) *cmsp1;
               tpstrdS->pres = tpstrsS->pres;
               /* if present, copy */
               if (tpstrsS->pres)
               {
                  siMfBcopy(tpstrsS->val, tpstrdS->val, (U32) tpstrsS->len);
                  tpstrdS->len = tpstrsS->len;
               }
/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
               ADDFARPTR((PTR *) cmsp1, (U32) sizeof(TknStrS));
            } 
            else 
            {
               tpstrdS->pres = NOTPRSNT;
               tpstrdS->len = 0;
            }

/* si010.220: Modification - replacing fpAdd with macro ADDFARPTR */
            ADDFARPTR((PTR *) cmsp2, (U32) sizeof(TknStrS));
            break;
      }
   }
   RETVALUE(MFROK);
} /* end of siMfInitTkns */

  
/*
*
*       Fun:   siMfDecTkns
*
*       Desc:  message function - decode tokens
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfDecTkns
(
Buffer *mp,
/* si010.220: Modification - replace telp with mep in the function arguments */
CONSTANT SiMsgElmtDef *mep,
SiMfMsgCtl *msgCtlp              /* pointer to message control structure */
)
#else
PRIVATE S16 siMfDecTkns(mp, mep, msgCtlp)
Buffer *mp;
/* si010.220: Modification - replace telp with mep in the function arguments */
CONSTANT SiMsgElmtDef *mep;
SiMfMsgCtl *msgCtlp;             /* pointer to message control structure */
#endif
{
   S16 ret;                    /* return code */
   U16 errCnt;                 /* error count */
   CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
/* si010.220: Addition - local variables */
   CONSTANT SiTknElmtDef *CONSTANT *telp; /* double token pointer */

   TRC2(siMfDecTkns)
/* si010.220: Addition - intialize telp */
   telp = mep->telp;
   /* initialize control variables */
   ret = MFROK;
   siMfExt = 1;
   siMfOctet = 0;
   siMfSp = MF_STKSIZE;
   errCnt = msgCtlp->errCnt;
   msgCtlp->ee[errCnt].tknIdx = 0;

   /* loop thru token elements and decode to done or error */
   while (*telp != NULLP) 
   {
      tep = *telp;
#if (ERRCLASS & ERRCLS_DEBUG)
      if (!tep->flagp)
         MSGRET(msgCtlp, MFDEBUGERR);
#endif

      telp += 1;
      switch (tep->type)
      {
         case TET_U8:
            ret = siMfDecU8(mp, tep, msgCtlp);
            switch (ret)
            {
               case MFSKIP20TKNS:
                  telp += 20;
                  msgCtlp->ee[errCnt].tknIdx += 20;
                  continue;

               /* si032.220: addition - added case of skip 16 */
               case MFSKIP16TKNS:
                  telp += 16;
                  msgCtlp->ee[errCnt].tknIdx += 16;
                  continue;

               /* si032.220: addition - added case of skip 11 */
               case MFSKIP11TKNS:
                  telp += 11;
                  msgCtlp->ee[errCnt].tknIdx += 11;
                  continue;

               case MFSKIP1TKNS:
                  telp += 1;
                  msgCtlp->ee[errCnt].tknIdx += 1;
                  continue;
               
               case MFSKIP2TKNS:
                  telp += 2;
                  msgCtlp->ee[errCnt].tknIdx += 2;
                  continue;

               /* Skip 5 and 6 tokens, as returned by the escape function */
               case MFSKIP5TKNS:
                  telp += 5;
                  msgCtlp->ee[errCnt].tknIdx += 5;
                  continue;

               case MFSKIP6TKNS:
                  telp += 6;
                  msgCtlp->ee[errCnt].tknIdx += 6;
                  continue;

               default:
                  break;
            }
            break;

         case TET_U8_ENUM:
            ret = siMfDecU8Enum(mp, tep, msgCtlp);
            switch (ret)
            {
               case MFSKIPNXTU8LSTTKN:
                  msgCtlp->ee[errCnt].tknIdx++;
                  telp += 1;
                  ret = MFROK;
                  break;

               /* Skip 19 tokens, as returned by escape funtion */
               case MFSKIP19TKNS:
                  telp += 19;
                  msgCtlp->ee[errCnt].tknIdx += 19;
                  continue;

               case MFSKIP6TKNS:
                  telp += 6;
                  msgCtlp->ee[errCnt].tknIdx += 6;
                  continue;

               case MFSKIP5TKNS:
                  telp += 5;
                  msgCtlp->ee[errCnt].tknIdx += 5;
                  continue;

               case MFSKIP3TKNS:
                  telp += 3;
                  msgCtlp->ee[errCnt].tknIdx += 3;
                  continue;

               case MFSKIP2TKNS:
                  telp += 2;
                  msgCtlp->ee[errCnt].tknIdx += 2;
                  continue;

               case MFSKIP1TKNS:
                  telp += 1;
                  msgCtlp->ee[errCnt].tknIdx += 1;
                  continue;

               /* si009.220, ADDED: added for case MFCAUSEVAL */
               case MFCAUSEVAL:
                  ret = MFROK;
                  break;
            }
            break;

         case TET_BITS:
         case TET_BITS_ENUM:
            ret = siMfDecBits(mp, tep, msgCtlp);
            break;

         case TET_U16:
            ret = siMfDecU16(mp, tep, msgCtlp);
            break;

         case TET_U16_EXT:
            ret = siMfDecU16Ext(mp, tep, msgCtlp);
            break;

         case TET_U24:
            ret = siMfDecU24(mp, tep, msgCtlp);
            break;

         case TET_U32:
            ret = siMfDecU32(mp, tep, msgCtlp);
            break;

         case TET_STR:
         case TET_STR_IA5:
         case TET_STRS:
         case TET_STRS_IA5:
         case TET_STRM:
         case TET_STRL:
            ret = siMfDecStr(mp, tep, msgCtlp);
            break;

#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            MSGRET(msgCtlp, MFDEBUGERR);
#endif
      }

      if (ret != ROK)
         break;

      msgCtlp->ee[errCnt].tknIdx++;
   }

   if (ret != ROK)
   {
/* si010.220: Modification - use macro ADDFARPTR */
      ADDFARPTR((PTR *) &msgCtlp->dup1, mep->skipsz);
      RETVALUE(ret);
   }

   RETVALUE(MFROK);
} /* end of siMfDecTkns */

  
/*
*
*       Fun:   siMfEncTkns
*
*       Desc:  message function - encode tokens
*
*       Ret:   MFROK      - ok
* 
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfEncTkns
(
Buffer *mp,
CONSTANT SiTknElmtDef *CONSTANT *telp,
SiMfMsgCtl *msgCtlp              /* pointer to message control structure */
)
#else
PRIVATE S16 siMfEncTkns(mp, telp, msgCtlp)
Buffer *mp;
CONSTANT SiTknElmtDef *CONSTANT *telp;
SiMfMsgCtl *msgCtlp;             /* pointer to message control structure */
#endif
{
   S16 ret;                    /* return code */
   U16 errCnt;                 /* error count */
   CONSTANT SiTknElmtDef *tep;   /* token element definition pointer */
   TknHdr *tp;                 /* token header pointer */

   TRC2(siMfEncTkns)
   /* initialize control variables */
   siMfExt = 1;
   siMfSp = MF_STKSIZE;
   errCnt = msgCtlp->errCnt;
   msgCtlp->ee[errCnt].tknIdx = 0;

   /* loop thru token elements and encode to done or error */
   while (*telp != NULLP)
   {
      tp = (TknHdr *) msgCtlp->dup1;
      if ( ((tp->pres != NOTPRSNT) && (tp->pres != PRSNT_NODEF) 
         && (tp->pres != PRSNT_DEF)) )
      {
         MSGRET(msgCtlp, MFCCINVINFOEL);
      }

      tep = *telp;
#if (ERRCLASS & ERRCLS_DEBUG)
      if (!tep->flagp)
         MSGRET(msgCtlp, MFDEBUGERR);
#endif

      telp += 1;
      switch (tep->type)
      {
         case TET_U8:
            ret = siMfEncU8(mp, tep, msgCtlp);
            switch ( ret ) 
            {
               case MFSKIP1TKNSCPY:
               case MFSKIP1TKNSEXT:
                  msgCtlp->ee[errCnt].tknIdx++;
                  telp += 1;
                  break;
               case MFSKIP2TKNSCPY:
                  msgCtlp->ee[errCnt].tknIdx++;
                  msgCtlp->ee[errCnt].tknIdx++;
                  telp += 2;
                  break;
               case MFROK:
                  break;
               default:
                  RETVALUE(ret);
            }
            break;

         case TET_U8_ENUM:
            ret = siMfEncU8Enum(mp, tep, msgCtlp);
            switch ( ret ) 
            {
               case MFROK:
                  break;
               case MFSKIPNXTU8LSTTKN:
                  msgCtlp->ee[errCnt].tknIdx++;
                  telp += 1;
                  break;
               default:
                  RETVALUE(ret);
            }
            break;

         case TET_BITS:
         case TET_BITS_ENUM:
            if ((ret = siMfEncBits(mp, tep, msgCtlp)) != MFROK)
               RETVALUE(ret);
            break;

         case TET_U16:
            if ((ret = siMfEncU16(mp, tep, msgCtlp)) != MFROK)
               RETVALUE(ret);
            break;

         case TET_U16_EXT:
            if ((ret = siMfEncU16Ext(mp, tep, msgCtlp)) != MFROK)
               RETVALUE(ret);
            break;

         case TET_U24:
            if ((ret = siMfEncU24(mp, tep, msgCtlp)) != MFROK)
               RETVALUE(ret);
            break;

         case TET_U32:
            if ((ret = siMfEncU32(mp, tep, msgCtlp)) != MFROK)
               RETVALUE(ret);
            break;
         case TET_STRL:
         case TET_STR:
         case TET_STR_IA5:
         case TET_STRS:
         case TET_STRM:
         case TET_STRS_IA5:
            if ((ret = siMfEncStr(mp, tep, msgCtlp)) != MFROK)
               RETVALUE(ret); 
            break;

#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            MSGRET(msgCtlp, MFDEBUGERR);
#endif
      }
      msgCtlp->ee[errCnt].tknIdx++;
   }
   RETVALUE(MFROK);
} /* end of siMfEncTkns */


  
/*
*
*       Fun:   siMfInitElmts
*
*       Desc:  message function - init elements
*
*       Ret:   MFROK      - ok
*
*       Notes: This is optimized for subset-to-superset initialization.
*              Superset to subset can also be optimized in this or another
*              similar function.
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfInitElmts
(
SiMfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 siMfInitElmts(msgCtlp)
SiMfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
   CONSTANT SiMsgElmtDef *CONSTANT *melp1;
   CONSTANT SiMsgElmtDef *CONSTANT *sav_melp1;
   CONSTANT SiMsgElmtDef *CONSTANT *melp2;
   CONSTANT SiMsgElmtDef *mep1;
   CONSTANT SiMsgElmtDef *mep2;
   CONSTANT SiMsgElmtDef *CONSTANT *tmp_melp1;
   ElmtHdr *cmsp1;          /* beginning source element header */
   ElmtHdr *cmsp2;          /* beginning destination element header */
   ElmtHdr *dep;            /* current destination element header */
   U8 mode;
   Swtch swtch;
   U32  flags;
   
   TRC2(siMfInitElmts);


   /* initialize control variables */
   cmsp1 = msgCtlp->dup1;
   cmsp2 = msgCtlp->dup2;
   melp1 = tmp_melp1 = msgCtlp->melp1;
   melp2 = msgCtlp->melp2;
   swtch = msgCtlp->swtch;
   mode  = msgCtlp->mode;
   flags = msgCtlp->flags;
   sav_melp1 = NULLP;

   mep1 = NULLP;

   if(mode == NOTPRSNT)
   {
      while(*melp2 != NULLP)
      {
         mep2 = *melp2;
         dep = (ElmtHdr *)cmsp2;
/* si010.220: Modification - use macro ADDFARPTR */
         ADDFARPTR((PTR *) &cmsp2, (U32) sizeof(ElmtHdr));
         dep->pres = NOTPRSNT;
#ifdef TSTINITTKNS
/* si010.220: Modification - use macro ADDFARPTR */
         ADDFARPTR((PTR *) &cmsp2, mep2->skipsz);
#endif
         siMfInitTkns(NULLP, (TknHdr **) &cmsp2, mep2->telp, 
                      mode, swtch, &flags); 
         melp2++;
      }
      RETVALUE(MFROK);
   }
   if(cmsp1)
      mep1 = *melp1;
   /* loop thru message elements and init to done */
#if (ERRCLASS & ERRCLS_DEBUG)
   if ((((cmsp1 == NULLP) || (*melp1 == NULLP)) 
        && (msgCtlp->mode == PRSNT_NODEF)) )
      MSGRET(msgCtlp, MFDEBUGERR);

   if (((cmsp1 != NULLP) && (msgCtlp->mode != PRSNT_NODEF)))
      MSGRET(msgCtlp, MFDEBUGERR);
#endif

   while(*melp2 != NULLP)
   {
      mep2 = *melp2;
#if (ERRCLASS & ERRCLS_DEBUG)
      if (!(mep2->flagp))
         MSGRET(msgCtlp, MFDEBUGERR);
#endif
      dep = (ElmtHdr *)cmsp2;
/* si010.220: Modification - use macro ADDFARPTR */
      ADDFARPTR((PTR *) &cmsp2, (U32) sizeof(ElmtHdr));

      /* If the element is not applicable in the Destination skip it */
      if(mep2->flagp[swtch] & EF_NA)
      {
         dep->pres = NOTPRSNT;
         melp2++;
/* si010.220: Modification - use macro ADDFARPTR */
         ADDFARPTR((PTR *) &cmsp2, mep2->skipsz);
         continue;
      }
      if(mode == PRSNT_DEF)
      {
         /* If the mode is PRSNT_DEF then we need to init from the DB
          * and ignore the source(assumption is that source passed will
          * be NULLP)
          */
         if(!(mep2->flagp[swtch] & EF_MAND)) 
         {
            /* If non mandatory element then set it to NOTPRSNT and skip 
             * over it. No need to check for the mode.
             */
            dep->pres = NOTPRSNT;
/* si010.220: Modification - use macro ADDFARPTR */
            ADDFARPTR((PTR *) &cmsp2, mep2->skipsz);
         }
         else
         {
            dep->pres = mode;
            siMfInitTkns(NULLP, (TknHdr **) &cmsp2, mep2->telp, 
                       mode, swtch, &flags); 
         }
         melp2++;
         continue;
      }
      else   /* PRSNT_NODEF mode */
      {
         /* Here we need to find an element in the source with the same
          * index as the destination. If found we init the destination
          * with the contents of the source. Else we skip that element
          * in the destination setting it to NOTPRSNT.
          */
         /* 
          * Here "sav_melp1" is the last element we encountered in the
          * source. We initialise it to NULLP and set it to the current
          * element in the source we are checking in this case.  If this 
          * element is not applicable we skip it and go on to check the
          * next element.  If we reach the last element in the source
          * we just wrapback to the first element.  We get out of the
          * loop either when there is a match or we have gone thru. all
          * the source elements once.  If there is no match then set the
          * element we were checking for in the destination to NOTPRSNT.
          * Skip the tokens in the source and reset the "sav_melp1" to
          * NULLP. This ensures that we start with the same element 
          * which did not match  in the source. 
          * If there is a match set the mode of the destination to that
          * of the matching source element.  If the mode is NOTPRSNT then
          * skip the element in both the source and destination.  Otherwise
          * initialise the destination from the tokens in the source element.
          * Also increment the source element pointer to the next element
          * (to take care of multiple elements with same index) after 
          * setting the sav_melp1 to the current element.
          *
          */
         while(melp1 != sav_melp1)
         {
            if(sav_melp1 == NULLP)
               sav_melp1 = melp1;
            mep1 = *melp1;
            if(mep1->flagp[swtch] & EF_NA)
            {
/* si010.220: Modification - use macro ADDFARPTR */
               ADDFARPTR((PTR *) &cmsp1, (U32) sizeof(ElmtHdr));
               ADDFARPTR((PTR *) &cmsp1, mep1->skipsz);
            }
            else 
            {
               if(mep1->idx == mep2->idx)
               {
                  melp1++;
                  break;
               }
               else
               {
/* si010.220: Modification - use macro ADDFARPTR */
                  ADDFARPTR((PTR *) &cmsp1, (U32) sizeof(ElmtHdr));
                  ADDFARPTR((PTR *) &cmsp1, mep1->skipsz); 
               }
            }
            melp1++;
            if(*melp1 == NULLP)
            {
               melp1 = tmp_melp1;
               cmsp1 = msgCtlp->dup1;
            }
         }
         if(melp1 == sav_melp1)
         {
            /* This means that the element was not found in the source.
             * So skip the tokens in the destination *
             */
            dep->pres = NOTPRSNT;
/* si010.220: Modification - use macro ADDFARPTR */
            ADDFARPTR((PTR *) &cmsp2, mep2->skipsz);
            melp2++;
            sav_melp1 = NULLP;
            /* If it is a duplicate parameter in event but not in PDU
             * then cmsp1 pointers should also be updated
             */
            if (mep1->idx == mep2->idx)
            {
/* si010.220: Modification - use macro ADDFARPTR */
               ADDFARPTR((PTR *)&cmsp1, (U32) sizeof(ElmtHdr));
               ADDFARPTR((PTR *) &cmsp1, mep1->skipsz);
            }
         }
         else 
         {
            /* Initialise tokens */
            dep->pres = ((ElmtHdr *)cmsp1)->pres;
/* si010.220: Modification - use macro ADDFARPTR */
            ADDFARPTR((PTR *)&cmsp1, (U32) sizeof(ElmtHdr));
            if(dep->pres == NOTPRSNT)
            {
/* si010.220: Modification - use macro ADDFARPTR */
               ADDFARPTR((PTR *) &cmsp2, mep2->skipsz);
               ADDFARPTR((PTR *) &cmsp1, mep1->skipsz);
            }
            else
               siMfInitTkns((TknHdr **) &cmsp1, (TknHdr **) &cmsp2, 
                     mep2->telp, mode, swtch, &flags); 
            melp2++;
            sav_melp1 = NULLP;
            if(*melp1 == NULLP)
            {
               melp1 = tmp_melp1;
               cmsp1 = msgCtlp->dup1;
            }
         }
      }  
   }
   RETVALUE(MFROK);
} /* end of siMfInitElmts */

  
/*
*
*       Fun:   siMfInitElmt
*
*       Desc:  message function - init element
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to initialize one specif information element.
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siMfInitElmt
(
SiMfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PUBLIC S16 siMfInitElmt(msgCtlp)
SiMfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
 
   CONSTANT SiMsgElmtDef *mep;
   ElmtHdr *cmsp1;
   ElmtHdr *cmsp2;
   ElmtHdr *sep;            /* source element header */
   ElmtHdr *dep;            /* destination element header */
   
   TRC2(siMfInitElmt)

   /* initialize control variables */
   siMfBackOut = 0;
   cmsp1 = msgCtlp->dup1;
   cmsp2 = msgCtlp->dup2;
   mep = msgCtlp->mep;

   /* init one message element */
#if (ERRCLASS & ERRCLS_DEBUG)
   if (((cmsp1) && (msgCtlp->mode != PRSNT_NODEF)))
      MSGRET(msgCtlp, MFDEBUGERR);

   if (((!cmsp1) && (msgCtlp->mode == PRSNT_NODEF)))
      MSGRET(msgCtlp, MFDEBUGERR);

   if (!mep )
      MSGRET(msgCtlp, MFDEBUGERR);
#endif

   sep = (ElmtHdr *) cmsp1;
   dep = (ElmtHdr *) cmsp2;
   

   if (cmsp1)
   {
      dep->pres = sep->pres;
/* si010.220: Modification - use macro ADDFARPTR */
      ADDFARPTR((PTR *) &cmsp1, (U32) sizeof(ElmtHdr));
   }
   else
   {
      dep->pres = msgCtlp->mode;
   }

/* si010.220: Modification - use macro ADDFARPTR */
   ADDFARPTR((PTR *) &cmsp2, (U32) sizeof(ElmtHdr));

   /* not present, init */
   if (mep->type != MET_SINGLE2)
   {
      siMfInitTkns((TknHdr **) &cmsp1, (TknHdr **) &cmsp2, mep->telp, 
         msgCtlp->mode, msgCtlp->swtch, &msgCtlp->flags);
   }
   RETVALUE(MFROK);
} /* end of siMfInitElmt */

  
/*
*
*       Fun:   siMfInitSdu
*
*       Desc:  message function - initialize data unit
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to initialize a sdu structure
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siMfInitSdu
(
SiMfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PUBLIC S16 siMfInitSdu(msgCtlp)
SiMfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;               /* return code */
   CONSTANT SiMsgDef *allPduDefs;
   CONSTANT SiMsgDef *allSduDefs; 
   U8 numPdus;            /* number of pdu messages in database */

   TRC2(siMfInitSdu)
   /* init message du structure */
   allPduDefs = msgCtlp->cfgp->pduDefs;
   allSduDefs = msgCtlp->cfgp->sduDefs;
   numPdus = msgCtlp->cfgp->numPdus;

   if (!msgCtlp->dup1)
   {
      msgCtlp->mdbp = NULLP;
      msgCtlp->melp1 = NULLP;
   }
   else
   {
      if (msgCtlp->smsgIdx < numPdus)
      {
         msgCtlp->mdbp = &allPduDefs[msgCtlp->smsgIdx];
         msgCtlp->melp1 = allPduDefs[msgCtlp->smsgIdx].melp;
      }
      else
      {
         msgCtlp->mdbp = &allSduDefs[msgCtlp->smsgIdx - numPdus];
         msgCtlp->melp1 = allSduDefs[msgCtlp->smsgIdx - numPdus].melp;
      }
   }
   msgCtlp->melp2 = allSduDefs[msgCtlp->dmsgIdx - numPdus].melp;
   msgCtlp->decode = FALSE; 
   ret = siMfInitElmts(msgCtlp);
   RETVALUE(ret);
} /* end of siMfInitSdu */

  
/*
*
*       Fun:   siMfInitPdu
*
*       Desc:  message function - initialize data unit
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to initialize a pdu structure.
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siMfInitPdu
(
SiMfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PUBLIC S16 siMfInitPdu(msgCtlp)
SiMfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;               /* return code */
   CONSTANT SiMsgDef *allPduDefs;
   CONSTANT SiMsgDef *allSduDefs;
   U8 numPdus;            /* number of pdu messages in database */

   TRC2(siMfInitPdu)
   /* init message du structure */
   allPduDefs = msgCtlp->cfgp->pduDefs;
   allSduDefs = msgCtlp->cfgp->sduDefs;
   numPdus = msgCtlp->cfgp->numPdus;

   if (!msgCtlp->dup1)
   {
      msgCtlp->mdbp = NULLP;
      msgCtlp->melp1 = NULLP;
   }
   else
   {
      if (msgCtlp->smsgIdx < msgCtlp->cfgp->numPdus)
      {
         msgCtlp->mdbp = &allPduDefs[msgCtlp->smsgIdx];
         msgCtlp->melp1 = allPduDefs[msgCtlp->smsgIdx].melp;
      }
      else
      {
         msgCtlp->mdbp = &allSduDefs[msgCtlp->smsgIdx - numPdus];
         msgCtlp->melp1 = allSduDefs[msgCtlp->smsgIdx - numPdus].melp;
      }
   }
   msgCtlp->melp2 = allPduDefs[msgCtlp->dmsgIdx].melp;
   msgCtlp->decode = FALSE; 
   ret = siMfInitElmts(msgCtlp);
   RETVALUE(ret);
} /* end of siMfInitPdu */

  
/*
*
*       Fun:   siMfDecPduHdr
*
*       Desc:  message function - decode pdu header
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to decode a pdu header from a Buffer structure.
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siMfDecPduHdr
(
SiMfMsgCtl *msgCtlp           /* pointer to message control structure */
)
#else
PUBLIC S16 siMfDecPduHdr(msgCtlp)
SiMfMsgCtl *msgCtlp;          /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */

   TRC2(siMfDecPduHdr)
      
   ret = ROK;

   /* decode message header */
   siMfReinitMsgCtl(msgCtlp);
   SFndLenMsg(msgCtlp->mp, &msgCtlp->baseIdx);

   msgCtlp->dir = MF_DECODE;

#ifdef SS7
   if (msgCtlp->cfgp->flags & MF_ISUP)
       ret = siMfDecSS7Elmts(msgCtlp);
   else if (msgCtlp->cfgp->flags & MF_TUP)
       ret = siMfDecSS7Elmts(msgCtlp);
   else if (msgCtlp->cfgp->flags & MF_SCCP)
       ret = siMfDecSS7Elmts(msgCtlp);
#endif /* SS7 */

   msgCtlp->melp1 = msgCtlp->smelp1;
   RETVALUE(ret);
} /* end of siMfDecPduHdr */

  
/*
*
*       Fun:   siMfDecPdu
*
*       Desc:  message function - decode pdu body
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to decode the rest of a pdu after header decoded.
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siMfDecPdu
(
SiMfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PUBLIC S16 siMfDecPdu(msgCtlp)
SiMfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;               /* return code */

   TRC2(siMfDecPdu)
      
   ret = ROK;

   /* decode message body */
   msgCtlp->smelp1 = msgCtlp->melp1;
   msgCtlp->dir = MF_DECODE;

   if (msgCtlp->cfgp->flags & MF_ISUP)
   {
       cmMemset((U8 *)msgCtlp->dup1, (U8 )NOTPRSNT, sizeof(SiAllPdus));
       ret = siMfDecSS7Elmts(msgCtlp);
   }

   RETVALUE(ret);
} /* end of siMfDecPdu */

  
/*
*
*       Fun:   siMfEncPduHdr
*
*       Desc:  message function - encode pdu header
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to encode a pdu from a message structure.
*
*       File:  si_mf.c
*
*/

#ifdef ANSI
PUBLIC S16 siMfEncPduHdr
(
SiMfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PUBLIC S16 siMfEncPduHdr(msgCtlp)
SiMfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;               /* return code */

   TRC2(siMfEncPduHdr)
      
   ret = ROK;

   /* encode message header */
   siMfReinitMsgCtl(msgCtlp);
   siMfOctet = 0;
   SFndLenMsg(msgCtlp->mp, &msgCtlp->baseIdx);

   msgCtlp->dir = MF_ENCODE;

   if (msgCtlp->cfgp->flags & MF_ISUP)
       ret = siMfEncSS7Elmts(msgCtlp);

   msgCtlp->melp1 = msgCtlp->smelp1;
   RETVALUE(ret);
} /* end of siMfEncPduHdr */
 
  
/*
*
*       Fun:   siMfEncPdu
*
*       Desc:  message function - encode pdu body
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to encode a pdu from a message structure.
*
*       File:  si_mf.c
*
*/

#ifdef ANSI
PUBLIC S16 siMfEncPdu
(
SiMfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PUBLIC S16 siMfEncPdu(msgCtlp)
SiMfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;               /* return code */

   TRC2(siMfEncPdu)
      
   ret = ROK;

   /* encode message body */
   msgCtlp->smelp1 = msgCtlp->melp1;
   msgCtlp->decode = FALSE; 
   msgCtlp->dir = MF_ENCODE;

   if (msgCtlp->cfgp->flags & MF_ISUP)
      ret = siMfEncSS7Elmts(msgCtlp);

   RETVALUE(ret);
} /* end of siMfEncPdu */
 
  
/*
*
*       Fun:   siMfBcopy
*
*       Desc:  copy a block from src to dest 
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/

#ifdef ANSI
PRIVATE S16 siMfBcopy
(
REG1 U8 *src,               /* source */
REG2 U8 *dst,               /* destination */
REG3 U32 count              /* count */
)
#else
PRIVATE S16 siMfBcopy(src, dst, count)
REG1 U8 *src;               /* source */
REG2 U8 *dst;               /* destination */
REG3 U32 count;             /* count */
#endif
{

   TRC2(siMfBcopy)

   cmMemcpy((U8 *) dst, (CONSTANT U8 *) src, (PTR) count);
   
   RETVALUE(ROK);

} /* end of siMfBcopy */
 

/*
*
*       Fun:   siMfStrlen
*
*       Desc:  Search for length of a null terminated string
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/

#ifdef ANSI
PRIVATE U32 siMfStrlen
(
REG1 U8 *srcp               /* source pointer */
)
#else
PRIVATE U32 siMfStrlen(srcp)
REG1 U8 *srcp;              /* source pointer */
#endif
{
   REG2 U8 *endp;           /* end pointer */

   TRC2(siMfStrlen)

   endp = srcp;
   if (srcp == NULLP)
      RETVALUE(0);
   while (*endp++ != 0);
   RETVALUE((endp - srcp) - 1);
} /* end of siMfStrlen */

#ifdef DBG4

/*
*
*       Fun:   siMfPrntErr
*
*       Desc:  print decode or encode error
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/

#ifdef ANSI
PUBLIC S16 siMfPrntErr
(
SiMfMsgCtl *m                 /* pointer to message control structure */
)
#else
PUBLIC S16 siMfPrntErr(m)
SiMfMsgCtl *m;                /* pointer to message control structure */
#endif
{
   S16 i;                   /* counter */
   Txt prntBuf[PRNTSZE];    /* print buffer */

   TRC2(siMfPrntErr)
   
   if (!(siCb.init.dbgMask & SIDBGMASK_MSGERR))
   {
      RETVALUE(MFROK);
   }
   
   sprintf(prntBuf,"\nsiMfPrntErr: errCnt  0x%02x,   mandCnt:  0x%02x\n",
      m->errCnt,m->acMandCnt);
   SPrint(prntBuf);
   sprintf(prntBuf,"siMfPrntErr: msgType 0x%02x,   msgIdx:   0x%02x\n",
      m->msgType,m->msgIdx);
   SPrint(prntBuf);
   sprintf(prntBuf,"siMfPrntErr: octIdx: 0x%02x\n", m->octIdx);
   SPrint(prntBuf);
   /* print entire error structure array */
   for (i = 0; i < MF_MAX_ERRORS; i++)
   {
      sprintf(prntBuf,"siMfPrntErr: elmtId: 0x%02x,   elmtIdx:  0x%02x\n",
         m->ee[i].elmtId, m->ee[i].elmtIdx);
      SPrint(prntBuf);
      sprintf(prntBuf,"siMfPrntErr: tknId:    ??,   tknIdx:   0x%02x\n", 
         m->ee[i].tknIdx);
      SPrint(prntBuf);
      sprintf(prntBuf,"siMfPrntErr: siMfCauseDgn.eh.pres:       0x%02x\n", 
         m->ee[i].siMfCauseDgn.eh.pres);
      SPrint(prntBuf);
      if (m->ee[i].siMfCauseDgn.eh.pres)
      {
         sprintf(prntBuf,"siMfPrntErr: siMfCauseDgn.causeVal.pres: 0x%02x\n", 
            m->ee[i].siMfCauseDgn.causeVal.pres);
         SPrint(prntBuf);
         if (m->ee[i].siMfCauseDgn.causeVal.pres)
         {
            sprintf(prntBuf,"siMfPrntErr: siMfCauseDgn.causeVal.val:  0x%02x\n", 
               m->ee[i].siMfCauseDgn.causeVal.val);
            SPrint(prntBuf);
         }
         sprintf(prntBuf,"siMfPrntErr: siMfCauseDgn.dgnVal.pres:   0x%02x\n", 
            m->ee[i].siMfCauseDgn.dgnVal.pres);
         SPrint(prntBuf);
         if (m->ee[i].siMfCauseDgn.dgnVal.pres)
         {
            sprintf(prntBuf,"siMfPrntErr: siMfCauseDgn.dgnVal.len:    0x%02x\n", 
               m->ee[i].siMfCauseDgn.dgnVal.len);
            SPrint(prntBuf);
            sprintf(prntBuf,"siMfPrntErr: siMfCauseDgn.dgnVal.val[0]: 0x%02x\n", 
               m->ee[i].siMfCauseDgn.dgnVal.val[0]);
            SPrint(prntBuf);
         }
      }
   }
   sprintf(prntBuf,"\n");
   SPrint(prntBuf);

   RETVALUE(MFROK);
} /* end of siMfPrntErr */
#endif

#ifdef SS7

#define VALIDATE(mc) if (mc->validate && (mc->acMandCnt < mc->exMandCnt)) \
        MSGRET(mc, MFCCINVINFOEL)


/*
*
*       Fun:   siMfDecSS7Elmts
*
*       Desc:  message function - decode elements for ISUP
*
*       Ret:   MFROK      - ok
*
*       Notes: siMfDecSS7Elmts is called instead of siMfDecElmts when
*             we are dealing with SS7 message elements. These two routines 
*             can not be integrated gracefully because some of the parameters
*             ids used for SS7 have the 8th bit set which makes them
*             indistinguishable from MET_SINGLE1, or MET_SINGLE2
*             parameters used in ISDN.
*            
*       File:  si_mf.c
*
*/

#ifdef ANSI
PRIVATE S16 siMfDecSS7Elmts
(
SiMfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 siMfDecSS7Elmts(msgCtlp)
SiMfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
    S16 ret;                /* return value */
    Swtch swtch;            /* Protocol Standard switch */
    CONSTANT SiMsgElmtDef *mep;   /* pointer to message element */
    ElmtHdr *ehp;           /* pointer to element header */
    ElmtHdr *fehp;          /* pointer to first element header */
    Data c;                 /* one octet of data */
#ifdef SI
    Data d;                 /* Temporary octet of data */
    MsgLen uLen;             /* counter */
#endif /* SI */

    MsgLen mlen;            /* message length */
    Bool opFlag;            /* optional parameter flag */
    U8 MFPSize;
    Bool fxdPres;

    TRC2(siMfDecSS7Elmts)

    /* msgCtlp->melp1 = message element defintion list (db)
     * msgCtlp->smelp1 = first message element defintion (db)
     * msgCtlp->dup1 = current element header tokens (storage/destination)
     * fehp = first element header (storage/destination)
     * ehp = current element header.
     * mep = current message element defintion.
     */

    /* RG: should remove this check to catch unrecognized elements; in that 
     * case, some logic will need to be changed to deal with null mep
     */
    /* make sure we have something to do */
    if (*msgCtlp->melp1 == NULLP)
      RETVALUE(MFROK);

    /* Intialize */

    /* Set the switch */
    swtch = msgCtlp->swtch;

    /* set optional parameter flag to false */
    opFlag = FALSE;

    /* set fehp to first element storage location */
    fehp = msgCtlp->dup1;

    MFPSize = 0;
    fxdPres = FALSE;

    /* set mep to first message element defintion */

    /* mlen is the length of the message in octets */

   SFndLenMsg(msgCtlp->mp, &mlen);

    mep = *msgCtlp->melp1;
    ehp = msgCtlp->dup1;

    /* Before the decoding procedure, the message format errors are checked.
     * These checking should be applicable for all the variants.
     * 1> if message length is less than the number of octets required for 
     *    the mandatory fixed part, the mandatory variable pointers and 
     *    the start of optional parameter pointer.
     * 2> if a mandatory variable or start of optional parameter's pointer
     *    points beyond the message length
     * 3> if a mandatory variable or optional parameter's length indicator
     *    causes the overall message length to be exceeds.
     * NOTE: 1> are checked before the decoding procedure by calling 
     *       siChkMsgFor, while 2> and 3> are checked during the element 
     *       decoding. In ISUP, we just check the token type as 
     *       MET_VARIABLE(for optional param)
     *       and MET_FIXED_PTR(for mandatory variable param).
     */
    
    /* if not a header decoding, we check the massage format error case 1> */
    if ((*(msgCtlp->melp1))->id != ME_HEDR)
    {
        ret = siChkMsgFor(mlen, msgCtlp->msgIdx, msgCtlp->swtch);
        if (ret != MFROK)
           MSGRET(msgCtlp, MFUNXENDOFMSG);
        /* assign the number of expected mand info elments */
        msgCtlp->exMandCnt = siMsgForTbl[msgCtlp->msgIdx][msgCtlp->swtch].exMandCnt;
    } 
    
    else
       /* for header decoding, exMandCnt should be 1 */
       msgCtlp->exMandCnt = 1;

    /* we loop continuously, however, there is one iteration
     * per message element
     */
    while (TRUE)      
    {
      /* Check if this element is applicable */
      if ( mep->flagp[swtch] & EF_NA )
      {
/* si010.220: Modification - use macro ADDFARPTR */
         ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));
         ADDFARPTR((PTR *) &msgCtlp->dup1, mep->skipsz);
         msgCtlp->melp1++;
         mep = *msgCtlp->melp1;
         ehp = msgCtlp->dup1;
         if (mep == (SiMsgElmtDef *)NULLP)
            /* nothing to decode */
            RETVALUE(MFROK);
         continue;
      }

       /* if this element is mandatory, increment expected mandatory count */
       switch(mep->type)
       {
          case MET_OPT:                /* TUP */
          {
             /* ehp points to the element header (storage) */ 
             ehp = msgCtlp->dup1;

             /* dup1 now points to the tokens */
/* si010.220: Modification - use macro ADDFARPTR */
             ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));

             /* set error indices */
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtIdx = mep->idx;
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = mep->id;

             /* set the length */
             msgCtlp->elen = mep->maxLen;

             /* decode the tokens */
/* si010.220: Modification - change argument mep->telp to mep */
             if ((ret = siMfDecTkns(msgCtlp->mp, mep, msgCtlp)) != MFROK)
             { 
                /* decode failed */

                /* If this element is mandatory, return with error code */
                if (mep->flagp[swtch] & EF_MAND)
                    MSGRET(msgCtlp, MFCCINVINFOEL);

                /* increment message element list */
                msgCtlp->melp1++;

                /* Check that it's valid */
                if (*msgCtlp->melp1 == NULLP)
                {
                   VALIDATE(msgCtlp);
                   RETVALUE(MFROK);
                }

                /* prepare for next iteration */
                mep = *msgCtlp->melp1;
                break;
             }

             /* decode succeeded */

             /* check the length */
             if (!(mep->flagp[swtch] & EF_VARLEN))
                if (msgCtlp->elen > 0)
                   MSGRET(msgCtlp, MFCCINVINFOEL);
                 
             if (msgCtlp->mdbp->func)   /* call user func if avail. */
             {
                if ((ret = (*msgCtlp->mdbp->func)(msgCtlp)) != MFROK)
                   MSGRET(msgCtlp, ret);
             }

             /* We don't mark the * "End of Optional Parameters" (id == 0) */
             ehp->pres = PRSNT_NODEF;

             /* increment actual mandatory count */
             if (mep->flagp[swtch] & EF_MAND)
                msgCtlp->acMandCnt++;
 
             /* increment message element list */
             msgCtlp->melp1++;

             /*  Is next available? */
             if (*msgCtlp->melp1 == NULLP)
             {
                VALIDATE(msgCtlp);
                RETVALUE(MFROK);
             }

             /* If mlen == msgCtlp->elen, nothing left to read */
             if (mlen == (MsgLen)msgCtlp->octIdx)
             {
                VALIDATE(msgCtlp);
                RETVALUE(MFROK);
             }

             /* prepare for next iteration */
             mep = *msgCtlp->melp1;
             ehp = msgCtlp->dup1;
             break;
          } 
          case MET_ENDOFOPT:     /* Fall through */
          case MET_FIXED:
          {
/*  si048.220   Add the remaining PDU to UBuf  *******/
#ifdef SI             
             /* if this is endopt but still some IE in the message remaining */
             if ((mep->id == 0) && ( mlen > ((MsgLen) msgCtlp->octIdx+1)))
             {
                      /* if no FIXED_PTR, adjust octet index for pointer here */
                      if (fxdPres == FALSE)
                      {
                         fxdPres = TRUE;
                         /* increment the indices for the element id */
                         msgCtlp->octIdx += 1;
                         msgCtlp->bitIdx += 8;
                      }
                      while (mlen > (MsgLen)msgCtlp->octIdx)
                      {
                        if (DecodeIeToUBuf(msgCtlp, mlen) == FALSE)
                        {
                          RETVALUE(MFROK);
                        }
                      }
		/* One last check */
                if (mlen == (MsgLen)msgCtlp->octIdx)
                {
                   VALIDATE(msgCtlp);
                   RETVALUE(MFROK);
                }
             }
#endif 
             /* ehp points to the element header (storage) */ 
             ehp = msgCtlp->dup1;

             /* dup1 now points to the tokens */
/* si010.220: Modification - use macro ADDFARPTR */
             ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));

             /* set error indices */
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtIdx = mep->idx;
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = mep->id;

             /* set the length */
             msgCtlp->elen = mep->maxLen;

             /* decode the tokens */
/* si010.220: Modification - change argument mep->telp to mep */
             if ((ret = siMfDecTkns(msgCtlp->mp, mep, msgCtlp)) != MFROK)
             { 
                /* decode failed */

                /* If this element is mandatory, return with error code */
                if (mep->flagp[swtch] & EF_MAND)
                    MSGRET(msgCtlp, ret);

                /* increment message element list */
                msgCtlp->melp1++;

                /* check if we have reached the end of list */
                if (*msgCtlp->melp1 == NULLP)
                {
                   VALIDATE(msgCtlp);
/*  si048.220   Add the remaining PDU to UBuf  *******/
                   {
                      /* if no FIXED_PTR, adjust octet index for pointer here */
                      if (fxdPres == FALSE)
                      {
                         fxdPres = TRUE;
                         /* increment the indices for the element id */
                         msgCtlp->octIdx += 1;
                         msgCtlp->bitIdx += 8;
                      }
                      while (mlen > (MsgLen)msgCtlp->octIdx)
                      {
                        if (DecodeIeToUBuf(msgCtlp, mlen) == FALSE)
                        {
                          RETVALUE(MFROK);
                        }
                      }
                   }
                   RETVALUE(MFROK);
                }

                /* prepare for next iteration */
                mep = *msgCtlp->melp1;
                break;
             }

             /* decode succeeded */

             /* check the length */
             if (!(mep->flagp[swtch] & EF_VARLEN))
                if (msgCtlp->elen > 0)
                   MSGRET(msgCtlp, MFCCINVINFOEL);
                 
             /* call user function, if available */
             if (msgCtlp->mdbp->func)   /* call user func if avail. */
             {
                if ((ret = (*msgCtlp->mdbp->func)(msgCtlp)) != MFROK)
                   MSGRET(msgCtlp, ret);
             }

             /* We don't mark the * "End of Optional Parameters" (id == 0) */
             ehp->pres = PRSNT_NODEF;

             /* increment actual mandatory count */
             if (mep->flagp[swtch] & EF_MAND)
                msgCtlp->acMandCnt++;
 
             /* increment message element list pointer */
             msgCtlp->melp1++;

             /* check if we have reached the end of list */
             if (*msgCtlp->melp1 == NULLP)
             {
                VALIDATE(msgCtlp);
                RETVALUE(MFROK);
             }

             /* check if we have reached the end of the buffer */
             if (mlen == (MsgLen)msgCtlp->octIdx)
             {
                VALIDATE(msgCtlp);
                RETVALUE(MFROK);
             }

             /* prepare for next iteration */
             mep = *msgCtlp->melp1;
             ehp = msgCtlp->dup1;
             break;
          } 
          case MET_VARIABLE:            
          {
             CONSTANT SiMsgElmtDef *hold_mep; /* place holder message element */
             ElmtHdr *hold_ehp;          /* place holder element header */
             Bool hold_flag;             /* flag; are we holding? */

             hold_flag = FALSE;
             hold_mep  = NULLP;
             hold_ehp  = NULLP;

             /* ehp points to the element header (storage) */
             ehp = msgCtlp->dup1;

             /* if no FIXED_PTR, adjust octet index for pointer here */
             if (fxdPres == FALSE)
             {
                fxdPres = TRUE;
                /* increment the indices for the element id */
                msgCtlp->octIdx += 1;
                msgCtlp->bitIdx += 8;
             }

             /*  if it's already present, we skip it */
             if ((ehp->pres == PRSNT_NODEF) || (ehp->pres == PRSNT_DEF))
             {
                /* increment message element list */
                msgCtlp->melp1++;

                if (*msgCtlp->melp1 == NULLP)
                {
                  VALIDATE(msgCtlp);
                  RETVALUE(MFROK);
                }

                /* One last check */
                if (mlen == (MsgLen)msgCtlp->octIdx)
                {
                  VALIDATE(msgCtlp);
                  RETVALUE(MFROK);
                }

                /* okay, next mep is good */

                /* skip the header */
/* si010.220: Modification - use macro ADDFARPTR */
                ADDFARPTR((PTR *)&msgCtlp->dup1, (U32) sizeof(ElmtHdr));

                /* skip the tokens */
/* si010.220: Modification - use macro ADDFARPTR */
                ADDFARPTR((PTR *) &msgCtlp->dup1, mep->skipsz);

                /* prepare for next iteration */
                mep = *msgCtlp->melp1;
                ehp = msgCtlp->dup1;
                break;
             }

             /* check the first octet */
             if (SExamMsg(&c, msgCtlp->mp, msgCtlp->octIdx) != ROK)
             {
                /* This may simply be it */
                VALIDATE(msgCtlp);
                RETVALUE(MFROK);
             }

             /* check if this octet = the current message element id */

             /* For Q.763, Optional Parameters may be in ANY order.
              * So, we look through the whole list of message elements
              * to try and find this message id; 
              */
             if (mep->id != c)
             { 
                CONSTANT SiMsgElmtDef *CONSTANT *tmp_melp;
                CONSTANT SiMsgElmtDef *tmp_mep;
                ElmtHdr *tmp_ehp;
                S16 found;

                found = FALSE;
                hold_mep = mep; 
                hold_ehp = ehp; 

                /*  set tmps to their head pointers */
                tmp_melp = msgCtlp->smelp1;
                tmp_mep = *msgCtlp->smelp1;
                tmp_ehp = fehp; 

                while ( tmp_mep != NULLP)
                {
                   /* id must match, and storage must be empty
                     and element must be aplicable */
                   if ((tmp_mep->id == c) && (tmp_ehp->pres == NOTPRSNT)
                       && !(tmp_mep->flagp[swtch] & EF_NA))
                   {
                      found = TRUE;
                      break;
                   }
                   /* Skip Tokens */
                   /* skip the header */
/* si010.220: Modification - use macro ADDFARPTR */
                   ADDFARPTR((PTR *)&tmp_ehp, (U32) sizeof(ElmtHdr));
                   /* skip the tokens */
                   ADDFARPTR((PTR *) &tmp_ehp, tmp_mep->skipsz);
                   tmp_melp++;
                   tmp_mep = *tmp_melp; /* next message element */
                }

                /* If we don't find it, something
                 * is wrong with the the pdu defintion,
                 * or this parameter doesn't exist in our db.
                 * record the error, but continue.
                 */
                if (!found) 
                {
#ifdef SI
                  /* Check if we already have a buffer with unrecognized
                     parameters */
                  if (msgCtlp->uBuf == NULLP)
                  {
                     /* if not allocate one */
                     ret = SGetMsg(msgCtlp->mem.region, msgCtlp->mem.pool, 
                                   &(msgCtlp->uBuf));
                     if (ret != ROK)
                     {
                        /* If allocation of a buffer fails we drop this 
                           parameter */
                        msgCtlp->uBuf = NULLP;
                     }

                  }
                  if (msgCtlp->uBuf != NULLP)
                  {
                     /* Add the unrecognized parameter */
                     ret = SAddPstMsg(c, msgCtlp->uBuf);
                     if (ret != ROK)
                     {
                        SPutMsg(msgCtlp->uBuf);
                        msgCtlp->uBuf = NULLP;
                     }
                  }
#endif /* SI */
                  msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = c;
                  /* check if message is not ended */
                  if( (msgCtlp->octIdx+1) == mlen )
                     MSGRET(msgCtlp, MFUNXENDOFMSG);
                  msgCtlp->octIdx+= 1;
                  msgCtlp->bitIdx+= 8;
                  ret = SExamMsg(&c, msgCtlp->mp, msgCtlp->octIdx);
                  if (ret != MFROK)
                     MSGRET(msgCtlp, ret);
#ifdef SI
                  /* copy the unrecognized parameter */
                  if (msgCtlp->uBuf != NULLP)
                  {
                     /* Add the length */
                     ret = SAddPstMsg(c, msgCtlp->uBuf);
                     if (ret == ROK)
                     {
                        for (uLen=1; uLen <= (MsgLen) c; uLen++)
                        {
                           ret = SExamMsg(&d,msgCtlp->mp,
                                    (MsgLen )(msgCtlp->octIdx+uLen));
                           if (ret != ROK)
                           {
                               /* remove the parameter form the uBuffer */
                               uLen++;
 
                               /* also remove id and length but incrementing
                                  here only by one, because uLen was already
                                  incremented in the for loop but the byte has
                                  not been added to the message yet */
 
                               while (uLen)
                               {
                                  ret = SRemPstMsg(&d, msgCtlp->uBuf);
                                  uLen--;
                               }
                               break;
                           }
                           ret = SAddPstMsg(d, msgCtlp->uBuf);
                           if (ret != ROK)
                           {
                              /* remove the parameter form the uBuffer */
                              uLen++;
 
                              /* also remove id and length but incrementing
                                 here only by one, because uLen was already
                                 incremented in the for loop but the byte has
                                 not been added to the message yet */

                              while (uLen)
                              {
                                 ret = SRemPstMsg(&d, msgCtlp->uBuf);
                                 uLen--;
                              }
                              break;
                           }
                        }
                     }
                     else
                     {
                        /* Remove element id and keep the rest of the buffer */
                        ret = SRemPstMsg(&d, msgCtlp->uBuf);
                     }
                  } 
#endif /* SI */
                  msgCtlp->octIdx+= c + 1;
                  msgCtlp->bitIdx+= ((c + 1) * 8);
                  break;
                }

                mep = tmp_mep;
                ehp = tmp_ehp;

                /* Check for the "End of Optional Parameters" Element */
                if (c == 0x00) /* We handle this in MET_FIXED case */
                {
                   if( mlen != ((MsgLen) msgCtlp->octIdx+1))
                   {
                      MSGRET(msgCtlp, MFCCINVMSGLEN);
                   }
                   msgCtlp->dup1 = ehp;
                   break;
                }

                hold_flag = TRUE;
             }

             /* increment the indices for the element id */
             msgCtlp->octIdx += 1;
             msgCtlp->bitIdx += 8;

             /* get the element length */
             if ((ret = SExamMsg((Data *) &msgCtlp->elen, msgCtlp->mp, 
                        msgCtlp->octIdx)) != ROK)
                RETVALUE(ret);

             /* increment the indices for the element length */
             msgCtlp->octIdx += 1;
             msgCtlp->bitIdx += 8;

             /* check the message format error case 3> for optional param
              * The length should not cause the message overall length
              * exceed.
              */
             if (mlen < (MsgLen)(msgCtlp->elen + msgCtlp->octIdx))
                MSGRET(msgCtlp, MFUNXENDOFMSG);

             /* set dup1 to current element definition */
             msgCtlp->dup1 = ehp;

             /* dup1 now points to the tokens */
/* si010.220: Modification - use macro ADDFARPTR */
             ADDFARPTR((PTR *)&msgCtlp->dup1, (U32) sizeof(ElmtHdr));

             /* set error indices */
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtIdx = mep->idx;
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = mep->id;

             /* si031.220: Addition - added code to check the element length
              * of MET_VARIABLE type. If the length is not valid, drop the 
              * parameter only.
              */
             if ((msgCtlp->validate) && ((msgCtlp->elen < mep->minLen) || 
                (msgCtlp->elen > mep->maxLen)))
             {
                siMfMsgRet(msgCtlp, SIMF_DISCPARM, __LINE__);
                msgCtlp->octIdx += msgCtlp->elen;
                msgCtlp->bitIdx = (U16)(msgCtlp->octIdx << 0x8);
 
                /* increment message element list */
                msgCtlp->melp1++;
 
                if (*msgCtlp->melp1 == NULLP)
                {
                  VALIDATE(msgCtlp);
                  RETVALUE(MFROK);
                }
 
                /* One last check */
                if (mlen == (MsgLen)msgCtlp->octIdx)
                {
                  VALIDATE(msgCtlp);
                  RETVALUE(MFROK);
                }
 
                /* okay, next mep is good */
 
                /* skip the tokens */
                ADDFARPTR((PTR *) &msgCtlp->dup1, mep->skipsz);
 
                /* prepare for next iteration */
                mep = *msgCtlp->melp1;
                ehp = msgCtlp->dup1;
                break;
             }

             /* try to decode the tokens */
/* si010.220: Modification - change argument mep->telp to mep */
             ret = siMfDecTkns(msgCtlp->mp, mep, msgCtlp); 
             if (ret != MFROK) 
             {
                if (ret == SIMF_DISCPARM)
                   siMfMsgRet(msgCtlp, SIMF_DISCPARM, __LINE__);
                else
                {  
                   MSGRET(msgCtlp, ret);
                } 

             }

             if (msgCtlp->elen > 0)            /* elen should be zero */
             {
                msgCtlp->octIdx += msgCtlp->elen;
                msgCtlp->bitIdx = (U16)(msgCtlp->octIdx << 0x8);
 
                /* increment message element list */
                msgCtlp->melp1++;
 
                if (*msgCtlp->melp1 == NULLP)
                {
                  VALIDATE(msgCtlp);
                  RETVALUE(MFROK);
                }
 
                /* One last check */
                if (mlen == (MsgLen)msgCtlp->octIdx)
                {
                  VALIDATE(msgCtlp);
                  RETVALUE(MFROK);
                }
 
                /* okay, next mep is good */
 
                /* skip the header */
/* si010.220: Modification - use macro ADDFARPTR */
                ADDFARPTR((PTR *)&msgCtlp->dup1, (U32) sizeof(ElmtHdr));
 
                /* prepare for next iteration */
                mep = *msgCtlp->melp1;
                ehp = msgCtlp->dup1;
                break;
             }
 

             if (msgCtlp->mdbp->func)   /* call user func if avail. */
             {
                ret = (*msgCtlp->mdbp->func)(msgCtlp);
                if (ret != ROK)
                {
                   msgCtlp->octIdx += msgCtlp->elen;
                   msgCtlp->bitIdx = (U16)(msgCtlp->octIdx << 0x8);
                   
                   /* increment message element list */
                   msgCtlp->melp1++;
                   
                   if (*msgCtlp->melp1 == NULLP)
                   {
                      VALIDATE(msgCtlp);
                      RETVALUE(MFROK);
                   }
                   
                   /* One last check */
                   if (mlen == (MsgLen)msgCtlp->octIdx)
                   {
                      VALIDATE(msgCtlp);
                      RETVALUE(MFROK);
                   }
                   
                   /* okay, next mep is good */
                   
                   /* skip the header */
/* si010.220: Modification - use macro ADDFARPTR */
                   ADDFARPTR((PTR *)&msgCtlp->dup1, (U32) sizeof(ElmtHdr));
                   
                   /* prepare for next iteration */
                   mep = *msgCtlp->melp1;
                   ehp = msgCtlp->dup1;
                   break;
                }
 
             }

             /* mark the header as present */
             ehp->pres = PRSNT_NODEF;
             opFlag = TRUE;

             /* check if we're holding */
             if (hold_flag)                   
             {
                /* have we exhausted the message buffer? */
                if (mlen == (MsgLen)msgCtlp->octIdx )
                {
                   /* if opFlag, and ISUP, there must be
                    * an end of optional parameter element which
                    * is type MET_FIXED. Therefore, this is an
                    * error. 
                    */
                   VALIDATE(msgCtlp);
                   RETVALUE(MFROK);
                }

                /* otherwise,  reset the pointers */
                msgCtlp->dup1 = hold_ehp;
                ehp = hold_ehp;
                mep = hold_mep;

                /* unset hold flag */
                hold_flag = FALSE; 
             }
             else                        /* we're not holding */
             {
                /* increment list */
                msgCtlp->melp1++; 

                /* Check that it's valid */
                if (*msgCtlp->melp1  == NULLP)
                {
                   /* if opFlag, and ISUP, there must be
                    * an end of optional parameter element which
                    * is type MET_FIXED. Therefore, this is an
                    * error. 
                    */
                   VALIDATE(msgCtlp);
                   RETVALUE(MFROK);
                }

                /* have we exhausted the message buffer? */
                if (mlen == (MsgLen)msgCtlp->octIdx)
                {
                   /* if opFlag, and ISUP, there must be
                    * an end of optional parameter element which
                    * is type MET_FIXED. Therefore, this is an
                    * error. 
                    */
                   VALIDATE(msgCtlp);
                   RETVALUE(MFROK);
                }

                /* otherwise, prepare for next iteration */
                mep =*msgCtlp->melp1;
                ehp = msgCtlp->dup1;
             }
             break;
          }
          case MET_FIXED_PTR:
          {
             U8 offset = (U8)0;
             U8 hold_idx = (U8)0;
             U8 opPtr = (U8)0;
             /* si017.220, Addition: variable declaration, parameter
              * last octet index */
             U16 parmLastOctIdx = (U16)0;

             fxdPres = TRUE;

             /* set error indices */
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtIdx = mep->idx;
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = mep->id;

             /* Get the offset */
             ret = SExamMsg(&offset, msgCtlp->mp, msgCtlp->octIdx);
             if (ret != ROK)
                RETVALUE(ret);
             if( ! offset )
             {
                MSGRET(msgCtlp, MFCCINVINFOEL);
             }

             /* increment indexes */
             msgCtlp->octIdx += 1;
             msgCtlp->bitIdx += 8;

             /* Save the current position */
             hold_idx = (U8)msgCtlp->octIdx;
             /* check the message format error case 2> for mand variable
              * the pointer does not points beyond the message length
              */
             if (mlen < (MsgLen)(msgCtlp->octIdx + (offset -1)))
                MSGRET(msgCtlp, MFUNXENDOFMSG);

             /* temporarily bump octIdx */
             msgCtlp->octIdx += (U8)(offset -1);
                
             /* get the element length */
             ret = SExamMsg((Data *) &msgCtlp->elen, msgCtlp->mp, 
                            msgCtlp->octIdx);
             if (ret != ROK)
                RETVALUE(ret);

             /* check the message format error case 3> for mand variable
              * The length should not cause the message overall length
              * exceed.
              */
             if (mlen < (MsgLen)(msgCtlp->elen + msgCtlp->octIdx + 1))
                MSGRET(msgCtlp, MFUNXENDOFMSG);
        
             /* si017.220, Addition: calculate parameter last octet index */
             parmLastOctIdx = msgCtlp->elen + msgCtlp->octIdx + 1;

             /* Keep tracking the Size */
             MFPSize += (msgCtlp->elen +1);

             /* increment the indices */
             msgCtlp->octIdx += 1;
             msgCtlp->bitIdx += 8;

             /* validate the length if required */
             if ((msgCtlp->validate) && ((msgCtlp->elen < mep->minLen) || 
                (msgCtlp->elen > mep->maxLen)))
                if (mep->flagp[swtch] & EF_MAND) 
                   MSGRET(msgCtlp, MFCCINVINFOEL);


             /* set dup1 to current element definition */
             msgCtlp->dup1 = ehp;

             /* dup1 now points to the tokens */
/* si010.220: Modification - use macro ADDFARPTR */
             ADDFARPTR((PTR *)&msgCtlp->dup1, (U32) sizeof(ElmtHdr));

             /* try to decode the tokens */
/* si010.220: Modification - change argument mep->telp to mep */
             ret = siMfDecTkns(msgCtlp->mp, mep, msgCtlp); 
             if (ret != MFROK)
                RETVALUE(ret);

             if (msgCtlp->elen > 0)      /* validate length */
                MSGRET(msgCtlp, MFCCINVINFOEL);

             if (msgCtlp->mdbp->func)   /* call user func if avail. */
             {
                if ((ret = (*msgCtlp->mdbp->func)(msgCtlp)) != MFROK)
                   MSGRET(msgCtlp, ret);
             }

             /* mark the header as present */
             ehp->pres = PRSNT_NODEF;

             /* All MET_FIXED_PTR elements are mandatory */
             msgCtlp->acMandCnt++;

             /* reset the index to the position of the pointers */
             msgCtlp->octIdx = hold_idx;

             /* point to next message element pointer */
             msgCtlp->melp1++; 

             /* Check if we've exhausted the message buffer */
             mep =*msgCtlp->melp1;
             ehp = msgCtlp->dup1;

             /* Check if we're done with mand. variables parameters */
             if ((mep != NULLP) && (mep->type != MET_FIXED_PTR))
             {
                /* si017.220, Addition: check if we have reached the end
                 * of the message which actually has no optional parameter
                 * included. */
                if (mlen == (MsgLen) parmLastOctIdx)
                   RETVALUE(MFROK);

                /* Grab the Pointer to Optional Parameters */
                ret = SExamMsg(&opPtr, msgCtlp->mp, msgCtlp->octIdx);
                msgCtlp->octIdx++;
                msgCtlp->bitIdx += 8;
                if (opPtr == 0)
                {
                   if ((MsgLen)(msgCtlp->octIdx + MFPSize) != mlen)
                   {  
                      MSGRET(msgCtlp, MFCCINFOELMSSG);
                   } 
                   else
                      RETVALUE(MFROK);
                }
                else
                {
                   /* check the message format error case 2> for optional ptr
                    * the pointer does not point beyond the message length
                    */
                   if (mlen < (MsgLen)(msgCtlp->octIdx + (opPtr - 1)))
                      MSGRET(msgCtlp, MFUNXENDOFMSG);

                   msgCtlp->octIdx += (opPtr -1);                      
                   msgCtlp->bitIdx += (opPtr -1) * 8;
                }
             }
             else 
                if (mep == NULLP)
                   RETVALUE(MFROK);

             /* If we're at the end of the message element poiters, ERROR */
             if (*msgCtlp->melp1  == NULLP)
                MSGRET(msgCtlp, MFCCINFOELMSSG);

             /* If we're at the end of the message, ERROR */
             if (mlen == (MsgLen)msgCtlp->octIdx)
                MSGRET(msgCtlp, MFCCINFOELMSSG);

             /* prepare for next iteration */
             break;
          }
          default:
             MSGRET(msgCtlp, MFCCINVMSG);
       }  /* end of switch */
    } /* end of while */
} /* end of siMfDecSS7Elmts */


/*
*
*       Fun:   siMfEncSS7Elmts
*
*       Desc:  message function - encode elements
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to encode ISUP elements...
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siMfEncSS7Elmts
(
SiMfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 siMfEncSS7Elmts(msgCtlp)
SiMfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
    S16 ret;                /* return value */
    Swtch swtch;            /* Protocol Standard switch */
    CONSTANT SiMsgElmtDef *mep;   /* pointer to message element */
    ElmtHdr *ehp;           /* pointer to element header */
    ElmtHdr *fehp;          /* pointer to first element header */
    Bool MFPFlag;           /* flag for MET_FIXED_PTR */
    Bool MVFlag;            /* flag for MET_VARIABLE */
    U8 opPtrIdx;            /* index for the  OptionalPointer */
    Bool firstVar;          /* first variable element flag */
    Bool optPres;           /* optional elements present flag */
#ifdef SI
    MsgLen uLen;
    Data   data;
    MsgLen uIdx;
#endif /* SI */


    TRC2(siMfEncSS7Elmts)

    /* Initialize */
    swtch = msgCtlp->swtch; /* set protocol switch */
    mep = *msgCtlp->melp1;  /* mep = first message element pointer */
    fehp = msgCtlp->dup1;   /* fehp = first element header */
    ehp = msgCtlp->dup1;    /* ehp = first element header */
    MFPFlag = FALSE;        /* Initialize to false */
    MVFlag = FALSE;         /* Initialize to false */
    opPtrIdx = 0;           /* Initialize to 0 */
    firstVar = TRUE;        /* Initialize to true */
    optPres = FALSE;

   /* One iteration per element to be encoded, except for
   * MET_FIXED_PTRS which must be handled all at once 
   */
   while (mep != NULLP)
   {
      /* Check if this Element is applicable */
      if (mep->flagp[swtch] & EF_NA)
      {
/* si010.220: Modification - use macro ADDFARPTR */
         ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));
         ADDFARPTR((PTR *) &msgCtlp->dup1, mep->skipsz);
         msgCtlp->melp1++;
         mep = *msgCtlp->melp1;
         ehp = msgCtlp->dup1;
         continue;
      }
      /* increment past element header */
/* si010.220: Modification - use macro ADDFARPTR */
      ADDFARPTR((PTR *)&msgCtlp->dup1, (U32)sizeof(ElmtHdr));

      /* update error indices */
      msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = mep->id;
      msgCtlp->ee[(S16)msgCtlp->errCnt].elmtIdx = mep->idx;

      /* Deal with Elements that are not present */
      if (ehp->pres == NOTPRSNT)
      {
         /* All mandatory elements must be present */
         if (mep->flagp[swtch] & EF_MAND)       
         {  
            MSGRET(msgCtlp, MFCCINFOELMSSG);
         } 
         else 
         {   /* Element not mandatory, and not present, skip */
/* si010.220: Modification - use macro ADDFARPTR */
             ADDFARPTR((PTR *) &msgCtlp->dup1, mep->skipsz);
             if ((mep->type == MET_VARIABLE)
                 || (mep->id == 0))
                optPres = TRUE; 
             msgCtlp->melp1++;
             mep = *msgCtlp->melp1;
             ehp = msgCtlp->dup1;
             continue;
         }      
      }  
      else      /* make sure pres value is valid */
      {
         if((ehp->pres != PRSNT_NODEF) && (ehp->pres != PRSNT_DEF))
         {
            if (mep->flagp[swtch] & EF_MAND)       
            {  
               MSGRET(msgCtlp, MFCCINFOELMSSG);
            } 
            else
            {   /* Element not mandatory, and not present, skip */
               ehp->pres = NOTPRSNT;
/* si010.220: Modification - use macro ADDFARPTR */
               ADDFARPTR((PTR *) &msgCtlp->dup1, mep->skipsz);
               if ((mep->type == MET_VARIABLE) || (mep->id == 0))
                  optPres = TRUE; 
               msgCtlp->melp1++;
               mep = *msgCtlp->melp1;
               ehp = msgCtlp->dup1;
               continue;
            }
         }
      }
      /* User Functions are called before encoding... */
      if (msgCtlp->mdbp)
         if (msgCtlp->mdbp->func)
            if ((ret = (*msgCtlp->mdbp->func)(msgCtlp)) != MFROK)
            {
               if ((mep->flagp[swtch] & EF_MAND) || 
                   !(msgCtlp->cfgp->flags & MF_IGNORE))
                  MSGRET(msgCtlp, ret);
               ehp->pres = NOTPRSNT;
/* si010.220: Modification - use macro ADDFARPTR */
               ADDFARPTR((PTR *) &msgCtlp->dup1, mep->skipsz);
               msgCtlp->melp1++;
               mep = *msgCtlp->melp1;
               ehp = msgCtlp->dup1;
               continue; /* next iteration */
            }

      /*  If we're here, we need to encode this element */
      switch(mep->type)
      {
         case MET_OPT:
         case MET_FIXED:
         {
            if (mep->id == 0)      /* If EndOp */
            {
               /* Skip */
               msgCtlp->melp1++;
               mep = *msgCtlp->melp1;
               ehp = msgCtlp->dup1;
               break;
            }
            msgCtlp->elen = 0;
            if ((ret = siMfEncTkns(msgCtlp->mp, 
                (CONSTANT SiTknElmtDef* CONSTANT*)mep->telp, msgCtlp)) != MFROK) 
               RETVALUE(ret);
            if ((msgCtlp->elen < mep->minLen) || (msgCtlp->elen > mep->maxLen))
               MSGRET(msgCtlp, MFCCINVINFOEL);
            /* increment melp1 */
            msgCtlp->melp1++;
            mep = *msgCtlp->melp1;
            ehp = msgCtlp->dup1;
            break;  /* next iteration... */
         }
         case MET_VARIABLE:
         {
            U16 holdIdx;         /* holder for element length index */
            /* si021.220: Addition - add variable declarations for use 
             * in this case block. 
             */
            U16 octIdx;          /* octet index */
            U16 bitIdx;          /* bit index */

            MVFlag = TRUE;       /* We have Parameters of type MET_VARIABLE */
            optPres = TRUE;
            siMfOctet = 0;
            /* si021.220: Deletion - remove the variable declarations 
             * to before any C statement to avoid compilation error
             */ 

            /* if no mandatory elements */
            if ((MFPFlag == FALSE) && (firstVar))
            {
/* si043.220 : Modification - In case there is only single opt parameter
                              and it is dropped, set start of opt param
                              to zero
*/
              /* firstVar = FALSE; */

               msgCtlp->octIdx += 1;
               msgCtlp->bitIdx += 8;
               if (msgCtlp->encode)
               {
                  ret = SAddPstMsg((U8)1, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
                  if (ret != ROK)
                     MSGRET(msgCtlp, MFRESFAILURE);
#endif
               }
            }

            /* encode element id */
            if (msgCtlp->encode)
            {
               ret = SAddPstMsg((U8)mep->id, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif
            }
            msgCtlp->octIdx += 1;
            msgCtlp->bitIdx += 8;
            /* save the element length index */
            holdIdx = msgCtlp->octIdx + msgCtlp->baseIdx;
            /* encode a zero into the element length */
            if (msgCtlp->encode)
            {
               ret = SAddPstMsg((U8)0, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif
            }
            msgCtlp->octIdx += 1;
            msgCtlp->bitIdx += 8;

            /* si020.220: Addition - add code to save the octet 
             * and bit index numbers so that we can resume them 
             * in case of encoding errors in siMfEncTkns. 
             */
            octIdx = msgCtlp->octIdx;
            bitIdx = msgCtlp->bitIdx;
            /* encode the tokens */
            msgCtlp->elen = 0;
            ret = siMfEncTkns(msgCtlp->mp, 
                   (CONSTANT SiTknElmtDef * CONSTANT*) mep->telp, msgCtlp);
            if (ret != MFROK)
            {
               Data foo[MF_SIZE_TKNSTR];
               if ((ret == MFRESFAILURE) || (ret == MFDEBUGERR))
                  RETVALUE(ret);
               if ((mep->flagp[swtch] & EF_MAND) &&
                      (!msgCtlp->cfgp->flags & MF_IGNORE))
                  RETVALUE(ret);
               /* else skip */
               msgCtlp->errCnt = 0;
               siMfBackOut = 0;
               ehp->pres = NOTPRSNT;
/* si043.220 : Modification - In case there is only single opt parameter
                              and it is dropped, set start of opt param
                              to zero
*/
               if ((firstVar))
                  MVFlag = FALSE;

               /* si020.220: Addition - resume the octet and bit index using
                * the saved values.
                */
               msgCtlp->octIdx = octIdx;
               msgCtlp->bitIdx = bitIdx;

               msgCtlp->octIdx -= 2;
               msgCtlp->bitIdx -= 16;
               msgCtlp->dup1 = ehp;
               if ((ret = SRemPstMsgMult(foo, (MsgLen)(msgCtlp->elen + 2) , 
                          msgCtlp->mp))!= ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
/* si010.220: Modification - use macro ADDFARPTR */
               ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));
               ADDFARPTR((PTR *) &msgCtlp->dup1, mep->skipsz);
               msgCtlp->melp1++;
               mep = *msgCtlp->melp1;
               ehp = msgCtlp->dup1;
               break;  /* next iteration... */
            }

            /* encode was successfull */
            if ((msgCtlp->elen < mep->minLen) || (msgCtlp->elen > mep->maxLen))
               MSGRET(msgCtlp, MFCCINVINFOEL);
            /* replace the element zero with the correct 
             * element length
             */
            if (msgCtlp->encode)
            {
               if (msgCtlp->elen != 0)
               {
                  ret = SRepMsg(msgCtlp->elen, msgCtlp->mp, holdIdx);
#if (ERRCLASS & ERRCLS_ADD_RES)
                  if (ret != ROK)
                     MSGRET(msgCtlp, MFRESFAILURE);
#endif
               }
            }
/* si043.220 : Modification - In case there is only single opt parameter
                              and it is dropped, set start of opt param
                              to zero
*/
            firstVar = FALSE;
            /* if element break flag set, exit ok */
            if (mep->flagp[swtch] & EF_BREAK)
            {
               if (mep->flagp[swtch] & EF_REP)
                  msgCtlp->dup1 = fehp;
               else 
                  msgCtlp->melp1++;
               RETVALUE(MFROK);
            }
            msgCtlp->melp1++;
            mep = *msgCtlp->melp1;
            ehp = msgCtlp->dup1;
            break;
         }
         case MET_FIXED_PTR:
         {
            /* MET_FIXED_PTRs must be encoded all at once,
             * this is the one exception to the one iteration, one 
             * element comment above
             */
            U8 cnt;           /* counter */
            U8 nElmts;        /* number of elements */
            U8 nmbElmts;      /* number of elements */
            U8 strtIdx;       /* the octIdx where we start */
            U8 opPtrVal;      /* value of optional Pointer */

            CONSTANT SiMsgElmtDef *CONSTANT *tmp_melp;
            CONSTANT SiMsgElmtDef *tmp_mep;
            ElmtHdr   *tmp_ehp;

            /* Initialize from where we are */
            MFPFlag = TRUE;      /* we have MET_FIXED_PTR variables */
            nElmts = 0;
            nmbElmts = 0;
            opPtrVal = 0;
            tmp_melp = msgCtlp->melp1;
            tmp_mep = mep;
            tmp_ehp = ehp;

            /* First look ahead */
            while ((tmp_mep != NULLP) && (tmp_mep->type == MET_FIXED_PTR))
            {
               if (!(tmp_mep->flagp[swtch] & EF_NA))
                  nElmts++;
               tmp_melp++;
               tmp_mep = *tmp_melp;
            }
            /* Okay, we have the number of elements */

            /* preserve some important indices */  

            /* where we start */
            strtIdx = (U8)(msgCtlp->octIdx + msgCtlp->baseIdx);      

            /* where the OpPtr goes */
            opPtrIdx = strtIdx + nElmts;      

            /* Code to check the swtch flag before to determine the optional 
             * pointer. first, check if there is a need for the optional 
             * pointer 
             */
            if (tmp_mep == NULLP)
            {
               opPtrVal = nElmts;
               nmbElmts = nElmts;
            }
            else
            {
               /* There exists an optional parameter.  However, need to check
                * the swtch flag to determine if this optional variable is 
                * applicatable to itselt.
                */
               while (tmp_mep != NULLP)
               {
                  if (((tmp_mep->type == MET_VARIABLE) ||
                      (tmp_mep->type == MET_FIXED) ||
                      (tmp_mep->type == MET_ENDOFOPT)) &&
                      (!(tmp_mep->flagp[swtch] & EF_NA)))
                  {
                     /* where the OpPtr goes */
                     optPres = TRUE;
                     nmbElmts = (nElmts + 1);
                     opPtrVal = (U8) (nElmts + 1);
                     break;
                  }
                  else
                  {
                     /* the optional parameter is not applicatable */
                     opPtrVal = nElmts;
                     nmbElmts = nElmts;
                     tmp_melp++;
                     tmp_mep = *tmp_melp;
                  }
               } /* end of while */
            } /* end of else */

            /* make room for the pointers */
            for ( cnt = 0; cnt < nmbElmts; cnt++)
            {
               /* we put zeros the pointers, 
                * and the optional pointer for now 
                */
               ret = SAddPstMsg(0, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif
               /* increment the message control indices */
               msgCtlp->octIdx += 1;
               msgCtlp->bitIdx += 8;
            }

            /* reset the pointers */

            /* now we encode  */
            mep = *msgCtlp->melp1;
            for ( cnt = 0; cnt < nElmts; cnt++)
            {
               U8 elenIdx; /* index of element length */
               /* Check if this Element is applicable */
               if (mep->flagp[swtch] & EF_NA)
               {
/* si010.220: Modification - use macro ADDFARPTR */
                  ADDFARPTR((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));
                  ADDFARPTR((PTR *) &msgCtlp->dup1, mep->skipsz);
                  msgCtlp->melp1++;
                  mep = *msgCtlp->melp1;
                  ehp = msgCtlp->dup1;
                  cnt--;
                  continue;
               }
               if (cnt != 0)
/* si010.220: Modification - use macro ADDFARPTR */
                  ADDFARPTR((PTR *)&msgCtlp->dup1, (U32)sizeof(ElmtHdr));
               elenIdx = (U8)(msgCtlp->octIdx + msgCtlp->baseIdx);

               /* put a zero in the place of the of the element length */
               ret = SAddPstMsg(0, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif

               msgCtlp->octIdx += 1;
               msgCtlp->bitIdx += 8;

               msgCtlp->elen = 0;
               ret = siMfEncTkns(msgCtlp->mp, mep->telp, msgCtlp);
               if (ret != MFROK)
                  RETVALUE(ret);

               /* encode was successfull */

               /* check the length */
               if ((msgCtlp->elen < mep->minLen) || 
                   (msgCtlp->elen > mep->maxLen))
                  MSGRET(msgCtlp, MFCCINVINFOEL);

               /* replace the element length of zero with the correct 
                * element length
                */

               ret = SRepMsg(msgCtlp->elen, msgCtlp->mp, elenIdx);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif

               /* set the ptr val */
               ret = SRepMsg(opPtrVal, msgCtlp->mp, (MsgLen )(strtIdx + cnt));
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif

               /* increment the Optional Pointer Val 
                * by the length plus the element length 
                */
               opPtrVal += msgCtlp->elen; 

               msgCtlp->melp1++;
               mep = *msgCtlp->melp1;
               ehp = msgCtlp->dup1;
               /* si027.220: addition - added code to update error indices */
               if (mep != NULLP)
               {
                  msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = mep->id;
                  msgCtlp->ee[(S16)msgCtlp->errCnt].elmtIdx = mep->idx;
               }
            }
            /* We're done with the pointers, now set OpPtr */
            if (optPres)
            {
               ret = SRepMsg(opPtrVal, msgCtlp->mp, opPtrIdx);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif
            }
            break;
         }
      } /* end of switch */
   } /* end of while */

   /* deal with our flags */
#ifdef SI
   if (msgCtlp->uBuf != NULLP)
   {
      ret = ROK;
      if ((MFPFlag == FALSE) && (firstVar == TRUE))
      {
         firstVar = FALSE;
         ret = SAddPstMsg((U8)1, msgCtlp->mp);
      }
      if (ret == ROK)
      {
         ret = SFndLenMsg( msgCtlp->uBuf, &uLen);
         if (ret == ROK)
         {
            for (uIdx=0; uIdx<uLen; uIdx++)
            {
               ret = SExamMsg(&data, msgCtlp->uBuf, uIdx);
               if (ret != ROK)
               {
                  /* remove the parameter form the uBuffer */
                  uLen++;
 
                  /* also remove id and length but incrementing
                     here only by one, because uLen was already
                     incremented in the for loop but the byte has
                     not been added to the message yet */
 
                  while (uLen)
                  {
                     ret = SRemPstMsg(&data, msgCtlp->uBuf);
                     uLen--;
                  }
                  break;
               }
               ret = SAddPstMsg(data, msgCtlp->mp);
               if (ret != ROK)
               {
                  /* remove the parameter form the uBuffer */
                  uLen++;
                  /* also remove id and length but incrementing
                     here only by one, because uLen was already
                     incremented in the for loop but the byte has
                     not been added to the message yet */

                  while (uIdx)
                  {
                     ret = SRemPstMsg(&data, msgCtlp->uBuf);
                     uIdx--;
                  }
                  break;
               }
            }
            MVFlag = TRUE;
         }
      }
   }
#endif /* SI */
   if ((MFPFlag == TRUE))            /* we have MET_FIXED_PTRs */
   {
      if (MVFlag == TRUE)            /* we have MET_VARIABLE */
      {
         ret = SAddPstMsg((U8)0, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
      if (ret != ROK)
         MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
      else
      {
         if (optPres)
         {
            ret = SRepMsg((U8) 0, msgCtlp->mp, opPtrIdx);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
         }
      }
   }
   else /* No MET_FIXED_PTRs */
   {
      if (optPres == TRUE)                 /* we have MET_VARIABLE */
      {
         ret = SAddPstMsg((U8)0, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
   }
   RETVALUE(MFROK);
} /* end of siMfEncSS7Elmts */



/*
*
*       Fun:   siMfSetMfLen
*
*       Desc:  message function - sets siMfLen value based on token dependencies
*
*       Ret:   MFROK      - ok
*
*       Notes: 
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PUBLIC Void siMfSetMfLen
(
U8 len
)
#else
PUBLIC Void siMfSetMfLen(len)
U8 len;
#endif
{
   TRC2(siMfSetSiMfLen)

   siMfLen = len;
   RETVOID;
} /* siMfSetSiMfLen */


/*
*
*       Fun:   siMfGetMfLen
*
*       Desc:  message function - sets siMfLen value based on token dependencies
*
*       Ret:   MFROK      - ok
*
*       Notes: 
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siMfGetMfLen
(
void
)
#else
PUBLIC S16 siMfGetMfLen()
#endif
{
   TRC2(siMfGetMfLen)

  RETVALUE(siMfLen);
} /* siMfGetSiMfLen */

#endif /* SS7 */


/*
*
*       Fun:   siMfInitForMsg
*
*       Desc:  message function - initialize the message format table
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siMfInitForMsg
(
void     
)
#else
PUBLIC S16 siMfInitForMsg()
#endif
{
   U16 numPdu;                            /* a couter for PDU def */
   U16 numSwtch;                          /* a counter for swtch type */
   CONSTANT SiMsgElmtDef *CONSTANT *melp; /* msg elmt list ptr */
   CONSTANT SiMsgElmtDef *meptmp;         /* ptr to message element */
   CONSTANT SiMsgDef *siAllPduDefs1;      /* pointer to pdu def */
   CONSTANT SiMsgDef *deftmp;             /* message pdu def ptr */

   U8  exMandCnt;                         /* Mand fix param counter */
   U16 numMandVar;                        /* number of mand variable ptr */
   U16 mandFixLen;                        /* total length of mand fix param */
   Bool opFlag;                            /* optional param flag */
           
   TRC2(siMfInitForMsg)

   /* meptmp definition */
   melp = (CONSTANT SiMsgElmtDef **)NULLP;
   /* pointer to all pdu definition structure */
   siAllPduDefs1 = &siAllPduDefs[0]; 

   mandFixLen = 0;
   numMandVar = 0;
   exMandCnt = 0;
   opFlag = FALSE;
   
   /* loop through the pdus */
   for (numPdu = 0; siAllPduDefs1[numPdu].melp; numPdu++)
   {
      deftmp = &siAllPduDefs1[numPdu];
      
      /* loop through the variant */
      for (numSwtch = 0; numSwtch < SI_MAX_SWITCH; numSwtch++ )
      {
         /* set the meptmp to the elment list ptr */
         melp = siAllPduDefs1[numPdu].melp;
         meptmp = *melp;
         
         if (deftmp->flagp[numSwtch] & MF_NA)
         {
            siMsgForTbl[numPdu][numSwtch].flags = MF_NA;
            siMsgForTbl[numPdu][numSwtch].exMandCnt = 0;
            siMsgForTbl[numPdu][numSwtch].mandFixLen = 0;
            siMsgForTbl[numPdu][numSwtch].numMandVar = 0;
            siMsgForTbl[numPdu][numSwtch].opVarFlag = FALSE;
            continue;
         }
         else
         {
             while(meptmp)
             {
                /* First check the database defintions */
                if (meptmp->flagp[numSwtch] & EF_MAND)
                {
                   /* Mandatory elements:
                    * 1) includes the mandatory fixed and variable param
                    * 2) counts the number of octets of mandatory fixed
                    *    param.
                    * 3) counts the number of mandatory variable param
                    * 4) checks if there exists optional param.
                    */
                   exMandCnt++;
                   if (meptmp->type & MET_FIXED)
                         mandFixLen += meptmp->minLen;
                   else
                      numMandVar++;
                }
                else
                {
                    /* not a mandatory param, it could be an optional or
                     * not applicable. If it is optional, set the optional
                     * flag true.
                     */
                    if ((!(meptmp->flagp[numSwtch] & EF_NA)) && (!opFlag))
                        opFlag = TRUE;
                }
                melp++;
                meptmp = *melp;
             }        
             /* assign to the message format table */
             siMsgForTbl[numPdu][numSwtch].flags = MF_OP;
             siMsgForTbl[numPdu][numSwtch].numMandVar = numMandVar;
             siMsgForTbl[numPdu][numSwtch].exMandCnt = exMandCnt;
             siMsgForTbl[numPdu][numSwtch].opVarFlag = opFlag;
             /* count message type field as one mand fixed octed */
             siMsgForTbl[numPdu][numSwtch].mandFixLen = mandFixLen++;
                
             /* reset the variables */
             mandFixLen = 0;
             numMandVar = 0;
             exMandCnt = 0;
             opFlag = FALSE;

          }
       }
               
   }

   RETVALUE(MFROK);
} /* end of siMfInitForMsg */


/*
*
*       Fun:   siChkMsgFor
*
*       Desc:  message function - check message format error case 1>
*              -- if message length is less than the number of octets required 
*                 for the mandatory fixed part, the mandatory variable pointers 
*                 and the start of optional parameter pointer.
*
*       Ret:   MFROK      - no error
*              RFAILED    - has error
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siChkMsgFor
(
MsgLen mlen,                  /* length of message */
U8 msgIdx,                    /* message index */
Swtch swtch                   /* switch index */
)
#else
PRIVATE S16 siChkMsgFor (mlen, msgIdx, swtch)
MsgLen mlen;                  /* length of message */
U8 msgIdx;                    /* message index */
Swtch swtch;                  /* switch index */
#endif
{
   U16 minMsgLen;             /* required minimum message length */
   U16 mandFixLen;            /* total length of mand fixed param */
   U16 numMandVar;            /* total number of mand variable ptr */
   Bool opFlag;               /* optional param flag */
   
   TRC2(siChkMsgFor)
           
   /* check if the message type is applicable */
   if (siMsgForTbl[msgIdx][swtch].flags & MF_NA)
   {
      SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "Msg type %d, 0x%dx not found in Data Base\n",msgIdx,msgIdx));
      RETVALUE (RFAILED);
   }
                   
   /* set the local variables */
   mandFixLen = siMsgForTbl[msgIdx][swtch].mandFixLen;
   numMandVar = siMsgForTbl[msgIdx][swtch].numMandVar;
   opFlag = siMsgForTbl[msgIdx][swtch].opVarFlag;

   /* add the number of octets required for fixed mand and mand variable
    * pointers for the specified message type and variant
    */
   minMsgLen = mandFixLen + numMandVar;

   /* add 1 octet to the minMsgLen if the optional param exists */
   if (opFlag)
      minMsgLen++;

   /* check the message format error case 1> */
   if (mlen < (MsgLen) minMsgLen)
      RETVALUE(RFAILED);

   RETVALUE(MFROK);

} /* end of siChkMsgFor */

/* si009.220, ADDED: return the cause default value base on the cause class */

/*
*
*       Fun:   siMfGetCauseDef
*
*       Desc:  return the cause default value based on the cause class
*
*       Ret:   cause default value 
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
#ifdef ANSI
PRIVATE S16 siMfGetCauseDef
(
U8 value                      /* token value */
)
#else
PRIVATE S16 siMfGetCauseDef (value)
U8 value;                     /* token value */
#endif
{
   TRC2(siMfGetCauseDef)
           
   switch (value & MF_CHKCAUBIT)
   {
      case SIMF_CAUCLS000:    /* normal event */
      case SIMF_CAUCLS001:
         RETVALUE(SIT_CCNORMUNSPEC);

      case SIMF_CAUCLS010:    /* resource unavailable */
         RETVALUE(SIT_CCRESCUNAVAIL);

      case SIMF_CAUCLS011:    /* servie or option not available */
         RETVALUE(SIT_CCSERVUNAVAIL);

      case SIMF_CAUCLS100:    /* servie or option not implemented */
         RETVALUE(SIT_CCSERVNOTIMP);

      case SIMF_CAUCLS101:    /* invalid message */
         RETVALUE(SIT_CCINVMSG);

      case SIMF_CAUCLS110:    /* protocol error */
         RETVALUE(SIT_CCPROTERR);

      case SIMF_CAUCLS111:    /* interworking class */
      default:
         RETVALUE(SIT_CCINTRWRK);
   }
} /* end of siMfGetCauseDef */

/*si048.220 ADDED : Handler to decode the UBuf */

/*
*
*       Fun:  DecodeIeToUBuf 
*
*       Desc:  
*
*       Ret:   return the FALSE/TRUE 
*
*       Notes: None
*
*       File:  si_mf.c
*
*/
#ifdef ANSI
Bool DecodeIeToUBuf(
SiMfMsgCtl *msgCtlp,
MsgLen mlen
)
#else
Bool DecodeIeToUBuf(msgCtlp, mlen)
SiMfMsgCtl *msgCtlp;
MsgLen mlen;
#endif
{
    S16 ret;                /* return value */
    Data c;                 /* one octet of data */
    Data d;                 /* Temporary octet of data */
    MsgLen uLen;             /* counter */



    /* One last check */
    if (mlen == (MsgLen)msgCtlp->octIdx)
    {
      return FALSE;
    }

    /* check the first octet */
    if (SExamMsg(&c, msgCtlp->mp, msgCtlp->octIdx) != ROK)
    {
      return FALSE;
    }

    /* Check for the "End of Optional Parameters" Element */
    if (c == 0x00)
    {
      return FALSE;
    }

    /* Check if we already have a buffer with unrecognized
       parameters */
    if (msgCtlp->uBuf == NULLP)
    {
       /* if not allocate one */
       ret = SGetMsg(msgCtlp->mem.region, msgCtlp->mem.pool,
                     &(msgCtlp->uBuf));
       if (ret != ROK)
{
          /* If allocation of a buffer fails we drop this
             parameter */
          msgCtlp->uBuf = NULLP;
          return FALSE;
       }
    }

    if (msgCtlp->uBuf != NULLP)
    {
       /* Add the unrecognized parameter */
       ret = SAddPstMsg(c, msgCtlp->uBuf);
       if (ret != ROK)
       {
         return FALSE;
       }
       /* check if message is not ended */
       if( (msgCtlp->octIdx+1) == mlen )
       {
             /* Remove element id and keep the rest of the buffer */
             ret = SRemPstMsg(&d, msgCtlp->uBuf);
         return FALSE;
       }
       msgCtlp->octIdx+= 1;
       msgCtlp->bitIdx+= 8;

       ret = SExamMsg(&c, msgCtlp->mp, msgCtlp->octIdx);
       if (ret != MFROK)
       {
             /* Remove element id and keep the rest of the buffer */
             ret = SRemPstMsg(&d, msgCtlp->uBuf);
           return FALSE;
       }
       /* copy the unrecognized parameter */
       if (msgCtlp->uBuf != NULLP)
       {
          /* Add the length */
          ret = SAddPstMsg(c, msgCtlp->uBuf);
          if (ret == ROK)
{
             for (uLen=1; uLen <= (MsgLen) c; uLen++)
             {
                ret = SExamMsg(&d,msgCtlp->mp,
                         (MsgLen )(msgCtlp->octIdx+uLen));
                if (ret != ROK)
                {
                    /* remove the parameter form the uBuffer */
                    uLen++;

                    /* also remove id and length but incrementing
                       here only by one, because uLen was already
                       incremented in the for loop but the byte has
                       not been added to the message yet */

                    while (uLen)
                    {
                       ret = SRemPstMsg(&d, msgCtlp->uBuf);
                       uLen--;
                    }
                    break;
                }
                ret = SAddPstMsg(d, msgCtlp->uBuf);
                if (ret != ROK)
                {
                   /* remove the parameter form the uBuffer */
                   uLen++;

                   /* also remove id and length but incrementing
                      here only by one, because uLen was already
                      incremented in the for loop but the byte has
                      not been added to the message yet */

                   while (uLen)
                   {
                      ret = SRemPstMsg(&d, msgCtlp->uBuf);
                      uLen--;
                   }
                   break;
                }
             }
}
          else
          {
             /* Remove element id and keep the rest of the buffer */
             ret = SRemPstMsg(&d, msgCtlp->uBuf);
          }
       }
       msgCtlp->octIdx+= c + 1;
       msgCtlp->bitIdx+= ((c + 1) * 8);
     }

   return TRUE;
}
/********************************************************************30**
  
         End of file:     si_mf.c@@/main/8 - Wed Jul 25 13:20:24 2001
    
*********************************************************************31*/


/********************************************************************40**

   Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

   Revision history:

*********************************************************************61*/


/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rs   1. initial release for ISUP.
             ---      rh   1. Removed SCCP MF functions to avoid symbol 
                              referencing erros
1.2          ---      rs   1. Removed IN releated code.
1.2+         ---      ym   1. Error is returned on getting extra bytes
                              after end of optional.
             ---      ym   1. Unexpected end of message is handled.
                           2. In siMfDecU8Enum proper return value is
                              returned if no action indicator is specified
                              for the token.
             ---      ym   1. Handling of zero pointer to variable mandatory
                              parameters is corrected.
             ---      ym   1. The fpAdd function is made public.
                           2. Extern declr for fpAdd is removed from this
                              file.
                           3. siMfChkEnum is made public and local extern
                              declr. is removed.
             ---      ym   1. ret value is initialised to MFROK in 
                              siMfDecU8Enum.
                           2. In siMfInitTkns the validation of present flag
                              is done properly.
                           3. In siMfInitTkns the PRSNT_INVALID is taken care
                              in initialising the token.
                           4. The double assignment in siMfEncTkns is 
                              removed.
                           5. Default value filling is corrected in 
                              siMfDecU8Enum
                           6. The initialisation of the allPdu is 
                              optimised.
             ---      ym   1. Mandatory element count is updated properly.
1.5          ---      dvs  1. miscellaneous changes
1.6          ---      bsp  1. Merged the message processing functions from ISUP
                              2.16 (LPR for Bellcore GR-317 variant of ISUP) with
                              the database from ISUP 2.17 (LPR for NTT variant
                              of ISUP).
             ---      rrb  2. Changed code in siMfEncStr to set the extension
                              bit for a token having TF_PEXT flag defined.
             ---      rrb  3. Converted siMfLen into public variable.
             ---      ym   1. NT compilation warnings are removed.
/main/7      ---      bsp  1. Fixed bugs found in 64 bit compilation
           si003.218  sk   1. Removed redundant code from siDecU8Enum to
                              pass "no default" as token type
             ---      hy   1. Added the codes to support 3 kind of message
                              format errors checking. e.g. functions
                              siMfInitForMsg and siChkMsgFor are added.
                      bsp  1. Changed code to handle new tokens required by
                              ITU 97, ANSI 95 and ETSI v3 variants
                           2. Added SI_ALLOW_PRSNT_INVALID related changes.
                      hy   3. Removed the #if 1 or #if 0 tags in the file.
                           4. Fixed a bug in siMfInitForMsg function.
                      bsp  5. Added code to handle repeated parameters.
                      hy   6. Fixed a bug in siMfInitTkn function that the
                              present field is passed correctly.
                      bsp  7. Fixes for decoding U8 token and handle skipping
                              of tokens returned from escape functions
             /main/8                 bsp  1. Made changes to skip tokens as indicated by escape
                              functions 
                      hy   1. Correction of variable name from word to
                              word1 in function siMfDecBits
                      hy   1. Modified the code to check the swtch flag when 
                              determining the optional parameter pointer in
                              function siMfEncSS7Elmts.
                           2. Modified the code to handle the skip token
                              flag MFSKIP1TKNSCPY by returning from the 
                              escape function in siMfEncTkns and siMfEncU8
           si009.220  hy   1. Modified function siMfDecTkns and siMfDecU8Enum,
                              to handle the cause default value base on
                              the cause class.
           si010.220 tz    1. Replacing siMfSkipTkns and fpAdd with macro ADDFARPTR. 
                           2. Deleted siMfSkipTkns function definition.
           si012.220 km    1. Added code to siMfEncU8Enum to make sure that if the 
                              extension bit of the cause value indicator is 1, no
                              dianostic values follow, and vice versa when the 
                              extension bit is 0
          si013.220  km    1. Fixed syntax error with patch si012.220
          si017.220  tz    1. Modified DecSS7Elmts such that it decodes
                              correctly when a message may contain optional
                              parameters, but actually does not have any.
          si020.220  tz    1. Added code in siMfEncSS7Elmts to correct an encoding
                              problem in case of siMfEncTkns failure.
          si021.220  tz    1. Move variable delaration to before C statement.
          si027.220  tz    1. Added code to update the error indices during
                              encoding MET_FIXED_PTR type elements.
          si031.220  tz    1. Added code to drop MET_VARIABLE type parameter
                              if the parameter length is not valid.
          si032.220  tz    1. Added code to take care of skip token 11 and 16.
          si043.220  rk    1. In case there is only single opt parameter
                              and it is dropped, set start of opt param
                              to zero
          si048.220  ng    1. Added handling of single optional parameter with EF_NA
*********************************************************************91*/
