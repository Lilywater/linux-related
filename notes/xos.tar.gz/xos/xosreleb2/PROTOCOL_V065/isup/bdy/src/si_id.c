/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     isup - id
  
     Type:     C source file
  
     Desc:     Structure for software part number, version and
               revision.

     File:     si_id.c
  
     Sid:      si_id.c@@/main/26 - Wed Jul 25 13:20:21 2001

     Prg:      bn
  
*********************************************************************21*/
  
  
/* header include files (.h) */

#include "envopt.h"           /* environment options */  
#include "envdep.h"           /* environment dependent */
#include "envind.h"           /* environment independent */

#include "gen.h"              /* general layer */
#include "ssi.h"              /* system services */
   
/* header/extern include files (.x) */

#include "gen.x"              /* general layer */
#include "ssi.x"              /* system services */

/* defines */

#define SISWMV 2             /* isup - main version */
#define SISWMR 20            /* isup - main revision */
#define SISWBV 0             /* isup - branch version */
/* si055.220 - incremented the branch number */
#define SISWBR 55            /* isup - branch revision */
#define SISWPN "1000029"     /* isup - part number */

/* public variable declarations */

#ifdef __cplusplus
extern "C" {
#endif

EXTERN S16 siGetSId ARGS((SystemId *s));

#ifdef __cplusplus
}
#endif
  
/* copyright banner */
  
PUBLIC CONSTANT Txt siBan1[] ={"(c) COPYRIGHT 1989-1998, Trillium Digital Systems, Inc."};
PUBLIC CONSTANT Txt siBan2[] ={"                 All rights reserved."};
  
/* system id */
  
PRIVATE CONSTANT SystemId sId ={
   SISWMV,              /* isup - main version */
   SISWMR,              /* isup - main revision */
   SISWBV,              /* isup - branch version */
   SISWBR,              /* isup - branch revision */
   SISWPN               /* isup - part number */
};

  
/*
*     support functions
*/

   
/*
*
*       Fun:   get system id
*
*       Desc:  Get system id consisting of part number, main version and
*              revision and branch version and branch.
*
*       Ret:   TRUE      - ok
*
*       Notes: None
*
*       File:  si_id.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siGetSId
(
SystemId *s                 /* system id */
)
#else
PUBLIC S16 siGetSId(s)
SystemId *s;                /* system id */
#endif
{
   TRC2(siGetSId)
   s->mVer = sId.mVer;
   s->mRev = sId.mRev;
   s->bVer = sId.bVer;
   s->bRev = sId.bRev;
   s->ptNmb = sId.ptNmb;
   RETVALUE(TRUE);
} /* end of siGetSid */

  
/********************************************************************30**
  
         End of file:     si_id.c@@/main/26 - Wed Jul 25 13:20:21 2001

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  jrl   1. initial release
             ---  jrl   2. trillium development system checkpoint (dvs)
                           at version: 1.0.0.0

1.2          ---  bn    1. change version

1.3          ---  bn    1. change version

1.4          ---  jrl   1. change version

1.5          ---  jrl   1. change version
 
1.6          ---  bn    1. change version
 
1.7          ---  bn    1. change version
             ---  bn    2. change return( to RETVALUE(

1.8          ---  bn    1. change version
             ---  bn    2. replace ss_pt.? and ss_ms.? with ssi.?.
             ---  bn    3. remove lm_pt.h include file
             ---  bn    4. change ban1 and ban2 to PUBLIC.
             ---  bn    5. rename ban1 and ban2 to siBan1 and siBan2.

1.9          ---  bn    1. miscellaneous changes
             ---  bn    2. change version

1.10         ---  bn    1. change version

1.11         ---  bn    1. change version

1.12         ---  bn    1. change version

1.13         ---  bn    1. change version

1.14         ---  aa    1. change version

1.15         ---  bn    1. change version

1.16         ---  bn    1. change version

1.17         ---  dm    1. change version

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.18         ---      bn   1. change version
 
1.19         ---      rh   1. textual changes
1.20         ---      rs   1. Removed compilation warnings.
1.21         ---      ym   1. Release number is updated to 2.17.
1.23         ---      dvs  1. miscellaneous changes
1.24         ---      ym   1. The release main revision number is bumped
                              to 18.
/main/25     ---      hy   1. The release main revision number is updated
                              to 19.
/main/26     ---      bsp  1. The release main revision number is updated
                              to 20.
          si001.220   hy   1. Incremented the branch number.
          si002.220   mm   2. Incremented the branch number.
          si003.220   mm   1. Incremented the branch number.
          si004.220   mm   1. Incremented the branch number.
          si005.220   mm   1. Incremented the branch number.
          si006.220   hy   1. Incremented the branch number.
          si007.220   mm   1. Incremented the branch number.
          si008.220   mm   1. Incremented the branch number.
          si009.220   hy   1. Increased the branch number.
          si010.220   tz   1. Increased the branch number.
          si011.220   km   1. Increased the branch number.
          si012.220   km   1. Increased the branch number.
          si013.220   km   1. Increased the branch number.
          si014.220   km   1. Increased the branch number.
          si015.220   sg   1. Increased the branch number.
          si016.220   tz   1. Increased the branch number.
          si017.220   tz   1. Increased the branch number.
          si018.220   tz   1. Increased the branch number.
          si019.220   tz   1. Increased the branch number.
          si020.220   tz   1. Increased the branch number.
          si021.220   tz   1. Increased the branch number.
          si022.220   tz   1. Increased the branch number.
          si023.220   tz   1. Increased the branch number.
          si024.220   tz   1. Increased the branch number.
          si025.220   tz   1. Increased the branch number.
          si026.220   tz   1. Increased the branch number.
          si027.220   tz   1. Increased the branch number.
          si028.220   tz   1. Increased the branch number.
          si029.220   tz   1. Increased the branch number.
          si030.220   tz   1. Increased the branch number.
          si031.220   tz   1. Increased the branch number.
          si032.220   tz   1. Increased the branch number.
          si033.220   rk   1. Increased the branch number.
          si034.220   rk   1. Increased the branch number.
          si035.220   rk   1. Increased the branch number.
          si036.220   rk   1. Increased the branch number.
          si037.220   rk   1. Increased the branch number.
          si038.220   rk   1. Increased the branch number.
          si039.220   rk   1. Increased the branch number.
          si040.220   rk   1. Increased the branch number.
          si040.220   rk   1. Increased the branch number.
          si041.220   rk   1. Increased the branch number.
          si042.220   bn   1. Increased the branch number.
          si043.220   rk   1. Increased the branch number.
          si044.220   rk   1. Increased the branch number.
          si045.220   ng   1. Increased the branch number.
          si046.220   ng   1. Increased the branch number.
          si047.220   ng   1. Increased the branch number.
          si048.220   ng   1. Increased the branch number.
          si049.220   ng   1. Increased the branch number.
          si050.220   ng   1. Increased the branch number.
          si051.220   rk   1. Increased the branch number.
          si052.220   rk   1. Increased the branch number.
          si053.220   vp   1. Increased the branch number.
          si054.220   vp   1. Increased the branch number.
          si055.220   vp   1. Increased the branch number.
*********************************************************************91*/

