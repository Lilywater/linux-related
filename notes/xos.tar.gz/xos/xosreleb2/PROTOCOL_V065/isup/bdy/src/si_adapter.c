#ifdef LCSILISNT_XOS
#include "xosshell.h"
#endif

#ifdef LCSIUISIT_XOS

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* hash-list header */
#include "cm5.h"           /* common - hashing */
#include "cm_ss7.h"        /* common - SS7 */
#include "sit.h"           /* isup layer */
#include "lsi.h"           /* layer manager */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* hash-list structure */
#include "cm5.x"           /* common - hashing */
#include "cm_ss7.x"        /* common - SS7 */
#include "lsi.x"           /* layer manager */
#include "sit.x"           /* isup layer */

#include "si_adapter.h"


extern PUBLIC U8 *cmMemset
(
U8           *str,
U8           val,
PTR          len
);

U32 g_isupUaModId = 0;

extern void XosToFrameCallBack(U32 mid, Pst *pPst, void * pvBuf);

U32 siSendMsg2UA(Pst *pPst, SiEventHdr *pEventHdr, Buffer *mBuf)
{

     Si2UaMsg  si2UaMsg;
     SMemCpy((void *)(&si2UaMsg.siEventHdr), (void *)pEventHdr, sizeof(SiEventHdr));
     // ��Ϣ�ṹָ��
     si2UaMsg.mBuf = mBuf;

     XosToFrameCallBack(g_isupUaModId, pPst, &si2UaMsg);
    
     RETVALUE(ROK);
}




PUBLIC S16 aPkSitBndCfm 
(
Pst *pst,
SuId suId,
U8   status
)
{
   SiEventHdr evnthdr;
   cmMemset((U8 *)&evnthdr, 0x00, sizeof(SiEventHdr));

   TRC2(aPkSitBndCfm)

   evnthdr.event = EVTSITBNDCFM;
   evnthdr.subEvent = status;
   evnthdr.suId  = suId;

   (void)siSendMsg2UA(pst, &evnthdr, NULL);

   RETVALUE(ROK);
}/* aPkSitBndCfm */

PUBLIC S16 aPkSitConInd 
(
Pst       *pst,
SuId      suId,
SiInstId  suInstId,
SiInstId  spInstId,
CirId     circuit,
SiConEvnt *siConEvnt,
Buffer    *uBuf
)
{
   Buffer *mBuf;
   SiEventHdr evnthdr;
   cmMemset((U8 *)&evnthdr, 0x00, sizeof(SiEventHdr));

   TRC2(aPkSitConInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkConEvnt(siConEvnt, mBuf, pst, EVTGTIAM) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }


   FILL_EVENT_HEADER(evnthdr, suId, suInstId, spInstId, circuit, EVTSITCONIND, 0);
     
   (void)siSendMsg2UA(pst, &evnthdr, mBuf);
   
   RETVALUE(ROK);
}/* aPkSitConInd */




PUBLIC S16 aPkSitConCfm 
(
Pst       *pst,
SuId      suId,
SiInstId  suInstId,
SiInstId  spInstId,
CirId     circuit,
SiConEvnt *siConEvnt,
Buffer    *uBuf
)
{
   Buffer *mBuf;
   SiEventHdr evnthdr;

   cmMemset((U8 *)&evnthdr, 0x00, sizeof(SiEventHdr));

   TRC2(cmPkSitConCfm)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkConEvnt(siConEvnt, mBuf, pst, EVTGTANM) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   FILL_EVENT_HEADER(evnthdr, suId, suInstId, spInstId, circuit, EVTSITCONCFM, 0);
   (void)siSendMsg2UA(pst, &evnthdr, mBuf);

   RETVALUE(ROK);
}/* cmPkSitConCfm */


PUBLIC S16 aPkSitCnStInd 
(
Pst        *pst,
SuId       suId,
SiInstId   suInstId,
SiInstId   spInstId,
CirId      circuit,
SiCnStEvnt *siCnStEvnt,
U8         evntType,
Buffer     *uBuf
)
{
   Buffer *mBuf;
   SiEventHdr evnthdr;
   cmMemset((U8 *)&evnthdr, 0x00, sizeof(SiEventHdr));

   TRC2(cmPkSitCnStInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   
   if (siPkCnStEvnt(siCnStEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   FILL_EVENT_HEADER(evnthdr, suId, suInstId, spInstId, circuit, EVTSITCNSTIND, evntType);
   (void)siSendMsg2UA(pst, &evnthdr, mBuf);


   RETVALUE(ROK);
}/* cmPkSitCnStInd */


PUBLIC S16 aPkSitStaInd 
(
Pst       *pst, 
SuId      suId, 
SiInstId  suInstId, 
SiInstId  spInstId, 
CirId     circuit, 
Bool      globalFlag, 
U8        eventType, 
SiStaEvnt *siStaEvnt,
Buffer    *uBuf
)
{
   Buffer *mBuf;
   Bool   evtprcs;
   SiEventHdr evnthdr;
   cmMemset((U8 *)&evnthdr, 0x00, sizeof(SiEventHdr));

   TRC2(cmPkSitStaInd)

   UNUSED(globalFlag);

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
   {
      mBuf = uBuf;
   }

   evtprcs = FALSE;
   if (siStaEvnt != NULLP)
   {
      evtprcs = TRUE;
      if (siPkStaEvnt(siStaEvnt, mBuf, pst) != ROK)
      {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
         RETVALUE(RFAILED);
      }
   }

   FILL_EVENT_HEADER(evnthdr, suId, suInstId, spInstId, circuit, EVTSITSTAIND, eventType);

   if(TRUE == evtprcs)
   {
       (void)siSendMsg2UA(pst, &evnthdr, mBuf);
   }
   else
   {
       (void)siSendMsg2UA(pst, &evnthdr, NULL);
       SPutMsg(mBuf);
   }

   RETVALUE(ROK);
}





PUBLIC S16 aPkSitRelInd 
(
Pst       *pst, 
SuId      suId, 
SiInstId  suInstId, 
SiInstId  spInstId, 
CirId     circuit,
SiRelEvnt *siRelEvnt,
Buffer    *uBuf
)
{
   Buffer *mBuf;
   SiEventHdr evnthdr;
   cmMemset((U8 *)&evnthdr, 0x00, sizeof(SiEventHdr));

   TRC2(cmPkSitRelInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
   {
      mBuf = uBuf;
   }

   if (siPkRelEvnt(siRelEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   } 

   FILL_EVENT_HEADER(evnthdr, suId, suInstId, spInstId, circuit, EVTSITRELIND, 0);
   (void)siSendMsg2UA(pst, &evnthdr, mBuf);


   RETVALUE(ROK);
}/* aPkSitRelInd */


PUBLIC S16 aPkSitRelCfm 
(
Pst       *pst, 
SuId      suId, 
SiInstId  suInstId, 
SiInstId  spInstId, 
CirId     circuit,
SiRelEvnt *siRelEvnt,
Buffer    *uBuf
)
{
   Buffer *mBuf;
   SiEventHdr evnthdr;
   cmMemset((U8 *)&evnthdr, 0x00, sizeof(SiEventHdr));

   TRC2(cmPkSitRelCfm)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
   {
      mBuf = uBuf;
   }

   if (siPkRelEvnt(siRelEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   } 

   FILL_EVENT_HEADER(evnthdr, suId, suInstId, spInstId, circuit, EVTSITRELCFM, 0);
   (void)siSendMsg2UA(pst, &evnthdr, mBuf);

   
   RETVALUE(ROK);
}/* cmPkSitRelCfm */


PUBLIC S16 aPkSitDatInd 
(
Pst        *pst, 
SuId       suId, 
SiInstId   suInstId,
SiInstId   spInstId, 
CirId      circuit,
SiInfoEvnt *siInfoEvnt,
Buffer     *uBuf
)
{
   Buffer *mBuf;
   SiEventHdr evnthdr;
   cmMemset((U8 *)&evnthdr, 0x00, sizeof(SiEventHdr));

   TRC2(cmPkSitDatInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkInfoEvnt(siInfoEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }


   FILL_EVENT_HEADER(evnthdr, suId, suInstId, spInstId, circuit, EVTSITDATIND, 0);
   (void)siSendMsg2UA(pst, &evnthdr, mBuf);

   RETVALUE(ROK);
}/* aPkSitDatInd */


PUBLIC S16 aPkSitFacCfm 
(
Pst       *pst, 
SuId      suId, 
SiInstId  suInstId, 
SiInstId  spInstId, 
CirId     circuit,
U8        evntType,
SiFacEvnt *siFacEvnt,
Buffer    *uBuf
)
{
   Buffer *mBuf;
   SiEventHdr evnthdr;
   cmMemset((U8 *)&evnthdr, 0x00, sizeof(SiEventHdr));

   TRC2(aPkSitFacCfm)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkFacEvnt(siFacEvnt, mBuf, pst, EVTGTMLTP) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }


   FILL_EVENT_HEADER(evnthdr, suId, suInstId, spInstId, circuit, EVTSITFACCFM, 0);
   (void)siSendMsg2UA(pst, &evnthdr, mBuf);

   RETVALUE(ROK);
}/* cmPkSitFacCfm */


PUBLIC S16 aPkSitFacInd 
(
Pst       *pst, 
SuId      suId, 
SiInstId  suInstId, 
SiInstId  spInstId, 
CirId     circuit,
U8        evntType,
SiFacEvnt *siFacEvnt,
Buffer    *uBuf
)
{
   Buffer *mBuf;
   SiEventHdr evnthdr;
   cmMemset((U8 *)&evnthdr, 0x00, sizeof(SiEventHdr));

   TRC2(aPkSitFacInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkFacEvnt(siFacEvnt, mBuf, pst, EVTGTFRQ) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(ROK);
   }


   FILL_EVENT_HEADER(evnthdr, suId, suInstId, spInstId, circuit, EVTSITFACIND, 0);
   (void)siSendMsg2UA(pst, &evnthdr, mBuf);

   RETVALUE(ROK);
}/* aPkSitFacInd */



PUBLIC S16 aPkSitResmInd 
(
Pst        *pst, 
SuId       suId, 
SiInstId   suInstId, 
SiInstId   spInstId, 
CirId      circuit,
SiResmEvnt *siResmEvnt,
Buffer     *uBuf
)
{
   Buffer *mBuf;
   SiEventHdr evnthdr;
   cmMemset((U8 *)&evnthdr, 0x00, sizeof(SiEventHdr));

   TRC2(aPkSitResmInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkResmEvnt(siResmEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   } 

   FILL_EVENT_HEADER(evnthdr, suId, suInstId, spInstId, circuit, EVTSITRESMIND, 0);
   (void)siSendMsg2UA(pst, &evnthdr, mBuf);


   RETVALUE(ROK);
}/* aPkSitResmInd */


PUBLIC S16 aPkSitSuspInd 
(
Pst        *pst, 
SuId       suId, 
SiInstId   suInstId, 
SiInstId   spInstId, 
CirId      circuit,
SiSuspEvnt *siSuspEvnt,
Buffer     *uBuf
)
{
   Buffer *mBuf;
   SiEventHdr evnthdr;
   cmMemset((U8 *)&evnthdr, 0x00, sizeof(SiEventHdr));


   TRC2(aPkSitSuspInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkSuspEvnt(siSuspEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   } 


   FILL_EVENT_HEADER(evnthdr, suId, suInstId, spInstId, circuit, EVTSITSUSPIND, 0);
   (void)siSendMsg2UA(pst, &evnthdr, mBuf);


   RETVALUE(ROK);
}/* aPkSitSuspInd */


PUBLIC S16 aPkSitUMsgInd 
(
Pst     *pst,               /* post structure */
SuId     suId,              /* service provider id */
SiInstId suInstId,          /* service user instance id */
SiInstId spInstId,          /* service provider instance id */
CirId    circuit,           /* circuit ID code */
Buffer   *uBuf              /* message with unrecognizable parameters */
)
{
   Buffer *mBuf;
   SiEventHdr evnthdr;
   cmMemset((U8 *)&evnthdr, 0x00, sizeof(SiEventHdr));

   TRC2(aPkSitUMsgInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;


   FILL_EVENT_HEADER(evnthdr, suId, suInstId, spInstId, circuit, EVTSITUMSGIND, 0);
   (void)siSendMsg2UA(pst, &evnthdr, mBuf);

   RETVALUE(ROK);
}/* aPkSitUMsgInd */


PUBLIC S16 aPkSitPtCdeStaCfm 
(
Pst  *pst,
SuId suId,
SiInstId intfId,
U8   status,
U8   congLevel
)
{
   Buffer *mBuf;
   SiEventHdr evnthdr;
   cmMemset((U8 *)&evnthdr, 0x00, sizeof(SiEventHdr));

   TRC2(cmPkSitPtCdeStaCfm)


   evnthdr.event = EVTSITPTCDESTACFM;
   evnthdr.subEvent = status;
   evnthdr.suId  = suId;
   evnthdr.cirId = intfId;
   evnthdr.spInstId = congLevel;

   (void)siSendMsg2UA(pst, &evnthdr, mBuf);

   RETVALUE(ROK);
}/* cmPkSitPtCdeStaCfm */


#endif //LCSIUISIT_XOS



#ifdef LCSILISNT_XOS


PUBLIC S16 aPkSntUDatReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Dpc opc,                        /* originating pont code */
Dpc dpc,                        /* destination point code */
SrvInfo sInfo,                  /* service information */
LnkSel sls,                     /* signalling link selector */
Priority prior,                 /* priority */
Buffer *mBuf                    /* message buffer */
)
{
   S16 msgLen,len;
   S16 ret;
   t_XOSCOMMHEAD *pXosMsg;
   isup2ATT *pAttMsg;

   ret = SFndLenMsg(mBuf, &msgLen);

   if (ret != ROK || msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
      RETVALUE(ROK);
   }

   //msgLen += 2*sizeof(Dpc);

   pXosMsg = XOS_MsgMemMalloc(80, (msgLen+2*sizeof(Dpc)));
   if(NULL==pXosMsg)
   {
       RETVALUE(RFAILED);
   }

   pXosMsg->datadest.FID = 80;
   pXosMsg->datadest.PID = XNULL;

   pXosMsg->datasrc.FID  = 65;
   pXosMsg->datasrc.PID  = XNULL;

   pAttMsg= (isup2ATT  *)pXosMsg;
   pAttMsg->opc = opc;
   pAttMsg->dpc = dpc;

   SCpyMsgFix(mBuf, 0, msgLen, pAttMsg->buf, &len);

   if(XSUCC != XOS_MsgSend(pXosMsg))
   {
       XOS_MsgMemFree(80, pXosMsg);
       RETVALUE(RFAILED);
   }          
   
   RETVALUE(ROK);
}  /* end of cmPkSntUDatReq */



#endif //LCSILISNT_XOS


