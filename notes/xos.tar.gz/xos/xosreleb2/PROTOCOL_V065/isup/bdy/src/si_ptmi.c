/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     ISUP - portable upper interface     
  
     Type:     C source file     
  
     Desc:     C source code for the ISUP stack manager interface primitives.
     
 
     File:     si_ptmi.c

     Sid:      si_ptmi.c@@/main/18 - Wed Mar 14 15:31:51 2001
  
     Prg:      bn
  
*********************************************************************21*/
  

/*
  
Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.
 
The following functions are provided in this file:

     SiMiLsiStaInd      Status Indication
     SiMiLsiStaCfm      Status Confirm
     SiMiLsiStsCfm      Statistics Confirm
     SiMiLsiAcntCfm     Accounting Indication
     SiMiLsiTrcInd      Trace Indication
 
It is assumed that the following functions are provided in the
layer managment service user file:
  
     SiMiLsiCfgReq      Configure Request
     SiMiLsiStaReq      Status Request
     SiMiLsiStsReq      Statistics Request
     SiMiLsiCntrlReq    Control Request
 
*/
  

/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000028     SS7 - Stack manager
*
*/
 

/* header include files (.h) */
#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* general SS7 layer */
#include "cm_hash.h"       /* hash-list header */
#include "lsi.h"           /* layer management */
#include "si_mf.h"         /* message functions */
#include "cm5.h"           /* timers */
#include "ci_db.h"         /* ISUP data base */
#include "sit.h"           /* ISUP */
#include "snt.h"           /* MTP3 */
#ifdef SI_SPT
#include "spt.h"           /* SCCP */
#endif
#ifdef SI_FTHA
#include "sht.h"           /* FTHA */
#endif
#include "si.h"            /* ISUP */
#include "si_err.h"        /* ISUP error */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* general SS7 layer */
#include "cm_lib.x"        /* common library functions */
#include "cm_hash.x"       /* hash-list structure */
#include "lsi.x"           /* layer management */
#include "si_mf.x"            /* message functions */
#include "cm5.x"           /* timers */
#include "ci_db.x"         /* ISUP data base */
#include "sit.x"           /* ISUP */
#include "snt.x"           /* MTP3 */
#ifdef SI_SPT
#include "spt.x"           /* SCCP */
#endif
#ifdef SI_FTHA
#include "sht.x"           /* FTHA */
#endif
#include "si.x"            /* ISUP */

  


/* local defines */
  
/* local typedefs */
  
/* local externs */
  
/* forward references */
 
PRIVATE S16 PtMiLsiStaInd ARGS((Pst *pst, SiMngmt *sta));
PRIVATE S16 PtMiLsiStaCfm ARGS((Pst *pst, SiMngmt *sta));
PRIVATE S16 PtMiLsiStsCfm ARGS((Pst *pst, Action action, SiMngmt *sts));
#if SI_ACNT
PRIVATE S16 PtMiLsiAcntInd ARGS((Pst *pst, SiMngmt *acnt));
#endif
PRIVATE S16 PtMiLsiTrcInd ARGS((Pst *pst, SiMngmt *trc));
#if (SI_LMINT3 || SMSI_LMINT3)
PRIVATE S16 PtMiLsiCfgCfm   ARGS((Pst *pst, SiMngmt *cfg));
PRIVATE S16 PtMiLsiCntrlCfm ARGS((Pst *pst, SiMngmt *cntrl));
#endif

#ifdef SI_FTHA
PRIVATE S16 PtMiShtCntrlCfm ARGS((Pst *pst, ShtCntrlCfmEvnt *cfmInfo)); 
#endif
 
/* functions in other modules */
  
/* public variable declarations */
  
/* private variable declarations */
 

/*

the following matrices define the mapping between the primitives
called by the layer management interface of ISUP and the corresponding
primitives of the ISUP service user(s).
 
The parameter MAXSIMI defines the maximum number of service users on
top of ISUP. There is an array of functions per primitive
invoked by ISUP. Every array is MAXSIMI long (i.e. there
are as many functions as the number of service users).
 
The dispatching is performed by the configurable variable: selector.
The selector is configured during general configuration.
 
The selectors are:
 
   0 - loosely coupled - new interface, forawrd cabability (#define LCSIMILSI)
   1 - loosely coupled - old interface, backward cabability (#define LCSIMILSI)
       no longer supported
   2 - Lsi (#define SM)
 
*/
 

/* Status Indication primitive */
 
PRIVATE LsiStaInd SiMiLsiStaIndMt[MAXSIMI] =
{
#ifdef LCSIMILSI
   cmPkLsiStaInd,          /* 0 - loosely coupled - fc */
#else
   PtMiLsiStaInd,          /* 0 - loosely coupled, portable */
#endif
   PtMiLsiStaInd,          /* 1 - loosely coupled, portable */
#ifdef SM
   SmMiLsiStaInd,          /* 2 - tightly coupled, layer management */
#else
   PtMiLsiStaInd,          /* 2 - tightly coupled, portable */
#endif
};

/* Status confirm primitive */
 
PRIVATE LsiStaCfm SiMiLsiStaCfmMt[MAXSIMI] =
{
#ifdef LCSIMILSI
   cmPkLsiStaCfm,          /* 0 - loosely coupled - fc */
#else
   PtMiLsiStaCfm,          /* 0 - loosely coupled, portable */
#endif
   PtMiLsiStaCfm,          /* 1 - loosely coupled, portable */
#ifdef SM
   SmMiLsiStaCfm,          /* 2 - tightly coupled, layer management */
#else
   PtMiLsiStaCfm,          /* 2 - tightly coupled, portable */
#endif
};

/* Statistic Confirm primitive */
 
PRIVATE LsiStsCfm SiMiLsiStsCfmMt[MAXSIMI] =
{
#ifdef LCSIMILSI
   cmPkLsiStsCfm,          /* 0 - loosely coupled - fc */
#else
   PtMiLsiStsCfm,          /* 0 - loosely coupled, portable */
#endif
   PtMiLsiStsCfm,          /* 1 - loosely coupled, portable */
#ifdef SM
   SmMiLsiStsCfm,          /* 2 - tightly coupled, layer management */
#else
   PtMiLsiStsCfm,          /* 2 - tightly coupled, portable */
#endif
};


#if SI_ACNT
/* Accounting Indication primitive */
 
PRIVATE LsiAcntInd SiMiLsiAcntIndMt[MAXSIMI] =
{
#ifdef LCSIMILSI
   cmPkLsiAcntInd,          /* 0 - loosely coupled - fc */
#else
   PtMiLsiAcntInd,          /* 0 - loosely coupled, portable */
#endif
   PtMiLsiAcntInd,          /* 1 - loosely coupled, portable */
#ifdef SM
   SmMiLsiAcntInd,          /* 2 - tightly coupled, layer management */
#else
   PtMiLsiAcntInd,          /* 2 - tightly coupled, portable */
#endif
};
#endif


/* Trace Indication primitive */
 
PRIVATE LsiTrcInd SiMiLsiTrcIndMt[MAXSIMI] =
{
#ifdef LCSIMILSI
   cmPkLsiTrcInd,          /* 0 - loosely coupled - fc */
#else
   PtMiLsiTrcInd,          /* 0 - loosely coupled, portable */
#endif
   PtMiLsiTrcInd,          /* 1 - loosely coupled, portable */
#ifdef SM
   SmMiLsiTrcInd,          /* 2 - tightly coupled, layer management */
#else
   PtMiLsiTrcInd,          /* 2 - tightly coupled, portable */
#endif
};

#if (SI_LMINT3 || SMSI_LMINT3)

/* Configuration Confirm primitive */

PRIVATE LsiCfgCfm SiMiLsiCfgCfmMt[MAXSIMI] =
{
#ifdef LCSIMILSI
   cmPkLsiCfgCfm,          /* 0 - loosely coupled - fc              */
#else
   PtMiLsiCfgCfm,          /* 0 - loosely coupled, portable         */
#endif
   PtMiLsiCfgCfm,          /* 1 - loosely coupled, portable         */
#ifdef SM
   SmMiLsiCfgCfm,          /* 2 - tightly coupled, layer management */
#else
   PtMiLsiCfgCfm,          /* 2 - tightly coupled, portable         */
#endif
};

/* Control Confirm primitive */

PRIVATE LsiCntrlCfm SiMiLsiCntrlCfmMt[MAXSIMI] =
{
#ifdef LCSIMILSI
   cmPkLsiCntrlCfm,        /* 0 - loosely coupled - fc              */
#else
   PtMiLsiCntrlCfm,        /* 0 - loosely coupled, portable         */
#endif
   PtMiLsiCntrlCfm,        /* 1 - loosely coupled, portable         */
#ifdef SM
   SmMiLsiCntrlCfm,        /* 2 - tightly coupled, layer management */
#else
   PtMiLsiCntrlCfm,        /* 2 - tightly coupled, portable         */
#endif
};

#endif

#ifdef SI_FTHA
    /* System agent control Confirm primitive */
PRIVATE ShtCntrlCfm SiMiShtCntrlCfmMt[MAXSIMI] =
{
   cmPkMiShtCntrlCfm,       /* 0 - loosely coupled - fc        */
   PtMiShtCntrlCfm,         /* 1 - loosely coupled , portable  */
#ifdef SH
   ShMiShtCntrlCfm,         /* 2 - tightly coupled system agent */
#else
   PtMiShtCntrlCfm,         /* 2 - tightly coupled, portable*/
#endif
};
#endif /* FTHA */



/*
*     support functions
*/


/*
*     layer management interface functions 
*/
 
/*
*
*       Fun:   Status Indication
*
*       Desc:  This function is used to indicate the status of ISUP
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SiMiLsiStaInd
(
Pst *pst,                 /* post structure */
SiMngmt *sta              /* unsolicited status */
)
#else
PUBLIC S16 SiMiLsiStaInd(pst, sta)
Pst *pst;                 /* post structure */   
SiMngmt *sta;             /* unsolicited status */
#endif
{
   TRC3(SiMiLsiStaInd)
   SIDBGP(DBGMASK_MI,(siCb.init.prntBuf,"StaInd : LM <- L4      \n"));  

   /* jump to siecific primitive depending on configured selector */
   (*SiMiLsiStaIndMt[pst->selector])(pst, sta); 
   RETVALUE(ROK);
} /* end of SiMiLsiStaInd */
 

/*
*
*       Fun:   Status Confirm
*
*       Desc:  This function is used to return the status of ISUP
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SiMiLsiStaCfm
(
Pst *pst,                 /* post structure */     
SiMngmt *sta              /* solicited status */
)
#else
PUBLIC S16 SiMiLsiStaCfm(pst, sta)
Pst *pst;                 /* post structure */     
SiMngmt *sta;             /* solicited status */
#endif
{
   TRC3(SiMiLsiStaCfm)
   SIDBGP(DBGMASK_MI,(siCb.init.prntBuf,"StaCfm : LM <- L4      \n"));  

   /* jump to siecific primitive depending on configured selector */
   (*SiMiLsiStaCfmMt[pst->selector])(pst, sta); 
   RETVALUE(ROK);
} /* end of SiMiLsiStaCfm */
 

/*
*
*       Fun:   Statistics Confirm
*
*       Desc:  This function is used to return the statistics of MTP
*              level 3 to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SiMiLsiStsCfm
(
Pst *pst,                 /* post structure */    
Action action,            /* action */
SiMngmt *sts              /* statistics */
)
#else
PUBLIC S16 SiMiLsiStsCfm(pst, action, sts)
Pst *pst;                 /* post structure */    
Action action;            /* action */
SiMngmt *sts;             /* statistics */
#endif
{
   TRC3(SiMiLsiStsCfm)
   SIDBGP(DBGMASK_MI,(siCb.init.prntBuf,"StsCfm : LM <- L4      \n"));  

   /* jump to siecific primitive depending on configured selector */
   (*SiMiLsiStsCfmMt[pst->selector])(pst, action, sts); 
   RETVALUE(ROK);
} /* end of SiMiLsiStsCfm */
 

#if SI_ACNT
/*
*
*       Fun:   Accounting Indication
*
*       Desc:  This function is used to indicate the accounting information
*              of ISUP to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SiMiLsiAcntInd
(
Pst *pst,                 /* post structure */
SiMngmt *acnt             /* accounting */
)
#else
PUBLIC S16 SiMiLsiAcntInd(pst, acnt)
Pst *pst;                 /* post structure */   
SiMngmt *acnt;            /* accounting */
#endif
{
   TRC3(SiMiLsiAcntInd)
   SIDBGP(DBGMASK_MI,(siCb.init.prntBuf,"AcntInd : LM <- L4      \n"));  

   /* jump to siecific primitive depending on configured selector */
   (*SiMiLsiAcntIndMt[pst->selector])(pst, acnt); 
   RETVALUE(ROK);
} /* end of SiMiLsiAcntInd */
#endif
 

/*
*
*       Fun:   Trace Indication
*
*       Desc:  This function is used to indicate the trace of ISUP
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SiMiLsiTrcInd
(
Pst *pst,                 /* post structure */
SiMngmt *trc              /* trace */
)
#else
PUBLIC S16 SiMiLsiTrcInd(pst, trc)
Pst *pst;                 /* post structure */   
SiMngmt *trc;             /* trace */
#endif
{
   TRC3(SiMiLsiTrcInd)
   SIDBGP(DBGMASK_MI,(siCb.init.prntBuf,"TrcInd : LM <- L4      \n"));  

   /* jump to siecific primitive depending on configured selector */
   (*SiMiLsiTrcIndMt[pst->selector])(pst, trc); 
   RETVALUE(ROK);
} /* end of SiMiLsiTrcInd */

#if (SI_LMINT3 || SMSI_LMINT3)


/*
*
*       Fun:   SiMiLsiCfgCfm
*
*       Desc:  Configuration confirmation primitive for LMINT3
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  si_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 SiMiLsiCfgCfm
(
Pst     *pst,
SiMngmt *cfm
)
#else
PUBLIC S16 SiMiLsiCfgCfm (pst, cfm)
Pst     *pst;
SiMngmt *cfm;
#endif
{
   TRC3(SiMiLsiCfgCfm)
   /* jump to siecific primitive depending on configured selector */
   (*SiMiLsiCfgCfmMt[pst->selector])(pst, cfm); 
   RETVALUE(ROK);
} /* SiMiLsiCfgCfm */


/*
*
*       Fun:   SiMiLsiCntrlCfm
*
*       Desc:  Control confirmation primitive for LMINT3
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  si_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 SiMiLsiCntrlCfm
( 
Pst     *pst,
SiMngmt *cfm
)
#else
PUBLIC S16 SiMiLsiCntrlCfm (pst, cfm)
Pst     *pst;
SiMngmt *cfm;
#endif
{
   TRC3(SiMiLsiCntrlCfm)
   /* jump to siecific primitive depending on configured selector */
   (*SiMiLsiCntrlCfmMt[pst->selector])(pst, cfm); 
   RETVALUE(ROK);
} /* SiMiLsiCntrlCfm */

#endif /* SI_LMINT3 */

/**************************************************************************** 
 *     layer management interface portable functions
 ****************************************************************************/


/*
*
*       Fun:   portable - Status Indication
*
*       Desc:  This function is used to indicate the status of ISUP
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptmi.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtMiLsiStaInd
(
Pst *pst,                 /* post structure */
SiMngmt *sta              /* unsolicited status */
)
#else
PRIVATE S16 PtMiLsiStaInd(pst, sta)
Pst *pst;                 /* post structure */
SiMngmt *sta;             /* unsolicited status */
#endif
{
   TRC3(PtMiLsiStaInd)
   UNUSED(pst);
   UNUSED(sta);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
            "PtMiLsiStaInd called. To be ported\n"));  

#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1694, (ErrVal) 0, "PtMiLsiStaInd() called");
#endif
   RETVALUE(ROK);
} /* end of PtMiLsiStaInd */
 
/*
*
*       Fun:   portable - Status Confirm
*
*       Desc:  This function is used to return the status of ISUP
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLsiStaCfm
(
Pst *pst,                 /* post structure */     
SiMngmt *sta              /* solicited status */
)
#else
PRIVATE S16 PtMiLsiStaCfm(pst, sta)
Pst *pst;                 /* post structure */     
SiMngmt *sta;             /* solicited status */
#endif
{
   TRC3(PtMiLsiStaCfm)
   UNUSED(pst);
   UNUSED(sta);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
            "PtMiLsiStaCfm called. To be ported\n"));  

#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1695, (ErrVal) 0, "PtMiLsiStaCfm() called");
#endif
   RETVALUE(ROK);
} /* end of PtMiLsiStaCfm */
 
/*
*
*       Fun:   portable - Statistics Confirm
*
*       Desc:  This function is used to return the statistics of MTP
*              level 3 to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLsiStsCfm
(
Pst *pst,                 /* post structure */    
Action action,            /* action */
SiMngmt *sts              /* statistics */
)
#else
PRIVATE S16 PtMiLsiStsCfm(pst, action, sts)
Pst *pst;                 /* post structure */    
Action action;            /* action */
SiMngmt *sts;             /* statistics */
#endif
{
   TRC3(PtMiLsiStsCfm)
   UNUSED(pst);
   UNUSED(action);
   UNUSED(sts);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
            "PtMiLsiStsCfm called. To be ported\n"));  

#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1696, (ErrVal) 0, "PtMiLsiStsCfm() called");
#endif
   RETVALUE(ROK);
} /* end of PtMiLsiStsCfm */
 


#if SI_ACNT
/*
*
*       Fun:   portable - Accounting Indication
*
*       Desc:  This function is used to indicate the accounting information
*              of ISUP to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptmi.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtMiLsiAcntInd
(
Pst *pst,                 /* post structure */
SiMngmt *acnt             /* accounting */
)
#else
PRIVATE S16 PtMiLsiAcntInd(pst, acnt)
Pst *pst;                 /* post structure */
SiMngmt *acnt;            /* accounting */
#endif
{
   TRC3(PtMiLsiAcntInd)
   UNUSED(pst);
   UNUSED(acnt);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
            "PtMiLsiAcntInd called. To be ported\n"));  

#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1697, (ErrVal) 0, "PtMiLsiAcntInd() called");
#endif
   RETVALUE(ROK);
} /* end of PtMiLsiAcntInd */
#endif


/*
*
*       Fun:   portable - Trace Indication
*
*       Desc:  This function is used to indicate the trace of ISUP
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptmi.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtMiLsiTrcInd
(
Pst *pst,                 /* post structure */
SiMngmt *trc              /* trace */
)
#else
PRIVATE S16 PtMiLsiTrcInd(pst, trc)
Pst *pst;                 /* post structure */
SiMngmt *trc;             /* trace */
#endif
{
   TRC3(PtMiLsiTrcInd)
   UNUSED(pst);
   UNUSED(trc);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
            "PtMiLsiTrcInd called. To be ported\n"));  

#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1698, (ErrVal) 0, "PtMiLsiTrcInd() called");
#endif
   RETVALUE(ROK);
} /* end of PtMiLsiTrcInd */

#if (SI_LMINT3 || SMSI_LMINT3)


/*
*
*       Fun:   PtMiLsiCfgCfm
*
*       Desc:  portable - configuration confirm. This function is used to 
*              indicate the status configuration request when the LMINT3
*              mgmt interface is used
*              
*       Ret:   ROK - ok;
*
*       Notes: none
*
*       File:  si_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 PtMiLsiCfgCfm
(
Pst     *pst,
SiMngmt *cfm
)
#else
PUBLIC S16 PtMiLsiCfgCfm (pst, cfm)
Pst     *pst;
SiMngmt *cfm;
#endif
{
   TRC3(PtMiLsiCfgCfm)
   UNUSED(pst);
   UNUSED(cfm);

#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1699, (ErrVal) 0, "PtMiLsiCfgCfm() called");
#endif
   RETVALUE(ROK);
}


/*
*
*       Fun:   PtMiLsiCntrlCfm
*
*       Desc:  portable - control confirm. This function is used to 
*              indicate the status configuration request when the LMINT3
*              mgmt interface is used
*              
*       Ret:   ROK - ok;
*
*       Notes: none
*
*       File:  si_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 PtMiLsiCntrlCfm
(
Pst     *pst,
SiMngmt *cfm
)
#else
PUBLIC S16 PtMiLsiCntrlCfm (pst, cfm)
Pst     *pst;
SiMngmt *cfm;
#endif
{
   TRC3(PtMiLsiCntrlCfm)
   UNUSED(pst);
   UNUSED(cfm);

#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1700, (ErrVal) 0, "PtMiLsiCntrlCfm() called");
#endif
   RETVALUE(ROK);
}

#endif /* SI_LMINT3 */


#ifdef SI_FTHA
/*
*
*       Fun:   System agent control Confirm
*
*       Desc:  This function is used to send the system agent control confirm
*              primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  xx_ptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 SiMiShtCntrlCfm
(
Pst *pst,                /* post structure */
ShtCntrlCfmEvnt *cfmInfo     /* system agent control confirm event */
)
#else
PUBLIC S16 SiMiShtCntrlCfm(pst, cfmInfo)
Pst *pst;                /* post structure */
ShtCntrlCfmEvnt *cfmInfo;    /* system agent control confirm event */
#endif
{
   TRC3(SiMiShtCntrlCfm)

   /* jump to specific primitive depending on configured selector */
   (*SiMiShtCntrlCfmMt[pst->selector])(pst, cfmInfo);

   RETVALUE(ROK);
} /* end of SiShShtCntrlCfm */


/*
*
*       Fun:   portable - Control Confirm
*
*       Desc:  This function is used to return the control confirm
*              to system agent
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptmi.c
*
*/

#ifdef ANSI
PRIVATE S16 PtMiShtCntrlCfm
(
Pst *pst,                 /* post structure */
ShtCntrlCfmEvnt *cfmInfo     /* system agent control confirm event */
)
#else
PRIVATE S16 PtMiShtCntrlCfm(pst, cfmInfo)
Pst *pst;                 /* post structure */
ShtCntrlCfmEvnt *cfmInfo;     /* system agent control confirm event */
#endif
{
   TRC3(PtMiShtCntrlCfm)
   UNUSED(pst);
   UNUSED(cfmInfo);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
            "PtMiShtCntrlCfm called. To be ported\n"));

#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1701, (ErrVal) 0, "PtMiShtCntrlCfm() called");
#endif
   RETVALUE(ROK);
} /* end of PtMiShtCntrlCfm */

#endif /* FTHA */



  
/********************************************************************30**
  
         End of file:     si_ptmi.c@@/main/18 - Wed Mar 14 15:31:51 2001
  
*********************************************************************31*/
  
  
/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/
  
  
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------

  
*********************************************************************71*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  bn    1. initial release.

1.2          ---  bn    1. change defines

1.3          ---  bn    1. added loopback ack transmitted and received 
                           counter to sap statistics structure.
1.4          ---  bn    1. added transmit and receive counters for the 
                           new messages in packing of the statistic
                           structures.
1.5          ---  bn    1. added conTx and conRx to statistic structure
                           for Italian Q767.

1.6          ---  lc    1. miscellaneous changes

1.7          ---  bn    1. changed siPkMiLsiStaInd and siPkMiLsiTrcInd

1.8          ---  bn    1. removed unused variable in siPkMiLsiStaInd.

1.9          ---  bn    1. Moved to SLogError for error logging
             ---  bn    2. added macros for calling packing functions.

1.10         ---  pc    1. added loop prevention msg to statistics 
                           structure for ETSI variant

1.11         ---  dm    1. added support GT_FTZ variant
             ---  dm    2. added include cm_ss7.x
             ---  dm    3. removes SEL_LC_OLD

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.12         ---      dm   1. corrected use of forward/backward compatibility
                              for loosely coupled interface.
 
1.13         ---      fl   1. fixed typo.
1.14         ---      rs   1. moved accounting procedures under SI_ACNT
             ---      rh   1. removed cm_gen.x dependency
1.15         ---      rs   1. Added confirmation primitives from ISUP to LM.

1.16         ---      ym   1. File header is updated to the new one. 
                           2. Error codes are updated.
1.17         ---      dvs  1. miscellaneous changes
/main/18     ---      sk   1. Addition of packing system agent control cfm 
                      hy   2. correct an error in definition of 
                              PtMiShtCntrlCfm if ANSI is disable.
*********************************************************************91*/

