/**********************************************************************

        Name:   si_debug.c - Debug print for the ISUP

        Type:   C source file

        Desc:   C code for the ISUP layer debug print

        File:   si_debug.c

        Sid:    si_debug.c - 2006/05/12

        Created by:     xiaoruo

**********************************************************************/
/* header include files : .h) */
#ifdef SSI_WITH_CLI_ENABLED


#include "clishell.h"
#include "xosshell.h"

#include "envopt.h"        /* environment options  */ 
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* general SS7 layer */
#include "cm_hash.h"       /* hash-list header */
#include "lsi.h"           /* layer management */
#include "si_mf.h"         /* message functions */
#include "cm5.h"           /* timers */
#include "ci_db.h"         /* ISUP data base */
#include "sit.h"           /* ISUP */
#include "snt.h"           /* MTP3 */
#ifdef SI_SPT
#include "spt.h"           /* SCCP */
#endif
#include "si.h"            /* ISUP */
#include "si_err.h"        /* ISUP error */
#ifdef IW
#include "cm_atm.h"          /* common ATM defines                 */
#include "cm_cc.h"           /* Common Call Control Hash Defs      */
#include "rmt.h"             /* resource manager defines           */
#include "cct.h"             /* Call Control Interface Header      */
#include "liw.h"             /* ISUP PSIF Layer Management Headers */
#include "iw.h"              /* ISUP PSIF Hash Defines             */
#include "iw_err.h"          /* ISUP PSIF Error Defines            */
#include "iw_ptli.h"         /* o/g SIT i/f funcs. hash defs       */
#endif

#ifdef ZI
#include "cm_pftha.h"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.h"       /* common PSF */
#include "cm_psfft.h"      /* common PSF */
#endif
#include "lzi.h"           /* ISUP PSF management */
#include "zi.h"            /* ISUP PSF */
#include "zi_err.h"        /* ISUP PSF error codes */
#endif /* ZI */

#ifdef SI_FTHA
#include "sht.h"           /* common ftha sh defines */
#endif
/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* general SS7 layer */
#include "cm_lib.x"        /* common library functions */
#include "cm_hash.x"       /* hash-list structure */
#include "lsi.x"           /* layer management */
#include "si_mf.x"            /* message functions */
#include "cm5.x"           /* timers */
#include "ci_db.x"         /* ISUP data base */
#include "sit.x"           /* ISUP */
#include "snt.x"           /* MTP3 */
#ifdef SI_SPT
#include "spt.x"           /* SCCP */
#endif
#ifdef SI_FTHA
#include "sht.x"           /* common ftha sh structure */
#endif
#include "si.x"            /* ISUP */

#ifdef IW
#include "cm_atm.x"          /* common ATM defines                  */
#include "cm_cc.x"           /* Common Call Control Typedefs        */
#include "rmt.x"             /* resource manager function decls.    */
#include "cct.x"             /* Call Control Interface              */
#include "liw.x"             /* ISUP PSIF Layer Management typedefs */
#include "iw.x"              /* ISUP PSIF Typedefs                  */
#endif
#ifdef ZI 
#include "cm_pftha.x"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.x"       /* common PSF */
#include "cm_psfft.x"      /* common PSF */
#endif
#include "lzi.x"           /* ISUP PSF management */
#include "zi.x"            /* ISUP PSF */
#endif /* ZI */

#ifdef DEBUGP
#include "mf.x"    
#endif 

#define SI_DBG_ERR_NULLP                     "��ָ��Ϊ��ָ��!!!����λ��%s �ļ���%d ��\r\n"

#ifdef STR_TST
#include "si_cfg.h"
#include "oam_public_data_def.h"
#include "str.h"
#include "cc.h"
#include "Benchmark.h"          /*�����ʱͷ�ļ�*/
#include "si_oam.x"
#include "cp_tab_def.h"

extern void StrStartTest();
extern void StrResetTest();
#define  BENCHMARK_MAX_COUNT 20
DateTime gBenchmark_Start[BENCHMARK_MAX_COUNT];	
DateTime gBenchmark_End[BENCHMARK_MAX_COUNT];	
DateTime gBenchmark_Counter[BENCHMARK_MAX_COUNT];
extern void BMTimerEnd(U16 cmdNum);
extern void BMTimerStart(U16 cmdNum);
extern void InitializeBenchMark();
//extern TestSetPar sTstSetPar;
#endif

#define SYS_ATOL(str)                       (atol((const char *)str))   //10����

S8 *callState[5]={"TRANS","COTCHK","INCBUSY","OUTBUSY","IDLE"};
#define GET_CALL_STA(state)  callState[(state)>2 ? (((state) >>2)+1):(state)]


S8 *transState[11] = 
{"UNEQPD", "IDLE","WTBLKACK","LOCBLKED",\
 "WTUBLACK","WTRESACK","WTBLKRSP", "REMBLKED",\
 "WTUBLRSP","WTRESRSP","INVALID"
};
#define GET_TRANS_STA(state)  transState[(state)==0xFF ? 10:(state)]



S8 *IntfState[6]={"AVAIL","UNAVAIL","CONG1","CONG2","CONG3","UNEQUIP"};
#define GET_INTF_STA(state)  IntfState[state]
S8 *TrunkType[2]={"E1","T1"};
#define Get_TRUNK_TYPE(state)  TrunkType[state?0:1]

S8 *boolval[2]={"TRUE","FALSE"};
#define GET_BOOL_STR(state)  boolval[state?0:1]

S8 *pauseActn[4]={"UNKNOWN","CLRDFLT","CLRTRAN","CLRTMOUT"};
#define GET_PAUSE_ACTION(atcn) pauseActn[atcn]

S8 *dbgMask[2]={"ON","OFF"};
#define GET_DBG_STATE(mask) dbgMask[(siCb.init.dbgMask & (mask))?0:1]

S8 *lnkSelOpt[3]={"Base CIC","Loadshare","Invalid"};
#define GET_LKSEL_OPT(opt)  lnkSelOpt[opt>1?2:opt]

S8 *sapState[4]={"UNBND","BND","WTBNDCFM","Invalid"};
#define GET_SAP_STA(state)  sapState[state<=2?state:3]

S8 *nSapType[5]={"MTP3","SCCP","RM","M3UA","Unknown"};
#define GET_NSAP_TYPE(type)  nSapType[type<4 ? type:4]




/* local defines */
#ifdef DEBUGP
#define DEBUG_ALL            0  /*����DBG��Ĳ���*/

#define DEBUG_MI             1  /* layer management interface */
#define DEBUG_UI             2  /* upper interface */
#define DEBUG_LI             3  /* lower interface */


#define SIDBG_PROG           7  /* progress of handling an Event */
#define SIDBG_WARN           8  /* warning , not critical for an event */
#define SIDBG_CERR           9  /* Event specific err*/
#define SIDBG_ERR            10  /* Global error */
#define SIDBG_TMR            11 /* Timer related */
#define SIDBG_STATE          12 /* state transition */
#define SIDBG_MF             13 /* mf related prog/warn/error */

#define SIDBG_MSGERR       14  /* error messages */
#define SIDBG_MSGSEG       15  /* message buffer in case of segmentation */
#define SIDBG_MSGTX        16  /* tx msg */
#define SIDBG_MSGRX        17  /* rx Msg */

/*0 ��ʾ�ر�DBG��Ϣ, 1 ��ʾ��DBG��Ϣ */
#define SI_OPEN_DEBUG        1
#define SI_SHUT_DEBUG        0  



#endif /*DEBUGP*/



/************************************************************/
/*****  Functions: Print all the status of ISUP layer  ******/
/************************************************************/



PUBLIC void siPrintSiCb(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    int i = 0;
    int nNum = 0;
    SpId  sapId; 
    SiUpSAPCb *cb = NULLP;
    SiNSAPCb *nCb = NULLP;
    SiIntfCb* psiIntfCb = NULLP;
    
    
    if (1 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������,�������Ҫ����");
        return;
    }
    
    /**	��ʼ����Ϣ*/
    XOS_CliExtPrintf(pCliEnv, "[ISUP]TskInit: \r\n");
    
    XOS_CliExtPrintf(pCliEnv, "entity             : %d \r\n", siCb.init.ent);
    XOS_CliExtPrintf(pCliEnv, "Instance           : %d \r\n",siCb.init.inst);
    XOS_CliExtPrintf(pCliEnv, "Region             : %d \r\n",siCb.init.region);
    XOS_CliExtPrintf(pCliEnv, "Pool               : %d \r\n",siCb.init.pool);
    XOS_CliExtPrintf(pCliEnv, "reason             : %d \r\n",siCb.init.reason);
    XOS_CliExtPrintf(pCliEnv, "Config done        : %s \r\n",GET_BOOL_STR(siCb.init.cfgDone));
    XOS_CliExtPrintf(pCliEnv, "Accounting         : %s \r\n",GET_BOOL_STR(siCb.init.acnt));
    XOS_CliExtPrintf(pCliEnv, "unsolicited status : %s \r\n",GET_BOOL_STR(siCb.init.usta));
    XOS_CliExtPrintf(pCliEnv, "trace              : %s \r\n",GET_BOOL_STR(siCb.init.trc));
    
    
    XOS_CliExtPrintf(pCliEnv, "--------General config--------\r\n");
    XOS_CliExtPrintf(pCliEnv, "MAX UpSap          : %d \r\n", siCb.genCfg.nmbSaps);
    XOS_CliExtPrintf(pCliEnv, "MAX NSap           : %d \r\n", siCb.genCfg.nmbNSaps); 
    XOS_CliExtPrintf(pCliEnv, "MAX circuit        : %d \r\n", siCb.genCfg.nmbCir); 
    XOS_CliExtPrintf(pCliEnv, "MAX interface      : %d \r\n", siCb.genCfg.nmbIntf);
    XOS_CliExtPrintf(pCliEnv, "MAX cirGrp         : %d \r\n", siCb.genCfg.nmbCirGrp);
    XOS_CliExtPrintf(pCliEnv, "MAX call           : %d \r\n", siCb.genCfg.nmbCalRef);
    XOS_CliExtPrintf(pCliEnv, "Time resolution    : %d (100MS)\r\n", siCb.genCfg.timeRes);

    /**	ͨ������*/
#if (LSIV3 || LSIV4)
    XOS_CliExtPrintf(pCliEnv, "Link select option : %s  \r\n", GET_LKSEL_OPT(siCb.genCfg.lnkSelOpt)); 
#endif
    
    XOS_CliExtPrintf(pCliEnv, "--------Run time info--------\r\n");
    XOS_CliExtPrintf(pCliEnv, "Last used spInstId : %d \r\n", siCb.lastSpInstId); 
    XOS_CliExtPrintf(pCliEnv, "Config cir number  : %d \r\n", siCb.cirCnt);
    XOS_CliExtPrintf(pCliEnv, "Config intf number : %d \r\n", siCb.intfCnt);
    
    /****  UpSap     ******/
    nNum = 0;
    for(sapId = 0; sapId < siCb.genCfg.nmbSaps; sapId++)
    {
        cb = SIUPSAP(sapId);

        if(cb)
        {
            nNum++;
        }
    }

    XOS_CliExtPrintf(pCliEnv, "config UpSap number: %d \r\n", nNum);
    
    
    
    /******* NSap ******/
    nNum = 0;
    for(sapId = 0; sapId < siCb.genCfg.nmbNSaps; sapId++)
    {
        nCb = SIMTPSAP(sapId);
        
        if(nCb != NULLP)
        {
            nNum++;
        }
    }
    
    XOS_CliExtPrintf(pCliEnv, "config NSap number : %d \r\n", nNum);
    
    return;
    
}



PUBLIC void siPrintUpSap(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    U8  sapId; 
    U8  nNum = 0;
    SiUpSAPCb *cb;
    
    XOS_CliExtPrintf(pCliEnv, "SapId   SuId   Switch   Ssf   AutoInfoReq   Location   State \r\n");
    XOS_CliExtPrintf(pCliEnv, "-------------------------------------------------------------\r\n");
    for(sapId = 0; sapId < siCb.genCfg.nmbSaps; sapId++)
    {
        cb = SIUPSAP(sapId);
        
        if(cb != NULLP)
        {
            XOS_CliExtPrintf(pCliEnv, "%-5d   %-4d   %-6d   %-3d   %-10d   %-8d   %-5s \r\n",
                                      cb->spId,
                                      cb->suId,
                                      cb->cfg.swtch,
                                      cb->cfg.ssf,
                                      cb->cfg.reqOpt,
                                      cb->cfg.relLocation,
                                      GET_SAP_STA(cb->state));
            nNum++;
        }
    }
    XOS_CliExtPrintf(pCliEnv, "-------------------------------------------------------------\r\n");
    XOS_CliExtPrintf(pCliEnv, "total: %d \r\n",nNum);
    
    
    return;   
    
}





PUBLIC void siPrintNSap(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    U8  sapId;
    U8  nNum = 0;
    SiNSAPCb *nCb;
    

    
    XOS_CliExtPrintf(pCliEnv, "SapId   SpId   NwId   Ssf   SapType   State \r\n");
    XOS_CliExtPrintf(pCliEnv, "--------------------------------------------\r\n");
	for(sapId = 0; sapId < siCb.genCfg.nmbNSaps; sapId++)
	{
	    nCb = SIMTPSAP(sapId);
	    
	    if(nCb != NULLP)
	    {
	        XOS_CliExtPrintf(pCliEnv, "%-5d   %-4d   %-4d   %-3d   %-7s   %-5s \r\n", 
	                                  nCb->suId, nCb->spId, 
	                                  nCb->cfg.nwId,nCb->cfg.ssf,
	                                  GET_NSAP_TYPE(nCb->cfg.sapType),
	                                  GET_SAP_STA(nCb->state));
	        nNum++;
	    }
	}
    XOS_CliExtPrintf(pCliEnv, "---------------------------------------------\r\n");
    XOS_CliExtPrintf(pCliEnv, "total: %d \r\n",nNum);
    
    return;   
}




PUBLIC void siPrintIntf(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    SiInstId intfId=0;
    
    SiIntfCb* psiIntfCb = NULLP;

    SiIntfCbCfg    *pIntfCfg;
    
    
    if (siArgc >=2)
    {
        intfId = (SiInstId)SYS_ATOL(ppArgv[1]);
    }
    
    if( 0 ==intfId )
    {
         U32 cnt=0;
         XOS_CliExtPrintf(pCliEnv,"\n\r IntfId   NwId   SapId   OPC      DPC      Switch     Ssf     State");
         XOS_CliExtPrintf(pCliEnv,"\n\r ------------------------------------------------------------------");
         psiIntfCb = (SiIntfCb*)NULLP;
         while(cmHashListGetNext(&siCb.intfHlCp.k3Cp, (PTR) psiIntfCb,
                   (PTR *) &psiIntfCb) == ROK)
         {

              pIntfCfg = &psiIntfCb->cfg;
              XOS_CliExtPrintf(pCliEnv,"\n\r %-6d   %-4d   %-5d   0x%-5x   0x%-5x   %-6d   %-3d    %-s", 
                                        pIntfCfg->intfId,pIntfCfg->nwId,
                                        pIntfCfg->sapId,pIntfCfg->opc,pIntfCfg->phyDpc,
                                        pIntfCfg->swtch,pIntfCfg->ssf,
                                        GET_INTF_STA(psiIntfCb->state));


              cnt++;
         }

         XOS_CliExtPrintf(pCliEnv,"\n\r ------------------------------------------------------------------");
         XOS_CliExtPrintf(pCliEnv,"\n\r Total:%d", cnt);


         return;


    }

    // ��ӡָ���Ľӿ���Ϣ
    
    if ( siFindIntf(&psiIntfCb, intfId, 0, 0, 0, 0, SIINTF_KEY_1) == RFAILED )
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n Interface not exist [IntfId:%d]", intfId);
    }
    else
    {
        /*������Ϣ*/
        XOS_CliExtPrintf(pCliEnv, "\r\n config:");
        XOS_CliExtPrintf(pCliEnv, "\r\n -----------------");
        XOS_CliExtPrintf(pCliEnv, "\r\n IntfId   : %d ", psiIntfCb->cfg.intfId);
        XOS_CliExtPrintf(pCliEnv, "\r\n NwId     : %d ", psiIntfCb->cfg.nwId);
        XOS_CliExtPrintf(pCliEnv, "\r\n SapId    : %d ", psiIntfCb->cfg.sapId);
        XOS_CliExtPrintf(pCliEnv, "\r\n OPC      : %d ", psiIntfCb->cfg.opc);
        XOS_CliExtPrintf(pCliEnv, "\r\n DPC      : %d ", psiIntfCb->cfg.phyDpc);
        XOS_CliExtPrintf(pCliEnv, "\r\n Switch   : %d ", psiIntfCb->cfg.swtch);
        XOS_CliExtPrintf(pCliEnv, "\r\n Ssf      : %d ", psiIntfCb->cfg.ssf);
        XOS_CliExtPrintf(pCliEnv, "\r\n PauseActn: %d (%s)", psiIntfCb->cfg.pauseActn,GET_PAUSE_ACTION(psiIntfCb->cfg.pauseActn));
        
#if (SS7_ANS95 || SS7_ITU97 || SS7_ETSIV3)
        XOS_CliExtPrintf(pCliEnv, "\r\n TrunkType: %s ",Get_TRUNK_TYPE(psiIntfCb->cfg.trunkType));
#endif        
        XOS_CliExtPrintf(pCliEnv, "\r\n -----------------"); 
        XOS_CliExtPrintf(pCliEnv, "\r\n Status:");
        XOS_CliExtPrintf(pCliEnv, "\r\n -----------------"); 

        XOS_CliExtPrintf(pCliEnv, "\r\n msapId   : %d ", psiIntfCb->msapId);
        XOS_CliExtPrintf(pCliEnv, "\r\n t4Runing : %s ", GET_BOOL_STR(psiIntfCb->t4Runing));
        XOS_CliExtPrintf(pCliEnv, "\r\n State    : %s ", GET_INTF_STA(psiIntfCb->state));
        XOS_CliExtPrintf(pCliEnv, "\r\n lnkSelCnt: %d ", psiIntfCb->lnkSel);

    }

 
    return;   
}

PUBLIC void siShowOneCirCfg(CLI_ENV* pCliEnv, SiCirCb* pCirCb, Bool horizontal)
{

     if(horizontal)
     {

	    XOS_CliExtPrintf(pCliEnv, "\r\n  %-5d   %-3d   %-6d   %-8d   %-7d", 
	                               pCirCb->cfg.cirId,
	                               pCirCb->cfg.cic,
	                               pCirCb->cfg.intfId,
	                               pCirCb->cfg.typeCntrl,
	                               pCirCb->cfg.contReq);
     }
     else
     {


           XOS_CliExtPrintf(pCliEnv, "\r\n CirId   :%d ", pCirCb->cfg.cirId);
           XOS_CliExtPrintf(pCliEnv, "\r\n Cic     :%d ", pCirCb->cfg.cic);
           XOS_CliExtPrintf(pCliEnv, "\r\n IntfId  :%d ", pCirCb->cfg.intfId);
           XOS_CliExtPrintf(pCliEnv, "\r\n CtrlType:%d ", pCirCb->cfg.typeCntrl);
           XOS_CliExtPrintf(pCliEnv, "\r\n ContReq :%d ", pCirCb->cfg.contReq);


     }
     return;


}



PUBLIC void siShowOneCirState(CLI_ENV* pCliEnv, SiCirCb* pCirCb, Bool horizontal)
{

    
     // ˮƽ��ӡ
     if(horizontal)
     {

	       XOS_CliExtPrintf(pCliEnv, "\r\n  %-5d     %-5d   %-6d   %-7s   %-9s   %-8s   %-9s   %-8s", 
	                               pCirCb->cfg.cirId,
	                               pCirCb->cfg.cic,
	                               pCirCb->cfg.intfId,
	                               GET_CALL_STA(pCirCb->calProcStat),
	                               GET_TRANS_STA(pCirCb->transStat[LOCMTEVT]),
	                               GET_TRANS_STA(pCirCb->transStat[LOCHWEVT]),
	                               GET_TRANS_STA(pCirCb->transStat[REMMTEVT]),
	                               GET_TRANS_STA(pCirCb->transStat[REMHWEVT]) );
     }
     else
     {
           XOS_CliExtPrintf(pCliEnv, "\r\n CirId      :%d ", pCirCb->cfg.cirId);
           XOS_CliExtPrintf(pCliEnv, "\r\n Cic        :%d ", pCirCb->cfg.cic);
           XOS_CliExtPrintf(pCliEnv, "\r\n IntfId     :%d ", pCirCb->cfg.intfId);
           XOS_CliExtPrintf(pCliEnv, "\r\n CallState  :%s ", GET_CALL_STA(pCirCb->calProcStat));
           XOS_CliExtPrintf(pCliEnv, "\r\n LocMntState:%s ", GET_TRANS_STA(pCirCb->transStat[LOCMTEVT]));
           XOS_CliExtPrintf(pCliEnv, "\r\n LocHwState :%s ", GET_TRANS_STA(pCirCb->transStat[LOCHWEVT]));
           XOS_CliExtPrintf(pCliEnv, "\r\n RemMntState:%s ", GET_TRANS_STA(pCirCb->transStat[REMMTEVT]));
           XOS_CliExtPrintf(pCliEnv, "\r\n RemHwState :%s ", GET_TRANS_STA(pCirCb->transStat[REMHWEVT]));

     }

     return;

}


PUBLIC void siPrintCirCfg(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    
    CirId cirId=0;
    SiInstId  intfId=0;
    U8  type=0;
    SiCirKey  key;
    U16 idx;
    SiIntfCb* psiIntfCb = NULLP;
    SiCirCb* pCirCb = NULLP;
    
   
    if(1 == siArgc)
    {
         U32 cnt=0;
         XOS_CliExtPrintf(pCliEnv,"\r\n CirId   Cic   IntfId   CtrlType   ContReq");
         XOS_CliExtPrintf(pCliEnv,"\r\n -----------------------------------------");
         pCirCb = (SiCirCb*)NULLP;
         while(cmHashListGetNext(&siCb.cirHlCp.chCp, (PTR) pCirCb,
                   (PTR *)&pCirCb) == ROK)
         {

              siShowOneCirCfg(pCliEnv, pCirCb, TRUE);
              cnt++;
         }

         XOS_CliExtPrintf(pCliEnv,"\r\n -----------------------------------------");
         XOS_CliExtPrintf(pCliEnv,"\r\n Total:%d", cnt);


         return;
    }

    if (3 != siArgc)
    {
         XOS_CliExtPrintf(pCliEnv,"\r\n  Para error");
    }

    type= (U8)SYS_ATOL(ppArgv[1]);

    if(1==type)
    {
        
        
        intfId = (SiInstId)SYS_ATOL(ppArgv[2]);
		if ( siFindIntf(&psiIntfCb, intfId, 0, 0, 0, 0, SIINTF_KEY_1) == RFAILED )
		{
			XOS_CliExtPrintf(pCliEnv, "\r\n Interface not exist [IntfId: %d]", intfId);
			return;
		}

        
        XOS_CliExtPrintf(pCliEnv,"\r\n CirId   Cic   IntfId   CtrlType   ContReq");
        XOS_CliExtPrintf(pCliEnv,"\r\n -----------------------------------------");    
    
	    key.k3.intfId = intfId;
	    for (idx = 0; ; idx++)
	    {
            pCirCb =(SiCirCb*)NULLP;
	        if( ROK == siFindCir(&siCb.cirHlCp, &pCirCb, &key, idx, KEY_INTF) &&
	           pCirCb != (SiCirCb*)NULLP)
	        {

                siShowOneCirCfg(pCliEnv, pCirCb, TRUE);
	        }     
	        else
	        {
	            break;
	        }
	    }
	    XOS_CliExtPrintf(pCliEnv,"\n\r -----------------------------------------");
        XOS_CliExtPrintf(pCliEnv,"\n\r Total:%d", idx);
    }

    //��ʾĳһָ���ĵ�·
    if( 2==type)
    {
        cirId = (CirId)SYS_ATOL(ppArgv[2]);
        
	    key.k1.cirId = cirId;
	    siFindCir(&siCb.cirHlCp, &pCirCb, &key, 0, KEY_CIR);
	    
	    if( NULLP == pCirCb)
	    {
	        XOS_CliExtPrintf(pCliEnv, "\r\n Circuit not exist [cirId: %d]", cirId);
	        return;		
	    }
	    
	      
	    siShowOneCirCfg(pCliEnv, pCirCb, FALSE);
	}
  
    return;   
}


PUBLIC void siPrintCirState(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    
    CirId cirId=0;
    U8  type=0;
    SiInstId  intfId=0;
    SiCirKey  key;
    U16 idx;
    SiIntfCb* psiIntfCb = NULLP;
    SiCirCb* pCirCb = NULLP;
    
        
    if(1 == siArgc)
    {
         U32 cnt=0;
         XOS_CliExtPrintf(pCliEnv,"\n\r CirId     Cic   IntfId   CallSta   LocMntSta   LocHwSta   RemMntSta   RemHwSta");
         XOS_CliExtPrintf(pCliEnv,"\n\r ------------------------------------------------------------------------------");
         pCirCb = (SiCirCb*)NULLP;
         while(cmHashListGetNext(&siCb.cirHlCp.chCp, (PTR) pCirCb, (PTR *)&pCirCb) == ROK)
         {

              siShowOneCirState(pCliEnv, pCirCb, TRUE);
              cnt++;
         }

         XOS_CliExtPrintf(pCliEnv,"\n\r ------------------------------------------------------------------------------");
         XOS_CliExtPrintf(pCliEnv,"\n\r Total:%d", cnt);


         return;
    }


    if (3 != siArgc)
    {
         XOS_CliExtPrintf(pCliEnv,"\n\r  Para error");
    }

    type= (U8)SYS_ATOL(ppArgv[1]);

    if(1==type)
    {
        
        
        intfId = (SiInstId)SYS_ATOL(ppArgv[2]);
		if ( siFindIntf(&psiIntfCb, intfId, 0, 0, 0, 0, SIINTF_KEY_1) == RFAILED )
		{
			XOS_CliExtPrintf(pCliEnv, "\r\n Interface not exist [IntfId: %d]", intfId);
			return;
		}

        
        XOS_CliExtPrintf(pCliEnv,"\n\r CirId     Cic   IntfId   CallSta   LocMntSta   LocHwSta   RemMntSta   RemHwSta");
        XOS_CliExtPrintf(pCliEnv,"\n\r ------------------------------------------------------------------------------");
    
	    key.k3.intfId = intfId;
	    for (idx = 0; ; idx++)
	    {
            pCirCb =(SiCirCb*)NULLP;
	        if( ROK == siFindCir(&siCb.cirHlCp, &pCirCb, &key, idx, KEY_INTF) &&
	           pCirCb != (SiCirCb*)NULLP)
	        {

                siShowOneCirState(pCliEnv, pCirCb, TRUE);
	        }     
	        else
	        {
	            break;
	        }
	    }
	    XOS_CliExtPrintf(pCliEnv,"\n\r ------------------------------------------------------------------------------");
        XOS_CliExtPrintf(pCliEnv,"\n\r Total:%d", idx);
    }

    //��ʾĳһָ���ĵ�·
    if( 2==type)
    {
        cirId = (CirId)SYS_ATOL(ppArgv[2]);
        
	    key.k1.cirId = cirId;
	    siFindCir(&siCb.cirHlCp, &pCirCb, &key, 0, KEY_CIR);
	    
	    if( NULLP == pCirCb)
	    {
	        XOS_CliExtPrintf(pCliEnv, "\r\n Circuit not exist [cirId: %d]", cirId);
	        return;		
	    }
	    
	      
	    siShowOneCirState(pCliEnv, pCirCb, FALSE);
	}
	
  
    return;   
}

#if 0
PUBLIC void siPrintIntfidCic(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{

    SiInstId intfId;
    
    Cic cic;
    SiCirKey  key;
    
    SiCirCb* cir;
    
    if (3 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������");
        return;
    }
    
    intfId = (SiInstId)SYS_ATOL(ppArgv[1]);
    cic = (Cic)SYS_ATOL(ppArgv[2]);
    
    cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));    
    key.k2.cic = cic;
    key.k2.intfId = intfId;
    
    siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);

    if( NULLP == cir)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\nû�������ĵ�·��,intfId: %d, cic: %d", intfId, cic);
        return;		
    }
    
    XOS_CliExtPrintf(pCliEnv, "\r\nintfId: %d, cic: %d\r\n", intfId, cic);
    
    XOS_CliExtPrintf(pCliEnv, "cirId: %d, intfId: %d, cirCtl: %d, opc: %d, Dpc: %d\r\n ", cir->key.k1.cirId,  cir->cirCtl, cir->opc, cir->phyDpc);
    
    
    XOS_CliExtPrintf(pCliEnv, "��·״̬: calProcStat: %d, MntLocalStat: %d,  HWLocalStat: %d, MntRemoteStat: %d,  HWRemoteStat: %d,\r\n ", 
        cir->calProcStat, cir->transStat[SICIR_MTLOCST],cir->transStat[LOCHWEVT], cir->transStat[REMMTEVT], cir->transStat[REMHWEVT]);

    return;   
}

#endif

#if (SI_LMINT3 || SMSI_LMINT3)

PUBLIC void siPrintErrSts(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    
    /*����ͳ����Ϣ*/
    XOS_CliExtPrintf(pCliEnv, "Error statistics  \r\n");
    XOS_CliExtPrintf(pCliEnv, "------------------\r\n");
    
    XOS_CliExtPrintf(pCliEnv, "abnrmlAckCgba: %d \r\n", siCb.sts.abnrmlAckCgba);
    XOS_CliExtPrintf(pCliEnv, "abnrmlAckCgua: %d \r\n", siCb.sts.abnrmlAckCgua);
    XOS_CliExtPrintf(pCliEnv, "abnrmlRel    : %d \r\n", siCb.sts.abnrmlRel);
    XOS_CliExtPrintf(pCliEnv, "blkReq       : %d \r\n", siCb.sts.blkReq);
    XOS_CliExtPrintf(pCliEnv, "noAckCgba    : %d \r\n", siCb.sts.noAckCgba);
    XOS_CliExtPrintf(pCliEnv, "noAckCgua    : %d \r\n", siCb.sts.noAckCgua);
#if (SS7_ANS95 || SS7_ITU97 || SS7_ETSIV3)
    XOS_CliExtPrintf(pCliEnv, "numNonCont   : %d \r\n", siCb.sts.numNonCont);
#endif    
    XOS_CliExtPrintf(pCliEnv, "pduFmtErr    : %d \r\n", siCb.sts.pduFmtErr);
    XOS_CliExtPrintf(pCliEnv, "relFail      : %d \r\n", siCb.sts.relFail);
    XOS_CliExtPrintf(pCliEnv, "relUnrecInfo : %d \r\n", siCb.sts.relUnrecInfo);
    XOS_CliExtPrintf(pCliEnv, "t13Exp       : %d \r\n", siCb.sts.t13Exp);
    XOS_CliExtPrintf(pCliEnv, "t15Exp       : %d \r\n", siCb.sts.t15Exp);
    XOS_CliExtPrintf(pCliEnv, "t17Exp       : %d \r\n", siCb.sts.t17Exp);
    XOS_CliExtPrintf(pCliEnv, "t19Exp       : %d \r\n", siCb.sts.t19Exp);
    XOS_CliExtPrintf(pCliEnv, "t21Exp       : %d \r\n", siCb.sts.t21Exp);
    XOS_CliExtPrintf(pCliEnv, "t23Exp       : %d \r\n", siCb.sts.t23Exp);
    XOS_CliExtPrintf(pCliEnv, "t5Exp        : %d \r\n", siCb.sts.t5Exp);
    XOS_CliExtPrintf(pCliEnv, "unxBla       : %d \r\n", siCb.sts.unxBla);
    XOS_CliExtPrintf(pCliEnv, "unxCgba      : %d \r\n", siCb.sts.unxCgba);
    XOS_CliExtPrintf(pCliEnv, "unxCgua      : %d \r\n", siCb.sts.unxCgua);
    XOS_CliExtPrintf(pCliEnv, "unxEvt       : %d \r\n", siCb.sts.unxEvt);
    XOS_CliExtPrintf(pCliEnv, "unxMsg       : %d \r\n", siCb.sts.unxMsg);
    XOS_CliExtPrintf(pCliEnv, "unxUba       : %d \r\n", siCb.sts.unxUba);
   
}

void siPrintPduSts(CLI_ENV* pCliEnv, SiPduSts* pSts)
{

    XOS_CliExtPrintf(pCliEnv, "Address complete(ACM)             : %d \n\r", pSts->acm);
    XOS_CliExtPrintf(pCliEnv, "Answer(ANM)                       : %d \n\r", pSts->anm);


    XOS_CliExtPrintf(pCliEnv, "Blocking ack(BLA)                 : %d \n\r", pSts->bla);
    XOS_CliExtPrintf(pCliEnv, "Blocking(BLO)                     : %d \n\r", pSts->blo);


    XOS_CliExtPrintf(pCliEnv, "Continuity check request(CCR)     : %d \n\r", pSts->ccr);
    XOS_CliExtPrintf(pCliEnv, "Confusion(CFN)                    : %d \n\r", pSts->cfn);
    XOS_CliExtPrintf(pCliEnv, "Circuit group blocking(CGB)       : %d \n\r", pSts->cgb);
    XOS_CliExtPrintf(pCliEnv, "Circuit group blocking ack(CGBA)  : %d \n\r", pSts->cgba);
    XOS_CliExtPrintf(pCliEnv, "Circuit group unblocking(CGU)     : %d \n\r", pSts->cgu);
    XOS_CliExtPrintf(pCliEnv, "Circuit group unblocking ack(CGUA): %d \n\r", pSts->cgua);

    XOS_CliExtPrintf(pCliEnv, "Connect(CON)                      : %d \n\r", pSts->con);
    XOS_CliExtPrintf(pCliEnv, "Continuity(COT)                   : %d \n\r", pSts->cot);

    XOS_CliExtPrintf(pCliEnv, "Call progress(CPG)                : %d \n\r", pSts->cpg);
    XOS_CliExtPrintf(pCliEnv, "Circuit query(CQM)                : %d \n\r", pSts->cqm);
    XOS_CliExtPrintf(pCliEnv, "Circuit query response(CQR)       : %d \n\r", pSts->cqr);

    XOS_CliExtPrintf(pCliEnv, "Facility accepted(FAA)            : %d \n\r", pSts->faa);
    XOS_CliExtPrintf(pCliEnv, "Facility(FAC)                     : %d \n\r", pSts->fac);
    XOS_CliExtPrintf(pCliEnv, "Facility request(FAR)             : %d \n\r", pSts->farMsg);
    XOS_CliExtPrintf(pCliEnv, "Forward transfer(FOT)             : %d \n\r", pSts->fot);
    XOS_CliExtPrintf(pCliEnv, "Facility rejected(FRJ)            : %d \n\r", pSts->frj);
    
    XOS_CliExtPrintf(pCliEnv, "Circuit group reset ack(GRA)      : %d \n\r", pSts->gra);
    XOS_CliExtPrintf(pCliEnv, "Circuit group reset(GRS)          : %d \n\r", pSts->grs);
    XOS_CliExtPrintf(pCliEnv, "Initial address(IAM)              : %d \n\r", pSts->iam);
    XOS_CliExtPrintf(pCliEnv, "Identification request(IDR)       : %d \n\r", pSts->idr);
    XOS_CliExtPrintf(pCliEnv, "Information(INF)                  : %d \n\r", pSts->inf);
    XOS_CliExtPrintf(pCliEnv, "nformation request(INR)           : %d \n\r", pSts->inr);
    XOS_CliExtPrintf(pCliEnv, "Identification response(IRS)      : %d \n\r", pSts->irs);

    XOS_CliExtPrintf(pCliEnv, "Loop prevention(LOP)              : %d \n\r", pSts->lop);
    XOS_CliExtPrintf(pCliEnv, "Loopback ack(LPA)                 : %d \n\r", pSts->lpa);
    XOS_CliExtPrintf(pCliEnv, "Network resource management(NRM)  : %d \n\r", pSts->nrm);
    XOS_CliExtPrintf(pCliEnv, "Overload(OLM)                     : %d \n\r", pSts->olm);
    
    XOS_CliExtPrintf(pCliEnv, "Pass-along(PAM)                   : %d \n\r", pSts->pam);
    
    XOS_CliExtPrintf(pCliEnv, "Release(REL)                      : %d \n\r", pSts->rel);
    XOS_CliExtPrintf(pCliEnv, "Resume(RES)                       : %d \n\r", pSts->res);
    XOS_CliExtPrintf(pCliEnv, "Release complete(RLC)             : %d \n\r", pSts->rlc);
    
    XOS_CliExtPrintf(pCliEnv, "Reset(RSC)                        : %d \n\r", pSts->rsc);
    XOS_CliExtPrintf(pCliEnv, "Subsequent address(SAM)           : %d \n\r", pSts->sam);
    XOS_CliExtPrintf(pCliEnv, "Segmentation(SGM)                 : %d \n\r", pSts->sgm);
    XOS_CliExtPrintf(pCliEnv, "Suspend(SUS)                      : %d \n\r", pSts->sus);
    
    XOS_CliExtPrintf(pCliEnv, "Unblocking ack(UBA)               : %d \n\r", pSts->uba);
    XOS_CliExtPrintf(pCliEnv, "Unblocking(UBL)                   : %d \n\r", pSts->ubl);
    XOS_CliExtPrintf(pCliEnv, "Unequipped CIC(UCIC)              : %d \n\r", pSts->ucic);
    XOS_CliExtPrintf(pCliEnv, "User part available(UPA)          : %d \n\r", pSts->upa);
    XOS_CliExtPrintf(pCliEnv, "User part test(UPT)               : %d \n\r", pSts->upt);
    XOS_CliExtPrintf(pCliEnv, "User to user(USR)                 : %d \n\r", pSts->usr);
    
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_INDIA)
    XOS_CliExtPrintf(pCliEnv, "Application transport message(APN): %d \n\r", pSts->apn);
    XOS_CliExtPrintf(pCliEnv, "Pre-release information(PRI)      : %d \n\r", pSts->pri);
#endif 

#if SS7_CHINA
    XOS_CliExtPrintf(pCliEnv, "Operator message(OPR)             : %d \n\r", pSts->opr);
    XOS_CliExtPrintf(pCliEnv, "Metering Pulse message(MPM)       : %d \n\r", pSts->mpm);
    XOS_CliExtPrintf(pCliEnv, "Calling Party Clearing(CPC)       : %d \n\r", pSts->cpc);

#endif



}

PUBLIC void siPrintIntfSts(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    SiInstId intfId;
    
    SiIntfCb* psiIntfCb = NULLP;
    SiPduSts* pSts = NULLP;

    
    if (2 > siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, " Para error\r\n");
        return;
    }
    
    intfId = (SiInstId)SYS_ATOL(ppArgv[1]);
    
    if ( siFindIntf(&psiIntfCb, intfId, 0, 0, 0, 0, SIINTF_KEY_1) == RFAILED )
    {
        XOS_CliExtPrintf(pCliEnv, "Interface not exist [intfId: %d] \r\n", intfId);
    }
    else
    {
        if( 2==siArgc)
        {

	        /*�ӿ�ͳ����Ϣ*/
	        XOS_CliExtPrintf(pCliEnv, "Interface statistics[intfId: %d] \r\n", intfId);
	        
	        XOS_CliExtPrintf(pCliEnv, "Total transmitted messages        : %d \n\r", psiIntfCb->sts->total.tx);
	        XOS_CliExtPrintf(pCliEnv, "Total received messages           : %d \n\r", psiIntfCb->sts->total.rx);
	    
	        // ������Ϣͳ��
	        pSts = &psiIntfCb->sts->pdu.tx;
	        XOS_CliExtPrintf(pCliEnv, "-----------------------------------------\r\n");
	        XOS_CliExtPrintf(pCliEnv, "Total of each message type transmitted:\r\n");
	        XOS_CliExtPrintf(pCliEnv, "-----------------------------------------\r\n");
	        
	        siPrintPduSts(pCliEnv, pSts);
	        
	        /*������Ϣͳ��*/

	        pSts = &psiIntfCb->sts->pdu.rx;
	        XOS_CliExtPrintf(pCliEnv, "-----------------------------------------\r\n");
	        XOS_CliExtPrintf(pCliEnv, "Total of each message type received: \r\n");
	        XOS_CliExtPrintf(pCliEnv, "-----------------------------------------\r\n");

	        siPrintPduSts(pCliEnv, pSts);
	        return;
	        
        }

        {
           U8 type = (U8)SYS_ATOL(ppArgv[2]);

           //���ͼ���
           if(1 == type)
           {
                /*�ӿ�ͳ����Ϣ*/
		        XOS_CliExtPrintf(pCliEnv, "Interface statistics[intfId: %d] \r\n", intfId);
		        
		        XOS_CliExtPrintf(pCliEnv, "Total transmitted messages        : %d \n\r", psiIntfCb->sts->total.tx);		    
		        // ������Ϣͳ��
		        pSts = &psiIntfCb->sts->pdu.tx;
		        XOS_CliExtPrintf(pCliEnv, "-----------------------------------------\r\n");
		        XOS_CliExtPrintf(pCliEnv, "Total of each message type transmitted:\r\n");
		        XOS_CliExtPrintf(pCliEnv, "-----------------------------------------\r\n");
		        
		        siPrintPduSts(pCliEnv, pSts);

           }

           //���ռ���
           if(2 == type)
           {
	            /*�ӿ�ͳ����Ϣ*/
		        XOS_CliExtPrintf(pCliEnv, "Interface statistics[intfId: %d] \r\n", intfId);
		        
		        XOS_CliExtPrintf(pCliEnv, "Total received messages           : %d \n\r", psiIntfCb->sts->total.rx);
		        /*������Ϣͳ��*/

		        pSts = &psiIntfCb->sts->pdu.rx;
		        XOS_CliExtPrintf(pCliEnv, "-----------------------------------------\r\n");
		        XOS_CliExtPrintf(pCliEnv, "Total of each message type received: \r\n");
		        XOS_CliExtPrintf(pCliEnv, "-----------------------------------------\r\n");

		        siPrintPduSts(pCliEnv, pSts);

           }

        }

    }

   
    
    return;   

    
}

/*
PUBLIC void siPrintNSapSts(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    int  sapId; 
    SiNSAPCb *nCb;
    SiNSAPSts   *sts;             
    
    if (2 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������");
        return;
    }
    
    sapId = SYS_ATOL(ppArgv[1]);
    nCb = SIMTPSAP(sapId);
    
    if (nCb == NULLP)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n sapId����");
    }
    else
    {
        sts = nCb.sts;
        
        XOS_CliExtPrintf(pCliEnv, "adrCmpltRx: %d, ", sts.adrCmpltRx);
        XOS_CliExtPrintf(pCliEnv, "adrCmpltTx: %d, ", sts.adrCmpltTx);


        XOS_CliExtPrintf(pCliEnv, "answerRx: %d, ", sts.answerRx);
        XOS_CliExtPrintf(pCliEnv, "answerTx: %d, ", sts.answerTx);



        XOS_CliExtPrintf(pCliEnv, "callModComRx: %d, ", sts.callModComRx);
        XOS_CliExtPrintf(pCliEnv, "callModComTx: %d, ", sts.callModComTx);
        XOS_CliExtPrintf(pCliEnv, "callModRejRx: %d, ", sts.callModRejRx);
        XOS_CliExtPrintf(pCliEnv, "callModRejTx: %d, ", sts.callModRejTx);

        XOS_CliExtPrintf(pCliEnv, "callModReqRx: %d, ", sts.callModReqRx);
        XOS_CliExtPrintf(pCliEnv, "callModReqTx: %d, ", sts.callModReqTx);

        XOS_CliExtPrintf(pCliEnv, "chargeAckRx: %d, ", sts.chargeAckRx);
        XOS_CliExtPrintf(pCliEnv, "chargeAckTx: %d, ", sts.chargeAckTx);
        
        XOS_CliExtPrintf(pCliEnv, "conChkReqRx: %d, ", sts.conChkReqRx);
        XOS_CliExtPrintf(pCliEnv, "conChkReqRx: %d, ", sts.conChkReqRx);
        XOS_CliExtPrintf(pCliEnv, "confusRx: %d, ", sts.confusRx);
        XOS_CliExtPrintf(pCliEnv, "confusTx: %d, ", sts.confusTx);
        XOS_CliExtPrintf(pCliEnv, "conRx: %d, ", sts.conRx);
        XOS_CliExtPrintf(pCliEnv, "conTx: %d, ", sts.conTx);

        XOS_CliExtPrintf(pCliEnv, "facAckRx: %d, ", sts.facAckRx);
        XOS_CliExtPrintf(pCliEnv, "facAckTx: %d, ", sts.facAckTx);
        XOS_CliExtPrintf(pCliEnv, "facRejRx: %d, ", sts.facRejRx);
        XOS_CliExtPrintf(pCliEnv, "facRejTx: %d, ", sts.facRejTx);
        XOS_CliExtPrintf(pCliEnv, "infoReqRx: %d, ", sts.infoReqRx);
        XOS_CliExtPrintf(pCliEnv, "infoReqTx: %d, ", sts.infoReqTx);
        XOS_CliExtPrintf(pCliEnv, "infoRx: %d, ", sts.infoRx);
        XOS_CliExtPrintf(pCliEnv, "infoTx: %d, ", sts.infoTx);
        XOS_CliExtPrintf(pCliEnv, "initAdrRx: %d, ", sts.initAdrRx);        
        XOS_CliExtPrintf(pCliEnv, "initAdrTx: %d, ", sts.initAdrTx);
        
        XOS_CliExtPrintf(pCliEnv, "passAlongRx: %d, ", sts.passAlongRx);
        XOS_CliExtPrintf(pCliEnv, "passAlongTx: %d, ", sts.passAlongTx);
        XOS_CliExtPrintf(pCliEnv, "progressRx: %d, ", sts.progressRx);
        XOS_CliExtPrintf(pCliEnv, "progressTx: %d, ", sts.progressTx);
        
        XOS_CliExtPrintf(pCliEnv, "relCmpltRx: %d, ", sts.relCmpltRx);
        XOS_CliExtPrintf(pCliEnv, "relCmpltTx: %d, ", sts.relCmpltTx);
        XOS_CliExtPrintf(pCliEnv, "relRx: %d, ", sts.relRx);
        XOS_CliExtPrintf(pCliEnv, "relTx: %d, ", sts.relTx);
        XOS_CliExtPrintf(pCliEnv, "resmRx: %d, ", sts.resmRx);
        XOS_CliExtPrintf(pCliEnv, "resmTx: %d, ", sts.resmTx);        
        XOS_CliExtPrintf(pCliEnv, "subsAdrRx: %d, ", sts.subsAdrRx);
        XOS_CliExtPrintf(pCliEnv, "subsAdrTx: %d, ", sts.subsAdrTx);
        XOS_CliExtPrintf(pCliEnv, "suspRx: %d, ", sts.suspRx);
        XOS_CliExtPrintf(pCliEnv, "suspTx: %d, ", sts.suspTx);
        
        XOS_CliExtPrintf(pCliEnv, "uneqCirIdRx: %d, ", sts.uneqCirIdRx);       
        XOS_CliExtPrintf(pCliEnv, "uneqCirIdTx: %d, ", sts.uneqCirIdTx);
        XOS_CliExtPrintf(pCliEnv, "usrToUsrRx: %d, ", sts.usrToUsrRx);
        XOS_CliExtPrintf(pCliEnv, "usrToUsrTx: %d, ", sts.usrToUsrTx);
       
        
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_INDIA)
        XOS_CliExtPrintf(pCliEnv, "appTranRx: %d, ", sts->appTranRx);
        XOS_CliExtPrintf(pCliEnv, "appTranTx: %d, ", sts->appTranTx);
        XOS_CliExtPrintf(pCliEnv, "preRelRx: %d, ", sts.preRelRx);
        XOS_CliExtPrintf(pCliEnv, "preRelTx: %d, ", sts.preRelTx);
#endif

#if SS7_CHINA
        XOS_CliExtPrintf(pCliEnv, "cpcRx: %d, ", sts.cpcRx);
        XOS_CliExtPrintf(pCliEnv, "cpcTx: %d, ", sts.cpcTx);
        XOS_CliExtPrintf(pCliEnv, "mpmRx: %d, ", sts.mpmRx);
        XOS_CliExtPrintf(pCliEnv, "mpmTx: %d, ", sts.mpmTx);
        XOS_CliExtPrintf(pCliEnv, "oprRx: %d, ", sts.oprRx);
        XOS_CliExtPrintf(pCliEnv, "oprTx: %d, ", sts.oprTx);
#endif
    }
    
    return;   
}
*/

#endif /*#if (SI_LMINT3 || SMSI_LMINT3)*/

#ifdef DEBUGP
PUBLIC void setDBG(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    int dbgType;  
    int flag;     /*0 ��ʾ�ر�DBG��Ϣ, 1 ��ʾ��DBG��Ϣ */
    
    if (3 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������");
        return;
    }
    
    dbgType = (int)SYS_ATOL(ppArgv[1]);
    flag = (int)SYS_ATOL(ppArgv[2]);
    
    
    switch(dbgType)
    {
    case DEBUG_ALL:
        if (SI_OPEN_DEBUG == flag)
        {
            siCb.init.dbgMask = 0xffffffff;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else if (SI_SHUT_DEBUG == flag)
        {
            siCb.init.dbgMask = 0x0;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        }
        break;
    case DEBUG_LI:
        if (SI_OPEN_DEBUG == flag)
        {
            siCb.init.dbgMask |= DBGMASK_LI;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else if (SI_SHUT_DEBUG == flag)
        {
            siCb.init.dbgMask &= (~DBGMASK_LI);
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        }
        break;
    case DEBUG_MI:
        if (SI_OPEN_DEBUG == flag)
        {
            siCb.init.dbgMask |= DBGMASK_MI;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else if (SI_SHUT_DEBUG == flag)
        {
            siCb.init.dbgMask &= (~DBGMASK_MI);
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        }
        break;
    case DEBUG_UI:
        if (SI_OPEN_DEBUG == flag)
        {
            siCb.init.dbgMask |= DBGMASK_UI;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else if (SI_SHUT_DEBUG == flag)
        {
            siCb.init.dbgMask &= (~DBGMASK_UI);
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        }
        break;
   
    case SIDBG_PROG:
        if (SI_OPEN_DEBUG == flag)
        {
            siCb.init.dbgMask |= SIDBGMASK_PROG;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else if (SI_SHUT_DEBUG == flag)
        {
            siCb.init.dbgMask &= (~SIDBGMASK_PROG);
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        }
        break;
    case SIDBG_WARN:
        if (SI_OPEN_DEBUG == flag)
        {
            siCb.init.dbgMask |= SIDBGMASK_WARN;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else if (SI_SHUT_DEBUG == flag)
        {
            siCb.init.dbgMask &= (~SIDBGMASK_WARN);
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        }
        break;
    case SIDBG_CERR:
        if (SI_OPEN_DEBUG == flag)
        {
            siCb.init.dbgMask |= SIDBGMASK_CERR;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else if (SI_SHUT_DEBUG == flag)
        {
            siCb.init.dbgMask &= (~SIDBGMASK_CERR);
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        }
        break;
    case SIDBG_ERR:
        if (SI_OPEN_DEBUG == flag)
        {
            siCb.init.dbgMask |= SIDBGMASK_ERR;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else if (SI_SHUT_DEBUG == flag)
        {
            siCb.init.dbgMask &= (~SIDBGMASK_ERR);
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        }
        break;
    case SIDBG_TMR:
        if (SI_OPEN_DEBUG == flag)
        {
            siCb.init.dbgMask |= SIDBGMASK_TMR;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else if (SI_SHUT_DEBUG == flag)
        {
            siCb.init.dbgMask &= (~SIDBGMASK_TMR);
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        }
        break;
    case SIDBG_STATE:
        if (SI_OPEN_DEBUG == flag)
        {
            siCb.init.dbgMask |= SIDBGMASK_STATE;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else if (SI_SHUT_DEBUG == flag)
        {
            siCb.init.dbgMask &= (~SIDBGMASK_STATE);
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        }
        break;
    case SIDBG_MF:
        if (SI_OPEN_DEBUG == flag)
        {
            siCb.init.dbgMask |= SIDBGMASK_MF;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else if (SI_SHUT_DEBUG == flag)
        {
            siCb.init.dbgMask &= (~SIDBGMASK_MF);
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        }
        break;
     case SIDBG_MSGERR:
        if (SI_OPEN_DEBUG == flag)
        {
            siCb.init.dbgMask |= SIDBGMASK_MSGERR;
            g_DBGMsgErr = TRUE;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else if (SI_SHUT_DEBUG == flag)
        {
            siCb.init.dbgMask &= (~SIDBGMASK_MSGERR);
            g_DBGMsgErr = FALSE;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        }
        break;
    case SIDBG_MSGSEG:
        if (SI_OPEN_DEBUG == flag)
        {
            siCb.init.dbgMask |= SIDBGMASK_MSGSEG;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else if (SI_SHUT_DEBUG == flag)
        {
            siCb.init.dbgMask &= (~SIDBGMASK_MSGSEG);
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        }
        break;
     case SIDBG_MSGTX:
        if (SI_OPEN_DEBUG == flag)
        {
            siCb.init.dbgMask |= SIDBGMASK_MSGTX;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else if (SI_SHUT_DEBUG == flag)
        {
            siCb.init.dbgMask &= (~SIDBGMASK_MSGTX);
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        }
        break;
    case SIDBG_MSGRX:
        if (SI_OPEN_DEBUG == flag)
        {
            siCb.init.dbgMask |= SIDBGMASK_MSGRX;
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else if (SI_SHUT_DEBUG == flag)
        {
            siCb.init.dbgMask &= (~SIDBGMASK_MSGRX);
            XOS_CliExtPrintf(pCliEnv, "DBG���óɹ�\r\n");
        }
        else
        {
            XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        }
        break;
    default:
        XOS_CliExtPrintf(pCliEnv, "\r\n�����������!");
        break;
    }
    
    
    return;
}


PUBLIC void setDbgMask(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    U32 mask;
    
    if (2 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������");
        return;
    }
    
   if( XSUCC!= XOS_StrToNum(ppArgv[1],&mask))
   {
       XOS_CliExtPrintf(pCliEnv, "\r\n����Ĳ�������");
       return;
   }
   

    if( 0 == mask || 0xffffffff == mask)
    {
        siCb.init.dbgMask = mask;
    }
    else
    {
        siCb.init.dbgMask |= mask;

    }

    
     XOS_CliExtPrintf(pCliEnv, "\r\n debug�������óɹ�");
       
    
    return;
}


PUBLIC void showDBG(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    
    if (siCb.init.dbgMask == 0x0)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n Not debug open, dbgMask is 0");
    }
    
    XOS_CliExtPrintf(pCliEnv, "\r\n DBGMASK_SI      : %s",GET_DBG_STATE(DBGMASK_SI));
    XOS_CliExtPrintf(pCliEnv, "\r\n DBGMASK_MI      : %s",GET_DBG_STATE(DBGMASK_MI));
    XOS_CliExtPrintf(pCliEnv, "\r\n DBGMASK_UI      : %s",GET_DBG_STATE(DBGMASK_UI));
    XOS_CliExtPrintf(pCliEnv, "\r\n DBGMASK_LI      : %s",GET_DBG_STATE(DBGMASK_LI));
    XOS_CliExtPrintf(pCliEnv, "\r\n DBGMASK_PI      : %s",GET_DBG_STATE(DBGMASK_PI));
    XOS_CliExtPrintf(pCliEnv, "\r\n DBGMASK_PLI     : %s",GET_DBG_STATE(DBGMASK_PLI));

    
    XOS_CliExtPrintf(pCliEnv, "\r\n SIDBGMASK_PROG  : %s",GET_DBG_STATE(SIDBGMASK_PROG));
    XOS_CliExtPrintf(pCliEnv, "\r\n SIDBGMASK_WARN  : %s",GET_DBG_STATE(SIDBGMASK_WARN));
    XOS_CliExtPrintf(pCliEnv, "\r\n SIDBGMASK_CERR  : %s",GET_DBG_STATE(SIDBGMASK_CERR));
    XOS_CliExtPrintf(pCliEnv, "\r\n SIDBGMASK_ERR   : %s",GET_DBG_STATE(SIDBGMASK_ERR) );
    XOS_CliExtPrintf(pCliEnv, "\r\n SIDBGMASK_TMR   : %s",GET_DBG_STATE(SIDBGMASK_TMR));
    XOS_CliExtPrintf(pCliEnv, "\r\n SIDBGMASK_STATE : %s",GET_DBG_STATE(SIDBGMASK_STATE));
    XOS_CliExtPrintf(pCliEnv, "\r\n SIDBGMASK_MF    : %s",GET_DBG_STATE(SIDBGMASK_MF));

    XOS_CliExtPrintf(pCliEnv, "\r\n SIDBGMASK_MSGERR: %s",GET_DBG_STATE(SIDBGMASK_MSGERR));
    XOS_CliExtPrintf(pCliEnv, "\r\n SIDBGMASK_MSGSEG: %s",GET_DBG_STATE(SIDBGMASK_MSGSEG));
    XOS_CliExtPrintf(pCliEnv, "\r\n SIDBGMASK_MSGTX : %s",GET_DBG_STATE(SIDBGMASK_MSGTX));
    XOS_CliExtPrintf(pCliEnv, "\r\n SIDBGMASK_MSGRX : %s",GET_DBG_STATE(SIDBGMASK_MSGRX));
    
    return;
    
}
    

#endif /* DEBUGP */

#ifdef STR_TST
PUBLIC void setStrPar(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{


    TestSetPar Para;
    
    if (4 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������");
        return;
    }
    
    Para.CallOutNum     = (U32)SYS_ATOL(ppArgv[1]);
    Para.CallingTime    = (U32)SYS_ATOL(ppArgv[2]);
    Para.CallNumPerTick = (U32)SYS_ATOL(ppArgv[3]);

    StrSetPar(Para);
    
    XOS_CliExtPrintf(pCliEnv, "\r\n���óɹ�\r\n");
    return;
}

PUBLIC void StartStrTest(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{

    XCHAR  starttime[30];
    
    
    if (1 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������");
        return;
    }
    InitializeBenchMark();
    BMTimerStart(0);
    XOS_GetLocTime(starttime);
    printf("The Start Time is: %s\n",starttime);
    StrStartTest();
    
    return;
}

PUBLIC void StartStrOnceTest(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
 
    if (1 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������");
        return;
    }

       CallOut();
       StrStopTest();
    
    return;
}

PUBLIC void StopStrTest(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    DateTime dt;
    XCHAR  stoptime[30];
    if (1 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������");
        return;
    }

    XOS_GetLocTime(stoptime);
    printf("The Stop Time is: %s\n",stoptime);
    StrStopTest();
    BMTimerEnd(0);
    printf("The total time of test is: %dday: %dhour: %dmin: %dsec: %dtenths\n",
    gBenchmark_Counter[0].day,gBenchmark_Counter[0].hour,gBenchmark_Counter[0].min,
    gBenchmark_Counter[0].sec,gBenchmark_Counter[0].tenths);


    return;
}

PUBLIC void ResetStrTest(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    U32 i;
    
    if (1 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������");
        return;
    }

    StrResetTest();
    StrStartTest();
    
    return;
}

PUBLIC void ShowStrTestResult(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    U32 i;
    
    if (1 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������");
        return;
    }

    XOS_CliExtPrintf(pCliEnv, "\r\n");
    XOS_CliExtPrintf(pCliEnv, "Intf  Callout  callin  COutFail  CInFail\r\n");
    for (i = 0; i < SI_NMB_INTF; i++)
    {
        if (IntfCb[i].intfId != U32_INVALID)
        {
            XOS_CliExtPrintf(pCliEnv, "%-5d %-7d  %-7d  %-7d  %-7d\r\n", IntfCb[i].intfId, 
            IntfCb[i].sCallStat.CallOutNum, IntfCb[i].sCallStat.CallinNum, IntfCb[i].sCallStat.CallOutFailNum,
            IntfCb[i].sCallStat.CallinFailNum);
        }
    }

    XOS_CliExtPrintf(pCliEnv, "\r\n");
    
    return;
}
PUBLIC void ShowMsgInOneCircuit(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    CirId cirId;

 
    if (2 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������");
        return;
    }
    
    cirId = (CirId)SYS_ATOL(ppArgv[1]);

    
    XOS_CliExtPrintf(pCliEnv, "----------------------------------------------------\r\n");
    XOS_CliExtPrintf(pCliEnv, "CirNum  SndConReq  uSndRelReq uRcvConReq  uRcvRelReq\r\n");
    XOS_CliExtPrintf(pCliEnv, "----------------------------------------------------\r\n");

    if (cirId != U32_INVALID)
    {
        XOS_CliExtPrintf(pCliEnv, "%-10d %-10d %-10d %-10d %-10d\r\n", cirId,
        ccCb.cirData[cirId].uSndConReq,ccCb.cirData[cirId].uSndRelReq, ccCb.cirData[cirId].uRcvConReq,
        ccCb.cirData[cirId].uRcvRelReq);
    }

   

    XOS_CliExtPrintf(pCliEnv, "\r\n");
    
    return;
}



PUBLIC void ShowStrCcCir(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{

    U32 i;
    
    if (1 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������\r\n");
        return;
    }


    XOS_CliExtPrintf(pCliEnv, "----CC circuit config information: \r\n");
    XOS_CliExtPrintf(pCliEnv, "----------------------------------------------------\r\n");
     XOS_CliExtPrintf(pCliEnv, "uCirNum: %d  \r\n", ccCb.uCirNum);
    XOS_CliExtPrintf(pCliEnv, "----------------------------------------------------\r\n\r\n");

//    XOS_CliExtPrintf(pCliEnv, "intfId  cirId  CirState\r\n");
//    for (i = 0; i < SI_NMB_CIR; i++)
//    {
//        if (ccCb.cirData[i].cirId != U32_INVALID)
//        {
//             XOS_CliExtPrintf(pCliEnv, "%-7d %-7d  %-d\r\n", ccCb.cirData[i].intfId, ccCb.cirData[i].cirId, 
//                 ccCb.cirData[i].CirState);
//        }
//    }



    XOS_CliExtPrintf(pCliEnv, "----stress circuit config information: \r\n");
    XOS_CliExtPrintf(pCliEnv, "----------------------------------------------------\r\n");
    XOS_CliExtPrintf(pCliEnv, "intfId  CirNum CtrlingNum  CallingNum CallOutNum\r\n");

    for (i = 0; i < SI_NMB_INTF; i++)
    {
        if (IntfCb[i].intfId != U32_INVALID)
        {
             XOS_CliExtPrintf(pCliEnv, "%-7d %-6d  %-11d  %-10d  %d\r\n", IntfCb[i].intfId, IntfCb[i].uCirNum, 
             IntfCb[i].uCtrlingNum, IntfCb[i].uCallingNum, IntfCb[i].uCallOutNum);
        }
    }

    XOS_CliExtPrintf(pCliEnv, "----------------------------------------------------\r\n\r\n");

    return;
}

PUBLIC void ShowStrCirState(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{

    U32 i;
    U32 firstCir;
    U32 uNum;
    
    if (3 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������\r\n");
        return;
    }

    firstCir    = (U32)SYS_ATOL(ppArgv[1]);
    uNum        = (U32)SYS_ATOL(ppArgv[2]);
    
    XOS_CliExtPrintf(pCliEnv, "----------------------------------------------------\r\n");

    XOS_CliExtPrintf(pCliEnv, "intfId  CirId  CirState \r\n");

    for (i = 0; i < uNum; i++)
    {

         if (sStrCirData[i].CfgDone != FALSE)
         {
         XOS_CliExtPrintf(pCliEnv, "%-7d %-6d  %d\r\n", sStrCirData[i].intfId, sStrCirData[i].cirId, sStrCirData[i].uCirState);
         }
    }

    XOS_CliExtPrintf(pCliEnv, "----------------------------------------------------\r\n");

}

extern S16 StrStartConTmr(CirId circuit, S16 timer);
extern void SetDefalt();
extern TestSetPar sTstSetPar;

extern U32  m_SartConTmr;
extern U32  m_EndConTmr;


PUBLIC void StartConTimer(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{

    U32 circuit;
    
    if (2 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������\r\n");
        return;
    }

    circuit    = (U32)SYS_ATOL(ppArgv[1]);


    if (FALSE == sTstSetPar.bSetDone)
    {
         SetDefalt();
    }
    
    StrStartConTmr(circuit, 2);

}

PUBLIC void ShowConTimerN(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    
    if (1 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������\r\n");
        return;
    }


    XOS_CliExtPrintf(pCliEnv, "\r\n Start Con number: %d, End Con number: %d \r\n", m_SartConTmr, m_EndConTmr);


}


PUBLIC void CfgData(CLI_ENV* pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
    U32 uNum;
    U32 i;
    SiCfgCirGrpTab cfg;
    
    if (2 != siArgc)
    {
        XOS_CliExtPrintf(pCliEnv, "\r\n���������������\r\n");
        return;
    }

    uNum    = (U32)SYS_ATOL(ppArgv[1]);
    cfg.spId = 1;
    cfg.cirNum = 31;
    cfg.pcmType = 1;
    cfg.subRtId = 200002;
    cfg.cirGrpId = 0;
    cfg.fstCIC = -30;
    cfg.fstTimeSlot = 1;
    cfg.locPcmId = 0;

    for (i = 0; i < uNum; i++)
    {
        cfg.locPcmId++;
        cfg.cirGrpId++;

        cfg.fstCIC += 31;

  
        XOS_CliExtPrintf(pCliEnv, "%-10d  %-10d  %-10d  %-10d  %-10d  %-10d  %-10d  %-10d \n",
        cfg.spId, cfg.cirGrpId, cfg.subRtId, cfg.locPcmId, 
        cfg.pcmType, cfg.fstTimeSlot, cfg.fstCIC, cfg.cirNum);
    }


}


#endif /* #ifdef STR_TST */


#ifdef SI_TEST_CP_OAM_SUPPORT
/************************************************************/
/*****       Functions: ISUP dynamic config test       ******/ 
/************************************************************/
void siTestAddIntf(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
    unsigned int tableid;
    unsigned short msgtype;
    unsigned int sequence = 1;
    unsigned char pack_end = FALSE;
    
    tb_record row;
    SiCfgIntfTab   siIntfCfg;
    
    tb_record * prow = &row;
    SiCfgIntfTab   *pSiIntfCfg = &siIntfCfg;
    
    cmMemset((U8 *)prow, 0, sizeof(tb_record));
    
    if ( NULLP == pCliEnv )
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if (NULLP == ppArgv)
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if(argc != 1)
    {
        XOS_CliExtPrintf(pCliEnv, "���������������,�������޲���", __FILE__, __LINE__ );
        RETVOID;
    }
    
    tableid = APP_TABLE_ID_SS7_ISUP_INTF;
    msgtype = SA_INSERT_MSG;
    pack_end = TRUE;
    
    prow->head.mask[0] = 0;
    prow->head.col_count = 1;
    prow->tableid = APP_TABLE_ID_SS7_ISUP_INTF;
    
    pSiIntfCfg->intfId    = 2;
    pSiIntfCfg->nwId      = 1;
    pSiIntfCfg->opcIdx    = 1;
    pSiIntfCfg->dpcInx    = 4;
    pSiIntfCfg->lnkSelOpt = 0;
    pSiIntfCfg->trunkType = 1;
    pSiIntfCfg->pauseActn = 1;
    
    prow->panytbrow = (void *)pSiIntfCfg;
    
    siDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);
    
    RETVOID;
}

void siTestModIntf(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
    unsigned int tableid;
    unsigned short msgtype;
    unsigned int sequence = 1;
    unsigned char pack_end = FALSE;
    
    tb_record row;
    SiCfgIntfTab   siIntfCfg;
    
    tb_record * prow = &row;
    SiCfgIntfTab   *pSiIntfCfg = &siIntfCfg;
    
    cmMemset((U8 *)prow, 0, sizeof(tb_record));
    
    if ( NULLP == pCliEnv )
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if (NULLP == ppArgv)
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if(argc != 1)
    {
        XOS_CliExtPrintf(pCliEnv, "���������������,�������޲���", __FILE__, __LINE__ );
        RETVOID;
    }
    
    tableid = APP_TABLE_ID_SS7_ISUP_INTF;
    msgtype = SA_UPDATE_MSG;
    pack_end = TRUE;
    
    prow->head.mask[0] = 0;
    prow->head.col_count = 1;
    prow->tableid = APP_TABLE_ID_SS7_ISUP_INTF;
    
    pSiIntfCfg->intfId    = 2;
    pSiIntfCfg->nwId      = 1;
    pSiIntfCfg->opcIdx    = 1;
    pSiIntfCfg->dpcInx    = 4;
    pSiIntfCfg->lnkSelOpt = 0;
    pSiIntfCfg->trunkType = 2;
    pSiIntfCfg->pauseActn = 2;
    
    prow->panytbrow = (void *)pSiIntfCfg;
    
    siDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);
    
    RETVOID;
}

void siTestDelIntf(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
    unsigned int tableid;
    unsigned short msgtype;
    unsigned int sequence = 1;
    unsigned char pack_end = FALSE;
    
    tb_record row;
    SiCfgIntfTab   siIntfCfg;
    
    tb_record * prow = &row;
    SiCfgIntfTab   *pSiIntfCfg = &siIntfCfg;
    
    cmMemset((U8 *)prow, 0, sizeof(tb_record));
    
    if ( NULLP == pCliEnv )
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if (NULLP == ppArgv)
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if(argc != 1)
    {
        XOS_CliExtPrintf(pCliEnv, "���������������,�������޲���", __FILE__, __LINE__ );
        RETVOID;
    }
    
    tableid = APP_TABLE_ID_SS7_ISUP_INTF;
    msgtype = SA_DELETE_MSG;
    pack_end = TRUE;
    
    prow->head.mask[0] = 0;
    prow->head.col_count = 1;
    prow->tableid = APP_TABLE_ID_SS7_ISUP_INTF;
    
    pSiIntfCfg->intfId    = 2;
    
    
    prow->panytbrow = (void *)pSiIntfCfg;
    
    siDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);
    
    RETVOID;
}


/************************************************************/
/*****       Functions: isup dynamic config test       ******/ 
/************************************************************/
void siTestAddSubRoute(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
    unsigned int tableid;
    unsigned short msgtype;
    unsigned int sequence = 1;
    unsigned char pack_end = FALSE;
    
    tb_record row;
    SiCfgSubRouteTab   siSubRouteCfg;
    
    tb_record * prow = &row;
    SiCfgSubRouteTab   *pSiSubRouteCfg = &siSubRouteCfg;
    
    cmMemset((U8 *)prow, 0, sizeof(tb_record));
    
    if ( NULLP == pCliEnv )
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if (NULLP == ppArgv)
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if(argc != 1)
    {
        XOS_CliExtPrintf(pCliEnv, "���������������,�������޲���", __FILE__, __LINE__ );
        RETVOID;
    }
    
    tableid = APP_TABLE_ID_SS7_ISUP_SUBROUT;
    msgtype = SA_INSERT_MSG;
    pack_end = TRUE;
    
    prow->head.mask[0] = 0;
    prow->head.col_count = 1;
    prow->tableid = APP_TABLE_ID_SS7_ISUP_SUBROUT;
    
    pSiSubRouteCfg->subRtId        = 200001;
    pSiSubRouteCfg->intfId         = 2;
    pSiSubRouteCfg->CallSrcId      = 0;
    pSiSubRouteCfg->SigRuleId      = 1;
    pSiSubRouteCfg->CirType        = 0;
    pSiSubRouteCfg->CtrlMode       = 1;
    pSiSubRouteCfg->CtrlSelMath    = 2;
    pSiSubRouteCfg->NonCtrlSelMath = 3;
    pSiSubRouteCfg->ResvPerc       = 0;

    
    prow->panytbrow = (void *)pSiSubRouteCfg;
    
    siDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);
    
    RETVOID;
}






/************************************************************/
/*****       Functions: isup dynamic config test       ******/ 
/************************************************************/
void siTestModSubRoute(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
    unsigned int tableid;
    unsigned short msgtype;
    unsigned int sequence = 1;
    unsigned char pack_end = FALSE;
    
    tb_record row;
    SiCfgSubRouteTab   siSubRouteCfg;
    
    tb_record * prow = &row;
    SiCfgSubRouteTab   *pSiSubRouteCfg = &siSubRouteCfg;
    
    cmMemset((U8 *)prow, 0, sizeof(tb_record));
    
    if ( NULLP == pCliEnv )
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if (NULLP == ppArgv)
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if(argc != 1)
    {
        XOS_CliExtPrintf(pCliEnv, "���������������,�������޲���", __FILE__, __LINE__ );
        RETVOID;
    }
    
    tableid = APP_TABLE_ID_SS7_ISUP_SUBROUT;
    msgtype = SA_UPDATE_MSG;
    pack_end = TRUE;
    
    prow->head.mask[0] = 0;
    prow->head.col_count = 1;
    prow->tableid = APP_TABLE_ID_SS7_ISUP_SUBROUT;
    
    pSiSubRouteCfg->subRtId        = 200001;
    pSiSubRouteCfg->intfId         = 2;
    pSiSubRouteCfg->CallSrcId      = 0;
    pSiSubRouteCfg->SigRuleId      = 1;
    pSiSubRouteCfg->CirType        = 0;
    pSiSubRouteCfg->CtrlMode       = 1;
    pSiSubRouteCfg->CtrlSelMath    = 2;
    pSiSubRouteCfg->NonCtrlSelMath = 3;
    pSiSubRouteCfg->ResvPerc       = 0;

    
    prow->panytbrow = (void *)pSiSubRouteCfg;
    
    siDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);
    
    RETVOID;
}



/************************************************************/
/*****       Functions: isup dynamic config test       ******/ 
/************************************************************/
void siTestDelSubRoute(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
    unsigned int tableid;
    unsigned short msgtype;
    unsigned int sequence = 1;
    unsigned char pack_end = FALSE;
    
    tb_record row;
    SiCfgSubRouteTab   siSubRouteCfg;
    
    tb_record * prow = &row;
    SiCfgSubRouteTab   *pSiSubRouteCfg = &siSubRouteCfg;
    
    cmMemset((U8 *)prow, 0, sizeof(tb_record));
    
    if ( NULLP == pCliEnv )
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if (NULLP == ppArgv)
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if(argc != 1)
    {
        XOS_CliExtPrintf(pCliEnv, "���������������,�������޲���", __FILE__, __LINE__ );
        RETVOID;
    }
    
    tableid = APP_TABLE_ID_SS7_ISUP_SUBROUT;
    msgtype = SA_DELETE_MSG;
    pack_end = TRUE;
    
    prow->head.mask[0] = 0;
    prow->head.col_count = 1;
    prow->tableid = APP_TABLE_ID_SS7_ISUP_SUBROUT;
    
    pSiSubRouteCfg->subRtId        = 200001;
    
    prow->panytbrow = (void *)pSiSubRouteCfg;
    
    siDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);
    
    RETVOID;
}


void siTestAddCirGrp(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
    unsigned int tableid;
    unsigned short msgtype;
    unsigned int sequence = 1;
    unsigned char pack_end = FALSE;
    
    tb_record row;
    SiCfgCirGrpTab   siCirGrpCfg;
    
    tb_record * prow = &row;
    SiCfgCirGrpTab   *pSiCirGrpCfg = &siCirGrpCfg;
    
    cmMemset((U8 *)prow, 0, sizeof(tb_record));
    
    if ( NULLP == pCliEnv )
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if (NULLP == ppArgv)
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if(argc != 1)
    {
        XOS_CliExtPrintf(pCliEnv, "���������������,�������޲���", __FILE__, __LINE__ );
        RETVOID;
    }
    
    tableid = APP_TABLE_ID_SS7_ISUP_CIRGRP;
    msgtype = SA_INSERT_MSG;
    pack_end = TRUE;
    
    prow->head.mask[0] = 0;
    prow->head.col_count = 1;
    prow->tableid = APP_TABLE_ID_SS7_ISUP_CIRGRP;
    
    pSiCirGrpCfg->spId        = 1;
    pSiCirGrpCfg->cirGrpId    = 101;
    pSiCirGrpCfg->subRtId     = 200001;
    pSiCirGrpCfg->locPcmId    = 101;
    pSiCirGrpCfg->pcmType     = 1;
    pSiCirGrpCfg->fstTimeSlot = 1;
    pSiCirGrpCfg->fstCIC      = 3100;
    pSiCirGrpCfg->cirNum      = 31;
    pSiCirGrpCfg->conReq      = 0;
    
    prow->panytbrow = (void *)pSiCirGrpCfg;
    
    siDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);
    
    RETVOID;
}


void siTestModCirGrp(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
    unsigned int tableid;
    unsigned short msgtype;
    unsigned int sequence = 1;
    unsigned char pack_end = FALSE;
    
    tb_record row;
    SiCfgCirGrpTab   siCirGrpCfg;
    
    tb_record * prow = &row;
    SiCfgCirGrpTab   *pSiCirGrpCfg = &siCirGrpCfg;
    
    cmMemset((U8 *)prow, 0, sizeof(tb_record));
    
    if ( NULLP == pCliEnv )
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if (NULLP == ppArgv)
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if(argc != 1)
    {
        XOS_CliExtPrintf(pCliEnv, "���������������,�������޲���", __FILE__, __LINE__ );
        RETVOID;
    }
    
    tableid = APP_TABLE_ID_SS7_ISUP_CIRGRP;
    msgtype = SA_UPDATE_MSG;
    pack_end = TRUE;
    
    prow->head.mask[0] = 0;
    prow->head.col_count = 1;
    prow->tableid = APP_TABLE_ID_SS7_ISUP_CIRGRP;
    
    pSiCirGrpCfg->spId        = 1;
    pSiCirGrpCfg->cirGrpId    = 101;
    pSiCirGrpCfg->subRtId     = 200001;
    pSiCirGrpCfg->locPcmId    = 101;
    pSiCirGrpCfg->pcmType     = 1;
    pSiCirGrpCfg->fstTimeSlot = 1;
    pSiCirGrpCfg->fstCIC      = 3100;
    pSiCirGrpCfg->cirNum      = 31;
    pSiCirGrpCfg->conReq      = 1;
    
    prow->panytbrow = (void *)pSiCirGrpCfg;
    
    siDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);
    
    RETVOID;
}




void siTestDelCirGrp(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
    unsigned int tableid;
    unsigned short msgtype;
    unsigned int sequence = 1;
    unsigned char pack_end = FALSE;
    
    tb_record row;
    SiCfgCirGrpTab   siCirGrpCfg;
    
    tb_record * prow = &row;
    SiCfgCirGrpTab   *pSiCirGrpCfg = &siCirGrpCfg;
    
    cmMemset((U8 *)prow, 0, sizeof(tb_record));
    
    if ( NULLP == pCliEnv )
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if (NULLP == ppArgv)
    {
        XOS_CliExtPrintf(pCliEnv, SI_DBG_ERR_NULLP, __FILE__, __LINE__ );
        RETVOID;
    }
    
    if(argc != 1)
    {
        XOS_CliExtPrintf(pCliEnv, "���������������,�������޲���", __FILE__, __LINE__ );
        RETVOID;
    }
    
    tableid = APP_TABLE_ID_SS7_ISUP_CIRGRP;
    msgtype = SA_DELETE_MSG;
    pack_end = TRUE;
    
    prow->head.mask[0] = 0;
    prow->head.col_count = 1;
    prow->tableid = APP_TABLE_ID_SS7_ISUP_CIRGRP;
    
    pSiCirGrpCfg->spId    = 2;
    pSiCirGrpCfg->cirGrpId    = 101;
    
    prow->panytbrow = (void *)pSiCirGrpCfg;
    
    siDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);
    
    RETVOID;
}





#endif /* SI_TEST_CP_OAM_SUPPORT */



PUBLIC void RegIsupDbg()
{
    XS32 isupId;  
    XS32 retId;
    retId = XOS_RegistCmdPrompt( SYSTEM_MODE, "prtl",  "Э��ģʽ", "�޲���" );
    
    
    isupId = XOS_RegistCmdPrompt( retId, "isup", "isupЭ��", "�޲���" );
    
    XOS_RegistCommand(isupId,
        siPrintSiCb,
        "showsicb",
        "��ʾisup���ƿ���Ϣ",
        "�޲���");
    
    XOS_RegistCommand(isupId,
        siPrintUpSap,
        "showusap",
        "��ʾisup�ϲ�Sap������",
        "����1: SapId");
    XOS_RegistCommand(isupId,
        siPrintNSap,
        "shownsap",
        "��ʾisup�����Sap����",
        "����1: SapId");
    
    XOS_RegistCommand(isupId,
        siPrintIntf,
        "showinterface",
        "��ʾisup�ӿڵ�����,�����������ʾ���нӿ�",
        "����1: �ӿں�intfId");
    
    XOS_RegistCommand(isupId,
        siPrintCirCfg,
        "showcircfg",
        "��ʾisup��·�������ݣ������������ʾ�������õĵ�·",
        "����1: 1-��ʾ�ӿ����е�·,2-��ʾָ���ĵ�·\n\r"
        "����2: �������1Ϊ1����Ϊ�ӿ�ID,����Ϊ��·ID");
    
    XOS_RegistCommand(isupId,
        siPrintCirState,
        "showcirstate",
        "��ʾisup��·״̬�������������ʾ�������õĵ�·",
        "����1: 1-��ʾ�ӿ����е�·,2-��ʾָ���ĵ�·\n\r"
        "����2: �������1Ϊ1����Ϊ�ӿ�ID,����Ϊ��·ID");
    
    
    /*ͳ����Ϣ*/
#if (SI_LMINT3 || SMSI_LMINT3)
    XOS_RegistCommand(isupId,
        siPrintErrSts,
        "showerrsts",
        "��ʾisup����ͳ������",
        "����: ��");
    
    XOS_RegistCommand(isupId,
        siPrintIntfSts,
        "showintfsts",
        "��ʾisup�ӿڵ�ͳ������",
        "����1: intfId \n\r"
        "����2: 1-transmitted stat | 2-received stat");
#endif
    
#ifdef DEBUGP
    XOS_RegistCommand(isupId,
        setDBG,
        "setdebug",
        "����DBG��Ϣ��ӡ",
        "����1: DBG���� \n\r"
        "0--��ʾ������DBGMASK���� \n\r"
        "1--��ʾDBGMASK_MI \n\r"
        "2--��ʾDBGMASK_UI \n\r"
        "3--��ʾDBGMASK_LI \n\r"
        "7--��ʾSIDBGMASK_PROG \n\r"
        "8--��ʾSIDBGMASK_WARN \n\r"
        "9--��ʾSIDBGMASK_CERR \n\r"
        "10-��ʾSIDBGMASK_ERR  \n\r"
        "11-��ʾSIDBGMASK_TMR    \n\r"
        "12-��ʾSIDBGMASK_STATE  \n\r"
        "13-��ʾSIDBGMASK_MF     \n\r"
        "14-��ʾSIDBGMASK_MSGERR \n\r"
        "15-��ʾSIDBGMASK_MSGSEG \n\r"
        "16-��ʾSIDBGMASK_MSGTX  \n\r"
        "17-��ʾSIDBGMASK_MSGRX  \n\r"
        "����2: [0-��ʾ�ر�] [1-��ʾ��]");
    
    
    XOS_RegistCommand(isupId,
        setDbgMask,
        "setdbgmask",
        "����DBG��Ϣ��ӡ",
        "����1: DBG���� \n\r"
        "0          ��ʾ�ر�����debug��ӡ \n\r"
        "0xFFFFFFFF ��ʾ������debug��ӡ \n\r"
        "0x00001    ��ʾDBGMASK_SI        \n\r"
        "0x00002    ��ʾDBGMASK_MI        \n\r"
        "0x00004    ��ʾDBGMASK_UI        \n\r"
        "0x00008    ��ʾDBGMASK_UI        \n\r"
        "0x00010    ��ʾDBGMASK_PI        \n\r"
        "0x00020    ��ʾDBGMASK_PLI       \n\r"
        "0x00100    ��ʾSIDBGMASK_PROG    \n\r"
        "0x00200    ��ʾSIDBGMASK_WARN    \n\r"
        "0x00400    ��ʾSIDBGMASK_CERR    \n\r"
        "0x00800    ��ʾSIDBGMASK_ERR     \n\r"
        "0x01000    ��ʾSIDBGMASK_TMR     \n\r"
        "0x02000    ��ʾSIDBGMASK_STATE   \n\r"
        "0x04000    ��ʾSIDBGMASK_MF      \n\r"
        "0x08000    ��ʾSIDBGMASK_MSGERR  \n\r"
        "0x10000    ��ʾSIDBGMASK_MSGSEG  \n\r"
        "0x20000    ��ʾSIDBGMASK_MSGTX   \n\r"
        "0x40000    ��ʾSIDBGMASK_MSGRX   \n\r"
        );
    
    XOS_RegistCommand(isupId,
        showDBG,
        "showdbgmask",
        "��ʾ�򿪵�DBG����",
        "����: ��");
#endif /* DEBUGP */
    
#ifdef STR_TST
    
    XOS_RegistCommand(isupId,
        setStrPar,
        "setStr",
        "����ѹ�����Բ���",
        " ����1: ������е������� ����2:ÿһ�����в��Ե�ʱ��, ����3:ÿtick������еĴ���");
    
    
    XOS_RegistCommand(isupId,
        StartStrTest,
        "StartStrTest",
        "��ʼѹ������",
        " ����: ��");
    
    XOS_RegistCommand(isupId,
        StopStrTest,
        "StopStrTest",
        "ֹͣѹ������",
        " ����: ��");
    
    XOS_RegistCommand(isupId,
        ShowStrTestResult,
        "ShowStrTestResult",
        "��ʾ���Խ��",
        " ����: ��");      
    
    XOS_RegistCommand(isupId,
        ShowStrCcCir,
        "ShowStrCcCir",
        "��ʾCC��·����",
        " ����: ��");  
    
    XOS_RegistCommand(isupId,
        ShowConTimerN,
        "ShowConTimerN",
        "��ʾConTimerN",
        " ����: ��");
    
    XOS_RegistCommand(isupId,
        ShowStrCirState,
        "ShowStrCirState",
        "��ʾStr circuit state",
        " ����: ��");
    
    
    XOS_RegistCommand(isupId,
        CfgData,
        "CfgData",
        "��ʾStr circuit state",
        " ����: ��");  
    
    XOS_RegistCommand(isupId,
        StartStrOnceTest,
        "StartStrOnceTest",
        "��ʼ����ѹ������",
        " ����: ��");
    
    XOS_RegistCommand(isupId,
        ResetStrTest,
        "ResetStrTest",
        "��������",
        " ����: ��");
    
    XOS_RegistCommand(isupId,
        ShowMsgInOneCircuit,
        "ShowMsgInOneCircuit",
        "�����·�ţ���ʾ������·���ͺͽ��յ���Ϣ��ͳ������",
        "����1: cirId");
    
    
#endif /* #ifdef STR_TST */
    
    
#ifdef SI_TEST_CP_OAM_SUPPORT
/************ Intf ****************/    
    XOS_RegistCommand(isupId,
        siTestAddIntf,
        "addintf",
        "����:����intf",
        " ����: ��");

	XOS_RegistCommand(isupId,
        siTestModIntf,
        "modintf",
        "����:�޸�intf",
        " ����: ��");

    XOS_RegistCommand(isupId,
        siTestDelIntf,
        "delintf",
        "����:ɾ��intf",
        " ����: ��");

/************ SubRoute ****************/
	XOS_RegistCommand(isupId,
        siTestAddSubRoute,
        "addsubroute",
        "����:����SubRoute",
        " ����: ��");

	XOS_RegistCommand(isupId,
        siTestModSubRoute,
        "modsubroute",
        "����:�޸�SubRoute",
        " ����: ��");

	XOS_RegistCommand(isupId,
        siTestDelSubRoute,
        "delsubroute",
        "����:ɾ��SubRoute",
        " ����: ��");


/*********** CirGrp ***************/
	    XOS_RegistCommand(isupId,
        siTestAddCirGrp,
        "addcirgrp",
        "����:����CirGrp",
        " ����: ��");

	    XOS_RegistCommand(isupId,
        siTestModCirGrp,
        "modcirgrp",
        "����:�޸�CirGrp",
        " ����: ��");


	    XOS_RegistCommand(isupId,
        siTestDelCirGrp,
        "delcirgrp",
        "����:ɾ��CirGrp",
        " ����: ��");
		
#endif /*SI_TEST_CP_OAM_SUPPORT*/
    
}


#endif  /*#ifdef SSI_WITH_CLI_ENABLED*/

/*added by wanglijun for set dbgmask from shell*/
#ifdef SI_DEBUG
U32 g_siDbgMask = DBGMASK_LI|DBGMASK_UI|DBGMASK_MI;
#else
U32 g_siDbgMask = 0;
#endif

Void siSetDbgMaskFromShell(U32 dbgMask)
{
  g_siDbgMask = dbgMask;
#ifdef DEBUGP
  siCb.init.dbgMask = g_siDbgMask;
#endif
  RETVOID;
}




