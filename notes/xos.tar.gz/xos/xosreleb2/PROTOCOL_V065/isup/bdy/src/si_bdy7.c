/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

    Name:     ISUP - body 7

    Type:     C source file

    Desc:     C source code for ISUP timer functions. These functions
              are called to start/stop the timers and the action
              taken upon a timer's expiry.

    File:     ci_bdy7.c

    Sid:      ci_bdy7.c@@/main/9 - Wed Jul 25 13:20:59 2001
 
    Prg:      rh

*********************************************************************21*/


/************************************************************************

     Note: 

     This file has been extracted to support the following options:

     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif

************************************************************************/


/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.             description
*     --------    ----------------------------------------------
*
*/


/* header include files (.h) */

#include "envopt.h"        /* environment options                          */  
#include "envdep.h"        /* environment dependent                        */
#include "envind.h"        /* environment independent                      */

#include "gen.h"           /* general layer                                */
#include "ssi.h"           /* system services                              */
#include "cm_ss7.h"        /* general SS7 layer                            */
#include "cm_hash.h"       /* hash-list header                             */
#include "lsi.h"           /* layer management                             */
#include "si_mf.h"         /* message functions                            */
#include "cm5.h"           /* timers                                       */
#include "ci_db.h"         /* ISUP data base                               */
#include "sit.h"           /* ISUP                                         */
#include "snt.h"           /* MTP3                                         */
#ifdef SI_SPT
#include "spt.h"           /* SCCP                                         */
#endif
#ifdef SI_FTHA
#include "sht.h"           /* sht interface */
#endif
#include "si.h"            /* ISUP                                         */
#include "si_err.h"        /* ISUP error                                   */
#ifdef IW
#include "cm_atm.h"          /* common ATM defines                 */
#include "cm_cc.h"           /* Common Call Control Hash Defs      */
#include "rmt.h"             /* resource manager defines           */
#include "cct.h"             /* Call Control Interface Header      */
#include "liw.h"             /* ISUP PSIF Layer Management Headers */
#include "iw.h"              /* ISUP PSIF Hash Defines             */
#include "iw_err.h"          /* ISUP PSIF Error Defines            */
#include "iw_ptli.h"         /* o/g SIT i/f funcs. hash defs       */
#endif

#ifdef ZI
#include "cm_pftha.h"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.h"       /* common PSF */
#include "cm_psfft.h"      /* common PSF */
#endif
#include "lzi.h"           /* ISUP PSF management */
#include "zi.h"            /* ISUP PSF */
#include "zi_err.h"        /* ISUP PSF error codes */
#endif /* ZI */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer                                */
#include "ssi.x"           /* system services                              */
#include "cm_ss7.x"        /* general SS7 layer                            */
#include "cm_lib.x"        /* common library functions                     */
#include "cm_hash.x"       /* hash-list structure                          */
#include "lsi.x"           /* layer management                             */
#include "si_mf.x"         /* message functions                            */
#include "cm5.x"           /* timers                                       */
#include "ci_db.x"         /* ISUP data base                               */
#include "sit.x"           /* ISUP                                         */
#include "snt.x"           /* MTP3                                         */
#ifdef SI_SPT
#include "spt.x"           /* SCCP                                         */
#endif
#ifdef SI_FTHA
#include "sht.x"           /* sht interface */
#endif
#include "si.x"            /* ISUP                                         */

#ifdef IW
#include "cm_atm.x"          /* common ATM defines                  */
#include "cm_cc.x"           /* Common Call Control Typedefs        */
#include "rmt.x"             /* resource manager function decls.    */
#include "cct.x"             /* Call Control Interface              */
#include "liw.x"             /* ISUP PSIF Layer Management typedefs */
#include "iw.x"              /* ISUP PSIF Typedefs                  */
#endif
#ifdef ZI 
#include "cm_pftha.x"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.x"       /* common PSF */
#include "cm_psfft.x"      /* common PSF */
#endif
#include "lzi.x"           /* ISUP PSF management */
#include "zi.x"            /* ISUP PSF */
#endif /* ZI */


/* local defines */


/* local externs */
PRIVATE S16 siRelRspTmrExp ARGS((SiCon *con));


/* forward references */


/* public variable declarations */


/* support functions */

  
/*
*
*       Fun:    siActvTmr
*
*       Desc:   Processes Timing queues for ISUP
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siActvTmr
(
Void
)
#else
PUBLIC S16 siActvTmr()
#endif
{
   TRC2(siActvTmr)

   if( siCb.tmrFlag )
   {
      RETVALUE(ROK);
   }
   cmPrcTmr(&siCb.conTqCp, siCb.conTq, siConTmrEv);
   cmPrcTmr(&siCb.nsapTqCp, siCb.nsapTq, siNSAPTmrEv);
   cmPrcTmr(&siCb.intfCbTqCp, siCb.intfCbTq, siIntfTmrEv);
   cmPrcTmr(&siCb.cirTqCp, siCb.cirTq, siCirTmrEv);
   cmPrcTmr(&siCb.cirGrpTqCp, siCb.cirGrpTq, siCirGrTmrEv);

   RETVALUE(ROK);
} /* end of siActvTmr */

  
/*
*
*       Fun:   siStartNSAPTmr
*
*       Desc:  start network SAP timer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy7.c
*
*/

#ifdef ANSI
PUBLIC S16 siStartNSAPTmr
(
S16       timer,
SiNSAPCb  *cb
)
#else
PUBLIC S16 siStartNSAPTmr(timer, cb)
S16      timer;
SiNSAPCb *cb;
#endif
{
   U16 wait;
   CmTmrArg arg;

   TRC2(siStartNSAPTmr)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (cb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "Null NSAP control block.\n"));
      SILOGERROR(ERRCLS_DEBUG, ESI822, (ErrVal) 0, 
                 "siStartNSAPTmr() Failed, control block is NULLP");
      RETVALUE(ROK);
   }
#endif
   wait = 0;

   switch (timer)
   {
      case TMR_TINT:
         if (cb->cfg.tINT.enb == TRUE)
            wait = cb->cfg.tINT.val;
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid timer : 0x%x %d\n", timer, timer));  
         SILOGERROR(ERRCLS_DEBUG, ESI823, (ErrVal) 0, 
                 "siStartNSAPTmr() Failed, invalid timer event");
         RETVALUE(ROK);
#endif
   }
   if (wait != 0)
   {
      arg.tq     = siCb.nsapTq;
      arg.tqCp   = &siCb.nsapTqCp;
      arg.timers = cb->timers;
      arg.cb     = (PTR)cb;
      arg.evnt   = timer;
      arg.wait   = wait;
      arg.tNum   = NOTUSED;
      arg.max    = MAXSIMTIMER;

      SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
                            "NSAP TMR: + %d 0x%x [val:%d] \n",
                            timer, timer, wait));  
      cmPlcCbTq(&arg);
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                             "NSAP TMR 0x%x %d has 0 timeout \n",
                             timer, timer));  
   } 
   RETVALUE(ROK);
} /* end of siStartNSAPTmr */


/*
 *
 *      Fun:   siRestartNSAPTimers
 *
 *      Desc:  If any  sap is unbound , restart timers and send
 *             bind req
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  ci_bdy7.c
 *
 */

#ifdef ANSI
PUBLIC S16 siRestartNSAPTimers
(
Void
)
#else
PUBLIC S16 siRestartNSAPTimers()
#endif
{

   S16 i;
   SiNSAPCb  *nCb;
#ifdef IW   
   IwRmSap   *rCb;
#endif   

   TRC2(siRestartNSAPTimers)

   /* go through sap list ,send bind req , and start timers */
   for (i=0; i< siCb.genCfg.nmbNSaps; i++)
   {
      if ((nCb = SIMTPSAP(i)) != NULLP)
      {
         if (nCb->state == SI_WT_BNDCFM)
         {
            siStartNSAPTmr(TMR_TINT, nCb);
            SiLiSntBndReq(&nCb->pst, nCb->suId, nCb->spId, nCb->srvInfo);
         }
      }
   }

#ifdef SI_SPT
   for (i=0; i< siCb.genCfg.nmbNSaps; i++)
   {
      if ((nCb = SISCCPSAP(i)) != NULLP)
      {
         if (nCb->state == SI_WT_BNDCFM)
         {
            siStartNSAPTmr(TMR_TINT, nCb);
            SiLiSptBndReq(&nCb->pst, nCb->suId, nCb->spId, (U8) SS_ISUP);
         }
      }
   }
#endif

#ifdef IW
   if ((rCb = IWGETRMSAP(0)) != NULLP)
   {
      if (rCb->state == IW_BND_CONT)
      {
         iwStartRmSapTmr((PTR)rCb, TMR_TBNDCFM);
         IwLiRmtBndReq(&rCb->pst, rCb->suId, rCb->spId);
      }
   }
#endif

   RETVALUE(ROK);

} /* siRestartNSAPTimers */

  
/*
*
*       Fun:    siRmvNSAPTq
*
*       Desc:   Removes NSAP Control Block from Timing Queue
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siRmvNSAPTq
(
SiNSAPCb *cb,
U8 tmrNum 
)
#else
PUBLIC S16 siRmvNSAPTq(cb, tmrNum)
SiNSAPCb *cb;
U8 tmrNum; 
#endif
{
   CmTmrArg arg;

   TRC2(siRmvNSAPTq)

   arg.tq     = siCb.nsapTq;
   arg.tqCp   = &siCb.nsapTqCp;
   arg.timers = cb->timers;
   arg.cb     = (PTR)cb;
   arg.evnt   = NOTUSED;
   arg.wait   = NOTUSED;
   arg.tNum   = tmrNum;
   arg.max    = MAXSIMTIMER;

   SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf, "NSAP TMR: - %d 0x%x \n",
                         tmrNum, tmrNum)); 
   cmRmvCbTq(&arg);

   RETVALUE(ROK);
} /* end of siRmvCirTq */

  
/*
*
*       Fun:   siStartConTmr
*
*       Desc:  start network connection timer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy7.c
*
*/

#ifdef ANSI
PUBLIC S16 siStartConTmr
(
S16 timer,
SiCon *con,
SiUpSAPCb *cb
)
#else
PUBLIC S16 siStartConTmr(timer, con, cb)
S16 timer;
SiCon *con;
SiUpSAPCb *cb;
#endif
{
   U16 wait;
   CmTmrArg arg;

   TRC2(siStartConTmr)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (cb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "control block is null !\n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI824, (ErrVal) 0, 
                 "siStartConTmr() Failed, control block is NULLP");
      RETVALUE(ROK);
   }
#endif
   wait = 0;
   switch(timer)
   {
      case TMR_T1I:
         if (cb->cfg.tmr.t1.enb == TRUE)
            wait = cb->cfg.tmr.t1.val;
         break;
      case TMR_T1O:
         if (cb->cfg.tmr.t1.enb == TRUE)
            wait = cb->cfg.tmr.t1.val;
         break;
      case TMR_T2I:
         if (cb->cfg.tmr.t2.enb == TRUE)
            wait = cb->cfg.tmr.t2.val;
         break;
      case TMR_T2O:
         if (cb->cfg.tmr.t2.enb == TRUE)
            wait = cb->cfg.tmr.t2.val;
         break;
      case TMR_T5I:
         if (cb->cfg.tmr.t5.enb == TRUE)
            wait = cb->cfg.tmr.t5.val;
         break;
      case TMR_T5O:
         if (cb->cfg.tmr.t5.enb == TRUE)
            wait = cb->cfg.tmr.t5.val;
         break;
      case TMR_T6I:
         if (cb->cfg.tmr.t6.enb == TRUE)
            wait = cb->cfg.tmr.t6.val;
         break;
      case TMR_T6O:
         if (cb->cfg.tmr.t6.enb == TRUE)
            wait = cb->cfg.tmr.t6.val;
         break;
      case TMR_T7I:
         if (cb->cfg.tmr.t7.enb == TRUE)
            wait = cb->cfg.tmr.t7.val;
         break;
      case TMR_T7O:
         if (cb->cfg.tmr.t7.enb == TRUE)
            wait = cb->cfg.tmr.t7.val;
         break;
      case TMR_T8:
         if (cb->cfg.tmr.t8.enb == TRUE)
            wait = cb->cfg.tmr.t8.val;
         break;
      case TMR_T9:
         if (cb->cfg.tmr.t9.enb == TRUE)
            wait = cb->cfg.tmr.t9.val;
         break;
       case TMR_T31:
         if (cb->cfg.tmr.t31.enb == TRUE)
            wait = cb->cfg.tmr.t31.val;
         break;
     case TMR_T33I:
         if (cb->cfg.tmr.t33.enb == TRUE)
            wait = cb->cfg.tmr.t33.val;
         break;
     case TMR_T33O:
         if (cb->cfg.tmr.t33.enb == TRUE)
            wait = cb->cfg.tmr.t33.val;
         break;
     case TMR_TCCRI:
         if (cb->cfg.tmr.tCCR.enb == TRUE)
            wait = cb->cfg.tmr.tCCR.val;
         break;
     case TMR_T27:
         if (cb->cfg.tmr.t27.enb == TRUE)
            wait = cb->cfg.tmr.t27.val;
         break;
     case TMR_T36I:
         if (cb->cfg.tmr.t36.enb == TRUE)
            wait = cb->cfg.tmr.t36.val;
         break;
     case TMR_T36O:
         if (cb->cfg.tmr.t36.enb == TRUE)
            wait = cb->cfg.tmr.t36.val;
         break;
     case TMR_T34:
         if (cb->cfg.tmr.t34.enb == TRUE)
            wait = cb->cfg.tmr.t34.val;
         break;
#if (SS7_ETSI || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      case TMR_TECT:
         if (cb->cfg.tmr.tECT.enb == TRUE)
            wait = cb->cfg.tmr.tECT.val;
         break;
#endif
      case TMR_TRELRSP:
         if (cb->cfg.tmr.tRELRSP.enb == TRUE)
            wait = cb->cfg.tmr.tRELRSP.val;
         break;

      case TMR_TFNLRELRSP:
         if (cb->cfg.tmr.tFNLRELRSP.enb == TRUE)
            wait = cb->cfg.tmr.tFNLRELRSP.val;
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid timer : 0x%x %d\n", timer, timer));  
         SILOGERROR(ERRCLS_DEBUG, ESI825, (ErrVal) 0, 
                 "siStartConTmr() Failed, invalid timer event");
         RETVALUE(ROK);
#endif
   }
   if (wait != 0)
   {
      arg.tq = siCb.conTq;
      arg.tqCp = &siCb.conTqCp;
      arg.timers = con->timers;
      arg.cb = (PTR)con;
      arg.evnt = timer;
      arg.wait = wait;
      arg.tNum = NOTUSED;
      arg.max = MAXSIMTIMER;
      SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
              "CON TMR: + %d 0x%x [val:%d] \n", timer, timer, wait));  
      cmPlcCbTq(&arg);
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "CON TMR 0x%x %d has 0 timeout \n", timer, timer));  
   } 
   RETVALUE(ROK);
} /* end of siStartConTmr */

  
/*
*
*       Fun:    siRmvConTq
*
*       Desc:   Removes Connection from Timing Queue
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siRmvConTq
(
SiCon *con,
U8 tmrNum
)
#else
PUBLIC S16 siRmvConTq(con, tmrNum)
SiCon *con;
U8 tmrNum;
#endif
{
   CmTmrArg arg;

   TRC2(siRmvConTq)
   arg.tq = siCb.conTq;
   arg.tqCp = &siCb.conTqCp;
   arg.timers = con->timers;
   arg.cb = (PTR)con;
   arg.evnt = NOTUSED;
   arg.wait = NOTUSED;
   arg.tNum = tmrNum;
   arg.max = MAXSIMTIMER;
   SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf, "CON TMR: - %d 0x%x \n",
                         tmrNum, tmrNum)); 
   cmRmvCbTq(&arg);
   RETVALUE(ROK);
} /* end of siRmvConTq */

  
/*
*
*       Fun:   siStartCirTmr
*
*       Desc:  start circuit timer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy7.c
*
*/

#ifdef ANSI
PUBLIC S16 siStartCirTmr
(
S16 timer,
SiCirCb *cir
)
#else
PUBLIC S16 siStartCirTmr(timer, cir)
S16 timer;
SiCirCb *cir;
#endif
{
   U16 wait;
   CmTmrArg arg;

   TRC2(siStartCirTmr)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "circuit block is null for starting a ckt tmr\n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI826, (ErrVal) 0, 
                 "siStartCirTmr() Failed, control block is NULLP");
      RETVALUE(ROK);
   }
#endif
   wait = 0;
   switch(timer)
   {
      case TMR_T3:
         if (cir->cfg.cirTmr.t3.enb == TRUE)
            wait = cir->cfg.cirTmr.t3.val;
         break;
      case TMR_T12:
         if (cir->cfg.cirTmr.t12.enb == TRUE)
            wait = cir->cfg.cirTmr.t12.val;
         break;
      case TMR_T13:
         if (cir->cfg.cirTmr.t13.enb == TRUE)
            wait = cir->cfg.cirTmr.t13.val;
         break;
      case TMR_T14:
         if (cir->cfg.cirTmr.t14.enb == TRUE)
            wait = cir->cfg.cirTmr.t14.val;
         break;
      case TMR_T15:
         if (cir->cfg.cirTmr.t15.enb == TRUE)
            wait = cir->cfg.cirTmr.t15.val;
         break;
      case TMR_T16:
         if (cir->cfg.cirTmr.t16.enb == TRUE)
            wait = cir->cfg.cirTmr.t16.val;
         break;
      case TMR_T17:
         if (cir->cfg.cirTmr.t17.enb == TRUE)
            wait = cir->cfg.cirTmr.t17.val;
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                     "invalid ckt timer : %d\n", timer));  
         SILOGERROR(ERRCLS_DEBUG, ESI827, (ErrVal) 0, 
                 "siStartCirTmr() Failed, invalid timer event");
         RETVALUE(ROK);
#endif
   }
   if (wait != 0)
   {
      arg.tq = siCb.cirTq;
      arg.tqCp = &siCb.cirTqCp;
      arg.timers = cir->timers;
      arg.cb = (PTR)cir;
      arg.evnt = timer;
      arg.wait = wait;
      arg.tNum = NOTUSED;
      arg.max = MAXSIMTIMER;
      SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
              "CKT TMR: + %d 0x%x [val:%d] \n", timer, timer, wait));  
      cmPlcCbTq(&arg);
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "CKT TMR %d has 0 timeout \n", timer));  
   } 
   RETVALUE(ROK);
} /* end of siStartCirTmr */

  
/*
*
*       Fun:    siRmvCirTq
*
*       Desc:   Removes Circuit Control Block from Timing Queue
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siRmvCirTq
(
SiCirCb *cir,
U8 tmrNum 
)
#else
PUBLIC S16 siRmvCirTq(cir, tmrNum)
SiCirCb *cir;
U8 tmrNum; 
#endif
{
   CmTmrArg arg;

   TRC2(siRmvCirTq)

   arg.tq = siCb.cirTq;
   arg.tqCp = &siCb.cirTqCp;
   arg.timers = cir->timers;
   arg.cb = (PTR)cir;
   arg.evnt = NOTUSED;
   arg.wait = NOTUSED;
   arg.tNum = tmrNum;
   arg.max = MAXSIMTIMER;
   SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
      "CKT TMR: - %d 0x%x \n", tmrNum, tmrNum)); 
   cmRmvCbTq(&arg);

   RETVALUE(ROK);
} /* end of siRmvCirTq */

  
/*
*
*       Fun:   siStartCirGrTmr
*
*       Desc:  start circuit group timer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy7.c
*
*/

#ifdef ANSI
PUBLIC S16 siStartCirGrTmr
(
S16 timer,
SiCirGrp *cirGr
)
#else
PUBLIC S16 siStartCirGrTmr(timer, cirGr)
S16 timer;
SiCirGrp *cirGr;
#endif
{
   U16 wait;
   CmTmrArg arg;

   TRC2(siStartCirGrTmr)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (cirGr == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "cirGr is null for starting the timer !\n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI828, (ErrVal) 0, 
                 "siStartCirGrTmr() Failed, control block is NULLP");
      RETVALUE(ROK);
   }
#endif
   wait = 0;
   switch(timer)
   {
      case TMR_T18:
         if (siCb.genCfg.cirGrTmr.t18.enb == TRUE)
            wait = siCb.genCfg.cirGrTmr.t18.val;
         break;
      case TMR_T19:
         if (siCb.genCfg.cirGrTmr.t19.enb == TRUE)
            wait = siCb.genCfg.cirGrTmr.t19.val;
         break;
      case TMR_T20:
         if (siCb.genCfg.cirGrTmr.t20.enb == TRUE)
            wait = siCb.genCfg.cirGrTmr.t20.val;
         break;
      case TMR_T21:
         if (siCb.genCfg.cirGrTmr.t21.enb == TRUE)
            wait = siCb.genCfg.cirGrTmr.t21.val;
         break;
      case TMR_T22:
         if (siCb.genCfg.cirGrTmr.t22.enb == TRUE)
            wait = siCb.genCfg.cirGrTmr.t22.val;
         break;
      case TMR_T23:
         if (siCb.genCfg.cirGrTmr.t23.enb == TRUE)
            wait = siCb.genCfg.cirGrTmr.t23.val;
         break;
      case TMR_T28:
         if (siCb.genCfg.cirGrTmr.t28.enb == TRUE)
            wait = siCb.genCfg.cirGrTmr.t28.val;
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid timer : 0x%x %d\n", timer, timer));  
         SILOGERROR(ERRCLS_DEBUG, ESI829, (ErrVal) 0, 
                 "siStartCirGrTmr() Failed, invalid timer event");
         RETVALUE(ROK);
#endif
   }
   if (wait != 0)
   {
      arg.tq = siCb.cirGrpTq;
      arg.tqCp = &siCb.cirGrpTqCp;
      arg.timers = cirGr->timers;
      arg.cb = (PTR)cirGr;
      arg.evnt = timer;
      arg.wait = wait;
      arg.tNum = NOTUSED;
      arg.max = MAXSIMTIMER;
      SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
              "GRP TMR: + %d 0x%x [val:%d] \n", timer, timer, wait));  
      cmPlcCbTq(&arg);
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "GRP TMR %d has 0 timeout \n", timer));  
   } 
   RETVALUE(ROK);
} /* end of siStartCirGrTmr */

  
/*
*
*       Fun:    siRmvCirGrpTq
*
*       Desc:   Removes Circuit Group Control Block from Timing Queue
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siRmvCirGrpTq
(
SiCirGrp *cirGr,
U8 tmrNum 
)
#else
PUBLIC S16 siRmvCirGrpTq(cirGr, tmrNum)
SiCirGrp *cirGr;
U8 tmrNum; 
#endif
{
   CmTmrArg arg;

   TRC2(siRmvCirGrpTq)

   arg.tq = siCb.cirGrpTq;
   arg.tqCp = &siCb.cirGrpTqCp;
   arg.timers = cirGr->timers;
   arg.cb = (PTR)cirGr;
   arg.evnt = NOTUSED;
   arg.wait = NOTUSED;
   arg.tNum = tmrNum;
   arg.max = MAXSIMTIMER;
   SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
      "GRP TMR: - %d 0x%x \n", tmrNum, tmrNum)); 
   cmRmvCbTq(&arg);
   RETVALUE(ROK);
} /* end of siRmvCirGrpTq */

  
/*
*
*       Fun:   siStartIntfTmr
*
*       Desc:  start Dpc timer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy7.c
*
*/

#ifdef ANSI
PUBLIC S16 siStartIntfTmr
(
S16 timer,
SiIntfCb *siIntfCb
)
#else
PUBLIC S16 siStartIntfTmr(timer, siIntfCb)
S16 timer;
SiIntfCb *siIntfCb;
#endif
{
   U16 wait;
   CmTmrArg arg;

   TRC2(siStartIntfTmr)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "ERR: DPC TMR: siIntfCb null !\n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI830, (ErrVal) 0, 
                 "siStartIntfTmr() Failed, control block is NULLP");
      RETVALUE(ROK);
   }
#endif
   wait = 0;
   switch(timer)
   {
      case TMR_T4:
         if (siIntfCb->cfg.dpcCbTmr.t4.enb == TRUE)
            wait = siIntfCb->cfg.dpcCbTmr.t4.val;
         break;

      case TMR_PAUSE:
         if (siIntfCb->cfg.dpcCbTmr.tPAUSE.enb == TRUE)
            wait = siIntfCb->cfg.dpcCbTmr.tPAUSE.val;
         break;

      case TMR_TSTAENQ:
#ifdef SNT2
         if (siIntfCb->cfg.dpcCbTmr.tSTAENQ.enb == TRUE)
            wait = siIntfCb->cfg.dpcCbTmr.tSTAENQ.val;
#endif
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid dpc tmr %d\n", timer));  
         SILOGERROR(ERRCLS_DEBUG, ESI831, (ErrVal) 0, 
                 "siStartIntfTmr() Failed, invalid timer event");
         RETVALUE(ROK);
#endif
   }
   if (wait != 0)
   {
      arg.tq = siCb.intfCbTq;
      arg.tqCp = &siCb.intfCbTqCp;
      arg.timers = siIntfCb->timers;
      arg.cb = (PTR)siIntfCb;
      arg.evnt = timer;
      arg.wait = wait;
      arg.tNum = NOTUSED;
      arg.max = MAXSIMTIMER;
      SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
              "DPC TMR: + %d 0x%x [val:%d] \n", timer, timer, wait));  
      cmPlcCbTq(&arg);
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "DPC TMR %d has 0 timeout \n", timer));  
   } 
   RETVALUE(ROK);
} /* end of siStartIntfTmr */

  
/*
*
*       Fun:    siRmvIntfTq
*
*       Desc:   Removes DPC Control Block from Timing Queue
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
#ifdef ANSI
PUBLIC S16 siRmvIntfTq
(
SiIntfCb *siIntfCb,
U8 tmrNum 
)
#else
PUBLIC S16 siRmvIntfTq(siIntfCb, tmrNum)
SiIntfCb *siIntfCb;
U8 tmrNum; 
#endif
{
   CmTmrArg arg;

   TRC2(siRmvIntfTq)

   arg.tq = siCb.intfCbTq;
   arg.tqCp = &siCb.intfCbTqCp;
   arg.timers = siIntfCb->timers;
   arg.cb = (PTR)siIntfCb;
   arg.evnt = NOTUSED;
   arg.wait = NOTUSED;
   arg.tNum = tmrNum;
   arg.max = MAXSIMTIMER;
   SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
      "DPC TMR: - %d 0x%x \n", tmrNum, tmrNum)); 
   cmRmvCbTq(&arg);

   RETVALUE(ROK);
} /* end of siRmvIntfTq */

  
/*
*
*       Fun:    siStopNSAPTmr
*
*       Desc:   Stops given NSAP Timer
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
#ifdef ANSI
PUBLIC S16 siStopNSAPTmr
(
SiNSAPCb *cb,
S16     timer
)
#else
PUBLIC S16 siStopNSAPTmr(cb, timer)
SiNSAPCb *cb;
S16     timer;
#endif
{
   U8 tmrNum; 

   TRC2(siStopNSAPTmr)

   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((cb->timers[tmrNum].tmrEvnt == timer) || (timer == TMR_ALL))
         siRmvNSAPTq(cb, tmrNum);

   RETVALUE(ROK);
} /* end of siStopNSAPTmr */

  
/*
*
*       Fun:    siStopIntfTmr
*
*       Desc:   Stops given DPC Timer
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
#ifdef ANSI
PUBLIC S16 siStopIntfTmr
(
SiIntfCb *siIntfCb,
S16     timer
)
#else
PUBLIC S16 siStopIntfTmr(siIntfCb, timer)
SiIntfCb *siIntfCb;
S16     timer;
#endif
{
   U8 tmrNum; 

   TRC2(siStopIntfTmr)

   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((siIntfCb->timers[tmrNum].tmrEvnt == timer) || (timer == TMR_ALL))
         siRmvIntfTq(siIntfCb, tmrNum);
   RETVALUE(ROK);
} /* end of siStopIntfTmr */

  
/*
*
*       Fun:    siStopConTmr
*
*       Desc:   Stops all Connection Timers
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siStopConTmr
(
SiCon *con,
S16 timer
)
#else
PUBLIC S16 siStopConTmr(con, timer)
SiCon *con;
S16 timer;
#endif
{
   U8 tmrNum; 

   TRC2(siStopConTmr)

   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt == timer) || (timer == TMR_ALL))
         siRmvConTq(con, tmrNum);
   RETVALUE(ROK);
} /* end of siStopConTmr */

  
/*
*
*       Fun:    siStopCirTmr
*
*       Desc:   Stops given Circuit Timer
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
#ifdef ANSI
PUBLIC S16 siStopCirTmr
(
SiCirCb *cir,
S16     timer
)
#else
PUBLIC S16 siStopCirTmr(cir, timer)
SiCirCb *cir;
S16     timer;
#endif
{
   U8 tmrNum; 

   TRC2(siStopCirTmr)

   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if (cir->timers[tmrNum].tmrEvnt == timer) 
         siRmvCirTq(cir, tmrNum);
   RETVALUE(ROK);
}

  
/*
*
*       Fun:    siStopAllCirTmr
*
*       Desc:   Stops all Circuit Timers
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siStopAllCirTmr
(
SiCirCb *cir
)
#else
PUBLIC S16 siStopAllCirTmr(cir)
SiCirCb *cir;
#endif
{
   U8 tmrNum; 

   TRC2(siStopAllCirTmr)

   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if (cir->timers[tmrNum].tmrEvnt != TMR_NONE)
         siRmvCirTq(cir, tmrNum);
   RETVALUE(ROK);
} /* end of siStopAllCirTmr */

  
/*
*
*       Fun:    siStopCirGrTmr
*
*       Desc:   Stops all Circuit Group Timers
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siStopCirGrTmr
(
SiCirGrp *cirGr,
U8 tmrNum
)
#else
PUBLIC S16 siStopCirGrTmr(cirGr, tmrNum)
SiCirGrp *cirGr;
U8 tmrNum;
#endif
{
   U8 i; 

   TRC2(siStopCirGrTmr)

   for (i = 0; i < MAXSIMTIMER; i++)
      if (cirGr->timers[i].tmrEvnt != TMR_NONE)
         if ((tmrNum == (U8) TMR_ALL) || (cirGr->timers[i].tmrEvnt == tmrNum))
            siRmvCirGrpTq(cirGr, i);
   RETVALUE(ROK);
} /* end of siStopCirGrTmr */


/*
*
*       Fun:   siNSAPTmrEv
*
*       Desc:  Processes an NSAP timer expiry event
*              
*       Ret:   ROK - ok 
*
*       Notes: none
*
*       File:  ci_bdy7.c
*
*/
#ifdef ANSI
PUBLIC Void siNSAPTmrEv 
(
PTR cb,
S16 event
)
#else
PUBLIC Void siNSAPTmrEv (cb, event)
PTR cb;
S16 event;
#endif
{
   SiNSAPCb *nCb;

/* si003.220 - Modification for correct type cast.
 */
   U8 event1;
    
   TRC2(siNSAPTmrEv)
   event1 = (U8)event;
   nCb = (SiNSAPCb *) cb;

   /*if in the process of data swapping, 
     rstTmr flag will be turned on and all
     the timers restarted */
   if (siCb.rstTmr)
   {
      siStartNSAPTmr(event, nCb);
      RETVOID;
   }

   SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
                          "%s\n\nNSAP TMR: x %d 0x%x \n", SI_STR, event, 
                         event));

   switch (event)
   {
      case TMR_TINT:
         
         if ((nCb->cfg.sapType == SAP_MTP) ||
            (nCb->cfg.sapType == SAP_M3UA))  
         {
#ifdef SNT2
            if (nCb->state == SI_WT_BNDCFM)
            {
               if (nCb->bndRetryCnt < SI_MAX_INTRETRY)
               {
                  nCb->bndRetryCnt++;
                  siStartNSAPTmr(TMR_TINT, nCb);
                  SiLiSntBndReq(&nCb->pst, nCb->suId, nCb->spId, nCb->srvInfo);
               }
               else
               {
                  nCb->bndRetryCnt = 0;
                  nCb->state       = SI_UNBND;
#if (SI_LMINT3 || SMSI_LMINT3)
/* si003.220 - Modification. Modified parameter into event1 to have correct
 * type.
 */
                  siInitUstaDgn(LSI_USTA_DGNVAL_SUID, (PTR) &nCb->suId,
                                LSI_USTA_DGNVAL_EVENT, (PTR) &event1,
                                LSI_USTA_DGNVAL_NONE, NULLP,
                                LSI_USTA_DGNVAL_NONE, NULLP);
                  siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                                LCM_EVENT_BND_FAIL, LSI_CAUSE_TMR_EXP, TRUE);
#endif
                  RETVOID;
               }
            }
#endif /* SNT2 */
            RETVOID;
         }
#ifdef SI_SPT
         if (nCb->cfg.sapType == SAP_SCCP)
         {
#ifdef SPT2
            if (nCb->state == SI_WT_BNDCFM)
            {
               if (nCb->bndRetryCnt < SI_MAX_INTRETRY)
               {
                  nCb->bndRetryCnt++;
                  siStartNSAPTmr(TMR_TINT, nCb);
                  SiLiSptBndReq(&nCb->pst, nCb->suId, nCb->spId, (U8) SS_ISUP);
               }
               else
               {
                  nCb->bndRetryCnt = 0;
                  nCb->state       = SI_UNBND;
#if (SI_LMINT3 || SMSI_LMINT3)
/* si003.220 - Modification. Modified parameter into event1 to have correct
 *  * type.
 *   */
                  siInitUstaDgn(LSI_USTA_DGNVAL_SUID, (PTR) &nCb->suId,
                                LSI_USTA_DGNVAL_EVENT, (PTR) &event1,
                                LSI_USTA_DGNVAL_NONE, NULLP,
                                LSI_USTA_DGNVAL_NONE, NULLP);
                  siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                                LCM_EVENT_BND_FAIL, LSI_CAUSE_TMR_EXP, TRUE);
#endif
                  RETVOID;
               }
            }
#endif /* SPT2 */
            RETVOID;
         }
#endif /* SI_SPT */
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid timer %d expired\n", event));  
         SILOGERROR(ERRCLS_DEBUG, ESI832, (ErrVal) 0, 
                 "siNSAPTmrEv() Failed, invalid timer event");
         RETVOID;
#endif
   }

   RETVOID;
}/* siNSAPTmrEv */

  
/*
*
*       Fun:    siIntfTmrEv
*
*       Desc:   Processes DPC control block Timing Events
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
#ifdef ANSI
PUBLIC Void siIntfTmrEv
(
PTR cb,
S16 event
)
#else
PUBLIC Void siIntfTmrEv(cb, event)
PTR cb;
S16 event;
#endif
{
   SiCauseDgn causeDgn;
   SiCirKey   key;
   SiUpSAPCb  *tCb;
   SiIntfCb    *siIntfCb;
   SiCirCb    *cir;
   S16        ret;
   U16      idx;

   TRC2(siIntfTmrEv)

   siIntfCb = (SiIntfCb *) cb;

   /*if in the process of data swapping, 
     rstTmr flag will be turned on and all
     the timers restarted */
   if (siCb.rstTmr)
   {
      siStartIntfTmr(event, siIntfCb);
      RETVOID;
   }

   SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
          "%s\n\nDPC TMR: x %d 0x%x \n", SI_STR, event, event));  
   switch (event)
   {
      case TMR_T4:
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case TMR_T4 \n"));   
         key.k3.intfId = siIntfCb->cfg.intfId;
         siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_INTF);
         if (cir == NULLP)
            break;
         else
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            if (siChkCirIntf(cir) != ROK)
               RETVOID;
#endif
            /* start user part test timer  and send UPT msg*/
            siStartIntfTmr(TMR_T4, siIntfCb);
            /* si009.220, MODIFIED: change the interface valid flag 
             * to FALSE, not checking the interface control block 
             * state in siGenCirMsg (siGenPdu) function
             */
            siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                        cir->phyDpc, FALSE, cir->pIntfCb->cfg.swtch, 
                        M_USRPARTT, MI_USRPARTT, NULLP, 
                        cir->pIntfCb->cfg.ssf, cir->pIntfCb->cfg.nwId);
#ifdef SI_PROVE
            SPrint("Send user part test message  \n");
#endif
         }
         break;
         
      case TMR_PAUSE:
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case TMR_PAUSE \n"));

         if (NULLP == (tCb = SIUPSAP(siIntfCb->cfg.sapId)))
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SILOGERROR(ERRCLS_DEBUG, ESI833, (ErrVal) siIntfCb->cfg.swtch,
                       "siIntfTmrEv(), can't find upper SAP for the switch");
#endif
            RETVOID;
         }
         /* initialize cause diagnostic structure */
         MFINITELMT(&tCb->mfMsgCtl, ret, (ElmtHdr *) NULLP, 
                    (ElmtHdr *) &causeDgn, &meCauseIndV, (U8) PRSNT_DEF, 
                    tCb->cfg.swtch, (U32) MF_ISUP);

         causeDgn.causeVal.pres = PRSNT_NODEF;
         causeDgn.causeVal.val  = SIT_CCTMPFAIL;
         causeDgn.recommend.pres = NOTPRSNT;
/* si029.220: Addition - added INDIA processing */
#if SS7_INDIA
         if (tCb->cfg.swtch == LSI_SW_INDIA)
            causeDgn.dgnVal.pres = NOTPRSNT;
#endif
         /* find circuit */
         key.k3.intfId = siIntfCb->cfg.intfId;
         cir = NULLP;
         for (idx = 0;; idx++)
         {
            if (!cir)
               siFindCir(&siCb.cirHlCp, &cir, &key, idx, KEY_INTF);
            else
            {
               if (cmHashListGetNext(&siCb.cirHlCp.ihCp, (PTR) cir, 
                     (PTR *) &cir) != ROK) break;
               else
                  if (cir->cfg.intfId != siIntfCb->cfg.intfId)
                     break;
            }
            if (cir != NULLP)
            {
               /* after receiving invalid iam though conblock
                * is present yet relind is not required */
               if ((cir->siCon) && (cir->siCon->tCallCb))
               {
                  if ((cir->siCon->incC.conPrcs) &&
                      (cir->cfg.cirId == cir->siCon->incC.cirId) &&
                      /* if call is in conv then it is not released on pause, 
                       * then relreq is received and toBeRelsd flag is TRUE 
                       * yet this connection is to be handled as if it were in
                       * transient state */
                      ( (cir->siCon->incC.toBeRelsd == FALSE) ||
                        (cir->siCon->incC.conState == ST_WTFORRELCMP)) )
                  {
                     cir->siCon->incC.toBeRelsd = TRUE;
                     siGenRelUp(cir->cfg.cirId, cir->siCon, &causeDgn);
                  }
               
                  if ((cir->siCon->outC.conPrcs) &&
                      (cir->cfg.cirId == cir->siCon->outC.cirId) &&
                      /* if call is in conv then it is not released on pause, 
                         then relreq is received and toBeRelsd flag is TRUE 
                         yet this connection is to be handled as if it were in
                         transient state */
                      ((cir->siCon->outC.toBeRelsd == FALSE) ||
                        (cir->siCon->outC.conState == ST_WTFORRELCMP)))
                  {
                     cir->siCon->outC.toBeRelsd = TRUE;
                     siGenRelUp(cir->cfg.cirId, cir->siCon, &causeDgn);
                  }
               }
            }
            else
               break;
         } /* end for (idx = 0.....*/ 
         break;

#ifdef SNT2
      case TMR_TSTAENQ:
      {
         SiNSAPCb *nCb;

         if ( (nCb = SIMTPSAP(siIntfCb->msapId)) == NULLP)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SILOGERROR(ERRCLS_DEBUG, ESI834, (ErrVal) siIntfCb->cfg.swtch,
                       "siIntfTmrEv() Failed, can't find NSAP for the switch");
#endif
            RETVOID;
         }
          
         siStartIntfTmr(event, siIntfCb);
         SiLiSntStaReq(&nCb->pst, nCb->spId, siIntfCb->cfg.phyDpc); 
      }
#endif /* SNT2 */
      break;

   } /* end switch event */
} /* end of siIntfTmrEv */

  
/*
*
*       Fun:    siCirTmrEv
*
*       Desc:   Processes Circuit Timing Events
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
  
#ifdef ANSI
PUBLIC Void siCirTmrEv
(
PTR cb,
S16 event
)
#else
PUBLIC Void siCirTmrEv(cb, event)
PTR cb;
S16 event;
#endif
{
   SiCirCb    *cir;
   SiCauseDgn cause;
   SiUpSAPCb  *tCb;
   S16        ret;
/* si003.220 - Modification for correct type cast.
 */
   U8         event1;

   TRC2(siCirTmrEv)
   event1 = (U8)event;
   cir = (SiCirCb *) cb;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(cir) != ROK)
      RETVOID;
#endif

   /*if in the process of data swapping, rstTmr flag will be turned on and all
     the timers restarted */
   if (siCb.rstTmr)
   {
      SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
                      "rstTmr SET .Restarting timers\n"));  
      siStartCirTmr(event, cir);
      RETVOID;
   }
   SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
                      "%s\n\nCIR TMR: x %d 0x%x \n", SI_STR, event, event));  
   switch (event)
   {
      case TMR_T3:
 
         /* get pointer to the upper control block */
         tCb = siGetUprCbPtr(cir);
 
         /* initialize cause */
         MFINITELMT(&tCb->mfMsgCtl, ret, NULLP,
                   (ElmtHdr *) &cause, &meCauseIndV, (U8) PRSNT_DEF,
                   tCb->cfg.swtch, (U32) MF_ISUP);
         cause.causeVal.pres = PRSNT_NODEF;
         cause.causeVal.val  = SIT_CCNORMUNSPEC;
         cause.location.val  = tCb->cfg.relLocation;
 
         /* connection block is maintained until T3 expiry */
         siGenRelUpLw(cir->key.k1.cirId, cir->siCon, &cause);
 
         break;

      case TMR_T12:
         /* start Blocking timer */
         siStartCirTmr(TMR_T12, cir);
         siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                     cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                     M_BLOCK, MI_BLOCK, NULLP, cir->pIntfCb->cfg.ssf, 
                     cir->pIntfCb->cfg.nwId);
         break;
      case TMR_T13:
         if (siIsTmrRunning(cir->timers, MAXSIMTIMER, TMR_T12) == ROK)
         {
            /* stop Blocking timer */
            siStopCirTmr(cir, TMR_T12);
            /* generate Alarm */
#if (SI_LMINT3 || SMSI_LMINT3)
/* si003.220 - Modification. Modified parameter into event1 to have correct
 * type.
 */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId,
                          LSI_USTA_DGNVAL_EVENT, (PTR) &event1,
                          LSI_USTA_DGNVAL_NONE, NULLP,
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LCM_EVENT_TIMEOUT, LSI_CAUSE_TMR_EXP, TRUE, 
                           cir->cfg.cirId, CIR_OUT_ORD);
#endif
         }
#if (SI_LMINT3 || SMSI_LMINT3)
         siUpdErrSts(cir, LSI_STS_T13EXP);
#endif
#ifndef SI_INFINITETRY  
         if (cir->tmrCnt < NMB_MGTMSG_RSNT)
            cir->tmrCnt++;
         else
         {
            cir->tmrCnt = 0;
            RETVOID;
         }
#endif 
         /* start Blocking timer */
         siStartCirTmr(TMR_T13, cir);
         siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                     cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                     M_BLOCK, MI_BLOCK, NULLP, cir->pIntfCb->cfg.ssf, 
                     cir->pIntfCb->cfg.nwId);
         break;

      case TMR_T14:
         /* start Unblocking timer */
         siStartCirTmr(TMR_T14, cir);
         siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                     cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                     M_UNBLK, MI_UNBLK, NULLP, cir->pIntfCb->cfg.ssf, 
                     cir->pIntfCb->cfg.nwId);
         break;

      case TMR_T15:
         if (siIsTmrRunning(cir->timers, MAXSIMTIMER, TMR_T14) == ROK)
         {
            /* stop unblocking timer */
            siStopCirTmr(cir, TMR_T14);
            /* generate Alarm */
/* si003.220 - Modification. Modified parameter into event1 to have correct
 * type.
 */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId,
                          LSI_USTA_DGNVAL_EVENT, (PTR) &event1,
                          LSI_USTA_DGNVAL_NONE, NULLP,
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                          LCM_EVENT_TIMEOUT, LSI_CAUSE_TMR_EXP, TRUE, 
                          cir->cfg.cirId, CIRMGT_NORESP);
         }
#if (SI_LMINT3 || SMSI_LMINT3)
         siUpdErrSts(cir, LSI_STS_T15EXP);
#endif
#ifndef SI_INFINITETRY  
         if (cir->tmrCnt < NMB_MGTMSG_RSNT)
            cir->tmrCnt++;
         else
         {
            cir->tmrCnt = 0;
            RETVOID;
         }
#endif 
         /* start Blocking timer */
         siStartCirTmr(TMR_T15, cir);
         siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                     cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                     M_UNBLK, MI_UNBLK, NULLP, cir->pIntfCb->cfg.ssf, 
                     cir->pIntfCb->cfg.nwId);
         break;
 
      case TMR_T16:
         /* start reset timer */
         siStartCirTmr(TMR_T16, cir);
         siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                     cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                     M_RESCIR, MI_RESCIR, NULLP, cir->pIntfCb->cfg.ssf, 
                     cir->pIntfCb->cfg.nwId);
         break;

      case TMR_T17:
         if (siIsTmrRunning(cir->timers, MAXSIMTIMER, TMR_T16) == ROK)
         {
            /* stop reset timer */
            siStopCirTmr(cir, TMR_T16);
            /* generate Alarm */
/* si003.220 - Modification. Modified parameter into event1 to have correct
 * type.
 */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId,
                          LSI_USTA_DGNVAL_EVENT, (PTR) &event1,
                          LSI_USTA_DGNVAL_NONE, NULLP,
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LCM_EVENT_TIMEOUT, LSI_CAUSE_TMR_EXP, TRUE, 
                           cir->cfg.cirId, CIRMGT_NORESP);
         }
#if (SI_LMINT3 || SMSI_LMINT3)
         siUpdErrSts(cir, LSI_STS_T17EXP);
#endif
#ifndef SI_INFINITETRY  
         if (cir->tmrCnt < NMB_MGTMSG_RSNT)
            cir->tmrCnt++;
         else
         {
            cir->tmrCnt = 0;
            RETVOID;
         }
#endif 
         /* start reset timer */
         siStartCirTmr(TMR_T17, cir);
         siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                     cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                     M_RESCIR, MI_RESCIR, NULLP, cir->pIntfCb->cfg.ssf, 
                     cir->pIntfCb->cfg.nwId);
         break;
 

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid timer %d expired\n", event));  
         SILOGERROR(ERRCLS_DEBUG, ESI835, (ErrVal) 0, 
                 "siCirTmrEv() Failed, invalid timer event");
         RETVOID;
#endif
   }
   RETVOID;
} /* end of siCirTmrEv */

  
/*
*
*       Fun:    siCirGrTmrEv
*
*       Desc:   Processes Circuit Group Timing Events
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
  
#ifdef ANSI
PUBLIC Void siCirGrTmrEv
(
PTR cb,
S16 event
)
#else
PUBLIC Void siCirGrTmrEv(cb, event)
PTR cb;
S16 event;
#endif
{
   SiAllPdus msg;
   SiNSAPCb *mCb;
/* si040.220 */
#ifdef SIT_TMREXP
   SiUpSAPCb *uCb;  
#endif
   S16 ret;
   SiPduHdr pduHdr;
   LnkSel lnkSel;
   SiCirGrp *cirGrp;
/* si003.220 - Modification for correct type cast.
 */
   U8       event1;
   TRC2(siCirGrTmrEv)
   event1 = (U8)event; 
   cirGrp = (SiCirGrp *) cb;

   /*if in the process of data swapping, rstTmr flag will be turned on and all
     the timers restarted */
   if (siCb.rstTmr)
   {
      SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
                      "rstTmr SET .Restarting timers\n"));  
      siStartCirGrTmr(event, cirGrp);
      RETVOID;
   }

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(cirGrp->cir) != ROK)
      RETVOID;
#endif

   /* get pointer to the lower control block */
   mCb = siGetLwrMCbPtr(cirGrp->cir);
   pduHdr.eh.pres = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   /* get link selection value */
   /* si009.220 - Modified: to pass cic into siGenLnkSel. */
   /* si025.220 - Modified: change the arguments in siGenLnkSel. */
   siGetLnkSel(mCb, &lnkSel, cirGrp->cir->pIntfCb->cfg.swtch, cirGrp->cir);

   SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
                      "%s\n\nGRP TMR: x %d 0x%x \n", SI_STR, event, event));  
   switch (event)
   {
      case TMR_T18:
         /* start Group Blocking timer */
         siStartCirGrTmr(TMR_T18, cirGrp);
         /* Generate Message */
         /* prepare Pdu header */
         pduHdr.msgType.val = (U8) M_CIRGRPBLK;
         /* Generate Circuit Group Blocking Message */
         MFINITPDU(&mCb->mfMsgCtl, ret, (U8) 0, (U8) MI_CIRGRPBLK,
                  (ElmtHdr *) NULLP, (ElmtHdr *) &msg, (U8) PRSNT_DEF,
                  cirGrp->cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);
         msg.m.cirGrpBlk.cgsmti.eh.pres = PRSNT_NODEF;
         msg.m.cirGrpBlk.cgsmti.typeInd.pres = PRSNT_NODEF;
         msg.m.cirGrpBlk.cgsmti.typeInd.val = cirGrp->cgsmti.typeInd.val;

         /* initialize rangStat element */
         MFINITELMT(&mCb->mfMsgCtl, ret, (ElmtHdr *) &cirGrp->rangStat,
                     (ElmtHdr *) &msg.m.cirGrpBlk.rangStat, &meRangStatV,
                     (U8) PRSNT_NODEF, cirGrp->cir->pIntfCb->cfg.swtch, 
                     (U32) MF_ISUP);

         siGenPdu(mCb, &pduHdr, &msg, cirGrp->cir->pIntfCb->cfg.swtch, 
                  cirGrp->cir->opc, cirGrp->cir->key.k2.intfId, 
                  cirGrp->cir->phyDpc, TRUE,
                  cirGrp->cir->key.k2.cic, lnkSel, 
                  siGetPriority(M_CIRGRPBLK,
                  cirGrp->cir->pIntfCb->cfg.swtch), NULLP);
         break;

      case TMR_T19:
         if (siIsTmrRunning(cirGrp->timers, MAXSIMTIMER, TMR_T18) == ROK)
         {
            /* stop Group Blocking timer */
            siStopCirGrTmr(cirGrp, TMR_T18);
            /* generate Alarm */
/* si003.220 - Modification. Modified parameter into event1 to have correct
 * type.
 */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                          (PTR) &cirGrp->cir->key.k1.cirId,
                          LSI_USTA_DGNVAL_EVENT, (PTR) &event1,
                          LSI_USTA_DGNVAL_NONE, NULLP,
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LCM_EVENT_TIMEOUT, LSI_CAUSE_TMR_EXP, TRUE, 
                           cirGrp->cir->cfg.cirId, CIRMGT_NORESP);
         }
#if (SI_LMINT3 || SMSI_LMINT3)
         siUpdErrSts(cirGrp->cir, LSI_STS_T19EXP);
#endif
#ifndef SI_INFINITETRY  
         if (cirGrp->tmrCnt < NMB_GMGTMSG_RSNT)
            cirGrp->tmrCnt++;
         else
         {
            cirGrp->tmrCnt = 0;
            RETVOID;
         }
#endif 

         /* start Group Blocking timer */
         siStartCirGrTmr(TMR_T19, cirGrp);
         /* Generate Message */
         pduHdr.msgType.val = (U8) M_CIRGRPBLK;
         /* Generate Circuit Group Blocking Message */
         MFINITPDU(&mCb->mfMsgCtl, ret, (U8) 0, (U8) MI_CIRGRPBLK,
                  (ElmtHdr *) NULLP, (ElmtHdr *) &msg, (U8) PRSNT_DEF,
                  cirGrp->cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);
         msg.m.cirGrpBlk.cgsmti.eh.pres = PRSNT_NODEF;
         msg.m.cirGrpBlk.cgsmti.typeInd.pres = PRSNT_NODEF;
         msg.m.cirGrpBlk.cgsmti.typeInd.val = cirGrp->cgsmti.typeInd.val;
         /* initialize rangStat element */
         MFINITELMT(&mCb->mfMsgCtl, ret, (ElmtHdr *) &cirGrp->rangStat,
                     (ElmtHdr *) &msg.m.cirGrpBlk.rangStat, &meRangStatV,
                     (U8) PRSNT_NODEF, cirGrp->cir->pIntfCb->cfg.swtch, 
                     (U32) MF_ISUP);


         siGenPdu(mCb, &pduHdr, &msg, cirGrp->cir->pIntfCb->cfg.swtch, 
                  cirGrp->cir->opc, cirGrp->cir->key.k2.intfId, 
                  cirGrp->cir->phyDpc, TRUE,
                  cirGrp->cir->key.k2.cic, lnkSel, 
                  siGetPriority(M_CIRGRPBLK,
                          cirGrp->cir->pIntfCb->cfg.swtch), NULLP);
         break;

      case TMR_T20:
         /* start Group Unblocking timer */
         siStartCirGrTmr(TMR_T20, cirGrp);
         /* Generate Message */
         /* prepare Pdu header */
         pduHdr.msgType.val = (U8) M_CIRGRPUBLK;
         /* Generate Circuit Group Unblocking Message */
         MFINITPDU(&mCb->mfMsgCtl, ret, (U8) 0, (U8) MI_CIRGRPUBLK,
                  (ElmtHdr *) NULLP, (ElmtHdr *) &msg, (U8) PRSNT_DEF,
                  cirGrp->cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);
         msg.m.cirGrpUnblk.cgsmti.eh.pres = PRSNT_NODEF;
         msg.m.cirGrpUnblk.cgsmti.typeInd.pres = PRSNT_NODEF;
         msg.m.cirGrpUnblk.cgsmti.typeInd.val = cirGrp->cgsmti.typeInd.val;
         /* initialize rangStat element */
         MFINITELMT(&mCb->mfMsgCtl, ret, (ElmtHdr *) &cirGrp->rangStat,
                     (ElmtHdr *) &msg.m.cirGrpUnblk.rangStat, &meRangStatV,
                     (U8) PRSNT_NODEF, cirGrp->cir->pIntfCb->cfg.swtch, 
                     (U32) MF_ISUP);

         siGenPdu(mCb, &pduHdr, &msg, cirGrp->cir->pIntfCb->cfg.swtch, 
                  cirGrp->cir->opc, cirGrp->cir->key.k2.intfId, 
                  cirGrp->cir->phyDpc, TRUE, 
                  cirGrp->cir->key.k2.cic, lnkSel, 
                  siGetPriority(M_CIRGRPUBLK,
                               cirGrp->cir->pIntfCb->cfg.swtch), NULLP);
         break;
      case TMR_T21:
         if (siIsTmrRunning(cirGrp->timers, MAXSIMTIMER, TMR_T20) == ROK)
         {
            /* stop Group Unblocking timer */
            siStopCirGrTmr(cirGrp, TMR_T20);
            /* generate Alarm */
/* si003.220 - Modification. Modified parameter into event1 to have correct
 * type.
 */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                          (PTR) &cirGrp->cir->key.k1.cirId,
                          LSI_USTA_DGNVAL_EVENT, (PTR) &event1,
                          LSI_USTA_DGNVAL_NONE, NULLP,
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LCM_EVENT_TIMEOUT, LSI_CAUSE_TMR_EXP, TRUE, 
                           cirGrp->cir->cfg.cirId, CIRMGT_NORESP);
         }
#if (SI_LMINT3 || SMSI_LMINT3)
         siUpdErrSts(cirGrp->cir, LSI_STS_T21EXP);
#endif
#ifndef SI_INFINITETRY  
         if (cirGrp->tmrCnt < NMB_GMGTMSG_RSNT)
            cirGrp->tmrCnt++;
         else
         {
            cirGrp->tmrCnt = 0;
            RETVOID;
         }
#endif 
         /* start Group Unblocking timer */
         siStartCirGrTmr(TMR_T21, cirGrp);
         /* Generate Message */
         pduHdr.msgType.val = (U8) M_CIRGRPUBLK;
         /* Generate Circuit Group Unblocking Message */
         MFINITPDU(&mCb->mfMsgCtl, ret, (U8) 0, (U8) MI_CIRGRPUBLK,
                  (ElmtHdr *) NULLP, (ElmtHdr *) &msg, (U8) PRSNT_DEF,
                  cirGrp->cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);
         msg.m.cirGrpUnblk.cgsmti.eh.pres = PRSNT_NODEF;
         msg.m.cirGrpUnblk.cgsmti.typeInd.pres = PRSNT_NODEF;
         msg.m.cirGrpUnblk.cgsmti.typeInd.val = cirGrp->cgsmti.typeInd.val;
         /* initialize rangStat element */
         MFINITELMT(&mCb->mfMsgCtl, ret, (ElmtHdr *) &cirGrp->rangStat,
                  (ElmtHdr *) &msg.m.cirGrpUnblk.rangStat, &meRangStatV,
                  (U8) PRSNT_NODEF, cirGrp->cir->pIntfCb->cfg.swtch, 
                  (U32) MF_ISUP);

         siGenPdu(mCb, &pduHdr, &msg, cirGrp->cir->pIntfCb->cfg.swtch, 
                  cirGrp->cir->opc, cirGrp->cir->key.k2.intfId, 
                  cirGrp->cir->phyDpc, TRUE, 
                  cirGrp->cir->key.k2.cic, lnkSel, 
                  siGetPriority(M_CIRGRPUBLK,
                               cirGrp->cir->pIntfCb->cfg.swtch), NULLP);
         break;
      case TMR_T22:
         /* start Group Reset timer */
         siStartCirGrTmr(TMR_T22, cirGrp);
         /* Generate Message */
         /* prepare Pdu header */
         pduHdr.msgType.val = (U8) M_CIRGRPRES;
         /* Generate Circuit Group Reset Message */

         MFINITPDU(&mCb->mfMsgCtl, ret, (U8) 0, MI_CIRGRPRES, 
                   (ElmtHdr *) NULLP, (ElmtHdr *) &msg,
                   (U8) PRSNT_DEF, cirGrp->cir->pIntfCb->cfg.swtch, 
                   (U32) MF_ISUP);
         
         MFINITELMT(&mCb->mfMsgCtl, ret, (ElmtHdr *) &cirGrp->rangStat,
                    (ElmtHdr *) &msg.m.cirGrpRes.rangStat, &meRangNoStat,
                    (U8) PRSNT_NODEF, cirGrp->cir->pIntfCb->cfg.swtch, 
                    (U32) MF_ISUP);
 
         siGenPdu(mCb, &pduHdr, &msg, cirGrp->cir->pIntfCb->cfg.swtch, 
                  cirGrp->cir->opc, cirGrp->cir->key.k2.intfId, 
                  cirGrp->cir->phyDpc, TRUE, 
                  cirGrp->cir->key.k2.cic, lnkSel, 
                  siGetPriority(M_CIRGRPRES, 
                                cirGrp->cir->pIntfCb->cfg.swtch), NULLP);
         break;
      case TMR_T23:
         if (siIsTmrRunning(cirGrp->timers, MAXSIMTIMER, TMR_T22) == ROK)
         {
            /* generate Alarm */
/* si003.220 - Modification. Modified parameter into event1 to have correct
 * type.
 */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                          (PTR) &cirGrp->cir->key.k1.cirId,
                          LSI_USTA_DGNVAL_EVENT, (PTR) &event1,
                          LSI_USTA_DGNVAL_NONE, NULLP,
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LCM_EVENT_TIMEOUT, LSI_CAUSE_TMR_EXP, TRUE, 
                           cirGrp->cir->cfg.cirId, CIRMGT_NORESP);
            /* stop Group Reset timer TMR_T22 */
            siStopCirGrTmr(cirGrp, TMR_T22);
         }
#if (SI_LMINT3 || SMSI_LMINT3)
         siUpdErrSts(cirGrp->cir, LSI_STS_T23EXP);
#endif
#ifndef SI_INFINITETRY  
         if (cirGrp->tmrCnt < NMB_GMGTMSG_RSNT)
            cirGrp->tmrCnt++;
         else
         {
            cirGrp->tmrCnt = 0;
            RETVOID;
         }
#endif 
         /* start Group Reset timer */
         siStartCirGrTmr(TMR_T23, cirGrp);
         /* Generate Message */
         pduHdr.msgType.val = (U8) M_CIRGRPRES;
         /* Generate Circuit Group Reset Message */
         MFINITPDU(&mCb->mfMsgCtl, ret, (U8) 0, MI_CIRGRPRES, 
                   (ElmtHdr *) NULLP, (ElmtHdr *) &msg,
                   (U8) PRSNT_DEF, cirGrp->cir->pIntfCb->cfg.swtch, 
                   (U32) MF_ISUP);
         
         MFINITELMT(&mCb->mfMsgCtl, ret, (ElmtHdr *) &cirGrp->rangStat,
                    (ElmtHdr *) &msg.m.cirGrpRes.rangStat, &meRangNoStat,
                    (U8) PRSNT_NODEF, cirGrp->cir->pIntfCb->cfg.swtch, 
                    (U32) MF_ISUP);
         
         siGenPdu(mCb, &pduHdr, &msg, cirGrp->cir->pIntfCb->cfg.swtch, 
                  cirGrp->cir->opc, cirGrp->cir->key.k2.intfId, 
                  cirGrp->cir->phyDpc, TRUE, 
                  cirGrp->cir->key.k2.cic, lnkSel, 
                  siGetPriority(M_CIRGRPRES,
                                cirGrp->cir->pIntfCb->cfg.swtch), NULLP);
         break;

      case TMR_T28: /* circuit group query timer */
/* si003.220 - Modification. Modified parameter into event1 to have correct
 * type.
 */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                       (PTR) &cirGrp->cir->key.k1.cirId,
                       LSI_USTA_DGNVAL_EVENT, (PTR) &event1,
                       LSI_USTA_DGNVAL_NONE, NULLP,
                       LSI_USTA_DGNVAL_NONE, NULLP);
/* si040.220 - Send Status Indication to CC in case of T28 expiry.
               SR 55862
*/
#ifdef SIT_TMREXP
         /* get pointer to the upper control block */
         uCb = siGetUprCbPtr(cirGrp->cir);
         if (uCb && (uCb->state == SI_BND))
           SiUiSitStaInd(&uCb->pst, uCb->suId, 0, 0, cirGrp->cir->key.k1.cirId, FALSE, 
                      SIT_STA_TMREXP, NULLP, NULLP);

#endif
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                        LCM_EVENT_TIMEOUT, LSI_CAUSE_TMR_EXP, TRUE, 
                        cirGrp->cir->cfg.cirId, CIRMGT_NORESP);
         if (cirGrp->state == SICG_ST_IDLE) /* no other pending event */
         {
            /* finish the procedure */
            cirGrp->cir->cirGr[cirGrp->cirState] = NULLP;
            SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) cirGrp, 
                     (Size) sizeof(SiCirGrp)); 
         }
         else /* some other event pending */
            cirGrp->querPrcs = FALSE; 
         break;

    
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "ERR:GRP TMR: x %d invalid\n", event));  
         SILOGERROR(ERRCLS_DEBUG, ESI836, (ErrVal) 0, 
                 "siCirGrTmrEv() Failed, invalid timer event");
         RETVOID;
#endif
   }
   RETVOID;
} /* end of siCirGrTmrEv */

  
/*
*
*       Fun:    siConTmrEv
*
*       Desc:   Processes Connection Timing Events
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
  
#ifdef ANSI
PUBLIC Void siConTmrEv
(
PTR cb,
S16 event
)
#else
PUBLIC Void siConTmrEv(cb, event)
PTR cb;
S16 event;
#endif
{
   SiCon *con;

   TRC2(siConTmrEv)

   con = (SiCon *) cb;

   /*if in the process of data swapping, rstTmr flag will be turned on and all
     the timers restarted */
   if (siCb.rstTmr)
   {
      SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
                      "rstTmr SET .Restarting timers\n"));  
      siStartConTmr(event, con, con->tCallCb);
      RETVOID;
   }
   SIDBGP(SIDBGMASK_TMR, (siCb.init.prntBuf,
                      "%s\n\nCON TMR: x %d 0x%x \n", SI_STR, event, event));  

   switch (event)
   {
      case TMR_T1I:
         siTmrT1Exp(con, INC);
         break;
      case TMR_T1O:
         siTmrT1Exp(con, OUTTYPE);
         break;
      case TMR_T2I:
         siTmrExp(con, INC, event);
         break;
      case TMR_T2O:
         siTmrExp(con, OUTTYPE, event);
         break;
      case TMR_T5I: /* stop T1, start T17 */
         siTmrT5Exp(con, INC, event);
         break;
      case TMR_T5O: /* stop T1, start T17 */
         siTmrT5Exp(con, OUTTYPE, event);
         break;
      case TMR_T6I:
         siTmrExp(con, INC, event);
         break;
      case TMR_T6O:
         siTmrExp(con, OUTTYPE, event);
         break;
      case TMR_T7I:
         siTmrExp(con, INC, event);
         break;
      case TMR_T7O:
         siTmrExp(con, OUTTYPE, event);
         break;
      case TMR_T8:
         siTmrExp(con, INC, event);
         break;
      case TMR_T9:
         siTmrExp(con, OUTTYPE, event);
         break;
      case TMR_T31:
         if (con->key.k1.spInstId)
            siDelInst(&siCb.conHlCp, con);
         con->tCallCb = NULLP;
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) con, (Size) 
                  sizeof(SiCon));
         break;
      case TMR_T33I:
         siTmrExp(con, INC, event);
         break;
      case TMR_T33O:
         siTmrExp(con, OUTTYPE, event);
         break;
      case TMR_TCCRI: /* start T16, T17 */
      case TMR_T27:
      case TMR_T34:
         siTmrT5Exp(con, INC, event);
         break;
      case TMR_T36I:
         siReassblSegms(con, &(con->incC), SEGM_TMR);
         break;
      case TMR_T36O:
         siReassblSegms(con, &(con->outC), SEGM_TMR);
         break;
#if (SS7_ETSI || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      case TMR_TECT:
         siTmrTECTExp(con);
         break;
#endif
      case TMR_TRELRSP:
         {
            SiRelEvnt relEvnt;
            CirId     circuit;


            circuit = ((con->incC.conPrcs == TRUE) ? 
                        con->incC.cirId: con->outC.cirId);

            cmMemset((U8 *)&relEvnt, (U8) NOTPRSNT, sizeof(SiRelEvnt));
            UPDATECAUSE(relEvnt.causeDgn, SIT_CCPROTERR, con->tCallCb);
            siStartConTmr(TMR_TRELRSP, con, con->tCallCb);
            SiUiSitRelInd(&con->tCallCb->pst, con->tCallCb->suId, 
                          con->suInstId, con->key.k1.spInstId, circuit, 
                          &relEvnt, NULLP);
         }
         break;

      case TMR_TFNLRELRSP:
         siRelRspTmrExp(con);
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "ERR:CON TMR: x %d invalid\n", event));  
         SILOGERROR(ERRCLS_DEBUG, ESI837, (ErrVal) 0, 
                 "siConTmrEv() Failed, invalid timer event");
         RETVOID;
#endif
   }
   RETVOID;
} /* end of siConTmrEv */

  
/*
*
*       Fun:    siTmrT1Exp
*
*       Desc:   Processes Connection Timer T1
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siTmrT1Exp
(
SiCon *con,
U8 dir
)
#else
PUBLIC S16 siTmrT1Exp(con, dir)
SiCon *con;
U8 dir;
#endif
{
   SiUpSAPCb *tCb;
   SiCirCb   *cir;
   Buffer    *tmpBuf;
   Buffer    *mBuf;
   Dpc       phyDpc;
   SiInstId  intfid;
   S16       ret;

   TRC2(siTmrT1Exp)

   cir = NULLP;
   tmpBuf = NULLP;

   /* validate SAP control block */  
   if (con->tCallCb == NULLP)
   {
      /* get pointer to the upper control block */
      if (dir == INC)
         tCb = SIUPSAP(con->incC.cir->pIntfCb->cfg.sapId);
      else
/*�����·��������֣���ôӦ��ȡ���ֵ�·�ϵĽӿڿ��ƿ��Ӧ��sapId---lixinxin(2006/09/26)*/
       //  tCb = SIUPSAP(con->incC.cir->pIntfCb->cfg.sapId);
         tCb = SIUPSAP(con->outC.cir->pIntfCb->cfg.sapId);
   }
   else
      tCb = con->tCallCb;

   switch (dir)
   {
      case INC:
         tmpBuf = con->incC.rel;
         intfid = con->incC.cir->cfg.intfId;
         phyDpc = con->incC.cir->phyDpc;
         cir = con->incC.cir;
         /* Start T1 Timer */
         siStartConTmr(TMR_T1I, con, tCb);
         break;
      case OUTTYPE:
         tmpBuf = con->outC.rel;
         intfid = con->outC.cir->cfg.intfId;
         phyDpc = con->outC.cir->phyDpc;
         cir = con->outC.cir;
         /* Start T1 Timer */
         siStartConTmr(TMR_T1O, con, tCb);
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "Invalid the call direction %d\n", dir));  
         RETVALUE(RFAILED);
   }
   if (tmpBuf != NULLP)
   {
      /* retransmit Release */

      ret = SCpyMsgMsg(tmpBuf, con->mCallCb->pst.region,
            con->mCallCb->pst.pool, &mBuf);
      if (ret == ROK)
      {
         /* send message */
          siSndMsg(con->mCallCb, mBuf, cir->opc, intfid, phyDpc, TRUE,
            con->lnkSel, TRUE, siGetPriority(M_RELSE,
               tCb->cfg.swtch), tCb->cfg.swtch);
         RETVALUE(ROK);
      }
#if (ERRCLASS & ERRCLS_ADD_RES)
      else
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "SCpyMsgMsg failed\n"));  
         SILOGERROR(ERRCLS_ADD_RES, ESI838, (ErrVal) ret,
                    "SCpyMsgMsg failed in siTmrT1Exp");
      }
#endif

   }
   
   siGenCirEvt(cir, SIT_STA_CIRLOCRES);
   /* Reset circuit */

   siProcCirEvt(cir, SIT_STA_CIRRESREQ, FALSE);

   RETVALUE(ROK);
} /* end of siTmrT1Exp */

  
/*
*
*       Fun:    siTmrT5Exp
*
*       Desc:   Processes Connection Timer T5
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siTmrT5Exp
(
SiCon *con,
U8 dir,
S16 event
)
#else
PUBLIC S16 siTmrT5Exp(con, dir, event)
SiCon *con;
U8 dir;
S16   event;
#endif
{
   SiCirCb   *cir;
   SiUpSAPCb *tCb;
   S16        t5event;

   TRC2(siTmrT5Exp)

   cir = NULLP;

   /* validate SAP control block */  
   if (con->tCallCb == NULLP)
   /* get pointer to the upper control block */
   {
      if (dir == INC)
         tCb = SIUPSAP(con->incC.cir->pIntfCb->cfg.sapId);
      else
/*--�����·��������֣���ôӦ��ȡ���ֵ�·�ϵĽӿڿ��ƿ��Ӧ��sapId---lixinxin(2006/09/26)*/
        // tCb = SIUPSAP(con->incC.cir->pIntfCb->cfg.sapId);
         tCb = SIUPSAP(con->outC.cir->pIntfCb->cfg.sapId);
/*----------------------------------------------------------------------------------------*/
   }
   else
      tCb = con->tCallCb;

   switch (dir)
   {
      case INC:
         cir = con->incC.cir;

         con->incC.relResp = FALSE;
         /* stop T1 (if running) */
         siStopConTmr(con, TMR_T1I);
         if (event == TMR_T34)
            t5event = event;
         else
            t5event = TMR_T5I;
         break;

      case OUTTYPE:
         cir = con->outC.cir;
 /*---�޸�Ϊ���ֵ�·�Ƿ�ϣ���ͷ���Ӧ   lixinxin(2006/09/26)-----*/        
     //    con->incC.relResp = FALSE;
         con->outC.relResp = FALSE;
 /*-------------------------------------------------------------*/        
         /* stop T1 (if running) */
         siStopConTmr(con, TMR_T1O);
         {
            t5event = TMR_T5O;
         }
         break;
   }

/* si027.220: Addition - added cir NULLP check to avoid program
 * core dump in case of cir pointer NULLP */
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "Circuit pointer is NULLP in siTmrT5Exp(). \n"));  

      SILOGERROR(ERRCLS_DEBUG, ESIXXX, (ErrVal) 0, 
         "siTmrT5Exp() Failed, circuit pointer NULLP");
      RETVALUE(RFAILED);
   }
   /* generate Alarm */
   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId,
                 LSI_USTA_DGNVAL_EVENT, (PTR) &t5event,
                 LSI_USTA_DGNVAL_NONE, NULLP,
                 LSI_USTA_DGNVAL_NONE, NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                  LCM_EVENT_TIMEOUT, LSI_CAUSE_TMR_EXP, TRUE, 
                  cir->cfg.cirId, SI_CIR_UNEQPD);
#if (SI_LMINT3 || SMSI_LMINT3)
   siUpdErrSts(cir, LSI_STS_T5EXP);
#endif

   /* initiate an outgoing reset on the circuit */
   siProcCirEvt(cir, SIT_STA_CIRRESREQ, FALSE);
   switch ( event )
   {
      case TMR_T5O:
      case TMR_T5I:
         siStopCirTmr(cir, TMR_T16);
         break;
      default:
         break;
   }

   /* generate local reset event to upper layer */
   siGenCirEvt(cir, SIT_STA_CIRLOCRES);
   RETVALUE(ROK);
} /* end of siTmrT5Exp */


  
/*
*
*       Fun:    siTmrExp
*
*       Desc:   Processes Connection Timers
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
#ifdef ANSI
PUBLIC S16 siTmrExp
(
SiCon *con,
U8 dir,
S16   event
)
#else
PUBLIC S16 siTmrExp(con, dir, event)
SiCon *con;
U8 dir;
S16   event;
#endif
{
   SiCauseDgn cause;
   CirId cirId;
   S16 ret;
   Swtch swtch;

   TRC2(siTmrExp)

   cirId = 0;

   switch (dir)
   {
      case INC:
         cirId = con->incC.cir->cfg.cirId;
         swtch = con->incC.cir->pIntfCb->cfg.swtch;
         break;
      case OUTTYPE:
         cirId = con->outC.cir->cfg.cirId;
         swtch = con->outC.cir->pIntfCb->cfg.swtch;
         break;
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "Invalid the call direction %d\n", dir));  
         RETVALUE(RFAILED);
   }
   /* initialize cause */
   MFINITELMT(&con->mCallCb->mfMsgCtl, ret, NULLP, (ElmtHdr *) &cause, 
              &meCauseIndV, (U8) PRSNT_DEF, swtch, 
              (U32) MF_ISUP);
   cause.causeVal.pres = PRSNT_NODEF;
   cause.location.pres = PRSNT_NODEF;
   switch( event )
   {
      case TMR_T8:
         cause.causeVal.val  = SIT_CCTMPFAIL;
         cause.location.val  = con->tCallCb->cfg.relLocation;
         break;

      case TMR_T6I:   
      case TMR_T6O:
         cause.causeVal.val  = SIT_CCCALLCLR; 
         cause.location.val  = ILOC_PUBNETLU;
         break;

/* si029.220: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
      case TMR_T9:
         cause.causeVal.val  = SIT_CCNOANSWR;
         cause.location.val  = con->tCallCb->cfg.relLocation;
         break;
#endif /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA */

      case TMR_T33I:
      case TMR_T33O:
         /* generate an alarm to layer manager */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cirId,
                       LSI_USTA_DGNVAL_EVENT, (PTR) &event,
                       LSI_USTA_DGNVAL_NONE, NULLP,
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                        LCM_EVENT_TIMEOUT, LSI_CAUSE_TMR_EXP, TRUE, 
                        cirId, CIRMGT_NORESP);
         /* fall through */

      default:
         /* si017.220, Modify: change cause value to normal
          * unspecified as per Q.850 table 1, remarks */
         cause.causeVal.val  = SIT_CCNORMUNSPEC;
         cause.location.val  = con->tCallCb->cfg.relLocation;
         break;
   }

   siGenRelUpLw(cirId, con, &cause);
   RETVALUE(ROK);
} /* end of siTmrExp */



#if (SS7_ETSI || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
  
/*
*
*       Fun:    siTmrTECTExp
*
*       Desc:   Processes Connection Timers
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siTmrTECTExp
(
SiCon *con
)
#else
PUBLIC S16 siTmrTECTExp(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16 ret;

   TRC2(siTmrTECTExp)

#if (ERRCLASS & ERRCLS_DEBUG)
   if ((con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
       (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
       (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
       (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
       (con->tCallCb->cfg.swtch != LSI_SW_ITU97))
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
         "swtch != LSI_SW_ETSI or ITU97 therefore event dumped\n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI839, (ErrVal) 0, 
                 "Bad Switch value, siTmrTECTExp");
      RETVALUE(ROK);
   }
#endif 
   /* Turn off ECT timer */
   con->callTRef.tRefUsed = FALSE;

   /* send empty TECT_TIMEOUT event to upper layer */
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) SI_CNSTREQ,
             (ElmtHdr *) NULLP, (ElmtHdr *) &ev, (U8) NOTPRSNT, 
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId,
                  con->suInstId, con->key.k1.spInstId, con->outC.cirId,
                  &ev.m.siCnStEvnt, TECT_TIMEOUT, NULLP);
   RETVALUE(ROK);

} /* end of siTmrTECTExp */
#endif /* SS7_ETSI || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */


/*
*
*       Fun:   siRelRspTmrExp
*
*       Desc:  process the loss of release indication primitive to upper layer.
*              the release response timers are started when ISUP internally
*              generates the release to take care of primitive loss. there are
*              two release response timers - one minor and the other major.
*              when the minor timer expires it is merely restarted. when the
*              major timer expires, the connection cleared at ISUP, circuit
*              associated is blocked and an alarm is generated
*              
*       Ret:   ROK - ok; RFAILED - failed
*
*       Notes: none
*
*       File:  ci_bdy7.c
*
*/
#ifdef ANSI
PRIVATE S16 siRelRspTmrExp 
(
SiCon *con
)
#else
PRIVATE S16 siRelRspTmrExp (con)
SiCon *con;
#endif
{
   SiCirCb *cir;
   U8      event;

   TRC2(siRelRspTmrExp)

   cir = NULLP;

   siStopConTmr(con, TMR_TRELRSP); /* stop the release response timer */

   /* no, no release responses expected - primitive lost! */
   con->incC.relResp = FALSE;
   con->outC.relResp = FALSE;

   /* this clears the incoming half if it were active */
   if (con->incC.conPrcs)
   {
#ifdef ZI
      ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) con);
#endif
      cir = con->incC.cir;
      siClearIncCon(con);
      siMngCirBlk(cir, TRUE);
#ifdef ZI
      ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
      ziUpdPeer();
#endif
   }

   /* if this were a transit connection, the conn block is not cleared
    * until outgoing half is cleared. clear that half also, if applicable */
   if (con->outC.conPrcs)
   {
#ifdef ZI
      ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) con);
#endif
      cir = con->outC.cir;
      siClearOutCon(con);
      siMngCirBlk(cir, TRUE);
#ifdef ZI
      ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
      ziUpdPeer();
#endif
   }

   event = TMR_TFNLRELRSP;
#if (SI_LMINT3 || SMSI_LMINT3)
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
             "Circuit pointer is NULLP \n"));  
      RETVALUE(RFAILED);
   }
   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId,
                 LSI_USTA_DGNVAL_EVENT, (PTR) &event,
                 LSI_USTA_DGNVAL_NONE, NULLP,
                 LSI_USTA_DGNVAL_NONE, NULLP);
   siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, LCM_EVENT_TIMEOUT, 
                 LSI_CAUSE_TMR_EXP, TRUE );
#endif

   RETVALUE(ROK);
}/* siRelRspTmrExp */

  
/*
*
*       Fun:    siIsTmrRunning
*
*       Desc:   Checks if Circuit Timer is running
*
*       Ret:    ROK     - Tmr is running
*               RFAILED - Tmr is not running
*       Notes:  None
*
*       File:   ci_bdy7.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siIsTmrRunning
(
CmTimer *timers,
U8 maxNum,
U8 tmrNum
)
#else
PUBLIC S16 siIsTmrRunning(timers, maxNum, tmrNum)
CmTimer *timers;
U8 maxNum;
U8 tmrNum;
#endif
{
   U8 i; 

   TRC2(siIsTmrRunning)

   for (i = 0; i < maxNum; i++)
   {
      if (timers[i].tmrEvnt != TMR_NONE)
      {
         if (timers[i].tmrEvnt == tmrNum)
         {
            RETVALUE(ROK);
         }
      }
   }
   RETVALUE(RFAILED);
} /* end of siIsTmrRunning */
  
/********************************************************************30**
  
         End of file:     ci_bdy7.c@@/main/9 - Wed Jul 25 13:20:59 2001
 
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  


/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rh   1. initial release.
1.2          ---      ym   1. changes in siTmrT5Exp to avoid sending 
                              alarm (internal inconsistency) to LM.
             ---      rh   1. Fixed TMR_PAUSE expiry for SITVER2 - update
                              the protocol switch in the circuit from that
                              of the DPC control block before calling the
                              reset handler function
             ---      rh   1. added break statement after T17 expiry to
                              avoid fall thru.
             ---      ym   1. Modifications for Debug prints 
             ---      ao   2. Added Russian variant
1.3          ---      rh   1. Fixed TCRM expiry to start normal release
                              procedures
1.3+         ---      ym   1. Prioirity of message is corrected in siSndMsg.
                           2. The index in siIntfTmrEv is made U16 .
                           3. Check for timer flag is added in the timer 
                              processing function . Timers are not processed
                              if the Flag is TRUE.
             ---      ym   1. Proper cause is filled in release at the 
                              expiry of timer T8.
                           2. On expiry of Timer T5 , the extra T16 timer
                              is stopped.
             ---      ym   1. Recommendation field in the cause element is
                              marked NOTPRSNT.
             ---      ym   1. For CLRTRAN and CLRTMOUT option for pause the calls
                              in conv. on which RelReq is received are also handled.
             ---      ym   1. siFindCir is replaced with cmHashListGetNext
                              to improve performance in handling of expiry of
                              TMR_PAUSE timer.
             ---      ym   1. On expiry of TCCRO STPCONTINUITY is sent.
1.4          ---      ym   1. Changes related to addition of NTT variant in
                              ISUP.
             ---      ym   1. The handling of the pause timer expiry is
                              corrected .
             ---      tz   1. On expiry of T6, cause value is set to normal
                              call clearing.
                           2. Location indicator in cause indicator is
                              changed to local local network.
1.6          ---      dvs  1. miscellaneous changes
1.7          ---      ym   1. If SITVER2 is not defined then on getting
                              group reset the circuit related processing
                              is performed for all the circuits covered 
                              in the range received in the group reset. The
                              connection related handling is performed
                              taking into account the flow control process.
                              For all processed (wrt circuit processing 
                              and connection processing) circuits at any 
                              given time the resFlag in circuit 
                              control block is TRUE. 
                              At the expiry of TMR_TGRES (the flow control
                              timer) the processes circuits are handled
                              wrt any new connection and next numResInd 
                              circuits are processed for GRS.
                           2. OUT define is changed to OUTTYPE for NT
                              compilation.
/main/8      ---       hy  1. Added a cause value #19 if T9 is expired for 
                              ITU97 and ETSI v3 variant in siTmrExp.
                           2. Added ITU97 variant to the ECT timer related codes.
                           3. changes for removal of swtch and ssf field in
                              circuit control block.
             ---       bsp 1. Added alarm to layer manager upon expiry of 
                              EXIT timer.              
                           2. Changed hash define names which were changed
                              in sit.h to resolve clash between sit.h and int.h
                           3. Removed SITVER2 flag
                           4. Removed siGrResTmrExp and TGRES related code 
                              since SITVER2 has been phased out
                           5. Patch propogation related changes:
                              . Correction of debug print when SCpyMsg returns
                                failure and location value for q767
                              . Added code to siTmrT5Exp so that when TCCRO or
                                T34 expire, an alarm is generated to the LM with
                                TMR_TCCRO (ANSI88/ANSI92/BELL) or T34 as event
                                type
                              . Initialized value of key before searching hash
                                list for cir control block and starting TMR_T4
                       sk  1. Utility function to start mtp3/sccp sap timers and
                              send bind req 
                       hy  1. Patch propogation related changes:
                              . Added the siIsTmrRunning function, and modified
                                siCirGrTmrEv such that LM is notified only on
                                the first expiry of T23
                              . Added code to generate an alarm to layer 
                                manager when timer T33 is expired.
                           2. Used phyDpc in SntStaReq instead of intfId in
                              siIntfTmrEv.
                           3. Added the default case in switch statement on
                              dir in siTmrT1Exp and siTmrExp.
                           4. Added initialization of cir and error checking
                              on cir in siRelRspTmrExp
                           5. Changed the local variable t5event to S16 from
                              U8 in siTmrT5Exp.
                           6. Removed the include of lrm.h.
/main/9      ---       mm  1. Modified code such that LM is notified only on
                              the first expiry of the maintenance related tmrs
             si003.220 mm  1. Modified code to correct parameter(variable) 
                              type.
             si009.220 hy  1. In siIntfTmrEv and siTmrValExp function, set the 
                              interface valie flag to FALSE when sending the 
                              UPT / CVT message on expiry of T4 / TVAL timer.
                       mm  2. Modified code so that when calling siGetLnkSel
                              an extra parameter cic will be passed in.
             si017.220 tz  1. Modified cause value for release message when
                              timer such as T7 expires.
             si025.220 tz  1. Modified arguments in siGetLnkSel call.
             si027.220 tz  1. Added code to check cir NULLP to avoid core
                              dump.
             si029.220 tz  1. Added INDIA variant.
             si040.220 rk  1. Changes made to send SiUiSitStaInd with event type 
                              SIT_STA_TMREXP to upper layer in case of TMR_T28 
                              expiry. Changes are under SIT_TMREXP compile time flag.
             si042.220 bn  1. Added ITU2000 and Russian 2000 ISUP variants.
*********************************************************************91*/
