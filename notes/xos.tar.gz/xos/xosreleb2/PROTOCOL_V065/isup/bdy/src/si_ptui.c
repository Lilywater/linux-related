/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

      Name:     ISUP - portable upper interface

      Type:     C source file

      Desc:     C source code for the ISUP upper interface primitives.

      File:     si_ptui.c

      Sid:      si_ptui.c@@/main/31 - Wed Mar 14 15:31:55 2001

      Prg:      bn

*********************************************************************21*/


/*

The following functions are provided in this file for the
ISUP Layer service user:

   SiUiSitCnStInd    - Connection Status Indication
   SiUiSitConCfm     - Connection Establishment Confirmation
   SiUiSitConInd     - Connection Establishment Indication
   SiUiSitDatInd     - User Information Indication
   SiUiSitFacCfm     - Facility Confirmation
   SiUiSitFacInd     - Facility Indication
   SiUiSitRelCfm     - Release Confirmation
   SiUiSitRelInd     - Release Indication
   SiUiSitResmInd    - Call Resume Indication
   SiUiSitStaInd     - Status Indication
   SiUiSitSuspInd    - Call Suspend Indication
   SiUiSitFtzInd     - Call Suspend Indication (only for GT_FTZ variant)
   SiUiSitUMsgInd    - Network Unkown Message Indication 

It is assumed that the following functions are provided in the
ISUP layer service user file:

   CcLiSitCnStInd    - Connection Status Indication
   CcLiSitConCfm     - Connection Establishment Confirmation
   CcLiSitConInd     - Connection Establishment Indication
   CcLiSitDatInd     - User Information Indication
   CcLiSitFacCfm     - Facility Confirmation
   CcLiSitFacInd     - Facility Indication
   CcLiSitRelCfm     - Release Indication
   CcLiSitRelInd     - Release Indication
   CcLiSitResmInd    - Call Resume Indication
   CcLiSitStaInd     - Status Indication
   CcLiSitSuspInd    - Call Suspend Indication
   CcLiSitFtzInd     - Call Suspend Indication (only for GT_FTZ variant)

*/


/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.             description
*     --------    ----------------------------------------------
*
*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lsi.h"           /* layer management */
#include "si_mf.h"            /* message functions */
#include "ci_db.h"         /* ISUP data base */
#include "cm_hash.h"       /* hash-list header */
#include "sit.h"           /* ISUP */
#ifdef SI_SPT
#include "spt.h"           /* sccp layer */
#endif
#include "cm5.h"           /* common - timers */
#ifdef SI_FTHA
#include "sht.h"           /* sht interface */
#endif
#include "si.h"            /* ISUP */
#include "si_err.h"        /* ISUP error */
#include "cm_ss7.h"        /* common SS7 packing/unpacking */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* general SS7 layer */
#include "cm_hash.x"       /* hash-list structure */
#include "lsi.x"           /* layer management */
#include "si_mf.x"            /* message functions */
#include "ci_db.x"         /* ISUP data base */
#include "sit.x"           /* ISUP */
#ifdef SI_SPT
#include "spt.x"           /* SCCP */
#endif
#include "cm5.x"           /* common - timers */
#ifdef SI_FTHA
#include "sht.x"           /* sht interface */
#endif
#include "si.x"            /* ISUP */

#ifdef LCSIUISIT_XOS
extern U32  SiSendMsg2UA(Pst *pPst, void  *pEventHdr, Buffer *mBuf);
extern S16  aPkSitBndCfm (Pst *pst,SuId suId,U8   status);
extern S16  aPkSitConInd(Pst *pst,SuId suId, SiInstId suInstId,SiInstId spInstId,CirId circuit,SiConEvnt *siConEvnt,Buffer *uBuf);
extern S16  aPkSitConCfm(Pst *pst,SuId suId,SiInstId suInstId,SiInstId spInstId,CirId circuit,SiConEvnt *siConEvnt,Buffer *uBuf);
extern S16  aPkSitCnStInd(Pst *pst,SuId suId,SiInstId suInstId, SiInstId  spInstId,CirId circuit,SiCnStEvnt *siCnStEvnt,U8 evntType,Buffer *uBuf);
extern S16  aPkSitStaInd(Pst *pst, SuId suId, SiInstId suInstId, SiInstId spInstId, CirId  circuit, Bool globalFlag, U8 eventType, SiStaEvnt *siStaEvnt,Buffer *uBuf);
extern S16  aPkSitRelInd(Pst *pst, SuId suId, SiInstId  suInstId,SiInstId spInstId, CirId circuit,SiRelEvnt *siRelEvnt,Buffer *uBuf);
extern S16  aPkSitRelCfm(Pst *pst, SuId suId, SiInstId suInstId, SiInstId spInstId, CirId circuit,SiRelEvnt *siRelEvnt,Buffer *uBuf);
extern S16  aPkSitDatInd(Pst *pst,SuId suId,SiInstId suInstId,SiInstId spInstId,CirId circuit,SiInfoEvnt *siInfoEvnt,Buffer *uBuf);
extern S16  aPkSitFacCfm(Pst *pst, SuId  suId, SiInstId suInstId,SiInstId spInstId, CirId circuit, U8 evntType,SiFacEvnt *siFacEvnt,Buffer *uBuf);
extern S16  aPkSitFacInd(Pst  *pst, SuId suId, SiInstId  suInstId, SiInstId spInstId, CirId circuit,U8 evntType,SiFacEvnt *siFacEvnt,Buffer *uBuf);
extern S16  aPkSitResmInd(Pst *pst, SuId  suId, SiInstId suInstId, SiInstId spInstId, CirId circuit,SiResmEvnt *siResmEvnt,Buffer *uBuf);
extern S16  aPkSitSuspInd(Pst *pst, SuId suId, SiInstId suInstId, SiInstId spInstId, CirId circuit,SiSuspEvnt *siSuspEvnt,Buffer *uBuf);
extern S16  aPkSitUMsgInd(Pst *pst,SuId suId, SiInstId suInstId,SiInstId spInstId, CirId circuit, Buffer *uBuf);
extern S16  aPkSitPtCdeStaCfm(Pst  *pst,SuId suId,SiInstId intfId,U8 status,U8 congLevel);
#endif


/* local defines */
#define MAXSIUISIT        5      /* maximum number of upper interfaces */

/* local typedefs */
  
/* local externs */

/* forward references */

#ifdef SIT2
PRIVATE S16 PtUiSitBndCfm ARGS((Pst *pst, SuId suId, U8 status));
#endif
PRIVATE S16 PtUiSitCnStInd ARGS ((Pst *pst, SuId suId, SiInstId suInstId,
        SiInstId spInstId, CirId circuit, SiCnStEvnt *siCnStEvnt,U8 evntType,
        Buffer *uBuf));
PRIVATE S16 PtUiSitConCfm ARGS ((Pst *pst, SuId suId, SiInstId suInstId, 
        SiInstId spInstId, CirId circuit, SiConEvnt *siConEvnt,
        Buffer *uBuf));
PRIVATE S16 PtUiSitConInd ARGS ((Pst *pst, SuId suId, SiInstId suInstId,
        SiInstId spInstId, CirId circuit, SiConEvnt *siConEvnt,
        Buffer *uBuf));
PRIVATE S16 PtUiSitDatInd ARGS ((Pst *pst, SuId suId, SiInstId suInstId,
        SiInstId spInstId, CirId circuit, SiInfoEvnt *siInfoEvnt,
        Buffer *uBuf));
PRIVATE S16 PtUiSitFacCfm ARGS ((Pst *pst, SuId suId, SiInstId suInstId,
        SiInstId spInstId, CirId circuit, U8 evntType, SiFacEvnt *siFacEvnt,
        Buffer *uBuf));
PRIVATE S16 PtUiSitFacInd ARGS ((Pst *pst, SuId suId, SiInstId suInstId,
        SiInstId spInstId, CirId circuit, U8 evntType, SiFacEvnt *siFacEvnt,
        Buffer *uBuf));
PRIVATE S16 PtUiSitRelCfm ARGS ((Pst *pst, SuId suId, SiInstId suInstId,
        SiInstId spInstId, CirId circuit, SiRelEvnt *siRelEvnt,
        Buffer *uBuf));
PRIVATE S16 PtUiSitRelInd ARGS ((Pst *pst, SuId suId, SiInstId suInstId,
        SiInstId spInstId, CirId circuit, SiRelEvnt *siRelEvnt,
        Buffer *uBuf));
PRIVATE S16 PtUiSitResmInd ARGS ((Pst *pst, SuId suId, SiInstId suInstId,
        SiInstId spInstId, CirId circuit, SiResmEvnt *siResmEvnt,
        Buffer *uBuf));
PRIVATE S16 PtUiSitStaInd ARGS ((Pst *pst, SuId suId, SiInstId suInstId,
        SiInstId spInstId, CirId circuit, Bool globalFlag, U8 eventType,
        SiStaEvnt *siStaEvnt,
        Buffer *uBuf));
PRIVATE S16 PtUiSitSuspInd ARGS ((Pst *pst, SuId suId, SiInstId suInstId,
        SiInstId spInstId, CirId circuit, SiSuspEvnt *siSuspEvnt,
        Buffer *uBuf));
#if SS7_FTZ
PRIVATE S16 PtUiSitFtzInd ARGS ((Pst *pst, SuId suId, SiInstId suInstId,
        SiInstId spInstId, CirId circuit, U8 eventType, SiFtzEvnt *siFtzEvnt,
        Buffer *uBuf));
#endif /* SS7_FTZ */

PRIVATE S16 PtUiSitUMsgInd ARGS ((Pst *pst, SuId suId, SiInstId suInstId,
                            SiInstId spInstId, CirId circuit, Buffer *uBuf));

PRIVATE S16 PtUiSitPtCdeStaCfm ARGS ((Pst *pst, SuId suId, SiInstId intfId,
                                      U8  status, U8 congLevel));

/* public variable declarations */

/*

the following matrices define the mapping between the primitives
called by the upper interface of isup and the corresponding
primitives of the isup service user(s).

The parameter MAXSIUISIT defines the maximum number of service users on
top of isup. There is an array of functions per primitive
invoked by isup. Every array is MAXISUI long (i.e. there
are as many functions as the number of service users).
 
The dispatching is performed by the configurable variable: selector.
The selector is configured on a per SAP basis.

The selectors are:

   0 - loosely coupled (#define LCSIUISIT)
   1 - loosely coupled (#define LCSIUISIT) backw. comp. NO more supported
   2 - application (#define CC)

*/

#ifdef SIT2

/* Bind Confirmation  */
PRIVATE CONSTANT SitBndCfm siUiSitBndCfmMt [MAXSIUISIT] =
{
#ifdef LCSIUISIT
   cmPkSitBndCfm,      /* 0 - loosely coupled  - fc */
#else
   PtUiSitBndCfm,      /* 0 - tightly coulpled, portable */
#endif
   PtUiSitBndCfm,      /* 1 - tightly coulpled, portable */
#ifdef CC
   CcLiSitBndCfm,      /* 2 - tightly coupled, call 1control */
#else
   PtUiSitBndCfm,      /* 2 - tightly coupled, portable */
#endif
#ifdef IW
   IwLiSitBndCfm,      /* 3 - tightly coupled, ISUP Wrapper */
#else
   PtUiSitBndCfm,      /* 3 - tightly coupled, portable */
#endif
#ifdef LCSIUISIT_XOS
   aPkSitBndCfm,      /* 4 - loosely coupled, -XOS */
#else
   PtUiSitBndCfm,     /* 4 - tightly coupled, portable */
#endif
};

#endif

/* Connection Status Indication */
PRIVATE CONSTANT SitCnStInd siUiSitCnStIndMt [MAXSIUISIT] =
{
#ifdef LCSIUISIT
   cmPkSitCnStInd,      /* 0 - loosely coupled  - fc */
#else
   PtUiSitCnStInd,      /* 0 - tightly coulpled, portable */
#endif
   PtUiSitCnStInd,      /* 1 - tightly coulpled, portable */
#ifdef CC
   CcLiSitCnStInd,      /* 2 - tightly coupled, call 1control */
#else
   PtUiSitCnStInd,      /* 2 - tightly coupled, portable */
#endif
#ifdef IW
   IwLiSitCnStInd,      /* 3 - tightly coupled, ISUP Wrapper */
#else
   PtUiSitCnStInd,      /* 3 - tightly coupled, portable */
#endif
#ifdef LCSIUISIT_XOS
   aPkSitCnStInd,      /* 4 - loosely coupled  - XOS */
#else
   PtUiSitCnStInd,     /* 4 - tightly coulpled, portable */
#endif
};

/* Connection Establishment Confirmation */
PRIVATE CONSTANT SitConCfm siUiSitConCfmMt [MAXSIUISIT] =
{
#ifdef LCSIUISIT
   cmPkSitConCfm,       /* 0 - loosely coupled  - fc */
#else
   PtUiSitConCfm,       /* 0 - tightly coulpled, portable */
#endif
   PtUiSitConCfm,       /* 1 - tightly coulpled, portable */
#ifdef CC
   CcLiSitConCfm,       /* 2 - tightly coupled, call control */
#else
   PtUiSitConCfm,       /* 2 - tightly coupled, portable */
#endif
#ifdef IW
   IwLiSitConCfm,       /* 3 - tightly coupled, ISUP Wrapper */
#else
   PtUiSitConCfm,       /* 3 - tightly coupled, portable */
#endif
#ifdef LCSIUISIT_XOS
   aPkSitConCfm,        /* 4 - loosely coupled  - fc */
#else
   PtUiSitConCfm,       /* 4 - tightly coulpled, portable */
#endif
};

/* Connection Establishment Indication */
PRIVATE CONSTANT SitConInd siUiSitConIndMt [MAXSIUISIT] =
{
#ifdef LCSIUISIT
   cmPkSitConInd,       /* 0 - loosely coupled - fc */
#else
   PtUiSitConInd,       /* 0 - tightly coulpled, portable */
#endif
   PtUiSitConInd,       /* 1 - tightly coulpled, portable */
#ifdef CC
   CcLiSitConInd,       /* 2 - tightly coupled, call control */
#else
   PtUiSitConInd,       /* 2 - tightly coupled, portable */
#endif
#ifdef IW
   IwLiSitConInd,       /* 3 - tightly coupled, ISUP Wrapper */
#else
   PtUiSitConInd,       /* 3 - tightly coupled, portable */
#endif
#ifdef LCSIUISIT_XOS
   aPkSitConInd,        /* 4 - loosely coupled - XOS */
#else
   PtUiSitConInd,       /* 4 - tightly coulpled, portable */
#endif
};

/* User Information Indication */
PRIVATE CONSTANT SitDatInd siUiSitDatIndMt [MAXSIUISIT] =
{
#ifdef LCSIUISIT
   cmPkSitDatInd,       /* 0 - loosely coupled  - fc */
#else
   PtUiSitDatInd,       /* 0 - tightly coulpled, portable */
#endif
   PtUiSitDatInd,       /* 1 - tightly coulpled, portable */
#ifdef CC
   CcLiSitDatInd,       /* 2 - tightly coupled, call control */
#else
   PtUiSitDatInd,       /* 2 - tightly coupled, portable */
#endif
#ifdef IW
   IwLiSitDatInd,       /* 3 - tightly coupled, ISUP Wrapper */
#else
   PtUiSitDatInd,       /* 3 - tightly coupled, portable */
#endif
#ifdef LCSIUISIT_XOS
   aPkSitDatInd,       /* 0 - loosely coupled  - XOS */
#else
   PtUiSitDatInd,       /* 0 - tightly coulpled, portable */
#endif
};

/* Facility Confirmation */
PRIVATE CONSTANT SitFacCfm siUiSitFacCfmMt [MAXSIUISIT] =
{
#ifdef LCSIUISIT
   cmPkSitFacCfm,       /* 0 - loosely coupled  - fc */
#else
   PtUiSitFacCfm,       /* 0 - tightly coulpled, portable */
#endif
   PtUiSitFacCfm,       /* 1 - tightly coulpled, portable */
#ifdef CC
   CcLiSitFacCfm,       /* 2 - tightly coupled, call control */
#else
   PtUiSitFacCfm,       /* 2 - tightly coupled, portable */
#endif
#ifdef IW
   IwLiSitFacCfm,       /* 3 - tightly coupled, ISUP Wrapper */
#else
   PtUiSitFacCfm,       /* 3 - tightly coupled, portable */
#endif
#ifdef LCSIUISIT_XOS
   aPkSitFacCfm,       /* 0 - loosely coupled  - XOS */
#else
   PtUiSitFacCfm,       /* 0 - tightly coulpled, portable */
#endif
};

/* Facility Indication */
PRIVATE CONSTANT SitFacInd siUiSitFacIndMt [MAXSIUISIT] =
{
#ifdef LCSIUISIT
   cmPkSitFacInd,       /* 0 - loosely coupled  - fc */
#else
   PtUiSitFacInd,       /* 0 - tightly coulpled, portable */
#endif
   PtUiSitFacInd,       /* 1 - tightly coulpled, portable */
#ifdef CC
   CcLiSitFacInd,       /* 2 - tightly coupled, call control */
#else
   PtUiSitFacInd,       /* 2 - tightly coupled, portable */
#endif
#ifdef IW
   IwLiSitFacInd,       /* 3 - tightly coupled, ISUP Wrapper */
#else
   PtUiSitFacInd,       /* 3 - tightly coupled, portable */
#endif
#ifdef LCSIUISIT_XOS
   aPkSitFacInd,       /* 4 - loosely coupled  - XOS */
#else
   PtUiSitFacInd,       /* 4 - tightly coulpled, portable */
#endif
};

/* Release Confirmation */
PRIVATE CONSTANT SitRelCfm siUiSitRelCfmMt [MAXSIUISIT] =
{
#ifdef LCSIUISIT
   cmPkSitRelCfm,       /* 0 - loosely coupled  - fc */
#else
   PtUiSitRelCfm,       /* 0 - tightly coulpled, portable */
#endif
   PtUiSitRelCfm,       /* 1 - tightly coulpled, portable */
#ifdef CC
   CcLiSitRelCfm,       /* 2 - tightly coupled, call control */
#else
   PtUiSitRelCfm,       /* 2 - tightly coupled, portable */
#endif
#ifdef IW
   IwLiSitRelCfm,       /* 3 - tightly coupled, ISUP Wrapper */
#else
   PtUiSitRelCfm,       /* 3 - tightly coupled, portable */
#endif
#ifdef LCSIUISIT_XOS
   aPkSitRelCfm,        /* 4 - loosely coupled  - XOS */
#else
   PtUiSitRelCfm,       /* 4 - tightly coulpled, portable */
#endif
};

/* Release Indication */
PRIVATE CONSTANT SitRelInd siUiSitRelIndMt [MAXSIUISIT] =
{
#ifdef LCSIUISIT
   cmPkSitRelInd,       /* 0 - loosely coupled  - fc */
#else
   PtUiSitRelInd,       /* 0 - tightly coulpled, portable */
#endif
   PtUiSitRelInd,       /* 1 - tightly coulpled, portable */
#ifdef CC
   CcLiSitRelInd,       /* 2 - tightly coupled, call control */
#else
   PtUiSitRelInd,       /* 2 - tightly coupled, portable */
#endif
#ifdef IW
   IwLiSitRelInd,       /* 3 - tightly coupled, ISUP Wrapper */
#else
   PtUiSitRelInd,       /* 3 - tightly coupled, portable */
#endif
#ifdef LCSIUISIT_XOS
   aPkSitRelInd,       /* 4 - loosely coupled  - XOS */
#else
   PtUiSitRelInd,      /* 4 - tightly coulpled, portable */
#endif
};

/* Call Resume Indication */
PRIVATE CONSTANT SitResmInd siUiSitResmIndMt [MAXSIUISIT] =
{
#ifdef LCSIUISIT
   cmPkSitResmInd,      /* 0 - loosely coupled  - fc */
#else
   PtUiSitResmInd,      /* 0 - tightly coulpled, portable */
#endif
   PtUiSitResmInd,      /* 1 - tightly coulpled, portable */
#ifdef CC
   CcLiSitResmInd,      /* 2 - tightly coupled, call control */
#else
   PtUiSitResmInd,      /* 2 - tightly coupled, portable */
#endif
#ifdef IW
   IwLiSitResmInd,      /* 3 - tightly coupled, ISUP Wrapper */
#else
   PtUiSitResmInd,      /* 3 - tightly coupled, portable */
#endif
#ifdef LCSIUISIT_XOS
   aPkSitResmInd,       /* 4 - loosely coupled  - XOS */
#else
   PtUiSitResmInd,      /* 4 - tightly coulpled, portable */
#endif
};

/* Status Indication */
PRIVATE CONSTANT SitStaInd siUiSitStaIndMt [MAXSIUISIT] =
{
#ifdef LCSIUISIT
   cmPkSitStaInd,       /* 0 - loosely coupled  -fc */
#else
   PtUiSitStaInd,       /* 0 - tightly coulpled, portable */
#endif
   PtUiSitStaInd,       /* 1 - tightly coulpled, portable */
#ifdef CC
   CcLiSitStaInd,       /* 2 - tightly coupled, call control */
#else
   PtUiSitStaInd,       /* 2 - tightly coupled, portable */
#endif
#ifdef IW
   IwLiSitStaInd,       /* 3 - tightly coupled, ISUP Wrapper */
#else
   PtUiSitStaInd,       /* 3 - tightly coupled, portable */
#endif
#ifdef LCSIUISIT_XOS
   aPkSitStaInd,        /* 4 - loosely coupled  -XOS */
#else
   PtUiSitStaInd,       /* 4 - tightly coulpled, portable */
#endif
};

/* Call Suspend Indication */
PRIVATE CONSTANT SitSuspInd siUiSitSuspIndMt [MAXSIUISIT] =
{
#ifdef LCSIUISIT
   cmPkSitSuspInd,      /* 0 - loosely coupled - fc */
#else
   PtUiSitSuspInd,      /* 0 - tightly coulpled, portable */
#endif
   PtUiSitSuspInd,      /* 1 - tightly coulpled, portable */
#ifdef CC
   CcLiSitSuspInd,      /* 2 - tightly coupled, call control */
#else
   PtUiSitSuspInd,      /* 2 - tightly coupled, portable */
#endif
#ifdef IW
   IwLiSitSuspInd,      /* 3 - tightly coupled, ISUP Wrapper */
#else
   PtUiSitSuspInd,      /* 3 - tightly coupled, portable */
#endif
#ifdef LCSIUISIT_XOS
   aPkSitSuspInd,       /* 4 - loosely coupled - XOS */
#else
   PtUiSitSuspInd,      /* 4 - tightly coulpled, portable */
#endif
};

#if SS7_FTZ
/* Call FTZ utilities Indication */
PRIVATE CONSTANT SitFtzInd siUiSitFtzIndMt [MAXSIUISIT] =
{
#ifdef LCSIUISIT
   cmPkSitFtzInd,      /* 0 - loosely coupled - fc */
#else
   PtUiSitFtzInd,      /* 0 - tightly coulpled, portable */
#endif
   PtUiSitFtzInd,      /* 1 - tightly coulpled, portable */
#ifdef CC
   CcLiSitFtzInd,      /* 2 - tightly coupled, call control */
#else
   PtUiSitFtzInd,      /* 2 - tightly coupled, portable */
#endif
#ifdef IW
   IwLiSitFtzInd,       /* 3 - tightly coupled, ISUP Wrapper */
#else
   PtUiSitFtzInd,       /* 3 - tightly coupled, portable */
#endif
#ifdef LCSIUISIT_XOS
   PtUiSitFtzInd,      /* 4 - loosely coupled - XOS */
#else
   PtUiSitFtzInd,      /* 4 - tightly coulpled, portable */
#endif
};
#endif /* SS7_FTZ */

PRIVATE CONSTANT SitUMsgInd siUiSitUMsgIndMt [MAXSIUISIT] =
{
#ifdef LCSIUISIT
   cmPkSitUMsgInd,      /* 0 - loosely coupled - fc */
#else
   PtUiSitUMsgInd,      /* 0 - tightly coulpled, portable */
#endif
   PtUiSitUMsgInd,      /* 1 - tightly coulpled, portable */
#ifdef CC
   CcLiSitUMsgInd,      /* 2 - tightly coupled, call control */
#else
   PtUiSitUMsgInd,      /* 2 - tightly coupled, portable */
#endif
#ifdef IW
   IwLiSitUMsgInd,      /* 3 - tightly coupled, ISUP Wrapper */
#else
   PtUiSitUMsgInd,      /* 3 - tightly coupled, portable */
#endif
#ifdef LCSIUISIT_XOS
   aPkSitUMsgInd,       /* 4 - loosely coupled - XOS */
#else
   PtUiSitUMsgInd,      /* 4 - tightly coulpled, portable */
#endif
};

PRIVATE CONSTANT SitPtCdeStaCfm siUiSitPtCdeStaCfmMt [MAXSIUISIT] =
{
#ifdef LCSIUISIT
   cmPkSitPtCdeStaCfm,  /* 0 - loosely coupled - fc */
#else
   PtUiSitPtCdeStaCfm,  /* 0 - tightly coulpled, portable */
#endif
   PtUiSitPtCdeStaCfm,  /* 1 - tightly coulpled, portable */
#ifdef CC
   CcLiSitPtCdeStaCfm,  /* 2 - tightly coupled, call control */
#else
   PtUiSitPtCdeStaCfm,  /* 2 - tightly coupled, portable */
#endif
#ifdef IW
   IwLiSitPtCdeStaCfm,  /* 3 - tightly coupled, ISUP Wrapper */
#else
   PtUiSitPtCdeStaCfm,  /* 3 - tightly coupled, portable */
#endif
#ifdef LCSIUISIT_XOS
   aPkSitPtCdeStaCfm,   /* 4 - loosely coupled - XOS */
#else
   PtUiSitPtCdeStaCfm,  /* 4 - tightly coulpled, portable */
#endif
};

  
/*
*     support functions
*/

  
/*
*     upper interface functions
*/

#ifdef SIT2

/*
*
*      Fun:   upper interface - Bind Confirmation
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitBndCfm
(
Pst *pst, 
SuId suId, 
U8   status
)
#else
PUBLIC S16 SiUiSitBndCfm(pst, suId, status)
Pst  *pst; 
SuId suId; 
U8   status;
#endif
{
   TRC3(SiUiSitBndCfm)

   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_UI,(siCb.init.prntBuf,"BndCfm : suId=%#x, status=%#x,\
          L4 -> L5\n", suId, status)); 

   /* jump to specific primitive depending on configured selector */
   RETVALUE(*siUiSitBndCfmMt[pst->selector])(pst, suId, status);
} /* end of SiUiSitBndCfm */

#endif


/*
*
*      Fun:   upper interface - Connection Status Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitCnStInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
SiCnStEvnt *siCnStEvnt, 
U8 evntType,
Buffer *uBuf
)
#else
PUBLIC S16 SiUiSitCnStInd(pst, suId, suInstId, spInstId, circuit,
           siCnStEvnt, evntType, uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
SiCnStEvnt *siCnStEvnt; 
U8 evntType;
Buffer *uBuf;
#endif
{
   TRC3(SiUiSitCnStInd)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_UI,(siCb.init.prntBuf,"CnStInd : suId=%#x, suInstId=%#lx,\
          spInstId=%#lx, circuit=%#lx, L4 -> L5 evtyp:%d\n", \
          suId, suInstId, spInstId, circuit, evntType)); 
   /* jump to specific primitive depending on configured selector */
   RETVALUE(*siUiSitCnStIndMt[pst->selector])(pst, suId, suInstId, 
                                              spInstId, circuit, siCnStEvnt, 
                                              evntType, uBuf);
} /* end of SiUiSitCnStInd */


/*
*
*      Fun:   upper interface - Connection Establishment Confirmation
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitConCfm
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
SiConEvnt *siConEvnt,
Buffer *uBuf
)
#else
PUBLIC S16 SiUiSitConCfm(pst, suId, suInstId, spInstId, circuit, siConEvnt, 
                         uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
SiConEvnt *siConEvnt;
Buffer *uBuf;
#endif
{
   TRC3(SiUiSitConCfm)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_UI,(siCb.init.prntBuf,"ConCfm : suId=%#x, suInstId=%#lx,\
          spInstId=%#lx, circuit=%#lx, L4 -> L5 \n", \
          suId, suInstId, spInstId, circuit)); 

   /* jump to specific primitive depending on configured selector */
   RETVALUE(*siUiSitConCfmMt[pst->selector])(pst, suId, suInstId, spInstId,
                                             circuit, siConEvnt, uBuf);
} /* end of SiUiSitConCfm */


/*
*
*      Fun:   upper interface - Connection Establishment Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitConInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit, 
SiConEvnt *siConEvnt,
Buffer *uBuf
)
#else
PUBLIC S16 SiUiSitConInd(pst, suId, suInstId, spInstId, circuit, siConEvnt, 
                         uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit; 
SiConEvnt *siConEvnt;
Buffer *uBuf;
#endif
{
   TRC3(SiUiSitConInd)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_UI,(siCb.init.prntBuf,"ConInd : suId=%#x, suInstId=%#lx,\
          spInstId=%#lx, circuit=%#lx, L4 -> L5 \n", \
          suId, suInstId, spInstId, circuit)); 

   /* jump to specific primitive depending on configured selector */
   RETVALUE(*siUiSitConIndMt[pst->selector])(pst, suId, suInstId, spInstId,
                                             circuit, siConEvnt, uBuf);
} /* end of SiUiSitConInd */


/*
*
*      Fun:   upper interface - User Information Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitDatInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
SiInfoEvnt *siInfoEvnt,
Buffer *uBuf
)
#else
PUBLIC S16 SiUiSitDatInd(pst, suId, suInstId, spInstId, circuit, siInfoEvnt, 
                         uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
SiInfoEvnt *siInfoEvnt;
Buffer *uBuf;
#endif
{
   TRC3(SiUiSitDatInd)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_UI,(siCb.init.prntBuf,"DatInd : suId=%#x, suInstId=%#lx,\
          spInstId=%#lx, circuit=%#lx, L4 -> L5 \n", \
          suId, suInstId, spInstId, circuit)); 

   /* jump to specific primitive depending on configured selector */
   RETVALUE(*siUiSitDatIndMt[pst->selector])(pst, suId, suInstId, spInstId,
                                             circuit, siInfoEvnt, uBuf);
} /* end of SiUiSitDatInd */


/*
*
*      Fun:   upper interface - Facility Confirmation
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitFacCfm
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
U8 evntType,
SiFacEvnt *siFacEvnt,
Buffer *uBuf
)
#else
PUBLIC S16 SiUiSitFacCfm(pst, suId, suInstId, spInstId, circuit, 
                         evntType, siFacEvnt, uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
U8 evntType;
SiFacEvnt *siFacEvnt;
Buffer *uBuf;
#endif
{
   TRC3(SiUiSitFacCfm)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_UI,(siCb.init.prntBuf,"FacCfm : suId=%#x, suInstId=%#lx,\
          spInstId=%#lx, circuit=%#lx, evntType=%d, L4 -> L5 \n", \
          suId, suInstId, spInstId, circuit, evntType)); 

   /* jump to specific primitive depending on configured selector */
   RETVALUE(*siUiSitFacCfmMt[pst->selector])(pst, suId, suInstId, spInstId,
                                             circuit, evntType, siFacEvnt, 
                                             uBuf);
} /* end of SiUiSitFacCfm */


/*
*
*      Fun:   upper interface - Facility Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitFacInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
U8 evntType,
SiFacEvnt *siFacEvnt,
Buffer *uBuf
)
#else
PUBLIC S16 SiUiSitFacInd(pst, suId, suInstId, spInstId, circuit, 
                         evntType, siFacEvnt, uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
U8 evntType;
SiFacEvnt *siFacEvnt;
Buffer *uBuf;
#endif
{
   TRC3(SiUiSitFacInd)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_UI,(siCb.init.prntBuf,"FacInd : suId=%#x, suInstId=%#lx,\
          spInstId=%#lx, circuit=%#lx, evntType=%d, L4 -> L5 \n", \
          suId, suInstId, spInstId, circuit, evntType)); 

   /* jump to specific primitive depending on configured selector */
   RETVALUE(*siUiSitFacIndMt[pst->selector])(pst, suId, suInstId, spInstId,
                                             circuit, evntType, siFacEvnt, 
                                             uBuf);
} /* end of SiUiSitFacInd */


/*
*
*      Fun:   upper interface - Release Confirmation
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitRelCfm
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
SiRelEvnt *siRelEvnt,
Buffer *uBuf
)
#else
PUBLIC S16 SiUiSitRelCfm(pst, suId, suInstId, spInstId, circuit, siRelEvnt, 
                         uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
SiRelEvnt *siRelEvnt;
Buffer *uBuf;
#endif
{
   TRC3(SiUiSitRelCfm)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_UI,(siCb.init.prntBuf,"RelCfm : suId=%#x, suInstId=%#lx,\
          spInstId=%#lx, circuit=%#lx, L4 -> L5 \n", \
          suId, suInstId, spInstId, circuit)); 

   /* jump to specific primitive depending on configured selector */
   RETVALUE(*siUiSitRelCfmMt[pst->selector])(pst, suId, suInstId, spInstId,
                                             circuit, siRelEvnt, uBuf);
} /* end of SiUiSitRelCfm */


/*
*
*      Fun:   upper interface - Release Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitRelInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
SiRelEvnt *siRelEvnt,
Buffer *uBuf
)
#else
PUBLIC S16 SiUiSitRelInd(pst, suId, suInstId, spInstId, circuit, siRelEvnt, 
                         uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
SiRelEvnt *siRelEvnt;
Buffer *uBuf;
#endif
{
   TRC3(SiUiSitRelInd)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_UI,(siCb.init.prntBuf,"RelInd : suId=%#x, suInstId=%#lx,\
          spInstId=%#lx, circuit=%#lx, L4 -> L5 \n", \
          suId, suInstId, spInstId, circuit)); 

   /* jump to specific primitive depending on configured selector */
   RETVALUE(*siUiSitRelIndMt[pst->selector])(pst, suId, suInstId, spInstId,
                                             circuit, siRelEvnt, uBuf);
} /* end of SiUiSitRelInd */


/*
*
*      Fun:   upper interface - Call Resume Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitResmInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
SiResmEvnt *siResmEvnt,
Buffer *uBuf
)
#else
PUBLIC S16 SiUiSitResmInd(pst, suId, suInstId, spInstId, circuit,siResmEvnt, 
                          uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
SiResmEvnt *siResmEvnt;
Buffer *uBuf;
#endif
{
   TRC3(SiUiSitResmInd)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_UI,(siCb.init.prntBuf,"ResmInd : suId=%#x, suInstId=%#lx,\
          spInstId=%#lx, circuit=%#lx, L4 -> L5 \n", \
          suId, suInstId, spInstId, circuit)); 

   /* jump to specific primitive depending on configured selector */
   RETVALUE(*siUiSitResmIndMt[pst->selector])(pst, suId, suInstId, 
                                              spInstId, circuit, siResmEvnt, 
                                              uBuf);
} /* end of SiUiSitResmInd */


/*
*
*      Fun:   upper interface - Status Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitStaInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit, 
Bool globalFlag, 
U8 eventType, 
SiStaEvnt *siStaEvnt,
Buffer *uBuf
)
#else
PUBLIC S16 SiUiSitStaInd(pst, suId, suInstId, spInstId, circuit, globalFlag,
        eventType, siStaEvnt, uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit; 
Bool globalFlag; 
U8 eventType; 
SiStaEvnt *siStaEvnt;
Buffer *uBuf;
#endif
{
   TRC3(SiUiSitStaInd)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_UI,(siCb.init.prntBuf,"StaInd : suId=%#x, suInstId=%#lx,\
          spInstId=%#lx, circuit=%#lx, evntType=%d, L4 -> L5 \n", \
          suId, suInstId, spInstId, circuit, eventType)); 

   /* jump to specific primitive depending on configured selector */
   RETVALUE(*siUiSitStaIndMt[pst->selector])(pst, suId, suInstId, spInstId,
                                             circuit, globalFlag, eventType, 
                                             siStaEvnt, uBuf);
} /* end of SiUiSitStaInd */


/*
*
*      Fun:   upper interface - Call Suspend Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitSuspInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
SiSuspEvnt *siSuspEvnt,
Buffer *uBuf
)
#else
PUBLIC S16 SiUiSitSuspInd(pst, suId, suInstId, spInstId, circuit,siSuspEvnt, 
                          uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
SiSuspEvnt *siSuspEvnt;
Buffer *uBuf;
#endif
{
   TRC3(SiUiSitSuspInd)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_UI,(siCb.init.prntBuf,"SuspInd : suId=%#x, suInstId=%#lx,\
          spInstId=%#lx, circuit=%#lx, L4 -> L5 \n", \
          suId, suInstId, spInstId, circuit)); 

   /* jump to specific primitive depending on configured selector */
   RETVALUE(*siUiSitSuspIndMt[pst->selector])(pst, suId, suInstId, 
                                              spInstId, circuit, siSuspEvnt, 
                                              uBuf);
} /* end of SiUiSitSuspInd */

 
#if SS7_FTZ

/*
*
*      Fun:   upper interface - Call FTZ utilities Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 SiUiSitFtzInd
(
Pst *pst,
SuId suId,
SiInstId suInstId,
SiInstId spInstId,
CirId circuit,
U8 evntType,
SiFtzEvnt *siFtzEvnt,
Buffer *uBuf
)
#else
PUBLIC S16 SiUiSitFtzInd(pst, suId, suInstId, spInstId, circuit,
           evntType,siFtzEvnt, uBuf)
Pst *pst;
SuId suId;
SiInstId suInstId;
SiInstId spInstId;
CirId circuit;
U8 evntType;
SiFtzEvnt *siFtzEvnt;
Buffer *uBuf;
#endif
{
   TRC3(SiUiSitFtzInd)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_UI,(siCb.init.prntBuf,"FtzInd : suId=%#x, suInstId=%#lx,\
          spInstId=%#lx, circuit=%#lx, evntType=%d, L4 -> L5 \n", \
          suId, suInstId, spInstId, circuit, evntType)); 

   /* jump to specific primitive depending on configured selector */
   RETVALUE(*siUiSitFtzIndMt[pst->selector])(pst, suId, suInstId,
                                             spInstId, circuit, evntType, 
                                             siFtzEvnt, uBuf);
} /* end of SiUiSitFtzInd */
 
#endif /* SS7_FTZ */


/*
*
*      Fun:   upper interface - unrecognized event Indication
*
*      Desc:  This function passes the unrecognized message  received
*             from network to CC.
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 SiUiSitUMsgInd
(
Pst *pst,
SuId suId,
SiInstId suInstId,
SiInstId spInstId,
CirId circuit,
Buffer *uBuf
)
#else
PUBLIC S16 SiUiSitUMsgInd(pst, suId, suInstId, spInstId, 
                         circuit, uBuf)
Pst *pst;
SuId suId;
SiInstId suInstId;
SiInstId spInstId;
CirId circuit;
Buffer *uBuf;
#endif
{
   TRC3(SiUiSitUMsgInd)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_UI,(siCb.init.prntBuf,"UMsgInd : suId=%#x, suInstId=%#lx,\
          spInstId=%#lx, circuit=%#lx, L4 -> L5 \n", \
          suId, suInstId, spInstId, circuit)); 

   /* jump to specific primitive depending on configured selector */
   RETVALUE(*siUiSitUMsgIndMt[pst->selector])(pst, suId, suInstId,
                                             spInstId, circuit, 
                                             uBuf);
} /* end of SiUiSitUMsgInd */


/*
*
*      Fun:   upper interface - Point code status confirmation
*
*      Desc:  This function returns the status of the point code to the 
*             service user.
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 SiUiSitPtCdeStaCfm
(
Pst      *pst,
SuId     suId,
SiInstId intfId,
U8       status,
U8       congLevel
)
#else
PUBLIC S16 SiUiSitPtCdeStaCfm(pst, suId, intfId, status, congLevel)
Pst      *pst;
SuId     suId;
SiInstId intfId;
U8       status;
U8       congLevel;
#endif
{
   TRC3(SiUiSitPtCdeStaCfm)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_UI,(siCb.init.prntBuf,"PtCdeStaCfm : suId=%#x, intfId=%#lx,\
          status=%#x, congLevel=%#x, L4 -> L5 \n", \
          suId, intfId, status, congLevel)); 

   /* jump to specific primitive depending on configured selector */
   RETVALUE (*siUiSitPtCdeStaCfmMt[pst->selector])(pst, suId, intfId, status, 
                                                   congLevel);
} /* end of SiUiSitPtCdeStaCfm */
 
 
/*
*     portable functions 
*/
#ifdef SIT2

/*
*
*      Fun:   portable - Bind Confirmation
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSitBndCfm
(
Pst  *pst, 
SuId suId, 
U8   status
)
#else
PRIVATE S16 PtUiSitBndCfm(pst, suId, status)
Pst *pst; 
SuId suId; 
U8   status;
#endif
{
   TRC3(PtUiSitBndCfm)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(status);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf, "PtUiSitBndCfm() called.\n"));  
     
#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1702, (ErrVal) 0, "PtUiSitBndCfm() called");
#endif
   RETVALUE(ROK);
} /* end of PtUiSitBndCfm */

#endif


/*
*
*      Fun:   portable - Connection Status Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSitCnStInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
SiCnStEvnt *siCnStEvnt, 
U8 evntType,
Buffer *uBuf
)
#else
PRIVATE S16 PtUiSitCnStInd(pst, suId, suInstId, spInstId, circuit, siCnStEvnt,
        evntType, uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
SiCnStEvnt *siCnStEvnt; 
U8 evntType;
Buffer *uBuf;
#endif
{
   TRC3(PtUiSitCnStInd)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suInstId);
   UNUSED(spInstId);
   UNUSED(circuit);
   UNUSED(siCnStEvnt);
   UNUSED(evntType);
   UNUSED(uBuf);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtUiSitCnStInd Called ! It is to be ported.\n"));  
     
#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1703, (ErrVal) 0, "PtUiSitCnStInd() called");
#endif
   RETVALUE(ROK);
} /* end of PtUiSitCnStInd */


/*
*
*      Fun:   portable - Connection Establishment Confirmation
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSitConCfm
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
SiConEvnt *siConEvnt,
Buffer *uBuf
)
#else
PRIVATE S16 PtUiSitConCfm(pst, suId, suInstId, spInstId, circuit, siConEvnt, 
                          uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
SiConEvnt *siConEvnt;
Buffer *uBuf;
#endif
{
   TRC3(PtUiSitConCfm)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suInstId);
   UNUSED(spInstId);
   UNUSED(circuit);
   UNUSED(siConEvnt);
   UNUSED(uBuf);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtUiSitConCfm Called ! It is to be ported.\n"));  
     
#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1704, (ErrVal) 0, "PtUiSitConCfm() called");
#endif
   RETVALUE(ROK);
} /* end of PtUiSitConCfm */


/*
*
*      Fun:   portable - Connection Establishment Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSitConInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit, 
SiConEvnt *siConEvnt,
Buffer *uBuf
)
#else
PRIVATE S16 PtUiSitConInd(pst, suId, suInstId, spInstId, circuit, siConEvnt, 
                          uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit; 
SiConEvnt *siConEvnt;
Buffer *uBuf;
#endif
{
   TRC3(PtUiSitConInd)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suInstId);
   UNUSED(spInstId);
   UNUSED(circuit);
   UNUSED(siConEvnt);
   UNUSED(uBuf);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtUiSitConInd Called ! It is to be ported.\n"));  
     
#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1705, (ErrVal) 0, "PtUiSitConInd() called");
#endif
   RETVALUE(ROK);
} /* end of PtUiSitConInd */


/*
*
*      Fun:   portable - User Information Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSitDatInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
SiInfoEvnt *siInfoEvnt,
Buffer *uBuf
)
#else
PRIVATE S16 PtUiSitDatInd(pst, suId, suInstId, spInstId, circuit,siInfoEvnt, 
                          uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
SiInfoEvnt *siInfoEvnt;
Buffer *uBuf;
#endif
{

   TRC3(PtUiSitDatInd)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suInstId);
   UNUSED(spInstId);
   UNUSED(circuit);
   UNUSED(siInfoEvnt);
   UNUSED(uBuf);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtUiSitDatInd Called ! It is to be ported.\n"));  
#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1706, (ErrVal) 0, "PtUiSitDatInd() called");
#endif
   RETVALUE(ROK);
} /* end of PtUiSitDatInd */


/*
*
*      Fun:   portable - Facility Confirmation
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSitFacCfm
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
U8 evntType,
SiFacEvnt *siFacEvnt,
Buffer *uBuf
)
#else
PRIVATE S16 PtUiSitFacCfm(pst, suId, suInstId, spInstId, circuit, 
                          evntType, siFacEvnt, uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
U8 evntType;
SiFacEvnt *siFacEvnt;
Buffer *uBuf;
#endif
{
   TRC3(PtUiSitFacCfm)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suInstId);
   UNUSED(spInstId);
   UNUSED(circuit);
   UNUSED(evntType);
   UNUSED(siFacEvnt);
   UNUSED(uBuf);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtUiSitFacCfm Called ! It is to be ported.\n"));  
     
#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1707, (ErrVal) 0, "PtUiSitFacCfm() called");
#endif
   RETVALUE(ROK);
} /* end of PtUiSitFacCfm */


/*
*
*      Fun:   portable - Facility Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSitFacInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
U8 evntType,
SiFacEvnt *siFacEvnt,
Buffer *uBuf
)
#else
PRIVATE S16 PtUiSitFacInd(pst, suId, suInstId, spInstId, circuit, 
                          evntType, siFacEvnt, uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
U8 evntType;
SiFacEvnt *siFacEvnt;
Buffer *uBuf;
#endif
{
   TRC3(PtUiSitFacInd)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suInstId);
   UNUSED(spInstId);
   UNUSED(circuit);
   UNUSED(siFacEvnt);
   UNUSED(evntType);
   UNUSED(uBuf);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtUiSitFacInd Called ! It is to be ported.\n"));  
     
#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1708, (ErrVal) 0, "PtUiSitFacInd() called");
#endif
   RETVALUE(ROK);
} /* end of PtUiSitFacInd */


/*
*
*      Fun:   portable - Release Confirmation
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSitRelCfm
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
SiRelEvnt *siRelEvnt,
Buffer *uBuf
)
#else
PRIVATE S16 PtUiSitRelCfm(pst, suId, suInstId, spInstId, circuit, siRelEvnt, 
                          uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
SiRelEvnt *siRelEvnt;
Buffer *uBuf;
#endif
{
   TRC3(PtUiSitRelCfm)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suInstId);
   UNUSED(spInstId);
   UNUSED(circuit);
   UNUSED(siRelEvnt);
   UNUSED(uBuf);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtUiSitRelCfm Called ! It is to be ported.\n"));  
     
#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1709, (ErrVal) 0, "PtUiSitRelCfm() called");
#endif
   RETVALUE(ROK);
} /* end of PtUiSitRelCfm */


/*
*
*      Fun:   portable - Release Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSitRelInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
SiRelEvnt *siRelEvnt,
Buffer *uBuf
)
#else
PRIVATE S16 PtUiSitRelInd(pst, suId, suInstId, spInstId, circuit, siRelEvnt, 
                          uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
SiRelEvnt *siRelEvnt;
Buffer *uBuf;
#endif
{
   TRC3(PtUiSitRelInd)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suInstId);
   UNUSED(spInstId);
   UNUSED(circuit);
   UNUSED(siRelEvnt);
   UNUSED(uBuf);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtUiSitRelInd Called ! It is to be ported.\n"));  
     
#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1710, (ErrVal) 0, "PtUiSitRelInd() called");
#endif
   RETVALUE(ROK);
} /* end of PtUiSitRelInd */


/*
*
*      Fun:   portable - Call Resume Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSitResmInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
SiResmEvnt *siResmEvnt,
Buffer *uBuf
)
#else
PRIVATE S16 PtUiSitResmInd(pst, suId, suInstId, spInstId, circuit, siResmEvnt,
                           uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
SiResmEvnt *siResmEvnt;
Buffer *uBuf;
#endif
{
   TRC3(PtUiSitResmInd)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suInstId);
   UNUSED(spInstId);
   UNUSED(circuit);
   UNUSED(siResmEvnt);
   UNUSED(uBuf);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtUiSitResmInd Called ! It is to be ported.\n"));  
     
#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1711, (ErrVal) 0, "PtUiSitResmInd() called");
#endif
   RETVALUE(ROK);
} /* end of PtUiSitResmInd */


/*
*
*      Fun:   portable - Status Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSitStaInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit, 
Bool globalFlag, 
U8 eventType, 
SiStaEvnt *siStaEvnt,
Buffer *uBuf
)
#else
PRIVATE S16 PtUiSitStaInd(pst, suId, suInstId, spInstId, circuit, globalFlag, 
        eventType, siStaEvnt, uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit; 
Bool globalFlag; 
U8 eventType; 
SiStaEvnt *siStaEvnt;
Buffer *uBuf;
#endif
{
   TRC3(PtUiSitStaInd)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suInstId);
   UNUSED(spInstId);
   UNUSED(circuit);
   UNUSED(globalFlag);
   UNUSED(eventType);
   UNUSED(siStaEvnt);
   UNUSED(uBuf);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtUiSitStaInd Called ! It is to be ported.\n"));  
     
#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1712, (ErrVal) 0, "PtUiSitStaInd() called");
#endif
   RETVALUE(ROK);
} /* end of PtUiSitStaInd */


/*
*
*      Fun:   portable - Call Suspend Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/

#ifdef ANSI
PRIVATE S16 PtUiSitSuspInd
(
Pst *pst, 
SuId suId, 
SiInstId suInstId, 
SiInstId spInstId, 
CirId circuit,
SiSuspEvnt *siSuspEvnt,
Buffer *uBuf
)
#else
PRIVATE S16 PtUiSitSuspInd(pst, suId, suInstId, spInstId, circuit, siSuspEvnt,
                           uBuf)
Pst *pst; 
SuId suId; 
SiInstId suInstId; 
SiInstId spInstId; 
CirId circuit;
SiSuspEvnt *siSuspEvnt;
Buffer *uBuf;
#endif
{
   TRC3(PtUiSitSuspInd)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suInstId);
   UNUSED(spInstId);
   UNUSED(circuit);
   UNUSED(siSuspEvnt);
   UNUSED(uBuf);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtUiSitSuspInd Called ! It is to be ported.\n"));  
     
#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1713, (ErrVal) 0, "PtUiSitSuspInd() called");
#endif
   RETVALUE(ROK);
} /* end of PtUiSitSuspInd */

#if SS7_FTZ

/*
*
*      Fun:   portable - Call FTZ utilities Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiSitFtzInd
(
Pst *pst,
SuId suId,
SiInstId suInstId,
SiInstId spInstId,
CirId circuit,
U8 evntType,
SiFtzEvnt *siFtzEvnt,
Buffer *uBuf
)
#else
PRIVATE S16 PtUiSitFtzInd(pst, suId, suInstId, spInstId, circuit, 
            evntType,siFtzEvnt, uBuf)
Pst *pst;
SuId suId;
SiInstId suInstId;
SiInstId spInstId;
CirId circuit;
U8 evntType;
SiFtzEvnt *siFtzEvnt;
Buffer *uBuf;
#endif
{
   TRC3(PtUiSitFtzInd)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suInstId);
   UNUSED(spInstId);
   UNUSED(circuit);
   UNUSED(evntType);
   UNUSED(siFtzEvnt);
   UNUSED(uBuf);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtUiSitFtzInd Called ! It is to be ported.\n"));  
     
#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1714, (ErrVal) 0, "PtUiSitFtzInd() called");
#endif
   RETVALUE(ROK);
} /* end of PtUiSitFtzInd */
#endif /* SS7_FTZ */

/*
*
*      Fun:   portable - Unknown Message Indication
*
*      Desc:  This function ...
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtUiSitUMsgInd
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service provider id */
SiInstId suInstId,          /* service user instance id */
SiInstId spInstId,          /* service provider instance id */
CirId     circuit,          /* circuit ID code */
Buffer *uBuf                /* message with unrecognizable parameters */
)
#else
PRIVATE S16 PtUiSitUMsgInd(pst, suId, suInstId, spInstId, circuit, uBuf)
Pst *pst;
SuId suId;
SiInstId suInstId;
SiInstId spInstId;
CirId circuit;
Buffer *uBuf;
#endif
{
   TRC3(PtUiSitUMsgInd)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suInstId);
   UNUSED(spInstId);
   UNUSED(circuit);
   UNUSED(uBuf);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtUiSitUMsgInd Called ! It is to be ported.\n"));  
     
#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1715, (ErrVal) 0, "PtUiSitUMsgInd() called");
#endif
   RETVALUE(ROK);
} /* end of PtUiSitUMsgInd */


/*
*
*      Fun:   PtUiSitPtCdeStaCfm
*
*      Desc:  Portable point code status confirmation
*
*      Ret:   ROK   - ok
*
*      Notes:
*
*      File:  si_ptui.c
*
*/
 
#ifdef ANSI
PUBLIC S16 PtUiSitPtCdeStaCfm
(
Pst      *pst,
SuId     suId,
SiInstId intfId,
U8       status,
U8       congLevel
)
#else
PUBLIC S16 PtUiSitPtCdeStaCfm(pst, suId, intfId, status, congLevel)
Pst      *pst;
SuId     suId;
SiInstId intfId;
U8       status;
U8       congLevel;
#endif
{
   TRC3(PtUiSitPtCdeStaCfm)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(intfId);
   UNUSED(status);
   UNUSED(congLevel);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtUiSitPtCdeStaCfm Called ! It is to be ported.\n"));  
     
#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1716, (ErrVal) 0, "PtUiSitPtCdeStaCfm() called");
#endif
   RETVALUE(ROK);
} /* PtUiSitPtCdeStaCfm */


  
/********************************************************************30**
  
         End of file:     si_ptui.c@@/main/31 - Wed Mar 14 15:31:55 2001
 
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  bn    1. initial release
             ---  jrl   2. trillium development system checkpoint (dvs)
                           at version: 1.0.0.0

1.2          ---  jrl   1. added ifdef LCSIUISIT around some loosely
                           coupled code

1.3          ---  jrl   1. text changes

1.4          ---  bn    1. corrected packing of SiUiSitStaInd

1.5          ---  jrl   1. text changes
 
1.6          ---  bn    1. add support for ansi

1.7          ---  jrl   1. text changes

1.8          ---  rhk   1. miscellaneous changes

1.9          ---  bn    1. add support for ansi 92.
             ---  bn    2. change return( to RETVALUE(
             ---  bn    3. text changes

1.10         ---  bn    1. changed MAXSIUI to MAXSIUISIT.
             ---  bn    2. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.11         ---  bn    1. added siPkOpFwdCalIndA for ansi 88

1.12         ---  bn    1. changed order of siPkOpFwdCalIndA and 
                           siPkOpFwdCalInd in packing of siConEvnt.

1.13         ---  bn    1. add ifdef SP around include spt.x
             ---  bn    2. changed to new interfaces.

1.14         ---  fmg   1. changed CONSTANT PRIVATE to PRIVATE CONSTANT

1.15         ---  bn    1. added support for SW_Q767 and SW_SINGTEL.

1.16         ---  bn    1. moved prototypes of siPkRangStat, and 
                           siPkCirGrpSupMTypInd to si.x, changed them to
                           PUBLIC.

1.17         ---  bn    1. corrections for Italian Q767.

1.18         ---  bn    1. added packing of backward vad to packing of 
                           siConEvnt structure for Italian Q767.
             ---  bn    2. changed packing of circuit to U32 from U16.

1.19         ---  bn    1. replaced ifdef SP by ifdef SI_SPT.

1.20         ---  aa    1. Surrounded the siPkGenAddr under #ifdef SS7_ANS92

1.21         ---  bn    1. Used SLogError for error scenarios
             ---  bn    2. Added macros for calling packing functions.

1.22         ---  pc    1. added support for ETSI SI

1.23         ---  dm    1. added support for GT_FTZ SI
             ---  dm    2. moved packing funcs. for message elements and
                           events in sit.c
             ---  dm    3. added event type in FacInd and FacCfm.
             ---  dm    4. added include cm_ss7.x
             ---  dm    5. removed SEL_LC_OLD and not SSINT2 ans CCVER2
                           sections.

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.24         ---      bn   1. removed all tcLi* functions.
 
1.25         ---      ao   1. added uBuf to upper layer primitives

1.26         ---      rs   1. added procedures for umsg
             ---      rh   1. made MAXSIUISIT a private hash def of 
                              si_ptui.c
                           2. added supported for interface resolution
                              for ISUP Wrapper
             ---      rh   1. removed cm_gen.x dependency
1.27         ---      ym   1. Changes for TCO0003 (Debug TCO)
             ---      rh   1. moved packing functions for loosely coupled
                              upper interface to sit.c
1.28         ---      ym   1. Copyright header is updated.
                           2. Error codes are updated.
1.29         ---      dvs  1. miscellaneous changes
1.30         ---      ym   1. Changes for ISUP v2.18
/main/31     ---      hy   1. Include the sht.[hx] files.
                           2. Updated the error code and header file.
           si018.220  tz   1. Modified SIDBGP to provide more debug prints.              
*********************************************************************91*/

