/*************************************************************************
 * Name: 
 *
 * Type: C Source file
 *
 * Desc: C Source code for XOS OAM registration
 *
 * File: si_bind.c
 *
 * Author: xiaoruo
 **************************************************************************/



/* header include files (.h) */

#include "envopt.h"        /* environment options  */ 
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* general SS7 layer */
#include "cm_hash.h"       /* hash-list header */
#include "lsi.h"           /* layer management */
#include "si_mf.h"         /* message functions */
#include "cm5.h"           /* timers */
#include "ci_db.h"         /* ISUP data base */
#include "sit.h"           /* ISUP */
#include "snt.h"           /* MTP3 */
#ifdef SI_SPT
#include "spt.h"           /* SCCP */
#endif
#include "si.h"            /* ISUP */
#include "si_err.h"        /* ISUP error */
#ifdef IW
#include "cm_atm.h"          /* common ATM defines                 */
#include "cm_cc.h"           /* Common Call Control Hash Defs      */
#include "rmt.h"             /* resource manager defines           */
#include "cct.h"             /* Call Control Interface Header      */
#include "liw.h"             /* ISUP PSIF Layer Management Headers */
#include "iw.h"              /* ISUP PSIF Hash Defines             */
#include "iw_err.h"          /* ISUP PSIF Error Defines            */
#include "iw_ptli.h"         /* o/g SIT i/f funcs. hash defs       */
#endif

#ifdef ZI
#include "cm_pftha.h"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.h"       /* common PSF */
#include "cm_psfft.h"      /* common PSF */
#endif
#include "lzi.h"           /* ISUP PSF management */
#include "zi.h"            /* ISUP PSF */
#include "zi_err.h"        /* ISUP PSF error codes */
#endif /* ZI */

#ifdef SI_FTHA
#include "sht.h"           /* common ftha sh defines */
#endif
/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* general SS7 layer */
#include "cm_lib.x"        /* common library functions */
#include "cm_hash.x"       /* hash-list structure */
#include "lsi.x"           /* layer management */
#include "si_mf.x"            /* message functions */
#include "cm5.x"           /* timers */
#include "ci_db.x"         /* ISUP data base */
#include "sit.x"           /* ISUP */
#include "snt.x"           /* MTP3 */
#ifdef SI_SPT
#include "spt.x"           /* SCCP */
#endif
#ifdef SI_FTHA
#include "sht.x"           /* common ftha sh structure */
#endif
#include "si.x"            /* ISUP */

#ifdef IW
#include "cm_atm.x"          /* common ATM defines                  */
#include "cm_cc.x"           /* Common Call Control Typedefs        */
#include "rmt.x"             /* resource manager function decls.    */
#include "cct.x"             /* Call Control Interface              */
#include "liw.x"             /* ISUP PSIF Layer Management typedefs */
#include "iw.x"              /* ISUP PSIF Typedefs                  */
#endif
#ifdef ZI 
#include "cm_pftha.x"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.x"       /* common PSF */
#include "cm_psfft.x"      /* common PSF */
#endif
#include "lzi.x"           /* ISUP PSF management */
#include "zi.x"            /* ISUP PSF */
#endif /* ZI */

extern Void smSiPstInit(Pst *smSiPst);
extern Void smSiHdrInit(Header *hdr);


S16 siBndItReq(void)
{
    SpId  sapId; 

    SiNSAPCb *pCb = NULLP;
    Pst		smSiPst;

    	  SiMngmt cntrl;
    
    for(sapId = 0; sapId < siCb.genCfg.nmbNSaps; sapId++)
    {
        pCb = SIMTPSAP(sapId);
        
        if(pCb != NULLP)
        {
              /* init header */
			smSiHdrInit(&cntrl.hdr);

			smSiPstInit(&smSiPst);

			smSiPst.event  = EVTLSICNTRLREQ;


			cntrl.hdr.msgType = TCNTRL;
			cntrl.hdr.entId.ent = siCb.init.ent;
			cntrl.hdr.entId.inst = siCb.init.inst;
			cntrl.hdr.elmId.elmnt = STNSAP;

			/* these fields need to be initialized in the new LM i/f requests */
			cntrl.hdr.response.prior    = PRIOR0;
			cntrl.hdr.response.route    = RTESPEC;
#ifdef LCSMSIMILSI
			cntrl.hdr.response.selector = 0;
#else
			cntrl.hdr.response.selector = 2;
#endif

			cntrl.t.cntrl.s.siElmnt.elmntId.sapId = pCb->cfg.nsapId; 
			cntrl.t.cntrl.s.siElmnt.elmntParam.nsap.nsapType = pCb->cfg.sapType;

			cntrl.t.cntrl.subAction = SAELMNT; 
			cntrl.t.cntrl.action = ABND_ENA;

			SiMiLsiCntrlReq(&smSiPst,&cntrl); 
            
        }
    }
    

	  return 0;

}				











