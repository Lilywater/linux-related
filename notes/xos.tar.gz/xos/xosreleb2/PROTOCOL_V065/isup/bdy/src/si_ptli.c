/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

     Name:     ISUP - portable - lower interface

     Type:     C source file

     Desc:     C source code for the ISUP lower interface primitives.

     File:     si_ptli.c

     Sid:      si_ptli.c@@/main/22 - Wed Mar 14 15:31:49 2001
 
     Prg:      bn

*********************************************************************21*/


/*
  
The following functions are provided in this file for the SNT Layer service 
provider:
  
   PtLiSntBndReq       lower interface - Bind Request
   PtLiSntUDatReq      lower interface - Unit Data Request

The following functions are provided in this file for the SPT Layer service 
provider:
  
   PtLiSptBndReq       lower interface - Bind Request
   PtLiSptUDatReq      lower interface - Unit Data Request
 
It is assumed that the following functions are provided in the
SNT Layer service provider file:
  
   SnUiSntBndReq       upper interface - Bind Request
   SnUiSntUDatReq      upper interface - Unit Data Request
  
It is assumed that the following functions are provided in the
SPT Layer service provider file:
  
   SpUiSptBndReq       upper interface - Bind Request
   SpUiSptUDatReq      upper interface - Unit Data Request
 
*/

  
/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*
*/
 

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lsi.h"           /* layer management */
#include "si_mf.h"            /* message functions */
#include "ci_db.h"         /* ISUP data base */
#include "cm_ss7.h"        /* common SS7 defines */
#include "cm_hash.h"       /* hash-list header */
#include "snt.h"           /* mtp level 3 */
#ifdef SI_SPT
#include "spt.h"           /* sccp */
#endif
#ifdef SI_FTHA
#include "sht.h"           /* sht interface */
#endif
#include "sit.h"           /* ISUP */
#include "cm5.h"           /* common timers  */
#include "si.h"            /* ISUP */
#include "si_err.h"        /* ISUP error */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* general SS7 layer */
#include "cm_hash.x"       /* hash-list structure */
#include "lsi.x"           /* layer management */
#include "si_mf.x"            /* message functions */
#include "snt.x"           /* mtp level 3 */
#ifdef SI_SPT
#include "spt.x"           /* sccp */
#endif
#include "ci_db.x"         /* ISUP data base */
#include "sit.x"           /* ISUP */
#include "cm5.x"           /* common timers  */
#ifdef SI_FTHA
#include "sht.x"           /* sht interface */
#endif
#include "si.x"            /* ISUP */


/* local defines */

/* local typedefs */
  
/* local externs */

/* forward references */


  
/* portable functions */
PRIVATE S16 PtLiSntBndReq ARGS((Pst *pst, SuId suId, SpId spId,
            SrvInfo srvInfo));
PRIVATE S16 PtLiSntUDatReq ARGS ((Pst *pst, SpId spId, Dpc cgAdr, Dpc cdAdr, 
            SrvInfo srvInfo, LnkSel lnkSel, Priority priority, Buffer *mBuf));
#ifdef SNT2
PRIVATE S16 PtLiSntStaReq ARGS((Pst *pst, SpId spId, Dpc phyDpc));
#endif

#ifdef L3
/* portable functions */
PRIVATE S16 tcLiSntBndReq ARGS((Pst *pst, SuId suId, SpId spId,
            SrvInfo srvInfo));
PRIVATE S16 tcLiSntUDatReq ARGS ((Pst *pst, SpId spId, Dpc cgAdr, Dpc cdAdr, 
            SrvInfo srvInfo, LnkSel lnkSel, Priority priority, Buffer *mBuf));
#ifdef SNT2
PRIVATE S16 tcLiSntStaReq ARGS((Pst *pst, SpId spId, Dpc phyDpc));
#endif

#endif
#ifdef SI_SPT

/* portable functions */
PRIVATE S16 PtLiSptBndReq ARGS((Pst *pst, SuId suId, SpId spId, Ssn ssn));
PRIVATE S16 PtLiSptUDatReq ARGS((Pst *pst, SpId spId, 
            SpUDatEvnt *pUData, Buffer *mBuf));

#endif /* SI_SPT */

#ifdef L3
EXTERN S16 SnUiSntBndReq ARGS((Pst *pst, SuId suId, SpId spId, SrvInfo srvInfo));
EXTERN S16 SnUiSntUDatReq ARGS((Pst *pst, SpId spId, Dpc cgAdr, Dpc cdAdr, SrvInfo srvInfo, LnkSel lnkSel, Priority prior, Buffer *mBuf));
#ifdef SNT2
EXTERN S16 SnUiSntStaReq ARGS((Pst *pst, SpId spId, Dpc adr));
#endif
#endif

#ifdef LCSILISNT_XOS
PUBLIC S16 aPkSntUDatReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Dpc opc,                        /* originating pont code */
Dpc dpc,                        /* destination point code */
SrvInfo sInfo,                  /* service information */
LnkSel sls,                     /* signalling link selector */
Priority prior,                 /* priority */
Buffer *mBuf                    /* message buffer */
);

#endif


/* public variable declarations */


/*
  
the following matrices define the mapping between the primitives
called by the lower interface of isup and the corresponding
primitives of the mtp level 3 service providers(s).

The parameter MAXSILISNT defines the maximum number of service providers. 
There is an array of functions per primitive invoked by isup. 
Every array is MAXSILISNT long (i.e. there are as many functions as the number
of service providers).

The dispatching is performed by the configurable variable: selector.
The selector is configured on a per SAP basis.

The selectors are:

   0 - loosely coupled (#define LCSILISNT)
   1 - loosely coupled (#define LCSILISNT) backw. comp. NO more supported
   2 -  snt (#define SN)

*/
 
  
/* Bind Request primitive */
  
PRIVATE CONSTANT SntBndReq siLiSntBndReqMt [MAXSILISNT] =
{
#ifdef LCSILISNT
   cmPkSntBndReq,          /* 0 - loosely coupled - fc */
#else  
   PtLiSntBndReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef LCSILISNT
   PtLiSntBndReq,          /* 1 - loosely coupled  - bc */
#else  
   PtLiSntBndReq,          /* 1 - tightly coupled, portable */
#endif
#ifdef L3
   tcLiSntBndReq,          /* 2 - tightly coupled, SNT */
#else
   PtLiSntBndReq,          /* 2 - tightly coupled, portable */
#endif
#ifdef IT
/* si032.220: modification - changed M3UA primitive name as ItLiSntBndReq 
 * does not exist */
   ItUiSntBndReq,          /* 3 - tightly coupled, SNT M3UA */
#else
   PtLiSntBndReq,          /* 3 - tightly coupled, portable */
#endif
#ifdef LCSILISNT_XOS
   cmPkSntBndReq,          /* 4 - loosely coupled - fc */
#else  
   PtLiSntBndReq,          /* 4 - tightly coupled, portable */
#endif
};
  
  
/* Unit Data Request primitive */
  
PRIVATE CONSTANT SntUDatReq siLiSntUDatReqMt [MAXSILISNT] =
{
#ifdef LCSILISNT
   cmPkSntUDatReq,         /* 0 - loosely coupled - fc */
#else  
   PtLiSntUDatReq,         /* 0 - loosely coupled, portable */
#endif 
#ifdef LCSILISNT
   PtLiSntUDatReq,         /* 1 - loosely coupled - bc */
#else  
   PtLiSntUDatReq,         /* 1 - loosely coupled, portable */
#endif 
#ifdef L3
   tcLiSntUDatReq,         /* 2 - tightly coupled, SNT */
#else
   PtLiSntUDatReq,         /* 2 - tightly coupled, portable */
#endif
#ifdef IT
/* si032.220: modification - changed M3UA primitive name as ItLiSntUDatReq 
 * does not exist */
   ItUiSntUDatReq,         /* 3 - tightly coupled, SNT M3UA */
#else
   PtLiSntUDatReq,         /* 3 - tightly coupled, portable */
#endif
#ifdef LCSILISNT_XOS
   aPkSntUDatReq,          /* 4 - loosely coupled - fc */
#else  
   PtLiSntUDatReq,         /* 4 - loosely coupled, portable */
#endif 
};


#ifdef SNT2
/* Status Request */
PRIVATE CONSTANT SntStaReq siLiSntStaReqMt [MAXSILISNT] =
{
#ifdef LCSILISNT
   cmPkSntStaReq,          /* 0 - loosely coupled - fc */
#else  
   PtLiSntStaReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef LCSILISNT
   PtLiSntStaReq,          /* 1 - loosely coupled  - bc */
#else  
   PtLiSntStaReq,          /* 1 - tightly coupled, portable */
#endif
#ifdef L3
   tcLiSntStaReq,          /* 2 - tightly coupled, SNT */
#else
   PtLiSntStaReq,          /* 2 - tightly coupled, portable */
#endif
#ifdef IT
/* si032.220: modification - changed M3UA primitive name as ItLiSntStaReq 
 * does not exist */
   ItUiSntStaReq,          /* 3 - tightly coupled, SNT M3UA */
#else
   PtLiSntStaReq,          /* 3 - tightly coupled, portable */
#endif
#ifdef LCSILISNT_XOS
   cmPkSntStaReq,          /* 4 - loosely coupled - fc */
#else  
   PtLiSntStaReq,          /* 4 - loosely coupled, portable */
#endif
};
#endif /* SNT2 */


/*
  
the following matrices define the mapping between the primitives
called by the lower interface of isup and the corresponding
primitives of the sccp service providers(s).

The parameter MAXSILISPT defines the maximum number of service providers.
There is an array of functions per primitive invoked by isup. 
Every array is MAXSILISPT long (i.e. there are as many functions as the number
of service providers).

The dispatching is performed by the configurable variable: selector.
The selector is configured on a per SAP basis.

The selectors are:

   0 - loosely coupled (#define LCSILISPT)
   1 - spt (#define SP)

*/
#ifdef SI_SPT 
  
/* Bind Request primitive */
  
PRIVATE CONSTANT SptBndReq siLiSptBndReqMt [MAXSILISPT] =
{
#ifdef LCSILISPT
   cmPkSptBndReq,          /* 0 - loosely coupled - fc */
#else  
   PtLiSptBndReq,          /* 0 - loosely coupled, portable */
#endif
#ifdef SP
   SpUiSptBndReq,          /* 1 - tightly coupled, SPT */
#else
   PtLiSptBndReq,          /* 1 - tightly coupled, portable */
#endif
};
  
  
/* Unit Data Request primitive */
  
PRIVATE CONSTANT SptUDatReq siLiSptUDatReqMt [MAXSILISPT] =
{
#ifdef LCSILISPT
   cmPkSptUDatReq,         /* 0 - loosely coupled - fc */
#else  
   PtLiSptUDatReq,         /* 0 - loosely coupled, portable */
#endif 
#ifdef SP
   SpUiSptUDatReq,         /* 1 - tightly coupled, SPT */
#else
   PtLiSptUDatReq,         /* 1 - tightly coupled, portable */
#endif
};
#endif 

  
/*
*     lower interface functions for mtp - level 3
*/

  
/*
*
*       Fun:   lower interface - MTP 3 Bind Request
*
*       Desc:  This function binds the ISUP service user with the 
*              MTP 3 network layer service provider. The MTP3
*              network layer software will register this new service
*              user and will allocate a Service Access Point (SAP) for
*              this bind. The ISUP will specify the reference
*              number that will be used for the duration of this bind.
*
*       Ret:   ROK.
*
*       Notes: None
*
*       File:  si_ptli.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SiLiSntBndReq
(
Pst *pst,                   /* Bind Configuration */
SuId suId,                  /* service user id */
SpId spId,                  /* Service provider Id */
SrvInfo srvInfo             /* service information */       
)
#else
PUBLIC S16 SiLiSntBndReq(pst, suId, spId, srvInfo)
Pst *pst;                   /* Bind Configuration */
SuId suId;                  /* service user id */
SpId spId;                  /* Service provider Id */
SrvInfo srvInfo;            /* service information */       
#endif
{
   TRC3(SiLiSntBndReq)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_LI,(siCb.init.prntBuf,"BndReq : suId=%#x, spId=%#x,\
          L3 <- L4\n", suId, spId)); 

   /* jump to specific primitive depending on configured selector */
/* si031.220: Modification - due to ldf-m3ua support */
#ifdef DN
   if (pst->dstEnt == ENTSN && pst->route != RTE_PROTO)
      RETVALUE(DnUiSntBndReq(pst, suId, spId, srvInfo));
#endif /* DN */
#ifdef DV
   if (pst->dstEnt == ENTIT && pst->route != RTE_PROTO)
      RETVALUE(DvUiSntBndReq(pst, suId, spId, srvInfo));
#endif /* DV */
   RETVALUE(*siLiSntBndReqMt[pst->selector])(pst, suId, spId, srvInfo);
} /* end of SiLiSntBndReq */
  
  
/*
*
*       Fun:   lower interface - MTP 3 Unit Data Request
*
*       Desc:  This function tells the MTP 3 Network Layer to transmit data
*              
*       Ret:   ROK.
*
*       Notes: None
*
*       File:  si_ptli.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SiLiSntUDatReq
(
Pst *pst,                   /* post structure */     
SpId spId,                  /* service provider id */
Dpc cgAdr,                  /* calling address */
Dpc cdAdr,                  /* called address */
SrvInfo srvInfo,            /* service information */       
LnkSel lnkSel,              /* link selection */
Priority prior,             /* congestion priority */
Buffer *mBuf                /* data buffer */
)
#else
PUBLIC S16 SiLiSntUDatReq(pst, spId, cgAdr, cdAdr, srvInfo, lnkSel, prior,mBuf)
Pst *pst;                   /* post structure */     
SpId spId;                  /* service provider id */
Dpc cgAdr;                  /* calling address */
Dpc cdAdr;                  /* called address */
SrvInfo srvInfo;            /* service information */       
LnkSel lnkSel;              /* link selection */
Priority prior;             /* congestion priority */
Buffer *mBuf;               /* data buffer */
#endif
{
   TRC3(SiLiSntUDatReq)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_LI,(siCb.init.prntBuf,"UDatReq : spId=%#x, cgAdr=%#lx,\
          cdAdr=%#lx, srvInfo=%#x, lnkSel=%#x, prior=%#x, L3 <- L4\n", \
          spId, cgAdr, cdAdr, srvInfo, lnkSel, prior)); 

   /* jump to specific primitive depending on configured selector */
/* si031.220: Modification - due to ldf-m3ua support */
#ifdef DN
   if (pst->dstEnt == ENTSN && pst->route != RTE_PROTO)
      RETVALUE(DnUiSntUDatReq(pst, spId, cgAdr, cdAdr, srvInfo,
                              lnkSel, prior, mBuf));
#endif /* DN */
#ifdef DV
   if (pst->dstEnt == ENTIT && pst->route != RTE_PROTO)
      RETVALUE(DvUiSntUDatReq(pst, spId, cgAdr, cdAdr, srvInfo,
                              lnkSel, prior, mBuf));
#endif /* DV */
   RETVALUE(*siLiSntUDatReqMt[pst->selector])(pst, spId, cgAdr, cdAdr, srvInfo, 
         lnkSel, prior, mBuf);
}  /* end of SiLiSntUDatReq */

#ifdef SNT2
  
/*
*
*       Fun:   lower interface - MTP 3 Status Request
*
*       Desc:  This function tells the MTP 3 Layer to enquire DPC status
*              
*       Ret:   ROK.
*
*       Notes: None
*
*       File:  si_ptli.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SiLiSntStaReq
(
Pst  *pst,                  /* post structure */     
SpId spId,                  /* service provider id */
Dpc  adr                    /* called address */
)
#else
PUBLIC S16 SiLiSntStaReq(pst, spId, adr)
Pst  *pst;                  /* post structure */     
SpId spId;                  /* service provider id */
Dpc  adr;                   /* called address */
#endif
{
   TRC3(SiLiSntStaReq)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_LI,(siCb.init.prntBuf,"StaReq : spId=%#x, adr=%#lx,\
          L3 <- L4\n", spId, adr)); 

   /* jump to specific primitive depending on configured selector */
/* si031.220: Modification - due to ldf-m3ua support */
#ifdef DN
   if (pst->dstEnt == ENTSN && pst->route != RTE_PROTO)
      RETVALUE(DnUiSntStaReq(pst, spId, adr));
#endif /* DN */
#ifdef DV
   if (pst->dstEnt == ENTIT && pst->route != RTE_PROTO)
      RETVALUE(DvUiSntStaReq(pst, spId, adr));
#endif /* DV */
   RETVALUE(*siLiSntStaReqMt[pst->selector])(pst, spId, adr);
}  /* end of SiLiSntStaReq */
#endif


/*
*     portable functions 
*/

  
/*
*
*       Fun:   portable - MTP 3 Bind Request
*
*       Desc:  This function binds the ISUP service user
*              with the MTP 3 network layer service provider. The MTP 3
*              network layer software will register this new service
*              user and will allocate a Service Access Point (SAP) for
*              this bind. The service user will specify the reference
*              number that will be used for the duration of this bind.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptli.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtLiSntBndReq
(
Pst *pst,                   /* post structure */     
SuId suId,                  /* service user id */
SpId spId,                  /* Service provider Id */
SrvInfo srvInfo             /* service information */       
)
#else
PRIVATE S16 PtLiSntBndReq(pst, suId, spId, srvInfo)
Pst *pst;                   /* post structure */     
SuId suId;                  /* service user id */
SpId spId;                  /* Service provider Id */
SrvInfo srvInfo;            /* service information */       
#endif
{
   TRC3(PtLiSntBndReq)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(spId);
   UNUSED(srvInfo);

#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1689, (ErrVal) 0, "PtLiSntBndReq() called");
#endif
   RETVALUE(ROK);
} /* end of PtLiSntBndReq */
  
  
/*
*
*       Fun:   portable - MTP 3 Unit Data Request
*
*       Desc:  This function tells the MTP 3 Layer to transmit data
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptli.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtLiSntUDatReq
(
Pst *pst,                   /* post structure */     
SpId spId,                  /* service provider id */
Dpc cgAdr,                  /* calling address */
Dpc cdAdr,                  /* called address */
SrvInfo srvInfo,            /* service information */       
LnkSel lnkSel,              /* link selection */
Priority prior,             /* congestion priority */
Buffer *mBuf                /* data buffer */
)
#else
PRIVATE S16 PtLiSntUDatReq(pst, spId, cgAdr, cdAdr, srvInfo, lnkSel, prior, 
        mBuf)
Pst *pst;                   /* post structure */     
SpId spId;                  /* service provider id */
Dpc cgAdr;                  /* calling address */
Dpc cdAdr;                  /* called address */
SrvInfo srvInfo;            /* service information */       
LnkSel lnkSel;              /* link selection */
Priority prior;             /* congestion priority */
Buffer *mBuf;               /* data buffer */
#endif
{
   TRC3(PtLiSntUDatReq)
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(cgAdr);
   UNUSED(cdAdr);
   UNUSED(srvInfo);
   UNUSED(lnkSel);
   UNUSED(prior);
   UNUSED(mBuf);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtLiSntUDatReq Called ! It is to be ported.\n"));  
     

#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1690, (ErrVal) 0, "PtLiSntUDatReq() called");
#endif
   RETVALUE(ROK);
}  /* end of PtLiSntUDatReq */

#ifdef SNT2
  
/*
*
*       Fun:   portable - MTP 3 Status Request
*
*       Desc:  This function tells the MTP 3 Layer to enquire DPC status
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptli.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtLiSntStaReq
(
Pst *pst,                   /* post structure */     
SpId spId,                  /* service provider id */
Dpc  adr                   /* called address */
)
#else
PRIVATE S16 PtLiSntStaReq(pst, spId, adr)
Pst *pst;                   /* post structure */     
SpId spId;                  /* service provider id */
Dpc  adr;                   /* called address */
#endif
{
   TRC3(PtLiSntStaReq)
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(adr);


   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
             "PtLiSntStaReq Called ! It is to be ported.\n"));  

#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1691, (ErrVal) 0, "PtLiSntStaReq() called");
#endif
   RETVALUE(ROK);
}  /* end of PtLiSntStaReq */
#endif


/*
*     tightly coupled lower interface  functions 
*/

#ifdef L3
  
/*
*
*       Fun:   portable - MTP 3 Bind Request
*
*       Desc:  This function binds the ISUP service user
*              with the MTP 3 network layer service provider. The MTP 3
*              network layer software will register this new service
*              user and will allocate a Service Access Point (SAP) for
*              this bind. The service user will specify the reference
*              number that will be used for the duration of this bind.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptli.c
*
*/
  
#ifdef ANSI
PRIVATE S16 tcLiSntBndReq
(
Pst *pst,                   /* post structure */     
SuId suId,                  /* service user id */
SpId spId,                  /* Service provider Id */
SrvInfo srvInfo             /* service information */       
)
#else
PRIVATE S16 tcLiSntBndReq(pst, suId, spId, srvInfo)
Pst *pst;                   /* post structure */     
SuId suId;                  /* service user id */
SpId spId;                  /* Service provider Id */
SrvInfo srvInfo;            /* service information */       
#endif
{

   TRC3(tcLiSntBndReq)

   SnUiSntBndReq(pst, suId, spId, srvInfo);

   RETVALUE(ROK);
} /* end of tcLiSntBndReq */
  
  
/*
*
*       Fun:   portable - MTP 3 Unit Data Request
*
*       Desc:  This function tells the MTP 3 Layer to transmit data
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptli.c
*
*/
  
#ifdef ANSI
PRIVATE S16 tcLiSntUDatReq
(
Pst *pst,                   /* post structure */     
SpId spId,                  /* service provider id */
Dpc cgAdr,                  /* calling address */
Dpc cdAdr,                  /* called address */
SrvInfo srvInfo,            /* service information */       
LnkSel lnkSel,              /* link selection */
Priority prior,             /* congestion priority */
Buffer *mBuf                /* data buffer */
)
#else
PRIVATE S16 tcLiSntUDatReq(pst, spId, cgAdr, cdAdr, srvInfo, lnkSel, prior, 
        mBuf)
Pst *pst;                   /* post structure */     
SpId spId;                  /* service provider id */
Dpc cgAdr;                  /* calling address */
Dpc cdAdr;                  /* called address */
SrvInfo srvInfo;            /* service information */       
LnkSel lnkSel;              /* link selection */
Priority prior;             /* congestion priority */
Buffer *mBuf;               /* data buffer */
#endif
{
   TRC3(tcLiSntUDatReq)
   SIDBGP(DBGMASK_LI,(siCb.init.prntBuf,"UDatReq : L3 <- L4      \n"));  


   SnUiSntUDatReq(pst, spId, cgAdr, cdAdr, srvInfo, lnkSel, prior, mBuf);

   RETVALUE(ROK);
}  /* end of tcLiSntUDatReq */

#ifdef SNT2
  
/*
*
*       Fun:   tightly coupled  - MTP 3 Unit Data Request
*
*       Desc:  This function tells the MTP 3 Layer to enquire DPC status
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptli.c
*
*/
  
#ifdef ANSI
PRIVATE S16 tcLiSntStaReq
(
Pst *pst,                   /* post structure */     
SpId spId,                  /* service provider id */
Dpc  adr                    /* called address */
)
#else
PRIVATE S16 tcLiSntStaReq(pst, spId, adr)
Pst *pst;                   /* post structure */     
SpId spId;                  /* service provider id */
Dpc  adr;                   /* called address */
#endif
{
   TRC3(tcLiSntStaReq)

   SIDBGP(DBGMASK_LI,(siCb.init.prntBuf,"StaReq : L3 <- L4      \n"));  

   SnUiSntStaReq(pst, spId, adr);

   RETVALUE(ROK);
}  /* end of tcLiSntUDatReq */
#endif /* SNT2 */
#endif

#ifdef SI_SPT
  
/*
*     lower interface functions for sccp
*/

  
/*
*
*       Fun:   lower interface - SCCP Bind Request
*
*       Desc:  This function binds the SCCP upper layer service user
*              with the SCCP network layer service provider. The SCCP
*              network layer software will register this new service
*              user and will allocate a Service Access Point (SAP) for
*              this bind. The service user will specify the reference
*              number that will be used for the duration of this bind.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  si_ptli.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SiLiSptBndReq
(
Pst *pst,                       /* post structure */
SuId suId,                      /* service user id */
SpId spId,                      /* service provider id */
Ssn ssn                         /* subsystem number  */
)
#else
PUBLIC S16 SiLiSptBndReq(pst, suId, spId, ssn)
Pst *pst;                       /* post structure */
SuId suId;                      /* service user id */
SpId spId;                      /* service provider id */
Ssn ssn;                        /* subsystem number  */
#endif
{
   TRC3(SiLiSptBndReq)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_LI,(siCb.init.prntBuf,"BndReq : suId=%#x, spId=%#x, \
          ssn=%#x, L3 <- L4 SPT\n", suId, spId, ssn));  

   /* jump to specific primitive depending on configured selector */
#ifdef DP
   if (pst->route != RTE_PROTO)
      RETVALUE(DpUiSptBndReq(pst, suId, spId, ssn));
#endif /* DP */
   RETVALUE(*siLiSptBndReqMt[pst->selector])(pst, suId, spId, ssn);
} /* end of SiLiSptBndReq */
  
  
/*
*
*       Fun:   lower interface - SCCP Unit Data Request
*
*       Desc:  This function tells the SCCP Layer to transmit data
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  si_ptli.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SiLiSptUDatReq
(
Pst *pst,                   /* Bind Configuration */
SpId spId,                  /* service provider id */
SpUDatEvnt *pUData,         /* pointer to Unit Data Event */
Buffer *mBuf                /* data buffer */
)
#else
PUBLIC S16 SiLiSptUDatReq(pst, spId, pUData, mBuf)
Pst *pst;                   /* Bind Configuration */
SpId spId;                  /* service provider id */
SpUDatEvnt *pUData;         /* pointer to Unit Data Event */
Buffer *mBuf;               /* data buffer */
#endif
{
   TRC3(SiLiSptUDatReq)
   /* si018.220: modificaition - modify SIDBGP to provide more info */
   SIDBGP(DBGMASK_LI,(siCb.init.prntBuf,"UDatReq : spId=%#x, \
          L3 <- L4 SPT\n", spId));  

   /* jump to specific primitive depending on configured selector */
#ifdef DP
   if (pst->route != RTE_PROTO)
      RETVALUE(DpUiSptUDatReq(pst, spId, pUData, mBuf));
#endif /* DP */
   RETVALUE(*siLiSptUDatReqMt[pst->selector])(pst, spId, pUData, mBuf);
}  /* end of SiLiSptUDatReq */


/*
*     portable functions 
*/

  
/*
*
*       Fun:   portable - SCCP Bind Request
*
*       Desc:  This function binds the SCCP upper layer service user
*              with the SCCP network layer service provider. The SCCP
*              network layer software will register this new service
*              user and will allocate a Service Access Point (SAP) for
*              this bind. The service user will specify the reference
*              number that will be used for the duration of this bind.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptli.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtLiSptBndReq
(
Pst *pst,            /* Bind Configuration */
SuId suId,           /* service user id */
SpId spId,           /* service provider id */
Ssn ssn              /* subsystem number  */
)
#else
PRIVATE S16 PtLiSptBndReq(pst, suId, spId, ssn)
Pst *pst;            /* Bind Configuration */
SuId suId;           /* service user id */
SpId spId;           /* service provider id */
Ssn ssn;             /* subsystem number  */
#endif
{
   TRC3(PtLiSptBndReq)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(spId);
   UNUSED(ssn);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
            "PtLiSptBndReq called. To be ported\n"));  

#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1692, (ErrVal) 0, "PtLiSptBndReq() called");
#endif
   RETVALUE(ROK);
} /* end of PtLiSptBndReq */
  
  
/*
*
*       Fun:   portable - SCCP Unit Data Request
*
*       Desc:  This function tells the SCCP Layer to transmit data
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  si_ptli.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtLiSptUDatReq
(
Pst *pst,                   /* Bind Configuration */
SpId spId,                  /* service provider id */
SpUDatEvnt *pUData,         /* pointer to Unit Data Event */
Buffer *mBuf                /* data buffer */
)
#else
PRIVATE S16 PtLiSptUDatReq(pst, spId, pUData, mBuf)
Pst *pst;                   /* Bind Configuration */
SpId spId;                  /* service provider id */
SpUDatEvnt *pUData;         /* pointer to Unit Data Event */
Buffer *mBuf;               /* data buffer */
#endif
{
   TRC3(PtLiSptUDatReq)
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(pUData);
   UNUSED(mBuf);

   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
            "PtLiSptUDatReq called. To be ported\n"));  

#if (ERRCLASS & ERRCLS_DEBUG)
   SILOGERROR(ERRCLS_DEBUG, ESI1693, (ErrVal) 0, "PtLiSptUDatReq() called");
#endif
   RETVALUE(ROK);
}  /* end of PtLiSptUDatReq */

#endif

  
/********************************************************************30**
  
         End of file:     si_ptli.c@@/main/22 - Wed Mar 14 15:31:49 2001
 
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      bn   1. initial release
             ---      jrl  2. trillium development system checkpoint (dvs)
                              at version: 1.0.0.0
 
1.2          ---      bn   1. change packing of cdAdr from U16 to U32 in
                              siPkLiSntUDatReq

1.3          ---      jrl  1. text changes

1.4          ---      rhk  1. miscellaneous changes

1.5          ---      bn   1. text changes
             ---      bn   2. add include cm5.h and cm5.x

1.6          ---      bn   1. change ANS88 to SS7_ANS88, ANS92 to
                              SS7_ANS92 SS7_ANS92

1.7          ---      bn   1. add ifdef SP around include spt.x and spt.h

1.8          ---      bn   1. add #ifdef SN around tightly coupled interface 
                              functions to MTP 3.

1.9          ---      fmg  1. changed CONSTANT PRIVATE to PRIVATE CONSTANT
             ---      fmg  2. conditionally compile in i in PkBndReq
                               to avoid compiler warnings.

1.10         ---      bn   1. added declaration for S16 i in tcLiSntBndReq.
             ---      bn   2. put #ifdef SN around tcLiSnt functions.

1.11         ---      bn   1. removed #include cm2.x.                        

1.12         ---      bn   1. replaced ifdef SP by ifdef SI_SPT.

1.13         ---      kss  1. Fixed syntax error

1.14         ---      bn   1. changed parameters in SiLiSntUDatReq
             ---      bn   2. removed calls to SError
             ---      bn   3. added macros for calling packing functions.

1.15         ---      pc   1. added ETSI variant for SI

1.16         ---      dm   1. added GT_FTZ variant for SI
             ---      dm   2. added include cm_ss7.x
             ---      dm   3. removed SEL_LC_OLD and not SSINT2 sections

1.17         ---      rs   1. added include files cm_hash.x and cm_hash.h

1.18         ---      rs   1. Modification for status request to lower interface.

1.19         ---      ym   1. File header is updated to the new one. 
                           2. Error codes are updated.
1.20         ---      dvs  1. miscellaneous changes
1.21         ---      ym   1. Changes for ISUP v2.18
/main/22     ---      ym   1. Added the tightly coupled functions for 
                              M3UA layer (product code it)
                      sk   1. Addition of MTP3/SCCP LDF calls
            si018.220 tz   1. Modified SIDBGP to provide more debug prints.
            si031.220 tz   1. Modified code to support LDF-M3UA.
            si032.220 tz   1. Modified code tight coupling with M3UA.
*********************************************************************91*/
