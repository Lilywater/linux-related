/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

    Name:     ISUP - body 5

    Type:     C source file

    Desc:     C source code for ISUP Upper Layer, Lower Layer,
              System Service and Layer Management service user primitives
              supplied by TRILLIUM.

              Part 5: Support Functions;

    File:     ci_bdy5.c

    Sid:      ci_bdy5.c@@/main/48 - Wed Jul 25 13:20:51 2001
 
    Prg:      na

*********************************************************************21*/


/************************************************************************

     Note: 

     This file has been extracted to support the following options:

     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif


************************************************************************/


/*
It is assumed that the following functions are provided in the system
services service provider file:

     SInitQueue     Initialize Queue
     SQueueFirst    Queue to First Place
     SQueueLast     Queue to Last Place
     SDequeueFirst  Dequeue from First Place
     SDequeueLast   Dequeue from Last Place
     SFlushQueue    Flush Queue
     SCatQueue      Concatenate Queue
     SFndLenQueue   Find Length of Queue

     SGetMsg        Get Message
     SPutMsg        Put Message
     SInitMsg       Initialize Message

     SAddPreMsg     Add Pre Message
     SAddPstMsg     Add Post Message
     SRemPreMsg     Remove Pre Message
     SRemPstMsg     Remove Post Message
     SExamMsg       Examine Message
     SFndLenMsg     Find Length of Message
     SCopyMsgMsg    Copy Message to Message
     SCatMsg        Concatenate Message
     SSegMsg        Segment Message

     SChkRes        Check Resources
     SRegTmr        Register Activate Task - timer

*/


/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.             description
*     --------    ----------------------------------------------
*
*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* general SS7 layer */
#include "cm_hash.h"       /* hash-list header */
#include "lsi.h"           /* layer management */
#include "si_mf.h"         /* message functions */
#include "cm5.h"           /* timers */
#include "ci_db.h"         /* isup data base */
#include "sit.h"           /* isup */
#include "snt.h"           /* MTP3 */
#ifdef SI_SPT
#include "spt.h"           /* SCCP */
#endif
#ifdef SI_FTHA
#include "sht.h"           /* sht interface */
#endif
#include "si.h"            /* isup */
#include "si_err.h"        /* isup error */
#ifdef IW
#include "cm_atm.h"          /* common ATM defines                 */
#include "cm_cc.h"           /* Common Call Control Hash Defs      */
#include "rmt.h"             /* resource manager defines           */
#include "cct.h"             /* Call Control Interface Header      */
#include "liw.h"             /* ISUP PSIF Layer Management Headers */
#include "iw.h"              /* ISUP PSIF Hash Defines             */
#include "iw_err.h"          /* ISUP PSIF Error Defines            */
#include "iw_ptli.h"         /* o/g SIT i/f funcs. hash defs       */
#endif

#ifdef ZI
#include "cm_pftha.h"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.h"       /* common PSF */
#include "cm_psfft.h"      /* common PSF */
#endif

#include "lzi.h"           /* ISUP PSF management */
#include "zi.h"            /* ISUP PSF */
#include "zi_err.h"        /* ISUP PSF error codes */
#endif /* ZI */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* general SS7 layer */
#include "cm_hash.x"       /* hash-list structure */
#include "cm_lib.x"        /* common library functions */
#include "lsi.x"           /* layer management */
#include "si_mf.x"         /* message functions */
#include "cm5.x"           /* timers */
#include "ci_db.x"         /* isup data base */
#include "sit.x"           /* isup */
#include "snt.x"           /* MTP3 */
#ifdef SI_SPT
#include "spt.x"           /* SCCP */
#endif
#ifdef SI_FTHA
#include "sht.x"           /* sht interface */
#endif
#include "si.x"            /* isup */

#ifdef IW
#include "cm_atm.x"          /* common ATM defines                  */
#include "cm_cc.x"           /* Common Call Control Typedefs        */
#include "rmt.x"             /* resource manager function decls.    */
#include "cct.x"             /* Call Control Interface              */
#include "liw.x"             /* ISUP PSIF Layer Management typedefs */
#include "iw.x"              /* ISUP PSIF Typedefs                  */
#endif
#ifdef ZI 
#include "cm_pftha.x"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.x"       /* common PSF */
#include "cm_psfft.x"      /* common PSF */
#endif
#include "lzi.x"           /* ISUP PSF management */
#include "zi.x"            /* ISUP PSF */
#endif /* ZI */

#ifdef DEBUGP
#include "mf.x"    
#endif 

#ifdef CP_OAM_SUPPORT
extern PUBLIC void RegIsupDbg();
#endif

EXTERN U32 g_siDbgMask;


/* local defines */
#define F FALSE
#define T TRUE

/* In parameter compability info param, variant ETSI or FTZ have the pass on 
 * not possible indicator (GF bits). While variant ITU97 and ETSI3 have both
 * of pass on not possible indicator and broadband/narrowband interworking
 * indicator (GF bits and IJ bits). We also store the transit exchange
 * indicator(A bit) in the "list.instrnInd" for variant ITU97 and ETSIv3
 * in another marco INSTRARRAY1
 */ 
#if (SS7_ETSI || SS7_FTZ) 
#else /* ETSI or FTZ */
#define INSTRARRAY(list, idx, pComp, num) \
{ \
  if (num == 1) \
  { \
     list[idx].instrnInd |= pComp->relCllInd1.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd1.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd1.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd1.val << 4; \
     list[idx].upgrParm   = pComp->upgrPar1.val; \
  } \
  if (num == 2) \
  { \
     list[idx].instrnInd |= pComp->relCllInd2.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd2.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd2.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd2.val << 4; \
     list[idx].upgrParm   = pComp->upgrPar2.val; \
  } \
  if (num == 3) \
  { \
     list[idx].instrnInd |= pComp->relCllInd3.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd3.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd3.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd3.val << 4; \
     list[idx].upgrParm   = pComp->upgrPar3.val; \
  } \
  if (num == 4) \
  { \
     list[idx].instrnInd |= pComp->relCllInd4.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd4.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd4.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd4.val << 4; \
     list[idx].upgrParm   = pComp->upgrPar4.val; \
  } \
  if (num == 5) \
  { \
     list[idx].instrnInd |= pComp->relCllInd5.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd5.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd5.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd5.val << 4; \
     list[idx].upgrParm   = pComp->upgrPar5.val; \
  } \
  if (num == 6) \
  { \
     list[idx].instrnInd |= pComp->relCllInd6.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd6.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd6.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd6.val << 4; \
     list[idx].upgrParm   = pComp->upgrPar6.val; \
  } \
  if (num == 7) \
  { \
     list[idx].instrnInd |= pComp->relCllInd7.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd7.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd7.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd7.val << 4; \
     list[idx].upgrParm   = pComp->upgrPar7.val; \
  } \
  if (num == 8) \
  { \
     list[idx].instrnInd |= pComp->relCllInd8.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd8.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd8.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd8.val << 4; \
     list[idx].upgrParm   = pComp->upgrPar8.val; \
  } \
  if (num == 9) \
  { \
     list[idx].instrnInd |= pComp->relCllInd9.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd9.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd9.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd9.val << 4; \
     list[idx].upgrParm   = pComp->upgrPar9.val; \
  } \
  if (num == 10) \
  { \
     list[idx].instrnInd |= pComp->relCllInd10.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd10.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd10.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd10.val << 4; \
     list[idx].upgrParm   = pComp->upgrPar10.val; \
  } \
}
#endif /* ETSI || FTZ */

/* si029.220: Addition - added SS7_INDIA flag */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
#define INSTRARRAY1(list, idx, pComp, num) \
{ \
  if (num == 1) \
  { \
     list[idx].instrnInd  = pComp->tranXInd1.val; \
     list[idx].instrnInd |= pComp->relCllInd1.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd1.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd1.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd1.val << 4; \
     list[idx].instrnInd |= pComp->passNtPoss1.val << 5; \
     list[idx].pBbNbInd   = pComp->pBbNbIntwkI1.val; \
     list[idx].upgrParm   = pComp->upgrPar1.val; \
  } \
  if (num == 2) \
  { \
     list[idx].instrnInd  = pComp->tranXInd2.val; \
     list[idx].instrnInd |= pComp->relCllInd2.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd2.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd2.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd2.val << 4; \
     list[idx].instrnInd |= pComp->passNtPoss2.val << 5; \
     list[idx].pBbNbInd   = pComp->pBbNbIntwkI2.val; \
     list[idx].upgrParm   = pComp->upgrPar2.val; \
  } \
  if (num == 3) \
  { \
     list[idx].instrnInd  = pComp->tranXInd3.val; \
     list[idx].instrnInd |= pComp->relCllInd3.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd3.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd3.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd3.val << 4; \
     list[idx].instrnInd |= pComp->passNtPoss3.val << 5; \
     list[idx].pBbNbInd   = pComp->pBbNbIntwkI3.val; \
     list[idx].upgrParm   = pComp->upgrPar3.val; \
  } \
  if (num == 4) \
  { \
     list[idx].instrnInd  = pComp->tranXInd4.val; \
     list[idx].instrnInd |= pComp->relCllInd4.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd4.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd4.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd4.val << 4; \
     list[idx].instrnInd |= pComp->passNtPoss4.val << 5; \
     list[idx].pBbNbInd   = pComp->pBbNbIntwkI4.val; \
     list[idx].upgrParm   = pComp->upgrPar4.val; \
  } \
  if (num == 5) \
  { \
     list[idx].instrnInd  = pComp->tranXInd5.val; \
     list[idx].instrnInd |= pComp->relCllInd5.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd5.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd5.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd5.val << 4; \
     list[idx].instrnInd |= pComp->passNtPoss5.val << 5; \
     list[idx].pBbNbInd   = pComp->pBbNbIntwkI5.val; \
     list[idx].upgrParm   = pComp->upgrPar5.val; \
  } \
  if (num == 6) \
  { \
     list[idx].instrnInd  = pComp->tranXInd6.val; \
     list[idx].instrnInd |= pComp->relCllInd6.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd6.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd6.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd6.val << 4; \
     list[idx].instrnInd |= pComp->passNtPoss6.val << 5; \
     list[idx].pBbNbInd   = pComp->pBbNbIntwkI6.val; \
     list[idx].upgrParm   = pComp->upgrPar6.val; \
  } \
  if (num == 7) \
  { \
     list[idx].instrnInd  = pComp->tranXInd7.val; \
     list[idx].instrnInd |= pComp->relCllInd7.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd7.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd7.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd7.val << 4; \
     list[idx].instrnInd |= pComp->passNtPoss7.val << 5; \
     list[idx].pBbNbInd   = pComp->pBbNbIntwkI7.val; \
     list[idx].upgrParm   = pComp->upgrPar7.val; \
  } \
  if (num == 8) \
  { \
     list[idx].instrnInd  = pComp->tranXInd8.val; \
     list[idx].instrnInd |= pComp->relCllInd8.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd8.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd8.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd8.val << 4; \
     list[idx].instrnInd |= pComp->passNtPoss8.val << 5; \
     list[idx].pBbNbInd   = pComp->pBbNbIntwkI8.val; \
     list[idx].upgrParm   = pComp->upgrPar8.val; \
  } \
  if (num == 9) \
  { \
     list[idx].instrnInd  = pComp->tranXInd9.val; \
     list[idx].instrnInd |= pComp->relCllInd9.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd9.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd9.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd9.val << 4; \
     list[idx].instrnInd |= pComp->passNtPoss9.val << 5; \
     list[idx].pBbNbInd   = pComp->pBbNbIntwkI9.val; \
     list[idx].upgrParm   = pComp->upgrPar9.val; \
  } \
  if (num == 10) \
  { \
     list[idx].instrnInd  = pComp->tranXInd10.val; \
     list[idx].instrnInd |= pComp->relCllInd10.val << 1; \
     list[idx].instrnInd |= pComp->sndNotInd10.val << 2; \
     list[idx].instrnInd |= pComp->dcrdMsgInd10.val << 3; \
     list[idx].instrnInd |= pComp->dcrdParInd10.val << 4; \
     list[idx].instrnInd |= pComp->passNtPoss10.val << 5; \
     list[idx].pBbNbInd   = pComp->pBbNbIntwkI10.val; \
     list[idx].upgrParm   = pComp->upgrPar10.val; \
  } \
}
#endif /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA */

#define UPDATEDGNVAL(_cDgn, _presInd, _len, _cnt, _val) \
{ \
  (_cDgn)->dgnVal.pres = _presInd; \
  (_cDgn)->dgnVal.len  = _len; \
  (_cDgn)->dgnVal.val[_cnt] = _val; \
}
#define SNDCONF(nCb, intfid, cgAdr, intfflg, cicVal, mBuf, causeDgn, opc, swtch) \
{ \
      (causeDgn)->causeVal.val = SIT_CCNOMSGTYP; \
      siGenConfNoCon(nCb, intfid, cgAdr, intfflg, opc, cicVal, causeDgn, swtch); \
      RETVALUE(MC_DROPMSG); \
} 
/* local typedefs */
  
/* local externs */

PRIVATE Bool siIncCompTbl [][MAX_NMB_CON_ST] =
{
   /* Address Complete */
   {F, F, F, F, F, F, F, F, F, F, F, F, F},
   /* Answer */
   {F, F, F, F, F, F, F, F, F, F, F, F, F},
   /* Call Modification Complete */
   {F, F, F, F, T, F, F, F, F, F, F, F, F},
   /* Call Modification Request */
   {F, F, F, F, T, F, F, F, F, F, F, F, F},
   /* Call Modification Rejected */
   {F, F, F, F, T, F, F, F, F, F, F, F, F},
   /* Call Progress */
   {F, F, F, T, T, F, F, F, F, F, F, F, F},
   /* Confusion */
   {T, T, T, T, T, T, T, F, F, F, F, F, F},
   /* Connect */
   {F, F, F, F, F, F, F, F, F, F, F, F, F},
   /* Continuity */
   {T, T, F, F, F, F, F, F, F, T, F, F, F},
   /* Continuity check request */
   {T, T, F, F, F, F, F, F, F, F, F, F, F},
   /* Facility Accepted */
   {F, F, T, T, T, F, F, F, F, F, F, F, F},
   /* Facility Rejected */
   {F, F, T, T, T, F, F, F, F, F, F, F, F},
   /* Facility Request */
   {F, F, T, T, T, F, F, F, F, F, F, F, F},
   /* Forward Transfer */
   {F, F, F, T, T, F, F, F, F, F, F, F, F},
   /* Information */
   {F, T, T, T, T, T, F, F, F, F, F, F, F},
   /* Information Request */
   {F, T, T, T, F, F, F, F, F, F, F, F, F},
   /* Initial Address */
   {T, F, F, F, F, F, F, F, F, F, T, F, F},
   /* Release */
   {T, T, T, T, T, T, T, T, F, T, T, F, F},
   /* Release Complete */
   {T, T, T, T, T, T, T, F, T, T, T, F, F},
   /* Resume */
   {F, F, F, F, F, T, F, F, F, F, F, F, F},
   /* Subsequent Address */
   {F, T, T, F, F, F, F, F, F, F, F, F, F},
   /* Suspend */
   {F, F, F, F, T, T, F, F, F, F, F, F, F},
   /* User to User */
   {F, F, T, T, T, F, F, F, F, F, F, F, F},
   /* Circuit Reservation Message */
   {T, F, F, F, F, F, F, F, F, F, F, F, F},
   /* Circuit Reservation Acknowledge Message */
   {F, F, F, F, F, F, F, F, F, F, F, F, F},

  /* Blocking */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Blocking acknowledgement  */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Unblocking */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Unblocking acknowledgement */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Reset circuit */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
 
  /* Overload */
   {F, F, F, F, F, F, F, F, F, F, F, F, F},
  /* Pass-along */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Loop back acknowledgement */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Unequiped Cicuit Identification Code */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
 
  /* Circuit group query */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Circuit group query response */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Circuit group blocking */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Circuit group blocking acknowledgement */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Circuit group unblocking */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Circuit group unblocking acknowledgement */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Circuit group reset */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Circuit group reset acknowledgement */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},

   /* Facility Message */
   {F, T, T, T, T, T, T, T, T, T, T, F, F},
   /* Identification request */
   {F, F, F, F, F, F, F, F, F, F, F, F, F},
   /* Identification Response */
   {F, T, T, T, F, F, F, F, F, T, T, F, F},
   /* Network Resource Management */
   {F, T, T, T, T, T, T, T, T, T, T, F, F},
   /* User Part Available Message */
   {T, T, T, T, T, T, T, T, T, T, T, F, F},
   /* User Part Test Message */
   {T, T, T, T, T, T, T, T, T, T, T, F, F},
   /* Clsd. usr. grp. sel. val. req */
   {T, T, T, T, T, T, T, T, T, T, T, F, F},
   /* Clsd. usr. grp. sel. val. rsp. */
   {T, T, T, T, T, T, T, T, T, T, T, F, F},
   /* Circuit validation response */
   {T, T, T, T, T, T, T, T, T, T, T, F, F},
   /* Circuit validation request */
   {T, T, T, T, T, T, T, T, T, T, T, F, F},
   /* Exit Message */
   {F, F, F, F, F, F, F, F, F, F, F, F, F},
   /* Facility Information */
   {T, T, T, T, T, T, T, T, T, T, T, F, F},
   /* Facility deactivation */
   {T, T, T, T, T, T, T, T, T, T, T, F, F},
   /* Malicious call print */
   {F, T, T, T, T, T, T, T, T, T, T, F, F},
   /* Charge Info */
   {F, T, T, T, T, T, T, T, T, T, T, F, F},
   /* Tariff Change */
   {F, T, T, T, T, T, T, T, T, T, T, F, F},
   /* Charge Acknowledge */
   {F, T, T, T, T, T, T, T, T, T, T, F, F},
   /* Call Offering Message */
   {T, T, T, T, T, T, T, T, T, T, T, F, F},
   /* Loop Prevention Message */
   {F, T, T, T, T, T, F, F, F, T, T, F, F},
   /* charging */ 
   {F, T, T, T, T, T, T, T, T, T, T, F, F},
   /* charging extended */ 
   {F, T, T, T, T, T, T, T, T, T, T, F, F},
   /* charging extended acknowledge */
   {F, T, T, T, T, T, T, T, T, T, T, F, F},
   /* hanging up of A-tln */ 
   {T, T, T, T, T, T, T, T, T, T, T, F, F},
   /* Facility information */
   {T, T, T, T, T, T, T, T, T, T, T, F, F},
   /* user information */
   {T, T, T, T, T, T, T, T, T, T, T, F, F},
   /* National message */
   {T, T, T, T, T, T, T, T, T, T, T, F, F},
   /* segmentation */
   {F, T, T, T, T, T, T, T, T, T, T, F, F},
   /* Call Line Clear Message */
   {F, F, T, T, T, T, F, F, F, F, F, F, F},
   /* Ringing Send Message */
   {F, F, T, T, T, F, F, F, F, F, F, F, F},
   /* Charging message for NTT */
   {F, F, F, F, F, F, F, F, F, F, F, F, F},
   /* Pre-release message for ETSI v3 */
   {F, T, T, T, T, T, F, F, F, F, F, F, F},
   /* Application transport message for ETSI v3 */
   {F, F, T, T, T, F, F, F, F, F, F, F, F}
};
  
PRIVATE Bool siOutCompTbl [][MAX_NMB_CON_ST] =
{
  /*
   00 01 02 03 04 05 06 07 08 09 10 11 12
  */
  /* Address Complete */
   {F, F, T, F, F, F, F, F, F, F, F, F, F},
  /* Answer */
   {F, F, T, T, F, F, F, F, F, F, F, F, F},
  /* Call Modification Complete */
   {F, F, F, F, T, F, F, F, F, F, F, F, F},
  /* Call Modification Request */
   {F, F, F, F, T, F, F, F, F, F, F, F, F},
  /* Call Modification Rejected */
   {F, F, F, F, T, F, F, F, F, F, F, F, F},
  /* Call Progress */
   {F, F, T, T, T, F, F, F, F, F, F, F, F},
  /* Confusion */
   {T, T, T, T, T, T, T, F, F, F, F, F, F},
  /* Connect */
   {F, F, T, F, F, F, F, F, F, F, F, F, F},
  /* Continuity */
   {F, F, F, F, F, F, F, F, F, F, F, F, F},
  /* Continuity check request */
   {F, F, F, F, F, F, F, F, F, F, F, F, F},
  /* Facility Accepted */
   {F, F, T, T, T, F, F, F, F, F, F, F, F},
  /* Facility Rejected */
   {F, F, T, T, T, F, F, F, F, F, F, F, F},
  /* Facility Request */
   {F, F, T, T, T, F, F, F, F, F, F, F, F},
  /* Forward Transfer */
   {F, F, F, F, F, F, F, F, F, F, F, F, F},
  /* Information */
   {F, T, T, T, T, T, F, F, F, F, F, F, F},
  /* Information Request */
   {F, T, T, T, F, F, F, F, F, F, F, F, F},
  /* Initial Address */
   {T, T, T, F, F, F, F, F, F, T, F, T, F},
  /* Release */
   {F, T, T, T, T, T, T, T, F, T, T, T, F},
  /* Release Complete */
   {F, T, T, T, T, T, T, F, T, T, T, F, F},
  /* Resume */
   {F, F, F, F, F, T, F, F, F, F, F, F, F},
  /* Subsequent Address */
   {F, F, F, F, F, F, F, F, F, F, F, F, F},
  /* Suspend */
   {F, F, F, F, T, T, F, F, F, F, F, F, F},
  /* User to User */
   {F, F, T, T, T, F, F, F, F, F, F, F, F},
  /* Circuit Reservation Message */
   {F, T, T, F, F, F, F, F, F, T, F, T, F},
  /* Circuit Reservation Acknowledge Message */
   {F, F, F, F, F, F, F, F, F, T, F, T, F},

  /* Blocking */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Blocking acknowledgement  */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Unblocking */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Unblocking acknowledgement */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Reset circuit */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
 
  /* Overload */
   {F, F, T, F, F, F, F, F, F, F, F, F, F},
  /* Pass-along */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Loop back acknowledgement */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Unequiped Cicuit Identification Code */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
 
  /* Circuit group query */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Circuit group query response */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Circuit group blocking */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Circuit group blocking acknowledgement */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Circuit group unblocking */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Circuit group unblocking acknowledgement */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Circuit group reset */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
  /* Circuit group reset acknowledgement */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},

   /* Facility Message */
   {F, T, T, T, T, T, T, T, T, F, F, F, F},
   /* Identification request */
   {F, T, T, T, F, F, F, F, F, T, T, T, T},
   /* Identification Response */
   {F, F, F, F, F, F, F, F, F, F, F, F, F},
   /* Network Resource Management */
   {F, T, T, T, T, T, T, T, T, T, T, T, T},
   /* User Part Available Message */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
   /* User Part Test Message */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
   /* Clsd. usr. grp. sel. val. req */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
   /* Clsd. usr. grp. sel. val. rsp. */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
   /* Circuit validation response */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
   /* Circuit validation request */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
   /* Exit Message */
   {F, F, T, F, F, F, F, F, F, F, F, F, F},
   /* Facility Information */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
   /* Facility deactivation */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
   /* Malicious call print */
   {F, T, T, T, T, T, T, T, T, T, T, T, T},
   /* Charge Info */
   {F, T, T, T, T, T, T, T, T, T, T, T, T},
   /* Tariff Change */
   {F, T, T, T, T, T, T, T, T, T, T, T, T},
   /* Charge Acknowledge */
   {F, T, T, T, T, T, T, T, T, T, T, T, T},
   /* Call Offering Message */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
   /* Loop Prevention Message */
   {F, T, T, T, T, T, F, F, F, T, T, T, T},
   /* charging */ 
   {F, T, T, T, T, T, T, T, T, T, T, T, T},
   /* charging extended */ 
   {F, T, T, T, T, T, T, T, T, T, T, T, T},
   /* charging extended acknowledge */
   {F, T, T, T, T, T, T, T, T, T, T, T, T},
   /* hanging up of A-tln */ 
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
   /* Facility information */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
   /* user information */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
   /* National message */
   {T, T, T, T, T, T, T, T, T, T, T, T, T},
   /* segmentation */
   {F, T, T, T, T, T, T, T, T, T, T, T, T},
   /* Call Line Clear Message */
   {F, F, F, F, F, F, F, F, F, F, F, F, F},
   /* Ringing Send Message */
   {F, F, F, F, F, F, F, F, F, F, F, F, F},
   /* Charging message for NTT */
   {F, F, T, T, T, T, T, T, T, F, F, F, F},
   /* Pre-release message for ETSI v3 */
   {F, T, T, T, T, T, F, F, F, F, F, F, F},
   /* Application transport message for ETSI v3 */
   {F, F, T, T, T, F, F, F, F, F, F, F, F}
};

#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
/* index on [trunktype][slotid][value of N] */
PRIVATE Bool siTrunkTbl[][SI_MAX_NO_OF_CIR][SI_MAX_NO_OF_CIR]=
{
   { /* E1 trunk type. Read the number combined 1st and 2nd lines. These
      * number represent the value of N */
     /* 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1 2 2 2 2 2 2 2 2 2 2 3 3
        0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 */
       {F,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,F,F,F,F,F,F,F},
       {F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,T,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,T,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,T,F,F,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,F,T,F,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,F,F,F,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,T,T,F,T,F,F,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,T,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,T,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,T,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F}
   },

   { /* T1 trunk type. Read the number combined 1st and 2nd lines. These
      * number represent the value of N */
     /* 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1 2 2 2 2 2 2 2 2 2 2 3 3
        0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 */
       {F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T},
       {F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,T,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,T,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,T,F,F,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,F,T,F,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,F,F,F,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,T,T,F,T,F,F,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,F,F,F,F,F,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,F,F,F,T,F,F,F,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,T,F,T,F,F,F,F,F,F,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,T,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,T,F,F,T,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,T,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,T,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,T,T,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F},
       {F,T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F}
   }

};
#endif


/* forward references */
PRIVATE SiCon *siGetCon      ARGS((Void));
PRIVATE S16 siSegmMsg        ARGS((U8 msgType, SiNSAPCb *cb, Buffer *mBuf,
                                   Buffer **segmBufi, Swtch swtch));
PRIVATE S16 siSegMsgRemParm  ARGS((Data parmLen, Buffer *uBuf, MsgLen  offset));
PRIVATE S16 siBldInstrIndArr ARGS((SiNSAPCb *nCb, U8 xchgType,
                                   SiUpgrParmInfo parmList[], U8 *numPar,
                                   SiParmCompInfo *parmComp, 
                                   SiCauseDgn *causeDgni, SiUpSAPCb *tCb));
PRIVATE S16 siChkPCinRelMsg  ARGS((U8 nPar, SiUpgrParmInfo parmList[],
                                   SiAllPdus *message, SiNSAPCb *nCb,
                                   SiUpSAPCb *tCb, U8 xchgType));
PRIVATE S16 siPCinMsg        ARGS((SiNSAPCb *nCb, SiCirCb *siCir, 
                                   SiCon *siCon, SiAllPdus *message,
                                   SiParmCompInfo *parmComp));
PRIVATE S16 siNoPCinMsg      ARGS((SiNSAPCb *nCb, SiCirCb *siCir, SiCon *siCon,
                                   SiAllPdus *message));
/* si029.220: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
PRIVATE S16 siChkPassOnNtPossInd ARGS((SiNSAPCb *nCb, SiCirCb *siCir, 
                                       SiCon *siCon, SiUpgrParmInfo parmList[],
                                       U8 tmpPos, Bool incrCntr, U8 cntr, 
                                       SiCauseDgn *causeDgn));
#endif

/* si029.220: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
PRIVATE S16 siChkBrNbInd ARGS((SiNSAPCb *nCb, SiCirCb *siCir, SiCon *siCon,
                               SiUpgrParmInfo parmList[], U8 nPar,
                               SiCauseDgn *causeDgn));
#endif /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA */

PRIVATE S16 siProcPauseCir  ARGS((SiNSAPCb *nCb, SiUpSAPCb *tCb, 
                                  SiIntfCb *siIntfCb));
/* si009.220, DELETED: moved the function prototype of siProcResumeCir
 * to the si.x file and changed the function to public from private func 
 */
PRIVATE S16 siProcUpuCir    ARGS((SiNSAPCb *nCb, SiUpSAPCb *tCb, 
                                  SiIntfCb *siIntfCb));
PRIVATE S16 siChkMsgCompInd ARGS((SiNSAPCb *nCb, SiCirCb *siCir, Dpc cgAdr,
                                  Cic cicVal, Buffer *mbuf, Data byte, U8 xchgType));
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
PRIVATE S16 siValMRateCkt ARGS((SiCirCb *cir, Swtch swtch, U8 maxNumCir, 
                               U32 mapVal, U8 transRate, Bool contiMRateCall, 
                               SiCirCb *mRateCirPtrs[], U8 multiplier, U16 *causeVal,
                               Cic *nullCirCic));
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */

/* public variable declarations */


/* support functions */


/*
*
*       Fun:   siBldReplyPst   
*
*       Desc:  Copy the incoming post structure to reply post for management
*              primitive confirmations (LMINT3)
*              
*       Ret:   none
*
*       Notes: none
*
*       File:  ci_bdy5.c
*
*/
#ifdef ANSI
PUBLIC Void siBldReplyPst 
(
Pst    *rPst,
Header *hdr,
Pst    *iPst
)
#else
PUBLIC Void siBldReplyPst (rPst, hdr, iPst)
Pst    *rPst;
Header *hdr;
Pst    *iPst;
#endif
{
   TRC2(siBldReplyPst)

   rPst->dstProcId = iPst->srcProcId;
   rPst->srcProcId = SFndProcId();

   rPst->dstEnt    = iPst->srcEnt;
   rPst->dstInst   = iPst->srcInst;
   rPst->srcEnt    = siCb.init.ent;
   rPst->srcInst   = siCb.init.inst;

#if (SI_LMINT3 || SMSI_LMINT3)
   rPst->selector  = hdr->response.selector;
   rPst->prior     = hdr->response.prior;
   rPst->route     = hdr->response.route;
   rPst->region    = hdr->response.mem.region;
   rPst->pool      = hdr->response.mem.pool;
#else
   rPst->prior      = iPst->prior;
   rPst->route      = iPst->route;
   rPst->region     = iPst->region;
   rPst->pool       = iPst->pool;
   rPst->selector   = iPst->selector;
#endif 

   /* si025.220: Modification - added LSIV4 flag in addition
    * to SI_RUG */
   /* si001.220, ADDED: changes for rolling upgrade */
#if (defined(SI_RUG) || defined(LSIV4))
   /* Generate reply using the same version as one in the received request */
   rPst->intfVer    = iPst->intfVer;
#else
   /* si042.220 corrected insure error */
   rPst->intfVer    = iPst->intfVer;
#endif

   RETVOID;
}/* siBldReplyPst */

  
/*
*
*       Fun:   siAddIntf
*
*       Desc:  Adds an interface control block entry 
*
*       Ret:   ROK      - ok
*              RFAILED  - if failure in addition
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siAddIntf
(
SiIntfCp *intfCp, /* interface hashlist control pointer */
SiIntfCb *intfp    /* pointer to intf block that is to be added */
)
#else
PUBLIC S16 siAddIntf(intfCp, intfp)
SiIntfCp *intfCp; /* interface hashlist control pointer */
SiIntfCb *intfp;   /* pointer to intf block that is to be added */
#endif
{
   TRC2(siAddIntf);

   /* Add the interface block in the hashlist on interface ids */
   if (cmHashListInsert(&intfCp->k1Cp, (PTR) intfp, (U8 *) &intfp->key.k1,
                           SISIZEOF(SiIntfKey, k1)) != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "Unable to enter intfblock for intfid [%ld] in k1hl\n",
                  intfp->key.k1.intfId));
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI557, (ErrVal) intfp->key.k1.intfId,
                  "siAddIntf() : can't insert intfblock in intfid hashlist 1");
#endif
      RETVALUE(RFAILED);
   }


   /* Now add the interface block in second hashlist on dpc, NT, swtch, opc */
   if (cmHashListInsert(&intfCp->k2Cp, (PTR) intfp, (U8 *) &intfp->key.k2,
                           SISIZEOF(SiIntfKey, k2)) != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
       "Unable to enter intfid [%ld](dpc:%ld, NT:%d, nwId:%lx, opc:%ld)in k2hl\n",
          intfp->key.k1.intfId, intfp->key.k2.phyDpc, intfp->key.k2.ssf,
            intfp->key.k2.nwId, intfp->key.k2.opc));
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI558, (ErrVal) intfp->key.k1.intfId,
                  "siAddIntf() : can't insert intfblock in intfid hashlist 2");
#endif
      /* delete entry from previous hashlist too */
      cmHashListDelete(&intfCp->k1Cp, (PTR)intfp);

      RETVALUE(RFAILED);
   }


   /* Add the intfblock in thid hashlist on dpc, NT, swtch */
   if (cmHashListInsert(&intfCp->k3Cp, (PTR) intfp, (U8 *) &intfp->key.k3,
                           SISIZEOF(SiIntfKey, k3)) != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "Unable to enter intfId [%ld] (dpc:%ld NT:%d nwId:%lx) in k3hl\n",
            intfp->key.k1.intfId, intfp->key.k2.phyDpc, intfp->key.k3.ssf,
               intfp->key.k3.nwId));
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI559, (ErrVal) intfp->key.k1.intfId,
             "siAddIntf(): cannot insert intfblock in intfid hashlist 3");
#endif
      
      /* do the recovery action by undoing previous insertion */
      cmHashListDelete(&intfCp->k1Cp, (PTR)intfp);
      cmHashListDelete(&intfCp->k2Cp, (PTR)intfp);

      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* end of siAddIntf */

  
/*
*
*       Fun:   siDelIntf
*
*       Desc:  Deletes an interface control block entry 
*
*       Ret:   ROK      - ok
*              RFAILED  - failure
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siDelIntf
(
SiIntfCp *intfCp,    /* interface hashlist control pointer */
SiIntfCb *intfp       /* interface block to be added */
)
#else
PUBLIC S16 siDelIntf(intfCp, intfp)
SiIntfCp *intfCp;    /* interface hashlist control pointer */
SiIntfCb *intfp;      /* interface block to be added */
#endif
{
   TRC2(siDelIntf);
   
   /* remove the interface block from all three hashlists */
   cmHashListDelete(&intfCp->k1Cp, (PTR)intfp);
   cmHashListDelete(&intfCp->k2Cp, (PTR)intfp);
   cmHashListDelete(&intfCp->k3Cp, (PTR)intfp);

   RETVALUE(ROK);
}  /* end of siDelIntf */

  
/*
*
*       Fun:   siAddCir
*
*       Desc:  Adds a circuit control block entry 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siAddCir
(
SiCirCp *cirCp,
SiCirCb *cirp 
)
#else
PUBLIC S16 siAddCir(cirCp, cirp)
SiCirCp *cirCp;
SiCirCb *cirp;
#endif
{
   TRC2(siAddCir);

   if (cmHashListInsert(&cirCp->chCp, (PTR) cirp, (U8 *) &cirp->key.k1, 
                        SISIZEOF(SiCirKey, k1)) != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
        "cmHashListInsert Failed for cirID %ld [in cic list]\n",
           cirp->key.k1.cirId));  
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI560, (ErrVal) cirp->key.k1.cirId,
                 "siAddCir(): Can't insert circuit into circuit id hash list");
#endif
      RETVALUE(RFAILED);
   }

   if (cmHashListInsert(&cirCp->ichCp, (PTR) cirp, (U8 *) &cirp->key.k2, 
                        SISIZEOF(SiCirKey, k2)) != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
        "cmHashListInsert Failed for cirID %ld [in dpc+cic list]\n",
           cirp->key.k1.cirId));  

#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI561, (ErrVal) cirp->key.k1.cirId,
                 "siAddCir(): Can't insert circuit into cic + dpc hash list");
#endif
      /* delete the entry from circuit id hash list */
      cmHashListDelete(&cirCp->chCp, (PTR) cirp);
      RETVALUE(RFAILED);
   }

   if (cmHashListInsert(&cirCp->ihCp, (PTR) cirp, (U8 *) &cirp->key.k3, 
                        SISIZEOF(SiCirKey, k3)) != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
        "cmHashListInsert Failed for cirID %ld [in dpc list]\n",
           cirp->key.k1.cirId));  
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI562, (ErrVal) cirp->key.k1.cirId,
                 "siAddCir(): Can't insert circuit into dpc hash list");
#endif
      /* delete the entry from other hash lists */
      cmHashListDelete(&cirCp->chCp, (PTR) cirp);
      cmHashListDelete(&cirCp->ichCp, (PTR) cirp);
      RETVALUE(RFAILED);
   }
   
   RETVALUE(ROK);
} /* end of siAddCir */

  
/*
*
*       Fun:   siDelCir
*
*       Desc:  Deletes a circuit control block entry 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siDelCir
(
SiCirCp *cirCp,
SiCirCb *cirp 
)
#else
PUBLIC S16 siDelCir(cirCp, cirp)
SiCirCp *cirCp;
SiCirCb *cirp;
#endif
{
   TRC2(siDelCir);

   cmHashListDelete(&cirCp->chCp, (PTR) cirp);
   cmHashListDelete(&cirCp->ichCp, (PTR) cirp);
   cmHashListDelete(&cirCp->ihCp, (PTR) cirp);

   RETVALUE(ROK);
}  /* end of siDelCir */

  
/*
*
*       Fun:   siFindIntf
*
*       Desc:  Finds an interface control block or
*                 other information related to it
*
*       Ret:   ROK      - ok
*              RFAILED  - failure
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siFindIntf
(
SiIntfCb  **intfBlk,       /* interface control block    */
SiInstId    intfId,        /* interface id               */ 
Dpc         phyDpc,        /* physical dpc               */
SiInstId    nwId,          /* network Id                 */
U8          ssf,           /* Network type               */
Dpc         opc,           /* originating point code     */
U8       keytype           /* type of the key            */
)
#else
PUBLIC S16 siFindIntf(intfBlk, intfId, phyDpc, nwId, ssf, opc, keytype)
SiIntfCb  **intfBlk;         /* interface control block    */
SiInstId    intfId;        /* interface id         */ 
Dpc         phyDpc;        /* physical dpc         */
SiInstId    nwId;         /* network Id              */
U8          ssf;           /* Network type         */
Dpc         opc;           /* originating point code  */
U8       keytype;          /* type of the key         */
#endif
{
   S16 ret;
   SiIntfKey intfkey;

   TRC2(siFindIntf)

   cmMemset((U8 *) &intfkey, '\0', sizeof(SiIntfKey));
   ret = ROK;

   /* check the actions to be taken */
   switch (keytype)
   {
      case SIINTF_KEY_1: /* Find dpc, opc, NT, nwId using intfid */
         intfkey.k1.intfId = intfId;
         ret = cmHashListFind(&siCb.intfHlCp.k1Cp, (U8 *)&intfkey.k1,
                              (U16) sizeof(intfkey.k1), 0, (PTR *) intfBlk);
         break;

      case SIINTF_KEY_2: /* Find intf id with dpc, opc, NT, nwId provided*/
         /* prepare the key */
         intfkey.k2.phyDpc = phyDpc;
         intfkey.k2.nwId = nwId;
         intfkey.k2.ssf = ssf;
         intfkey.k2.opc = opc;
         ret = cmHashListFind(&siCb.intfHlCp.k2Cp, (U8 *)&intfkey.k2,
                              (U16) sizeof(intfkey.k2), 0, (PTR *) intfBlk);
         break;

      case SIINTF_KEY_3: /* find first intfid block with given dpc, NT, nwId */
         /* fill the structure */
         intfkey.k3.phyDpc = phyDpc;
         intfkey.k3.ssf = ssf;
         intfkey.k3.nwId = nwId;
         ret = cmHashListFind(&siCb.intfHlCp.k3Cp, (U8 *)&intfkey.k3,
                              (U16) sizeof(intfkey.k3), 0, (PTR *) intfBlk);
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:    /* undefined key */
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Invalid keyType %d for finding circuit\n", keytype));  
         SILOGERROR(ERRCLS_DEBUG, ESI563, (ErrVal) keytype,
                    "siFindIntf(): Unknown search key selector");
         ret = RFAILED;
         break; 
#endif
    }

   /* Now check for the return value and fill all fields */
   if (ret != ROK)
   {
      /* mark the output as unavailable */
      *intfBlk = NULLP;
   }

   RETVALUE(ret);
} /* end of siFindIntf */

  
/*
*
*       Fun:   siFindCir
*
*       Desc:  Finds a circuit control block entry 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siFindCir
(
SiCirCp *cirCp,             /* route control point pointer */
SiCirCb **cirp,             /* route control block pointer */
SiCirKey *id,               /* key id value for lookup */
U16 idx,                    /* key index for duplicate keys */
U8  keySel                  /* key selector */
)
#else
PUBLIC S16 siFindCir(cirCp, cirp, id, idx, keySel)
SiCirCp *cirCp;             /* route control point pointer */
SiCirCb **cirp;             /* route control block pointer */
SiCirKey *id;               /* key id value for lookup */
U16 idx;                    /* key index for duplicate keys */
U8  keySel;                 /* key selector */
#endif
{
   S16 ret;

   TRC2(siFindCir)

   switch (keySel)
   {
      case KEY_CIR:
         ret = cmHashListFind(&cirCp->chCp, (U8 *)&id->k1, 
                              (U16) sizeof(id->k1), idx, (PTR *) cirp);
         break;

      case KEY_CICINTF:
         ret = cmHashListFind(&cirCp->ichCp, (U8 *)&id->k2, 
                              sizeof(id->k2), idx, (PTR *) cirp);
         break;
 
      case KEY_INTF:
         ret = cmHashListFind(&cirCp->ihCp, (U8 *)&id->k3, 
                              sizeof(id->k3), idx, (PTR *) cirp);
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Invalid keySel %d for finding circuit\n", keySel));  
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI564, (ErrVal) keySel,
                    "siFindCir(): Unknown search key selector");
#endif
         ret = RFAILED;
         break; 
   }

   if (ret != ROK)
   {  
      *cirp = NULLP;
   } 

   RETVALUE(ret);
} /* end of siFindCir */

  
/*
*
*       Fun:   siAddInst
*
*       Desc:  Adds a instance control block entry 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siAddInst
(
SiInstCp *spInstCp,
SiCon *conp
)
#else
PUBLIC S16 siAddInst(spInstCp, conp)
SiInstCp *spInstCp;
SiCon *conp;
#endif
{
   S16 ret;

   TRC2(siAddInst);

   /* Code to check the prev and next pointers to 
    * insure they are null before the insertion to the hash list to avoid 
    * double insertion. Please note that this checking is under flag
    * SI_CMHASH_CHK                  
    */           
#ifdef SI_CMHASH_CHK          
      /* Check if the next and prev pointers are not null */
      if ( (conp->hl.list.next) || (conp->hl.list.prev) )
      {     
         /* Print diagnostic information */
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "hash:siAddInst:ConBlk conState:(inc:%d,out:%d) \
                conPrcs:(inc:%d out:%d) \n", conp->incC.conState, 
                conp->outC.conState, conp->incC.conPrcs, conp->outC.conPrcs));
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "hash:siAddInst: ACTION: \
                 Deleting from the hash list unconditionally\n"));
         siDelInst(&siCb.conHlCp, conp);
      }
#endif /* SI_CMHASH_CHK */

   ret = cmHashListInsert(&spInstCp->instCp, (PTR) conp, (U8 *)&conp->key.k1, 
                          sizeof(conp->key.k1));
   /* si014.220, Added: Added code to increment number of running calls only
                        if insertion into the hash list is successful */
   if (ret == ROK)
      siCb.nmbRunCalls++;
   /* si014.220, Removed: Deleted code that incremented the number of running
                          calls only for a standby copy */

   RETVALUE(ret);
} /* end of siAddInst */

  
/*
*
*       Fun:   siDelInst
*
*       Desc:  Deletes a instance control block entry 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siDelInst
(
SiInstCp *siInstCp1,
SiCon *conp 
)
#else
PUBLIC S16 siDelInst(siInstCp1, conp)
SiInstCp *siInstCp1;
SiCon *conp;
#endif
{
   /* si014.220, Addition: Added varible */
   S16 ret;
   TRC2(siDelInst);

   /* si014.220, Change: Modified code to check return value from 
                         cmHashListDelete */
   ret = cmHashListDelete(&siInstCp1->instCp, (PTR) conp);
   if (siCb.nmbRunCalls == 0)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                "  siDelInst failed, number of running calls already 0  \n"));
   }     
   else
      /* si014.220, Added: Added code to decrement number of running calls 
                           only if deleting from hash list is successful */
      if (ret == ROK)
         siCb.nmbRunCalls--;
   RETVALUE(ROK);
}  /* end of siDelInst */

  
/*
*
*       Fun:   siFindInst
*
*       Desc:  Finds a instance control block entry based on spInstId
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siFindInst
(
SiInstCp *siInstCp1,
SiCon **conp,
SiInstKey *id
)
#else
PUBLIC S16 siFindInst(siInstCp1, conp, id)
SiInstCp *siInstCp1;
SiCon **conp;
SiInstKey *id;
#endif
{
   S16 ret;

   TRC2(siFindInst)

   ret = cmHashListFind(&siInstCp1->instCp, (U8 *)&id->k1, 
                        sizeof(id->k1), 0, (PTR *)conp);

   if (ret != ROK)
      *conp = NULLP;

   RETVALUE(ret);
} /* end of siFindInst */


/*
*
*       Fun:   siFindSuInstId
*
*       Desc:  Find a connection control block associated with the 'suInstId'
*              when the 'spInstId' information is not available
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy5.c
*
*/
#ifdef ANSI
PUBLIC S16 siFindSuInstId
(
SiInstId suInstId,
SiCon    **siConPtr
)
#else
PUBLIC S16 siFindSuInstId (suInstId, siConPtr)
SiInstId suInstId;
SiCon    **siConPtr;
#endif
{
   SiCon *prevCon;
   SiCon *con;

   TRC2(siFindSuInstId)

   prevCon   = NULLP;
   con       = NULLP;
   *siConPtr = NULLP;

   /* search the hash list sequentially */
   while (cmHashListGetNext(&siCb.conHlCp.instCp, (PTR) prevCon, (PTR *) &con) 
          == ROK)
   {
      if (con->suInstId == suInstId)
      {
         *siConPtr = con;
         RETVALUE(ROK);
      }
      prevCon = con;
   }
   RETVALUE(RFAILED);
}

  
/* si009,220, MODIFIED: added one argument of cic for function siGetLnkSel */
/* si025,220, MODIFIED: change argument type cic to cir and remove cb */
/*
*
*       Fun:   siGetLnkSel
*
*       Desc:  Get Link Selection value 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGetLnkSel
(
SiNSAPCb *cb,
LnkSel   *lnkSel,
Swtch    swtch,
SiCirCb  *cir 
)
#else
PUBLIC S16 siGetLnkSel(cb, lnkSel, swtch, cir)
SiNSAPCb *cb;
LnkSel   *lnkSel;
Swtch   swtch;
SiCirCb  *cir;
#endif
{
#ifdef LSIV4
   SiIntfCb *intfCb;
#endif

   UNUSED(cb);

   TRC2(siGetLnkSel);
/* si025.220: Modification - change code so that link selection 
 * could be done per interface and it is reconfigurable from LSI 
 * interface.
 */
#ifdef LSIV4
   /* find interface control block */
   if (siFindIntf(&intfCb, cir->cfg.intfId, 0, 0, 0, 0, SIINTF_KEY_1) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESIXXX, (ErrVal) cir->cfg.intfId,
        "siGetLnkSel() Failed, Can't find Interface control block");
#endif
      RETVALUE(RFAILED);
   }
#endif /* LSIV4 */

#ifdef LSIV3 
   if (siCb.genCfg.lnkSelOpt == LSI_LNKSEL_LD_DISTR)
#endif
#ifdef LSIV4
   if (intfCb->cfg.lnkSelOpt == LSI_LNKSEL_LD_DISTR)
#endif /* LSIV4 */
   {
      switch (swtch)
      {
/* si025.220: modification - 8 bit or 5 bit link selection option
 * is applicable to ANSI and BELLCORE variants only.
 * 8 bit or 5 bit link selection can be specified either by interface
 * configuration or by compile time flag SLS_8BIT. The later one is to
 * support the backward compatibility. */

#ifdef SS7_ITU97
         case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
        case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
        case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         case LSI_SW_ITU:
#ifdef LSIV4
            *lnkSel = (LnkSel) ((intfCb->lnkSel++) & MOD15);
#else
            *lnkSel = (LnkSel) ((cb->lnkSel++) & MOD15);
#endif /* LSIV4 */
            break;
#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "Invalid swtch for siGetLnkSel: %d\n", swtch ));
            SILOGERROR(ERRCLS_DEBUG, ESI565, (ErrVal) 0,
                    "siGetLnkSel() Failed, invalid search key");
            break;
#endif
      }
   }
   
   /*  set link selector base on CIC */
#if (SI_SLSCIC || LSIV3 || LSIV4)
#ifdef LSIV3 
   if (siCb.genCfg.lnkSelOpt == LSI_LNKSEL_CIC)
#endif
#ifdef LSIV4
   if (intfCb->cfg.lnkSelOpt == LSI_LNKSEL_CIC)
#endif
   {
      switch(swtch)
      {
#ifdef SS7_ITU97
         case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
        case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
        case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         case LSI_SW_ITU:
            *lnkSel = (LnkSel) (cir->cfg.cic & MOD15);
            break;
#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SILOGERROR(ERRCLS_DEBUG, ESI572, (ErrVal) swtch,
                    "siGetLnkSel() Failed, invalid switch");
            break;
#endif
      }
   }
#endif /* SI_SLSCIC || LSIV3 || LSIV4 */
   RETVALUE(ROK);
} /* end of siGetLnkSel */
/*si044.220 Addition: Fixed the UCIC problem in case of unequip circuit*/
  /*
*
*       Fun:   siGetLnkSelIntf
*
*       Desc:  Get Link Selection value 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGetLnkSelIntf
(
SiNSAPCb *cb,
LnkSel   *lnkSel,
Swtch    swtch,
Cic     cic,
SiInstId intfId
)
#else
PUBLIC S16 siGetLnkSelIntf(cb, lnkSel, swtch, cic,intfId)
SiNSAPCb *cb;
LnkSel   *lnkSel;
Swtch   swtch;
Cic     cic;
SiInstId    intfId;
#endif
{
#ifdef LSIV4
   SiIntfCb *intfCb;
#endif

   UNUSED(cb);

   TRC2(siGetLnkSelIntf);
#ifdef LSIV4
   /* find interface control block */
   if (siFindIntf(&intfCb, intfId, 0, 0, 0, 0, SIINTF_KEY_1) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESIXXX, (ErrVal) intfId,
        "siGetLnkSelIntf() Failed, Can't find Interface control block");
#endif
      RETVALUE(RFAILED);
   }
#endif /* LSIV4 */

#ifdef LSIV3 
   if (siCb.genCfg.lnkSelOpt == LSI_LNKSEL_LD_DISTR)
#endif
#ifdef LSIV4
   if (intfCb->cfg.lnkSelOpt == LSI_LNKSEL_LD_DISTR)
#endif /* LSIV4 */
   {
      switch (swtch)
      {
/* si025.220: modification - 8 bit or 5 bit link selection option
 * is applicable to ANSI and BELLCORE variants only.
 * 8 bit or 5 bit link selection can be specified either by interface
 * configuration or by compile time flag SLS_8BIT. The later one is to
 * support the backward compatibility. */

#ifdef SS7_ITU97
         case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
        case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
        case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         case LSI_SW_ITU:
#ifdef LSIV4
            *lnkSel = (LnkSel) ((intfCb->lnkSel++) & MOD15);
#else
            *lnkSel = (LnkSel) ((cb->lnkSel++) & MOD15);
#endif /* LSIV4 */
            break;
#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "Invalid swtch for siGetLnkSelIntf: %d\n", swtch ));
            SILOGERROR(ERRCLS_DEBUG, ESI565, (ErrVal) 0,
                    "siGetLnkSelIntf() Failed, invalid search key");
            break;
#endif
      }
   }
   
   /*  set link selector base on CIC */
#if (SI_SLSCIC || LSIV3 || LSIV4)
#ifdef LSIV3 
   if (siCb.genCfg.lnkSelOpt == LSI_LNKSEL_CIC)
#endif
#ifdef LSIV4
   if (intfCb->cfg.lnkSelOpt == LSI_LNKSEL_CIC)
#endif
   {
      switch(swtch)
      {
#ifdef SS7_ITU97
         case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
        case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
        case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         case LSI_SW_ITU:
            *lnkSel = (LnkSel) (cic & MOD15);
            break;
#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SILOGERROR(ERRCLS_DEBUG, ESI572, (ErrVal) swtch,
                    "siGetLnkSelIntf() Failed, invalid switch");
            break;
#endif
      }
   }
#endif /* SI_SLSCIC || LSIV3 || LSIV4 */
   RETVALUE(ROK);
} /* end of siGetLnkSelIntf */
/*si044.220 END Addition: Fixed the UCIC problem in case of unequip circuit*/

/*
*
*       Fun:    siAscAdrToBcd
*
*       Desc:   Converts Ascii Address to BCD
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   ci_bdy5.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siAscAdrToBcd
(
U8 *inpBuf,                 /* pointer to input address buffer */
U8 *bcdBuf                  /* pointer to output address buffer */
)
#else
PUBLIC S16 siAscAdrToBcd(inpBuf, bcdBuf)
U8 *inpBuf;                 /* pointer to input address buffer */
U8 *bcdBuf;                 /* pointer to output address buffer */
#endif
{
   REG1 U8 c;
   S16 d;
  
   TRC2(siAscAdrToBcd)

   while (cmIsANumber(&d, c = *inpBuf++, (S16) BASE16))
   {
      *bcdBuf = (U8) d;
      if (!cmIsANumber(&d, c = *inpBuf++, (S16) BASE16))
         break;
      *bcdBuf++ |= (U8) (d << 4);
   }
   RETVALUE(ROK);
}  /* end of siAscAdrToBcd */


/*
*
*       Fun:    siAscMaskToBcd
*
*       Desc:   Converts Ascii Mask to BCD
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   ci_bdy5.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siAscMaskToBcd
(
U8 *mask,
U8 *buf 
)
#else
PUBLIC S16 siAscMaskToBcd(mask, buf)
U8 *mask;
U8 *buf;
#endif
{
   U8 count;

   TRC2(siAscMaskToBcd)
   count = ADRLEN;
   while (count)
   {
      if (*mask == '1')
         *buf = (U8) (0xf << 4);
#if (ERRCLASS & ERRCLS_DEBUG)
      else
         if (*mask != '0')
         {
            SILOGERROR(ERRCLS_DEBUG, ESI566, (ErrVal) 0, 
                       "siAscMaskToBcd() Failed, invalid mask");
            RETVALUE(ROK);
         }
#endif
      count--;
      mask++;
      if (*mask == '1')
         *buf |= 0xf;
#if (ERRCLASS & ERRCLS_DEBUG)
      else
         if (*mask != '0')
         {
            SILOGERROR(ERRCLS_DEBUG, ESI567, (ErrVal) 0, 
                       "siAscMaskToBcd() Failed, invalid mask");
            RETVALUE(ROK);
         }
#endif
      count--;
      mask++;
      buf++;
   }
   RETVALUE(ROK);
}  /* end of siAscMaskToBcd */

  
/*
*
*       Fun:   siCmpAddr
*
*       Desc:  Compares Two Hex Addresses
*
*       Ret:   ROK     - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siCmpAddr
(
U8 *adr1,
U8 len1,
U8 *adr2,
U8 len2,
U8 *mask 
)
#else
PUBLIC S16 siCmpAddr(adr1, len1, adr2, len2, mask)
U8 *adr1;
U8 len1;
U8 *adr2;
U8 len2;
U8 *mask;
#endif
{
   REG1 U8 i;
   REG2 U8 count;
   U8 tAdr1[ADRLEN];
   U8 tAdr2[ADRLEN];
   U8 *buf;
   U8 *tMask;
  
   TRC2(siCmpAddr)
   /* see if 1st addr is same length as second */
   if (len1 != len2)
      RETVALUE(len1 - len2);  
  
/* si032.220: modification - don't use mask if it is NULLP */
   if (mask == (U8*) NULLP)
   {
      for (i = 0; i < len1; i++)
         if (adr1[i] != adr2[i])
            RETVALUE(adr1[i] - adr2[i]); 
   }
   else /* mask not NULLP */
   {
      tMask = mask;  
      /* zero out temp storage */
      for (i = 0; i < ADRLEN; i++) 
      {
         tAdr1[i] = 0;
         tAdr2[i] = 0;
      }

      i = len1;
  
      buf = adr1;
      for (count = 0; count < i; count++)
         tAdr1[count] = (*buf++) & (*mask++);

      i = len2;
  
      buf = adr2;
      for (count = 0; count < i; count++)
         tAdr2[count] = (*buf++) & (*tMask++);

      for (i = 0; len1; i++, len1--)
         if (tAdr1[i] != tAdr2[i])
            RETVALUE(tAdr1[i] - tAdr2[i]);
   }
   RETVALUE(len1);
} /* end of siCmpAddr */


/*
*
*       Fun:   siGetPriority
*
*       Desc:  Gives priority for the given message type 
*
*       Ret:   PRI_ZERO/PRI_ONE/PRI_TWO 
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC Priority siGetPriority
(
U8       msgtype,
Swtch    swtch
)
#else
PUBLIC Priority siGetPriority(msgtype, swtch)
U8    msgtype;
Swtch swtch;
#endif
{
   Priority prior;

   TRC2(siGetPriority)
   switch (swtch)
   {
      default:
         switch (msgtype)
         {
            case M_ANSWER:
            case M_RELCOMP:
               prior = PRI_TWO;
               break;

            case M_RELSE:
            case M_ADDCOMP:
            case M_CONTCHKREQ:
            case M_RESUME:
            case M_SUSPND:
            case M_LOOPBCKACK:
            case M_UNEQUIPCIC:
               prior = PRI_ONE;
               break;

            default:
               prior = PRI_ZERO;
               break;
         }
         break;
   }

   RETVALUE(prior);
} 


/*
*
*       Fun:   siInitSiCb
*
*       Desc:  Initialize globals
*              
*       Ret:   ROK - ok; RFAILED - failed
*
*       Notes: none
*
*       File:  ci_bdy5.c
*
*/
#ifdef ANSI
PUBLIC S16 siInitSiCb 
(
Ent entity,            /* entity */
Inst inst,             /* instance */
Region region,         /* region */
Reason reason          /* reason */
)
#else
PUBLIC S16 siInitSiCb (entity, inst, region, reason)
Ent entity;            /* entity */
Inst inst;             /* instance */
Region region;         /* region */
Reason reason;         /* reason */
#endif
{
   TRC2(siInitSiCb)

   cmMemset((U8 *) &siCb, '\0', sizeof(SiCb));

   siCb.init.ent = entity;
   siCb.init.inst = inst;
   siCb.init.region = region;
   siCb.init.reason = reason;
   siCb.init.cfgDone = FALSE;
   siCb.init.pool = 0;
#ifdef SI_ACNT
   siCb.init.acnt = FALSE;
#endif
#ifdef SI_USTA
   siCb.init.usta = TRUE;
#else
   siCb.init.usta = FALSE;
#endif /* SI_USTA */
   siCb.init.trc = FALSE;
   siCb.init.procId = SFndProcId();

   siCb.upSAPLst   = NULLP;
   siCb.mtpSAPLst  = NULLP;
   siCb.sccpSAPLst = NULLP;
#ifdef DEBUGP
   siCb.init.dbgMask=0x0;
   g_DBGMsgErr = FALSE;
/* si043.220 : Addition - DEBUG Changes introduced  */
#ifdef SI_DEBUG
   siCb.init.dbgMask = g_siDbgMask;
#endif  /* if SI_DEBUG */
#endif

   RETVALUE(ROK);
}/* siInitSiCb */


/*
*
*      Fun:   Activate Task - initialize
*
*      Desc:  Invoked by system services to initialize a task.
*
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siActvInit
(
Ent entity,            /* entity */
Inst inst,             /* instance */
Region region,         /* region */
Reason reason          /* reason */
)
#else
PUBLIC S16 siActvInit(entity, inst, region, reason)
Ent entity;            /* entity */
Inst inst;             /* instance */
Region region;         /* region */
Reason reason;         /* reason */
#endif
{
   TRC3(siActvInit)
   


   siInitSiCb(entity, inst, region, reason);
   siMfInitForMsg();
#ifdef IW
   iwActvInit(ENTIW, inst, region, reason);
#endif

#ifdef ZI
   ziActvInit(ENTSI, inst, region, reason);
#endif


#ifdef SSI_WITH_CLI_ENABLED
    RegIsupDbg();
    
#endif



   siInitExt();  

   RETVALUE(ROK);
} /* end of siActvInit */



/*
*
*       Fun:   siDropMsg
*
*       Desc:  drop data
*
*       Ret:   ROK - ok found
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siDropMsg
(
Buffer *mBuf 
)
#else
PUBLIC S16 siDropMsg(mBuf)
Buffer *mBuf;
#endif
{

   TRC2(siDropMsg)
   if (mBuf != NULLP)
   {
      SPutMsg(mBuf);
   } 
    RETVALUE(ROK);
} /* end of siDropMsg */


/*
*
*       Fun:   siChkPslgDst
*
*       Desc:  check destination of Passalong Message
*
*       Ret:   TRUE - final destination
*              FALSE
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC Bool siChkPslgDst
(
SiCirCb *cir
)
#else
PUBLIC Bool siChkPslgDst(cir)
SiCirCb *cir;
#endif
{
   TRC2(siChkPslgDst)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (cir->siCon == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "connection block is not present\n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI568, (ErrVal) 0, 
                 "siChkPslgDst() Failed, connection NULLP");
      RETVALUE(ROK);
   }
#endif
   if ((cir->siCon->incC.conPrcs) && (cir->siCon->outC.conPrcs))
   {  
      SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "Incoming and outgoing conPrcs are SET\n"));  
      RETVALUE(FALSE);
   } 
   else
      RETVALUE(TRUE);
} /* end of siChkPslgDst */

  
/*
*
*       Fun:   siErrorMapFunc
*
*       Desc:  message function - error mapping function
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siErrMapFunc
(
SiMfMsgCtl *msgCtlp,        /* message function control / error structure */
SiCauseDgn *causeDgn        /* q.931 error structure */
)
#else
PUBLIC S16 siErrMapFunc(msgCtlp, causeDgn)
SiMfMsgCtl *msgCtlp;        /* message function control / error structure */
SiCauseDgn *causeDgn;       /* q.931 error structure */
#endif
{

   TRC2(siErrMapFunc)

   causeDgn->eh.pres = PRSNT_NODEF; 
   causeDgn->causeVal.pres = PRSNT_NODEF; 
   switch (msgCtlp->ee[0].siMfCauseDgn.causeVal.val)
   {
      case MFCCINVMSG:
         causeDgn->causeVal.val = SIT_CCINVMSG;
         causeDgn->dgnVal.pres = NOTPRSNT;
         causeDgn->dgnVal.len = 0;
         break;

      case MFCCINFOELMSSG:
         causeDgn->causeVal.val = SIT_CCPROTERR;
         causeDgn->dgnVal.pres = PRSNT_NODEF;
         causeDgn->dgnVal.len = 1;
         causeDgn->dgnVal.val[0] = msgCtlp->ee[0].siMfCauseDgn.dgnVal.val[0];
         break;

      case MFCCNOMSGTYP:
         causeDgn->causeVal.val = SIT_CCNOMSGTYP;
         causeDgn->dgnVal.pres = PRSNT_NODEF;
         causeDgn->dgnVal.len = 1;
         causeDgn->dgnVal.val[0] = msgCtlp->ee[0].siMfCauseDgn.dgnVal.val[0];
         break;

      case MFCCNOINFOEL:
         causeDgn->causeVal.val = CCNOPARAMDISC;
         causeDgn->dgnVal.pres = PRSNT_NODEF;
         causeDgn->dgnVal.len = 1;
         causeDgn->dgnVal.val[0] = msgCtlp->ee[0].siMfCauseDgn.dgnVal.val[0];
         break;

      case MFCCINVINFOEL:
         causeDgn->causeVal.val = SIT_CCPROTERR;
         causeDgn->dgnVal.pres = PRSNT_NODEF;
         causeDgn->dgnVal.len = 1;
         causeDgn->dgnVal.val[0] = msgCtlp->ee[0].siMfCauseDgn.dgnVal.val[0];
         break;

      default:
         causeDgn->causeVal.val = SIT_CCPROTERR;
         causeDgn->dgnVal.pres = NOTPRSNT;
         causeDgn->dgnVal.len = 0;
         break;

   }

   causeDgn->recommend.pres = NOTPRSNT;

/* si029.220: Addition - added INDIA switch */
#if (SS7_Q767 || SS7_RUSSIA || SS7_INDIA)
   if ((msgCtlp->swtch == LSI_SW_Q767)
       ||  (msgCtlp->swtch == LSI_SW_INDIA)
       ||  (msgCtlp->swtch == LSI_SW_RUSSIA))
   {
      causeDgn->dgnVal.pres = NOTPRSNT;
   }
#endif

   RETVALUE(MFROK); 
} /* end of siErrMapFunc */


/*
*
*       Fun:   siActDat
*
*       Desc:  Activate matrix from data link layer interface.
*
*       Ret:   ROK - ok found
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siActDat
(
CirId cirId,                 /* circuit Id */
SiCon *siCon,                /* circuit connection */
U8 event                     /* event */
)
#else
PUBLIC S16 siActDat(cirId, siCon, event)
CirId cirId;                 /* circuit Id */
SiCon *siCon;                /* circuit connection */
U8 event;                    /* event */
#endif
{
   TRC2(siActDat)

   if (cirId == siCon->incC.cirId)
   {  
      SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
        "siConInc[event:%d][state:%d] for cir:%ld\n",
            event, siCon->incC.conState, cirId));  
      siConInc[event][siCon->incC.conState](siCon);
   } 
   else 
      if (cirId == siCon->outC.cirId)
      {  
        SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
          "siConOut[event:%d][state:%d] for cir:%ld\n",
      /* si012.220, Change: Modified incoming connection
                            state to outgoing state to
                            reference correct state */
            event, siCon->outC.conState, cirId));  
        siConOut[event][siCon->outC.conState](siCon);
      } 
      else
#if (ERRCLASS & ERRCLS_DEBUG)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siActDat:cirID does not match\n"));  
         SILOGERROR(ERRCLS_DEBUG, ESI569, (ErrVal) 0, 
                 "siActDat() Failed, invalid circuit");
         RETVALUE(ROK);
      }
#else
;
#endif
   RETVALUE(ROK); 
} /* end of siActDat */


/*
*
*       Fun:   siGenConfNoCon
*
*       Desc:  Sends Confusion message where conection is not available
*
*       Ret:   ROK - ok found
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenConfNoCon
(
SiNSAPCb *cb,                 /* network layer control block */
SiInstId intfId,                 /* interface id */
Dpc phyDpc,                   /* physical DPC */
U8    intfflg,                /* interface valid flag */
Dpc opc,                      /* opc */
Cic cic,                      /* cic code */
SiCauseDgn *cause,            /* cause */
Swtch swtch                   /* switch */
)
#else
PUBLIC S16 siGenConfNoCon(cb, intfId, phyDpc, intfflg, opc, cic, cause, swtch)
SiNSAPCb *cb;                 /* network layer control block */
SiInstId intfId;                 /* interface id */
Dpc phyDpc;                   /* physical DPC */
U8    intfflg;                /* interface valid flag */
Dpc opc;                      /* opc */
Cic cic;                      /* cic code */
SiCauseDgn *cause;            /* cause */
Swtch swtch;                  /* switch */
#endif
{
   SiPduHdr pduHdr;
   SiAllPdus allPdus;
   S16 ret;
   LnkSel lnkSel;
/* si025.220: Addition - Added key and cir declaration */
   SiCirCb *cir;
   SiCirKey key;

   TRC2(siGenConfNoCon)
   /* Generate Confusion Message to Lower Layer */
   /* prepare Pdu header */
   pduHdr.eh.pres = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val = (U8) M_CONFUSION;
   MFINITPDU(&cb->mfMsgCtl, ret, (U8) 0, (U8) MI_CONFUSION, NULLP, 
         (ElmtHdr *) &allPdus, (U8) PRSNT_DEF, swtch, (U32) MF_ISUP);
   /* init cause */
   MFINITELMT(&cb->mfMsgCtl, ret, (ElmtHdr *) cause, (ElmtHdr *) 
         &allPdus.m.confusion.causeDgn, &meCauseIndV, (U8) PRSNT_NODEF, 
         swtch, (U32) MF_ISUP);

   allPdus.m.confusion.causeDgn.recommend.pres = NOTPRSNT;

   /* get link selection value */
   /* si009.220 - Modified: to pass cic into siGetLnkSel. */
   /* si025.220 - Modification - modify arguments in siGetLnkSel */
   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
   key.k2.cic = cic;
   key.k2.intfId = intfId;
   siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);

   if (cir == (SiCirCb *) NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "can not find circuit control block. cic=%x, intfId=%lx\n",
             cic, intfId));

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIC, (PTR) &cic,
                    LSI_USTA_DGNVAL_INTF, (PTR) &intfId,
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERNAL,
                     LCM_EVENT_INV_EVT, LSI_CAUSE_INV_CIRCUIT, FALSE,
                     cic, SI_ALRM_CIR_UNEQUPD);

      RETVALUE(RFAILED);
   }
   siGetLnkSel(cb, &lnkSel, swtch, cir);
   siGenPdu(cb, &pduHdr, &allPdus, swtch, opc,
            intfId, phyDpc, intfflg, cic, lnkSel, siGetPriority(M_CONFUSION,
                  swtch), NULLP);
   RETVALUE(ROK); 
} /* end of siGenConfNoCon */


/*
*
*       Fun:   siGenConf
*
*       Desc:  Sends Confusion message.
*
*       Ret:   ROK - ok found
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenConf
(
SiCon *siCon,                /* connection control block */
SiCirCb *cir,                /* circuit */
SiCauseDgn *cause              /* cause */
)
#else
PUBLIC S16 siGenConf(siCon, cir, cause)
SiCon *siCon;                /* connection control block */
SiCirCb *cir;                /* circuit */
SiCauseDgn *cause;             /* cause */
#endif
{
   SiPduHdr pduHdr;
   SiAllPdus allPdus;
   S16 ret;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   TRC2(siGenConf)
   /* Generate Confusion Message to Lower Layer */
   /* prepare Pdu header */
   pduHdr.eh.pres = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val = (U8) M_CONFUSION;
   MFINITPDU(&siCon->mCallCb->mfMsgCtl, ret, (U8) 0, (U8) MI_CONFUSION,
            NULLP, (ElmtHdr *) &allPdus, (U8) PRSNT_DEF,
            cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);
   /* init cause */
   MFINITELMT(&siCon->mCallCb->mfMsgCtl, ret, (ElmtHdr *) cause,
            (ElmtHdr *) &allPdus.m.confusion.causeDgn, &meCauseIndV,
            (U8) PRSNT_NODEF, cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);

   allPdus.m.confusion.causeDgn.recommend.pres = NOTPRSNT;

    siGenPdu(siCon->mCallCb, &pduHdr, &allPdus, cir->pIntfCb->cfg.swtch,
            cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, 
            cir->cfg.cic, siCon->lnkSel, 
            siGetPriority(M_CONFUSION, cir->pIntfCb->cfg.swtch), NULLP); 
   RETVALUE(ROK); 
} /* end of siGenConf */



/*
*
*       Fun:   siGenCnStInd
*
*       Desc:  Generates SiUiSitCnStInd
*
*       Ret:   ROK - ok found
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenCnStInd
(
SiCirCb *cir,
SiAllPdus *msg,
U8 evntType
)
#else
PUBLIC S16 siGenCnStInd(cir, msg, evntType)
SiCirCb *cir;
SiAllPdus *msg;
U8 evntType;
#endif
{
   S16 ret;
   SiCon *con;
   U8 event;
   U8 mode;
   SiAllSdus ev;

   TRC2(siGenCnStInd)

   con = cir->siCon;
   if ((con == NULLP) || ((con->outC.conState == ST_IDLE) &&
           (con->incC.conState == ST_IDLE)))
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
         "siGenCnStInd:either con null or state IDLE\n"));  
        
      RETVALUE(ROK);
   } 
   mode = PRSNT_NODEF;

   switch (evntType)
   {
      /* network resource mnagement message */
      case MI_NETRESMGT:
         /* si029.220: Modification - added INDIA switch */
         if ((con->tCallCb->cfg.swtch != LSI_SW_ITU) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
               "NETRESMGT:for swtch neither ITU, ITU97, ETSI nor India\n"));  
            RETVALUE(ROK);
         } 
         
         event = NETRESMGT;
         break;
      /* identification request */
      case MI_IDENTREQ:
         /* si029.220: Modification - added INDIA switch */
         if ((con->tCallCb->cfg.swtch != LSI_SW_ITU) &&
             (con->tCallCb->cfg.swtch != LSI_SW_FTZ) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "IDENTREQ: for swtch not ITU/FTZ/ETSI/ITU97/INDIA %d\n",
                           con->tCallCb->cfg.swtch));  
            RETVALUE(ROK);
         } 
         event = IDENTREQ;
         break;
      /* identification response */
      case MI_IDENTRSP:
         /* si029.220: Modification - added INDIA switch */
         if ((con->tCallCb->cfg.swtch != LSI_SW_ITU) &&
             (con->tCallCb->cfg.swtch != LSI_SW_FTZ) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "IDENTRSP: for swtch not ITU/FTZ/ETSI/ITU97/INDIA %d\n",
                           con->tCallCb->cfg.swtch));  
            RETVALUE(ROK);
         } 
         event = IDENTRSP;
         break;
/* si029.220: Modification - added INDIA switch */
#if (SS7_RUSSIA || SS7_SINGTEL || SS7_INDIA)
      case MI_CHARGE:
         /* Charge Info */
         if ((con->tCallCb->cfg.swtch != LSI_SW_SINGTEL) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSSIA) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
               "swtch != LSI_SW_SINGTEL/RUSSIA/INDIA returning\n"));
            RETVALUE(ROK);
         }
         event = CHARGE;
         break;
#endif
#if (SS7_ETSI || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      case MI_LOOPPRVNT:
         /* Loop Prevention Message */
         if ((con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97))
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
               "swtch != LSI_SW_ETSI or LSI_SW_ITU97 therefore returning\n"));  
            RETVALUE(ROK);
         } 
         event = LOOPPRVNT;
         break;
#endif
/* si029.220: Modification - added INDIA switch */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      case MI_PRERELINF:
         /* Pre-release message for ETSI v3  and itu 97*/
         if ((con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
               "swtch != ETSIv3, ITU97, INDIA therefore returning\n"));  
            RETVALUE(ROK);
         } 
         event = PRERELEASE;
         break;

      case MI_APPTRAN:
         /* Application transport message for ETSI v3 and itu97 */
         if ((con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
               "swtch != ETSIv3, ITU97, INDIA therefore returning\n"));  
            RETVALUE(ROK);
         } 
         event = APPTRANSPORT;
         break;
#endif
/* si034.220: Modification - added CHINA switch */
#if SS7_CHINA
      case MI_METPULSE:
         /* Metering pulse message for China */
         if (con->tCallCb->cfg.swtch != LSI_SW_CHINA) 
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
               "swtch != LSI_SW_CHINA returning\n"));
            RETVALUE(ROK);
         }
         event = METPULSE;
         break;
      
      case MI_CLGPTYCLR:
         /* Calling Party Clear message for China */
         if (con->tCallCb->cfg.swtch != LSI_SW_CHINA) 
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
               "swtch != LSI_SW_CHINA returning\n"));
            RETVALUE(ROK);
         }
         event = CLGPTCLR;
         break;
      
      case MI_OPERATOR:
         /* Operator message for China */
         if (con->tCallCb->cfg.swtch != LSI_SW_CHINA) 
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
               "swtch != LSI_SW_CHINA returning\n"));
            RETVALUE(ROK);
         }
         event = OPERATOR;
         break;
#endif /* if SS7_CHINA */
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "evntType : %d not recognised for cnstind\n", evntType));  
         RETVALUE(ROK);
   }

   if ((evntType!= MI_CLGPTYCLR) && (evntType != MI_OPERATOR))
   { 
     /* initialize event */
     MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) evntType,
             (U8) SI_CNSTREQ, (ElmtHdr *) msg, (ElmtHdr *) &ev, 
             mode, con->tCallCb->cfg.swtch, (U32) MF_ISUP);
   }

   switch(con->tCallCb->cfg.swtch)
   {
      default:
         break;
   }

   if ((evntType!= MI_CLGPTYCLR) && (evntType != MI_OPERATOR))
   { 
   /* send indication to the upper layer */
   SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId,
          con->suInstId, con->key.k1.spInstId, cir->cfg.cirId,
          &ev.m.siCnStEvnt, event, con->tCallCb->mfMsgCtl.uBuf);
   }
   else
   {
      /* initialize event */
      MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0,
             (U8) SI_CNSTREQ, (ElmtHdr *) msg, (ElmtHdr *) &ev, 
                NOTPRSNT, con->tCallCb->cfg.swtch, (U32) MF_ISUP);

      SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId,
          con->suInstId, con->key.k1.spInstId, cir->cfg.cirId,
          &ev.m.siCnStEvnt, event, con->tCallCb->mfMsgCtl.uBuf);
   }
   
   RETVALUE(ROK); 
} /* end of siGenCnStInd */



/*
*
*       Fun:   siGenRelUpLw
*
*       Desc:  Release Indication to upper and Release to lower layers.
*
*       Ret:   ROK - ok found
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenRelUpLw
(
CirId      cir,              /* circuit */
SiCon      *siCon,           /* connection control block */
SiCauseDgn *cause            /* cause */
)
#else
PUBLIC S16 siGenRelUpLw(cir, siCon, cause)
CirId      cir;              /* circuit */
SiCon      *siCon;           /* connection control block */
SiCauseDgn *cause;           /* cause */
#endif
{
   SiRelEvnt siRelEvnt;
   U8        tmrNum;
   SiPduHdr  pduHdr;
   SiAllPdus allPdus;
   S16       ret;
   Status    status;
   SiCirCb   *tmpCir;
   SiUpSAPCb *tCb;
   Bool genRelInd;

   TRC2(siGenRelUpLw)

   if (cir == siCon->incC.cirId)
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((siCon->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             ((siCon->timers[tmrNum].tmrEvnt & INC) ||
             (siCon->timers[tmrNum].tmrEvnt == TMR_TCRA)))
            siRmvConTq(siCon, tmrNum);
      tCb = SIUPSAP(siCon->incC.cir->pIntfCb->cfg.sapId); 
   }
   else
   {
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((siCon->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (siCon->timers[tmrNum].tmrEvnt & OUTTYPE))
            siRmvConTq(siCon, tmrNum);
      tCb = SIUPSAP(siCon->outC.cir->pIntfCb->cfg.sapId); 
   }
   genRelInd = FALSE;

   if ((siCon->tCallCb) && ((siCon->incC.conPrcs) || 
                            (siCon->outC.conPrcs)))
   {

      genRelInd = TRUE;

      /* Generate Release Indication to Upper Layer */
      MFINITSDU(&siCon->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) SI_RELREQ,
                NULLP, (ElmtHdr *) &siRelEvnt, (U8) PRSNT_DEF,
                siCon->tCallCb->cfg.swtch, (U32) MF_ISUP);

      /* init cause */
      MFINITELMT(&siCon->tCallCb->mfMsgCtl, ret, (ElmtHdr *) cause,
                 (ElmtHdr *) &siRelEvnt.causeDgn, &meCauseIndV,
                 (U8) PRSNT_NODEF, siCon->tCallCb->cfg.swtch, 
                 (U32) MF_ISUP);
   }
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_RELSE;

   MFINITPDU(&siCon->mCallCb->mfMsgCtl, ret, (U8) 0, (U8) MI_RELSE,
             NULLP, (ElmtHdr *) &allPdus, (U8) PRSNT_DEF,
             tCb->cfg.swtch, (U32) MF_ISUP);

   /* init cause */
   MFINITELMT(&siCon->mCallCb->mfMsgCtl, ret, (ElmtHdr *) cause,
              (ElmtHdr *) &allPdus.m.release.causeDgn, &meCauseIndV,
              (U8) PRSNT_NODEF, tCb->cfg.swtch, (U32) MF_ISUP);

   allPdus.m.release.causeDgn.recommend.pres = NOTPRSNT;
   if (cause->location.pres == NOTPRSNT)
   {
      allPdus.m.release.causeDgn.location.pres  = PRSNT_NODEF;
      if (siCon->tCallCb == NULLP)
      {
         allPdus.m.release.causeDgn.location.val = tCb->cfg.relLocation;
      }
      else
      {
         allPdus.m.release.causeDgn.location.val = 
                                        siCon->tCallCb->cfg.relLocation;
      }
   }
   {
      SChkRes(siCon->mCallCb->pst.region, siCon->mCallCb->pst.pool, &status);

      if (status < siCb.genCfg.poolTrUpper)
      {
         allPdus.m.release.auCongLvl.eh.pres          = PRSNT_NODEF;
         allPdus.m.release.auCongLvl.auCongLvl.pres   = PRSNT_NODEF;
         if (status < siCb.genCfg.poolTrLower)
            allPdus.m.release.auCongLvl.auCongLvl.val = ACLVL_LVL2;
         else
            allPdus.m.release.auCongLvl.auCongLvl.val = ACLVL_LVL1;
      }
   }

   if (cir == siCon->incC.cirId)
   {
      tmpCir = siCon->incC.cir;
      /* build copy of a Release Message */
      if ((ret = siBldMsg(siCon->mCallCb, tmpCir->cfg.cic, &pduHdr, &allPdus,
                          siCon->mCallCb->pst.region, siCon->mCallCb->pst.pool,
                          &siCon->incC.rel, tCb->cfg.swtch, 
                          NULLP)) != ROK)
         siCon->incC.rel = NULLP;

      /* Start T1 Timer */
      siStartConTmr(TMR_T1I, siCon, tCb);
      /* Start T5 Timer */
      siStartConTmr(TMR_T5I, siCon, tCb);

      siGenPdu(siCon->mCallCb, &pduHdr, &allPdus, tCb->cfg.swtch,
               tmpCir->opc, tmpCir->cfg.intfId, tmpCir->phyDpc, 
               TRUE, tmpCir->cfg.cic, 
               siCon->lnkSel, siGetPriority(M_RELSE,
               tCb->cfg.swtch), NULLP);

      siCon->incC.relResp = FALSE;
      if ((siCon->tCallCb) && (genRelInd))
      {
         if ((siCon->incC.conState == ST_WTFORRELRSP) ||
             (siCon->incC.conState == ST_WTFORRLCRRS))
         {
            /* change state */
            SISTATECHNG(siCon->incC.conState , ST_WTFORRLCRRS);
            RETVALUE(ROK);
         }
         /* change state */
         SISTATECHNG(siCon->incC.conState , ST_WTFORRLCRRS);
      }
      else
      {
         /* change state */
         SISTATECHNG(siCon->incC.conState , ST_WTFORRELCMP);
      }
   }
   else
   {
      tmpCir = siCon->outC.cir;
      /* build copy of a Release Message */
      if ((ret = siBldMsg(siCon->mCallCb, tmpCir->cfg.cic, &pduHdr, &allPdus,
                          siCon->mCallCb->pst.region, siCon->mCallCb->pst.pool,
                          &siCon->outC.rel, tCb->cfg.swtch,
                          NULLP)) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "     siBldMsg   failed   \n"));  
         siCon->outC.rel = NULLP;
      } 

      /* Start T1 Timer */
      siStartConTmr(TMR_T1O, siCon, tCb);
      /* Start T5 Timer */
      siStartConTmr(TMR_T5O, siCon, tCb);

      siGenPdu(siCon->mCallCb, &pduHdr, &allPdus, tCb->cfg.swtch,
               tmpCir->opc, tmpCir->cfg.intfId, tmpCir->phyDpc, TRUE,
               tmpCir->cfg.cic, 
               siCon->lnkSel, siGetPriority(M_RELSE,
               tCb->cfg.swtch), NULLP);

      siCon->outC.relResp = FALSE;
      if ((siCon->tCallCb) && (genRelInd))
      {
         if ((siCon->outC.conState == ST_WTFORRELRSP) ||
             (siCon->outC.conState == ST_WTFORRLCRRS))
         {
            /* change state */
            SISTATECHNG(siCon->outC.conState , ST_WTFORRLCRRS);
            RETVALUE(ROK);
         }
         /* change state */
         SISTATECHNG(siCon->outC.conState , ST_WTFORRLCRRS);
      }
      else
      {
         /* change state */
         SISTATECHNG(siCon->outC.conState , ST_WTFORRELCMP);
      }
   }

   siRelEvnt.causeDgn.location.pres  = PRSNT_DEF;
/* si004.220 - Modification. Modified code so that when tCallCb in siCon is
 * NULLP timer TMR_TRELRSP and TMR_TFNLRELRSP will not be started.
 */
   if (siCon->tCallCb == NULLP)
   {   
      siRelEvnt.causeDgn.location.val = tCb->cfg.relLocation;
   }
   else
   {
      siRelEvnt.causeDgn.location.val = siCon->tCallCb->cfg.relLocation;
   }
   siRelEvnt.causeDgn.recommend.pres = NOTPRSNT;

   if ((siCon->tCallCb) && (genRelInd))
   {
      siStartConTmr(TMR_TRELRSP, siCon, tCb);
      siStartConTmr(TMR_TFNLRELRSP, siCon, tCb); 
#ifdef IW
      siCon->contCrm |= SI_REL_UPLW;
#endif
      SiUiSitRelInd(&siCon->tCallCb->pst, siCon->tCallCb->suId,
                    siCon->suInstId, siCon->key.k1.spInstId, cir, &siRelEvnt,
                    NULLP);
   }
   RETVALUE(ROK); 
} /* end of siGenRelUpLw */


/*
*
*       Fun:   siGenRelUp
*
*       Desc:  Release Indication to upper layer.
*
*       Ret:   ROK - ok found
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenRelUp
(
CirId cir,                   /* circuit */
SiCon *siCon,                /* connection control block */
SiCauseDgn *cause              /* cause */
)
#else
PUBLIC S16 siGenRelUp(cir, siCon, cause)
CirId cir;                   /* circuit */
SiCon *siCon;                /* connection control block */
SiCauseDgn *cause;             /* cause */
#endif
{
   SiRelEvnt siRelEvnt;
   U8 tmrNum;
   S16 ret;
   Buffer *uBuf;

   TRC2(siGenRelUp)

   if (cir == siCon->incC.cirId)
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((siCon->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (siCon->timers[tmrNum].tmrEvnt & INC))
            siRmvConTq(siCon, tmrNum);
      if ((siCon->incC.conState == ST_WTFORRELRSP) ||
          (siCon->incC.conState == ST_WTFORRLCRRS))
         RETVALUE(ROK);
   }
   else
   {
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((siCon->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (siCon->timers[tmrNum].tmrEvnt & OUTTYPE))
            siRmvConTq(siCon, tmrNum);
      if ((siCon->outC.conState == ST_WTFORRELRSP) ||
          (siCon->outC.conState == ST_WTFORRLCRRS))
         RETVALUE(ROK);
   }

   /* Generate Release Indication to Upper Layer */
   MFINITSDU(&siCon->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) SI_RELREQ,
             NULLP, (ElmtHdr *) &siRelEvnt, (U8) PRSNT_DEF,
             siCon->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* init cause */
   MFINITELMT(&siCon->tCallCb->mfMsgCtl, ret, (ElmtHdr *) cause,
              (ElmtHdr *) &siRelEvnt.causeDgn, &meCauseIndV,
              (U8) PRSNT_NODEF, siCon->tCallCb->cfg.swtch, (U32) MF_ISUP);

   siRelEvnt.causeDgn.location.pres  = PRSNT_DEF;
   siRelEvnt.causeDgn.location.val   = siCon->tCallCb->cfg.relLocation;
   if (cause->causeVal.val == SIT_CCREQUNAVAIL)
   {
      SiUiSitRelCfm(&siCon->tCallCb->pst, siCon->tCallCb->suId,
                    siCon->suInstId, siCon->key.k1.spInstId, cir, &siRelEvnt,
                    siCon->tCallCb->mfMsgCtl.uBuf);
#ifdef ZI
      ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) siCon);
      ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
      ziUpdPeer();
#endif
      /* clear connection */
      if (siCon->incC.cirId == cir)
         siClearIncCon(siCon);
      else
         siClearOutCon(siCon);
   }
   else
   {
      if (siCon->incC.cirId == cir)
      {
         if (cause->causeVal.val == CCNOPARAMPASS)
            siCon->incC.relResp = TRUE;

         /* change state */
         SISTATECHNG(siCon->incC.conState , ST_WTFORRELRSP);
      }
      else
      {
         if (cause->causeVal.val == CCNOPARAMPASS)
            siCon->outC.relResp = TRUE;
         /* change state */
         SISTATECHNG(siCon->outC.conState , ST_WTFORRELRSP);

      }

      siStartConTmr(TMR_TRELRSP, siCon, siCon->tCallCb);
      siStartConTmr(TMR_TFNLRELRSP, siCon, siCon->tCallCb);

      uBuf = siCon->tCallCb->mfMsgCtl.uBuf;
      siCon->tCallCb->mfMsgCtl.uBuf = NULLP;
      SiUiSitRelInd(&siCon->tCallCb->pst, siCon->tCallCb->suId,
                    siCon->suInstId, siCon->key.k1.spInstId, cir, &siRelEvnt,
                    uBuf);
   }
   
   RETVALUE(ROK); 
} /* end of siGenRelUp */


/*
*
*       Fun:   siGenRelLw
*
*       Desc:  Release to lower layers.
*
*       Ret:   ROK - ok found
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenRelLw
(
CirId      cir,                /* circuit */
SiCon      *siCon,             /* connection control block */
SiCauseDgn *cause              /* cause */
)
#else
PUBLIC S16 siGenRelLw(cir, siCon, cause)
CirId      cir;                /* circuit */
SiCon      *siCon;             /* connection control block */
SiCauseDgn *cause;             /* cause */
#endif
{
   SiAllPdus allPdus;
   U8        tmrNum;
   SiPduHdr  pduHdr;
   SiCirCb   *tmpCir;
   S16       ret;
   Status    status;
   SiUpSAPCb *tCb;

   TRC2(siGenRelLw)

   if (cir == siCon->incC.cirId)
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((siCon->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (siCon->timers[tmrNum].tmrEvnt & INC))
            siRmvConTq(siCon, tmrNum);
      tCb = SIUPSAP(siCon->incC.cir->pIntfCb->cfg.sapId); 
   }
   else
   {
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((siCon->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (siCon->timers[tmrNum].tmrEvnt & OUTTYPE))
            siRmvConTq(siCon, tmrNum);
      tCb = SIUPSAP(siCon->outC.cir->pIntfCb->cfg.sapId); 
   }

   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_RELSE;

   MFINITPDU(&siCon->mCallCb->mfMsgCtl, ret, (U8) 0, (U8) MI_RELSE,
             NULLP, (ElmtHdr *) &allPdus, (U8) PRSNT_DEF,
             tCb->cfg.swtch, (U32) MF_ISUP);

   /* init cause */
   MFINITELMT(&siCon->mCallCb->mfMsgCtl, ret, (ElmtHdr *) cause,
              (ElmtHdr *) &allPdus.m.release.causeDgn, &meCauseIndV,
              (U8) PRSNT_NODEF, tCb->cfg.swtch, (U32) MF_ISUP);
   {
      SChkRes(siCon->mCallCb->pst.region, siCon->mCallCb->pst.pool, &status);
      if (status < siCb.genCfg.poolTrUpper)
      {
         allPdus.m.release.auCongLvl.eh.pres          = PRSNT_NODEF;
         allPdus.m.release.auCongLvl.auCongLvl.pres   = PRSNT_NODEF;
         if (status < siCb.genCfg.poolTrLower)
            allPdus.m.release.auCongLvl.auCongLvl.val = ACLVL_LVL2;
         else
            allPdus.m.release.auCongLvl.auCongLvl.val = ACLVL_LVL1;
      }
   }

   allPdus.m.release.causeDgn.recommend.pres       = NOTPRSNT;

   if (siCon->incC.cirId == cir)
   {
      tmpCir = siCon->incC.cir;
      /* build copy of a Release Message */
      if ((ret = siBldMsg(siCon->mCallCb, tmpCir->cfg.cic, &pduHdr, &allPdus,
                          siCon->mCallCb->pst.region, siCon->mCallCb->pst.pool,
                          &siCon->incC.rel, tCb->cfg.swtch,
                          NULLP)) != ROK)
         siCon->incC.rel = NULLP;

      /* change state */
      SISTATECHNG(siCon->incC.conState , ST_WTFORRELCMP);
      siCon->incC.relResp = FALSE;

      /* Start T1 Timer */
      siStartConTmr(TMR_T1I, siCon, tCb);
      /* Start T5 Timer */
      siStartConTmr(TMR_T5I, siCon, tCb);
   }
   else
   {
      tmpCir = siCon->outC.cir;

      /* build copy of a Release Message */
      if ((ret = siBldMsg(siCon->mCallCb, tmpCir->cfg.cic, &pduHdr, &allPdus,
                          siCon->mCallCb->pst.region, siCon->mCallCb->pst.pool,
                          &siCon->outC.rel, tCb->cfg.swtch,
                          NULLP)) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "     siBldMsg   failed   \n"));  
         siCon->outC.rel = NULLP;
      } 

      /* change state */
      SISTATECHNG(siCon->outC.conState , ST_WTFORRELCMP);
      siCon->outC.relResp  = FALSE;

      /* Start T1 Timer */
      siStartConTmr(TMR_T1O, siCon, tCb);
      /* Start T5 Timer */
      siStartConTmr(TMR_T5O, siCon, tCb);
   }

   siGenPdu(siCon->mCallCb, &pduHdr, &allPdus, tCb->cfg.swtch,
            tmpCir->opc, tmpCir->cfg.intfId, tmpCir->phyDpc, TRUE,
            tmpCir->cfg.cic, siCon->lnkSel, 
            siGetPriority(M_RELSE, tCb->cfg.swtch), NULLP); 
   RETVALUE(ROK); 
} /* end of siGenRelLw */


/*
*
*       Fun:   siGenMFacRej
*
*       Desc:  Generate Facility Reject through MTP
*
*       Ret:   ROK - ok found
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenMFacRej
(
CirId cir,                   /* circuit id */
SiCon *con,                  /* connection control block */
SiCauseDgn *cause,           /* cause */
SiAllPdus *message           /* pointer to decoded message */
)
#else
PUBLIC S16 siGenMFacRej(cir, con, cause, message)
CirId cir;                   /* circuit id */
SiCon *con;                  /* connection control block */
SiCauseDgn *cause;           /* cause */
SiAllPdus *message;          /* pointer to decoded message */
#endif
{
   SiAllPdus allPdus;
   SiPduHdr pduHdr;
   SiCirCb *tmpCir;
   Swtch   swtch;
   S16 ret;

   TRC2(siGenMFacRej)

   if (cir == con->incC.cirId)
   {
      tmpCir = con->incC.cir;
      swtch  = con->incC.cir->pIntfCb->cfg.swtch;
   }
   else
   {
      tmpCir = con->outC.cir;
      swtch  = con->outC.cir->pIntfCb->cfg.swtch;
   }
   /* prepare Pdu header */
   pduHdr.eh.pres = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val = (U8) M_FACREJ;

   MFINITPDU(&con->mCallCb->mfMsgCtl, ret, (U8) MI_FACREQ, (U8) MI_FACREJ,
            (ElmtHdr *) message, (ElmtHdr *) &allPdus, (U8) PRSNT_NODEF,
            swtch, (U32) MF_ISUP);

   /* init cause */
   MFINITELMT(&con->mCallCb->mfMsgCtl, ret, (ElmtHdr *) cause,
            (ElmtHdr *) &allPdus.m.facReject.causeDgn, &meCauseIndV,
            (U8) PRSNT_NODEF, swtch, (U32) MF_ISUP);

   siGenPdu(con->mCallCb, &pduHdr, &allPdus, swtch,
            tmpCir->opc, tmpCir->cfg.intfId, tmpCir->phyDpc, TRUE, 
            tmpCir->cfg.cic, con->lnkSel, siGetPriority(M_FACREJ, 
            swtch), NULLP); 
   RETVALUE(ROK); 
} /* end of siGenMFacRej */


/*
*
*       Fun:   siGenSFacRej
*
*       Desc:  Generate Facility Reject through SCCP
*
*       Ret:   ROK - ok found
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenSFacRej
(
SiNSAPCb *cb,                  /* Sap control block */
SiCauseDgn *cause,             /* cause */
Dpc opc,                       /* dpc */
SiInstId intfid,               /* interface id */
Dpc phyDpc,                    /* physical DPC */
U8    intfflg,                 /* interface flag */
SiAllPdus *message,            /* pointer to decoded message */
Swtch swtch                    /* variant */
)
#else
PUBLIC S16 siGenSFacRej(cb, cause, opc, intfid, phyDpc, intfflg, message, swtch)
SiNSAPCb *cb;                  /* Sap control block */
SiCauseDgn *cause;             /* cause */
Dpc opc;                       /* opc */
SiInstId intfid;               /* interface id */
Dpc phyDpc;                    /* physical DPC */
U8    intfflg;                 /* interface flag */
SiAllPdus *message;            /* pointer to decoded message */
Swtch swtch;                   /* variant */
#endif
{
   SiAllPdus allPdus;
   SiPduHdr pduHdr;
   S16 ret;

   TRC2(siGenSFacRej)

   /* prepare Pdu header */
   pduHdr.eh.pres = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val = (U8) M_FACREJ;

   MFINITPDU(&cb->mfMsgCtl, ret, (U8) MI_FACREQ, (U8) MI_FACREJ,
            (ElmtHdr *) message, (ElmtHdr *) &allPdus, (U8) PRSNT_DEF,
            swtch, (U32) MF_ISUP);

   /* init cause */
   MFINITELMT(&cb->mfMsgCtl, ret, (ElmtHdr *) cause,
            (ElmtHdr *) &allPdus.m.facReject.causeDgn, &meCauseIndV,
            (U8) PRSNT_NODEF, swtch, (U32) MF_ISUP);

   siGenScPdu(cb, &pduHdr, &allPdus, swtch, opc, intfid,
            phyDpc, intfflg, FALSE, NULLP);

   RETVALUE(ROK); 
} /* end of siGenSFacRej */


/*
*
*       Fun:   siGenReatInd
*
*       Desc:  Reattemp Indication to upper layer.
*
*       Ret:   ROK - ok found
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenReatInd
(
CirId cir,                   /* circuit */
SiCon *siCon,                /* connection control block */
SiCauseDgn *cause              /* cause */
)
#else
PUBLIC S16 siGenReatInd(cir, siCon, cause)
CirId cir;                   /* circuit */
SiCon *siCon;                /* connection control block */
SiCauseDgn *cause;             /* cause */
#endif
{
   SiStaEvnt siStaEvnt;
   U8 tmrNum;
   S16 ret;

   TRC2(siGenReatInd)

   if (cir == siCon->outC.cirId)
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((siCon->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (siCon->timers[tmrNum].tmrEvnt & OUTTYPE))
            siRmvConTq(siCon, tmrNum);
   }
   else
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((siCon->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (siCon->timers[tmrNum].tmrEvnt & INC))
            siRmvConTq(siCon, tmrNum);
   }

   /* Generate Status Indication to Upper Layer */
   MFINITSDU(&siCon->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) SI_STAREQ,
            NULLP, (ElmtHdr *) &siStaEvnt, (U8) PRSNT_DEF,
            siCon->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* init cause */
   MFINITELMT(&siCon->tCallCb->mfMsgCtl, ret, (ElmtHdr *) cause,
            (ElmtHdr *) &siStaEvnt.causeDgn, &meCauseIndV,
            (U8) PRSNT_NODEF, siCon->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* send reattempt indication to the upper layer */
   SiUiSitStaInd(&siCon->tCallCb->pst, siCon->tCallCb->suId,
                 siCon->suInstId, siCon->key.k1.spInstId, cir, FALSE, 
                 SIT_STA_REATTEMPT, &siStaEvnt, NULLP);

   if( ! siCon->incC.conPrcs )
   {
      /* remove Upper Call Ref */
      if (siCon->key.k1.spInstId)
      {
         siDelInst(&siCb.conHlCp, siCon);
         siCon->key.k1.spInstId = 0;
      }
#if ICCREATTEMPT
      SISTATECHNG(siCon->outC.conState, ST_IDLE);
      siCon->suInstId = 0;
#endif

   }
   RETVALUE(ROK); 
} /* end of siGenReatInd */


/*
*
*       Fun:   siGenStaInd
*
*       Desc:  Generate Status Indication to upper layer.
*
*       Ret:   ROK - ok found
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenStaInd
(
CirId cir,                   /* circuit */
SiCon *siCon,                /* connection control block */
U8 msgIdx                    /* message index */
)
#else
PUBLIC S16 siGenStaInd(cir, siCon, msgIdx)
CirId cir;                   /* circuit */
SiCon *siCon;                /* connection control block */
U8 msgIdx;                   /* message index */
#endif
{
   SiAllSdus ev;
   U8 event;
   S16 ret;

   TRC2(siGenStaInd)

   event = 0;

   switch (msgIdx)
   {
      case MI_LOOPBCKACK:
         /* Generate Status Indication to Upper Layer */
         MFINITSDU(&siCon->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) SI_STAREQ,
                  NULLP, (ElmtHdr *) &ev, (U8) PRSNT_DEF,
                  siCon->tCallCb->cfg.swtch, (U32) MF_ISUP);
         event = SIT_STA_LOOPBACKACK;
         break;
      case MI_CONFUSION:
         /* Generate Status Indication to Upper Layer */
         MFINITSDU(&siCon->tCallCb->mfMsgCtl, ret, (U8) MI_CONFUSION,
                  (U8) SI_STAREQ, (ElmtHdr *) siCon->pduSp,
                  (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
                  siCon->tCallCb->cfg.swtch, (U32) MF_ISUP);
         event = SIT_STA_CONFUSION;
         break;
      case MI_USRPARTA:
         /* Generate Status Indication to Upper Layer */
         MFINITSDU(&siCon->tCallCb->mfMsgCtl, ret, (U8) 0, 
                  (U8) SI_STAREQ, (ElmtHdr *) NULLP, 
                  (ElmtHdr *) &ev, (U8) PRSNT_DEF,
                  siCon->tCallCb->cfg.swtch, (U32) MF_ISUP);
         event = SIT_STA_USRPARTA;
         break;
   }

   /* send status indication to the upper layer */
   SiUiSitStaInd(&siCon->tCallCb->pst, siCon->tCallCb->suId,
                 siCon->suInstId, siCon->key.k1.spInstId, cir, FALSE, event,
                 &ev.m.siStaEvnt, NULLP);

   RETVALUE(ROK); 
} /* end of siGenStaInd */


/*
*
*       Fun:   siClearOutCon
*
*       Desc:  Clears outgoing side of circuit connection
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siClearOutCon
(
SiCon *con                   /* connection control block */
)
#else
PUBLIC S16 siClearOutCon(con)
SiCon *con;                  /* connection control block */
#endif
{
   Buffer  *mBuf;
   S16     ret;
   SiInstId intfid;
   U8       intfflg;
   Dpc      phyDpc;
   
   TRC2(siClearOutCon)

   if (con->outC.relResp)
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "relResp already SET\n"));  
      RETVALUE(ROK);
   } 
   if (con->outC.cir)
   {
      intfid = con->outC.cir->cfg.intfId;
      phyDpc = con->outC.cir->phyDpc;
      intfflg = TRUE;
   }
   else
   {
      /* Note that 0 is a valid interface id , though just to pass
       * an initialised variable intfid is initialised to 0 
       */
      intfid = 0;
      phyDpc = con->outC.phyDpc;
      intfflg = FALSE;
   }
   con->outC.conPrcs = FALSE;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(con->outC.cir) != ROK)
      RETVALUE(RFAILED);
#endif

   if (con->sccpUsed)
   {
      ret = SGetMsg(con->sCallCb->pst.region, con->sCallCb->pst.pool, &mBuf);
      if (ret == ROK)
      {  
         /* tell SCCP, that connection sequence is over */
         siSndMsg(con->mCallCb, mBuf, con->outC.cir->opc, intfid, phyDpc,
               intfflg, 0, TRUE, PRI_ZERO, con->outC.cir->pIntfCb->cfg.swtch);
      } 
      else  
      {  
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "SGetMsg failed.Proceeding ...\n"));  
      } 
   }

   if (con->outC.cir != NULLP)
   {
      /* if circuit is not in transient state, idle it */
      if (con->outC.cir->calProcStat != TRANS)
      {              
         SISTATECHNG(con->outC.cir->calProcStat , CALL_IDLE);
      }
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if this is a non-single rate call. If so, should clear the
       * circuit cb pointer for all affected circuits
       */
      if (con->outC.cir->ctrlMultiRateCir != NULLP)
      {
         /* this is a non-single rate connection. Break the linkage */
         if (siDelMRateLnk(&con->outC) != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "Break the linkage of outgoing non-single rate call failed.\n"));  
            RETVALUE(RFAILED);
         }
      }           
#endif
      con->outC.cir->siCon = NULLP;
      con->outC.cir        = NULLP;
   }

   con->outC.cirId      = 0;
   if (con->outC.rel)
      siDropMsg(con->outC.rel);
   con->outC.rel        = NULLP;
   con->outC.dCallRef   = 0;
   SISTATECHNG(  con->outC.conState   , 0);
   con->outC.relResp    = FALSE;

   if (!con->incC.conPrcs)
      siRelCon(con);

   RETVALUE(ROK);
} /* end of siClearOutCon */


/*
*
*       Fun:   siForceClearOutCon
*
*       Desc:  Unconditionally clears outgoing side 
*              of circuit connection
*
*       Ret:   ROK      - ok
*              RAFILED  - not ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siForceClearOutCon
(
SiCon *con                   /* connection control block */
)
#else
PUBLIC S16 siForceClearOutCon(con)
SiCon *con;                  /* connection control block */
#endif
{
   TRC2(siForceClearOutCon)
   if (con != NULLP)
   {
      con->outC.relResp = FALSE;
      RETVALUE(siClearOutCon(con));
   }
   else
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "siForceClearOutCon: Conn cb is NULL\n"));  
      RETVALUE(RFAILED);       
   }

} /* end of siForceClearOutCon */
 

/*
*
*       Fun:   siClearIncCon
*
*       Desc:  Clears incoming side of circuit connection
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siClearIncCon
(
SiCon *con                   /* connection control block */
)
#else
PUBLIC S16 siClearIncCon(con)
SiCon *con;                  /* connection control block */
#endif
{
   Buffer  *mBuf;
   S16     ret;
   SiInstId intfid;
   U8       intfflg;
   Dpc      phyDpc;

   TRC2(siClearIncCon)
   if (con->incC.relResp)
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "relResp already set\n"));  
      RETVALUE(ROK);
   } 
   con->incC.conPrcs = FALSE;
   
   if (con->incC.cir)
   {
      intfid = con->incC.cir->cfg.intfId;
      phyDpc = con->incC.cir->phyDpc;
      intfflg = TRUE;
   }
   else
   {
      /* Note that 0 is a valid interface id , though just to pass
       * an initialised variable intfid is initialised to 0 
       */
      intfid = 0;
      phyDpc = con->incC.phyDpc;
      intfflg = FALSE;
   }

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(con->incC.cir) != ROK)
      RETVALUE(RFAILED);
#endif

   if (con->sccpUsed)
   {
      ret = SGetMsg(con->sCallCb->pst.region, con->sCallCb->pst.pool, &mBuf);
      if (ret == ROK)
      {
         /* tell SCCP, that connection sequence is over */
         siSndMsg(con->mCallCb, mBuf, con->incC.cir->opc, intfid, phyDpc, 
                     intfflg, 0, TRUE, PRI_ZERO, 
                     con->incC.cir->pIntfCb->cfg.swtch);
      } 
      else 
      {  
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "SGetMsg failed. Proceeding ...\n"));  
      } 
   }

   if (con->incC.cir != NULLP)
   {
      /* if circuit is not in transient state, idle it */
      if (con->incC.cir->calProcStat != TRANS)
      {              
         SISTATECHNG(con->incC.cir->calProcStat, CALL_IDLE);
      }         
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if this is a non-single rate call. If so, should clear the
       * circuit cb pointer for all affected circuits
       */
      if (con->incC.cir->ctrlMultiRateCir != NULLP)
      {
         /* this is a non-single rate connection. Break the linkage */
         if (siDelMRateLnk(&con->incC) != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "Break the linkage of incoming non-single rate call failed.\n"));  
            RETVALUE(RFAILED);
         }
      }           
#endif
      con->incC.cir->siCon = NULLP;
      con->incC.cir        = NULLP;
   }

   con->incC.cirId        = 0;
   if (con->incC.msgToSegm)
   {
      siDropMsg(con->incC.msgToSegm);
      con->incC.msgToSegm = NULLP;
   }
   if (con->incC.rel)
      siDropMsg(con->incC.rel);
   con->incC.rel          = NULLP;
   con->incC.dCallRef     = 0;
   SISTATECHNG(  con->incC.conState     , 0);
   if (!con->outC.conPrcs)
      siRelCon(con);
   RETVALUE(ROK);
} /* end of siClearIncCon */
 
/*
*
*       Fun:   siForceClearIncCon
*
*       Desc:  Unconditionally clears incoming side 
*              of circuit connection
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siForceClearIncCon
(
SiCon *con                   /* connection control block */
)
#else
PUBLIC S16 siForceClearIncCon(con)
SiCon *con;                  /* connection control block */
#endif
{

   TRC2(siForceClearIncCon)
   if (con != NULLP)
   {
      con->incC.relResp = FALSE;
      RETVALUE(siClearIncCon(con));
   }
   else
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "siForceClearIncCon: Conn cb is NULL\n"));  
      RETVALUE(RFAILED);       
   }
} /* end of siForceClearIncCon */



/*
*
*       Fun:   siRelCon
*
*       Desc:  Release circuit connection
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siRelCon
(
SiCon *con                   /* connection control block */
)
#else
PUBLIC S16 siRelCon(con)
SiCon *con;                  /* connection control block */
#endif
{
   U8 tmrNum;

   TRC2(siRelCon)
   con->mCallCb = NULLP;
   con->sCallCb = NULLP;
   /* remove timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
   {
      if (con->timers[tmrNum].tmrEvnt != TMR_NONE)
         siRmvConTq(con, tmrNum);
   }
   if (!con->sccpUsed)
   {
       /* Idle the circuit(which attached with the connection) state */
       if (con->outC.cir != NULLP)
          SISTATECHNG(con->outC.cir->calProcStat, CALL_IDLE);
       if (con->incC.cir != NULLP)
          SISTATECHNG(con->incC.cir->calProcStat, CALL_IDLE);

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if this con cb is used by any non-single rate call. If so,
       * clear the linkage. This is required if this funciton is called
       * directly
       */ 
      /* Break the outgoing connection linkage */
      if ((con->outC.cir != NULLP) &&
          (con->outC.cir->ctrlMultiRateCir != NULLP))
      {
         if (siDelMRateLnk(&con->outC) != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "Break the linkage of outgoing non-single rate call failed.\n"));  
            RETVALUE(RFAILED);
         }
      }   

      /* Break the incoming connection linkage */
      if ((con->incC.cir != NULLP) &&
          (con->incC.cir->ctrlMultiRateCir != NULLP))
      {
         if (siDelMRateLnk(&con->incC) != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "Break the linkage of incoming non-single rate call failed.\n"));  
            RETVALUE(RFAILED);
         }
      }           
#endif

      con->tCallCb = NULLP;
      if (con->key.k1.spInstId)
         siDelInst(&siCb.conHlCp, con);

      /* Code to check the prev and next pointers after
       * the deletion from the hash list to avoid double insertion.
       */      
#ifdef SI_CMHASH_CHK
      /* Check if the next and prev pointers are not null */
      if ((con->hl.list.next) || (con->hl.list.prev))
      {
         /* Print diagnostic information */
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "hash:siRelCon:ConBlk conState:(inc:%d,out:%d) \
                conPrcs:(inc:%d out:%d) \n", con->incC.conState, 
                con->outC.conState, con->incC.conPrcs, con->outC.conPrcs));
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "hash:siRelCon: ACTION: \
                Deleting from the hash list unconditionally\n"));
         siDelInst(&siCb.conHlCp, con);
      }
#endif /* SI_CMHASH_CHK */

#ifdef IW
      if (con->conEvt != NULLP)
      {
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) con->conEvt, 
                  (Size) sizeof(SiConEvnt));
         con->conEvt = NULLP;
      }
#endif
      SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) con, (Size) sizeof(SiCon));
   } 
   else     
      /* Start T31 Timer */
      siStartConTmr(TMR_T31, con, con->tCallCb);
   RETVALUE(ROK);
} /* end of siRelCon */
 

/*
*
*       Fun:   siGenPdu
*
*       Desc:  generate pdu
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenPdu
(
SiNSAPCb *cb,                   /* network layer control block */
SiPduHdr *pduHdr,
SiAllPdus *allPdus,
Swtch swtch,
Dpc   opc,
SiInstId intfId,
Dpc   phyDpc,  /* physical destination point code */
U8    intfflg, /* interface valid flag */
Cic cic,
LnkSel lnkSel,
Priority prior,
Buffer *uBuf
)
#else
PUBLIC S16 siGenPdu(cb, pduHdr, allPdus, swtch, opc, intfId, phyDpc, intfflg,
                  cic, lnkSel, prior, uBuf) 
SiNSAPCb *cb;                   /* network layer control block */
SiPduHdr *pduHdr;
SiAllPdus *allPdus;
Swtch swtch;
Dpc opc;
SiInstId intfId;
Dpc   phyDpc;  /* physical destination point code */
U8    intfflg; /* interface valid flag */
Cic cic;
LnkSel lnkSel;
Priority prior;
Buffer *uBuf;
#endif
{
   Buffer *mBuf;            /* message buffer */
/*si047.220 : Modified Remove warnings */
   MsgLen bufLen;
   S16 ret;
   Buffer *segmBuf;
   U16   maxSizMsg;
   U16   netMaxSizMsg;
   /* si009.220, ADDED: added a local variable for interface cb */
   SiIntfCb  *intfCb;

   TRC2(siGenPdu)

   /* Check if the lower SAP is bound to the service provider */
   if (cb->state != SI_BND)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   Lower SAP not bound.   \n"));  
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI570, (ErrVal) 0, 
                 "siGenPdu() Failed, Lower SAP not bound. ");
#endif
      RETVALUE(RFAILED);
   }

   /* si009.220, ADDED: check the interface state. If it is unavailable,
    * stop sending the traffic
    */
   /* If interface id is valid, find interface control block */
   if (intfflg == TRUE) 
   {
      if (siFindIntf(&intfCb, intfId, 0, 0, 0, 0, SIINTF_KEY_1) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "interface (%#lx) control block can't be found\n", intfId));
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESIXXX, (ErrVal) intfId, 
                    "siGenPdu() Failed, Interface CB can't be found. ");
#endif
         RETVALUE(RFAILED);
      }

/* si019.220: modification - add a compile time flag SI_NO_INTF_CHECK
   so that the interface availability check can be turned on or off.
*/
#ifndef SI_NO_INTF_CHECK
      /* si018.220: modification - when it is CVT message, then we
       * should send it out even if the interface state is unavailable
       */
      if (pduHdr->msgType.val != (U8) M_CIRVALTEST)
      {
         if (intfCb->state == SI_INTF_UNAVAIL)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                   "INTF (%#lx) state is unavailable \n", intfId)); 
#if (ERRCLASS & ERRCLS_DEBUG)
            SILOGERROR(ERRCLS_DEBUG, ESIXXX, (ErrVal) intfId, 
                       "siGenPdu() Failed, Interface state is unavailable. ");
#endif
            RETVALUE(RFAILED);
         }
      } /* if */
#endif /* SI_NO_INTF_CHECK */
   }

   /* build message */
   ret = siBldMsg(cb, cic, pduHdr, allPdus, cb->pst.region, cb->pst.pool,
                  &mBuf, swtch, uBuf);
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   siBldMsg   failed   \n"));  
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI571, (ErrVal) 0, 
                 "siGenPdu() Failed, SFndLenMsg failed ");
#endif
      RETVALUE(RFAILED);
   }
   switch (swtch)
   {

      default:
         maxSizMsg = MAX_SIMTP2_LEN;
         netMaxSizMsg = MAX_SIMSG_LEN;
         break;
   }
 
   /* si009.220, DELETED: move the code for selecting the link base on CIC 
    * to function siGetLnkSel
    */

   ret = SFndLenMsg(mBuf, &bufLen);
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SFndLenMsg   failed   \n"));  
      siDropMsg(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI573, (ErrVal) 0, 
                 "siGenPdu() Failed, SFndLenMsg failed ");
#endif
      RETVALUE(RFAILED);
   }
   if (bufLen > netMaxSizMsg)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "bufLen %d is GT limit %d\n", bufLen, netMaxSizMsg));  
      siDropMsg(mBuf);
      RETVALUE(bufLen);
   }
   if (bufLen > maxSizMsg)
   {
      /* check if the segmentation is allowed base on the
       * variant type
       */
      switch (swtch)
      {
         default:
            /* For other variant type, only IAM, ACM, ANM, CPG and
             * CON can be segmentable */
            switch(pduHdr->msgType.val)
            {
               case M_INIADDR:
               case M_ADDCOMP:
               case M_ANSWER:
               case M_CALLPROG:
               case M_CONNCT:
                  break;
 
               default:
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "Msg %d not segmentable and length %d requires\n",
                       pduHdr->msgType.val, bufLen));  
              
                  /* this is a message not segmentable: discards it */
                  siDropMsg(mBuf);
                  RETVALUE(bufLen);
            }
            break;
      }      

      {
         /* segments the message */
         ret = siSegmMsg(pduHdr->msgType.val, cb, mBuf, &segmBuf, swtch);
      }

      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   siSegmMsg   failed   \n"));  
         siDropMsg(mBuf);
         RETVALUE(RFAILED);
      }
      /* si009.220, MODIFIED: use the function to send message without check 
       * the interface state again
       */
      /* sends the segmented message */
      siSndMsgNoChk(cb, mBuf, opc, intfId, phyDpc, intfflg, lnkSel, 
                    TRUE, prior, swtch);
 
      /* sends the SGM or INF */
      siSndMsgNoChk(cb, segmBuf, opc, intfId, phyDpc, intfflg, lnkSel, 
                    TRUE, prior, swtch);
   }

   else
      /* si009.220, MODIFIED: use the function to send message without check 
       * the interface state again
       */
      /* send message */
      siSndMsgNoChk(cb, mBuf, opc, intfId, phyDpc, intfflg, lnkSel, 
                    TRUE, prior, swtch);

   RETVALUE(ROK);
} /* end of siGenPdu */
 

/*
*
*       Fun:   siGenScPdu
*
*       Desc:  generate pdu for SCCP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenScPdu
(
SiNSAPCb *cb,                   /* network layer control block */
SiPduHdr *pduHdr,
SiAllPdus *allPdus,
Swtch swtch,
Dpc  opc,
SiInstId intfid,
Dpc phyDpc,
U8    intfflg,    /* interface id valid flag */
Bool endSeg,
Buffer *uBuf
)
#else
PUBLIC S16 siGenScPdu(cb, pduHdr, allPdus, swtch, opc, intfid, 
                           phyDpc, intfflg, endSeg, uBuf)
SiNSAPCb *cb;                   /* network layer control block */
SiPduHdr *pduHdr;
SiAllPdus *allPdus;
Swtch swtch;
Dpc  opc;
SiInstId intfid;
Dpc phyDpc;
U8    intfflg;    /* interface id valid flag */
Bool endSeg;
Buffer *uBuf;
#endif
{
   Buffer *mBuf;            /* message buffer */
   S16 ret;

   TRC2(siGenScPdu)

   /* Check if the lower SAP is bound to the service provider */
   if (cb->state != SI_BND)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   Lower SAP not bound.   \n"));  
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI574, (ErrVal) 0, 
                 "siGenScPdu() Failed, Lower SAP not bound. ");
#endif
      RETVALUE(RFAILED);
   }

   /* build message */
   ret = siBldMsg(cb, 0, pduHdr, allPdus, cb->pst.region, cb->pst.pool,
                  &mBuf, swtch, uBuf);

   /* send message */
   siSndMsg(cb, mBuf, opc, intfid, phyDpc, intfflg, 0, 
            endSeg, PRI_ZERO, swtch);

   RETVALUE(ROK);
} /* end of siGenScPdu */
 
#ifdef SI_SPT
  
/*
*
*       Fun:   siBldUData
*
*       Desc:  build uData structure for SCCP messages
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siBldUData
(
SpUDatEvnt *uData,
Dpc phyDpc,
Dpc opc,
Swtch swtch
)
#else
PUBLIC S16 siBldUData(uData, phyDpc, opc, swtch)
SpUDatEvnt *uData;
Dpc phyDpc;
Dpc opc;
Swtch swtch;
#endif
{

   TRC2(siBldUData)
   /* protocol class */
   uData->qos.pClass = (U8) PCLASS1;
   uData->qos.retOpt = (U8) REC_ROE;
   uData->qos.credit = (U8) 0;
   uData->tmr = (U8) 0;

   /* addressing data */
   uData->cdAddr.pres = PRSNT_NODEF;   
   uData->cdAddr.sw = swtch;
   switch(swtch)
   {
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         uData->cdAddr.niInd = INAT_IND;
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Invalid swtch %d\n", swtch));  
         SILOGERROR(ERRCLS_DEBUG, ESI575, (ErrVal) 0, 
                 "siBldUData() Failed, invalid switch");
         RETVALUE(ROK);
#endif
   }
   uData->cdAddr.rtgInd = RTE_SSN;
   uData->cdAddr.pcInd = TRUE;
   uData->cdAddr.ssnInd = TRUE;
   uData->cdAddr.pc = phyDpc;
   uData->cdAddr.ssn = SS_ISUP;
   uData->cdAddr.gt.format = GTFRMT_0;

   /* originating address */
   uData->cgAddr.pres = PRSNT_NODEF;
   uData->cgAddr.sw = swtch;
   switch(swtch)
   {
      case LSI_SW_ITU:
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         uData->cgAddr.niInd = INAT_IND;
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Invalid swtch %d\n", swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI576, (ErrVal) 0, 
                 "siBldUData() Failed, invalid switch");
         RETVALUE(ROK);
#endif
   }
   uData->cgAddr.rtgInd = RTE_SSN;
   uData->cgAddr.pcInd = TRUE;
   uData->cgAddr.ssnInd = TRUE;
   uData->cgAddr.pc = opc;
   uData->cgAddr.ssn = SS_ISUP;
   uData->cgAddr.gt.format = GTFRMT_0;

   RETVALUE(ROK);
} /* end of siBldUData */
#endif

  
/*
*
*       Fun:   siBldMsg
*
*       Desc:  build message
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siBldMsg
(
SiNSAPCb *cb,                   /* network layer control block */
Cic cic,
SiPduHdr *hdr,
SiAllPdus *msg,
Region region,
Pool pool,
Buffer **mBuf,
Swtch swtch,
Buffer *uBuf 
)
#else
PUBLIC S16 siBldMsg(cb, cic, hdr, msg, region, pool, mBuf, swtch, uBuf)
SiNSAPCb *cb;                   /* data link control block */
Cic cic;
SiPduHdr *hdr;
SiAllPdus *msg;
Region region;
Pool pool;
Buffer **mBuf;
Swtch swtch;
Buffer *uBuf;
#endif
{
   Buffer *tBuf;
   S16    ret;
   Bool   valFlg;
   Data   byte1;
   Data   byte2;
   Buffer *savUbuf;

   TRC2(siBldMsg)
   *mBuf = 0;

   ret = SGetMsg(region, pool, &tBuf);
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "     SGetMsg   failed   \n"));  
      RETVALUE(RFAILED);
   } 

   if (cb->mfMsgCtl.msgIdx == MI_FACREJ)
      valFlg = FALSE;
   else
      valFlg = TRUE;

   /* save the old 'uBuf' contents of msgCtl */
   savUbuf = cb->mfMsgCtl.uBuf;
   /* no 'uBuf' during encoding PDU header */
   cb->mfMsgCtl.uBuf = NULLP;

   switch (cb->cfg.sapType)
   {
      case SAP_MTP:
      case SAP_M3UA:
         /* insert cic into message */
         byte1 = (U8) GetLoByte(cic);
         ret = SAddPstMsg(byte1, tBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SAddPstMsg   failed   \n"));  
            /* return tBuf */
            siDropMsg(tBuf);
            SILOGERROR(ERRCLS_ADD_RES, ESI577, (ErrVal) ret,
                       "SAddPstMsg failed in siBldMsg");
            RETVALUE(RFAILED);
         }
#endif
         byte2 = (U8) GetHiByte(cic);
         ret = SAddPstMsg(byte2, tBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SAddPstMsg   failed   \n"));  
            /* return tBuf */
            siDropMsg(tBuf);
            SILOGERROR(ERRCLS_ADD_RES, ESI578, (ErrVal) ret, 
                       "SAddPstMsg failed in siBldMsg");
            RETVALUE(RFAILED);
         }
#endif
         break;
      case SAP_SCCP:
         break;
   }
   MFENCPDUHDR(&cb->mfMsgCtl, ret, tBuf, (ElmtHdr *) hdr, &siPduHdrMsgDef[0], 
               valFlg, TRUE, swtch, MF_ISUP);
   if (ret != ROK)
   {
      siDropMsg(tBuf);
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MFENCPDUHDR Failed\n"));  
        
#ifdef DBG4
      siMfPrntErr(&cb->mfMsgCtl);
#endif
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI579, (ErrVal) 0, 
                 "siBldMsg() Failed, encode header failed");
#endif
      RETVALUE(RFAILED);
   }

   /* attach new uBuf to msgCtl */
   cb->mfMsgCtl.uBuf = uBuf;

   MFENCPDU(&cb->mfMsgCtl, ret, (ElmtHdr *) msg);

   /* reattach the old contents */
   cb->mfMsgCtl.uBuf = savUbuf; 

   if (ret !=ROK)
   {
      siDropMsg(tBuf);
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MFENCPDU Failed\n"));  
        
#ifdef DBG4
      siMfPrntErr(&cb->mfMsgCtl);
#endif
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI580, (ErrVal) 0, 
                 "siBldMsg() Failed, encode message failed");
#endif
      RETVALUE(RFAILED);
   }
   *mBuf = tBuf;
   RETVALUE(ROK);
} /* end of siBldMsg */

  
/*
*
*       Fun:   siBldPsalngMsg
*
*       Desc:  build Passalong message
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siBldPsalngMsg
(
SiNSAPCb *cb,                   /* network layer control block */
Cic cic,
SiPduHdr *hdr,
SiAllPdus *msg,
Region region,
Pool pool,
Buffer **mBuf,
Swtch swtch,
Buffer *uBuf
)
#else
PUBLIC S16 siBldPsalngMsg(cb, cic, hdr, msg, region, pool, mBuf,
                          swtch, uBuf)
SiNSAPCb *cb;                   /* data link control block */
Cic cic;
SiPduHdr *hdr;
SiAllPdus *msg;
Region region;
Pool pool;
Buffer **mBuf;
Swtch swtch;
Buffer *uBuf;
#endif
{
   Buffer *tBuf;
   S16 ret;
   Bool valFlg;
   Data byte1;
   Data byte2;

   TRC2(siBldPsalngMsg)
   UNUSED(uBuf);

   *mBuf = 0;

   ret = SGetMsg(region, pool, &tBuf);
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "     SGetMsg   failed   \n"));  
      RETVALUE(RFAILED);
   } 

   if (cb->mfMsgCtl.msgIdx == MI_FACREJ)
      valFlg = FALSE;
   else
      valFlg = TRUE;

   /* insert cic into message */
   byte1 = (U8) GetLoByte(cic);
   ret = SAddPstMsg(byte1, tBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SAddPstMsg   failed   \n"));  
      /* return tBuf */
      siDropMsg(tBuf);
      SILOGERROR(ERRCLS_ADD_RES, ESI581, (ErrVal) ret,
                 "SAddPstMsg failed in siBldPsalngMsg");
      RETVALUE(RFAILED);
   }
#endif
   byte2 = (U8) GetHiByte(cic);
   ret = SAddPstMsg(byte2, tBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SAddPstMsg   failed   \n"));  
      /* return tBuf */
      siDropMsg(tBuf);
      SILOGERROR(ERRCLS_ADD_RES, ESI582, (ErrVal) ret,
                 "SAddPstMsg failed in siBldPsalngMsg");
      RETVALUE(RFAILED);
   }
#endif
   /* insert Passalong message type */
   ret = SAddPstMsg((Data) M_PASSALNG, tBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SAddPstMsg   failed   \n"));  
      /* return tBuf */
      siDropMsg(tBuf);
      SILOGERROR(ERRCLS_ADD_RES, ESI583, (ErrVal) ret,
                 "SAddPstMsg failed in siBldMsg");
      RETVALUE(RFAILED);
   }
#endif

   MFENCPDUHDR(&cb->mfMsgCtl, ret, tBuf, (ElmtHdr *) hdr, &siPduHdrMsgDef[0], 
               valFlg, TRUE, swtch, MF_ISUP);
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MFENCPDUHDR Failed\n"));  
        
#ifdef DBG4
      siMfPrntErr(&cb->mfMsgCtl);
#endif
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI584, (ErrVal) 0, 
                 "siBldPsalngMsg() , encode message header failed");
#endif
      RETVALUE(RFAILED);
   }

   MFENCPDU(&cb->mfMsgCtl, ret, (ElmtHdr *) msg);
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MFENCPDU Failed\n"));  
        
#ifdef DBG4
      siMfPrntErr(&cb->mfMsgCtl);
#endif
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI585, (ErrVal) 0, 
                 "siBldPsalngMsg() , encode message failed");
#endif
      RETVALUE(RFAILED);
   }
   *mBuf = tBuf;
   RETVALUE(ROK);
} /* end of siBldPsalngMsg */


/*
*
*       Fun:   siGenPslg
*
*       Desc:  Generates Passalong Message
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenPslg
(
SiCirCb *cir,
SiCon *con,
Buffer *mBuf
)
#else
PUBLIC S16 siGenPslg(cir, con, mBuf)
SiCirCb *cir;
SiCon *con;
Buffer *mBuf;
#endif
{
   SiCirCb *tmpCir;
   Data byte1;
   Data byte2;
   Buffer *tBuf;
   S16 ret;
   U8 data;
   U8 dataValid;

   TRC2(siGenPslg)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   if (cir->cfg.cirId == con->incC.cir->cfg.cirId)
      tmpCir = con->outC.cir;
   else
      tmpCir = con->incC.cir;
   dataValid = 1;
   /* store the message type in the PAM */
   if( (SExamMsg(&data, mBuf, 1)  != ROK ))
      dataValid = 0;

   ret = SGetMsg(con->mCallCb->pst.region, con->mCallCb->pst.pool, &tBuf);
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "     SGetMsg   failed   \n"));  
      RETVALUE(RFAILED);
   } 

   /* insert cic into message */
   byte1 = (U8) GetLoByte(tmpCir->cfg.cic);
   ret = SAddPstMsg(byte1, tBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SAddPstMsg   failed   \n"));  
      /* return tBuf */
      siDropMsg(tBuf);
      SILOGERROR(ERRCLS_ADD_RES, ESI586, (ErrVal) ret,
                 "SAddPstMsg failed in siGenPslg");
      RETVALUE(RFAILED);
   }
#endif
   byte2 = (U8) GetHiByte(tmpCir->cfg.cic);
   ret = SAddPstMsg(byte2, tBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SAddPstMsg   failed   \n"));  
      /* return tBuf */
      siDropMsg(tBuf);
      SILOGERROR(ERRCLS_ADD_RES, ESI587, (ErrVal) ret,
                 "SAddPstMsg failed in siGenPslg");
      RETVALUE(RFAILED);
   }
#endif

   ret = SCatMsg(tBuf, mBuf, M1M2);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SCatMsg   failed   \n"));  
      /* return tBuf */
      siDropMsg(tBuf);
      /* si013.220, Deletion: Removed deallcation of mBuf as it going
                              to be deallocated in the calling function */
      SILOGERROR(ERRCLS_DEBUG, ESI588, (ErrVal) ret,
                 "SCatMsg failed in siGenPslg");
      RETVALUE(RFAILED);
   }
#endif

   /* send message */
   if( dataValid == 0 )
      siSndMsg(con->mCallCb, tBuf, tmpCir->opc, tmpCir->cfg.intfId, 
            tmpCir->phyDpc, TRUE, con->lnkSel, FALSE, PRI_ZERO, 
            cir->pIntfCb->cfg.swtch);
   else
      siSndMsg(con->mCallCb, tBuf, tmpCir->opc, tmpCir->cfg.intfId, 
            tmpCir->phyDpc, TRUE, con->lnkSel, FALSE, 
               siGetPriority(data, cir->pIntfCb->cfg.swtch), 
               cir->pIntfCb->cfg.swtch);

   siDropMsg(mBuf);
   RETVALUE(ROK);
} /* end of siGenPslg */


/*
*
*       Fun:   siGetCon
*
*       Desc:  Allocate and initialize an ISUP connection control block
*              
*       Ret:   Pointer to SiCon - success; NULLP - failure
*
*       Notes: none
*
*       File:  ci_bdy5.c
*
*/
#ifdef ANSI
PRIVATE SiCon *siGetCon 
(
Void
)
#else
PRIVATE SiCon *siGetCon (Void)
#endif
{
   SiCon *con;
   S16    ret;

   TRC2(siGetCon)

   ret = SGetSBuf(siCb.init.region, siCb.init.pool, (Data **) &con,
                  (Size) sizeof(SiCon));
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf, "   SGetSBuf   failed   \n"));  
      SILOGERROR(ERRCLS_ADD_RES, ESI589, (ErrVal) ret, 
                  "siGetCon() Failed, SGetSBuf failed");
      RETVALUE(NULLP);
   }

   /* Assign NULLP to the prev and next
    * pointers after connection control block is allocated.
    */
#ifdef SI_CMHASH_CHK
   /* next and prev pointers are initialised to NULLP when block is allocated.
    * Before deallocating the memory of the block these pointers should be
    * NULLP. If not then it may be because of a connection control block
    * getting deallocated without being released from the hashlist.
    * The release call function takes care of this by removing it from the
    * hashlist.
   */
   con->hl.list.next = NULLP;
   con->hl.list.prev = NULLP;
#endif /* SI_CMHASH_CHK */

   con->key.k1.spInstId    = 0;
   con->suInstId           = 0;
   con->lnkSel             = 0;
   con->calDura            = 0;
#ifdef SI_ACNT
   con->charge             = FALSE;
#endif
   con->exchCalRef         = FALSE;
   con->end2end            = FALSE;
   con->useSCCP            = FALSE;
   con->sccpUsed           = FALSE;
   con->resDir             = 0;
#ifdef SI_INIT_TOXA
   /* type A without broad-narrowband interworking */
   con->xchgType            = TOXA;
#else
#ifdef SI_INIT_TOXA_BRNBAND
   /* type A with broad-narrowband interworking */
   con->xchgType           = TOXA_BRNBAND;
#else
   /* type B by default */
   con->xchgType           = TOXB;
#endif /* SI_INIT_TOXA_BRNBAND */
#endif /* SI_INIT_TOXA */
   con->evntType           = 0;
/* si029.220: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
   con->callTRef.tRefUsed  = FALSE;
#endif
#ifdef IW
   con->conEvt             = NULLP;
   con->contPrcs           = FALSE;
   con->contCrm            = 0;
#endif
#ifdef IW_COT_NEW
   con->cid                = CC_RESVD_CALL_CNTRL_ID;
#endif
   con->pduSp              = NULLP;
   con->sduSp              = NULLP;
#if SI_ACNT
   con->dstAdr.length      = 0;
   con->srcAdr.length      = 0;
#endif

   con->incC.cirId         = 0;
   con->incC.phyDpc           = 0;
/* si003.220 - Modification. Modified code to avoid uninitialized variable
 * reference.
 */
   con->incC.conState = ST_IDLE;
   con->incC.eventType     = 0;
   con->incC.suspDir       = 0;
   con->incC.dCallRef      = 0;
   con->incC.conPrcs       = FALSE;
   con->incC.toBeRelsd     = FALSE;
   con->incC.cllModProc    = FALSE;
   con->incC.relResp       = FALSE;
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   con->incC.numMulRateCkts = 1;
   con->incC.mulRateConFlg = SI_SINGLE;
   con->incC.mulReset = FALSE;
#endif
   con->incC.cir           = NULLP;
   con->incC.rel           = NULLP;
   con->incC.msgToSegm     = NULLP;

   con->outC.cirId         = 0;
   con->outC.phyDpc           = 0;
/* si003.220 - Modification. Modified code to avoid uninitialized variable
 * reference.
 */
   con->outC.conState = ST_IDLE;
   con->outC.eventType     = 0;
   con->outC.suspDir       = 0;
   con->outC.dCallRef      = 0;
   con->outC.conPrcs       = FALSE;
   con->outC.toBeRelsd     = FALSE;
   con->outC.cllModProc    = FALSE;
   con->outC.relResp       = FALSE;
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   con->outC.numMulRateCkts = 1;
   con->outC.mulRateConFlg = SI_SINGLE;
   con->outC.mulReset = FALSE;
#endif
   con->outC.cir           = NULLP;
   con->outC.rel           = NULLP;
   con->outC.msgToSegm     = NULLP;


   /* init timer structure */
   cmInitTimers(con->timers, MAXSIMTIMER);

   RETVALUE(con);
}


/*
*
*       Fun:   siGetIncCon
*
*       Desc:  Get an incoming connection control block
*              
*       Ret:   Pointer to SiCon - success; NULLP - failure;
*
*       Notes: none
*
*       File:  ci_bdy5.c
*
*/
#ifdef ANSI
PUBLIC SiCon *siGetIncCon
(
SiCirCb  *cir,
SiNSAPCb *cb
)
#else
PUBLIC SiCon *siGetIncCon (cir, cb)
SiCirCb  *cir;
SiNSAPCb *cb;
#endif
{
   SiCon *con;

   TRC2(siGetIncCon)

   if (cir->siCon != NULLP)
      RETVALUE(cir->siCon);
   else
   {
      if ((con = siGetCon()) != NULLP)
      {
         cir->siCon      = con;
         con->tCallCb    = NULLP;
         con->sCallCb    = NULLP;
         con->mCallCb    = cb;
         con->incC.cir   = cir;
         con->incC.cirId = cir->key.k1.cirId;
         con->incC.conPrcs = TRUE;
      }
   }

   RETVALUE(con);
}


/*
*
*       Fun:   siGetOutCon
*
*       Desc:  Get an ougoing connection control block
*              
*       Ret:   Pointer to SiCon - success; NULLP - failure
*
*       Notes: none
*
*       File:  ci_bdy5.c
*
*/
#ifdef ANSI
PUBLIC SiCon *siGetOutCon
(
SiCirCb  *cir,
SiUpSAPCb *cb
)
#else
PUBLIC SiCon *siGetOutCon (cir, cb)
SiCirCb  *cir;
SiUpSAPCb *cb;
#endif
{
   SiCon *con;

   TRC2(siGetOutCon)

   if (cir->siCon != NULLP)
      RETVALUE(cir->siCon);
   else
   {
      if ((con = siGetCon()) != NULLP)
      { 
         cir->siCon      = con;
         con->tCallCb    = cb;
         con->sCallCb    = NULLP;
         con->mCallCb    = NULLP;
         con->outC.cir   = cir;
         con->outC.cirId = cir->key.k1.cirId;
         con->outC.conPrcs = TRUE;
      }
   }

   RETVALUE(con);
}

/*
*
*       Fun:   siGetCirGr
*
*       Desc:  get pointer to a circuit group control block
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC SiCirGrp *siGetCirGr
(
SiCirCb *cir
)
#else
PUBLIC SiCirGrp *siGetCirGr(cir)
SiCirCb *cir;
#endif
{
   S16 ret;
   SiCirGrp *cirGrp;

   TRC2(siGetCirGr)

   ret = SGetSBuf(siCb.init.region, siCb.init.pool, 
         (Data **) &cirGrp, (Size) sizeof(SiCirGrp));
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "   SGetSBuf   failed   \n"));  
      SILOGERROR(ERRCLS_ADD_RES, ESI590, (ErrVal) ret, 
                 "siGetCirGr() Failed, SGetSMem failed");
      RETVALUE(NULLP);
   }

   cmMemset((U8 *)&cirGrp->rangStat, (U8) NOTPRSNT, sizeof(SiRangStat));
   cmMemset((U8 *)&cirGrp->cirSte, (U8) 0, sizeof(SiCirStateInd));
   cirGrp->firstRevdStat.pres = NOTPRSNT;
   cirGrp->pduSp       = NULLP;
   cirGrp->sduSp       = NULLP;
   cirGrp->cirState    = 0;
   cirGrp->querRange   = 0;
 
   cirGrp->cgsmti.eh.pres = NOTPRSNT;
   cirGrp->cgsmti.typeInd.pres = NOTPRSNT;
   cirGrp->state = SICG_ST_IDLE;
   cirGrp->tmrCnt = 0;
   /* init timer structure */
   cmInitTimers(cirGrp->timers, MAXSIMTIMER);
   cirGrp->querPrcs = FALSE;

   cirGrp->cir = cir;

   RETVALUE(cirGrp);
} /* end of siGetCirGr */

  
/*
*
*       Fun:   siGetInstId
*
*       Desc:  Allocates instance id
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGetInstId
(
SiInstId *ref               /* pointer to call reference */
)
#else
PUBLIC S16 siGetInstId(ref)
SiInstId *ref;              /* pointer to call reference */
#endif
{
   SiCon *entry;
   U32 i;

   TRC2(siGetInstId)

   *ref = siCb.lastSpInstId + 1;

   if ((siCb.nmbRunCalls + 1) > siCb.genCfg.nmbCalRef)
      RETVALUE(RFAILED);

   for (i=1; i<= SI_MAX_ALLOWED_SPINSTID; i++)
   {
      if(*ref > SI_MAX_ALLOWED_SPINSTID)
         *ref = 1;

      siFindInst(&siCb.conHlCp, &entry, (SiInstKey *) ref);
      if (entry == NULLP)
      {
         siCb.lastSpInstId = *ref;
         /* si014.220, Deleted: Removed code that incremented the number
                                of running calls */
         RETVALUE(ROK);
      }   
      (*ref)++;
   }

   RETVALUE(RFAILED);
} /* end of siGetInstId */


/*
*
*       Fun:   siGetLwrMCbPtr
*
*       Desc:  Gets pointer to MTP Sap Control Block
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC SiNSAPCb *siGetLwrMCbPtr
(
SiCirCb   *cir
)
#else
PUBLIC SiNSAPCb *siGetLwrMCbPtr(cir)
SiCirCb   *cir;
#endif
{
/* si003.220 - Addition. Added local variable.
 */
   SpId   sapId;
   TRC2(siGetLwrMCbPtr)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (cir->pIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "Interface control block pointer missing\n"));

      SILOGERROR(ERRCLS_DEBUG, ESI591, (ErrVal) 0, 
         "siGetLwrMCbPtr() Failed, Interface control block pointer missing");
      RETVALUE(ROK);
   }
#endif
/* si003.220 - Modification. Modified code to always check MTP3 SAP Id.
 */
   sapId = cir->pIntfCb->msapId;
   RETVALUE(((sapId >= (SuId)siCb.genCfg.nmbNSaps) || (sapId < 0)) ?
            (SiNSAPCb *)NULLP : *(siCb.mtpSAPLst + sapId));

} /* end of siGetLwrMCbPtr */


/*
*
*       Fun:   siGetLwrSCbPtr
*
*       Desc:  Gets pointer to SCCP Sap Control Block
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC SiNSAPCb *siGetLwrSCbPtr
(
SiCirCb   *cir
)
#else
PUBLIC SiNSAPCb *siGetLwrSCbPtr(cir)
SiCirCb   *cir;
#endif
{
/* si003.220 - Addition. Added local varialbe.
 */
   SpId   sapId;

   TRC2(siGetLwrSCbPtr)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (cir->pIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "Interface control block pointer missing\n"));

      SILOGERROR(ERRCLS_DEBUG, ESI592, (ErrVal) 0, 
         "siGetLwrSCbPtr() Failed, Interface control block pointer missing");
      RETVALUE(ROK);
   }
#endif
/* si003.220 - Modification. Modified code to always check SCCP SAP Id.
 */
   sapId = cir->pIntfCb->ssapId;
   RETVALUE((((sapId >= (SuId)siCb.genCfg.nmbNSaps) || (sapId < 0)) ?
            (SiNSAPCb *)NULLP : *(siCb.sccpSAPLst + sapId)));

} /* end of siGetLwrSCbPtr */

  
/*
*
*       Fun:   siGetMCbPtr
*
*       Desc:  Gets pointer to MTP Sap Control Block
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC SiNSAPCb *siGetMCbPtr
(
SiInstId nwId,
U8    ssf
)
#else
PUBLIC SiNSAPCb *siGetMCbPtr(nwId, ssf)
SiInstId nwId;
U8    ssf;
#endif
{
   S16 i;
   SiNSAPCb *entry;

   TRC2(siGetMCbPtr)

   entry = NULLP;

   for (i = 0; i < siCb.genCfg.nmbNSaps; i++)
   {
      entry = SIMTPSAP(i);
      if ((entry != NULLP) && (entry->cfg.nwId == nwId)
               && (SICMPNT(entry->cfg.ssf, ssf)) )
         break;
   }
   if( i==siCb.genCfg.nmbNSaps )
   {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "GetMCbptr: can not find MTPblock for nwId %lx and ssf %d\n",
                       nwId, ssf)); 
   }
#if (ERRCLASS & ERRCLS_DEBUG)
   if (i == siCb.genCfg.nmbNSaps)
   {
      SILOGERROR(ERRCLS_DEBUG, ESI593, (ErrVal) 0, 
                 "siGetMCbPtr() Failed, invalid network Id and ssf");
      RETVALUE(NULLP);
   }
#endif
   RETVALUE(entry);
} /* end of siGetMCbPtr */

  
/*
*
*       Fun:   siGetSCbPtr
*
*       Desc:  Gets pointer to SCCP Sap Control Block
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC SiNSAPCb *siGetSCbPtr
(
SiInstId nwId,
U8    ssf
)
#else
PUBLIC SiNSAPCb *siGetSCbPtr(nwId, ssf)
SiInstId nwId;
U8    ssf;
#endif
{
   S16 i;
   SiNSAPCb *entry;

   TRC2(siGetSCbPtr)

   entry = NULLP;

   for (i = 0; i < siCb.genCfg.nmbNSaps; i++)
   {
      entry = SISCCPSAP(i);
      if ((entry != NULLP) && (entry->cfg.nwId == nwId)
                  && (SICMPNT(entry->cfg.ssf, ssf)))
         break;
   }

   if (i == siCb.genCfg.nmbNSaps)
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "can not get SCbPtr for nwId %lx\n", nwId));  
      RETVALUE(NULLP);
   }

   RETVALUE(entry);
} /* end of siGetSCbPtr */

/*
*
*       Fun:   siGetUprCbPtr
*
*       Desc:  Gets pointer to Upper Sap Control Block
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC SiUpSAPCb *siGetUprCbPtr
(
SiCirCb *cir
)
#else
PUBLIC SiUpSAPCb *siGetUprCbPtr(cir)
SiCirCb *cir;
#endif
{

   TRC2(siGetUprCbPtr)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (cir->pIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "Interface control block pointer missing\n"));

      SILOGERROR(ERRCLS_DEBUG, ESI594, (ErrVal) 0, 
         "siGetUprbPtr() Failed, Interface control block pointer missing");
      RETVALUE(ROK);
   }
#endif

   RETVALUE(SIUPSAP(cir->pIntfCb->cfg.sapId));

} /* end of siGetUprCbPtr */

  
/*
*
*       Fun:   siGetCbPtr
*
*       Desc:  Gets pointer to Upper Sap Control Block
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC SiUpSAPCb *siGetCbPtr
(
Swtch swtch,
U8    ssf      /* subsytem information */
)
#else
PUBLIC SiUpSAPCb *siGetCbPtr(swtch, ssf)
Swtch swtch;
U8    ssf;     /* subsystem service information */
#endif
{
   SpId spId;
   SiUpSAPCb *entry;

   TRC2(siGetCbPtr)
  
   entry = NULLP;

   for (spId = 0; spId < (SpId)siCb.genCfg.nmbSaps; spId++)
   {
      entry = SIUPSAP(spId);
      if ((entry != NULLP) && (entry->cfg.swtch == swtch)
                  && (SICMPNT(entry->cfg.ssf, ssf)))
         break;
   }
#if (ERRCLASS & ERRCLS_DEBUG)
   if (spId == siCb.genCfg.nmbSaps)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "can not find CbPtr for swtch %d ssf: %d\n", swtch, ssf));  
      SILOGERROR(ERRCLS_DEBUG, ESI595, (ErrVal) 0, 
                 "siGetCbPtr() Failed, invalid switch");
      RETVALUE(NULLP);
   }
#endif
   RETVALUE(entry);
} /* end of siGetCbPtr */





/*
*
*       Fun:   siChkDimMsg
*
*       Desc:  checks if PDU size is critical: if so, tries 
*              to reduce it removing some optional parameter 
*              from the message itself
*
*       Ret:   ROK      - ok
*              RFAILED  - nok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siChkDimMsg
(
SiNSAPCb *cb,
Buffer   **mBuf,        /* PDU to be checked */
U16      length,      /* PDU size */
U16      maxLength    /* PDU max size */
)
#else
PRIVATE S16 siChkDimMsg(cb, mBuf, length, maxLength)
SiNSAPCb *cb;
Buffer   **mBuf;        /* PDU to be checked */
U16      length;      /* PDU size */
U16      maxLength;   /* PDU max size */
#endif
{
   U16     i;
   MsgLen     len;
   S16            ret;
   Buffer *tempBuf;
   U8      parTyp;
   U8      lenPar;
   Data    c;
   Data    stuff[MAX_SIMTP2_LEN];
   
   TRC3(siChkDimMsg)

   if (length > (U16) maxLength)
   {
      for (i = (U16) 0; i < length; )
      {
 
         ret = SExamMsg(&parTyp, *mBuf, (MsgLen) i);
         if (ret != ROK)
         {  
            RETVALUE(ret);
         } 
 
 
         /* extracts parameter length ------------------- */
         ret = SExamMsg(&c, *mBuf, (MsgLen) (i + 1));
         if (ret != ROK)
            RETVALUE(ret);

         lenPar =  c;
         /* parameter length extracted ------------------- */
 

         switch (cb->mfMsgCtl.swtch)
         {
            case LSI_SW_ITU:
#ifdef SS7_ITU97
            case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
           case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
           case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
            case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
               if (parTyp != ME_USR2USRINFO)
               {
                  i += (lenPar + 2);
                  continue;
               }         
               break;
            default:
               RETVALUE(RFAILED);
         }


         /* Segments the message */
         if ((ret = SSegMsg(*mBuf, i, &tempBuf)) != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SSegMsg   failed   \n"));  
            SPutMsg(tempBuf);
            RETVALUE(ret);
         }
 
         /* Removes from the second piece the data in front... */
         ret = SRemPreMsgMult(&stuff[0], lenPar, tempBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
         if (ret != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SRemPreMsgMult   failed   \n"));  
            SPutMsg(tempBuf);
            SILOGERROR(ERRCLS_DEBUG, ESI596, (ErrVal) ret,
                       "siChkDimMsg: SRemPreMsgMult failed");
            RETVALUE(ret);
         }
#endif
 
         /* attaches the remaining portion of the second
            msg to the original one*/
         ret = SCatMsg(*mBuf, tempBuf, M1M2);
#if (ERRCLASS & ERRCLS_DEBUG)
         if (ret != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SCatMsg   failed   \n"));  
            SPutMsg(tempBuf);
            SILOGERROR(ERRCLS_DEBUG, ESI597, (ErrVal) ret,
                       "siChkDimMsg: SCatMsg failed");
            RETVALUE(ret);
         }
#endif
 
         SPutMsg(tempBuf);

         /* Checks if the segmented message is now with
            correct size: if so, the segmentation done
            is sufficient: exits */

         ret = SFndLenMsg(*mBuf,  &len);
#if (ERRCLASS & ERRCLS_DEBUG)
         if (ret != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SFndLenMsg   failed   \n"));  
            SILOGERROR(ERRCLS_DEBUG, ESI598, (ErrVal) ret,
                       "siChkDimMsg: SFndLenMsg failed");
            RETVALUE(ret);
         }
#endif
     
         if (len < (U16) maxLength)
            break;
      }

      if (len > (U16) maxLength)
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of siChkDimMsg */


/*
*
*       Fun:   siSegmMsg
*
*       Desc:  segments pdu XXX (XXX -> XXX' + SGM), where XXX in
*              {IAM, ACM, CPG, ANM, CON}
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siSegmMsg
(
U8       msgType,  /* message type */
SiNSAPCb *cb,
Buffer   *mBuf,     /* PDU to be segmented */
Buffer   **segmBuf,  /* SGM PDU */
Swtch    swtch      /* Variant */
)
#else
PRIVATE S16 siSegmMsg(msgType, cb, mBuf, segmBuf, swtch)
U8       msgType;  /* message type */
SiNSAPCb *cb;
Buffer   *mBuf;     /* PDU to be segmented */
Buffer   **segmBuf; /* SGM PDU */
Swtch    swtch;     /* variant */
#endif
{
   CONSTANT SiMsgElmtDef *CONSTANT *meElmntList;
   CONSTANT SiMsgElmtDef   *meElmntDef;
   MsgLen            length;
   U16            length2;
   U16            i;
   U16            lenPar;
   S16            ret;
   U8             noOfItems;
   S16            j;
   U8             k;
   U8             parTyp;
   Data           c;
   Bool           found;
   struct 
   {
      U16  parTyp;
      U16  index;
      U16  length;
   }              item [SGM_MAX_NO_OF_IES]; 
   Buffer        *tempBuf;
   Buffer        *tempBuf2;
   Data           stuff[MAX_SIMTP2_LEN];
   U16      maxSizMsg;  /* Takes different values for ANSI and rest */
   U8             startOp;          /* starting postion of optional param */

   TRC3(siSegmMsg)
 
   switch (swtch)
   {

      default:
         maxSizMsg = MAX_SIMTP2_LEN;
         break;
   }
   length    = 0;
   length2   = 0;
   j         = 0;
   startOp   = 0;
   found     = FALSE;
   noOfItems = SGM_MAX_NO_OF_IES;

   for (i = 0; i < noOfItems; i++)
   {
      item[i].parTyp = 0;
      item[i].index = 0;
      item[i].length = 0;
   }

   /* extracts message length */
#ifdef DBG5
   if (siCb.init.dbgMask & SIDBGMASK_MSGSEG)
   {
       SPrntMsg(mBuf, 0, 0);
   }
#endif
   ret = SFndLenMsg(mBuf, &length);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SFndLenMsg   failed   \n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI599, (ErrVal) ret,
                 "SFndLenMsg() Failed, siSegmMsg");
      RETVALUE(ROK);
   }
#endif

   switch(msgType)
   {
      case M_INIADDR:
         k = 9;
         break;
      case M_ADDCOMP:
         k = 5;
         break;
      case M_ANSWER:
         k = 3;
         break;
      case M_CALLPROG:
         k = 4;
         break;
      case M_CONNCT:
         k = 5;
         break;
      default:
       /* this is a message not segmentable: discards it */
       RETVALUE(RFAILED);
   }

   ret = SExamMsg(&startOp, mBuf, (MsgLen) k);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SExamMsg   failed   \n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI600, (ErrVal) ret,
                 "siSegmMsg: SExamMsg failed");
      RETVALUE(ret);
   }
#endif
   startOp += k;
 
   /* now j points to the optional part */


   /* OUTER LOOP scans the input message -------------------- */
   for (i = (U16) startOp, j = 0; i < length; ) 
   {
 
      ret = SExamMsg(&parTyp, mBuf, (MsgLen) i);
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SExamMsg   failed   \n"));  
         SILOGERROR(ERRCLS_DEBUG, ESI601, (ErrVal) ret,
                    "siSegmMsg: SExamMsg failed");
         RETVALUE(ret);
      }
#endif
 
      if (parTyp == ME_ENDOP)
         break;
 
      /* extracts parameter length -------------------------- */
      ret = SExamMsg(&c, mBuf, (MsgLen) (i + 1));
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SExamMsg   failed   \n"));  
         SILOGERROR(ERRCLS_DEBUG, ESI602, (ErrVal) ret,
                    "siSegmMsg: SExamMsg failed");
         RETVALUE(ret);
      }
#endif
      lenPar = (U16) c;
      /* parameter length extracted -------------------------- */
 



      /* If present, sets in Optional Backward/Forward
         Call Indicator parameter, the Simple Segmentation
         Indicator to: "additional information..." */
      if ((parTyp == ME_OPBACKCALLIND) || 
          (parTyp == ME_OPFWDCALLIND))
      {
         ret = SExamMsg(&c, mBuf, (MsgLen) (i + 2));
#if (ERRCLASS & ERRCLS_DEBUG)
         if (ret != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SExamMsg   failed   \n"));  
            SILOGERROR(ERRCLS_DEBUG, ESI603, (ErrVal) ret,
                       "siSegmMsg: SExamMsg failed");
            RETVALUE(ret);
         }
#endif
         c |= 0x04;
         ret = SRepMsg(c, mBuf, (MsgLen) (i + 2));
#if (ERRCLASS & ERRCLS_DEBUG)
         if (ret != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SRepMsg   failed   \n"));  
            SILOGERROR(ERRCLS_DEBUG, ESI604, (ErrVal) ret,
                       "siSegmMsg: SExamMsg failed");
            RETVALUE(ret);
         }
#endif
         found = TRUE;
      }

      /* get the address of the Segmentation message 
         element pointer list */
      meElmntList = &siSegmentMsgDef[0];

      /* INNER LOOP scans the SGM message element pointer list */
      /* skips the message compatibility parameter */
      meElmntList++;
      while (*meElmntList != NULLP)
      {
         meElmntDef = (CONSTANT SiMsgElmtDef *CONSTANT) *meElmntList;
         /* if message compatibility parameter: skips */
         if (meElmntDef->id == (U16) ME_MSGCOMP)
         {
            meElmntList++;
            continue;
         }


         if ((U16) parTyp == meElmntDef->id)
         {
            /* found one parameter that could be moved from 
               input msg to SGM: marks it */
            item[j].parTyp = parTyp;
            item[j].index  = i;
            item[j].length = (lenPar + 2);
            j++;
            /* examines the next parameter in SGM parameter list */
            break;
         }            /* end "if (parTyp == meElmntDef->id)" */

         meElmntList++;
      }               /* end inner loop */
      i += (lenPar + 2);
   }                  /* end outer loop */
   


   /* Segments --------------------------------------------------- */

   if ((ret = SGetMsg(cb->pst.region, cb->pst.pool, &tempBuf))!=ROK)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "     SGetMsg   failed   \n"));  
      RETVALUE (ret);
   } 

   /* Now examines the input message scanning it from the tail to 
      the head, using the indecies previously saved */
/* si003.220 : Addition. Added code so that item[j] will be within the range.
 * This is for removing compiler warning.
 */
   if (j >= SGM_MAX_NO_OF_IES)
      RETVALUE(RFAILED);
   for ( j -= 1; j >= 0; --j)
   {
      if ((i = item[j].index) == 0)
         continue;

      /* Segments the message */
      if ((ret = SSegMsg(mBuf, i, &tempBuf2)) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SSegMsg   failed   \n"));  
         SPutMsg(tempBuf);
         RETVALUE(ret);
      }

      /* Removes from the second piece the data in front... */
      ret = SRemPreMsgMult(&stuff[0], item[j].length, tempBuf2);
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SRemPreMsgMult   failed   \n"));  
         SPutMsg(tempBuf);
         SPutMsg(tempBuf2);
         SILOGERROR(ERRCLS_DEBUG, ESI605, (ErrVal) ret,
                    "siSegmMsg: SRemPreMsgMult failed");
         RETVALUE(ret);
      }
#endif

      /* ...and places it at the end of the segm. message 
         under construction */
      ret = SAddPstMsgMult(&stuff[0], item[j].length, tempBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SAddPstMsgMult   failed   \n"));  
         SPutMsg(tempBuf);
         SPutMsg(tempBuf2);
         SILOGERROR(ERRCLS_ADD_RES, ESI606, (ErrVal) ret,
                    "SAddPstMsg failed in siSegmMsg");
         RETVALUE(ret);
      }
#endif

      /* attaches the remaining portion of the second 
         msg to the original one*/
      ret = SCatMsg(mBuf, tempBuf2, M1M2);
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SCatMsg   failed   \n"));  
         SPutMsg(tempBuf);
         SPutMsg(tempBuf2);
         SILOGERROR(ERRCLS_DEBUG, ESI607, (ErrVal) ret,
                    "siSegmMsg: SCatMsg failed");
         RETVALUE(ret);
      }
#endif

      SPutMsg(tempBuf2);

      /* Checks if the original message is now with 
         correct size: if so, the segmentation done 
         is sufficient: exits; takes into account the 
         Segmentation Indicator that must be added */
      ret = SFndLenMsg(mBuf,  &length);
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SFndLenMsg   failed   \n"));  
         SPutMsg(tempBuf);
         SILOGERROR(ERRCLS_DEBUG, ESI608, (ErrVal) ret,
                    "siSegmMsg: SFndLenMsg failed");
         RETVALUE(ret);
      }
#endif

      /* Updates the SGM message length */
      length2 += item[j].length;

      if ((found && (length < (U16)(maxSizMsg - k + 1))) ||
          ((!found) && (length < (U16)(maxSizMsg - k - 2))))
         break;
   } /* end of segmenting loop ------------------------- */



   /* If after segmenting the message, its size is
      yet critical: returns KO ------------------------- */
   if (j == 0)
   {
      ret = siChkDimMsg(cb, &mBuf, length, 
                        (U16 )(found ? (maxSizMsg - k + 1) :
                                 (maxSizMsg - k - 2)));
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   siChkDimMsg   failed   \n"));  
         SPutMsg(tempBuf);
         SILOGERROR(ERRCLS_DEBUG, ESI609, (ErrVal) ret,
                    "siSegmMsg: siChkDimMsg failed");
         RETVALUE(ret);
      }
#endif
   }
 


   /* If segmentation message size is yet critical 
      then removes stuff ------------------------------- */

   ret = siChkDimMsg(cb, &tempBuf, length2, (U16 )(maxSizMsg - 8));
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   siChkDimMsg   failed   \n"));  
      SPutMsg(tempBuf);
      SILOGERROR(ERRCLS_DEBUG, ESI610, (ErrVal) ret,
                 "siSegmMsg: siChkDimMsg failed");
      RETVALUE(ret);
   }
#endif


   /* if Forward/Backward Call Indicator weren't
      present in the original message... */
   if (!found)
   {
      /* ...then prepares Segmentation Indicator 
         set to "additional information..."... */

      if (msgType != M_INIADDR)
         stuff [0] = ME_OPBACKCALLIND;
      else
         stuff [0] = ME_OPFWDCALLIND;

      stuff [1] = 0x01;
      stuff [2] = 0x04;
      stuff [3] = 0x00;        /* end of optional parameter */

 
      /* remove the original end of optional parameter */
      ret = SRemPstMsg(&c, mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SRemPstMsg   failed   \n"));  
         SPutMsg(tempBuf);
         SILOGERROR(ERRCLS_ADD_RES, ESI611, (ErrVal) ret,
                    "SRemPstMsg failed in siSegmMsg");
         RETVALUE(ret);
      }
#endif

      /* ...and places it at the end of the original 
         message modified */
      ret = SAddPstMsgMult(&stuff[0], 4, mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SAddPstMsgMult   failed   \n"));  
         SPutMsg(tempBuf);
         SILOGERROR(ERRCLS_ADD_RES, ESI612, (ErrVal) ret,
                    "SAddPstMsgMult failed in siSegmMsg");
         RETVALUE(ret);
      }
#endif
   }


   /* Final operations on SGM --------------------------- */
   /* adds Message Compatibility parameter to SGM */

   stuff[0] = ME_MSGCOMP;
   stuff[1] = 0x01;
   stuff[2] = MSGCSGM;
   stuff[3] = 0x00;        /* end of optional parameter */
   ret = SAddPstMsgMult(&stuff[0], 4, tempBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SAddPstMsgMult   failed   \n"));  
      SPutMsg(tempBuf);
      SILOGERROR(ERRCLS_ADD_RES, ESI613, (ErrVal) ret,
                 "SAddPstMsg failed in siSegmMsg");
      RETVALUE(ret);
   }
#endif


   /* Prepares header for SGM (reverse order because 
      it's attached in front) */

   stuff[0] = 1;              /* pointer to optional part */
   stuff[1] = M_SEGMMSG;

   /* CIC 2nd byte */
   ret = SExamMsg(&c, mBuf, (MsgLen) 1);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SExamMsg   failed   \n"));  
      SPutMsg(tempBuf);
      SILOGERROR(ERRCLS_DEBUG, ESI614, (ErrVal) ret,
                 "siSegmMsg: SExamMsg failed");
      RETVALUE(ret);
   }
#endif
   stuff[2] = c;

   /* CIC 1st byte */
   ret = SExamMsg(&c, mBuf, (MsgLen) 0);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SExamMsg   failed   \n"));  
      SPutMsg(tempBuf);
      SILOGERROR(ERRCLS_DEBUG, ESI615, (ErrVal) ret,
                 "siSegmMsg: SExamMsg failed");
      RETVALUE(ret);
   }
#endif
   stuff[3] = c;

   ret = SAddPreMsgMult(&stuff[0], 4, tempBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SAddPreMsgMult   failed   \n"));  
      SPutMsg(tempBuf);
      SILOGERROR(ERRCLS_ADD_RES, ESI616, (ErrVal) ret,
                 "SAddPreMsg failed in siSegmMsg");
      RETVALUE(ret);
   }
#endif



   *segmBuf = tempBuf;
   RETVALUE(ROK);
}  /* siSegmMsg */


/*
*
*       Fun:   siReassblSegms
*
*       Desc:  generate pdu
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siReassblSegms
(
SiCon  *con,
CirCon *cCon,
Bool    action
)
#else
PUBLIC S16 siReassblSegms(con, cCon, action)
SiCon  *con;
CirCon *cCon;
Bool    action;
#endif
{
   SiNSAPCb  *mCb;
   SiUpSAPCb *tCb;
   SiPduHdr  hdr;
   SiAllPdus message;
   SiAllSdus ev;
   Buffer    *firstMsg;
   Buffer    *secndMsg;
   S16       ret;
   MsgLen       bufLen;
   Data      c;
   S16       j;
   U16       lenPar;
   U8        parTyp;
   Data      stuff[20];
   Buffer    *uBuf;

   TRC2(siReassblSegms)

   /* get cb with MTP 3 */
   mCb = siGetLwrMCbPtr(cCon->cir);

   /* find upper sap */
   tCb = siGetUprCbPtr (cCon->cir);

   ret = RFAILED;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (mCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "pointer to lower SAP missing \n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI617, (ErrVal) ret,
                 "siReassblSegms() Failed, lower SAP ptr missing");
      RETVALUE(RFAILED);
   }
   if (tCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "pointer to upper SAP missing \n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI618, (ErrVal) ret,
                 "siReassblSegms() Failed, upper SAP ptr missing");
      RETVALUE(RFAILED);
   }
#endif


   firstMsg = cCon->msgToSegm;   
   if (action == SEGM_MSG)
      secndMsg = mCb->mfMsgCtl.mp;
   else
      secndMsg = NULLP;

   if (action == SEGM_MSG)
   {
      /* extracts second message's length ------------ */
      ret = SFndLenMsg(secndMsg, &bufLen);
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SFndLenMsg   failed   \n"));  
         SILOGERROR(ERRCLS_DEBUG, ESI619, (ErrVal) ret,
                    "SFndLenMsg() Failed, siReassblSegms");
         RETVALUE(ROK);
      }
#endif
      /* second message's length extracted ----------- */ 

      {
         /* removes, if any, the message comp. par. from the SGM ----- */
         for (j = 2; j < bufLen; )
         {
            ret = SExamMsg(&parTyp, secndMsg, j);
#if (ERRCLASS & ERRCLS_DEBUG)
            if (ret != ROK)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SExamMsg   failed   \n"));  
               SILOGERROR(ERRCLS_DEBUG, ESI620, (ErrVal) ret,
                       "siReassblSegms: SExamMsg failed");
               RETVALUE(ret);
            }
#endif
            /* if the parameter is end-of-optionals come out of loop */
            if (parTyp == ME_ENDOP)
               break;
   
            /* extracts message element's length */
            ret = SExamMsg((Data *)&c, secndMsg, (MsgLen )(j+1));
#if (ERRCLASS & ERRCLS_DEBUG)
            if (ret != ROK)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                         "   SExamMsg   failed   \n"));  
               SILOGERROR(ERRCLS_DEBUG, ESI621, (ErrVal) ret,
                       "siReassblSegms: SExamMsg failed");
               RETVALUE(ret);
            }
#endif
            lenPar = (U16) c;

 
            if (parTyp == ME_MSGCOMP)
            {
               Buffer *tempBuf;
    
               if ((ret = SSegMsg(secndMsg, j, &tempBuf)) != ROK)
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                         "     SSegMsg   failed   \n"));  
                  RETVALUE(ret);
               } 
 
               /* Removes from the second msg the msg. comp. parameter */
               ret = SRemPreMsgMult((Data *)&stuff[0], (MsgLen )(lenPar + 2), 
                                             tempBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
               if (ret != ROK)
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SRemPreMsgMult   failed   \n"));  
                  SPutMsg(tempBuf);
                  SILOGERROR(ERRCLS_DEBUG, ESI622, (ErrVal) ret,
                          "siReassblSegms: SRemPreMsgMult failed");
                  RETVALUE(ret);
               }
#endif
 
               /* attaches the remaining portion second msg to the original one */
               ret = SCatMsg(secndMsg, tempBuf, M1M2);
#if (ERRCLASS & ERRCLS_DEBUG)
               if (ret != ROK)
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SCatMsg   failed   \n"));  
                  SPutMsg(tempBuf);
                  SILOGERROR(ERRCLS_DEBUG, ESI623, (ErrVal) ret,
                          "siReassblSegms: SCatMsg failed");
                  RETVALUE(ret);
    
               }
#endif
 
               SPutMsg(tempBuf);
               bufLen -= (lenPar + 2);
               break;
            }
            else
               /* skips n-th parameter */
               j += (lenPar + 2);
         }
      }
 

      /* removes header and optional param pointer from second message */
      ret = SRemPreMsgMult(&stuff[0], 2, secndMsg);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SRemPreMsgMult   failed   \n"));  
         SILOGERROR(ERRCLS_DEBUG, ESI624, (ErrVal) ret,
                    "siReassblSegms: SRemPreMsgMult failed");
         RETVALUE(ret);
      }
#endif

      {
         /* remove the original end of optional parameter 
            from the first message */
         ret = SRemPstMsg(&c, firstMsg);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SRemPstMsg   failed   \n"));  
            SILOGERROR(ERRCLS_ADD_RES, ESI625, (ErrVal) ret,
                    "SRemPstMsg failed in siSegmMsg");
            RETVALUE(ret);
         }
#endif
      }

      /* attaches the remaining portion of the second 
         msg to the first one */
      ret = SCatMsg(firstMsg, secndMsg, M1M2);
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SCatMsg   failed   \n"));  
         SILOGERROR(ERRCLS_DEBUG, ESI626, (ErrVal) ret,
                    "siReassblSegms: SCatMsg failed");
         RETVALUE(ret);
      }
#endif
      /*...and lets the caller function to release the 
        segment (second) message */

#ifdef DBG5
      /* print transmitted message */
   if (siCb.init.dbgMask & SIDBGMASK_MSGSEG)
   {
      if (cCon->cir)
         SPrntMsg(firstMsg, (S16) cCon->cir->opc,
               (S16) cCon->phyDpc);
   }
#endif
   }
/*si050.220 Modification Timer T36 should be stop after the INF processing */
   /* Stop T34(T36)  Timer */
   if (&(con->incC) == (cCon))
      siStopConTmr(con, TMR_T36I);
   else
      siStopConTmr(con, TMR_T36O);

   /* ******************* Decoding ******************** */
   /* decode message header */
   MFDECPDUHDR(&mCb->mfMsgCtl, ret, firstMsg, (ElmtHdr *) &hdr, 
               &siPduHdrMsgDef[0], TRUE, TRUE, tCb->cfg.swtch, 
               (U32) MF_ISUP);

   /* decode message */
   MFDECPDU(&mCb->mfMsgCtl, ret, (ElmtHdr *) &message);
   /* ************************************************* */

   if (mCb->mfMsgCtl.uBuf != NULLP)
   {
      switch (tCb->cfg.swtch)
      {
#ifdef SS7_ITU97
         case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
        case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
        case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         case LSI_SW_ITU:
           /* do parameter comaptibility checking */
           /*  Get pointer to upper control block */
           ret = siChkParmComp(mCb, cCon->cir, con, &message, FALSE);
           if (ret != ROK)
              RETVALUE(ret);
           break;
         default:
           break;
      }
   }

   if ((cCon) && (cCon->msgToSegm != NULLP))
   {
      SPutMsg(cCon->msgToSegm);
      cCon->msgToSegm = NULLP;
   }

   switch(cCon->eventType)
   {
      case MI_INIADDR:
         /* init connect event for the upper layer */
         MFINITSDU(&tCb->mfMsgCtl, ret, (U8) MI_INIADDR, (U8) SI_CONREQ, 
                   (ElmtHdr *)&message.m.initAddr, (ElmtHdr *) &ev, 
                   (U8) PRSNT_NODEF, tCb->cfg.swtch, (U32) MF_ISUP);

         switch(tCb->cfg.swtch)
         {
            default:
               break;
         }
 
         /* send connect indication to the upper layer */
         SiUiSitConInd(&tCb->pst, tCb->suId, NULLD, con->key.k1.spInstId, 
                       cCon->cirId, &ev.m.siConEvnt, tCb->mfMsgCtl.uBuf);
         break;

      case MI_ADDCOMP:
         /* initialize connect status event to upper layer */
         MFINITSDU(&tCb->mfMsgCtl, ret, (U8) MI_ADDCOMP, (U8) SI_CNSTREQ, 
                   (ElmtHdr *) &message.m.addrComp, (ElmtHdr *) &ev, 
                   (U8) PRSNT_NODEF, tCb->cfg.swtch, (U32) MF_ISUP);

         /* change state to Waiting for Answer */
         SISTATECHNG(cCon->conState, ST_WTFORANSWR);
 
         /* if answer controlling exchange */
         if (!con->incC.conPrcs)
            /* Start T9 Timer */
            siStartConTmr(TMR_T9, con, con->tCallCb);
 
         /* change circuit state to outgoing busy */
         SISTATECHNG(cCon->cir->calProcStat, OUTBUSY);

#ifdef ZI
         if (ziCb.updateOption == ZI_UPD_UNANSWRD)
         {
            ziRunTimeUpd(ZI_CON_CB, CMPFTHA_CREATE_REQ, (PTR) con);
            ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cCon->cir);
            ziUpdPeer();
         }
#endif
         /* Store uBuf in a local variable and initialize the
          * mCb->mfMsgCtl.uBuf filed to NULLP before generating
          * the primitive to upper layer to avoid accessing stale
          * pointer in case of tightly coupled upper interface.
          */
         uBuf               = mCb->mfMsgCtl.uBuf;
         mCb->mfMsgCtl.uBuf = NULLP;

         /* send connect status indication to the upper layer */
         SiUiSitCnStInd(&tCb->pst, tCb->suId, con->suInstId, 
                        con->key.k1.spInstId, cCon->cirId, &ev.m.siCnStEvnt, 
                        ADDRCMPLT, uBuf);
         break;
 

      case MI_CALLPROG:
         /* initialize connect status event to upper layer */
         MFINITSDU(&tCb->mfMsgCtl, ret, (U8) MI_CALLPROG, (U8) SI_CNSTREQ, 
                   (ElmtHdr *) &message.m.caProg, (ElmtHdr *) &ev, 
                   (U8) PRSNT_NODEF, tCb->cfg.swtch, (U32) MF_ISUP);

         /* Store uBuf in a local variable and initialize the
          * mCb->mfMsgCtl.uBuf filed to NULLP before generating
          * the primitive to upper layer to avoid accessing stale
          * pointer in case of tightly coupled upper interface.
          */
         uBuf               = mCb->mfMsgCtl.uBuf;
         mCb->mfMsgCtl.uBuf = NULLP;

         /* send connect status indication to the upper layer */
         SiUiSitCnStInd(&tCb->pst, tCb->suId, con->suInstId, 
                        con->key.k1.spInstId, cCon->cirId, &ev.m.siCnStEvnt, 
                        PROGRESS, uBuf);
         break;

      case MI_ANSWER:
         /* init connect event for the upper layer */
         MFINITSDU(&tCb->mfMsgCtl, ret, (U8) MI_ANSWER, (U8) SI_CONREQ,
                   (ElmtHdr *)&message.m.answer, (ElmtHdr *) &ev, 
                   (U8) PRSNT_NODEF, tCb->cfg.swtch, (U32) MF_ISUP);
 
         /* change state to Answered */
         SISTATECHNG(cCon->conState, ST_ANSWRD);
         /* change circuit state to outgoing busy */
         SISTATECHNG(cCon->cir->calProcStat , OUTBUSY);

#ifdef SI_ACNT
         if (siCb.init.acnt)
            SGetSysTime(&con->calDura);
#endif

#ifdef ZI
         if (ziCb.updateOption == ZI_UPD_UNANSWRD)
            ziRunTimeUpd(ZI_CON_CB, CMPFTHA_UPD_REQ, (PTR) con);
         else
            ziRunTimeUpd(ZI_CON_CB, CMPFTHA_CREATE_REQ, (PTR) con);
         ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cCon->cir);
         ziUpdPeer(); 
#endif
         switch(tCb->cfg.swtch)
         {
            default:
               break;
         }
 
         /* Store uBuf in a local variable and initialize the
          * mCb->mfMsgCtl.uBuf filed to NULLP before generating
          * the primitive to upper layer to avoid accessing stale
          * pointer in case of tightly coupled upper interface.
          */
         uBuf               = mCb->mfMsgCtl.uBuf;
         mCb->mfMsgCtl.uBuf = NULLP;

         /* send connect confirmation to the upper layer */
         SiUiSitConCfm(&tCb->pst, tCb->suId, con->suInstId,
                       con->key.k1.spInstId, cCon->cirId, &ev.m.siConEvnt, 
                       uBuf);
         break;

      case MI_CONNCT: 
         /* init connect event for the upper layer */
         MFINITSDU(&tCb->mfMsgCtl, ret, (U8) MI_CONNCT, (U8) SI_CONREQ,
                   (ElmtHdr *)&message.m.connect, (ElmtHdr *) &ev,
                   (U8) PRSNT_NODEF, tCb->cfg.swtch, (U32) MF_ISUP);

         /* change state to Answered */
         SISTATECHNG(cCon->conState , ST_ANSWRD);
         /* change circuit state to outgoing busy */
         SISTATECHNG(cCon->cir->calProcStat , OUTBUSY);
 
#ifdef SI_ACNT
         if (siCb.init.acnt)
            SGetSysTime(&con->calDura);
#endif
         /* Store uBuf in a local variable and initialize the
          * mCb->mfMsgCtl.uBuf filed to NULLP before generating
          * the primitive to upper layer to avoid accessing stale
          * pointer in case of tightly coupled upper interface.
          */
         uBuf               = mCb->mfMsgCtl.uBuf;
         mCb->mfMsgCtl.uBuf = NULLP;

         /* send connect confirmation to the upper layer */
         SiUiSitConCfm(&tCb->pst, tCb->suId, con->suInstId, 
                       con->key.k1.spInstId, cCon->cirId, &ev.m.siConEvnt, 
                       uBuf);

#ifdef ZI
         if (ziCb.updateOption == ZI_UPD_UNANSWRD)
            ziRunTimeUpd(ZI_CON_CB, CMPFTHA_UPD_REQ, (PTR) con);
         else
            ziRunTimeUpd(ZI_CON_CB, CMPFTHA_CREATE_REQ, (PTR) con);
         ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cCon->cir);
         ziUpdPeer(); 
#endif
         break;
   }
 
   cCon->eventType = 0;
   RETVALUE(ROK);
} /* siReassblSegms */


/*
*
*       Fun:   siInsCallRef
*
*       Desc:  Inserts the call reference in a message
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siInsCallRef
(
SiCirCb   *cir,
SiAllPdus *m,
U8        event
)
#else
PUBLIC S16 siInsCallRef(cir, m, event)
SiCirCb   *cir;
SiAllPdus *m;
U8        event;
#endif
{
   SiCon *con;
   U32 callId;
   U16 pntCode;
/* si034.220 : Addition - CHINA flag */   
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
   U32 pntCodeA; 
#endif   

   TRC2(siInsCallRef)

   con = cir->siCon;
  
   callId = 0;
   pntCode = 0;
/* si034.220 : Addition - CHINA flag */   
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
   pntCodeA = 0;
#endif

   switch (con->tCallCb->cfg.swtch)
   {
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
      case LSI_SW_ITU:
         callId = con->key.k1.spInstId;
         pntCode = (U16) cir->opc;
         if ((con->incC.cirId) && (con->incC.dCallRef))
         {       
            if (con->outC.dCallRef)
            {
               callId = con->incC.dCallRef;
               pntCode = (U16) con->incC.phyDpc;
            }
            else
               con->outC.dCallRef = callId; 
         } 
         else
            if ((con->outC.cirId) && (con->outC.dCallRef))
            {       
               callId = con->outC.dCallRef;
               pntCode = (U16) con->outC.phyDpc;
            } 
      
         switch(event)
         {
            case M_ADDCOMP:
               if (con->exchCalRef == TRUE)
               {
                  m->m.addrComp.callRef.eh.pres = PRSNT_NODEF;
                  m->m.addrComp.callRef.callId.pres = PRSNT_NODEF;
                  m->m.addrComp.callRef.callId.val = callId;
                  m->m.addrComp.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.addrComp.callRef.pntCde.val =pntCode;
               }
               else
                  m->m.addrComp.callRef.eh.pres = NOTPRSNT;
               break;
            case M_ANSWER:
               if (con->exchCalRef == TRUE)
               {
                  m->m.answer.callRef.eh.pres = PRSNT_NODEF;
                  m->m.answer.callRef.callId.pres = PRSNT_NODEF;
                  m->m.answer.callRef.callId.val = callId;
                  m->m.answer.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.answer.callRef.pntCde.val = pntCode;
               }
               else
                  m->m.answer.callRef.eh.pres = NOTPRSNT;
               break;
            case M_CALLMODCOMP:
               if (con->exchCalRef == TRUE)
               {
                  m->m.caModComp.callRef.eh.pres = PRSNT_NODEF;
                  m->m.caModComp.callRef.callId.pres = PRSNT_NODEF;
                  m->m.caModComp.callRef.callId.val = callId;
                  m->m.caModComp.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.caModComp.callRef.pntCde.val = pntCode;
               }
               else
                  m->m.caModComp.callRef.eh.pres = NOTPRSNT;
               break;
            case M_CALLMODREQ:
               if (con->exchCalRef == TRUE)
               {
                  m->m.caModReq.callRef.eh.pres = PRSNT_NODEF;
                  m->m.caModReq.callRef.callId.pres = PRSNT_NODEF;
                  m->m.caModReq.callRef.callId.val = callId;
                  m->m.caModReq.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.caModReq.callRef.pntCde.val = pntCode;
               }
               else
                  m->m.caModReq.callRef.eh.pres = NOTPRSNT;
               break;
            case M_CALLMODREJ:
               if (con->exchCalRef == TRUE)
               {
                  m->m.caModRej.callRef.eh.pres = PRSNT_NODEF;
                  m->m.caModRej.callRef.callId.pres = PRSNT_NODEF;
                  m->m.caModRej.callRef.callId.val = callId;
                  m->m.caModRej.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.caModRej.callRef.pntCde.val = pntCode;
               }
               else
                  m->m.caModRej.callRef.eh.pres = NOTPRSNT;
               break;
            case M_CALLPROG:
               if (con->exchCalRef == TRUE)
               {
                  m->m.caProg.callRef.eh.pres = PRSNT_NODEF;
                  m->m.caProg.callRef.callId.pres = PRSNT_NODEF;
                  m->m.caProg.callRef.callId.val = callId;
                  m->m.caProg.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.caProg.callRef.pntCde.val = pntCode;
               }
               else
                  m->m.caProg.callRef.eh.pres = NOTPRSNT;
               break;
            case M_CONNCT:
               if (con->exchCalRef == TRUE)
               {
                  m->m.connect.callRef.eh.pres = PRSNT_NODEF;
                  m->m.connect.callRef.callId.pres = PRSNT_NODEF;
                  m->m.connect.callRef.callId.val = callId;
                  m->m.connect.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.connect.callRef.pntCde.val = pntCode;
               }
               else
                  m->m.connect.callRef.eh.pres = NOTPRSNT;
               break;
            case M_FACREJ:
               if (con->exchCalRef == TRUE)
               {
                  m->m.facReject.callRef.eh.pres = PRSNT_NODEF;
                  m->m.facReject.callRef.callId.pres = PRSNT_NODEF;
                  m->m.facReject.callRef.callId.val = callId;
                  m->m.facReject.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.facReject.callRef.pntCde.val = pntCode;
               }
               else
                  m->m.facReject.callRef.eh.pres = NOTPRSNT;
               break;
            case M_FACREQ:
               if (con->exchCalRef == TRUE)
               {
                  m->m.facRequest.callRef.eh.pres = PRSNT_NODEF;
                  m->m.facRequest.callRef.callId.pres = PRSNT_NODEF;
                  m->m.facRequest.callRef.callId.val = callId;
                  m->m.facRequest.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.facRequest.callRef.pntCde.val = pntCode;
               }
               else
                  m->m.facRequest.callRef.eh.pres = NOTPRSNT;
               break;
            case M_FWDTFER:
               if (con->exchCalRef == TRUE)
               {
                  m->m.fwdTrans.callRef.eh.pres = PRSNT_NODEF;
                  m->m.fwdTrans.callRef.callId.pres = PRSNT_NODEF;
                  m->m.fwdTrans.callRef.callId.val = callId;
                  m->m.fwdTrans.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.fwdTrans.callRef.pntCde.val = pntCode;
               }
               else
                  m->m.fwdTrans.callRef.eh.pres = NOTPRSNT;
               break;
            case M_INFORMTN:
               if (con->exchCalRef == TRUE)
               {
                  m->m.info.callRef.eh.pres = PRSNT_NODEF;
                  m->m.info.callRef.callId.pres = PRSNT_NODEF;
                  m->m.info.callRef.callId.val = callId;
                  m->m.info.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.info.callRef.pntCde.val = pntCode;
               }
               else
                  m->m.info.callRef.eh.pres = NOTPRSNT;
               break;
            case M_INFOREQ:
               if (con->exchCalRef == TRUE)
               {
                  m->m.infoReq.callRef.eh.pres = PRSNT_NODEF;
                  m->m.infoReq.callRef.callId.pres = PRSNT_NODEF;
                  m->m.infoReq.callRef.callId.val = callId;
                  m->m.infoReq.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.infoReq.callRef.pntCde.val = pntCode;
               }
               else
                  m->m.infoReq.callRef.eh.pres = NOTPRSNT;
               break;
            case M_INIADDR:
               if (con->exchCalRef == TRUE)
               {
                  m->m.initAddr.callRef.eh.pres = PRSNT_NODEF;
                  m->m.initAddr.callRef.callId.pres = PRSNT_NODEF;
                  m->m.initAddr.callRef.callId.val = callId;
                  m->m.initAddr.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.initAddr.callRef.pntCde.val = pntCode;
               }
               else
                  m->m.initAddr.callRef.eh.pres = NOTPRSNT;
               break;
            case M_RESUME:
               if (con->exchCalRef == TRUE)
               {
                  m->m.resume.callRef.eh.pres = PRSNT_NODEF;
                  m->m.resume.callRef.callId.pres = PRSNT_NODEF;
                  m->m.resume.callRef.callId.val = callId;
                  m->m.resume.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.resume.callRef.pntCde.val = pntCode;
               }
               else
                  m->m.resume.callRef.eh.pres = NOTPRSNT;
               break;
            case M_SUSPND:
               if (con->exchCalRef == TRUE)
               {
                  m->m.suspend.callRef.eh.pres = PRSNT_NODEF;
                  m->m.suspend.callRef.callId.pres = PRSNT_NODEF;
                  m->m.suspend.callRef.callId.val = callId;
                  m->m.suspend.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.suspend.callRef.pntCde.val = pntCode;
               }
               else
                  m->m.suspend.callRef.eh.pres = NOTPRSNT;
               break;
            case M_USR2USR:
               if (con->exchCalRef == TRUE)
               {
                  m->m.usr2Usr.callRef.eh.pres = PRSNT_NODEF;
                  m->m.usr2Usr.callRef.callId.pres = PRSNT_NODEF;
                  m->m.usr2Usr.callRef.callId.val = callId;
                  m->m.usr2Usr.callRef.pntCde.pres = PRSNT_NODEF;
                  m->m.usr2Usr.callRef.pntCde.val = pntCode;
               }
               else
                  m->m.usr2Usr.callRef.eh.pres = NOTPRSNT;
               break;
            case M_FACINF:
            case M_FACDEACT:
            case M_RELSE:
            case M_CUGSELVALRSP:
            case M_CUGSELVALREQ:
            case M_CIRVALRSP:
            case M_CIRVALTEST:
            case M_EXIT:
            case M_UNBLK:
            case M_UNBLKACK:
            case M_SUBADDR:
            case M_RELCOMP:
            case M_RESCIR:
            case M_PASSALNG:
            case M_CONTINUITY:
            case M_CONTCHKREQ:
            case M_FACACC:
            case M_BLOCK:
            case M_BLOCKACK:
            case M_CIRGRPBLK:
            case M_CIRGRPBLKACK:
            case M_CIRGRPQRY:
            case M_CIRGRPQRYRES:
            case M_CIRGRPRES:
            case M_CIRGRPRESACK:
            case M_CIRGRPUBLK:
            case M_CIRGRPUBLKACK:
            case M_CONFUSION:
            case M_CIRRESERVE:
            case M_CIRRESACK:
            case M_FACIL:
            case M_IDENTREQ:
            case M_IDENTRSP:
            case M_NETRESMGT:
            case M_USRPARTA:
            case M_USRPARTT:
            case M_CHARGE:
            case M_COM:
            case M_TRFFCHGE:
            case M_CHARGEACK:
            case M_LOOPPRVNT:
            case M_GTCHRGEXT:
            case M_GTCHRGEXTACK:
            case M_GTHANGUP:
            case M_SEGMMSG:
               break;

#if (ERRCLASS & ERRCLS_DEBUG)
            default:
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siInsCallRef(): invalid event : %d\n", event));  
                SILOGERROR(ERRCLS_DEBUG, ESI628, (ErrVal) event,
                           "siInsCallRef() Failed, invalid message type");
                RETVALUE(ROK);
#endif
         }
         break;
    

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siInsCallRef(): invalid swtch %d\n", con->tCallCb->cfg.swtch));  
         SILOGERROR(ERRCLS_DEBUG, ESI629, (ErrVal) con->tCallCb->cfg.swtch,
                    "siInsCallRef() Failed, invalid configuration switch");
         RETVALUE(ROK);
    
#endif
   }
   RETVALUE(ROK);
}  /* siInsCallRef */

  
/*
*
*       Fun:   siSndMsg
*
*       Desc:  send message
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siSndMsg
(
SiNSAPCb *cb,
Buffer   *mBuf,
Dpc      opc,
SiInstId intfId,
Dpc      phyDpc,  /* physical dpc */
U8       intfflg, /* interface id valid flag */
LnkSel   lnkSel,
Bool     endSeg,
Priority prior,
Swtch    swtch
)
#else
PUBLIC S16 siSndMsg(cb, mBuf, opc, intfId, phyDpc, intfflg, 
                           lnkSel, endSeg, prior, swtch)
SiNSAPCb *cb;
Buffer  *mBuf;
Dpc      opc;
SiInstId intfId;
Dpc      phyDpc;  /* physical dpc */
U8       intfflg; /* interface id valid flag : TRUE: intfid is valid */
LnkSel lnkSel;
Bool endSeg;
Priority prior;
Swtch swtch;
#endif
{
   Data msgType;
   /* si009.220, ADDED: added a local variable for interface cb */
   SiIntfCb  *intfCb;
#ifdef SI_SPT
   SpUDatEvnt uData;
#else
   UNUSED(endSeg);
#endif

   TRC2(siSndMsg)

/* si039.220 - Debug flag changed from DBG4 to DBG5 as DBG4 should be used for error
               cases in mf and not in Tx & Rx
*/
#ifdef DBG5
   /* print transmitted message */
   if (siCb.init.dbgMask & SIDBGMASK_MSGTX)
   {
       SPrntMsg(mBuf, (S16) opc, (S16) phyDpc);
   }
#endif

   /* do trace if needed */
   if (cb->trc)
      siTrcBuf(phyDpc, intfId, (U16 )TL5MSGTX, (U8 )cb->cfg.sapType, mBuf);

   /* On receiving a message for which there is no interface 
    * block associated with the corresponding NT, swtch and opc
    * interface id is not valid in this function
   */
   /* If interface id is valid */
   if(intfflg == TRUE) 
   {
      /* si009.220, ADDED: check the interface state. If it is unavailable,
       * stop sending the traffic. Since this function is  called directly
       * for sending message, need to check the interface state 
       */
      if (siFindIntf(&intfCb, intfId, 0, 0, 0, 0, SIINTF_KEY_1) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "interface (%#lx) control block can't be found\n", intfId));
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESIXXX, (ErrVal) intfId, 
                    "siSndMsg() Failed, Interface CB can't be found. ");
#endif
      /* si035.220 : Addition - Drop message in case of failure to aviod memory leak */
         siDropMsg(mBuf);
         RETVALUE(RFAILED);
      }

      if (intfCb->state == SI_INTF_UNAVAIL)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "INTF (%#lx) state is unavailable \n", intfId)); 
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESIXXX, (ErrVal) intfId, 
                    "siSndMsg() Failed, Interface state is unavailable. ");
#endif
   /* si035.220 : Addition - Drop message in case of failure to aviod memory leak */
         siDropMsg(mBuf);
         RETVALUE(RFAILED);
      }

      if (SExamMsg((Data *) &msgType, mBuf, (MsgLen) 0x02) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI630, (ErrVal) 0,
                    "siSndMsg() Failed, can not find PDU type in mBuf");
#endif
   /* si044.220 : Addition - Drop message in case of failure to aviod memory leak */
         siDropMsg(mBuf);
         RETVALUE(RFAILED);
      }
   
      /* update transmit statistics counters */
#if (SI_LMINT3 || SMSI_LMINT3)
      siUpdIntfSts(intfId, LSI_STS_TX, msgType);
#else
      {
         U8 tmpCic;
         Cic cic;
   
         tmpCic = 0;
         SExamMsg(&tmpCic, mBuf, 0);
         cic = PutLoByte(cic, tmpCic);
         tmpCic = 0;
         SExamMsg(&tmpCic, mBuf, 1);
         cic = PutHiByte(cic, tmpCic);
   
         siUpdTxSts(cb, cic, intfId, msgType);
      }
#endif
   }  /* if interface id is provided */

   switch (cb->cfg.sapType)
   {
      case SAP_MTP:
      case SAP_M3UA:
         SiLiSntUDatReq(&cb->pst, cb->spId, opc, phyDpc, 
            cb->srvInfo, lnkSel, prior, mBuf);
         break;
#ifdef SI_SPT
      case SAP_SCCP:
         siBldUData(&uData, phyDpc, opc, swtch);
         uData.esc = endSeg;
         uData.prior = prior;
         SiLiSptUDatReq(&cb->pst, cb->spId, &uData, mBuf);
         break;
#endif
   }
   RETVALUE(ROK);
} /* end of siSndMsg */


#ifdef ANSI
PRIVATE S16 siSegMsgRemParm
(
Data parmLen,
Buffer *uBuf,
MsgLen  offset
)
#else
PRIVATE S16 siSegMsgRemParm(parmLen, uBuf, offset)
Data parmLen;
Buffer *uBuf;
MsgLen offset;
#endif
{
   Buffer *newuBuf;
   Data   tmpBuf[(MF_SIZE_TKNSTR + 2)];
   
   if (offset > 0)
   {
      SSegMsg(uBuf, offset, &newuBuf);
      SRemPreMsgMult(tmpBuf, (MsgLen) (parmLen + 2), newuBuf);
      SCatMsg(uBuf, newuBuf, M1M2);
      siDropMsg(newuBuf);
      newuBuf = NULLP;
   }
   else 
   {
      SRemPreMsgMult(tmpBuf, (MsgLen) (parmLen + 2), uBuf);
   }
   RETVALUE(ROK);
}


/*
*
*       Fun:   siBldInstrIndArr 
*
*       Desc:  This function builds instruction indicators array.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*/

#ifdef ANSI
PRIVATE S16  siBldInstrIndArr
(
SiNSAPCb *nCb,
U8 xchgType,
SiUpgrParmInfo parmList[],
U8 *numPar,
SiParmCompInfo *parmComp,
SiCauseDgn *causeDgn,
SiUpSAPCb *tCb
)
#else
PRIVATE S16 siBldInstrIndArr (nCb, xchgType, parmList, numPar, 
                              parmComp, causeDgn, tCb) 
SiNSAPCb *nCb;
U8 xchgType;
SiUpgrParmInfo parmList[];
U8 *numPar;
SiParmCompInfo *parmComp;
SiCauseDgn *causeDgn;
SiUpSAPCb *tCb;
#endif
{

   U8 nPar;
   U8 cntr;
   Data byte;
   MsgLen bufLen;
   MsgLen offset;
   Buffer *uBuf;
   
   TRC2(siBldInstrIndArr);
   
   nPar   = *numPar;
   cntr   = 0;
   offset = 0;
   uBuf   = nCb->mfMsgCtl.uBuf;
   SFndLenMsg(uBuf, &bufLen); /* find the length of uBuf */
   
   while (bufLen > 0)
   {      
      if (SExamMsg(&byte, uBuf, offset) != ROK) 
      {  
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                 "SExamMsg failed\n"));  

         RETVALUE(RFAILED);
      } 

      /* 1st param */
      if ((parmComp->upgrPar1.pres) && (byte == parmComp->upgrPar1.val))
      {
         /* 
          * if xchgType=B and bit A=0 then do not build the array of
          * of instruction indicators as the rest of the instruction
          * indicators are ignored. Build the array of instruction
          * indicators if (xchgType=B and bit A=1) or xhcgType=A
          * which means if bit A=1, all kinds of exchange i.e type A
          * or type B, have to interpret the instruction indicators.
          */ 
/* si029.220: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
         if ((parmComp->passNtPoss1.pres) && (parmComp->passNtPoss1.val == 0x03))
            parmComp->passNtPoss1.val = 0x00;
#endif
         if ((xchgType & TOXA) || (parmComp->tranXInd1.val))
         {
/* si029.220: Modification - added INDIA switch */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
            if ((tCb->cfg.swtch == LSI_SW_ITU97) ||
                (tCb->cfg.swtch == LSI_SW_ETSIV3) ||
                (tCb->cfg.swtch == LSI_SW_ITU2000) ||
                (tCb->cfg.swtch == LSI_SW_RUSS2000) ||
                (tCb->cfg.swtch == LSI_SW_INDIA))
            {
               INSTRARRAY1(parmList, nPar, parmComp, 1);
            }
            else
#endif
               INSTRARRAY(parmList, nPar, parmComp, 1);
            nPar++;
         }
         /* 
          * if xchgType=B & bit A=0 & passOn has been instructed then
          * skip this parameter. it should be passed on unmodified, as
          * there are no instrcution indicators for this case in the 
          * array. If xchgType=A || (B && bit A=0), then instruction 
          * indicators will be analysed and action taken accordingly. 
          * If action is ReleaseCall or DiscardMsg the uBuf will be 
          * dropped. If action=DiscardParm the parameter will be removed 
          * from the uBuf.
          * If passOn is not possibe then parameter is removed anyway 
          * from the uBuf. Further actions are taken after analysing 
          * the instuction indicators.
          */
         /* find the length of the parameter */
         if (SExamMsg(&byte, uBuf, (MsgLen )(offset + 1)) != ROK)
         {  
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SExamMsg failed\n"));  
            RETVALUE(RFAILED);
         } 
         bufLen -= (MsgLen) (byte + 2);
         offset += byte + 2;
         continue;  
      }

      /* 2nd param */
      if ((parmComp->upgrPar2.pres) && (byte == parmComp->upgrPar2.val))
      {
/* si029.220: Modification - added INDIA switch */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
         if ((parmComp->passNtPoss2.pres) && 
             (parmComp->passNtPoss2.val == 0x03))
            parmComp->passNtPoss2.val = 0x00;
#endif
         if ((xchgType & TOXA) || (parmComp->tranXInd2.val))
         {
#if (SS7_ITU97 || SS7_ETSIV3 || SS7_INDIA)
            if ((tCb->cfg.swtch == LSI_SW_ITU97) ||
                (tCb->cfg.swtch == LSI_SW_ETSIV3) ||
                (tCb->cfg.swtch == LSI_SW_ITU2000) ||
                (tCb->cfg.swtch == LSI_SW_RUSS2000) ||
                (tCb->cfg.swtch == LSI_SW_INDIA))
            {
               INSTRARRAY1(parmList, nPar, parmComp, 2);
            }
            else
#endif
            {
               INSTRARRAY(parmList, nPar, parmComp, 2);
            }
            nPar++;       
         }
         /* find the length of the parameter */
         if (SExamMsg(&byte, uBuf, (MsgLen)(offset + 1)) != ROK)
         {  
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SExamMsg failed\n"));  

            RETVALUE(RFAILED);
         } 
         bufLen -= (MsgLen) (byte + 2);
         offset += byte + 2;
         continue;  
      }

      /* 3rd param */
      if ((parmComp->upgrPar3.pres) && (byte == parmComp->upgrPar3.val))
      {
/* si029.220: Modification - added INDIA switch */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_ETSIV3 || SS7_INDIA)
         if ((parmComp->passNtPoss3.pres) && 
             (parmComp->passNtPoss3.val == 0x03))
            parmComp->passNtPoss3.val = 0x00;
#endif
         if ((xchgType & TOXA) || (parmComp->tranXInd3.val))
         {
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
            if ((tCb->cfg.swtch == LSI_SW_ITU97) ||
                (tCb->cfg.swtch == LSI_SW_ETSIV3) ||
                (tCb->cfg.swtch == LSI_SW_ITU2000) ||
                (tCb->cfg.swtch == LSI_SW_RUSS2000) ||
                (tCb->cfg.swtch == LSI_SW_INDIA))
            {
               INSTRARRAY1(parmList, nPar, parmComp, 3);
            }
            else
#endif
            {
               INSTRARRAY(parmList, nPar, parmComp, 3);
            }
            nPar++;
         }
      
         /* find the length of the parameter */
         if (SExamMsg(&byte, uBuf, (MsgLen )(offset + 1)) !=ROK)
         {  
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SExamMsg failed\n"));  

            RETVALUE(RFAILED);
         } 
         bufLen -= (MsgLen) (byte + 2);
         offset += byte + 2;
         continue;  
     
      }

      /* 4th param */
      if ((parmComp->upgrPar4.pres) && (byte == parmComp->upgrPar4.val))
      {
/* si029.220: Modification - added INDIA switch */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_ETSIV3 || SS7_INDIA)
         if ((parmComp->passNtPoss4.pres) && 
             (parmComp->passNtPoss4.val == 0x03))
            parmComp->passNtPoss4.val = 0x00;
#endif
         if ((xchgType & TOXA) || (parmComp->tranXInd4.val))
         {
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
            if ((tCb->cfg.swtch == LSI_SW_ITU97) ||
                (tCb->cfg.swtch == LSI_SW_ETSIV3) ||
                (tCb->cfg.swtch == LSI_SW_ITU2000) ||
                (tCb->cfg.swtch == LSI_SW_RUSS2000) ||
                (tCb->cfg.swtch == LSI_SW_INDIA))
            {
               INSTRARRAY1(parmList, nPar, parmComp, 4);
            }
            else
#endif
            {
               INSTRARRAY(parmList, nPar, parmComp, 4);
            }
            nPar++;
         }
      
         /* find the length of the parameter */
         if (SExamMsg(&byte, uBuf, (MsgLen )(offset + 1)) !=ROK)
         {  
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SExamMsg failed\n"));  

            RETVALUE(RFAILED);
         } 
         bufLen -= (MsgLen) (byte + 2);
         offset += byte + 2;
         continue;  
     
      }

      /* 5th param */
      if ((parmComp->upgrPar5.pres) && (byte == parmComp->upgrPar5.val))
      {
/* si029.220: Modification - added INDIA switch */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
         if ((parmComp->passNtPoss5.pres) && 
             (parmComp->passNtPoss5.val == 0x03))
            parmComp->passNtPoss5.val = 0x00;
#endif
         if ((xchgType & TOXA) || (parmComp->tranXInd5.val))
         {
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
            if ((tCb->cfg.swtch == LSI_SW_ITU97) ||
                (tCb->cfg.swtch == LSI_SW_ETSIV3) ||
                (tCb->cfg.swtch == LSI_SW_ITU2000) ||
                (tCb->cfg.swtch == LSI_SW_RUSS2000) ||
                (tCb->cfg.swtch == LSI_SW_INDIA))
            {
               INSTRARRAY1(parmList, nPar, parmComp, 5);
            }
            else
#endif
            {
               INSTRARRAY(parmList, nPar, parmComp, 5);
            }
            nPar++;
         }
      
         /* find the length of the parameter */
         if (SExamMsg(&byte, uBuf, (MsgLen )(offset + 1)) !=ROK)
         {  
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SExamMsg failed\n"));  

            RETVALUE(RFAILED);
         } 
         bufLen -= (MsgLen) (byte + 2);
         offset += byte + 2;
         continue;  
     
      }

      /* 6th param */
      if ((parmComp->upgrPar6.pres) && (byte == parmComp->upgrPar6.val))
      {
/* si029.220: Modification - added INDIA switch */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
         if ((parmComp->passNtPoss6.pres) && 
             (parmComp->passNtPoss6.val == 0x03))
            parmComp->passNtPoss6.val = 0x00;
#endif
         if ((xchgType & TOXA) || (parmComp->tranXInd6.val))
         {
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
            if ((tCb->cfg.swtch == LSI_SW_ITU97) ||
                (tCb->cfg.swtch == LSI_SW_ETSIV3) ||
                (tCb->cfg.swtch == LSI_SW_ITU2000) ||
                (tCb->cfg.swtch == LSI_SW_RUSS2000) ||
                (tCb->cfg.swtch == LSI_SW_INDIA))
            {
               INSTRARRAY1(parmList, nPar, parmComp, 6);
            }
            else
#endif
            {
               INSTRARRAY(parmList, nPar, parmComp, 6);
            }
            nPar++;
         }
      
         /* find the length of the parameter */
         if (SExamMsg(&byte, uBuf, (MsgLen )(offset + 1)) !=ROK)
         {  
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SExamMsg failed\n"));  

            RETVALUE(RFAILED);
         } 
         bufLen -= (MsgLen) (byte + 2);
         offset += byte + 2;
         continue;  
     
      }

      /* 7th param */
      if ((parmComp->upgrPar7.pres) && (byte == parmComp->upgrPar7.val))
      {
/* si029.220: Modification - added INDIA switch */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
         if ((parmComp->passNtPoss7.pres) && 
             (parmComp->passNtPoss7.val == 0x03))
            parmComp->passNtPoss7.val = 0x00;
#endif
         if ((xchgType & TOXA) || (parmComp->tranXInd7.val))
         {
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
            if ((tCb->cfg.swtch == LSI_SW_ITU97) ||
                (tCb->cfg.swtch == LSI_SW_ETSIV3) ||
                (tCb->cfg.swtch == LSI_SW_ITU2000) ||
                (tCb->cfg.swtch == LSI_SW_RUSS2000) ||
                (tCb->cfg.swtch == LSI_SW_INDIA))
            {
               INSTRARRAY1(parmList, nPar, parmComp, 7);
            }
            else
#endif
            {
               INSTRARRAY(parmList, nPar, parmComp, 7);
            }
            nPar++;
         }
      
         /* find the length of the parameter */
         if (SExamMsg(&byte, uBuf, (MsgLen )(offset + 1)) !=ROK)
         {  
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SExamMsg failed\n"));  

            RETVALUE(RFAILED);
         } 
         bufLen -= (MsgLen) (byte + 2);
         offset += byte + 2;
         continue;  
     
      }

      /* 8th param */
      if ((parmComp->upgrPar8.pres) && (byte == parmComp->upgrPar8.val))
      {
/* si029.220: Modification - added INDIA switch */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
         if ((parmComp->passNtPoss8.pres) && 
             (parmComp->passNtPoss8.val == 0x03))
            parmComp->passNtPoss8.val = 0x00;
#endif
         if ((xchgType & TOXA) || (parmComp->tranXInd8.val))
         {
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
            if ((tCb->cfg.swtch == LSI_SW_ITU97) ||
                (tCb->cfg.swtch == LSI_SW_ETSIV3) ||
                (tCb->cfg.swtch == LSI_SW_ITU2000) ||
                (tCb->cfg.swtch == LSI_SW_RUSS2000) ||
                (tCb->cfg.swtch == LSI_SW_INDIA))
            {
               INSTRARRAY1(parmList, nPar, parmComp, 8);
            }
            else
#endif
            {
               INSTRARRAY(parmList, nPar, parmComp, 8);
            }
            nPar++;
         }
      
         /* find the length of the parameter */
         if (SExamMsg(&byte, uBuf, (MsgLen )(offset + 1)) !=ROK)
         {  
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SExamMsg failed\n"));  

            RETVALUE(RFAILED);
         } 
         bufLen -= (MsgLen) (byte + 2);
         offset += byte + 2;
         continue;  
     
      }

      /* 9th param */
      if ((parmComp->upgrPar9.pres) && (byte == parmComp->upgrPar9.val))
      {
/* si029.220: Modification - added INDIA switch */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
         if ((parmComp->passNtPoss9.pres) && 
             (parmComp->passNtPoss9.val == 0x03))
            parmComp->passNtPoss9.val = 0x00;
#endif
         if ((xchgType & TOXA) || (parmComp->tranXInd9.val))
         {
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
            if ((tCb->cfg.swtch == LSI_SW_ITU97) ||
                (tCb->cfg.swtch == LSI_SW_ETSIV3) ||
                (tCb->cfg.swtch == LSI_SW_ITU2000) ||
                (tCb->cfg.swtch == LSI_SW_RUSS2000) ||
                (tCb->cfg.swtch == LSI_SW_INDIA))
            {
               INSTRARRAY1(parmList, nPar, parmComp, 9);
            }
            else
#endif
            {
               INSTRARRAY(parmList, nPar, parmComp, 9);
            }
            nPar++;
         }
      
         /* find the length of the parameter */
         if (SExamMsg(&byte, uBuf, (MsgLen )(offset + 1)) !=ROK)
         {  
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SExamMsg failed\n"));  

            RETVALUE(RFAILED);
         } 
         bufLen -= (MsgLen) (byte + 2);
         offset += byte + 2;
         continue;  
     
      }

      /* 10th param */
      if ((parmComp->upgrPar10.pres) && (byte == parmComp->upgrPar10.val))
      {
/* si029.220: Modification - added INDIA switch */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
         if ((parmComp->passNtPoss10.pres) && 
             (parmComp->passNtPoss10.val == 0x03))
            parmComp->passNtPoss10.val = 0x00;
#endif
         if ((xchgType & TOXA) || (parmComp->tranXInd10.val))
         {
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
            if ((tCb->cfg.swtch == LSI_SW_ITU97) ||
                (tCb->cfg.swtch == LSI_SW_ETSIV3) ||
                (tCb->cfg.swtch == LSI_SW_ITU2000) ||
                (tCb->cfg.swtch == LSI_SW_RUSS2000) ||
                (tCb->cfg.swtch == LSI_SW_INDIA))
            {
               INSTRARRAY1(parmList, nPar, parmComp, 10);
            }
            else
#endif
            {
               INSTRARRAY(parmList, nPar, parmComp, 10);
            }
            nPar++;
         }
      
         /* find the length of the parameter */
         if (SExamMsg(&byte, uBuf, (MsgLen )(offset + 1)) !=ROK)
         {  
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SExamMsg failed\n"));  

            RETVALUE(RFAILED);
         } 
         bufLen -= (MsgLen) (byte + 2);
         offset += byte + 2;
         continue;  
     
      }
      /* 
       * if the parameter compatibility is present but the unexpected
       * parmeter ID != parmComp->upgrParm[123], then a default action
       * will be set here.
       */
      if (!((tCb->cfg.passOnFlag) || (nPar > MAX_UNREG_PC)))
      {
         parmList[nPar].instrnInd = DISCPARM_SNDNOTIF;
         parmList[nPar].upgrParm = byte;
         nPar++;
         /* find length of the parameter */
         if (SExamMsg(&byte, uBuf, (MsgLen )(offset + 1)) != ROK)
         {  
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "SExamMsg failed\n"));  
         
            RETVALUE(RFAILED);
         } 
         bufLen -= (MsgLen) (byte + 2);
         offset += byte + 2;
         continue;  
      }
      if (!causeDgn->causeVal.pres)
      {
         UPDATECAUSE((*causeDgn), CCNOPARAMDISC, tCb);
      }
/* si029.220: Addition - added code for INDIA */
#if SS7_INDIA
      if (tCb->cfg.swtch == LSI_SW_INDIA)
      {
         causeDgn->dgnVal.pres = NOTPRSNT;
      }
      else
#endif
      UPDATEDGNVAL(causeDgn, PRSNT_NODEF, (cntr + 1), cntr, byte );

      if (byte > 0) 
         siSegMsgRemParm(byte, uBuf, offset);
      bufLen -= (MsgLen) (byte + 2);
      cntr++;
   } /* End while(bufLen) */
   *numPar = nPar;
   RETVALUE(ROK);
} /* end siBldInstrIndArr */


/*
 *
 *       Fun:   siChkPCinRelMsg
 *
 *       Desc:  This function takes action based on PC in REL msg.
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: IF a Release Msg is received with Parm. Compatibility PLUS an 
 *              unrecognized param then depending on the instructions received 
 *              in the PC, an exchange will either: 
 *  
 *              - discard the parameter (Type A/Type B)
 *              - discard the parameter and send a cause 99, in RLC. (Type A/Type B)
 *              - transfer the parameter transparently  (only Type B).
 *
         File:  ci_bdy5.c
 */

#ifdef ANSI
PRIVATE S16 siChkPCinRelMsg 
(
U8 nPar,
SiUpgrParmInfo parmList[],
SiAllPdus *message,
SiNSAPCb *nCb,
SiUpSAPCb *tCb,
U8 xchgType
)
#else
PRIVATE S16 siChkPCinRelMsg(nPar, parmList, message, nCb, tCb, xchgType)
U8 nPar;
SiUpgrParmInfo parmList[];
SiAllPdus *message;
SiNSAPCb *nCb;
SiUpSAPCb *tCb;
U8 xchgType;
#endif
{
   U8 idx;
   U8 tmpPos;
   U8 curPos;
   MsgLen bufLen;
   MsgLen offset;
   Data byte;
   Bool found;
   Buffer *uBuf;
   
   TRC2(siChkPCinRelMsg);
   
   offset = 0;
   tmpPos = 0;
   uBuf = nCb->mfMsgCtl.uBuf;
   
   while (tmpPos < nPar)
   { 
      /* if DiscParInd, bit D=1, discard parameter */
      if ((parmList[tmpPos].instrnInd & 0x10) == 0x10)
      {
         /* if SendNotInd, bit C=1, send a cause 99 in RLC (NO DIAGNOSTIC) */
         if ((parmList[tmpPos].instrnInd & 0x04) == 0x04)
         {
            message->m.release.causeDgn.causeVal.pres = PRSNT_NODEF;
            message->m.release.causeDgn.causeVal.val = CCNOPARAMDISC;
         }
         
         /*
          * If xchgType=Type A drop uBuf, as in this case passON is not to be 
          * done. Pass on in case of Release Msg can only be done for Type B. 
          * If passOn is not possible uBuf should be dropped in case of Release
          * message irrespective of the type of the exchange.
          */
         if ((xchgType & TOXA) || (!tCb->cfg.passOnFlag)) 
         {
            siDropMsg(uBuf);
            nCb->mfMsgCtl.uBuf = NULLP;
         }
         else
         { 
            /* 
             * xchgTpye = Type B && passON is possible, but action=DISCPAR
             * (+ SNDNOT); find the parameter in the uBuf and remove it 
             */
            /* find the length of the uBuf */
            SFndLenMsg(uBuf, &bufLen);
            /* extract the parameter ID from uBuf */
            SExamMsg(&byte, uBuf, offset); 
            
            /* 
             * see if the parameter ID(s) matches with the upgrParm(s) in the
             * parameter compatibility, if it does, remove it from uBuf. 
             * (the case where it doesn't match has already been taken care off)
             */
            curPos = 0;
            found  = FALSE;
            for (idx = 0; idx < nPar; idx++)
            {
               curPos = idx;
               if ((parmList[idx].upgrParm == byte) 
                   && (!parmList[idx].removed))
               {
                  found = TRUE;
                  break;
               }
            }
            /* find the length of the parameter */
            SExamMsg(&byte, uBuf, (MsgLen )(offset + 1));
            if(found)
            {
               siSegMsgRemParm(byte, uBuf, offset);
               parmList[curPos].removed = TRUE;  
            }
            else 
            {
               offset += (byte +2);
            }
            /* adjust bufLen */
            bufLen -= (MsgLen) (byte + 2);
         }
      }
      else
      {
         /* For Type A no other action is specified, so drop uBuf 
          * For Type B if action is not discard parameter(|| +sndcfn)
          * then passON if passOn possible
          */
         if (xchgType & TOXA)
         {
            siDropMsg(uBuf);
            nCb->mfMsgCtl.uBuf = NULLP;
         }
         /* For Type B no action is required here, parm is in uBuf and
            it will be passed on unmodified */
      }
      tmpPos++;
   } /* End while tmpPos < nPar */
   RETVALUE(ROK);
} /* end siChkPCinRelMsg */



/*
 *
 *       Fun:   siChkRelCallInd
 *
 *       Desc:  This function checks if the release call indicator is set in
 *              the parameter compatibility. If it is set then a release 
 *              indication is sent to the upper layer and release msg is 
 *              sent to the preceeding exchange from which this message is 
 *              received.
 *
 *       Ret:   ROK        - ok
 *              PC_DROPMSG - message is dropped in SiLiSntUDatInd
 *
 *       Notes: none
 *
         File:  ci_bdy5.c
 */

#ifdef ANSI
PRIVATE S16 siChkRelCallInd 
(
SiNSAPCb *nCb,
SiCirCb *siCir,
SiCon *siCon,
SiUpgrParmInfo parmList[],
U8 nPar,
SiCauseDgn *causeDgn
)
#else
PRIVATE S16 siChkRelCallInd(nCb, siCir, siCon, parmList, 
                            nPar, causeDgn)
SiNSAPCb *nCb;
SiCirCb *siCir;
SiCon *siCon;
SiUpgrParmInfo parmList[];
U8     nPar;
SiCauseDgn *causeDgn;
#endif
{
   U8 tmpPos;
/* si029.220: Addition - added SAP variable */
#if SS7_INDIA
   SiUpSAPCb *tCb;
#endif
   
   TRC2(siChkRelCallInd);
   
   /* si029.220: Addition -  Get pointer to upper control block */
#if SS7_INDIA
   tCb = SIUPSAP(siCir->pIntfCb->cfg.sapId);
#endif

   for(tmpPos = 0;tmpPos < nPar;tmpPos++) 
   { 
      if ((parmList[tmpPos].instrnInd & 0x02) == 0x02)
      {
         if (!causeDgn->causeVal.pres)
            UPDATECAUSE((*causeDgn), CCNOPARAMDISC, siCon->tCallCb);
/* si029.220: Addition - added INDIA processing */
#if SS7_INDIA
         if (tCb->cfg.swtch == LSI_SW_INDIA)
            causeDgn->dgnVal.pres = NOTPRSNT;
         else
#endif
         UPDATEDGNVAL(causeDgn, PRSNT_NODEF, 1, 0, parmList[tmpPos].upgrParm);
         siDropMsg(nCb->mfMsgCtl.uBuf);
         nCb->mfMsgCtl.uBuf = NULLP;
         /* send Release */
         siGenRelUpLw(siCir->cfg.cirId, siCon, causeDgn);

/* si054.220 : Added Code to update error counter */
#if(SI_LMINT3 || SMSI_LMINT3)
/* si055.220 : Changed NULL to NULLP */
          siUpdErrSts(NULLP,LSI_STS_RELUNRECINFO);
#endif /* SI_LMINT3 , SMSI_LMINT3 */
         RETVALUE(PC_DROPMSG);
      }
   } /* End B=1 */
   RETVALUE(ROK);
} /* siChkRelCallInd */


/*
 *
 *       Fun:   siChkDiscMsgInd
 *
 *       Desc:  If discard message indicator is set in the parameter 
 *              compatibility the received message is discarded. If send 
 *              notification indicator is CFN msg is sent to the preceeding 
 *              exchange.
 *
 *       Ret:   ROK        - ok
 *              PC_DROPMSG - message is dropped in SiLiSntUDatInd
 *
 *       Notes: none
 *
         File:  ci_bdy5.c
 */
#ifdef ANSI
PRIVATE S16 siChkDiscMsgInd
(
SiNSAPCb *nCb,
SiCirCb *siCir,
SiCon *siCon,
SiUpgrParmInfo parmList[],
U8 nPar,
SiCauseDgn *causeDgn
)
#else
PRIVATE S16 siChkDiscMsgInd(nCb, siCir, siCon, parmList, 
                            nPar, causeDgn)
SiNSAPCb *nCb;
SiCirCb *siCir;
SiCon *siCon;
SiUpgrParmInfo parmList[];
U8     nPar;
SiCauseDgn *causeDgn;
#endif
{
   U8  tmpPos;
/* si029.220: Addition - added SAP variable */
#if SS7_INDIA
   SiUpSAPCb *tCb;
#endif
   
   TRC2(siChkDiscMsgInd);
   
   /* si029.220: Addition -  Get pointer to upper control block */
#if SS7_INDIA
   tCb = SIUPSAP(siCir->pIntfCb->cfg.sapId);
#endif
   for(tmpPos = 0;tmpPos < nPar;tmpPos++)
   { 
      if ((parmList[tmpPos].instrnInd & 0x08) == 0x08)
      {
         /* if SendNotInd, bit C=1, send CFN */
         if ((parmList[tmpPos].instrnInd & 0x04) == 0x04)
         {
            if (!causeDgn->causeVal.pres)
               UPDATECAUSE((*causeDgn), CCNOPARAMDISCMSG, siCon->tCallCb);
/* si029.220: Addition - added INDIA processing */
#if SS7_INDIA
            if (tCb->cfg.swtch == LSI_SW_INDIA)
               causeDgn->dgnVal.pres = NOTPRSNT;
            else
#endif
            { 
               UPDATEDGNVAL(causeDgn, PRSNT_NODEF, 1, 0, nCb->mfMsgCtl.msgType);
               UPDATEDGNVAL(causeDgn, PRSNT_NODEF, 2, 1, 
                            parmList[tmpPos].upgrParm);
            }
            /* send CFN */
            siGenConf(siCir->siCon, siCir, causeDgn);
         }
         /* Since the message is going to be discarded, 
          * if incoming connection state=idle remove the 
          * incoming connection block */ 
         if ((siCir->cfg.cirId == siCon->incC.cirId) &&
             (siCon->incC.conState == ST_IDLE))
            siClearIncCon(siCon);
         siDropMsg(nCb->mfMsgCtl.uBuf);
         nCb->mfMsgCtl.uBuf = NULLP;
         RETVALUE(PC_DROPMSG);
      }
   } /* End bit B=0, D=1 */
   RETVALUE(ROK);
} /* siChkDiscMsgInd */


/* si029.220: Addition - added INDIA switch */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
/*
 *
 *       Fun:   siChkPassOnNtPossInd
 *
 *       Desc:  This function checks the passon not possible indicator (bits G-F) of 
 *              parameter compatibility and takes appropriate actions.
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: This is called for ETSI and FTZ only.
 *
 *       File:  ci_bdy5.c
 */
#ifdef ANSI
PRIVATE S16 siChkPassOnNtPossInd 
(
SiNSAPCb *nCb,
SiCirCb *siCir,
SiCon *siCon,
SiUpgrParmInfo parmList[],
U8 tmpPos,
Bool incrCntr,
U8 cntr,
SiCauseDgn *causeDgn
)
#else
PRIVATE S16 siChkPassOnNtPossInd(nCb, siCir, siCon, parmList, tmpPos,
                             incrCntr, cntr, causeDgn)
SiNSAPCb *nCb;
SiCirCb *siCir;
SiCon *siCon;
SiUpgrParmInfo parmList[];
U8 tmpPos;
Bool incrCntr;
U8 cntr;
SiCauseDgn *causeDgn;
#endif
{
#if SS7_INDIA
   SiUpSAPCb *tCb;
#endif

   TRC2(siChkPassOnNtPossInd);
   
   /* si029.220: Addition -  Get pointer to upper control block */
#if SS7_INDIA
   tCb = SIUPSAP(siCir->pIntfCb->cfg.sapId);
#endif
   /* pass on not possible indicator is examined for 
      Type A exchange only */
   switch (parmList[tmpPos].instrnInd & 0x60)
   {
      case PASSON_NTPOSS_RELCALL   :  /* Release Call */
      case PASSON_NTPOSS_ASSUME00  :  /* Assume value 00 , do this 
                                         here only if this is not being 
                                         done while decoding */
      
        UPDATECAUSE((*causeDgn), CCNOPARAMDISC, siCon->tCallCb);
/* si029.220: Addition - added INDIA processing */
#if SS7_INDIA
        if (tCb->cfg.swtch == LSI_SW_INDIA)
           causeDgn->dgnVal.pres = NOTPRSNT;
        else
#endif
        UPDATEDGNVAL(causeDgn, PRSNT_NODEF, 1, 0, 
                     parmList[tmpPos].upgrParm);
        siDropMsg(nCb->mfMsgCtl.uBuf);
        nCb->mfMsgCtl.uBuf = NULLP;
        siGenRelUpLw(siCir->cfg.cirId, siCon, causeDgn);
        RETVALUE(PC_DROPMSG);   
      
      case PASSON_NTPOSS_DISCMSG :  /* Discard Message */
        /* if SendNotInd, bit C=1, send CFN */
        if ((parmList[tmpPos].instrnInd & 0x04) == 0x04)
        {
           UPDATECAUSE((*causeDgn), CCNOPARAMDISCMSG, siCon->tCallCb);
/* si029.220: Addition - added INDIA processing */
#if SS7_INDIA
           if (tCb->cfg.swtch == LSI_SW_INDIA)
              causeDgn->dgnVal.pres = NOTPRSNT;
           else
#endif
           {
              UPDATEDGNVAL(causeDgn, PRSNT_NODEF, 1, 0, 
                           nCb->mfMsgCtl.msgType);
              UPDATEDGNVAL(causeDgn, PRSNT_NODEF, 2, 1,
                           parmList[tmpPos].upgrParm);
           }
           /* send CFN */
           siGenConf(siCir->siCon, siCir, causeDgn);
        }
        /*
         * Since the message is going to be discarded, 
         * if incoming connection state=idle remove the
         * incoming connection block 
         */ 
        if ((siCir->cfg.cirId == siCon->incC.cirId) &&
            (siCon->incC.conState == ST_IDLE))
           siClearIncCon(siCon);             
        /* drop uBuf */
        siDropMsg(nCb->mfMsgCtl.uBuf);
        nCb->mfMsgCtl.uBuf = NULLP;
        RETVALUE(PC_DROPMSG);
      
      case  PASSON_NTPOSS_DISCPARM :  /* Discard Parameter */
        /* if SendNotInd, bit C=1, send CFN */
        if ((parmList[tmpPos].instrnInd & 0x04) == 0x04)
        {
           parmList[tmpPos].action = PC_DISCPAR_SNDCONF; 
           /* update diagnostics CFN will be sent after 
              examining all the parameters */
           UPDATECAUSE((*causeDgn), CCNOPARAMDISC, siCon->tCallCb);
/* si029.220: Addition - added INDIA processing */
#if SS7_INDIA
           if (tCb->cfg.swtch == LSI_SW_INDIA)
              causeDgn->dgnVal.pres = NOTPRSNT;
           else
#endif
           UPDATEDGNVAL(causeDgn, PRSNT_NODEF, (cntr + 1),
                        cntr, parmList[tmpPos].upgrParm);
        }
        else
        {
           parmList[tmpPos].action = PC_DISCPAR;
           incrCntr = FALSE;
        }
        break;
   } /* end switch (parmList[tmpPos].instrnInd && 0x60) */
   RETVALUE(ROK);
}  /* end siChkPassOnNtPossInd   */
#endif /* if ETSI || FTZ || ITU97 || SS7_RUSS2000 || SS7_ITU2000 || ETSIV3 || INDIA */


#ifdef ANSI
PRIVATE S16 siChkDiscParmInd 
(
SiNSAPCb *nCb,
SiCirCb *siCir,
SiCon *siCon,
SiUpgrParmInfo parmList[],
U8 nPar,
SiCauseDgn *causeDgn
)
#else
PRIVATE S16 siChkDiscParmInd(nCb, siCir, siCon, parmList, nPar, 
                             causeDgn )
SiNSAPCb *nCb;
SiCirCb *siCir;
SiCon *siCon;
SiUpgrParmInfo parmList[];
U8 nPar;
SiCauseDgn *causeDgn;
#endif
{
   U8   cntr;
   U8   tmpPos;
   U8   instrvalue;
   U8   xchgType;
   Bool incrCntr;
   SiUpSAPCb *tCb;
/* si029.220: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
   S16  ret;
#endif

   TRC2(siChkDiscParmInd);

   cntr     = 0;
   incrCntr = TRUE;
   xchgType = siCon->xchgType;
   /*  Get pointer to upper control block */
   tCb =  SIUPSAP(siCir->pIntfCb->cfg.sapId);
  
   for(tmpPos=0; tmpPos < nPar; tmpPos++)
   {
      instrvalue = 0;
      instrvalue = (parmList[tmpPos].instrnInd & CHKBITS_E_C);

      switch (instrvalue)
      {
         case PASSON_PARM :
         case PASSON_PARM_SND_NOTIF :
           parmList[tmpPos].action = PC_PASSONPAR;
           incrCntr = FALSE;
           break;
        
         case DISCPARM :
           parmList[tmpPos].action = PC_DISCPAR;
           incrCntr = FALSE;
           break;
        
         case DISCPARM_SNDNOTIF :
           parmList[tmpPos].action = PC_DISCPAR_SNDCONF; 
           /* update diagnostics CFN will be sent after examining
              all the parameters (after while loop) */
/* si029.220: Addition - added INDIA processing */
#if SS7_INDIA
           if (tCb->cfg.swtch == LSI_SW_INDIA)
              causeDgn->dgnVal.pres = NOTPRSNT;
           else
#endif
           {
              UPDATECAUSE((*causeDgn), CCNOPARAMDISC, tCb);
              UPDATEDGNVAL(causeDgn, PRSNT_NODEF, (cntr + 1), cntr,
                           parmList[tmpPos].upgrParm);  
           }
           break;
      } /* end switch(instrvalue) */
    
      /* 
       * if action=PC_PASSONPAR and passOnFlag=TRUE, the unrecognized
       * parameter will be passed on unmodified. 
       * However, if passOnFlag=FALSE, then for
       *
       * a) Type A exchange "pass on not possible indicator" (G-F) 
       * and "send notification indicator" are checked. For ITU'92 
       * (G-F) are Spare. Instruction indicators marked as Spare
       * are not examined and since this parameter has already been
       * removed from the uBuf no further actions are required.
       * 
       * b) Type B exchange no actions are specified and since this
       * parameter has already been removed from uBuf no further
       * actions are required.
       */
    
      if ((parmList[tmpPos].action == PC_PASSONPAR) 
          && (!tCb->cfg.passOnFlag))
      {
         switch (tCb->cfg.swtch)
         {
/* si029.220: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
            case LSI_SW_ETSI :
            case LSI_SW_ETSIV3 :
            case LSI_SW_FTZ :
            case LSI_SW_ITU97:
            case LSI_SW_ITU2000:
            case LSI_SW_RUSS2000:
            /* si029.220: Addition - added INDIA case */
            case LSI_SW_INDIA:
              if (xchgType & TOXA)
              {
                 ret = siChkPassOnNtPossInd(nCb, siCir, siCon, parmList,
                                            tmpPos, incrCntr, cntr, causeDgn);
                 if (ret != ROK)
                 {
                    SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "     siChkPassOnNtPossInd   failed   \n"));  
                    RETVALUE(ret);
                 } 
              }
              else
              {
                 /* 
                  *  No action is specified for Type B exchange 
                  *  action = PC_NOACTION; This is a dummy case
                  *  at present.
                  */
              }
              break;
#endif
            case LSI_SW_ITU :
              /*
               * for Type B exchange if passON has not been instructed
               * or is not possible then if C=1 send CFN. The unrecognized 
               * parameter has already been removed from uBuf while
               * building instruction array 
               */
              if (!(xchgType & TOXA) && (!tCb->cfg.passOnFlag))
              {
                 if ( parmList[tmpPos].instrnInd & 0x04) /* C=1 */
                 {
                    parmList[tmpPos].action = PC_SNDCONF;
                    UPDATECAUSE((*causeDgn), CCNOPARAMDISCMSG, tCb);
/* si029.220: Addition - added INDIA processing */
#if SS7_INDIA
                    if (tCb->cfg.swtch == LSI_SW_INDIA)
                       causeDgn->dgnVal.pres = NOTPRSNT;
                    else
#endif
                    UPDATEDGNVAL(causeDgn, PRSNT_NODEF, (cntr + 1), cntr, 
                                 parmList[tmpPos].upgrParm);
                    incrCntr = TRUE;
                 }
              }
              break;  
         } /* end switch (tCb->cfg.swtch) */
      } /* if (action==PC_PASSONPAR) && (passOnFlag==FALSE) */
    
      if (incrCntr)
         cntr++;
      incrCntr = TRUE;
    
   } /* end for (tmpPos=0, tmpPos < nPar.....) */
   RETVALUE(ROK);
}


/* si029.220: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
/*
 *
 *       Fun:   siChkBrNbInd
 *
 *       Desc:  This function checks the braodband/narrowband interworking 
 *              indicator (bits IJ) of parameter compatibility and takes 
 *              appropriate actions.
 *
 *       Ret:   ROK     - not broadband/narrowband interworking
 *                        Type B
 *
 *       Notes: This is called for ITU97 and ETSI v3 only.
 *
 *       File:  ci_bdy5.c
 */
#ifdef ANSI
PRIVATE S16 siChkBrNbInd 
(
SiNSAPCb *nCb,
SiCirCb *siCir,
SiCon *siCon,
SiUpgrParmInfo parmList[],
U8 nPar,
SiCauseDgn *causeDgn
)
#else
PRIVATE S16 siChkBrNbInd(nCb, siCir, siCon, parmList, nPar, 
                             causeDgn )
SiNSAPCb *nCb;
SiCirCb *siCir;
SiCon *siCon;
SiUpgrParmInfo parmList[];
U8 nPar;
SiCauseDgn *causeDgn;
#endif
{
   U8   curPos;
   U8   tmpPos;
   U8   xchgType;
   Bool found;
   SiUpSAPCb *tCb;
   S16  ret;
   MsgLen offset;
   MsgLen bufLen;
   Data byte;
   Buffer *uBuf;
   
   TRC2(siChkBrNbInd);

   xchgType = siCon->xchgType;
   /*  Get pointer to upper control block */
   tCb =  SIUPSAP(siCir->pIntfCb->cfg.sapId);
   uBuf = nCb->mfMsgCtl.uBuf;
   ret = RIGNORE;

   for(tmpPos=0; tmpPos < nPar; tmpPos++)
   {
      /* Check if type A exchang or bit A = 1 */
      if ((xchgType & TOXA) || (parmList[tmpPos].instrnInd & 0x01))
      {
         /* check if broadband/narrowband interworking */
         if (xchgType & BRNBAND_ITWK)
         {
            /* take the action only base on IJ bit */
            switch (parmList[tmpPos].pBbNbInd & CHKBITS_I_J)
            {
               case PC_BRN_PASSON:
                  /* No action is required here, param is in uBuf and 
                   * it will be passed on unmodified
                   */
                  RETVALUE(PC_BRN_PASSON);

               case PC_BRN_DISCMSG:
                  /* Since the message is going to be discarded, 
                   * if incoming connection state=idle remove the
                   * incoming connection block 
                   */ 
                  if ((siCir->cfg.cirId == siCon->incC.cirId) &&
                      (siCon->incC.conState == ST_IDLE))
                     siClearIncCon(siCon);             
                  /* drop uBuf */
                  siDropMsg(nCb->mfMsgCtl.uBuf);
                  nCb->mfMsgCtl.uBuf = NULLP;
                  RETVALUE(PC_DROPMSG);

               case PC_BRN_RELCALL:
                  /* Release the call */
                  UPDATECAUSE((*causeDgn), CCNOPARAMDISC, siCon->tCallCb);
/* si029.220: Addition - added INDIA processing */
#if SS7_INDIA
                  if (tCb->cfg.swtch == LSI_SW_INDIA)
                     causeDgn->dgnVal.pres = NOTPRSNT;
                  else
#endif
                  UPDATEDGNVAL(causeDgn, PRSNT_NODEF, 1, 0, 
                               parmList[tmpPos].upgrParm);
                  siDropMsg(nCb->mfMsgCtl.uBuf);
                  nCb->mfMsgCtl.uBuf = NULLP;
                  siGenRelUpLw(siCir->cfg.cirId, siCon, causeDgn);
                  RETVALUE(PC_DROPMSG);

               case PC_BRN_DISCPARM:
                  /* Discard parameter */
                  parmList[tmpPos].action = PC_DISCPAR;
                  
                  /* Search through the parmList again and remove those
                   * parameters which matches the upgrParms in the param
                   * compability from uBuf. The modified uBuf will be passed
                   * on.
                   */
                  /* find length of the uBuf */
                  SFndLenMsg(uBuf, &bufLen);
                  offset = 0;
                  while (bufLen)
                  {
                     /* extract the parameter ID from uBuf */
                     SExamMsg(&byte, uBuf, offset); 
                     curPos = 0;
                     found  = FALSE;
                     for (tmpPos = 0; tmpPos < nPar; tmpPos++)
                     {
                        curPos = tmpPos;
                        if ((parmList[tmpPos].upgrParm == byte) 
                             && (parmList[tmpPos].action == PC_DISCPAR) 
                             && (!parmList[tmpPos].removed))
                        {
                           found = TRUE;
                           break;
                        }
                     }
                     /* find the length of the parameter */
                     SExamMsg(&byte, uBuf, (MsgLen )(offset + 1));
                     if (found)
                     {
                        siSegMsgRemParm(byte, uBuf, offset);
                        parmList[curPos].removed = TRUE;  
                     }
                     else
                     {
                        offset += (byte + 2);
                     }
                     /* adjust bufLen */
                     bufLen -= (MsgLen) (byte + 2);
                  } /* end while */
                  /* no unrecognised parameters present, drop uBuf */
                  if (bufLen == 0)
                  {
                     siDropMsg(uBuf);
                     nCb->mfMsgCtl.uBuf = NULLP;
                  }
                  
                  RETVALUE(PC_BRN_DISCPARM);
            } /* end of switch */
         } /* end of (xchType & BRNBAND_ITWK)*/
         else
         {
            /* Not a broadband/narrowband interworking exchange. Codes will 
             * fall through after returning to calling function.
             * The usual procedure will be followed.
             */
             ret = RIGNORE;
         }
      }
      else
      {
         /* It is a Type B exchange and bit A = 0. No actions are required.
          * It was taken into account in funciton siBldInstrIndArr. 
          */
         ret = RIGNORE;
      }
   } /* end of for(tmpPos ... ) */
                    
   RETVALUE(ret);
}
#endif /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA */


/*
 *
 *       Fun:   siPCinMsg
 *
 *       Desc:  Handles the case when PC is present in the recvd msg.
 *
 *       Ret:   ROK      - ok
 *              PC_DROPMSG - message is dropped in SiLiSntUDatInd
 *
 *       Notes: If parameter compatibility is not present, actions depend on 
 *              whether passON has been instructed (is possible) or not.
 *              Handling for Release and Facility Request is different from 
 *              other msgs.
 *
         File:  ci_bdy5.c
 */
#ifdef ANSI
PRIVATE S16 siPCinMsg 
(
SiNSAPCb *nCb,
SiCirCb *siCir,
SiCon *siCon,
SiAllPdus *message,
SiParmCompInfo *parmComp
)
#else
PRIVATE S16 siPCinMsg(nCb, siCir, siCon, message, parmComp)
SiNSAPCb *nCb;
SiCirCb *siCir;
SiCon *siCon;
SiAllPdus *message;
SiParmCompInfo *parmComp;
#endif
{
   U8             cntr;  
   U8             nPar;
   U8             curPos;
   U8             tmpPos;
   U8             msgIdx;
   U8             xchgType;
   MsgLen         offset;
   MsgLen         bufLen;
   S16            ret;
   Data           byte;
   Buffer         *uBuf;
   SiUpSAPCb      *tCb;
   Bool           found;
   Bool           incrCntr;
   SiCauseDgn     causeDgn;
   SiUpgrParmInfo parmList[MAX_UNREG_PC];
   
   TRC2(siPCinMsg);
  
   incrCntr = TRUE;
   cntr     = 0;
   tmpPos   = 0;
   curPos  = 0;
   uBuf = nCb->mfMsgCtl.uBuf;

   for (nPar = 0; nPar < MAX_UNREG_PC; nPar++)
   {
      parmList[nPar].instrnInd = 0;
      parmList[nPar].upgrParm  = 0;
      parmList[nPar].removed   = FALSE;
      parmList[nPar].action    = PC_NOACTION;
   }
  
   /*  Get pointer to upper control block */
   tCb = SIUPSAP(siCir->pIntfCb->cfg.sapId);

   /* initialize cause/diagnostic element */
   MFINITELMT(&nCb->mfMsgCtl, ret, NULLP, (ElmtHdr *) &causeDgn,
              &meCauseIndV, (U8) PRSNT_DEF, tCb->cfg.swtch, (U32) MF_ISUP);
   causeDgn.recommend.pres = NOTPRSNT;

   /* find length of the uBuf */
   nPar = 0;  
   offset = 0;
   causeDgn.causeVal.pres = NOTPRSNT;
   xchgType = siCon->xchgType;
  
   if (siBldInstrIndArr(nCb, xchgType, parmList, &nPar, parmComp, &causeDgn,
                        tCb) != ROK)
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siBldInstrIndArr failed\n"));  
      RETVALUE(RFAILED);
   } 
  
   if (nPar >0)
   {
/* si029.220: Modification - added INDIA switch */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
      /* check the broad/narrow band indictor first for ITU97 and ETSIV3
       * variants
       */
      /* check if it is the ITU97 and ETSI v3 variants */
      if ((tCb->cfg.swtch == LSI_SW_ITU97) || 
          (tCb->cfg.swtch == LSI_SW_ETSIV3) ||
          (tCb->cfg.swtch == LSI_SW_ITU2000) ||
          (tCb->cfg.swtch == LSI_SW_RUSS2000) ||
          (tCb->cfg.swtch == LSI_SW_INDIA))
      {
         ret = siChkBrNbInd(nCb, siCir, siCon, parmList, nPar, &causeDgn);
         if (ret != RIGNORE)
         {
            /* Already took actions base on IJ bits */
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "    siChkBrNrInd does not return ROK   \n"));
            if (ret != PC_DROPMSG)
               /* uBuf need to be passed on */
               RETVALUE (ROK);
            else
               /* discard message */
               RETVALUE(PC_DROPMSG);
          }
       }         
#endif 

      if (nCb->mfMsgCtl.msgIdx == MI_RELSE)
      {
         siChkPCinRelMsg(nPar, parmList, message, nCb, tCb, xchgType);
         RETVALUE(ROK);
      } /* end if Release Msg */
    
      /*  if RelCallInd=1, bit B=1, Release the Call  */
      ret = siChkRelCallInd(nCb, siCir, siCon, parmList, nPar, &causeDgn);
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "     siChkRelCallInd   failed   \n"));  
         RETVALUE(PC_DROPMSG);
      } 
    
      /* if DiscMsgInd=1, bit B=0, D=1, Discard Message */
      ret = siChkDiscMsgInd(nCb, siCir, siCon, parmList, nPar, &causeDgn);
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "     siChkDiscMsgInd   failed   \n"));  
         RETVALUE(PC_DROPMSG);
      } 
    
      /* If DiscParmInd=1, bit B=0, D=0 and E=1, Discard Parameter */
      ret = siChkDiscParmInd(nCb, siCir, siCon, parmList, nPar, &causeDgn);
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "     siChkDiscParmInd   failed   \n"));  
         RETVALUE(PC_DROPMSG);
      } 
    
    
      /* 
       * if action=PC_PASSONPAR and passOnFlag=TRUE, then no further
       * action is required. Parameter in the uBuf will be passed on 
       * unmodified.
       * Search thru the parmList, if action=PC_DISCPAR_SNDCONF for 
       * any one such parameter, send CFN. causeDgn has already been 
       * updated with parameter ID's of all such parameters.
       */
    
      for (tmpPos = 0; tmpPos < nPar; tmpPos++)
      { 
         if ((parmList[tmpPos].action == PC_DISCPAR_SNDCONF)
             || (parmList[tmpPos].action == PC_SNDCONF))
         {
            /* send CFN */
            msgIdx = nCb->mfMsgCtl.msgIdx;
            siGenConf(siCir->siCon, siCir, &causeDgn);
            nCb->mfMsgCtl.msgIdx = msgIdx;
            break;
         }  
      }
    
      /* Search thru the parmList again and remove all those parameters
       * from uBuf for which action = PC_DISCPAR || PC_DISCPAR_SNDCONF
       * if they have not already been removed in the instruction array
       * building process.
       */

      if (!tCb->cfg.passOnFlag)
      {
         /* drop uBuf */
         siDropMsg(nCb->mfMsgCtl.uBuf);
         nCb->mfMsgCtl.uBuf = NULLP;
      }
      else
      {      
         /* find length of the uBuf */
         SFndLenMsg(uBuf, &bufLen);
         offset = 0;
         while (bufLen)
         {
            /* extract the parameter ID from uBuf */
            SExamMsg(&byte, uBuf, offset); 
            curPos = 0;
            found  = FALSE;
            for (tmpPos = 0; tmpPos < nPar; tmpPos++)
            {
               curPos = tmpPos;
               if ((parmList[tmpPos].upgrParm == byte) 
                   && ((parmList[tmpPos].action == PC_DISCPAR) ||
                       (parmList[tmpPos].action == PC_DISCPAR_SNDCONF))
                   && (!parmList[tmpPos].removed))
               {
                  found = TRUE;
                  break;
               }
            }
            /* find the length of the parameter */
            SExamMsg(&byte, uBuf, (MsgLen )(offset + 1));
            if(found)
            {
               siSegMsgRemParm(byte, uBuf, offset);
               parmList[curPos].removed = TRUE;  
            }
            else
            {
               offset += (byte + 2);
            }
            /* adjust bufLen */
            bufLen -= (MsgLen) (byte + 2);
         } /* end while */
         /* no unrecognised parameters present, drop uBuf */
         /* Check if unrecognized parameter present,
          * if not, should drop the uBuf.
          * find the length of the uBuf again
          */
         SFndLenMsg(uBuf, &bufLen);
         if (bufLen == 0)
         {
            siDropMsg(uBuf);
            nCb->mfMsgCtl.uBuf = NULLP;
         }
      } /* end else */
   } /* end of if(nPar) > 0 */
   RETVALUE(ROK);
} /* end siPCinMsg */



/*
 *
 *       Fun:   siNoPCinMsg
 *
 *       Desc:  Handles the case when PC is not present in the recvd msg.
 *
 *       Ret:   ROK      - ok
 *              PC_DROPMSG - message is dropped in SiLiUDatInd
 *
 *       Notes: If parameter compatibility is not present, actions depend on 
 *              whether passON has been instructed (is possible) or not.
 *              Handling for Release and Facility Request is different from 
 *              other msgs.
 *
         File:  ci_bdy5.c
 */

#ifdef ANSI
PRIVATE S16 siNoPCinMsg 
(
SiNSAPCb *nCb,
SiCirCb *siCir,
SiCon *siCon,
SiAllPdus *message
)
#else
PRIVATE S16 siNoPCinMsg(nCb, siCir, siCon, message)
SiNSAPCb *nCb;
SiCirCb *siCir;
SiCon *siCon;
SiAllPdus *message;
#endif
{
   U8         cntr;
   U8         msgIdx;
   U8         xchgType;
   Data       byte;
   S16        ret;
   Data       tmpBuf[(MF_SIZE_TKNSTR + 2)];
   MsgLen     bufLen;
   SiUpSAPCb  *tCb;
   Buffer     *uBuf;
   SiCauseDgn causeDgn;
  
   TRC2(siNoPCinMsg);
  
#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(siCir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* initialize cause/diagnostic element */
   MFINITELMT(&nCb->mfMsgCtl, ret, NULLP, (ElmtHdr *) &causeDgn,
              &meCauseIndV, (U8) PRSNT_DEF, siCir->pIntfCb->cfg.swtch, 
              (U32) MF_ISUP);
  
   causeDgn.recommend.pres = NOTPRSNT;
   cntr = 0;
   bufLen = 0;
   uBuf = nCb->mfMsgCtl.uBuf;
   causeDgn.causeVal.pres = NOTPRSNT;
   xchgType = siCon->xchgType;
   /*  Get pointer to upper control block */
   tCb = SIUPSAP(siCir->pIntfCb->cfg.sapId);
   /* find length of the uBuf */
   SFndLenMsg(uBuf, &bufLen);
  
   if (nCb->mfMsgCtl.msgIdx == MI_RELSE)
   {
      /* If a Release message w/unrecognized parameter is received then
       * -at Type B xchg, RLC w/cause 99 is sent if it CANNOT be PASSED ON.
       * -at Type A xchg, RLC w/cause 99 is sent (anyways)
       * *** RLC will be sent after jumping into State Matrix.
       */
      /* xchgType is now a bit flag */
      if ((xchgType & TOXA) || (!tCb->cfg.passOnFlag)) 
      {
         /* drop uBuf */
         siDropMsg(uBuf);
         nCb->mfMsgCtl.uBuf = NULLP;
         RETVALUE(PC_INVRELMSG);   
      }
   }
  
   if (nCb->mfMsgCtl.msgIdx == MI_FACREQ)
   {
      /* get the parameter ID from uBuf */
      if (SExamMsg(&byte, uBuf, 0) !=ROK) 
         RETVALUE(RFAILED);

      /* update cause diagnostics with parm name code */
      causeDgn.causeVal.pres = PRSNT_NODEF; 
      causeDgn.causeVal.val = CCNOPARAMDISC;
/* si029.220: Addition - added INDIA processing */
#if SS7_INDIA
      if (tCb->cfg.swtch == LSI_SW_INDIA)
         causeDgn.dgnVal.pres = NOTPRSNT;
      else
#endif
      {
         causeDgn.dgnVal.pres = PRSNT_NODEF;
         causeDgn.dgnVal.len = 1;
         causeDgn.dgnVal.val[0] = byte;
      }

      /* Send a FRJ after detecting an unrecognized
         parameter in FAR with no parameter compatibilty */
      siGenMFacRej(siCir->cfg.cirId, siCon, &causeDgn, message);
      /* 
       * Since the message is going to be discarded, 
       * if incoming connection state=idle remove the 
       * incoming connection block 
       */ 
      if ((siCir->cfg.cirId == siCon->incC.cirId) &&
          (siCon->incC.conState == ST_IDLE))
         siClearIncCon(siCon);
      siDropMsg(uBuf);
      nCb->mfMsgCtl.uBuf = NULLP;
      RETVALUE(PC_DROPMSG);
   }
  
   /* Check the passOnFlag, if possible then no further action is required.
    * Otherwise, send CFN and discard message
    */
   if (!tCb->cfg.passOnFlag)
   {
      if (!causeDgn.causeVal.pres)
      {
         while (bufLen > 0)
         {
            MsgLen     nmbOctetsToExt;     /* number of octets to extract */
            MsgLen     nmbOctetsRem;       /* number of octets remaining */      

            if (SExamMsg(&byte, uBuf, 0) != ROK)
               RETVALUE(RFAILED);
      
            causeDgn.causeVal.pres = PRSNT_NODEF; 
            causeDgn.causeVal.val = CCNOPARAMDISC;
/* si029.220: Addition - added INDIA processing */
#if SS7_INDIA
            if (tCb->cfg.swtch == LSI_SW_INDIA)
               causeDgn.dgnVal.pres = NOTPRSNT;
            else
#endif
            {
               causeDgn.dgnVal.pres = PRSNT_NODEF;
               causeDgn.dgnVal.len = (cntr + 1);
               causeDgn.dgnVal.val[cntr] = byte;
            }
      
            /* find length of the parameter */
            if (SExamMsg(&byte, uBuf, 1) != ROK)
               RETVALUE(RFAILED);
            nmbOctetsRem = (MsgLen) (byte + 2);
            while (nmbOctetsRem > 0)
            {
               nmbOctetsToExt = (nmbOctetsRem > MF_SIZE_TKNSTR) ?
                                 MF_SIZE_TKNSTR : nmbOctetsRem;
               SRemPreMsgMult(tmpBuf, nmbOctetsToExt, uBuf);
               nmbOctetsRem -= nmbOctetsToExt;
            }

            bufLen -= (MsgLen) (byte + 2);
            cntr++;
            continue;
         }
      }
      if (nCb->mfMsgCtl.uBuf) 
      { 
         siDropMsg(nCb->mfMsgCtl.uBuf);
         nCb->mfMsgCtl.uBuf = NULLP;
      } 
      /* send CFN */
      msgIdx = nCb->mfMsgCtl.msgIdx;
      siGenConf(siCir->siCon, siCir, &causeDgn);
      nCb->mfMsgCtl.msgIdx = msgIdx;
   }
   RETVALUE(ROK);
} /* end siNoPCinMsg */


/*
 *
 *       Fun:   siChkMsgCompInd
 *
 *       Desc:  Handles the case when bit BCDE are indicated in the message
 *              compability info parameter..
 *
 *       Ret:   RFAILED    - not ok
 *              PC_DROPMSG - action is taken, message is dropped after return
 *
 *       Notes: If message compatibility is present and not for broadband-
 *              narrowband internetworking, actions depend on the bits BCDE
 *              for type A exchange.
 *
 *       File:  ci_bdy5.c
 */

#ifdef ANSI
PRIVATE S16 siChkMsgCompInd 
(
SiNSAPCb *nCb,
SiCirCb  *siCir,
Dpc      cgAdr,
Cic      cicVal,
Buffer   *mBuf,
Data     byte,
U8       xchgType
)
#else
PRIVATE S16 siChkMsgCompInd(nCb, siCir, cgAdr, cicVal, mBuf, byte, xchgType)
SiNSAPCb *nCb;
SiCirCb *siCir;
Dpc     cgAdr;
Cic     cicVal;
Buffer  *mBuf;
Data    byte;
U8      xchgType;
#endif
{
   SiCon      *siCon;        
   S16        ret;
   SiUpSAPCb  *tCb;
   Buffer     *uBuf;
   SiCauseDgn causeDgn;
   SiInstId   intfid;
  
   TRC2(siChkMsgCompInd);
   
#if (ERRCLASS & ERRCLS_DEBUG)
   if (nCb == NULLP)
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
             "Lower SAP control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI631, (ErrVal) 0, 
                 "siChkMsgCompInd() Failed, pointer to MTP3 missing");
      RETVALUE(RFAILED);
   }
   if (siCir == NULLP)
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
             "no circuit control block\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI632, (ErrVal) 0, 
                 "siChkMsgCompInd() Failed, pointer to circuit missing");
      RETVALUE(RFAILED);
   }
   
   if (siChkCirIntf(siCir) != ROK)
      RETVALUE(RFAILED);

#endif
   
   /*  Get pointer to upper control block */
   tCb = SIUPSAP(siCir->pIntfCb->cfg.sapId);
     
   intfid = siCir->cfg.intfId;

   /* initialize cause/diagnostic element */
   MFINITELMT(&nCb->mfMsgCtl, ret, NULLP, (ElmtHdr *) &causeDgn,
              &meCauseIndV, (U8) PRSNT_DEF, tCb->cfg.swtch, (U32) MF_ISUP);
   causeDgn.recommend.pres = NOTPRSNT;
   /* si028.220: addition - added code to set the diagnostic value */
   /* si029.220: modification - Indian variant does not use diagnostic */
#if SS7_INDIA
   if (tCb->cfg.swtch == LSI_SW_INDIA)
   {
      causeDgn.dgnVal.pres = NOTPRSNT;
   }
   else
#endif
   {
      causeDgn.dgnVal.len = 1;
      {
         U8    msgType;

         if (SExamMsg(&msgType, mBuf, 0) != ROK )
         {
            causeDgn.dgnVal.pres = NOTPRSNT;
         }
         else
         {
            causeDgn.dgnVal.pres = PRSNT_NODEF;
            causeDgn.dgnVal.val[0] = msgType;
         }
      }
   }

   /* check bit B - release call indicator */
   if (byte & 0x2) /* release call */
   {
      /* find connection pointer. If connection does not exist 
         - get new connection and send release */
      if ((siCon = siCir->siCon) == NULLP)
      {
         siCon = siGetIncCon(siCir, nCb);
         if (siCon == NULLP)
         {
            SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                   "     siGetIncCon   failed   \n"));  
            RETVALUE(MC_DROPMSG);
         } 
         /* si025.220: Modificaiton - modify the arguments in siGetLnkSel */
         /* si009.220 - Modified: to pass cic into siGetLnkSel. */
         siGetLnkSel(nCb, &siCon->lnkSel, siCir->pIntfCb->cfg.swtch, siCir);
         causeDgn.causeVal.val = SIT_CCNOMSGTYP;
         siGenRelLw(siCir->cfg.cirId, siCon, &causeDgn);
         RETVALUE(MC_DROPMSG);
     }
     causeDgn.causeVal.val = SIT_CCNOMSGTYP;
     siGenRelUpLw(siCir->cfg.cirId, siCon, &causeDgn);
     RETVALUE(MC_DROPMSG);
  }
            
  switch (byte & CHKMC_BITS_C_D)
  {
     case DISCMSG: /* C=0, D=1 */
        RETVALUE(MC_DROPMSG);
     case DISCMSG_SNDNOTIF: /* C=1, D=1 */
        SNDCONF(nCb, intfid, cgAdr, TRUE, cicVal, mBuf, &causeDgn, 
                siCir->opc, tCb->cfg.swtch);
     case PASSONMSG: /* C=0, D=0 */
     case PASSONMSG_SND_NOTIF: /* C=1, D=0 Notes 2and 3 Q.764 */
        /* pass on unrecog msg if possible */
        if (tCb->cfg.passOnFlag)
        {
           /* copy mBuf to uBuf, if NOK take default action */
           if (SCpyMsgMsg(mBuf, tCb->pst.region, tCb->pst.pool, 
                          &uBuf) != ROK)
           {  
              SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                        "SCpyMsgMsg failed\n"));  
              SNDCONF(nCb, intfid, cgAdr, TRUE, cicVal, mBuf, &causeDgn, 
                     siCir->opc, tCb->cfg.swtch);
           } 

           if ((siCon = siCir->siCon) != NULLP)
           {
              SiUiSitUMsgInd(&tCb->pst, tCb->suId, siCon->suInstId,
                             siCon->key.k1.spInstId, siCir->key.k1.cirId, 
                             uBuf);
           }
           else
           {
              SiUiSitUMsgInd(&tCb->pst, tCb->suId, 
                              0, 0, siCir->key.k1.cirId, uBuf);
           } 
           if ((byte & CHKMC_BITS_C_D)==PASSONMSG_SND_NOTIF)
              SNDCONF(nCb, intfid, cgAdr, TRUE, cicVal, mBuf, &causeDgn, 
                      siCir->opc, tCb->cfg.swtch);
           RETVALUE(MC_DROPMSG);
       }
       else
       {

          /* if RelCallInd is set release the call */
          if (!(byte & 0x10)) /* release call */
          {
             if ((siCon = siCir->siCon) == NULLP)
             {
                siCon = siGetIncCon(siCir, nCb);
                if (siCon == NULLP)
                {
                    SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                           "     siGetIncCon   failed   \n"));  
                    RETVALUE(MC_DROPMSG);
                } 
                causeDgn.causeVal.val = SIT_CCNOMSGTYP;
                /* si025.220: Modification - modify the arguments in siGetLnkSel */
                /* si009.220 - Modified: to pass cic into siGetLnkSel. */
                siGetLnkSel(nCb, &siCon->lnkSel, siCir->pIntfCb->cfg.swtch, siCir);
                siGenRelLw(siCir->cfg.cirId, siCon, &causeDgn);
                RETVALUE(MC_DROPMSG);
             }
             causeDgn.causeVal.val = SIT_CCNOMSGTYP;
             siGenRelUpLw(siCir->cfg.cirId, siCon, &causeDgn);
             RETVALUE(MC_DROPMSG);
          }
          /* if release call is not set, and passon is not
             possible send notification */
          if (byte & 0x04) /* Check bit C, if C=1, send CFN */
             SNDCONF(nCb, intfid, cgAdr, TRUE, cicVal, mBuf, &causeDgn, 
                     siCir->opc, tCb->cfg.swtch);
          RETVALUE(MC_DROPMSG);
       }
       break;
  } /* end switch (byte & CHKMC_BITS_C_D) */
  RETVALUE(RFAILED);
}  

/*
 *
 *       Fun:   siChkParmComp
 *
 *       Desc:  Unrecognized parameter(s) have been found in the message,
 *              check if parameter compatibility is present in this message
 *              and decide how the message needs to be treated. 
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: Actions which are applicable for incoming and outgoing 
 *              International exchanges ONLY which are sub-types of Type A
 *              exchanges are not supported at this time.
 *
         File:  ci_bdy5.c
 *
 */
#ifdef ANSI
PUBLIC S16 siChkParmComp
(
SiNSAPCb  *nCb,
SiCirCb   *siCir,
SiCon     *siCon,
SiAllPdus *message,
Bool      chkSegm
)
#else
PUBLIC S16 siChkParmComp(nCb, siCir, siCon, message, chkSegm)
SiNSAPCb  *nCb;
SiCirCb   *siCir;
SiCon     *siCon;
SiAllPdus *message;
Bool      chkSegm;
#endif
{
   SiParmCompInfo *parmComp;
   S16    ret;

   TRC2(siChkParmComp);

   ret = ROK;

   /* Find if Parameter Compatibility element was included in the received */
   switch (nCb->mfMsgCtl.msgIdx)
   {
      case MI_ADDCOMP:
        if (((message->m.addrComp.optBckCalInd.eh.pres) &&
             (message->m.addrComp.optBckCalInd.simpleSegmInd.pres) && 
             (message->m.addrComp.optBckCalInd.simpleSegmInd.val
              == SSI_ADDSEGM)) && (chkSegm))
           RETVALUE(ROK);
        parmComp = &message->m.addrComp.parmCom;
        break;
      case MI_ANSWER:
        if (((message->m.answer.optBckCalInd.eh.pres) &&
             (message->m.answer.optBckCalInd.simpleSegmInd.pres) && 
             (message->m.answer.optBckCalInd.simpleSegmInd.val
              == SSI_ADDSEGM)) && (chkSegm))
           RETVALUE(ROK);
        parmComp = &message->m.answer.parmCom;
        break;
      case MI_CALLPROG:
        if (((message->m.caProg.optBckCalInd.eh.pres) &&
             (message->m.caProg.optBckCalInd.simpleSegmInd.pres) && 
             (message->m.caProg.optBckCalInd.simpleSegmInd.val
              == SSI_ADDSEGM)) && (chkSegm))
           RETVALUE(ROK);
        parmComp = &message->m.caProg.parmCom;
        break;
      case MI_CONNCT:
        if (((message->m.connect.optBckCalInd.eh.pres) &&
             (message->m.connect.optBckCalInd.simpleSegmInd.pres) && 
             (message->m.connect.optBckCalInd.simpleSegmInd.val
              == SSI_ADDSEGM)) && (chkSegm))
           RETVALUE(ROK);
        parmComp = &message->m.connect.parmCom;
        break;
      case MI_FACREQ:
        parmComp = &message->m.facRequest.parmCom;
        break;
      case MI_FACACC:
        parmComp = &message->m.facAccept.parmCom;
        break;
      case MI_INFORMTN:
        parmComp = &message->m.info.parmCom;
        break;
      case MI_INFOREQ:
        parmComp = &message->m.infoReq.parmCom;
        break;
      case MI_INIADDR:
        if ((message->m.initAddr.opFwdCalInd.eh.pres) &&
            (message->m.initAddr.opFwdCalInd.simpleSegmInd.pres) && 
            (message->m.initAddr.opFwdCalInd.simpleSegmInd.val
             == SSI_ADDSEGM) && (chkSegm))
           RETVALUE(ROK);
        parmComp = &message->m.initAddr.parmCom;
        break;
      case MI_RELSE:
        parmComp = &message->m.release.parmCom;
        break;
      case MI_FACIL:
        parmComp = &message->m.facility.parmCom;
        break;
      case MI_USRPARTA:
        parmComp = &message->m.usrPrtAvTst.parmCom;
        break;
      case MI_USRPARTT:
        parmComp = &message->m.usrPrtAvTst.parmCom;
        break;
      case MI_NETRESMGT:
        parmComp = &message->m.netResMgt.parmCom;
        break;
      case MI_IDENTREQ:
        parmComp = &message->m.identReq.parmCom;
        break;
      case MI_IDENTRSP:
        parmComp = &message->m.identRsp.parmCom;
        break;
      case MI_LOOPPRVNT:
        parmComp = &message->m.loopPrvnt.parmCom;
        break;
      case MI_SEGMMSG:
        RETVALUE(ROK);
      default:
        /* the check for following three msgs should be moved to si_bdy1.c */
        if ((nCb->mfMsgCtl.msgIdx == MI_RELCOMP) || 
            (nCb->mfMsgCtl.msgIdx == MI_CONFUSION) ||
            (nCb->mfMsgCtl.msgIdx == MI_FACREJ))
        {
           siDropMsg(nCb->mfMsgCtl.uBuf);
           nCb->mfMsgCtl.uBuf = NULLP;
           RETVALUE(ROK);
        }
        parmComp = NULLP;
        break;
   }
   if ((parmComp != NULLP) && (parmComp->eh.pres))
      ret = siPCinMsg(nCb, siCir, siCon, message, parmComp);
   else
      if ((parmComp == NULLP) || (!parmComp->eh.pres))
         ret = siNoPCinMsg(nCb, siCir, siCon, message);
  
   RETVALUE(ret);
} /* end of siChkParmComp */



/*
 *
 *       Fun:   siChkMsgComp
 *
 *       Desc:  Unrecognized  message has been received. Check if message 
 *              compatibility is present and decide how the message needs
 *              to be treated. 
 *
 *       Ret:   ROK        - ok
 *              MC_DROPMSG - msg to be dropped in SiLiSntUDatInd
 *
 *       Notes: Actions which are applicable for incoming and outgoing 
 *              International exchanges ONLY which are sub-types of Type A
 *              exchanges are not supported at this time.
 *
         File:  ci_bdy5.c
 *
 */

#ifdef ANSI
PUBLIC S16 siChkMsgComp
(
SiNSAPCb   *nCb,
SiCirCb    *siCir,
Buffer     *mBuf,
Dpc        cgAdr,
Cic        cicVal,
SiCauseDgn *causeDgn
)
#else
PUBLIC S16 siChkMsgComp(nCb, siCir, mBuf, cgAdr, cicVal, causeDgn)
SiNSAPCb   *nCb;
SiCirCb    *siCir;
Buffer     *mBuf;
Dpc        cgAdr;
Cic        cicVal;
SiCauseDgn *causeDgn;
#endif
{
   SiCon     *siCon;
   SiUpSAPCb *tCb;
   Buffer    *uBuf;
   S16       ret;
   U8        xchgType;
   Data      msgType;
   Data      byte;
   MsgLen    offset;
   MsgLen    bufLen;
   SiInstId  intfid;
  
   ret = SFndLenMsg(mBuf, &bufLen);
   /*  Get pointer to upper control block */
   tCb = SIUPSAP(siCir->pIntfCb->cfg.sapId);

   if (siCir->siCon != NULLP)
      xchgType = siCir->siCon->xchgType;
   else
      xchgType = TOXB;

   intfid = siCir->cfg.intfId;
 
   switch (tCb->cfg.swtch)
   {
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
       case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case  LSI_SW_ITU:
      
        /* si029.220: Addition - added code for INDIA processing */
#if SS7_INDIA
        if (tCb->cfg.swtch == LSI_SW_INDIA)
           causeDgn->dgnVal.pres = NOTPRSNT;
#endif
         
        offset = 0;  
        /* Check if message type octect is present in mBuf */
        if (SExamMsg(&msgType, mBuf, offset) != ROK)
           SNDCONF(nCb, intfid, cgAdr, TRUE, cicVal, mBuf, 
                     causeDgn, siCir->opc, tCb->cfg.swtch);
      
        /* initialize cause diagnostic */
        /* si029.220: modification - added code for INDIA processing */
#if SS7_INDIA
        if (tCb->cfg.swtch == LSI_SW_INDIA)
        {
           causeDgn->dgnVal.pres = NOTPRSNT;
        }
        else
#endif
        {
           causeDgn->dgnVal.pres = PRSNT_NODEF;
           causeDgn->dgnVal.len = 1;
           causeDgn->dgnVal.val[0] = msgType;
        }
      
        offset++;   /* go pass the message type */
      
        /* Since the unrecognized messages can only have optional parameters,
           check if the next octect is the pointer to optional parameters */
        if (SExamMsg(&byte, mBuf, offset) != ROK)
        {  
           SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "SExamMsg failed\n"));  

           SNDCONF(nCb, intfid, cgAdr, TRUE, cicVal, mBuf, causeDgn, 
                     siCir->opc, tCb->cfg.swtch);
        } 
        if (byte != 1)
           SNDCONF(nCb, intfid, cgAdr, TRUE, cicVal, mBuf, causeDgn, 
                     siCir->opc, tCb->cfg.swtch);
      
        offset++;   /* go pass the pointer */
        /* Message compatibility is present decode the instruction set */
        while (bufLen > offset)
        {
           /* get parameter id */
           if (SExamMsg(&byte, mBuf, offset) != ROK)
           {  
              SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SExamMsg failed\n"));  

              SNDCONF(nCb, intfid, cgAdr, TRUE, cicVal, mBuf, causeDgn, 
                        siCir->opc, tCb->cfg.swtch);
           } 
         
           if (byte == ME_MSGCOMP)
           {
              offset += 2;   /* go pass the length */
              /* get instruction indicator octet */
              if (SExamMsg(&byte, mBuf, offset) != ROK)
              {  
                 SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SExamMsg failed\n"));  

                 SNDCONF(nCb, intfid, cgAdr, TRUE, cicVal, mBuf, 
                              causeDgn, siCir->opc, tCb->cfg.swtch);
              } 
          
              /* check if type A or bit A =1, xchgType is now a bit flag */
              if ((xchgType & TOXA) || (byte & 0x1))
              {
/* si029.220: Modification - added INDIA switch */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
                 if ((tCb->cfg.swtch == LSI_SW_ITU97) ||
                     (tCb->cfg.swtch == LSI_SW_ETSIV3) ||
                     (tCb->cfg.swtch == LSI_SW_ITU2000) ||
                     (tCb->cfg.swtch == LSI_SW_RUSS2000) ||
                     (tCb->cfg.swtch == LSI_SW_INDIA))
                 {        
                    /* check if broadband/narrowband interworking? If no, bit
                     * BCDE are checked. Otherwise, bit FG are checked.
                     */
                    if (!(xchgType & BRNBAND_ITWK))
                    {
                       if (siChkMsgCompInd(nCb, siCir, cgAdr, cicVal, mBuf, 
                            byte, xchgType) == MC_DROPMSG)
                          RETVALUE(MC_DROPMSG);
                    }
                    else
                    {
                       /* Only FG bits are checked */
                       switch (byte & CHKMC_BITS_F_G)
                       {
                          case BRN_DISCMSG: /* G = 0, F = 1 */
                             RETVALUE(MC_DROPMSG);
                          case BRN_PASSONMSG: /* G = 0, F = 0 */
                          case BRN_RESERVE: /* G = 1, F = 1 */
                             /* copy mBuf to uBuf, if NOK take default action */
                            if (SCpyMsgMsg(mBuf, tCb->pst.region, tCb->pst.pool, 
                                        &uBuf) != ROK)
                            {  
                                SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                                       "SCpyMsgMsg failed\n"));  
                                SNDCONF(nCb, intfid, cgAdr, TRUE, cicVal, 
                                        mBuf, causeDgn, siCir->opc, 
                                        tCb->cfg.swtch);
                            } 

                            if ((siCon = siCir->siCon) != NULLP)
                            {
                               SiUiSitUMsgInd(&tCb->pst, tCb->suId, 
                                              siCon->suInstId,
                                              siCon->key.k1.spInstId, 
                                              siCir->key.k1.cirId, uBuf);
                            }
                            else
                            {
                               SiUiSitUMsgInd(&tCb->pst, tCb->suId, 
                                              0, 0, siCir->key.k1.cirId,
                                              uBuf);
                            }

                            RETVALUE(MC_DROPMSG);
                            break;
                         case BRN_RELCALL: /* G = 1, F = 0 */
                            /* find connection pointer. If connection does not exist 
                               - get new connection and send release */
                            if ((siCon = siCir->siCon) == NULLP)
                            {  
                               siCon = siGetIncCon(siCir, nCb);
                               if (siCon == NULLP)
                               {
                                  SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                                         "     siGetIncCon   failed   \n"));  
                                  RETVALUE(MC_DROPMSG);
                               } 
                               /* si009.220 - Modified: to pass cic into 
                                * siGetLnkSel. 
                                */
                               /* si025.220: Modifications - modify the arguments in
                                * siGetLnkSel */
                               siGetLnkSel(nCb, &siCon->lnkSel,
                                           siCir->pIntfCb->cfg.swtch,
                                           siCir);
                               causeDgn->causeVal.val = SIT_CCNOMSGTYP;
                               siGenRelLw(siCir->cfg.cirId, siCon, causeDgn);
                               RETVALUE(MC_DROPMSG);
                            }
                            causeDgn->causeVal.val = SIT_CCNOMSGTYP;
                            siGenRelUpLw(siCir->cfg.cirId, siCon, causeDgn);
                            RETVALUE(MC_DROPMSG);
                            break;
                       } /* end of switch (byte & CHKMC_BITS_F_G) */
                    } /* end of else */
                 } /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETISV3 */    
                 else
#endif /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA */
                 {
                    if (siChkMsgCompInd(nCb, siCir, cgAdr, cicVal,
                                         mBuf, byte, xchgType) == MC_DROPMSG)
                       RETVALUE(MC_DROPMSG);
                 }               
              } /* end of TOXA or bit A */
              
              if (tCb->cfg.passOnFlag)
              {
                 /* copy mBuf to uBuf, if NOK take default action */
                 if (SCpyMsgMsg(mBuf, tCb->pst.region, tCb->pst.pool, 
                                &uBuf) != ROK)
                 {  
                    SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SCatMsg failed\n"));  
                    SNDCONF(nCb, intfid, cgAdr, TRUE, cicVal, mBuf, 
                              causeDgn, siCir->opc, tCb->cfg.swtch);
                 } 

                 if ((siCon = siCir->siCon) != NULLP)
                 {
                    SiUiSitUMsgInd(&tCb->pst, tCb->suId, 
                                 siCon->suInstId,
                                 siCon->key.k1.spInstId, 
                                 siCir->key.k1.cirId, 
                                 uBuf);
                 }
                 else
                 {
                    SiUiSitUMsgInd(&tCb->pst, tCb->suId, 
                              0, 0, siCir->key.k1.cirId,
                                    uBuf);
                 }
                 RETVALUE(MC_DROPMSG);
              }
              else
                 RETVALUE(MC_DROPMSG);

           }
           else
           {
              /* check if the next parameter is message compatibility */
              offset++;   /* go pass the parameter id */
              /* get parameter length */
              if (SExamMsg(&byte, mBuf, offset) != ROK)
              {  
                 SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SExamMsg failed\n"));  
                 SNDCONF(nCb, intfid, cgAdr, TRUE, cicVal, 
                         mBuf, causeDgn, siCir->opc, tCb->cfg.swtch);
              } 
              offset += (byte + 1);   /* go pass the parameter */
           }
        } /* end while */
        /* message compatability is not present, send CNF */
        SNDCONF(nCb, intfid, cgAdr, TRUE, cicVal, mBuf, causeDgn, 
               siCir->opc, tCb->cfg.swtch);
   } /* end switch */
   RETVALUE(ROK);
} /* End of siChkMsgComp */


/*
 *
 *      Fun  :  siChkifMsgExp
 *
 *      Desc :  Checks whether the specified message type is expected
 *              in the current call state
 *
 *      Ret  :  TRUE  - message is expected
 *              FALSE - message is not expected
 *
 *      Notes:  None
 *
 *      File :  ci_bdy5.c
 *
 */
#ifdef ANSI
PUBLIC Bool siChkifMsgExp
(
CirId cirId,            /* circuit Id */
SiCon *siCon,           /* connection block ptr */
U8    msgIdx            /* message index */
)
#else
PUBLIC Bool siChkifMsgExp(cirId, siCon, msgIdx)
CirId cirId;            /* circuit Id */
SiCon *siCon;           /* connection block ptr */
U8    msgIdx;           /* message index */
#endif
{
   TRC2(siChkifMsgExp);
  
   if (siCon == NULLP)
   {  
      SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "siCon is null\n"));  
      RETVALUE(TRUE);
   } 
   if (cirId == siCon->incC.cirId) 
      RETVALUE(siIncCompTbl[msgIdx][siCon->incC.conState]);
   else if (cirId == siCon->outC.cirId)
      RETVALUE(siOutCompTbl[msgIdx][siCon->outC.conState]);
   else
#if (ERRCLASS & ERRCLS_DEBUG)
   {
      SILOGERROR(ERRCLS_DEBUG, ESI633, (ErrVal) 0, 
                 "siChkifMsgExp() Failed, invalid circuit");
      RETVALUE(FALSE);
   }
#else
   RETVALUE(FALSE); 
#endif
} /* end of siChkifMsgExp */



/*
*
*       Fun:   siProcPauseCir
*
*       Desc:  Process the the CICs towards a PAUSEd DPC
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy5.c
*
*/
#ifdef ANSI
PRIVATE S16 siProcPauseCir 
(
SiNSAPCb  *nCb,
SiUpSAPCb *tCb,
SiIntfCb   *siIntfCb
)
#else
PRIVATE S16 siProcPauseCir (nCb, tCb, siIntfCb)
SiNSAPCb  *nCb;
SiUpSAPCb *tCb;
SiIntfCb   *siIntfCb;
#endif
{
   SiCauseDgn causeDgn;
   SiCirKey   key;
   SiCirCb    *cir;
   U16        idx;

   TRC2(siProcPauseCir)
   UNUSED(nCb);

   cmMemset((U8 *) &key, '\0', sizeof(SiCirKey));
   key.k3.intfId = siIntfCb->cfg.intfId;
   idx = 0;

   if (siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTRAN)
   {
      /* initialize cause diagnostic structure */
      cmMemset((U8 *) &causeDgn, (U8) NOTPRSNT, sizeof(SiCauseDgn));
      UPDATECAUSE(causeDgn, SIT_CCNETAOL, tCb);
   }
   cir = NULLP;
   while (1)
   {
      if (!cir)
      {
         siFindCir(&siCb.cirHlCp, &cir, &key, idx++, KEY_INTF);
         if (!cir)
            break;
      }
      else
         if (cmHashListGetNext(&siCb.cirHlCp.ihCp, (PTR) cir, 
               (PTR *) &cir) != ROK)
            break;
         else
            if (cir->cfg.intfId != siIntfCb->cfg.intfId)
               break;
      if (cir->siCon)
      {
         switch (siIntfCb->cfg.pauseActn)
         {
            case SI_PAUSE_CLRDFLT:
               cir->siCon->resDir = FROM_LWR;
               if (cir->siCon->incC.conPrcs)
                  cir->siCon->incC.relResp = FALSE;
               if (cir->siCon->outC.conPrcs)
                  cir->siCon->outC.relResp = FALSE;
               /* new i/f => reset has to always come from circuit fsm */
/* si023.220: modificatioN - reverse the change from si022.220 since there is 
 * the noRspFlgToLw = FALSE is removed in processing Reset Message in 
 * si_bdy4.c
 */
               cir->noRspFlgToLw = TRUE;
/* si045.220 CEI_RES changed to MI_RESCIR **/
               siProcCirMsg(cir, MI_RESCIR, TRUE);
               break;

            /* clone of FTZ behaviour */
            case SI_PAUSE_CLRTRAN:
               cir->siCon->resDir = FROM_LWR;
               /* if tcallcb is null then do not 
                  send relind to cc
               */
               if (!cir->siCon->tCallCb)
                  break;
               if ((cir->siCon->incC.conPrcs) &&
                   (cir->cfg.cirId == cir->siCon->incC.cirId))
               {
                  /* stable call if ST_ANSWRD */
                  if (cir->siCon->incC.conState != ST_ANSWRD)
                  {
                     cir->siCon->incC.toBeRelsd = TRUE;
                     siGenRelUp(cir->cfg.cirId, cir->siCon, &causeDgn);
                  }
               } 
               if ((cir->siCon) && (cir->siCon->outC.conPrcs) &&
                   (cir->cfg.cirId == cir->siCon->outC.cirId))
               {
                  if (cir->siCon->outC.conState != ST_ANSWRD)
                  {
                     cir->siCon->outC.toBeRelsd = TRUE;
                     siGenRelUp(cir->cfg.cirId, cir->siCon, &causeDgn);
                  }
               }
               break;

            case SI_PAUSE_CLRTMOUT:
               /* no action - PAUSE timer expiry will initiate 
                * appropriate release procedure. 
                */
               break;
         
            default:
               SIDBGP(SIDBGMASK_WARN,
                      (siCb.init.prntBuf, "dpc=%#lx, pauseAction=%#x invalid\n",
                       siIntfCb->cfg.intfId, siIntfCb->cfg.pauseActn)); 
#if (ERRCLASS & ERRCLS_INT_PAR)
               SILOGERROR(ERRCLS_INT_PAR, ESI634, (ErrVal) siIntfCb->cfg.intfId, 
                          "siProcPauseCir() Failed, Invalid PAUSE actn");
#endif
               break;
         } /* end switch */
      } /* end else */
   } /* end while */

   RETVALUE(ROK);
}/* siProcPauseCir */


/* si009.220, MODIFIED: change the function to public from private func */
/*
*
*       Fun:   siProcResumeCir
*
*       Desc:  Process circuits towards a RESUMEd DPC
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy5.c
*
*/
#ifdef ANSI
PUBLIC S16 siProcResumeCir 
(
SiNSAPCb  *nCb,
SiUpSAPCb *tCb,
SiIntfCb   *siIntfCb
)
#else
PUBLIC S16 siProcResumeCir (nCb, tCb, siIntfCb)
SiNSAPCb  *nCb;
SiUpSAPCb *tCb;
SiIntfCb   *siIntfCb;
#endif
{
   SiCauseDgn cause;
   SiCirKey   key;
   SiCirCb    *cir;
   S16        ret;
   U16        idx;
   U8       prevState;

   TRC2(siProcResumeCir)
   UNUSED(tCb);
   UNUSED(nCb);

   cmMemset((U8 *) &key, '\0', sizeof(SiCirKey));
   key.k3.intfId = siIntfCb->cfg.intfId;
   idx      = 0;

   cir = NULLP; 
   while (1)
   {
      if (!cir)
      {
         siFindCir(&siCb.cirHlCp, &cir, &key, idx++, KEY_INTF);
         if (!cir)
            break;
      }
      else
         if (cmHashListGetNext(&siCb.cirHlCp.ihCp, (PTR) cir, 
               (PTR *) &cir) != ROK)
            break;
         else
            if (cir->cfg.intfId != siIntfCb->cfg.intfId)
               break;

      {
         switch (siIntfCb->cfg.pauseActn)
         {
            /* call is cleared already */
            case SI_PAUSE_CLRDFLT:
               break;
            case SI_PAUSE_CLRTRAN:
            case SI_PAUSE_CLRTMOUT:
               /* If RSC is already sent then do not send REL . Let
                  RSC be resent at expiry of T17. 
               */
               if( (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK) ||
                   (cir->transStat[SICIR_HWLOCST] == SICIR_ST_WTRESACK))
                  continue;
               if (cir->siCon)
               {
                  /* initialize cause/diagnostic element */
                  MFINITELMT(&cir->siCon->mCallCb->mfMsgCtl, ret, 
                              NULLP, (ElmtHdr *) &cause,
                              &meCauseIndV, (U8) PRSNT_DEF, 
                              siIntfCb->cfg.swtch,
                              (U32) MF_ISUP);

                  cause.causeVal.pres = PRSNT_NODEF;
                  cause.causeVal.val = SIT_CCTMPFAIL;
                  if (cir->siCon->incC.rel != NULLP)
                  {
                     siDropMsg(cir->siCon->incC.rel);
                     cir->siCon->incC.rel = NULLP;
                  }
                  if (cir->siCon->outC.rel != NULLP)
                  {
                     siDropMsg(cir->siCon->outC.rel);
                     cir->siCon->outC.rel = NULLP;
                  }
                  prevState = (cir->siCon->incC.conPrcs) ? 
                              cir->siCon->incC.conState:
                                 cir->siCon->outC.conState;
                  if (cir->siCon->incC.conPrcs)
                  {
                     if (cir->siCon->incC.toBeRelsd)
                     {
                        siGenRelLw(cir->cfg.cirId, cir->siCon, &cause);
                        cir->siCon->incC.toBeRelsd = FALSE;
                        /* Scenario: pause, call in conv, relreq , resume
                           In this case on getting RLC from peer RelCfm is sent
                           to the CC
                        */
                        if ( prevState == ST_WTFORRELCMP )
                           cir->siCon->incC.relResp = TRUE;
                     }
                  }
                  if (cir->siCon->outC.conPrcs)
                  {
                     if (cir->siCon->outC.toBeRelsd)
                     {
                        siGenRelLw(cir->cfg.cirId, cir->siCon, &cause);
                        cir->siCon->outC.toBeRelsd = FALSE;
                        /* Scenario: pause, call in conv, relreq , resume
                           In this case on getting RLC from peer RelCfm is sent
                           to the CC
                        */
                        if ( prevState == ST_WTFORRELCMP )
                           cir->siCon->outC.relResp = TRUE;
                     }
                  }
               } /* if (cir->siCon) */
               break;

            default:
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                  "Undefined action %d on pause detected .\n",
                     siIntfCb->cfg.pauseActn)); 
#if (ERRCLASS & ERRCLS_INT_PAR)
               SILOGERROR(ERRCLS_INT_PAR, ESI635, (ErrVal) siIntfCb->cfg.intfId, 
                     "SiLiSntStaInd() Failed, Invalid PAUSE actn");
#endif
               break;
         }
      }
   }

   RETVALUE(ROK);
}/* siProcResumeCir */


/*
*
*       Fun:   siProcUpuCir
*
*       Desc:  Process circuits towards a DPC where the User Part is 
*              unavailable
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy5.c
*
*/
#ifdef ANSI
PRIVATE S16 siProcUpuCir 
(
SiNSAPCb  *nCb,
SiUpSAPCb *tCb,
SiIntfCb   *siIntfCb
)
#else
PRIVATE S16 siProcUpuCir (nCb, tCb, siIntfCb)
SiNSAPCb  *nCb;
SiUpSAPCb *tCb;
SiIntfCb   *siIntfCb;
#endif
{
   SiCirKey key;
   SiCirCb  *cir;

   TRC2(siProcUpuCir)
   UNUSED(tCb);
   UNUSED(nCb);

   cmMemset((U8 *) &key, '\0', sizeof(SiCirKey));
   key.k3.intfId = siIntfCb->cfg.intfId;
   cir = NULLP;

   while (1)
   {
      if (!cir)
      {
         siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_INTF);
         if (!cir)
            break;
      }
      else
         if (cmHashListGetNext(&siCb.cirHlCp.ihCp, (PTR) cir, 
               (PTR *) &cir) != ROK)
            break;
         else
            if (cir->cfg.intfId != siIntfCb->cfg.intfId)
               break;

      {
         if( ! cir->siCon ) 
            continue;
         cir->noRspFlgToLw = TRUE;
         siProcCirMsg(cir, CEI_RES, TRUE);
      }
   }

   RETVALUE(ROK);
}/* siProcUpuCir */


/*
*
*       Fun:   siProcIntfStatus
*
*       Desc:  Process status of a DPC within ISDN user part
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy5.c
*
*/
#ifdef ANSI
PUBLIC S16 siProcIntfStatus 
(
SiNSAPCb  *mCb,
SiUpSAPCb *tCb,
SiIntfCb   *siIntfCb,
Status    status,
Priority  priority
)
#else
PUBLIC S16 siProcIntfStatus (mCb, tCb, siIntfCb, status, priority)
SiNSAPCb  *mCb;
SiUpSAPCb *tCb;
SiIntfCb   *siIntfCb;
Status    status;
Priority  priority;
#endif
{
   SiCirCb   *cir;
   SiCirKey  key;
   SiAllSdus ev;
   Bool      sendInd;
   Bool      action;
   S16       (*func)(SiNSAPCb *, SiUpSAPCb *, SiIntfCb *);
   S16       ret;
   U8        staEvntType;
   U16       cause;

   TRC2(siProcIntfStatus)

   sendInd = FALSE;
   action  = FALSE;
   func = NULLP;

   /* si042.220 fixing a case of uninitialized circuit */
   /* find a circuit towards the DPC for generating status indication */
   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
   key.k3.intfId = siIntfCb->cfg.intfId;
   siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_INTF);
   
   /* indication can not be sent to application if upper SAP is unbound */
   if (tCb->state == SI_BND)
   {
      if (cir != NULLP)
      {
         sendInd = TRUE;
      }
   }

   /* generate status indication to call control */
   MFINITSDU(&tCb->mfMsgCtl, ret, (U8) 0, (U8) SI_STAREQ, (ElmtHdr *) NULLP,
             (ElmtHdr *) &ev, (U8) NOTPRSNT, siIntfCb->cfg.swtch, (U32) MF_ISUP);

   /* prepare an alarm to layer manager */
#if (SI_LMINT3 || SMSI_LMINT3)
   siInitUstaDgn(LSI_USTA_DGNVAL_INTF, (PTR) &siIntfCb->cfg.intfId,
                 LSI_USTA_DGNVAL_NONE, NULLP,
                 LSI_USTA_DGNVAL_NONE, NULLP,
                 LSI_USTA_DGNVAL_NONE, NULLP);
#endif
   switch (status)
   {
      case SN_PAUSE:
         /* generate alarm to layer manager */   
         SISNDOLDLSISTAIND(&siCb.init.lmPst, (SiInstId)siIntfCb->cfg.intfId, 
                           SIMTP_PAUSE);
#if (SI_LMINT3 || SMSI_LMINT3)
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE,
                        LSI_EVENT_MTP, LSI_CAUSE_PAUSE,
                        TRUE, (SiInstId)siIntfCb->cfg.intfId, SIMTP_PAUSE);
#endif
         switch (siIntfCb->state)
         {
            case SI_INTF_UNAVAIL:
               RETVALUE(ROK);

            default:
               siIntfCb->state = SI_INTF_UNAVAIL; 
               staEvntType    = SIT_STA_PAUSEIND;
               func           = siProcPauseCir;
               action         = TRUE;

               if ((siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTRAN) ||
                     (siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTMOUT))
                  siStartIntfTmr(TMR_PAUSE, siIntfCb);
#ifdef SNT2
               /* start the status enquiry timer */
               siStartIntfTmr(TMR_TSTAENQ, siIntfCb);
#endif
               break;
         }
         break;

      case SN_RESUME:
         siIntfCb->state = SI_INTF_AVAIL;
         func           = siProcResumeCir;
         action         = TRUE;
         staEvntType    = SIT_STA_RESUMEIND; 
         /* stop "wait before releasing all conns" timer */
         siStopIntfTmr(siIntfCb, TMR_PAUSE);
#ifdef SNT2
         siStopIntfTmr(siIntfCb, TMR_TSTAENQ);
#endif
         /* generate alarm to layer manager */
         SISNDOLDLSISTAIND(&siCb.init.lmPst, (SiInstId)siIntfCb->cfg.intfId, SIMTP_RESUME);
#if (SI_LMINT3 || SMSI_LMINT3)
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE,
                        LSI_EVENT_MTP, LSI_CAUSE_RESUME,
                        TRUE, (SiInstId)siIntfCb->cfg.intfId, SIMTP_RESUME);
#endif

#ifdef SI_PROVE
         /* start user part test timer */
         siStartIntfTmr(TMR_T4, siIntfCb);
         siIntfCb->t4Runing = TRUE;
          if (cir != NULLP)
         /* si009.220, MODIFIED: change the interface valid flag 
          * to FALSE, not checking the interface control block 
          * state in siGenCirMsg (siGenPdu) function
          */
         siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                     cir->phyDpc, FALSE, 
                     siIntfCb->cfg.swtch, M_USRPARTT, MI_USRPARTT, NULLP, 
                     siIntfCb->cfg.ssf, siIntfCb->cfg.nwId);
         SPrint("Send user part test message \n");

#endif
         break;

      case SN_CONG:
         /* generate alarm to layer manager */   
         SISNDOLDLSISTAIND(&siCb.init.lmPst, (SiInstId)siIntfCb->cfg.intfId, SIMTP_CONG);

         /* send error indicating to the upper layer */
         switch(priority)
         {
            case SN_PRI0:
               staEvntType    = SIT_STA_MTPCONG0;
               siIntfCb->state = SI_INTF_AVAIL;
               cause = LSI_CAUSE_CONG_LVL0;
               break;
            case SN_PRI1:
               staEvntType    = SIT_STA_MTPCONG1;
               siIntfCb->state = SI_INTF_CONG1;
               cause = LSI_CAUSE_CONG_LVL1;
               break;
            case SN_PRI2:
               staEvntType    = SIT_STA_MTPCONG2;
               siIntfCb->state = SI_INTF_CONG2;
               cause = LSI_CAUSE_CONG_LVL2;
               break;
            case SN_PRI3:
               staEvntType    = SIT_STA_MTPCONG3;
               siIntfCb->state = SI_INTF_CONG3;
               cause = LSI_CAUSE_CONG_LVL3;
               break;
            default:
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                      "Invalid priority value %#x \n", priority));  
              
               RETVALUE(RFAILED);
         }
         /* generate an alarm to layer manager for LMINT3 interface */
#if (SI_LMINT3 || SMSI_LMINT3)
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE,
                        LSI_EVENT_MTP, cause,
                        TRUE, (SiInstId)siIntfCb->cfg.intfId, SIMTP_CONG);
#endif
         break;

      case SN_STPCONG:
         staEvntType    = SIT_STA_MTPSTPCONG;
         siIntfCb->state = SI_INTF_AVAIL;
         func           = siProcResumeCir;
         action         = TRUE;
         /* generate alarm to layer manager */   
         SISNDOLDLSISTAIND(&siCb.init.lmPst, (SiInstId)siIntfCb->cfg.intfId, SIMTP_STPCONG);
#if (SI_LMINT3 || SMSI_LMINT3)
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE,
                        LSI_EVENT_MTP, LSI_CAUSE_STPCONG,
                        TRUE, (SiInstId)siIntfCb->cfg.intfId, SIMTP_STPCONG);
#endif
         break;

      case SN_RMTUSRUNAV:
         siIntfCb->state = SI_INTF_UNAVAIL; 
         staEvntType    = SIT_STA_RMTUSRUNAV;
         func           = siProcUpuCir;
         action         = TRUE;
         switch (siIntfCb->cfg.swtch)
         {
            case LSI_SW_ITU:
#ifdef SS7_ITU97
            case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
           case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
           case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
            case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
       case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
               /* priority = 1 , uneq remote user, in this case 
               * only management system should be informed.
               * Availability test procedures are not initiated
               * SNT_UPU_UNEQUIPPED = 1 */
               if (priority != SNT_USR_UNEQUIPPED)
               {
                  /* UPU w/cause=inaccessible remote user while
                     t4 is runing are ignored */
/* si007.220 -  to avoid calling siProcUpuCir repeatedly if t4Runing
 * flag is set into TRUE.
 */
                  if (siIntfCb->t4Runing)
                  {
                     action = FALSE;
                     break;
                  }                     
                  /* si009.220: MODIFIED: According to the Q764-1997 section 
                   * 2.13.2, when an UPU indication is received, calls in 
                   * progress need not be released. Therefore, change code 
                   * to handle the UPU smiliar as Pause indication, allow it 
                   * to have the options to release the calls
                   */
/* si029.220: Modification - added INDIA switch */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
                  if ((siIntfCb->cfg.swtch == LSI_SW_ITU97) ||
                     (siIntfCb->cfg.swtch == LSI_SW_ETSIV3) ||
                     (siIntfCb->cfg.swtch == LSI_SW_ITU2000) ||
                     (siIntfCb->cfg.swtch == LSI_SW_RUSS2000) ||
                     (siIntfCb->cfg.swtch == LSI_SW_INDIA))
                  {
                     /* overwrite the func to the same function for 
                      * processing Pause
                      */
                     func = siProcPauseCir;

                     if ((siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTRAN) ||
                          (siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTMOUT))
                        siStartIntfTmr(TMR_PAUSE, siIntfCb);
                  }
#endif
                  /* start user part test timer */
                  siStartIntfTmr(TMR_T4, siIntfCb);
                  siIntfCb->t4Runing = TRUE;
/* si052.220 - Addition: T4 Timer issue. While processing MTP3 status indication
               with UPU, interface state was not changed.When any message
               was received on that interface, timer T4 was not checked 
               because of wrong interface state.
*/
                  siIntfCb->state = SI_INTF_UNAVAIL;
                  
/* si004.220 - Modification. Modified code to deal with the situation that
 * variable cir is NULLP.
 */
                  if (cir != NULLP)
                     /* si009.220, MODIFIED: change the interface valid flag 
                      * to FALSE, not checking the interface control block 
                      * state in siGenCirMsg (siGenPdu) function
                      */
                     siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                                 cir->phyDpc, FALSE, 
                                 siIntfCb->cfg.swtch, M_USRPARTT, MI_USRPARTT, NULLP, 
                                 siIntfCb->cfg.ssf, siIntfCb->cfg.nwId);
                  /* generate alarm rmt user unavailable */
                  siInitUstaDgn(LSI_USTA_DGNVAL_INTF, (PTR) &siIntfCb->cfg.intfId, 
                                LSI_USTA_DGNVAL_NONE, NULLP, 
                                LSI_USTA_DGNVAL_NONE, NULLP, 
                                LSI_USTA_DGNVAL_NONE, NULLP);
                  SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                                 LSI_EVENT_USERPART, LSI_CAUSE_UNAVAILABLE,
                                 TRUE, (SiInstId)siIntfCb->cfg.intfId, SIMTP_RMTUSRUNAV);
               }
               else
               {
                  /* generate alarm rmt user unequipped */
                  siInitUstaDgn(LSI_USTA_DGNVAL_INTF, (PTR) &siIntfCb->cfg.intfId, 
                                LSI_USTA_DGNVAL_NONE, NULLP, 
                                LSI_USTA_DGNVAL_NONE, NULLP, 
                                LSI_USTA_DGNVAL_NONE, NULLP);
                  SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                                 LSI_EVENT_USERPART, LSI_CAUSE_UNEQUIPPED,
                                 TRUE, (SiInstId)siIntfCb->cfg.intfId, SI_UPU_UNEQUIPPED);
               }
               break;
            default:
               siIntfCb->state = SI_INTF_UNAVAIL;
               /* generate alarm to layer manager */
               siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                              LSI_USTA_DGNVAL_NONE, NULLP, 
                              LSI_USTA_DGNVAL_NONE, NULLP, 
                              LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, 0, 0, 0, FALSE, (SiInstId)siIntfCb->cfg.intfId, 
                              SIMTP_RMTUSRUNAV);
               break;
         }
         break;

      default:
         SIDBGP(SIDBGMASK_CERR,
                (siCb.init.prntBuf, "Invalid MTP-3 status %#x \n", status));  
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI636, (ErrVal) siIntfCb->cfg.intfId, 
                    "SiLiSntStaInd() Failed, invalid status event");
#endif
         siInitUstaDgn(LSI_USTA_DGNVAL_INTF, (PTR) &siIntfCb->cfg.intfId, 
                        LSI_USTA_DGNVAL_NONE, NULLP, 
                        LSI_USTA_DGNVAL_NONE, NULLP, 
                        LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_LI_INV_EVT, LSI_CAUSE_INV_EVNT, TRUE, 
                        (SiInstId)siIntfCb->cfg.intfId, SIMTP_EVTINV);
         RETVALUE(ROK);
   }

   if (sendInd == TRUE)
   {
#if SIT_PARAMETER
      if( status == SN_RESUME )
         SiUiSitStaInd(&tCb->pst, tCb->suId, 0, 0, cir->cfg.cirId, FALSE, 
                       staEvntType, &ev.m.siStaEvnt, NULLP);
      else
         SiUiSitStaInd(&tCb->pst, tCb->suId, 0, 0, cir->cfg.cirId, FALSE, 
                       staEvntType, &ev.m.siStaEvnt, NULLP);
         
#else
      SiUiSitStaInd(&tCb->pst, tCb->suId, 0, 0, cir->cfg.cirId, FALSE, 
                    staEvntType, &ev.m.siStaEvnt, NULLP);
#endif
   }

   if (action && (func != NULLP))
   {
      (*func)(mCb, tCb, siIntfCb);
   }
   RETVALUE(ROK);
}/* siProcIntfStatus */


/*
*
*       Fun:   siGenErrRelInd
*
*       Desc:  Generates release indication to service user when
*              an erroneous primitive is initiated from the user
*              
*       Ret:   ROK - ok; RFAILED - failed
*
*       Notes: This function is used to send release indications in case of
*              interface errors. The parameters used in the primitives (which
*              are the potential culprits for this problem - suId, suInstId,
*              spInstId, circuit) are passed 'AS IS' 
*              to the service user of ISUP. And if there is a non-NULL 
*              connection passed, in order to avoid primitive loss, release 
*              response timers are started, and call processing states are 
*              adjusted. The function of this function is to clean up the
*              interface primitive errors in an unforgiving manner.
*
*       File:  ci_bdy5.c
*
*/
#ifdef ANSI
PUBLIC S16 siGenErrRelInd
(
SiUpSAPCb *tCb,              /* post */
SiInstId  suInstId,          /* service user instance Id */
SiInstId  spInstId,          /* service provider instance Id */
CirId     circuit,           /* circuit Id */
SiCon     *con,              /* connection control block */
U8        causeVal           /* cause value */
)
#else
PUBLIC S16 siGenErrRelInd (tCb, suInstId, spInstId, circuit, con, 
                           causeVal)
SiUpSAPCb *tCb;              /* post */
SiInstId  suInstId;          /* service user instance Id */
SiInstId  spInstId;          /* service provider instance Id */
CirId     circuit;           /* circuit Id */
SiCon     *con;              /* connection control block */
U8        causeVal;          /* cause value */
#endif
{
   SiRelEvnt relEvnt;

   TRC2(siGenErrRelInd)

   /* error check - if SAP is inactive clear the connection internally 
    * usually this is checked in all the incoming primitives. but its
    * okay to double check */
   if (tCb->state != SI_BND)
   {
      if ((con != NULLP) && (con->incC.conPrcs == TRUE))
         siClearIncCon(con);

      if ((con != NULLP) && (con->outC.conPrcs == TRUE))
         siClearOutCon(con);

      RETVALUE(ROK);
   }

   cmMemset((U8 *) &relEvnt, (U8) NOTPRSNT, sizeof(SiRelEvnt));
   UPDATECAUSE(relEvnt.causeDgn, causeVal, tCb); 

   /* stop all the protocol related timers - let the protocol timer expiry 
      events and subsequent resets take care of cleaning up the mess */
   if (con != NULLP)
   {
      /* cancel all the timers */
      siStopConTmr(con, TMR_ALL);

      /* start the release response timers */
      siStartConTmr(TMR_TRELRSP, con, tCb);
      siStartConTmr(TMR_TFNLRELRSP, con, tCb);

      if (con->incC.conPrcs == TRUE)
         SISTATECHNG(con->incC.conState, ST_WTFORRELRSP);
      if (con->outC.conPrcs == TRUE)
         SISTATECHNG(con->outC.conState, ST_WTFORRELRSP);
   }

   /* increment layerwide error counter for abnormal releases */
#if (SI_LMINT3 || SMSI_LMINT3)
   siUpdErrSts(NULLP, LSI_STS_ABNRMLREL);
#endif

   /* send release indication */
   SiUiSitRelInd(&tCb->pst, tCb->suId, suInstId, spInstId, circuit,
                 &relEvnt, NULLP);
   RETVALUE(ROK);
} /* siGenErrRelInd */




/*
*
*       Fun:   siSanChkConEvtCkts
*
*       Desc:  Sanity check of each circuit for both single rate call and 
*              non-single rate call in outgoing connection.
*
*       Ret:   ROK      - ok
*              RFAILED  - not ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siSanChkConEvtCkts
(
SiConEvnt *siConEvnt,          /* connect event */
SiUpSAPCb *tCb,                /* upper SAP control block */
SiCirCb   *ctrlCir,            /* controlling circuit cb */
SiCirCb   *cir,                /* affected circuit cb */
SiAllSdus *ev,                 /* pointer to SDU structure */
SiInstId  suInstId,            /* service user instance id */
SiInstId  spInstId             /* service provider instance id */
)
#else
PUBLIC S16 siSanChkConEvtCkts(siConEvnt, tCb, ctrlCir, cir, ev, suInstId, spInstId)
SiConEvnt *siConEvnt;          /* connect event */
SiUpSAPCb *tCb;                /* upper SAP control block */
SiCirCb   *ctrlCir;            /* controlling circuit cb */
SiCirCb   *cir;                /* affected circuit cb */
SiAllSdus *ev;                 /* pointer to SDU structure */
SiInstId  suInstId;            /* service user instance id */
SiInstId  spInstId;            /* service provider instance id */
#endif
{
   S16      ret;
   CirId    cntrlCirId;        /* controlling circuit Id */
   CirId    circuit;           /* affected circuit Id */

   TRC2(siSanChkConEvtCkts)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (tCb == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "Upper SAP control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI640, (ErrVal) 0, 
                 "siSanChkConEvtCkts() Failed, pointer to upper SAP missing");
      RETVALUE(RFAILED);
   }
   if (siConEvnt == NULLP)
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "siConEvnt pointer missing\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI641, (ErrVal) 0, 
                 "siSanChkConEvtCkts() Failed, pointer to siConEvnt missing");
      RETVALUE(ROK);
   }
   if (ctrlCir == NULLP)
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "controlling circuit control block pointer missing\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI642, (ErrVal) 0, 
                 "siSanChkConEvtCkts() Failed, pointer to controll circuit missing");
      RETVALUE(RFAILED);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "no circuit control block\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI643, (ErrVal) 0, 
                 "siSanChkConEvtCkts() Failed, pointer to circuit missing");
      RETVALUE(RFAILED);
   }
#endif

   /* get the circuit Id code */
   cntrlCirId = ctrlCir->cfg.cirId;      /* controlling circuit ID */
   circuit = cir->cfg.cirId;          /* affected circuit ID */

   /* Sanity check for each circuit involved */
   if (cir->cfg.typeCntrl == INCOMING)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
             "connection attempt on incoming circuit\n")); 

      /* send reattempt indication to the upper layer on the controlling 
       * circuit
       */
      cmMemset((U8 *)ev, (U8)NOTPRSNT, sizeof(SiStaEvnt));
      UPDATECAUSE(ev->m.siStaEvnt.causeDgn, SIT_CCREQUNAVAIL, tCb);
      SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId, cntrlCirId, 
                    FALSE, SIT_STA_REATTEMPT, &(ev->m.siStaEvnt), NULLP);
      RETVALUE(RFAILED);
   }
   else
   {
      {   
         if ((cir->siCon != NULLP) && (cir->siCon->outC.conPrcs))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "Active connection (state = %#x) exists on the ckt\n",
                    cir->siCon->outC.conState)); 

            /* Generate Alarm to Layer management on the affected circuit */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_NONE, NULLP,
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_BUSY, TRUE, 
                           circuit, SI_ALRM_RESOURCE_BUSY);

            /* Generate and send release indication to upper layer on ctrl ckt */
            siGenErrRelInd(tCb, suInstId, spInstId, cntrlCirId, NULLP, 
                           SIT_CCREQUNAVAIL);
            RETVALUE(RFAILED);
         }
      }   
   }

   switch (tCb->cfg.swtch)
   {
#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
       case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         /* local blocking conditions needs to be removed, connection
            request shall be processed */
         if (((cir->transStat[SICIR_MTLOCST] > SICIR_ST_IDLE) && 
              (cir->transStat[SICIR_MTLOCST] < SICIR_ST_WTRESACK)) ||
             ((cir->transStat[SICIR_HWLOCST] > SICIR_ST_IDLE) &&
              (cir->transStat[SICIR_HWLOCST] < SICIR_ST_WTRESACK)) )
         {
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                     "O/g connection attempt, idling local states=(%#x, %#x)\n",
                     cir->transStat[SICIR_MTLOCST], 
                     cir->transStat[SICIR_HWLOCST])); 
            siStopAllCirTmr(cir); /* stop the running blk/unblk timers */
            SISTATECHNG(cir->transStat[SICIR_MTLOCST], SICIR_ST_IDLE)
            SISTATECHNG(cir->transStat[SICIR_HWLOCST], SICIR_ST_IDLE)
         }

         /* if circuit is in WTRESACK state, reattempt the call */
         if ((cir->transStat[SICIR_HWLOCST] == SICIR_ST_WTRESACK) ||
             (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK))
         {
            /* initialize Status Event */
            MFINITSDU(&tCb->mfMsgCtl, ret, (U8) 0, (U8) SI_STAREQ,
                      (ElmtHdr *) NULLP, (ElmtHdr *) ev, (U8) NOTPRSNT,
                      tCb->cfg.swtch, (U32) MF_ISUP);
            ev->m.siStaEvnt.causeDgn.eh.pres = PRSNT_NODEF;
            ev->m.siStaEvnt.causeDgn.causeVal.pres = PRSNT_NODEF;
            ev->m.siStaEvnt.causeDgn.causeVal.val = SIT_CCREQUNAVAIL;
         
            /* send reattempt indication to the upper layer */
            SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                          circuit, FALSE, SIT_STA_REATTEMPT, 
                          &(ev->m.siStaEvnt), NULLP);
            RETVALUE(RFAILED);
         }

         /* send failure indication if remotely blocked or 
            invalid conn state */
         /* Even if calling party category is not present then
            let call be failed due to missing mandatory parameters
          */
         if ((siConEvnt->cgPtyCat.cgPtyCat.pres == NOTPRSNT ) ||
              ( siConEvnt->cgPtyCat.cgPtyCat.val != CAT_TEST))
            if ((cir->transStat[SICIR_MTREMST] != SICIR_ST_IDLE) ||
                (cir->transStat[SICIR_HWREMST] != SICIR_ST_IDLE) ||
                ((cir->calProcStat != CALL_IDLE) && (!cir->siCon))) 
            {                     
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Remote blocking states (%#x, %#x), call proc state %#x\n",
                      cir->transStat[SICIR_MTREMST], 
                      cir->transStat[SICIR_HWREMST],
                      cir->calProcStat)); 

               /* Generate Alarm to Layer management on the affected circuit */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                             LSI_USTA_DGNVAL_NONE, NULLP,
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, LSI_CAUSE_RMT_BLKED, TRUE, 
                              circuit, SI_ALRM_RESOURCE_BLKD);

               /* Generate and send release indication to upper layer on ctrl 
                * ckt 
                */
               siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                              SIT_CCREQUNAVAIL);
               RETVALUE(RFAILED);
            } 

         /* now check the call processing status */
         if (cir->calProcStat != CALL_IDLE) 
         {
            /* If an incoming IAM has been recvd, then even if
               this circuit is controlling circuit, send a reat
               to CC. This is b'coz its a collision between ISUP
               and CC. Dual seizure cases are handled when collision
               of IAM occurs on the line */ 
            if (cir->siCon->incC.conPrcs) 
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Incoming call detected. Reattempt ind to CC\n"));
/* si003.220 Addition. Added code to initialize Status Event.
 */
               /* initialize Status Event */
               MFINITSDU(&tCb->mfMsgCtl, ret, (U8) 0, (U8) SI_STAREQ,
                         (ElmtHdr *) NULLP, (ElmtHdr *) ev, (U8) NOTPRSNT,
                         tCb->cfg.swtch, (U32) MF_ISUP);
               ev->m.siStaEvnt.causeDgn.eh.pres       = PRSNT_NODEF;
               ev->m.siStaEvnt.causeDgn.causeVal.pres = PRSNT_NODEF;
               ev->m.siStaEvnt.causeDgn.causeVal.val  = SIT_CCREQUNAVAIL;
               /* send error indicatin to the upper layer */
               SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                             cntrlCirId, FALSE, SIT_STA_REATTEMPT, 
                             &(ev->m.siStaEvnt), NULLP);
               RETVALUE(RFAILED);
            }
         }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* check if the circuit involved in another non-single rate call */
         if (cir->ctrlMultiRateCir != NULLP)     
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                 "Active non-single rate connection exists on the ckt\n")); 

            /* Generate Alarm to Layer management on affected ckt */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_NONE, NULLP,
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_BUSY, TRUE, 
                           circuit, SI_ALRM_RESOURCE_BUSY);

            /* Generate and send release indication to upper layer on 
             * cntrl ckt
             */
            siGenErrRelInd(tCb, suInstId, spInstId, cntrlCirId, NULLP, 
                           SIT_CCREQUNAVAIL);
            RETVALUE(RFAILED);

         }
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
         break;
 
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI644, (ErrVal) tCb->cfg.swtch, 
                    "siSanChkConEvtCkts() Failed, invalid swtch type");
#endif
         SISNDOLDLSISTAIND(&siCb.init.lmPst, (CirId)suInstId, SIISAP_INV);
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);

} /* end of siSanChkConEvtCkts */


/*
*
*       Fun:   siSanChkIAMCkts
*
*       Desc:  Sanity check of each circuit for both single rate call and 
*              non-single rate call when receiving IAM msg from nw. 
*
*       Ret:   ROK      - ok
*              RFAILED  - not ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siSanChkIAMCkts
(
SiCon     *con,                /* connection cb */
SiCirCb   *cir,                /* affected circuit cb */
SiAllSdus *ev                  /* pointer to SDU structure */
)
#else
PUBLIC S16 siSanChkIAMCkts(con, cir, ev)
SiCon     *con;                /* connection cb */
SiCirCb   *cir;                /* affected circuit cb */
SiAllSdus *ev;                 /* pointer to SDU structure */
#endif
{

   S16    ret;                 /* return value */

   TRC2(siSanChkIAMCkts)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "connection pointer missing\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI645, (ErrVal) 0, 
                 "siSanChkIAMCkts() Failed, pointer to conn missing");
      RETVALUE(RFAILED);
   }

   if (siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif
   
   if (con->pduSp->m.initAddr.cgPtyCat.cgPtyCat.val != CAT_TEST)
   {
      /* unblock remote states if blocked */
      /* if it is unequipped then also on getting IAM from remote
         end state should be made equipped.
      */
      if((cir->transStat[SICIR_MTREMST] != SICIR_ST_WTRESRSP) ||
          (cir->transStat[SICIR_HWREMST] != SICIR_ST_WTRESRSP))
      {
         if ((cir->transStat[SICIR_MTREMST] != SICIR_ST_IDLE) ||
             (cir->transStat[SICIR_HWREMST] != SICIR_ST_IDLE))
         {
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                   "Unblocking remotely bloked states\n"));  

            cir->transStat[SICIR_MTREMST] = SICIR_ST_IDLE;
            cir->transStat[SICIR_HWREMST] = SICIR_ST_IDLE;
            /* At this point we have received normal IAM on a blocked
             * circuit. So, we have to unblock this circuit and generate
             * SitStaInd to the service user to indicate that the circuit
             * has been unblocked. In response to this SitStaInd, service
             * user may generate SitStaReq to ISUP to notify ISUP that
             * it can complete the unblocking procedure and send out UBA.
             * However, because of the fact that we have unblocked the
             * circuit on reception of normal IAM not UBL, we should not
             * be sending out UBA message. We can avoid sending UBA message
             * in two ways:
             *
             * o By changing the circuit state to IDLE, or
             * o By setting cir->noRspFlgToLw to TRUE.
             *
             * We must change the circuit state to IDLE as we have received
             * normal IAM. So, setting cir->noRspFlgToLw flag to TRUE is
             * redundant. Moreover, if we set this flag to TRUE at this
             * point, we may not be able to send future circuit maintenance
             * messages to peer, lest we set it to FALSE on receiving
             * SitCnStReq primitive from service user to send out ACM
             * message. Reseting this flag on receiving SitCnStReq primitive
             * would likely interfere with other procedures. So, we are
             * taking the safer approach of not setting cir->noRspFlgToLw
             * to TRUE.
             */
             siGenCirEvt(cir, SIT_STA_CIRUBLIND);
         }
      }
      /* generate UCIC if locally unequipped */
      if (cir->transStat[SICIR_MTLOCST] == SICIR_ST_UNEQPD)
      { 
         /* validate the unequipped local states */
         if (cir->transStat[SICIR_HWLOCST] != SICIR_ST_UNEQPD)
         {
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & cir->key.k1.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERNAL, 
                           LCM_EVENT_INV_STATE, LSI_CAUSE_CIC_STATE_MISMATCH, 
                           TRUE, cir->key.k1.cirId, SI_CIR_STOUTSYNC);
         }
         else
         { 
            /* generate UCIC */
            {
               siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                           cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                           M_UNEQUIPCIC, MI_UNEQUIPCIC, NULLP, 
                           cir->pIntfCb->cfg.ssf, con->mCallCb->cfg.nwId);
            }
            RETVALUE(RFAILED);
         }
      }
      /* generate block if locally M-blocked */
      if ((cir->transStat[SICIR_MTLOCST] > SICIR_ST_IDLE) && 
          (cir->transStat[SICIR_MTLOCST] < SICIR_ST_WTUBLACK))
      {
         SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                   "Locally Mntce blocked. Generating block\n"));  
         /* blocking procedure will clear the connection */
         cir->noRspFlgToUp = TRUE;
         siProcCirEvt(cir, SIT_STA_CIRBLOREQ, FALSE);
         RETVALUE(RFAILED);
      }
      {
         /* generate a CGB if locally H-blocked */
         if ((cir->transStat[SICIR_HWLOCST] > SICIR_ST_IDLE) && 
             (cir->transStat[SICIR_HWLOCST] < SICIR_ST_WTUBLACK))
         {
            /* Return BLO in case of H-blocked
             * for ANS92,  ANS95 and Bellcore variants. Please refer to 
             * T1.113.4(1992, 1995) section 2.8.2.3 point 14) and
             * GR-317 (1997) section 3.1.4.3A R3-163 and section 3.1.4.3B
             * CR3-167
             */

            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "Locally HW block. Generating CGB\n"));  
            /* initialize status event */
            MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) SI_STAREQ, 
                      (ElmtHdr *) NULLP, (ElmtHdr *) &(ev->m.siStaEvnt), 
                      (U8) NOTPRSNT, con->tCallCb->cfg.swtch, (U32) MF_ISUP);
            /* supervisory indicators */
            ev->m.siStaEvnt.cgsmti.eh.pres       = PRSNT_NODEF;
            ev->m.siStaEvnt.cgsmti.typeInd.pres  = PRSNT_NODEF;
            ev->m.siStaEvnt.cgsmti.typeInd.val   = HARDFAIL;
            /* range and status fields */
            ev->m.siStaEvnt.rangStat.eh.pres     = PRSNT_NODEF;
            ev->m.siStaEvnt.rangStat.range.pres  = PRSNT_NODEF;
            ev->m.siStaEvnt.rangStat.range.val   = 0x01;
            ev->m.siStaEvnt.rangStat.status.pres = PRSNT_NODEF;
            ev->m.siStaEvnt.rangStat.status.len  = 0x01;
            ev->m.siStaEvnt.rangStat.status.val[0]  = 0x01;
            cir->sduSp = (SiAllSdus *)&(ev->m.siStaEvnt);
            /* process circuit group event - this will clear the connection */
            siProcCirGrEvt(cir, SIT_STA_CGBREQ, (SiStaEvnt *)&(ev->m.siStaEvnt));
            /* incoming connection request failed */
            RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
} /* end of siSanChkIAMCkts */

/*
*
*       Fun:   siChkContin 
*
*       Desc:  Checks the action required regarding stopping continuity
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siChkContin
(
SiCon *con 
)
#else
PUBLIC S16 siChkContin(con)
SiCon *con;
#endif
{
   SiCirCb    *cir;

   TRC2(siChkContin)
   cir = con->outC.cir;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "connection ctrl block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI646, (ErrVal) 0, 
                 "siOutE37SND() Failed, pointer to con cb  missing");
      RETVALUE(ROK);
   }

   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI306, (ErrVal) 0, 
                 "siChkContin() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif
   /* Status Indication to Upper Layer to stop continuity check */
   switch (con->outC.conState)
   {
      case ST_IDLE:
      case ST_WTFORCONTIN:
      /* For ANSI 88 & ANSI 92 & ANS95, stopping TMR_TTCRO when sending
       * a status indication to upper layer to stop continuity
       */

         SiUiSitStaInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
            con->key.k1.spInstId, con->outC.cirId, FALSE, 
            SIT_STA_STPCONTIN, NULLP, NULLP);
         break;

      default:
         break;
   }
   RETVALUE(ROK);
} /* end of siChkContin */


/*
*
*       Fun:   siSelectCirCon
*
*       Desc:  Find the incoming/outgoing circuit connection  
*
*       Ret:   pointer of the circuit connection
*              NULLP   - error
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC CirCon *siSelectCirCon
(
SiCon      *siCon,            /* connection control block */     
CirId      cirId              /* cir Id of the circuit attached the conn. */
)
#else
PUBLIC CirCon *siSelectCirCon(siCon, cirId)
SiCon      *siCon;            /* connection control block */     
CirId      cirId;             /* cir Id of the circuit attached the conn. */
#endif
{
/* si003.220 - Modification. Modified code to fix a compiling error.
 */
   CirCon  *cirConPtr;       /* circuit connection ptr */

   TRC2(siSelectCirCon)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siCon == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "the conn control block pointer missing.\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI647, (ErrVal) 0, 
                 "siSelectCirCon() Failed, pointer to conn missing");
      RETVALUE(NULLP);
   }
#endif

   cirConPtr = NULLP;

   /* Find the incoming/outgoing circuit connection block */
   if ((siCon->incC.conPrcs) && (siCon->incC.cirId == cirId)) 
      cirConPtr = &(siCon->incC);
   else
   {
      if ((siCon->outC.conPrcs) && (siCon->outC.cirId == cirId))
         cirConPtr = &(siCon->outC);
   }      

   RETVALUE(cirConPtr);

} /* end of siSelectCirCon */


#if (ERRCLASS & ERRCLS_DEBUG)
/*
*
*       Fun:   siChkCirIntf
*
*       Desc:  This function checks the circuit and cir->intfCb pointers
*
*       Ret:   ROK     - ok
*              RFAILED - failure
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siChkCirIntf
(
SiCirCb *cir                         /* circuit control block */
)
#else
PUBLIC S16 siChkCirIntf(cir)
SiCirCb *cir;                        /* circuit control block */           
#endif
{
   TRC2(siChkCirIntf)

   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "Circuit pointer missing in siChkCirIntf(). \n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI648, (ErrVal) 0, 
         "siChkCirIntf() Failed, circuit pointer missing");
      RETVALUE(RFAILED);
   }
   if (cir->pIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
       "Interface control block pointer on circuit missing; (cirId = %#lx)\n",
       cir->cfg.cirId));  

      SILOGERROR(ERRCLS_DEBUG, ESI649, (ErrVal) 0, 
         "siChkCirIntf() Failed, Interface control block pointer missing");
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of siChkCirIntf */
#endif 


#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
/*
*
*       Fun:   siChkMRateCon
*
*       Desc:  Process each affected circuit if the call is a outgoing 
*              multirate or N*64 kbits/s connection
*
*       Ret:   ROK      - ok
*              RFAILED  - not ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siChkMRateCon
(
SiConEvnt *siConEvnt,          /* connect event */
SiUpSAPCb *tCb,                /* upper SAP control block */
SiCirCb   *cir,                /* controlling circuit cb */
SiAllSdus *ev,                 /* pointer to SDU structure */
SiInstId  suInstId,            /* service user instance id */
SiInstId  spInstId             /* service provider instance id */
)
#else
PUBLIC S16 siChkMRateCon(siConEvnt, tCb, cir, ev, suInstId, spInstId)
SiConEvnt *siConEvnt;          /* connect event */
SiUpSAPCb *tCb;                /* upper SAP control block */
SiCirCb   *cir;                /* controlling circuit cb */
SiAllSdus *ev;                 /* pointer to SDU structure */
SiInstId  suInstId;            /* service user instance id */
SiInstId  spInstId;            /* service provider instance id */
#endif
{
   S16      ret;
   SiCirCb  *mRateCirPtrs[SI_MAX_NO_OF_CIR]; 
                               /* the ptrs of affected CirCb */
   Bool     contiMRateCall;    /* contiguous non-single rate call */    
   SiCirCb  *mRateCir;         /* affected cir control block */
   U8       multiplier;        /* num of affected circuits */
   U8       transRate;         /* info transfer rate/trans med req*/ 
   U8       i;                 /* counter */
   CirId    cntrlCirId;        /* controlling(1st) circuit Id */
   U8       maxNumCir;         /* max num of affected circuits */
   U32      mapVal;            /* map format value */
   U16      causeVal;          /* cause value */
   Cic      nullCirCic;        /* unequipped circuit Cic */

   TRC2(siChkMRateCon)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (tCb == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "Upper SAP control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI650, (ErrVal) 0, 
                 "siChkMRateCon() Failed, pointer to upper SAP missing");
      RETVALUE(RFAILED);
   }
   if (siConEvnt == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "siConEvnt pointer missing\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI651, (ErrVal) 0, 
                 "siChkMRateCon() Failed, pointer to siConEvnt missing");
      RETVALUE(RFAILED);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "no controlling circuit control block\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI652, (ErrVal) 0, 
                 "siChkMRateCon() Failed, pointer to circuit missing");
      RETVALUE(RFAILED);
   }
#endif

   /* initialize the variable */
   contiMRateCall = TRUE;
   for (i = 0; i < SI_MAX_NO_OF_CIR; i++)
     mRateCirPtrs[i] = NULLP;

   mRateCir = NULLP;
   cntrlCirId = cir->cfg.cirId;
   transRate = 0;
   mapVal = 0;
   maxNumCir = 0;
   multiplier = 0;
   causeVal = 0;
   nullCirCic = 0;

   /* Get the required info for the further processing. Set the flow direction 
    * to TRUE (from upper). 
    */
   ret = siGetMRateInfo(cir->siCon, siConEvnt, cir, &transRate, &multiplier, 
                        &maxNumCir, &mapVal, &contiMRateCall, TRUE);
   if (ret == RNA)
   {
      /* means the map type is invalid, release the call */
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
             "siGetMRateInfo() return failed\n")); 

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cntrlCirId, 
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_UNEX_CAM, TRUE, 
                     cntrlCirId, SI_ALRM_NOCIRTO_ROUTE);

      siGenErrRelInd(tCb, suInstId, spInstId, cntrlCirId, NULLP, 
                     SIT_CCPROTERR);
      RETVALUE(RFAILED);
   }

   if (ret == RFAILED)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "siGetMRateInfo return failed \n"));
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI653, (ErrVal) 0,
                 "siChkMRateCon() Failed, fetch info failed.");
#endif
      RETVALUE(RFAILED);
   }
   
   /* select the affected circuits and store them in mRateCirPtrs */
   ret = siValMRateCkt(cir, tCb->cfg.swtch, maxNumCir, mapVal, transRate,
                       contiMRateCall, mRateCirPtrs, multiplier, 
                       &causeVal, &nullCirCic);

   if (ret == RFAILED)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
             "siValMRateCkt() failed\n")); 

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cntrlCirId, 
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, causeVal, TRUE, 
                     cntrlCirId, SI_ALRM_NOCIRTO_ROUTE);

      if (causeVal == LSI_CAUSE_INV_CIRCUIT)
         siGenErrRelInd(tCb, suInstId, spInstId, cntrlCirId, NULLP, 
                        SIT_CCBCAPNOTIMP);
      else               
         siGenErrRelInd(tCb, suInstId, spInstId, cntrlCirId, NULLP, 
                     SIT_CCPROTERR);
      RETVALUE(RFAILED);
   }

   if (ret == RNA)
   {
      /* return here, do not sent the alarm */
      RETVALUE(RFAILED);
   }

   /* Sanity check for each affected circuit */
   for (i = 0; i < multiplier - 1; i++)
   {
      /* controlling circuit is already processed */
      mRateCir = mRateCirPtrs[i+1];
      ret = siSanChkConEvtCkts(siConEvnt, tCb, cir, mRateCir, ev, suInstId, spInstId);

      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "Sanity check for non-controlling circuit failed\n")); 
         RETVALUE(RFAILED);
      }
   }

   RETVALUE(ROK);
} /* end of siChkMRateCon */


/*
*
*       Fun:   siGetNumCkts
*
*       Desc:  Get the number of affected circuits if the call is a multirate
*              or N*64 kbits/s connection
*
*       Ret:   ROK      - ok
*              ROKDNA  -  ok, data not available ( value of N)
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGetNumCkts
(
Swtch swtch,
U8    transRate,
U8    *num
)
#else
PUBLIC S16 siGetNumCkts(swtch, transRate, num)
Swtch swtch;
U8    transRate;
U8    *num;
#endif
{
   S16 ret;
   
   TRC2(siGetNumCkts)

   ret = ROK;           
           
   switch (swtch)
   {
#ifdef SS7_ITU97 
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         switch (transRate)
         {
            case TMR_2X64KBITS:
               *num = 2;
               break;
            case TMR_384KBITS:
               *num = 6;
               break;
            case TMR_1536KBITS:
               *num = 24;
               break;
            case TMR_1920KBITS:
               *num = 25;
               break;
            case TMR_3X64KBITS:
               *num = 3;
               break;
            case TMR_4X64KBITS:
               *num = 4;
               break;
            case TMR_5X64KBITS:
               *num = 5;
               break;
            case TMR_7X64KBITS:
               *num = 7;
               break;
            case TMR_8X64KBITS:
               *num = 8;
               break;
            case TMR_9X64KBITS:
               *num = 9;
               break;
            case TMR_10X64KBITS:
               *num = 10;
               break;
            case TMR_11X64KBITS:
               *num = 11;
               break;
            case TMR_12X64KBITS:
               *num = 12;
               break;
            case TMR_13X64KBITS:
               *num = 13;
               break;
            case TMR_14X64KBITS:
               *num = 14;
               break;
            case TMR_15X64KBITS:
               *num = 15;
               break;
            case TMR_16X64KBITS:
               *num = 16;
               break;
            case TMR_17X64KBITS:
               *num = 17;
               break;
            case TMR_18X64KBITS:
               *num = 18;
               break;
            case TMR_19X64KBITS:
               *num = 19;
               break;
            case TMR_20X64KBITS:
               *num = 20;
               break;
            case TMR_21X64KBITS:
               *num = 21;
               break;
            case TMR_22X64KBITS:
               *num = 22;
               break;
            case TMR_23X64KBITS:
               *num = 23;
               break;
            case TMR_25X64KBITS:
               *num = 25;
               break;
            case TMR_26X64KBITS:
               *num = 26;
               break;
            case TMR_27X64KBITS:
               *num = 27;
               break;
            case TMR_28X64KBITS:
               *num = 28;
               break;
            case TMR_29X64KBITS:
               *num = 29;
               break;
#if (ERRCLASS & ERRCLS_DEBUG)
            default:
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "trans med req is invalid %d\n", transRate));
               SILOGERROR(ERRCLS_DEBUG, ESI655, (ErrVal) 0,
                      "siGerNumCkts() Failed, invalid trans med req");
               RETVALUE(RFAILED);
#endif
         }         
         break;
#endif
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "swtch is not ans95/itu97/etsi v3, invalid %d\n", 
                    swtch));
         SILOGERROR(ERRCLS_DEBUG, ESI656, (ErrVal) 0,
                 "siGetNumCkts() Failed, invalid configuration swtch");
         RETVALUE(RFAILED);
#endif
   }           
   RETVALUE (ret);

} /* end of siGetNumCkts */


/*
*
*       Fun:   siChkMRateCtrlCkts
*
*       Desc:  check if the message received on a non-controlling circuit
*              from network. 
*              Take the actions base on the message type and variant type.
*
*       Ret:   ROK      - ok
*              RFAILED  - not ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siChkMRateCtrlCkts
(
SiCirCb   *cir,                          /* circuit control block */
SiAllPdus *msg,                          /* pointer to AllPdus structure */
U8        msgIdx                         /* message index */
)
#else
PUBLIC S16 siChkMRateCtrlCkts(cir, msg, msgIdx)
SiCirCb   *cir;                          /* circuit control block */
SiAllPdus *msg;                          /* pointer to AllPdus structure */
U8        msgIdx;                        /* message index */
#endif
{
   SiCon     *ctrlCon;
   U8        genCtrlRscFlg;
   S16       ret;
   SiNSAPCb  *cb;
   LnkSel    lnkSel;

   TRC2(siChkMRateCtrlCkts)

#if (ERRCLASS & ERRCLS_DEBUG)
   /* check the cir and cir->pIntfCb pointer */
   if (siChkCirIntf(cir) != ROK)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "no controlling circuit control block or no interface cb ptr\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI657, (ErrVal) 0, 
                 "siChkMRateCtrlCkts() Failed, \
                 pointer to cntrl circuit or interface cb missing");
      RETVALUE(RFAILED);
   }
   
   if (cir->ctrlMultiRateCir == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "circuit is not involved in a non-single rate call\n"));
      SILOGERROR(ERRCLS_DEBUG, ESI658, (ErrVal) 0,
                 "siChkMRateCtrlCkts() Failed, circuit is not involved in a non-single rate call");
      RETVALUE(RFAILED);
   }
#endif

   genCtrlRscFlg = 0;

   /* check if msg received on the non-controlling circuit, if so, take
    * the action base on the msg type and variant type
    */
   if (cir->ctrlMultiRateCir != cir)
   {
      /* get pointer of lower sap control block */
      cb = siGetMCbPtr(cir->pIntfCb->cfg.nwId, cir->pIntfCb->cfg.ssf);

      /* get link selection value */
      /* si025.220: Modification - modify the arguments in siGetLnkSel */
      /* si009.220 - Modified: to pass cic into siGetLnkSel. */
      siGetLnkSel(cb, &lnkSel, cir->pIntfCb->cfg.swtch, cir);

      /* message received on a non-controlling circuit. 
       * Check the message type. If it is a connection related message, 
       * get the connection block
       */
      switch (msgIdx)
      {
         case MI_BLOCK:
         case MI_BLOCKACK:
         case MI_UNBLK:
         case MI_UNBLKACK:
         case MI_RESCIR:
         case MI_UNEQUIPCIC:
         case MI_CIRGRPQRY:
         case MI_CIRGRPQRYRES:
         case MI_CIRGRPBLK:
         case MI_CIRGRPBLKACK:
         case MI_CIRGRPUBLK:
         case MI_CIRGRPUBLKACK:
         case MI_CIRGRPRES:
         case MI_CIRGRPRESACK:
         case MI_USRPARTA:
         case MI_USRPARTT:
         case MI_CIRVALRSP:
         case MI_CIRVALTEST:
            RETVALUE(ROK);

         case MI_RELCOMP:
            /* check if this is a response to Reset Req. If so there is no conn 
             * block, ans return OK.  otherwise fall through 
             */
            if ((cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK) ||
                (cir->transStat[SICIR_HWLOCST] == SICIR_ST_WTRESACK))
            {
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "Waiting for reset ack therefore no conn block\n")); 
               RETVALUE(ROK);
            }

            /* get the conn cb */
            ctrlCon = cir->ctrlMultiRateCir->siCon;
            if (ctrlCon == NULLP)
            {
               SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                 "There is no conn. cb on ctrl cic %#lx for a non-single \
                  rate call\n", cir->ctrlMultiRateCir->cfg.cirId));
               RETVALUE(RFAILED);
            }

#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
            if ((cir->pIntfCb->cfg.swtch == LSI_SW_ITU97) ||
                (cir->pIntfCb->cfg.swtch == LSI_SW_ITU2000) ||
                (cir->pIntfCb->cfg.swtch == LSI_SW_RUSS2000) ||
                (cir->pIntfCb->cfg.swtch == LSI_SW_ETSIV3))
            {            
               if ((ctrlCon->incC.conPrcs) &&
                   (ctrlCon->incC.cirId == cir->ctrlMultiRateCir->key.k1.cirId))
               {
                  /* if the call is in the busy state and the release has not be
                   * sent out, send a REL on the controlling circuit
                   */
                  if ((ctrlCon->incC.conState > ST_WTFORACM) &&
                      (ctrlCon->incC.conState < ST_WTFORRELCMP))
                  {               
                     SiCauseDgn cause;
                     /* initialize cause/diagnostic element */
                     MFINITELMT(&ctrlCon->mCallCb->mfMsgCtl, ret, NULLP,
                                (ElmtHdr *) &cause, &meCauseIndV, 
                                (U8) PRSNT_DEF, ctrlCon->tCallCb->cfg.swtch, 
                                (U32) MF_ISUP);
                     cause.causeVal.pres = PRSNT_NODEF;
                     cause.causeVal.val = SIT_CCTMPFAIL;
                     siGenRelUpLw(ctrlCon->incC.cir->cfg.cirId, ctrlCon, &cause);
                  }
                  else /* process the reset procedures */
                     genCtrlRscFlg = 1;
               }

               if ((ctrlCon->outC.conPrcs) &&
                   (ctrlCon->outC.cirId == cir->ctrlMultiRateCir->key.k1.cirId))
               {
                  /* if the call is in the busy state and the release has not be
                   * sent out, send a REL on the controlling circuit
                   */
                  if ((ctrlCon->outC.conState > ST_WTFORACM) &&
                      (ctrlCon->outC.conState < ST_WTFORRELCMP))
                  {               
                     SiCauseDgn cause;
                     /* initialize cause/diagnostic element */
                     MFINITELMT(&ctrlCon->mCallCb->mfMsgCtl, ret, NULLP,
                                (ElmtHdr *) &cause, &meCauseIndV, 
                                (U8) PRSNT_DEF, ctrlCon->tCallCb->cfg.swtch, 
                                (U32) MF_ISUP);
                     cause.causeVal.pres = PRSNT_NODEF;
                     cause.causeVal.val = SIT_CCTMPFAIL;
                     siGenRelUpLw(ctrlCon->outC.cir->cfg.cirId, ctrlCon, &cause);
                  }
                  else /* process the reset procedures */
                     genCtrlRscFlg = 1;
               }
            }   
#endif
            break;

         case MI_RELSE:
            /* reply a RLC on the circuit which received the REL message */
            {
               SiPduHdr  pduHdr;

               /* prepare Pdu header */
               pduHdr.eh.pres      = PRSNT_NODEF;
               pduHdr.msgType.pres = PRSNT_NODEF;
               pduHdr.msgType.val  = (U8) M_RELCOMP;

               /* initialize Release Complete */
               MFINITPDU(&cb->mfMsgCtl, ret, (U8) 0, (U8) MI_RELCOMP, 
                         (ElmtHdr *)NULLP, (ElmtHdr *) msg, (U8) PRSNT_DEF,
                         cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);
                  
               siGenPdu(cb, &pduHdr, msg, cir->pIntfCb->cfg.swtch, cir->opc,
                        cir->cfg.intfId, cir->phyDpc, TRUE,
                        cir->cfg.cic, lnkSel, 
                        siGetPriority(M_RELCOMP, cir->pIntfCb->cfg.swtch), NULLP);
            }            

            /* need to send the GRS with CAM for ANS95 or multiple RSCs for ITU97 and
             * ETSI v3
             */ 
            genCtrlRscFlg = 1;

            /* get the connection block on the controlling ckt */
            ctrlCon = cir->ctrlMultiRateCir->siCon;
            if (ctrlCon == NULLP)
            {
               SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                 "There is no conn. cb on ctrl cic %#lx for a non-single \
                  rate call\n", cir->ctrlMultiRateCir->cfg.cirId));
               RETVALUE(RFAILED);
            }
            break;

         default:
            /* get the conn cb frm controlling ckt */
            ctrlCon = cir->ctrlMultiRateCir->siCon;
            if (ctrlCon == NULLP)
            {
               SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                 "There is no conn. cb on ctrl cic %#lx for a non-single \
                  rate call\n", cir->ctrlMultiRateCir->cfg.cirId));
               RETVALUE(RFAILED);
            }

            /* check the conn state, if it is in the before receiving first backward
             * message state, need to respond the reset procedure. Otherwise,
             * discard the revd msg.
             */
            if ((ctrlCon->incC.conPrcs) && 
                (ctrlCon->incC.cirId == cir->ctrlMultiRateCir->key.k1.cirId))
            {
               switch (ctrlCon->incC.conState)
               {               
                  case ST_IDLE:
                  case ST_WTFORCONTIN:
                  case ST_WTFORACM:
                     genCtrlRscFlg = 1;
                     break;
                  

                  default:
                     /* discard the message */
                     RETVALUE(RFAILED);
               }
            }

            if ((ctrlCon->outC.conPrcs) &&
                (ctrlCon->outC.cirId == cir->ctrlMultiRateCir->key.k1.cirId))
            {
               switch (ctrlCon->outC.conState)
               {               
                  case ST_IDLE:
                  case ST_WTFORCONTIN:
                  case ST_WTFORACM:
                     /* if received msg is an IAM or CRM, it indicates a dual 
                      * seizure occurred. Allocated a conneciton block to this 
                      * cir. This has been taken care in the state matrix 
                      * function
                      */ 
                     if ((msgIdx == MI_INIADDR) || (msgIdx == MI_CIRRESERVE))
                     {
                         cir->siCon = siGetIncCon(cir, cb);
                         if (cir->siCon == NULLP)
                         {
                            SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                                   "Can not allocate a connection block \n")); 

                            RETVALUE(RFAILED);
                         }
                         RETVALUE(ROK);
                     }
                     else
                        genCtrlRscFlg = 1;
                     break;
                  

                  default:
                     /* discard the message */
                     RETVALUE(RFAILED);
               }
            }
            break;
      }

      /* For incoming call, generate the GRS with CAM for ANS'95 when the 
       * circuit state is idle. 
       * The circuit state is not idle means there exists a pending circuit 
       * related message event. For ANS95, if controlling circuit has sent 
       * out a CGB or GRS req before, this second GRS msg won't be sent. 
       * For ITU97 and ETSIV3, generate multiple RSCs.
       */ 
      if ((ctrlCon->incC.conPrcs) &&
          (ctrlCon->incC.cirId == cir->ctrlMultiRateCir->key.k1.cirId) &&
          (ctrlCon->incC.cir->transStat[SICIR_MTLOCST] == SICIR_ST_IDLE) &&
          (ctrlCon->incC.cir->transStat[SICIR_HWLOCST] == SICIR_ST_IDLE) &&
          (genCtrlRscFlg))
      {              
         if ((siGenMRateRsc(cir->ctrlMultiRateCir)) != ROK)
         {
             SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
             "Can't generate the GRS with Cal for ANS'95 or multiple RSC for\
              ITU97/ETSI v3 \n"));  

#if (ERRCLASS & ERRCLS_DEBUG)
             SILOGERROR(ERRCLS_DEBUG, ESI659, (ErrVal) 0, 
                        "generate resets failed for non-single rate calls");
#endif
             RETVALUE(RFAILED);
         }
      }         

      /* For outgoing call, generate the GRS with CAM for ANS'95 when the 
       * circuit state is idle. And generate the reattemp indication if 
       * receiving msg is not IAM.
       * The circuit state is not idle means there exists a pending circuit 
       * related message event. For ANS95, if controlling circuit has sent 
       * out GRS req before, this second GRS msg won't be sent. 
       * For ITU97 and ETSIV3, generate multiple RSCs.
       */
      if ((ctrlCon->outC.conPrcs) &&
          (ctrlCon->outC.cirId == cir->ctrlMultiRateCir->key.k1.cirId) &&
          (ctrlCon->outC.cir->transStat[SICIR_MTLOCST] == SICIR_ST_IDLE) &&
          (ctrlCon->outC.cir->transStat[SICIR_HWLOCST] == SICIR_ST_IDLE) &&
          (genCtrlRscFlg))
      {              
         if ((siGenMRateRsc(cir->ctrlMultiRateCir)) != ROK)
         {
             SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
             "Can't generate the GRS with Cal for ANS'95 or multiple RSC \
              for ITU97/ETSI v3 \n"));  

#if (ERRCLASS & ERRCLS_DEBUG)
             SILOGERROR(ERRCLS_DEBUG, ESI660, (ErrVal) 0, 
                        "generate resets failed for non-single rate calls");
#endif
             RETVALUE(RFAILED);
         }

         /* defensive check. The connection might have been cleared */
         ctrlCon = cir->ctrlMultiRateCir->siCon;
         if (ctrlCon == NULLP) 
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "connection on controlling ckt is cleared\n"));
            RETVALUE(RFAILED);
         }

         /* For the call in the state before receipt of first backward
          * message, send a reattempt indication to CC for outgoing conneciton 
          */
         if (((ctrlCon->outC.conState > ST_IDLE) && 
              (ctrlCon->outC.conState < ST_WTFORANSWR))
             )              
         {
            /* send a reattempt indication to CC for outgoing conneciton */
            SiCauseDgn cause;

            MFINITELMT(&ctrlCon->mCallCb->mfMsgCtl, ret, NULLP, 
                       (ElmtHdr *) &cause, &meCauseIndV, (U8) PRSNT_DEF, 
                       cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);

            cause.eh.pres       = PRSNT_NODEF;
            cause.causeVal.pres = PRSNT_NODEF;
            cause.causeVal.val  = SIT_CCREQUNAVAIL;
     
            /* generate reattempt indication */ 
            siGenReatInd(ctrlCon->outC.cirId, ctrlCon, &cause);
         }
      }         
      RETVALUE(RFAILED);
   }    
   else
   {
      /* message received on a controlling circuit for a non-single rate call.
       * Pocessed the message in the connection state matrix
       */
      RETVALUE(ROK);
   }   
} /* end of siChkMRateCtrlCkts */        


/*
*
*       Fun:   siGenMRateRsc
*
*       Desc:  generate GRS with CAM for ans95 and multiple RSC for itu97 and
*              etsi v3 in a non-single rate conneciton. 
*
*       Ret:   ROK      - ok
*              RFAILED  - not ok or already took action
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenMRateRsc
(
SiCirCb   *siCir              /* controlling circuit cb */
)
#else
PUBLIC S16 siGenMRateRsc(siCir)
SiCirCb   *siCir;             /* controlling circuit cb */
#endif
{
   SiCon       *siCtrlCon;    /* connection control block */
   SiCirCb     *tmpCir;       /* circuit control block */

   TRC2(siGenMRateRsc)

#if (ERRCLASS & ERRCLS_DEBUG)
   /* check the cir and cir->pIntfCb pointer */
   if (siChkCirIntf(siCir) != ROK)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "No circuit control block or no interface cb ptr \n"));
      SILOGERROR(ERRCLS_DEBUG, ESI661, (ErrVal) 0,
                 "siGenMRateRsc() Failed, \
                 no circuit contrl or interface cb pointer.");
      RETVALUE(RFAILED);
   }   

   if (siCir->siCon == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "connection control block pointer missing\n"));
      SILOGERROR(ERRCLS_DEBUG, ESI662, (ErrVal) 0,
                 "siGenMRateRsc() Failed, conn. control block pointer missing");
      RETVALUE(RFAILED);
   }

   if (siCir->siCon->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "MTP3 control block pointer missing in connection cb\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI663, (ErrVal) 0, 
                 "siGenMRateRsc() Failed, MTP3 control block pointer missing \
                 in connection Cb");
      RETVALUE(RFAILED);
   }
#endif

   /* get the connection cb */
   siCtrlCon = siCir->siCon;
    

   switch (siCir->pIntfCb->cfg.swtch)
   {

#ifdef SS7_ITU97 
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* Generate multiple reset on the involved circuits
          * and set the flag mulReset to TRUE, it would not process the 
          * connection Cb
          */
         if ((siCtrlCon->incC.conPrcs) &&
             (siCtrlCon->incC.cirId == siCir->key.k1.cirId))
            siCtrlCon->incC.mulReset = TRUE;
         if ((siCtrlCon->outC.conPrcs) &&
             (siCtrlCon->outC.cirId == siCir->key.k1.cirId))
            siCtrlCon->outC.mulReset = TRUE;

         tmpCir = siCir;
         while (tmpCir != NULLP)
         {
            /* Generate RSC as if Reset request is received for each involved
             * circuit
             */
            siProcCirEvt(tmpCir, SIT_STA_CIRRESREQ, FALSE);
            /* Generate a local reset for each involved circuit */
            siGenCirEvt(tmpCir, SIT_STA_CIRLOCRES);

            tmpCir = tmpCir->nextMultiRateCir;
         }

         /* Take action here on the connection Cb by calling siActDat directly
          */
         siCtrlCon->resDir = FROM_UPR;
         siActDat(siCir->key.k1.cirId, siCtrlCon, IEI_CIRRES);

         /* reset the mulReset */
         if ((siCtrlCon->incC.conPrcs) &&
             (siCtrlCon->incC.cirId == siCir->key.k1.cirId))
            siCtrlCon->incC.mulReset = FALSE;
         if ((siCtrlCon->outC.conPrcs) &&
             (siCtrlCon->outC.cirId == siCir->key.k1.cirId))
            siCtrlCon->outC.mulReset = FALSE;

         break;
#endif

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "swtch type is not Ans'95/itu'97/etsi v3, invalid swtch type\n"));
         SILOGERROR(ERRCLS_DEBUG, ESI666, (ErrVal) 0,
                    "siGenMRateRsc() Failed, invalid swtch type");
         RETVALUE(RFAILED);
#endif
   }
   RETVALUE (ROK);

} /* end of siGenMRateRsc */        

/*
*
*       Fun:   siProcMRateIAM
*
*       Desc:  Process each affected circuit if the call is a incoming multirate
*              or N*64 kbits/s connection
*
*       Ret:   ROK      - ok
*              RNA      - not ok, already sent release. The calling funciton should
*                         not clear the conn.
*              RFAILED  - not ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siProcMRateIAM
(
SiCon     *siCon,                   /* connectin control block */
SiAllSdus *ev,                      /* pointer to Sdu structure */
U8        multiplier,               /* num of affected circuits N */       
U8        maxNumCir,                /* max num of affected circuits */
U8        transRate,                /* info transfer rate/trans med req */
U32       mapVal,                   /* CAM map value */
Bool      contiMRateCall            /* contiguous call flag */
)
#else
PUBLIC S16 siProcMRateIAM(siCon, ev, multiplier, maxNumCir, transRate, 
                          mapVal, contiMRateCall)
SiCon     *siCon;                   /* connection control block */
SiAllSdus *ev;                      /* pointer to Sdu structure */
U8        multiplier;               /* num of affected circuits N */
U8        maxNumCir;                /* max num of affected circuits */
U8        transRate;                /* info transfer rate/trans med req */
U32       mapVal;                   /* CAM map value */
Bool      contiMRateCall;           /* contiguous call flag */
#endif
{
   S16      ret;
   SiCirCb  *cir;                   /* cir Cb associated with conn. Cb */
   SiCirCb  *mRateCirPtrs[SI_MAX_NO_OF_CIR]; 
                                    /* the ptrs of affected CirCb */
   SiCirCb  *mRateCir;              /* affected cir control block */
   U8       i;                      /* counter */
   CirId    cntrlCirId;             /* 1st circuit Id */
   Bool     mRateN64Flg;            /* N*64 type non-single rate call flag */
   SiCauseDgn cause;                /* cause structure */
   U16      causeVal;               /* cause value for layer manager */
   Cic      nullCirCic;             /* the cic of null cir */
   SiCirCb  *prev_cir;            

   TRC2(siProcMRateIAM)

   cir = siCon->incC.cir;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siCon->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "Lower SAP control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI667, (ErrVal) 0, 
                 "siProcMRateIAM() Failed, pointer to Lower SAP missing");
      RETVALUE(RFAILED);
   }

   /* check the cir and cir->pIntfCb pointer */
   if (siChkCirIntf(cir) != ROK)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "no controlling circuit control block or interface cb ptr\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI668, (ErrVal) 0, 
                 "siProcMRateIAM() Failed, \
                 pointer to circuit or interface cb missing");
      RETVALUE(RFAILED);
   }
#endif

   /* initialize the variable */
   for (i = 0; i < SI_MAX_NO_OF_CIR; i++)
   {           
      mRateCirPtrs[i] = NULLP;
   }

   mRateCir = NULLP;
   prev_cir = siCon->incC.cir;
   cntrlCirId = cir->cfg.cirId;
   mRateN64Flg = TRUE;
   nullCirCic = 0;

   /* initialize cause/diagnostic element */
   MFINITELMT(&siCon->mCallCb->mfMsgCtl, ret, NULLP, (ElmtHdr *) &cause, 
              &meCauseIndV, (U8) PRSNT_DEF, siCon->tCallCb->cfg.swtch, 
              (U32) MF_ISUP);

   /* Validate the affected circuits and store them in mRateCirPtrs */
   ret = siValMRateCkt(cir, siCon->tCallCb->cfg.swtch, maxNumCir, mapVal, transRate,
                   contiMRateCall, mRateCirPtrs, multiplier, &causeVal, &nullCirCic);

   /* if return is RFAILED, need to send an alarm and release the call */
   if (ret == RFAILED)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
             "siValMRateCkt() failed\n")); 

      /* Generate Alarm to Layer management on controlling circuit */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cntrlCirId, 
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_LI_INV_EVT, causeVal, TRUE, 
                     cntrlCirId, SI_ALRM_NOCIRTO_ROUTE);

      /* check if it is the error cause of unequipped circuit. send the UCIC on 
       * this circuit with opc, dpc from controlling circuit 
       */
      if (causeVal == LSI_CAUSE_INV_CIRCUIT)
      {
         /* means one of affected circuit is unequipped. send the UCIC on 
            this circuit with opc, dpc from controlling circuit */
         siGenCirMsg(nullCirCic, cir->opc, 0, cir->phyDpc, FALSE, 
                     cir->pIntfCb->cfg.swtch, M_UNEQUIPCIC, 
                     MI_UNEQUIPCIC, NULLP, siCon->mCallCb->cfg.ssf, 
                     siCon->mCallCb->cfg.nwId);

      }
      else               
      {   
         /* release the call */
         cause.causeVal.pres = PRSNT_NODEF;
         cause.causeVal.val  = SIT_CCPROTERR;
         siGenRelLw(cir->cfg.cirId, siCon, &cause);
      }
      RETVALUE(RNA);
   }
   
   /* if return is RNA, internal error. Do not sent an alarm. */
   if (ret == RNA)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
             "siValMRateCkt() failed\n")); 
      RETVALUE(RFAILED);
   }

   /* Determind the multirate connection type call for contiguous call after
    * validation. At this point, we know that the validating of starting Cic 
    * according the table was performed or not. 
    */
   if (contiMRateCall)
   {
      /* determine the multirate connection type call */
      switch (siCon->tCallCb->cfg.swtch)
      {

#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
         case LSI_SW_ITU97:
         case LSI_SW_ITU2000:
         case LSI_SW_RUSS2000:
            if ((transRate >= TMR_2X64KBITS) && (transRate <= TMR_1920KBITS))
            {
               /* need to see if Q.763 table 3 part checking is required
                * If so, then this call is multirate connection type call by
                * our interpretation.
                */
               if (cir->pIntfCb->cfg.checkTable & LSI_CHKTBLE_MRATE)
               {
                  mRateN64Flg = FALSE;
               }
            }
            break;
#endif

            break;

#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "swtch is not ans95/itu97/etsi v3, invalid %d\n",
                    siCon->tCallCb->cfg.swtch));
            SILOGERROR(ERRCLS_DEBUG, ESI669, (ErrVal) 0,
                    "siProcMRateIAM() Failed, invalid configuration switch");
            RETVALUE(RFAILED);
#endif
      }
   }

   /* Sanity check for each affected circuit */
   for (i = 0; i < multiplier; i++)
   {
      mRateCir = mRateCirPtrs[i];

      /* check the typeCntrl of each affected circuit. We do not
       * check the calProcStat for a non-single rate incoming
       * conn here. We do this check later. If we found
       * there is a incoming call on the affected, we want to send 
       * release for this non-single rate call
       */
      if (mRateCir->cfg.typeCntrl == OUTGOING)
      {
          SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
              "ckt with cirId(%#lx) is outgoing type \n", 
              mRateCir->cfg.cirId));
          RETVALUE(RFAILED);
      }

      /* Sanity check on the affected circuit. The checking includes the
       * circuit blocking, unequipped states, etc.
       */
      ret = siSanChkIAMCkts(siCon, mRateCir, ev);

      if (ret != ROK)
      {
          SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
              "siSanChkIAMCkts returned failure on circuit with cirId(%#lx)\n", 
               mRateCir->cfg.cirId));
          RETVALUE(RFAILED);
      }

      /* check if the circuit involved in a non-single rate connection */
      if (mRateCir->ctrlMultiRateCir != NULLP)
      {
         /* the circuit involved in a non-single rate call, check if this is a
          * incoming call. If so, reject this incoming call.
          */
         if ((mRateCir->ctrlMultiRateCir->siCon != NULLP) &&
             (mRateCir->ctrlMultiRateCir->siCon->incC.conPrcs) &&
             (mRateCir->ctrlMultiRateCir->siCon->incC.cirId == 
              mRateCir->ctrlMultiRateCir->cfg.cirId))
         {
            /* there exists an incoming connection.*/
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                  "one of affected circuit involved in an incoming non-single rate call\n")); 
            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cntrlCirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP,
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_LI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, 
                            TRUE, cntrlCirId, SI_ALRM_NOCIRTO_ROUTE);
            cause.causeVal.pres = PRSNT_NODEF;
            cause.causeVal.val  = SIT_CCNOCIRCUIT;
            siGenRelLw(cir->cfg.cirId, siCon, &cause);
            RETVALUE(RFAILED);
         }   
            
         /* check if this is a outgoing call. If dual seizure happened, need to 
          * determind which end is the controlling exchange and take actions.
          */
         if ((mRateCir->ctrlMultiRateCir->siCon != NULLP) &&
             (mRateCir->ctrlMultiRateCir->siCon->outC.conPrcs) &&
             (mRateCir->ctrlMultiRateCir->siCon->outC.cirId == 
              mRateCir->ctrlMultiRateCir->cfg.cirId))
         {
            /* there exists an outgoing connection. If it has not received a
             * first backward message, dual seizure happened. 
             */ 
            if((mRateCir->ctrlMultiRateCir->siCon->outC.conState < 
                ST_WTFORANSWR) 
               )               
            {
               /* dual seizure occurred between two non-single rate call. 
                * Check to see which call will controll
                */
               ret = siChkMultiDualSeiz(mRateCirPtrs[0], mRateCir, 
                                        contiMRateCall, transRate);
               if (ret == RFAILED)
               {
                   SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                          "check dual seizure failed between non-single rate \
                          calls \n"));
                   RETVALUE(RFAILED);
               }   

               /* Check if accept this incoming call. If so, clear the existing 
                * outgoing connection and sent reattemp indication to upper 
                * layer.  We clear the outgoing conn once we detected the 
                * incoming should control on this circuit. Even though, we might 
                * clear this incoming call later due to some failures. We will 
                * end up both calls cleared.
                * This is acceptable because the peer node will use the same 
                * logic to validate the calls. The peer node also will clear 
                * this outgoing call
                */
               if (ret == INCOMING_CTRL)
               {
                  /* If the outgoing require continuity check, sent Status 
                   * Indication to upper layer to stop continuity check
                   */
                  siChkContin(mRateCir->ctrlMultiRateCir->siCon);                  

                  MFINITELMT(&mRateCir->ctrlMultiRateCir->siCon->tCallCb->mfMsgCtl, 
                             ret, NULLP, (ElmtHdr *) &cause, &meCauseIndV, 
                             (U8) PRSNT_DEF, 
                             mRateCir->ctrlMultiRateCir->siCon->tCallCb->cfg.swtch, 
                             (U32) MF_ISUP);
                  cause.causeVal.pres = PRSNT_NODEF;
                  cause.causeVal.val  = SIT_CCREQUNAVAIL;

                  /* send reattemp indication on the contrl circuit */
                  siGenReatInd(
                     mRateCir->ctrlMultiRateCir->siCon->outC.cir->cfg.cirId, 
                               mRateCir->ctrlMultiRateCir->siCon, &cause);

                  mRateCir->ctrlMultiRateCir->siCon->suInstId              = 0;
                  SISTATECHNG(
                        mRateCir->ctrlMultiRateCir->siCon->outC.cir->calProcStat,
                        CALL_IDLE);

                  /* clear the outgoing conn */
                  siClearOutCon(mRateCir->ctrlMultiRateCir->siCon);
            
               }
               else /* Discard the incoming call */
               {
                  if (ret == OUTGOING_CTRL)
                  {
                      /* discard the message */
                      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                       "recv a non-single rate IAM on the non-contrl exchange \
                        when dual seizure detected.\n"));
                      RETVALUE(RFAILED);
                  } 
                  SISTATECHNG(
                      mRateCir->ctrlMultiRateCir->siCon->outC.cir->calProcStat,
                      CALL_IDLE);
               }   
               
            }
            else 
            /* Existing outgoing call is in the stable state. Reject the incoming call */ 
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                      "one of  circuit involved in another outgoing non-single rate call \
                       other than dual seizure\n")); 
               /* Generate Alarm to Layer management */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cntrlCirId, 
                             LSI_USTA_DGNVAL_NONE, NULLP,
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_LI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, 
                               TRUE, cntrlCirId, SI_ALRM_NOCIRTO_ROUTE);
               cause.causeVal.pres = PRSNT_NODEF;
               cause.causeVal.val  = SIT_CCNOCIRCUIT;
               siGenRelLw(cir->cfg.cirId, siCon, &cause);
               RETVALUE(RFAILED);
            }            
         } 
      }
      else
      /* the circuit involved in a single rate call */ 
      {
         /* For non-cntrl ckt, check if it involves in another incoming call. 
          * For cntrl circuit, if it invloves in another incoming call, it 
          * should not be processed here. Moreover, the incC conn is already 
          * allocated to it. 
          */
         if ((i != 0 ) &&
             (mRateCir->siCon != NULLP) && (mRateCir->siCon->incC.conPrcs) &&
             (mRateCir->siCon->incC.cirId == mRateCir->cfg.cirId))
         {
            /* there exists an incoming connection.*/
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                  "one of affected circuit involved in an incoming single rate call\n")); 
            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cntrlCirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP,
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_LI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, 
                            TRUE, cntrlCirId, SI_ALRM_NOCIRTO_ROUTE);
            cause.causeVal.pres = PRSNT_NODEF;
            cause.causeVal.val  = SIT_CCNOCIRCUIT;
            siGenRelLw(cir->cfg.cirId, siCon, &cause);
            RETVALUE(RNA);
         }   
            
         /* For non-cntrl ckt, check if it involves in another outgoing call. 
          * For cntrl circuit, if it invloves in another outgoing call, it 
          * should not be processed here. 
          */
         if ((i != 0) && (mRateCir->siCon != NULLP) && 
             (mRateCir->siCon->outC.conPrcs) &&
             (mRateCir->siCon->outC.cirId == mRateCir->cfg.cirId))
         {
            /* there exists an outgoing connection. If it has not received a
             * first backward message, dual seizure happened. 
             */ 
            if((mRateCir->siCon->outC.conState < ST_WTFORANSWR) 
               )               
            {
               /* dual seizure occurred between one non-single rate call and
                * an outgoing single rate call
                */
               ret = siChkMultiDualSeiz(mRateCirPtrs[0], mRateCir, 
                                        contiMRateCall, transRate);
               if (ret == RFAILED)
               {
                   SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                          "check dual seizure failed \n"));
                   RETVALUE(RFAILED);
               }   
               /* Check if accept this incoming call. If so, clear the existing outgoing
                * connection and sent reattemp indication to upper layer. 
                * We clear the outgoing conn once we detected the incoming should
                * control on this circuit. Even though, we might clear this incoming
                * call later due to some failures. We will end up both calls cleared.
                * This is acceptable because the peer node will use the same logic 
                * to validate the calls. The peer node also will clear this outgoing
                * call
                */
               if (ret == INCOMING_CTRL)
               {
                  /* If the outgoing require continuity check, sent Status Indication
                   * to upper layer to stop continuity check
                   */
                  siChkContin(mRateCir->siCon);                  

                  MFINITELMT(&mRateCir->siCon->tCallCb->mfMsgCtl, ret, NULLP, 
                       (ElmtHdr *) &cause, &meCauseIndV, (U8) PRSNT_DEF, 
                       mRateCir->siCon->tCallCb->cfg.swtch, (U32) MF_ISUP);
                  cause.causeVal.pres = PRSNT_NODEF;
                  cause.causeVal.val  = SIT_CCREQUNAVAIL;

                  /* send reattemp indication on the contrl circuit */
                  siGenReatInd(mRateCir->siCon->outC.cir->cfg.cirId, 
                                mRateCir->siCon, &cause);

                  mRateCir->siCon->suInstId              = 0;
                  SISTATECHNG(mRateCir->siCon->outC.cir->calProcStat, 
                               CALL_IDLE);

                  /* clear the outgoing conn */
                  siClearOutCon(mRateCir->siCon);
            
               }
               else /* discard the incoming call */
               {
                  if (ret == OUTGOING_CTRL)
                  {
                     /* discard the message */
                     SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                          "recv a non-single rate IAM on the non-contrl \
                          exchange when dual seizure detected between single \
                          rate and non-single rate calls.\n"));
                     RETVALUE(RFAILED);
                  }
               }   
            }
            else
            /* Existing outgoing call is in the stable state. Reject the 
             * incoming call 
             */ 
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                      "one of circuit involved in another outgoing single rate \
                       call other than dual seizure\n")); 
               /* Generate Alarm to Layer management */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cntrlCirId, 
                             LSI_USTA_DGNVAL_NONE, NULLP,
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_LI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, 
                               TRUE, cntrlCirId, SI_ALRM_NOCIRTO_ROUTE);
               cause.causeVal.pres = PRSNT_NODEF;
               cause.causeVal.val  = SIT_CCNOCIRCUIT;
               siGenRelLw(cir->cfg.cirId, siCon, &cause);
               RETVALUE(RNA);
            }            
         } 
      } /* end of else */              
   } 

   /* Update the non-single rate related information on the connection and 
    * circuit cb after the sanity check. At this point, all the check are 
    * done.
    */
   for (i = 0; i < multiplier; i++)
   {
      mRateCir = mRateCirPtrs[i];

      BLDMRATELNK(mRateCir, prev_cir, cir);
      prev_cir = mRateCir;

      /* update info on non-controlling cir */
      if ( i != 0)
         mRateCir->sts->numNonCont++; 
      SISTATECHNG(mRateCir->calProcStat, INCBUSY);
      
   } /* end of validate each affected circuit */        

   /* update other information */
   if (mRateN64Flg)
      siCon->incC.mulRateConFlg = SI_N64_CONN;
   else
      siCon->incC.mulRateConFlg = SI_MULTI_CONN;

   siCon->incC.numMulRateCkts = multiplier;

   RETVALUE (ROK);
} /* end of siProcMRateIAM */   

/*
*
*       Fun:   siChkMultiDualSeiz
*
*       Desc:  determine the control exchange when the dual seizure is
*              detected when incoming conn is non-single rate call.
*
*       Ret:   INCOMING_CTRL     - incoming conn is the control one
*              OUTGOING_CTRL     - outgoing conn is the control one
*              RFAILED           - not OK
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siChkMultiDualSeiz
(
SiCirCb   *ctrlCir,          /* the controlling circuit cb(revd IAM) */
SiCirCb   *affeCir,          /* the affected circuit block */
Bool      incContiCall,      /* incoming contiguous non-single rate flag */
U8        incTransRate       /* incoming conn trans rate */     
)
#else
PUBLIC S16 siChkMultiDualSeiz(ctrlCir, affeCir, incContiCall, incTransRate)
SiCirCb   *ctrlCir;          /* the controlling circuit cb(revd IAM) */
SiCirCb   *affeCir;          /* the affected circuit block */
Bool      incContiCall;      /* incoming contiguous non-single rate flag */
U8        incTransRate;      /* incoming conn trans rate */     
#endif
{
   S16        ret;
   SiCon      *outCon;         /* the existing outgoing conn */
   Bool       incN64Flg;       /* incoming Nx64 type non-single call flg */
   Cic        recvCic;         /* cic of the controlling cir (revd IAM) */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   U8         incNumMultCkts;  /* # of ckts in incoming conn */
   U8         incSlotId;       /* 1st slotId in incoming non-singlerate con */
   S16        result;          /* result of controlling conn */
#endif

   TRC2(siChkMultiDualSeiz)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (ctrlCir == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "the control circuit control block pointer missing.\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI670, (ErrVal) 0, 
           "siChkMultiDualSeiz() Failed, pointer to control circuit missing");
      RETVALUE(RFAILED);
   }

   if (affeCir == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
           "the affect circuit control block pointer missing.\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI671, (ErrVal) 0, 
          "siChkMultiDualSeiz() Failed, pointer to affected circuit missing");
      RETVALUE(RFAILED);
   }
   
   if (affeCir->pIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
        "Interface control block pointer on affected circuit missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI672, (ErrVal) 0, 
       "siChkMultiDualSeiz() Failed, Interface control block pointer missing");
      RETVALUE(RFAILED);
   }
#endif

   /* get the existing conn block. If the affected circuit involved in a 
    * non-single rate call, get the conn from the controlling circuit of
    * this existing conn.
    */ 
   if (affeCir->ctrlMultiRateCir != NULLP)
   {
      /* the second conn. is a non-single rate call */
      outCon = affeCir->ctrlMultiRateCir->siCon;
   }
   else
      outCon = affeCir->siCon;

   if (outCon == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
          "conn on ckt with cic(%d) is NULLP\n", affeCir->key.k2.cic));  
      RETVALUE(RFAILED);
   }

   recvCic = ctrlCir->key.k2.cic;
   incN64Flg = TRUE;
   ret = 0;
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   incSlotId = ctrlCir->cfg.slotId & LSI_CIR_SLOTID_MASK; 
                                             /* get the slot info */
   incNumMultCkts = 0; 
   result = 0;
#endif

   /* Need to determine the type of incoming non-single rate call. If 
    * there is a dual seizure happend on the controlling circuit, the 
    * incoming conn has not validated the starting cic of IAM with the 
    * Q763 table and the type of non-single rate call is not known yet. 
    */
   switch (affeCir->pIntfCb->cfg.swtch)
   {

#if (SS7_ITU97 || SS7_ITU2000) 
      case LSI_SW_ITU97:
      case LSI_SW_ITU2000:
         if (incContiCall)
         {
            /* For the contigous calls, need to see if Q.763 table 3 part 
             * checking is required. If so, validate the starting cic with 
             * table. If correct, then this call is multirate connection 
             * type call by our interpretation. 
             */
            if ((incTransRate >= TMR_2X64KBITS) && 
                (incTransRate <= TMR_1920KBITS))
            {
               /* need to see if Q.763 table 3 part checking is required. If so,
                * validate the starting cic with table. If correct, then this 
                * call is multirate connection type call by our interpretation. 
                */
               if (affeCir->pIntfCb->cfg.checkTable & LSI_CHKTBLE_MRATE)
               {
                  /* get the number of circuit N. */
                  siGetNumCkts(affeCir->pIntfCb->cfg.swtch, incTransRate, 
                               &incNumMultCkts);

                  if (incNumMultCkts == 0)
                  {
                     SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "number of circuit involved in incoming conn. on cir\
                       %#lx is invalid\n", affeCir->cfg.cirId));  

                     RETVALUE(RFAILED);
                  }
                  /* table 3 part 1 is to be checked */
                  if (siTrunkTbl[affeCir->pIntfCb->cfg.trunkType][incSlotId]
                             [incNumMultCkts] != TRUE)
                  {
                     SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                      "invalid starting cic for multi call in dual seizure\n")); 
   
                     RETVALUE(RFAILED);
                  }
                  else
                     incN64Flg = FALSE;
               }   
            } 
         } /* other cases are Nx64 type call by our interpretation */
         break;
#endif /* SS7_ITU97 || SS7_ITU2000 */
#ifdef SS7_RUSS2000 
      case LSI_SW_RUSS2000:
         if (incContiCall)
         {
            /* For the contigous calls, need to see if Q.763 table 3 part 
             * checking is required. If so, validate the starting cic with 
             * table. If correct, then this call is multirate connection 
             * type call by our interpretation. 
             */
            if ((incTransRate >= TMR_2X64KBITS) && 
                (incTransRate <= TMR_1920KBITS))
            {
               /* need to see if Q.763 table 3 part checking is required. If so,
                * validate the starting cic with table. If correct, then this 
                * call is multirate connection type call by our interpretation. 
                */
               if (affeCir->pIntfCb->cfg.checkTable & LSI_CHKTBLE_MRATE)
               {
                  /* get the number of circuit N. */
                  siGetNumCkts(affeCir->pIntfCb->cfg.swtch, incTransRate, 
                               &incNumMultCkts);

                  if (incNumMultCkts == 0)
                  {
                     SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "number of circuit involved in incoming conn. on cir\
                       %#lx is invalid\n", affeCir->cfg.cirId));  

                     RETVALUE(RFAILED);
                  }
                  /* table 3 part 1 is to be checked */
                  if (siTrunkTbl[affeCir->pIntfCb->cfg.trunkType][incSlotId]
                             [incNumMultCkts] != TRUE)
                  {
                     SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                      "invalid starting cic for multi call in dual seizure\n")); 
   
                     RETVALUE(RFAILED);
                  }
                  else
                     incN64Flg = FALSE;
               }   
            } 
         } /* other cases are Nx64 type call by our interpretation */
         break;
#endif /* SS7_RUSS2000 */


#if (ERRCLASS & ERRCLS_DEBUG)
       default:
          SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                 "swtch is not ans95/itu97/etsi v3, invalid %d\n", 
                  affeCir->pIntfCb->cfg.swtch));
          SILOGERROR(ERRCLS_DEBUG, ESI674, (ErrVal) 0,
               "siChkMultiDualSeiz Failed, invalid configuration switch");
          RETVALUE(RFAILED);
#endif
     }


   switch (affeCir->pIntfCb->cfg.swtch)
   {
#ifdef SS7_ITU97 
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* check if the outgoing conn is a single rate conn */
         if (affeCir->ctrlMultiRateCir == NULLP)
         {
            /* since we know the first conn is a non-single rate call, the
             * non-single rate call should be the control one because it has a
             * greater number of 64 kbit/s.
             */
            ret = INCOMING_CTRL;
         }  
         else
         {
            /* outgoing conn is a non-single rate call */
            switch (outCon->outC.mulRateConFlg)
            {
               case SI_N64_CONN:
                  /* second is a N*64 kbit/s connection type call. Determind by the
                   * bilateral agreement. Need check which
                   * exchange is the control one
                   */ 
                  if (affeCir->cfg.ctrlMult == LSI_CIR_MRATE_CTRL)
                     /* ISUP acts as the controlling end, discard the received 
                      * incoming IAM 
                      */
                     ret = OUTGOING_CTRL;
                  else
                     /* peer end acts as the controlling end, accept the received
                      * incoming IAM
                      */
                     ret = INCOMING_CTRL;
                  break;

               case SI_MULTI_CONN:
                  /* the outgoing is a multirate conn. type call. Check the 
                   * incoming call connection type
                   */
                  if (incN64Flg)
                  {
                     /* incoming is a N*64 kbit/s connection type call. 
                      * Determined by the bilateral agreement. Need check which
                      * exchange is the control one
                      */ 
                     if (affeCir->cfg.ctrlMult == LSI_CIR_MRATE_CTRL)
                        /* ISUP acts as the controlling end, discard the received 
                         * incoming IAM */
                        ret = OUTGOING_CTRL;
                     else
                        /* peer end acts as the controlling end, accept the 
                         * received incoming IAM
                         */
                        ret = INCOMING_CTRL;
                  }
                  else
                  {
                     /* incoming conn is also a multirate conn. type call. 
                      * Determined by the number of N. Higher N controll.
                      */
               
                     if (incNumMultCkts > outCon->outC.numMulRateCkts)
                        ret = INCOMING_CTRL;
                     if (incNumMultCkts < outCon->outC.numMulRateCkts)
                        ret = OUTGOING_CTRL;
                     if (incNumMultCkts == outCon->outC.numMulRateCkts)
                     {
#if (ERRCLASS & ERRCLS_DEBUG)
                        if (incNumMultCkts == 0)
                        {
                           SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                            "number of circuit involved in incoming conn. on cir\
                             %#lx is invalid\n", affeCir->cfg.cirId));  
                           SILOGERROR(ERRCLS_DEBUG, ESI675, (ErrVal) 0,
                              "siChkMultiDualSeiz() Failed, \
                               invalid number of circuits ");

                           RETVALUE(RFAILED);
                        }
#endif /* ERRCLASS & ERRCLS_DEBUG */
                        /* both have the same multirate conn. type. the CIC 
                         * used in the IAM should be divided by the number 
                         * of 64 kits/s circuits. Take the integer part as 
                         * the result.
                         */
                        result = (S16) (recvCic / incNumMultCkts);
                        if (result & OE_ODD)
                        {
                           /* result is odd. the exchange with the lower 
                            * singlling point code is the control one
                            */
                           if (affeCir->pIntfCb->cfg.opc < 
                               affeCir->pIntfCb->cfg.phyDpc)
                              ret = OUTGOING_CTRL;
                           else
                              ret = INCOMING_CTRL;
                        }         
                        else
                        {
                           /* result is even. the exchange with the higher 
                            * singlling point code is the control one
                            */
                           if (affeCir->pIntfCb->cfg.opc < 
                               affeCir->pIntfCb->cfg.phyDpc)
                              ret = INCOMING_CTRL;
                           else
                              ret = OUTGOING_CTRL;
                        }          
                     } /* end of same of N */
                  } /* end of else */
                  break;

            } /* end of switch */
         } /* end of non-single rate conn */   
         break;
#endif
   }           
   RETVALUE(ret);
} /* end of siChkMultiDualSeiz */   


/*
*
*       Fun:   siProcMRateinCirGrMsg
*
*       Desc:  Process each non-single rate connection if receiving a  
*              CGB or GRS circuit related message. 
*
*       Ret:   ROK       - OK
*              RFAILED   - error
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siProcMRateinCirGrMsg
(
SiCirCb    *mCntrlPtrs[],    /* controlling circuit ptr array */
U8         eventType,        /* event type */     
U8         numCkts           /* size of the array */
)
#else
PUBLIC S16 siProcMRateinCirGrMsg(mCntrlPtrs, eventType, numCkts)
SiCirCb    *mCntrlPtrs[];    /* controlling circuit ptr array */
U8         eventType;        /* event type */     
U8         numCkts;          /* size of the array */
#endif
{
   SiCon   *siCntrlCon;       /* connection block of each non-single rate call */
   SiCirCb *tmpCir;           /* circuit cb */
   U8      conFlwDirFlg;      /* outgoing/incoming conn flag */
   U8      counter;

   TRC2(siProcMRateinCirGrMsg)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (mCntrlPtrs == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "the controlling ckt block pointer missing.\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI676, (ErrVal) 0, 
                 "siProcMRateinCirGrMsg() Failed, pointer to ctrl cir missing");
      RETVALUE(RFAILED);
   }
#endif

   /* initialize the conFlwDirFlg to BOTHWAY conn */
   conFlwDirFlg = BOTHWAY;

   /* process each non-single rate connection by calling siActDat directly */
   for (counter = 0; counter < numCkts; counter++)
   {
      /* get conn. Cb in the cntrl cir */
      siCntrlCon = mCntrlPtrs[counter]->siCon;

      if (siCntrlCon == NULLP) 
      {
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
           "conn. Cb is NULLP for a non-single rate with cntrl cirID(%#lx)\n",
                 mCntrlPtrs[counter]->key.k1.cirId));  
       
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI677, (ErrVal) 0,
                    "siProcMRateinCirGrMsg():no conn. Cb in a non-single rate call");
#endif
         RETVALUE(RFAILED); 
      }

      /* Determine the conn flow direction first. The reason is that, after 
       * jumping to the connection state matrix function, the connection
       * might be cleared. Store this info and use it when reset the mulReset
       * flag
       */
      if ((siCntrlCon->incC.conPrcs) &&
          (siCntrlCon->incC.cirId == mCntrlPtrs[counter]->cfg.cirId))
         conFlwDirFlg = INCOMING;
      if ((siCntrlCon->outC.conPrcs) &&
          (siCntrlCon->outC.cirId == mCntrlPtrs[counter]->cfg.cirId))
         conFlwDirFlg = OUTGOING;

      switch (eventType)
      {
         case CEI_GRSREQ:
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case CEI_GRSREQ\n"));  

            /* jump to the connection state matrix to process the conn */
            siCntrlCon->resDir = FROM_UPR;
            if (mCntrlPtrs[counter]->resFlag == FALSE)
               siActDat(mCntrlPtrs[counter]->key.k1.cirId, siCntrlCon, 
                        IEI_CIRRES);

            /* change each cir call state in this non-single rate conn.*/
            tmpCir = mCntrlPtrs[counter]->ctrlMultiRateCir;
            while (tmpCir != NULLP)
            {
               SISTATECHNG(tmpCir->calProcStat, TRANS);
               tmpCir = tmpCir->nextMultiRateCir;
            }
            break;

         case CEI_MTCGBREQ:
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case CEI_MTCGBREQ\n"));  
            /* maintenance oriented CGB req */
            siActDat(mCntrlPtrs[counter]->key.k1.cirId, siCntrlCon, 
                     IEI_BLKREQ);
            break;

         case CEI_HWCGBREQ:
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case CEI_HWCGBREQ\n"));  
            /* hardware oriented CGB req */
            siCntrlCon->resDir = FROM_LWR;
            siActDat(mCntrlPtrs[counter]->key.k1.cirId, siCntrlCon, 
                     IEI_CIRRES);
            break;

         case CEI_MTCGB:
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case CEI_MTCGB\n"));  
            /* maintenance oriented CGB from nw */
            siActDat(mCntrlPtrs[counter]->key.k1.cirId, siCntrlCon, IEI_BLKREQ);
            break;

         case CEI_HWCGB:
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case CEI_HWCGB\n"));  
            /* hardware oriented CGB from nw */
            siCntrlCon->resDir = FROM_GRP;
            siActDat(mCntrlPtrs[counter]->key.k1.cirId, siCntrlCon, 
                     IEI_CIRRES);
            break;

         case CEI_GRS:
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case CEI_GRS\n"));  

            /* generate GRS with CAM for ANS95 or multiple RSCs for ITU97 and
             * ETSI v3 to idle all circuits involved in the non-single rate
             * call 
             */
            if (siGenMRateRsc(mCntrlPtrs[counter]) != ROK)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "generate GRS with CAM in ans95 or mulitple RSC in \
                      itu97/etsi v3 failed in siProcMRateinCirGrMsg() \n"));  
               RETVALUE(RFAILED);
            }

            /* defensive check before jump to the connection state matrix.
             * The connection might have been cleared
             * Please note that the mCntrlPtrs store controlling circuit ptr.
             * Here we like to access the connection associated with circuit.
             */
            siCntrlCon = mCntrlPtrs[counter]->siCon;
            if (siCntrlCon == NULLP) 
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, \
                       "connection on controlling ckt is cleared\n"));
               RETVALUE(ROK);
            }

            /* GRS from nw */
            siCntrlCon->resDir = FROM_LWR;
            siActDat(mCntrlPtrs[counter]->key.k1.cirId, siCntrlCon, 
                     IEI_CIRRES);
            break;

#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "invalid eventType in siProcMRateinCirGrMsg\n"));
            SILOGERROR(ERRCLS_DEBUG, ESI678, (ErrVal) 0,
                    "siProcMRateinCirMsg() Failed, invalid event type");
            RETVALUE(RFAILED);
#endif
      }

      /* reset the mulReset. Check if the conn is still existing, if so, 
       * reset the mulReset to FALSE. If the conn is already cleared,
       * the mulReset should be reset already
       */
      siCntrlCon = mCntrlPtrs[counter]->siCon;
      if (siCntrlCon)
      {
         if (conFlwDirFlg == INCOMING)
            siCntrlCon->incC.mulReset = FALSE;
         if (conFlwDirFlg == OUTGOING)
            siCntrlCon->outC.mulReset = FALSE;
      }      
   }
   RETVALUE(ROK);
} /* end of siProcMRateinCirGrMsg */


/*
*
*       Fun:   siStoreCntrlCir
*
*       Desc:  Store the affected controlling circuit of non-single rate 
*              connection when processing a CGB or GRS circuit related message. 
*
*       Ret:   ROK       - OK
*              RFAILED   - error
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siStoreCntrlCir
(
SiCirCb    *mCntrlPtrs[],    /* controlling circuit ptr array */
SiCirCb    *cir,             /* affected cir control block */
U8         *numCkts          /* size of the array ptr */
)
#else
PUBLIC S16 siStoreCntrlCir(mCntrlPtrs, cir, numCkts)
SiCirCb    *mCntrlPtrs[];    /* controlling circuit ptr array */
SiCirCb    *cir;             /* affected cir control block */
U8         *numCkts;         /* size of the array ptr */
#endif
{
   CirCon *cirConPtr;       /* circuit connection ptr */

   TRC2(siStoreCntrlCir)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (mCntrlPtrs == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "the pointer to controlling ckt ptr array missing.\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI679, (ErrVal) 0, 
                 "siStoreCntrlCir() Failed, pointer to ctrl cir missing");
      RETVALUE(RFAILED);
   }

   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "the affected ckt %#lx pointer missing.\n", cir->cfg.cirId));  

      SILOGERROR(ERRCLS_DEBUG, ESI680, (ErrVal) 0, 
                 "siStoreCntrlCir() Failed, pointer to affected cir missing");
      RETVALUE(RFAILED);
   }
#endif

   /* Check if the affected cir involved in a non-single rate call. 
    * If so, check if the mulReset is set. 
    * If mulReset in not set to TRUE, need to set the muReset to TRUE 
    * and store the ctrlMultiRateCir in the local array 
    * mCntrlPtrs. By setting the flag mulReset to TRUE, when it 
    * jumps to the circuit state matrix funct, it would not process 
    * the connection Cb
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      if (cir->ctrlMultiRateCir->siCon != NULLP)
      {
         /* check if the mulReset is FALSE. If so, set them to TRUE and
          * store the controlling cir cb. Otherwise, no processing is
          * required.
          * By setting mulReset to TRUE, it would not process the 
          * connection cb when it jumps into the circuit state matrix 
          * function to avoid multiple processing for a non-single rate call.
          */
         cirConPtr = siSelectCirCon(cir->ctrlMultiRateCir->siCon,
                                    cir->ctrlMultiRateCir->cfg.cirId);

         if (cirConPtr == NULLP)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "incoming/outgoning cir conn. ptr is NULLP for a non-single \
                rate with cntrl cirID %ld\n", 
                cir->ctrlMultiRateCir->cfg.cirId));  
            RETVALUE(RFAILED);
         }
   
         /* check if the mulReset is set to TRUE. If so, store the
          * the controlling cir cb
          */
         if (cirConPtr->mulReset == FALSE )
         {
            cirConPtr->mulReset = TRUE;
            mCntrlPtrs[*numCkts] = cir->ctrlMultiRateCir;
            (*numCkts)++;
         }
      }
      else
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "conn. Cb is NULLP for a non-single rate with cntrl cirID %ld\n",
          cir->ctrlMultiRateCir->cfg.cirId));  
         RETVALUE(RFAILED);
      }
   }

   RETVALUE(ROK);
} /* end of siStoreCntrlCir */

/*
*
*       Fun:   siJumpMRatefrmCirMsg
*
*       Desc:  Jump to the connection state matrix to process the non-single
*              rate connection when in the circuit processing matrix.
*
*       Ret:   ROK       - OK
*              RFAILED   - error
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siJumpMRatefrmCirMsg
(
SiCirCb    *ctrlCir,         /* non-single rate cntrl cir cb */
U8         msgType,          /* message type when jump to the conn matrix */     
U8         fsmEvnt,          /* circuit message event */
U8         resDir            /* direction of reset direction */
)
#else
PUBLIC S16 siJumpMRatefrmCirMsg(ctrlCir, msgType, fsmEvnt, resDir)
SiCirCb    *ctrlCir;         /* non-single rate cntrl cir cb */
U8         msgType;          /* message type when jump to the conn matrix */     
U8         fsmEvnt;          /* circuit message event */
U8         resDir;           /* direction of reset direction */
#endif
{
   SiCirCb  *tmpCir;         /* temp. circuit cb */

   TRC2(siJumpMRatefrmCirMsg)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (ctrlCir == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "the controlling ckt block of ckt %#lx missing.\n",
              ctrlCir->cfg.cirId));  

      SILOGERROR(ERRCLS_DEBUG, ESI681, (ErrVal) 0, 
                 "siJumpMRatefrmCirMsg() Failed, pointer to ctrl ckt missing");
      RETVALUE(RFAILED);
   }
#endif

   /* call the siActDat function base on the circuit msg event */
   switch (fsmEvnt)
   {
      case CEI_BLOREQ:
      case CEI_BLO:
         /* jump to the connection state matrix */
         if (ctrlCir->siCon != NULLP)
         {
            siActDat(ctrlCir->cfg.cirId, ctrlCir->siCon, msgType);
         }
         else
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "connection on controlling ckt(%#lx) is NULLP\n",
                      ctrlCir->cfg.cirId));
            RETVALUE(RFAILED);
         }
         break;

      case CEI_RESREQ:
      case CEI_MTCGBREQ:
      case CEI_HWCGBREQ:
      case CEI_MTCGB:
      case CEI_HWCGB:
      case CEI_GRSREQ:
         /* jump to the connection state matrix */
         if (ctrlCir->siCon != NULLP)
         {
            /* check the mulReset flag */
            if ((ctrlCir->siCon->incC.conPrcs) &&
                (ctrlCir->siCon->incC.cirId == ctrlCir->cfg.cirId) &&
                (ctrlCir->siCon->incC.mulReset == FALSE))
            {
               /* if the reset direcition is present, set the resDir 
                * in the conn cb for reset procedure
                */
               if (resDir != NOTPRSNT)
                  ctrlCir->siCon->resDir = resDir;
               siActDat(ctrlCir->cfg.cirId, ctrlCir->siCon, msgType);
 
               /* for RSC req and GRS req, change each cir call state in 
                * this non-single rate call
                */
               if ((fsmEvnt == CEI_GRSREQ) || (fsmEvnt == CEI_RESREQ))
               {
                  tmpCir = ctrlCir;
                  while (tmpCir != NULLP)
                  {
                     SISTATECHNG(tmpCir->calProcStat, TRANS);
                     tmpCir = tmpCir->nextMultiRateCir;
                  }
               }
            }
            else
            {
               if ((ctrlCir->siCon->outC.conPrcs) &&
                   (ctrlCir->siCon->outC.cirId == ctrlCir->cfg.cirId) &&
                   (ctrlCir->siCon->outC.mulReset == FALSE))
               {
                  /* if the reset direcition is present, set the resDir 
                   * in the conn cb for reset procedure
                   */
                  if (resDir != NOTPRSNT)
                     ctrlCir->siCon->resDir = resDir;
                  siActDat(ctrlCir->cfg.cirId, ctrlCir->siCon, msgType);
                  /* for RSC req and GRS req, change each cir call state in 
                   * this non-single rate call
                   */
                  if ((fsmEvnt == CEI_GRSREQ) || (fsmEvnt == CEI_RESREQ))
                  {
                     tmpCir = ctrlCir;
                     while (tmpCir != NULLP)
                     {
                        SISTATECHNG(tmpCir->calProcStat, TRANS);
                        tmpCir = tmpCir->nextMultiRateCir;
                     }
                  }
               }
            } /* end of outgoing conn */

         }
         else
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "connection on controlling ckt(%#lx) is NULLP\n",
                      ctrlCir->cfg.cirId));
            RETVALUE(RFAILED);
         }
         break;

      case CEI_GRS:
      case CEI_RES:
         /* jump to the connection state matrix */
         if (ctrlCir->siCon != NULLP)
         {
            /* check the mulReset flag */
            if ((ctrlCir->siCon->incC.conPrcs) &&
                (ctrlCir->siCon->incC.cirId == ctrlCir->cfg.cirId) &&
                (ctrlCir->siCon->incC.mulReset == FALSE))
            {
               /* ISUP received a RSC or GRS msg, if affected circuit is 
                * involved in a non-single rate call. ISUP need generate GRS 
                * with CAM for ANS95 or multiple RSCs for ITU97 and ETSI v3 
                * to idle all circuits involved in the non-single rate call. 
                * Call the siGenMRateRsc() after checking the mulReset. 
                * In siGenMRateRsc(), the mulReset is reset. However, we need 
                * to keep the mulReset consistent for handling GRS msg. 
                */
               if (siGenMRateRsc(ctrlCir) != ROK)
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                       "Generate reset procedures  on controlling ckt(%#lx) \
                         when recv RSC/GRS msg failed\n",
                         ctrlCir->cfg.cirId));
                  RETVALUE(RFAILED);
               }

               /* defensive check before jump to the connection state matrix.
                * The connection might have been cleared
                */
               if (ctrlCir->siCon == NULLP)
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "connection on controlling ckt is cleared\n"));
                  RETVALUE(ROK);
               }

               /* set the resDir in the conn cb for reset procedure */
               ctrlCir->siCon->resDir = resDir;
               siActDat(ctrlCir->cfg.cirId, ctrlCir->siCon, msgType);

            }
            else
            {
               if ((ctrlCir->siCon->outC.conPrcs) &&
                   (ctrlCir->siCon->outC.cirId == ctrlCir->cfg.cirId) &&
                   (ctrlCir->siCon->outC.mulReset == FALSE))
               {
                  /* ISUP received a RSC or GRS msg, if affected circuit is 
                   * involved in a non-single rate call. ISUP need generate GRS 
                   * with CAM for ANS95 or multiple RSCs for ITU97 and ETSI v3 
                   * to idle all circuits involved in the non-single rate call. 
                   * Call the siGenMRateRsc() after checking the mulReset. 
                   * In siGenMRateRsc(), the mulReset is reset. However, we need 
                   * to keep the mulReset consistent for handling GRS msg. 
                   */
                  if (siGenMRateRsc(ctrlCir) != ROK)
                  {
                     SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                          "Generate reset procedures  on controlling ckt(%#lx) \
                            when recv RSC/GRS msg failed\n",
                            ctrlCir->cfg.cirId));
                     RETVALUE(RFAILED);
                  }

                  /* defensive check before jump to the connection state matrix.
                   * The connection might have been cleared
                   */
                  if (ctrlCir->siCon == NULLP)
                  {
                     SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                         "connection on controlling ckt is cleared\n"));
                     RETVALUE(ROK);
                  }

                  /* set the resDir in the conn cb for reset procedure */
                  ctrlCir->siCon->resDir = resDir;
                  siActDat(ctrlCir->cfg.cirId, ctrlCir->siCon, msgType);
               }
            } /* end of outgoing conn */
         }
         else
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "connection on controlling ckt(%#lx) is NULLP\n",
                      ctrlCir->cfg.cirId));
            RETVALUE(RFAILED);
         }
         break;
         
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "invalid cir msg type %d in siJumpMRatefrmCirMsg\n",
                 fsmEvnt));
         SILOGERROR(ERRCLS_DEBUG, ESI682, (ErrVal) 0,
                  "siJumpMRatefrmCirMsg() Failed, invalid cir msg type");
         RETVALUE(RFAILED);
#endif
         
   }
   RETVALUE(ROK);
} /* end of siJumpMRatefrmCirMsg */

/*
*
*       Fun:   siGenMRateLnk
*
*       Desc:  Generate the linkage of the affected circuits in an outgoing 
*              non-single rate call.
*
*       Ret:   ROK     - ok
*              RFAILED - error
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenMRateLnk
(
SiCon     *con,              /* the conntection cntrl block */
U32       mapVal,            /* CAM map value */
U8        transRate,         /* transfer rate for this non-single rate call */
U8        maxNumCir,         /* Max. num involved in a non-single rate call */
Bool      contiMRateCall,    /* contiguous or non-contiguous call */
U8        multiplier         /* number of circuits */
)
#else
PUBLIC S16 siGenMRateLnk(con, mapVal, transRate, maxNumCir, contiMRateCall,
                          multiplier)
SiCon     *con;              /* the conntection cntrl block */
U32       mapVal;            /* CAM map value */
U8        transRate;         /* transfer rate for this non-single rate call */
U8        maxNumCir;         /* Max. num involved in a non-single rate call */
Bool      contiMRateCall;    /* contiguous or non-contiguous call */
U8        multiplier;        /* number of circuits */
#endif
{
   SiCirCb  *cir;            /* cir Cb which have conn cb */
   Bool     mRateN64Flg;     /* N*64 type non-single rate call flag */
   SiCirCb  *mRateCir;       /* affected cir control block */
   Cic      startCic;        /* 1st CIC in non-singlerate call */
   U8       conSlotId;       /* 1st slotId in non-singlerate con */
   CirId    cntrlCirId;      /* 1st circuit Id */
   U8       numCir;          /* num of bits set in CAM */
   Bool     chkTable;        /* Q763 table 3 checking flg */
   SiCirKey key;             /* key of circuit */
   U32      mask;            /* mask of CAM */
   SiCirCb  *prev_cir;
   U8       i;
   U8       frmStartCic;                         
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   U8       prevSlotId;      /* previous slotId in non-singlerate con */
#endif

   TRC2(siGenMRateLnk)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "connection control block pointer missing\n"));
      SILOGERROR(ERRCLS_DEBUG, ESI683, (ErrVal) 0,
                 "siGenMRateLnk() Failed, conn. control block pointer missing");
      RETVALUE(RFAILED);
   }
#endif

   cir = con->outC.cir;

#if (ERRCLASS & ERRCLS_DEBUG)
   /* check the cir and cir->pIntfCb pointer */
   if (siChkCirIntf(cir) != ROK)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "no controlling circuit control block or no interface cb ptr\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI684, (ErrVal) 0, 
                 "siGenMRateLnk() Failed, \
                 pointer to cntrl circuit or interface cb missing");
      RETVALUE(RFAILED);
   }
#endif

   /* initialize the variable */
   mRateCir = NULLP;
   prev_cir = con->outC.cir;
   cntrlCirId = con->outC.cir->cfg.cirId;
   conSlotId = con->outC.cir->cfg.slotId & LSI_CIR_SLOTID_MASK;   
                                                      /* get the slot info */
   startCic = con->outC.cir->key.k2.cic;
   mask = 0x01;
   numCir = 0;
   chkTable = FALSE;
   mRateN64Flg = TRUE;
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   prevSlotId = 0;
#endif

   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
   key.k2.intfId = con->outC.cir->key.k2.intfId;
      
   if (!contiMRateCall)
   {
      /* it is a non-contiguous N*64 kbit/s multirate call */
      for ( i = ((cir->pIntfCb->cfg.trunkType == LSI_TRUNKTYP_E1)?1:0), 
                 frmStartCic = 0; i < maxNumCir; i++, mask <<= 0x01)
      {
         key.k2.cic = startCic + frmStartCic;
         /* check if the bit of the map is set to 1 */
         if (mapVal & mask)
         {
            /* check if this is the first CIC, if yes, reset the counter. */
            if (conSlotId == i)
            {
               frmStartCic = 0;
               key.k2.cic = startCic;
            }

            /* find the circuit */
            siFindCir(&siCb.cirHlCp, &mRateCir, &key, 0, KEY_CICINTF);
            /* if circuit could not found, generate err log and leave the
               loop
             */
            if (mRateCir == NULLP)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                      "can't find circuit for non-conti N*64 multi call\n")); 
               RETVALUE (RFAILED);
            }
          
            /* update the statistics info on non-controlling circuit */
            if (conSlotId != i)
               mRateCir->sts->numNonCont++;

            BLDMRATELNK(mRateCir, prev_cir, cir);
            prev_cir = mRateCir;

            numCir++;
        }   
         
        /* check if num of used bit exceed N */
        if (numCir > multiplier)
           break;

        mRateCir = NULLP;
        frmStartCic++;
     }
  }
  else
  {
     /* this is contiguous call 
      * First see if the checking the starting cic base on Q.763 table 3 part 1 
      * or part 2 is performed or not for ITU97 and ETSIV3. If so, set the 
      * chkTable to TRUE. 
      * Then determine if the call is the multirate conn
      * type call by our interpretation. At this point, we know the validation
      * for the starting Cic base on the table is performed or not.
      */
     switch (con->tCallCb->cfg.swtch)
     {

#if (SS7_ITU97 || SS7_ITU2000)
        case LSI_SW_ITU97:
        case LSI_SW_ITU2000:
           if ((transRate >= TMR_2X64KBITS) && (transRate <= TMR_1920KBITS))
           {
              /* need to see if Q.763 table 3 part checking is required
               * If so, then this call is multirate connection type call by
               * our interpretation. And set the chkTable to TRUE.
               */
              if (cir->pIntfCb->cfg.checkTable & LSI_CHKTBLE_MRATE)
              {
                 chkTable = TRUE;
                 mRateN64Flg = FALSE;
              }   
           }
           else
           {
              /* this is a contigous N*64 kbits/s call, Q763 table 3 part 2
               * should be checked if this checking is required
               */
              if (cir->pIntfCb->cfg.checkTable & LSI_CHKTBLE_FIXCNTG)
                 chkTable = TRUE;
           }   
           break;
#endif

#ifdef SS7_RUSS2000
        case LSI_SW_RUSS2000:
           if ((transRate >= TMR_2X64KBITS) && (transRate <= TMR_1920KBITS))
           {
              /* need to see if Q.763 table 3 part checking is required
               * If so, then this call is multirate connection type call by
               * our interpretation. And set the chkTable to TRUE.
               */
              if (cir->pIntfCb->cfg.checkTable & LSI_CHKTBLE_MRATE)
              {
                 chkTable = TRUE;
                 mRateN64Flg = FALSE;
              }   
           }
           else
           {
              /* this is a contigous N*64 kbits/s call, Q763 table 3 part 2
               * should be checked if this checking is required
               */
              if (cir->pIntfCb->cfg.checkTable & LSI_CHKTBLE_FIXCNTG)
                 chkTable = TRUE;
           }   
           break;
#endif


#if (ERRCLASS & ERRCLS_DEBUG)
        default:
           SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                     "swtch is not ans95/itu97/etsi v3, invalid %d\n", 
                       cir->pIntfCb->cfg.swtch));
           SILOGERROR(ERRCLS_DEBUG, ESI686, (ErrVal) 0,
                         "siGenMRateLnk Failed, invalid configuration swtch");
           RETVALUE(RFAILED);
#endif
     }

     i = multiplier;
     key.k2.cic = startCic;

     while ( i != 0 )
     {
        /* find the circuit */
        siFindCir(&siCb.cirHlCp, &mRateCir, &key, 0, KEY_CICINTF);
        if (mRateCir == NULLP)
        {
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
            /* if this is the circuit with slotId 16. If so, the circuit might
             * not be configured. This is OK according to the Q.763 table 3.
             * We just allocate the next available circuit
             */
            if ((con->tCallCb->cfg.swtch == LSI_SW_ITU97) || 
                (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) || 
                (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) || 
                (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3))
            {
               if (prevSlotId == 15)
               {
                  key.k2.cic++;
                  continue;
               }
               else
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                   "can't find circuit for non-single rate call\n")); 
                  RETVALUE(RFAILED);
               }
            }   
             
#endif
        } 
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
        if ((con->tCallCb->cfg.swtch == LSI_SW_ITU97) ||
            (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) ||
            (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) ||
            (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3))
        {              
           /* get the slotId of this circuit */
           prevSlotId = mRateCir->cfg.slotId & LSI_CIR_SLOTID_MASK;

           /* check the circuit can be used for contigous call (or
            * skipped)
            */
                      
           if (!(siChkSkipCkts(mRateCir, chkTable)))
           {
              BLDMRATELNK(mRateCir, prev_cir, cir);
              prev_cir = mRateCir;
              i--;
            } /* else, just skip the cic */
         }         
#endif

         /* update the statistics info on non-controlling circuit */
         if (key.k2.cic != startCic)
             mRateCir->sts->numNonCont++;

         key.k2.cic++;
         mRateCir = NULLP;
     }     
  }

  /* update the field on circuit connection block */
  con->outC.numMulRateCkts = multiplier;

  if (mRateN64Flg)
     con->outC.mulRateConFlg = SI_N64_CONN;
  else
     con->outC.mulRateConFlg = SI_MULTI_CONN;

  RETVALUE(ROK);
} /* end of siGenMRateLnk */


/*
*
*       Fun:   siGetMRateInfo
*
*       Desc:  Validate the non-single rate related variables in the IAM msg
*              or ConEvnt. 
*
*       Ret:   ROK     - ok
*              RNA     - error, need to generate release in the calling function
*              RFAILED - error.
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siGetMRateInfo
(
SiCon       *con,              /* the conntection cntrl block */
SiConEvnt   *siConEvnt,        /* pointer to the siConEvnt structure */
SiCirCb     *cir,              /* controlling circuit cb */
U8          *transRate,        /* transfer rate for this non-single rate call */
U8          *multiplier,       /* number of circuits */
U8          *maxNumCir,        /* Max. num involved in a non-single rate call */
U32         *mapVal,           /* CAM map value */
Bool        *contiMRateCall,   /* contiguous or non-contiguous call */
Bool        flwDirFlg          /* flow dir flag, upper (TRUE)/lower (FALSE)*/
)
#else
PUBLIC S16 siGetMRateInfo(con, siConEvnt, cir, transRate, multiplier,
                          maxNumCir, mapVal, contiMRateCall, flwDirFlg)
SiCon       *con;              /* the conntection cntrl block */
SiConEvnt   *siConEvnt;        /* pointer to the siConEvnt structure */
SiCirCb     *cir;              /* controlling circuit cb */
U8          *transRate;        /* transfer rate for this non-single rate call */
U8          *multiplier;       /* number of circuits */
U8          *maxNumCir;        /* Max. num involved in a non-single rate call */
U32         *mapVal;           /* CAM map value */
Bool        *contiMRateCall;   /* contiguous or non-contiguous call */
Bool        flwDirFlg;         /* flow dir flag, upper (TRUE)/lower (FALSE)*/
#endif
{
   SiTxMedReq      txMedReq;     /* transmission medium requirement */
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
   SiCirAsgnMap    cirAsgnMap;   /* circuit assignment map */
#endif
   Swtch           swtch;        /* swtch type */
   S16 ret;

   TRC2(siGetMRateInfo)

#if (ERRCLASS & ERRCLS_DEBUG)
   /* check the cir and cir->pIntfCb pointer */
   if (siChkCirIntf(cir) != ROK)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "no controlling circuit control block or no interface cb ptr\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI687, (ErrVal) 0, 
                 "siGetMRateInfo() Failed, \
                 pointer to cntrl circuit or interface cb missing");
      RETVALUE(RFAILED);
   }
#endif

   /* initialization */
   swtch = cir->pIntfCb->cfg.swtch;

   cmMemset((U8 *)&txMedReq, (U8)NOTPRSNT, sizeof(SiTxMedReq));
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
   cmMemset((U8 *)&cirAsgnMap, (U8)NOTPRSNT, sizeof(SiCirAsgnMap));
#endif

   /* fetch the required parameters from con or siConEvnt base on the flow 
    * direction 
    */
   switch (swtch)
   {

#if (SS7_ITU97 || SS7_ITU2000)
     case LSI_SW_ITU97:
     case LSI_SW_ITU2000:
        /* check the flow direction and get the info */
        if (flwDirFlg)
        {
           /* It is from upper, get the info from siConEvnt */
           txMedReq = siConEvnt->txMedReq;
           cirAsgnMap = siConEvnt->cirAsgnMap;
        }
        else
        {
           /* it is from lower, get the info from con */
           txMedReq = con->pduSp->m.initAddr.txMedReq;
           cirAsgnMap = con->pduSp->m.initAddr.cirAsgnMap;
        }
        break;
#endif

#ifdef SS7_RUSS2000
     case LSI_SW_RUSS2000:
        /* check the flow direction and get the info */
        if (flwDirFlg)
        {
           /* It is from upper, get the info from siConEvnt */
           txMedReq = siConEvnt->txMedReq;
           cirAsgnMap = siConEvnt->cirAsgnMap;
        }
        else
        {
           /* it is from lower, get the info from con */
           txMedReq = con->pduSp->m.initAddr.txMedReq;
           cirAsgnMap = con->pduSp->m.initAddr.cirAsgnMap;
        }
        break;
#endif


#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "swtch is not ans95/itu97/etsi v3, invalid %d\n", 
                    swtch));
         SILOGERROR(ERRCLS_DEBUG, ESI690, (ErrVal) 0,
                 "siGetMRateInfo() Failed, invalid configuration switch");
         RETVALUE(RFAILED);
#endif
   }
           
   /* Get the info from the parameters. Determined the contiguous or non-contiguous
    * non-single rate call. 
    */
   switch (swtch)
   {
#if (SS7_ITU97 || SS7_ITU2000)
      case LSI_SW_ITU97:
      case LSI_SW_ITU2000:
         if (txMedReq.trMedReq.pres)
         {
            *transRate = txMedReq.trMedReq.val;
         }
         else
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "transfer rate %d doesn't exist \n", 
                    *transRate));
            RETVALUE(RFAILED);
         }

         if (*transRate > TMR_64KBITSPREF)
         {
            /* get the value of N */
            ret = siGetNumCkts(swtch, *transRate, multiplier);
            if (ret == RFAILED)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "invalid multiplier %d in non-single rate conn\n", 
                    *multiplier));
               RETVALUE(RFAILED);
            }
            /* check if it is contiguous */
            if (cirAsgnMap.eh.pres)
            {
               /* verify the map type with the trunk group */
               if (cirAsgnMap.mapType.pres)
               {
                  /* Validate the map type. If it got failure, return RNA. In 
                   * the calling function, ISUP will release the request
                   */
                  if (siValMapinCAM(cir, cirAsgnMap.mapType.val) != ROK)
                  {
                     SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                         "siValMapinCAM returned failure\n"));
#if (ERRCLASS & ERRCLS_DEBUG)
                     SILOGERROR(ERRCLS_DEBUG, ESI697, (ErrVal) 0,
                          "siGetMRateInfo() Failed, invalid map format type");
#endif
                     RETVALUE(RNA);
                  }
               }
#if (ERRCLASS & ERRCLS_DEBUG)
               else
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                     "Map type value is not present in non-single rate conn\n"));
                  SILOGERROR(ERRCLS_DEBUG, ESI698, (ErrVal) 0,
                          "siGetMRateInfo() Failed, Map type is not present");
                  RETVALUE(RFAILED);
               }
#endif
               *contiMRateCall = FALSE;
               if (cirAsgnMap.mapFormat.pres)
                  *mapVal = cirAsgnMap.mapFormat.val;
#if (ERRCLASS & ERRCLS_DEBUG)
               else
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid map format value %ld in non-single rate conn\n", 
                       *mapVal));
                  SILOGERROR(ERRCLS_DEBUG, ESI699, (ErrVal) 0,
                             "siGetMRateInfo() Failed, invalid map value");
                  RETVALUE(RFAILED);
                }
#endif
               /* check the circuit trunk type to determine allowed 
                * max. # circuit involved in a non-single rate
                * call.
                */
               if (cir->pIntfCb->cfg.trunkType == LSI_TRUNKTYP_E1)
                  /* E1 trunk type, max. 32 */
                  *maxNumCir = SI_MAX_NO_OF_CIR;
               else /* T1 type, max. 24 */
                  *maxNumCir = SI_MAX_CIR_24;
            }
         }
#if (ERRCLASS & ERRCLS_DEBUG)
         else
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "invalid transfer rate %d in non-single rate conn\n", 
                    *transRate));
            SILOGERROR(ERRCLS_DEBUG, ESI700, (ErrVal) 0,
                 "siGetMRateInfo() Failed, invalid transfer rate");
            RETVALUE(RFAILED);
         }
#endif
         break;
#endif

#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
         if (txMedReq.trMedReq.pres)
         {
            *transRate = txMedReq.trMedReq.val;
         }
         else
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "transfer rate %d doesn't exist \n", 
                    *transRate));
            RETVALUE(RFAILED);
         }

         if (*transRate > TMR_64KBITSPREF)
         {
            /* get the value of N */
            ret = siGetNumCkts(swtch, *transRate, multiplier);
            if (ret == RFAILED)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "invalid multiplier %d in non-single rate conn\n", 
                    *multiplier));
               RETVALUE(RFAILED);
            }
            /* check if it is contiguous */
            if (cirAsgnMap.eh.pres)
            {
               /* verify the map type with the trunk group */
               if (cirAsgnMap.mapType.pres)
               {
                  /* Validate the map type. If it got failure, return RNA. In 
                   * the calling function, ISUP will release the request
                   */
                  if (siValMapinCAM(cir, cirAsgnMap.mapType.val) != ROK)
                  {
                     SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                         "siValMapinCAM returned failure\n"));
#if (ERRCLASS & ERRCLS_DEBUG)
                     SILOGERROR(ERRCLS_DEBUG, ESI697, (ErrVal) 0,
                          "siGetMRateInfo() Failed, invalid map format type");
#endif
                     RETVALUE(RNA);
                  }
               }
#if (ERRCLASS & ERRCLS_DEBUG)
               else
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                     "Map type value is not present in non-single rate conn\n"));
                  SILOGERROR(ERRCLS_DEBUG, ESI698, (ErrVal) 0,
                          "siGetMRateInfo() Failed, Map type is not present");
                  RETVALUE(RFAILED);
               }
#endif
               *contiMRateCall = FALSE;
               if (cirAsgnMap.mapFormat.pres)
                  *mapVal = cirAsgnMap.mapFormat.val;
#if (ERRCLASS & ERRCLS_DEBUG)
               else
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid map format value %ld in non-single rate conn\n", 
                       *mapVal));
                  SILOGERROR(ERRCLS_DEBUG, ESI699, (ErrVal) 0,
                             "siGetMRateInfo() Failed, invalid map value");
                  RETVALUE(RFAILED);
                }
#endif
               /* check the circuit trunk type to determine allowed 
                * max. # circuit involved in a non-single rate
                * call.
                */
               if (cir->pIntfCb->cfg.trunkType == LSI_TRUNKTYP_E1)
                  /* E1 trunk type, max. 32 */
                  *maxNumCir = SI_MAX_NO_OF_CIR;
               else /* T1 type, max. 24 */
                  *maxNumCir = SI_MAX_CIR_24;
            }
         }
#if (ERRCLASS & ERRCLS_DEBUG)
         else
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "invalid transfer rate %d in non-single rate conn\n", 
                    *transRate));
            SILOGERROR(ERRCLS_DEBUG, ESI700, (ErrVal) 0,
                 "siGetMRateInfo() Failed, invalid transfer rate");
            RETVALUE(RFAILED);
         }
#endif
         break;
#endif


#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "swtch is not ans95/itu97/etsi v3, invalid %d\n", 
                    swtch));
         SILOGERROR(ERRCLS_DEBUG, ESI702, (ErrVal) 0,
                 "siGetMRateInfo() Failed, invalid configuration switch");
         RETVALUE(RFAILED);
#endif
   }   

   RETVALUE(ROK);
} /* end of siGetMRateInfo */


/*
*
*       Fun:   siChkFstBitinCAM
*
*       Desc:  Validate that if the first bit set in CAM parameter indicates i
*              the circuit which received the message.
*
*       Ret:   ROK     - ok
*              RNA     - error, need to take action in the calling function
*              RFAILED - error.
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siChkFstBitinCAM
(
SiCirCb     *cir,              /* controlling circuit cb */
U32         *mapVal            /* pointer to CAM map value */
)
#else
PUBLIC S16 siChkFstBitinCAM(cir, mapVal)
SiCirCb     *cir;              /* controlling circuit cb */
U32         *mapVal;           /* pointer to CAM map value */
#endif
{
   U8       startVal;          /* starting num when scanning the map val */
   U8       maxNumCir;         /* Max. num involved in a non-single rate call */
   U8       conSlotId;         /* 1st slotId in non-singlerate con */
   U32      mask;              /* mask of CAM */
   Bool     found;             /* fist cic and CAM flg */
   U8       i;                 /* counter */

   TRC2(siChkFstBitinCAM)

#if (ERRCLASS & ERRCLS_DEBUG)
   /* check the cir and cir->pIntfCb pointer */
   if (siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* get the controlling circuit slot ID */
   conSlotId = cir->cfg.slotId & LSI_CIR_SLOTID_MASK;  
   found = FALSE;

   /* Determine the starting slot Id base on the variant and trunk type. 
    * In CAM, the first position bit corresponds first circuit is used 
    * in the trunk. 
    * For E1 trunk type exchange, circuit with slotId 0 is unallocated.
    * The first position bit indicates the circuit with slotId 1.
    * However, for T1 trunk type exchange, the circuit with slotId 0
    * can be used. The first position bit in CAM indicates the circuit
    * with slotId 0.
    */
   switch (cir->pIntfCb->cfg.swtch)
   {

#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
     case LSI_SW_ITU97:
     case LSI_SW_ITU2000:
     case LSI_SW_RUSS2000:
     case LSI_SW_ETSIV3:
        /* The maxNumCir and startSlotId determined by the trunk type */
        if (cir->pIntfCb->cfg.trunkType == LSI_TRUNKTYP_E1)
        {
           /* It is E1 trunk type */
           startVal = 1;
           maxNumCir = SI_MAX_NO_OF_CIR;
        }
        else
        {
           /* It is T1 trunk type */
           startVal = 0;
           maxNumCir = SI_MAX_CIR_24;
        }
        break;
#endif

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "swtch is not ans95/itu97/etsi v3, invalid %d\n", 
                    cir->pIntfCb->cfg.swtch));
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI703, (ErrVal) 0,
                 "siChkFstBitinCAM() Failed, invalid configuration switch");
#endif
         RETVALUE(RFAILED);
   }

   /* check the match between CAM and first CIC */  
   for (i = startVal, mask = 0x01; i < maxNumCir; i++, mask <<= 0x01)
   {
      /* check if the bit of the map is set to 1 */
      if (*mapVal & mask)
      {
         if (conSlotId  == i)
            found = TRUE;
         break;
      }
   }

   if (!found)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
             "mismatch between CAM and CIC on circuit %#lx\n", cir->cfg.cirId)); 

      /* the calling function need to take action */
      RETVALUE(RNA);
   }

   RETVALUE(ROK);
} /* end of siChkFstBitinCAM */


/*
*
*       Fun:   siValMapinCAM
*
*       Desc:  Validate that if the map type value in CAM parameter match
*              the trunkType configured.
*
*       Ret:   ROK     - ok
*              RFAILED - error.
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siValMapinCAM
(
SiCirCb     *cir,              /* controlling circuit cb */
U8          mapType            /* CAM map type value */
)
#else
PUBLIC S16 siValMapinCAM(cir, mapType)
SiCirCb     *cir;              /* controlling circuit cb */
U8          mapType;           /* CAM map type value */
#endif
{

   TRC2(siValMapinCAM)

#if (ERRCLASS & ERRCLS_DEBUG)
   /* check the cir and cir->pIntfCb pointer */
   if (siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   switch (cir->pIntfCb->cfg.swtch)
   {

#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3) 
     case LSI_SW_ITU97:
     case LSI_SW_ETSIV3:
     case LSI_SW_RUSS2000:
     case LSI_SW_ITU2000:
        /* if it is a T1 trunk type exchange and map type is 
         * not 1544 kb/s digital path, return RNA. In the
         * calling function, ISUP will release the request
         */
        if ((cir->pIntfCb->cfg.trunkType == LSI_TRUNKTYP_T1) &&
            (mapType != MAPTYPE_DS1))
        {
           SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "invalid map type value %d on interface %#lx with configured \
               trunk type %d in non-single rate conn\n", 
                mapType, cir->pIntfCb->cfg.intfId, 
                cir->pIntfCb->cfg.trunkType));
#if (ERRRCLS_DEBUG)
           SILOGERROR(ERRCLS_DEBUG, ESI705, (ErrVal) 0,
                "siValMapinCAM() Failed, invalid map format type");

#endif
           RETVALUE(RFAILED);
        }
        /* if it is a E1 trunk type exchange and map type is 
         * not 2048 kb/s digital path, return RNA. In the
         * calling function, ISUP will release the request
         */
        if ((cir->pIntfCb->cfg.trunkType == LSI_TRUNKTYP_E1) &&
            (mapType != MAPTYPE_2048))
        {
           SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "invalid map type value %d on interface %#lx with configured \
               trunk type %d in non-single rate conn\n", 
                mapType, cir->pIntfCb->cfg.intfId, 
                cir->pIntfCb->cfg.trunkType));
#if (ERRCLASS & ERRCLS_DEBUG)
           SILOGERROR(ERRCLS_DEBUG, ESI706, (ErrVal) 0,
                "siValMapinCAM() Failed, invalid map format type ");
#endif
           RETVALUE(RFAILED);
        }
        break;
#endif

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "swtch is not ans95/itu97/etsiv3, invalid %d\n", 
                    cir->pIntfCb->cfg.swtch));
         SILOGERROR(ERRCLS_DEBUG, ESI707, (ErrVal) 0,
                 "siValMapinCAM() Failed, invalid configuration switch");
         RETVALUE(RFAILED);
#endif
   }

   RETVALUE(ROK);
} /* end of siValMapinCAM */

/*
*
*       Fun:   siValMRateCkt
*
*       Desc:  Validate the affected circuits indicated in the TMR/transrate or
*              CAM parameter in a non-single rate call. And store the associated
*              circuit into a array. The validation includes: matching with CAM
*              and N and first bit of CAM if CAM is presented, Starting cic
*              according to the Q763 table etc.
*
*       Ret:   ROK     - ok, the circuit can be used.
*              RFAILED - error, need to take action based on the causeVal
*              RNA     - error 
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PRIVATE S16 siValMRateCkt
(
SiCirCb   *cir,              /* the cir cb which recv IAM or ConReq */
Swtch     swtch,             /* swtch type */
U8        maxNumCir,         /* Max. num involved in a non-single rate call */
U32       mapVal,            /* CAM map value */
U8        transRate,         /* transfer rate for this non-single rate call */
Bool      contiMRateCall,    /* contiguous or non-contiguous call */
SiCirCb   *mRateCirPtrs[],   /* Cir Cb pointer array to store the affected cir */
U8        multiplier,        /* number of circuits */
U16       *causeVal,         /* cause value */
Cic       *nullCirCic        /* NULLP circuit cic */
)
#else
PRIVATE S16 siValMRateCkt(cir, swtch, maxNumCir, mapVal, transRate, 
                          contiMRateCall, mRateCirPtrs, multiplier,
                          causeVal, nullCirCic)
SiCirCb   *cir;              /* the cir cb which recv IAM or ConReq */
Swtch     swtch;             /* swtch type */
U8        maxNumCir;         /* Max. num involved in a non-single rate call */
U32       mapVal;            /* CAM map value */
U8        transRate;         /* transfer rate for this non-single rate call */
Bool      contiMRateCall;    /* contiguous or non-contiguous call */
SiCirCb   *mRateCirPtrs[];   /* Cir Cb pointer array to store the affected cir */
U8        multiplier;        /* number of circuits */
U16       *causeVal;         /* cause value */
Cic       *nullCirCic;       /* NULLP circuit cic */
#endif
{
   SiCirCb  *mRateCir;       /* affected cir control block */
   Cic      startCic;        /* 1st CIC in non-singlerate call */
   U8       conSlotId;       /* 1st slotId in non-singlerate con */
   CirId    cntrlCirId;      /* 1st circuit Id */
   U8       numCir;          /* num of cir used in the non-single call */
   Bool     chkTable;        /* Q763 table 3 checking flg */
   SiCirKey key;             /* key of circuit */
   U32      mask;            /* mask of CAM */
   Bool     found;           /* fist cic and CAM flg */
   U8       frmStartCic;     /* the num of Cic from the starting Cic */   
   U8       i;               /* counter */
   S16      ret;             /* return value */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   U8       prevSlotId;      /* previous slotId in non-singlerate con */
#endif

   TRC2(siValMRateCkt)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (mRateCirPtrs == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "pointer to the ckt cb array is missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI708, (ErrVal) 0, 
                 "siValMRateCkt() Failed, pointer to ckt cb array missing");
      RETVALUE(RNA);
   }
   
   /* check the cir and cir->pIntfCb pointer */
   if (siChkCirIntf(cir) != ROK)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "no controlling circuit control block or no interface cb ptr\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI709, (ErrVal) 0, 
                 "siValMRateCkt() Failed, \
                 pointer to cntrl circuit or interface cb missing");
      RETVALUE(RNA);
   }
#endif

   /* initialize the variable */
   mRateCir = NULLP;
   cntrlCirId = cir->cfg.cirId;
   conSlotId = cir->cfg.slotId & LSI_CIR_SLOTID_MASK;   /* get the slot info */
   startCic = cir->key.k2.cic;
   mask = 0x01;
   numCir = 0;
   found = FALSE;
   chkTable = FALSE;
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   prevSlotId = 0;
#endif

   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
   key.k2.intfId = cir->key.k2.intfId;

   /* select the affected circuits and store them in mRateCirPtrs */
   if (!contiMRateCall)
   {
      /* it is a non-contiguous N*64 kbit/s multirate call, check the match
       * between CAM and first CIC. 
       */

      ret = siChkFstBitinCAM(cir, &mapVal);

      if (ret != ROK)
      {
         if (ret == RNA)
         {  
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "mismatch between CAM %#lx and CIC(%#x) for \
                non-conti N*64 multi call\n", mapVal, startCic)); 
            /* return a cause value */
            *causeVal = LSI_CAUSE_CIC_CAM_MISMATCH;
         }

         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "siChkFstBitinCAM return failure \n")); 
         RETVALUE(RFAILED);
      }

      /* start to validate the affected circuits indicated in CAM */
      for ( i = ((cir->pIntfCb->cfg.trunkType == LSI_TRUNKTYP_E1)?1:0), 
            frmStartCic = 0; i < maxNumCir; i++, mask <<= 0x01)
      {
         key.k2.cic = startCic + frmStartCic;
         /* check if the bit of the map is set to 1 */
         if (mapVal & mask)
         {
            /* check if this is the first CIC, if yes, reset the counter. */
            if (conSlotId == i)
            {
               frmStartCic = 0;
               key.k2.cic = startCic;
            }

            /* find the circuit */
            siFindCir(&siCb.cirHlCp, &mRateCir, &key, 0, KEY_CICINTF);
            /* if circuit could not found, generate alarm and release the call
             * on the controlling circuit
             */
            if (mRateCir == NULLP)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                      "can't find circuit for non-conti N*64 multi call\n")); 

               /* return a cause value */
               *causeVal = LSI_CAUSE_INV_CIRCUIT;
               *nullCirCic = key.k2.cic;

               RETVALUE(RFAILED);
             }
             /* check if this circuit can be used for non-contiguous -- slotId
              * bit 6
              */
             if (!(mRateCir->cfg.slotId & LSI_CIR_NON_CONTIGOUS))
             {
                SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                       "circuit does not allow non-conti N*64 multi call\n")); 

               /* return a cause value */
               *causeVal = LSI_CAUSE_UNEX_CAM;
               RETVALUE(RFAILED);
             }
          
             mRateCirPtrs[numCir] = mRateCir;
             numCir++;
         }   
         
         mRateCir = NULLP;
         frmStartCic++;
      }

      /* check if num of used bit mismatched N */
      if (numCir != multiplier)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "mismatch between CAM %#lx and multiplier (N = %d) for \
                non-conti N*64 multi call\n", mapVal, multiplier)); 

         /* return a cause value */
         *causeVal = LSI_CAUSE_N_CAM_MISMATCH;
         RETVALUE(RFAILED);
      }              
   }   
   else
   {
      /* this is multirate connection type call or contiguous N*64 kbits/s
       * call
       */
      /* validate the starting cic */
      switch (swtch)
      {
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
         case LSI_SW_ITU97:
         case LSI_SW_ITU2000:
         case LSI_SW_RUSS2000:
            if ((transRate >= TMR_2X64KBITS) && (transRate <= TMR_1920KBITS))
            {
               /* this is a multirate connection type call, Q.763 table 3 part
                * 1 should be check if this checking is required
                */
               if (cir->pIntfCb->cfg.checkTable & LSI_CHKTBLE_MRATE)
               {
                  /* table 3 part 1 is to be checked */
                  if (siTrunkTbl[cir->pIntfCb->cfg.trunkType][conSlotId][multiplier] 
                      != TRUE)
                  {
                     SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                            "invalid starting cic %#x for multi call\n", 
                            startCic)); 

                     /* return a cause value */
                     *causeVal = LSI_CAUSE_INV_START_CIC;
                     RETVALUE(RFAILED);
                  }
                  chkTable = TRUE;
               } /* else, table not to be checked */
            }
            else
            {
               /* this is a contigous N*64 kbits/s call, Q763 table 3 part 2
                * should be checked if this checking is required
                */
               if (cir->pIntfCb->cfg.checkTable & LSI_CHKTBLE_FIXCNTG)
               {
                  /* table 3 part 2 is to be checked */
                  if (siTrunkTbl[cir->pIntfCb->cfg.trunkType][conSlotId][multiplier] 
                       != TRUE)
                  {
                     SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                            "invalid starting cic %#x for multi call\n",
                            startCic)); 

                     /* return a cause value */
                     *causeVal = LSI_CAUSE_INV_START_CIC;
                     RETVALUE(RFAILED);
                  }
                  chkTable = TRUE;
               } /* else, table not to be checked */
            }   
            break;
#endif
#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "swtch %d is not ans95/itu97/etsi v3, invalid\n", 
                    swtch));
            SILOGERROR(ERRCLS_DEBUG, ESI711, (ErrVal) 0,
                    "siValMRateCkt() Failed, invalid configuration switch");
            RETVALUE(RNA);
#endif
      }

      /* select the affected circuits */
      i = multiplier;
      key.k2.cic = startCic;
      numCir = 0;

      while ( i != 0 )
      {
         /* find the circuit */
         siFindCir(&siCb.cirHlCp, &mRateCir, &key, 0, KEY_CICINTF);

         /* if circuit could not found, generate alarm and release the call
          * on the controlling circuit
          */
         if (mRateCir == NULLP)
         {
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
            /* if this is the circuit with slotId 16. If so, the circuit might
             * not be configured. This is OK according to the Q.763 table 3.
             * We just allocate the next available circuit
             */
            if ((swtch == LSI_SW_ITU97) || 
                (swtch == LSI_SW_ITU2000) || 
                (swtch == LSI_SW_RUSS2000) || 
                (swtch == LSI_SW_ETSIV3))
            {
               if (prevSlotId == 15)
               {
                  key.k2.cic++;
                  continue;
               }
               else
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                        "can't find circuit for multirate or conti N*64 multi call\n")); 
                  /* return a cause value */
                  *causeVal = LSI_CAUSE_INV_CIRCUIT;
                  *nullCirCic = key.k2.cic;
                  RETVALUE(RFAILED);
               }
            }   
             
#endif
         } 

#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         if ((swtch == LSI_SW_ITU97) ||
             (swtch == LSI_SW_ITU2000) ||
             (swtch == LSI_SW_RUSS2000) ||
             (swtch == LSI_SW_ETSIV3))
         { 
            /* get the slotId of this circuit */
            prevSlotId = mRateCir->cfg.slotId & LSI_CIR_SLOTID_MASK;

            /* check the circuit can be used for contigous call (or
             * skipped) 
             */
            if (!(siChkSkipCkts(mRateCir, chkTable)))
            {
               /* circuit can be used */     
               mRateCirPtrs[numCir] = mRateCir;
               numCir++;
               i--;
            } /* else, just skip the cic */
         }   
#endif
         key.k2.cic++;
         mRateCir = NULLP;
      }    
   }
   RETVALUE(ROK);
} /* end of siValMRateCkt */


/*
*
*       Fun:   siDelMRateLnk
*
*       Desc:  Break the linkage of the circuits and reset the related fields in 
*              circuit connnection block for a non-single rate call.
*
*       Ret:   ROK     - ok.
*              RFAILED - error.
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siDelMRateLnk
(
CirCon   *cirC              /* circuit connection(incoming/outgoing) */
)
#else
PUBLIC S16 siDelMRateLnk(cirC)
CirCon   *cirC;             /* circuit connection(incoming/outgoing) */
#endif
{
   SiCirCb   *tmpCir;       /* circuit control block */
   SiCirCb   *prevCir;      /* previous circuit control block */
   TRC2(siDelMRateLnk)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (cirC == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
              "pointer to the ckt connection is missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI712, (ErrVal) 0, 
                 "siDelMRateLnk() Failed, pointer to ckt connection missing");
      RETVALUE(RFAILED);
   }
#endif
 
   /* break the linkage of the circuits */
   prevCir = cirC->cir;                    /* controlling circuit */
   tmpCir = cirC->cir->nextMultiRateCir;   
        
   while (tmpCir != NULLP)
   {
      SISTATECHNG(tmpCir->calProcStat, CALL_IDLE);
      prevCir->nextMultiRateCir = NULLP;
      prevCir->ctrlMultiRateCir = NULLP;
      prevCir = tmpCir;
      tmpCir = tmpCir->nextMultiRateCir;
      if (tmpCir == NULLP)
      {
         /* already reach the last cir cb in the linkage */
         prevCir->ctrlMultiRateCir = NULLP;
      }
   }

   cirC->numMulRateCkts = 1;
   cirC->mulRateConFlg = SI_SINGLE;
   cirC->mulReset = FALSE;

   RETVALUE(ROK);
} /* end of siDelMRateLnk */


/*
*
*       Fun:   siChgRateState
*
*       Desc:  Modify the calProcState of non-controlling circuit in a 
*              non-single rate call.
*
*       Ret:   ROK     - ok.
*              RFAILED - error.
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siChgMRateState
(
SiCirCb  *cir,              /* controlling circuit control block */
U8       state              /* call processing state */
)
#else
PUBLIC S16 siChgMRateState(cir, state)
SiCirCb  *cir;              /* controlling circuit control block */
U8       state;             /* call processing state */
#endif
{
   SiCirCb   *tmpCir;       /* circuit control block */

   TRC2(siChgMRateState)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
              "pointer to the ckt control block missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI713, (ErrVal) 0, 
                 "siChgMRateState() Failed, pointer to ckt cb missing");
      RETVALUE(RFAILED);
   }
#endif
 
   /* Change the circuit progress state on non-controlling circuits */
   tmpCir = cir->nextMultiRateCir;   
        
   while (tmpCir != NULLP)
   {
      SISTATECHNG(tmpCir->calProcStat, state);
      tmpCir = tmpCir->nextMultiRateCir;
   }

   RETVALUE(ROK);
} /* end of siChgMRateState */


/*
*
*       Fun:   siIsMultCirConn
*
*       Desc:  Checks whether cirCon is in a mutirate/N*64 call
*
*       Ret:   TRUE     - yes- multirate/n*64.
*              False    - no - single rate or no conn.
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siIsMultCirConn
(
CirCon  cirCon              /* Circuit conn cb */
)
#else
PUBLIC S16 siIsMultCirConn(cirCon)
CirCon cirCon;              /* Circuit conn cb */
#endif
{
   S16 ret;  /* return value */

   TRC2(siIsMultCirConn)

   ret = ((cirCon.numMulRateCkts > 1) &&
          (cirCon.numMulRateCkts < SI_MAX_NO_OF_CIR)) ?
          TRUE : FALSE;


   RETVALUE(ret);
} /* end of siIsMultCirConn */

  
/*
*
*       Fun:   siChkDualinNonCtrl
*
*       Desc:  Determine which exchange is controlling when ISUP receiving
*              an single rate IAM or a CRM on a non-controlling circuit
*              for an non-single rate outgoing connection before receipt 
*              of first backward message. This is a case that dual seizure
*              happend between a non-single rate outgoing conn and single
*              rate incoming on the non-controlling circuit.
*              Generate a reattemp indication if the outgoing connection
*              need to be cleared.
*
*       Ret:   ROK      - accept the incoming msg
*              RFAILED  - reject the incoming msg or error
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siChkDualinNonCtrl
(
SiCon *con                    /* connection control block */
)
#else
PUBLIC S16 siChkDualinNonCtrl(con)
SiCon *con;                  /* connection control block */
#endif
{
   SiCirCb    *cir;
   SiCauseDgn cause;
   S16        ret;
   Bool       ctrlFlg;      /* contrl flg when dual seizure */

   TRC2(siChkDualinNonCtrl)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "connection control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI714, (ErrVal) 0, 
               "siChkDualinNonCtrl() Failed, pointer to connnection missing");
      RETVALUE(RFAILED);
   }
#endif

   /* get the circuit control block */
   cir = con->incC.cir;
   ctrlFlg = TRUE;

#if (ERRCLASS & ERRCLS_DEBUG)
   /* check the cir and cir->pIntfCb pointer */
   if (siChkCirIntf(cir) != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
          "no circuit associated with the connection or no interface ptr\n"));
 
      SILOGERROR(ERRCLS_DEBUG, ESI715, (ErrVal) 0, 
                 "siChkDualinNonCtrl() Failed, \
                 pointer to circuit missing or interface cb missing");
      RETVALUE(RFAILED);
   }
#endif

   /* initialize cause/diagnostic element */
   MFINITELMT(&con->mCallCb->mfMsgCtl, ret, NULLP, (ElmtHdr *) 
              &cause, &meCauseIndV, (U8) PRSNT_DEF, 
              cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);

   /* check if the circuit involved in other non-single rate call. This
    * could happened because ISUP receives incoming IAM/CRM on 
    * non-controlling circuit. A dual seizure happened. 
    * In the function siChkMRateCtrlCkt(),
    * we allocate a siCon attached to this circuit. Here we determined 
    * which exchange should controll the call.
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* If the circuit involved in another incoming non-single rate 
       * call, this is an error. This type of error should be detected 
       * in siChkMRateCtrlCkt()
       */
      if ((cir->ctrlMultiRateCir->siCon != NULLP) &&
          (cir->ctrlMultiRateCir->siCon->incC.conPrcs) &&
          (cir->ctrlMultiRateCir->siCon->incC.cirId == 
           cir->ctrlMultiRateCir->cfg.cirId))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
            "recv an incoming single rate call on non-cntrl ckt %#lx in a \
            non-single rate call in siChkDualinNonCtrl\n", 
            cir->cfg.cirId)); 
         RETVALUE(RFAILED);
      }   
      
      /* If the circuit involved in another outgoing call, need to 
       * determine which exchange should control in case of dual 
       * seizure. 
       */
      if ((cir->ctrlMultiRateCir->siCon != NULLP) &&
          (cir->ctrlMultiRateCir->siCon->outC.conPrcs) &&
          (cir->ctrlMultiRateCir->siCon->outC.cirId == 
           cir->ctrlMultiRateCir->cfg.cirId))
      {
         /* there exists an outgoing connection. If it has not 
          * received a first backward message, dual seizure happened. 
          */ 
         if ((cir->ctrlMultiRateCir->siCon->outC.conState < 
              ST_WTFORANSWR) 
            )
         {
            /* dual seizure occurred between single rate incoming 
             * conn and outgoing non-single rate call 
             */
            switch (cir->pIntfCb->cfg.swtch)
            {
               case LSI_SW_ANS95:
                  /* For ans95, it uses "all-none" method to slove the 
                   * dual seizure when having at least one non-single 
                   * rate call
                   */
                  if (cir->cfg.ctrlMult == LSI_CIR_MRATE_CTRL)
                     /* outgoing conn control */
                     ctrlFlg = TRUE;
                  else
                     /* discard the incoming conn. */
                     ctrlFlg = FALSE;
                  break;

               case LSI_SW_ITU97:
               case LSI_SW_ITU2000:
               case LSI_SW_RUSS2000:
               case LSI_SW_ETSIV3:
                  /* non-single rate outgoing call control because of 
                   * greater N 
                   */
                  ctrlFlg = TRUE;
                  break;

#if (ERRCLASS & ERRCLS_DEBUG)
               default:
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Variant swtch %d is not ans95/itu97/etsiv3, invalid\n",
                       cir->pIntfCb->cfg.swtch));
 
                  SILOGERROR(ERRCLS_DEBUG, ESI716, 
                             (ErrVal) cir->pIntfCb->cfg.swtch, 
                             "siChkDualinNonCtrl() Failed, \
                              invalide variant swtch type");
                  RETVALUE(RFAILED);
#endif
             }

             /* if exchange is not the controlling one, accept the 
              * incoming IAM and clear the outgoing conn.
              */
             if (!ctrlFlg)
             {
                /* if there required a continuity check, stop it */
                siChkContin(cir->ctrlMultiRateCir->siCon);

                cause.causeVal.pres = PRSNT_NODEF;
                cause.causeVal.val  = SIT_CCREQUNAVAIL;

                /* send reattemp indication on the contrl circuit */
                siGenReatInd(
                   cir->ctrlMultiRateCir->siCon->outC.cir->cfg.cirId, 
                   cir->ctrlMultiRateCir->siCon, &cause);

                cir->ctrlMultiRateCir->siCon->suInstId = 0;
                SISTATECHNG(
                    cir->ctrlMultiRateCir->siCon->outC.cir->calProcStat,
                          CALL_IDLE);

                /* clear the outgoing conn */
                siClearOutCon(cir->ctrlMultiRateCir->siCon);
             }
             else
             {
                /* discard the incoming IAM */
                SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                     "Discard the incoming single rate call on ckt %#lx in \
                      siChkDualinNonCtrl()\n", cir->cfg.cirId)); 
                RETVALUE(RFAILED);
             }
         }
         else
         {
            /* circuit involved in a outgoing call other than 
             * dual seizure. this type of error should be detected 
             * in siChkMRateCtrlCkts()
             */
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "recv an incoming single rate call on non-cntrl ckt\
                 %#lx in a non-single rate call in siChkDualinNonCtrl()\n",
                 cir->cfg.cirId)); 
            RETVALUE(RFAILED);
         }   
      }            
   } /* else, single rate procedure as normal */ 

   RETVALUE(ROK);
} /* end of siChkDualinNonCtrl */
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */


#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
/*
*
*       Fun:   siChkSkipCkts
*
*       Desc:  check if the circuit is skipped or not base on SlotId bit 5 and
*              Q.763 table 3 part 1 or part 2 
*
*       Ret:   TRUE    -  skipped
*              FALSE  -  not skipped
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC Bool siChkSkipCkts
(
SiCirCb *cir,                         /* circuit control blk */
Bool    chkTable                      /* check Q763 table 3 flg */
)
#else
PUBLIC Bool siChkSkipCkts(cir, chkTable)
SiCirCb *cir;                         /* circuit control blk */
Bool    chkTable;                     /* check Q763 table 3 flg */
#endif
{
   TRC2(siChkSkipCkts)

#if (ERRCLASS & ERRCLS_DEBUG)
   /* check the cir and cir->pIntfCb pointer */
   if (siChkCirIntf(cir) != ROK)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "no controlling circuit control block or no interface cb ptr\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI717, (ErrVal) 0, 
                 "siChkSkipCkts() Failed, \
                 pointer to cntrl circuit or interface cb missing");
      RETVALUE(FALSE);
   }
#endif
   if (chkTable == TRUE)
   {
      /* the checking of Q763 table 3 part 1 or part 2 is done for the call,
       * only slotId 16 is skipped for E1 trunk. If the slotId other than 16, the checking
       * for slotId bit 5 is not performed
       */
      if (cir->pIntfCb->cfg.trunkType == LSI_TRUNKTYP_E1)
      {
         /* this is E1 trunk */
         if ((cir->cfg.slotId & LSI_CIR_SLOTID_MASK) == 16)
            RETVALUE(TRUE);
         else
            RETVALUE(FALSE);
      }
      else  /* T1 trunk, not performed slotId bit 5 checking */
         RETVALUE(FALSE);     
              
   }
   else
   {
      /* Q.763 table 3 is not checked, the circuit can be skipped base on the
       * configuration
       */
      if (cir->cfg.slotId & LSI_CIR_SKIP_CONTIGOUS)
         RETVALUE(TRUE);
      else
         RETVALUE(FALSE);     
   }           
} /* end of siChkSkipCkts */        
#endif /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */






/*
*
*       Fun:   siSndCGBinReset
*
*       Desc:  Sending a hardware CGB to nw when processing GRS from network.
*
*       Ret:   ROK      - ok
*              RFAILED  - error
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/
#ifdef ANSI
PUBLIC S16 siSndCGBinReset
(
U8         cirState,             /* circuit state */
SiCirCb    *cir,                 /* circuit control block */
SiRangStat *hRangState,          /* range and status structure */
SiNSAPCb   *mCb                  /* ptr to Lower SAP */
)
#else
PUBLIC S16 siSndCGBinReset(cirState, cir, hRangState, mCb)
U8         cirState;             /* circuit state */
SiCirCb    *cir;                 /* circuit control block */
SiRangStat *hRangState;          /* range and status structure */
SiNSAPCb   *mCb;                 /* ptr to Lower SAP */
#endif
{

   SiAllSdus  outEv;             
   SiCirGrp   *tmpCirGr;         /* tmp circuit group block */
   S16        ret;

   TRC2(siSndCGBinReset)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (mCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "siSndCGBinReset() failed, pointer to lower SAP missing \n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI748, (ErrVal) 0,
                 "siSndCGBinReset() Failed, lower SAP ptr missing");
      RETVALUE(RFAILED);
   }
   if (hRangState == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "siSndCGBinReset() failed, pointer to Range&Status missing \n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI749, (ErrVal) 0,
                 "siSndCGBinReset() Failed, Range&Status ptr missing");
      RETVALUE(RFAILED);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "siSndCGBinReset() failed, pointer to cirgr missing \n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI750, (ErrVal) 0,
                 "siSndCGBinReset() Failed, cirgr ptr missing");
      RETVALUE(RFAILED);
   }

   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* initialize structure to send CGB */
   MFINITSDU(&mCb->mfMsgCtl, ret, (U8) MI_CIRGRPBLK, (U8) SI_STAREQ,
             (ElmtHdr *) NULLP, (ElmtHdr *) &outEv, (U8) NOTPRSNT, 
             cir->pIntfCb->cfg.swtch, (U32) MF_ISUP); 

   outEv.m.siStaEvnt.cgsmti.eh.pres = PRSNT_NODEF;
   outEv.m.siStaEvnt.cgsmti.typeInd.pres = PRSNT_NODEF;
   switch (cirState)
   {
      case SICIR_HWLOCST:
         outEv.m.siStaEvnt.cgsmti.typeInd.val = HARDFAIL;
         break;
      case SICIR_MTLOCST:
         outEv.m.siStaEvnt.cgsmti.typeInd.val = MAINT;
         break;
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "siSndCGBinReset() failed, invalid circuit state \n"));  
         RETVALUE(RFAILED);
   }

   cmMemcpy((U8 *) &outEv.m.siStaEvnt.rangStat, (U8 *) hRangState, 
             sizeof(SiRangStat)); 
      
   /* get the locally hw circuit group control blk */
   if ((tmpCirGr = cir->cirGr[cirState]) == NULLP)
   {
      /* allocate a new circuit group control blk */
      if ((tmpCirGr = siGetCirGr(cir)) == NULLP)
      {
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                "Can not allocate new circuit group\n"));

#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI751, (ErrVal) 0,
                       "siSndCGBinReset() Failed, can't allocate circuit grp");
#endif
         RETVALUE(RFAILED);
      }
/* si049.220 Addition : Range value is intialized */
   cmMemcpy((U8 *) &(tmpCirGr->rangStat), (U8 *) hRangState, 
             sizeof(SiRangStat)); 

      cir->cirGr[cirState] = tmpCirGr;
      tmpCirGr->state = cirState;

   }                 

   tmpCirGr->sduSp = &outEv;
   if (siGenCirGrMsg(tmpCirGr, M_CIRGRPBLK, MI_CIRGRPBLK) == ROK)
   {
      /* start Group Blocking timer */
      siStartCirGrTmr(TMR_T18, tmpCirGr);
      /* start initial Group Blocking timer */
      siStartCirGrTmr(TMR_T19, tmpCirGr);
      /* change states */
      SISTATECHNG(tmpCirGr->state , SICG_ST_WTCGBACK);
   }
   else
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "Sending CGB failed on cir %#lx\n", cir->cfg.cirId));  
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);

} /* end of siSndCGBinReset */


/*
*
*       Fun:   siSndBLOinReset
*
*       Desc:  Sending a BLO to nw when processing GRS from network.
*
*       Ret:   ROK      - ok
*              RFAILED  - error
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siSndBLOinReset
(
SiCirCb   *cir               /* circuit control block */
)
#else
PUBLIC S16 siSndBLOinReset(cir)
SiCirCb   *cir;              /* circuit control block */
#endif
{

   TRC2(siSndBLOinReset)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   cir->noRspFlgToUp = TRUE;
   if (siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId,
                  cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch,
                  M_BLOCK, MI_BLOCK, NULLP, cir->pIntfCb->cfg.ssf,
                  cir->pIntfCb->cfg.nwId) == ROK)
   {
      siStopAllCirTmr(cir);
      siStartCirTmr(TMR_T12, cir);
      siStartCirTmr(TMR_T13, cir);
      cir->transStat[SICIR_MTLOCST] = SICIR_ST_WTBLKACK;
   }
   else
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "Sending BLO failed on cir %#lx\n", cir->cfg.cirId));  
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* end of siSndCGBinReset */

/* si009.220, ADDED: added new function to send message without checking the
 * interface state
 */
  
/*
*
*       Fun:   siSndMsgNoChk
*
*       Desc:  send message
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy5.c
*
*/

#ifdef ANSI
PUBLIC S16 siSndMsgNoChk
(
SiNSAPCb *cb,
Buffer   *mBuf,
Dpc      opc,
SiInstId intfId,
Dpc      phyDpc,  /* physical dpc */
U8       intfflg, /* interface id valid flag */
LnkSel   lnkSel,
Bool     endSeg,
Priority prior,
Swtch    swtch
)
#else
PUBLIC S16 siSndMsgNoChk(cb, mBuf, opc, intfId, phyDpc, intfflg, 
                           lnkSel, endSeg, prior, swtch)
SiNSAPCb *cb;
Buffer  *mBuf;
Dpc      opc;
SiInstId intfId;
Dpc      phyDpc;  /* physical dpc */
U8       intfflg; /* interface id valid flag : TRUE: intfid is valid */
LnkSel lnkSel;
Bool endSeg;
Priority prior;
Swtch swtch;
#endif
{
   Data msgType;
#ifdef SI_SPT
   SpUDatEvnt uData;
#else
   UNUSED(endSeg);
#endif

   TRC2(siSndMsgNoChk)

/* si039.220 - Debug flag changed from DBG4 to DBG5 as DBG4 should be used for error
               cases in mf and not in Tx & Rx
*/
#ifdef DBG5
   /* print transmitted message */
   if (siCb.init.dbgMask & SIDBGMASK_MSGTX)
   {
       SPrntMsg(mBuf, (S16) opc, (S16) phyDpc);
   }
#endif

   /* do trace if needed */
   if (cb->trc)
      siTrcBuf(phyDpc, intfId, (U16 )TL5MSGTX, (U8 )cb->cfg.sapType, mBuf);

   /* If interface id is valid */
   if(intfflg == TRUE) 
   {
      if (SExamMsg((Data *) &msgType, mBuf, (MsgLen) 0x02) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI630, (ErrVal) 0,
                    "siSndMsgNoChk() Failed, can not find PDU type in mBuf");
#endif
         RETVALUE(RFAILED);
      }
   
      /* update transmit statistics counters */
#if (SI_LMINT3 || SMSI_LMINT3)
      siUpdIntfSts(intfId, LSI_STS_TX, msgType);
#else
      {
         U8 tmpCic;
         Cic cic;
   
         tmpCic = 0;
         SExamMsg(&tmpCic, mBuf, 0);
         cic = PutLoByte(cic, tmpCic);
         tmpCic = 0;
         SExamMsg(&tmpCic, mBuf, 1);
         cic = PutHiByte(cic, tmpCic);
   
         siUpdTxSts(cb, cic, intfId, msgType);
      }
#endif
   }  /* if interface id is provided */

   switch (cb->cfg.sapType)
   {
      case SAP_MTP:
      case SAP_M3UA:
         SiLiSntUDatReq(&cb->pst, cb->spId, opc, phyDpc, 
            cb->srvInfo, lnkSel, prior, mBuf);
         break;
#ifdef SI_SPT
      case SAP_SCCP:
         siBldUData(&uData, phyDpc, opc, swtch);
         uData.esc = endSeg;
         uData.prior = prior;
         SiLiSptUDatReq(&cb->pst, cb->spId, &uData, mBuf);
         break;
#endif
   }
   RETVALUE(ROK);
} /* end of siSndMsgNoChk */
  
/********************************************************************30**
  
         End of file:     ci_bdy5.c@@/main/48 - Wed Jul 25 13:20:51 2001

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  jrl   1. initial release. created from portion of
                           ci_bdy1.c
             ---  jrl   2. trillium development system checkpoint (dvs)
                           at version: 1.0.0.0

1.2          ---  jrl   1. change siChkPslgDst declaration from PRIVATE
                           to PUBLIC

1.3          ---  jrl   1. move siSndMsg to ci_bdy1.c
             ---  jrl   2. remove includes for snt.h, snt.x, spt.h and
                           spt.x

1.4          ---  rk    1. miscellaneous changes
             ---  jrl   2. add breaks for default cases

1.5          ---  bn    1. change declaration for siCmpAscStr
             ---  bn    2. change declaration for siChkPslgDst
                           from PRIVATE to PUBLIC

1.6          ---  rk    1. miscellaneous changes

1.7          ---  bn    1. add else break in siFndCircuit and siFndCircuit1
                           when circuit is NULLP

1.8          ---  bn    1. cast TMR_ALL to U8 in siStopCirGrTmr
             ---  bn    2. remove staEvnt from siGrResTmrExp
             ---  bn    3. remove ret from siChkPslgDst

1.9          ---  bn    1. added siPrcUneqMsg.
             ---  bn    2. changed timer routines.
             ---  bn    3. add support for ansi 92.
             ---  bn    4. changed timer routines to common functions.
             ---  bn    5. added include cm5.x and cm5.h.

1.10         ---  bn    1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.11         ---  bn    1. corrected typo's

1.12         ---  bn    1. change event to S16 in TmrEv functions.
             ---  bn    2. save circuit switch in siPrcUneqMsg.
             ---  bn    3. zeroed out cir->cirGrp when tFGR timer expired.
             ---  bn    4. changed to support new interfaces.
 
1.13         ---  bn    1. text changes.

1.14         ---  fmg   1. removed unused variables.
             ---  fmg   2. changes for NOERRCHK

1.15         ---  bn    1. check if unsolicited status generation is enabled
                           before sending Status Indication to SM in siGenAlarm

1.16         ---  bn    1. added functionality for continuity recheck 
                           procedures
             ---  bn    2. added support for Q.767 and Singapore Telecom.

1.17         ---  bn    1. text changes

1.18         ---  bn    1. si007.23.
             ---  bn    2. added Italian Q.767 features.

1.19         ---  bn    1. text changes

1.20         ---  lc    1. miscellaneous changes

1.21         ---  bn    1. additions for Italian Q767.

1.22         ---  bn    1. chnaged SW_... to LSI_SW_...
             ---  bn    2. miscelenious changes.

1.23         ---  bn    1. corrected typo in siCirGrTmrEv.

1.24         ---  bn    1. changed ifdef SP to ifdef SI_SPT.
             ---  bn    2. initialized recommend token to NOTPRSNT inside of
                           siErrorMapFunc for all variants.

1.25         ---  bn    1. changed cause codes in siErrMapFunc.

1.26         ---  bn    1. si003.26 (initialized dgnVal in siErrMapFunc).
             ---  bn    2. changed LSI_SW_CCITT to LSI_SW_ITU and 
                           LSI_SW_ANSI?? to LSI_SW_ANS??.

1.27         ---  bn    1. corrected gcc compiler warnings.

1.28         ---  bn    1. necessary recovery actions placed in error scenarios
             ---  bn    2. misceleneous corrections.

1.29         ---  dm    1. misceleneous corrections.

1.30         ---  bn    1. removed SLogError from siGetSCbPtr.

1.31         ---  bn    1. removed #endif from siGetSCbPtr.

1.32         ---  pc    1. added ETSI variant for SI
             ---  bn    2. changed siGenRelUpLw and siGenRelUp not to generate
                           a Release Indication to the upper layer if one has
                           already been sent.
             ---  bn    3. siPrcExitMsg: completed checks on unexpected Exit
                           message.

1.33         ---  bn    1. text change

1.34         ---  bn    1. added test for incoming connection in siPrcExitMsg.

1.35         ---  dm    1. added GT_FTZ variant for SI
             ---  dm    2. added segmantation and reassembly functions.
             ---  dm    3. added tCCRt management for ANSI
                           and siGenRelLw.
             ---  dm    4. added include cm_ss7.[hx]

1.36         ---  bn    1. changed j to S16 in siReassblSegms.

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.37         ---      ao   1. siClearIncCon and siClearOutCon: changed NULLP
                              to pointer to empty buffer when calling SCCP
                              function.
             ---      ao   2. added opc in function siBldUData.
             ---      ao   3. added function siInsCallRef
             ---      ao   4. corrected gcc compile warnings.
             ---      ao   5. added status indication for user part test
                              available in siGenStaInd

1.37         ---      ao   1. added case for ANSI-92 in siInsCallRef 
             ---      ao   2. replaced siCon with siCir->siCon in 
                              siPrcUneqMsg
             ---      ao   3. defined pntCodeA in siInsCallRef for ANSI-92
             ---      ao   4. changed idx in siFndCircuit and siFndCircuit1
                              from U8 to U16.
             ---      ao   5. added case statement in siInsCallRef for 
                              Q.767
             ---      ao   6. added stop of TMR_TCRA in siGenRelUpLw
             ---      ao   7. fixed compilation problem for ANSI-92
             ---      ao   8. Changed init of usta flag.
             ---      ao   9. disabled setting of clli when length is zero
             ---      rh  10. removed the multiple divide by 2 for comparing
                              route addresses
                          11. added UCIC processing facility for ITU option
             ---      ao  12. changes in getinstId() to allocate instance ids 
                              in a round robin fashion.
             ---      ao  13. removed check of tmrCnt when timer expiry
                              for timers t13, t15, t19, t21, and t23
             ---      aa  14. Corrected the patch si013.211
             ---      aa  15. proper double seizing control indicators added
                              in siValCir()
             ---      rh  16. in siRelCon(), facilitated the removal of the 
                              associated connection timers 

1.38         ---      rh   1. Timer handling functions for new PAUSE/RESUME 
                              behaviour
                           2. Changes to incorporate UI primtive changes
                           3. Added the function siAppendUbufToMsg() to handle
                              unrecognised parameters
                           4. Moved siSndMsg() from si_bdy1.c to si_bdy5.c
                              (bdy1.c should only contain primitive definitions)
1.39         ---      ao   1. Fixed problem with reference to uBuf for
                              tightly coupled mode.
             ---      rs   2. Removed status field for GRS when re-transmitting
                              after expiry of timer T22/T23.
             ---      ao   3. Added check for upper SAP cb in siGenRelUpLw.
             ---      rs   1. Added procedures/functions to handle message and
                              parameter compatibility. 
                              Note: PassOn of unrecognized msgs is not currently
                              supported.
                           2. Modified Reassembly func to do handle 
                              compatibility procedures.
                           3. Changed the initialization of type of Exchange to
                              Type B from Type Unknown.
                           4. Added check for upper SAP cb in siGenRelUpLw.
                           5. Added Tables/func to handle unexpected messages.

1.39         ---      rs   1. Added function for handling dpc timers (timers
                              t4 and tPAUSE are moved from cirCb to dpcCb)
                      rs   2. Added functions to add/delete dpcCb to/from hash
                              list. 
                      rs   3. Moved accounting info under SI_ACNT compile option
                      rs   4. Modified SiChkMsgComp to support passON of umsg.
                      rs   5. Change to make TFGR applicable for ANSI 92.
                      rs   6. Added T3 timer for overload procedures.

1.40         ---      ao   1. Added option to have SLS coupled to the 
                              circuit id.
             ---      rh   1. Fixed siGenAlarm() not to send status indications
                              to layer management when gen config is not done.
             ---      rh   1. Fixed siGenBill() to initialize charge number
                              only for ANSI variants
             ---      ym   1. Changes in siGenRelLw to enable sending RelCfm 
                              on getting RLC from the peer.
             ---      ym   1. Initialisation of the tccriCnt on allocation of
                              connection block.
             ---      rs   1. Added missing messages to siIncCompTbl and 
                              siOutCompTbl tables.
                      ym   1. Misc. modifications to DEBUG prints 
                              implementation
             ---      rh   2. Use of cmIsANumber() in place of siIsANumber()
1.41         ---      ao   1. Added Russian variant

1.42         ---      dvs  1. rev sync
1.42+        ---      ym   1. Priority of the PAM, RLC and confusion message is
                              corrected.
                           2.Internal router loop is reduced to cut time.
                           3.Sending of CnStInd is corrected in handling
                             of exit message.
                           4.Error class compile opt. now includes if statement
                             in siGetRtEntry function.
                           5.The buffer is deallocated in case of failures in
                              siBldMsg and siGenPdu.
                           6.The swtch field in SiCir is updated properly.
                              Initially it was updated from dpc.
                           7.In siValCir the check for even number of
                             CIC is corrected.
                           8.On getting unexpected CVR or EXM 
                             reset is generated.
              ---     ym   1. Recommendation field in the cause element is
                             marked NOTPRSNT.
                           2.Unrecog. parameter in REL are handled 
                             properly by giving a unique returnvalue
                             to the calling function.
                           3.The type of index in pause and UPU  hdler function is
                             corrected.
                           4.COT state matrix is updated for the idle state.
                           5.For remote user unavailable case RESET indication
                             for the circuits having connections on them is 
                             sent.
                           6.On getting remote user part unavailable the state
                             of DPC is made SI_INTF_UNAVAIL.
                           7.siValCir is called with proper parameters
                             to send CVT message on getting remote user
                             unavailable from MTP3.
              ---          1.For SIT_PARAMETER the resume indication to CC
                             is sent with status event pointer as NULLP.
              ---          1.The proper cirId is compared in handling of pause
                             from MTP3 for clear transient case.
                           2.Handling of resume for call in conv on which relreq
                             is received is corrected.
                           3.Handling of resume for a circuit in wait reset
                             ack is corrected. In this case let clearing is
                             done by expiry of T17.
                           4.Index type is corrected in siProcResumeCir.
                           5.siGenReatInd is modified to take care of tandem connection
                             blocks in ISUP.
                           6.The performance of ISUP in handling of pause
                             , upu and resume is improved by using 
                             cmHashListGetNext.
                           7.Subsequent UPU indications are ignored if
                             timer TVal is still running siProcDpcStatus. 
              ---       ym 1.The priority field for user part unavailable
                             indication is properly checked. This change
                             is under SNT_PARAMETER compile option.
              ---       ym 1.The return value in siGenPdu is corrected.
                           2.Unnecessary check on the return value is 
                             removed in siGenPslg.
                           3.Unnecessary deallocation of the buffer is 
                             removed from siChkDimMsg function.
                           4.Circuit and connection RT updations are done
                             prior to clearing the connection in siGenRelUp.
                           5.Specific information is provided in the 
                             diagnostics in siValCir.
                           6.Handling of remote usr unavailable for ETSI 
                             is protected under compile option.
                           7.Handling of remote user unavailable for ANSI
                             variant is corrected.
                           8.Double seizure indicator is properly filled 
                             for circuit validation test for bothway ckt
                           9.Unrecognised info buffer is deallocated
                             if there is no PC in msg.
                          10.Exit message is expected in wait for 
                             continuity state also.
                          11.Changes related to different max size of the
                             message.
               ---     ym  1.Handling of initial address after sending CCR
                             is corrected.
                           2.tmpPos was incremented twice in siChkDiscParmInd.
                              This is corrected.
                           3. Handling of PC procedure if an unrecog. param
                              is received with no entry in PC is corrected.
                           4. Usage of SNT_USR_UNEQUIPPED define is
                              protected under SNT_PARAEMTER flag.
                           5. The proper opc values is used under DBG5
                              flag.
                           6. conPrcs is updated on allocation of the
                              inc/out going connection.
                           7. pres flag is initialised to NOTPRSNT
                              siRelEvnt in siGenRelUpLw.
                           8. Opc is included in the SNDCONF macro.
                           9. CPG is a valid msg in awt acm state.
                          10. The length field in Addr structures in SiCon
                              is initialised properly.
                          11. The suInstId is made null after sending
                              reattempt indication to CC. Note that this
                              change is done under ICCREATTEMPT compile 
                              option.
1.43         ---      ym   1. Changes related to addition of NTT variant in
                              ISUP.
            si026.214      1. The AND operation is corrected in
                              siChkPassOnNtPossInd.
                           2. Restart begin and end are handled in the
                              interface function itself.
                           3. The handling of pause for connections 
                              with no association with upper sap is 
                              corrected.
            si028.214 tz   1. The cid field is initialised to invalid value.
                              Note that this change is under IW_COT_NEW
                              compile option.
            si003.216 tz   1. Fixed the SLS width problem in siGetLnkSel for
                              ANSI'92 and Bellcore (GR-317) variants.
            si005.216 rrb  1. Changed code in siReassblSegms to avoid
                              accessing stale memory when the upper interface
                              of ISUP is tightly coupled.
            si031.214 tz   1. Changed code to assign the proper value for
                              the double seizure control indicator in the
                              function siValCir when the circuit is configured
                              to be BOTHWAY control.
            si032.214 tz   1. Added code to send confusion message in
                              processing unrecognized message when needed.
                           2. Changed the names of parameter PASSON_PARM_NO_NOTIF
                              and PASSONMSG_NO_NOTIF to PASSON_SND_NOTIF and
                              PASSONMSG_SND_NOTIF to avoid the confusion about
                              the meaning of the variables.
            si032.214 rrb  1. Corrected compilation problem.
            si033.214 tz   1. Changed code to send StaInd to layer manager when
                              CLLI is correct.
                           2. Changed code to update the location value in
                              cause indicator only when the presence of location
                              is set NOTPRSNT.
            si034.214 rrb  1. Corrected the memory overflow problem in
                              function siNoPCinMsg.
            si035.214 tz   1. Changed code so that it will not send out a
                              confusion message when it is a type B exchange
                              and indicator bit A = 0 and passOnFlag is not
                              set to TRUE.
            si039.214 tz   1. Changed code to assign a proper value to mask
                              before function siRoutSearch is called.
                           2. Changed code to return  RFAILED when route
                              deletion is not possible.
                           3. Added code so that the case of only one routing
                              entry is considered when deleting the route
                              entry.

1.45         ---      dvs  1. miscellaneous changes
1.46         ---      bsp  1. Removed code related to unused variable clli in
                              SiGenCfg.
             ---      rrb  2. Incorporated changes in siValCir function to
                              accomodate CONTROLLING and CONTROLLED type
                              of circuits.
             ---      ym   1. Debug print is corrected in siAddIntf.
                           2. Debug print is corrected , keytype is used
                              instead of keyType
                           3. OUT define is changed to OUTTYPE for NT
                              compilation.

/main/47     ---      rrb  1. Changed code to properly initialize the
                              "Circuit group charateristic indicator"
                              tokens on receiving CVT message.
                      rrb  2. Changed to get the appropriate bytes from
                              "cirFlg" field of a circuit to get appropriate
                              values for "Circuit group charateristic
                              indicator" token verification on receiving
                              CVR message.
                      rrb  3. Added code in siGenPdu and siGenScPdu to
                              check if the lower SAP is bound or not.
             ---      hy   1. Added codes to generate an alarm to layer 
                              manager in siProcIntfStatus.
                           2. Changed code in siIncCompTbl to support
                              Call Progress Message under "waiting for
                              Answer" state.
                           3. Added code to initiate a cir validation
                              test with MTP_STATUS resume primitive in
                              siProcIntfStatus.
                           4. Added code to support LOP message for 
                              ITU97 variant in siGenCnStInd.
                           5. Added code to initialize the xchgType base
                              on the compile options in siGetCon.
                           6. Added code, in new function siChkMsgCompInd,
                              to check GF bits on receipt of message 
                              compability parameter for ITU97 and ETSI v3 
                              variant in siChkMsgComp.
                           7. Changed code to send CFN message when passOnFlag
                              is false in function siNoPCinMsg.
                           8. Added code to support checking FG and IJ bits
                              in parameter compability info param for 
                              ITU97 and ETSI v3 in siPCinMsg. Modifed codes 
                              to support 5 upgraded param.
                           9. Added code to support PRI and APM message in 
                              function siGenCnStInd for ETSI v3 variant.
                           10. Added entries for PRI and APM message in table
                               siIncCompTbl and siOutCompTbl.  
                           11. Added code to initialize the field 
                               "firstRevdStat" in siGetCirGr 
                           12. Changes to support multirate connections.
                           13. Added INSTRARRAY1 for ITU97 and ETSIv3 
                               variants
                           14. Idx variable from siGetCon function is 
                               removed as it is not used.
                           15. Added checking for the pointer of 
                               incoming/outgoing circuit block in siRelCon.
                           16. Modified the checking of CAM and N in 
                               siChkMRateCon and siProcMRateIAM.
                           17. Added checking for invalid transfer rate
                               in siChkMRateCon.
                           18. Changed the return value to RFAILED from 
                               ROK in certain failure cases in 
                               siProcMRateIAM.
                           19. Added code to send UCIC msg if the affected
                               circuit is unequipped in a non-single rate
                               call in siProcMRateIAM.
                           20. Added a function siValMRateCkt to validate
                               affected circuits in a non-single rate call.
                           21. Changes the code to determine the multirate
                               connection type call according to our
                               interpretation in siProcMRateIAM and
                               siChkMultiDualSeiz.
                           22. Changes to delete the outgoing conn once 
                               it detect the incoming should accept 
                               instead of deleting conn afterward in
                               siProcMRateIAM.
                           23. Modified the table siTrunkTbl to used 
                               circuit with slotId 0 in T1 trunk type.
                           24. Added code to check the previous circuit
                               slotId if the circuit is unequipped when
                               validating the affected ckts for contiguous i
                               non- single rate call in siValMRateCkt for
                               ITU97 and ETSIV3.
                           25. Added a function siSanChkConEvtCkts to 
                               perform the sanity check for each circuit
                               for a outgoing connection call.
                           26. Added functions siSelectCirCon,
                               siProcMRateinCirGrMsg, siDelMRateLnk, 
                               siGenMRateLnk, siGetMRateInfo, 
                               siJumpMRatefrmCirMsg, siSanChkConEvtCkts,
                               siChkFstBitinCAM, siChgMRateState,
                               siValMapinCAM, siStoreCntrlCir. 
                           27. Modified function siChkContin to a public
                               funcition.
                      bsp  28. Changed hash define names which were changed
                               in sit.h to resolve clash between sit.h and int.h
                      hy   29. changes for removal of swtch and ssf field in
                               circuit control block. Added a funtion
                               siChkCirIntf
                           30. Changes for supporting 10 parameters in 
                               Parameter Compability Information.
                      bsp  31. Removed SITVER2 flag.
                           32. Removed internal related code.
                           33. Enabled code to enable APM and PRI messages 
                               for ITU97
                      hy   34. Changes for supported segmentation in 
                               ANS92 and ANS95. Added a function
                               siSegmIAMtoINF.
                      bsp  35. Patch propogation related changes:
                               . Corrected handling of information and
                                 information request message
                               . Corrected the dual siezure problem that was
                                 occuring in the hash list
                               . Corrected the function calls to siUpdIntfSts
                                 to be made only with an actual interface id.
                               . Corrected the double insertion problem 
                                 that was occuring in the hash list  
                               . Added initialization of a newly added field in
                                 connection control block.
                               . Added code in siGetPriority to specify message
                                 priorities for messages for the Bellcore 
                                 variant
                               . Added siChargeInfo function to take care of
                                 charging based on parameters available from IAM
                      hy    36. Added function siProcCGBinReset and 
                                siSndCGBinReset to generate CGB when
                                ISUP receive GRS with CAM from nw.
                            37. Added function siProcBLOinReset and 
                                siSndBLOinReset to generate BLO when
                                ISUP receive GRS with CAM from nw.
                            38. Add new function siCmpCAM to compare the CAM 
                                parameter while processing GRS/GRA messages
                                for ANS95.
                            39. Bug fixed on siOutCompTbl array to accept the 
                                CRM msg on states WTFORCONTIN, WTFORACM, 
                                WTFORCOTIAM and WTFORCRA
                            40. Added function siChkDualinNonCtrl to handle
                                dual seizure between non-single rate outgoing
                                connection and single rate incoming on
                                non-controlling ckt.
                      bsp   41. Moved tmpCir outside compile time flags to 
                                correct compilation error in siGenMRateRsc
                            42. Moved CAM under ANSI 95 and ITU 97 flag in
                                siGetMRateInfo
                      hy    43. Initialized the cirConPtr in function
                                siSelectCirCon.
                            44. Added a check for the return value after
                                calling siGenMRateRsc in function 
                                siProcMRateinCirGrMsg.
                            45. Remove the #if 1 or #if 0 tags in the file.
                            46. Remove local variable maxNumPar in function 
                                siPCinMsg and siBldInstrIndArr. Instead use
                                a define MAX_UNREG_PC
                            47. Remove the code to check the variant type
                                in function siChargeInfo.
                            48. Added the initialization for ret value in 
                                siFindIntf, siChkParComp, siChkMultiDualSeiz 
                                siReassblSegms and siChkBrNbInd.
                            49. Change the code to print the cic value of
                                affected circuit in siChkMultiDualSeiz.
                            50. Added the initialization for maxSizMsg in
                                siSegmIAMtoINF.
                            51. Added a default case for the switch statement
                                of priority and initialized the func
                                siProcIntfStatus.
                            52. Changed the variable j in siSegmMsg and 
                                onOfItems in siSegmIAMtoINF from U8 to S16 type
                                and the corresponding changes.
                            53. Fixed a bug in the siSegMsgRemParm function
                                definition for non-ANSI.
                            54. Removed the casting for variable 'lenPar' in
                                siChkDimMsg.
                            55. Removed the include of lrm.h.
/main/48     ---        hy   1. Changed code so that when ISUP receives a 
                                ConReq on a circuit with a connection in 
                                waiting for RELCMP state and relResp being FALSE
                                (release generated by ISUP due to timer 
                                expiration), ISUP responds to the upper layer by
                                a reattempt indication instead of release 
                                indication in siSanChkConEvtCkts .
                             2. Added code to fix connection hash list 
                                corruption problems. Please note that the 
                                related changes are under compilation flag 
                                SI_CMHASH_CHK
                             3. Modify siIncCompTbl and siOutCompTbl so as
                                to accept CFN in idle call state
                             4. Modified code so that, for ANS92,BELL and ANS95, 
                                when IAM was received on a circuit that was 
                                local blocked with immediate release, BLO was 
                                sent back instead of CGB in function
                                siSanChkIAMCkts 
                             5. Stopping TMR_TCCRO when sending a status 
                                indication to upper layer to stop continuity in
                                function siChkContin
                        hy   1. Modified function siSndCGBinReset to send 
                                both hw and mnt CGB when handling GRS.
                        hy   1. Modified the code to pass the uBuf when 
                                indicating pass on parameter in siPCinMsg.
                        bsp  1. Modified event type from LSI_EVENT_REMOTE to 
                                LSI_EVENT_MTP in siProcIntfStatus
                        tz   1. Added code to set a bit in contCrm bit flag in
                                connection control block when ISUP generates
                                release up and low.
             si001.220  hy   1. Added code to fill the version number in the 
                                confirm post structure as one in
                                the received request in function siBldReplyPst.
             si003.220  mm   1. In function siSegmMsg added code so that item[j] 
                                will be within the range. This is for removing 
                                compiler warning.
                             2. In function siSelectCirCon, modified code to fix
                                a compiling error.
                             3. In function siSanChkConEvtCkts, added code to 
                                initialize Status Event.
                             4. In function siGetLwrSCbPtr and siGetLwrMCbPtr, 
                                modified code to always check SCCP and MTP3 SAP
                                Id.
                             5. In function siGetCon, modified code to avoid 
                                uninitialized variable references.
             si004.220  mm   1. In function siProcIntfStatus, modified code to
                                deal with the situation that variable cir is 
                                NULLP.
                             2. Modified code in function siGenRelUpLw so that 
                                when tCallCb in siCon is NULLP timer TMR_TRELRSP 
                                and TMR_TFNLRELRSP will not be started.
             si007.220  mm   1. In function siProcIntfStatus, modified code to 
                                avoid calling siProcUpuCir repeatedly under
                                SN_RMTUSRUNAV status if t4Runing flag is set 
                                into TRUE.
             si009.220  hy   1. In siProcIntfStatus, change code to handle the 
                                SN_RMTUSRUNAV case simliar as the SN_PAUSE case
                                for ITU97 and ETSIV3 variants.
                             2. In siGenPdu and siSndMsg, add code to check the
                                available state of interface to avoid sending
                                more traffic to the network if the intf
                                is marked as SI_INTF_UNAVAIL.
                             3. Added a new function siSndMsgNoChk to send 
                                message without checking the interface state.
                                This function is called by siGenPdu.
                             4. Set the interface valid flag to FALSE
                                when sending the UPT and CRV message, in order
                                not to check the state of interface cb in 
                                siGenPdu function.
                             5. Changed siProcResumeCir to a public function.
                         mm  6. Modified function siGetLnkSel so that link 
                                selector could be retrieved either by cic value
                                or load distribution or by configured field if 
                                LSIV3 is used.  Also modified code so that when 
                                calling siGetLnkSel
                                an extra parameter cic will be passed in.
                             7. Modifief function prototype of siProcUnINF as
                                PUBLIC 
                         hy  8. In function siSanChkConEvtCkts, corrected an
                                error when calling function cmMemset.
             si012.220  km   1. In siActDat, modified siCon->incC.conState to 
                                siCon->outC.conState such that the correct
                                outgoing connection state is referenced
             si013.220  km   1. In siGenPslg, removed code that deallocated
                                mBuf as it is going to be deallocated in the
                                calling function if RFAILED is returned
             si014.220  km   1. Deleted code from siGetInstId to stop the
                                number of running calls from getting 
                                incremented when this function is called
                             2. Added code to siAddInst and siDelInst to 
                                increment or decrement the total number of 
                                running calls only after proper access to the
                                hash list
                             3. Deleted code from siAddInst that incremented
                                the total number of running calls only for 
                                a standby copy
             si018.220  tz   1. Modified intfflg to TRUE in siValCir so that 
                                the interface statistics counters can be 
                                updated.
                             2. Modified code in siGenPdu to allow CVT message
                                being sent out even if interface state is 
                                unavailable.
             si019.220  tz   1. Modified siGenPdu so that the interface
                                availability check can be turned on or 
                                off at compile time.
             si022.220  tz   1. Modified code to update the circuit flag
                                noRspFlgToLw after siProcCirMsg to avoid
                                the same flag being set to FALSE.
             si023.220  tz   1. Reverse the change from si022.220.
             si025.220  tz   1. Modified function siGetLnkSel.
                             2. Modified arguments for function call of
                                siGetLnkSel.
             si028.220  tz   1. Added code in siChkMsgCompInd function to 
                                set the diagnostic value.
                             2. Added code in siChargeInfo function to move 
                                uBuf to tBuf to avoid uBuf double deallocation.
             si029.220  tz   1. Added INDIA variant. 
             si032.220  tz   1. Changed code so that mask value NULLP is 
                                considered.
             si034.220  rk   1. Added CHINA flag and switch where applicable.
             si035.220  rk   1. Checks introduced to prevent memory leaks.
             si039.220  rk   1. In siSndMsg, Debug flag changed from DBG4 to 
                                DBG5 as DBG4 should be used for error cases in 
                                mf and not in Tx & Rx
             si042.220  bn    1. Added ITU2000 and Russian 2000 ISUP variants.
             si043.220  rk   1. DEBUG Changes introduced
	     si044.220  ng   1. Added GetLnkSelIntf func to Fixed the UCIC problem 
                                in case of unequip circuit.
			     2. Addition - Drop message in case of failure to aviod memory leak 
            si045.220   ng   1. CEI_RES changed to MI_RESCIR
            si047.220   ng   1. Proper pointer type passed in SFndLenMsg
            si049.220   ng   1. Range value is intialized 
            si050.220   ng   1. Modification Timer T36 should be stop after the INF processing 
            si052.220   rk   1. T4 Timer issue for interface state change.
	    si054.220   vp   1. Added Code to update error counter
	    si055.220   vp   1. Changed NULL To NULLP
*********************************************************************91*/

