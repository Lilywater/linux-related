#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "cm_ss7.h"        /* ss7 layer */
#include "ssi.h"           /* system services */
#include "lsi.h"           /* layer management */
#include "cm_err.h"        /* common error */
#include "sit.h"           /* isup network layer */
#include "cm5.h"           /* common timers */
#ifdef SI_FTHA
#include "sht.h"           /* system agent */
#endif

  
/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* general SS7 layer */
#include "lsi.x"           /* layer management */
#include "sit.x"           /* ISUP */
#ifdef SI_FTHA
#include "sht.x"           /* system agent */
#endif

extern S16 siActvInit   ARGS((Ent entity, Inst inst, Region region, 
                              Reason reason));
extern  S16 siActvTskNew ARGS((Pst *pst, Buffer *mBuf));

#ifdef SI_TEST
extern S16 snActvTskNew ARGS((Pst *pst, Buffer *mBuf));
extern U8 suIdCcitt;
#endif


void si_init_fun(SSTskId tskId)
{
    Inst inst=0;
    

	if (ROK != SRegTTsk(ENTSI, inst, TTNORM, PRIOR0, siActvInit, siActvTskNew))
	{
		RETVALUE(RFAILED);
	}

	if(tskId == 0)
	{
	    if (SCreateSTsk(PRIOR0, &tskId) != ROK)
	    {
	         RETVALUE(RFAILED);
	    }
	}

	if (ROK != SAttachTTsk(ENTSI, inst, tskId))
	{
		RETVALUE(RFAILED);
	}

	
#ifdef SI_TEST	
    suIdCcitt = 0;
    SRegActvTsk(ENTSN, inst, TTNORM, 0, snActvTskNew);
#endif SI_TEST

#ifdef CP_OAM_SUPPORT
   if (ROK != smSiInitCfg())
   {
          /*chendh SM_SIDBGP(DBGMASK_SI, (siCb.init.prntBuf, 
            "siActvInit(smSiInitCfg is RFAILED)\n"));*/
   }
#endif
    RETVALUE(ROK);

}



