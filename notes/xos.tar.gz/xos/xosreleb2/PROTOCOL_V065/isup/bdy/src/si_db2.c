/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/
 

/********************************************************************20**
 
    Name:     ISUP message database 2
 
    Type:     C source file
 
    Desc:     Defines actions to take when parameters with 
              unrecognized values are recvd.
 
    File:     ci_db2.c
 
    Sid:      ci_db2.c@@/main/7 - Wed Jul 25 13:21:12 2001
 
    Prg:      rs
 
*********************************************************************21*/


/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.             description
*     --------     ----------------------------------------------
*     1000029      SS7 - ISUP
*
*/


/*
 *
 * All comments enclosed in brackets "()" are references to page numbers in: 
 *
 * CCITT Blue Book
 * ---------------
 * Specifications of Signalling System No. 7
 * Recommendations Q.721-Q.766
 * ISBN 92-61-03521-3
 *
 */ 

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "si_mf.h"            /* message functions */
#include "ci_db.h"         /* message functions - isup */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer            */
#include "ssi.x"           /* system services */
#include "si_mf.x"            /* message functions        */
#include "ci_db.x"         /* message functions - isup */
#include "ci_db2.x"        /* Action indicator */

/* local defines */

/* foreward references */

PUBLIC SiTknEnum teCommonActInd0  [SI_MAX_SWITCH] =
{
   SIMF_DISCPARM,                    /* action ind, switch test */
   SIMF_DISCPARM,                    /* action ind, switch ccitt */
   SIMF_NA,                          /* action ind, switch ansi */
   SIMF_NODFLT,                      /* action ind, switch ansi 92 */
   SIMF_DISCPARM,                    /* action ind, switch singapore tel */
   SIMF_DISCPARM,                    /* action ind, switch q.767 */
   SIMF_DISCPARM,                    /* action ind, switch ETSI */
   SIMF_DISCPARM,                    /* action ind, switch GT_FTZ */
   SIMF_DISCPARM,                    /* action ind, switch RUSSIA */
   SIMF_NODFLT,                      /* action ind, switch Bellcore */
   SIMF_NA,                          /* action ind, switch NTT */
   SIMF_NODFLT,                      /* action ind, switch ansi 95 */
   SIMF_DISCPARM,                    /* action ind, switch itu 97 */
   SIMF_DISCPARM,                    /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCPARM,                    /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCPARM,                    /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCPARM,                    /* action ind, switch ITU2000 */
   SIMF_DISCPARM,                    /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd1  [SI_MAX_SWITCH] =
{
   SIMF_DFLT,                        /* action ind, switch test */
   SIMF_DFLT,                        /* action ind, switch ccitt */
   SIMF_DFLT,                        /* action ind, switch ansi */
   SIMF_DFLT,                        /* action ind, switch ansi 92 */
   SIMF_DFLT,                        /* action ind, switch singapore tel */
   SIMF_DFLT,                        /* action ind, switch q.767 */
   SIMF_DFLT,                        /* action ind, switch ETSI */
   SIMF_DFLT,                        /* action ind, switch GT_FTZ */
   SIMF_DFLT,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                        /* action ind, switch Bellcore */
   SIMF_DFLT,                        /* action ind, switch NTT */  
   SIMF_DFLT,                        /* action ind, switch ansi 95 */
   SIMF_DFLT,                        /* action ind, switch itu 97 */
   SIMF_DFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                    /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                        /* action ind, switch ITU2000 */
   SIMF_DFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd2  [SI_MAX_SWITCH] =
{
   SIMF_DFLT,                        /* action ind, switch test */
   SIMF_DFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                      /* action ind, switch ansi */
   SIMF_NODFLT,                      /* action ind, switch ansi 92 */
   SIMF_DFLT,                        /* action ind, switch singapore tel */
   SIMF_DFLT,                        /* action ind, switch q.767 */
   SIMF_DFLT,                        /* action ind, switch ETSI */
   SIMF_DFLT,                        /* action ind, switch GT_FTZ */
   SIMF_DFLT,                        /* action ind, switch RUSSIA */
   SIMF_NODFLT,                      /* action ind, switch Bellcore */
   SIMF_NODFLT,                      /* action ind, switch NTT */ 
   SIMF_NODFLT,                      /* action ind, switch ansi 95 */
   SIMF_DFLT,                        /* action ind, switch itu 97 */
   SIMF_DFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                    /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                        /* action ind, switch ITU2000 */
   SIMF_DFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd3  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                    /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd4  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NA,                            /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NA,                            /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NA,                            /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd5  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NA,                            /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};


PUBLIC SiTknEnum teCommonActInd7  [SI_MAX_SWITCH] =
{
   SIMF_DFLT,                          /* action ind, switch test */
   SIMF_DFLT,                          /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_DFLT,                          /* action ind, switch singapore tel */
   SIMF_DFLT,                          /* action ind, switch q.767 */
   SIMF_DFLT,                          /* action ind, switch ETSI */
   SIMF_DFLT,                          /* action ind, switch GT_FTZ */
   SIMF_DFLT,                          /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */ 
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_DFLT,                          /* action ind, switch itu 97 */
   SIMF_DFLT,                          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                          /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                          /* action ind, switch ITU2000 */
   SIMF_DFLT,                          /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd8  [SI_MAX_SWITCH] =
{
   SIMF_REL_CAUSE28,                   /* action ind, switch test */
   SIMF_REL_CAUSE28,                   /* action ind, switch ccitt */
   SIMF_REL_CAUSE28,                   /* action ind, switch ansi */
   SIMF_REL_CAUSE28,                   /* action ind, switch ansi 92 */
   SIMF_REL_CAUSE28,                   /* action ind, switch singapore tel */
   SIMF_REL_CAUSE28,                   /* action ind, switch q.767 */
   SIMF_REL_CAUSE28,                   /* action ind, switch ETSI */
   SIMF_REL_CAUSE28,                   /* action ind, switch GT_FTZ */
   SIMF_REL_CAUSE28,                   /* action ind, switch RUSSIA */
   /* si011.220, Change: For Bell, changed action value for Nature of Address 
                         indicator in Called Party Number parameter */
   SIMF_REL_CAUSE111,                  /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                 /* action ind, switch NTT */
   SIMF_REL_CAUSE28,                   /* action ind, switch ansi 95 */
   SIMF_REL_CAUSE28,                   /* action ind, switch itu 97 */
   SIMF_REL_CAUSE28,                   /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_REL_CAUSE28,                   /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_REL_CAUSE28,                   /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_REL_CAUSE28,                   /* action ind, switch ITU2000 */
   SIMF_REL_CAUSE28,                   /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teNmbPlnActInd  [SI_MAX_SWITCH] =
{
   SIMF_REL_CAUSE28,                   /* action ind, switch test */
   SIMF_REL_CAUSE28,                   /* action ind, switch ccitt */
   SIMF_REL_CAUSE28,                   /* action ind, switch ansi */
   SIMF_REL_CAUSE28,                   /* action ind, switch ansi 92 */
   SIMF_REL_CAUSE28,                   /* action ind, switch singapore tel */
   SIMF_REL_CAUSE28,                   /* action ind, switch q.767 */
   SIMF_REL_CAUSE28,                   /* action ind, switch ETSI */
   SIMF_REL_CAUSE28,                   /* action ind, switch GT_FTZ */
   SIMF_REL_CAUSE28,                   /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                 /* action ind, switch NTT */
   SIMF_REL_CAUSE28,                   /* action ind, switch ansi 95 */
   SIMF_REL_CAUSE28,                   /* action ind, switch itu 97 */
   SIMF_REL_CAUSE28,                   /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_REL_CAUSE28,                   /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_REL_CAUSE28,                   /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_REL_CAUSE28,                   /* action ind, switch ITU2000 */
   SIMF_REL_CAUSE28,                   /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd10  [SI_MAX_SWITCH] =
{
   SIMF_NA,                            /* action ind, switch test */
   SIMF_NA,                            /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_NA,                            /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NA,                            /* action ind, switch ETSI */
   SIMF_NA,                            /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NA,                            /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NA,                            /* action ind, switch itu 97 */
   SIMF_NA,                            /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NA,                            /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NA,                   /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NA,                            /* action ind, switch ITU2000 */
   SIMF_NA,                            /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd12  [SI_MAX_SWITCH] =
{
   SIMF_DISCPARM,                      /* action ind, switch test */
   SIMF_DISCPARM,                      /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_DISCPARM,                      /* action ind, switch singapore tel */
   SIMF_DISCPARM,                      /* action ind, switch q.767 */
   SIMF_DISCPARM,                      /* action ind, switch ETSI */
   SIMF_DISCPARM,                      /* action ind, switch GT_FTZ */
   SIMF_DISCPARM,                      /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_DISCPARM,                      /* action ind, switch itu 97 */
   SIMF_DISCPARM,                      /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCPARM,                      /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCPARM,                      /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCPARM,                      /* action ind, switch ITU2000 */
   SIMF_DISCPARM,                      /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd13  [SI_MAX_SWITCH] =
{
   SIMF_DFLT,                          /* action ind, switch test */
   SIMF_DFLT,                          /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_DFLT,                          /* action ind, switch singapore tel */
   SIMF_DFLT,                          /* action ind, switch q.767 */
   SIMF_DFLT,                          /* action ind, switch ETSI */
   SIMF_DFLT,                          /* action ind, switch GT_FTZ */
   SIMF_DFLT,                          /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_DFLT,                          /* action ind, switch NTT   */ 
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_DFLT,                          /* action ind, switch itu 97 */
   SIMF_DFLT,                          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                          /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                          /* action ind, switch ITU2000 */
   SIMF_DFLT,                          /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd14  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};



PUBLIC SiTknEnum teCommonActInd17  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_REL_CCPROTERR,                 /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};


PUBLIC SiTknEnum teCommonActInd19  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_DFLT,                          /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd20  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_DFLT,                          /* action ind, switch ansi */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd21  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_NA,                            /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd22  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd23  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT    **/
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd24  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd25  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd26  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd27  [SI_MAX_SWITCH] =
{
   SIMF_DISCPARM,                      /* action ind, switch test */
   SIMF_DISCPARM,                      /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 92 */
   SIMF_DISCPARM,                      /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_DISCPARM,                      /* action ind, switch ETSI */
   SIMF_DISCPARM,                      /* action ind, switch GT_FTZ */
   SIMF_DISCPARM,                      /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 95 */
   SIMF_DISCPARM,                      /* action ind, switch itu 97 */
   SIMF_DISCPARM,                      /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCPARM,                      /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCPARM,                      /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd28  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NA,                            /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd29  [SI_MAX_SWITCH] =
{
   SIMF_DFLT,                        /* action ind, switch test */
   SIMF_DFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                      /* action ind, switch ansi */
   SIMF_DFLT,                        /* action ind, switch ansi 92 */
   SIMF_DFLT,                        /* action ind, switch singapore tel */
   SIMF_DFLT,                        /* action ind, switch q.767 */
   SIMF_DFLT,                        /* action ind, switch ETSI */
   SIMF_DFLT,                        /* action ind, switch GT_FTZ */
   SIMF_DFLT,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                        /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,               /* action ind, switch NTT   */ 
   SIMF_DFLT,                        /* action ind, switch ansi 95 */
   SIMF_DFLT,                        /* action ind, switch itu 97 */
   SIMF_DFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                        /* action ind, switch ITU2000 */
   SIMF_DFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd30  [SI_MAX_SWITCH] =
{
   SIMF_DISCPARM,                        /* action ind, switch test */
   SIMF_DISCPARM,                        /* action ind, switch ccitt */
   SIMF_NA,                              /* action ind, switch ansi */
   SIMF_REL_CCPROTERR,                   /* action ind, switch ansi 92 */
   SIMF_DISCPARM,                        /* action ind, switch singapore tel */
   SIMF_NA,                              /* action ind, switch q.767 */
   SIMF_DISCPARM,                        /* action ind, switch ETSI */
   SIMF_DISCPARM,                        /* action ind, switch GT_FTZ */
   SIMF_DISCPARM,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                   /* action ind, switch NTT */
   SIMF_REL_CCPROTERR,                   /* action ind, switch ansi 95 */
   SIMF_DISCPARM,                        /* action ind, switch itu 97 */
   SIMF_DISCPARM,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCPARM,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCPARM,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCPARM,                        /* action ind, switch ITU2000 */
   SIMF_DISCPARM,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd30B  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 92 */
   SIMF_DISCPARM,                      /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_DISCPARM,                      /* action ind, switch ETSI */
   SIMF_DISCPARM,                      /* action ind, switch GT_FTZ */
   SIMF_DISCPARM,                      /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                 /* action ind, switch NTT */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 95 */
   SIMF_DISCPARM,                      /* action ind, switch itu 97 */
   SIMF_DISCPARM,                      /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCPARM,                      /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCPARM,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCPARM,                        /* action ind, switch ITU2000 */
   SIMF_DISCPARM,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd31  [SI_MAX_SWITCH] =
{
   SIMF_DISCPARM,                        /* action ind, switch test */
   SIMF_DISCPARM,                        /* action ind, switch ccitt */
   SIMF_NA,                              /* action ind, switch ansi */
   SIMF_NA,                              /* action ind, switch ansi 92 */
   SIMF_DISCPARM,                        /* action ind, switch singapore tel */
   SIMF_DISCPARM,                        /* action ind, switch q.767 */
   SIMF_DISCPARM,                        /* action ind, switch ETSI */
   SIMF_DISCPARM,                        /* action ind, switch GT_FTZ */
   SIMF_DISCPARM,                        /* action ind, switch RUSSIA */
   SIMF_NA,                              /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                   /* action ind, switch NTT */
   SIMF_NA,                              /* action ind, switch ansi 95 */
   SIMF_DISCPARM,                        /* action ind, switch itu 97 */
   SIMF_DISCPARM,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCPARM,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCPARM,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCPARM,                        /* action ind, switch ITU2000 */
   SIMF_DISCPARM,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd32  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                 /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd33  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_REL_CCPROTERR,                 /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                 /* action ind, switch NTT */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd34  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_DFLT,                          /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd35  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                 /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd36 [SI_MAX_SWITCH] =
{
   SIMF_DFLT,                        /* action ind, switch test */
   SIMF_DFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                          /* action ind, switch ansi */
   SIMF_DFLT,                        /* action ind, switch ansi 92 */
   SIMF_DFLT,                        /* action ind, switch singapore tel */
   SIMF_DFLT,                        /* action ind, switch q.767 */
   SIMF_DFLT,                        /* action ind, switch ETSI */
   SIMF_DFLT,                        /* action ind, switch GT_FTZ */
   SIMF_DFLT,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                        /* action ind, switch Bellcore */
   SIMF_DFLT,                        /* action ind, switch NTT */ 
   SIMF_DFLT,                        /* action ind, switch ansi 95 */
   SIMF_DFLT,                        /* action ind, switch itu 97 */
   SIMF_DFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                      /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                        /* action ind, switch ITU2000 */
   SIMF_DFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd37  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                 /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd38  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_DFLT,                          /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_DFLT,                          /* action ind, switch NTT **/
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

/* si029.220: Addition - added action list due to Indian variant */
PUBLIC SiTknEnum teCommonActInd38i  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_DFLT,                          /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_DFLT,                          /* action ind, switch NTT **/
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
   SIMF_DFLT,                          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};
PUBLIC SiTknEnum teCommonActInd39  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                 /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCommonActInd40  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NA,                            /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
};

PUBLIC SiTknEnum teCommonActInd41  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NA,                            /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NA,                            /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NA,                            /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
};

PUBLIC SiTknEnum teCommonActInd42  [SI_MAX_SWITCH] =
{
   SIMF_DFLT,                      /* action ind, switch test */
   SIMF_DFLT,                      /* action ind, switch ccitt */
   SIMF_NA,                        /* action ind, switch ansi */
   SIMF_NA,                        /* action ind, switch ansi 92 */
   SIMF_DFLT,                      /* action ind, switch singapore tel */
   SIMF_NA,                        /* action ind, switch q.767 */
   SIMF_DFLT,                      /* action ind, switch ETSI */
   SIMF_DFLT,                      /* action ind, switch GT_FTZ */
   SIMF_NA,                        /* action ind, switch RUSSIA */
   SIMF_NA,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                    /* action ind, switch NTT */
   SIMF_NA,                        /* action ind, switch ansi 95 */
   SIMF_DFLT,                      /* action ind, switch itu 97 */
   SIMF_DFLT,                      /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                      /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};


PUBLIC SiTknEnum teHoldIndActIndA[SI_MAX_SWITCH] =
{
   SIMF_DFLT,                          /* action ind, switch test */
   SIMF_DFLT,                          /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_DFLT,                          /* action ind, switch singapore tel */
   SIMF_IGNORE,                        /* action ind, switch q.767 */
   SIMF_DFLT,                          /* action ind, switch ETSI */
   SIMF_DFLT,                          /* action ind, switch GT_FTZ */
   SIMF_IGNORE,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */ 
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_DFLT,                          /* action ind, switch itu 97 */
   SIMF_DFLT,                          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                          /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                          /* action ind, switch ITU2000 */
   SIMF_DFLT,                          /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teServIndA  [SI_MAX_SWITCH] =
{
   SIMF_DFLT,                        /* action ind, switch test */
   SIMF_DFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                          /* action ind, switch ansi */
   SIMF_NA,                          /* action ind, switch ansi 92 */
   SIMF_DFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                          /* action ind, switch q.767 */
   SIMF_DFLT,                        /* action ind, switch ETSI */
   SIMF_DFLT,                        /* action ind, switch GT_FTZ */
   SIMF_DFLT,                        /* action ind, switch RUSSIA */
   SIMF_NA,                          /* action ind, switch Bellcore */
   SIMF_NA,                          /* action ind, switch NTT    **/
   SIMF_NA,                          /* action ind, switch ansi 95 */
   SIMF_DFLT,                        /* action ind, switch itu 97 */
   SIMF_DFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                          /* action ind, switch ITU2000 */
   SIMF_DFLT,                          /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teServIndB  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NA,                            /* action ind, switch NTT    **/
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_DFLT,                          /* action ind, switch itu 97 */
   SIMF_DFLT,                          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                          /* action ind, switch ITU2000 */
   SIMF_DFLT,                          /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teConnNumNatAddrActIndA[SI_MAX_SWITCH] =
{
   SIMF_DISCPARM,                      /* action ind, switch test */
   SIMF_DISCPARM,                      /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_DISCPARM,                      /* action ind, switch singapore tel */
   SIMF_DISCPARM,                      /* action ind, switch q.767 */
   SIMF_DISCPARM,                      /* action ind, switch ETSI */
   SIMF_DISCPARM,                      /* action ind, switch GT_FTZ */
   SIMF_DISCPARM,                      /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_DISCPARM,                      /* action ind, switch itu 97 */
   SIMF_DISCPARM,                      /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCPARM,                      /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCPARM,                      /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCPARM,                      /* action ind, switch ITU2000 */
   SIMF_DISCPARM,                      /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCagPrtyNatAddrActIndA[SI_MAX_SWITCH] =
{
   SIMF_DISCPARM,                      /* action ind, switch test */
   SIMF_DISCPARM,                      /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 92 */
   SIMF_DISCPARM,                      /* action ind, switch singapore tel */
   SIMF_DISCPARM,                      /* action ind, switch q.767 */
   SIMF_DISCPARM,                      /* action ind, switch ETSI */
   SIMF_DISCPARM,                      /* action ind, switch GT_FTZ */
   SIMF_DISCPARM,                      /* action ind, switch RUSSIA */
   SIMF_IGNORE,                        /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                 /* action ind, switch NTT */ 
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 95 */
   SIMF_DISCPARM,                      /* action ind, switch itu 97 */
   SIMF_DISCPARM,                      /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCPARM,                      /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCPARM,                      /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCPARM,                      /* action ind, switch ITU2000 */
   SIMF_DISCPARM,                      /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teRedirNumNatAddrActIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_IGNORE,                        /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                 /* action ind, switch NTT */ 
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 95 */
   SIMF_DISCPARM,                      /* action ind, switch itu 97 */
   SIMF_DISCPARM,                      /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCPARM,                      /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCPARM,                      /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCPARM,                      /* action ind, switch ITU2000 */
   SIMF_DISCPARM,                      /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCagPrtyNumPlanActIndA[SI_MAX_SWITCH] =
{
   SIMF_DISCPARM,                      /* action ind, switch test */
   SIMF_DISCPARM,                      /* action ind, switch ccitt */
   SIMF_DFLT,                          /* action ind, switch ansi */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 92 */
   SIMF_DISCPARM,                      /* action ind, switch singapore tel */
   SIMF_DISCPARM,                      /* action ind, switch q.767 */
   SIMF_DISCPARM,                      /* action ind, switch ETSI */
   SIMF_DISCPARM,                      /* action ind, switch GT_FTZ */
   SIMF_DISCPARM,                      /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */ 
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 95 */
   SIMF_DISCPARM,                      /* action ind, switch itu 97 */
   SIMF_DISCPARM,                      /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCPARM,                      /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCPARM,                      /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCPARM,                      /* action ind, switch ITU2000 */
   SIMF_DISCPARM,                      /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teRedirNumNumPlanActIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                      /* action ind, switch test */
   SIMF_NODFLT,                      /* action ind, switch ccitt */
   SIMF_DFLT,                        /* action ind, switch ansi */
   SIMF_REL_CCPROTERR,               /* action ind, switch ansi 92 */
   SIMF_NODFLT,                      /* action ind, switch singapore tel */
   SIMF_NODFLT,                      /* action ind, switch q.767 */
   SIMF_NODFLT,                      /* action ind, switch ETSI */
   SIMF_NODFLT,                      /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                      /* action ind, switch RUSSIA */
   SIMF_DFLT,                        /* action ind, switch Bellcore */ 
   SIMF_NODFLT,                      /* action ind, switch NTT */
   SIMF_DFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                      /* action ind, switch itu 97 */
   SIMF_NODFLT,                      /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                      /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                      /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                      /* action ind, switch ITU2000 */
   SIMF_NODFLT,                      /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teConnNumPlanActIndA[SI_MAX_SWITCH] =
{
   SIMF_DISCPARM,                      /* action ind, switch test */
   SIMF_DISCPARM,                      /* action ind, switch ccitt */
   SIMF_DFLT,                          /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_DISCPARM,                      /* action ind, switch singapore tel */
   SIMF_DISCPARM,                      /* action ind, switch q.767 */
   SIMF_DISCPARM,                      /* action ind, switch ETSI */
   SIMF_DISCPARM,                      /* action ind, switch GT_FTZ */
   SIMF_DISCPARM,                      /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_DISCPARM,                      /* action ind, switch itu 97 */
   SIMF_DISCPARM,                      /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCPARM,                      /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCPARM,                      /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCPARM,                      /* action ind, switch ITU2000 */
   SIMF_DISCPARM,                      /* action ind, switch RUSS2000 */
};


PUBLIC SiTknEnum teRedirNumPlanActIndA[SI_MAX_SWITCH] =
{
   SIMF_DISCPARM,                      /* action ind, switch test */
   SIMF_DISCPARM,                      /* action ind, switch ccitt */
   SIMF_DFLT,                          /* action ind, switch ansi */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 92 */
   SIMF_DISCPARM,                      /* action ind, switch singapore tel */
   SIMF_DISCPARM,                      /* action ind, switch q.767 */
   SIMF_DISCPARM,                      /* action ind, switch ETSI */
   SIMF_DISCPARM,                      /* action ind, switch GT_FTZ */
   SIMF_DISCPARM,                      /* action ind, switch RUSSIA */
   SIMF_REL_CCPROTERR,                 /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 95 */
   SIMF_DISCPARM,                      /* action ind, switch itu 97 */
   SIMF_DISCPARM,                      /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCPARM,                      /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCPARM,                            /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCPARM,                      /* action ind, switch ITU2000 */
   SIMF_DISCPARM,                      /* action ind, switch RUSS2000 */
};
PUBLIC SiTknEnum teCagPrtyScreenIndActIndA[SI_MAX_SWITCH] =
{
   SIMF_DISCPARM,                      /* action ind, switch test */
   SIMF_DISCPARM,                      /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_DISCPARM,                      /* action ind, switch singapore tel */
   SIMF_DISCPARM,                      /* action ind, switch q.767 */
   SIMF_DISCPARM,                      /* action ind, switch ETSI */
   SIMF_DISCPARM,                      /* action ind, switch GT_FTZ */
   SIMF_DISCPARM,                      /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                 /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_DISCPARM,                      /* action ind, switch itu 97 */
   SIMF_DISCPARM,                      /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCPARM,                      /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCPARM,                      /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCPARM,                      /* action ind, switch ITU2000 */
   SIMF_DISCPARM,                      /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teConnNumPresRestActIndA[SI_MAX_SWITCH] =
{
   SIMF_DFLT,                          /* action ind, switch test */
   SIMF_DFLT,                          /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_DFLT,                          /* action ind, switch singapore tel */
   SIMF_DFLT,                          /* action ind, switch q.767 */
   SIMF_DFLT,                          /* action ind, switch ETSI */
   SIMF_DFLT,                          /* action ind, switch GT_FTZ */
   SIMF_DFLT,                          /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_DFLT,                          /* action ind, switch itu 97 */
   SIMF_DFLT,                          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                          /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                          /* action ind, switch ITU2000 */
   SIMF_DFLT,                          /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teTypeIndActIndA[SI_MAX_SWITCH] =
{
   SIMF_DISCMSG,                       /* action ind, switch test */
   SIMF_DISCMSG,                       /* action ind, switch ccitt */
   SIMF_DISCMSG,                       /* action ind, switch ansi */
   SIMF_DISCMSG,                       /* action ind, switch ansi 92 */
   SIMF_DISCMSG,                       /* action ind, switch singapore tel */
   SIMF_DISCMSG,                       /* action ind, switch q.767 */
   SIMF_DISCMSG,                       /* action ind, switch ETSI */
   SIMF_DISCMSG,                       /* action ind, switch GT_FTZ */
   SIMF_DISCMSG,                       /* action ind, switch RUSSIA */
   SIMF_DISCMSG,                       /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_DISCMSG,                       /* action ind, switch ansi 95 */
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch itu 97 */
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch ITU2000 */
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teFacIndActIndA[SI_MAX_SWITCH] =
{
   SIMF_DISCMSG,                       /* action ind, switch test */
   SIMF_DISCMSG,                       /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_DISCMSG,                       /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_DISCMSG,                       /* action ind, switch ETSI */
   SIMF_DISCMSG,                       /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_DISCMSG,                       /* action ind, switch itu 97 */
   SIMF_DISCMSG,                       /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCMSG,                       /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCMSG,                       /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCMSG,                       /* action ind, switch ITU2000 */
   SIMF_DISCMSG,                       /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teTypeEvtIndA[SI_MAX_SWITCH] =
{
   SIMF_DISCMSG,                       /* action ind, switch test */
   SIMF_DISCMSG,                       /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_REL_CAUSE111,                  /* action ind, switch ansi 92 */
   SIMF_DISCMSG,                       /* action ind, switch singapore tel */
   SIMF_DISCMSG,                       /* action ind, switch q.767 */
   SIMF_DISCMSG,                       /* action ind, switch ETSI */
   SIMF_DISCMSG,                       /* action ind, switch GT_FTZ */
   SIMF_DISCMSG,                       /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_DISCMSG,                       /* action ind, switch NTT */
   SIMF_REL_CAUSE111,                  /* action ind, switch ansi 95 */
   SIMF_DISCMSG,                       /* action ind, switch itu97 */
   SIMF_DISCMSG,                       /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCMSG,                       /* action ind, switch India*/
/* si034.220: Addition - added item for China variant */
   SIMF_DISCMSG,                       /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCMSG,                       /* action ind, switch ITU2000 */
   SIMF_DISCMSG,                       /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teTypeEvtIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                       /* action ind, switch test */
   SIMF_NODFLT,                       /* action ind, switch ccitt */
   SIMF_NODFLT,                      /* action ind, switch ansi */
   SIMF_REL_CAUSE111,                /* action ind, switch ansi 92 */
   SIMF_NODFLT,                      /* action ind, switch singapore tel */
   SIMF_NODFLT,                      /* action ind, switch q.767 */
   SIMF_NODFLT,                      /* action ind, switch ETSI */
   SIMF_NODFLT,                      /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                      /* action ind, switch RUSSIA */
   SIMF_NODFLT,                      /* action ind, switch Bellcore */
   SIMF_NODFLT,                      /* action ind, switch NTT */
   SIMF_REL_CAUSE111,                /* action ind, switch ansi 95 */
   SIMF_NODFLT,                      /* action ind, switch itu97 */
   SIMF_NODFLT,                      /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                      /* action ind, switch India*/
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                      /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                      /* action ind, switch ITU2000 */
   SIMF_NODFLT,                      /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teISDNUsrPrtPrfIndActIndA[SI_MAX_SWITCH] =
{
   SIMF_REL_CAUSE111,                  /* action ind, switch test */
   SIMF_REL_CAUSE111,                  /* action ind, switch ccitt */
   SIMF_DFLT,                          /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_REL_CAUSE111,                  /* action ind, switch singapore tel */
   SIMF_REL_CAUSE111,                  /* action ind, switch q.767 */
   SIMF_REL_CAUSE111,                  /* action ind, switch ETSI */
   SIMF_REL_CAUSE111,                  /* action ind, switch GT_FTZ */
   SIMF_REL_CAUSE111,                  /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                 /* action ind, switch NTT */
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_REL_CAUSE111,                  /* action ind, switch itu 97 */
   SIMF_REL_CAUSE111,                  /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_REL_CAUSE111,                  /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_REL_CAUSE111,                  /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_REL_CAUSE111,                  /* action ind, switch ITU2000 */
   SIMF_REL_CAUSE111,                  /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teSCCPMethInd1ActIndA[SI_MAX_SWITCH] =
{
   SIMF_DFLT,                          /* action ind, switch test */
   SIMF_DFLT,                          /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_DFLT,                          /* action ind, switch singapore tel */
   SIMF_DFLT,                          /* action ind, switch q.767 */
   SIMF_DFLT,                          /* action ind, switch ETSI */
   SIMF_DFLT,                          /* action ind, switch GT_FTZ */
   SIMF_DFLT,                          /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_DFLT,                          /* action ind, switch itu 97 */
   SIMF_DFLT,                          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                          /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                          /* action ind, switch ITU2000 */
   SIMF_DFLT,                          /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCgPrtyAddRespIndActIndA[SI_MAX_SWITCH] =
{
   SIMF_DFLT,                          /* action ind, switch test */
   SIMF_DFLT,                          /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_DFLT,                          /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_DFLT,                          /* action ind, switch ETSI */
   SIMF_DFLT,                          /* action ind, switch GT_FTZ */
   SIMF_DFLT,                          /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_DFLT,                          /* action ind, switch itu 97 */
   SIMF_DFLT,                          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                       /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                          /* action ind, switch ITU2000 */
   SIMF_DFLT,                          /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teHoldProvIndActIndA[SI_MAX_SWITCH] =
{
   SIMF_DFLT,                          /* action ind, switch test */
   SIMF_DFLT,                          /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_DFLT,                          /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_DFLT,                          /* action ind, switch ETSI */
   SIMF_DFLT,                          /* action ind, switch GT_FTZ */
   SIMF_DFLT,                          /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_DFLT,                          /* action ind, switch itu 97 */
   SIMF_DFLT,                          /* action ind, switch etsi v3 */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                          /* action ind, switch ITU2000 */
   SIMF_DFLT,                          /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCgPrtyCatRespIndActIndA[SI_MAX_SWITCH] =
{
   SIMF_DFLT,                          /* action ind, switch test */
   SIMF_DFLT,                          /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_DFLT,                          /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_DFLT,                          /* action ind, switch ETSI */
   SIMF_DFLT,                          /* action ind, switch GT_FTZ */
   SIMF_DFLT,                          /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teChrgInfoRespIndActIndA[SI_MAX_SWITCH] =
{
   SIMF_DFLT,                          /* action ind, switch test */
   SIMF_DFLT,                          /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_DFLT,                          /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_DFLT,                          /* action ind, switch ETSI */
   SIMF_DFLT,                          /* action ind, switch GT_FTZ */
   SIMF_DFLT,                          /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_DFLT,                          /* action ind, switch itu 97 */
   SIMF_DFLT,                          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                       /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                          /* action ind, switch ITU2000 */
   SIMF_DFLT,                          /* action ind, switch RUSS2000 */
};


PUBLIC SiTknEnum teSatIndActInd[SI_MAX_SWITCH] =
{
   SIMF_DFLT,                          /* action ind, switch test */
   SIMF_DFLT,                          /* action ind, switch ccitt */
   SIMF_DFLT,                          /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_DFLT,                          /* action ind, switch singapore tel */
   SIMF_DFLT,                          /* action ind, switch q.767 */
   SIMF_DFLT,                          /* action ind, switch ETSI */
   SIMF_DFLT,                          /* action ind, switch GT_FTZ */
   SIMF_DFLT,                          /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_DFLT,                          /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_DFLT,                          /* action ind, switch itu 97 */
   SIMF_DFLT,                          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                          /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                          /* action ind, switch ITU2000 */
   SIMF_DFLT,                          /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCaFwdMayOccIndActIndA[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT   */ 
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};


PUBLIC SiTknEnum teNetExcDelIndActIndA[SI_MAX_SWITCH] =
{
   SIMF_IGNORE,                        /* action ind, switch test */
   SIMF_IGNORE,                        /* action ind, switch ccitt */
   SIMF_IGNORE,                        /* action ind, switch ansi */
   SIMF_IGNORE,                        /* action ind, switch ansi 92 */
   SIMF_IGNORE,                        /* action ind, switch singapore tel */
   SIMF_IGNORE,                        /* action ind, switch q.767 */
   SIMF_IGNORE,                        /* action ind, switch ETSI */
   SIMF_IGNORE,                        /* action ind, switch GT_FTZ */
   SIMF_IGNORE,                        /* action ind, switch RUSSIA */
   SIMF_IGNORE,                        /* action ind, switch Bellcore */
   SIMF_IGNORE,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_IGNORE,                        /* action ind, switch itu 97 */
   SIMF_IGNORE,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_IGNORE,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_IGNORE,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_IGNORE,                        /* action ind, switch ITU2000 */
   SIMF_IGNORE,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teUsrNetIneractIndActIndA[SI_MAX_SWITCH] =
{
   SIMF_IGNORE,                        /* action ind, switch test */
   SIMF_IGNORE,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_IGNORE,                        /* action ind, switch singapore tel */
   SIMF_IGNORE,                        /* action ind, switch q.767 */
   SIMF_IGNORE,                        /* action ind, switch ETSI */
   SIMF_IGNORE,                        /* action ind, switch GT_FTZ */
   SIMF_IGNORE,                        /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_IGNORE,                        /* action ind, switch itu 97 */
   SIMF_IGNORE,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_IGNORE,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_IGNORE,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_IGNORE,                        /* action ind, switch ITU2000 */
   SIMF_IGNORE,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teSimpleSegmIndActIndA[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_IGNORE,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_IGNORE,                        /* action ind, switch ITU2000 */
   SIMF_IGNORE,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teMLPPUserIndActIndA[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};
PUBLIC SiTknEnum teClsdUGrpCaInd1ActIndA[SI_MAX_SWITCH] =
{
   SIMF_DFLT,                          /* action ind, switch test */
   SIMF_DFLT,                          /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_DFLT,                          /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_DFLT,                          /* action ind, switch ETSI */
   SIMF_DFLT,                          /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_DFLT,                          /* action ind, switch itu 97 */
   SIMF_DFLT,                          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                          /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                          /* action ind, switch ITU2000 */
   SIMF_DFLT,                          /* action ind, switch RUSS2000 */
};
/* No procedures for ANSI 92 */
PUBLIC SiTknEnum teRedirIndActIndA[SI_MAX_SWITCH] =
{
   SIMF_DFLT,                          /* action ind, switch test */
   SIMF_DFLT,                          /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_DFLT,                          /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_DFLT,                          /* action ind, switch ETSI */
   SIMF_DFLT,                          /* action ind, switch GT_FTZ */
   SIMF_DFLT,                          /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_DFLT,                          /* action ind, switch itu 97 */
   SIMF_DFLT,                          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                          /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                          /* action ind, switch ITU2000 */
   SIMF_DFLT,                          /* action ind, switch RUSS2000 */
};
PUBLIC SiTknEnum teOrigRedirReasActIndA[SI_MAX_SWITCH] =
{
   SIMF_DFLT,                          /* action ind, switch test */
   SIMF_DFLT,                          /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_DFLT,                          /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_DFLT,                          /* action ind, switch ETSI */
   SIMF_DFLT,                          /* action ind, switch GT_FTZ */
   SIMF_DFLT,                          /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_DFLT,                          /* action ind, switch itu 97 */
   SIMF_DFLT,                          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                          /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                          /* action ind, switch ITU2000 */
   SIMF_DFLT,                          /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teRedirInfoReasActIndA[SI_MAX_SWITCH] =
{
   SIMF_DFLT,                          /* action ind, switch test */
   SIMF_DFLT,                          /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_DFLT,                          /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_DFLT,                          /* action ind, switch ETSI */
   SIMF_DFLT,                          /* action ind, switch GT_FTZ */
   SIMF_DFLT,                          /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_DFLT,                          /* action ind, switch itu 97 */
   SIMF_DFLT,                          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                          /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                          /* action ind, switch ITU2000 */
   SIMF_DFLT,                          /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teRedirReasActIndA[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                          /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_DFLT,                          /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_DFLT,                          /* action ind, switch GT_FTZ */
   SIMF_DFLT,                          /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_NODFLT,                          /* action ind, switch itu 97 */
   SIMF_NODFLT,                          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                          /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                          /* action ind, switch ITU2000 */
   SIMF_NODFLT,                          /* action ind, switch RUSS2000 */
};
PUBLIC SiTknEnum teNetIdPlnActInd[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_DFLT,                          /* action ind, switch ansi */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_REL_CCPROTERR,                 /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                          /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                          /* action ind, switch ITU2000 */
   SIMF_NODFLT,                          /* action ind, switch RUSS2000 */
};





PUBLIC SiTknEnum teTrMedReqActInd[SI_MAX_SWITCH] =
{
   SIMF_REL_CAUSE65,                   /* action ind, switch test */
   SIMF_REL_CAUSE65,                   /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_REL_CAUSE65,                   /* action ind, switch singapore tel */
   SIMF_REL_CAUSE65,                   /* action ind, switch q.767 */
   SIMF_REL_CAUSE65,                   /* action ind, switch ETSI */
   SIMF_REL_CAUSE65,                   /* action ind, switch GT_FTZ */
   SIMF_REL_CAUSE65,                   /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_REL_CAUSE65,                   /* action ind, switch itu 97 */
   SIMF_REL_CAUSE65,                   /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_REL_CAUSE65,                   /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_REL_CAUSE65,                   /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_REL_CAUSE65,                   /* action ind, switch ITU2000 */
   SIMF_REL_CAUSE65                    /* action ind, switch RUSS2000 */
};



PUBLIC SiTknEnum teLoopPrvntIndRspActInd[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NA,                            /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NA,                            /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NA,                            /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};


PUBLIC SiTknEnum teHoldIndActIndB[SI_MAX_SWITCH] =
{
   SIMF_IGNORE,                        /* action ind, switch test */
   SIMF_IGNORE,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_IGNORE,                        /* action ind, switch singapore tel */
   SIMF_IGNORE,                        /* action ind, switch q.767 */
   SIMF_IGNORE,                        /* action ind, switch ETSI */
   SIMF_IGNORE,                        /* action ind, switch GT_FTZ */
   SIMF_IGNORE,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */ 
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_IGNORE,                        /* action ind, switch itu 97 */
   SIMF_IGNORE,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_IGNORE,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_IGNORE,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_IGNORE,                        /* action ind, switch ITU2000 */
   SIMF_IGNORE,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teSCCPMethInd0ActIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teModIndActInd[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_NA,                            /* action ind, switch itu 97 */
   SIMF_NA,                            /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NA,                            /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NA,                            /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NA,                            /* action ind, switch ITU2000 */
   SIMF_NA,                            /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teConnNumNatAddrActIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                            /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCagPrtyNatAddrActIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_IGNORE,                        /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                 /* action ind, switch NTT */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                            /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teLocNumNatAddrActInd[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_IGNORE,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                            /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCagPrtyNumPlanActIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_DFLT,                          /* action ind, switch ansi */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                            /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teConnNumPlanActIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_DFLT,                          /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                            /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teOrigCadNumPlanActIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_REL_CCPROTERR,                 /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                            /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};


PUBLIC SiTknEnum teCagPrtyScreenIndActIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};
PUBLIC SiTknEnum teCagPrtyPresRestActIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_DFLT,                          /* action ind, switch NTT */ 
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teOrigCadNumPresRestActIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_DFLT,                          /* action ind, switch NTT */
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teConnNumPresRestActIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_DFLT,                          /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teCdeStandCIActIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                 /* action ind, switch NTT */
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teTypeIndActIndB[SI_MAX_SWITCH] =
{
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch test */
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch ccitt */
   SIMF_DISCMSG,                       /* action ind, switch ansi */
   SIMF_DISCMSG,                       /* action ind, switch ansi 92 */
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch singapore tel */
   SIMF_DISCMSG,                       /* action ind, switch q.767 */
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch ETSI */
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch GT_FTZ */
   SIMF_DISCMSG,                       /* action ind, switch RUSSIA */
   SIMF_DISCMSG,                       /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_DISCMSG,                       /* action ind, switch ansi 95 */
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch itu 97 */
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch ITU2000 */
   SIMF_DISCMSG_CFN_CAUSE110,          /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teFacIndActIndB[SI_MAX_SWITCH] =
{
   SIMF_DISCMSG,                       /* action ind, switch test */
   SIMF_DISCMSG,                       /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_DISCMSG,                       /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_DISCMSG,                       /* action ind, switch ETSI */
   SIMF_DISCMSG,                       /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_DISCMSG,                       /* action ind, switch itu 97 */
   SIMF_DISCMSG,                       /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DISCMSG,                       /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DISCMSG,                       /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DISCMSG,                       /* action ind, switch ITU2000 */
   SIMF_DISCMSG,                       /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teISDNUsrPrtPrfIndActIndB[SI_MAX_SWITCH] =
{
   SIMF_REL_CAUSE111,                  /* action ind, switch test */
   SIMF_REL_CAUSE111,                  /* action ind, switch ccitt */
   SIMF_DFLT,                          /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_REL_CAUSE111,                  /* action ind, switch singapore tel */
   SIMF_REL_CAUSE111,                  /* action ind, switch q.767 */
   SIMF_REL_CAUSE111,                  /* action ind, switch ETSI */
   SIMF_REL_CAUSE111,                  /* action ind, switch GT_FTZ */
   SIMF_REL_CAUSE111,                  /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_REL_CCPROTERR,                 /* action ind, switch NTT */
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_REL_CAUSE111,                  /* action ind, switch itu 97 */
   SIMF_REL_CAUSE111,                  /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_REL_CAUSE111,                  /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_REL_CAUSE111,                  /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_REL_CAUSE111,                  /* action ind, switch ITU2000 */
   SIMF_REL_CAUSE111,                  /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teSCCPMethInd1ActIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_DFLT,                          /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */};

PUBLIC SiTknEnum teChrgInfoRespIndActIndB[SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_NODFLT,                        /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teNetExcDelIndActIndB[SI_MAX_SWITCH] =
{
   SIMF_IGNORE,                        /* action ind, switch test */
   SIMF_IGNORE,                        /* action ind, switch ccitt */
   SIMF_IGNORE,                        /* action ind, switch ansi */
   SIMF_IGNORE,                        /* action ind, switch ansi 92 */
   SIMF_IGNORE,                        /* action ind, switch singapore tel */
   SIMF_IGNORE,                        /* action ind, switch q.767 */
   SIMF_IGNORE,                        /* action ind, switch ETSI */
   SIMF_IGNORE,                        /* action ind, switch GT_FTZ */
   SIMF_IGNORE,                        /* action ind, switch RUSSIA */
   SIMF_IGNORE,                        /* action ind, switch Bellcore */
   SIMF_IGNORE,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_IGNORE,                        /* action ind, switch itu 97 */
   SIMF_IGNORE,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_IGNORE,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_IGNORE,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teUsrNetIneractIndActIndB[SI_MAX_SWITCH] =
{
   SIMF_IGNORE,                        /* action ind, switch test */
   SIMF_IGNORE,                        /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NODFLT,                        /* action ind, switch ansi 92 */
   SIMF_IGNORE,                        /* action ind, switch singapore tel */
   SIMF_IGNORE,                        /* action ind, switch q.767 */
   SIMF_IGNORE,                        /* action ind, switch ETSI */
   SIMF_IGNORE,                        /* action ind, switch GT_FTZ */
   SIMF_IGNORE,                        /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_IGNORE,                        /* action ind, switch itu 97 */
   SIMF_IGNORE,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_IGNORE,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_IGNORE,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_IGNORE,                        /* action ind, switch ITU2000 */
   SIMF_IGNORE,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teINNIndActInd[SI_MAX_SWITCH] =
{
   SIMF_NA,                            /* action ind, switch test */
   SIMF_NA,                            /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NA,                            /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NA,                            /* action ind, switch ETSI */
   SIMF_NA,                            /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_NA,                            /* action ind, switch itu 97 */
   SIMF_NA,                            /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NA,                            /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NA,                            /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NA,                            /* action ind, switch ITU2000 */
   SIMF_NA,                            /* action ind, switch RUSS2000 */
};

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
PUBLIC SiTknEnum teMapTypeActInd[SI_MAX_SWITCH] =
{
   SIMF_NA,                            /* action ind, switch test */
   SIMF_NA,                            /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NA,                            /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NA,                            /* action ind, switch ETSI */
   SIMF_NA,                            /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NA,                            /* action ind, switch NTT */
   SIMF_NODFLT,                        /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NA,                            /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};
#endif

PUBLIC SiTknEnum teSuspResIndActInd[SI_MAX_SWITCH] =
{
   SIMF_NA,                            /* action ind, switch test */
   SIMF_NA,                            /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_NA,                            /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NA,                            /* action ind, switch ETSI */
   SIMF_NA,                            /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NA,                            /* action ind, switch Bellcore */
   SIMF_NA,                            /* action ind, switch NTT */
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_NA,                            /* action ind, switch itu 97 */
   SIMF_NA,                            /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NA,                            /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NA,                            /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NA,                            /* action ind, switch ITU2000 */
   SIMF_NA,                            /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teLocationActIndA  [SI_MAX_SWITCH] =
{
   SIMF_DFLT,                        /* action ind, switch test */
   SIMF_DFLT,                        /* action ind, switch ccitt */
   SIMF_DFLT,                        /* action ind, switch ansi */
   SIMF_DFLT,                        /* action ind, switch ansi 92 */
   SIMF_DFLT,                        /* action ind, switch singapore tel */
   SIMF_DFLT,                        /* action ind, switch q.767 */
   SIMF_DFLT,                        /* action ind, switch ETSI */
   SIMF_DFLT,                        /* action ind, switch GT_FTZ */
   SIMF_DFLT,                        /* action ind, switch RUSSIA */
   SIMF_NODFLT,                      /* action ind, switch Bellcore */
   SIMF_DFLT,                        /* action ind, switch NTT */  
   SIMF_DFLT,                        /* action ind, switch ansi 95 */
   SIMF_DFLT,                        /* action ind, switch itu 97 */
   SIMF_DFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_DFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_DFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_DFLT,                        /* action ind, switch ITU2000 */
   SIMF_DFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teLocationActIndB  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NODFLT,                        /* action ind, switch ccitt */
   SIMF_DFLT,                          /* action ind, switch ansi */
   SIMF_DFLT,                          /* action ind, switch ansi 92 */
   SIMF_NODFLT,                        /* action ind, switch singapore tel */
   SIMF_NODFLT,                        /* action ind, switch q.767 */
   SIMF_NODFLT,                        /* action ind, switch ETSI */
   SIMF_NODFLT,                        /* action ind, switch GT_FTZ */
   SIMF_NODFLT,                        /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NODFLT,                        /* action ind, switch NTT */
   SIMF_DFLT,                          /* action ind, switch ansi 95 */
   SIMF_NODFLT,                        /* action ind, switch itu 97 */
   SIMF_NODFLT,                        /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NODFLT,                        /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NODFLT,                        /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NODFLT,                        /* action ind, switch ITU2000 */
   SIMF_NODFLT,                        /* action ind, switch RUSS2000 */
};

PUBLIC SiTknEnum teRedirCapActInd  [SI_MAX_SWITCH] =
{
   SIMF_NODFLT,                        /* action ind, switch test */
   SIMF_NA,                            /* action ind, switch ccitt */
   SIMF_NA,                            /* action ind, switch ansi */
   SIMF_NA,                            /* action ind, switch ansi 92 */
   SIMF_NA,                            /* action ind, switch singapore tel */
   SIMF_NA,                            /* action ind, switch q.767 */
   SIMF_NA,                            /* action ind, switch ETSI */
   SIMF_NA,                            /* action ind, switch GT_FTZ */
   SIMF_NA,                            /* action ind, switch RUSSIA */
   SIMF_NODFLT,                        /* action ind, switch Bellcore */
   SIMF_NA,                            /* action ind, switch NTT */
   SIMF_NA,                            /* action ind, switch ansi 95 */
   SIMF_NA,                            /* action ind, switch itu 97 */
   SIMF_NA,                            /* action ind, switch etsi v3 */
/* si029.220: Addition - added item for Indian variant */
   SIMF_NA,                            /* action ind, switch India */
/* si034.220: Addition - added item for China variant */
   SIMF_NA,                            /* action ind, switch China */
/* si040.220: Addition - added item for ITU200 and Russian 2000  variants */
   SIMF_NA,                            /* action ind, switch ITU2000 */
   SIMF_NA,                            /* action ind, switch RUSS2000 */
};

/********************************************************************30**
 
         End of file:     ci_db2.c@@/main/7 - Wed Jul 25 13:21:12 2001
 
*********************************************************************31*/
 

/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 

/********************************************************************60**
 
        Revision history:

*********************************************************************61*/
 
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      rs   1. initial release.

1.2          ---      ao   1. Added Russian variant 
1.3          ---      ym   1. Added NTT variant.
            si008.216 tz   1. Changed the action indicator for calling
                              party numbering plan for GR-317 (Bellcore)
                              variant such that if an unrecognized
                              parameter value is received, a default value
                              is used.
1.5          ---      bsp  1. Merged the database from ISUP 2.16 (LPR for
                              Bellcore GR-317 variant of ISUP) with the
                              database from ISUP 2.17 (LPR for NTT variant
                              of ISUP).
/main/6      ---      bsp  1. Added action indicators for itokens added for 
                              ITU 97, ANSI 95 and ETSI v3 variants.
                           2. Changed define type in teCagPrtyNatAddrActIndA &
                              teCagPrtyNatAddrActIndB to SIMF_IGNORE such that
                              spare values of Nature of Addr are also passed on
                           3. Deleted unused variable
/main/7      ---      hy   1. Changes related to patch propagation, bug fixes
                              and addition of new action types
                      hy   1. Added a action type for teSuspResIndActInd
                           2. Added action types for teLocationActInd and
                              teRedirCapActInd
                           3. Modified the action in teSCCPMethInd1ActIndA
                              and teSCCPMethInd1ActIndB for Bellcore
            si011.220 km   1. For Telcordia variant, changed action type for 
                              Nature of Address in the Called Party Number 
                              parameter
            si029.220 tz   1. Added INDIA variant.
           si034220  rk    1. Added CHINA flag and switch where applicable.
           si042.220 bn    1. Added ITU2000 and Russian 2000 ISUP variants.
*********************************************************************91*/
