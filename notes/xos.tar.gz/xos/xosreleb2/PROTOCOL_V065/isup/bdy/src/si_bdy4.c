/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

    Name:     ISUP - body 4

    Type:     C source file

    Desc:     C source code for ISUP Circuit Control,
              Circuit and Circuit Group Control supplied by TRILLIUM.

              Part 4: Support functions

    File:     ci_bdy4.c

    Sid:      ci_bdy4.c@@/main/36 - Wed Jul 25 13:20:46 2001
 
    Prg:      rh

    Notes:    This file is heavily modified and completely reorganised
              to incorporate hardware and maintenance blocking for circuits
              Certain interface changes are assumed, but backward 
              compatibility is provided, which will not be supported
              after sometime in the future (12/03/97).

*********************************************************************21*/


/************************************************************************

     Note: 

     This file has been extracted to support the following options:

     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif

************************************************************************/


/*
It is assumed that the following functions are provided in the system
services service provider file:

     SInitQueue     Initialize Queue
     SQueueFirst    Queue to First Place
     SQueueLast     Queue to Last Place
     SDequeueFirst  Dequeue from First Place
     SDequeueLast   Dequeue from Last Place
     SFlushQueue    Flush Queue
     SCatQueue      Concatenate Queue
     SFndLenQueue   Find Length of Queue

     SGetMsg        Get Message
     SPutMsg        Put Message
     SInitMsg       Initialize Message

     SAddPreMsg     Add Pre Message
     SAddPstMsg     Add Post Message
     SRemPreMsg     Remove Pre Message
     SRemPstMsg     Remove Post Message
     SExamMsg       Examine Message
     SFndLenMsg     Find Length of Message
     SCopyMsgMsg    Copy Message to Message
     SCatMsg        Concatenate Message
     SSegMsg        Segment Message

     SChkRes        Check Resources
     SRegTmr        Register Activate Task - timer

*/



/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.             description
*     --------    ----------------------------------------------
*
*/


/* header include files (.h) */

#include "envopt.h"        /* environment options     */  
#include "envdep.h"        /* environment dependent   */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer           */
#include "ssi.h"           /* system services         */
#include "lsi.h"           /* layer management        */
#include "si_mf.h"         /* message functions       */
#include "cm5.h"           /* timers                  */
#include "ci_db.h"         /* isup data base          */
#include "cm_hash.h"       /* hash-list header */
#include "sit.h"           /* isup upper interface    */
#ifdef SI_SPT
#include "spt.h"           /* SCCP upper interface    */
#endif
#ifdef SI_FTHA
#include "sht.h"           /* sht interface */
#endif

#include "si.h"            /* isup                    */
#include "si_err.h"        /* isup error              */
#ifdef IW
#include "cm_atm.h"          /* common ATM defines                 */
#include "cm_cc.h"           /* Common Call Control Hash Defs      */
#include "rmt.h"             /* resource manager defines           */
#include "cct.h"             /* Call Control Interface Header      */
#include "liw.h"             /* ISUP PSIF Layer Management Headers */
#include "iw.h"              /* ISUP PSIF Hash Defines             */
#include "iw_err.h"          /* ISUP PSIF Error Defines            */
#include "iw_ptli.h"         /* o/g SIT i/f funcs. hash defs       */
#endif

#ifdef ZI
#include "cm_pftha.h"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.h"       /* common PSF */
#include "cm_psfft.h"      /* common PSF */
#endif
#include "lzi.h"           /* ISUP PSF management */
#include "zi.h"            /* ISUP PSF */
#include "zi_err.h"        /* ISUP PSF error codes */
#endif /* ZI */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer           */
#include "ssi.x"           /* system services         */
#include "cm_ss7.x"        /* general SS7 layer       */
#include "cm_hash.x"       /* hash-list header        */
#include "cm_lib.x"        /* memory functions header */
#include "lsi.x"           /* layer management        */
#include "si_mf.x"         /* message functions       */
#include "cm5.x"           /* timers                  */
#include "ci_db.x"         /* isup data base          */
#include "sit.x"           /* isup layer              */
#ifdef SI_SPT
#include "spt.x"           /* SCCP                    */
#endif
#ifdef SI_FTHA
#include "sht.x"           /* sht interface */
#endif

#include "si.x"            /* isup                    */

#ifdef IW
#include "cm_atm.x"          /* common ATM defines                  */
#include "cm_cc.x"           /* Common Call Control Typedefs        */
#include "rmt.x"             /* resource manager function decls.    */
#include "cct.x"             /* Call Control Interface              */
#include "liw.x"             /* ISUP PSIF Layer Management typedefs */
#include "iw.x"              /* ISUP PSIF Typedefs                  */
#endif
#ifdef ZI 
#include "cm_pftha.x"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.x"       /* common PSF */
#include "cm_psfft.x"      /* common PSF */
#endif
#include "lzi.x"           /* ISUP PSF management */
#include "zi.x"            /* ISUP PSF */
#endif /* ZI */


/* local defines */

/* local typedefs */
  
/* local externs */
PRIVATE S16 siValidateRangStat ARGS((SiRangStat *rangStat, Swtch swtch, 
                                     U8 cgFsmEvt, U16 cirFlg));
PRIVATE S16 siGenCirSteInd ARGS((SiCirGrp *cirgr, SiCirStateInd *cirState,
                                    U8 evnt));
PRIVATE S16 siCirRETFAIL ARGS((SiCirCb *cir));
PRIVATE S16 siCirRETOK ARGS((SiCirCb *cir));
PRIVATE S16 siCirGrRETFAIL ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirLocEXXS00 ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemEXXS00Nmsg ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemEXXS00 ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE00SND ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE00S05 ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE01S01 ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE01S02 ARGS((SiCirCb *cir));
/* si003.220 - Addition. Added function declaration.
 */
PRIVATE S16 siCirLocE01S03 ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE01IGN ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE02S01 ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE02SND ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE02S05 ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE03IGN ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE03S03 ARGS((SiCirCb *cir));
/* si003.220 - Addition. Added function declaration.
 */
PRIVATE S16 siCirLocE06S05 ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE03S04 ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE04SND ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE05S05 ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE06SND ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE06S03 ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE07SND ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE07IGN ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE08SND ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE09SND ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE09IGN ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE090DS05 ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE0ASND ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE0BSND ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE0CSND ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE0DSND ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE0ESND ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE0FS05 ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE10SND ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE10S06 ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE10S07 ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE11S01 ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE11SND ARGS((SiCirCb *cir));
/* si013.220 : Addition */
PRIVATE S16 siCirRemE12S00Nmsg ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE12S01 ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE12SND ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE13SND ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE13S07 ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE14S00 ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE14SND ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE15SND ARGS((SiCirCb *cir));
/* si013.220 : Addition */
PRIVATE S16 siCirRemE16S00Nmsg ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE16SND ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE17SND ARGS((SiCirCb *cir));
/* si013.220 : Addition */
PRIVATE S16 siCirRemE18S00Nmsg ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE18SND ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE19SND ARGS((SiCirCb *cir));
/* si013.220 : Addition */
PRIVATE S16 siCirRemE1AS00Nmsg ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE1ASND ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE1BSND ARGS((SiCirCb *cir));
/* si013.220 : Addition */
PRIVATE S16 siCirRemE1CS00Nmsg ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE1CSND ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE1DSND ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE1ESND ARGS((SiCirCb *cir));
PRIVATE S16 siCirLocE1FSND ARGS((SiCirCb *cir));
PRIVATE S16 siCirRemE20SND ARGS((SiCirCb *cir));

PRIVATE S16 siCirGrE00S00 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE00S01 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE00S03 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE01S00 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE01S01 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE02S00 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE02S01 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE02S03 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE03S00 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE03S02 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE04SND ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE05S03 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE06S00 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE06S01 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE06S06 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE07S00 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE07SND ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE08S00 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE08S01 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE08S06 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE09S00 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE09SND ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE0ASND ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE0BS00 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE0BS06 ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE0CSND ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE0DSND ARGS((SiCirGrp *cirgr));
PRIVATE S16 siCirGrE0ESND ARGS((SiCirGrp *cirgr));

/* state event matrix for circuits */
PRIVATE PFSICCM siCirFsm[NMB_SICIR_INC_EVT][NMB_SICIR_ST] =
{
   /* block request */
   {
      siCirLocEXXS00,         /* unequipped                      */
      siCirLocE00SND,         /* idle                            */
      siCirLocE00SND,         /* waiting for BLA                 */
      siCirLocE00SND,         /* locally blocked                 */
      siCirLocE00SND,         /* waiting for UBA                 */
      siCirLocE00S05,         /* waiting for reset ack           */
      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },

   /* block ack */
   {
      siCirRemEXXS00,         /* unequipped                      */
      siCirLocE01S01,         /* idle                            */
      siCirLocE01S02,         /* waiting for BLA                 */
/* si003.220 - Modification. Modified code so that timer T12 and T13 
 * will be stopped in this state.
 */
      siCirLocE01S03,         /* locally blocked                 */
      siCirLocE01IGN,         /* waiting for UBA                 */
      siCirLocE01IGN,         /* waiting for reset ack           */
      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },

   /* unblock request */
   {
      siCirLocEXXS00,         /* unequipped                      */
      siCirLocE02S01,         /* idle                            */
      siCirLocE02SND,         /* waiting for BLA                 */
      siCirLocE02SND,         /* locally blocked                 */
      siCirLocE02SND,         /* waiting for UBA                 */
      siCirLocE02S05,         /* waiting for reset ack           */
      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },

   /* unblock ack */
   {
      siCirRemEXXS00,         /* unequipped                      */
      siCirLocE03IGN,         /* idle                            */
      siCirLocE03IGN,         /* waiting for BLA                 */
      siCirLocE03S03,         /* locally blocked                 */
      siCirLocE03S04,         /* waiting for UBA                 */
      siCirLocE03IGN,         /* waiting for reset ack           */
      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },

   /* reset request */
   {
      siCirLocE04SND,         /* unequipped                      */
      siCirLocE04SND,         /* idle                            */
      siCirLocE04SND,         /* waiting for BLA                 */
      siCirLocE04SND,         /* locally blocked                 */
      siCirLocE04SND,         /* waiting for UBA                 */
      siCirLocE04SND,         /* waiting for reset ack           */
      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },

   /* reset ack */
   {
      siCirRemE05S05,         /* unequipped                      */
      siCirRemE05S05,         /* idle                            */
      siCirRemE05S05,         /* waiting for BLA                 */
      siCirRemE05S05,         /* locally blocked                 */
      siCirRemE05S05,         /* waiting for UBA                 */
      siCirRemE05S05,         /* waiting for reset ack           */
      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },

   /* maintenance oriented CGB req */
   {
      siCirLocEXXS00,         /* unequipped                      */
      siCirLocE06SND,         /* idle                            */
      siCirLocE06SND,         /* waiting for BLA                 */
      siCirLocE06S03,         /* locally blocked                 */
      siCirLocE06SND,         /* waiting for UBA                 */
/* si003.220 - Modification. In 'waiting for reset ack' state, CGB Request should not
 * stop the pending timer for RSC.
 */
      siCirLocE06S05,         /* waiting for reset ack           */

      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },

   /* maintenance oriented CGB ack */
   {
      siCirRemEXXS00,         /* unequipped                      */
      siCirRemE07IGN,         /* idle                            */
      siCirRemE07SND,         /* waiting for BLA                 */
      siCirRemE07SND,         /* locally blocked                 */
      siCirRemE07IGN,         /* waiting for UBA                 */
      siCirRemE07IGN,         /* waiting for reset ack           */
      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },
 
   /* maintenance oriented CGU req */
   {
      siCirLocEXXS00,         /* unequipped                      */
      siCirLocE08SND,         /* idle                            */
      siCirLocE08SND,         /* waiting for BLA                 */
      siCirLocE08SND,         /* locally blocked                 */
      siCirLocE08SND,         /* waiting for UBA                 */
      siCirRETFAIL,           /* waiting for reset ack           */
      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },

   /* maintenance oriented CGU ack */
   {
      siCirRemEXXS00,         /* unequipped                      */
      siCirRemE09SND,         /* idle                            */
      siCirRemE09IGN,         /* waiting for BLA                 */
      siCirRemE09IGN,         /* locally blocked                 */
      siCirRemE09SND,         /* waiting for UBA                 */
      siCirRemE090DS05,       /* waiting for reset ack           */
      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },

   /* hardware oriented CGB req */
   {
      siCirLocEXXS00,         /* unequipped                      */
      siCirLocE0ASND,         /* idle                            */
      siCirLocE0ASND,         /* waiting for BLA                 */
      siCirRETOK,             /* locally blocked                 */
      siCirLocE0ASND,         /* waiting for UBA                 */
      siCirLocE0ASND,         /* waiting for reset ack           */
      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },

   /* hardware oriented CGB ack */
   {
      siCirRemEXXS00,         /* unequipped                      */
      siCirRETFAIL,           /* idle                            */
      siCirRemE0BSND,         /* waiting for BLA                 */
      siCirRemE0BSND,         /* locally blocked                 */
      siCirRETFAIL,           /* waiting for UBA                 */
      siCirRETFAIL,           /* waiting for reset ack           */
      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },

   /* hardware oriented CGU req */
   {
      siCirLocEXXS00,         /* unequipped                      */
      siCirLocE0CSND,         /* idle                            */
      siCirLocE0CSND,         /* waiting for BLA                 */
      siCirLocE0CSND,         /* locally blocked                 */
      siCirLocE0CSND,         /* waiting for UBA                 */
      siCirRETFAIL,           /* waiting for reset ack           */
      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },

   /* hardware oriented CGU ack */
   {
      siCirRemEXXS00,         /* unequipped                      */
      siCirRemE0DSND,         /* idle                            */
      siCirRETFAIL,           /* waiting for BLA                 */
      siCirRETFAIL,           /* locally blocked                 */
      siCirRemE0DSND,         /* waiting for UBA                 */
      siCirRemE090DS05,       /* waiting for reset ack           */
      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },

   /* circuit group reset request */
   {
      siCirLocE0ESND,         /* unequipped                      */
      siCirLocE0ESND,         /* idle                            */
      siCirLocE0ESND,         /* waiting for BLA                 */
      siCirLocE0ESND,         /* locally blocked                 */
      siCirLocE0ESND,         /* waiting for UBA                 */
      siCirLocE0ESND,         /* waiting for reset ack           */
      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },

   /* circuit group reset ack */
   {
      NULLP,                  /* unequipped                      */
      /* In certain case, the circuit is set to be idle during
       * the period when GRS has been sent and no GRA has been
       * received. This occurs when a RLC is received during that
       * time. The circuit is set to an idle state. This RLC is
       * corresponded to a RSC, which is sent out before GRS and
       * the circuit is included in the GRS range. Later on, when
       * ISUP process the GRA, the circuit is already in the idle
       * state, which is correct. It should return OK.
       * For example:
       * 1. RSC request with CIC=2 (RSC is sent)
       * 2. GRS request with CIC = 1, range = 1(GRS is sent)
       * 3. RLC message is received
       * 4. GRA message is received
       */
      siCirRETOK,             /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      siCirRemE0FS05,         /* waiting for reset ack           */
      NULLP,                  /* waiting for blocking response   */
      NULLP,                  /* remotely blocked                */
      NULLP,                  /* waiting for unblocking response */
      NULLP,                  /* waiting for reset response      */
   },

   /* block message */
   {
      siCirRemEXXS00Nmsg,     /* unequipped                      */
      siCirRemE10SND,         /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirRemE10S06,         /* waiting for blocking response   */
      siCirRemE10S07,         /* remotely blocked                */
      siCirRemE10SND,         /* waiting for unblocking response */
      siCirRemE10SND,         /* waiting for reset response      */
   },

   /* block response */
   {
      siCirLocEXXS00,         /* unequipped                      */
      siCirLocE11S01,         /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirLocE11SND,         /* waiting for blocking response   */
      siCirRETOK,             /* remotely blocked                */
      siCirRETOK,             /* waiting for unblocking response */
      siCirRETOK,             /* waiting for reset response      */
   },

   /* unblock message */
   {
      /* si013.220, Modification: Changed function when UBL is
                                  received in unequipped state */
      siCirRemE12S00Nmsg,     /* unequipped                      */
      siCirRemE12S01,         /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirRemE12SND,         /* waiting for blocking response   */
      siCirRemE12SND,         /* remotely blocked                */
      siCirRETOK,             /* waiting for unblocking response */
      siCirRemE12SND,         /* waiting for reset response      */
   },

   /* unblock response */
   {
      siCirLocEXXS00,         /* unequipped                      */
      siCirRETOK,             /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirRETOK,             /* waiting for blocking response   */
      siCirLocE13S07,         /* remotely blocked                */
      siCirLocE13SND,         /* waiting for unblocking response */
      siCirRETOK,             /* waiting for reset response      */
   },

   /* reset message */
   {
      siCirRemE14S00,         /* unequipped                      */
      siCirRemE14SND,         /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirRemE14SND,         /* waiting for blocking response   */
      siCirRemE14SND,         /* remotely blocked                */
      siCirRemE14SND,         /* waiting for unblocking response */
      siCirRemE14SND,         /* waiting for reset response      */
   },
 
   /* reset response */
   {
      siCirRemE15SND,         /* unequipped                      */
      siCirRemE15SND,         /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirRemE15SND,         /* waiting for blocking response   */
      siCirRemE15SND,         /* remotely blocked                */
      siCirRemE15SND,         /* waiting for unblocking response */
      siCirRemE15SND,         /* waiting for reset response      */
   },

   /* maintenance oriented CGB message */
   {
      /* si013.220, Modification: Changed function when CGB is
                                  received in unequipped state */
      siCirRemE16S00Nmsg,     /* unequipped                      */
      siCirRemE16SND,         /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirRemE16SND,         /* waiting for blocking response   */
      siCirRemE16SND,         /* remotely blocked                */
      siCirRemE16SND,         /* waiting for unblocking response */
      siCirRemE16SND,         /* waiting for reset response      */
   },

   /* maintenance oriented CGB response */
   {
      siCirLocEXXS00,         /* unequipped                      */
      siCirRETFAIL,           /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirLocE17SND,         /* waiting for blocking response   */
      siCirRETOK,             /* remotely blocked                */
      siCirRETFAIL,           /* waiting for unblocking response */
      siCirRETFAIL,           /* waiting for reset response      */
   },

   /* maintenance oriented CGU message */
   {
      /* si013.220, Modification: Changed function when CGU is
                                  received in unequipped state */
      siCirRemE18S00Nmsg,     /* unequipped                      */
      siCirRemE18SND,         /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirRemE18SND,         /* waiting for blocking response   */
      siCirRemE18SND,         /* remotely blocked                */
      siCirRETOK,             /* waiting for unblocking response */
      siCirRemE18SND,         /* waiting for reset response      */
   },

   /* maintenance oriented CGU response */
   {
      siCirLocEXXS00,         /* unequipped                      */
      siCirLocE19SND,         /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirRETFAIL,           /* waiting for blocking response   */
      siCirRETFAIL,           /* remotely blocked                */
      siCirLocE19SND,         /* waiting for unblocking response */
      siCirRETFAIL,           /* waiting for reset response      */
   },

   /* hardware oriented CGB message */
   {
      /* si013.220, Modification: Changed function when CGB is
                                  received in unequipped state */
      siCirRemE1AS00Nmsg,     /* unequipped                      */
      siCirRemE1ASND,         /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirRemE1ASND,         /* waiting for blocking response   */
      siCirRemE1ASND,         /* remotely blocked                */
      siCirRemE1ASND,         /* waiting for unblocking response */
      siCirRemE1ASND,         /* waiting for reset response      */
   },

   /* hardware oriented CGB response */
   {
      siCirLocEXXS00,         /* unequipped                      */
      siCirRETFAIL,           /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirLocE1BSND,         /* waiting for blocking response   */
      siCirLocE1BSND,         /* remotely blocked                */
      siCirRETFAIL,           /* waiting for unblocking response */
      siCirRETFAIL,           /* waiting for reset response      */
   },

   /* hardware oriented CGU message */
   {
      /* si013.220, Modification: Changed function when CGU is
                                  received in unequipped state */
      siCirRemE1CS00Nmsg,     /* unequipped                      */
      siCirRemE1CSND,         /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirRemE1CSND,         /* waiting for blocking response   */
      siCirRemE1CSND,         /* remotely blocked                */
      siCirRemE1CSND,         /* waiting for unblocking response */
      siCirRemE1CSND,         /* waiting for reset response      */
   },

   /* hardware oriented CGU response */
   {
      siCirLocEXXS00,         /* unequipped                      */
      siCirLocE1DSND,         /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirRETFAIL,           /* waiting for blocking response   */
      siCirRETFAIL,           /* remotely blocked                */
      siCirLocE1DSND,         /* waiting for unblocking response */
      siCirRETFAIL,           /* waiting for reset response      */
   },

   /* circuit group reset message */
   {
      siCirRemE1ESND,         /* unequipped                      */
      siCirRemE1ESND,         /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirRemE1ESND,         /* waiting for blocking response   */
      siCirRemE1ESND,         /* remotely blocked                */
      siCirRemE1ESND,         /* waiting for unblocking response */
      siCirRemE1ESND,         /* waiting for reset response      */
   },

   /* circuit group reset response */
   {
      NULLP,                  /* unequipped                      */
      siCirLocE1FSND,         /* idle                            */
      NULLP,                  /* waiting for BLA                 */
      NULLP,                  /* locally blocked                 */
      NULLP,                  /* waiting for UBA                 */
      NULLP,                  /* waiting for reset ack           */
      siCirLocE1FSND,         /* waiting for blocking response   */
      siCirLocE1FSND,         /* remotely blocked                */
      siCirLocE1FSND,         /* waiting for unblocking response */
      siCirLocE1FSND,         /* waiting for reset response      */
   },

   /* unequipped circuit message */
   {
      siCirRemE20SND,         /* unequipped                      */
      siCirRemE20SND,         /* idle                            */
      siCirRemE20SND,         /* waiting for BLA                 */
      siCirRemE20SND,         /* locally blocked                 */
      siCirRemE20SND,         /* waiting for UBA                 */
      siCirRemE20SND,         /* waiting for reset ack           */
      siCirRemE20SND,         /* waiting for blocking response   */
      siCirRemE20SND,         /* remotely blocked                */
      siCirRemE20SND,         /* waiting for unblocking response */
      siCirRemE20SND,         /* waiting for reset response      */
   } 
};

PRIVATE PFSICGM siCirGrFsm[NMB_SICIRGR_INC_EVT][NMB_SICIRGR_ST] =
{
   /* CGB request */
   {
      siCirGrE00S00,               /* idle                     */
      siCirGrE00S01,               /* waiting for CGBA         */
      siCirGrE00S01,               /* waiting for CGUA         */
      siCirGrE00S03,               /* waiting for GRA          */
      NULLP,                       /* waiting for CGB response */
      NULLP,                       /* waiting for CGU response */
      NULLP,                       /* waiting for GRS response */
   },

   /* CGBA */
   {
      siCirGrE01S00,               /* idle                     */
      siCirGrE01S01,               /* waiting for CGBA         */
      siCirGrRETFAIL,              /* waiting for CGUA         */
      siCirGrRETFAIL,              /* waiting for GRA          */
      NULLP,                       /* waiting for CGB response */
      NULLP,                       /* waiting for CGU response */
      NULLP,                       /* waiting for GRS response */
   },

   /* CGU request */
   {
      siCirGrE02S00,               /* idle                     */
      siCirGrE02S01,               /* waiting for CGBA         */
      siCirGrE02S01,               /* waiting for CGUA         */
      siCirGrE02S03,               /* waiting for GRA          */
      NULLP,                       /* waiting for CGB response */
      NULLP,                       /* waiting for CGU response */
      NULLP,                       /* waiting for GRS response */
   },
  
   /* CGUA */ 
   {
      siCirGrE03S00,               /* idle                     */
      siCirGrRETFAIL,              /* waiting for CGBA         */
      siCirGrE03S02,               /* waiting for CGUA         */
      siCirGrRETFAIL,              /* waiting for GRA          */
      NULLP,                       /* waiting for CGB response */
      NULLP,                       /* waiting for CGU response */
      NULLP,                       /* waiting for GRS response */
   },

   /* GRS request */
   {
      siCirGrE04SND,               /* idle                     */
      siCirGrE04SND,               /* waiting for CGBA         */
      siCirGrE04SND,               /* waiting for CGUA         */
      siCirGrE04SND,               /* waiting for GRA          */
      NULLP,                       /* waiting for CGB response */
      NULLP,                       /* waiting for CGU response */
      NULLP,                       /* waiting for GRS response */
   },

   /* GRA */
   {
      siCirGrRETFAIL,              /* idle                     */
      siCirGrRETFAIL,              /* waiting for CGBA         */
      siCirGrRETFAIL,              /* waiting for CGUA         */
      siCirGrE05S03,               /* waiting for GRA          */
      NULLP,                       /* waiting for CGB response */
      NULLP,                       /* waiting for CGU response */
      NULLP,                       /* waiting for GRS response */
   },

   /* CGB */ 
   {
      siCirGrE06S00,               /* idle                     */
      NULLP,                       /* waiting for CGBA         */
      NULLP,                       /* waiting for CGUA         */
      NULLP,                       /* waiting for GRA          */
      siCirGrE06S01,               /* waiting for CGB response */
      siCirGrE06S01,               /* waiting for CGU response */
      siCirGrE06S06,               /* waiting for GRS response */
   },

   /* CGB response */
   {
      siCirGrE07S00,               /* idle                     */
      NULLP,                       /* waiting for CGBA         */
      NULLP,                       /* waiting for CGUA         */
      NULLP,                       /* waiting for GRA          */
      siCirGrE07SND,               /* waiting for CGB response */
      siCirGrRETFAIL,              /* waiting for CGU response */
      siCirGrRETFAIL,              /* waiting for GRS response */
   },

   /* CGU */
   {
      siCirGrE08S00,               /* idle                     */
      NULLP,                       /* waiting for CGBA         */
      NULLP,                       /* waiting for CGUA         */
      NULLP,                       /* waiting for GRA          */
      siCirGrE08S01,               /* waiting for CGB response */
      siCirGrE08S01,               /* waiting for CGU response */
      siCirGrE08S06,               /* waiting for GRS response */
   },

   /* CGU response */
   {
      siCirGrE09S00,               /* idle                     */
      NULLP,                       /* waiting for CGBA         */
      NULLP,                       /* waiting for CGUA         */
      NULLP,                       /* waiting for GRA          */
      siCirGrRETFAIL,              /* waiting for CGB response */
      siCirGrE09SND,               /* waiting for CGU response */
      siCirGrRETFAIL,              /* waiting for GRS response */
   },

   /* GRS */
   {
      siCirGrE0ASND,               /* idle                     */
      NULLP,                       /* waiting for CGBA         */
      NULLP,                       /* waiting for CGUA         */
      NULLP,                       /* waiting for GRA          */
      siCirGrE0ASND,               /* waiting for CGB response */
      siCirGrE0ASND,               /* waiting for CGU response */
      siCirGrE0ASND,               /* waiting for GRS response */
   },

   /* GRS response */
   {
      siCirGrE0BS00,               /* idle                     */
      NULLP,                       /* waiting for CGBA         */
      NULLP,                       /* waiting for CGUA         */
      NULLP,                       /* waiting for GRA          */
      siCirGrRETFAIL,              /* waiting for CGB response */
      siCirGrRETFAIL,              /* waiting for CGU response */
      siCirGrE0BS06,               /* waiting for GRS response */
   }
};

/* FSM event to affected circuit state map table for circuit events */
PRIVATE U8 siCirFsmEvtStateMap[NMB_SICIR_INC_EVT] = 
{
   SICIR_MTLOCST,               /* CEI_BLOREQ   */
   SICIR_MTLOCST,               /* CEI_BLA      */
   SICIR_MTLOCST,               /* CEI_UBLREQ   */
   SICIR_MTLOCST,               /* CEI_UBA      */
   SICIR_MTLOCST,               /* CEI_RESREQ   */
   SICIR_MTLOCST,               /* CEI_RESACK   */
   SICIR_MTLOCST,               /* CEI_MTCGBREQ */
   SICIR_MTLOCST,               /* CEI_MTCGBA   */
   SICIR_MTLOCST,               /* CEI_MTCGUREQ */
   SICIR_MTLOCST,               /* CEI_MTCGUA   */
   SICIR_HWLOCST,               /* CEI_HWCGBREQ */
   SICIR_HWLOCST,               /* CEI_HWCGBA   */
   SICIR_HWLOCST,               /* CEI_HWCGUREQ */
   SICIR_HWLOCST,               /* CEI_HWCGUA   */
   SICIR_MTLOCST,               /* CEI_GRSREQ   */
   SICIR_MTLOCST,               /* CEI_GRA      */
   SICIR_MTREMST,               /* CEI_BLO      */
   SICIR_MTREMST,               /* CEI_BLORSP   */
   SICIR_MTREMST,               /* CEI_UBL      */
   SICIR_MTREMST,               /* CEI_UBLRSP   */
   SICIR_MTREMST,               /* CEI_RES      */
   SICIR_MTREMST,               /* CEI_RESRSP   */
   SICIR_MTREMST,               /* CEI_MTCGB    */
   SICIR_MTREMST,               /* CEI_MTCGBRSP */
   SICIR_MTREMST,               /* CEI_MTCGU    */
   SICIR_MTREMST,               /* CEI_MTCGURSP */
   SICIR_HWREMST,               /* CEI_HWCGB    */
   SICIR_HWREMST,               /* CEI_HWCGBRSP */
   SICIR_HWREMST,               /* CEI_HWCGU    */
   SICIR_HWREMST,               /* CEI_HWCGURSP */
   SICIR_MTREMST,               /* CEI_GRS      */
   SICIR_MTREMST,               /* CEI_GRSRSP   */
   SICIR_MTREMST,               /* CEI_UCIC     */
};

/* forward references */

/* public variable declarations */


/*
*
*       Fun:   siProcCirEvt
*
*       Desc:  Driver function for local circuit management state machine
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: tPAUSE is associated with DPC control block, not with circuit
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 siProcCirEvt
(
SiCirCb *cir,
U8      evt,
Bool    indexFlag
)
#else
PUBLIC S16 siProcCirEvt(cir, evt, indexFlag)
SiCirCb *cir;
U8      evt;
Bool    indexFlag;
#endif
{
   PFSICCM pCirActFunc;     /* pointer to activation function */
   U8      cirStateIdx;

   TRC3(siProcCirEvt)

/* si027.220: Addition - added cir and interface NULLP checks to 
 * prevent program core dumps */
#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* index of the incoming event unknown - derive the info */
   if (indexFlag == FALSE)
   {
      /* find the input index to circuit group state machine */
      switch (evt)
      {
         case SIT_STA_CIRBLOREQ    :
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : SIT_STA_CIRBLOREQ \n"));  
            cir->fsmEvnt      = CEI_BLOREQ;
            break;

         case SIT_STA_CIRBLORSP    :
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : SIT_STA_CIRBLORSP \n"));  
            cir->fsmEvnt      = CEI_BLORSP;
            break;

         case SIT_STA_CIRUBLREQ    :
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : SIT_STA_CIRUBLREQ \n"));  
            cir->fsmEvnt      = CEI_UBLREQ;
            break;

         case SIT_STA_CIRUBLRSP    :
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : SIT_STA_CIRUBLRSP \n"));  
            cir->fsmEvnt      = CEI_UBLRSP;
            break;

         case SIT_STA_CIRRESREQ    :
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : SIT_STA_CIRRESREQ \n"));  
            cir->fsmEvnt      = CEI_RESREQ;
            break;

         case SIT_STA_CIRRESRSP    :
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : SIT_STA_CIRRESRSP \n"));  
            cir->fsmEvnt      = CEI_RESRSP;
            break;

         default:
         {
            Bool    hFlag;

            switch (cir->sduSp->m.siStaEvnt.cgsmti.typeInd.val & 0x03)
            {
               case HARDFAIL: 
                  SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : HARDFAIL       \n"));  
                  hFlag = TRUE;
                  break;
               case MAINT: 
                  SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : MAINT       \n"));  
                  hFlag = FALSE;
                  break;
               default:
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "type is neither HARDFAIL not MAINT %d\n",
                           cir->sduSp->m.siStaEvnt.cgsmti.typeInd.val&0x03));  
                    
#if (ERRCLASS & ERRCLS_DEBUG)

#endif
                  RETVALUE(RFAILED); 
            } 

            switch (evt)
            {
               case SIT_STA_CGBREQ       :
                  SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : SIT_STA_CGBREQ       \n"));  
                  if (!hFlag)
                     cir->fsmEvnt = CEI_MTCGBREQ;
                  else
                     cir->fsmEvnt = CEI_HWCGBREQ;
                  break;

               case SIT_STA_CGUREQ       :
                  SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : SIT_STA_CGUREQ       \n"));  
                  if (!hFlag)
                     cir->fsmEvnt = CEI_MTCGUREQ;
                  else
                     cir->fsmEvnt = CEI_HWCGUREQ;
                  break;
       
               case SIT_STA_CGBRSP       :
                  SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : SIT_STA_CGBRSP       \n"));  
                  if (!hFlag)
                     cir->fsmEvnt = CEI_MTCGBRSP;
                  else
                     cir->fsmEvnt = CEI_HWCGBRSP;
                  break;

               case SIT_STA_CGURSP       :
                  SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : SIT_STA_CGURSP       \n"));  
                  if (!hFlag)
                     cir->fsmEvnt = CEI_MTCGURSP;
                  else
                     cir->fsmEvnt = CEI_HWCGURSP;
                  break;

               case SIT_STA_GRSREQ       :
                  SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : SIT_STA_GRSREQ       \n"));  
                  cir->fsmEvnt = CEI_GRSREQ;
                  break;

               case SIT_STA_GRSRSP       :
                  SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : SIT_STA_GRSRSP       \n"));  
                  cir->fsmEvnt = CEI_GRSRSP;

               default:
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "default evt %d unknown !! dumping \n", evt));  
                    
#if (ERRCLASS & ERRCLS_DEBUG)

#endif
                  RETVALUE(RFAILED);
            }
         }
         break;
      }
   }
   else
      cir->fsmEvnt = evt;

   /* get the affected circuit state */
   cirStateIdx = siCirFsmEvtStateMap[cir->fsmEvnt];

#ifndef SI_INFINITETRY  
   /* reset the timer count to zero to restart major timers 
    * whenever a new event sequence is initiated
    */
   cir->tmrCnt = 0;
#endif 
   /* find the pointer to action function */
   if ( (pCirActFunc = siCirFsm[cir->fsmEvnt][cir->transStat[cirStateIdx]]) 
                          == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "NULL siCirFsm[fsmEvt:%#x][transStat:%#x, cirStateIdx:%#x]\n",
              cir->fsmEvnt, cirStateIdx, cir->transStat[cirStateIdx]));  
        
#if (ERRCLASS & ERRCLS_DEBUG) 
      SILOGERROR(ERRCLS_DEBUG, ESI519, (ErrVal) 0, 
                 "siProcCirEvt() Failed, invalid circuit state and event");
#endif 
      RETVALUE(RFAILED);
   }

   if ((*pCirActFunc)(cir) == RFAILED)
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "action function returned failure.\n"));  
      RETVALUE(RFAILED);
   } 
#ifdef ZI
   /* This is done so that group operations does not result in the
      loss of information to be updated */
   ziUpdPeer();
#endif
   
   RETVALUE(ROK);
} /* end of siProcCirEvt */


/*
*
*       Fun:   siProcCirMsg
*
*       Desc:  Driver function for remote circuit management state machine
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: tPAUSE is associated with DPC control block, not with circuit
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 siProcCirMsg
(
SiCirCb *cir,            /* pointer to control block */
U8      msgIdx,          /* type of incoming event */
Bool    indexFlag        /* if the passed msg type is fsm event index itself */
)
#else
PUBLIC S16 siProcCirMsg(cir, msgIdx, indexFlag)
SiCirCb *cir;
U8      msgIdx;
Bool    indexFlag;
#endif
{
   PFSICCM pCirActFunc;     /* pointer to activation function */
   U8      cirStateIdx;

   TRC3(siProcCirMsg)

   if (indexFlag == FALSE)
   {
      /* find the index of the event */
      switch (msgIdx)
      {
         case MI_RELCOMP    :
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : MI_RELCOMP \n"));  
            cir->fsmEvnt = CEI_RESACK;
            break;

         case MI_RESCIR     :
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : MI_RESCIR \n"));  
            cir->fsmEvnt = CEI_RES;
            break;

         case MI_BLOCK      :
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : MI_BLOCK \n"));  
            cir->fsmEvnt = CEI_BLO;
            break;

         case MI_UNBLK      :
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : MI_UNBLK \n"));  
            cir->fsmEvnt = CEI_UBL;
            break;

         case MI_BLOCKACK   :
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : MI_BLOCKACK \n"));  
            cir->fsmEvnt = CEI_BLA;
            break;

         case MI_UNBLKACK   :
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : MI_UNBLKACK \n"));  
            cir->fsmEvnt = CEI_UBA;
            break;

         case MI_UNEQUIPCIC :
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : MI_UNEQUIPCIC \n"));  
            cir->fsmEvnt = CEI_UCIC;
            break;

         default:
         {
            Bool hFlag;

            hFlag = FALSE;
            switch (msgIdx)
            {
               case MI_CIRGRPBLK :
                  SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : MI_CIRGRPBLK       \n"));  
                  if (cir->pduSp->m.cirGrpBlk.cgsmti.typeInd.val & 0x03)
                     hFlag = TRUE;
                  if (!hFlag)
                     cir->fsmEvnt      = CEI_MTCGB;
                  else
                     cir->fsmEvnt      = CEI_HWCGB;
                  break;

               case MI_CIRGRPBLKACK :
                  SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : MI_CIRGRPBLKACK       \n"));  
                  if (cir->pduSp->m.cirGrpBlkAck.cgsmti.typeInd.val & 0x03)
                     hFlag = TRUE;
                  if (!hFlag)
                     cir->fsmEvnt      = CEI_MTCGBA;
                  else
                     cir->fsmEvnt      = CEI_HWCGBA;
                  break;

               case MI_CIRGRPUBLK :
                  SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : MI_CIRGRPUBLK       \n"));  
                  if (cir->pduSp->m.cirGrpUnblk.cgsmti.typeInd.val & 0x03)
                     hFlag = TRUE;
                  if (!hFlag)
                     cir->fsmEvnt = CEI_MTCGU;
                  else
                     cir->fsmEvnt = CEI_HWCGU;
                  break;

               case MI_CIRGRPUBLKACK :
                  SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : MI_CIRGRPUBLKACK       \n"));  
                  if (cir->pduSp->m.cirGrpUblkAck.cgsmti.typeInd.val & 0x03)
                     hFlag = TRUE;
                  if (!hFlag)
                     cir->fsmEvnt      = CEI_MTCGUA;
                  else
                     cir->fsmEvnt      = CEI_HWCGUA;
                  break;

               case MI_CIRGRPRES    :
                  SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : MI_CIRGRPRES       \n"));  
                  cir->fsmEvnt      = CEI_GRS;
                  break;

               case MI_CIRGRPRESACK       :
                  SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case : MI_CIRGRPRESACK       \n"));  
                  cir->fsmEvnt = CEI_GRA;

               default:
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid msg Idx %d\n", msgIdx));  
                    
                  RETVALUE(RFAILED);
            }
         }
      }
   }
   else
      cir->fsmEvnt = msgIdx;

   cirStateIdx = siCirFsmEvtStateMap[cir->fsmEvnt];
   /* find the pointer to action function */
   if ((pCirActFunc = siCirFsm[cir->fsmEvnt][cir->transStat[cirStateIdx]]) 
        == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "NULL siCirFsm[fsmEvt:%#x][transStat:%#x, cirStateIdx:%#x]\n",
             cir->fsmEvnt, cirStateIdx, cir->transStat[cirStateIdx]));  
#if (ERRCLASS & ERRCLS_DEBUG) 
      SILOGERROR(ERRCLS_DEBUG, ESI520, (ErrVal) 0, 
                 "siProcCirMsg() Failed, action function failure");
#endif 
      RETVALUE(RFAILED);
   }

   if ((*pCirActFunc)(cir) == RFAILED)
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "action function returned failure.\n"));  

      RETVALUE(RFAILED);
   } 

#ifdef ZI
   /* This is done so that group operations does not result in the
      loss of information to be updated */
   ziUpdPeer();
#endif
   
   RETVALUE(ROK);
} /* end of siProcCirMsg */


/*
*
*       Fun:   siProcCirGrEvt
*
*       Desc:  Processing function for circuit group events from upper layer
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 siProcCirGrEvt
(
SiCirCb   *cir,     /* pointer to circuit control block */
U8        evtType,  /* event type */
SiStaEvnt *staEvt   /* status event from upper layer */
)
#else
PUBLIC S16 siProcCirGrEvt(cir, evtType, staEvt)
SiCirCb   *cir;     /* pointer to circuit control block */
U8        evtType;  /* event type */
SiStaEvnt *staEvt;  /* status event from upper layer */
#endif
{
   PFSICGM   pCirGrActFunc;  /* pointer to action function */
   SiCirGrp  *cirGr;         /* pointer to circuit group control block */
   SiNSAPCb  *cb;
   SiAllSdus ev;
   S16       ret;
   Bool      hFlag;
   U8        cirState;

   TRC3(siProcCirGrEvt)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   hFlag = FALSE;
   
   if ((evtType != SIT_STA_GRSREQ) && (evtType != SIT_STA_GRSRSP) &&
       (evtType !=  SIT_STA_CGQRYREQ))
   { 
      switch (cir->sduSp->m.siStaEvnt.cgsmti.typeInd.val & 0x03)
      {
         case HARDFAIL:
            hFlag = TRUE;
            break;
         case MAINT:
            hFlag = FALSE;
            break;
         default:
             SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                  "type is neither HARDFAIL not MAINT %d\n",
                      cir->sduSp->m.siStaEvnt.cgsmti.typeInd.val&0x03));  
#if (ERRCLASS & ERRCLS_DEBUG)
             SILOGERROR(ERRCLS_DEBUG, ESI521, (ErrVal )cir->
                            sduSp->m.siStaEvnt.cgsmti.typeInd.val,
                  "[cgsmti.typeInd.val] is not recognised ");
#endif
             /* generate Alarm */
             siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->cfg.cirId, 
                 LSI_USTA_DGNVAL_NONE, NULLP,
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP);
             SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL,
                 LSI_EVENT_LOCAL, LSI_CAUSE_INV_CGSMTI, TRUE,
                     cir->cfg.cirId, SI_ALRM_CGSMTIERR);
            RETVALUE(RFAILED); 
      } 
   }

   /* find the input to circuit group state machine */
   switch (evtType)
   {
      case SIT_STA_CGBREQ     :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case SIT_STA_CGBREQ \n"));   
         cir->fsmEvnt = CGEI_CGBREQ;
         if (!hFlag)
            cirState = SICIR_MTLOCST;
         else
            cirState = SICIR_HWLOCST;
         break;

      case SIT_STA_CGUREQ     :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case SIT_STA_CGUREQ \n"));   
         cir->fsmEvnt = CGEI_CGUREQ;
         if (!hFlag)
            cirState = SICIR_MTLOCST;
         else
            cirState = SICIR_HWLOCST;
         break;

      case SIT_STA_CGQRYREQ     :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case SIT_STA_CGQRYREQ \n"));   
         /* special case: circuit group FSM is bypassed */
         cir->fsmEvnt = CGEI_CGQRYREQ;
         cirState = SICIR_MTLOCST;
         break;

      case SIT_STA_CGBRSP     :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case SIT_STA_CGBRSP \n"));   
         cir->fsmEvnt = CGEI_CGBRSP;
         if (!hFlag)
            cirState = SICIR_MTREMST;
         else
            cirState = SICIR_HWREMST;
         break;

      case SIT_STA_CGURSP     :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case SIT_STA_CGURSP \n"));   
         cir->fsmEvnt    = CGEI_CGURSP;
         if (!hFlag)
            cirState = SICIR_MTREMST;
         else
            cirState = SICIR_HWREMST;
         break;

      case SIT_STA_GRSREQ       :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case SIT_STA_GRSREQ\n"));  
         /* check if the status is present? if so, make it not present
          */
         if (staEvt->rangStat.status.pres)
         {
            staEvt->rangStat.status.pres = NOTPRSNT;
         }
         cir->fsmEvnt   = CGEI_GRSREQ;
         cirState = SICIR_MTLOCST;
         break;

      case SIT_STA_GRSRSP       :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case SIT_STA_GRSRSP \n"));   
         cir->fsmEvnt = CGEI_GRSRSP;
         cirState = SICIR_MTREMST;
         break;
      default:
         SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "evtType is unknown ! %d\n", evtType));  
         RETVALUE(RFAILED);  
   } 

   {           
      if (siValidateRangStat(&staEvt->rangStat, cir->pIntfCb->cfg.swtch, 
           cir->fsmEvnt, cir->cfg.cirFlg) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Range or Status is not valid.Dumping\n"));  
        
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI522, (ErrVal )0,
              "Some problem detected with range or status! can not proceed.");
#endif
         /* generate Alarm */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->cfg.cirId, 
            LSI_USTA_DGNVAL_NONE, NULLP,
            LSI_USTA_DGNVAL_NONE, NULLP, 
            LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL,
            LSI_EVENT_LOCAL, LSI_CAUSE_INV_RNGORSTATUS, TRUE,
            cir->cfg.cirId, SI_ALRM_RNGSTATERR);
         RETVALUE(RFAILED);
      }
   }   

   /* select the proper circuit group from the circuit based on event type */
   /* if circuit group does not exist, allocate one */
   if ( (cirGr = cir->cirGr[cirState]) == NULLP)
   {
      cb = siGetLwrMCbPtr(cir);
      if ((cirGr = siGetCirGr(cir)) == NULLP)
      {
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "Can not allocate new circuit group\n"));  
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI523, (ErrVal) 0, 
                    "siProcCirGrEvt() Failed, can't allocate circuit group");
#endif
         RETVALUE(RFAILED);
      }
      cir->cirGr[cirState] = cirGr;
      cirGr->cirState      = cirState;

      /* if we are processing incoming group reset request, copy range status 
         into the cirquit group */
      if (evtType == SIT_STA_GRSREQ)
      {
        if (cirGr->state == SICG_ST_IDLE)
        {
          cirGr->rangStat.eh.pres = PRSNT_NODEF;
          cirGr->rangStat.range.pres = PRSNT_NODEF;
          cirGr->rangStat.range.val = staEvt->rangStat.range.val;
        }
        else
        {
          if (((staEvt->rangStat.range.val) && 
               (cirGr->rangStat.range.val != staEvt->rangStat.range.val)) 
             )
          {  
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                  "range in event %d and in cirgr %d does not match\n",
                  staEvt->rangStat.range.val, cirGr->rangStat.range.val));  
            RETVALUE(RFAILED);
          } 
        }
      }
   }
   else 
   {  
      SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "already circuit group existing\n"));  
   } 


   ev.m.siStaEvnt = *(SiStaEvnt *)staEvt; 
   cirGr->sduSp   = &ev;

#ifndef SI_INFINITETRY  
   cir->tmrCnt = 0;
#endif

   if (cir->fsmEvnt == CGEI_CGQRYREQ)
   {
      ret = siCirGrE0CSND(cirGr);
      RETVALUE(ret);
   }

   if ( (pCirGrActFunc = siCirGrFsm[cir->fsmEvnt][cirGr->state]) == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "siCirGrFsm[fsmEvt:%#x][cirGr->state:%#x] is null !!! \n",
             cir->fsmEvnt, cirGr->state));  
#if (ERRCLASS & ERRCLS_DEBUG) 
      SILOGERROR(ERRCLS_DEBUG, ESI524, (ErrVal) 0, 
                 "siProcCirGrEvt(): invalid circuit group state and event");
#endif
      RETVALUE(RFAILED);
   }

   if ((*pCirGrActFunc)(cirGr) == RFAILED)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "circuit group function (state=%d, event=%d) failed.\n",
             cir->fsmEvnt, cirGr->state));  

      RETVALUE(RFAILED);
   }

   RETVALUE(ROK); 
} 


/*
*
*       Fun:   siProcCirGrMsg
*
*       Desc:  Processing function for circuit group messages from network
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 siProcCirGrMsg
(
SiCirCb   *cir,        /* pointer to circuit control block */
U8        msgIdx,      /* PDU type */
SiAllPdus *allPdus     /* incoming PDU */
)
#else
PUBLIC S16 siProcCirGrMsg(cir, msgIdx, allPdus)
SiCirCb   *cir;        /* pointer to circuit control block */
U8        msgIdx;      /* event for circuit group state machine based on PDU */
SiAllPdus *allPdus;    /* incoming PDU */
#endif
{
   PFSICGM  pCirGrActFunc; /* pointer to activation function */
   SiRangStat *rangStat;
   SiCirGrp *cirGr;         /* pointer to circuit group control block */
   SiNSAPCb *cb;
   U8       typeInd;
   U8       cirState;

   TRC3(siProcCirGrMsg)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* find the input to circuit group state machine */
   switch (msgIdx)
   {
      case MI_CIRGRPBLK     :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case MI_CIRGRPBLK \n"));   
         typeInd = cir->pduSp->m.cirGrpBlk.cgsmti.typeInd.val & 0x03;
         rangStat = &cir->pduSp->m.cirGrpBlk.rangStat;
         if (typeInd == HARDFAIL) 
            cirState = SICIR_HWREMST;
         else
            cirState = SICIR_MTREMST;
         cir->fsmEvnt = CGEI_CGB;
         break;

      case MI_CIRGRPBLKACK  :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case MI_CIRGRPBLKACK \n"));   
         typeInd = cir->pduSp->m.cirGrpBlkAck.cgsmti.typeInd.val;
         rangStat = &cir->pduSp->m.cirGrpBlkAck.rangStat;
         if (typeInd == HARDFAIL) 
            cirState = SICIR_HWLOCST;
         else
            cirState = SICIR_MTLOCST;
         cir->fsmEvnt = CGEI_CGBACK;
         break;

      case MI_CIRGRPQRY     :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case MI_CIRGRPQRY \n"));   
         cirState = SICIR_MTREMST;
         rangStat = (SiRangStat *)&cir->pduSp->m.cirGrpQry.rangStat;
         cir->fsmEvnt = CGEI_CGQRY;
         break;
 
      case MI_CIRGRPQRYRES  :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case MI_CIRGRPQRYRES \n"));   
         cirState = SICIR_MTLOCST;
         rangStat = (SiRangStat *)&cir->pduSp->m.cirGrpQryRes.rangStat;
         cir->fsmEvnt   = CGEI_CGQRYRSP; 
         break;

      case MI_CIRGRPRES     :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case MI_CIRGRPRES \n"));   
         /* check if the status is present? if so, need to dump the GRS msg */
         if (cir->pduSp->m.cirGrpRes.rangStat.status.pres)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "Status is present in GRS msg on ckt %#lx. Dumping\n",
                   cir->cfg.cirId));  
            /* generate Alarm */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->cfg.cirId, 
                       LSI_USTA_DGNVAL_NONE, NULLP,
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL,
                        LSI_EVENT_REMOTE, LSI_CAUSE_INV_RNGORSTATUS, TRUE,
                        cir->cfg.cirId, SI_ALRM_RNGSTATERR);

            RETVALUE(RFAILED);
         }
         cirState = SICIR_MTREMST;
         rangStat = (SiRangStat *)&cir->pduSp->m.cirGrpRes.rangStat;
         cir->fsmEvnt   = CGEI_GRS;
         break;

      case MI_CIRGRPRESACK  :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case MI_CIRGRPRESACK \n"));   
         cirState = SICIR_MTLOCST;
         rangStat = &cir->pduSp->m.cirGrpResAck.rangStat;
         cir->fsmEvnt = CGEI_GRSACK;
         break;

      case MI_CIRGRPUBLK    :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case MI_CIRGRPUBLK \n"));   
         typeInd = cir->pduSp->m.cirGrpUnblk.cgsmti.typeInd.val & 0x03;
         rangStat = &cir->pduSp->m.cirGrpUnblk.rangStat;
         if (typeInd == HARDFAIL) 
            cirState = SICIR_HWREMST;
         else
            cirState = SICIR_MTREMST;
         cir->fsmEvnt = CGEI_CGU;
         break;

      case MI_CIRGRPUBLKACK :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case MI_CIRGRPUBLKACK \n"));   
         typeInd = cir->pduSp->m.cirGrpUblkAck.cgsmti.typeInd.val & 0x03;
         rangStat = &cir->pduSp->m.cirGrpUblkAck.rangStat;
         if (typeInd == HARDFAIL) 
            cirState = SICIR_HWLOCST;
         else
            cirState = SICIR_MTLOCST;
         cir->fsmEvnt = CGEI_CGUACK;
         break;

      default:
         RETVALUE(RFAILED);
   }

   {           
      if (siValidateRangStat(rangStat, cir->pIntfCb->cfg.swtch, cir->fsmEvnt, 
          cir->cfg.cirFlg) != ROK)
      {  
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Range or Status is not valid.Dumping\n"));  
         /* generate Alarm */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->cfg.cirId, 
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL,
                     LSI_EVENT_REMOTE, LSI_CAUSE_INV_RNGORSTATUS, TRUE,
                     cir->cfg.cirId, SI_ALRM_RNGSTATERR);

         RETVALUE(RFAILED);
      }
   }

   /* if circuit group does not exist, allocate one */ 
   if ( (cirGr = cir->cirGr[cirState]) == NULLP)
   {
      cb = siGetLwrMCbPtr(cir);
      if ((cirGr = siGetCirGr(cir)) == NULLP)
      {
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "Can not allocate new circuit group\n"));  

#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI525, (ErrVal) 0, 
                 "siProcCirGrMsg() Failed, can't allocate circuit grp");
#endif
         RETVALUE(RFAILED);
      }
      cir->cirGr[cirState] = cirGr;
      cirGr->cirState      = cirState;

      /* if we are processing incoming group reset, copy range status 
         into the cirquit group */
      if (msgIdx == MI_CIRGRPRES)
      {
        if (cirGr->state == SICG_ST_IDLE)
        {
          cirGr->rangStat.eh.pres = PRSNT_NODEF;
          cirGr->rangStat.range.pres = PRSNT_NODEF;
          cirGr->rangStat.range.val = rangStat->range.val;
        }
        else
        {
          if (((rangStat->range.val) && 
               (cirGr->rangStat.range.val != rangStat->range.val))
             )
          {  
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                  "range in event %d and in cirgr %d does not match\n",
                  rangStat->range.val, cirGr->rangStat.range.val));  
            RETVALUE(RFAILED);
          } 
        }
      }
   }   
   else
   {  
      SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "already circuit group existing\n"));  
   } 

   cirGr->pduSp = allPdus;

   if (cir->fsmEvnt == CGEI_CGQRY)
   {
      RETVALUE(siCirGrE0DSND(cirGr));
   }
   else if (cir->fsmEvnt == CGEI_CGQRYRSP)
   {
      RETVALUE(siCirGrE0ESND(cirGr));
   }
   else
   {
      if ( (pCirGrActFunc = siCirGrFsm[cir->fsmEvnt][cirGr->state]) == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "siCirGrFsm[fsmEvt:%#x][cirGr->state:%#x] is invalid\n",
                cir->fsmEvnt, cirGr->state));  
#if (ERRCLASS & ERRCLS_DEBUG) 
         SILOGERROR(ERRCLS_DEBUG, ESI526, (ErrVal) 0, 
                    "siProcCirGrMsg() Failed, unknown state & event action");
#endif
         RETVALUE(RFAILED);
      }

      if ((*pCirGrActFunc)(cirGr) == RFAILED)
      {  
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "action function returned failure.\n"));  

         RETVALUE(RFAILED);
      } 
   }
   RETVALUE(ROK); 
} 


/*
*
*       Fun:   siValidateRangStat
*
*       Desc:  Validate RangeStat Information Element for circuit group
*              procedures
*              
*       Ret:   
*
*       Notes: 
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siValidateRangStat
(
SiRangStat *rangStat,
Swtch      swtch,
U8         cgFsmEvt,
U16         cirFlg
)
#else
PRIVATE S16 siValidateRangStat (rangStat, swtch, cgFsmEvt, cirFlg)
SiRangStat *rangStat;
Swtch      swtch;
U8         cgFsmEvt;
U16         cirFlg;
#endif
{
   U8 numOct;
   /* si013.220, Change: Modified maxCir from U8 to U16, and 
                         added other variables */
   U16 maxCir;
   U8 mask;
   U8 i; 
   U8 j;
   U8 bitSet = 0;

   TRC3(siValidateRangStat)

   if ( (rangStat->eh.pres == NOTPRSNT)  ||
        (rangStat->range.pres == NOTPRSNT)
      )
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
         "Range . pres == NOTPRSNT therefore event dumped\n"));  
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI527, (ErrVal )0,
              "Range in rangeStat not present !");
#endif
      RETVALUE(RFAILED);
   }

   /* validate range values */
   switch (cgFsmEvt)
   {
      case CGEI_CGQRYREQ:
      case CGEI_CGQRY:
      case CGEI_CGQRYRSP:
            maxCir = MAX_CIR_QUER;
      break;

/* si033.220: Addition - Patch for discarding the GRS messages if maximum circuit
   is greater than 32 
*/   
#if (SS7_ITU || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
      case CGEI_GRSREQ: 
      case CGEI_GRSACK: 
      case CGEI_GRS: 
      case CGEI_GRSRSP:
         if ((swtch == LSI_SW_ITU97) || 
             (swtch == LSI_SW_ITU2000) || 
             (swtch == LSI_SW_RUSS2000) || 
             (swtch == LSI_SW_ITU))
                maxCir = MAX_CIR_GRS; 
#endif /* End of SS7_ITU || SS7_ITU97 */

      default:
      /* si034.220: Modification - added CHINA switch */
      /* si029.220: Modification - added INDIA switch */
      /* si028.220: Modification - change some OR operators to AND */
      /* si014.220, Modified: Changed error brought up by si013.220 */
      /* si013.220, Addition: For ITU and ETSI variants, made the 
                              maximum range as 256 for group block and 
                              group unblocking messages */
      {
         if (((swtch == LSI_SW_ITU) || (swtch == LSI_SW_ITU97) ||
              (swtch == LSI_SW_ETSI) || (swtch == LSI_SW_ETSIV3) ||
              (swtch == LSI_SW_ITU2000) || (swtch == LSI_SW_RUSS2000) ||
              (swtch == LSI_SW_INDIA) || (swtch == LSI_SW_CHINA)) &&
              ((cgFsmEvt != CGEI_GRSREQ) && (cgFsmEvt != CGEI_GRSACK) && 
               (cgFsmEvt != CGEI_GRS) && (cgFsmEvt != CGEI_GRSRSP)))
            maxCir = MAX_CIR_BLK_ITU;
         else
            maxCir = MAX_CIR_BLK;
      }
      break;
   } 

   /* can not exceed the max. number of circuits allowed */
   if (rangStat->range.val >= maxCir)
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
         "range.val %d >= maxCir %d therefore event dumped\n",
              rangStat->range.val, maxCir));  
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI528, (ErrVal )rangStat->range.val,
            "siValidateRangStat(): Range exceeds the maximum allowed value.");
#endif
      RETVALUE(RFAILED);
   }

   if (rangStat->range.val == 0)
   {
      if ((cgFsmEvt != CGEI_CGQRYREQ) && (cgFsmEvt != CGEI_CGQRY) && 
          (cgFsmEvt != CGEI_CGQRYRSP))
      {

         /* failure for anything other than ANSI92, ANSI95 and Bellcore */
         if ((swtch != LSI_SW_ANS92) && (swtch != LSI_SW_ANS95) && 
             (swtch != LSI_SW_BELL))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "Range value is 0 and protocol variant does not allow it \n")); 
#if (ERRCLASS & ERRCLS_DEBUG)
            SILOGERROR(ERRCLS_DEBUG, ESI529, (ErrVal )0,
                "Range value is 0 and protocol variant does not allow it");
#endif
            RETVALUE(RFAILED);
         }
         else
         {
            if ((cgFsmEvt == CGEI_GRS) || (cgFsmEvt == CGEI_GRSREQ)
                || (cgFsmEvt == CGEI_GRSRSP) || (cgFsmEvt == CGEI_GRSACK))
              RETVALUE(ROK);
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * If this function is called by the receipt of CGB, CGB Req, CBG Rsp, CGBA, 
 * CGU, CGU Req, CBU Rsp, or CGUA with range value of 0, return ROK
 */
         if ((cgFsmEvt == CGEI_CGB) || (cgFsmEvt == CGEI_CGBREQ) ||
             (cgFsmEvt == CGEI_CGBRSP) || (cgFsmEvt == CGEI_CGBACK) ||
             (cgFsmEvt == CGEI_CGU) || (cgFsmEvt == CGEI_CGUREQ) ||
             (cgFsmEvt == CGEI_CGURSP) || (cgFsmEvt == CGEI_CGUACK))
            RETVALUE(ROK);
#endif
         }

      }
   }

   /* si013.220, Change: Modified code to check if range value is
                         is 255 */
   numOct = (U8)((rangStat->range.val + 1) >> 3) + 
                (U8)(((rangStat->range.val + 1) & 0x07) ? 1 : 0);

   switch (cgFsmEvt)
   {
      /* don't have to validate status token */
      case CGEI_GRSREQ:
      case CGEI_GRS:
         
      case CGEI_CGQRYREQ:
      case CGEI_CGQRY:
      case CGEI_CGQRYRSP:
         break;

      default:
         /* validate the consistency between range and length of status */
         if ((rangStat->status.pres == NOTPRSNT) ||
             (numOct != rangStat->status.len))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "either status absent [%d] or len [%d] is not expected [%d]\n",
                rangStat->status.pres, rangStat->status.len, numOct));
              
#if (ERRCLASS & ERRCLS_DEBUG)
            SILOGERROR(ERRCLS_DEBUG, ESI530, (ErrVal )rangStat->status.pres,
              "Either Status not present [presentflg] or \
              length does not match with range");
#endif
            RETVALUE(RFAILED);
         }
   }
   /* si034.220: Addition - added CHINA switch */
   /* si029.220: Addition - added INDIA switch */
   /* si013.220, Addition: Added code to make sure that the number of status 
                           bit set in does not exceed 32 for ITU or ETSI */
   if ((swtch == LSI_SW_ITU) || (swtch == LSI_SW_ITU97) ||
       (swtch == LSI_SW_ITU2000) || (swtch == LSI_SW_RUSS2000) ||
       (swtch == LSI_SW_ETSI) || (swtch == LSI_SW_ETSIV3) ||
       (swtch == LSI_SW_INDIA) || (swtch == LSI_SW_CHINA))
   {
      switch (cgFsmEvt)
      {
         case CGEI_CGB:
         case CGEI_CGBRSP:
         case CGEI_CGBREQ:
         case CGEI_CGBACK:
         case CGEI_CGU:
         case CGEI_CGURSP:
         case CGEI_CGUREQ:
         case CGEI_CGUACK:
            for (i = 0; i < rangStat->status.len; i++)
            {
               /* for each bit in octet */
               for (j = 0, mask = 1; j < 8; j++)
               {
                  if (rangStat->status.val[i] & mask)
                     bitSet++;
                  mask = mask << 1;
               }
            }
            if (bitSet > MAX_CIR_BLK)
            {
#if ERRCLASS & ERRCLS_DEBUG
               SILOGERROR(ERRCLS_DEBUG, ESI528, (ErrVal) bitSet,
                  "siValidateRangStat() : number of bit set exceeds maximum value");
#endif
               RETVALUE(RFAILED);
            }
            break;
         default:
            break;
      }
   }
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCmpStatus
*
*       Desc:  compare two status fields
*              
*       Ret:   
*      SISUBSET - <range1, status1> is a subset of <range2, status2> 
*      SISUPSET - <range1, status1> is a superset of <range2, status2> 
*      SIEQLSET - <range1, status1> = <range2, status2> 
*      SIDISJNT - <range1, status1> intersection <range2, status2>is NULL
*      SIINTSECT - <range1, status1> intersect <range2, status2> is not NULL
*      returns intersection in intsect argument
*      returns additional values present in the second field in diff
*
*       Notes: implements set operations on status fields
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCmpStatus
(
U8 r1,
U8 *s1,
U8 r2,
U8 *s2,
U8 *intsect,
U8 *diff
)
#else
PRIVATE S16 siCmpStatus(r1, s1, r2, s2, intsect, diff)
U8 r1;
U8 *s1;
U8 r2;
U8 *s2;
U8 *intsect;
U8 *diff;
#endif
{
   Bool first;
   Bool present;
   Bool foundIntSect;
   U8   *s;
   S16  ret;
   S16  newret;
   U8   numOct;
   U8   range;
   U16  outer;
   Bool equalFlag;
   U8   result;          /* bit wise flag to indicate the type of two sets */

   TRC3(siCmpStatus)

   /* find the smaller range to be used */
   first = FALSE;
   if (r1 >= r2)
   {
      range = r2;
      first = TRUE;
   }
   else 
      range = r1; 

   /* find the significant number of octets */
   /* si013.220, Change: Modified code to check if range value is
                         is 255 */
   numOct = (U8)((range + 1) >> 3) + 
                (U8)(((range + 1) & 0x07) ? 1 : 0);

   /* check for intersection and equality in significant # of octets */
   foundIntSect = FALSE;
   ret          = SIEQLSET;
   equalFlag = TRUE;
   result = 0x00;

   for (outer = 0; outer < numOct; outer++)
   {
      if (s1[outer] == s2[outer])
      {
         result |= SI_EQLSET_FLG;
         if (intsect != NULLP)
            intsect[outer] = s1[outer];
      }
      else
      {
         if (equalFlag == TRUE)
            equalFlag = FALSE;
         if (intsect != NULLP)
            intsect[outer] = (s1[outer] & s2[outer]);
       
         /* if one of two sets are all 0's, should consider as subset or 
          * supperset
          */
         if ((s1[outer] & s2[outer]) || (s1[outer] == 0x00) || 
             (s2[outer] == 0x00))
         {
            foundIntSect = TRUE;
            ret          = SIINTSECT;
         }
         if (diff != NULLP)
            diff[outer] = ~s1[outer] & s2[outer];
      }
   }

   /* check if we have non-zero elements in status beyond significant # 
    * of octets - this is used for checking supersetness */
   if (first)
   {
      newret = (r1 >> 3) + ((r1 % 8) ? 1 : 0);
      s = s1;
   }
   else
   {
      newret = (r2 >> 3) + ((r2 % 8) ? 1 : 0);
      s = s2;
   }

   present = FALSE;
   for (outer = numOct; outer < (U16)newret; outer++)
   {
      if (s[outer] != 0x00)
         present = TRUE;
      /* if second set has a larger range add the addl. elements to this */
      if (!first)
         if (diff != NULLP)
            diff[outer] = s[outer];
   }

   /* return if they are equal */
   if ((equalFlag == TRUE) & !present)
   {  
      result |= SI_EQLSET_FLG;
   }
   if (!equalFlag && !foundIntSect)
   {
      result |= SI_DISJNT_FLG;
   }

   /* check for subset/superset if intersection exists */
   if (foundIntSect)
   {
      ret    = SISUPSET;
      newret = SISUPSET;
      /* check for subset/superset in significant # of octets */
      for (outer = 0; outer < numOct; outer++)
      {
         /* s2 has more status fields present */
         if (s1[outer] < s2[outer])
         {
            /* found an octet for which s2 is a superset */
            newret = SISUBSET;
            /* fields of s2 do not exactly match with s1 */
            if ((s1[outer] & s2[outer]) != s1[outer])
               result |= SI_INTSET_FLG;
         }
         else 
         {
            /* we have found an octet for which s2 is a superset or 
               some fields of s1 and s2 are disjoint */
            if ((ret != newret) ||
                ((s1[outer] & s2[outer]) != s2[outer]))
               result |= SI_INTSET_FLG;
         }
      }
      /* first one is superset for significant # of octets */                
      if (newret == SISUPSET)
      {
         /* second one has a larger range  */
         if (!first)
         {
            /* and has fields present beyond the significant # of octets */
            if (present) 
               result |= SI_INTSET_FLG;
         }
         result |= SI_SUPSET_FLG;
      }
      else if (newret == SISUBSET) 
      {
         /* first one has larger range */
         if (first)
         {
            /* and has fields present beyond the significant # of octets */
            if (present)
               result |= SI_INTSET_FLG;
         }   
         result |= SI_SUBSET_FLG;
      }
   }

   switch (result)
   {
      case SI_SUPSET_FLG:
         SIDBGP(SIDBGMASK_PROG,(siCb.init.prntBuf,
                  "returning SISUPSET\n"));  
         RETVALUE(SISUPSET);
      case SI_SUBSET_FLG:
         SIDBGP(SIDBGMASK_PROG,(siCb.init.prntBuf,
                  "returning SISUBSET\n"));  
         RETVALUE(SISUBSET);
      case SI_EQLSET_FLG:
         SIDBGP(SIDBGMASK_PROG,(siCb.init.prntBuf,
                  "returning SIEQLSET\n"));  
         RETVALUE(SIEQLSET);
      case SI_DISJNT_FLG:
         SIDBGP(SIDBGMASK_PROG,(siCb.init.prntBuf,
                  "returning SIDISJNT\n"));  
         RETVALUE(SIDISJNT);
      default:
         /* others consider as interset */
         SIDBGP(SIDBGMASK_PROG,(siCb.init.prntBuf,
                  "returning SIINTSECT\n"));  
         RETVALUE(SIINTSECT);
   }
}
  
/*
*
*       Fun:   siGenCirEvt
*
*       Desc:  Generate circuit status event to upper layer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 siGenCirEvt
(
SiCirCb *cir,
U8      evtType
)
#else
PUBLIC S16 siGenCirEvt(cir, evtType)
SiCirCb *cir;
U8      evtType;
#endif
{
   SiUpSAPCb *cb;
   Bool      rmtFlag;
 
   TRC2(siGenCirEvt);
 
#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* get pointer to the upper control block */
   cb      = siGetUprCbPtr(cir);

   /* check if the SAP is available and bound */
   if (cb && (cb->state == SI_BND))
   {
      /* consider locally reset */
      rmtFlag = ((evtType == SIT_STA_CIRLOCRES) ? FALSE : TRUE);

      /* send status indication to the upper layer */
      SiUiSitStaInd(&cb->pst, cb->suId, 0, 0, cir->cfg.cirId, rmtFlag, 
                    evtType, NULLP, NULLP);
      RETVALUE(ROK);
   }

#if ERRCLASS & ERRCLS_DEBUG
   SILOGERROR(ERRCLS_DEBUG, ESI531, (ErrVal) cir->pIntfCb->cfg.swtch,
              "siGenCirEvt() : wrong upper SAP");
#endif
   RETVALUE(RFAILED);

} /* end of siGenCirEvt */

  
/*
*
*       Fun:   siGenCirMsg
*
*       Desc:  Generate Circuit Message 
*
*       Ret:   ROK      - ok
*
*       Notes: cause pointer has to be a non-null pointer pointing to a valid
*              cause if RLC has to be sent
*
*       File:  ci_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenCirMsg
(
Cic     cic,
Dpc     opc,
SiInstId intfId,
Dpc     phyDpc,     /* physical destination point code */
U8      intfflg,    /* interface valid flg */
Swtch   swtch,
U8      msgType,        /* message type                             */
U8      msgIdx,         /* message index                            */
U8      *cause,        /* additional parameter value if necessary  */
U8      ssf,            /* subservice information                   */
SiInstId nwId
)
#else
PUBLIC S16 siGenCirMsg(cic, opc, intfId, phyDpc, intfflg, swtch, msgType, 
                       msgIdx, cause, ssf, nwId)
Cic     cic;
Dpc     opc;
SiInstId    intfId;
Dpc     phyDpc;     /* physical destination point code */
U8      intfflg;    /* interface valid flg */
Swtch   swtch;
U8      msgType;
U8      msgIdx;
U8      *cause;
U8      ssf;      /* subservice information                    */
SiInstId    nwId;
#endif
{
   SiPduHdr  pduHdr;
   SiAllPdus allPdus;
   SiCirKey  key;
   SiNSAPCb  *cb;
   SiCirCb   *cir;
   LnkSel    lnkSel;
   S16       ret;

   TRC2(siGenCirMsg);

   /* get pointer to the lower control block */
   cb = siGetMCbPtr(nwId, ssf);

   /* Generate Message */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = msgType;

   /* initialize PDU structure for these messages */
   if ((msgType == M_USRPARTT) || (msgType == M_USRPARTA))
   {
      MFINITPDU(&cb->mfMsgCtl, ret, (U8) 0, (U8) msgIdx,
                (ElmtHdr *) NULLP, (ElmtHdr *) &allPdus, (U8) NOTPRSNT,
                LSI_SW_ITU, (U32) MF_ISUP);
   }

   /* initialize cause if RLC */
   if (msgType == M_RELCOMP)
   {
      switch (swtch)
      {






#ifdef SS7_ITU97
         case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
        case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
        case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         case LSI_SW_ITU:
            /* init pdu */
            MFINITPDU(&cb->mfMsgCtl, ret, (U8) 0, (U8) MI_RELCOMP, NULLP, 
                      (ElmtHdr *) &allPdus.m.relComplete, (U8) PRSNT_DEF, 
                      swtch, (U32) MF_ISUP);
   
            /* init cause */
            MFINITELMT(&cb->mfMsgCtl, ret, (ElmtHdr *) NULLP,
                       (ElmtHdr *) &allPdus.m.relComplete.causeDgn, 
                        &meCauseIndV, (U8) PRSNT_DEF, swtch, (U32) MF_ISUP);

            allPdus.m.relComplete.causeDgn.eh.pres       = PRSNT_NODEF;
            allPdus.m.relComplete.causeDgn.causeVal.pres = PRSNT_NODEF;
            allPdus.m.relComplete.causeDgn.causeVal.val  = *cause;
            allPdus.m.relComplete.causeDgn.recommend.pres = NOTPRSNT;
            break;

#if (ERRCLASS & ERRCLS_INT_PAR)
         default:
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid swtch %d\n", swtch));  
            SILOGERROR(ERRCLS_INT_PAR, ESI532, (ErrVal) 0, 
                 "siProcCirEvt() Failed:  unrecognised switch");
            RETVALUE(RFAILED);        
#endif
      }
   }

   /* get link selection value */
   /* si025.220 - Modification - modify arguments in siGetLnkSel */
   /* si009.220 - Modified: to pass cic into siGetLnkSel. */
   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
   key.k2.cic = cic;
   key.k2.intfId = intfId;
   siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);

   if (cir == (SiCirCb *) NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "can not find circuit control block. cic=%x, intfId=%lx\n",
             cic, intfId));

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIC, (PTR) &cic,
                    LSI_USTA_DGNVAL_INTF, (PTR) &intfId,
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERNAL,
                     LCM_EVENT_INV_EVT, LSI_CAUSE_INV_CIRCUIT, FALSE,
                     cic, SI_ALRM_CIR_UNEQUPD);
/* si044.220 Modified: To send the UCIC for invalid circuit */
      /*   RETVALUE(RFAILED);*/
   }
   siGetLnkSelIntf(cb, &lnkSel, swtch, cic,intfId);
/* si044.220 END Modified: To send the UCIC for invalid circuit */

   if ((msgType != M_RELCOMP) && (msgType != M_UNEQUIPCIC))
   {
      /* si025.220: Deletion - deleted find circuit code as it is
       * done above */

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      if (cir->ctrlMultiRateCir != NULLP)
      {
         /* the circuit involved in a non-single rate call, get
          * link selection value from the controlling circuit
          * conn cb
          */
         if (cir->ctrlMultiRateCir->siCon)
         {
            if ((cir->ctrlMultiRateCir->siCon->incC.conPrcs) || 
                (cir->ctrlMultiRateCir->siCon->outC.conPrcs))
               lnkSel = cir->ctrlMultiRateCir->siCon->lnkSel;
         }
      }
      else
#endif
      {              
         if (cir->siCon)
         {
            if ((cir->siCon->incC.conPrcs) || (cir->siCon->outC.conPrcs))
               lnkSel = cir->siCon->lnkSel;
         }
      }         
   }     

    if (siGenPdu(cb, &pduHdr, &allPdus, swtch, opc, intfId, phyDpc, 
                  intfflg, cic, lnkSel, siGetPriority(msgType, swtch),
                     NULLP) == RFAILED)
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siGenPdu failed\n"));  
      RETVALUE(RFAILED);
   } 
      
   RETVALUE(ROK);
} /* end of siGenCirMsg */


/*
*
*       Fun:   siGenCirGrMsg
*
*       Desc:  generate a circuit group message from sduSp status event
*              
*       Ret:   ROK - ok; RFAILED - failed
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 siGenCirGrMsg
(
SiCirGrp *cirgr, 
U8       msgType, 
U8       msgIdx
)
#else
PUBLIC S16 siGenCirGrMsg(cirgr, msgType, msgIdx)
SiCirGrp *cirgr;
U8       msgType;
U8       msgIdx;
#endif
{
   SiPduHdr  pduHdr;
   SiNSAPCb  *cb;
   SiAllPdus allPdus;
   LnkSel    lnkSel;
   S16       ret;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(cirgr->cir) != ROK)
      RETVALUE(RFAILED);
#endif

   TRC3(siGenCirGrMsg)

   cb  = siGetLwrMCbPtr(cirgr->cir);
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) msgType;

   MFINITPDU(&cb->mfMsgCtl, ret, (U8) SI_STAREQ, (U8) msgIdx,
             (ElmtHdr *)&cirgr->sduSp->m.siStaEvnt, (ElmtHdr *) &allPdus, 
             (U8) PRSNT_NODEF, cirgr->cir->pIntfCb->cfg.swtch, 
             (U32) MF_ISUP);
   /* si025.220 - Modification - modify arguments in siGetLnkSel */
   /* si009.220 - Modified: to pass cic into siGetLnkSel. */
   siGetLnkSel(cb, &lnkSel, cirgr->cir->pIntfCb->cfg.swtch, cirgr->cir);

   ret = siGenPdu(cb, &pduHdr, &allPdus, cirgr->cir->pIntfCb->cfg.swtch, 
                  cirgr->cir->opc, cirgr->cir->key.k2.intfId,
                  cirgr->cir->phyDpc, TRUE,
                  cirgr->cir->key.k2.cic, lnkSel, 
                  siGetPriority(msgType, cirgr->cir->pIntfCb->cfg.swtch), 
                  NULLP);


   RETVALUE(ret);
}


/*
*
*       Fun:   siGetCirState
*
*       Desc:  Obtain the call processing and blocking state of a circuit
*              coded as per circuit state indicators information element.
*              (Q.763). This function is used in processing CQM or management
*              status request
*              
*       Ret:   none.
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void siGetCirState
(
SiCirCb *cir, 
U8      *state
)
#else
PUBLIC Void siGetCirState (cir, state)
SiCirCb *cir;
U8      *state;
#endif
{
   TRC3(siGetCirState) 

   if (cir == NULLP)
   {
      *state = CIRUNEQP; /* unequipped */
   }
   else if ((cir->transStat[SICIR_MTLOCST] == SICIR_ST_UNEQPD) &&
            (cir->transStat[SICIR_HWLOCST] == SICIR_ST_UNEQPD))
   {
      *state = CIRUNEQP; /* unequipped */
   }
   else
   {
      *state = cir->calProcStat;
/* si003.220 - Addition. Added code so that the function will not return
 * idle state after remote state is set into unequipped. Also check call
 * processing trianscient state. If it is transient, return the state because
 * transient state does not overlap with the other states.
 */
      /* si009.220, MODIFIED: change the code to proper report the call 
       * transient state. In some cases, the calProcStat is not reflected
       * the correct the state
       */
      switch (*state)
      {
         case TRANS:
            RETVOID;

         case OUTBUSY:
         {
            /* need to check the conState in the connection cb to determine
             * if the connection is in the transient state
             * According to ANSI T1.113 (1992) section 2.8.2A.2 and ITU
             * Q764 (1993) section 2.8.3.2, the transient call processing
             * state should only refer to outgoing calls.
             */
            U8 conState;

            conState = ST_IDLE;
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
            /* check if this is a non-single rate call. If so, find the 
             * connection block in the controlling circuit
             */
            if (cir->ctrlMultiRateCir != NULLP)
            {
               /* it is a non-single rate call */
               if (cir->ctrlMultiRateCir->siCon)
                  if (cir->ctrlMultiRateCir->siCon->outC.conPrcs)
                     conState = cir->ctrlMultiRateCir->siCon->outC.conState;
            }
            else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
            {           
               if (cir->siCon)
                  if (cir->siCon->outC.conPrcs)
                     conState = cir->siCon->outC.conState;
            }

            switch (conState)
            {
               case ST_WTFORCONTIN:
               case ST_WTFORACM:
               case ST_WTFORRELCMP:
                  *state = TRANS;
                  RETVOID;

               default:
                  break;
            }
            break;
         }

         default:
            break;
      }      

/* si010.220: deletion - delete processing for remote unequipped */
      if (cir->pIntfCb == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "Interface blk on ckt %#lx is missing.\n", 
                 cir->key.k1.cirId));  
         RETVOID;
      }
 
      switch (cir->pIntfCb->cfg.swtch)
      {
#ifdef SS7_ITU97
         case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
        case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
        case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         case LSI_SW_ITU:
/* si010.220: addition - add processing for remote unequipped */
            if ((cir->transStat[SICIR_MTREMST] == SICIR_ST_UNEQPD) &&
                (cir->transStat[SICIR_HWREMST] == SICIR_ST_UNEQPD))
            {
               *state |= MRMTBLKED;
               *state |= HRMTBLKED;
            }
            if ((cir->transStat[SICIR_HWLOCST] == SICIR_ST_LOCBLKED) ||
                (cir->transStat[SICIR_HWLOCST] == SICIR_ST_WTBLKACK))
            {
               *state |= HLOCBLKED;
            }
            if ((cir->transStat[SICIR_HWREMST] == SICIR_ST_REMBLKED) ||
                (cir->transStat[SICIR_HWREMST] == SICIR_ST_WTBLKRSP))
            {
               *state |= HRMTBLKED;
            } 

            if ((cir->transStat[SICIR_MTLOCST] == SICIR_ST_LOCBLKED) ||
                  (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTBLKACK))
            {
               *state |= MLOCBLKED;
            }
            if ((cir->transStat[SICIR_MTREMST] == SICIR_ST_REMBLKED) ||
                  (cir->transStat[SICIR_MTREMST] == SICIR_ST_WTBLKRSP))
            {
               *state |= MRMTBLKED;
            }

            /* si009.220: ADDED: mark the circuit state as transient when 
             * cicuit ss in waiting for reset ack or in waiting for 
             * (group) (un)blocking ack.
             */
            if (((cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK) ||
                 (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTUBLACK) ||
                 (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTBLKACK)) &&
                (cir->pIntfCb->cfg.swtch != LSI_SW_FTZ))  
            {
               *state = TRANS;
            }
            break;
      } /* end switch */
   } /* end else */

   RETVOID;
} /* siGetCirState */


/*
*
*       Fun:   siCirRETFAIL
*
*       Desc:  dummy function for returning failure for circuit events
*              
*       Ret:   RFAILED - failed
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRETFAIL
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRETFAIL(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRETFAIL)
   UNUSED(cir);

   SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "siCirRETFAIL called !\n"));  
   RETVALUE(RFAILED);
}


/*
*
*       Fun:   siCirRETOK
*
*       Desc:  dummy function for returning OK for circuit events
*              
*       Ret:   ROK - ok
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRETOK
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRETOK(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRETOK)
   UNUSED(cir);

   RETVALUE(ROK);
}

 /*
 *
*       Fun:   siCirRemEXXS00Nmsg
*
*       Desc:  Action function for processing any kind of message  
*              for unequipped circuits (does not send UCIC)
*
*       Ret:   
*              ROK     - ok 
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemEXXS00Nmsg
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemEXXS00Nmsg(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemEXXS00Nmsg)
   SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
        "circuit unequipped : siCirRemEXXS00Nmsg\n"));  

   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                 LSI_USTA_DGNVAL_EVENT, (PTR) &cir->fsmEvnt, 
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                  LCM_EVENT_UI_INV_EVT, LSI_CAUSE_UNEQP_CIR, TRUE, 
                  cir->cfg.cirId, SI_CIR_UNEQPD);
   /* si013.220, Addition: Added code to mark remote maintenance state as wait-
                           ing for blocking response, and remote hardware state
                           as idle. Also, a blocking indication is sent to 
                           upper layer */
   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_WTBLKRSP);
   SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_IDLE);
   siGenCirEvt(cir, SIT_STA_CIRBLOIND);
   RETVALUE(ROK); 
} /* end of siCirRemEXXS00Nmsg */
/* si013.220, Addition: Added functions when different messages are 
                        receieved in unequipped state */

/*
*
*       Fun:   siCirRemE12S00Nmsg
*
*       Desc:  Action function for processing unblock message  
*              for unequipped circuits (does not send UCIC)
*
*       Ret:   
*              ROK     - ok 
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE12S00Nmsg
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE12S00Nmsg(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE12S00Nmsg)
   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
        "circuit unequipped : siCirRemE12S00Nmsg\n"));  

   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_WTUBLRSP);
   SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_IDLE);
   siGenCirEvt(cir, SIT_STA_CIRUBLIND);
   RETVALUE(ROK); 
} /* end of siCirRemE12S00Nmsg */

/*
*
*       Fun:   siCirRemE16S00Nmsg
*
*       Desc:  Action function for processing any CGB
*              for unequipped circuits (does not send UCIC)
*
*       Ret:   
*              ROK     - ok 
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE16S00Nmsg
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE16S00Nmsg(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE16S00Nmsg)
   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
        "circuit unequipped : siCirRemE16S00Nmsg\n"));  

   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                 LSI_USTA_DGNVAL_EVENT, (PTR) &cir->fsmEvnt, 
                 LSI_USTA_DGNVAL_NONE,  NULLP, 
                 LSI_USTA_DGNVAL_NONE,  NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                  LCM_EVENT_UI_INV_EVT, LSI_CAUSE_UNEQP_CIR, TRUE, 
                  cir->cfg.cirId, SI_CIR_UNEQPD);
   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_WTBLKRSP);
   SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_IDLE);
   RETVALUE(ROK); 
} /* end of siCirRemE16S00Nmsg */
/*
*
*       Fun:   siCirRemE18S00Nmsg
*
*       Desc:  Action function for processing CGU
*              for unequipped circuits (does not send UCIC)
*
*       Ret:   
*              ROK     - ok 
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE18S00Nmsg
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE18S00Nmsg(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE18S00Nmsg)
   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
        "circuit unequipped : siCirRemE18S00Nmsg\n"));  

   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_WTUBLRSP);
   SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_IDLE);
   RETVALUE(ROK); 
} /* end of siCirRemE18S00Nmsg */
/*
*
*       Fun:   siCirRemE1AS00Nmsg
*
*       Desc:  Action function for processing CGB
*              for unequipped circuits (does not send UCIC)
*
*       Ret:   
*              ROK     - ok 
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE1AS00Nmsg
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE1AS00Nmsg(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE1AS00Nmsg)
   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
        "circuit unequipped : siCirRemE1AS00Nmsg\n"));  

   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                 LSI_USTA_DGNVAL_EVENT, (PTR) &cir->fsmEvnt, 
                 LSI_USTA_DGNVAL_NONE,  NULLP, 
                 LSI_USTA_DGNVAL_NONE,  NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                  LCM_EVENT_UI_INV_EVT, LSI_CAUSE_UNEQP_CIR, TRUE, 
                  cir->cfg.cirId, SI_CIR_UNEQPD);
   /* si070218 : Addition of 3 lines */
   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_IDLE);
   SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_WTBLKRSP);
   RETVALUE(ROK); 
} /* end of siCirRemE1AS00Nmsg */
/*
*
*       Fun:   siCirRemE1CS00Nmsg
*
*       Desc:  Action function for processing CGU
*              for unequipped circuits (does not send UCIC)
*
*       Ret:   
*              ROK     - ok 
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE1CS00Nmsg
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE1CS00Nmsg(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE1CS00Nmsg)
   SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
        "circuit unequipped : siCirRemE1CS00Nmsg\n"));  

   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_IDLE);
   SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_WTUBLRSP);
   RETVALUE(ROK); 
} /* end of siCirRemE1CS00Nmsg */

/*
*
*       Fun:   siCirLocEXXS00
*
*       Desc:  Action function for processing any kind of blocking/unblocking
*              request for unequipped circuits
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocEXXS00
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocEXXS00(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocEXXS00)
   SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
        "circuit unequipped : siCirLocEXXS00\n"));  

   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                 LSI_USTA_DGNVAL_EVENT, (PTR) &cir->fsmEvnt, 
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                  LCM_EVENT_UI_INV_EVT, LSI_CAUSE_UNEQP_CIR, TRUE, 
                  cir->cfg.cirId, SI_CIR_UNEQPD);
   siGenCirEvt(cir, SIT_STA_CIRUNEQPD);
   RETVALUE(ROK); 
} 


/*
*
*       Fun:   siCirRemEXXS00
*
*       Desc:  Action function for processing any kind of blocking/unblocking
*              ack for unequipped circuits
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemEXXS00
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemEXXS00(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemEXXS00)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "circuit unequipped\n"));  
   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                 LSI_USTA_DGNVAL_EVENT, (PTR) &cir->fsmEvnt, 
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                  LCM_EVENT_LI_INV_EVT, 
                  LSI_CAUSE_UNEQP_CIR, TRUE, cir->cfg.cirId, SI_CIR_UNEQPD);
   {
      siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                  cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch,
               M_UNEQUIPCIC, MI_UNEQUIPCIC, NULLP, cir->pIntfCb->cfg.ssf, 
               cir->pIntfCb->cfg.nwId);
   }
   RETVALUE(ROK); 
}


/*
*
*       Fun:   siCirLocE00SND
*
*       Desc:  Action function for handling block request when circuit is 
*              idle/waiting for BLA/waiting for UBA
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE00SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE00SND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE00SND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                 LSI_USTA_DGNVAL_EVENT, (PTR) &cir->fsmEvnt, 
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, LSI_EVENT_LOCAL, 
                  LSI_CAUSE_BLOCK, TRUE, cir->key.k1.cirId, SI_CIR_BLOCK);

   if (siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                   cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch,
                   M_BLOCK, MI_BLOCK, NULLP, cir->pIntfCb->cfg.ssf, 
                   cir->pIntfCb->cfg.nwId) 
                   == ROK)
   {
      /* stop all circuit timers if circuit not idle */
      if (cir->transStat[SICIR_MTLOCST] != SICIR_ST_IDLE)
         siStopAllCirTmr(cir);
      /* start Blocking Timer */
      siStartCirTmr(TMR_T12, cir);
      /* start initial Blocking Timer */
      siStartCirTmr(TMR_T13, cir);

      /* change state to waiting for BLA */
      SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_WTBLKACK);
      /* This flag is reset to take care of the race condition between
         internally generated UBL and block request from CC. 
         . unexpected BLA is received on an idle circuit
         . ISUP sends UBL to keep peer in sync and mark this flag SET
           so that CC remains transparent to it.
         . CC in the mean time sends a block request .
         . Now to give conf to CC for this new procedure this flag
           should be RESET.
      */
      cir->noRspFlgToUp = FALSE;

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if this is a non-single rate call. If so, find the connection
       * block in the controlling circuit and jump into call processing matrix 
       */
      if (cir->ctrlMultiRateCir != NULLP)
      {
         /* it is a non-single rate call */
         if ((siJumpMRatefrmCirMsg(cir->ctrlMultiRateCir, IEI_BLKREQ, 
                                  cir->fsmEvnt, NOTPRSNT)) != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "Processing connection on controlling ckt(%#lx) failed \
                   in bloreq\n", cir->ctrlMultiRateCir->cfg.cirId));  
            RETVALUE(RFAILED);
         }
      }
      else
#endif
      {
         /* jump into call processing matrix if a call exists on the circuit */
         if (cir->siCon)
            siActDat(cir->key.k1.cirId, cir->siCon, IEI_BLKREQ);
      }

      RETVALUE(ROK);
   } 
   else
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siGenCirMsg returns failure\n")); 
/* si003.220 : Addition. Add circuit block request error counter in circuit
 * statistics.
 */
#if (SI_LMINT3 || SMSI_LMINT3)
      siUpdErrSts(cir, LSI_STS_BLOREQ);
#endif  
   } 
      
   RETVALUE(RFAILED);
}


/*
*
*       Fun:   siCirLocE00S05
*
*       Desc:  Action function for handling BLOREQ when circuit is
*              waiting for reset ack
*
*       Ret:
*              ROK     - ok
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE00S05
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE00S05(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE00S05)

   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId,
                 LSI_USTA_DGNVAL_EVENT, (PTR) &cir->fsmEvnt,
                 LSI_USTA_DGNVAL_NONE, NULLP,
                 LSI_USTA_DGNVAL_NONE, NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, LCM_EVENT_INV_STATE,
                  LSI_CAUSE_CIR_MNTREQ, FALSE,
                  cir->key.k1.cirId, SI_CIR_INVMSG);
/* si003.220 : Addition. Add circuit block request error counter in circuit
 * statistics.
 */
#if (SI_LMINT3 || SMSI_LMINT3)
      siUpdErrSts(cir, LSI_STS_BLOREQ);
#endif 
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirLocE01S01
*
*       Desc:  Action function for handling BLA when circuit is idle
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE01S01
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE01S01(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE01S01)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & cir->key.k1.cirId,
                 LSI_USTA_DGNVAL_EVENT, (PTR) & cir->fsmEvnt,
                 LSI_USTA_DGNVAL_NONE, NULLP,
                 LSI_USTA_DGNVAL_NONE, NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL,
                  LCM_EVENT_INV_STATE, LSI_CAUSE_CIR_MNTACK, TRUE,
                  cir->key.k1.cirId, SI_CIR_INVMSG);

   if (siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                   cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch,
                   M_UNBLK, MI_UNBLK, NULLP, cir->pIntfCb->cfg.ssf, 
                   cir->pIntfCb->cfg.nwId) == ROK)
   {
      /* start unblocking timer */
      siStartCirTmr(TMR_T14, cir);
      /* start initial unblocking timer */
      siStartCirTmr(TMR_T15, cir);

      SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_WTUBLACK);
      cir->noRspFlgToUp             = TRUE;

      RETVALUE(ROK);
   } 
#ifdef DEBUGP
   else 
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "siGenCirMsg() failed\n"));  
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
   siUpdErrSts(cir, LSI_STS_UNXBLA);
#endif
  
   RETVALUE(RFAILED);
}


/*
*
*       Fun:   siCirLocE01S02
*
*       Desc:  Action function for handling BLA when circuit is waiting for
*              BLA
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE01S02
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE01S02(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE01S02)

   siStopCirTmr(cir, TMR_T13);
   if (siStopCirTmr(cir, TMR_T12) != ROK)
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf, 
             "t12 not running at BLA rx\n"));  
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & cir->key.k1.cirId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, LSI_EVENT_REMOTE,
                     LSI_CAUSE_T12_INACTIVE, FALSE, 
                     cir->key.k1.cirId, SI_CIR_TMREXP);
   } 

   /* change state */
   SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_LOCBLKED); 

   if (cir->noRspFlgToUp == FALSE)
      siGenCirEvt(cir, SIT_STA_CIRBLOCFM);
   else
      cir->noRspFlgToUp = FALSE;

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
   ziUpdPeer();
#endif

   RETVALUE(ROK);   
}


/*
*
*       Fun:   siCirLocE01IGN
*
*       Desc:  Action function for handling BLA when circuit is waiting for
*              UBA/reset ack or locally blocked
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE01IGN
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE01IGN(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE01IGN)

   if (cir->transStat[SICIR_MTLOCST] != SICIR_ST_LOCBLKED)
   {
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                    LSI_USTA_DGNVAL_EVENT, (PTR) &cir->fsmEvnt, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                     LCM_EVENT_INV_STATE, 
                     LSI_CAUSE_CIR_MNTACK, TRUE, 
                     cir->key.k1.cirId, SI_CIR_INVMSG);
#if (SI_LMINT3 || SMSI_LMINT3)
      siUpdErrSts(cir, LSI_STS_UNXBLA);
#endif
   }

   RETVALUE(ROK);
}

/* si003.220 - Addition. Added code for handling BLA when circuit is
 * locally blocked.
 */
/*
*
*       Fun:   siCirLocE01S03
*
*       Desc:  Action function for handling BLA when circuit is locally 
*              blocked
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE01S03
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE01S03(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE01S03)
   siStopCirTmr(cir, TMR_T12);
   siStopCirTmr(cir, TMR_T13);
   if (cir->transStat[SICIR_MTLOCST] != SICIR_ST_LOCBLKED)
   {
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                    LSI_USTA_DGNVAL_EVENT, (PTR) &cir->fsmEvnt, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                     LCM_EVENT_INV_STATE, 
                     LSI_CAUSE_CIR_MNTACK, TRUE, 
                     cir->key.k1.cirId, SI_CIR_INVMSG);
#if (SI_LMINT3 || SMSI_LMINT3)
      siUpdErrSts(cir, LSI_STS_UNXBLA);
#endif
   }

   RETVALUE(ROK);
}



/*
*
*       Fun:   siCirLocE02S01
*
*       Desc:  Action function for handling UBLREQ when circuit is 
*              idle
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE02S01
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE02S01(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE0208S01)

   siGenCirEvt(cir, SIT_STA_CIRUBLCFM);
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirLocE02SND
*
*       Desc:  Action function for handling UBLREQ when circuit is 
*              locally blocked/waiting for BLA or UBA
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE02SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE02SND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE02SND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   if (siGenCirMsg(cir->key.k2.cic, cir->opc , cir->key.k2.intfId, 
                   cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch,
                   M_UNBLK, MI_UNBLK, NULLP, cir->pIntfCb->cfg.ssf, 
                   cir->pIntfCb->cfg.nwId) == ROK)
   {
      /* stop timers if waiting for any ACKs in the current state */
      if (cir->transStat[SICIR_MTLOCST] != SICIR_ST_LOCBLKED)
         siStopAllCirTmr(cir);
      /* start timers */
      siStartCirTmr(TMR_T14, cir);
      siStartCirTmr(TMR_T15, cir);

      /* change state */
      SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_WTUBLACK);
      /* This flag is reset to take care of the race condition between
         internally generated BLO and unblock request from CC. 
         . unexpected UBA is received on a blocked circuit
         . ISUP sends BLO to keep peer in sync and mark this flag SET
           so that CC remains transparent to it.
         . CC in the mean time sends an un-block request .
         . Now to give conf to CC for this new procedure this flag
           should be RESET.
      */
      cir->noRspFlgToUp = FALSE;
      RETVALUE(ROK);       
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siGenCirMsg returns failure\n"));  

   } 
   RETVALUE(RFAILED);
}


/*
*
*       Fun:   siCirLocE02S05
*
*       Desc:  Action function for handling UBLREQ when circuit is 
*              waiting for reset ack
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE02S05
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE02S05(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE02S05)

   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                 LSI_USTA_DGNVAL_EVENT, (PTR) &cir->fsmEvnt, 
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, LCM_EVENT_INV_STATE,
                  LSI_CAUSE_CIR_MNTREQ, FALSE, 
                  cir->key.k1.cirId, SI_CIR_INVMSG);
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirLocE03IGN
*
*       Desc:  Action function for handling UBA when circuit is
*              idle/waiting for BLA/waiting for reset ack.
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE03IGN
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE03IGN(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE03IGN)

   /* si017.220, Addition: remove timer T14 and T15. Circuit state
    * may have been idled by GGU, however T14 and T15 may still be
    * running and UBL/UBA are going to repeat again and again.
    */
   siStopCirTmr(cir, TMR_T14);
   siStopCirTmr(cir, TMR_T15);

   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & cir->key.k1.cirId, 
                 LSI_USTA_DGNVAL_EVENT, (PTR) & cir->fsmEvnt, 
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                  LCM_EVENT_INV_STATE, LSI_CAUSE_CIR_MNTACK, TRUE,
                  cir->key.k1.cirId, SI_CIR_INVMSG);
#if (SI_LMINT3 || SMSI_LMINT3)
   siUpdErrSts(cir, LSI_STS_UNXUBA);
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirLocE03S03
*
*       Desc:  Action function for handling UBA when circuit is
*              locally blocked
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE03S03
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE03S03(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE03S03)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & cir->key.k1.cirId, 
                 LSI_USTA_DGNVAL_EVENT, (PTR) & cir->fsmEvnt, 
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                  LCM_EVENT_INV_STATE, LSI_CAUSE_CIR_MNTACK, 
                  TRUE, cir->key.k1.cirId, SI_CIR_INVMSG);
   if (siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                   cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                   M_BLOCK, MI_BLOCK, NULLP, cir->pIntfCb->cfg.ssf, 
                   cir->pIntfCb->cfg.nwId) 
                   == ROK)
   {
      /* stop circuit timers */
      siStopAllCirTmr(cir);
      /* start T12 and T13 */
      siStartCirTmr(TMR_T12, cir);
      siStartCirTmr(TMR_T13, cir);
      /* don't send BLOCFM to upper layer */
      cir->noRspFlgToUp = TRUE;
      /* change state */
      SISTATECHNG(cir->transStat[SICIR_MTLOCST], SICIR_ST_WTBLKACK);
      RETVALUE(ROK);
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siGenCirMsg returns failure\n"));  

   } 
#if (SI_LMINT3 || SMSI_LMINT3)
   siUpdErrSts(cir, LSI_STS_UNXUBA);
#endif
   RETVALUE(RFAILED);
}


/*
*
*       Fun:   siCirLocE03S04
*
*       Desc:  Action function for handling UBA when circuit is
*              waiting for UBA
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE03S04
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE03S04(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE03S04)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   siStopCirTmr(cir, TMR_T15);

   if (siStopCirTmr(cir, TMR_T14) == RFAILED)
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf, 
             "t14 inactive when UBA rx\n"));

      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                    LSI_USTA_DGNVAL_EVENT, (PTR) &cir->fsmEvnt, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                     LSI_EVENT_REMOTE, LSI_CAUSE_T14_INACTIVE, TRUE, 
                     cir->key.k1.cirId, SI_CIR_TMREXP);
   } 

   SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_IDLE);
   /* On getting unblock ack from peer in case of ANSI
      the hardware status should also be made idle.
   */

   /* Notify the service user that UBA has been received */
   if (cir->noRspFlgToUp == FALSE)
      siGenCirEvt(cir, SIT_STA_CIRUBLCFM);
   else
      cir->noRspFlgToUp = FALSE;

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
   ziUpdPeer();
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirLocE04SND
*
*       Desc:  Action function for reset request
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE04SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE04SND(cir)
SiCirCb *cir;
#endif
{

   TRC3(siCirLocE04SND) 
   
#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   if (siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                   cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch,
                   M_RESCIR, MI_RESCIR, NULLP, cir->pIntfCb->cfg.ssf, 
                   cir->pIntfCb->cfg.nwId) == ROK) 
   { 
      siStopAllCirTmr(cir); 
      siStartCirTmr(TMR_T16, cir);
      siStartCirTmr(TMR_T17, cir);
      
      /* ensure consistency of h/w & mntc states if 
       * uneqpd or waiting for reset ack - action is upto layer management
       */
      if ( (cir->transStat[SICIR_MTLOCST] == SICIR_ST_UNEQPD)   ||
           (cir->transStat[SICIR_HWLOCST] == SICIR_ST_UNEQPD)   ||
           (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK) ||
           (cir->transStat[SICIR_HWLOCST] == SICIR_ST_WTRESACK))
      {
         if (cir->transStat[SICIR_MTLOCST] != cir->transStat[SICIR_HWLOCST])
         {
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                          LSI_USTA_DGNVAL_NONE, (PTR) &cir->fsmEvnt, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERNAL, 
                           LCM_EVENT_INV_STATE, LSI_CAUSE_CIC_STATE_MISMATCH, 
                           TRUE, cir->key.k1.cirId, SI_CIR_STOUTSYNC);
         }
      }
      /* If remote mntce state is blocked then clear it as subsequently 
         BLO will be sent by peer 
      */
/* si003.220 - Modified code so that if remote maintenance state is waiting
 * for block ack then also clear it.
 */
      if((cir->transStat[SICIR_MTREMST] == SICIR_ST_REMBLKED) ||
         (cir->transStat[SICIR_MTREMST] == SICIR_ST_WTBLKACK))
      {
         SISTATECHNG(cir->transStat[SICIR_MTREMST], SICIR_ST_IDLE);
      }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if this is a non-single rate call. If so, find the connection
       * block in the controlling circuit and jump into call processing 
       * matrix 
       */
      if (cir->ctrlMultiRateCir != NULLP)
      {
         /* it is a non-single rate call */
         if (cir->ctrlMultiRateCir->siCon)
         {
            /* connection is not possible in these states */
            if ((cir->transStat[SICIR_MTLOCST] == SICIR_ST_UNEQPD) ||
                (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK))
            {
               SISNDOLDLSISTAIND(&siCb.init.lmPst, cir->key.k1.cirId, 
                                 SI_CIR_STOUTSYNC);
#if (SI_LMINT3 || SMSI_LMINT3)
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId,
                             LSI_USTA_DGNVAL_NONE, (PTR) &cir->fsmEvnt,
                             LSI_USTA_DGNVAL_NONE, NULLP,
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERNAL,
                              LCM_EVENT_INV_STATE, 
                              LSI_CAUSE_CIC_STATE_MISMATCH,
                              TRUE, cir->key.k1.cirId, SI_CIR_INVCON);

#endif
            }

            /* it is a non-single rate call */
            if ((siJumpMRatefrmCirMsg(cir->ctrlMultiRateCir, IEI_CIRRES, 
                                  cir->fsmEvnt, FROM_UPR)) != ROK)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Processing connection on controlling ckt(%#lx) \
                      failed in resreq\n", 
                      cir->ctrlMultiRateCir->cfg.cirId));  
               RETVALUE(RFAILED);
            }
         }
         else
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "connection in controlling ckt(%#lx) is NULLP\n",
                      cir->cfg.cirId));  
            RETVALUE(RFAILED);
         }
      }
      else
#endif
      {              
         /* if connection exists */
         if (cir->siCon)
         {
            /* connection is not possible in these states */
            if ((cir->transStat[SICIR_MTLOCST] == SICIR_ST_UNEQPD) ||
                (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK))
            {
                SISNDOLDLSISTAIND(&siCb.init.lmPst, cir->key.k1.cirId, 
                                  SI_CIR_STOUTSYNC);
            }
            
            SISTATECHNG(cir->calProcStat, TRANS);
            /* jump to call processing state matrix */
            /* NOTE : this should not affect circuit management */ 
            cir->siCon->resDir = FROM_UPR;
            siActDat(cir->key.k1.cirId, cir->siCon, IEI_CIRRES); 
         }
      }         

      /* change state */
      SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_WTRESACK);
      SISTATECHNG(cir->transStat[SICIR_HWLOCST] , SICIR_ST_WTRESACK);
      RETVALUE(ROK);
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siGenCirMsg returns failure\n"));  

   } 
   RETVALUE(RFAILED);
}


/*
*
*       Fun:   siCirRemE05S05
*
*       Desc:  Action function for processing reset ack
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE05S05
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE05S05(cir)
SiCirCb *cir;
#endif
{
   /* si006.220, MODIFIED: corrected the typo */
   TRC3(siCirRemE05S05)

   /* stop the timers */
   siStopCirTmr(cir, TMR_T17);
   if (siStopCirTmr(cir, TMR_T16) == RFAILED)
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf, 
             "T16 inactive when RLC rcvd\n"));  

      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                    LSI_USTA_DGNVAL_EVENT, (PTR) &cir->fsmEvnt, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, LSI_EVENT_REMOTE,
                     LSI_CAUSE_T16_INACTIVE, TRUE, 
                     cir->key.k1.cirId, SI_CIR_TMREXP);
   } 

   /* idle the circuit states */
   if (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK)
   {  
      SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_IDLE);
   } 
   if (cir->transStat[SICIR_HWLOCST] == SICIR_ST_WTRESACK)
   {  
      SISTATECHNG(cir->transStat[SICIR_HWLOCST] , SICIR_ST_IDLE);
   } 

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call. If so, find the connection
    * block in the controlling circuit and clear the connection cb
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* it is a non-single rate call */
      if (cir->ctrlMultiRateCir->siCon)
      {
#ifdef ZI
         ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ,
                      (PTR) cir->ctrlMultiRateCir->siCon);
#endif
         /* idle the call processing state for cntrl circuit */
         SISTATECHNG(cir->ctrlMultiRateCir->calProcStat, CALL_IDLE);

         if (cir->ctrlMultiRateCir->siCon->incC.cirId ==
             cir->ctrlMultiRateCir->key.k1.cirId)
            /* si006.220, MODIFIED: change code to unconditional clear conn */
            siForceClearIncCon(cir->ctrlMultiRateCir->siCon);
         else
         {
            if (cir->ctrlMultiRateCir->siCon->outC.cirId ==
                cir->ctrlMultiRateCir->key.k1.cirId)
               /* si006.220, MODIFIED: change code to unconditional clear conn */
               siForceClearOutCon(cir->ctrlMultiRateCir->siCon);
            else
            {
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                     "circuit %ld is not matching with inc/out %ld/%ld of \
                      cntrl conn in a non-single rate call\n",
                      cir->ctrlMultiRateCir->key.k1.cirId,
                      cir->ctrlMultiRateCir->siCon->incC.cirId,
                      cir->ctrlMultiRateCir->siCon->outC.cirId));  
            }                    
         }            
      }             
   }
   else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   {           
      /* si016.220, Modify: cir calProcStat should be changed to CALL_IDLE
       * even if there is no siCon in the circuit. In some situations, the
       * connection may have been deleted, but calProcStat is still in 
       * transient state resulting in new calls being rejected and the 
       * transient state remains forever.
       */
      /* idle the call processing state */
      SISTATECHNG(cir->calProcStat, CALL_IDLE);

      if (cir->siCon)
      {
#ifdef ZI
         ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) cir->siCon);
#endif
      
         if (cir->siCon->incC.cirId == cir->key.k1.cirId)
            /* si006.220, MODIFIED: change code to unconditional clear conn */
            siForceClearIncCon(cir->siCon);
         else 
         {
            if (cir->siCon->outC.cirId == cir->key.k1.cirId)
            {  
               /* si006.220, MODIFIED: change code to unconditional clear conn */
               siForceClearOutCon(cir->siCon);
            } 
            else
            {  
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "circuit %ld is not matching with inc/out %ld/%ld\n",
                      cir->key.k1.cirId, cir->siCon->incC.cirId,
                      cir->siCon->outC.cirId));  
            } 

         }
      }
      /* si006.220, DELETED: this code is reduntant */

   }
#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
   ziUpdPeer();
#endif

   /* generate reset confirm */
   siGenCirEvt(cir, SIT_STA_CIRRESCFM);


   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE06SND
*
*       Desc:  Action function for handling mntc CGB 
*              when not locally blocked or not unequipped
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE06SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE06SND(cir)
SiCirCb *cir;
#endif 
{
   TRC3(siCirLocE06SND)

   /* stop all circuit timers if circuit not idle */
   if (cir->transStat[SICIR_MTLOCST] != SICIR_ST_IDLE)
      siStopAllCirTmr(cir);

#ifdef SI_INDBLK
   /* start Blocking Timer */
   siStartCirTmr(TMR_T12, cir);
   /* start initial Blocking Timer */
   siStartCirTmr(TMR_T13, cir);
#endif 

   /* change state to waiting for BLA */
   SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_WTBLKACK);

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call. If so, find the connection
    * block in the controlling circuit and jump into call processing matrix 
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* it is a non-single rate call */
      if ((siJumpMRatefrmCirMsg(cir->ctrlMultiRateCir, IEI_BLKREQ, 
                                cir->fsmEvnt, NOTPRSNT)) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
          "Processing connection on controlling ckt(%#lx) failed in \
          CGBreq(mt)\n", cir->ctrlMultiRateCir->cfg.cirId));  
         RETVALUE(RFAILED);
      }
   }
   else
#endif
   {
      /* jump into call processing matrix if a call exists on the circuit */
      if (cir->siCon)
      {  
         siActDat(cir->key.k1.cirId, cir->siCon, IEI_BLKREQ);
      } 
      else  
      {  
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "no connection block on the circuit\n"));  
      }
   } 

   RETVALUE(ROK);
}


/* si003.220 - Addition. Added action function for CGB.
 */
/*
 * 
 *        Fun:   siCirLocE06S05
 * 
 *        Desc:  Action function for handling CGB when circuit is 
 *               waiting for reset ack
 * 
 *        Ret:   
 *               ROK     - ok 
 *               RFAILED - failed
 *       
 *        Notes: None
 *       
 *        File:  ci_bdy4.c
 *       
 */
#ifdef ANSI
PRIVATE S16 siCirLocE06S05
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE06S05(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE06S05)

   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                 LSI_USTA_DGNVAL_EVENT, (PTR) &cir->fsmEvnt, 
                 LSI_USTA_DGNVAL_NONE,  NULLP, 
                 LSI_USTA_DGNVAL_NONE,  NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, LCM_EVENT_INV_STATE,
                   LSI_CAUSE_CIR_MNTREQ, FALSE, 
                  cir->key.k1.cirId, SI_CIR_INVMSG);
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirLocE06S03
*
*       Desc:  Action function for handling mntc CGB req.
*              when circuit is locally blocked
*
*       Ret:   RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE06S03
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE06S03(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE06S03)

   siGenCirEvt(cir, SIT_STA_CIRBLOCFM);
   /* exclude this circuit from group request */
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE07SND
*
*       Desc:  Action function for handling mntc CGBA
*              when circuit is locally blocked/waiting for block ack
*
*       Ret:   ROK - OK
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE07SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE07SND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE07SND)

   if (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTBLKACK)
   {
#ifdef SI_INDBLK
      /* timers will be running if this flag is absent */
      siStopCirTmr(cir, TMR_T12);
      siStopCirTmr(cir, TMR_T13);
#endif
      SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_LOCBLKED);
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "local mntce state is not Wtblockack\n"));  

/* si054.220 : Added Code to update error counter */
#if(SI_LMINT3 || SMSI_LMINT3)
/* si055.220 : Changed NULL to NULLP */
          siUpdErrSts(NULLP,LSI_STS_UNXCGBA);
#endif /* SI_LMINT3 , SMSI_LMINT3 */
    
#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
#endif
   }
   RETVALUE(ROK); 
}


/*
*
*       Fun:   siCirRemE07IGN
*
*       Desc:  Action function for handling mntc CGBA
*              when circuit is idle/waiting for UBA/waiting for reset ack
*
*       Ret:   RFAILED - fail
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE07IGN
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE07IGN(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE07IGN)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   if (cir->transStat[SICIR_MTLOCST] != SICIR_ST_WTRESACK)
   {
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &cir->fsmEvnt, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                     LCM_EVENT_INV_STATE, 
                     LSI_CAUSE_CIR_MNTACK, TRUE, 
                     cir->key.k1.cirId, SI_ALRM_INVCGBA);
#ifdef SI_INDBLK 
      if (siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                      cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                      M_UNBLK, MI_UNBLK, NULLP, cir->pIntfCb->cfg.ssf, 
                      cir->pIntfCb->cfg.nwId) == ROK) 
      {
         siStopAllCirTmr(cir);
         /* start unblocking timers */
         siStartCirTmr(TMR_T15, cir);
         siStartCirTmr(TMR_T14, cir);
         SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_WTUBLACK); 
      } 
      else 
      {  
         SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "siGenCirMsg failed.\n"));  
      } 
#endif
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "Local mntce state is WTRESACK\n"));  
   } 
   RETVALUE(RFAILED);
}


/*
*
*       Fun:   siCirLocE08SND
*
*       Desc:  Action function for handling mntc CGU request
*              in the states: idle, waiting for UBA/BLA, locally blocked
*
*       Ret:   ROK - ok
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE08SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE08SND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE08XXX)

   /* stop timers if waiting for any ACKs in the current state */
   if ((cir->transStat[SICIR_MTLOCST] != SICIR_ST_LOCBLKED) ||
       (cir->transStat[SICIR_MTLOCST] != SICIR_ST_IDLE))
      siStopAllCirTmr(cir);
#ifdef SI_INDBLK
   /* start unblocking timers */
   siStartCirTmr(TMR_T14, cir);
   siStartCirTmr(TMR_T15, cir);
#endif
   /* change state */
   SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_WTUBLACK);
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE09SND
*
*       Desc:  Action function for handling mntc CGUA 
*              in the states: idle/waiting for UBA
*
*       Ret:   ROK - ok
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE09SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE09SND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE09SND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   if (cir->transStat[SICIR_MTLOCST] != SICIR_ST_IDLE)
   {
#ifdef SI_INDBLK
      /* timers will be running this flag is undefined */
      siStopCirTmr(cir, TMR_T14);
      siStopCirTmr(cir, TMR_T15);
#endif
      SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_IDLE);
   } 

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE09IGN
*
*       Desc:  Action function for handling mntc CGUA 
*              in the states: locally blocked/waiting for BLA
*
*       Ret:   RFAILED - fail
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE09IGN
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE09IGN(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE09S02)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

#ifdef SI_INDBLK
   if (siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                   cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                   M_BLOCK, MI_BLOCK, NULLP, cir->pIntfCb->cfg.ssf, 
                   cir->pIntfCb->cfg.nwId) == ROK)
   {
      siStopAllCirTmr(cir);
      /* start blocking timers */
      siStartCirTmr(TMR_T12, cir);
      siStartCirTmr(TMR_T13, cir);
      if (cir->transStat[SICIR_MTLOCST] == SICIR_ST_LOCBLKED)
         cir->noRspFlgToUp = TRUE;
      SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_WTBLKACK);
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "siGenCirMsg failed.\n"));  
   } 
#else
   UNUSED(cir);
#endif

   RETVALUE(RFAILED);
}


/*
*
*       Fun:   siCirRemE090DS05
*
*       Desc:  Action function for handling mntc/hw CGUA 
*              in the states: waiting for reset ack
*
*       Ret:   RFAILED - fail
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE090DS05
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE090DS05(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE090DS05)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

#ifdef SI_INDBLK
   if (siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                   cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                   M_RESCIR, MI_RESCIR, NULLP, cir->pIntfCb->cfg.ssf, 
                   cir->pIntfCb->cfg.nwId) == ROK)
   {
      siStopAllCirTmr(cir);
      /* start reset timers */
      siStartCirTmr(TMR_T16, cir);
      siStartCirTmr(TMR_T17, cir);
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "siGenCirMsg failed.\n"));  

   } 
#else
   UNUSED(cir);
#endif

   RETVALUE(RFAILED);
}


/*
*
*       Fun:   siCirLocE0ASND
*
*       Desc:  Action function for h/w CGB req.
*              states: idle/waiting for BLA/waiting
*                      for UBA/waiting for reset ack
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: There are no timers associated with circuit for hardware
*              blocking.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE0ASND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE0ASND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE0ASND)

   if (cir->transStat[SICIR_HWLOCST] == SICIR_ST_WTRESACK)
   {
      /* stop reset timers */
      siStopCirTmr(cir, TMR_T16);
      siStopCirTmr(cir, TMR_T17);
   }
   else
   {
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if this is a non-single rate call. If so, find the connection
       * block in the controlling circuit and jump into call processing matrix 
       */
      if (cir->ctrlMultiRateCir != NULLP)
      {
         /* it is a non-single rate call */
         if ((siJumpMRatefrmCirMsg(cir->ctrlMultiRateCir, IEI_CIRRES, 
                                cir->fsmEvnt, FROM_LWR)) != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "Processing connection on controlling ckt(%#lx) failed \
              in CGBreq(hw)\n", 
                cir->ctrlMultiRateCir->cfg.cirId));  
            RETVALUE(RFAILED);
         }
      }
      else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
      {              
         /* release connection if one exists */
         if (cir->siCon)
         {
            cir->siCon->resDir = FROM_LWR;
            siActDat(cir->key.k1.cirId, cir->siCon, IEI_CIRRES);
         }
      }
   }

   /* change state */
   SISTATECHNG(cir->transStat[SICIR_HWLOCST] , SICIR_ST_WTBLKACK);
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE0BSND
*
*       Desc:  Action function for h/w CGB ack.
*              states: locally blocked/waiting for block ack
*
*       Ret:   ROK     - ok 
*
*       Notes: There are no timers associated with circuit for hardware
*              blocking.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE0BSND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE0BSND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE0BSND)

   SISTATECHNG(cir->transStat[SICIR_HWLOCST] , SICIR_ST_LOCBLKED);

   /* idle the call processing state */
   SISTATECHNG(cir->calProcStat, CALL_IDLE);

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call. If so, find the connection
    * block in the controlling circuit and clear the connection cb 
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* it is a non-single rate call */
      if (cir->ctrlMultiRateCir->siCon)
      {
#ifdef ZI
         ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, 
                      (PTR) cir->ctrlMultiRateCir->siCon);
#endif

         /* idle the cntrl cir call processing state, the other affected cir
          * are idled in siClearIncCon or siClearOutCon
          */
         SISTATECHNG(cir->ctrlMultiRateCir->calProcStat, CALL_IDLE);

         if (cir->ctrlMultiRateCir->siCon->incC.cirId == 
             cir->ctrlMultiRateCir->key.k1.cirId)
         {
            cir->ctrlMultiRateCir->siCon->incC.relResp = FALSE;         
            siClearIncCon(cir->ctrlMultiRateCir->siCon);
         }   
         else 
         {
            if (cir->ctrlMultiRateCir->siCon->outC.cirId == 
                cir->ctrlMultiRateCir->key.k1.cirId)
            {
               cir->ctrlMultiRateCir->siCon->outC.relResp = FALSE;
               siClearOutCon(cir->ctrlMultiRateCir->siCon);
            }   
#ifdef DEBUGP
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "cir [%#lx] mismatch with out/inc circuit %#lx/%#lx of \
                      cntrl conn in a non-single rate call.\n",
                      cir->ctrlMultiRateCir->key.k1.cirId, 
                      cir->ctrlMultiRateCir->siCon->outC.cirId, 
                      cir->ctrlMultiRateCir->siCon->incC.cirId));  
            } 
#endif
         }
      }
   }
   else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   {           
      if (cir->siCon)
      {

#ifdef ZI
         ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) cir->siCon);
#endif

         if (cir->siCon->incC.cirId == cir->key.k1.cirId)
         {
            cir->siCon->incC.relResp = FALSE;
            siClearIncCon(cir->siCon);
         }
         else 
         {
            if (cir->siCon->outC.cirId == cir->key.k1.cirId)
            {
               cir->siCon->incC.relResp = FALSE;
               siClearOutCon(cir->siCon);
            }
#ifdef DEBUGP
            else
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                 "circuit=%#lx siCon->{incC.cirId=%#lx, outC.cirId = %#lx}\n",
                 cir->key.k1.cirId, cir->siCon->incC.cirId, 
                 cir->siCon->outC.cirId));  
#endif
         }
      }

      /* si006.220, DELETED: this code is redundant */
   }   

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirLocE0CSND
*
*       Desc:  Action function for h/w CGU request
*              states:waiting for BLA/waiting for UBA/locally blocked 
*
*       Ret:   
*
*       Notes: There are no timers associated with circuit for hardware
*              blocking.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE0CSND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE0CSND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE0CSND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* change state */
   SISTATECHNG(cir->transStat[SICIR_HWLOCST] , SICIR_ST_WTUBLACK);
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE0DSND
*
*       Desc:  Action function for h/w CGU ack
*              states:idle/waiting for UBA
*
*       Ret:   
*
*       Notes: There are no timers associated with circuit for hardware
*              blocking.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE0DSND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE0DSND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE0DSND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   if (cir->transStat[SICIR_HWLOCST] != SICIR_ST_IDLE)
      SISTATECHNG(cir->transStat[SICIR_HWLOCST] , SICIR_ST_IDLE);

   
#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
#endif
   
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirLocE0ESND
*
*       Desc:  Action function for handling circuit group reset request
*              states: all circuit states
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE0ESND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE0ESND(cir)
SiCirCb *cir;
#endif
{

   TRC3(siCirLocE0ESND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* ensure consistency of h/w & mntc states if 
    * uneqpd or waiting for reset ack - action is upto layer management
    */
   if ( (cir->transStat[SICIR_MTLOCST] == SICIR_ST_UNEQPD)   ||
        (cir->transStat[SICIR_HWLOCST] == SICIR_ST_UNEQPD)   ||
        (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK) ||
        (cir->transStat[SICIR_HWLOCST] == SICIR_ST_WTRESACK))
   {
      if (cir->transStat[SICIR_MTLOCST] != cir->transStat[SICIR_HWLOCST])
      {
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                       LSI_USTA_DGNVAL_EVENT, (PTR) &cir->fsmEvnt, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERNAL, 
                        LCM_EVENT_INV_STATE, LSI_CAUSE_CIC_STATE_MISMATCH, 
                        TRUE, cir->key.k1.cirId, SI_CIR_STOUTSYNC);
      }
   }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call. If so, find the connection
    * block in the controlling circuit and jump into call processing matrix 
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* it is a non-single rate call */
      if (cir->ctrlMultiRateCir->siCon)
      {
         /* connection is not possible in these states */
         if ((cir->transStat[SICIR_MTLOCST] == SICIR_ST_UNEQPD) ||
             (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK))
         {
            SISNDOLDLSISTAIND(&siCb.init.lmPst, cir->key.k1.cirId, 
                              SI_CIR_STOUTSYNC);
#if (SI_LMINT3 || SMSI_LMINT3)
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId,
                          LSI_USTA_DGNVAL_NONE, (PTR) &cir->fsmEvnt,
                          LSI_USTA_DGNVAL_NONE, NULLP,
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERNAL,
                           LCM_EVENT_INV_STATE, LSI_CAUSE_CIC_STATE_MISMATCH,
                           TRUE, cir->key.k1.cirId, SI_CIR_INVCON);

#endif
         }

         /* it is a non-single rate call */
         if ((siJumpMRatefrmCirMsg(cir->ctrlMultiRateCir, IEI_CIRRES, 
                                cir->fsmEvnt, FROM_UPR)) != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "Processing connection on controlling ckt(%#lx) failed \
               in GRSreq\n", cir->ctrlMultiRateCir->cfg.cirId));  
            RETVALUE(RFAILED);
         }
      }
      else
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "connection in controlling ckt is NULLP\n"));  
         RETVALUE(RFAILED);
      }
   }
   else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   {           
      /* if connection exists */
      if (cir->siCon)
      {
         /* connection is not possible in these states */
         if ((cir->transStat[SICIR_MTLOCST] == SICIR_ST_UNEQPD) ||
             (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK))
            SISNDOLDLSISTAIND(&siCb.init.lmPst, cir->key.k1.cirId, 
                              SI_CIR_INVCON);
 
         SISTATECHNG(cir->calProcStat, TRANS);
         /* send up individual release indication to upper layer */
         cir->siCon->resDir = FROM_UPR;
         if (cir->resFlag == FALSE)
            siActDat(cir->key.k1.cirId, cir->siCon, IEI_CIRRES);
      }
   }
   /* If remote mntce state is blocked then clear it as subsequently 
      BLO will be sent by peer 
   */
/* si003.220 - Modified code so that if remote maintenance state is waiting
 * for block ack then also clear it.
 */
   if((cir->transStat[SICIR_MTREMST] == SICIR_ST_REMBLKED) ||
      (cir->transStat[SICIR_MTREMST] == SICIR_ST_WTBLKACK))
   {
      SISTATECHNG(cir->transStat[SICIR_MTREMST], SICIR_ST_IDLE);
   }
/* si041.220 : If BLOREQ and GRS are sent from local to Remote, where BLOREQ
   happened first, the circuit state will be changed to WTRESACK but we were not
   stopping the timer T12. So when the timer will expire, we will send out
   another BLOREQ which is not correct. Ideally we should stop the all circuit
   timer 
*/
   siStopAllCirTmr(cir);

   /* change states */
   SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_WTRESACK);
   SISTATECHNG(cir->transStat[SICIR_HWLOCST] , SICIR_ST_WTRESACK);
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE0FS05
*
*       Desc:  Action function for group reset ack.
*              state: waiting for reset ack
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE0FS05
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE0FS05(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE0FS05)
   
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call. If so, find the connection
    * block in the controlling circuit and clear the connection cb 
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* it is a non-single rate call */
      if (cir->ctrlMultiRateCir->siCon)
      {
#ifdef ZI
         ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, 
                      (PTR) cir->ctrlMultiRateCir->siCon);
#endif

         /* idle the cntrl cir call processing state, the other affected cir
          * are idled in siClearIncCon or siClearOutCon
          */
         SISTATECHNG(cir->ctrlMultiRateCir->calProcStat, CALL_IDLE);

         if (cir->ctrlMultiRateCir->siCon->incC.cirId == 
             cir->ctrlMultiRateCir->key.k1.cirId)
            /* si006.220, MODIFIED: clear the connection unconditionally */
            siForceClearIncCon(cir->ctrlMultiRateCir->siCon);
         else 
         {
            if (cir->ctrlMultiRateCir->siCon->outC.cirId == 
                cir->ctrlMultiRateCir->key.k1.cirId)
               /* si006.220, MODIFIED: clear the connection unconditionally */
               siForceClearOutCon(cir->ctrlMultiRateCir->siCon);
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                 "cir [%#lx] does not match with out/inc circuit %#lx/%#lx \
                 of cntrl conn in a non-single rate call.\n",
                 cir->ctrlMultiRateCir->key.k1.cirId, 
                 cir->ctrlMultiRateCir->siCon->outC.cirId, 
                 cir->ctrlMultiRateCir->siCon->incC.cirId));  
            } 
         }
      }
   }
   else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   {           
      /* destroy the connections */  
      if (cir->siCon)
      {

#ifdef ZI
         ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) cir->siCon);
#endif

         if (cir->siCon->incC.cirId == cir->key.k1.cirId)
            /* si006.220, MODIFIED: clear the connection unconditionally */
            siForceClearIncCon(cir->siCon);
         else
         {
            if (cir->siCon->outC.cirId == cir->key.k1.cirId)
               /* si006.220, MODIFIED: clear the connection unconditionally */
               siForceClearOutCon(cir->siCon);
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "cir [%ld] does not match with out/inc %ld/%ld\n",
                       cir->key.k1.cirId, cir->siCon->outC.cirId, 
                       cir->siCon->incC.cirId));
            } 
         }
      } 
      /* si006.220, DELETED: this code is redundant */
   }
   /* idle the call processing state */
   SISTATECHNG(cir->calProcStat, CALL_IDLE);  

   /* idle the state */
   if (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK)
   {
      SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_IDLE);
   }
   if (cir->transStat[SICIR_HWLOCST] == SICIR_ST_WTRESACK)
   {
      SISTATECHNG(cir->transStat[SICIR_HWLOCST] , SICIR_ST_IDLE);
   }

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
#endif

   RETVALUE(ROK); 
}

/************************ REMOTE EVENTS *************************/


/*
*
*       Fun:   siCirRemE10SND
*
*       Desc:  Action function for block message 
*              state: idle /waiting for unblock response
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE10SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE10SND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE10SND)

   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, LSI_EVENT_REMOTE, 
                  LSI_CAUSE_BLOCK, TRUE, cir->key.k1.cirId, SI_CIR_BLOCK);
   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_WTBLKRSP);
   siGenCirEvt(cir, SIT_STA_CIRBLOIND);
   
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call. If so, find the connection
    * block in the controlling circuit and jump into call processing matrix 
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* it is a non-single rate call */
      if ((siJumpMRatefrmCirMsg(cir->ctrlMultiRateCir, IEI_BLKREQ, 
                                cir->fsmEvnt, NOTPRSNT)) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "Processing connection on controlling ckt(%#lx) failed \
                 in bloreq\n", cir->ctrlMultiRateCir->cfg.cirId));  
         RETVALUE(RFAILED);
      }
   }
   else
#endif
   {           
      if (cir->siCon)
         siActDat(cir->key.k1.cirId, cir->siCon, IEI_BLKREQ);
   }   
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE10S06
*
*       Desc:  Action function for block message
*              state: called when blocking indications are missing
*
*       Ret:
*              ROK     - ok
*              RFAILED - failed
*
*       Notes: Here the connection is not processed as it is
*              already done before
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE10S06
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE10S06(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE10S06)

   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId,
                 LSI_USTA_DGNVAL_NONE, NULLP,
                 LSI_USTA_DGNVAL_NONE, NULLP,
                 LSI_USTA_DGNVAL_NONE, NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, LSI_EVENT_REMOTE,
                  LSI_CAUSE_BLOCK, TRUE, cir->key.k1.cirId, SI_CIR_BLOCK);
   siGenCirEvt(cir, SIT_STA_CIRBLOIND);
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE10S07
*
*       Desc:  Action function for block message 
*              state: remotely blocked
*
*       Ret:   
*              ROK     - ok 
*
*       Notes: Assumes a reliable SIT interface
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE10S07
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE10S07(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE10S07)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   if (cir->noRspFlgToLw == TRUE)
   {
      cir->noRspFlgToLw = FALSE;
      RETVALUE(ROK);
   }
   if (siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                   cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                   M_BLOCKACK, MI_BLOCKACK, NULLP, cir->pIntfCb->cfg.ssf, 
                   cir->pIntfCb->cfg.nwId) == ROK)
   {  
      RETVALUE(ROK);
   } 
   else  
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "siGenCirMsg returns failure\n"));  
   } 

   RETVALUE(RFAILED);
}


/*
*
*       Fun:   siCirLocE11S01
*
*       Desc:  Action function for block response 
*              state: idle
*
*       Ret:   
*              ROK     - ok 
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE11S01
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE11S01(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE11S01)

   cir->noRspFlgToLw             = TRUE;
   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_WTUBLRSP);
   siGenCirEvt(cir, SIT_STA_CIRUBLIND);
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirLocE11SND
*
*       Desc:  Action function for block response 
*              state: waiting for block response
*
*       Ret:   
*              ROK     - ok 
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE11SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE11SND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE11SND);

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   if (cir->noRspFlgToLw == TRUE)
      cir->noRspFlgToLw = FALSE;
   else
   {
      if (siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                      cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                      M_BLOCKACK, MI_BLOCKACK, NULLP, cir->pIntfCb->cfg.ssf, 
                      cir->pIntfCb->cfg.nwId) != ROK)
      {
         SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf, 
                "siGenCirMsg returns failure\n"));  
         RETVALUE(RFAILED);
      }
   }

   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_REMBLKED);

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
   ziUpdPeer();
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE12S01
*
*       Desc:  Action function for UBL msg 
*              state: idle
*
*       Ret:   
*              ROK     - ok 
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE12S01
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE12S01(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE12S01)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, LSI_EVENT_REMOTE,
                  LSI_CAUSE_UBL_ON_IDLE_CIC, TRUE, 
                  cir->key.k1.cirId, SI_CIR_IDLE);
   /* As per ANSI'92 T1.113.4, 2.8.2.2, a received circuit unblocking message
    * may unblock the circuit regardless of whether the blocking procedure used
    * was immediate release or no release. The following code is added so that
    * if the remote hardware state is blocked or waiting for blocking response,
    * then ISUP generates a UBL indication to upper layer. When the upper layer 
    * responds with a UBL response, ISUP will idle the remote maintenance and 
    * as well as the remote hardware state and sends UBA to the peer. If it is
    * not ANSI'92 variant or remote harware state is not blocked or waiting for
    * UBL response, ISUP sends UBA immediately.
    */
   if (siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                   cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                   M_UNBLKACK, MI_UNBLKACK, NULLP, cir->pIntfCb->cfg.ssf, 
                   cir->pIntfCb->cfg.nwId) == ROK)
   {  
      RETVALUE(ROK);
   } 
   else  
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "siGenCirMsg returns failure\n"));  

   } 

   RETVALUE(RFAILED);
}


/*
*
*       Fun:   siCirRemE12SND
*
*       Desc:  Action function for UBL msg 
*              state: waiting for block/reset resp, remotely blocked
*
*       Ret:   
*              ROK     - ok 
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE12SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE12SND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE12SND)

   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_WTUBLRSP);
   siGenCirEvt(cir, SIT_STA_CIRUBLIND);
   RETVALUE(ROK); 
}


/*
*
*       Fun:   siCirLocE13SND
*
*       Desc:  Action function for unblock response
*              state: waiting for unblock response
*
*       Ret:   ROK     - ok 
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE13SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE13SND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE13SND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   if (cir->noRspFlgToLw == TRUE)
      cir->noRspFlgToLw = FALSE;
   else
   {
      if (siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                      cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                      M_UNBLKACK, MI_UNBLKACK, NULLP, cir->pIntfCb->cfg.ssf, 
                      cir->pIntfCb->cfg.nwId) != ROK)
      {
         SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf, 
                "siGenCirMsg returns failure\n"));  
         RETVALUE(RFAILED);
      }
   }

   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_IDLE);
   /* On getting unblock response from CC in case of ANSI
      the hardware status should also be made idle.
   */

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
   ziUpdPeer();
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirLocE13S07
*
*       Desc:  Action function for unblock response
*              state: remotely blocked
*
*       Ret:   ROK     - ok 
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE13S07
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE13S07(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE13S07)

   cir->noRspFlgToLw = TRUE;
   SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_WTBLKRSP);
   siGenCirEvt(cir, SIT_STA_CIRBLOIND);
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE14S00
*
*       Desc:  Action function for equipping circuit via reset.
*
*       Ret:   
*              ROK     - ok 
*              RFAILED - failed
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE14S00
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE14S00(cir)
SiCirCb *cir;
#endif
{

   TRC3(siCirRemE14S00)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* change state */
   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_WTRESRSP);
   SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_WTRESRSP);
   /* send up reset indication to upper layer */
   siGenCirEvt(cir, SIT_STA_CIRRESIND);
   /* generate UCIC message if circuit is unequipped at this end */
   if (cir->transStat[SICIR_MTLOCST] == SICIR_ST_UNEQPD)
   {
      if (cir->transStat[SICIR_HWLOCST] != SICIR_ST_UNEQPD)
      {
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                       LSI_USTA_DGNVAL_NONE, (PTR) &cir->fsmEvnt, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERNAL, 
                        LCM_EVENT_INV_STATE, LSI_CAUSE_CIC_STATE_MISMATCH, 
                        TRUE, cir->key.k1.cirId, SI_CIR_STOUTSYNC);
      }

      {
         siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                     cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, M_UNEQUIPCIC, 
                     MI_UNEQUIPCIC, NULLP, cir->pIntfCb->cfg.ssf,
                     cir->pIntfCb->cfg.nwId);
      }
   }
   RETVALUE(ROK);
}


/*
*
*       Fun:   
*       Desc:  Action function for reset message
*              state: any remote state other than unequipped
*
*       Ret:   ROK     - ok 
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE14SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE14SND(cir)
SiCirCb *cir;
#endif
{
   SiNSAPCb  *cb;
   SiAllSdus ev;
   S16       ret;
   U8  mntState;
   U8  hwState;
   
   TRC3(siCirRemE14SND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* validate unequipped states */
   if ( (cir->transStat[SICIR_MTLOCST] == SICIR_ST_UNEQPD)   ||
        (cir->transStat[SICIR_HWLOCST] == SICIR_ST_UNEQPD)   ||
        (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK) ||
        (cir->transStat[SICIR_HWLOCST] == SICIR_ST_WTRESACK))
   {
      if (cir->transStat[SICIR_MTLOCST] != cir->transStat[SICIR_HWLOCST])
      {
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                       LSI_USTA_DGNVAL_NONE, (PTR) &cir->fsmEvnt, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERNAL, 
                        LCM_EVENT_INV_STATE, LSI_CAUSE_CIC_STATE_MISMATCH, 
                        TRUE, cir->key.k1.cirId, SI_CIR_STOUTSYNC);
      }
   }
   
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call. If so, find the connection
    * block in the controlling circuit and jump into call processing matrix 
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* it is a non-single rate call */
      if (cir->ctrlMultiRateCir->siCon)
      {
         /* check if conn. exists in unequipped/waiting for reset ack 
          * states 
          */
         if ((cir->transStat[SICIR_MTLOCST] == SICIR_ST_UNEQPD) ||
             (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK))
            SISNDOLDLSISTAIND(&siCb.init.lmPst, cir->key.k1.cirId, 
                              SI_CIR_INVCON);

         /* if the circuit is in the locally blocked state, IUSP should
          * generate an alarm to layer manager. The reason is that ISUP
          * will generate GRS or multiple RSC for the non-single rate call.
          * The locally blocked state will be overwriten. The layer manager
          * and CC should be informed. CC will be informed by
          * SIT_STA_CIRLOCRES or SIT_STA_CIRLOCGRS status inidcation when
          * ISUP sending GRS or RSC
          */ 
         if ((cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTBLKACK) ||
              (cir->transStat[SICIR_MTLOCST] == SICIR_ST_LOCBLKED) ||
              (cir->transStat[SICIR_HWLOCST] == SICIR_ST_LOCBLKED) ||
              (cir->transStat[SICIR_HWLOCST] == SICIR_ST_WTBLKACK))
         {            
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_LOCAL, LSI_CAUSE_RSCONBLK, TRUE, 
                           cir->key.k1.cirId, SI_CIR_BLOCK);
         }

         /* Generate the reset procedure and jump to the connection state
          * matrix
          */
         if ((siJumpMRatefrmCirMsg(cir->ctrlMultiRateCir, IEI_CIRRES, 
                                  cir->fsmEvnt, FROM_LWR)) != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "Processing connection on controlling ckt(%#lx) failed \
                   in reset\n", cir->ctrlMultiRateCir->cfg.cirId));  
            RETVALUE(RFAILED);
         }

      }
      else
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "connection in controlling ckt(%#lx) is NULLP\n",
                cir->cfg.cirId));  
         RETVALUE(RFAILED);
      }
   }
   else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   {           
      /* release the call if any */
      if (cir->siCon)
      {
         /* check if conn. exists in unequipped/waiting for reset ack states */
         if ((cir->transStat[SICIR_MTLOCST] == SICIR_ST_UNEQPD) ||
             (cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK))
            SISNDOLDLSISTAIND(&siCb.init.lmPst, cir->key.k1.cirId, 
                              SI_CIR_INVCON);

         cir->siCon->resDir = FROM_LWR;
         siActDat(cir->key.k1.cirId, cir->siCon, IEI_CIRRES);
      }
   }

   mntState = cir->transStat[SICIR_MTREMST];
   hwState = cir->transStat[SICIR_HWREMST];

   /* Change the state to "waiting for reset response" as we will
    * be generating SitStaInd to the service user and will be
    * waiting to receive SitStaReq to change the state of this
    * circuit to IDLE.
    */
   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_WTRESRSP);
   SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_WTRESRSP);

   /* If the cirucit was blocked when it received reset message,
    * then we unblock this circuit. Generate an indication to
    * the service user that the circuit is unblocked.
    */
   {
      SiUpSAPCb *tcb;
      
      tcb = siGetUprCbPtr(cir);

      /* Generate UBL indication in SitStaInd primitive for maintenance
       * block states.
       */
      switch (mntState) 
      {
         case SICIR_ST_REMBLKED: /* Fall Through */
         case SICIR_ST_WTBLKRSP:
            siGenCirEvt(cir, SIT_STA_CIRUBLIND);
            break;
         
         default:
            break;
      }

      /* Generate CGU indication in SitStaInd primitive for hardware
       * block states.
       */
      switch (hwState)
      {
         case SICIR_ST_REMBLKED: /* Fall Through */
         case SICIR_ST_WTBLKRSP:
            {
               SiStaEvnt     staEvt;

               cmMemset((U8 *) &staEvt, (U8)NOTPRSNT, sizeof(SiStaEvnt));
               staEvt.cgsmti.eh.pres          = PRSNT_NODEF;
               staEvt.cgsmti.typeInd.pres     = PRSNT_NODEF;
               staEvt.cgsmti.typeInd.val      = HARDFAIL;
               staEvt.rangStat.eh.pres        = PRSNT_NODEF;
               staEvt.rangStat.range.pres     = PRSNT_NODEF;
               staEvt.rangStat.range.val      = 1;
               staEvt.rangStat.status.pres    = PRSNT_NODEF;
               staEvt.rangStat.status.len     = 1;
               staEvt.rangStat.status.val[0] =  0x01;
                

               SiUiSitStaInd(&tcb->pst, tcb->suId, 0, 0, 
                  cir->cfg.cirId, TRUE, SIT_STA_CGUIND,
                     &staEvt, NULLP);
            }
            break;
         
         default:
            break;
      }
   }      
    
   /* send BLO when circuit is in mntc. local blocking states */
   if ((cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTBLKACK) ||
       (cir->transStat[SICIR_MTLOCST] == SICIR_ST_LOCBLKED))
   {
      cir->noRspFlgToUp = TRUE;
      if (siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                      cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                      M_BLOCK, MI_BLOCK, NULLP, cir->pIntfCb->cfg.ssf, 
                      cir->pIntfCb->cfg.nwId) == ROK)
      {
         siStopAllCirTmr(cir);
         siStartCirTmr(TMR_T12, cir); 
         siStartCirTmr(TMR_T13, cir); 
         SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_WTBLKACK);
      } 
      else 
      {  
         SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
           "siGenCirMsg returns failure\n"));  

      } 
   }
   /* send CGB when circuit is in h/w local blocking states */
   if (cir->transStat[SICIR_HWLOCST] == SICIR_ST_LOCBLKED)
   {
      cb = siGetLwrMCbPtr(cir);

      /* initialize status event */
      MFINITSDU(&cb->mfMsgCtl, ret, (U8) 0, (U8) SI_STAREQ, 
                (ElmtHdr *) NULLP, (ElmtHdr *) &ev.m.siStaEvnt, 
                (U8) NOTPRSNT, cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);
      /* supervisory indicators */
      ev.m.siStaEvnt.cgsmti.eh.pres       = PRSNT_NODEF;
      ev.m.siStaEvnt.cgsmti.typeInd.pres  = PRSNT_NODEF;
      ev.m.siStaEvnt.cgsmti.typeInd.val   = HARDFAIL;
      /* range and status fields */
      ev.m.siStaEvnt.rangStat.eh.pres     = PRSNT_NODEF;
      ev.m.siStaEvnt.rangStat.range.pres  = PRSNT_NODEF;
      ev.m.siStaEvnt.rangStat.range.val   = 0x01;
      ev.m.siStaEvnt.rangStat.status.pres = PRSNT_NODEF;
      ev.m.siStaEvnt.rangStat.status.len  = 0x01;
      ev.m.siStaEvnt.rangStat.status.val[0] = 0x01;

      /* process circuit group event */
      cir->sduSp = (SiAllSdus *)&ev.m.siStaEvnt;
      siProcCirGrEvt(cir, SIT_STA_CGBREQ, (SiStaEvnt *)&ev.m.siStaEvnt);
   }

/* si023.220: deletion - remove changes from si020.220 for the
 * flag setting of noRspFlgToLw, since this flag is set in 
 * SitUDatInd before calling siProcCirMsg.
 */

   /* send event to upper layer */
   siGenCirEvt(cir, SIT_STA_CIRRESIND);

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirLocE15SND
*
*       Desc:  Action function for reset response
*              state: waiting for reset response
*
*       Ret:   ROK     - ok 
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE15SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE15SND(cir)
SiCirCb *cir;
#endif
{
   U8 cause;

   TRC3(siCirRemE15SND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call. If so, find the connection
    * block in the controlling circuit and clear the connection cb 
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* it is a non-single rate call */
      if (cir->ctrlMultiRateCir->siCon)
      {
#ifdef ZI
         ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, 
                      (PTR) cir->ctrlMultiRateCir->siCon);
#endif

         if (cir->ctrlMultiRateCir->siCon->incC.cirId == 
             cir->ctrlMultiRateCir->key.k1.cirId)
            /* si006.220, MODIFIED: change code to unconditional clear conn */
            siForceClearIncCon(cir->ctrlMultiRateCir->siCon);
         else 
         {
            if (cir->ctrlMultiRateCir->siCon->outC.cirId == 
                cir->ctrlMultiRateCir->key.k1.cirId)
               /* si006.220, MODIFIED:  clear connection unconditionally */
               siForceClearOutCon(cir->ctrlMultiRateCir->siCon);
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "cir [%#lx] mismatch with out/inc circuit %#lx/%#lx of \
                      cntrl conn in a non-single rate call.\n",
                      cir->ctrlMultiRateCir->key.k1.cirId, 
                      cir->ctrlMultiRateCir->siCon->outC.cirId, 
                      cir->ctrlMultiRateCir->siCon->incC.cirId));  
            } 
         }
      }
   }
   else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   {           
      if (cir->siCon)
      {

#ifdef ZI
         ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) cir->siCon);
#endif

         if (cir->siCon->incC.cirId == cir->key.k1.cirId)
            /* si006.220, MODIFIED:  clear connection unconditionally */
            siForceClearIncCon(cir->siCon);
         else 
         {
            if (cir->siCon->outC.cirId == cir->key.k1.cirId)
               /* si006.220, MODIFIED:  clear connection unconditionally */
               siForceClearOutCon(cir->siCon);
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "cir [%#lx] mismatch with out/inc circuit %#lx/%#lx of \
                      conn.\n", cir->key.k1.cirId, cir->siCon->outC.cirId, 
                      cir->siCon->incC.cirId));  
            } 
         }
      }
      /* si006.220, DELETED: this code is reduntant */

   }

   cause = SIT_CCNORMUNSPEC;

   if (cir->noRspFlgToLw == TRUE)
      cir->noRspFlgToLw = FALSE;
   else
   {
      if (siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                      cir->phyDpc, TRUE, cir->pIntfCb->cfg.swtch, 
                      M_RELCOMP, MI_RELCOMP, &cause, cir->pIntfCb->cfg.ssf, 
                      cir->pIntfCb->cfg.nwId) != ROK)
      {
         SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf, 
                "can't send RLC to n/w\n"));  
         RETVALUE(RFAILED);
      }
   }

   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_IDLE);
   SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_IDLE);

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
   ziUpdPeer();
#endif


   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE16SND
*
*       Desc:  Action function for mntc CGB message
*              state: idle/waiting for block response/rem blocked
*
*       Ret:   ROK     - ok 
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE16SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE16SND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE16SND)

   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_WTBLKRSP);

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call. If so, find the connection
    * block in the controlling circuit and jump into call processing matrix 
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* it is a non-single rate call */
      if ((siJumpMRatefrmCirMsg(cir->ctrlMultiRateCir, IEI_BLKREQ, 
                                cir->fsmEvnt, NOTPRSNT)) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "Processing connection on controlling ckt(%#lx) failed in \
                 CGB(mt)\n", cir->ctrlMultiRateCir->cfg.cirId));  
         RETVALUE(RFAILED);
      }
   }
   else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   {           
      if (cir->siCon)
         siActDat(cir->key.k1.cirId, cir->siCon, IEI_BLKREQ);
   }
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirLocE17SND
*
*       Desc:  Action for mntc CGB response
*              
*       Ret:   ROK - ok; RFAILED - failed
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE17SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE17SND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE17SND)

   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_REMBLKED);

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE18SND
*
*       Desc:  Action for mntc CGU
*              
*       Ret:   ROK - ok
*
*       Notes: 
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE18SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE18SND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE18SND)

   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_WTUBLRSP);
   RETVALUE(ROK); 
}



/*
*
*       Fun:   siCirLocE19SND
*
*       Desc:  Action function for mntc. CGU response
*              States: waiting for unblocking response/idle 
*
*       Ret:   ROK - ok
*
*       Notes: 
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE19SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE19SND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE19SND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_IDLE);

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE1ASND
*
*       Desc:  Action for h/w CGB msg
*              State : all remote states except unequipped
*              
*       Ret:   ROK - ok
*
*       Notes: 
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE1ASND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE1ASND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE1ASND)

   SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_WTBLKRSP);

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call. If so, find the connection
    * block in the controlling circuit and jump into call processing matrix 
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* it is a non-single rate call */
      /* The reset direction should be FROM_LWR */
      if ((siJumpMRatefrmCirMsg(cir->ctrlMultiRateCir, IEI_CIRRES, 
                                cir->fsmEvnt, FROM_LWR)) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "Processing connection on controlling ckt(%#lx) failed in \
                CGB(hw)\n", cir->ctrlMultiRateCir->cfg.cirId));  
         RETVALUE(RFAILED);
      }
   }
   else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   {           
      /* if connection exists */
      if (cir->siCon)
      {
         /* The reset direction should be FROM_LWR */
         cir->siCon->resDir = FROM_LWR;
         /* jump into call state matrix */
         siActDat(cir->key.k1.cirId, cir->siCon, IEI_CIRRES);
      } 
      else 
      {  
         SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "no connection associated with circuit\n"));  
      }
   }   
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirLocE1BSND
*
*       Desc:  Action func. for h/w CGB response
*              states: waiting for block response/remotely blocked
*              
*       Ret:   ROK - ok
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE1BSND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE1BSND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE1BSND)

   SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_REMBLKED);

   /* idle the call processing state */
   SISTATECHNG(cir->calProcStat, CALL_IDLE);

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call. If so, find the connection
    * block in the controlling circuit and clear the connection cb 
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* it is a non-single rate call */
      if (cir->ctrlMultiRateCir->siCon)
      {
#ifdef ZI
         ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, 
                      (PTR) cir->ctrlMultiRateCir->siCon);
#endif

         /* idle the cntrl cir call processing state, the other affected cir
          * are idled in siClearIncCon or siClearOutCon
          */
         SISTATECHNG(cir->ctrlMultiRateCir->calProcStat, CALL_IDLE);

         if (cir->ctrlMultiRateCir->siCon->incC.cirId == 
             cir->ctrlMultiRateCir->key.k1.cirId)
         {
            cir->ctrlMultiRateCir->siCon->incC.relResp = FALSE;         
            siClearIncCon(cir->ctrlMultiRateCir->siCon);
         }   
         else 
         {
            if (cir->ctrlMultiRateCir->siCon->outC.cirId == 
                cir->ctrlMultiRateCir->key.k1.cirId)
            {
               cir->ctrlMultiRateCir->siCon->outC.relResp = FALSE;
               siClearOutCon(cir->ctrlMultiRateCir->siCon);
            }   
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "cir [%#lx] mismatch with out/inc circuit %#lx/%#lx of \
                      cntrl conn in a non-single rate call.\n",
                      cir->ctrlMultiRateCir->key.k1.cirId, 
                      cir->ctrlMultiRateCir->siCon->outC.cirId, 
                      cir->ctrlMultiRateCir->siCon->incC.cirId));  
            } 
         }
      }
   }
   else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   {           
      if (cir->siCon)
      {

#ifdef ZI
         ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) cir->siCon);
#endif

         if (cir->siCon->incC.cirId == cir->key.k1.cirId)
         {
            cir->siCon->incC.relResp = FALSE;
            siClearIncCon(cir->siCon);
         }
         else 
         {
            if (cir->siCon->outC.cirId == cir->key.k1.cirId)
            {
               cir->siCon->outC.relResp = FALSE;
               siClearOutCon(cir->siCon);
            }
#ifdef DEBUGP
            else
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "circuit =%#lx mismatch with inc/out (%#lx/%#lx) ckt of\
                      conn./\n", cir->key.k1.cirId, cir->siCon->incC.cirId, 
                      cir->siCon->outC.cirId));
#endif
         }
      }
      /* si006.220, DELETED: this code is reduntant */

   }


#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE1CSND
*
*       Desc:  action func. for h/w CGU message
*       States: all states except unequipped
* 
*       Ret:   
*
*       Notes: 
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE1CSND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE1CSND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirRemE1CSND)

   SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_WTUBLRSP);
   RETVALUE(ROK); 
}


/*
*
*       Fun:   siCirLocE1DSND
*
*       Desc:  action func. for h/w CGU response
*              states: idle/waiting for unblock response
*              
*       Ret:   ROK
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE1DSND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE1DSND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE1DSND)
  
#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_IDLE); 

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
#endif
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRem1ESND
*
*       Desc:  action function for handling group reset message
*              States: all states 
*       Ret:   ROK - ok;  RFAILED - failed
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE1ESND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE1ESND(cir)
SiCirCb *cir;
#endif
{
   S16 ret;
   U8  mntState;
   U8  hwState;
   
   TRC3(siCirRemE1ESND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* validate states in unequipped states */
   if ((cir->transStat[SICIR_MTREMST] == SICIR_ST_UNEQPD) || 
       (cir->transStat[SICIR_HWREMST] == SICIR_ST_UNEQPD))
   {
      if (cir->transStat[SICIR_MTREMST] != cir->transStat[SICIR_HWREMST])
      {
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                       LSI_USTA_DGNVAL_NONE, (PTR) &cir->fsmEvnt, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERNAL, 
                        LCM_EVENT_INV_STATE, LSI_CAUSE_CIC_STATE_MISMATCH, 
                        TRUE, cir->key.k1.cirId, SI_CIR_STOUTSYNC); 
      }
   }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call. If so, find the connection
    * block in the controlling circuit and jump into call processing matrix 
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* it is a non-single rate call */
      if (cir->ctrlMultiRateCir->siCon)
      {

         /* if the circuit is in the locally blocked state, IUSP should
          * generate an alarm to layer manager. The reason is that ISUP
          * will generate GRS or multiple RSC for the non-single rate call.
          * The locally blocked state will be overwriten. The layer manager
          * and CC should be informed. CC will be informed by
          * SIT_STA_CIRLOCRES or SIT_STA_CIRLOCGRS status inidcation when
          * ISUP sending GRS or RSC on the controlling circuit.
          */ 
         if ((cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTBLKACK) ||
             (cir->transStat[SICIR_MTLOCST] == SICIR_ST_LOCBLKED) ||
             (cir->transStat[SICIR_HWLOCST] == SICIR_ST_LOCBLKED) ||
             (cir->transStat[SICIR_HWLOCST] == SICIR_ST_WTBLKACK))
         {            
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_LOCAL, LSI_CAUSE_RSCONBLK, TRUE, 
                           cir->key.k1.cirId, SI_CIR_BLOCK);
         }

         /* Generate the reset procedure and jump to the connection state
          * matrix
          */
         if ((siJumpMRatefrmCirMsg(cir->ctrlMultiRateCir, IEI_CIRRES, 
                                  cir->fsmEvnt, FROM_LWR)) != ROK)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "Processing connection on controlling ckt(%#lx) failed in GRS\n", 
                 cir->ctrlMultiRateCir->cfg.cirId));  
            RETVALUE(RFAILED);
         }
      }
      else
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "connection in controlling ckt is NULLP\n"));  
         RETVALUE(RFAILED);
      }
   }
   else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   {           
      /* release the call if any */
      if (cir->siCon)
      {
         /* validate connections in unequipped and reset response states */

         cir->siCon->resDir = FROM_LWR;
         /* conn. block will be cleared before rel. indication 
          * is sent to upper layer . 
          * GRS processing can be viewed as circuit 
          * and connection (if present) related processing.
          */
         {
            siActDat(cir->key.k1.cirId, cir->siCon, IEI_CIRRES);
         }
      }
   }

   mntState = cir->transStat[SICIR_MTREMST];
   hwState = cir->transStat[SICIR_HWREMST];

   /* Change the state to "waiting for reset response" as we will
    * be generating SitStaInd to the service user and will be
    * waiting to receive SitStaReq to change the state of this
    * circuit to IDLE.
    */
   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_WTRESRSP);
   SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_WTRESRSP);

   /* If the cirucit was blocked when it received GRS message,
    * then we unblock this circuit. Generate an indication to
    * the service user that the circuit is unblocked.
    */
   {
      SiUpSAPCb *tcb;
      
      tcb = siGetUprCbPtr(cir);

      /* Generate UBL indication in SitStaInd primitive for maintenance
       * block states.
       */
      switch (mntState) 
      {
         case SICIR_ST_REMBLKED: /* Fall Through */
         case SICIR_ST_WTBLKRSP:
            siGenCirEvt(cir, SIT_STA_CIRUBLIND);
            break;
         
         default:
            break;
      }

      /* Generate CGU indication in SitStaInd primitive for hardware
       * block states.
       */
      switch (hwState)
      {
         case SICIR_ST_REMBLKED: /* Fall Through */
         case SICIR_ST_WTBLKRSP:
            {
               SiStaEvnt     staEvt;

               cmMemset((U8 *) &staEvt, (U8)NOTPRSNT, sizeof(SiStaEvnt));
               staEvt.cgsmti.eh.pres          = PRSNT_NODEF;
               staEvt.cgsmti.typeInd.pres     = PRSNT_NODEF;
               staEvt.cgsmti.typeInd.val      = HARDFAIL;
               staEvt.rangStat.eh.pres        = PRSNT_NODEF;
               staEvt.rangStat.range.pres     = PRSNT_NODEF;
               staEvt.rangStat.range.val      = 1;
               staEvt.rangStat.status.pres    = PRSNT_NODEF;
               staEvt.rangStat.status.len     = 1;
               staEvt.rangStat.status.val[0] =  0x01;
                

               SiUiSitStaInd(&tcb->pst, tcb->suId, 0, 0, 
                  cir->cfg.cirId, TRUE, SIT_STA_CGUIND,
                     &staEvt, NULLP);
            }
            break;
         
         default:
            break;
      }
   }      
    ret = ROK;
   if ((cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTBLKACK) ||
       (cir->transStat[SICIR_MTLOCST] == SICIR_ST_LOCBLKED))
   {
#ifdef SI_INDBLO_ON_GRS
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* send the BLO only when the circuit is not involved in a non-single
       * rate call
       */
      if (cir->ctrlMultiRateCir == NULLP)
#endif
      {              
         siSndBLOinReset(cir);
      }         
#endif
      ret = RFAILED;
   }


   RETVALUE(ret);
}


/*
*
*       Fun:   siCirLocE1FSND
*
*       Desc:  action function for group reset response
*              state: waiting for group reset response 
*       Ret:   ROK- ok
*
*       Notes: 
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirLocE1FSND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirLocE1FSND(cir)
SiCirCb *cir;
#endif
{
   TRC3(siCirLocE1FSND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call. If so, find the connection
    * block in the controlling circuit and clear the connection cb 
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* it is a non-single rate call */
      if (cir->ctrlMultiRateCir->siCon)
      {
#ifdef ZI
         ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, 
                      (PTR) cir->ctrlMultiRateCir->siCon);
#endif

         if (cir->ctrlMultiRateCir->siCon->incC.cirId == 
             cir->ctrlMultiRateCir->key.k1.cirId)
            /* si006.220, MODIFIED: clear the connection unconditionally */
            siForceClearIncCon(cir->ctrlMultiRateCir->siCon);
         else 
         {
            if (cir->ctrlMultiRateCir->siCon->outC.cirId == 
                cir->ctrlMultiRateCir->key.k1.cirId)
               /* si006.220, MODIFIED: clear the connection unconditionally */
               siForceClearOutCon(cir->ctrlMultiRateCir->siCon);
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "cir [%#lx] mismatch with out/inc circuit %#lx/%#lx of \
                      cntrl conn in a non-single rate call.\n",
                      cir->ctrlMultiRateCir->key.k1.cirId, 
                      cir->ctrlMultiRateCir->siCon->outC.cirId, 
                      cir->ctrlMultiRateCir->siCon->incC.cirId));  
            } 
         }
      }
   }
   else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   {           
      if (cir->siCon)
      {

#ifdef ZI
         ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) cir->siCon);
#endif

         if (cir->siCon->incC.cirId == cir->key.k1.cirId)
            /* si006.220, MODIFIED: clear the connection unconditionally */
            siForceClearIncCon(cir->siCon);
         else if (cir->siCon->outC.cirId == cir->key.k1.cirId)
            /* si006.220, MODIFIED: clear the connection unconditionally */
            siForceClearOutCon(cir->siCon);
         else  
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                   "cir [%#lx] mismatch with out/inc (%ld/%ld) of conn\n",
                   cir->key.k1.cirId, cir->siCon->outC.cirId, 
                   cir->siCon->incC.cirId)); 
         } 
      }
      /* si006.220, DELETED: this code is reduntant */

   }

   if (cir->transStat[SICIR_MTREMST] == SICIR_ST_WTRESRSP)
      SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_IDLE);
   if (cir->transStat[SICIR_HWREMST] == SICIR_ST_WTRESRSP)
      SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_IDLE);

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
#endif

   if ((cir->transStat[SICIR_MTLOCST] == SICIR_ST_WTBLKACK) ||
       (cir->transStat[SICIR_MTLOCST] == SICIR_ST_LOCBLKED))
      RETVALUE(RFAILED);


   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirRemE20SND
*
*       Desc:  action function for UCIC message
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirRemE20SND
(
SiCirCb *cir
)
#else
PRIVATE S16 siCirRemE20SND(cir)
SiCirCb *cir;
#endif
{
   SiCauseDgn cause;
   S16        ret;
   U8         tmrNum;
   Bool       genReattempt;
   Cntr       i;
   Cntr       j;
   Cntr       k;
   SiRangStat *ranSta;
   U8         mask;
   U8         numOct;
   SiCirKey   key;
   SiIntfCb  *intfCb;
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   SiCon      *ctrlCon;
#endif

   TRC3(siCirRemE20SND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* stop circuit timers */
   siStopAllCirTmr(cir);

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call. If so, find the connection
    * block in the controlling circuit and clear the connection cb
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      ctrlCon = cir->ctrlMultiRateCir->siCon;

      /* it is a non-single rate call */
      if (ctrlCon)
      {
         if (ctrlCon->outC.cirId == cir->ctrlMultiRateCir->key.k1.cirId)
         {
            /* stop all connection timers anyways */
            for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
               if ((ctrlCon->timers[tmrNum].tmrEvnt != TMR_NONE) &&
                   (ctrlCon->timers[tmrNum].tmrEvnt & OUTTYPE))
                  siRmvConTq(ctrlCon, tmrNum);

            /* generate reattempt indication */
            genReattempt = FALSE;
            {
               /* the call hasn't resulted in b/w message yet */
               if (ctrlCon->outC.conState < ST_WTFORANSWR)
                  genReattempt = TRUE;
            }
            /* generate reattempt */
            if (genReattempt == TRUE)
            {
               MFINITELMT(&ctrlCon->mCallCb->mfMsgCtl, ret, NULLP,
                         (ElmtHdr *) &cause, &meCauseIndV, (U8) PRSNT_DEF, 
                         cir->ctrlMultiRateCir->pIntfCb->cfg.swtch, 
                         (U32) MF_ISUP);
                     
               cause.eh.pres       = PRSNT_NODEF;
               cause.causeVal.pres = PRSNT_NODEF;
               cause.causeVal.val  = SIT_CCREQUNAVAIL;
               cause.dgnVal.pres   = PRSNT_NODEF;
               cause.dgnVal.len    = 1;
               cause.dgnVal.val[0] = SIT_STA_CIRUNEQPD;
               siGenReatInd(cir->ctrlMultiRateCir->cfg.cirId, ctrlCon, 
                            &cause);
            }

#ifdef ZI
            ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) ctrlCon);
#endif
            /* clear the connection */
            siClearOutCon(ctrlCon);
         }
         else
         {
            if (ctrlCon->outC.cirId == cir->ctrlMultiRateCir->key.k1.cirId)
            {
               /* stop all connection timers anyways */
               for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
                  if ((ctrlCon->timers[tmrNum].tmrEvnt != TMR_NONE) &&
                      (ctrlCon->timers[tmrNum].tmrEvnt & INC))
                     siRmvConTq(ctrlCon, tmrNum);

#ifdef ZI
         ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) ctrlCon);
#endif
               /* clear the connection */
               siClearIncCon(ctrlCon);
            }
            else
            {
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "circuit %ld is not matching with inc/out %ld/%ldi of\
                      cntrl conn in a non-single rate call\n",
                      cir->ctrlMultiRateCir->key.k1.cirId,
                      cir->ctrlMultiRateCir->siCon->incC.cirId,
                      cir->ctrlMultiRateCir->siCon->outC.cirId));  
            }                    
         }            
      }             
   }
   else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   {           
      /* if there is a connection */
      if (cir->siCon)
      {
         /* clear it */
         if (cir->key.k1.cirId == cir->siCon->outC.cirId)
         {
            /* stop all connection timers anyways */
            for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
               if ((cir->siCon->timers[tmrNum].tmrEvnt != TMR_NONE) &&
                   (cir->siCon->timers[tmrNum].tmrEvnt & OUTTYPE))
                  siRmvConTq(cir->siCon, tmrNum);

            /* generate reattempt indication */
            genReattempt = FALSE;
            {
               /* the call hasn't resulted in b/w message yet */
               if (cir->siCon->outC.conState < ST_WTFORANSWR)
                  genReattempt = TRUE;
            }
            /* generate reattempt */
            if (genReattempt == TRUE)
            {
                MFINITELMT(&cir->siCon->mCallCb->mfMsgCtl, ret, NULLP,
                           (ElmtHdr *) &cause, &meCauseIndV, 
                           (U8) PRSNT_DEF, 
                           cir->siCon->outC.cir->pIntfCb->cfg.swtch, 
                           (U32) MF_ISUP);
                     
                cause.eh.pres       = PRSNT_NODEF;
                cause.causeVal.pres = PRSNT_NODEF;
                cause.causeVal.val  = SIT_CCREQUNAVAIL;
/* si029.220: Addition - added INDIA processing */
#if SS7_INDIA
                if (cir->siCon->tCallCb->cfg.swtch ==
                    LSI_SW_INDIA)
                   cause.dgnVal.pres = NOTPRSNT;
                else
#endif
                {
                   cause.dgnVal.pres   = PRSNT_NODEF;
                   cause.dgnVal.len    = 1;
                   cause.dgnVal.val[0] = SIT_STA_CIRUNEQPD;
                }
                siGenReatInd(cir->cfg.cirId, cir->siCon, &cause);
             }

#ifdef ZI
             ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) cir->siCon);
#endif
             /* clear the connection */
             siClearOutCon(cir->siCon);
         }
         else if (cir->key.k1.cirId == cir->siCon->incC.cirId)
         {
            /* stop all connection timers anyways */
            for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
               if ((cir->siCon->timers[tmrNum].tmrEvnt != TMR_NONE) &&
                   (cir->siCon->timers[tmrNum].tmrEvnt & INC))
                  siRmvConTq(cir->siCon, tmrNum);

#ifdef ZI
            ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) cir->siCon);
#endif
            /* clear the connection */
            siClearIncCon(cir->siCon);
         }
      }
   }

   for (i = 0; i < NUMCIREVTGRP; i++)
   {
      if (cir->cirGr[i] != NULLP)
      {
         siStopCirGrTmr(cir->cirGr[i], TMR_ALL);
/* si035.220 - Modification - If UCIC is received for group msgs, restore the states
                              of all the circuits to the state before sending the group
			      message and mark the circuit on which the UCIC is received as
			      unequipped.
			      There was a race condition earlier. If UCIC was received for 
			      group blocking or any other circuit grp, the CIC on which the 
			      UCIC was received was marked UNEQUIPPED and all other circuits
			      in the group remained in transient state.
*/			      
#ifdef SI_CKTGRP_RANGZERO
         if (cir->cirGr[i].rangStat.range.val == 0)
           {
             U8 tempNumCir;
	     tempNumCir = cir->cirGr[i]->cir->cfg.numCir + 1;
	     key.k2.cic = cir->cirgr[i]->cir->cfg.firstCic;
	     cir->cirGr[i].rangStat.status.len = ((U8)(tempNumCir >> 3)) +
	                                        ((tempNumCir & 0x07) ? 1 : 0);,
	     numOct = cir->cirGr[i].rangStat.status.len;
	     for (j=0; j < numOct; j++)
	      {
	        if (tempNumCir > MAXBITS_IN_OCTET)
	  	  {      
		      cir->cirGr[i].rangStat.status.val[j] = 0xff;
		      tempNumCir = tempNumCir - MAXBITS_IN_OCTET;
                  }
	        else
                   cir->cirGr[i].rangStat.status.val[j] = 0xFF >>
	                                       (MAXBITS_IN_OCTET - tempNumCir);
	      }				       
            }
	  else  
#endif		 
           {
             numOct = cir->cirGr[i]->rangStat.status.len;		   
	     key.k2.cic =  cir->cirGr[i]->cir->key.k2.cic;
	   }
	   key.k2.intfId = cir->cirGr[i]->cir->key.k2.intfId;
           if ((intfCb = cir->cirGr[i]->cir->pIntfCb) == NULLP)
	      {
	        SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
	              "Could not find the interface corresponding to intfId = %lx\n",
	              cir->cirGr[i]->cir->key.k2.intfId));

                RETVALUE(RFAILED);
	      }	

	   ranSta = &cir->cirGr[i]->rangStat;
	   for (j = 0; j < numOct; j++)
	    {
              /* for each field in octet */
	      for (k = 0, mask = 0x01; k < 8; k++, mask <<= 0x01, key.k2.cic++)
	        {
                 /* if range is over */
                 if ( (j*8+k) > cir->cirGr[i]->rangStat.range.val )
                     break;
                 if (ranSta->status.val[j] & mask)
	           {
		     /* find circuit */
		     SiCirCb  *indCir = NULLP;
		     if (siFindCir(&siCb.cirHlCp, &indCir, &key, 0, KEY_CICINTF) == ROK)
                     {
                        SISTATECHNG(indCir->transStat[SICIR_MTLOCST] , SICIR_ST_IDLE);
		        SISTATECHNG(indCir->transStat[SICIR_HWLOCST] , SICIR_ST_IDLE);
		     }
	             ranSta->status.val[j] &= ~mask;
		   }
		 } /* for k */
	     } /* for j */	 
         cir->cirGr[i]->cir = NULLP;
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) cir->cirGr[i], 
                  (Size) sizeof(SiCirGrp));
         cir->cirGr[i] = NULLP;
      }
   }
   /* send status indication to upper layer */
   siGenCirEvt(cir, SIT_STA_CIRUNEQPD);
   /* mark circuit unequipped */
   SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_UNEQPD);
   SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_UNEQPD);
   /* si013.220- Addition: Added following code to mark local states
                           of circuit to idle */
   SISTATECHNG(cir->transStat[SICIR_MTLOCST] , SICIR_ST_IDLE);
   SISTATECHNG(cir->transStat[SICIR_HWLOCST] , SICIR_ST_IDLE);
   /* generate Alarm */
   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId, 
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, LSI_EVENT_REMOTE, 
                  LSI_CAUSE_UNEQP_CIR, TRUE, cir->key.k1.cirId, CIR_UNEQUIP);
 
#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
   ziUpdPeer();
#endif

   RETVALUE(ROK);
}

/*****************************************************************************/
/************************** circuit group functions **************************/
/*****************************************************************************/


/*
*
*       Fun:   siProcCGBREQ
*
*       Desc:  function for processing a CGB request.
*              
*       Ret:   ROK
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siProcCGBREQ
(
SiCirGrp  *cirgr,
SiStaEvnt *staEvnt
)
#else
PRIVATE S16 siProcCGBREQ(cirgr, staEvnt)
SiCirGrp  *cirgr;
SiStaEvnt *staEvnt;
#endif
{
   SiCirKey  key;
   SiCirCb   *cir;
   U8        cirFsmEvt;
   U8        mask;
   U8        i;
   U8        j;
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   SiCirCb   *mCntrlPtrs[SI_MAX_NO_OF_CIR];     /* ptrs array of cntrl CirCb 
                                                   in affected conn */
   SiCon     *siCntrlCon;                       /* conn. of the cntrl CirCb */
   U8        numCkts;                           /* num of cntrl ckts */
   S16       ret;
   U8        counter;
#endif

   TRC3(siProcCGBREQ)

   if (cirgr->cirState == SICIR_MTLOCST)
      cirFsmEvt = CEI_MTCGBREQ;
   else if (cirgr->cirState == SICIR_HWLOCST)
      cirFsmEvt = CEI_HWCGBREQ;
   else
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "circuit state %d is neither MTLOCST nor HWLOCST\n", 
             cirgr->cirState));  
        
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI533, (ErrVal) 0,
                 "siProcCGBREQ(): circuit grp has invalid circuit state type");
#endif
      RETVALUE(RFAILED); 
   }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* initialization */
   for (i = 0; i < SI_MAX_NO_OF_CIR; i++)
      mCntrlPtrs[i] = NULLP;
   siCntrlCon = NULLP;
   numCkts = 0;
   counter = 0;
#endif

   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * Added code over here so that when a CGBReq with range zero is being pro-
 * cessed, the configured "firstCic" value is used as the starting circuit for
 * this group msg, & the "numCir" value is used to fill up the status field
 */
   if (staEvnt->rangStat.range.val == 0)
   {
      U8 tempNumCir;   /* temporary variable for status assignment */
      /*
       * During ckt configuration, numCir is decremented by 1. To allow proper
       * status length calculation, 1 is added over here. firstCic is used as
       * the starting CIC value
       */
      tempNumCir = cirgr->cir->cfg.numCir + 1; 
      key.k2.cic = cirgr->cir->cfg.firstCic;
      /*
       * Status length is calculated by dividing tempNumCir value by 8, and
       * adding 1 if there's a remainder when tempNumCir is divided by 8 
       */
      staEvnt->rangStat.status.len = ((U8)(tempNumCir >> 3)) +
                                     ((tempNumCir & 0x07) ? 1 : 0);
      for (i = 0; i < staEvnt->rangStat.status.len; i++) 
      {
         if (tempNumCir > MAXBITS_IN_OCTET)
         {
            /*
             * If number of circuits to be blocked is greater than the total 
             * number of bits in an octet, the status value octet is filled 
             * with 0xFF
             */
            staEvnt->rangStat.status.val[i] = 0xFF;
            tempNumCir = tempNumCir - MAXBITS_IN_OCTET;
         }
         else
            /*
             * If number of circuits to be blocked is less than the total 
             * number of bits in an octet, the status value octet is filled 
             * with that many 1's
             */
            staEvnt->rangStat.status.val[i] = 0xFF >> 
                                              (MAXBITS_IN_OCTET - tempNumCir);
      }
      /*
       * Nullify status field of cirgr so that its not there in CGB msg.
       */
      cirgr->sduSp->m.siStaEvnt.rangStat.status.pres = NOTPRSNT;
   } 
   else
#endif 
   {    
      key.k2.cic = cirgr->cir->key.k2.cic;
   }
   key.k2.intfId = cirgr->cir->key.k2.intfId;
   /* start the blocking procedure */
   for (i = 0; i < staEvnt->rangStat.status.len; i++)
   {
       cirgr->rangStat.status.val[i] = 0x00;

       /* for each field in octet */
       for (j = 0, mask = 0x01; j < 8; j++, mask <<= 0x01, key.k2.cic++)
       {
          if (staEvnt->rangStat.status.val[i] & mask)
          {
             /* find circuit */
             siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
             /* if circuit not found, generate alarm and exclude the circuit */
             if (cir == NULLP)
             {
                staEvnt->rangStat.status.val[i] &= ~mask; 
                continue;
             }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
             /* check if this circuit involved in a non-single rate call */
             if (cir->ctrlMultiRateCir != NULLP)
             {
                /* it involved in a non-single rate call. Store the
                 * ctrlMultiRateCir in the local array mCntrlPtrs. And set the
                 * flag mulReset to TRUE. When it jumps to the circuit state
                 * matrix funct, it would not process the connection Cb
                 */
                if (siStoreCntrlCir(mCntrlPtrs, cir, &numCkts) != ROK)
                {
                   SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                       "Store the cntrl cir failure when processing cir %ld\n",
                        cir->cfg.cirId));  
                   RETVALUE(RFAILED);
                }

             }                
#endif

             if (siProcCirEvt(cir, cirFsmEvt, TRUE) == ROK)
                /* include in range status */
                cirgr->rangStat.status.val[i] |= mask; 
             else /* exclude it from incoming event */
                staEvnt->rangStat.status.val[i] &= ~mask;
         } 
      } 
   }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if the affected circuit involved in a non-single rate connection
    */
   if (numCkts != 0)
   {
      /* there exists non-single rate connection. Take action here on the
       * connection Cb for each non-single rate call by calling siActDat
       * directly
       */
      ret = siProcMRateinCirGrMsg(mCntrlPtrs, cirFsmEvt, numCkts);
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "Processing non-single conn when recv CGBREQ failed on \
                cir(%#lx).\n", cirgr->cir->cfg.cirId));  
         RETVALUE(RFAILED);
      }
   }
#endif

   /* generating alarm to the layer manager */
   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cirgr->cir->key.k1.cirId, 
                 LSI_USTA_DGNVAL_RANGE, (PTR) &staEvnt->rangStat.range.val, 
                 LSI_USTA_DGNVAL_STATUS_OCTS, 
                 (PTR) &staEvnt->rangStat.status, 
                 LSI_USTA_DGNVAL_NONE,  NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, LSI_EVENT_LOCAL, 
                  LSI_CAUSE_CGB, TRUE, cirgr->cir->key.k1.cirId, 
                  SI_CIRGRP_BLOCK);

   if (siGenCirGrMsg(cirgr, (U8) M_CIRGRPBLK, (U8) MI_CIRGRPBLK) == ROK)
   {
      /* start Group Blocking timer */
      siStartCirGrTmr(TMR_T18, cirgr);
      /* start initial Group Blocking timer */
      siStartCirGrTmr(TMR_T19, cirgr);
      /* change states */
      SISTATECHNG(cirgr->state , SICG_ST_WTCGBACK);
   }

   RETVALUE(ROK);
}


/*
*
*       Fun:   siProcCGUREQ
*
*       Desc:  Function for processing CGU req.
*              
*       Ret:   ROK - ok; RFAILED - failed 
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siProcCGUREQ
(
SiCirGrp *cirgr,
SiStaEvnt *staEvnt
)
#else
PRIVATE S16 siProcCGUREQ(cirgr, staEvnt)
SiCirGrp *cirgr;
SiStaEvnt *staEvnt;
#endif
{
   SiCirKey  key;
   SiCirCb   *cir;
   U8        cirFsmEvt;
   U8        mask;
   U8        i;
   U8        j;

   TRC3(siProcCGUREQ)

   if (cirgr->cirState == SICIR_MTLOCST)
      cirFsmEvt = CEI_MTCGUREQ;
   else if (cirgr->cirState == SICIR_HWLOCST)
      cirFsmEvt = CEI_HWCGUREQ;
   else
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
       "circuit state %d is neither MTLOCST nor HWLOCST\n", cirgr->cirState));  
        
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI534, (ErrVal) 0,
                 "siProcCGBREQ(): circuit grp has invalid circuit state type");
#endif
      RETVALUE(RFAILED); 
   }

   /* for all octets in the event */
   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * Added code over here so that when a CGUReq with range zero is being pro-
 * cessed, the configured "firstCic" value is used as the starting circuit for
 *  this  group msg, & the "numCir" value is used to fill up the status field
 */
   if (staEvnt->rangStat.range.val == 0)
   {
      U8 tempNumCir;    /* temporary variable for status assignment */ 
      /*
       * During ckt configuration, numCir is decremented by 1. To allow proper
       * status length calculation, 1 is added over here. firstCic is used as
       * the starting CIC value
       */
      tempNumCir = cirgr->cir->cfg.numCir + 1;
      key.k2.cic = cirgr->cir->cfg.firstCic;
      /*
       * Status length is calculated by dividing tempNumCir value by 8, and
       * adding 1 if there's a remainder when tempNumCir is divided by 8 
       */
      staEvnt->rangStat.status.len = ((U8)(tempNumCir >> 3)) +
                                     ((tempNumCir & 0x07) ? 1 : 0);
      for (i = 0; i < staEvnt->rangStat.status.len; i++) 
      {
         if (tempNumCir > MAXBITS_IN_OCTET)
         {
            /*
             * If number of circuits to be blocked is greater than the total 
             * number ofbits in an octet, the status value octet is filled 
             * with 0xFF
             */
            staEvnt->rangStat.status.val[i] = 0xFF;
            tempNumCir = tempNumCir - MAXBITS_IN_OCTET;
         }
         else
            /*
             * If number of circuits to be blocked is less than the total 
             * number of bits in an octet, the status value octet is filled 
             * with that many 1's
             */
            staEvnt->rangStat.status.val[i] = 0xFF >> 
                                              (MAXBITS_IN_OCTET - tempNumCir);
      }
      /*
       * Nullify status field of cirgr so that its not there in CGU msg.
       */
      cirgr->sduSp->m.siStaEvnt.rangStat.status.pres = NOTPRSNT;
   }
   else
#endif
   {
      key.k2.cic = cirgr->cir->key.k2.cic;
   }
   key.k2.intfId = cirgr->cir->key.k2.intfId;
   for (i = 0; i < staEvnt->rangStat.status.len; i++)
   {
       cirgr->rangStat.status.val[i] = 0x00;

       /* for each field in octet */
       for (j = 0, mask = 0x01; j < 8; j++, mask <<= 0x01, key.k2.cic++)
       {
          if (staEvnt->rangStat.status.val[i] & mask)
          {
             /* find circuit */
             siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
             if (cir == NULLP)
             {
                /* exclude circuit */
                staEvnt->rangStat.status.val[i] &= ~mask;
                continue;
             }
             if (siProcCirEvt(cir, cirFsmEvt, TRUE) == ROK)
                /* include in range status */
                cirgr->rangStat.status.val[i] |= mask; 
             else /* exclude it from incoming event */
                staEvnt->rangStat.status.val[i] &= ~mask;
         } 
      } /* for j */
   } /* for i */

   if (siGenCirGrMsg(cirgr, (U8) M_CIRGRPUBLK, (U8) MI_CIRGRPUBLK) == ROK)
   {
      /* start Group Unlocking timer */
      siStartCirGrTmr(TMR_T20, cirgr);
      /* start initial Group Unblocking timer */
      siStartCirGrTmr(TMR_T21, cirgr);
      SISTATECHNG(cirgr->state , SICG_ST_WTCGUACK);
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "siGenCirMsg returns failure\n"));  

   } 

   RETVALUE(ROK);  
} /* siProcCGUREQ */


/*
*
*       Fun:   siProcCGB
*
*       Desc:  function for handling CGB message
*              
*       Ret:   ROK - ok; RFAILED -failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siProcCGB
(
SiCirGrp *cirgr,
SiPduCGB  *cgb
)
#else
PRIVATE S16 siProcCGB (cirgr, cgb)
SiCirGrp *cirgr;
SiPduCGB  *cgb;
#endif
{
   SiCirKey  key;
   SiCirCb   *cir;
   SiStaEvnt staEvt;
   SiUpSAPCb *cb;
   SiNSAPCb  *mCb;
   S16       ret;
   U8        cirFsmEvt;
   U8        mask;
   U8        i;
   U8        j;
#ifdef SI_CKTGRP_RANGZERO   
/* si003.220 - Addition. Added a temporary variable for range zero checking.
 */
   U8         k;
#endif   
   SiIntfCb  *intfCb;
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   SiCirCb   *mCntrlPtrs[SI_MAX_NO_OF_CIR];     /* ptrs array of cntrl CirCb in 
                                                   affected conn */
   SiCon     *siCntrlCon;                       /* conn. of the cntrl CirCb */
   U8        numCkts;                           /* num of cntrl ckts */
   U8        counter;
#endif

   TRC3(siProcCGB)

   /* determine the event to be passed to circuit state machine */
   if (cirgr->cirState == SICIR_MTREMST)
      cirFsmEvt = CEI_MTCGB;
   else if (cirgr->cirState == SICIR_HWREMST)
      cirFsmEvt = CEI_HWCGB;
   else
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
       "circuit state %d is neither MTLOCST nor HWLOCST\n", cirgr->cirState));  
        
      RETVALUE(RFAILED); 
   } 

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* initialization */
   for (i = 0; i < SI_MAX_NO_OF_CIR; i++)
      mCntrlPtrs[i] = NULLP;
   siCntrlCon = NULLP;
   numCkts = 0;
   counter = 0;
#endif

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cirgr->cir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* get pointer to the upper control block */
   cb = siGetUprCbPtr(cirgr->cir);

   /* get pointer to the upper control block */
   mCb = siGetLwrMCbPtr(cirgr->cir);

   /* start the blocking procedure */
   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * Added code over here so that when a CGB with range zero is being processed,
 * the configured "firstCic" value is used as the starting circuit for this 
 * group msg. & the "numCir" value is used to fill up the status field
 */
   if (cgb->rangStat.range.val == 0)
   {
      U8 tempNumCir;   /* temporary variable for status assignment */
      /*
       * During ckt configuration, numCir is decremented by 1. To allow proper
       * status length calculation, 1 is added over here. firstCic is used as
       * the starting CIC value
       */
      tempNumCir = cirgr->cir->cfg.numCir + 1;
      key.k2.cic = cirgr->cir->cfg.firstCic;
      /*
       * Status length is calculated by dividing tempNumCir value by 8, and
       * adding 1 if there's a remainder when tempNumCir is divided by 8 
       */
      cgb->rangStat.status.len = ((U8)(tempNumCir >> 3)) +
                                 ((tempNumCir & 0x07) ? 1 : 0);
      for (i = 0; i < cgb->rangStat.status.len; i++) 
      {
         if (tempNumCir > MAXBITS_IN_OCTET)
         {
            /*
             * If number of circuits to be blocked is greater than the total 
             * number of bits in an octet, the status value octet is filled 
             * with 0xFF
             */
            cgb->rangStat.status.val[i] = 0xFF;
            tempNumCir = tempNumCir - MAXBITS_IN_OCTET;
         }
         else
            /*
             * If number of circuits to be blocked is less than the total 
             * number of bits in an octet, the status value octet is filled 
             * with that many 1's
             */
            cgb->rangStat.status.val[i] = 0xFF >> 
                                              (MAXBITS_IN_OCTET - tempNumCir);
      }
      /*
       * Nullify status presence field so that its not passed in CGB Indication
       */
      cgb->rangStat.status.pres = NOTPRSNT;
   }
   else
#endif
   {
      key.k2.cic = cirgr->cir->key.k2.cic;
   }
   key.k2.intfId = cirgr->cir->key.k2.intfId;

   if ((intfCb = cirgr->cir->pIntfCb) == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "Could not find the interface corresponding to intfId = %lx\n",
             cirgr->cir->key.k2.intfId));  
        
      RETVALUE(RFAILED);
   }
   /* Generate Status Indication to Upper Layer */
   MFINITSDU(&cb->mfMsgCtl, ret, (U8) MI_CIRGRPBLK, (U8) SI_STAREQ,
             (ElmtHdr *) cgb, (ElmtHdr *) &staEvt, (U8) PRSNT_NODEF, 
             intfCb->cfg.swtch, (U32) MF_ISUP);

   /* send status indication to the upper layer */
   if (cb && (cb->state == SI_BND)) 
      SiUiSitStaInd(&cb->pst, cb->suId, 0, 0, cirgr->cir->key.k1.cirId,
                    TRUE, SIT_STA_CGBINFOIND, &staEvt, NULLP);

   for (i = 0; i < cgb->rangStat.status.len; i++)
   {
      cirgr->rangStat.status.val[i] = 0x00;
#ifdef SI_CKTGRP_RANGZERO     
/* si003.220 -  Modification. Modified code so that when the range is zero,
 * the upper range of the for loop will be effective range.
 */
      /* si031.220: Modification - changed algorithm of (val+1)%8 to 
       * (val%8)+1. If val is a number of 8*n - 1, (val+1)%8 results in
       * a value of 0, however (val%8)+1 results in a value of 8. So if 
       * circuit range value is 23 or 31, the last octet in status will
       * not be processed using algorithm (val+1)%8. Therefore changed 
       * to (val%8)+1.  
       */
      if (cgb->rangStat.range.val)
      {
         k = (i == (cgb->rangStat.status.len-1))?((cgb->rangStat.range.val%8)+1):8;
      }
      else
      {
         k = (i == (cgb->rangStat.status.len-1))?((cirgr->cir->cfg.numCir%8)+1):8;
      }
       /* for each field in octet */
       /* Block all the CIC's according to the status value */
       for (j = 0, mask = 0x01; j < k; 
            j++, mask <<= 0x01, key.k2.cic++)
#else
       /* si006.220, MODIFIED: modified code to handle the last byte in status 
        * correctly
        */
       for (j = 0, mask = 0x01; j <= ((i == (cgb->rangStat.status.len-1))?
            ((cgb->rangStat.range.val)%8):7); j++, mask <<= 0x01, key.k2.cic++)
#endif
       {
          if (cgb->rangStat.status.val[i] & mask)
          {
             /* find circuit */
             siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
             if (cir == NULLP)
             {
                /* cic in the routing label is equipped, however some cic 
                 * in the range are not equipped, ISUP should process it as if 
                 * they are equipped.  
                 * However, for ANSI 92 and ANS95, ISUP may optionally send 
                 * UCIC for each of the cics that are unequipped. 
                 */
                cgb->rangStat.status.val[i] &= ~mask; /* exclude circuit */
                continue;
             }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
             /* check if this circuit involved in a non-single rate call */
             if (cir->ctrlMultiRateCir != NULLP)
             {
                /* it involved in a non-single rate call. Store the
                 * ctrlMultiRateCir in the local array mCntrlPtrs. And set the
                 * flag mulReset to TRUE. When it jumps to the circuit state
                 * matrix funct, it would not process the connection Cb
                 */
                if (siStoreCntrlCir(mCntrlPtrs, cir, &numCkts) != ROK)
                {
                   SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                       "Store the cntrl cir failure when processing cir %ld\n",
                        cir->cfg.cirId));  
                   RETVALUE(RFAILED);
                }
             }                
#endif
             if (siProcCirMsg(cir, cirFsmEvt, TRUE) == ROK)
                /* include in range status */
                cirgr->rangStat.status.val[i] |= mask; 
             else /* exclude it from incoming event */
                cgb->rangStat.status.val[i] &= ~mask;
         } 
      } /* for j */
   } /* for i */

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if the affected circuit involved in a non-single rate connection
    */
   if (numCkts != 0)
   {
      /* there exists non-single rate connection. Take action here on the
       * connection Cb for each non-single rate call by calling siActDat
       * directly
       */
      ret = siProcMRateinCirGrMsg(mCntrlPtrs, cirFsmEvt, numCkts);
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "Processing non-single conn when recv circuit ralated msg failed.\n"));  
         RETVALUE(RFAILED);
      }
   }
#endif

   /* generating alarm to the layer manager */
   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                 (PTR) &cirgr->cir->key.k1.cirId, 
                 LSI_USTA_DGNVAL_RANGE, (PTR) &cgb->rangStat.range.val, 
                 LSI_USTA_DGNVAL_STATUS_OCTS, (PTR) &cgb->rangStat.status, 
                 LSI_USTA_DGNVAL_NONE,  NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, LSI_EVENT_REMOTE, 
                  LSI_CAUSE_CGB, TRUE, cirgr->cir->key.k1.cirId, 
                  SI_CIRGRP_BLOCK);

   /* change state */
   SISTATECHNG(cirgr->state , SICG_ST_WTCGBRSP);

   /* Generate Status Indication to Upper Layer */
   MFINITSDU(&cb->mfMsgCtl, ret, (U8) MI_CIRGRPBLK, (U8) SI_STAREQ,
             (ElmtHdr *) cgb, (ElmtHdr *) &staEvt, (U8) PRSNT_NODEF, 
             intfCb->cfg.swtch, (U32) MF_ISUP);

   /* send status indication to the upper layer */
   if (cb && (cb->state == SI_BND)) 
      SiUiSitStaInd(&cb->pst, cb->suId, 0, 0, cirgr->cir->key.k1.cirId,
                    TRUE, SIT_STA_CGBIND, &staEvt, NULLP);

   RETVALUE(ROK);
}


/*
*
*       Fun:   siProcGRS
*
*       Desc:  action for circuit group reset message
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siProcGRS
(
SiCirGrp *cirgr,            /* circuit group block */
SiPduGRS *grs               /* pointer to grs msg */
)
#else
PRIVATE S16 siProcGRS(cirgr, grs)
SiCirGrp *cirgr;            /* circuit group block */
SiPduGRS *grs;              /* pointer to grs msg */
#endif
{
   SiCirKey   key;          /* key structure */
   SiRangStat hRangStat;    /* placeholder for h/w loc. blked ckts */
   SiStaEvnt  staEvt;       /* status event structure */
   SiCirCb    *cir;         /* circuit control block */
   SiUpSAPCb  *tCb;         /* upper SAP control block */
   SiNSAPCb   *mCb;         /* lower SAP control block */
   S16        ret;          /* return value */
   U8         numOct;       /* number of bytes frm range value */
   U8         numHBlk;      /* hw block state flag */
   U8         i;            /* counter */
   U8         mask;         /* mask */
   U8         effRange;     /* The effective range in case of GRS */
   SiIntfCb  *intfCb;       /* interface control block */
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   SiCirCb   *mCntrlPtrs[SI_MAX_NO_OF_CIR];     
                            /* ptrs array of cntrl CirCb in affected conn */
   U8        numCkts;       /* num of cntrl ckts */
#endif


   TRC3(siProcGRS)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (grs == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "siProcGRS() failed, pointer to grs is missing \n")); 
      SILOGERROR(ERRCLS_DEBUG, ESI535, (ErrVal )0,
                "siProcGRS() failed, pointer to grs missing \n");
      RETVALUE(RFAILED);
   }
   if (cirgr == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "siProcGRS() failed, ptr to circuit group control blk missing\n"));
      SILOGERROR(ERRCLS_DEBUG, ESI536, (ErrVal )0,
                "siProcGRS() failed, ptr to cirgr missing \n");
      RETVALUE(RFAILED);
   }
   if(siChkCirIntf(cirgr->cir) != ROK)
      RETVALUE(RFAILED);
#endif

   numOct = ((U8)(grs->rangStat.range.val+1) >> 3) +
            (((grs->rangStat.range.val+1) & 0x07) ? 1 : 0);

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* initialization */
   for (i = 0; i < SI_MAX_NO_OF_CIR; i++)
      mCntrlPtrs[i] = NULLP;
   numCkts = 0;
#endif

   /* get pointer to the lower control block */
   mCb = siGetLwrMCbPtr(cirgr->cir);

   /* get the interface control block */
   intfCb = cirgr->cir->pIntfCb;
   numHBlk = 0;
   effRange = 0;
   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
   key.k2.intfId = cirgr->cir->key.k2.intfId;


   /* initialize range and status for h/w CGB (if needed) to zero */
   cmMemset((U8 *)&hRangStat, (U8) PRSNT_DEF, sizeof(SiRangStat));

   {           
      /* Check the range value */
      if (grs->rangStat.range.val)
      {
         /* If the range is non-zero, then use this circuit's CIC value
          * as the starting cirucit for this group message. Effective
          * range is same as that received in the message.
          */
         key.k2.cic = cirgr->cir->key.k2.cic;
         effRange = grs->rangStat.range.val;
      }

      for (i = 0; i <= effRange; i++, key.k2.cic++)
      {
         mask = (0x01 << (i & 0x07));
         siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
         if (cir == NULLP)
         {
            /* cic in the routing label is equipped, however some cics 
             * in the range are not equipped, ISUP should process it as if 
             * they are equipped. ITU 92, 2.12, GR-317-CORE, R3-179. 
             * For ANSI 92, ISUP may optionally send UCIC for each of
             * the cics that are unequipped. ANSI92, 2.9.8.3A
             */
             continue;
         }
     
         /* no flow control logic is necessary */
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* check if this circuit involved in a non-single rate call */
         if (cir->ctrlMultiRateCir != NULLP)
         {
            /* it involved in a non-single rate call. Store the
             * ctrlMultiRateCir in the local array mCntrlPtrs. And set the
             * flag mulReset to TRUE. When it jumps to the circuit state
             * matrix funct, it would not process the connection Cb
             */
            if (siStoreCntrlCir(mCntrlPtrs, cir, &numCkts) != ROK)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                       "Store the cntrl cir failure when processing cir %ld\n",
                        cir->cfg.cirId));  
               RETVALUE(RFAILED);
            }
         }                
#endif
         ret = siProcCirMsg(cir, CEI_GRS, TRUE);

         /* As per ANS92 & 95 specs, T1.113-1992, 1995,
          * section 2.9.3.2, point 3, if the range field is codes as
          * all zero, should send a h/w CGB if circuit is hw blocked. 
          */
         {
            /* h/w locally blocked? */
            if ((cir->transStat[SICIR_HWLOCST] == SICIR_ST_LOCBLKED) ||
                (cir->transStat[SICIR_HWLOCST] == SICIR_ST_WTBLKACK))
            {
               switch (cir->pIntfCb->cfg.swtch)
               {
                  default:
                     numHBlk++;
                     hRangStat.status.val[(i >> 0x03)] |= mask;
               }
            }
            else
            {
               hRangStat.status.val[(i >> 0x03)] &= ~mask;
            }
         }

         /* As per ANS92 & 95 specs, T1.113-1992, 1995,
          * section 2.9.3.2, point 3, if the range field is codes as
          * all zero, should send a mnt CGB if circuit is mnt blocked. 
          */
      }  
   }

      
   /* As per ANS92 & 95 specs, T1.113-1992, 1995,
    * section 2.9.3.2, point 3, if the range field is codes as
    * all zero, should send a h/w CGB if circuit is hw blocked. 
    */
   {
      /* send CGB */
      if (numHBlk > 0)
      {
         hRangStat.range.val   = effRange;
         hRangStat.eh.pres     = PRSNT_NODEF;
         hRangStat.range.pres  = PRSNT_NODEF;
         hRangStat.status.pres = PRSNT_NODEF;
         hRangStat.status.len  = (effRange >> 0x03) + 1;

         /* For ANS92 & ANS95, should send the CGB
          * on the fisrt cic of predetermined group
          */
            cir = cirgr->cir;

         siSndCGBinReset(SICIR_HWLOCST, cir, &hRangStat, mCb);
      }
   }

   /* Check to see if need to send mnt CGB for range value
    * is zero for ANS92 and ANS95 variant, if so, send a mnt CGB msg
    */

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if the affected circuit involved in a non-single rate connection
    */
   if (numCkts != 0)
   {
      /* there exists non-single rate connection. Take action here on the
       * connection Cb for each non-single rate call by calling siActDat
       * directly
       */
      ret = siProcMRateinCirGrMsg(mCntrlPtrs, CEI_GRS, numCkts);
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "Processing non-single conn when recv circuit ralated msg failed.\n"));  
         RETVALUE(RFAILED);
      }

   }
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */

   /* change state */
   SISTATECHNG(cirgr->state , SICG_ST_WTCGRRSP);
   /* get pointer to the upper control block */
   tCb = siGetUprCbPtr(cirgr->cir);

   /* Generate and send Status Indication to Upper Layer */
   MFINITSDU(&tCb->mfMsgCtl, ret, (U8) MI_CIRGRPRES, (U8) SI_STAREQ,
             (ElmtHdr *) grs, (ElmtHdr *) &staEvt, (U8) PRSNT_NODEF, 
             cirgr->cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);

   /* send status indication to the call control */
   if (tCb && (tCb->state == SI_BND)) 
      SiUiSitStaInd(&tCb->pst, tCb->suId, 0, 0, cirgr->cir->key.k1.cirId,
                    TRUE, SIT_STA_GRSIND, &staEvt, NULLP);

   RETVALUE(ROK);
} /* end of siProcGRS */

/*
*
*       Fun:   siProcCGU
*
*       Desc:  action for circuit group unblock message
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siProcCGU
(
SiCirGrp *cirgr,
SiPduCGU *cgu
)
#else
PRIVATE S16 siProcCGU(cirgr, cgu)
SiCirGrp *cirgr;
SiPduCGU *cgu;
#endif
{
   SiCirKey  key;
   SiCirCb   *cir;
   SiStaEvnt staEvt;
   SiUpSAPCb *cb;
   SiNSAPCb  *mCb;
   S16       ret;
   U8        cirFsmEvt;
   U8        mask;
   U8        i;
   U8        j;
   SiIntfCb  *intfCb;

   TRC3(siProcCGU)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cirgr->cir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* get pointer to the upper control block */
   cb = siGetUprCbPtr(cirgr->cir);

   /* get pointer to the upper control block */
   mCb = siGetLwrMCbPtr(cirgr->cir);

   /* determine the event to be passed to circuit state machine */
   if (cirgr->cirState == SICIR_MTREMST)
      cirFsmEvt = CEI_MTCGU;
   else if (cirgr->cirState == SICIR_HWREMST)
      cirFsmEvt = CEI_HWCGU;
   else
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
       "circuit state %d is neither MTLOCST nor HWLOCST\n", cirgr->cirState));  
        
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI537, (ErrVal) 0,
                 "siProcCGU(): Invalid type indicator");
#endif
      RETVALUE(RFAILED); 
   }

   /* start the unblocking procedure */
   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * Added code over here so that when a CGU with range zero is being processed,
 * the configured "firstCic" value is used as the starting circuit for this 
 * group msg, & the "numCir" value is used to fill up the status field
 */
   if (cgu->rangStat.range.val == 0)
   {
      U8 tempNumCir;   /* temporary variable for status assignment */
      /*
       * During ckt configuration, numCir is decremented by 1. To allow proper
       * status length calculation, 1 is added over here. firstCic is used as
       * the starting CIC value
       */
      tempNumCir = cirgr->cir->cfg.numCir + 1;
      key.k2.cic = cirgr->cir->cfg.firstCic;
      /*
       * Status length is calculated by dividing tempNumCir value by 8, and
       * adding 1 if there's a remainder when tempNumCir is divided by 8 
       */
      cgu->rangStat.status.len = ((U8)(tempNumCir >> 3)) +
                                 ((tempNumCir & 0x07) ? 1 : 0);
      for (i = 0; i < cgu->rangStat.status.len; i++) 
      {
         if (tempNumCir > MAXBITS_IN_OCTET)
         {
            /*
             * If number of circuits to be blocked is greater than the total 
             * number of bits in an octet, the status value octet is filled 
             * with 0xFF
             */
            cgu->rangStat.status.val[i] = 0xFF;
            tempNumCir = tempNumCir - MAXBITS_IN_OCTET;
         }
         else
            /*
             * If number of circuits to be blocked is less than the total 
             * number of bits in an octet, the status value octet is filled 
             * with that many 1's
             */
            cgu->rangStat.status.val[i] = 0xFF >> 
                                              (MAXBITS_IN_OCTET - tempNumCir);
      }
      /*
       * Nullify status field of cgu so that its not there in CGU Indication
       */
      cgu->rangStat.status.pres = NOTPRSNT;
   }
   else
#endif
   {
      key.k2.cic = cirgr->cir->key.k2.cic;
   }
   key.k2.intfId = cirgr->cir->key.k2.intfId;
   if ((intfCb = cirgr->cir->pIntfCb) == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "Could not find the interface corresponding to intfId = %lx\n",
             cirgr->cir->key.k2.intfId));  
        
      RETVALUE(RFAILED);
   }
   for (i = 0; i < cgu->rangStat.status.len; i++)
   {
       cirgr->rangStat.status.val[i] = 0x00;

       /* for each field in octet */
       /* block all the CIC's according to the status value */
       /* si006.220, MODIFIED: modified code to handle the last byte in status 
        * correctly
        */
       for (j = 0, mask = 0x01; j <= ((i == (cgu->rangStat.status.len-1))?
            ((cgu->rangStat.range.val)%8):7); j++, mask <<= 0x01, key.k2.cic++)
       {
          if (cgu->rangStat.status.val[i] & mask)
          {
             /* find circuit */
             siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
             if (cir == NULLP)
             {
                cgu->rangStat.status.val[i] &= ~mask; /* exclude circuit */

                /* cic in the routing label is equipped, however some cic 
                 * in the range are not equipped, ISUP should process it as if 
                 * they are equipped.  
                 * However, for ANSI 92 and ANS95, ISUP may optionally send 
                 * UCIC for each of the cics that are unequipped. 
                 */
                continue;
             }
             if (siProcCirMsg(cir, cirFsmEvt, TRUE) == ROK)
                /* include in range status */
                cirgr->rangStat.status.val[i] |= mask; 
             else /* exclude it from incoming event */
                cgu->rangStat.status.val[i] &= ~mask;
         } 
      } 
   }

   /* change state */
   SISTATECHNG(cirgr->state , SICG_ST_WTCGURSP);

   /* Generate Status Indication to Upper Layer */
   MFINITSDU(&cb->mfMsgCtl, ret, (U8) MI_CIRGRPUBLK, (U8) SI_STAREQ,
             (ElmtHdr *) cgu, (ElmtHdr *) &staEvt, (U8) PRSNT_NODEF, 
             intfCb->cfg.swtch, (U32) MF_ISUP);
 
   /* send status indication to the upper layer */
   if (cb && (cb->state == SI_BND))
      SiUiSitStaInd(&cb->pst, cb->suId, 0, 0, cirgr->cir->key.k1.cirId,
                    TRUE, SIT_STA_CGUIND, &staEvt, NULLP);

   RETVALUE(ROK);
}


/*
*
*       Fun:   siGenCirSteInd
*
*       Desc:  generate circuit state indicators
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siGenCirSteInd
(
SiCirGrp      *cirgr, 
SiCirStateInd *cirState,
U8             evnt
)
#else
PRIVATE S16 siGenCirSteInd(cirgr, cirState, evnt)
SiCirGrp     *cirgr;
SiCirStateInd *cirState;
U8             evnt; /* whether CQM (TRUE) or CQMReq (FALSE)*/
#endif
{
   SiCirKey key;
   SiCirCb  *cir;
   Cntr     i;

   TRC3(siGenCirSteInd)
   UNUSED(evnt);
   cmMemset((U8 *) cirState, (U8) NOTPRSNT, sizeof(SiCirStateInd));
   cirState->eh.pres        = PRSNT_NODEF;
   cirState->cirSteInd.pres = PRSNT_NODEF;
   cirState->cirSteInd.len  = 0;

   /* initialize the key */
   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
   key.k2.cic = cirgr->cir->key.k2.cic;
   key.k2.intfId = cirgr->cir->key.k2.intfId;

   for (i = 0; i <= (Cntr) cirgr->querRange; i++)
   {
      cirState->cirSteInd.len++;
      cirState->cirSteInd.val[i] = 0x00; /* initialize the status array */

      siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
      siGetCirState(cir, &cirState->cirSteInd.val[i]);
      key.k2.cic++;
   }

   RETVALUE(ROK);
}
/**************************************************************************/
/***************** circuit group state machine functions ******************/
/**************************************************************************/


/*
*
*       Fun:   siCirGrRETFAIL
*
*       Desc:  dummy function for returning failure for circuit group events
*              
*       Ret:   RFAILED - failed
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrRETFAIL
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrRETFAIL(cirgr)
SiCirGrp *cirgr;
#endif
{
   Cntr i;

   TRC3(siCirGrRETFAIL)

   /* we are not expecting any acks for this circuit group */
   if (cirgr->state == SICG_ST_IDLE)
   {
      for (i = 0; i < NUMCIREVTGRP; i++)
      {
         if (cirgr->cir->cirGr[i] == cirgr)
         {
            siStopCirGrTmr(cirgr, TMR_ALL);
            cirgr->cir->cirGr[i] = NULLP;
            SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) cirgr, 
                     (Size) sizeof(SiCirGrp));
            break;
         }
      }
   }
   RETVALUE(RFAILED);
}


/*
*
*       Fun:   siCirGrE00S00
*
*       Desc:  Action function mntc./hardware oriented CGB request 
*       States:idle.
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: One function is sufficient for mntc/hardware because of 
*              mutual exclusivity
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE00S00
(
SiCirGrp *cirgr
) 
#else
PRIVATE S16 siCirGrE00S00 (cirgr)
SiCirGrp *cirgr;
#endif
{
   SiStaEvnt *staEvnt;
   SiCirGrp  *tmpCirGr;
   S16       ret;

   TRC3(siCirGrE00S00)

   staEvnt = (SiStaEvnt *)&cirgr->sduSp->m.siStaEvnt;

   /* check if there is a GRS event pending if its a h/w CGBREQ */
   switch (staEvnt->cgsmti.typeInd.val & 0x03) 
   {
      case HARDFAIL:
         tmpCirGr = cirgr->cir->cirGr[SICIR_MTLOCST];
         if ((tmpCirGr != NULLP) && (tmpCirGr->state == SICG_ST_WTCGRACK))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "Invalid CGBREQ: cirGr existing & state is WTCGRACK\n"));
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                          (PTR) &cirgr->cir->key.k1.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_INVCGBREQ, TRUE, 
                           cirgr->cir->key.k1.cirId, SI_ALRM_INVCGBREQ);
            cirgr->cir->cirGr[cirgr->cirState] = NULLP;
            SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
                     (Size) sizeof(SiCirGrp));
            RETVALUE(RFAILED);
         }

      /*** fall through ****/
      case MAINT:
         cirgr->cgsmti.eh.pres      = PRSNT_NODEF;
         cirgr->cgsmti.typeInd.pres = PRSNT_NODEF;
         cirgr->cgsmti.typeInd      = staEvnt->cgsmti.typeInd;
         cirgr->rangStat.eh.pres    = PRSNT_NODEF;
         cirgr->rangStat.range.pres = staEvnt->rangStat.range.pres;
         cirgr->rangStat.range.val  = staEvnt->rangStat.range.val;
         cirgr->rangStat.status.pres= staEvnt->rangStat.status.pres;
         cirgr->rangStat.status.len = staEvnt->rangStat.status.len;
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "Type %d is neither mntce nor hw\n",
                   staEvnt->cgsmti.typeInd.val & 0x03));  
         RETVALUE(RFAILED);
   }

   ret = siProcCGBREQ(cirgr, staEvnt);

   RETVALUE(ret);
} /* siCirGrE00SND */


/*
*
*       Fun:   siCirGrE00S01
*
*       Desc:  Process mntc/hardware oriented CGB request
*       States:Waiting for CGB ack; 
*       States:Waiting for CGU ack; 
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: the new request is dropped if its not for the same circuit
*              group as the previous request. One function is sufficient
*              for maintenance/hardware because of mutual exclusivity
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE00S01
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE00S01 (cirgr)
SiCirGrp *cirgr;
#endif
{
   SiStaEvnt *staEvnt;
   SiCirGrp  *tmpCirGr;
   S16       ret;

   TRC3(siCirGrE00S01)

   staEvnt = (SiStaEvnt *)&cirgr->sduSp->m.siStaEvnt;

   switch (staEvnt->cgsmti.typeInd.val & 0x03)
   {
      case HARDFAIL:
         /* check if there is a GRS event pending if its a h/w CGBREQ */
         /**** THIS SHOULD NEVER OCCUR *****/
         tmpCirGr = cirgr->cir->cirGr[SICIR_MTLOCST];
         if ((tmpCirGr != NULLP) &&(tmpCirGr->state == SICG_ST_WTCGRACK))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "Invalid CGBREQ: cirGr existing & state is WTCGRACK\n"));

#if (ERRCLASS & ERRCLS_DEBUG)
            SILOGERROR(ERRCLS_DEBUG, ESI538, (ErrVal) 0,
                       "siCirGrE00S01(): Group reset being processed");
#endif
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                          (PTR) &cirgr->cir->key.k1.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_INVCGBREQ, TRUE, 
                           cirgr->cir->key.k1.cirId, SI_ALRM_INVCGBREQ);
            siStopCirGrTmr(cirgr, TMR_ALL);
            cirgr->cir->cirGr[cirgr->cirState] = NULLP;
            SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
                     (Size) sizeof(SiCirGrp));
            RETVALUE(RFAILED);
         }
      
      /***** fall through ****/
      case MAINT:
         break;

     default:
        SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "Type %d is neither mntce nor hw\n",
                   staEvnt->cgsmti.typeInd.val & 0x03));  
        RETVALUE(RFAILED);
   }

   /* if its the same CGBREQ process it; else DROP IT */
   if (cirgr->rangStat.range.val == staEvnt->rangStat.range.val)
   {
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * If the range of CGBReq is zero, do not call siCmpStatus, as the status 
 * field will not be present
 */
      if (cirgr->rangStat.range.val == 0)
         ret = SIEQLSET; /* ret is assigned to SIEQLSET to call siProcCGBREQ */
      else /* if range != 0 */
#endif
      {
         ret = siCmpStatus(cirgr->rangStat.range.val, cirgr->rangStat.status.val,
                        staEvnt->rangStat.range.val, 
                        staEvnt->rangStat.status.val, NULLP, NULLP);
      }
      if (ret == SIEQLSET)
      {
         siStopCirGrTmr(cirgr, TMR_ALL);
         ret = siProcCGBREQ(cirgr, staEvnt);
         RETVALUE(ret);
      }
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "range in event %d and in cirgr %d does not match\n",
                staEvnt->rangStat.range.val, cirgr->rangStat.range.val));  

      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cirgr->cir->key.k1.cirId, 
                     LSI_USTA_DGNVAL_NONE, NULLP, 
                     LSI_USTA_DGNVAL_NONE, NULLP, 
                     LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                     LSI_EVENT_REMOTE, LSI_CAUSE_INV_RANGE, TRUE, 
                     cirgr->cir->key.k1.cirId, SI_ALRM_INVCGBREQ);
   } 
   RETVALUE(RFAILED);
} /* siCirGrE00S01 */


/*
*
*       Fun:   siCirGrE00S03
*
*       Desc:  Process mntc/hardware oriented CGB request.
*              state: waiting for GRA
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE00S03
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE00S03 (cirgr)
SiCirGrp *cirgr;
#endif
{
   SiStaEvnt *staEvnt;

   TRC3(siCirGrE00S03)

   staEvnt = (SiStaEvnt *)&cirgr->sduSp->m.siStaEvnt;

   switch (staEvnt->cgsmti.typeInd.val & 0x03)
   {
      /* hardware local states can never be in the state waiting for GRA */
      case HARDFAIL:
         siStopCirGrTmr(cirgr, TMR_ALL);
         cirgr->cir->cirGr[cirgr->cirState] = NULLP;
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
                  (Size) sizeof(SiCirGrp));
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI539, (ErrVal) 0,
                    "siCirGrE00S03(): Invalid hardware local state");
#endif
      /***** fall through *****/
      case MAINT:
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cirgr->cir->key.k1.cirId, 
                        LSI_USTA_DGNVAL_NONE, NULLP, 
                        LSI_USTA_DGNVAL_NONE, NULLP, 
                        LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                        LSI_EVENT_REMOTE, LSI_CAUSE_INVCGBREQ, TRUE, 
                        cirgr->cir->key.k1.cirId, SI_ALRM_INVCGBREQ);
      
      /***** fall through *****/
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "Type %d is neither mntce nor hw\n",
                   staEvnt->cgsmti.typeInd.val & 0x03));  
         break;
   }
   RETVALUE(RFAILED);
} /* siCirGrE00S03 */



/*
*
*       Fun:   siCirGrE01S00
*
*       Desc:  action func. for mntc/hw. CGBA
*              States: idle 
*       Ret:   
*
*       Notes: 
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE01S00
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE01S00(cirgr)
SiCirGrp *cirgr;
#endif
{
   SiCirKey  key;
   SiCirCb   *cir;
   SiPduCGBA *cgba;
   SiNSAPCb  *mCb;
   Bool      end;
   U8        mask;
   U8        i;
   U8        j;
   TknStr    effSts; /* Effective status */
   SiIntfCb  *intfCb;

   TRC3(siCirGrE01S00)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cirgr->cir) != ROK)
      RETVALUE(RFAILED);
#endif

   cgba   = (SiPduCGBA *)&cirgr->pduSp->m.cirGrpBlkAck;

   mCb    = siGetLwrMCbPtr(cirgr->cir);

   /* process circuits */
   end = FALSE;
   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * Added code over here so that when a CGBA with range zero is being processed,
 * the configured "firstCic" value is used as the starting circuit for this 
 * group msg, & the "numCir" value is used to fill up the status field
 */
   if (cgba->rangStat.range.val == 0)
   {
      U8 tempNumCir;   /* temporary variable for status assignment */
      /*
       * During ckt configuration, numCir is decremented by 1. To allow proper
       * status length calculation, 1 is added over here. firstCic is used as
       * the starting CIC value
       */
      tempNumCir = cirgr->cir->cfg.numCir + 1;
      key.k2.cic = cirgr->cir->cfg.firstCic;
      /*
       * Status length is calculated by dividing tempNumCir value by 8, and
       * adding 1 if there's a remainder when tempNumCir is divided by 8 
       */
      cgba->rangStat.status.len = ((U8)(tempNumCir >> 3)) +
                                  ((tempNumCir & 0x07) ? 1 : 0);
      for (i = 0; i < cgba->rangStat.status.len; i++) 
      {
         if (tempNumCir > MAXBITS_IN_OCTET)
         {
            /*
             * If number of circuits to be blocked is greater than the total 
             * number of bits in an octet, the status value octet is filled
             * with 0xFF
             */
            cgba->rangStat.status.val[i] = 0xFF;
            tempNumCir = tempNumCir - MAXBITS_IN_OCTET;
         }
         else
            /*
             * If number of circuits to be blocked is less than the total 
             * number of bits in an octet, the status value octet is filled 
             * with that many 1's
             */
            cgba->rangStat.status.val[i] = 0xFF >> 
                                              (MAXBITS_IN_OCTET - tempNumCir);
      }
   }
   else
#endif
   {
      key.k2.cic = cirgr->cir->key.k2.cic;
   }
   key.k2.intfId = cirgr->cir->key.k2.intfId;
   if ((intfCb = cirgr->cir->pIntfCb) == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "Could not find the interface corresponding to intfId = %lx\n",
             cirgr->cir->key.k2.intfId));  
        
      RETVALUE(RFAILED);
   }
   cmMemset((U8 *)&effSts, '\0', sizeof(TknStr));
   effSts.len = cgba->rangStat.status.len;
   for (i = 0; i < cgba->rangStat.status.len; i++)
   {
      if (end == TRUE)
         break;

      /* for each field in octet */
      for (j = 0, mask = 0x01; j < 8; j++, mask <<= 0x01, key.k2.cic++)
      {
         /* if range is over */
         if ( (i*8+j) > cgba->rangStat.range.val )
            break;
         if (cgba->rangStat.status.val[i] & mask)
         {
            /* find circuit */
            siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
            if (cir == NULLP)
            {
               /* cic in the routing label is equipped, however some cic 
                * in the range are not equipped, ISUP should process it as if 
                * they are equipped.  
                * However, for ANSI 92 and ANS95, ISUP may optionally send 
                * UCIC for each of the cics that are unequipped. 
                */
               continue;
            }
            /* if any of the circuits are not locally blked generate alarm */
            if (cir->transStat[cirgr->cirState] != SICIR_ST_LOCBLKED)
            {
               effSts.val[i] |= mask;
            }
         } 
      } /* for j */
   } /* for i */
   /* Now check if there is any circuit in unexpected state */
   for(i = 0; i < effSts.len; i++)
   {
      if( effSts.val[i] )
      {

         /* Take action on basis of variant */  
         switch (intfCb->cfg.swtch)
         {
            default:
/* si039.220 : pointer cir replaced with cirgr->cir. cir ptr may be 
               uninitialized pointer and can cause CPU crash
*/ 
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                             (PTR) &cirgr->cir->key.k1.cirId,
                             LSI_USTA_DGNVAL_EVENT, (PTR) &cirgr->cir->fsmEvnt,
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                              LSI_EVENT_REMOTE, LSI_CAUSE_CIR_MNTACK, TRUE, 
                              cirgr->cir->key.k1.cirId, SI_CG_INVACK);
               break;
         }
         RETVALUE(ROK);
      }
   }
   if (cirgr->querPrcs == FALSE)
   {
      cirgr->cir->cirGr[cirgr->cirState] = NULLP;
      SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
               (Size)sizeof(SiCirGrp));
   }

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirGrE01S01
*
*       Desc:  action function for mntc. CGBA.
*              State: waiting for CGBA
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE01S01
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE01S01(cirgr)
SiCirGrp *cirgr;
#endif
{
   U8        retStatus[4];
/* si019.220: Addition - add intersect status */
   TknStr    intStatus;
   SiCirKey  key;
   SiStaEvnt staEvnt;
   SiUpSAPCb *cb;
   SiNSAPCb  *mCb;
   SiCirCb   *cir;
   SiPduCGBA *cgba;
   S16       ret;
   Bool      found;
   U8        cirFsmEvt;
   U8        mask;
   U8        i;
   U8        j;
   SiIntfCb  *intfCb;
   U8        procStatus;

   TRC3(siCirGrE01S01)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cirgr->cir) != ROK)
      RETVALUE(RFAILED);
#endif

   cgba   = (SiPduCGBA *)&cirgr->pduSp->m.cirGrpBlkAck;

   /* get pointer to the upper control block */
   cb = siGetUprCbPtr(cirgr->cir);

   /* get pointer to the upper control block */
   mCb = siGetLwrMCbPtr(cirgr->cir);

   if ((intfCb = cirgr->cir->pIntfCb) == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "Could not find the interface corresponding to intfId = %lx\n",
             cirgr->cir->key.k2.intfId));  
        
      RETVALUE(RFAILED);
   }

   /* check if range values are the same */
   if (cirgr->rangStat.range.val != cgba->rangStat.range.val)
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "range in event %d and in cirgr %d does not match\n",
                cgba->rangStat.range.val, cirgr->rangStat.range.val));  
      RETVALUE(RFAILED);
   } 

   /* compare incoming status in the ack with the one in the request */
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * If the range of the CGBA is zero, do not call siCmpStatus, as the status 
 * field will not be present
 */
   if (cgba->rangStat.range.val == 0)
      /* ret value set to SIEQLSET to bypass siCmpStatus & switch statement */
      ret = SIEQLSET;
   else /* if range != 0 */
#endif
   {
/* si019.220: modify - pass intStatus instead of NULLP */
      ret = siCmpStatus(cirgr->rangStat.range.val, cirgr->rangStat.status.val,
                        cgba->rangStat.range.val, cgba->rangStat.status.val, 
                        intStatus.val, retStatus);
   }
   switch (ret)
   {
      /* hey! that's not for me! */
      case SIDISJNT:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siCmpStatus returns SIDISJNT.Returning failure\n"));  
         /* As per Bellcore spec GR-317, sec 3.1.4.3, R3-173,
          * should notify the maintenance
          */             
         /* si018.220: modification - modify diagnostic value so that circuit
          * range and status are also included in the alarm. */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cirgr->cir->key.k1.cirId,
                       LSI_USTA_DGNVAL_RANGE, (PTR) &cirgr->rangStat.range.val, 
                       LSI_USTA_DGNVAL_STATUS_OCTS, 
                       (PTR) &cirgr->rangStat.status,
                       LSI_USTA_DGNVAL_EVENT, (PTR) &cirgr->cir->fsmEvnt 
                      );
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                        LSI_EVENT_REMOTE, LSI_CAUSE_CIR_MNTACK, 
                        TRUE, cirgr->cir->key.k1.cirId, SI_CG_INVACK);
         RETVALUE(RFAILED);

      /* process additional circuits */
      case SISUBSET:
      case SIINTSECT:
         found = FALSE;
         cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
         key.k2.cic = cirgr->cir->key.k2.cic;
         key.k2.intfId = cirgr->cir->key.k2.intfId;
/* si019.220: Addition - process alarm if it is SIINTSECT. For citcuits
   which should be blocked but are not blocked in CGBA message */
         if (ret == SIINTSECT)
         {
            /* build up the status fields for the circuits not 
               blocked in CGBA however should be block in CGB.
             */
            intStatus.len = cirgr->rangStat.status.len;
            for (i = 0; i < cirgr->rangStat.status.len; i++)
            {
               /* overwrite the intersect status array */
               intStatus.val[i] = ~(intStatus.val[i]) & cirgr->rangStat.status.val[i]; 
            }

            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cirgr->cir->key.k1.cirId,
                          LSI_USTA_DGNVAL_RANGE, (PTR) &cirgr->rangStat.range.val, 
                          LSI_USTA_DGNVAL_STATUS_OCTS, (PTR) &intStatus,
                          LSI_USTA_DGNVAL_EVENT, (PTR) &cirgr->cir->fsmEvnt 
                         );
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CIR_MNTACK, 
                           TRUE, cirgr->cir->key.k1.cirId, SI_CG_INVACK);

         }

         /* some additional circuits are marked blocked in CGBA which are not
            specified in the CGB message, processing alarms. */
         for (i = 0; i < cgba->rangStat.status.len; i++)
         {
/* si019.220: deletion - remove found check to allow the alarms generated 
   for each of the circuits that are blocked in the CGBA however not 
   specified in the CGB message.
*/
            /* for each field in octet */
            for (j = 0, mask = 0x01; j < 8; j++, mask <<= 0x01, key.k2.cic++)
            {
               if (retStatus[i] & mask)
               {
                  /* find circuit */
                  siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
                  if (cir == NULLP)
                  {
                     /* cic in the routing label is equipped, however some cic 
                      * in the range are not equipped, ISUP should process it 
                      * as if they are equipped.  
                      * However, for ANSI 92 and ANS95, ISUP may optionally
                      * send UCIC for each of the cics that are unequipped. 
                      */
                     continue;
                  }
                  /* found one which is not in a blocking state!! */
                  if ((cir->transStat[cirgr->cirState] != SICIR_ST_WTBLKACK) ||
                      (cir->transStat[cirgr->cirState] != SICIR_ST_LOCBLKED))
                  {
                     siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                                   (PTR) &cir->key.k1.cirId,
                                   LSI_USTA_DGNVAL_EVENT, 
                                   (PTR) &cirgr->cir->fsmEvnt, 
                                   LSI_USTA_DGNVAL_NONE, NULLP, 
                                   LSI_USTA_DGNVAL_NONE, NULLP);
                     SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                                    LSI_EVENT_REMOTE, LSI_CAUSE_CIR_MNTACK, 
                                    TRUE, cir->key.k1.cirId, SI_CG_INVACK);
#if (SI_LMINT3 || SMSI_LMINT3)
                     siUpdErrSts(cirgr->cir, LSI_STS_ABNRMLCGBA);
#endif
/* si019.220: deletion - remove found check to allow the alarms generated 
   for each of the circuits that are blocked in the CGBA however not 
   specified in the CGB message.
*/
                  }  
               } 
               
            } /* for j */
         } /* for i */
         break;

      /* if all the circuits in the request are not present */
      case SISUPSET:
/* si019.220: modify - process alarm to allow the status fields constaining 
   only the circuits which are not acknowledged */
         intStatus.len = cirgr->rangStat.status.len;
         for (i = 0; i < cirgr->rangStat.status.len; i++)
         {
            /* overwrite the intersect status array */
            intStatus.val[i] = ~(intStatus.val[i]) & cirgr->rangStat.status.val[i]; 
         }
         /* si018.220: modification - modify diagnostic value so that circuit
          * range and status are also included in the alarm. */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cirgr->cir->key.k1.cirId,
                       LSI_USTA_DGNVAL_RANGE, (PTR) &cirgr->rangStat.range.val, 
                       LSI_USTA_DGNVAL_STATUS_OCTS, (PTR) &intStatus,
                       LSI_USTA_DGNVAL_EVENT, (PTR) &cirgr->cir->fsmEvnt 
                      );
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                        LSI_EVENT_REMOTE, LSI_CAUSE_CIR_MNTACK, TRUE, 
                        cirgr->cir->key.k1.cirId, SI_CG_INVACK);
#if (SI_LMINT3 || SMSI_LMINT3)
         siUpdErrSts(cirgr->cir, LSI_STS_NOCGBA);
#endif
         break;
   }

   siStopCirGrTmr(cirgr, TMR_T18);
   siStopCirGrTmr(cirgr, TMR_T19);

   if (cirgr->cirState == SICIR_MTLOCST)
      cirFsmEvt = CEI_MTCGBA;
   else if (cirgr->cirState == SICIR_HWLOCST)
      cirFsmEvt = CEI_HWCGBA;
   else
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
       "circuit state %d is neither MTLOCST nor HWLOCST\n", cirgr->cirState));  
        
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI540, (ErrVal) cirgr->cirState,
                 "siCirGrE01S01(): invalid circuit state in circuit group");
#endif
      RETVALUE(RFAILED); 
   }
 
   /* send block acks to all the circuits anyways */
   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * Added code over here so that when a CGBA with range zero is being processed,
 * the configured "firstCic" value is used as the starting circuit for this 
 * group msg, & the "numCir" value is used to fill up the status field
 */
   if (cgba->rangStat.range.val == 0)
   {
      U8 tempNumCir;   /* temporary variable for status assignment */
      /*
       * During ckt configuration, numCir is decremented by 1. To allow proper
       * status length calculation, 1 is added over here. firstCic is used as
       * the starting CIC value
       */
      tempNumCir = cirgr->cir->cfg.numCir + 1;
      key.k2.cic = cirgr->cir->cfg.firstCic;
      /*
       * Status length is calculated by dividing tempNumCir value by 8, and
       * adding 1 if there's a remainder when tempNumCir is divided by 8 
       */
      cgba->rangStat.status.len = ((U8)(tempNumCir >> 3)) +
                                  ((tempNumCir & 0x07) ? 1 : 0);
      for (i = 0; i < cgba->rangStat.status.len; i++) 
      {
         if (tempNumCir > MAXBITS_IN_OCTET)
         {
            /*
             * If number of circuits to be blocked is greater than the total 
             * number of bits in an octet, the status value octet is filled 
             * with 0xFF
             */
            cgba->rangStat.status.val[i] = 0xFF;
            tempNumCir = tempNumCir - MAXBITS_IN_OCTET;
         }
         else
            /*
             * If number of circuits to be blocked is less than the total 
             * number of bits in an octet, the status value octet is filled 
             * with that many 1's
             */
            cgba->rangStat.status.val[i] = 0xFF >> 
                                              (MAXBITS_IN_OCTET - tempNumCir);
      }
      /*
       * Nullify status field of cgba so that its not there in CGBA Indication
       */
      cgba->rangStat.status.pres = NOTPRSNT;
   }
   else
#endif
   {
      key.k2.cic = cirgr->cir->key.k2.cic;
   }
   key.k2.intfId = cirgr->cir->key.k2.intfId;
   for (i = 0; i < cgba->rangStat.status.len; i++)
   {
      switch (ret)
      {
         case SISUBSET:
            procStatus = cirgr->rangStat.status.val[i];
            break;
         case SISUPSET:
         case SIEQLSET:
            procStatus = cgba->rangStat.status.val[i];
            break;
         case SIINTSECT:
            procStatus = cirgr->rangStat.status.val[i] &
                            cgba->rangStat.status.val[i];
            break;
         default:    /* case SIDISJNT */
            procStatus = 0;
            break;
      }
      for (j = 0, mask = 0x01; j < 8; j++, mask <<= 0x01, key.k2.cic++)
      {
         if (procStatus & mask)
         {
            /* find circuit */
            siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
            if (cir == NULLP)
            {
               /* cic in the routing label is equipped, however some cic 
                * in the range are not equipped, ISUP should process it as if 
                * they are equipped.  
                * However, for ANSI 92 and ANS95, ISUP may optionally send 
                * UCIC for each of the cics that are unequipped. 
                */
               continue;
            }
            siProcCirMsg(cir, cirFsmEvt, TRUE);
         }
      }
   }

   /* Generate Circuit Group Block Confirm */
   MFINITSDU(&cb->mfMsgCtl, ret, (U8) MI_CIRGRPBLKACK, (U8) SI_STAREQ,
             (ElmtHdr *) cgba, (ElmtHdr *) &staEvnt,
             (U8) PRSNT_NODEF, intfCb->cfg.swtch, (U32) MF_ISUP);

   if (cb && (cb->state == SI_BND))
      SiUiSitStaInd(&cb->pst, cb->suId, 0, 0, cirgr->cir->key.k1.cirId, FALSE,
                    SIT_STA_CGBCFM, &staEvnt, NULLP);

   if (cirgr->querPrcs == FALSE)
   {
      cirgr->cir->cirGr[cirgr->cirState] = NULLP;
      /* deallocate Circuit Group Control Block */
      SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
               (Size)sizeof(SiCirGrp));
   }

#ifdef ZI
   ziUpdPeer();
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirGrE02S00
*
*       Desc:  Action function for Mntc./Hardware oriented CGU request
*       States:idle
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE02S00
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE02S00 (cirgr)
SiCirGrp *cirgr;
#endif
{
   SiStaEvnt *staEvnt;
   SiCirGrp  *tmpCirGr;
   S16       ret;

   TRC3(siCirGrE02S00)

   staEvnt = (SiStaEvnt *)&cirgr->sduSp->m.siStaEvnt;

   /* if hardware oriented unblocking check if there is a pending GRS */
   switch (staEvnt->cgsmti.typeInd.val & 0x03)
   {
      /* if there is a pending GRS for h/w CGUREQ, then DROP IT */ 
      case HARDFAIL:
         tmpCirGr = cirgr->cir->cirGr[SICIR_MTLOCST];
         if ((tmpCirGr != NULLP) && (tmpCirGr->state == SICG_ST_WTCGRACK))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "Invalid CGBREQ: cirGr existing & state is WTCGRACK\n"));

            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                          (PTR) &cirgr->cir->key.k1.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CGUREQ, TRUE, 
                           cirgr->cir->key.k1.cirId, SI_ALRM_INVCGBREQ);
            
            cirgr->cir->cirGr[cirgr->cirState] = NULLP;
            SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
                     (Size) sizeof(SiCirGrp));
            RETVALUE(RFAILED);
         }

      /***** fall through *****/
      case MAINT:
         cirgr->cgsmti.eh.pres      = PRSNT_NODEF;
         cirgr->cgsmti.typeInd.pres = PRSNT_NODEF;
         cirgr->cgsmti.typeInd      = staEvnt->cgsmti.typeInd;
         cirgr->rangStat.eh.pres    = PRSNT_NODEF;
         cirgr->rangStat.range.pres = staEvnt->rangStat.range.pres;
         cirgr->rangStat.range.val  = staEvnt->rangStat.range.val;
         cirgr->rangStat.status.pres= staEvnt->rangStat.status.pres;
         cirgr->rangStat.status.len = staEvnt->rangStat.status.len;
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "Type %d is neither mntce nor hw\n",
                   staEvnt->cgsmti.typeInd.val & 0x03));  
         RETVALUE(RFAILED);
   }

   ret = siProcCGUREQ(cirgr, staEvnt);
   RETVALUE(ret);
} /* siCirGrE02SND */


/*
*
*       Fun:   siCirGrE02S01
*
*       Desc:  Action function for Mntc./Hardware oriented CGU request
*       States:waiting for CGBA/waiting for CGUA
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE02S01
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE02S01 (cirgr)
SiCirGrp *cirgr;
#endif
{
   SiStaEvnt *staEvnt;
   SiCirGrp  *tmpCirGr;
   S16       ret;

   TRC3(siCirGrE02S01)

   staEvnt = (SiStaEvnt *)&cirgr->sduSp->m.siStaEvnt;

   switch (staEvnt->cgsmti.typeInd.val & 0x03) 
   {
      case HARDFAIL:
         tmpCirGr = cirgr->cir->cirGr[SICIR_MTLOCST];
         if ((tmpCirGr != NULLP) && (tmpCirGr->state == SICG_ST_WTCGRACK))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "Invalid CGBREQ: cirGr existing & state is WTCGRACK\n"));

#if (ERRCLASS & ERRCLS_DEBUG)
            SILOGERROR(ERRCLS_DEBUG, ESI541, (ErrVal) 0,
                       "siCirGrE02S01(): GRSREQ being processed");
#endif
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                          (PTR) &cirgr->cir->key.k1.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CGUREQ, TRUE, 
                           cirgr->cir->key.k1.cirId, SI_ALRM_INVCGBREQ);

            cirgr->cir->cirGr[cirgr->cirState] = NULLP;
            SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
                     (Size) sizeof(SiCirGrp));
            RETVALUE(RFAILED);
         }

      case MAINT:
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "Type %d is neither mntce nor hw\n",
                   staEvnt->cgsmti.typeInd.val & 0x03));  
         RETVALUE(RFAILED);
   }

   /* range should match */
   if (cirgr->rangStat.range.val == staEvnt->rangStat.range.val)
   {
      /* status bits should be the same */
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * If the range of the CGUReq is zero, do not call siCmpStatus, as the 
 * status field will not be present
 */
      if (cirgr->rangStat.range.val == 0)
         ret = SIEQLSET; /* ret is assigned to SIEQLSET to call siProcCGUREQ */
      else /* if range != 0 */
#endif
      {
         ret = siCmpStatus(cirgr->rangStat.range.val,    cirgr->rangStat.status.val,
                        staEvnt->rangStat.range.val, 
                        staEvnt->rangStat.status.val, NULLP, NULLP);
      }
      if (ret == SIEQLSET)
      {
         siStopCirGrTmr(cirgr, TMR_ALL);
         ret = siProcCGUREQ(cirgr, staEvnt);
         RETVALUE(ret);
      }
   } 
   else
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "range in event %d and in cirgr %d does not match\n",
                staEvnt->rangStat.range.val, cirgr->rangStat.range.val));  

      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cirgr->cir->key.k1.cirId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                     LSI_EVENT_INV_RANGE, LSI_CAUSE_CGUREQ, TRUE, 
                     cirgr->cir->key.k1.cirId, SI_ALRM_INVCGBREQ);
   } 
   RETVALUE(RFAILED);
} /* siCirGrE02S01 */


/*
*
*       Fun:   siCirGrE02S03
*
*       Desc:  Action function for Mntc./Hardware CGU request
*       States:waiting for GRA
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE02S03
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE02S03 (cirgr)
SiCirGrp *cirgr;
#endif
{
   SiStaEvnt *staEvnt;

   TRC3(siCirGrE02S03)

   staEvnt = (SiStaEvnt *)&cirgr->sduSp->m.siStaEvnt;

   switch (staEvnt->cgsmti.typeInd.val & 0x03)
   {
      /* hardware local states can never be in the state waiting for GRA */
      case HARDFAIL:
         siStopCirGrTmr(cirgr, TMR_ALL);
         cirgr->cir->cirGr[cirgr->cirState] = NULLP;
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
                  (Size) sizeof(SiCirGrp));
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI542, (ErrVal) 0,
                    "siCirGrE00S03(): Invalid hardware local state");
#endif
      /***** fall through *****/
      case MAINT:
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR)&cirgr->cir->key.k1.cirId,
                        LSI_USTA_DGNVAL_NONE, NULLP, 
                        LSI_USTA_DGNVAL_NONE, NULLP, 
                        LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                        LCM_EVENT_INV_STATE, LSI_CAUSE_CGUREQ, TRUE, 
                        cirgr->cir->key.k1.cirId, SI_ALRM_INVCGBREQ);
      
      /***** fall through *****/
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "Type %d is neither mntce nor hw\n",
                   staEvnt->cgsmti.typeInd.val & 0x03));  
         break;
   }
   RETVALUE(RFAILED);

} /* siCirGrE02S03 */


/*
*
*       Fun:   siCirGrE03S00
*
*       Desc:  action function for CGUA
*              State: idle 
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE03S00
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE03S00(cirgr)
SiCirGrp *cirgr;
#endif
{  
   SiCirKey  key;
   SiCirCb   *cir;
   SiPduCGUA *cgua;
   SiNSAPCb  *mCb;
   U8        numOct;
   U8        mask;
   U8        i;
   U8        j;
   TknStr    effSts; /* Effective status */
   SiIntfCb  *intfCb;

   TRC3(siCirGrE03S00)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cirgr->cir) != ROK)
      RETVALUE(RFAILED);
#endif

   cgua   = (SiPduCGUA *)&cirgr->pduSp->m.cirGrpUblkAck;
   /* si013.220, Change: Modified code to check if range value is
                         is 255 */
   numOct = (U8)((cgua->rangStat.range.val+1) >> 3) +
                (U8)(((cgua->rangStat.range.val+1) & 0x07) ? 1 : 0);

   mCb = siGetLwrMCbPtr(cirgr->cir);

   siStopCirGrTmr(cirgr, TMR_T20);
   siStopCirGrTmr(cirgr, TMR_T21);
   /* if any of circuits are not locally blocked generate alarm */
   cmMemset((U8 *) &key, '\0', sizeof(SiCirKey));
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * Added code over here so that when a CGUA with range zero is being processed,
 * the configured "firstCic" value is used as the starting circuit for this 
 * group msg, & the "numCir" value is used to fill up the status field
 */
   if (cgua->rangStat.range.val == 0)
   {
      U8 tempNumCir;   /* temporary variable for status assignment */
      /*
       * During ckt configuration, numCir is decremented by 1. To allow proper
       * status length calculation, 1 is added over here. firstCic is used as
       * the starting CIC value
       */
      tempNumCir = cirgr->cir->cfg.numCir + 1;
      key.k2.cic = cirgr->cir->cfg.firstCic;
      /*
       * Status length is calculated by dividing tempNumCir value by 8, and
       * adding 1 if there's a remainder when tempNumCir is divided by 8 
       */
      cgua->rangStat.status.len = ((U8)(tempNumCir >> 3)) +
                                  ((tempNumCir & 0x07) ? 1 : 0);
      numOct = cgua->rangStat.status.len;
      for (i = 0; i < cgua->rangStat.status.len; i++) 
      {
         if (tempNumCir > MAXBITS_IN_OCTET)
         {
            /*
             * If number of circuits to be blocked is greater than the total 
             * number of bits in an octet, the status value octet is filled 
             * with 0xFF
             */
            cgua->rangStat.status.val[i] = 0xFF;
            tempNumCir = tempNumCir - MAXBITS_IN_OCTET;
         }
         else
            /*
             * If number of circuits to be blocked is less than the total 
             * number of bits in an octet, the status value octet is filled 
             * with that many 1's
             */
            cgua->rangStat.status.val[i] = 0xFF >> 
                                              (MAXBITS_IN_OCTET - tempNumCir);
      }
   }
   else
#endif
   {
      key.k2.cic = cirgr->cir->key.k2.cic;
   }
   key.k2.intfId = cirgr->cir->key.k2.intfId;
   if ((intfCb = cirgr->cir->pIntfCb) == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "Could not find the interface corresponding to intfId = %lx\n",
             cirgr->cir->key.k2.intfId));  
        
      RETVALUE(RFAILED);
   }
   cmMemset((U8 *)&effSts, '\0', sizeof(TknStr));
   effSts.len = cgua->rangStat.status.len;
   for (i = 0; i < numOct; i++)
   {
      /* for each field in octet */
      for (j = 0, mask = 0x01; j < 8; j++, mask <<= 0x01, key.k2.cic++)
      {
         /* if range is over */
         if ( (i*8+j) > cgua->rangStat.range.val )
            break;
         if (cgua->rangStat.status.val[i] & mask)
         {
            /* find circuit */
            siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
            if (cir == NULLP)
            {
               /* cic in the routing label is equipped, however some cic 
                * in the range are not equipped, ISUP should process it as if 
                * they are equipped.  
                * However, for ANSI 92 and ANS95, ISUP may optionally send 
                * UCIC for each of the cics that are unequipped. 
                */
               continue;
            }
            if( cir->transStat[cirgr->cirState] != SICIR_ST_IDLE )
            {
               effSts.val[i] |= mask;
            }
         } 
      } /* for j */
   } /* for i */
   /* Now check if there is any circuit in unexpected state */
   for(i = 0; i < effSts.len; i++)
   {
      if( effSts.val[i] )
      {

         /* Take action on basis of variant */  
         switch (intfCb->cfg.swtch)
         {
            default:
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->key.k1.cirId,
                             LSI_USTA_DGNVAL_EVENT, (PTR) &cirgr->cir->fsmEvnt,
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                              LSI_EVENT_REMOTE, LSI_CAUSE_CIR_MNTACK, TRUE, 
                              cirgr->cir->key.k1.cirId, SI_CG_INVACK);
               break;
         }
         RETVALUE(ROK);
      }
   }
   if (cirgr->querPrcs == FALSE)
   {
      cirgr->cir->cirGr[cirgr->cirState] = NULLP;
      SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
               (Size)sizeof(SiCirGrp));
   }
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirGrE03S02
*
*       Desc:  action function for CGUA
*              states: waiting for CGUA 
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE03S02
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE03S02(cirgr)
SiCirGrp *cirgr;
#endif
{
   U8        retStatus[4];
/* si019.220: Addtion - add intersect status */
   TknStr    intStatus;
   SiCirKey  key;
   SiStaEvnt staEvnt;
   SiUpSAPCb *cb;
   SiNSAPCb  *mCb;
   SiCirCb   *cir;
   SiPduCGUA *cgua;
   S16       ret;
   Bool      found;
   U8        cirFsmEvt;
   U8        numOct;
   U8        mask;
   U8        i;
   U8        j;
   SiIntfCb  *intfCb;
   U8        procStatus;

   TRC3(siCirGrE03S02)

   cgua   = (SiPduCGUA *)&cirgr->pduSp->m.cirGrpUblkAck;
   /* si013.220, Change: Modified code to check if range value is
                         is 255 */
   numOct = (U8)((cgua->rangStat.range.val+1) >> 3) +
                (U8)(((cgua->rangStat.range.val+1) & 0x07) ? 1 : 0);

   /* get pointer to the upper control block */
   cb = siGetUprCbPtr(cirgr->cir);

   /* get pointer to the upper control block */
   mCb = siGetLwrMCbPtr(cirgr->cir);

   if ((intfCb = cirgr->cir->pIntfCb) == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "Could not find the interface corresponding to intfId = %lx\n",
             cirgr->cir->key.k2.intfId));  
        
      RETVALUE(RFAILED);
   }

   /* check if range values are the same */
   if (cirgr->rangStat.range.val != cgua->rangStat.range.val)
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "range in event %d and in cirgr %d does not match\n",
                cgua->rangStat.range.val, cirgr->rangStat.range.val));  
      RETVALUE(RFAILED);
   } 

   /* compare incoming status in the ack with the one in the request */
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * If the range of the CGUA is zero, do not call siCmpStatus, as the 
 * status field will not be present
 */
   if (cgua->rangStat.range.val == 0)
      /* ret value set to SIEQLSET to bypass siCmpStatus & switch statement */
      ret = SIEQLSET;
   else /* if range != 0 */
#endif
   {
/* si019.220: modify - pass intStatus instead of NULLP */
      ret = siCmpStatus(cirgr->rangStat.range.val, cirgr->rangStat.status.val,
                        cgua->rangStat.range.val, cgua->rangStat.status.val, 
                        intStatus.val, retStatus);
   }

   switch (ret)
   {
      /* hey! that's not for me! */
      case SIDISJNT:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siCmpStatus returns SIDISJNT.Returning failure\n"));  
         /* As per Bellcore specs, GR-317, sec 3.1.4.3,R3-174
          * should notify the maintenence
          */             
         /* si018.220: modification - modify diagnostic value so that circuit
          * range and status are also included in the alarm. */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cirgr->cir->key.k1.cirId,
                       LSI_USTA_DGNVAL_RANGE, (PTR) &cirgr->rangStat.range.val, 
                       LSI_USTA_DGNVAL_STATUS_OCTS, 
                       (PTR) &cirgr->rangStat.status,
                       LSI_USTA_DGNVAL_EVENT, (PTR) &cirgr->cir->fsmEvnt 
                      );
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                        LSI_EVENT_REMOTE, LSI_CAUSE_CIR_MNTACK, 
                        TRUE, cirgr->cir->key.k1.cirId, SI_CG_INVACK);
           
         RETVALUE(RFAILED);

      /* process additional circuits */
      case SISUBSET:
      case SIINTSECT:
         found  = FALSE;
         cmMemset((U8 *) &key, '\0', sizeof(SiCirKey));
         key.k2.cic = cirgr->cir->key.k2.cic;
         key.k2.intfId = cirgr->cir->key.k2.intfId;
/* si019.220: Addition - process alarm if it is SIINTSECT. For citcuits
   which should be unblocked but are not unblocked in CGUA message */
         if (ret == SIINTSECT)
         {
            /* build up the status fields for the circuits not 
               unblocked in CGUA however should be unblocked in CGU.
             */
            intStatus.len = cirgr->rangStat.status.len;
            for (i = 0; i < cirgr->rangStat.status.len; i++)
            {
               /* overwrite the intersect status array */
               intStatus.val[i] = ~(intStatus.val[i]) & cirgr->rangStat.status.val[i]; 
            }

            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cirgr->cir->key.k1.cirId,
                          LSI_USTA_DGNVAL_RANGE, (PTR) &cirgr->rangStat.range.val, 
                          LSI_USTA_DGNVAL_STATUS_OCTS, (PTR) &intStatus,
                          LSI_USTA_DGNVAL_EVENT, (PTR) &cirgr->cir->fsmEvnt 
                         );
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CIR_MNTACK, 
                           TRUE, cirgr->cir->key.k1.cirId, SI_CG_INVACK);

         }

         /* some additional circuits are marked unblocked in CGUA which are not
            specified in the CGU message, processing alarms. */
         for (i = 0; i < numOct; i++)
         {
/* si019.220: deletion - remove found check to allow the alarms generated 
   for each of the circuits that are unblocked in the CGUA however not 
   specified in the CGU message.
*/
            /* for each field in octet */
            for (j = 0, mask = 0x01; j < 8; j++, mask <<= 0x01, key.k2.cic++)
            {
               /* if range is over */
               if ( (i*8+j) > cgua->rangStat.range.val )
                  break;
               if (retStatus[i] & mask)
               {
                  /* find circuit */
                  siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
                  if (cir == NULLP)
                  {
                     /* cic in the routing label is equipped, however some cic 
                      * in the range are not equipped, ISUP should process it 
                      * as if they are equipped.  
                      * However, for ANSI 92 and ANS95, ISUP may optionallyi
                      * send UCIC for each of the cics that are unequipped. 
                      */
                     continue;
                  }
                  /* found one which is not in a blocking state!! */
                  if (cir->transStat[cirgr->cirState] != SICIR_ST_WTUBLACK) 
                  {
                     siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                                   (PTR) &cir->key.k1.cirId,
                                   LSI_USTA_DGNVAL_EVENT, 
                                   (PTR) &cirgr->cir->fsmEvnt, 
                                   LSI_USTA_DGNVAL_NONE, NULLP, 
                                   LSI_USTA_DGNVAL_NONE, NULLP);
                     SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                                    LSI_EVENT_REMOTE, LSI_CAUSE_CIR_MNTACK, 
                                    TRUE, cir->key.k1.cirId, SI_CG_INVACK);

#if (SI_LMINT3 || SMSI_LMINT3)
                     siUpdErrSts(cirgr->cir, LSI_STS_ABNRMLCGUA);
#endif
/* si019.220: deletion - remove found check to allow the alarms generated 
   for each of the circuits that are unblocked in the CGUA however not 
   specified in the CGU message.
*/
                  }  
               } 
            }
         }
         break;

      /* if all the circuits in the request are not present */
      case SISUPSET:
/* si019.220: modify - process alarm to allow the status fields constaining 
   only the circuits which are not acknowledged */
         intStatus.len = cirgr->rangStat.status.len;
         for (i = 0; i < cirgr->rangStat.status.len; i++)
         {
            /* overwrite the intersect status array */
            intStatus.val[i] = ~(intStatus.val[i]) & cirgr->rangStat.status.val[i]; 
         }
         /* si018.220: modification - modify diagnostic value so that circuit
          * range and status are also included in the alarm. */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cirgr->cir->key.k1.cirId,
                       LSI_USTA_DGNVAL_RANGE, (PTR) &cirgr->rangStat.range.val, 
                       LSI_USTA_DGNVAL_STATUS_OCTS, (PTR) &intStatus,
                       LSI_USTA_DGNVAL_EVENT, (PTR) &cirgr->cir->fsmEvnt 
                      );
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                        LSI_EVENT_REMOTE, LSI_CAUSE_CIR_MNTACK, TRUE, 
                        cirgr->cir->key.k1.cirId, SI_CG_INVACK);
#if (SI_LMINT3 || SMSI_LMINT3)
         siUpdErrSts(cirgr->cir, LSI_STS_NOCGUA);
#endif
         break;
   }

   siStopCirGrTmr(cirgr, TMR_T20);
   siStopCirGrTmr(cirgr, TMR_T21);

   if (cirgr->cirState == SICIR_MTLOCST)
      cirFsmEvt = CEI_MTCGUA;
   else if (cirgr->cirState == SICIR_HWLOCST)
      cirFsmEvt = CEI_HWCGUA;
   else
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
       "circuit state %d is neither MTLOCST nor HWLOCST\n", cirgr->cirState));  
        
      RETVALUE(RFAILED); 
   } 
   cmMemset ((U8 *)&key, '\0', sizeof(SiCirKey));
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * Added code over here so that when a CGUA with range zero is being processed,
 * the configured "firstCic" value is used as the starting circuit for this 
 * group msg, &  the "numCir" value is used to fill up the status field
 */
   if (cgua->rangStat.range.val == 0)
   {
      U8 tempNumCir;   /* temporary variable for status assignment */
      /*
       * During ckt configuration, numCir is decremented by 1. To allow proper
       * status length calculation, 1 is added over here. firstCic is used as
       * the starting CIC value
       */
      tempNumCir = cirgr->cir->cfg.numCir + 1;
      key.k2.cic = cirgr->cir->cfg.firstCic;
      /*
       * Status length is calculated by dividing tempNumCir value by 8, and
       * adding 1 if there's a remainder when tempNumCir is divided by 8 
       */
      cgua->rangStat.status.len = ((U8)(tempNumCir >> 3)) +
                                  ((tempNumCir & 0x07) ? 1 : 0);
      numOct = cgua->rangStat.status.len;
      for (i = 0; i < cgua->rangStat.status.len; i++) 
      {
         if (tempNumCir > MAXBITS_IN_OCTET)
         {
            /*
             * If number of circuits to be blocked is greater than the total 
             * number of bits in an octet, the status value octet is filled 
             * with 0xFF
             */
            cgua->rangStat.status.val[i] = 0xFF;
            tempNumCir = tempNumCir - MAXBITS_IN_OCTET;
         }
         else
            /*
             * If number of circuits to be blocked is less than the total 
             * number of bits in an octet, the status value octet is filled 
             * with that many 1's
             */
            cgua->rangStat.status.val[i] = 0xFF >> 
                                              (MAXBITS_IN_OCTET - tempNumCir);
      }
      /*
       * Nullify status field of cgua so that its not there in CGUA Indication
       */
      cgua->rangStat.status.pres = NOTPRSNT;
   }
   else
#endif
   {
      key.k2.cic = cirgr->cir->key.k2.cic;
   }
   key.k2.intfId = cirgr->cir->key.k2.intfId;

   /* send block acks to all the circuits anyways */
   for (i = 0; i < numOct; i++)
   {
      switch (ret)
      {
         case SISUBSET:
            procStatus = cirgr->rangStat.status.val[i];
            break;
         case SISUPSET:
         case SIEQLSET:
            procStatus = cgua->rangStat.status.val[i];
            break;
         case SIINTSECT:
            procStatus = cirgr->rangStat.status.val[i] &
                            cgua->rangStat.status.val[i];
            break;
         default:    /* case SIDISJNT */
            procStatus = 0;
            break;
      }

      for (j = 0, mask = 0x01; j < 8; j++, mask <<= 0x01, key.k2.cic++)
      {
         /* if range is over */
         if ( (i*8+j) > cgua->rangStat.range.val )
            break;
         if (procStatus & mask)
         {
            /* find circuit */
            siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
            if (cir == NULLP)
            {
               /* cic in the routing label is equipped, however some cic 
                * in the range are not equipped, ISUP should process it as if 
                * they are equipped.  
                * However, for ANSI 92 and ANS95, ISUP may optionally send 
                * UCIC for each of the cics that are unequipped. 
                */
               continue;
            }
            siProcCirMsg(cir, cirFsmEvt, TRUE);
         }
      }
   }

   /* Generate Circuit Group Unblock Confirm */
   MFINITSDU(&cb->mfMsgCtl, ret, (U8) MI_CIRGRPUBLKACK, (U8) SI_STAREQ,
             (ElmtHdr *) cgua, (ElmtHdr *) &staEvnt,
             (U8) PRSNT_NODEF, intfCb->cfg.swtch, (U32) MF_ISUP);

   if (cb && (cb->state == SI_BND))
      SiUiSitStaInd(&cb->pst, cb->suId, 0, 0, cirgr->cir->key.k1.cirId, FALSE,
                    SIT_STA_CGUCFM, &staEvnt, NULLP);
   if (cirgr->querPrcs == FALSE)
   {
      cirgr->cir->cirGr[cirgr->cirState] = NULLP;
      SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
               (Size)sizeof(SiCirGrp));
   }

#ifdef ZI
   ziUpdPeer();
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirGrE04SND
*
*       Desc:  action function for group reset request.
*              states: all states
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE04SND
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE04SND (cirgr)
SiCirGrp *cirgr;
#endif
{
   SiCirKey  key;
   SiCirCb   *cir;
   SiStaEvnt *staEvnt;
   SiCirGrp  *tmpCirGr;
   SiNSAPCb  *cb;
   U8        i;
   U8       effRange;   /* The effective range for GRSReq */
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   S16       ret;
   SiCirCb   *mCntrlPtrs[SI_MAX_NO_OF_CIR];     
                   /* ptrs array of cntrl CirCb in affected conn */
   U8        numCkts;        /* num of cntrl ckts */
#endif

   TRC3(siCirGrE04SND)

   staEvnt = (SiStaEvnt *)&cirgr->sduSp->m.siStaEvnt;

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cirgr->cir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* check if any mntc event is pending */
   if ((cirgr->cir->cirGr[SICIR_MTLOCST]->state > SICG_ST_IDLE) && 
         (cirgr->cir->cirGr[SICIR_MTLOCST]->state < SICG_ST_WTCGRACK)) 
   {
      /* check if this GRS event includes the previous mntc event */
      if (cirgr->rangStat.range.val > staEvnt->rangStat.range.val)
      {  
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "range in event %d and in cirgr %d does not match\n",
                staEvnt->rangStat.range.val, cirgr->rangStat.range.val));  
         RETVALUE(RFAILED);
      } 

      siStopCirGrTmr(cirgr->cir->cirGr[SICIR_MTLOCST], TMR_ALL);
   }

   /* check if h/w event is pending */
   if ((tmpCirGr = cirgr->cir->cirGr[SICIR_HWLOCST]) != NULLP)
   {
      /* check if this GRS event includes the previous h/w oriented event */
      if (tmpCirGr->rangStat.range.val > staEvnt->rangStat.range.val)
      {  
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
           "range in event %d is less than in cirgr %d \n",
                staEvnt->rangStat.range.val, tmpCirGr->rangStat.range.val));  
         RETVALUE(RFAILED);
      } 

      /* cancel the previous hardware oriented group event */
      if ((tmpCirGr->state > SICG_ST_IDLE) && 
          (tmpCirGr->state < SICG_ST_WTCGRACK)) 
      {
         siStopCirGrTmr(tmpCirGr, TMR_ALL);
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)tmpCirGr, 
                  (Size)sizeof(SiCirGrp));
         cirgr->cir->cirGr[SICIR_HWLOCST] = NULLP;
      }
   }

   effRange = 0;
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* initialization */
   for (i = 0; i < SI_MAX_NO_OF_CIR; i++)
      mCntrlPtrs[i] = NULLP;
   numCkts = 0;
#endif

   cb = siGetLwrMCbPtr(cirgr->cir);
   if (cb == NULLP)
   {
       SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
         "GetMCbptr: can not find MTPblock for swtch %d and ssf %d\n",
                       cirgr->cir->pIntfCb->cfg.swtch, 
                       cirgr->cir->pIntfCb->cfg.ssf));
       RETVALUE(RFAILED);
   }

   cirgr->rangStat.eh.pres     = PRSNT_NODEF;
   cirgr->rangStat.range.pres  = staEvnt->rangStat.range.pres;
   cirgr->rangStat.range.val   = staEvnt->rangStat.range.val;
   /* status field is not present in GRS */
   staEvnt->rangStat.status.pres = NOTPRSNT;


   /* initialize the key and process the affected circuits */
   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
   key.k2.intfId = cirgr->cir->key.k2.intfId;

   {
      /* Check the range value */
      if (staEvnt->rangStat.range.val)
      {
         /* If the range is non-zero, then use this circuit's CIC value
          * as the starting cirucit for this group message.
          * Effective range is same as the received range.
          */
         key.k2.cic = cirgr->cir->key.k2.cic;
         effRange = staEvnt->rangStat.range.val;
       }

       for (i = 0; i <= effRange; i++, key.k2.cic++)
       {
          siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);

          if (cir != NULLP)
          {
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
             /* check if this circuit involved in a non-single rate call */
             if (cir->ctrlMultiRateCir != NULLP)
             {
                /* it involved in a non-single rate call. Check if the 
                 * mulReset is set. If not, need to set the muReset to TRUE 
                 * and store the ctrlMultiRateCir in the local array 
                 * mCntrlPtrs. By setting the flag mulReset to TRUE, when it 
                 * jumps to the circuit state matrix funct, it would not 
                 * process the connection Cb to avoid multiple processing 
                 * on the conn cb
                 */
                if (siStoreCntrlCir(mCntrlPtrs, cir, &numCkts) != ROK)
                {
                    SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                       "Store the cntrl cir failure when processing cir %ld\n",
                        cir->cfg.cirId));  
                    RETVALUE(RFAILED);
                }
             }                
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
             siProcCirEvt(cir, CEI_GRSREQ, TRUE);
          }
       } /* end of range value */
   }   

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if the affected circuit involved in a non-single rate connection
    */
   if (numCkts != 0)
   {
      /* there exists non-single rate connection. Take action here on the
       * connection Cb for each non-single rate call by calling siActDat
       * directly
       */
      ret = siProcMRateinCirGrMsg(mCntrlPtrs, CEI_GRSREQ, numCkts);
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
          "Processing non-single conn when recv circuit ralated msg \
           failed.\n"));  
         RETVALUE(RFAILED);
      }
   }
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   /* flow control unnecessary */
   if (siGenCirGrMsg(cirgr, (U8) M_CIRGRPRES, (U8) MI_CIRGRPRES) == ROK)
   {
      /* start Group Blocking timer */
      siStartCirGrTmr(TMR_T22, cirgr);
      /* start initial Group Blocking timer */
      siStartCirGrTmr(TMR_T23, cirgr);
   }
   else
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siGenCirGrMsg returned failure\n"));  

      /* si013.220, Addition: Added code to stop timers T22 and T23
                              when GRS cannot be generated */
      siStopCirGrTmr(cirgr, TMR_T22);
      siStopCirGrTmr(cirgr, TMR_T23);
      /* Deallocate the circuit group control block, as we were
       * not able to send GRS message.
       */
      cirgr->cir->cirGr[cirgr->cirState] = NULLP;
      SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
                  (Size) sizeof(SiCirGrp));
      RETVALUE(RFAILED);
   } 


   SISTATECHNG(cirgr->state , SICG_ST_WTCGRACK);
   RETVALUE(ROK);  
}


/*
*
*       Fun:   siCirGrE05S03
*
*       Desc:  action for group reset ack.
*              states : waiting for group reset ack. 
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE05S03
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE05S03(cirgr)
SiCirGrp *cirgr;
#endif
{
   SiCirKey  key;
   SiStaEvnt staEvnt;
   SiCirCb   *cir;
   SiPduGRA  *gra;
   SiUpSAPCb *cb;
   SiNSAPCb  *mCb;
   S16       ret;
   U8        mask;
   U8        i;
   SiIntfCb  *intfCb;
   U8        effRange;       /* The effective range for GRA */

   TRC3(siCirGrE05S03)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cirgr->cir) != ROK)
      RETVALUE(RFAILED);
#endif

   siStopCirGrTmr(cirgr, TMR_ALL);

   gra   = (SiPduGRA *)&cirgr->pduSp->m.cirGrpResAck;

   /* get pointer to the upper control block */
   cb = siGetUprCbPtr(cirgr->cir);

   /* get pointer to the upper control block */
   mCb = siGetLwrMCbPtr(cirgr->cir);

   if ((intfCb = cirgr->cir->pIntfCb) == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "Could not find the interface corresponding to intfId = %lx\n",
             cirgr->cir->key.k2.intfId));  
        
      RETVALUE(RFAILED);
   }

   /* Check if we have received a non-zero range value */
   if (gra->rangStat.range.val)
   {
     /* We have received a non-zero range. Check if range values
      * are the same in received GRA message and the circuit
      * group control block.
      */
     if (cirgr->rangStat.range.val != gra->rangStat.range.val)
     {  
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "range in event %d and in cirgr %d does not match\n",
             gra->rangStat.range.val, cirgr->rangStat.range.val));  
       RETVALUE(RFAILED);
     } 
   }
   /* initialize key and process the circuits */
   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
   key.k2.intfId = cirgr->cir->key.k2.intfId;
   effRange = 0;

   {           
      /* Check the range value */
      if (cirgr->rangStat.range.val)
      {
         /* If the range is non-zero, then use this circuit's CIC value
          * as the starting cirucit for this group message.
          */
         key.k2.cic = cirgr->cir->key.k2.cic;
         effRange = cirgr->rangStat.range.val;
      }
      for (i = 0, mask = 0x01; i <= effRange; 
            i++, key.k2.cic++, mask <<= 0x01)
      {
         if (mask == 0x00)
            mask = 0x01;
         siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
         if (cir == NULLP)
         {
            /* cic in the routing label is equipped, however some cic 
             * in the range are not equipped, ISUP should process it as if 
             * they are equipped.  
             * However, for ANSI 92 and ANS95, ISUP may optionally send 
             * UCIC for each of the cics that are unequipped. 
             */
            continue;
         }

         /* idle the local states */
         siProcCirMsg(cir, CEI_GRA, TRUE);

         /* remotely M-blocked - coded as '1' in GRA */ 
         if ((gra->rangStat.range.val) && 
             (gra->rangStat.status.val[i >> 3] & mask))
         {
             cir->noRspFlgToLw = TRUE;  /* don't send BLA back */
             siProcCirMsg(cir, CEI_BLO, TRUE);
         }
      }
   }

   /* Generate Circuit Group Reset Confirm */
   MFINITSDU(&cb->mfMsgCtl, ret, (U8) MI_CIRGRPRESACK, (U8) SI_STAREQ,
             (ElmtHdr *) gra, (ElmtHdr *) &staEvnt,
             (U8) PRSNT_NODEF, intfCb->cfg.swtch, (U32) MF_ISUP);

   if (cb && (cb->state == SI_BND))
      SiUiSitStaInd(&cb->pst, cb->suId, 0, 0, cirgr->cir->key.k1.cirId, FALSE,
                    SIT_STA_GRSCFM, &staEvnt, NULLP);

   if (cirgr->querPrcs == FALSE)
   {
      cirgr->cir->cirGr[cirgr->cirState] = NULLP;
      SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
               (Size)sizeof(SiCirGrp));
   }

#ifdef ZI
   ziUpdPeer();
#endif
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirGrE06S00
*
*       Desc:  Action function for Mntc./Hardware CGB message
*       States:idle
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE06S00
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE06S00 (cirgr)
SiCirGrp *cirgr;
#endif
{
   SiPduCGB *cgb;
   SiCirGrp *tmpCirGr;
   S16      ret;
   U8       cntr;

   TRC3(siCirGrE06S00)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cirgr->cir) != ROK)
      RETVALUE(RFAILED);
#endif

   cgb = (SiPduCGB *)&cirgr->pduSp->m.cirGrpBlk;

   switch (cgb->cgsmti.typeInd.val & 0x03)
   {
      case HARDFAIL:
         tmpCirGr = cirgr->cir->cirGr[SICIR_MTREMST];
         if ((tmpCirGr != NULLP) && (tmpCirGr->state == SICG_ST_WTCGRRSP))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "Invalid CGBREQ: cirGr existing & state is WTCGRACK\n"));

            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                          (PTR) &cirgr->cir->key.k1.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LCM_EVENT_INV_STATE, LSI_CAUSE_INV_CGB, TRUE, 
                           cirgr->cir->key.k1.cirId, SI_ALRM_INVCGB);
            cirgr->cir->cirGr[cirgr->cirState] = NULLP;
            SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr,
                     (Size)sizeof(SiCirGrp));
            RETVALUE(RFAILED);
         }

      case MAINT:
         cirgr->cgsmti.eh.pres      = PRSNT_NODEF;
         cirgr->cgsmti.typeInd.pres = PRSNT_NODEF;
         cirgr->cgsmti.typeInd      = cgb->cgsmti.typeInd;
         cirgr->rangStat.eh.pres    = PRSNT_NODEF;
         cirgr->rangStat.range.pres = cgb->rangStat.range.pres;
         cirgr->rangStat.range.val  = cgb->rangStat.range.val;
         cirgr->rangStat.status.pres= cgb->rangStat.status.pres;
         cirgr->rangStat.status.len = cgb->rangStat.status.len;
         /* copy the status bits into firstRevdStat for later comparation
          * when receive subsquent CGB's
          */
         cirgr->firstRevdStat.pres = cgb->rangStat.status.pres;
         cirgr->firstRevdStat.len  = cgb->rangStat.status.len;
         for (cntr = 0; cntr < cgb->rangStat.status.len; cntr++)
            cirgr->firstRevdStat.val[cntr] = cgb->rangStat.status.val[cntr];
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "Type %d is neither mntce nor hw\n",
                   cgb->cgsmti.typeInd.val & 0x03));  
         RETVALUE(RFAILED);
   }


   ret = siProcCGB(cirgr, cgb);
   RETVALUE(ret);
} /* siCirGrE06S00 */


/*
*
*       Fun:   siCirGrE06S01
*
*       Desc:  Action function for handling Mntc./Hardware CGB
*       States:waiting for CGB/CGU response
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE06S01
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE06S01 (cirgr)
SiCirGrp *cirgr;
#endif
{
   SiPduCGB *cgb;
   SiCirGrp *tmpCirGr;
   S16      ret;
   Cntr      cntr;
   SiUpSAPCb *cb;
   SiStaEvnt staEvt;
   
   TRC3(siCirGrE06S01)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cirgr->cir) != ROK)
      RETVALUE(RFAILED);
#endif

   cgb = (SiPduCGB *)&cirgr->pduSp->m.cirGrpBlk;

   /* check if there is a GRS pending */
   switch (cgb->cgsmti.typeInd.val & 0x03)
   {
      case HARDFAIL:
         tmpCirGr = cirgr->cir->cirGr[SICIR_MTREMST];
         if ((tmpCirGr != NULLP) && (tmpCirGr->state == SICG_ST_WTCGRRSP))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "Invalid CGBREQ: cirGr existing & state is WTCGRACK\n"));

            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                          (PTR) &cirgr->cir->key.k1.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LCM_EVENT_INV_STATE, LSI_CAUSE_INV_CGB, TRUE, 
                           cirgr->cir->key.k1.cirId, SI_ALRM_INVCGB);
            cirgr->cir->cirGr[cirgr->cirState] = NULLP;
            SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
                     (Size)sizeof(SiCirGrp));
            RETVALUE(RFAILED);
         }

      case MAINT:
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "Type %d is neither mntce nor hw\n",
                   cgb->cgsmti.typeInd.val & 0x03));  
         RETVALUE(RFAILED);
   }

   /* validate the range */
   if (cirgr->rangStat.range.val != cgb->rangStat.range.val)
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "range in event %d and in cirgr %d does not match\n",
                cgb->rangStat.range.val, cirgr->rangStat.range.val));  
      RETVALUE(RFAILED);
   } 

  /* ISUP should just forward a CGB indication to CC again while in waiting 
   * for CGB response if Range and Status field are matched with the previous
   * CGB. This is happened because CGB indication primitive between the CC
   * and ISUP got lost. And the peer node resend CGB on the protocal timer
   * expiry 
   */ 
  /* check if there is a CGB pending */
  if ((cirgr->state == SICG_ST_WTCGBRSP) && (cirgr->cir->fsmEvnt == CGEI_CGB))
  {           
     /* However, we should compare the status field with the firstRevdStat
      * stored in cirgr instead of cirgr->rangStat.status. The reason is that
      * the cirgr->rangStat.status might be changed during processed the
      * previous CGB's. For example:
      * 1)1st CGB with (CIC = 1, range = 2, status = 7) is received,
      * 2)if circuit 2 is not allocated, then the status bit will be modifed as
      *   5, an indication with (CIC =1, range =2, status = 5) is sent to CC, 
      *   and the value in cirgr->rangStat.status is modified as 5
      * 3)2nd CGB with (CIC=1, range =2, status = 7) is received again
      * 4)if you compare with received status bits with the value in 
      *   cirgr->rangStat.status, they would not be matched. 
      * Therefore, we should not compare received status bits with the value in
      * cirgr->rangStat.status
      */
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * If the range of CGB is zero, do not call siCmpStatus, as the status field 
 * will not be present
 */
   if (cgb->rangStat.range.val == 0)
      ret = SIEQLSET;
   else
#endif
   {
      ret = siCmpStatus(cirgr->rangStat.range.val, 
                        cirgr->firstRevdStat.val, 
                        cgb->rangStat.range.val, 
                        cgb->rangStat.status.val, NULLP, NULLP);
   }
   
      /* if range and status are matched, just forwards an indication to CC */
      if (ret == SIEQLSET)
      {
         /* get pointer to the upper control block */
         cb = siGetUprCbPtr(cirgr->cir);

         /* copy the already processed status bits back into received
          * the message
          */
         cgb->rangStat.status.pres = cirgr->rangStat.status.pres;
         cgb->rangStat.status.len = cirgr->rangStat.status.len;
         for (cntr = 0; cntr < (Cntr) cirgr->rangStat.status.len; cntr++)
            cgb->rangStat.status.val[cntr] = cirgr->rangStat.status.val[cntr];

         /* Generate Status Indication to Upper Layer */
         MFINITSDU(&cb->mfMsgCtl, ret, (U8) MI_CIRGRPBLK, (U8) SI_STAREQ,
                   (ElmtHdr *) cgb, (ElmtHdr *) &staEvt, (U8) PRSNT_NODEF,
                   cirgr->cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);
               
         /* send status indication to the upper layer , ISUP send two type
            of indications */
         if (cb && (cb->state == SI_BND))
         {   
            SiUiSitStaInd(&cb->pst, cb->suId, 0, 0, cirgr->cir->key.k1.cirId,
                          TRUE, SIT_STA_CGBINFOIND, &staEvt, NULLP);
            SiUiSitStaInd(&cb->pst, cb->suId, 0, 0, 
                          cirgr->cir->key.k1.cirId, TRUE, SIT_STA_CGBIND, 
                             &staEvt, NULLP);
         }                 
         RETVALUE(ROK);
      }
   }
   /* otherwise, should process it following the existing procedure */
   ret = siCmpStatus(cirgr->rangStat.range.val, 
                     cirgr->rangStat.status.val, 
                     cgb->rangStat.range.val, 
                     cgb->rangStat.status.val, NULLP, NULLP);
   if (ret != SIEQLSET)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "siCmpStatus does not return SIEQLSET.Returning failure\n"));  
           
      SISNDOLDLSISTAIND(&siCb.init.lmPst, cirgr->cir->key.k1.cirId, 
                        SI_ALRM_INVCGB);
      RETVALUE(RFAILED);
   }

   /* cancel current pending timers */
   siStopCirGrTmr(cirgr, TMR_ALL);


   ret = siProcCGB(cirgr, cgb);
   RETVALUE(ret);
} /* siCirGrE06S01 */


/*
*
*       Fun:   siCirGrE06S06
*
*       Desc:  Action function for handling CGB when waiting for GRSRSP
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE06S06
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE06S06 (cirgr)
SiCirGrp *cirgr;
#endif
{
   SiPduCGB *cgb;

   TRC3(siCirGrE06S06)

   cgb = (SiPduCGB *)&cirgr->pduSp->m.cirGrpBlk;

   switch (cgb->cgsmti.typeInd.val & 0x03)
   {
      /* this is an error - h/w state can never be in WTGRSRSP state */
      case HARDFAIL:
         cirgr->cir->cirGr[cirgr->cirState] = NULLP;
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI546, (ErrVal) cirgr->state,
                    "siCirGrE02S03(): Invalid state for a h/w group event");
#endif
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
                  (Size) sizeof(SiCirGrp));

      /***** fall through *****/
      case MAINT:
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cirgr->cir->key.k1.cirId, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                        LCM_EVENT_INV_STATE, LSI_CAUSE_INV_CGB, TRUE, 
                        cirgr->cir->key.k1.cirId, SI_ALRM_INVCGB);
         break; 

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "Type %d is neither mntce nor hw\n",
                   cgb->cgsmti.typeInd.val & 0x03));  
         break;
   }

   /* stop all pending timers */
   RETVALUE(RFAILED);
}




/*
*
*       Fun:   siCirGrE07S00
*
*       Desc:  action function for CGB response
*              states: idle
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE07S00
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE07S00(cirgr)
SiCirGrp *cirgr;
#endif
{
#if (ERRCLASS & ERRCLS_DEBUG)
   SiCirKey       key;
   SiStaEvnt      *staEvt;
   SiCirCb        *cir;
   U8             numOct;
   U8             mask;
   U8             i;
   U8             j;
#endif

   TRC3(siCirGrE07S00)

#if (ERRCLASS & ERRCLS_DEBUG)

   staEvt = (SiStaEvnt *)&cirgr->sduSp->m.siStaEvnt;
   /* si013.220, Change: Modified code to check if range value is
                         is 255 */
   numOct = (U8)((staEvt->rangStat.range.val+1) >> 3) +
                (U8)(((staEvt->rangStat.range.val+1) & 0x07) ? 1 : 0);

   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
   key.k2.cic = cirgr->cir->key.k2.cic;
   key.k2.intfId = cirgr->cir->key.k2.intfId;
         
   for (i = 0; i < numOct; i++)
   {
      for (j = 0, mask = 0x01; j < 8; j++, mask <<= 0x01, key.k2.cic++)
      {
         if (staEvt->rangStat.status.val[i] & mask)
         {
            siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
            if (cir == NULLP)
               continue;
            
            switch (staEvt->cgsmti.typeInd.val & 0x03)
            {
               case HARDFAIL:
                  if (cir->transStat[SICIR_HWREMST] != SICIR_ST_REMBLKED)
                  {
                     SILOGERROR(ERRCLS_DEBUG, ESI547, (ErrVal) key.k2.cic,
                                "siCirGrE07S00(), circuit not idle");   
                  }
                  break;
               case MAINT:
                  if (cir->transStat[SICIR_MTREMST] != SICIR_ST_REMBLKED)
                  {
                     SILOGERROR(ERRCLS_DEBUG, ESI548, (ErrVal) key.k2.cic,
                                "siCirGrE07S00(), circuit not idle");   
                  }  
                  break;
            }
         }
      }
   }

#endif 

   cirgr->cir->cirGr[cirgr->cirState] = NULLP;
   /* deallocate Circuit Group Control Block */
   SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
            (Size)sizeof(SiCirGrp));

   RETVALUE(ROK);
}  /* siCirGrE07S00 */


/*
*
*       Fun:   siCirGrE07SND
*
*       Desc:  action function for CGB response
*              states: waiting for CGB response
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE07SND
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE07SND(cirgr)
SiCirGrp *cirgr;
#endif
{
   U8             retStatus[4];
   SiCirKey       key;
   SiStaEvnt      *staEvt;
   SiCirCb        *cir;
   SiNSAPCb       *mCb;
   S16            ret;
   Bool           found;
   U8             numOct;
   U8             mask;
   U8             cirFsmEvt;
   U8             i;
   U8             j;

   TRC3(siCirGrE07SND)

   staEvt = (SiStaEvnt *)&cirgr->sduSp->m.siStaEvnt;
   /* si013.220, Change: Modified code to check if range value is
                         is 255 */
   numOct = (U8)((staEvt->rangStat.range.val+1) >> 3) +
                (U8)(((staEvt->rangStat.range.val+1) & 0x07) ? 1 : 0);

   mCb    = siGetLwrMCbPtr(cirgr->cir);

   /* check if range values are the same */
   if (cirgr->rangStat.range.val != staEvt->rangStat.range.val)
      RETVALUE(RFAILED);

   /* compare incoming status in the ack with the one in the request */
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * If the range of the CGBRsp is zero, do not call siCmpStatus, as the status 
 * field will not be present
 */
   if (staEvt->rangStat.range.val == 0)
      /* ret value set to SIEQLSET to bypass siCmpStatus & switch statement */
      ret = SIEQLSET;
   else /* if range != 0 */
#endif
   {
      ret = siCmpStatus(cirgr->rangStat.range.val, cirgr->rangStat.status.val,
                     staEvt->rangStat.range.val, staEvt->rangStat.status.val, 
                     NULLP, retStatus);
   }

   switch (ret)
   {
      /* hey! that's not for me! */
      case SIDISJNT:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siCmpStatus returns SIDISJNT.Returning failure\n"));  
           
         RETVALUE(RFAILED);

      /* process additional circuits */
      case SISUBSET:
      case SIINTSECT:
         found = FALSE;
         cmMemset( (U8 *)&key, '\0', sizeof(SiCirKey));
         key.k2.cic = cirgr->cir->key.k2.cic;
         key.k2.intfId = cirgr->cir->key.k2.intfId;
         for (i = 0; i < numOct; i++)
         {
            if (found == TRUE)
               break;
            /* for each field in octet */
            for (j = 0, mask = 0x01; j < 8; j++, mask <<= 0x01, key.k2.cic++)
            {
               if (retStatus[i] & mask)
               {
                  /* find circuit */
                  siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
                  if (cir == NULLP)
                     continue;

                  /* found one which is not in a blocking state!! */
                  if ((cir->transStat[cirgr->cirState] != SICIR_ST_WTBLKACK) ||
                      (cir->transStat[cirgr->cirState] != SICIR_ST_LOCBLKED))
                  {
                     siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                                   (PTR) &cir->key.k1.cirId, 
                                   LSI_USTA_DGNVAL_NONE, NULLP, 
                                   LSI_USTA_DGNVAL_NONE, NULLP, 
                                   LSI_USTA_DGNVAL_NONE, NULLP);
                     SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                                    LSI_EVENT_INV_ACK, LSI_CAUSE_INV_CGBRSP, 
                                    TRUE, cirgr->cir->key.k1.cirId, 
                                    SI_CG_INVACK); 
                     found = TRUE;
                     break;
                  }  
               } 
            } /* for j */
         } /* for i */
         break;

      /* if all the circuits in the request are not present */
      case SISUPSET:
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR)&cirgr->cir->key.k1.cirId, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                        LSI_EVENT_INV_ACK, LSI_CAUSE_INV_CGBRSP, TRUE, 
                        cirgr->cir->key.k1.cirId, SI_CG_INVACK); 
         break;
   }

   if (cirgr->cirState == SICIR_MTREMST)
      cirFsmEvt = CEI_MTCGBRSP;
   else if (cirgr->cirState == SICIR_HWREMST)
      cirFsmEvt = CEI_HWCGBRSP;
   else
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
       "circuit state %d is neither MTLOCST nor HWLOCST\n", cirgr->cirState));  
        
      RETVALUE(RFAILED);   
   } 

   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * Added code over here so that when a CGBRsp with range zero is being pro-
 * cessed, the configured "firstCic" value is used as the starting circuit for
 *  this group msg, & the "numCir" value is used to fill up the status field
 */
   if (staEvt->rangStat.range.val == 0)
   {
      U8 tempNumCir;   /* temporary variable for status assignment */
      /*
       * During ckt configuration, numCir is decremented by 1. To allow proper
       * status length calculation, 1 is added over here. firstCic is used as
       * the starting CIC value
       */
      tempNumCir = cirgr->cir->cfg.numCir + 1;
      key.k2.cic = cirgr->cir->cfg.firstCic;
      /*
       * Status length is calculated by dividing tempNumCir value by 8, and
       * adding 1 if there's a remainder when tempNumCir is divided by 8 
       */
      staEvt->rangStat.status.len = ((U8)(tempNumCir >> 3)) +
                                    ((tempNumCir & 0x07) ? 1 : 0);
      numOct = staEvt->rangStat.status.len;
      for (i = 0; i < staEvt->rangStat.status.len; i++) 
      {
         if (tempNumCir > MAXBITS_IN_OCTET)
         {
            /*
             * If number of circuits to be blocked is greater than the total 
             * number of bits in an octet, the status value octet is filled 
             * with 0xFF
             */
            staEvt->rangStat.status.val[i] = 0xFF;
            tempNumCir = tempNumCir - MAXBITS_IN_OCTET;
         }
         else
            /*
             * If number of circuits to be blocked is less than the total 
             * number of bits in an octet, the status value octet is filled 
             * with that many 1's
             */
            staEvt->rangStat.status.val[i] = 0xFF >> 
                                              (MAXBITS_IN_OCTET - tempNumCir);
      }
      /* 
       * Nullify status field of cirgr so that it is not passed in the CBGA
       */
      cirgr->sduSp->m.siStaEvnt.rangStat.status.pres = NOTPRSNT;
   }
   else
#endif
   {
      key.k2.cic = cirgr->cir->key.k2.cic;
   }
   key.k2.intfId = cirgr->cir->key.k2.intfId;
   for (i = 0; i < numOct; i++)
   {
      for (j = 0, mask = 0x01; j < 8; j++, mask <<= 0x01, key.k2.cic++)
      {
         if (staEvt->rangStat.status.val[i] & mask)
         {
            siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
            if (cir != NULLP)
            {
               siProcCirEvt(cir, cirFsmEvt, TRUE);
            }
         }
      }
   }
   /* generate message to n/w */
   if (siGenCirGrMsg(cirgr, M_CIRGRPBLKACK, MI_CIRGRPBLKACK) != ROK)
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siGenCirGrMsg returned failure\n"));  

      RETVALUE(RFAILED);
   } 

   cirgr->cir->cirGr[cirgr->cirState] = NULLP;
   /* deallocate Circuit Group Control Block */
   SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
            (Size)sizeof(SiCirGrp));

#ifdef ZI
   ziUpdPeer();
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirGrE08S00
*
*       Desc:  Action function for handling Mntc./Hardware CGU message
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE08S00
( 
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE08S00 (cirgr)
SiCirGrp *cirgr;
#endif
{
   SiPduCGU *cgu;
   SiCirGrp *tmpCirGr;
   S16      ret;
   U8       cntr;

   TRC3(siCirGrE08S00)

   cgu = (SiPduCGU *)&cirgr->pduSp->m.cirGrpUnblk;

   /* process hardware oriented CGB */
   switch (cgu->cgsmti.typeInd.val & 0x03)
   {
      case HARDFAIL:
         tmpCirGr = cirgr->cir->cirGr[SICIR_MTREMST];
         if ((tmpCirGr != NULLP) && (tmpCirGr->state == SICG_ST_WTCGRRSP))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "Invalid CGBREQ: cirGr existing & state is WTCGRACK\n"));

            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & cirgr->cir->key.k1.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LCM_EVENT_INV_STATE, LSI_CAUSE_INV_CGU, TRUE, 
                           cirgr->cir->key.k1.cirId, SI_ALRM_INVCGU);
            cirgr->cir->cirGr[cirgr->cirState] = NULLP;
            SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr,
                     (Size)sizeof(SiCirGrp));
            RETVALUE(RFAILED);
         }

      case MAINT:
         cirgr->cgsmti.eh.pres      = PRSNT_NODEF;
         cirgr->cgsmti.typeInd.pres = PRSNT_NODEF;
         cirgr->cgsmti.typeInd      = cgu->cgsmti.typeInd;
         cirgr->rangStat.eh.pres    = PRSNT_NODEF;
         cirgr->rangStat.range.pres = cgu->rangStat.range.pres;
         cirgr->rangStat.range.val  = cgu->rangStat.range.val;
         cirgr->rangStat.status.pres= cgu->rangStat.status.pres;
         cirgr->rangStat.status.len = cgu->rangStat.status.len;
         /* copy the status bits into firstRevdStat for later comparation
          * when receive subsquent CGU's
          */
         cirgr->firstRevdStat.pres = cgu->rangStat.status.pres;
         cirgr->firstRevdStat.len  = cgu->rangStat.status.len;
         for (cntr = 0; cntr < cgu->rangStat.status.len; cntr++)
            cirgr->firstRevdStat.val[cntr] = cgu->rangStat.status.val[cntr];
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "Type %d is neither mntce nor hw\n",
                   cgu->cgsmti.typeInd.val & 0x03));  
         RETVALUE(RFAILED);
   }

   ret = siProcCGU(cirgr, cgu);
   RETVALUE(ret);
} /* siCirGrE08S00 */


/*
*
*       Fun:   siCirGrE08S01
*
*       Desc:  Action function for Mntc./Hardware CGU message
*       States:Waiting for CGBRSP/CGURSP
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE08S01
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE08S01 (cirgr)
SiCirGrp *cirgr;
#endif
{
   SiPduCGU *cgu;
   SiCirGrp *tmpCirGr;
   S16      ret;
   Cntr      cntr;
   SiUpSAPCb *cb;
   SiStaEvnt staEvt;

   TRC3(siCirGrE08S01)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(siChkCirIntf(cirgr->cir) != ROK)
      RETVALUE(RFAILED);
#endif

   cgu = (SiPduCGU *)&cirgr->pduSp->m.cirGrpUnblk;

   /* check if there is a GRS pending */
   switch (cgu->cgsmti.typeInd.val & 0x03)
   {
      case HARDFAIL:
         tmpCirGr = cirgr->cir->cirGr[SICIR_MTREMST];
         if ((tmpCirGr != NULLP) && (tmpCirGr->state == SICG_ST_WTCGRRSP))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
               "Invalid CGBREQ: cirGr existing & state is WTCGRACK\n"));

            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cirgr->cir->key.k1.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LCM_EVENT_INV_STATE, LSI_CAUSE_INV_CGU, TRUE, 
                           cirgr->cir->key.k1.cirId, SI_ALRM_INVCGB);
            cirgr->cir->cirGr[cirgr->cirState] = NULLP;
            SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr,
                     (Size)sizeof(SiCirGrp));
            RETVALUE(RFAILED);
         }

      case MAINT:
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "Type %d is neither mntce nor hw\n",
                   cgu->cgsmti.typeInd.val & 0x03));  
         RETVALUE(RFAILED);
   }

   /* validate the range */
   if (cirgr->rangStat.range.val != cgu->rangStat.range.val)
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "range in event %d and in cirgr %d does not match\n",
                cgu->rangStat.range.val, cirgr->rangStat.range.val));  
      RETVALUE(RFAILED);
   } 
  /* ISUP should just forward a CGU indication to CC again while in waiting 
   * for CGU response if Range and Status field are matched with the previous
   * CGB. This is happened because CGU indication primitive between the CC
   * and ISUP got lost. And the peer node resend CGU on the protocal timer
   * expiry 
   */ 
  /* check if there is a CGU pending */
/* si003.220 - Modification. Modified code to add 'waiting for CGBRSP' check.
 */
  if (((cirgr->state == SICG_ST_WTCGURSP) || (cirgr->state == SICG_ST_WTCGBRSP)) 
      && (cirgr->cir->fsmEvnt == CGEI_CGU))
  {           
     /* However, we should compare the status field with the firstRevdStat
      * stored in cirgr instead of cirgr->rangStat.status. The reason is that
      * the cirgr->rangStat.status might be changed during processed the
      * previous CGB's. For example:
      * 1)1st CGU with (CIC = 1, range = 2, status = 7) is received,
      * 2)if circuit 2 is not allocated, then the status bit will be modifed as
      *   5, an indication with (CIC =1, range =2, status = 5) is sent to CC, 
      *   and the value in cirgr->rangStat.status is modified as 5
      * 3)2nd CGU with (CIC=1, range =2, status = 7) is received again
      * 4)if you compare with received status bits with the value in 
      *   cirgr->rangStat.status, they would not be matched. 
      * Therefore, we should not compare received status bits with the value in
      * cirgr->rangStat.status
      */
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * If the range of CGU msg is zero, do not call siCmpStatus, as the status 
 * be present
 */
      if (cgu->rangStat.range.val == 0)
         ret = SIEQLSET;
      else
#endif
      {
         ret = siCmpStatus(cirgr->rangStat.range.val, 
                           cirgr->firstRevdStat.val, 
                           cgu->rangStat.range.val, 
                           cgu->rangStat.status.val, NULLP, NULLP);
      }
   
      /* if range and status are matched, just forwards an indication to CC */
      if (ret == SIEQLSET)
      {
         /* get pointer to the upper control block */
         cb = siGetUprCbPtr(cirgr->cir);

         /* copy the already processed status bits back into received
          * the message
          */
         cgu->rangStat.status.pres = cirgr->rangStat.status.pres;
         cgu->rangStat.status.len = cirgr->rangStat.status.len;
         for (cntr = 0; cntr < (Cntr) cirgr->rangStat.status.len; cntr++)
            cgu->rangStat.status.val[cntr] = cirgr->rangStat.status.val[cntr];

         /* Generate Status Indication to Upper Layer */
         MFINITSDU(&cb->mfMsgCtl, ret, (U8) MI_CIRGRPUBLK, (U8) SI_STAREQ,
                   (ElmtHdr *) cgu, (ElmtHdr *) &staEvt, (U8) PRSNT_NODEF,
                   cirgr->cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);
               
         /* send status indication to the upper layer */
         if (cb && (cb->state == SI_BND))
            SiUiSitStaInd(&cb->pst, cb->suId, 0, 0, 
                          cirgr->cir->key.k1.cirId, TRUE, SIT_STA_CGUIND, 
                             &staEvt, NULLP);
         RETVALUE(ROK);
      }
   }
   /* otherwise, should process it following the existing procedure */
   ret = siCmpStatus(cirgr->rangStat.range.val, cirgr->rangStat.status.val, 
                     cgu->rangStat.range.val, cgu->rangStat.status.val, 
                     NULLP, NULLP);
   if (ret != SIEQLSET)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "siCmpStatus does not return SIEQLSET.Returning failure\n"));  
           
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & cirgr->cir->key.k1.cirId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, LSI_EVENT_REMOTE,
                     LSI_CAUSE_INV_CGU, TRUE, 
                     cirgr->cir->key.k1.cirId, INV_EVENT);
      RETVALUE(RFAILED);
   }

   /* cancel current pending timers */
   siStopCirGrTmr(cirgr, TMR_ALL);

   ret = siProcCGU(cirgr, cgu);
   RETVALUE(ret);
} /* end siCirGrE08S01 */


/*
*
*       Fun:   siCirGrE08S06
*
*       Desc:  Action function for Mntc./Hardware CGU message
*       States:waiting for GRSRSP
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE08S06
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE08S06 (cirgr)
SiCirGrp *cirgr;
#endif
{
   SiPduCGU *cgu;

   TRC3(siCirGrE08S06)

   cgu = (SiPduCGU *)&cirgr->pduSp->m.cirGrpUnblk;

   switch (cgu->cgsmti.typeInd.val & 0x03)
   {
      /* this is an error - h/w state can never be in WTGRSRSP state */
      case HARDFAIL:
         cirgr->cir->cirGr[cirgr->cirState] = NULLP;
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI549, (ErrVal) cirgr->state,
                    "siCirGrE02S03(): Invalid state for a h/w group event");
#endif
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
                  (Size) sizeof(SiCirGrp));

      /***** fall through *****/
      case MAINT:
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & cirgr->cir->key.k1.cirId, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                        LCM_EVENT_INV_STATE, LSI_CAUSE_INV_CGU, TRUE, 
                        cirgr->cir->key.k1.cirId, SI_ALRM_INVCGB);
         break; 

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "Type %d is neither mntce nor hw\n",
                   cgu->cgsmti.typeInd.val & 0x03));  
         break;
   }

   RETVALUE(RFAILED);
}




/*
*
*       Fun:   siCirGrE09SND
*
*       Desc:  action function for CGU response 
*              states: waiting for CGU response
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE09SND
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE09SND(cirgr)
SiCirGrp *cirgr;
#endif
{
   U8             retStatus[4];
   SiCirKey       key;
   SiStaEvnt      *staEvt;
   SiCirCb        *cir;
   S16            ret;
   Bool           found;
   U8             numOct;
   U8             mask;
   U8             cirFsmEvt;
   U8             i;
   U8             j;

   TRC3(siCirGrE09SND)

   staEvt = (SiStaEvnt *)&cirgr->sduSp->m.siStaEvnt;
   /* si013.220, Change: Modified code to check if range value is
                         is 255 */
   numOct = (U8)((staEvt->rangStat.range.val+1) >> 3) +
                (U8)(((staEvt->rangStat.range.val+1) & 0x07) ? 1 : 0);

   /* check if range values are the same */
   if (cirgr->rangStat.range.val != staEvt->rangStat.range.val)
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "range in event %d and in cirgr %d does not match\n",
                staEvt->rangStat.range.val, cirgr->rangStat.range.val));  
      RETVALUE(RFAILED);
   } 

   /* compare incoming status in the ack with the one in the request */
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * If the range of the CGURsp is zero, do not call siCmpStatus, as the status 
 * field will not be present
 */
   if (staEvt->rangStat.range.val == 0)
      /* ret value set to SIEQLSET to bypass siCmpStatus & switch statement */
      ret = SIEQLSET;
   else /* if range != 0 */
#endif
   {
      ret = siCmpStatus(cirgr->rangStat.range.val, cirgr->rangStat.status.val,
                     staEvt->rangStat.range.val, staEvt->rangStat.status.val, 
                     NULLP, retStatus);
   }

   switch (ret)
   {
      /* hey! that's not for me! */
      case SIDISJNT:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siCmpStatus returns SIDISJNT.Returning failure\n"));  
           
         RETVALUE(RFAILED);

      /* process additional circuits */
      case SISUBSET:
      case SIINTSECT:
         found = FALSE;
         cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
         key.k2.cic = cirgr->cir->key.k2.cic;
         key.k2.intfId = cirgr->cir->key.k2.intfId;
         for (i = 0; i < numOct; i++)
         {
            if (found)
               break;
            /* for each field in octet */
            for (j = 0, mask = 0x01; j < 8; j++, mask <<= 0x01, key.k2.cic++)
            {
               if (retStatus[i] & mask)
               {
                  /* find circuit */
                  siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
                  if (cir == NULLP)
                     continue;
                  /* found one which is in a blocking state!! */
                  if ((cir->transStat[cirgr->cirState] == SICIR_ST_WTBLKACK) ||
                      (cir->transStat[cirgr->cirState] == SICIR_ST_LOCBLKED))
                  {
                     siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                                   (PTR) &cir->key.k1.cirId, 
                                   LSI_USTA_DGNVAL_NONE, NULLP, 
                                   LSI_USTA_DGNVAL_NONE, NULLP, 
                                   LSI_USTA_DGNVAL_NONE, NULLP);
                     SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                                    LSI_EVENT_INV_ACK, LSI_CAUSE_INV_CGURSP, 
                                    TRUE, cirgr->cir->key.k1.cirId, 
                                    SI_CG_INVACK); 
                     found = TRUE;
                     break;
                  }  
               } 
            }
         }
         break;

      /* if all the circuits in the request are not present */
      case SISUPSET:
         SISNDOLDLSISTAIND(&siCb.init.lmPst, cirgr->cir->key.k1.cirId, 
                           SI_CG_INVACK); 
         break;
   }

   if (cirgr->cirState == SICIR_MTREMST)
      cirFsmEvt = CEI_MTCGURSP;
   else if (cirgr->cirState == SICIR_HWREMST)
      cirFsmEvt = CEI_HWCGURSP;
   else
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
       "circuit state %d is neither MTLOCST nor HWLOCST\n", cirgr->cirState));  
        
      RETVALUE(RFAILED);   
   } 

   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
#ifdef SI_CKTGRP_RANGZERO
/* si003.220 : Code addition
 * Added code over here so that when a CGURsp with range zero is being pro-
 * cessed, the configured "firstCic" value is used as the starting circuit for
 *  this  group msg, & the "numCir" value is used to fill up the status field
 */
   if (staEvt->rangStat.range.val == 0)
   {
      U8 tempNumCir;   /* temporary variable for status assignment */
      tempNumCir = cirgr->cir->cfg.numCir + 1;
      key.k2.cic = cirgr->cir->cfg.firstCic;
      staEvt->rangStat.status.len = ((U8)(tempNumCir >> 3)) +
                                    ((tempNumCir & 0x07) ? 1 : 0);
      numOct = staEvt->rangStat.status.len;
      for (i = 0; i < staEvt->rangStat.status.len; i++) 
      {
         if (tempNumCir > MAXBITS_IN_OCTET)
         {
            /*
             * If number of circuits to be blocked is greater than the total 
             * number of bits in an octet, the status value octet is filled 
             * with 0xFF
             */
            staEvt->rangStat.status.val[i] = 0xFF;
            tempNumCir = tempNumCir - MAXBITS_IN_OCTET;
         }
         else
            /*
             * If number of circuits to be blocked is less than the total 
             * number of bits in an octet, the status value octet is filled 
             * with that many 1's
             */
            staEvt->rangStat.status.val[i] = 0xFF >> 
                                              (MAXBITS_IN_OCTET - tempNumCir);
      }
      /* 
       * Nullify status field of cirgr so that it is not passed in the CGUA
       */
      cirgr->sduSp->m.siStaEvnt.rangStat.status.pres = NOTPRSNT;
   }
   else
#endif
   {
      key.k2.cic = cirgr->cir->key.k2.cic;
   }
   key.k2.intfId = cirgr->cir->key.k2.intfId;
   for (i = 0; i < numOct; i++)
   {
      for (j = 0, mask = 0x01; j < 8; j++, mask <<= 0x01, key.k2.cic++)
      {
         if (staEvt->rangStat.status.val[i] & mask)
         {
            /* find circuit */
            siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
            if (cir == NULLP)
               continue;
            siProcCirEvt(cir, cirFsmEvt, TRUE);
         }
      }
   }
   /* generate message to n/w */
   if (siGenCirGrMsg(cirgr, M_CIRGRPUBLKACK, MI_CIRGRPUBLKACK) != ROK)
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siGenCirGrMsg returned failure\n"));  

      RETVALUE(RFAILED);
   } 

   /* reinitialize pointers & deallocate Circuit Group Control Block */
   cirgr->cir->cirGr[cirgr->cirState] = NULLP;
   SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
            (Size)sizeof(SiCirGrp));

#ifdef ZI
   ziUpdPeer();
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirGrE09S00
*
*       Desc:  action function for CGU response
*              states: idle
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE09S00
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE09S00(cirgr)
SiCirGrp *cirgr;
#endif
{
#if (ERRCLASS & ERRCLS_DEBUG)
   SiCirKey       key;
   SiStaEvnt      *staEvt;
   SiCirCb        *cir;
   U8             numOct;
   U8             mask;
   U8             i;
   U8             j;
#endif

   TRC3(siCirGrE09S00)

#if (ERRCLASS & ERRCLS_DEBUG)
   staEvt = (SiStaEvnt *)&cirgr->sduSp->m.siStaEvnt;
   /* si013.220, Change: Modified code to check if range value is
                         is 255 */
   numOct = (U8)((staEvt->rangStat.range.val+1) >> 3) +
                (U8)(((staEvt->rangStat.range.val+1) & 0x07) ? 1 : 0);

   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
   key.k2.cic = cirgr->cir->key.k2.cic;
   key.k2.intfId = cirgr->cir->key.k2.intfId;
   for (i = 0; i < numOct; i++)
   {
      for (j = 0, mask = 0x01; j < 8; j++, mask <<= 0x01, key.k2.cic++)
      {
         if (staEvt->rangStat.status.val[i] & mask)
         {
            siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
            if (cir == NULLP)
               continue;
            switch (staEvt->cgsmti.typeInd.val & 0x03)
            {
               case HARDFAIL:
                  break;
               case MAINT:
                  if (cir->transStat[SICIR_MTREMST] != SICIR_ST_IDLE)
                  {
                     SILOGERROR(ERRCLS_DEBUG, ESI550, (ErrVal) key.k2.cic,
                                "siCirGrE07S00(), circuit not idle");   
                  }  
                  break;
            }
         }
      }
   }

#endif 

   cirgr->cir->cirGr[cirgr->cirState] = NULLP;
   /* deallocate Circuit Group Control Block */
   SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
            (Size)sizeof(SiCirGrp));

   RETVALUE(ROK);
}  /* siCirGrE09S00 */

/*
*
*       Fun:   siCirGrE0ASND
*
*       Desc:  GRS handling function
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE0ASND
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE0ASND(cirgr)
SiCirGrp *cirgr;
#endif
{
   SiPduGRS   *grs;
   SiCirGrp   *tmpCirGr;
   S16        ret;

   TRC3(siCirGrE0ASND)

   grs = (SiPduGRS *)&cirgr->pduSp->m.cirGrpRes;

   if (cirgr->state == SICG_ST_IDLE)
   {
      cirgr->rangStat.range.val   = grs->rangStat.range.val;
      cirgr->rangStat.status.pres = NOTPRSNT;

   }
   else /* some mntc. blocking event is pending */
   {
      /* if the ranges are unequal, let the prev procedure finish first */
      if (cirgr->rangStat.range.val != grs->rangStat.range.val)
      {  
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "range in event %d and in cirgr %d does not match\n",
                grs->rangStat.range.val, cirgr->rangStat.range.val));  
         RETVALUE(RFAILED);
      } 


   }

   /* if some h/w. blocking event is pending */
   if ((tmpCirGr = cirgr->cir->cirGr[SICIR_HWREMST]) != NULLP)
   {
      if (tmpCirGr->state != SICG_ST_IDLE)
      {
         if (tmpCirGr->rangStat.range.val != grs->rangStat.range.val)
         {  
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
              "range in event %d and in cirgr %d does not match\n",
                  grs->rangStat.range.val, tmpCirGr->rangStat.range.val));  
            RETVALUE(RFAILED);
         } 
         /* cancel the pending event and start group reset */
         else 
         {
            siStopCirGrTmr(tmpCirGr, TMR_ALL);
            cirgr->cir->cirGr[SICIR_HWREMST] = NULLP;
            SPutSBuf(siCb.init.region, siCb.init.pool, 
                     (Data *)tmpCirGr, (Size)sizeof(SiCirGrp));
         }
      }
   }

   ret = siProcGRS(cirgr, grs);

   RETVALUE(ret);
}


/*
*
*       Fun:   siCirGrE0BS00
*
*       Desc:  action function for GRS response
*              states: idle
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE0BS00
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE0BS00(cirgr)
SiCirGrp *cirgr;
#endif
{

   TRC3(siCirGrE0BS00)

   cirgr->cir->cirGr[cirgr->cirState] = NULLP;
   /* deallocate Circuit Group Control Block */
   SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
            (Size)sizeof(SiCirGrp));

   RETVALUE(ROK);
}  /* siCirGrE0BS00 */


/*
*
*       Fun:   siCirGrE0BS06
*
*       Desc:  GRS response handling function.
*              states: waiting for GRS response
*       Ret:   ROK- ok; RFAILED - failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE0BS06
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE0BS06(cirgr)
SiCirGrp *cirgr;
#endif
{
   SiCirKey   key;
   SiStaEvnt  *staEvnt;
   SiCirCb    *cir;
   SiUpSAPCb  *cb;
   U8         numOct;
   U8         mask;
   U8         i;
   U8         j;
   Cic        lastCic;

   TRC3(siCirGrE0BS06)


#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(cirgr->cir) != ROK)
      RETVALUE(RFAILED);
#endif

   staEvnt = (SiStaEvnt *)&cirgr->sduSp->m.siStaEvnt;
   numOct = 1;
   lastCic = cirgr->cir->key.k2.cic;

   if (staEvnt->rangStat.range.val)
   {
      numOct  = (U8) ((U8) (staEvnt->rangStat.range.val+1) >> 3) +
      (( (staEvnt->rangStat.range.val+1) & 0x07) ? 1 : 0);
   }


   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));

   /* Check if we have received a non-zero range value */
   if (staEvnt->rangStat.range.val)
   {
     /* We have received a non-zero range. Check if range values
      * are the same in received staEvnt structure and the circuit
      * group control block.
      */
     if (cirgr->rangStat.range.val != staEvnt->rangStat.range.val)
     {  
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "range in event %d and in cirgr %d does not match\n",
              staEvnt->rangStat.range.val, cirgr->rangStat.range.val));  
       RETVALUE(RFAILED);
     } 

     /* If the range is non-zero, then use this circuit's CIC value
      * as the starting cirucit for this group message.
      */
     key.k2.cic = cirgr->cir->key.k2.cic;
     lastCic = key.k2.cic + staEvnt->rangStat.range.val;
   }
   key.k2.intfId = cirgr->cir->key.k2.intfId;

   {           
      for (i = 0; i < numOct; i++)
      {
         for (j = 0, mask = 0x01; j < 8; j++, mask <<= 0x01, key.k2.cic++)
         {
            if (key.k2.cic <= lastCic)
            {
               /* find circuit */
               siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);

               if (cir == NULLP)
               {
                  /* exclude from the status */
                  if (staEvnt->rangStat.range.val)
                     staEvnt->rangStat.status.val[i] |= mask;
                  continue;
                }
               /* include the circuit in status field if available for service or
                  exclude it */
               if (siProcCirEvt(cir, CEI_GRSRSP, TRUE) == ROK)
               {
                  staEvnt->rangStat.status.val[i] &= ~mask;
               } 
               else
               {
                  staEvnt->rangStat.status.val[i] |= mask;
               }
            }
         }
      }
   }
   /* get pointer to the upper control block */
   cb = siGetUprCbPtr(cirgr->cir);

   /* Send status indication to IW to idle the circuit group
    * according to the status bits set in ISUP. 
    */
#ifdef IW 
   if (cb && (cb->state == SI_BND))
       SiUiSitStaInd(&cb->pst, cb->suId, 0, 0, cirgr->cir->key.k1.cirId,
                     TRUE, SIT_STA_GRSRSPIND, staEvnt, NULLP);
#endif   

   /* Generate Circuit Group Reset Ack */
   siGenCirGrMsg(cirgr, M_CIRGRPRESACK, MI_CIRGRPRESACK);


   /* deallocate Circuit Group Control Block */
   cirgr->cir->cirGr[cirgr->cirState] = NULLP;
   SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cirgr, 
            (Size)sizeof(SiCirGrp));

#ifdef ZI
   ziUpdPeer();
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCirGrE0CSND
*
*       Desc:  action function for circuit group query request 
*              
*       Ret:   ROK - ok;
*
*       Notes: RFAILED - failed;
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE0CSND
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE0CSND (cirgr)
SiCirGrp *cirgr;
#endif
{
   TRC3(siCirGrE0CSND)

   cirgr->querRange = cirgr->sduSp->m.siStaEvnt.rangStat.range.val;
   cirgr->querPrcs  = TRUE;

   /* generate and store the circuit state indicators in the ckt group */
   siGenCirSteInd(cirgr, &cirgr->cirSte, FALSE);

   if (siGenCirGrMsg(cirgr, M_CIRGRPQRY, MI_CIRGRPQRY) == ROK)
   {
      /* Code to check if TMR_T28 is already running when the CQM
       * is sent, i.e. if a second CQM is sent before TMR_T28's expiry
       */
      if (siIsTmrRunning(cirgr->timers, MAXSIMTIMER, TMR_T28) == ROK)
         siStopCirGrTmr(cirgr, TMR_T28);

      siStartCirGrTmr(TMR_T28, cirgr);
      RETVALUE(ROK);
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "siGenCirGrMsg returned failure\n"));  

   } 
   RETVALUE(RFAILED);
}


/*
*
*       Fun:   siCirGrE0DSND
*
*       Desc:  action function for circuit group query message 
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none.
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE0DSND
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE0DSND(cirgr)
SiCirGrp *cirgr;
#endif
{
   SiAllSdus     ev;
   SiUpSAPCb     *cb;
   SiPduCQM      *cqm;
   S16           ret;

   TRC3(siCirGrE0DSND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(cirgr->cir) != ROK)
      RETVALUE(RFAILED);
#endif



   cqm = &cirgr->pduSp->m.cirGrpQry;

   cb = siGetUprCbPtr(cirgr->cir);
   cirgr->querRange = cqm->rangStat.range.val;
   siGenCirSteInd(cirgr, &cirgr->cirSte, TRUE);

   /* initalize the outgoing status event for circuit group query response */
   MFINITSDU(&cb->mfMsgCtl, ret, (U8) 0, (U8) SI_STAREQ, NULLP, 
             (ElmtHdr *) &ev.m.siStaEvnt, (U8) NOTPRSNT, 
             cirgr->cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);
   ev.m.siStaEvnt.rangStat.eh.pres    = PRSNT_NODEF;
   ev.m.siStaEvnt.rangStat.range.pres = cqm->rangStat.range.pres;
   ev.m.siStaEvnt.rangStat.range.val  = cqm->rangStat.range.val;
   ev.m.siStaEvnt.rangStat.status.pres = NOTPRSNT;
      cmMemcpy((U8 *)&ev.m.siStaEvnt.cirStateInd, (U8 *) &cirgr->cirSte,
               sizeof(SiCirStateInd));

   cirgr->sduSp = &ev;
   siGenCirGrMsg(cirgr, M_CIRGRPQRYRES, MI_CIRGRPQRYRES);
   /* if no other processing is going on deallocate the circuit group */
   if (cirgr->state == SICG_ST_IDLE)
   {
      cirgr->cir->cirGr[cirgr->cirState] = NULLP;
      SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) cirgr, 
               (Size) sizeof(SiCirGrp));
   }

   RETVALUE(ROK);
}

/*
*
*       Fun:   siCirGrE0ESND
*
*       Desc:  action function for circuit group query response message 
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none.
*
*       File: ci_bdy4.c
*
*/
#ifdef ANSI
PRIVATE S16 siCirGrE0ESND
(
SiCirGrp *cirgr
)
#else
PRIVATE S16 siCirGrE0ESND(cirgr)
SiCirGrp *cirgr;
#endif
{
   SiCauseDgn    causeDgn;
   SiAllPdus     allPdus;
   SiStaEvnt     staEvt;
   SiPduHdr      pduHdr;
   SiCirKey      key;
   SiCirStateInd *cirStePtr;
   SiCirCb       *cir;
   SiNSAPCb      *cb;
   SiUpSAPCb     *tCb;
   S16           ret;
   U8            remCpStat;
   U8            remMtStat;
   U8            remHwStat;
   U8            i;

   TRC3(siCirGrE0ESND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(cirgr->cir) != ROK)
      RETVALUE(RFAILED);
#endif

   switch (cirgr->cir->pIntfCb->cfg.swtch)
   {
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         cirStePtr = &cirgr->pduSp->m.cirGrpQryRes.cirSteInd;
         break;
         
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "Invalid variant type %d \n",
                 cirgr->cir->pIntfCb->cfg.swtch));  
         RETVALUE(RFAILED);

   }
  
   /* error */
   if (cirgr->querRange != cirgr->pduSp->m.cirGrpQryRes.rangStat.range.val)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "Circuit query range %d does not match with in event %d\n",
           cirgr->querRange, cirgr->pduSp->m.cirGrpQryRes.rangStat.range.val));  
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cirgr->cir->key.k1.cirId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                     LSI_EVENT_INV_RANGE, LSI_CAUSE_INV_CQM, FALSE, 
                     cirgr->cir->key.k1.cirId, SI_ALRM_INVCQR);
      RETVALUE(RFAILED);
   }

   /* stop the circuit group query timer */    
   siStopCirGrTmr(cirgr, TMR_T28);
 
   cb  = siGetLwrMCbPtr(cirgr->cir);
   tCb = SIUPSAP(cirgr->cir->pIntfCb->cfg.sapId);

   cmMemset((U8 *) &key, '\0', sizeof(SiCirKey));
   cmMemset((U8 *) &causeDgn, '\0', sizeof(SiCauseDgn));
   key.k2.cic = cirgr->cir->key.k2.cic;
   key.k2.intfId = cirgr->cir->key.k2.intfId;

   /* initialize the release and cause value */
   MFINITPDU(&cb->mfMsgCtl, ret, (U8) 0, (U8) MI_RELSE, NULLP,
             (ElmtHdr *) &allPdus, (U8) PRSNT_DEF, tCb->cfg.swtch,
             (U32) MF_ISUP);
   UPDATECAUSE(allPdus.m.release.causeDgn, SIT_CCPROTERR, tCb);
   allPdus.m.release.causeDgn.recommend.pres = NOTPRSNT;

   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = M_RELSE;

   for (i = 0; i <= cirgr->querRange; i++, key.k2.cic++)
   {
      siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
      /* if circuit not found, go to the next one */
      if (cir == NULLP)
        continue;

      /* near state: transient */
      if (cirgr->cirSte.cirSteInd.val[i] == TRANS)
         continue;

       /* near state: unequipped */
      if (cirgr->cirSte.cirSteInd.val[i] == CIRUNEQP)
      {
         /* far state: unequipped/transient; DC bits == 0 */
         if ((cirStePtr->cirSteInd.val[i] == TRANS) ||
             (cirStePtr->cirSteInd.val[i] == CIRUNEQP))
            continue;
         else
         {
            /* send block */
            if ((cirStePtr->cirSteInd.val[i] & MAINTBLK) == MTIDLE)
               siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId, 
                     cirgr->cir->phyDpc, TRUE, 
                     cirgr->cir->pIntfCb->cfg.swtch, M_BLOCK, MI_BLOCK, NULLP, 
                 cirgr->cir->pIntfCb->cfg.ssf, cirgr->cir->pIntfCb->cfg.nwId);

            /* send REL */
            if ((cirStePtr->cirSteInd.val[i] & CALL_IDLE) != CALL_IDLE)
                siGenPdu(cb, &pduHdr, &allPdus, cirgr->cir->pIntfCb->cfg.swtch, 
                        cir->opc, cir->key.k2.intfId, cir->phyDpc, TRUE,
                        cir->key.k2.cic, 0, siGetPriority(M_RELSE,
                        cirgr->cir->pIntfCb->cfg.swtch), NULLP);
         }
      }
      else /* circuit equipped and not transient */
      {
         if (cirStePtr->cirSteInd.val[i] == TRANS)
            continue;
         if (cirStePtr->cirSteInd.val[i] == CIRUNEQP)
         {
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
            /* check if circuit is involved in a non-single rate call. If so, 
             * release the call on the controlling circuit.
             */
            if (cir->ctrlMultiRateCir != NULLP)
            {
               /* it is a non-single rate call */
               if (cir->ctrlMultiRateCir->siCon)
               {
                  UPDATECAUSE(causeDgn, SIT_CCPROTERR, tCb);
                  if (cir->cfg.cirId == cir->ctrlMultiRateCir->siCon->incC.cirId)
                     cir->ctrlMultiRateCir->siCon->incC.relResp = FALSE;
                  if (cir->cfg.cirId == cir->ctrlMultiRateCir->siCon->outC.cirId)
                     cir->ctrlMultiRateCir->siCon->outC.relResp = FALSE;
                  siGenRelUp(cir->ctrlMultiRateCir->key.k1.cirId, 
                             cir->ctrlMultiRateCir->siCon, &causeDgn);

               }
            }
            else
#endif
            {
               if (cir->siCon)
               {
                  UPDATECAUSE(causeDgn, SIT_CCPROTERR, tCb);
                  if( cir->cfg.cirId == cir->siCon->incC.cirId )
                     cir->siCon->incC.relResp = FALSE;
                  if( cir->cfg.cirId == cir->siCon->outC.cirId )
                     cir->siCon->outC.relResp = FALSE;
                  siGenRelUp(cir->key.k1.cirId, cir->siCon, &causeDgn);
               }
               else
                  SISTATECHNG(cir->calProcStat, CALL_IDLE);
            }   

            {
            }
            {
              /* send status indication to upper layer */
              siGenCirEvt(cir, SIT_STA_CIRUNEQPD);
              SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_UNEQPD);
              SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_UNEQPD);
            }
            continue;
         }
         /* correct call processing states */
         remCpStat = (cirStePtr->cirSteInd.val[i] & CALL_IDLE);
         switch (cirgr->cirSte.cirSteInd.val[i] & CALL_IDLE)
         {
            case CALL_IDLE:
               switch (remCpStat)
               {
                  case CALL_IDLE:
                  case TRANS:
                     break;

                  /* other side has a call - generate REL */
                  case INCBUSY:
                  case OUTBUSY:
                      siGenPdu(cb, &pduHdr, &allPdus, 
                               cirgr->cir->pIntfCb->cfg.swtch, 
                              cir->opc, cir->key.k2.intfId, 
                              cir->phyDpc, TRUE, cir->key.k2.cic, 0, 
                              siGetPriority(M_RELSE,
                              cirgr->cir->pIntfCb->cfg.swtch), NULLP);
                     break;
               }
               break;

            case INCBUSY:
               switch (remCpStat)
               {
                  case CALL_IDLE:    /* idle this side */
                  case TRANS:
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
                     /* check if circuit is involved in a non-single rate call. If so, 
                      * release the call on the controlling circuit.
                      */
                     if (cir->ctrlMultiRateCir != NULLP)
                     {
                        /* it is a non-single rate call */
                        if (cir->ctrlMultiRateCir->siCon)
                        {
                           UPDATECAUSE(causeDgn, SIT_CCPROTERR, tCb);
                           siGenRelUp(cir->ctrlMultiRateCir->key.k1.cirId, 
                                      cir->ctrlMultiRateCir->siCon, &causeDgn);

                        }
                     }
                     else
#endif
                     {
                         if (cir->siCon)
                         {
                            UPDATECAUSE(causeDgn, SIT_CCPROTERR, tCb);
                            siGenRelUp(cir->key.k1.cirId, cir->siCon, &causeDgn);
                         }
                         else
                            SISTATECHNG(cir->calProcStat, CALL_IDLE);
                     }         
                     break;
                  
                  case INCBUSY: /* generate release for both ends */
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
                     /* check if circuit is involved in a non-single rate call. If so, 
                      * release the call on the controlling circuit for both
                      * end.
                      */
                     if (cir->ctrlMultiRateCir != NULLP)
                     {
                        /* it is a non-single rate call */
                        if (cir->ctrlMultiRateCir->siCon)
                        {
                           UPDATECAUSE(causeDgn, SIT_CCPROTERR, tCb);
                           siGenRelUpLw(cir->ctrlMultiRateCir->key.k1.cirId, 
                                        cir->ctrlMultiRateCir->siCon, &causeDgn);

                        }
                     }
                     else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
                     {
                        if (cir->siCon)
                        {
                           UPDATECAUSE(causeDgn, SIT_CCPROTERR, tCb);
                           siGenRelUpLw(cir->key.k1.cirId, cir->siCon, &causeDgn);
                        }
                        else
                        {
                           siGenPdu(cb, &pduHdr, &allPdus, 
                                    cirgr->cir->pIntfCb->cfg.swtch, 
                                    cir->opc, cir->key.k2.intfId, 
                                    cir->phyDpc, TRUE, cir->key.k2.cic,
                                    0, siGetPriority(M_RELSE,
                                    cirgr->cir->pIntfCb->cfg.swtch), NULLP);
                           SISTATECHNG(cir->calProcStat, CALL_IDLE);
                        }
                     }        
                     break;

                  case OUTBUSY:
                     break;
               }
               break;

            case OUTBUSY:
               switch (remCpStat)
               {
                  case CALL_IDLE:
                  case TRANS:
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
                     /* check if circuit is involved in a non-single rate call. If so, 
                      * release the call on the controlling circuit.
                      */
                     if (cir->ctrlMultiRateCir != NULLP)
                     {
                        /* it is a non-single rate call */
                        if (cir->ctrlMultiRateCir->siCon)
                        {
                           UPDATECAUSE(causeDgn, SIT_CCPROTERR, tCb);
                           siGenRelUp(cir->ctrlMultiRateCir->key.k1.cirId, 
                                      cir->ctrlMultiRateCir->siCon, &causeDgn);

                        }
                     }
                     else
#endif
                     {             
                        if (cir->siCon)
                        {
                           UPDATECAUSE(causeDgn, SIT_CCPROTERR, tCb);
                           siGenRelUp(cir->key.k1.cirId, cir->siCon, &causeDgn);
                        }
                        else
                           SISTATECHNG(cir->calProcStat, CALL_IDLE);
                     }        
                     break;

                  case INCBUSY:
                     break;

                  case OUTBUSY:
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
                     /* check if circuit is involved in a non-single rate call. If so, 
                      * release the call on the controlling circuit for both
                      * end.
                      */
                     if (cir->ctrlMultiRateCir != NULLP)
                     {
                        /* it is a non-single rate call */
                        if (cir->ctrlMultiRateCir->siCon)
                        {
                           UPDATECAUSE(causeDgn, SIT_CCPROTERR, tCb);
                           siGenRelUpLw(cir->ctrlMultiRateCir->key.k1.cirId, 
                                        cir->ctrlMultiRateCir->siCon, &causeDgn);

                        }
                     }
                     else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
                     {
                        if (cir->siCon)
                        {
                           UPDATECAUSE(causeDgn, SIT_CCPROTERR, tCb);
                           siGenRelUpLw(cir->key.k1.cirId, cir->siCon,
                                        &causeDgn);
                        }
                        else
                        {
                           siGenPdu(cb, &pduHdr, &allPdus, 
                                    cirgr->cir->pIntfCb->cfg.swtch, 
                                    cir->opc, cir->key.k2.intfId, 
                                    cir->phyDpc, TRUE, cir->key.k2.cic,
                                    0, siGetPriority(M_RELSE,
                                    cirgr->cir->pIntfCb->cfg.swtch), NULLP);
                           SISTATECHNG(cir->calProcStat, CALL_IDLE);
                        }
                     }
                     break;
               }
               break;

            case TRANS:
               break;
         }

         /* correct maintenance states */
         remMtStat = (cirStePtr->cirSteInd.val[i] & MAINTBLK); 
         switch (cirgr->cirSte.cirSteInd.val[i] & MAINTBLK)
         {
            case MTIDLE:
               switch (remMtStat)
               {
                  case MTIDLE: /* both idle */
                     break;

                  case MTLOCBLK: /* idle, locally blocked */
                     SISTATECHNG(cir->transStat[SICIR_MTREMST] , 
                                 SICIR_ST_REMBLKED);
                     siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                           (PTR) &cir->key.k1.cirId, 
                              LSI_USTA_DGNVAL_NONE, NULLP, 
                                 LSI_USTA_DGNVAL_NONE, NULLP, 
                                    LSI_USTA_DGNVAL_NONE, NULLP);
                     SISNDLSISTAIND(&siCb.init.lmPst, 
                           LCM_CATEGORY_PROTOCOL, LSI_EVENT_REMOTE, 
                              LSI_CAUSE_BLOCK, TRUE, 
                                    cir->key.k1.cirId, SI_CIR_BLOCK);
                     cir->noRspFlgToLw = TRUE;
                     siGenCirEvt(cir, SIT_STA_CIRBLOIND);
                     break;

                  case MTLOCRMTBLK:
                     SISTATECHNG(cir->transStat[SICIR_MTREMST] , 
                                 SICIR_ST_REMBLKED);
                     siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                           (PTR) &cir->key.k1.cirId, 
                              LSI_USTA_DGNVAL_NONE, NULLP, 
                                 LSI_USTA_DGNVAL_NONE, NULLP, 
                                    LSI_USTA_DGNVAL_NONE, NULLP);
                     SISNDLSISTAIND(&siCb.init.lmPst, 
                           LCM_CATEGORY_PROTOCOL, LSI_EVENT_REMOTE, 
                              LSI_CAUSE_BLOCK, TRUE, 
                                    cir->key.k1.cirId, SI_CIR_BLOCK);
                     cir->noRspFlgToLw = TRUE;
                     siGenCirEvt(cir, SIT_STA_CIRBLOIND);
                  case MTRMTBLK: /* send unblock */
                     /* start unblocking timer */
                     siStartCirTmr(TMR_T14, cir);
                     /* start initial unblocking timer */
                     siStartCirTmr(TMR_T15, cir);
                     
                     SISTATECHNG(cir->transStat[SICIR_MTLOCST] , 
                                SICIR_ST_WTUBLACK);
                     cir->noRspFlgToUp             = TRUE;
                     siGenCirMsg(cir->key.k2.cic, cir->opc, 
                        cir->key.k2.intfId, cir->phyDpc, TRUE, 
                           cirgr->cir->pIntfCb->cfg.swtch, M_UNBLK, 
                           MI_UNBLK, NULLP, cirgr->cir->pIntfCb->cfg.ssf, 
                           cirgr->cir->pIntfCb->cfg.nwId);
                     break;
               }
               break;

            case MTLOCBLK:
               switch (remMtStat)
               {
                  case MTIDLE: 
                     /* start T12 and T13 */
                     siStartCirTmr(TMR_T12, cir);
                     siStartCirTmr(TMR_T13, cir);
                     /* don't send BLOCFM to upper layer */
                     cir->noRspFlgToUp = TRUE;
                     /* change state */
                     SISTATECHNG(cir->transStat[SICIR_MTLOCST] , 
                                 SICIR_ST_WTBLKACK);
                     siGenCirMsg(cir->key.k2.cic, cir->opc, 
                        cir->key.k2.intfId, cir->phyDpc, TRUE, 
                           cirgr->cir->pIntfCb->cfg.swtch, M_BLOCK,
                           MI_BLOCK, NULLP, cirgr->cir->pIntfCb->cfg.ssf, 
                           cirgr->cir->pIntfCb->cfg.nwId);
                     break;

                  case MTLOCBLK: 
                     /* start T12 and T13 */
                     siStartCirTmr(TMR_T12, cir);
                     siStartCirTmr(TMR_T13, cir);
                     /* don't send BLOCFM to upper layer */
                     cir->noRspFlgToUp = TRUE;
                     /* change state */
                     SISTATECHNG(cir->transStat[SICIR_MTLOCST] , 
                                 SICIR_ST_WTBLKACK);
                     siGenCirMsg(cir->key.k2.cic, cir->opc,
                        cir->key.k2.intfId, cir->phyDpc, TRUE, 
                           cirgr->cir->pIntfCb->cfg.swtch, M_BLOCK,
                           MI_BLOCK, NULLP, cirgr->cir->pIntfCb->cfg.ssf, 
                           cirgr->cir->pIntfCb->cfg.nwId);
                  case MTLOCRMTBLK:
                     SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_REMBLKED);
                     siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                           (PTR) &cir->key.k1.cirId, 
                              LSI_USTA_DGNVAL_NONE, NULLP, 
                                 LSI_USTA_DGNVAL_NONE, NULLP, 
                                    LSI_USTA_DGNVAL_NONE, NULLP);
                     SISNDLSISTAIND(&siCb.init.lmPst, 
                           LCM_CATEGORY_PROTOCOL, LSI_EVENT_REMOTE, 
                              LSI_CAUSE_BLOCK, TRUE, 
                                    cir->key.k1.cirId, SI_CIR_BLOCK);
                     cir->noRspFlgToLw = TRUE;
                     siGenCirEvt(cir, SIT_STA_CIRBLOIND);
                     break;

                  case MTRMTBLK:
                     break;
               }
               break;

            case MTRMTBLK:
               switch (remMtStat)
               {
                  case MTIDLE:
                     SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_IDLE);
                     cir->noRspFlgToLw = TRUE;
                     siGenCirEvt(cir, SIT_STA_CIRUBLIND);
                     siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                           (PTR) &cir->key.k1.cirId, 
                              LSI_USTA_DGNVAL_NONE, NULLP, 
                                 LSI_USTA_DGNVAL_NONE, NULLP, 
                                    LSI_USTA_DGNVAL_NONE, NULLP);
                     SISNDLSISTAIND(&siCb.init.lmPst, 
                           LCM_CATEGORY_PROTOCOL, LSI_EVENT_REMOTE, 
                              LSI_CAUSE_UNBLOCK, TRUE, 
                                    cir->key.k1.cirId, SI_CIR_IDLE);
                     break;

                  case MTLOCBLK:
                     break;

                  case MTRMTBLK: /* correct the peer by sending unblock */
                     cir->noRspFlgToUp             = TRUE;
                     SISTATECHNG(cir->transStat[SICIR_MTREMST] ,
                              SICIR_ST_IDLE);
                     siGenCirEvt(cir, SIT_STA_CIRUBLIND);
                     siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                           (PTR) &cir->key.k1.cirId, 
                              LSI_USTA_DGNVAL_NONE, NULLP, 
                                 LSI_USTA_DGNVAL_NONE, NULLP, 
                                    LSI_USTA_DGNVAL_NONE, NULLP);
                     SISNDLSISTAIND(&siCb.init.lmPst, 
                           LCM_CATEGORY_PROTOCOL, LSI_EVENT_REMOTE, 
                              LSI_CAUSE_UNBLOCK, TRUE, 
                                    cir->key.k1.cirId, SI_CIR_IDLE);

                  case MTLOCRMTBLK: 
                     cir->noRspFlgToUp             = TRUE;
                     /* start unblocking timer */
                     siStartCirTmr(TMR_T14, cir);
                     /* start initial unblocking timer */
                     siStartCirTmr(TMR_T15, cir);
                     SISTATECHNG(cir->transStat[SICIR_MTLOCST] ,
                              SICIR_ST_WTUBLACK);
                     siGenCirMsg(cir->key.k2.cic, cir->opc, 
                           cir->key.k2.intfId, cir->phyDpc, TRUE, 
                              cirgr->cir->pIntfCb->cfg.swtch, M_UNBLK,
                              MI_UNBLK, NULLP, cirgr->cir->pIntfCb->cfg.ssf, 
                              cirgr->cir->pIntfCb->cfg.nwId);
                     break;
               }
               break;

            case MTLOCRMTBLK:
               switch (remMtStat)
               {
                  /* correct peer by sending blocking, 
                   * correct self by clearing remote state */
                  case MTIDLE: 
                     /* start T12 and T13 */
                     siStartCirTmr(TMR_T12, cir);
                     siStartCirTmr(TMR_T13, cir);
                     /* don't send BLOCFM to upper layer */
                     cir->noRspFlgToUp = TRUE;
                     /* change state */
                     SISTATECHNG(cir->transStat[SICIR_MTLOCST] , 
                                 SICIR_ST_WTBLKACK);
                     siGenCirMsg(cir->key.k2.cic, cir->opc, 
                           cir->key.k2.intfId, cir->phyDpc, TRUE, 
                           cirgr->cir->pIntfCb->cfg.swtch, M_BLOCK, 
                           MI_BLOCK, NULLP, cirgr->cir->pIntfCb->cfg.ssf, 
                           cirgr->cir->pIntfCb->cfg.nwId);
                  case MTRMTBLK:
                     SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_IDLE);
                     cir->noRspFlgToLw = TRUE;
                     siGenCirEvt(cir, SIT_STA_CIRUBLIND);
                     siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, 
                           (PTR) &cir->key.k1.cirId, 
                              LSI_USTA_DGNVAL_NONE, NULLP, 
                                 LSI_USTA_DGNVAL_NONE, NULLP, 
                                    LSI_USTA_DGNVAL_NONE, NULLP);
                     SISNDLSISTAIND(&siCb.init.lmPst, 
                           LCM_CATEGORY_PROTOCOL, LSI_EVENT_REMOTE, 
                              LSI_CAUSE_UNBLOCK, TRUE, 
                                    cir->key.k1.cirId, SI_CIR_IDLE);
                     break;

                  case MTLOCBLK: /* correct the peer */
                     /* start T12 and T13 */
                     siStartCirTmr(TMR_T12, cir);
                     siStartCirTmr(TMR_T13, cir);
                     /* don't send BLOCFM to upper layer */
                     cir->noRspFlgToUp = TRUE;
                     /* change state */
                     SISTATECHNG(cir->transStat[SICIR_MTLOCST] , 
                                 SICIR_ST_WTBLKACK);
                     siGenCirMsg(cir->key.k2.cic, cir->opc, cir->key.k2.intfId,
                                 cir->phyDpc, TRUE, 
                                 cirgr->cir->pIntfCb->cfg.swtch, M_BLOCK, 
                                 MI_BLOCK, NULLP, cirgr->cir->pIntfCb->cfg.ssf, 
                                 cirgr->cir->pIntfCb->cfg.nwId);
                     break;

                  case MTLOCRMTBLK:
                     break;
               }
               break;
         }
         {
            /* correct hardware states */
            cmMemset((U8 *) &staEvt, (U8)NOTPRSNT, sizeof(SiStaEvnt));
            staEvt.cgsmti.eh.pres          = PRSNT_NODEF;
            staEvt.cgsmti.typeInd.pres     = PRSNT_NODEF;
            staEvt.cgsmti.typeInd.val      = HARDFAIL;
            staEvt.rangStat.eh.pres        = PRSNT_NODEF;
            staEvt.rangStat.range.pres     = PRSNT_NODEF;
            staEvt.rangStat.range.val      = cirgr->querRange;
            staEvt.rangStat.status.pres    = PRSNT_NODEF;
            staEvt.rangStat.status.len     = (cirgr->cirSte.cirSteInd.len >> 
                                                   3);
   
            remHwStat = (cirStePtr->cirSteInd.val[i] & HRDWRBLK); 
            switch (cirgr->cirSte.cirSteInd.val[i] & HRDWRBLK)
            {
               case HWIDLE:
                  switch (remHwStat)
                  {
                     case HWIDLE:
                        break;
   
                     case HWLOCBLK:
                        SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_REMBLKED);
                        cir->noRspFlgToLw = TRUE;
                        staEvt.rangStat.status.val[i >> 3] = 
                                  (0x01 << (i & 0x07));
                        SiUiSitStaInd(&tCb->pst, tCb->suId, 0, 0, 
                              cir->cfg.cirId, TRUE, SIT_STA_CGBIND,
                                 &staEvt, NULLP);
                        staEvt.rangStat.status.val[i >> 3] = 0x00;
                        break;
   
                     case HWLOCRMTBLK:
                        SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_REMBLKED);
                        cir->noRspFlgToLw = TRUE;
                        staEvt.rangStat.status.val[i >> 3] = 
                                  (0x01 << (i & 0x07));
                        SiUiSitStaInd(&tCb->pst, tCb->suId, 0, 0, 
                              cir->cfg.cirId, TRUE, SIT_STA_CGBIND,
                                 &staEvt, NULLP);
                        staEvt.rangStat.status.val[i >> 3] = 0x00;
                     case HWRMTBLK:
                        /* send reset to clear the remote blocking of peer */
                        siGenCirMsg(cir->key.k2.cic, cir->opc, 
                           cir->key.k2.intfId, cir->phyDpc, TRUE, 
                           cirgr->cir->pIntfCb->cfg.swtch, M_RESCIR, MI_RESCIR, 
                           NULLP, cirgr->cir->pIntfCb->cfg.ssf, 
                           cirgr->cir->pIntfCb->cfg.nwId);
                        break;
                  }
                  break;
   
               case HWLOCBLK:
                  switch (remHwStat)
                  {
                     case HWIDLE:
                        staEvt.rangStat.status.val[i >> 3] = 
                                  (0x01 << (i & 0x07));
                        cirgr->sduSp = (SiAllSdus *) &staEvt;
                        siGenCirGrMsg(cirgr, M_CIRGRPBLK, MI_CIRGRPBLK);
                        staEvt.rangStat.status.val[i >> 3] = 0x00;
                        break;
                                   
                     case HWLOCBLK:
                        staEvt.rangStat.status.val[i >> 3] = 
                                  (0x01 << (i & 0x07));
                        cirgr->sduSp = (SiAllSdus *)&staEvt;
                        siGenCirGrMsg(cirgr, M_CIRGRPBLK, MI_CIRGRPBLK);
                        staEvt.rangStat.status.val[i >> 3] = 0x00;
   
                     case HWLOCRMTBLK:
                        SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_REMBLKED);
                        cir->noRspFlgToLw = TRUE;
                        staEvt.rangStat.status.val[i >> 3] = 
                                  (0x01 << (i & 0x07));
                        SiUiSitStaInd(&tCb->pst, tCb->suId, 0, 0, 
                              cir->cfg.cirId, TRUE, SIT_STA_CGBIND,
                                 &staEvt, NULLP);
                        staEvt.rangStat.status.val[i >> 3] = 0x00;

                     case HWRMTBLK:
                        break;
                  }
                  break;
   
               case HWRMTBLK:
                  switch (remHwStat)
                  {
                     case HWIDLE:
                        SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_IDLE);
                        cir->noRspFlgToLw = TRUE;
                        staEvt.rangStat.status.val[i >> 3] = 
                                  (0x01 << (i & 0x07));
                        SiUiSitStaInd(&tCb->pst, tCb->suId, 0, 0, 
                              cir->cfg.cirId, TRUE, SIT_STA_CGUIND,
                                 &staEvt, NULLP);
                        staEvt.rangStat.status.val[i >> 3] = 0x00;
                        break;
   
                     case HWLOCBLK:
                        break;
   
                     case HWRMTBLK:
                     case HWLOCRMTBLK:
                        staEvt.rangStat.status.val[i >> 3] = 
                                  (0x01 << (i & 0x07));
                        cirgr->sduSp = (SiAllSdus *)&staEvt;
                        siGenCirGrMsg(cirgr, M_CIRGRPUBLK, MI_CIRGRPUBLK);
                        staEvt.rangStat.status.val[i >> 3] = 0x00;
                        break;
                  }
                  break;
   
               case HWLOCRMTBLK:
                  switch (remHwStat)
                  {
                     case HWIDLE:
                        staEvt.rangStat.status.val[i >> 3] = 
                                  (0x01 << (i & 0x07));
                        cirgr->sduSp = (SiAllSdus *)&staEvt;
                        siGenCirGrMsg(cirgr, M_CIRGRPBLK, MI_CIRGRPBLK);
                        staEvt.rangStat.status.val[i >> 3] = 0x00;
   
                     case HWRMTBLK:
                        SISTATECHNG(cir->transStat[SICIR_HWREMST] , SICIR_ST_IDLE);
                        cir->noRspFlgToLw = TRUE;
                        staEvt.rangStat.status.val[i >> 3] = 
                                  (0x01 << (i & 0x07));
                        SiUiSitStaInd(&tCb->pst, tCb->suId, 0, 0, 
                              cir->cfg.cirId, TRUE, SIT_STA_CGUIND,
                                 &staEvt, NULLP);
                        staEvt.rangStat.status.val[i >> 3] = 0x00;
                        break;
   
                     case HWLOCBLK:
                        staEvt.rangStat.status.val[i >> 3] = 
                                  (0x01 << (i & 0x07));
                        cirgr->sduSp = (SiAllSdus *)&staEvt;
                        siGenCirGrMsg(cirgr, M_CIRGRPBLK, MI_CIRGRPBLK);
                        staEvt.rangStat.status.val[i >> 3] = 0x00;
                        break;
   
                     case HWLOCRMTBLK:
                        break;
                  }
                  break;
            }
         }
      }
#ifdef ZI
      ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
#endif
   }

   MFINITSDU(&tCb->mfMsgCtl, ret, (U8) MI_CIRGRPQRYRES, (U8) SI_STAREQ,
             (ElmtHdr *) &cirgr->pduSp->m.cirGrpQryRes, (ElmtHdr *) &staEvt, 
             (U8) PRSNT_NODEF, cirgr->cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);

   if (tCb && (tCb->state == SI_BND))
      SiUiSitStaInd(&tCb->pst, tCb->suId, 0, 0, cirgr->cir->key.k1.cirId,
                    TRUE, SIT_STA_CGQRYRSP, &staEvt, NULLP);

   /* if any other circuit group event is not pending */
   if (cirgr->state == SICG_ST_IDLE)
   {
      cirgr->cir->cirGr[cirgr->cirState] = NULLP;
      SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) cirgr, 
               (Size) sizeof(SiCirGrp));
   }
   else
      cirgr->querPrcs = FALSE;

#ifdef ZI
   ziUpdPeer();
#endif

   RETVALUE(ROK);
}

/************* LAYER MANAGER GENERATED CIRCUIT EVENTS ************************/

  
/*
*
*       Fun:   siMngCirGrpReq
*
*       Desc:  Process Management Circuit Group unblock/block/reset 
*              request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI 
PUBLIC S16 siMngCirGrpReq
(
SiCirCb     *cir,
U8          evntType,
SiStaEvnt   *siStaEvnt 
)
#else
PUBLIC S16 siMngCirGrpReq(cir, evntType, siStaEvnt)
SiCirCb     *cir;
U8          evntType;
SiStaEvnt   *siStaEvnt;
#endif
{
   SiUpSAPCb *cb;        /* for upper interface */ 
   U8        ccEvntType;

   TRC3(siMngCirGrpReq);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   /* Update the circuit control block */
   cir->sduSp = (SiAllSdus *)siStaEvnt;

   /* find upper SAP */
   cb = siGetUprCbPtr(cir);
   if ( cb == (SiUpSAPCb *)NULLP ) 
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf, 
             "No upper SAP for swtch %#x\n", cir->pIntfCb->cfg.swtch));  

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI555, (ErrVal )cir->pIntfCb->cfg.swtch,
                 "[switch] has no corresponding upper SAP");
#endif
      RETVALUE(RFAILED);
   }

   /* Now process it as if it comes from CC */
   if (siProcCirGrEvt(cir, evntType, siStaEvnt) != ROK )
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "siProcCirGrEvt failed\n"));  

#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI556, (ErrVal) 0, "can't process LM circuit grp req");
#endif
      RETVALUE(RFAILED);
   }

   switch (evntType)
   {
      case SIT_STA_CGUREQ:
         ccEvntType = SIT_STA_LMCGUREQ;
         break;

      case SIT_STA_CGBREQ:
         ccEvntType = SIT_STA_LMCGBREQ;
         break;

      case SIT_STA_GRSREQ:
         ccEvntType = SIT_STA_LMGRSREQ;
         break;
    
      case SIT_STA_CGQRYREQ:
         ccEvntType = SIT_STA_LMCQMINFOREQ;
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "Unknown event type %d\n", evntType));
         RETVALUE(RFAILED);
   }

   /* Send status indication to CC */
   if (cb && (cb->state == SI_BND))
#ifdef IW
      if (ccEvntType != SIT_STA_LMCQMINFOREQ)
      {
#endif 
      SiUiSitStaInd(&cb->pst, cb->suId, 0, 0, cir->cfg.cirId, FALSE,
                    ccEvntType, siStaEvnt, NULLP);
#ifdef IW
      }
#endif
   RETVALUE(ROK);
}

  
/*
*
*       Fun:   siMngCirBlk
*
*       Desc:  Process Management Circuit Blocking Request 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 siMngCirBlk
(
SiCirCb *cir,
S16     locFlg
)
#else
PUBLIC S16 siMngCirBlk(cir, locFlg)
SiCirCb *cir;
S16     locFlg;
#endif
{
   TRC2(siMngCirBlk);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   if (locFlg)
   {
       cir->noRspFlgToUp = FALSE;
       siProcCirEvt(cir, SIT_STA_CIRBLOREQ, FALSE);
       siGenCirEvt(cir, SIT_STA_CIRLOCALBLOIND);
   }
   else
   {
      cir->noRspFlgToLw = TRUE;
      /* waiting for blocking response */
      SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_WTBLKRSP);
      siGenCirEvt(cir, SIT_STA_CIRBLOIND);
   }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call. If so, find the connection
    * block in the controlling circuit and jump into call processing matrix 
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* it is a non-single rate call */
      if (cir->ctrlMultiRateCir->siCon)
      {
         /* check the mulReset flag */
         if ((cir->ctrlMultiRateCir->siCon->incC.conPrcs) && 
             (cir->ctrlMultiRateCir->siCon->incC.cirId ==
              cir->ctrlMultiRateCir->cfg.cirId) &&
             (cir->ctrlMultiRateCir->siCon->incC.mulReset == FALSE))
         {
            siActDat(cir->ctrlMultiRateCir->key.k1.cirId,
                     cir->ctrlMultiRateCir->siCon, IEI_BLKREQ);
         }         
         if ((cir->ctrlMultiRateCir->siCon->outC.conPrcs) &&
             (cir->ctrlMultiRateCir->siCon->outC.cirId ==
              cir->ctrlMultiRateCir->cfg.cirId) &&
             (cir->ctrlMultiRateCir->siCon->outC.mulReset == FALSE))
         {
            siActDat(cir->ctrlMultiRateCir->key.k1.cirId,
                     cir->ctrlMultiRateCir->siCon, IEI_BLKREQ);
         }

      }
      else
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                 "connection in controlling ckt is NULLP\n"));  
         RETVALUE(RFAILED);
      }
   }
   else /* single rate call procedure */
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   {
      if (cir->siCon)
         siActDat(cir->cfg.cirId, cir->siCon, IEI_BLKREQ);
   }
   RETVALUE(ROK);
} /* end of siMngCirBlk */

  
/*
*
*       Fun:   siMngCirUnBlk
*
*       Desc:  Process Management Circuit Unblocking Request 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 siMngCirUnBlk
(
SiCirCb *cir,
S16 locFlg
)
#else
PUBLIC S16 siMngCirUnBlk(cir, locFlg)
SiCirCb *cir;
S16 locFlg;
#endif
{
   TRC2(siMngCirUnBlk);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (siChkCirIntf(cir) != ROK)
      RETVALUE(RFAILED);
#endif

   if (locFlg)
   { 
      cir->noRspFlgToUp = FALSE;
      siProcCirEvt(cir, SIT_STA_CIRUBLREQ, FALSE);
      siGenCirEvt(cir, SIT_STA_CIRLOCALUBLIND);
   }
   else
   {
      cir->noRspFlgToLw = TRUE;
      SISTATECHNG(cir->transStat[SICIR_MTREMST] , SICIR_ST_WTUBLRSP);
      siGenCirEvt(cir, SIT_STA_CIRUBLIND);
   }
   RETVALUE(ROK);
} /* end of siMngCirUnBlk */

  
/*
*
*       Fun:   siMngCirRes
*
*       Desc:  Process Management Circuit Reset Request 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy4.c
*
*/

#ifdef ANSI
PUBLIC S16 siMngCirRes
(
SiCirCb *cir,
U8      locFlag
)
#else
PUBLIC S16 siMngCirRes(cir, locFlag)
SiCirCb *cir;
U8      locFlag;
#endif
{
   TRC2(siMngCirRes);

   if (locFlag == TRUE)
   {
      siProcCirEvt(cir, SIT_STA_CIRRESREQ, FALSE);
      siGenCirEvt(cir, SIT_STA_CIRLOCRES);
   }
   else if (locFlag == FALSE)
   {
      cir->noRspFlgToLw = TRUE;
      siProcCirEvt(cir, CEI_RES, TRUE);
   }

   RETVALUE(ROK);
} /* end of siMngCirRes */


/*
*
*       Fun:   siHndlCQMonUneqCIC
*
*       Desc:  This function handles CQM on unassigned/unequipped CIC
*
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 siHndlCQMonUneqCIC
(
SiNSAPCb *nCb,
Dpc      cgAdr,              /* originating point code */
Dpc      cdAdr,              /* destination point code */
Cic      cicVal,             /* CIC val */
SiAllPdus *message           /* all pdus structure */
)
#else
PUBLIC S16 siHndlCQMonUneqCIC(nCb, cgAdr, cdAdr, cicVal, message)
SiNSAPCb *nCb;
Dpc      cgAdr;              /* originating point code */
Dpc      cdAdr;              /* destination point code */
Cic      cicVal;             /* CIC val */
SiAllPdus *message;          /* all PDUs structure */
#endif
{
   U8         queryRange;
   S16        ret;
   SiPduHdr   pduHdr;
   SiIntfCb    *siIntfCb;
   LnkSel     lnkSel;
   Cntr       idx;
   SiCirKey   key;
   SiCirCb    *cir;
   SiAllSdus  ev;
   SiUpSAPCb  *tCb;
   SiPduCQM   *cqm;
   SiRangStat *rangStat;
   SiCirStateInd cirState;
  
   TRC2(siHndlCQMonUneqCIC)

   /* decode the message */
   MFDECPDU(&nCb->mfMsgCtl, ret, (ElmtHdr *) message);
   if ((ret != MFREOM) && (ret != ROK))
   {
      RETVALUE(ret);
   }
 
   /* check DPC status if configured */
   ret = siFindIntf(&siIntfCb, 0, cgAdr, nCb->cfg.nwId, nCb->cfg.ssf, 
                        cdAdr, SIINTF_KEY_2);
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Error searching DPC for dpc %ld\n", cgAdr));
      RETVALUE(ret);
   }

   /* On receipt of User part available or any other message, timer T4 is
    * stopped and user part (DPC) is marked available again and traffic is
    * restarted.
   */
   if (siIntfCb->state == SI_INTF_UNAVAIL)
   {
      SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "Dpc state was unavailable. making available\n"));
      if (siIntfCb->t4Runing)
      {
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "t4 was running . stopping it.\n"));
         siStopIntfTmr(siIntfCb, TMR_T4);
         siIntfCb->t4Runing = FALSE;
      }
      siInitUstaDgn(LSI_USTA_DGNVAL_INTF, (PTR) &siIntfCb->cfg.intfId,
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP);
   
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE,
                     LSI_EVENT_USERPART, LSI_CAUSE_AVAILABLE,
                     TRUE, (Dpc) siIntfCb->cfg.intfId, SIMTP_RESUME);
  
      siIntfCb->state = SI_INTF_AVAIL;
   }
   
   rangStat = (SiRangStat *)&message->m.cirGrpQry.rangStat;
   if (siValidateRangStat(rangStat, siIntfCb->cfg.swtch, 
                          CGEI_CGQRY, 0x00) != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Range or Status is not valid.Dumping\n"));
      RETVALUE(RFAILED);
   }
   
   cqm = &message->m.cirGrpQry;
   tCb = SIUPSAP(siIntfCb->cfg.sapId);
   queryRange = cqm->rangStat.range.val;
    
   /* prepare ciruit state indicator */
   cmMemset((U8 *) &cirState, (U8) NOTPRSNT, sizeof(SiCirStateInd));
   cirState.eh.pres        = PRSNT_NODEF;
   cirState.cirSteInd.pres = PRSNT_NODEF;
   cirState.cirSteInd.len  = 0;
   
   /* initialize the key */
   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
   key.k2.cic = cicVal;
   key.k2.intfId = siIntfCb->cfg.intfId;
    
   for (idx = 0; idx <= (Cntr) queryRange; idx++)
   {
      cirState.cirSteInd.len++;
      cirState.cirSteInd.val[idx] = 0x00; /* initialize the status array */
         
      siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);
      siGetCirState(cir, &cirState.cirSteInd.val[idx]);
         
      /* if it is unequipped then on getting CQM from remote
         end state should be made equipped.
      */
      if( (cir) &&
          ((cir->transStat[SICIR_MTREMST] == SICIR_ST_UNEQPD) ||
           (cir->transStat[SICIR_HWREMST] == SICIR_ST_UNEQPD) ))
      {
         cir->transStat[SICIR_MTREMST] = SICIR_ST_IDLE;
         cir->transStat[SICIR_HWREMST] = SICIR_ST_IDLE;
      }
      
      key.k2.cic++;
   }
   
   /* initalize the outgoing status event for circuit group query response */
   MFINITSDU(&tCb->mfMsgCtl, ret, (U8) 0, (U8) SI_STAREQ, NULLP,
             (ElmtHdr *) &ev.m.siStaEvnt, (U8) NOTPRSNT, tCb->cfg.swtch,
             (U32) MF_ISUP);
   ev.m.siStaEvnt.rangStat.eh.pres    = PRSNT_NODEF;
   ev.m.siStaEvnt.rangStat.range.pres = cqm->rangStat.range.pres;
   ev.m.siStaEvnt.rangStat.range.val  = cqm->rangStat.range.val;
   ev.m.siStaEvnt.rangStat.status.pres = NOTPRSNT;
   
      cmMemcpy((U8 *)&ev.m.siStaEvnt.cirStateInd, (U8 *) &cirState,
               sizeof(SiCirStateInd));
   
   /* build CQR and send it */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_CIRGRPQRYRES;
      
   MFINITPDU(&nCb->mfMsgCtl, ret, (U8) SI_STAREQ, (U8) MI_CIRGRPQRYRES,
             (ElmtHdr *)&ev.m.siStaEvnt, (ElmtHdr *) message,
             (U8) PRSNT_NODEF, tCb->cfg.swtch, (U32) MF_ISUP);
   /* si025.220 - Modification - modify arguments in siGetLnkSel */
   /* si009.220 - Modified: to pass cic into siGetLnkSel. */
   key.k2.cic = cicVal;
   siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);

   if (cir == (SiCirCb *) NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "can not find circuit control block. cic=%x, intfId=%lx\n",
             cicVal, key.k2.intfId));

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIC, (PTR) &cicVal,
                    LSI_USTA_DGNVAL_INTF, (PTR) &key.k2.intfId,
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERNAL,
                     LCM_EVENT_INV_EVT, LSI_CAUSE_INV_CIRCUIT, FALSE,
                     cicVal, SI_ALRM_CIR_UNEQUPD);
/* si045.220 Modified: To send the UCIC for invalid circuit */
      /*RETVALUE(RFAILED);*/
   }

siGetLnkSelIntf(nCb, &lnkSel,tCb->cfg.swtch, key.k2.cic,key.k2.intfId);
/* si045.220 END Modified: To send the UCIC for invalid circuit */
         
   ret = siGenPdu(nCb, &pduHdr, message, tCb->cfg.swtch,
                  cdAdr, siIntfCb->cfg.intfId, cgAdr, TRUE, 
                  cicVal, lnkSel, siGetPriority(M_UNEQUIPCIC,
                     tCb->cfg.swtch), NULLP);
   RETVALUE(ROK); 
} /* end of siHndlCQMonUneqCIC */

/* si011.220, Addition: Added function for assignment of range and status values */
  
/********************************************************************30**
  
         End of file:     ci_bdy4.c@@/main/36 - Wed Jul 25 13:20:46 2001
 
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  bn    1. initial release
             ---  jrl   2. trillium development system checkpoint (dvs)
                           at version: 1.0.0.0
 
1.2          ---  bn    1. add support for ansi

1.3          ---  jrl   1. remove includes for spt.h and spt.x

1.4          ---  rk    1. miscellaneous changes
             ---  jrl   2. add breaks for default cases


1.5          ---  rk    1. miscellaneous changes

1.6          ---  bn    1. remove ret from siGenCirMsg
             ---  bn    2. cast statement to U8 in siCirGrBlk
             ---  bn    3. remove staEvnt from siCirGrRes

1.7          ---  bn    1. add support for ansi 92.
             ---  bn    2. changed timer routines to common functions.
             ---  bn    3. added include cm5.x and cm5.h.
             ---  bn    4. change return( to RETVALUE(

1.8          ---  bn    1. initialized siCirGrResAck rangeStat from group's  
                           rangeStat in siCirGrRes.

1.9          ---  bn    1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.10         ---  bn    1. added cast (ElmtHdr *) in MFINITELMT in siCirGrRes.

1.11         ---  bn    1. changed to ignore group reset, blocking, query
                           and unblocking messages if received with bad 
                           rangStat.
                        2. corrected a typo.
                        3. start group reset timer when generating group 
                           reset message.
                        4. stop circuit group timers in siCirGrResReq and
                           siCirGrResAck.

1.12         ---  bn    1. added generation of group reset acknowledge when
                           get circuit group reset collision.
             ---  bn    2. initiaize cir state to BLKACK in when circuit reset
                           or group reset message received and circuit is 
                           blocked.
             ---  bn    3. correction in siCirGrRes.
             ---  bn    4. correction in siCirGrQuer.
             ---  bn    5. changed to support new interfaces.

1.13         ---  bn    1. added generation of SiUiSitStaInd when get
                           circuit group reset acknowledge.
             ---  bn    2. removed ifdef ERRCHK around ret in
                           siCirGrResAck

1.14         ---  bn    1. added support for Q.767 and Singapore Telecom.

1.15         ---  bn    1. text changes

1.16         ---  bn    1. si003.23, si004.23

1.17         ---  bn    1. text changes

1.18         ---  bn    1. chnaged SW_... to LSI_SW_...
             ---  bn    2. miscelenious changes.

1.19         ---  bn    1. changed ifdef SP to ifdef SI_SPT.
             ---  bn    2. corrected gcc compile warnings.
             ---  bn    3. changed processing of the ciecuit group reset 
                           messages to allow circuit groups to go over the
                           unequipped circuits.

1.20         ---  bn    1. changed LSI_SW_CCITT to LSI_SW_ITU and 
                           LSI_SW_ANSI?? to LSI_SW_ANS??.

1.21         ---  bn    1. necessary recovery actions placed in error scenarios
             ---  bn    2. misceleneous corrections.

1.22         ---  dm    1. miscellaneous changes

1.23         ---  pc    1. added ETSI variant for SI
             ---  bn    2. validated range while processing CQM against 
                           different numbers for ANSI and other versions.
             ---  bn    3. removed generation of Unequipped CIC message in 
                           case of CQM.
             ---  bn    4. corrected initialization of CQM when processing
                           CQ request.

1.24         ---  bn    1. text change

1.25         ---  dm    1. added support for FTZ protocol variant.
             ---  dm    2. corrected typo siCirGrRes
             ---  dm    3. added include cm_ss7.x

 
1.24         ---  dm    1. Fixed typo in siCirGrResReq

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.26         ---      ao   1. added a check for noRspToLw flag in siCirBlkRsp.
             ---      ao   2. added two new states for group block/unblock
                              handling to avoid problems when receiving the 
                              same message which had just been sent.
             ---      bn   3. added support for circuit state indicator
             ---      ao   4. changed siCirGrQuerAck functions to set the 
                              circuit state
             ---      ao   5. added initialization of conPrcs flag in 
                              siMngCirRes. Otherwise it can crash when receiving
                              the release complete message
             ---      ao   6. added status indication in siUnblkRmt for the
                              cases LOCUNBLKRSP and UNBLKRSP
             ---      dm   7. added status indication in siCirGrRes for the
                              cases CIRGRIDLE and CIRGRBLKRSP (si00x.210)
             ---      dm   8. added status indication in siCirGrResAck for
                              notifying the change of circuit status

1.26         ---      ao   1. Modified siCirGrQuerAck to handle uneqip state
             ---      ao   2. Swapped RelInd with StaInd in the cases of reset
                              messages processing.
             ---      ao   3. added missing brackets in siCirGrResAck
             ---      ao   4. changed siGenCirMsg to use the same SLS when
                              a connection exists.
             ---      ao   5. corrected siCirGrRes, was using wrong control
                              block when sending status indication to upper
                              layer
             ---      ao   6. Changed coding of circuit state indicator 
                              for ANSI.
             ---      rh   7. removed the possibility of race conditions in
                              tightly coupled mode for circuit mgmt fns.
                              (status indication was sent to upper layer prior
                              to state change, which would have caused problems)

             ---      ao   8. Removed start of individual blocking timers
                              for circuit group blocking.
             ---      aa   9. changed the cirGr pointer to NULLP before sending StaInd 
                              to the upper user in function siCirGrResAck
             ---      rh   10. corrected range validation in circuit group msgs
                               # of ckts = rangeval + 1
             ---      rh   11. In siCirGrResAck() in case of circuit group state
                               CIRGRRESACK after idling the call processing 
                               state, connection on the ckt if any, is released.

1.27         ---      rh   1. corrected 'noRspFlgToLw' flag being set for the 
                              circuit states which transition to LOCBLKED

1.28         ---      rh   1. Re-release - The procedures were written
                              from scratch. Previous changelogs have no
                              significance
                      rs   2. Changed siMngCirUnBlk/siMngCirBlk to report
                              these events to CC whenever such a request
                              is issued from Layer manager.
                      rs   3. Replaced errorind with release indication 
                               wherever applicable.
                      rs   4. Change to make TFGR applicable for ANSI 92.
                      rs   5. Changes in Reset functions releated to release
                              primitive exchange.
                      ym   6. Functions related to circuit group control
                              requests added like siMngCirGrpUnBlk,
                              siMngCirGrpBlk and siMngCirGrpReq etc.
                           7. Function name is corrected.

1.29         ---      rh   1. Fixed SITVER2 related problems in h/w oriented
                              block ack/response
             ---      ym   1. Change in siProcCGBREQ and siCirGrE04SND
                              to disable sending of 4 messages .
             ---      ao   1. Changed processing of group messages for ANSI
                              action is now taken on the first message.
                           2. Removed sending of UCIC to the peer when ISUP
                              gets a request for an unknow circuit from the
                              application layer.
                           3. Corrected setting of status bit in GRA
                           4. Fixed loop for processing GRS
                           5. Changed format of hw CGB when prcessing GRS for
                              hardware blocked circuits.
             ---      rh   1. Fixed the state machine function siCirGrE03S02
                              loop to jump into all the ciruit control blocks
                              indicated in the CGUA
             ---      rh   1. Fixed the initialization of status event from
                              the received CGBA in siCirGrE01S01
                      rh   2. Fixed T28 not stopped when CQR is received
                      rh   2. Fixed initialization of mask in GRA handling
                              function
             ---      ym   1. Enabled debug printing classes
             ---      ym   2. Miscellanous modifications to DEBUG printing
             ---      rh   3. Misc. changes - Mgmt circuit group request only
                              uses one common function.
1.30         ---      ao   1. Added Russian variant
1.30+        ---      ym   1. Handling of different messages on unequipped
                              circuit is corrected.
                           2. Priority of RELEASE message is corrected.
                           3. Blocking function siCirLocE06S03 is made 
                              to return ROK
                           4. Updating local/remote states on getting 
                              UBL/CGU(mnt/hw) resp/ack 
                           5. Fix to stop BLA generation when GRA is received
                           6. Fix to stop ongoing circuit group procedures
                           7. Fix for sending individual block 
                              unconditionally (now under SI_INDBLO_ON_GRS 
                              flag).
                           8. Disabling resending of HW oriented CGB on 
                              getting GRS for ansi-92 variant.
                           9. noRspFlgToUp is properly updated in 
                              handling of unblock and block request.
                           10.Remote unequipped state is updated properly on
                              getting CQM from peer.
                           11.Sending appropriate group message on getting 
                              unexpected CGBA/CGUA.
                           12.The circuit query response is corrected for
                              local state as RMTblk and remote state as
                              IDLE.
                           13.Indication to CC are sent if circuit state 
                              is modified on getting CQR .
                           14.siValidateRangeStat is corrected for presence
                              of range and status.
             ---      ym   1. cirFlg is checked to know the max number of ckts.
                              siValidateRangStat is corrected for the same.
                              Note that these changes are under LSI_PARAMETER
                              flag.
             ---      ym   1. The status field is enabled on sending GRA in
                              response to GRS.
             ---      ym   1. Alarm is generated if some error is detected
                              in range or status.
                              This change is under LSI_PARAMETER flag.
             ---      ym   1. The recommend field in the cause parameter is
                              set to NOTPRSNT.
                           2. On getting circuit reset request remote mntce
                              state is reset to idle if it is blocked .
                           3. On getting circuit group reset request the remote
                              mntce state is reset to idle if it is blocked.
             ---      ym   1. The warnings related to siStaEvnt is removed.
                           2. Remote state is compared with remote state
                              instead of local state for Group Reset Req.
                           3. Updation of remote unequipped state is corrected 
                              for CQM handling.
                           4. The checks on the range field is removed as it
                              is already done prior to calling this function.
             ---      ym   1. The processing for CGUA/CGBA takes into 
                              account the range for one octet of status .
                           2. Range and status are properly copied in cirgr
                              on sending CGB/CGU on getting unsolicited 
                              CGUA/CGBA.
                           3. The cause value is corrected for mismatch in 
                              the connection states for CQR handling
                           4. Handling of CQR for HW blocked states is 
                              corrected.
                           5. Alarm with cause unblock is generated on
                              getting RES on a non-idle circuit.
                           6. Connection related processing is done 
                              on getting CGB from peer.
                           7. Success is returned from state function 
                              siCirRemE15SND.
             ---      ym   1. Ubl/CGUInd is generated on getting RSC/GRS
                              on a circuit with remote state blocked.
                           2. The recommendation field in generation of the
                              RLC is init to not present.
                           3. On getting CGUReq (HW) for a circuit (WTBLA)
                              the associated timers for blocking are stopped
                              for ANS92.
                           4. For ANS92 effective maintainance state is
                              determined after taking into account the
                              HW states also.
                           5. A chk is performed to skip the spare combination
                              of circuit state indicator in cqr processing.
                           6. Handling of CQR for out, out is corrected
                           7. Circuit state is marked locally blocked on getting
                              cvr indicating *, unequipped
1.31         ---      ym   1. Changes related to addition of NTT variant in
                              ISUP.
             ---      ym   1. The ziUpdPeer is called after handling of every
                              circuit message and event. This makes the 
                              resolution of updation to a circuit for ISUP 
                              mntce circuit/circuit group operations.
             ---      tz   1. The filling of the circuit state idctr
                              is corrected.
                           2. The handling of GRS is corrected for SITVER2
                              not defined, case.
             ---      tz   1. Deleted code in function siHndlCQMonUneqCIC  
                              and siGenCirSteInd to avoid reseting the remote
                              unequipped state of the circuit to IDLE on  
                              receiving CQM message.
             ---      ym   1. If SITVER2 is not defined then on getting
                              group reset the circuit related processing
                              is performed for all the circuits covered 
                              in the range received in the group reset. The
                              connection related handling is performed
                              taking into account the flow control process.
                              For all processed (wrt circuit processing 
                              and connection processing) circuits at any 
                              given time the resFlag in circuit 
                              control block is TRUE. 
                              At the expiry of TMR_TGRES (the flow control
                              timer) the processes circuits are handled
                              wrt any new connection and next numResInd 
                              circuits are processed for GRS.
1.34         ---      ym   1. Code under NEW dummy compile option is removed.
                           2. OUT define is changed to OUTTYPE for NT 
                              compilation.

/main/35     ---      rrb  1. Modified code to use the OPC from the interface
                              control block instead of the "dfltOpc" field in
                              NSAP, while sending UCIC message for a non-
                              existent or unequipped circuit.
                      tz   2. Changed code in funciton siCirGrE0BS06 so that
                              the affected circuits are controlled by the
                              range value not by the total bits sepcified
                              in the status field.
                           3. Changed a typo error in the SitStaInd
                              primitive.
                           4. Corrected a compilation warning of unused
                              parameter evnt in function siGenCirSteInd.
           si004.218  hy   1. Changed funcion pointer to siRETOK instead
                              of NULLP under the idle state when processing
                              GRA in circuits status matrix.
             ---      hy   1. Added the variant type for ANS95, ITU97 and ETSIV3.
                           2. Added the codes to only forward an indication to 
                              CC if subsequent CGBs received instead of 
                              processing the CGB again in siCirGrE06S01. 
                              Assigned the field "firstRevdStat" of cirgr when 
                              first received CGB in siCirGrE06S00, siCirE06S07.
                           3. Added the codes to only forward an indication to 
                              CC if subsequent CGUs received instead of 
                              processing the CGB again in siCirGrE08S01. 
                              Assigned the field "firstRevdStat" of cirgr when 
                              first received CGB in siCirGrE06S00.
                           4. Changes the codes in function siCirGrE0ASND to 
                              start timer and allocated cirgr if required when 
                              sending CGB.
                           5. changes for non-single rate implemenation.
                           6. Added "continue" if the cir is NULLP on receipt of 
                              GRS/GRA with CAM in function siCirGrE0ASND and 
                              siCirGrE05S03.
                           7. Added code to send CGBINFO indication to CC
                              if receives second CGB from nw in function
                              siCIrGrE06S01.
                           8. Added code to check mulReset flag before storing 
                              the cntrl circuit Cb into a local structure 
                              "mCtrlPtrs" if the affected circuits invloved 
                              in a non-single rate call while processing the 
                              group related messages.
                      bsp  9. Changed hash define names which were changed
                              in sit.h to resolve clash between sit.h and int.h
                      hy  10. changes for removal of swtch and ssf field in
                              circuit control block.
                      bsp 11. Removed SITVER2 flag.
                          12. Patch propogation related changes:
                              . Changed code in function siCirGrE0ASND so
                                that it processed the GRS correctly when
                                there is some mntc. blocking event pending.
                              . Added a new function to the state matrix which
                                gets called whenever there is a blocking 
                                request, and ISUP is in waiting for reset 
                                ack state
                              . Corrected numCir value
                              . Added code to siCirGrE0BS06 to take care of the
                                situation when the range for circuit group is 0
                              . Definition of lastCic in function siCirGrE0BS06
                                is changed to U16 since it will hold a cic
                                value which is U16 instead of U8.
                              . Changed code in function siCirGrE0ASND so
                                that in the case of processing GRS for ANS92
                                or NTT a correct CGB with proper range and
                                status is generated for circuits in locally
                                (hardware) blocked state.
                              . Corrected GRA handling for range 0 cases
                              . Modified siCirGrE01S01 & siCirGrE03S02 such that
                                status bits of CGBA/CGUA are processed properly
                              . Added siCirRemE10S06 such that Blocking
                                indication is properly reported to application
                      hy  13. Add new function siCmpCAM to compare the CAM 
                              parameter while processing GRS/GRA messages
                              for ANS95.
                      bsp 14. Corrected compilation error of unused variable
                              and enabled GRS with range zero check for 
                              applicable variants only
                      hy  15. Modified the code on checking interface block 
                              of circuit ctrl block in siGetCirState. 
                          16. Added a local array to store the unequipped ckt
                              state when handling the GRS response if
                              CAM is present in siCirGrE0BS06 for ANS95
                              and some other misc. changes related to 
                              GRS/GRA handling if CAM is present.
                          17. Remove the #if 1 or #if 0 tags in the file.
                          18. Modified the code to validate the range and
                              status for swtch type other than ANS95 if 
                              SS7_ANS95 is defined in function siProcCirGrMsg
                              and siProcCirGrEvt
                          19. Added code to check if the status bit is
                              presented in GRS msg, if so, generate an 
                              alarm to the LM in siProcCirGrMsg.
                          20. Added code to check if the status bit is
                              presented in GRS event. If so, make the 
                              status is not present in siProcCirGrEvt.
                          21. Additional patch propogation related:
                              . Modified siCirGrE06S00, siCirGrE06S01,
                                siCirGrE08S00 and siCirGrE08S01 so that ptr 
                                to circuit group gets deallocated instead of 
                                the temporary circuit group ptr
                              . Modified code in siCmpStatus and siCirGrE01S01 
                                so that different status bits in the transmitted
                                CGB & the received CGBA can be handled properly
                              . Added codes to generate the alarms to layer
                                manager when ISUP receives CGB and sends
                                a CGB
                              . Modified the codes to handle the GRS properly
                                if the range value is 0 in siCirGrE05S03.
                              . Changed the code only to send UCIC for
                                ANS92 and ANS95 variants when ISUP received
                                circuit group supervision message where
                                the CIC in the routing laber is equipped but
                                one or more of the indicated circuit is 
                                unequipped.
                              . Modified code in siCirGrE03S02 
                                so that different status bits in the transmitted
                                CGU & the received CGUA can be handled properly
                              . Initialized cause dgn value in siCirRemE20SND so
                                that CC would know that reattempt is due to UCIC
                              . Wherever siCmpStatus was called from, the code
                                was modified such that arguements would be
                                range.val rather than status.len
                              . Modified the funciton siCmpStatus to process
                                properly when one of the set is all 0s.
                          22. Added the initialization for hFlag and changed
                              code to return failure for the default case in 
                              siProcCirGrEvt.
                          23. Moved the checking for circuit state out of
                              ERRCLASS defines in siProCGBREQ, siProcCGUREQ
                              siProcCGU and siCirGrE01S01
                          24. Added the initialization for effRange, lastCic
                              and mapVal in siProcGRS.
                          25. Added default cases for the switch statement of
                              the variant type in siCirGrE0ESND.
                          26. Added default cases for the switch statement of
                              the event type in siMngCirGrpReq. 
                          27. Added the initialization for effRange variable
                              in function siCirGrE04SND and siCirGrE05S03
                          28. Added the initialization for numOct and 
                              lastCic in siCirGrE0BS06
                          29. Changed the cdAdr as Dpc type defined for
                              non-ANSI in the siHndlCQMonUneq function
                              definition.
                          30. Corrected a bug in siCirGrE0ESND when SS7_NTT
                              flag is enabled.
                          31. Added a casting when calling function 
                              siProcBLOinReset
/main/36     ---        hy   1. Modified siCirGrE04SND so that when the MTPblock
                              cannot be found, RFAILED is returned and
                              add code to check interface control block
                              pointer in the cirCb.
                           2. Added code to generate a status indication to IW 
                              to idle the circuit group for the received GRS 
                              message.
                           3. Added code to check the interface control blk
                              pointer in the cirCb in funciton siCirGrE04SND
                           4. Modified siGetCirState so that when the circuits
                              local maintenance/hardware state waiting for
                              reset ack, (circuit group) unblocking ack, 
                              the transient state is returned
                           5. Modified siProcCGB and siProcCGU to make sure that
                              CIC's are properly blocked and unblocked according
                              to the status value
                           6. Code added in siCirGrE0CSND to stop TMR_T28 if it
                              is already running when the CQM is sent
                           7. Modified the code to pass the range and status
                              value for siCmpStatus in function siCirGrE08S07
                      hy   1. Changed the reset direction to FROM_LWR when
                              handling h/w CGB msg.
                           2. Added code to send alarm to layer manager when 
                              status bits disjoint in function siCirGrE01S01
                           3. Modified the code to send hw or mnt CGB if 
                              circuit is locally hw or mnt blocked when 
                              handling the GRS msg with range value is 0 for
                              ANS92 and ANS95 in siProcGRS function.
                           4. Added code to generate alarm to layer manager
                              in function siCirGrE0ESND
                       hy  1. Modified the code to check the circuit state 
                              properly when sending the alarm to layer
                              manager for the additional circuits indicated in 
                              received CGUA status bit in function siCirGrE03S02
                      mm   1. Added code to siCirRemE12S01 to generate a UBL  
                              indication  for remotely hardware block states
                              for ANSI 92 variant.
                      hy   1. Used cmMemset to initialize the hRangStat and 
                              mRangStat in siProcGRS.
         si003.220    mm   1. In siCirLocE04SND and siCirLocE0ESND, Modified code 
                              so that if remote maintenance state is waiting for 
                              block ack then also clear it.
                           2. In siCirLocE00SND and siCirLocE00s05, add circuit 
                              block request error counter in circuit statistics. 
                           3. Added code such that CGB/CGU with range 0 can be 
                              supported. This is as per ANSI 92 and Bellcore
                              variants. SI_CKTGRP_RANGZERO compile time flag has 
                              to be enabled for this
                           4. In function siGetCirState, added code so that the 
                              function will not return idle state after remote 
                              state is set into unequipped.
                           5. In function siCirGrE08S01, add check for 'waiting
                              for CGBRSP' before process CGU message.
                           6. Add function siCirLocE01S03 to handle receiving 
                              BLA in the circuit state of locally blocked.
         si006.220    hy   1. Modified the code to clear the connection 
                              unconditionally in function siCirRemE05S05, 
                              siCirREmE0FS05, siCirREmE15SND and siCirLocE1FSND
                           2. Removed the reduntent line cir->siCon = NULLP 
                              after clearing a connection.
                           3. In function siProcCGB, siProcCGU,modified code to
                              handle the last byte on status correctly.
         si009.220    hy   1. In function siGetCirState, modified the code to 
                              report the transient state properly.
                      mm   2. Modified code so that when calling siGetLnkSel an
                              extra parameter cic will be passed in.
         si010.220    tz   1. modify function siGetCirState to properly process the
                              remote unequipped state for ANSI and BELL variants.
         si011.220    km   1. Added code to siCirGrE06S07 to check if range and 
                              status value of 2nd CGB msg are the same as that 
                              of the first one received. 
                           2. Also added siAssignRangStat function definition
                              for assignment of range and status values for 
                              every new CGB received
         si013.220    km   1. In siCirGrE04SND, added code to stop timer T22 
                              and T23 when a GRS msg cannot be sent out
                           2. Added code to siCirRemE20SND so that the local
                              states of the circuit are set to idle when
                              UCIC msg is received
                           3. Added code to siValidateRangStat to make sure
                              that for group blocking/unblocking messages for 
                              ITU, the maximum range value is 256, and the 
                              maximum status bits set is 32
                           4. Added code to properly process BLO, UBL, CGB and
                              CGU messages when they are received in the 
                              unequipped state
                           5. In several functions, modified code to properly 
                              calculate total number of octets from the range 
                              value. This includes range values uptil 255
         si014.220    km   1. Correct error brought by si013.220
         si016.220    tz   1. Modified code so that circuit calProcStat is 
                              changed to CALL_IDLE even if there is not siCon
                              on the circuit in reset ack processing function.
         si017.220    tz   1. Remove T14 adn T15 on receiving UBA on idle state.
         si018.220    tz   1. Modified code in processing CGBA and CGUA functions such
                              that the circuit group info is sent to LM through alarm.
         si019.220    tz   1. Modified code to correct alarm issues with status fields
                              in case of CGBA or CGUA.
         si020.220    tz   1. Added code to reset noRspFlgToLw to FALSE to make
                              sure response to the received RSC message being
                              sent to the network.
         si023.220    tz   1. remove the change from si020.220 since that change 
                              is moved to SntUDatInd. 
         si025.220    tz   1. modified arguments in siGetLnkSel call.
         si027.220    tz   1. added code to check cir NULLP in siProcCirEvt.
         si028.220    tz   1. changed code to replace some OR to AND operators.
         si029.220    tz   1. Added INDIA variant.
         si031.220    tz   1. Modified code in siProcCGB so that last octet in
                              the status paraameter of CGB message can be proccessed
                              properly.
         si033.220    rk   1. Modified code in siValidateRangStat to discard the GRS message
                              if circuit id is greater than 32
         si034.220    rk    1. Added CHINA flag and switch where applicable.
         si035.220    rk    1. Modified function siCirRemE20SND. If UCIC is received in 
                               response to group message, the circuit on which UCIC is 
                               received is marked unequipped and states of all the 
                               circuits invloved in grp message is changed to IDLE.
         si039.220    rk    1. In siCirGrE01S00, pointer cir replaced with cirgr->cir. 
                               cir ptr may be uninitialized pointer and can cause CPU crash
         si041.220    rk    1. Circuit  timers stoped to avoid sending 
                               BLOREQ on expiry
        si042.220     bn    1. Added ITU2000 and Russian 2000 ISUP variants.
        si044.220     ng    1. Modified: To send the UCIC for invalid circuit 
        si045.220     ng    1. Modified: To send the UCIC for invalid circuit 
        si049.220     ng    1. Modification LSI_SW_ANS92 is replaced by LSI_SW_ANS95 
	si054.220 vp     1 Added Code to update error counter
	si055.220 vp     1 Changed NULL to NULLP
*********************************************************************91*/
