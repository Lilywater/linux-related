
/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

    Name:     ISUP - body 1

    Type:     C source file

    Desc:     C source code for ISUP Upper Layer, Lower Layer,
              System Service and Layer Management service user primitives
              supplied by TRILLIUM.

              Part 1: Interface primitives.

    File:     ci_bdy1.c

    Sid:      ci_bdy1.c@@/main/45 - Wed Jul 25 13:20:30 2001
 
    Prg:      na

*********************************************************************21*/


/************************************************************************

     Note: 

     This file has been extracted to support the following options:

     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif


************************************************************************/


/*

Upper layer functions interface to the application protocol.

The following functions are provided in this file:

   SiUiSitBndReq    - Bind Request
   SiUiSitConReq    - Connection Establishment Request
   SiUiSitConRsp    - Connection Establishment Response
   SiUiSitCnStReq   - Connection Status Request
   SiUiSitFacReq    - Facility Request
   SiUiSitFacRsp    - Facility Response 
   SiUiSitDatReq    - User Information Request
   SiUiSitSuspReq   - Call Suspend Request
   SiUiSitResmReq   - Call Resume Request
   SiUiSitRelReq    - Release Request
   SiUiSitRelRsp    - Release Respose
   SiUiSitStaReq    - Status Request
   SiUiSitFtzReq    - Call FTZ utilities Request (only for GT_FTZ variant)
   SiUiSitUMsgReq   - Unrecognized message Request

It is assumed that the following functions are provided in the
ISUP layer service user file:

   SiUiSitConInd    - Connection Establishment Indication
   SiUiSitConCfm    - Connection Establishment Confirmation
   SiUiSitCnStInd   - Connection Status Indication
   SiUiSitRelInd    - Release Indication
   SiUiSitRelCfm    - Release Confirmation
   SiUiSitDatInd    - User Information Indication
   SiUiSitSuspInd   - Call Suspend Indication
   SiUiSitResmInd   - Call Resume Indication
   SiUiSitStaInd    - Call Status Indication
   SiUiSitFacInd    - Facility Indication
   SiUiSitFacCfm    - Facility Confirmation
   SiUiSitFtzInd    - Call FTZ utilities Request (only for GT_FTZ variant)
   SiUiSitUMsgInd   - Unrecognized message Indication

*/


/*

System services are the functions required by the protocol layer for
buffer management, timer management, date/time management, resource
checking and initialization.

The following functions are provided in this file:

     siActvInit     Activate layer - initialize
     siActvTmr      Activate layer - timer

It is assumed that the following functions are provided in the system
services service provider file:

     SInitQueue     Initialize Queue
     SQueueFirst    Queue to First Place
     SQueueLast     Queue to Last Place
     SDequeueFirst  Dequeue from First Place
     SDequeueLast   Dequeue from Last Place
     SFlushQueue    Flush Queue
     SCatQueue      Concatenate Queue
     SFndLenQueue   Find Length of Queue

     SGetMsg        Get Message
     SPutMsg        Put Message
     SInitMsg       Initialize Message

     SAddPreMsg     Add Pre Message
     SAddPstMsg     Add Post Message
     SRemPreMsg     Remove Pre Message
     SRemPstMsg     Remove Post Message
     SExamMsg       Examine Message
     SFndLenMsg     Find Length of Message
     SCopyMsgMsg    Copy Message to Message
     SCatMsg        Concatenate Message
     SSegMsg        Segment Message

     SChkRes        Check Resources

     SRegTmr        Register Activate Task - timer

*/


/*

Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.

The following functions are provided in this file:

     SiMiLsiCfgReq       Configure Request
     SiMiLsiStaReq       Status Request
     SiMiLsiStsReq       Statistics Request
     SiMiLsiCntrlReq     Control Request

     SiMiShtCntrlReq     System Agent Control Request

It is assumed that the following functions are provided in the
layer management service provider file.

     SiMiLsiCfgInd       Configuration Indication
     SiMiLsiStaInd       Status Indication
     SiMiLsiTrcInd       Trace Indication

*/


/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.             description
*     --------    ----------------------------------------------
*
*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* general SS7 layer */
#include "cm_hash.h"       /* hash-list header */
#include "lsi.h"           /* layer management */
#include "si_mf.h"         /* message functions */
#include "cm5.h"           /* timers */
#include "ci_db.h"         /* ISUP data base */
#include "sit.h"           /* ISUP */
#include "snt.h"           /* MTP3 */
#ifdef SI_SPT
#include "spt.h"           /* SCCP */
#endif
#include "si.h"            /* ISUP */
#include "si_err.h"        /* ISUP error */
#ifdef IW
#include "cm_atm.h"          /* common ATM defines                 */
#include "cm_cc.h"           /* Common Call Control Hash Defs      */
#include "rmt.h"             /* resource manager defines           */
#include "cct.h"             /* Call Control Interface Header      */
#include "liw.h"             /* ISUP PSIF Layer Management Headers */
#include "iw.h"              /* ISUP PSIF Hash Defines             */
#include "iw_err.h"          /* ISUP PSIF Error Defines            */
#include "iw_ptli.h"         /* o/g SIT i/f funcs. hash defs       */
#endif

#ifdef ZI
#include "cm_pftha.h"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.h"       /* common PSF */
#include "cm_psfft.h"      /* common PSF */
#endif
#include "lzi.h"           /* ISUP PSF management */
#include "zi.h"            /* ISUP PSF */
#include "zi_err.h"        /* ISUP PSF error codes */
#endif /* ZI */

#ifdef SI_FTHA
#include "sht.h"           /* common ftha sh defines */
#endif
/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* general SS7 layer */
#include "cm_lib.x"        /* common library functions */
#include "cm_hash.x"       /* hash-list structure */
#include "lsi.x"           /* layer management */
#include "si_mf.x"            /* message functions */
#include "cm5.x"           /* timers */
#include "ci_db.x"         /* ISUP data base */
#include "sit.x"           /* ISUP */
#include "snt.x"           /* MTP3 */
#ifdef SI_SPT
#include "spt.x"           /* SCCP */
#endif
#ifdef SI_FTHA
#include "sht.x"           /* common ftha sh structure */
#endif
#include "si.x"            /* ISUP */

#ifdef IW
#include "cm_atm.x"          /* common ATM defines                  */
#include "cm_cc.x"           /* Common Call Control Typedefs        */
#include "rmt.x"             /* resource manager function decls.    */
#include "cct.x"             /* Call Control Interface              */
#include "liw.x"             /* ISUP PSIF Layer Management typedefs */
#include "iw.x"              /* ISUP PSIF Typedefs                  */
#endif
#ifdef ZI 
#include "cm_pftha.x"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.x"       /* common PSF */
#include "cm_psfft.x"      /* common PSF */
#endif
#include "lzi.x"           /* ISUP PSF management */
#include "zi.x"            /* ISUP PSF */
#endif /* ZI */


/* local defines */

/* local typedefs */
  
/* local externs */


/* forward references */


/* public variable declarations */

SiCb siCb;                  /* isup control point                          */

CONSTANT Txt ISUP[] = "ISUP";

Bool siProcIncSegm;


/*
*     support functions to service user
*/


/*
*     interface functions to service user
*/


/*
*
*       Fun:   ISUP Bind Request
*
*       Desc:  This function binds the ISUP layer service user
*              with the ISUP layer service provider. The ISUP
*              layer software will register this new service
*              user and will allocate a Service Access Point (SAP) for
*              this bind. The service user will specify the reference
*              number that will be used for the duration of this bind.
*              The Control Block for service provider is the ISUP
*              Layer SAP, while the Control Block for the
*              service user is dependent on the protocol.
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitBndReq
(
Pst *pst,               /* bind configuration */
SuId suId,              /* service user id */
SpId spId               /* service provider id */
)
#else
PUBLIC S16 SiUiSitBndReq(pst, suId, spId)
Pst *pst;               /* bind configuration */
SuId  suId;             /* service user id */
SpId spId;              /* service provider id */
#endif
{
   SiUpSAPCb *tCb;
   /* si001.220, ADDED: changes for rollup */
#ifdef SI_RUG
   Bool found;          /* flag to indicate if have version info */
   U16  i;
#endif /* SI_RUG */

   TRC3(SiUiSitBndReq)

   SIDBGP(DBGMASK_UI, (siCb.init.prntBuf, "%s\n\nBndReq  : L4 <- L5\n", 
          SI_STR)); 
#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI001, (ErrVal) ziCb.protState,
                 "SiUiSitBndReq() failed, ISUP is not active\n");
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_UI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   if ((tCb = SIUPSAP(spId)) == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                             "Can not find the SAP for spId:0x%x %d\n",
                             spId, spId) );

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI002, (ErrVal) spId, 
                 "SiUiSitBndReq() Failed, invalid spId");
#endif
      siInitUstaDgn(LSI_USTA_DGNVAL_SPID, (PTR) &spId, 
                    LSI_USTA_DGNVAL_EVENT, (PTR) &pst->event,
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LCM_CAUSE_INV_SAP, TRUE, 
                     (CirId) spId, SIISAP_INV);
      RETVALUE(RFAILED);
   }

   switch (tCb->state)
   {
      case SI_UNBND:
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                                "BindReq case SAP state is not bind \n"));
         /* si001.220, ADDED: Changes for rolling upgrade */
#ifdef SI_RUG
         /* For upper interface SAP, we look up the version info from the stored
          * information if it is available already at first bound request
          */
         found = FALSE;
         if (tCb->remIntfValid == FALSE)
         {
            for (i = 0; i < siCb.numIntfInfo; i++)
            {
               if (siCb.intfInfo[i].intf.intfId == SITIF)
               {
                  switch (siCb.intfInfo[i].grpType)
                  {
                     case SHT_GRPTYPE_ALL:
                        if (siCb.intfInfo[i].dstProcId == pst->srcProcId &&
                            siCb.intfInfo[i].dstEnt.ent == pst->srcEnt &&
                            siCb.intfInfo[i].dstEnt.inst == pst->srcInst)
                           found = TRUE;
                        break;
                     case SHT_GRPTYPE_ENT:
                        if (siCb.intfInfo[i].dstEnt.ent == pst->srcEnt &&
                            siCb.intfInfo[i].dstEnt.inst == pst->srcInst)
                           found = TRUE;
                        break;
                     default:
                        /* not possible */
                        break;
                  }
               }
            }
            if (found == TRUE)
            {
               tCb->pst.intfVer = siCb.intfInfo[i-1].intf.intfVer;
               tCb->remIntfValid = TRUE;
            }
            else
            {
               /* SAP cannot be bound if remote ver info is not available */
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Can not bind the SAP for spId:0x%x %d,\
                       remote ver info isnot available\n", spId, spId) );

#if (ERRCLASS & ERRCLS_INT_PAR)
               SILOGERROR(ERRCLS_INT_PAR, ESIXXX, (ErrVal) spId, 
                    "SiUiSitBndReq() Failed, remote ver info isnot available");
#endif
               siInitUstaDgn(LSI_USTA_DGNVAL_SPID, (PTR) &spId, 
                             LSI_USTA_DGNVAL_EVENT, (PTR) &pst->event,
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, LCM_CAUSE_SWVER_NAVAIL,
                              TRUE, (CirId) spId, SIISAP_INV);

               RETVALUE(ROK);
            }
         }
#endif /* SI_RUG */

         tCb->pst.dstProcId = pst->srcProcId;
         tCb->pst.dstEnt    = pst->srcEnt;
         tCb->pst.dstInst   = pst->srcInst;
         tCb->suId          = suId;
         tCb->state         = SI_BND;
         break;

#ifdef SIT2

      default: /* bind on bind allowed - SIT2 */
         break;

#else /* SIT2 */
      default: /* bind on bind not allowed - old i/f */
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "Bind Request for upper SAP (id=%#x, state=%#x)\n",
                                spId, tCb->state));
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI003, (ErrVal) spId, 
                    "SiUiSitBndReq() Failed, invalid ISUP SAP state");
#endif
         SISNDOLDLSISTAIND(&siCb.init.lmPst, (CirId)spId, SIISAP_INV);
         RETVALUE(RFAILED);
#endif
   }

#ifdef SIT2

#ifdef ZI
   ziRunTimeUpd(ZI_UPSAP_CB, CMPFTHA_UPD_REQ, (PTR) tCb);
   ziUpdPeer();
#endif /* ZI */

   SiUiSitBndCfm(&tCb->pst, suId, CM_BND_OK);
#endif /* SIT2 */

   RETVALUE(ROK);
}


/*
*
*      Fun:   ISUP Connect Request
*
*      Desc:  This function is used to establish a
*             circuit switched networkconnection.
*
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitConReq
(
Pst       *pst,             /* bind configuration */
SpId      spId,             /* service provider id */
SiInstId  suInstId,         /* service user instance id */
SiInstId  spInstId,         /* service provider instance id */
Bool      cirSelFlg,        /* circuit selection flag */
CirId     circuit,          /* circuit ID code */
SiConEvnt *siConEvnt,       /* connect event */
U8        xchgType,         /* type of exchange for this call */
Buffer    *uBuf             /* unrecognised parameters */
)
#else
PUBLIC S16 SiUiSitConReq(pst, spId, suInstId, spInstId, cirSelFlg, circuit,
                         siConEvnt, xchgType, uBuf)
Pst       *pst;             /* bind configuration */
SpId      spId;             /* service provider id */
SiInstId  suInstId;         /* service user instance id */
SiInstId  spInstId;         /* service provider instance id */
Bool      cirSelFlg;        /* circuit selection flag */
CirId     circuit;          /* circuit ID code */
SiConEvnt *siConEvnt;       /* connect event */
U8        xchgType;         /* type of exchange for this call */
Buffer    *uBuf;            /* unrecognised parameters */
#endif
{
   SiUpSAPCb *tCb;
   SiNSAPCb  *mCb;
   SiCon     *con;
   SiCirCb   *cir;
   S16       ret;
   SiCirKey  key;
   SiAllSdus ev;
   Status    status;
   U8        i;
   U8        trMedReq;
   SiIntfCb   *siIntfCb;
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   Bool      mulCallFlg;   /* non-single rate call flag */
#endif 

   TRC3(SiUiSitConReq)

#ifdef MEM_STS
   /*           lixinxin: added for memory debug print       */
   printf("Entered SiUiSitConReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif

   SIDBGP(DBGMASK_UI, (siCb.init.prntBuf,
        "%sSiUiSitConReq(spId=%#x, suInstId=%#lx, spInstId=%#lx,\
        cirSelFlag=%#x, cirId=%#lx)\n",
        SI_STR, spId, suInstId, spInstId, cirSelFlg, circuit)); 

   UNUSED(cirSelFlg);

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
/* si039.220 - SILOGERROR was using SiUiSitBndReq */
      SILOGERROR(ERRCLS_DEBUG, ESI004, (ErrVal) ziCb.protState,
                 "SiUiSitConReq() failed, ISUP is not active\n");
#endif
      siDropMsg(uBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_UI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   trMedReq = 0;

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   mulCallFlg = FALSE;
#endif 

   if (((tCb = SIUPSAP(spId)) == NULLP) || (tCb->state != SI_BND))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI005, (ErrVal) spId, 
                 "SiUiSitConReq() Failed, invalid spId");
#endif
      siInitUstaDgn(LSI_USTA_DGNVAL_SPID, (PTR) &spId, 
                    LSI_USTA_DGNVAL_EVENT, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LCM_CAUSE_INV_SAP, TRUE, 
                     (CirId) spId, SIISAP_INV);
      siDropMsg(uBuf);
      RETVALUE(RFAILED);
   }

   SChkRes(tCb->pst.region, tCb->pst.pool, &status);

   if ((status < siCb.genCfg.poolTrLower) ||
       ((status < siCb.genCfg.poolTrUpper) &&
        (siConEvnt->cgPtyCat.cgPtyCat.val != CAT_PRIOR)))
   {
      SIDBGP(SIDBGMASK_WARN, 
             (siCb.init.prntBuf, 
              "(poolTrLower = %#x, poolTrUpper = %#x),\n\
                current usage level = %#x,\n\
                calling party category=%#x\n",
              siCb.genCfg.poolTrLower, siCb.genCfg.poolTrUpper, status,
              siConEvnt->cgPtyCat.cgPtyCat.val)); 

       /* initialize Status Event */
       MFINITSDU(&tCb->mfMsgCtl, ret, (U8) 0, (U8) SI_STAREQ,
                (ElmtHdr *) NULLP, (ElmtHdr *) &ev, (U8) NOTPRSNT,
                tCb->cfg.swtch, (U32) MF_ISUP);
      ev.m.siStaEvnt.causeDgn.eh.pres = PRSNT_NODEF;
      ev.m.siStaEvnt.causeDgn.causeVal.pres = PRSNT_NODEF;
      ev.m.siStaEvnt.causeDgn.causeVal.val = SIT_CCSWTCHCONG;

      /* send reattempt indication to the upper layer */
      SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId, circuit, FALSE, 
                    SIT_STA_REATTEMPT, &ev.m.siStaEvnt, NULLP);
      siDropMsg(uBuf);
      RETVALUE(RFAILED);
   }

   switch (tCb->cfg.swtch)
   {
      case LSI_SW_ITU:
         trMedReq = siConEvnt->txMedReq.trMedReq.val;
         break;
#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         trMedReq = siConEvnt->txMedReq.trMedReq.val;
         /* check if it is a non-single rate call */
         if (trMedReq > TMR_64KBITSPREF)
            mulCallFlg = TRUE;
         break;
#endif /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   }

   /* find circuit */
   key.k1.cirId = circuit;
   siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CIR);
   if (cir == (SiCirCb *) NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
             "conreq on unequipped circuit (%#lx)\n", key.k1.cirId)); 
      siDropMsg(uBuf);

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, TRUE, 
                     circuit, SI_ALRM_CIR_UNEQUPD);

      /* Generate Release Indication to Upper Layer */
      siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                     SIT_CCREQUNAVAIL);
      /* Send UCIC indication to Call Control */
      SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId, circuit, 
                    FALSE, SIT_STA_CIRUNEQPD, NULLP, NULLP);
      RETVALUE(RFAILED);
   }

   /* get the interface control block and check if the state=AVAILABLE */
   if ((siIntfCb = cir->pIntfCb) == NULLP) 
   {
      SIDBGP(SIDBGMASK_CERR,
             (siCb.init.prntBuf, 
              "intf (%#lx) for the circuit (%#lx) not configured\n",
              cir->key.k3.intfId, circuit)); 
      siDropMsg(uBuf);

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_INTF, (PTR) &cir->key.k3.intfId, 
                    LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit,
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_INTF, TRUE, 
                     circuit, SI_ALRM_INTF_NOTCFGD);

      /* Generate and send release indication to Upper Layer */
      siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                     SIT_CCREQUNAVAIL);
      RETVALUE(RFAILED);
   }

#ifdef SI_UTSI_ENHANCE
   /* schubert.zhang: if the NSAP is not bound, the new con instance should not
    * be created. Otherwise, the new created con instance would cannot be clear 
    * by SiUiSitRelReq, SiUiSitRelRsp.
    */
   mCb = siGetLwrMCbPtr(cir);
   if (NULLP == mCb)
   {
      SIDBGP(SIDBGMASK_ERR,
             (siCb.init.prntBuf, "MTP-3 SAP invalid\n")); 
      siDropMsg(uBuf);

      /* Generate Release Indication to Upper Layer */
      siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP,
                     SIT_CCDESTOUTORD);
      RETVALUE(RFAILED);
   }

   if (mCb->state != SI_BND)
   {
      SIDBGP(SIDBGMASK_ERR,
             (siCb.init.prntBuf, "MTP-3 SAP %#x not bound (state=%#x)\n",
              mCb->suId, mCb->state)); 
      siDropMsg(uBuf);

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SPID, (PTR) &tCb->spId,
                    LSI_USTA_DGNVAL_SUID, (PTR) &mCb->suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_MSAP, TRUE, 
                     circuit, SI_ALRM_NSAP_NOTBOUND);

      /* Generate Release Indication to Upper Layer */
      siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP,
                     SIT_CCDESTOUTORD);
      RETVALUE(RFAILED);
   }
#endif /* SI_UTSI_ENHANCE */

   if (siIntfCb->state == SI_INTF_UNAVAIL)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
             "INTF (%#lx) unavailable \n", cir->key.k3.intfId)); 
      siDropMsg(uBuf);

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_INTF, (PTR) &cir->key.k3.intfId, 
                    LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit,
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_NW_RESOURCE, TRUE, 
                     circuit, SI_ALRM_INTF_PAUSED);

      /* Generate and send release indication to upper layer */
      siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                     SIT_CCDESTOUTORD);
      RETVALUE(RFAILED);
   }

   /* perform the sanity check on this circuit. Since we check the circuit 
    * which allocating the conn cb, the controlling cir is the same as the 
    * affected cir 
    */
   ret = siSanChkConEvtCkts(siConEvnt, tCb, cir, cir, &ev, suInstId, spInstId);
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
             "Ckecking on the controlling circuit is failed\n")); 

      siDropMsg(uBuf);
      RETVALUE(RFAILED);
   }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check the affected circuits if the connection is a non-single rate
    * type call
    */
   if (mulCallFlg)
   {           
      ret = siChkMRateCon(siConEvnt, tCb, cir, &ev, suInstId, spInstId);
      if (ret != ROK)
      {
         siDropMsg(uBuf);
         RETVALUE(RFAILED);
      }
   }   
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */

   if (spInstId)
   {
      /* find connection */
      siFindInst(&siCb.conHlCp, &con, (SiInstKey *) &spInstId);

      if (con == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "No connection found for passed spInstId\n")); 
         siDropMsg(uBuf);

         SISNDOLDLSISTAIND(&siCb.init.lmPst, circuit, SI_ALRM_INV_SPINSTID);

         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        CCINVALCALLREF);
         RETVALUE(RFAILED);
      }

      if( con->outC.cir != NULLP )
      {
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "O/g conn is active for (spInstId=%#lx, circuit=%#lx)\n",
            spInstId, con->outC.cir->key.k1.cirId)); 
            siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            SISNDOLDLSISTAIND(&siCb.init.lmPst, circuit, 
                  SI_ALRM_INV_CIRID);

            /* Generate Release Indication to Upper Layer 
             * This is a error from service user (sending yet another conn
             * request on already active connection). Clear the call and idle
             * the circuit 
             */
            siGenErrRelInd(tCb, suInstId, spInstId, circuit,
                  con, SIT_CCPROTERR);
            RETVALUE(RFAILED);

         }
      }

      mCb             = con->mCallCb;
      /* associate outgoing circuit connection with this circuit */
      con->outC.cirId = circuit;
      con->outC.cir   = cir;
   }
   else
   {
      /* get instance */
      if (siGetInstId(&spInstId) == RFAILED)
      {
         SIDBGP(SIDBGMASK_ERR,
                (siCb.init.prntBuf, " Can not allocate a new spInst id\n")); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP,
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_RESOURCE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CAL_REF, TRUE, 
                        circuit, SI_ALRM_ALOCSPINST_ERROR);

         /* Generate and send release indication to upper layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        SIT_CCSWTCHCONG);
         RETVALUE(RFAILED);
      }

      /* there's already a connection associated with the circuit */
      if (cir->siCon != NULLP)
      {
         SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf, 
                "Releasing the existing conn. on the ckt\n")); 
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI006, (ErrVal) circuit,
                    "SiUiSitConReq() connection cb exists");
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
         siUpdErrSts(cir, LSI_STS_ABNRMLREL);
#endif
         siRelCon(cir->siCon);
         cir->siCon = NULLP;
      }

      /* get connection */
      con = siGetOutCon(cir, tCb);
      if (con == NULLP)
      {
         SIDBGP(SIDBGMASK_ERR,
                (siCb.init.prntBuf, "Can not allocate a connection block\n")); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP,
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_RESOURCE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_NO_MEMORY, TRUE, 
                        circuit, SI_ALRM_ALOCCON_ERROR);

         /* Generate and send release indication to upper layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        SIT_CCRESCUNAVAIL);
         RETVALUE(RFAILED);
      }
      con->key.k1.spInstId = spInstId;
#if SI_ACNT
      con->charge = TRUE;
#endif 
      siAddInst(&siCb.conHlCp, con);
      /* get mtp control block */
      mCb = siGetLwrMCbPtr(cir);
      con->mCallCb = mCb;
   }

   if (mCb->state != SI_BND)
   {
      SIDBGP(SIDBGMASK_ERR,
             (siCb.init.prntBuf, "MTP-3 SAP %#x not bound (state=%#x)\n",
              mCb->suId, mCb->state)); 
      siDropMsg(uBuf);

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SPID, (PTR) &tCb->spId,
                    LSI_USTA_DGNVAL_SUID, (PTR) &mCb->suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_MSAP, TRUE, 
                     circuit, SI_ALRM_NSAP_NOTBOUND);

      /* Generate Release Indication to Upper Layer */
      siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, SIT_CCDESTOUTORD);
      RETVALUE(RFAILED);
   }
   else
   {
      if (tCb->cfg.sidIns)
      {
         if (siConEvnt->cgPtyNum.eh.pres)
         {
            if (tCb->cfg.sidVer)
            {
               if ((ret = siCmpAddr(&tCb->cfg.sid.strg[0],
                                    tCb->cfg.sid.length, 
                                    &siConEvnt->cgPtyNum.addrSig.val[0],
                                    siConEvnt->cgPtyNum.addrSig.len, 
                                    NULLP)) == ROK)
               {
                  siConEvnt->cgPtyNum.scrnInd.val = USRPROV;
               }
               else
               {
                  SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                         "Overwriting with default calling pty no.\n"));
                  siConEvnt->cgPtyNum.scrnInd.val = NETPROV;
                  siConEvnt->cgPtyNum.addrSig.len = tCb->cfg.sid.length;
                  for (i = 0; i < tCb->cfg.sid.length; i++)
                     siConEvnt->cgPtyNum.addrSig.val[i] = tCb->cfg.sid.strg[i];
               }
            }
         }
         else
         {
            siConEvnt->cgPtyNum.eh.pres = PRSNT_NODEF;
            siConEvnt->cgPtyNum.natAddrInd.pres = PRSNT_NODEF;
            siConEvnt->cgPtyNum.natAddrInd.val = tCb->cfg.natAddrInd;
            siConEvnt->cgPtyNum.oddEven.pres = PRSNT_NODEF;
            siConEvnt->cgPtyNum.oddEven.val = tCb->sidOddEven;
            siConEvnt->cgPtyNum.scrnInd.pres = PRSNT_NODEF;
            siConEvnt->cgPtyNum.scrnInd.val = NETPROV;
            siConEvnt->cgPtyNum.presRest.pres = PRSNT_NODEF;
            siConEvnt->cgPtyNum.presRest.val = tCb->cfg.sidPresInd;
            siConEvnt->cgPtyNum.numPlan.pres = PRSNT_NODEF;
            siConEvnt->cgPtyNum.numPlan.val = tCb->cfg.sidNPlan;
            siConEvnt->cgPtyNum.niInd.pres = PRSNT_NODEF;
            siConEvnt->cgPtyNum.niInd.val = NMB_COMPLTE;
            siConEvnt->cgPtyNum.addrSig.pres = PRSNT_NODEF;
            siConEvnt->cgPtyNum.addrSig.len = tCb->cfg.sid.length;
            for (i = 0; i < tCb->cfg.sid.length; i++)
               siConEvnt->cgPtyNum.addrSig.val[i] = tCb->cfg.sid.strg[i];
         }
         if (tCb->cfg.sidPresRes)
            siConEvnt->cgPtyNum.presRest.val = PRESREST;
         else
            siConEvnt->cgPtyNum.presRest.val = PRESALLOW;
      }
      else
      {
         if (tCb->cfg.sidPresRes)
         {
            siConEvnt->cgPtyNum.eh.pres = PRSNT_NODEF;
            siConEvnt->cgPtyNum.natAddrInd.pres = PRSNT_NODEF;
            siConEvnt->cgPtyNum.natAddrInd.val = ADDR_NOTPRSNT;
            siConEvnt->cgPtyNum.oddEven.pres = PRSNT_NODEF;
            siConEvnt->cgPtyNum.oddEven.val = NMB_EVEN;
            siConEvnt->cgPtyNum.numPlan.pres = PRSNT_NODEF;
            siConEvnt->cgPtyNum.numPlan.val = SIT_NP_UNK;
            siConEvnt->cgPtyNum.niInd.pres = PRSNT_NODEF;
            siConEvnt->cgPtyNum.niInd.val = 0;
            siConEvnt->cgPtyNum.scrnInd.pres = PRSNT_NODEF;
            siConEvnt->cgPtyNum.scrnInd.val = NETPROV;
            siConEvnt->cgPtyNum.presRest.pres = PRSNT_NODEF;
            siConEvnt->cgPtyNum.presRest.val = PRESREST;
            siConEvnt->cgPtyNum.addrSig.pres = NOTPRSNT;
         }
      }

/* si029.220: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
#ifdef SI_218_COMP
      /* in ITU97 and ETSI v3 variant, we use bit 3 of xchgType to hold the 
       * infomation of broadband/narrowband interworking. If the backword 
       * compatibility flag SI_218_COMP is defined, ISUP will fill in this 
       * bit base on the user define compile options
       */
#ifdef SI_INIT_TOXA_BRNBAND
      /* fill in bit 3 as 1 */
      xchgType |= BRNBAND_ITWK;
#else
      /* fill in bit 3 as 0 */
      xchgType = (xchgType & (~(BRNBAND_ITWK)));
#endif /* SI_INIT_TOXA_BRNBAND */
#endif /* SI_218_COMP */
#endif /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA */

      con->xchgType = xchgType;
      con->sduSp    = (SiAllSdus *) siConEvnt;
      con->suInstId = suInstId;
      cir->siCon    = con;
/* si005.220 - Modification. Modified code to return RFAILED if con->tCallCb
 * is NULLP.
 */
      if (con->tCallCb != NULLP)
      {
         con->tCallCb->mfMsgCtl.uBuf = uBuf;
      }
      else
      {
         SIDBGP(SIDBGMASK_ERR,
                (siCb.init.prntBuf, "tCallCb is NULLP\n"));
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP,
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_NW_RESOURCE, TRUE, 
                        circuit, SI_ALRM_ALOCCON_ERROR);
         RETVALUE(RFAILED);
      }
      /* jump into state matrix */
      siActDat(circuit, con, IEI_CONREQ);
   }

   /* Obtain the upper SAP afresh and set the uBuf to NULLP.
    * This is required because in case of tightly coupled
    * interface, tCb and con may be having stale pointer if
    * for some reason upper SAP and/or connection was deleted.
    */
   if ((tCb = SIUPSAP(spId)) != NULLP)
   {
      tCb->mfMsgCtl.uBuf = NULLP;
   }
   siDropMsg(uBuf);

/* lixinxin: added for memory debug print                  */
#ifdef MEM_STS
   
   printf("Leaving SiUiSitConReq, memory usage is:");
   SRegInfoShow(0);
#endif
/**********************************************************/
   
   RETVALUE(ROK);
} /* end of SiUiSitConReq */


/*
*
*      Fun:   ISUP Connect Response
*
*      Desc:  This function is used to establish a
*             circuit switched networkconnection.
*
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitConRsp
(
Pst       *pst,             /* bind configuration */
SpId      spId,             /* service user id */
SiInstId  suInstId,         /* service user instance id */
SiInstId  spInstId,         /* service provider instance id */
CirId     circuit,          /* circuit ID code */
SiConEvnt *siConEvnt,       /* connect event */
U8        xchgType,         /* type of exchange for this call */
Buffer    *uBuf             /* unrecognized parameters */
)
#else
PUBLIC S16 SiUiSitConRsp(pst, spId, suInstId, spInstId, circuit,
                         siConEvnt, xchgType, uBuf)
Pst       *pst;             /* bind configuration */
SpId      spId;             /* service user id */
SiInstId  suInstId;         /* service user instance id */
SiInstId  spInstId;         /* service provider instance id */
CirId     circuit;          /* circuit ID code */
SiConEvnt *siConEvnt;       /* connect event */
U8        xchgType;         /* type of exchange for this call */
Buffer    *uBuf;            /* unrecognised parameters */
#endif
{
   SiUpSAPCb *tCb;
   SiCon     *con;
   SiCirCb   *cir;
   SiCirKey  key;

   TRC3(SiUiSitConRsp)
   UNUSED(pst);

   SIDBGP(DBGMASK_UI, (siCb.init.prntBuf,
          "%s\n\nSiUiSitConRsp(spId=%#x, suInstId=%#lx, spInstId=%#lx,\
          circuit=%#lx)\n",
          SI_STR, spId, suInstId, spInstId, circuit)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n"));
#if (ERRCLASS & ERRCLS_DEBUG)
/* si039.220 - SILOGERROR was using SiUiSitBndReq */
      SILOGERROR(ERRCLS_DEBUG, ESI007, (ErrVal) ziCb.protState,
                 "SiUiSitConRsp() failed, ISUP is not active\n");
#endif
      siDropMsg(uBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_UI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   if (((tCb = SIUPSAP(spId)) == NULLP) || (tCb->state != SI_BND))
   {
      SIDBGP(SIDBGMASK_CERR,
             (siCb.init.prntBuf, "Invalid upper SAP=%#x in ConRsp", spId));

      siDropMsg(uBuf);
#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI008, (ErrVal) spId, 
                 "SiUiSitConRsp() Failed, invalid spId");
#endif
      siInitUstaDgn(LSI_USTA_DGNVAL_SPID, (PTR) &spId, 
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LCM_CAUSE_INV_SAP, TRUE, 
                     (CirId) spId, SIISAP_INV);
      RETVALUE(RFAILED);
   }

   con = NULLP;

   /* find connection */
   if (spInstId)
   {
      siFindInst(&siCb.conHlCp, &con, (SiInstKey *) &spInstId);
      if (con == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "No connection for spInstId %#lx in ConRsp\n", spInstId)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         SISNDOLDLSISTAIND(&siCb.init.lmPst, circuit, SI_ALRM_INV_SPINSTID);

         /* Generate and send release indication to upper layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        CCINVALCALLREF);
         RETVALUE(RFAILED);
      }

      if ((circuit != con->incC.cirId) && (circuit != con->outC.cirId))
      {
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* check if this is a non-single rate connection. */
         if (((con->incC.cir != NULLP) && 
              (con->incC.cir->ctrlMultiRateCir != NULLP)) ||
             ((con->outC.cir != NULLP) && 
             (con->outC.cir->ctrlMultiRateCir != NULLP)))
         {
            /* it is a non-single rate connection. Means it received msg on a
             * non-controlling circuit.  Generate an alarm. 
             */
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                  "rcvd call control msg on a non-cntrl ckt %#lx in CnStRsp\n",
                   circuit)); 
               siDropMsg(uBuf);

               /* means rcvd on a non cont ckt */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, 
                              LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                              TRUE, circuit, SI_ALRM_INV_CIRID);

               RETVALUE(RFAILED);
            }
         }
         else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
         {         
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "circuit mismatch in ConRsp (circuit=%#lx, incC.cirId=%#lx,\
                   outC.cirId %#lx)\n", 
                   circuit, con->incC.cirId, con->outC.cirId)); 
             siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_STATE_MISMATCH, 
                           TRUE, circuit, SI_ALRM_INV_CIRID);

            /* Generate Release Indication to Upper Layer 
             * Service user has some inconsistency - release this connection
             */
            siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, 
                           SIT_CCPROTERR);
            RETVALUE(RFAILED);
         }
      }
   }
   else
   {
      /* find circuit */
      key.k1.cirId = circuit;
      siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CIR);
      if (cir == (SiCirCb *) NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "ConRsp on an unequipped circuit=%lx\n", circuit)); 
         siDropMsg(uBuf);
         
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, FALSE, 
                        circuit, SI_ALRM_CIR_UNEQUPD);

         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        SIT_CCREQUNAVAIL);

         /* Send UCIC indication to Call Control */
         SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId, circuit, 
                       FALSE, SIT_STA_CIRUNEQPD, NULLP, NULLP);
         RETVALUE(RFAILED);
      }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if this is a non-single rate connection first */
      if (cir->ctrlMultiRateCir != NULLP)
      {
         /* it is a non-single rate connection. Check if the controlling 
          * circuit is the self circuit. If no, generate an alarm 
          */
         if (cir->ctrlMultiRateCir != cir)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                   "Revd call control msg on non-cntrl circuit=%lx\n", 
                   circuit)); 
            siDropMsg(uBuf);

            /* means rcvd on a non cont ckt */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, 
                                      LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                           TRUE, circuit, SI_ALRM_INV_CIRID);

            RETVALUE(RFAILED);
         }
      }         
#endif
      if (cir->siCon == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "No connection on the circuit=%lx\n", circuit)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_IDLE, TRUE, 
                        circuit, SI_ALRM_INV_CIRID);

         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        SIT_CCRESCUNAVAIL);
         RETVALUE(RFAILED);
      }
      con = cir->siCon;
   }

   if ((con->suInstId) && (con->suInstId != suInstId))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "ConRsp: suInstId mismatch (suInstId=%#lx, con->suInstId=%#lx)\n",
             suInstId, con->suInstId)); 
      siDropMsg(uBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI009, (ErrVal) circuit,
                    "SiUiSitConRsp() suInstId does not match");
#endif
      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &suInstId, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &spInstId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_SUINSTID_MISMATCH, TRUE, 
                     circuit, SI_ALRM_INV_SUINSTID);
      RETVALUE(RFAILED);
   }

   if (!con->suInstId)
      con->suInstId = suInstId;

   if (con->mCallCb->state != SI_BND)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf, 
             "ConRsp(): MTP-3 SAP (%#x) state unbound (%#x)\n",
             con->mCallCb->suId, con->mCallCb->state)); 
      siDropMsg(uBuf);

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SPID, (PTR) &con->tCallCb->spId, 
                    LSI_USTA_DGNVAL_SUID, (PTR) &con->mCallCb->suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_MSAP, TRUE, 
                     circuit, SI_ALRM_NSAP_NOTBOUND);

      /* Generate Release Indication to Upper Layer */
      siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, SIT_CCDESTOUTORD);
      RETVALUE(RFAILED);
   }
   else
   {
      con->sduSp    = (SiAllSdus *) siConEvnt;
/* si029.220: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
#ifdef SI_218_COMP
      /* in ITU97 variant, we use bit 3 of xchgType to hold the infomation
       * of broadband/narrowband interworking. If the backword compatibility
       * flag SI_218_COMP is defined, ISUP will fill in this bit base on 
       * the user define compile options
       */
#ifdef SI_INIT_TOXA_BRNBAND
      /* fill in bit 3 as 1 */
      xchgType |= BRNBAND_ITWK;
#else
      /* fill in bit 3 as 0 */
      xchgType = (xchgType & (~(BRNBAND_ITWK)));
#endif /* SI_INIT_TOXA_BRNBAND */
#endif /* SI_218_COMP */
#endif /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
      con->xchgType = xchgType;

/* si005.220 - Modification. Modified code to return RFAILED if con->tCallCb
 * is NULLP.
 */
      if (con->tCallCb != NULLP)
      {
         con->tCallCb->mfMsgCtl.uBuf = uBuf;
      }
      else
      {
         SIDBGP(SIDBGMASK_ERR,
                (siCb.init.prntBuf, "tCallCb is NULLP\n"));
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP,
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_NW_RESOURCE, TRUE,
                        circuit, SI_ALRM_ALOCCON_ERROR);
         RETVALUE(RFAILED);
      }
      /* jump into state matrix */
      siActDat(circuit, con, IEI_CONRSP);
   }

   /* Obtain the upper SAP afresh and set the uBuf to NULLP.
    * This is required because in case of tightly coupled
    * interface, tCb and con may be having stale pointer if
    * for some reason upper SAP and/or connection was deleted.
    */
   if ((tCb = SIUPSAP(spId)) != NULLP)
   {
      tCb->mfMsgCtl.uBuf = NULLP;
   }

   siDropMsg(uBuf);
   RETVALUE(ROK);
} /* end of SiUiSitConRsp */


/*
*
*      Fun:   ISUP Connection Progress Status request
*
*      Desc:  This function is used to specify the status of a circuit
*             switched connection in progress.
*
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitCnStReq
(
Pst        *pst,            /* bind configuration */
SpId       spId,            /* service user id */
SiInstId   suInstId,        /* service user instance id */
SiInstId   spInstId,        /* service provider instance id */
CirId      circuit,         /* circuit ID code */
SiCnStEvnt *siCnStEvnt,     /* connect status event */
U8         evntType,        /* event type */
U8         xchgType,        /* type of exchange - valid only for ACM */
Buffer     *uBuf            /* unrecognised parameters */
)
#else
PUBLIC S16 SiUiSitCnStReq(pst, spId, suInstId, spInstId,
                          circuit, siCnStEvnt, evntType, xchgType, uBuf)
Pst        *pst;            /* bind configuration */
SpId       spId;            /* service user id */
SiInstId   suInstId;        /* service user instance id */
SiInstId   spInstId;        /* service provider instance id */
CirId      circuit;         /* circuit ID code */
SiCnStEvnt *siCnStEvnt;     /* connect status event */
U8         evntType;        /* event type */
U8         xchgType;        /* type of exchange - valid only for ACM */
Buffer     *uBuf;           /* unrecognised parameters */
#endif
{
   SiUpSAPCb *tCb;
   SiCon     *con;
   SiCirKey  key;
   SiCirCb   *cir;

   TRC3(SiUiSitCnStReq)
   UNUSED(pst);

   SIDBGP(DBGMASK_UI, (siCb.init.prntBuf,
          "%s\n\nSiUiSitCnStReq(spId=%#x, suInstId=%#lx, spInstId=%#lx,\
          circuit=%#lx, evntType=%#x)\n",
          SI_STR, spId, suInstId, spInstId, circuit, evntType)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
/* si039.220 - SILOGERROR was using SiUiSitBndReq */
      SILOGERROR(ERRCLS_DEBUG, ESI010, (ErrVal) ziCb.protState,
                 "SiUiSitCnStReq() failed, ISUP is not active\n");
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_UI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   if (((tCb = SIUPSAP(spId)) == NULLP) || (tCb->state != SI_BND))
   {
      SIDBGP(SIDBGMASK_CERR,
             (siCb.init.prntBuf, "Invalid upper SAP=%#x in CnStRreq", spId));

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI011, (ErrVal) spId, 
                 "SiUiSitCnStReq() Failed, invalid spId");
#endif
      siDropMsg(uBuf);
      siInitUstaDgn(LSI_USTA_DGNVAL_SPID, (PTR) &spId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LCM_CAUSE_INV_SAP, TRUE, 
                     (CirId) spId, SIISAP_INV);
      RETVALUE(RFAILED);
   }

   /* find connection */
   if (spInstId)
   {
      siFindInst(&siCb.conHlCp, &con, (SiInstKey *) &spInstId);
      if (con == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "CnStReq(): No connection for spInstId:%#lx\n", spInstId));
         siDropMsg(uBuf);
         /* Generate Alarm to Layer management */
         SISNDOLDLSISTAIND(&siCb.init.lmPst, circuit, SI_ALRM_INV_SPINSTID);

         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        CCINVALCALLREF);
         RETVALUE(RFAILED);
      }

      if ((circuit != con->incC.cirId) && (circuit != con->outC.cirId))
      {
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* check if this is a non-single rate connection. */
         if (((con->incC.cir != NULLP) && 
              (con->incC.cir->ctrlMultiRateCir != NULLP)) ||
             ((con->outC.cir != NULLP) && 
             (con->outC.cir->ctrlMultiRateCir != NULLP)))
         {
            /* it is a non-single rate connection. Means it received msg on a
             * non-controlling circuit.  Generate an alarm. 
             */
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                      "rcvd call control msg on a non-cntrl ckt %#lx in CnStReq\n",
                      circuit)); 
               siDropMsg(uBuf);

               /* means rcvd on a non cont ckt */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, 
                              LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                              TRUE, circuit, SI_ALRM_INV_CIRID);

               RETVALUE(RFAILED);
            }
         }
         else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
         {                      
            SIDBGP(SIDBGMASK_CERR, 
                   (siCb.init.prntBuf,
                    "circuit mismatch in CnStReq (circuit=%#lx,\
                    incC.cirId=%#lx, outC.cirId %#lx)\n", 
                    circuit, con->incC.cirId, con->outC.cirId)); 
             siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_STATE_MISMATCH, 
                           TRUE, circuit, SI_ALRM_INV_CIRID);

            /* Generate Release Indication to Upper Layer */
            siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                           SIT_CCPROTERR);
            RETVALUE(RFAILED);
         }
      }         
   }
   else
   {
      /* find circuit */
      key.k1.cirId = circuit;
      siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CIR);
      if (cir == (SiCirCb *) NULLP)
      {
         /* find the connection on the basis of 'suInstId' */
         if (siFindSuInstId(suInstId, &con) == RFAILED)
         {
             SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "At unequipped circuit %ld\n", circuit)); 
             siDropMsg(uBuf);
         
            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_SUINSTID, (PTR) &suInstId, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_SUINSTID, 
                           TRUE, circuit, SI_ALRM_CIR_UNEQUPD);

            /* Generate Release Indication to Upper Layer */
            siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, 
                           SIT_CCREQUNAVAIL);
            /* Send UCIC indication to Call Control */
            SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                          circuit, FALSE, SIT_STA_CIRUNEQPD, NULLP, NULLP);
            RETVALUE(RFAILED);
         }

         /* connection found; get the circuit */
         if ((con->incC.conPrcs) && (con->incC.cir->siCon == con))
            cir = con->incC.cir;
         else if ((con->outC.conPrcs) && (con->outC.cir->siCon == con))
            cir = con->outC.cir;
         else
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "Conn associated with ckt %#lx & spInstId %#lx mismatch\n",
                   circuit, spInstId)); 
            siDropMsg(uBuf);

            SISNDOLDLSISTAIND(&siCb.init.lmPst, circuit, SI_ALRM_INV_SUINSTID);

            /* Generate and send Release Indication to Upper Layer */
            siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, 
                           SIT_CCRESCUNAVAIL);
            RETVALUE(RFAILED);
         }
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* check if this is a non-single rate connection */
         if (cir->ctrlMultiRateCir != NULLP)
         {
            /* it is a non-single rate connection. Check if the controlling 
             * circuit is the self circuit. If no, generate an alarm 
             */
            if (cir->ctrlMultiRateCir != cir)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                      "rcvd call control msg on a non-cntrl ckt %#lx in \
                           CnStReq\n" , circuit)); 
               siDropMsg(uBuf);

               /* means rcvd on a non cont ckt */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, 
                                   LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                              TRUE, circuit, SI_ALRM_INV_CIRID);

               RETVALUE(RFAILED);
            }  
         }         
#endif
         circuit = cir->key.k1.cirId;
      }
      else
      {
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* check if this is a non-single rate connection first */
         if (cir->ctrlMultiRateCir != NULLP)
         {
            /* it is a non-single rate connection. Check if the controlling 
             * circuit is the self circuit. If no, generate an alarm 
             */
            if (cir->ctrlMultiRateCir != cir)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                      "rcvd call control msg on a non-cntrl ckt %#lx in \
                           CnStReq\n" , circuit)); 
               siDropMsg(uBuf);

               /* means rcvd on a non cont ckt */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, 
                                   LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                              TRUE, circuit, SI_ALRM_INV_CIRID);

               RETVALUE(RFAILED);
            }  
         }         
#endif
         if (cir->siCon == NULLP)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
               "CnStReq(): no connection on the circuit %#lx\n", circuit)); 
            siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_IDLE, TRUE, 
                           circuit, SI_ALRM_INV_CIRID);

            /* Generate Release Indication to Upper Layer */
            siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                           SIT_CCRESCUNAVAIL);
            RETVALUE(RFAILED);
         }
         con = cir->siCon;
      }
   }

   if ((con->suInstId) && (con->suInstId != suInstId))
   {
      SIDBGP(SIDBGMASK_CERR,
             (siCb.init.prntBuf, 
              "CnStReq(): suInstId %#lx mismatch with that in con %#lx \n",
               suInstId, con->suInstId)); 
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI012, (ErrVal) circuit,
                    "SiUiSitCnStReq() suInstId does not match");
#endif
      siDropMsg(uBuf);
      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &suInstId, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &con->suInstId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_SUINSTID_MISMATCH, TRUE, 
                     circuit, SI_ALRM_INV_SUINSTID);
      RETVALUE(RFAILED);
   }
   else
      con->suInstId = suInstId;

   if (con->mCallCb->state != SI_BND)
   {
      SIDBGP(SIDBGMASK_ERR,
             (siCb.init.prntBuf, 
              "CnStReq(): MTP SAP (%#x) state unbound (%#x)\n",
              con->mCallCb->suId, con->mCallCb->state)); 
      siDropMsg(uBuf);

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUID, (PTR) &con->tCallCb->spId, 
                    LSI_USTA_DGNVAL_SPID, (PTR) &con->mCallCb->suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_MSAP, TRUE, 
                     con->mCallCb->suId, SI_ALRM_NSAP_NOTBOUND);

      /* Generate Release Indication to Upper Layer */
      siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, SIT_CCDESTOUTORD);
      RETVALUE(RFAILED);
   }
   else
   {
      con->sduSp         = (SiAllSdus *) siCnStEvnt;
      con->evntType      = evntType;
      /* copy suInstId */
      con->suInstId      = suInstId;
      if (evntType == ADDRCMPLT)
      {
/* si029.220: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
#ifdef SI_218_COMP
         /* in ITU97 variant, we use bit 3 of xchgType to hold the infomation
          * of broadband/narrowband interworking. If the backword compatibility
          * flag SI_218_COMP is defined, ISUP will fill in this bit base on 
          * the user define compile options
          */
#ifdef SI_INIT_TOXA_BRNBAND
      /* fill in bit 3 as 1 */
      xchgType |= BRNBAND_ITWK;
#else
      /* fill in bit 3 as 0 */
      xchgType = (xchgType & (~(BRNBAND_ITWK)));
#endif /* SI_INIT_TOXA_BRNBAND */
#endif /* SI_218_COMP */
#endif /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA */
         con->xchgType = xchgType;
      }
      tCb->mfMsgCtl.uBuf = uBuf;
      /* jump into state matrix with the derived circuit id */
      siActDat(circuit, con, IEI_CNSTREQ);
   }

   /* Obtain the upper SAP afresh and set the uBuf to NULLP.
    * This is required because in case of tightly coupled
    * interface, tCb and con may be having stale pointer if
    * for some reason upper SAP and/or connection was deleted.
    */
   if ((tCb = SIUPSAP(spId)) != NULLP)
   {
      tCb->mfMsgCtl.uBuf = NULLP;
   }

   siDropMsg(uBuf);
   RETVALUE(ROK);
} /* end of SiUiSitCnStReq */


/*
*
*      Fun:   Connection Release Request
*
*      Desc:  This function is used to release the circuit switched
*             connection.
*
*      Ret:   ROK   - ok
*
*      Notes: We need to initialize the circuit id, when we find the
*             connection based upon the suInstId.
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitRelReq
(
Pst       *pst,             /* bind configuration */
SpId      spId,             /* service user id */
SiInstId  suInstId,         /* service user instance id */
SiInstId  spInstId,         /* service provider instance id */
CirId     circuit,          /* circuit ID code */
SiRelEvnt *siRelEvnt,       /* release event */
Buffer    *uBuf             /* unrecognised parameters */
)
#else
PUBLIC S16 SiUiSitRelReq(pst, spId, suInstId, spInstId, circuit,
                         siRelEvnt, uBuf)
Pst       *pst;             /* bind configuration */
SpId      spId;             /* service user id */
SiInstId  suInstId;         /* service user instance id */
SiInstId  spInstId;         /* service provider instance id */
CirId     circuit;          /* circuit ID code */
SiRelEvnt *siRelEvnt;       /* release event */
Buffer    *uBuf;            /* unrecognised parameters */
#endif
{
   SiUpSAPCb *tCb;
   SiCon     *con;
   SiAllSdus ev;
   SiCirKey  key;
   SiCirCb   *cir;

   TRC3(SiUiSitRelReq)
   UNUSED(pst);

   SIDBGP(DBGMASK_UI, (siCb.init.prntBuf,
          "%s\n\nSiUiSitRelReq(spId=%#x, suInstId=%#lx, spInstId=%#lx,\
          circuit=%#lx)\n", SI_STR, spId, suInstId, spInstId, circuit)); 

   /* si001.220, ADDED: added code to initialize the cir ptr */
   cir = NULLP;

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n"));
#if (ERRCLASS & ERRCLS_DEBUG)
/* si039.220 - SILOGERROR was using SiUiSitBndReq */
      SILOGERROR(ERRCLS_DEBUG, ESI014, (ErrVal) ziCb.protState,
                 "SiUiSitRelReq() failed, ISUP is not active\n");
#endif
      siDropMsg(uBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_UI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */
   
   if (((tCb = SIUPSAP(spId)) == NULLP) || (tCb->state != SI_BND))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                             (tCb)?"spId = 0x%x state 0x%x not bound\n":
                                   "spId = 0x%x control block non-existent \n",
                             spId, (tCb) ? tCb->state : 0));

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI015, (ErrVal) spId, 
                 "SiUiSitRelReq() Failed, invalid spId");
#endif
      siDropMsg(uBuf);
      siInitUstaDgn(LSI_USTA_DGNVAL_SPID, (PTR) &spId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LCM_CAUSE_INV_SAP, TRUE, 
                     (CirId) spId, SIISAP_INV);
/* si054.220 : Added Code to update error counter */
#if(SI_LMINT3 || SMSI_LMINT3)
/* si055.220 : Changed NULL to NULLP */
          siUpdErrSts(NULLP,LSI_STS_RELFAIL);
#endif /* SI_LMINT3 , SMSI_LMINT3 */
      RETVALUE(RFAILED);
   }

   /* find connection */
   if (spInstId)
   {
      /* find connection */
      siFindInst(&siCb.conHlCp, &con, (SiInstKey *) &spInstId);
      if (con == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "No connection for spInstId:%ld\n", spInstId)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         SISNDOLDLSISTAIND(&siCb.init.lmPst, circuit, SI_ALRM_INV_SPINSTID);

         /* Generate Release Confirmation to Upper Layer */
         cmMemset((U8 *) &ev, (U8) NOTPRSNT, sizeof(SiRelEvnt));
         UPDATECAUSE(ev.m.siRelEvnt.causeDgn, CCINVALCALLREF, tCb);
#if (SI_LMINT3 || SMSI_LMINT3)
         siUpdErrSts(NULLP, LSI_STS_ABNRMLREL);
#endif

         /* send release indication to the upper layer */
         SiUiSitRelCfm(&tCb->pst, tCb->suId, suInstId, spInstId,
                       circuit, &ev.m.siRelEvnt, NULLP);
         RETVALUE(RFAILED);
      }

      if ((circuit != con->incC.cirId) && (circuit != con->outC.cirId))
      {
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* check if this is a non-single rate connection. */
         if (((con->incC.cir != NULLP) && 
              (con->incC.cir->ctrlMultiRateCir != NULLP)) ||
             ((con->outC.cir != NULLP) && 
             (con->outC.cir->ctrlMultiRateCir != NULLP)))
         {
            /* it is a non-single rate connection. Means it received msg on a
             * non-controlling circuit.  Generate an alarm. 
             */
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                  "rcvd call control msg on a non-cntrl ckt %#lx in \
                        RelReq\n" , circuit)); 
               siDropMsg(uBuf);

               /* means rcvd on a non cont ckt */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, 
                              LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                              TRUE, circuit, SI_ALRM_INV_CIRID);

               RETVALUE(RFAILED);
            }
         }
         else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
         {              
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                       "Ckt %ld is neither inc %ld nor outC %ld\n",
                        circuit, con->incC.cirId, con->outC.cirId)); 
            siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, 
                           TRUE, circuit, SI_ALRM_INV_CIRID);

            /* send release confirmation to the upper layer 
             * This could potentially result in the loss of next call 
             * This is the only way to recover from this 
             */
            cmMemset((U8 *) &ev, (U8) NOTPRSNT, sizeof (SiRelEvnt));
            UPDATECAUSE(ev.m.siRelEvnt.causeDgn, SIT_CCPROTERR, tCb);
#if (SI_LMINT3 || SMSI_LMINT3)
            siUpdErrSts(NULLP, LSI_STS_ABNRMLREL);
#endif

            SiUiSitRelCfm(&tCb->pst, tCb->suId, suInstId, spInstId,
                          circuit, &ev.m.siRelEvnt, NULLP);
            RETVALUE(RFAILED);
         }
      }         
   }
   else
   {
      /* find circuit */
      key.k1.cirId = circuit;
      siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CIR);
      if (cir == (SiCirCb *) NULLP)
      {
         if (siFindSuInstId(suInstId, &con) == RFAILED)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "At unequipped circuit %ld\n", circuit)); 
            siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_SUINSTID, (PTR) &suInstId, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_UNKNOWN_SUINSTID, 
                           TRUE, circuit, SI_ALRM_CIR_UNEQUPD);

            /* Generate and send Release Confirmation to Upper Layer 
             * This could potentially result in a loss of next call
             * This is the only way to recover from this 
             */
            cmMemset((U8 *) &ev, (U8) NOTPRSNT, sizeof (SiRelEvnt));
            UPDATECAUSE(ev.m.siRelEvnt.causeDgn, SIT_CCREQUNAVAIL, tCb);
#if (SI_LMINT3 || SMSI_LMINT3)
            siUpdErrSts(NULLP, LSI_STS_ABNRMLREL);
#endif
            SiUiSitRelCfm(&tCb->pst, tCb->suId, suInstId, spInstId,
                           circuit, &ev.m.siRelEvnt, NULLP);

            /* Send UCIC indication to Call Control */
            SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                        circuit, FALSE, SIT_STA_CIRUNEQPD, 
                        NULLP, NULLP);
            RETVALUE(RFAILED);
         }

         /* connection found; get the circuit */
         if ((con->incC.conPrcs) && (con->incC.cir->siCon == con))
            cir = con->incC.cir;
         else if ((con->outC.conPrcs) && (con->outC.cir->siCon == con))
            cir = con->outC.cir;
         else
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
              "Circuit and connection mismatch\n")); 
            siDropMsg(uBuf);
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_STATE_MISMATCH, 
                           TRUE, circuit, SI_ALRM_INV_CIRID);

            /* Generate and send Release Indication to Upper Layer */
            cmMemset((U8 *) &ev, (U8) NOTPRSNT, sizeof (SiRelEvnt));
            UPDATECAUSE(ev.m.siRelEvnt.causeDgn, SIT_CCRESCUNAVAIL, tCb);
#if (SI_LMINT3 || SMSI_LMINT3)
            siUpdErrSts(cir, LSI_STS_ABNRMLREL);
#endif
            SiUiSitRelCfm(&tCb->pst, tCb->suId, suInstId, spInstId,
                           circuit, &ev.m.siRelEvnt, NULLP);
            RETVALUE(RFAILED);
         }
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* check if this is a non-single rate connection */
         if (cir->ctrlMultiRateCir != NULLP)
         {
            /* it is a non-single rate connection. Check if the controlling 
             * circuit is the self circuit. If no, generate an alarm to the 
             * layer manager
             */
            if (cir->ctrlMultiRateCir != cir)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                      "rcvd call control msg on a non-cntrl ckt %#lx in \
                           RelReq\n" , circuit)); 
               siDropMsg(uBuf);

               /* means rcvd on a non cont ckt */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, 
                                   LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                              TRUE, circuit, SI_ALRM_INV_CIRID);

               RETVALUE(RFAILED);
            }  
         }         
#endif
         circuit = cir->key.k1.cirId;
      }
      else
      {
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* check if this is a non-single rate connection first */
         if (cir->ctrlMultiRateCir != NULLP)
         {
            /* it is a non-single rate connection. Check if the controlling 
             * circuit is the self circuit. If no, generate an alarm to the 
             * layer manager
             */
            if (cir->ctrlMultiRateCir != cir)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                      "rcvd call control msg on a non-cntrl ckt %#lx in \
                           RelReq\n" , circuit)); 
               siDropMsg(uBuf);

               /* means rcvd on a non cont ckt */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, 
                                   LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                              TRUE, circuit, SI_ALRM_INV_CIRID);

               RETVALUE(RFAILED);
            }  
         }         
#endif
         if (cir->siCon == NULLP)
         {
            siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_IDLE, TRUE, 
                           circuit, SI_ALRM_INV_CIRID);

            /* Generate Release Confirmation to Upper Layer */
            cmMemset((U8 *) &ev, (U8) NOTPRSNT, sizeof (SiRelEvnt));
            UPDATECAUSE(ev.m.siRelEvnt.causeDgn, SIT_CCRESCUNAVAIL, tCb);
#if (SI_LMINT3 || SMSI_LMINT3)
            siUpdErrSts(cir, LSI_STS_ABNRMLREL);
#endif
            SiUiSitRelCfm(&tCb->pst, tCb->suId, suInstId, spInstId,
                           circuit, &ev.m.siRelEvnt, NULLP);
            
            RETVALUE(RFAILED);
         }
      }
      con = cir->siCon;
   }

   if ((con->suInstId) && (con->suInstId != suInstId))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
              " suInstId provided %ld and in con %ld mismatch\n",
                 suInstId, con->suInstId)); 
      siDropMsg(uBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI016, (ErrVal) circuit,
                    "SiUiSitRelReq() suInstId does not match");
#endif
      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &suInstId, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &con->suInstId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_SUINSTID_MISMATCH, TRUE, 
                     circuit, SI_ALRM_INV_SUINSTID);
      RETVALUE(RFAILED);
   }
   else
      con->suInstId = suInstId;

   if (con->mCallCb->state != SI_BND)
   {
       SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                    " MTP SAP state not bound %d\n",
                       con->mCallCb->state)); 
       siDropMsg(uBuf);

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUID, (PTR) &con->tCallCb->spId, 
                    LSI_USTA_DGNVAL_SPID, (PTR) &con->mCallCb->suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_MSAP, TRUE, 
                     con->mCallCb->suId, SI_ALRM_NSAP_NOTBOUND);

      /* Generate and send Release Indication to Upper Layer */
      cmMemset((U8 *) &ev, (U8) NOTPRSNT, sizeof (SiRelEvnt));
      UPDATECAUSE(ev.m.siRelEvnt.causeDgn, SIT_CCDESTOUTORD, tCb);
#if (SI_LMINT3 || SMSI_LMINT3)
      siUpdErrSts(cir, LSI_STS_ABNRMLREL);
#endif
      SiUiSitRelCfm(&tCb->pst, tCb->suId, suInstId, spInstId,
                    circuit, &ev.m.siRelEvnt, NULLP);
      RETVALUE(RFAILED);
   }
   else
   {
      con->sduSp         = (SiAllSdus *) siRelEvnt;
      tCb->mfMsgCtl.uBuf = uBuf;

      /* jump into state matrix with the derived circuit id */
      siActDat(circuit, con, IEI_RELREQ);
   }


   /* Obtain the upper SAP afresh and set the uBuf to NULLP.
    * This is required because in case of tightly coupled
    * interface, tCb and con may be having stale pointer if
    * for some reason upper SAP and/or connection was deleted.
    */
   if ((tCb = SIUPSAP(spId)) != NULLP)
   {
      tCb->mfMsgCtl.uBuf = NULLP;
   }

   siDropMsg(uBuf);
   RETVALUE(ROK);
} /* end of SiUiSitRelReq */


/*
*
*      Fun:   Connection Release Response
*
*      Desc:  This function is used to release the circuit switched
*             connection.
*
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitRelRsp
(
Pst       *pst,             /* bind configuration */
SpId      spId,             /* service user id */
SiInstId  suInstId,         /* service user instance id */
SiInstId  spInstId,         /* service provider instance id */
CirId     circuit,          /* circuit ID code */
SiRelEvnt *siRelEvnt,       /* release event */
Buffer    *uBuf             /* unrecognised parameters */
)
#else
PUBLIC S16 SiUiSitRelRsp(pst, spId, suInstId, spInstId, circuit,
                         siRelEvnt, uBuf)
Pst       *pst;             /* bind configuration */
SpId      spId;             /* service user id */
SiInstId  suInstId;         /* service user instance id */
SiInstId  spInstId;         /* service provider instance id */
CirId     circuit;          /* circuit ID code */
SiRelEvnt *siRelEvnt;       /* release event */
Buffer    *uBuf;            /* unrecognised parameters */
#endif
{
   SiCirKey  key;
   SiUpSAPCb *tCb;
   SiCon     *con;
   SiCirCb   *cir;

   TRC3(SiUiSitRelRsp)
   UNUSED(pst);

   SIDBGP(DBGMASK_UI, (siCb.init.prntBuf, 
                      "%s\n\nRelRsp  :       L4 <- L5\n", SI_STR)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
/* si039.220 - SILOGERROR was using SiUiSitBndReq */
      SILOGERROR(ERRCLS_DEBUG, ESI017, (ErrVal) ziCb.protState,
                 "SiUiSitRelRsp() failed, ISUP is not active\n");
#endif
      siDropMsg(uBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_UI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   if (((tCb = SIUPSAP(spId)) == NULLP) || (tCb->state != SI_BND))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                              (tCb) ? "spId = 0x%x state 0x%x not bound\n":
                                  "spId = 0x%x control block non-existent \n",
                              spId, (tCb) ? tCb->state : 0));

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI018, (ErrVal) spId, 
                 "SiUiSitRelRsp() Failed, invalid spId");
#endif
      siDropMsg(uBuf);
      siInitUstaDgn(LSI_USTA_DGNVAL_SPID, (PTR) &spId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LCM_CAUSE_INV_SAP, TRUE, 
                     (CirId) spId, SIISAP_INV);
      RETVALUE(RFAILED);
   }

   /* find connection */
   if (spInstId)
   {
      siFindInst(&siCb.conHlCp, &con, (SiInstKey *) &spInstId);
      if (con == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "No connection for spInstId:%ld\n", spInstId)); 
         siDropMsg(uBuf);
         /* Generate Alarm to Layer management */
         SISNDOLDLSISTAIND(&siCb.init.lmPst, circuit, SI_ALRM_INV_SPINSTID);
         RETVALUE(RFAILED);
      }
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      if ((circuit != con->incC.cirId) && (circuit != con->outC.cirId))
      {
         /* check if this is a non-single rate connection. */
         if (((con->incC.cir != NULLP) && 
              (con->incC.cir->ctrlMultiRateCir != NULLP)) ||
             ((con->outC.cir != NULLP) && 
              (con->outC.cir->ctrlMultiRateCir != NULLP)))
         {
            /* it is a non-single rate connection. Means it received msg on a
             * non-controlling circuit.  Generate an alarm. 
             */
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                  "rcvd call control msg on a non-cntrl ckt %#lx in \
                        RelRsp\n" , circuit)); 
               siDropMsg(uBuf);

               /* means rcvd on a non cont ckt */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, 
                              LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                              TRUE, circuit, SI_ALRM_INV_CIRID);

               RETVALUE(RFAILED);
            }
         }
      }
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   }
   else
   {
      /* find circuit */
      key.k1.cirId = circuit;
      siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CIR);
      if (cir == (SiCirCb *) NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "At unequipped circuit %ld\n", circuit)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, TRUE, 
                        circuit, SI_ALRM_CIR_UNEQUPD);

         /* Send UCIC indication to Call Control */
         SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                       circuit, FALSE, SIT_STA_CIRUNEQPD, 
                       NULLP, NULLP);
         RETVALUE(RFAILED);
      }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if this is a non-single rate connection first */
      if (cir->ctrlMultiRateCir != NULLP)
      {
         /* it is a non-single rate connection. Check if the controlling 
          * circuit is the self circuit. If no, generate an alarm to the 
          * layer manager
          */
         if (cir->ctrlMultiRateCir != cir)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                   "rcvd call control msg on a non-cntrl ckt %#lx in \
                   RelRsp\n" , circuit)); 
            siDropMsg(uBuf);

            /* means rcvd on a non cont ckt */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, 
                           LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                           TRUE, circuit, SI_ALRM_INV_CIRID);

            RETVALUE(RFAILED);
         }  
      }         
#endif

      if (cir->siCon == NULLP)
      {
         SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                    "No connection existing on the circuit %ld\n",
                         circuit)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_IDLE, TRUE, 
                        circuit, SI_ALRM_INV_CIRID);
         RETVALUE(RFAILED);
      }

      con = cir->siCon;
   }

   siStopConTmr(con, TMR_TRELRSP);
   siStopConTmr(con, TMR_TFNLRELRSP);

   if (con->suInstId && (con->suInstId != suInstId))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
              " suInstId provided %ld and in con %ld mismatch\n",
                 suInstId, con->suInstId)); 
      siDropMsg(uBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI019, (ErrVal) circuit,
                    "SiUiSitRelRsp() suInstId does not match");
#endif
      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &suInstId, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &con->suInstId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_SUINSTID_MISMATCH, TRUE, 
                     circuit, SI_ALRM_INV_SUINSTID);

      RETVALUE(RFAILED);
   }
   else
   {
      con->suInstId = suInstId;
   }

   if (con->mCallCb->state != SI_BND)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf, 
             "MTP SAP unbound %d\n", con->mCallCb->state)); 
      siDropMsg(uBuf);

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUID, (PTR) &con->tCallCb->spId, 
                    LSI_USTA_DGNVAL_SPID, (PTR) &con->mCallCb->suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_MSAP, TRUE, 
                     con->mCallCb->suId, SI_ALRM_NSAP_NOTBOUND);
      RETVALUE(RFAILED);
   }
   else
   {
      con->sduSp = (SiAllSdus *) siRelEvnt;
     
/* si005.220 - Modification. Modified code to return RFAILED if con->tCallCb
 * is NULLP.
 */
      if (con->tCallCb != NULLP)
      {
         con->tCallCb->mfMsgCtl.uBuf = uBuf;
      }
      else
      {
         SIDBGP(SIDBGMASK_ERR,
                (siCb.init.prntBuf, "tCallCb is NULLP\n"));
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP,
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_NW_RESOURCE, TRUE, 
                        circuit, SI_ALRM_ALOCCON_ERROR);
         RETVALUE(RFAILED);
      }
      /* jump into state matrix */
      siActDat(circuit, con, IEI_RELRSP);
   }

   /* Obtain the upper SAP afresh and set the uBuf to NULLP.
    * This is required because in case of tightly coupled
    * interface, tCb and con may be having stale pointer if
    * for some reason upper SAP and/or connection was deleted.
    */
   if ((tCb = SIUPSAP(spId)) != NULLP)
   {
      tCb->mfMsgCtl.uBuf = NULLP;
   }

   siDropMsg(uBuf);

   RETVALUE(ROK);
} /* end of SiUiSitRelRsp */


/*
*
*      Fun:  ISUP Data request
*
*      Desc:  This function provides for an exchange of user
*             data units.
*   
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitDatReq
(
Pst        *pst,            /* bind configuration */
SpId       spId,            /* service user id */
SiInstId   suInstId,        /* service user instance id */
SiInstId   spInstId,        /* service provider instance id */
CirId      circuit,         /* circuit ID code */
SiInfoEvnt *siInfoEvnt,     /* information event */
Buffer     *uBuf            /* unrecognised parameters */
)
#else
PUBLIC S16 SiUiSitDatReq(pst, spId, suInstId, spInstId, circuit,
                         siInfoEvnt, uBuf)
Pst        *pst;            /* bind configuration */
SpId       spId;            /* service user id */
SiInstId   suInstId;        /* service user instance id */
SiInstId   spInstId;        /* service provider instance id */
CirId      circuit;         /* circuit ID code */
SiInfoEvnt *siInfoEvnt;     /* information event */
Buffer     *uBuf;           /* unrecognised parameters */
#endif
{
   SiCirKey  key;
   SiUpSAPCb *tCb;
   SiCon     *con;
   SiCirCb   *cir;

   TRC3(SiUiSitDatReq)
   UNUSED(pst);

   SIDBGP(DBGMASK_UI, (siCb.init.prntBuf, 
                      "%s\n\nDatReq  :       L4 <- L5\n", SI_STR)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI020, (ErrVal) ziCb.protState,
                 "SiUiSitDatReq() failed, ISUP is not active\n");
#endif
      siDropMsg(uBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_UI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   if (((tCb = SIUPSAP(spId)) == NULLP) || (tCb->state != SI_BND))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                              (tCb) ? "spId = 0x%x state 0x%x not bound\n":
                                  "spId = 0x%x control block non-existent \n",
                              spId, (tCb) ? tCb->state : 0));

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI021, (ErrVal) spId, 
                 "SiUiSitDatReq() Failed, invalid spId");
#endif
      siDropMsg(uBuf);
      siInitUstaDgn(LSI_USTA_DGNVAL_SPID, (PTR) &spId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LCM_CAUSE_INV_SAP, TRUE, 
                     (CirId) spId, SIISAP_INV);
      RETVALUE(RFAILED);
   }

   /* find connection */
   if (spInstId)
   {
      /* find connection */
      siFindInst(&siCb.conHlCp, &con, (SiInstKey *) &spInstId);
      if (con == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "No connection for spInstId:%ld\n", spInstId)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         SISNDOLDLSISTAIND(&siCb.init.lmPst, circuit, SI_ALRM_INV_SPINSTID);

         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        CCINVALCALLREF);
         RETVALUE(RFAILED);
      }

      if ((circuit != con->incC.cirId) && (circuit != con->outC.cirId))
      {
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* check if this is a non-single rate connection. */
         if (((con->incC.cir != NULLP) && 
              (con->incC.cir->ctrlMultiRateCir != NULLP)) ||
             ((con->outC.cir != NULLP) && 
              (con->outC.cir->ctrlMultiRateCir != NULLP)))
         {
            /* it is a non-single rate connection. Means it received msg on a
             * non-controlling circuit.  Generate an alarm. 
             */
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                  "rcvd call control msg on a non-cntrl ckt %#lx in \
                        CnStReq\n" , circuit)); 
               siDropMsg(uBuf);

               /* means rcvd on a non cont ckt */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, 
                              LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                              TRUE, circuit, SI_ALRM_INV_CIRID);

               RETVALUE(RFAILED);
            }
         }
         else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
         {              
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "Ckt %ld is neither inc %ld nor outC %ld\n",
                        circuit, con->incC.cirId, con->outC.cirId)); 
            siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_STATE_MISMATCH, 
                           TRUE, circuit, SI_ALRM_INV_CIRID);

            /* Generate Release Indication to Upper Layer */
            siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, 
                           SIT_CCPROTERR);
            RETVALUE(RFAILED);
         }
      }
   }
   else
   {
      /* find circuit */
      key.k1.cirId = circuit;
      siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CIR);
      if (cir == (SiCirCb *) NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "circuit %#lx unequipped\n", circuit)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, TRUE, 
                        circuit, SI_ALRM_CIR_UNEQUPD);

         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        SIT_CCREQUNAVAIL);
         /* Send UCIC indication to Call Control */
         SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId, circuit, 
                       FALSE, SIT_STA_CIRUNEQPD, NULLP, NULLP);
         RETVALUE(RFAILED);
      }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if this is a non-single rate connection first */
      if (cir->ctrlMultiRateCir != NULLP)
      {
         /* it is a non-single rate connection. Check if the controlling 
          * circuit is the self circuit. If no, generate an alarm 
          */
         if (cir->ctrlMultiRateCir != cir)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                   "rcvd call control msg on a non-cntrl ckt %#lx in \
                   DatReq\n" , circuit)); 
            siDropMsg(uBuf);

            /* means rcvd on a non cont ckt */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, 
                           LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                           TRUE, circuit, SI_ALRM_INV_CIRID);

            RETVALUE(RFAILED);
         }  
      }         
#endif
      if (cir->siCon == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "No connection existing on the circuit %ld\n",
                         circuit)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_IDLE, TRUE, 
                        circuit, SI_ALRM_INV_CIRID);
         
         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        SIT_CCRESCUNAVAIL);
         RETVALUE(RFAILED);
      }
      con = cir->siCon;
   }

   if (con->suInstId != suInstId)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
              " suInstId provided %ld and in con %ld mismatch\n",
                 suInstId, con->suInstId)); 
      siDropMsg(uBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI022, (ErrVal) circuit,
                    "SiUiSitDatReq() suInstId donot match");
#endif
      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &suInstId, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &con->suInstId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_SUINSTID_MISMATCH, TRUE, 
                     circuit, SI_ALRM_INV_SUINSTID);
      RETVALUE(RFAILED);
   }

   if (con->mCallCb->state != SI_BND)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                    " MTP SAP state not bound %d\n",
                       con->mCallCb->state)); 
      siDropMsg(uBuf);

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUID, (PTR) &con->tCallCb->spId, 
                    LSI_USTA_DGNVAL_SPID, (PTR) &con->mCallCb->suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_MSAP, TRUE, 
                     con->mCallCb->suId, SI_ALRM_NSAP_NOTBOUND);

      /* Generate Release Indication to Upper Layer */
      siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, SIT_CCDESTOUTORD);
      RETVALUE(RFAILED);
   }
   else
   {
      con->sduSp = (SiAllSdus *) siInfoEvnt;
      
/* si005.220 - Modification. Modified code to return RFAILED if con->tCallCb
 * is NULLP.
 */
      if (con->tCallCb != NULLP)
      {
         con->tCallCb->mfMsgCtl.uBuf = uBuf;
      }
      else
      {
         SIDBGP(SIDBGMASK_ERR,
                (siCb.init.prntBuf, "tCallCb is NULLP\n"));
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP,
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_NW_RESOURCE, TRUE, 
                        circuit, SI_ALRM_ALOCCON_ERROR);
         RETVALUE(RFAILED);
      }

      /* jump into state matrix */
      siActDat(circuit, con, IEI_INFREQ);
   }


   /* Obtain the upper SAP afresh and set the uBuf to NULLP.
    * This is required because in case of tightly coupled
    * interface, tCb and con may be having stale pointer if
    * for some reason upper SAP and/or connection was deleted.
    */
   if ((tCb = SIUPSAP(spId)) != NULLP)
   {
      tCb->mfMsgCtl.uBuf = NULLP;
   }

   siDropMsg(uBuf);
   RETVALUE(ROK);
} /* end of SiUiSitDatReq */


/*
*
*      Fun:   Call Suspend Request
*
*      Desc:  This function is used to suspend a circuit switched
*             connection.
*   
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitSuspReq
(
Pst        *pst,            /* bind configuration */
SpId       spId,            /* service user id */
SiInstId   suInstId,        /* service user instance id */
SiInstId   spInstId,        /* service provider instance id */
CirId      circuit,         /* circuit ID code */
SiSuspEvnt *siSuspEvnt,     /* suspend event */
Buffer     *uBuf            /* unrecognised parameters */
)
#else
PUBLIC S16 SiUiSitSuspReq(pst, spId, suInstId, spInstId,
                          circuit, siSuspEvnt, uBuf)
Pst        *pst;            /* bind configuration */
SpId       spId;            /* service user id */
SiInstId   suInstId;        /* service user instance id */
SiInstId   spInstId;        /* service provider instance id */
CirId      circuit;         /* circuit ID code */
SiSuspEvnt *siSuspEvnt;     /* suspend event */
Buffer     *uBuf;           /* unrecognised parameters */
#endif
{
   SiUpSAPCb *tCb;
   SiCon     *con;
   SiCirKey   key;
   SiCirCb   *cir;
   SiIntfCb   *siIntfCb;

   TRC3(SiUiSitSuspReq)
   UNUSED(pst);

   SIDBGP(DBGMASK_UI, (siCb.init.prntBuf,
          "%s\n\nSiUiSitSuspReq(spId=%#x, suInstId=%#lx, spInstId=%#lx, \
          circuit=%#lx)\n", SI_STR, spId, suInstId, spInstId, circuit)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI023, (ErrVal) ziCb.protState,
                 "SiUiSitSuspReq() failed, ISUP is not active\n");
#endif
      siDropMsg(uBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_UI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   if (((tCb = SIUPSAP(spId)) == NULLP) || (tCb->state != SI_BND))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                              (tCb) ? "spId = 0x%x state 0x%x not bound\n":
                                  "spId = 0x%x control block non-existent \n",
                              spId, (tCb) ? tCb->state : 0));


#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI024, (ErrVal) spId, 
                 "SiUiSitSuspReq() Failed, invalid spId");
#endif
      siDropMsg(uBuf);
      siInitUstaDgn(LSI_USTA_DGNVAL_SPID, (PTR) &spId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LCM_CAUSE_INV_SAP, TRUE, 
                     (CirId) spId, SIISAP_INV);
      RETVALUE(RFAILED);
   }

   /* find connection */
   if (spInstId)
   {
      /* find connection */
      siFindInst(&siCb.conHlCp, &con, (SiInstKey *) &spInstId);
      if (con == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "No connection for spInstId:%ld\n", spInstId)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         SISNDOLDLSISTAIND(&siCb.init.lmPst, circuit, SI_ALRM_INV_SPINSTID);

         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        CCINVALCALLREF);
         RETVALUE(RFAILED);
      }


      if ((circuit != con->incC.cirId) && (circuit != con->outC.cirId))
      {
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* check if this is a non-single rate connection. */
         if (((con->incC.cir != NULLP) && 
             (con->incC.cir->ctrlMultiRateCir != NULLP)) 
             ||
             ((con->outC.cir != NULLP) && 
             (con->outC.cir->ctrlMultiRateCir != NULLP)))
         {
            /* it is a non-single rate connection. For ITU'97 or ETSI
             * v3, suspend is supported for a non-single call. 
             * Means it received msg on a non-controlling circuit.  
             * Generate an alarm. 
             */
            if ((con->tCallCb != NULLP) &&
                ((con->tCallCb->cfg.swtch == LSI_SW_ITU97) ||
                (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) ||
                (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) ||
                (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3)))
            {                      
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                  "rcvd call control msg on a non-cntrl ckt %#lx in \
                        SuspReq\n" , circuit)); 
               siDropMsg(uBuf);

               /* means rcvd on a non cont ckt */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, 
                              LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                              TRUE, circuit, SI_ALRM_INV_CIRID);

               RETVALUE(RFAILED);
            }
         }   
         else
#endif /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
         {                      
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "Ckt %ld is neither inc %ld nor outC %ld\n",
                        circuit, con->incC.cirId, con->outC.cirId)); 
            siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_STATE_MISMATCH, 
                           TRUE, circuit, SI_ALRM_INV_CIRID);

            /* Generate Release Indication to Upper Layer */
            siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, 
                           SIT_CCPROTERR);
            RETVALUE(RFAILED);
         }
      }
      cir = (circuit == con->incC.cirId) ? con->incC.cir :
                        con->outC.cir;
   }
   else
   {
      /* find circuit */
      key.k1.cirId = circuit;
      siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CIR);
      if (cir == (SiCirCb *) NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "At unequipped circuit %ld\n", circuit)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, TRUE, 
                        circuit, SI_ALRM_CIR_UNEQUPD);

         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        SIT_CCREQUNAVAIL);
         /* Send UCIC indication to Call Control */
         SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                       circuit, FALSE, SIT_STA_CIRUNEQPD, NULLP, NULLP);
         RETVALUE(RFAILED);
      }

      if (cir->siCon == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "No connection existing on the circuit %ld\n", circuit)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_IDLE, TRUE, 
                        circuit, SI_ALRM_INV_CIRID);

         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        SIT_CCRESCUNAVAIL);
         RETVALUE(RFAILED);
      }

      con = cir->siCon;

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if recv the request on a non-controlling circuit for
       * a non-single rate connection. This is required that if spInstId
       * is not provided and find the circuit control block through
       * circuit ID. 
       */
      if (cir->ctrlMultiRateCir != NULLP)
      {
         {
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
            /* it is a non-single rate connection. For ITU'97 or ETSI v3, 
             * Suspend is supported for a non-single call. Check if the 
             * controlling circuit is the self circuit. If no, generate 
             * an alarm to the layer manager 
             */
            if ((tCb->cfg.swtch == LSI_SW_ITU97) ||
                (tCb->cfg.swtch == LSI_SW_ITU2000) ||
                (tCb->cfg.swtch == LSI_SW_RUSS2000) ||
                (tCb->cfg.swtch == LSI_SW_ETSIV3))
            {                      
               if (cir->ctrlMultiRateCir != cir)
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                      "rcvd call control msg on a non-cntrl ckt %#lx in \
                      SuspReq\n" , circuit)); 
                  siDropMsg(uBuf);

                  /* means rcvd on a non cont ckt */
                  siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                                LSI_USTA_DGNVAL_NONE, NULLP, 
                                LSI_USTA_DGNVAL_NONE, NULLP, 
                                LSI_USTA_DGNVAL_NONE, NULLP);
                  SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                                 LCM_EVENT_UI_INV_EVT, 
                                 LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                                 TRUE, circuit, SI_ALRM_INV_CIRID);

                  RETVALUE(RFAILED);
               }  
            }
#endif /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
         }
      }   
#endif
   }

   if (con->suInstId != suInstId)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
              " suInstId provided %ld and in con %ld mismatch\n",
                 suInstId, con->suInstId)); 
      siDropMsg(uBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI025, (ErrVal) circuit,
                    "SiUiSitSuspReq() suInstId does not match");
#endif
      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &suInstId, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &con->suInstId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_SUINSTID_MISMATCH, TRUE, 
                     circuit, SI_ALRM_INV_SUINSTID);
      RETVALUE(RFAILED);
   }

   if (con->mCallCb->state != SI_BND)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                    " MTP SAP state not bound %d\n",
                       con->mCallCb->state)); 
      siDropMsg(uBuf);

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUID, (PTR) &con->tCallCb->spId, 
                    LSI_USTA_DGNVAL_SPID, (PTR) &con->mCallCb->suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_MSAP, TRUE, 
                     con->mCallCb->suId, SI_ALRM_NSAP_NOTBOUND);

      /* Generate Release Indication to Upper Layer */
      siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                     SIT_CCDESTOUTORD);
      RETVALUE(RFAILED);
   }
   else
   {
      cmMemset((U8 *)&key, '\0', sizeof(SiCirKey)); 
      key.k3.intfId = cir->cfg.intfId;
      if ((siIntfCb = cir->pIntfCb) == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "intf (%ld) not configured \n", key.k3.intfId));
         siDropMsg(uBuf);
 
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_INTF, (PTR) &key.k3.intfId, 
                       LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit,
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_INTF, TRUE, 
                        circuit, SI_ALRM_INTF_NOTCFGD);
 
         /* Generate and send release indication to upper layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, 
                        SIT_CCREQUNAVAIL);
         RETVALUE(RFAILED);
      }

      if (siIntfCb->state == SI_INTF_UNAVAIL)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                                " INTF state is unavailable dpc:0x%lx\n",
                                cir->key.k3.intfId)); 
         siDropMsg(uBuf);
 
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_INTF, (PTR) &cir->key.k3.intfId, 
                       LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit,
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_NW_RESOURCE,
                        TRUE, circuit, SI_ALRM_INTF_PAUSED);

         if( (con->incC.conPrcs) && (circuit == cir->siCon->incC.cirId) )
            cir->siCon->incC.toBeRelsd = TRUE;
         if( (con->outC.conPrcs) && (circuit == cir->siCon->outC.cirId) )
            cir->siCon->outC.toBeRelsd = TRUE;
 
         /* Generate and send release indication to upper layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, 
                        SIT_CCTMPFAIL);
         RETVALUE(RFAILED);
      }

      con->sduSp = (SiAllSdus *) siSuspEvnt;
      tCb->mfMsgCtl.uBuf = uBuf;

      /* jump into state matrix */
      siActDat(circuit, con, IEI_SUSPREQ);
   }

   /* Obtain the upper SAP afresh and set the uBuf to NULLP.
    * This is required because in case of tightly coupled
    * interface, tCb and con may be having stale pointer if
    * for some reason upper SAP and/or connection was deleted.
    */
   if ((tCb = SIUPSAP(spId)) != NULLP)
   {
      tCb->mfMsgCtl.uBuf = NULLP;
   }

   siDropMsg(uBuf);
   RETVALUE(ROK);
} /* end of SiUiSitSuspReq */


/*
*
*      Fun:   Call Resume Request
*
*      Desc:  This function is used to resume a circuit switched
*             connection.
*   
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitResmReq
(
Pst        *pst,            /* bind configuration */
SpId       spId,            /* service user id */
SiInstId   suInstId,        /* service user instance id */
SiInstId   spInstId,        /* service provider instance id */
CirId      circuit,         /* circuit ID code */
SiResmEvnt *siResmEvnt,     /* resume event */
Buffer     *uBuf            /* unrecognised parameters */
)
#else
PUBLIC S16 SiUiSitResmReq(pst, spId, suInstId, spInstId,
                          circuit, siResmEvnt, uBuf)
Pst        *pst;            /* bind configuration */
SpId       spId;            /* service user id */
SiInstId   suInstId;        /* service user instance id */
SiInstId   spInstId;        /* service provider instance id */
CirId      circuit;         /* circuit ID code */
SiResmEvnt *siResmEvnt;     /* resume event */
Buffer     *uBuf;           /* unrecognised parameters */
#endif
{
   SiCirKey  key;
   SiCirCb   *cir;
   SiCon     *con;
   SiUpSAPCb *tCb;

   TRC3(SiUiSitResmReq)
   UNUSED(pst);

   SIDBGP(DBGMASK_UI, (siCb.init.prntBuf,
          "%s\n\nSiUiSitResmReq(spId=%#x, suInstId=%#lx, spInstId=%#lx, \
          circuit=%#lx)\n", SI_STR, spId, suInstId, spInstId, circuit)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI026, (ErrVal) ziCb.protState,
                 "SiUiSitResmReq() failed, ISUP is not active\n");
#endif
      siDropMsg(uBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_UI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   if (((tCb = SIUPSAP(spId)) == NULLP) || (tCb->state != SI_BND))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         (tCb)?"For spId 0x%x state 0x%x not bound\n":
            "For spId 0x%x control block does not exist \n",
               spId, (tCb)?tCb->state:0));

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI027, (ErrVal) spId, 
                 "SiUiSitResmReq() Failed, invalid spId");
#endif
      siDropMsg(uBuf);
      siInitUstaDgn(LSI_USTA_DGNVAL_SPID, (PTR) &spId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LCM_CAUSE_INV_SAP, TRUE, 
                     (CirId) spId, SIISAP_INV);
      RETVALUE(RFAILED);
   }

   /* find connection */
   if (spInstId)
   {
      /* find connection */
      siFindInst(&siCb.conHlCp, &con, (SiInstKey *) &spInstId);
      if (con == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "No connection for spInstId:%ld\n", spInstId)); 

         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         SISNDOLDLSISTAIND(&siCb.init.lmPst, circuit, SI_ALRM_INV_SPINSTID);

         /* Generate and Send Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        CCINVALCALLREF);
         RETVALUE(RFAILED);
      }


      if ((circuit != con->incC.cirId) && (circuit != con->outC.cirId))
      {
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         if (((con->incC.cir != NULLP) && 
              (con->incC.cir->ctrlMultiRateCir != NULLP)) ||
             ((con->outC.cir != NULLP) &&
              (con->outC.cir->ctrlMultiRateCir != NULLP)))
         {
            /* check if receive the request on the non-controlling ckt for
             * a non-single rate connection. 
             */
            if ((tCb->cfg.swtch == LSI_SW_ITU97) ||
                (tCb->cfg.swtch == LSI_SW_ITU2000) ||
                (tCb->cfg.swtch == LSI_SW_RUSS2000) ||
                (tCb->cfg.swtch == LSI_SW_ETSIV3))
            {                 
               /* it is a non-single rate connection. For ITU'97 or ETSI
                * v3, esume is supported for a non-single call. 
                * Means it received msg on a non-controlling circuit.  
                * Generate an alarm. 
                */
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                  "rcvd call control msg on a non-cntrl ckt %#lx in \
                        ResmReq\n" , circuit)); 
               siDropMsg(uBuf);

               /* means rcvd on a non cont ckt */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR)&circuit, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR)&con->incC.cirId, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR)&con->outC.cirId, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, 
                              LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                              TRUE, circuit, SI_ALRM_INV_CIRID);

               RETVALUE(RFAILED);
            }
         }
         else
#endif /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
         {              
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "Ckt %ld is neither inc %ld nor outC %ld\n",
                        circuit, con->incC.cirId, con->outC.cirId)); 
            siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_STATE_MISMATCH, 
                           TRUE, circuit, SI_ALRM_INV_CIRID);

            /* Generate Release Indication to Upper Layer */
            siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, 
                           SIT_CCPROTERR);
            RETVALUE(RFAILED);
         }
      }
   }
   else
   {
      /* find circuit */
      key.k1.cirId = circuit;
      siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CIR);
      if (cir == (SiCirCb *) NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "At unequipped circuit %ld\n", circuit)); 

         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, TRUE, 
                        circuit, SI_ALRM_CIR_UNEQUPD);

         /* Generate and send release indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        SIT_CCREQUNAVAIL);

         /* Send UCIC indication to Call Control */
         SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                       circuit, FALSE, SIT_STA_CIRUNEQPD, NULLP, NULLP);
         RETVALUE(RFAILED);
      }

      if (cir->pIntfCb == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "intf (%ld) not configured \n", cir->cfg.intfId));
         siDropMsg(uBuf);
 
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_INTF, (PTR) &cir->cfg.intfId, 
                       LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit,
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_INTF, TRUE, 
                        circuit, SI_ALRM_INTF_NOTCFGD);
 
         /* Generate and send release indication to upper layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        SIT_CCREQUNAVAIL);
         RETVALUE(RFAILED);
      }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if receiving the request on a non-controlling circuit for
       * a non-single rate connection. For ANS95, resume is not allow in
       * non-single rate call
       */
      if (cir->ctrlMultiRateCir != NULLP)
      {
         {              
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
            /* it is a non-single rate connection. For ITU'97 or ETSI
             * v3, esume is supported for a non-single call. Check if the 
             * controlling circuit is the self circuit. If no, generate an 
             * alarm to the ayer manager
             */
            if ((cir->pIntfCb->cfg.swtch == LSI_SW_ITU97) ||
                (cir->pIntfCb->cfg.swtch == LSI_SW_ITU2000) ||
                (cir->pIntfCb->cfg.swtch == LSI_SW_RUSS2000) ||
                (cir->pIntfCb->cfg.swtch == LSI_SW_ETSIV3))
            {                      
               if (cir->ctrlMultiRateCir != cir)
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                         "rcvd call control msg on a non-cntrl ckt %#lx in \
                         ResmReq\n" , circuit)); 
                  siDropMsg(uBuf);

                  /* means rcvd on a non cont ckt */
                  siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                                LSI_USTA_DGNVAL_NONE, NULLP, 
                                LSI_USTA_DGNVAL_NONE, NULLP, 
                                LSI_USTA_DGNVAL_NONE, NULLP);
                  SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                                 LCM_EVENT_UI_INV_EVT, 
                                 LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                                 TRUE, circuit, SI_ALRM_INV_CIRID);

                  RETVALUE(RFAILED);
               }  
            }
#endif /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
         }
      }   
#endif
      if (cir->siCon == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "No connection existing on the circuit %ld\n",
                         circuit)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_IDLE, TRUE, 
                        circuit, SI_ALRM_INV_CIRID);

         /* Generate and send release indication to upper layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        SIT_CCRESCUNAVAIL);
         RETVALUE(RFAILED);
      }

      con = cir->siCon;
   }

   if (con->suInstId != suInstId)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
              " suInstId provided %ld and in con %ld mismatch\n",
                 suInstId, con->suInstId)); 
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI028, (ErrVal) circuit,
                    "SiUiSitResmReq() suInstId does not match");
#endif
      siDropMsg(uBuf);
      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &suInstId, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &con->suInstId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_SUINSTID_MISMATCH, TRUE, 
                     circuit, SI_ALRM_INV_SUINSTID);
      RETVALUE(RFAILED);
   }

   if (con->mCallCb->state != SI_BND)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                    " MTP SAP state not bound %d\n",
                       con->mCallCb->state)); 
      siDropMsg(uBuf);

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUID, (PTR) &con->tCallCb->spId, 
                    LSI_USTA_DGNVAL_SPID, (PTR) &con->mCallCb->suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_MSAP, TRUE, 
                     con->mCallCb->suId, SI_ALRM_NSAP_NOTBOUND);

      /* Generate and send release indication to upper layer */
      siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, SIT_CCDESTOUTORD);
      RETVALUE(RFAILED);
   }
   else
   {
      con->sduSp                  = (SiAllSdus *) siResmEvnt;
    
/* si005.220 - Modification. Modified code to return RFAILED if con->tCallCb
 * is NULLP.
 */
      if (con->tCallCb != NULLP)
      {
         con->tCallCb->mfMsgCtl.uBuf = uBuf;
      }
      else
      {
         SIDBGP(SIDBGMASK_ERR,
                (siCb.init.prntBuf, "tCallCb is NULLP\n"));
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP,
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_NW_RESOURCE, TRUE, 
                        circuit, SI_ALRM_ALOCCON_ERROR);
         RETVALUE(RFAILED);
      }
      /* jump into state matrix */
      siActDat(circuit, con, IEI_RESREQ);
   }

   /* Obtain the upper SAP afresh and set the uBuf to NULLP.
    * This is required because in case of tightly coupled
    * interface, tCb and con may be having stale pointer if
    * for some reason upper SAP and/or connection was deleted.
    */
   if ((tCb = SIUPSAP(spId)) != NULLP)
   {
      tCb->mfMsgCtl.uBuf = NULLP;
   }

   siDropMsg(uBuf);
   RETVALUE(ROK);
} /* end of SiUiSitResmReq */


/*
*
*      Fun:   Call Status Request 
*
*      Desc:  This function is used to request global or circuit switched
*             connection status.
*   
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitStaReq
(
Pst       *pst,             /* bind configuration */
SpId      spId,             /* service user id */
SiInstId  suInstId,         /* service user instance id */
SiInstId  spInstId,         /* service provider instance id */
Bool      globalFlg,        /* global flag */
CirId     circuit,          /* circuit ID code */
U8        evntType,         /* event type */
SiStaEvnt *siStaEvnt,       /* status event */
Buffer    *uBuf             /* unrecognised parameters */
)
#else
PUBLIC S16 SiUiSitStaReq(pst, spId, suInstId, spInstId, globalFlg, circuit,
                         evntType, siStaEvnt, uBuf)
Pst       *pst;             /* bind configuration */
SpId      spId;             /* service user id */
SiInstId  suInstId;         /* service user instance id */
SiInstId  spInstId;         /* service provider instance id */
Bool      globalFlg;        /* global flag */
CirId     circuit;          /* circuit ID code */
U8        evntType;         /* event type */
SiStaEvnt *siStaEvnt;       /* status event */
Buffer    *uBuf;            /* unrecognised parameters */
#endif
{
   SiUpSAPCb *tCb;
   SiNSAPCb *mCb;
   SiCirKey  key;
   SiCirCb   *siCir;
   SiCon     *con;
   SiAllSdus ev;
   S16       ret;

   TRC3(SiUiSitStaReq)
   UNUSED(pst);
   UNUSED(globalFlg);

   SIDBGP(DBGMASK_UI, (siCb.init.prntBuf,
          "%s\n\nSiUiSitStaReq(spId=%#x, suInstId=%#lx, spInstId=%#lx, \
          circuit=%#lx, evntType=%#x)\n",
          SI_STR, spId, suInstId, spInstId, circuit, evntType)); 

   siCir = NULLP;

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI029, (ErrVal) ziCb.protState,
                 "SiUiSitStaReq() failed, ISUP is not active\n");
#endif
      siDropMsg(uBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_UI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   if (((tCb = SIUPSAP(spId)) == NULLP) || (tCb->state != SI_BND))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         (tCb)?"For spId 0x%x state 0x%x not bound\n":
            "For spId 0x%x control block does not exist \n",
               spId, (tCb)?tCb->state:0));

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI030, (ErrVal) spId, 
                 "SiUiSitStaReq() Failed, invalid spId");
#endif
      siDropMsg(uBuf);
      siInitUstaDgn(LSI_USTA_DGNVAL_SPID, (PTR) &spId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LCM_CAUSE_INV_SAP, TRUE, 
                     (CirId) spId, SIISAP_INV);
      RETVALUE(RFAILED);
   }

   switch (evntType)
   {
      case SIT_STA_CONFUSION:
         if (siStaEvnt)
         {
            /* initialize Status Event */
            MFINITSDU(&tCb->mfMsgCtl, ret, (U8) 0, (U8) SI_STAREQ,
                     (ElmtHdr *) NULLP, (ElmtHdr *) &ev, (U8) NOTPRSNT,
                     tCb->cfg.swtch, (U32) MF_ISUP);

            if (spInstId)
            {
               /* find connection */
               siFindInst(&siCb.conHlCp, &con, (SiInstKey *) &spInstId);
               if (con == NULLP)
               {
                  ev.m.siStaEvnt.causeDgn.eh.pres       = PRSNT_NODEF;
                  ev.m.siStaEvnt.causeDgn.causeVal.pres = PRSNT_NODEF;
                  ev.m.siStaEvnt.causeDgn.causeVal.val  = CCINVALCALLREF;
 
                  /* send error indicatin to the upper layer */
                  SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                                circuit, FALSE, ERRORIND, &ev.m.siStaEvnt, 
                                NULLP);
                  siDropMsg(uBuf);
                  RETVALUE(RFAILED);
               }
 
               if ((con->suInstId) && (con->suInstId != suInstId))
               {
                  ev.m.siStaEvnt.causeDgn.eh.pres       = PRSNT_NODEF;
                  ev.m.siStaEvnt.causeDgn.causeVal.pres = PRSNT_NODEF;
                  ev.m.siStaEvnt.causeDgn.causeVal.val  = CCINVALCALLREF;
 
                  /* send error indicatin to the upper layer */
                  SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                                circuit, FALSE, ERRORIND, &ev.m.siStaEvnt, 
                                NULLP);
                  siDropMsg(uBuf);
                  RETVALUE(RFAILED);
               }
               else
                  con->suInstId = suInstId;

               if ((con->incC.conPrcs) && (circuit == con->incC.cirId))
                  siCir = con->incC.cir;
               else if ((con->outC.conPrcs) && (circuit == con->outC.cirId))
                  siCir = con->outC.cir;

               if (siCir == NULLP)
               {
                  /* The siCir is NULLP, the reasons are:
                   * 1) if the conn is a non-single rate connection, CFN 
                   *    req is received on a non-controlling circuit 
                   *    because ISUP gets the siCir after comparing the 
                   *    circuit which recv CFN req with the cirId
                   *    in circuit conn cb within the conn.
                   * 2) if the conn is a non-single rate connection, CFN 
                   *    request is recv on the non-participated circuit 
                   *    for that conn.
                   * 3) if the conn is a single rate connection, CFN req 
                   *    is recv on the non-participated circuit for that 
                   *    conn.
                   * In all the cases, they are errors. Generate an alarm and
                   * drop the msg.
                   */
                   SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                          "rcvd CFN req on a NULLP ckt %#lx \
                          if spInstId is used in StaReq\n", circuit)); 
                   ev.m.siStaEvnt.causeDgn.eh.pres       = PRSNT_NODEF;
                   ev.m.siStaEvnt.causeDgn.causeVal.pres = PRSNT_NODEF;
                   ev.m.siStaEvnt.causeDgn.causeVal.val  = CCINVALCALLREF;
 
                   /* send error indicatin to the upper layer */
                   SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                                 circuit, FALSE, ERRORIND, &ev.m.siStaEvnt, 
                                 NULLP);

                        /* generate to the layer manager */
                   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                                   LSI_USTA_DGNVAL_NONE, NULLP, 
                                   LSI_USTA_DGNVAL_NONE, NULLP, 
                                   LSI_USTA_DGNVAL_NONE, NULLP);
                   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                                    LCM_EVENT_UI_INV_EVT, 
                                         LSI_CAUSE_INV_CIRCUIT, 
                                    TRUE, circuit, SI_ALRM_INV_CIRID);

                   siDropMsg(uBuf);
                   RETVALUE(RFAILED);
               }         
            }
            else
            {
               /* find circuit */
               key.k1.cirId = circuit;
               siFindCir(&siCb.cirHlCp, &siCir, &key, 0, KEY_CIR);
               if (siCir == (SiCirCb *) NULLP)
               {
                  ev.m.siStaEvnt.causeDgn.eh.pres       = PRSNT_NODEF;
                  ev.m.siStaEvnt.causeDgn.causeVal.pres = PRSNT_NODEF;
                  ev.m.siStaEvnt.causeDgn.causeVal.val  = SIT_CCPROTERR;
 
                  /* send error indication to the upper layer */
                  SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                                circuit, FALSE, ERRORIND, &ev.m.siStaEvnt, 
                                NULLP);
                  siDropMsg(uBuf);
                  RETVALUE(RFAILED);
               }
 
               /* get connection */
               if (siCir->siCon)
                  con = siCir->siCon;
            }
 
            mCb = siGetLwrMCbPtr(siCir);
            if (siStaEvnt->causeDgn.eh.pres == NOTPRSNT)
            {
               MFINITELMT(&mCb->mfMsgCtl, ret, NULLP,
                          (ElmtHdr *) &siStaEvnt->causeDgn, &meCauseIndV, 
                          (U8) PRSNT_DEF, tCb->cfg.swtch, (U32) MF_ISUP);
 
            }
            if (con != NULLP)
            {
               if (con->mCallCb == NULLP)
                  con->mCallCb = mCb;
               siGenConf(con, siCir, &siStaEvnt->causeDgn);
            }
            else
            {
               siGenConfNoCon(mCb, siCir->key.k2.intfId, siCir->phyDpc, TRUE, 
                    siCir->opc, siCir->key.k2.cic, &siStaEvnt->causeDgn,
                    tCb->cfg.swtch);
            }
         }
         break;
 
      case SIT_STA_CONTREP:     /* continuity report */
      case SIT_STA_CONTCHK:     /* continuity check */
      case SIT_STA_LOOPBACKACK:  /* loopback acknowledge */
         if (spInstId)
         {
            /* find connection */
            siFindInst(&siCb.conHlCp, &con, (SiInstKey *) &spInstId);
            if (con == NULLP)
            {
                SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                  "No connection for spInstId:%ld\n", spInstId)); 

               siDropMsg(uBuf);

               /* Generate Alarm to Layer management */
               SISNDOLDLSISTAIND(&siCb.init.lmPst, circuit, 
                                 SI_ALRM_INV_SPINSTID);

               /* Generate and send release indication to upper layer */
               siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                              CCINVALCALLREF);
               RETVALUE(RFAILED);
            }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
            /* check if this is a non-single rate connection. */
            if (((con->incC.cir != NULLP) && 
                 (con->incC.cir->ctrlMultiRateCir != NULLP)) 
                ||
                ((con->outC.cir != NULLP) && 
                 (con->outC.cir->ctrlMultiRateCir != NULLP)))
            {
               /* it is a non-single rate connection. There is no cases to get
                * CCR and LPA in the non-single rate calls for ANS'95 and CCR
                * for ITU97 and ETSI v3. CCR are sent under two scenarioes:
                * 1) after a conitunity check failure
                * 2) sent on a idle state
                * For case 1), only single continuty-check failure procedure
                * are applied to the controlling ckt, non-controlling ckts are
                * idled.
                * For case 2), there no call exists.
                */
               if ((evntType == SIT_STA_CONTCHK) || 
                        (evntType == SIT_STA_LOOPBACKACK))
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                     "rcvd CCR or LPA req for an non-single rate call on \
                     ckt %#lx \n", circuit)); 
                  siDropMsg(uBuf);

                  /* generate an alarm */
                  siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                                LSI_USTA_DGNVAL_NONE, NULLP, 
                                LSI_USTA_DGNVAL_NONE, NULLP, 
                                LSI_USTA_DGNVAL_NONE, NULLP);
                  SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                                 LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_EVNT, 
                                 TRUE, circuit, SI_ALRM_INV_CIRID);

                  RETVALUE(RFAILED);
               }              
               else
               {              
                  /* it is a non-single rate connection. COT is supported. 
                   * Check if the controlling circuit is the 
                   * self circuit. If no, generate an alarm to the ayer manager
                   */
                  if ((circuit != con->incC.cirId) && 
                      (circuit != con->outC.cirId))
                  {
                     SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                           "rcvd COT/CCR req on a non-cntrl ckt %#lx in \
                           StaReq\n" , circuit)); 
                     siDropMsg(uBuf);

                     /* means rcvd on a non cont ckt */
                     siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                                   LSI_USTA_DGNVAL_NONE, NULLP, 
                                   LSI_USTA_DGNVAL_NONE, NULLP, 
                                   LSI_USTA_DGNVAL_NONE, NULLP);
                     SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                                    LCM_EVENT_UI_INV_EVT, 
                                    LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                                    TRUE, circuit, SI_ALRM_INV_CIRID);

                     RETVALUE(RFAILED);
                  }  
               }
            }   
#endif

            if ((con->suInstId) && (con->suInstId != suInstId))
            {
                SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   " suInstId provided %ld and in con %ld mismatch\n",
                     suInstId, con->suInstId)); 
#if (ERRCLASS & ERRCLS_DEBUG)
                SILOGERROR(ERRCLS_DEBUG, ESI032, (ErrVal) suInstId,
                           "SiUiSitStaReq() suInstId does not match ");
#endif
               siDropMsg(uBuf);
               /* Generate Alarm to Layer management */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                             LSI_USTA_DGNVAL_SUINSTID, (PTR) &suInstId, 
                             LSI_USTA_DGNVAL_SUINSTID, (PTR) &con->suInstId, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LSI_EVENT_UI_INV_VARIANT, 
                              LSI_CAUSE_SUINSTID_MISMATCH, TRUE, 
                              circuit, SI_ALRM_INV_SUINSTID);
               RETVALUE(RFAILED);
            }
            else
               con->suInstId = suInstId;
         }
         else
         {
            /* find circuit */
            key.k1.cirId = circuit;
            siFindCir(&siCb.cirHlCp, &siCir, &key, 0, KEY_CIR);
            if (siCir == (SiCirCb *) NULLP) 
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "At unequipped circuit %ld\n", circuit)); 

               siDropMsg(uBuf);

               /* Send UCIC indication to Call Control */
               SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                             circuit, FALSE, SIT_STA_CIRUNEQPD, 
                             NULLP, NULLP);

               /* Generate Alarm to Layer management */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, 
                              TRUE, circuit, SI_ALRM_CIR_UNEQUPD);

               RETVALUE(RFAILED);
            }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
            /* check if this is a non-single rate connection.  */
            if (siCir->ctrlMultiRateCir != NULLP) 
            {
               /* it is a non-single rate connection. There is no cases to get
                * CCR(LPA in ans'95) in the non-single rate calls. CCR are
                * sent under two scenarioes:
                * 1) after a conitunity check failure
                * 2) sent on a idle state
                * For case 1), only single continuty-check failure procedure
                * are applied to the controlling ckt, non-controlling ckts are
                * idled.
                * For case 2), there no call exists.
                */
               if ((evntType == SIT_STA_CONTCHK) || 
                         (evntType == SIT_STA_LOOPBACKACK))
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                       "rcvd CCR or LPA req for an non-single rate call on \
                       ckt %#lx \n", circuit)); 
                  siDropMsg(uBuf);

                  /* generate an alarm */
                  siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                                LSI_USTA_DGNVAL_NONE, NULLP, 
                                LSI_USTA_DGNVAL_NONE, NULLP, 
                                LSI_USTA_DGNVAL_NONE, NULLP);
                  SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                                 LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_EVNT, 
                                 TRUE, circuit, SI_ALRM_INV_CIRID);

                  RETVALUE(RFAILED);
               }              
               else
               {              
                  /* it is a non-single rate connection. 
                   * COT is supported. Check if the controlling circuit is the 
                   * self circuit. If no, generate an alarm to the ayer manager
                   */
                  if (siCir->ctrlMultiRateCir != siCir) 
                  {
                     SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                            "rcvd COT/CCR req on a non-cntrl ckt %#lx in \
                            StaReq\n" , circuit)); 
                     siDropMsg(uBuf);

                     /* means rcvd on a non cont ckt */
                     siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                                   LSI_USTA_DGNVAL_NONE, NULLP, 
                                   LSI_USTA_DGNVAL_NONE, NULLP, 
                                   LSI_USTA_DGNVAL_NONE, NULLP);
                     SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                                    LCM_EVENT_UI_INV_EVT, 
                                    LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                                    TRUE, circuit, SI_ALRM_INV_CIRID);

                     RETVALUE(RFAILED);
                  }  
               }
            }   
#endif
            /* si014.220, Removed: Deleted code to avoid extra allocation of
                                   instance */
            /* get connection */
            if (siCir->siCon)
               con = siCir->siCon;
            else
            {
               /* si014.220, ADDITION: Moved code over here to allocate an 
                                       instance only if the connection control 
                                       block is not present */
               /* get instance */
               if (siGetInstId(&spInstId) == RFAILED)
               {
                  SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                       " Can not allocate a new spInst id\n")); 
 
                  siDropMsg(uBuf);

                  /* Generate Alarm to Layer management */
                  siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                                LSI_USTA_DGNVAL_NONE, NULLP,
                                LSI_USTA_DGNVAL_NONE, NULLP, 
                                LSI_USTA_DGNVAL_NONE, NULLP);
                  SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_RESOURCE, 
                                 LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CAL_REF, TRUE, 
                                 circuit, SI_ALRM_ALOCSPINST_ERROR);

                  /* Generate and send release indication to upper layer */
                  siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                                 SIT_CCSWTCHCONG);
                  RETVALUE(RFAILED);
               }
               con = siGetOutCon(siCir, tCb);
               if (con == NULLP)
               {
                  SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                    "Can not allocate a connection block\n")); 

                  siDropMsg(uBuf);

                  /* Generate Alarm to Layer management */
                  siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                                LSI_USTA_DGNVAL_NONE, NULLP,
                                LSI_USTA_DGNVAL_NONE, NULLP, 
                                LSI_USTA_DGNVAL_NONE, NULLP);
                  SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_RESOURCE, 
                                 LCM_EVENT_UI_INV_EVT, LSI_CAUSE_NO_MEMORY, 
                                 TRUE, circuit, SI_ALRM_ALOCCON_ERROR);

                  /* Generate and send release indication to upper layer */
                  siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                                 SIT_CCRESCUNAVAIL);
                  RETVALUE(RFAILED);
               }
               con->key.k1.spInstId = spInstId;
               siAddInst(&siCb.conHlCp, con);
               /* get Sap control block */
               con->mCallCb         = siGetLwrMCbPtr(siCir);
               con->tCallCb         = tCb;
               con->outC.conPrcs    = TRUE;
            }
            if (con->suInstId == 0)
               con->suInstId = suInstId;
         }
         if (con->mCallCb->state != SI_BND)
         {
            SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                    " MTP SAP state not bound %d\n",
                       con->mCallCb->state)); 
            siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_SUID, (PTR) &con->tCallCb->spId, 
                          LSI_USTA_DGNVAL_SPID, (PTR) &con->mCallCb->suId, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_MSAP, TRUE, 
                           con->mCallCb->suId, SI_ALRM_NSAP_NOTBOUND);

            /* Generate and send release indication to upper layer */
            siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, 
                           SIT_CCDESTOUTORD);
            RETVALUE(RFAILED);
         }
         else
         {
            con->sduSp         = (SiAllSdus *) siStaEvnt;
            con->evntType      = evntType;
            tCb->mfMsgCtl.uBuf = uBuf;
            
            /* jump into state matrix */
            siActDat(circuit, con, IEI_STAREQ);
         }
         break;
         

      case SIT_STA_CGQRYRSP:  /* circuit group query response */
         break;

      case SIT_STA_CIRBLOREQ: /* circuit block request */
      case SIT_STA_CIRBLORSP: /* circuit block response */
      case SIT_STA_CIRUBLREQ: /* circuit unblock request */
      case SIT_STA_CIRUBLRSP: /* circuit unblock response */
      case SIT_STA_CIRRESREQ: /* circuit reset request */
      case SIT_STA_CIRRESRSP: /* circuit reset response */
         /* find circuit */
         key.k1.cirId = circuit;
         siFindCir(&siCb.cirHlCp, &siCir, &key, 0, KEY_CIR);
         if (siCir == NULLP)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "At unequipped circuit %ld\n", circuit)); 

            siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, TRUE, 
                           circuit, SI_ALRM_CIR_UNEQUPD);

            /* Send UCIC indication to Call Control */
            SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                 circuit, FALSE, SIT_STA_CIRUNEQPD, 
                 NULLP, NULLP);
               
            RETVALUE(RFAILED);
         }

         /* process circuit requests */
         if (siStaEvnt != NULLP)
            ev.m.siStaEvnt = *(SiStaEvnt *)siStaEvnt;
         siCir->sduSp   = &ev;
         siProcCirEvt(siCir, evntType, FALSE);
         break;

      case SIT_STA_CGBREQ:   /* circuit group block request */
      case SIT_STA_CGUREQ:   /* circuit group unblock request */
      case SIT_STA_CGBRSP:   /* circuit group block response */
      case SIT_STA_CGURSP:   /* circuit group unblock response */
      case SIT_STA_CGQRYREQ: /* circuit group query request */
      case SIT_STA_GRSREQ:   /* circuit group reset request */
      case SIT_STA_GRSRSP:   /* circuit group reset response - ver3 i/f */
         /* find circuit */
         key.k1.cirId = circuit;
         siFindCir(&siCb.cirHlCp, &siCir, &key, 0, KEY_CIR);
         if (siCir == NULLP)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "At unequipped circuit %ld\n", circuit)); 
            siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, TRUE, 
                           circuit, SI_ALRM_CIR_UNEQUPD);
            /* Send UCIC indication to Call Control */
            SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                          circuit, FALSE, SIT_STA_CIRUNEQPD, 
                          NULLP, NULLP);
            RETVALUE(RFAILED);
         }

         /* si016.220, Modify: added a NULLP check before dereference 
          * of siStaEvnt */
         if (siStaEvnt != NULLP)
            ev.m.siStaEvnt = *(SiStaEvnt *)siStaEvnt;
         siCir->sduSp   = &ev;
         siProcCirGrEvt(siCir, evntType, siStaEvnt);
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "Default eventype received %d\n", evntType));
         siDropMsg(uBuf); 
         SILOGERROR(ERRCLS_DEBUG, ESI036, (ErrVal) circuit,
                    "SiUiSitConRsp() invalid event type");
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_SWTCH, (PTR) &tCb->cfg.swtch, 
                       LSI_USTA_DGNVAL_EVENT, (PTR) &pst->event, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_EVNT, TRUE, 
                        circuit, SI_ALRM_INV_EVENT);
         RETVALUE(RFAILED);
#endif
   }

   /* Obtain the upper SAP afresh and set the uBuf to NULLP.
    * This is required because in case if tightly coupled
    * interface, tCb and con may be having stale pointer if
    * for some reason upper SAP and/or connection was deleted.
    */
   if ((tCb = SIUPSAP(spId)) != NULLP)
   {
      tCb->mfMsgCtl.uBuf = NULLP;
   }

   siDropMsg(uBuf);
   RETVALUE(ROK);
} /* end of SiUiSitStaReq */


/*
*
*      Fun:   Facility Request
*
*      Desc:  This function is used to request facility.
*   
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitFacReq
(
Pst       *pst,             /* bind configuration */
SpId      spId,             /* service user id */
SiInstId  suInstId,         /* service user instance id */
SiInstId  spInstId,         /* service provider instance id */
CirId     circuit,          /* circuit ID code */
U8        evntType,         /* event type */
SiFacEvnt *siFacEvnt,       /* facility event */
Buffer    *uBuf             /* unrecognised parameters */
)
#else
PUBLIC S16 SiUiSitFacReq(pst, spId, suInstId, spInstId, circuit, 
                         evntType, siFacEvnt, uBuf)
Pst       *pst;             /* bind configuration */
SpId      spId;             /* service user id */
SiInstId  suInstId;         /* service user instance id */
SiInstId  spInstId;         /* service provider instance id */
CirId     circuit;          /* circuit ID code */
U8        evntType;         /* event type */
SiFacEvnt *siFacEvnt;       /* facility event */
Buffer    *uBuf;            /* unrecognised parameters */
#endif
{
   SiUpSAPCb *tCb;
   SiCon     *con;
   SiCirCb   *cir;
   SiCirKey  key;

   TRC3(SiUiSitFacReq)
   UNUSED(pst);

   SIDBGP(DBGMASK_UI, (siCb.init.prntBuf,
          "%s\n\nSiUiSitFacReq(spId=%#x, suInstId=%#lx, spInstId=%#lx, \
          circuit=%#lx)\n", SI_STR, spId, suInstId, spInstId, circuit)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI037, (ErrVal) ziCb.protState,
                 "SiUiSitFacReq() failed, ISUP is not active\n");
#endif
      siDropMsg(uBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_UI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   if (((tCb = SIUPSAP(spId)) == NULLP) || (tCb->state != SI_BND))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         (tCb)?"For spId 0x%x state 0x%x not bound\n":
            "For spId 0x%x control block does not exist \n",
               spId, (tCb)?tCb->state:0));


#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI038, (ErrVal) spId, 
                 "SiUiSitFacReq() Failed, invalid spId");
#endif
      siDropMsg(uBuf);
      siInitUstaDgn(LSI_USTA_DGNVAL_SPID, (PTR) &spId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LCM_CAUSE_INV_SAP, TRUE, 
                     (CirId) spId, SIISAP_INV);
      RETVALUE(RFAILED);
   }


   /* find connection */
   if (spInstId)
   {
      /* find connection */
      siFindInst(&siCb.conHlCp, &con, (SiInstKey *) &spInstId);
      if (con == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "No connection for spInstId:%ld\n", spInstId)); 

         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         SISNDOLDLSISTAIND(&siCb.init.lmPst, circuit, SI_ALRM_INV_SPINSTID);

         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        CCINVALCALLREF);
         RETVALUE(RFAILED);
      }

      if ((circuit != con->incC.cirId) && (circuit != con->outC.cirId))
      {
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* check if this is a non-single rate connection. */
         if (((con->incC.cir != NULLP) && 
              (con->incC.cir->ctrlMultiRateCir != NULLP)) ||
             ((con->outC.cir != NULLP) && 
              (con->outC.cir->ctrlMultiRateCir != NULLP)))
         {
            /* it is a non-single rate connection. Means it received msg on a
             * non-controlling circuit.  Generate an alarm. 
             */
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                  "rcvd call control msg on a non-cntrl ckt %#lx in \
                        FacReq\n" , circuit)); 
               siDropMsg(uBuf);

               /* means rcvd on a non cont ckt */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, 
                                   LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                              TRUE, circuit, SI_ALRM_INV_CIRID);

               RETVALUE(RFAILED);
            }
         }
         else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
         {              
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "Ckt %ld is neither inc %ld nor outC %ld\n",
                        circuit, con->incC.cirId, con->outC.cirId)); 
            siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_STATE_MISMATCH, 
                           TRUE, circuit, SI_ALRM_INV_CIRID);

            /* Generate Release Indication to Upper Layer */
            siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, 
                           SIT_CCPROTERR);
            RETVALUE(RFAILED);
         }
      }
   }
   else
   {
      /* find circuit */
      key.k1.cirId = circuit;
      siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CIR);
      if (cir == (SiCirCb *) NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "At unequipped circuit %ld\n", circuit)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, TRUE, 
                        circuit, SI_ALRM_CIR_UNEQUPD);

         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        SIT_CCREQUNAVAIL);
         /* Send UCIC indication to Call Control */
         SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                       circuit, FALSE, SIT_STA_CIRUNEQPD, NULLP, NULLP);
         RETVALUE(RFAILED);
      }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if this is a non-single rate connection first */
      if (cir->ctrlMultiRateCir != NULLP)
      {
         /* it is a non-single rate connection. Check if the controlling 
          * circuit is the self circuit. If no, generate an alarm 
          */
         if (cir->ctrlMultiRateCir != cir)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                   "rcvd call control msg on a non-cntrl ckt %#lx in \
                   FacReq\n" , circuit)); 
            siDropMsg(uBuf);

            /* means rcvd on a non cont ckt */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, 
                           LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                           TRUE, circuit, SI_ALRM_INV_CIRID);

            RETVALUE(RFAILED);
         }  
      }         
#endif
      if (cir->siCon == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "No connection existing on the circuit %ld\n",
                         circuit)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_IDLE, TRUE, 
                        circuit, SI_ALRM_INV_CIRID);

         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        SIT_CCRESCUNAVAIL);
         RETVALUE(RFAILED);
      }
      con = cir->siCon;
   }

   if (con->suInstId != suInstId)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             " suInstId provided %ld and in con %ld mismatch\n",
                 suInstId, con->suInstId)); 
      siDropMsg(uBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI039, (ErrVal) circuit,
                    "SiUiSitFacReq() suInstId does not match");
#endif
      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &suInstId, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &con->suInstId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LSI_EVENT_UI_INV_VARIANT, LSI_CAUSE_SUINSTID_MISMATCH, 
                     TRUE, circuit, SI_ALRM_INV_SUINSTID);
      RETVALUE(RFAILED);
   }

   if (((con->mCallCb) && (con->mCallCb->state == SI_BND)) ||
       ((con->sCallCb) && (con->sCallCb->state == SI_BND) && (con->useSCCP)))
   {
      con->sduSp                  = (SiAllSdus *) siFacEvnt;
      con->evntType               = evntType;

/* si005.220 - Modification. Modified code to return RFAILED if con->tCallCb
 * is NULLP.
 */
      if (con->tCallCb != NULLP)
      {
         con->tCallCb->mfMsgCtl.uBuf = uBuf;
      }
      else
      {
         SIDBGP(SIDBGMASK_ERR,
                (siCb.init.prntBuf, "tCallCb is NULLP\n"));
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP,
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_NW_RESOURCE, TRUE, 
                        circuit, SI_ALRM_ALOCCON_ERROR);
         RETVALUE(RFAILED);
      }
      /* jump into state matrix */
      siActDat(circuit, con, IEI_FACREQ);
   }
   else
   {
      siDropMsg(uBuf);

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUID, (PTR) &con->tCallCb->spId, 
                    LSI_USTA_DGNVAL_SPID, (PTR) &con->mCallCb->suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_MSAP, TRUE, 
                     con->mCallCb->suId, SI_ALRM_NSAP_NOTBOUND);

      /* Generate Release Indication to Upper Layer */
      siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                     SIT_CCDESTOUTORD);
      RETVALUE(RFAILED);
   }

   /* Obtain the upper SAP afresh and set the uBuf to NULLP.
    * This is required because in case of tightly coupled
    * interface, tCb and con may be having stale pointer if
    * for some reason upper SAP and/or connection was deleted.
    */
   if ((tCb = SIUPSAP(spId)) != NULLP)
   {
      tCb->mfMsgCtl.uBuf = NULLP;
   }
   siDropMsg(uBuf);
   RETVALUE(ROK);
} /* end of SiUiSitFacReq */


/*
*
*      Fun:   Facility Response
*
*      Desc:  This function is used to request facility.
*   
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitFacRsp
(
Pst       *pst,             /* bind configuration */
SpId      spId,             /* service user id */
SiInstId  suInstId,         /* service user instance id */
SiInstId  spInstId,         /* service provider instance id */
CirId     circuit,          /* circuit ID code */
U8        evntType,         /* event type */
SiFacEvnt *siFacEvnt,       /* facility event */
Buffer    *uBuf             /* unrecognised parameters */
)
#else
PUBLIC S16 SiUiSitFacRsp(pst, spId, suInstId, spInstId, circuit, 
                         evntType, siFacEvnt, uBuf)
Pst       *pst;             /* bind configuration */
SpId      spId;             /* service user id */
SiInstId  suInstId;         /* service user instance id */
SiInstId  spInstId;         /* service provider instance id */
CirId     circuit;          /* circuit ID code */
U8        evntType;         /* event type */
SiFacEvnt *siFacEvnt;       /* facility event */
Buffer    *uBuf;            /* unrecognised parameters */
#endif
{
   SiUpSAPCb *tCb;
   SiCon     *con;
   SiCirCb   *cir;
   SiCirKey  key;

   TRC3(SiUiSitFacRsp)
   UNUSED(pst);

   SIDBGP(DBGMASK_UI, (siCb.init.prntBuf,
          "%s\n\nSiUiSitFacRsp(spId=%#x, suInstId=%#lx, spInstId=%#lx, \
          circuit=%#lx)\n", SI_STR, spId, suInstId, spInstId, circuit)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI040, (ErrVal) ziCb.protState,
                 "SiUiSitFacRsp() failed, ISUP is not active\n");
#endif
      siDropMsg(uBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_UI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   if (((tCb = SIUPSAP(spId)) == NULLP) || (tCb->state != SI_BND))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         (tCb)?"For spId 0x%x state 0x%x not bound\n":
            "For spId 0x%x control block does not exist \n",
               spId, (tCb)?tCb->state:0));

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI041, (ErrVal) spId, 
                 "SiUiSitFacRsp() Failed, invalid spId");
#endif
      siDropMsg(uBuf);
      siInitUstaDgn(LSI_USTA_DGNVAL_SPID, (PTR) &spId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LCM_CAUSE_INV_SAP, TRUE, 
                     (CirId) spId, SIISAP_INV);
      RETVALUE(RFAILED);
   }


   /* find connection */
   if (spInstId)
   {
      /* find connection */
      siFindInst(&siCb.conHlCp, &con, (SiInstKey *) &spInstId);
      if (con == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "No connection for spInstId:%ld\n", spInstId)); 

         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         SISNDOLDLSISTAIND(&siCb.init.lmPst, circuit, SI_ALRM_INV_SPINSTID);

         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        CCINVALCALLREF);
         RETVALUE(RFAILED);
      }

      if ((circuit != con->incC.cirId) && (circuit != con->outC.cirId))
      {
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* check if this is a non-single rate connection. */
         if (((con->incC.cir != NULLP) && 
              (con->incC.cir->ctrlMultiRateCir != NULLP)) ||
             ((con->outC.cir != NULLP) && 
              (con->outC.cir->ctrlMultiRateCir != NULLP)))
         {
            /* it is a non-single rate connection. Means it received msg on a
             * non-controlling circuit.  Generate an alarm. 
             */
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                  "rcvd call control msg on a non-cntrl ckt %#lx in \
                        FacRsp\n" , circuit)); 
               siDropMsg(uBuf);

               /* means rcvd on a non cont ckt */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                             LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, 
                              LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                              TRUE, circuit, SI_ALRM_INV_CIRID);

               RETVALUE(RFAILED);
            }
         }
         else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
         {                      
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "Ckt %ld is neither inc %ld nor outC %ld\n",
                        circuit, con->incC.cirId, con->outC.cirId)); 
            siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_STATE_MISMATCH, 
                           TRUE, circuit, SI_ALRM_INV_CIRID);

            /* Generate Release Indication to Upper Layer */
            siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, 
                           SIT_CCPROTERR);
            RETVALUE(RFAILED);
         }
      }
   }
   else
   {
      /* find circuit */
      key.k1.cirId = circuit;
      siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CIR);
      if (cir == (SiCirCb *) NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "At unequipped circuit %ld\n", circuit)); 

         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, TRUE, 
                        circuit, SI_ALRM_CIR_UNEQUPD);

         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        SIT_CCREQUNAVAIL);

         /* Send UCIC indication to Call Control */
         SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                       circuit, FALSE, SIT_STA_CIRUNEQPD, NULLP, NULLP);
         RETVALUE(RFAILED);
      }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if this is a non-single rate connection first */
      if (cir->ctrlMultiRateCir != NULLP)
      {
         /* it is a non-single rate connection. Check if the controlling 
          * circuit is the self circuit. If no, generate an alarm 
          */
         if (cir->ctrlMultiRateCir != cir)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                   "rcvd call control msg on a non-cntrl ckt %#lx in \
                   FacRsp\n" , circuit)); 
            siDropMsg(uBuf);

            /* means rcvd on a non cont ckt */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, 
                           LSI_CAUSE_EVNT_ON_NON_CNTCIC, 
                           TRUE, circuit, SI_ALRM_INV_CIRID);

            RETVALUE(RFAILED);
         }  
      }         
#endif
      if (cir->siCon == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "No connection existing on the circuit %ld\n", circuit)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_IDLE, TRUE, 
                        circuit, SI_ALRM_INV_CIRID);

         /* Generate Release Indication to Upper Layer */
         siGenErrRelInd(tCb, suInstId, spInstId, circuit, NULLP, 
                        SIT_CCSWTCHCONG);
         RETVALUE(RFAILED);
      }
      con = cir->siCon;
   }

   if (con->suInstId != suInstId)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             " suInstId provided %ld and in con %ld mismatch\n",
                 suInstId, con->suInstId)); 
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI042, (ErrVal) circuit,
                    "SiUiSitFacRsp() suInstId does not match ");
#endif
      siDropMsg(uBuf);
      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &suInstId, 
                    LSI_USTA_DGNVAL_SUINSTID, (PTR) &con->suInstId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LSI_EVENT_UI_INV_VARIANT, 
                     LSI_CAUSE_SUINSTID_MISMATCH, TRUE, 
                     circuit, SI_ALRM_INV_SUINSTID);
      RETVALUE(RFAILED);
   }

   if (((con->mCallCb) && (con->mCallCb->state == SI_BND)) ||
       ((con->sCallCb) && (con->sCallCb->state == SI_BND) && (con->useSCCP)))
   {
      con->sduSp                  = (SiAllSdus *) siFacEvnt;
      con->evntType               = evntType;

/* si005.220 - Modification. Modified code to return RFAILED if con->tCallCb
 * is NULLP.
 */
      if (con->tCallCb != NULLP)
      {
         con->tCallCb->mfMsgCtl.uBuf = uBuf;
      }
      else
      {
         SIDBGP(SIDBGMASK_ERR,
                (siCb.init.prntBuf, "tCallCb is NULLP\n"));
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP,
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_NW_RESOURCE, TRUE, 
                        circuit, SI_ALRM_ALOCCON_ERROR);
         RETVALUE(RFAILED);
      }
      /* jump into state matrix */
      siActDat(circuit, con, IEI_FACRSP);
   }
   else
   {
      siDropMsg(uBuf);

      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                    LSI_USTA_DGNVAL_SUID, (PTR) &con->tCallCb->spId, 
                    LSI_USTA_DGNVAL_SPID, (PTR) &con->mCallCb->suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_MSAP, TRUE, 
                     con->mCallCb->suId, SI_ALRM_NSAP_NOTBOUND);

      /* Generate Release Indication to Upper Layer */
      siGenErrRelInd(tCb, suInstId, spInstId, circuit, con, SIT_CCDESTOUTORD);
      RETVALUE(RFAILED);
   }

   /* Obtain the upper SAP afresh and set the uBuf to NULLP.
    * This is required because in case of tightly coupled
    * interface, tCb and con may be having stale pointer if
    * for some reason upper SAP and/or connection was deleted.
    */
   if ((tCb = SIUPSAP(spId)) != NULLP)
   {
      tCb->mfMsgCtl.uBuf = NULLP;
   }

   siDropMsg(uBuf);
   RETVALUE(ROK);
} /* end of SiUiSitFacRsp */



/*
*
*      Fun:   Unrecognized message request
*
*      Desc:  This function provides a mechanism for call control to send
*             message(s) not supported by ISUP.
*
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 SiUiSitUMsgReq
(
Pst *pst,                   /* post structure */
SpId spId,                  /* service provider id */
SiInstId suInstId,          /* service user instance id */
SiInstId spInstId,          /* service provider instance id */
CirId     circuit,          /* circuit ID code */
Buffer *uBuf                /* message with unrecognizable parameters */
)
#else
PUBLIC S16 SiUiSitUMsgReq(pst, spId, suInstId, spInstId, circuit, uBuf)
Pst *pst;                   /* post structure */
SpId spId;                  /* service provider id */
SiInstId suInstId;          /* service user instance id */
SiInstId spInstId;          /* service provider instance id */
CirId    circuit;           /* circuit ID code */
Buffer *uBuf;               /* message with unrecognizable parameters */
#endif
{
   SiCirKey  key;
   SiUpSAPCb *tCb;
   SiNSAPCb  *nCb;
   SiCon     *siCon;
   SiCirCb   *siCir;
   Buffer    *mBuf;
   LnkSel    lnkSel;
   S16       ret;

   TRC3(SiUiSitUMsgReq)
   UNUSED(pst);

   SIDBGP(DBGMASK_UI, (siCb.init.prntBuf, "%s\n\nUMsgReq :       L4 <- L5\n",
                      SI_STR)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI051, (ErrVal) ziCb.protState,
                 "SiUiSitUMsgReq() failed, ISUP is not active\n");
#endif
      siDropMsg(uBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_UI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   /* check if received msg is empty */
   if (uBuf == NULLP)
   {
      /* drop uBuf */
      siDropMsg(uBuf);
      RETVALUE(RFAILED);
   }

   if (((tCb = SIUPSAP(spId)) == NULLP) || (tCb->state != SI_BND))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         (tCb)?"For spId 0x%x state 0x%x not bound\n":
            "For spId 0x%x control block does not exist \n",
               spId, (tCb)?tCb->state:0));


#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI052, (ErrVal)spId,
                "SiUiSitUMsgReq() Failed, invalid spId");
#endif
      siInitUstaDgn(LSI_USTA_DGNVAL_SPID, (PTR) &spId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LCM_CAUSE_INV_SAP, TRUE, 
                     (CirId) spId, SIISAP_INV);
      siDropMsg(uBuf);
      RETVALUE(RFAILED);
   }

   /* find connection */
   if (spInstId)
   {
      /* find connection */
      siFindInst(&siCb.conHlCp, &siCon, (SiInstKey *) &spInstId);
      if (siCon == NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "No connection for spInstId:%ld\n", spInstId)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         SISNDOLDLSISTAIND(&siCb.init.lmPst, circuit, SI_ALRM_INV_SPINSTID);
         RETVALUE(RFAILED);
      }

      if ((circuit != siCon->incC.cirId) && (circuit != siCon->outC.cirId))
      {
         {                      
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "Ckt %ld is neither inc %ld nor outC %ld\n",
                        circuit, siCon->incC.cirId, siCon->outC.cirId)); 
            siDropMsg(uBuf);

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &siCon->incC.cirId, 
                          LSI_USTA_DGNVAL_CIRCUIT, (PTR) &siCon->outC.cirId, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LCM_EVENT_UI_INV_EVT, LSI_CAUSE_CIC_STATE_MISMATCH, 
                           TRUE, circuit, SI_ALRM_INV_CIRID);
            RETVALUE(RFAILED);
         }
      }

      /* get the circuit control block */
      if ((siCon->incC.conPrcs) && (circuit == siCon->incC.cirId))
         siCir = siCon->incC.cir;
      else if ((siCon->outC.conPrcs) && (circuit == siCon->outC.cirId))
         siCir = siCon->outC.cir;

      if (siCir == (SiCirCb *) NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "At unequipped circuit %ld associated with spInstId %ld\n", 
                 circuit, spInstId)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, TRUE, 
                        circuit, SI_ALRM_CIR_UNEQUPD);
         RETVALUE(RFAILED);
      }
   }
   else
   {
      /* find circuit */
      key.k1.cirId = circuit;
      siCir = (SiCirCb *)NULLP;
      siFindCir(&siCb.cirHlCp, &siCir, &key, 0, KEY_CIR);
      if (siCir == (SiCirCb *) NULLP)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "At unequipped circuit %ld\n", circuit)); 
         siDropMsg(uBuf);

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, TRUE, 
                        circuit, SI_ALRM_CIR_UNEQUPD);
         /* Send UCIC indication to Call Control */
         SiUiSitStaInd(&tCb->pst, tCb->suId, suInstId, spInstId,
                       circuit, FALSE, SIT_STA_CIRUNEQPD, 
                       NULLP, NULLP);
         RETVALUE(RFAILED);
      }
      siCon = siCir->siCon;
   }

   if ((SiCon *)NULLP == siCon) 
   {
      /* if connection block is NULLP, get mtp control block */
      /* and linksel to post message to MTP-3 */
      nCb = siGetLwrMCbPtr(siCir);
      if (nCb == NULLP)
      {
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                "can't find MTP-3 SAP for swtch %d\n", tCb->cfg.swtch));  
         siDropMsg(uBuf); 
         RETVALUE(RFAILED);
      }
      /* si025.220 - Modified: changed arguments in siGetLnkSel */
      /* si009.220 - Modified: to pass cic into siGetLnkSel */
      siGetLnkSel(nCb, &lnkSel, tCb->cfg.swtch, siCir);
   }
   else
   {
      if ((siCon->suInstId) && (siCon->suInstId != suInstId))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "suInstId provided %ld and in con %ld mismatch\n",
                 suInstId, siCon->suInstId)); 
         siDropMsg(uBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI053, (ErrVal) circuit,
                    "SiUiSitUMsgReq() suInstId donot match");
#endif
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &circuit, 
                       LSI_USTA_DGNVAL_SUINSTID, (PTR) &suInstId, 
                       LSI_USTA_DGNVAL_SUINSTID, (PTR) &siCon->suInstId, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LSI_EVENT_UI_INV_VARIANT, 
                        LSI_CAUSE_SUINSTID_MISMATCH, TRUE, 
                        circuit, SI_ALRM_INV_SUINSTID);
         RETVALUE(RFAILED);
      } 
      lnkSel = siCon->lnkSel;
      nCb    = siCon->mCallCb;
   }

   /* copy unrecognized message into mBuf */
   if ((ret = SCpyMsgMsg(uBuf, nCb->pst.region, nCb->pst.pool, &mBuf)) 
       != ROK)
   {
   /* si013.220- ADD: Added following code to drop mBuf when the 
                      unrecognized message cannot be copied properly */
      siDropMsg(mBuf);
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "SCpyMsgMsg failed\n")); 
      RETVALUE(ret);
   } 
   siDropMsg(uBuf); /* drop the incoming uBuf from upper layer */

   
   /* si013.220- CHANGE: Modified code to check return value from GetHiByte,
                         and drop mBuf when this return value is incorrect */
   ret = SAddPreMsg((Data )GetHiByte(siCir->key.k2.cic), mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "SAddPreMsg failed .Dropping\n")); 
      SILOGERROR(ERRCLS_DEBUG, ESI079, (ErrVal)ret, 
         "SAddPstMsg() Failed");
      siDropMsg(mBuf);
      RETVALUE(ret);
   }
#endif
   /* si013.220- CHANGE: Modified code to check return value from GetHiByte,
                         and drop mBuf when this return value is incorrect */
   ret = SAddPreMsg((Data )GetLoByte(siCir->key.k2.cic), mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "SAddPreMsg failed .Dropping\n")); 
      SILOGERROR(ERRCLS_DEBUG, ESI079, (ErrVal)ret, 
         "SAddPstMsg() Failed");
      siDropMsg(mBuf);
      RETVALUE(ret);
   }
#endif

   /* send message */
   siSndMsg(nCb, mBuf, siCir->opc, siCir->key.k3.intfId, siCir->phyDpc, 
            TRUE, lnkSel, FALSE, PRI_ZERO, tCb->cfg.swtch); 

   RETVALUE(ROK);
} /* end of SiUiSitUMsgReq */


/*
*
*       Fun:   SiUiSitPtCdeStaReq
*
*       Desc:  Point code status request from the ISUP user
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy1.c
*
*/
#ifdef SI_UTSI_ENHANCE
/* Schubert.Zhang add for request status to MTP3/M3UA */
S32 siPortFlagReqDpcSta = 1;
#endif /* SI_UTSI_ENHANCE */

#ifdef ANSI
PUBLIC S16 SiUiSitPtCdeStaReq
(
Pst  *pst,
SpId spId,
SiInstId  intfId
)
#else
PUBLIC S16 SiUiSitPtCdeStaReq (pst, spId, intfId)
Pst  *pst;
SpId spId;
SiInstId  intfId;
#endif
{
   SiUpSAPCb *tCb;
   SiIntfCb   *intfCb;
   U8        status;
   U8        congLevel;

   TRC3(SiUiSitPtCdeStaReq)
   UNUSED(pst);

   tCb = SIUPSAP(spId);
   if ((tCb == NULLP) || (tCb->state != SI_BND))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI054, (ErrVal) spId,
                 "SiUiSitPtCdeStaReq() Failed, Invalid upper SAP");
#endif
      /* alarm to be generated */
      RETVALUE(RFAILED);
   }

   if (siFindIntf(&intfCb, intfId, 0, 0, 0, 0, SIINTF_KEY_1) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI055, (ErrVal) spId,
        "SiUiSitPtCdeStaReq() Failed, Can't find Interface control block");
#endif
      RETVALUE(RFAILED);
   }

   /* initialization */
   congLevel = SIT_STA_MTPCONG0;
/* si003.220 - Addition. Added initialization to status to remove compiler
 * warning.
 */
   status = 0x00;
   switch (intfCb->state)
   {
      case SI_INTF_AVAIL:
         status = SIT_STA_RESUMEIND;
         congLevel = SIT_STA_MTPCONG0;
         break;

      case SI_INTF_UNAVAIL:
         status = SIT_STA_PAUSEIND;
         break;

      case SI_INTF_CONG1:
         status = SIT_STA_RESUMEIND;
         congLevel = SIT_STA_MTPCONG1;
         break;

      case SI_INTF_CONG2:
         status = SIT_STA_RESUMEIND;
         congLevel = SIT_STA_MTPCONG2;
         break;

      case SI_INTF_CONG3:
         status = SIT_STA_RESUMEIND;
         congLevel = SIT_STA_MTPCONG3;
         break;
         
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI056, (ErrVal) intfCb->state,
                    "SiUiSitPtCdeStaReq() Failed, invalid state value");
#endif
         RETVALUE(RFAILED);
   }
   
#ifdef SI_UTSI_ENHANCE
   /* Schubert.Zhang modify it, to get DPC status from MTP3
   */
   if(!siPortFlagReqDpcSta)
   {
#endif /* SI_UTSI_ENHANCE */
   SiUiSitPtCdeStaCfm(&tCb->pst, tCb->suId, intfId, status, congLevel);
#ifdef SI_UTSI_ENHANCE
   }
   else
   {
     SiNSAPCb *nCb;
     nCb = SIMTPSAP(intfCb->msapId);
     if((NULLP == nCb) || (nCb->state != SI_BND))
       RETVALUE(RFAILED);
     SiLiSntStaReq(&nCb->pst, nCb->spId, intfCb->cfg.phyDpc); 
   }   
#endif /* SI_UTSI_ENHANCE */
   RETVALUE(ROK);
} /* SiUiSitPtCdeStaReq */



/********************************************
 *     interface functions to service provider
 ********************************************/

#ifdef SNT2

/*
*
*       Fun:   SiLiSntBndCfm
*
*       Desc:  Function to process bind confirmation from MTP-3
*              
*       Ret:   ROK - ok
*
*       Notes: none
*
*       File:  ci_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SiLiSntBndCfm 
(
Pst  *pst,
SuId suId,
U8   status
)
#else
PUBLIC S16 SiLiSntBndCfm (pst, suId, status)
Pst  *pst;
SuId suId;
U8   status;
#endif
{
   SiNSAPCb *nCb;

   TRC2(SiLiSntBndCfm)
   UNUSED(pst);

   SIDBGP(DBGMASK_LI, (siCb.init.prntBuf, 
                      "%s\n\nBndCfm : L3 -> L4      SNT intf\n", SI_STR)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI057, (ErrVal) ziCb.protState,
                 "SiUiSptBndCfm() failed, ISUP is not active\n");
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_LI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */
  
   if ((suId < (SuId) 0) || (suId >= (SuId) siCb.genCfg.nmbNSaps) ||
       ((nCb = SIMTPSAP(suId)) == NULLP)) 
   {
      SIDBGP(DBGMASK_LI, (siCb.init.prntBuf, 
                         "SntBndCfm(): MTP SAP is unavailable, (suId = %x)", 
                         suId)); 
#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI058, (ErrVal) suId,
                 "SiLiSntBndCfm(), NSAP not configured");
#endif
      siInitUstaDgn(LSI_USTA_DGNVAL_SUID, (PTR) &suId, 
                    LSI_USTA_DGNVAL_NONE, (PTR) NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_LI_INV_EVT, LSI_CAUSE_INV_MSAP, TRUE, 
                     suId, SIMSAP_INV);
      RETVALUE(RFAILED);
   }

   if (nCb->state != SI_WT_BNDCFM)
      RETVALUE(ROK);

   siStopNSAPTmr(nCb, TMR_TINT);
   nCb->bndRetryCnt = 0;

   if (status == CM_BND_NOK)
   {
      nCb->state       = SI_UNBND;
      siInitUstaDgn(LSI_USTA_DGNVAL_SUID, (PTR) &suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_BND_FAIL, LCM_EVENT_BND_FAIL, TRUE, 
                     suId, SI_ALRM_NSAP_NOTBOUND);
      RETVALUE(ROK);
   }

   nCb->state = SI_BND;

#ifdef ZI
   ziRunTimeUpd(ZI_MTP3SAP_CB, CMPFTHA_UPD_REQ, (PTR) nCb);
   ziUpdPeer();
#endif /* ZI */

   RETVALUE(ROK);
}/* SiLiSntBndCfm */


/*
*
*       Fun:   SiLISntStaCfm
*
*       Desc:  Receive DPC status confirmation from MTP-3
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SiLiSntStaCfm 
(
Pst *pst,                       /* post structure */
SuId suId,                      /* service user id */
Dpc  phyDpc,                    /* destination point code */
Status status,                  /* mtp-3 status */
U8 congLevel                    /* congestion level */
)
#else
PUBLIC S16 SiLiSntStaCfm (pst, suId, phyDpc, status, congLevel)
Pst *pst;                       /* post structure */
SuId suId;                      /* service user id */
Dpc phyDpc;                     /* affected point code */
Status status;                  /* mtp-3 status */
U8 congLevel;                   /* congestion level */
#endif
{
   SiIntfCb   *siIntfCb;
   SiNSAPCb  *nCb;
   SiUpSAPCb *tCb;

   TRC2(SiLiSntStaCfm)
   UNUSED(pst);

   SIDBGP(DBGMASK_LI, (siCb.init.prntBuf, 
      "SiLiSntSntStaCfm():(suId = %#x, pc = %#lx, status = %#x, cong = %#x)", 
       suId, phyDpc, status, congLevel));

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI059, (ErrVal) 0,
                 "SiLiSntStaCfm() Failed, received by standby ISUP");
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_LI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif

   if ((nCb = SIMTPSAP(suId)) == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI060, (ErrVal) suId,
                 "SiLiSntStaCfm() Failed, NSAP not found");
#endif
      RETVALUE(RFAILED);
   }

   /* find the first intf control block */
   if (siFindIntf(&siIntfCb, 0, phyDpc, nCb->cfg.nwId, nCb->cfg.ssf, 0,
                        SIINTF_KEY_3) != ROK)
   {  
      SIDBGP(SIDBGMASK_CERR,
             (siCb.init.prntBuf, 
              "intf (%#lx) control block unavailable\n", phyDpc));  
      RETVALUE(RFAILED);
   }     

   if (NULLP == (tCb = SIUPSAP(siIntfCb->cfg.sapId)))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI061, (ErrVal) siIntfCb->cfg.swtch,
                 "SiLiSntStaCfm() Failed, SAP not found");
#endif
      RETVALUE(RFAILED);
   }

   /* now process dpc status for all intf with different OPC */
   do
   {
      /* now check if swtch, NT and phyDpc are matching */
      if ((siIntfCb->cfg.nwId == nCb->cfg.nwId) &&
          (SICMPNT(siIntfCb->cfg.ssf, nCb->cfg.ssf)) &&
          (siIntfCb->cfg.phyDpc == phyDpc))
      {
         siProcIntfStatus(nCb, tCb, siIntfCb, status, congLevel);
#ifdef ZI
         ziRunTimeUpd(ZI_INTF_CB, CMPFTHA_UPD_REQ, (PTR) siIntfCb);
         ziUpdPeer();
#endif
      }
   } while(cmHashListGetNext(&siCb.intfHlCp.k3Cp, (PTR) siIntfCb,
                             (PTR *) &siIntfCb) == ROK);
   RETVALUE(ROK);

}/* SiLiSntStaCfm */

#endif /* SNT2 */


/*
*
*      Fun:   Unit Data Indication
*
*      Desc:  This function provides for an exchange of user
*             data units.
*   
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiLiSntUDatInd
(
Pst     *pst,               /* bind configuration */
SuId    suId,               /* service user id */
Dpc     cgAdr,              /* originating point code */
Dpc     cdAdr,              /* destination point code */
SrvInfo srvInfo,            /* service information octet */
LnkSel  lnkSel,             /* signalling link selection */
Buffer  *mBuf               /* pointer to the data buffer */
)
#else
PUBLIC S16 SiLiSntUDatInd(pst, suId, cgAdr, cdAdr, srvInfo, lnkSel, mBuf)
Pst     *pst;               /* bind configuration */
SuId    suId;               /* service user id */
Dpc     cgAdr;              /* originating point code */
Dpc     cdAdr;              /* destination point code */
SrvInfo srvInfo;            /* service information octet */
LnkSel  lnkSel;             /* signalling link selection */
Buffer  *mBuf;              /* pointer to the data buffer */
#endif
{
   SiNSAPCb   *nCb;
   MsgLen        bufLen;
   SiPduHdr   hdr;
   Data       tmpBuf[CIC_LEN];
   Cic        cicVal;
   S16        ret;
   SiAllPdus  message;
   SiCirCb    *siCir;
   SiCauseDgn causeDgn;
   SiCon      *siCon;
   SiCirKey   key;
   Bool       dest;
   U8         i;
#if (SS7_ETSI || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   U8         byte1;
   U8         byte2;
#endif
   U8         msgIdx;
   Buffer     *tempBuf;
   SiIntfCb    *siIntfCb;
   Bool       RelCall;
   S16        ret1;
   U8         tmrNum;
   Bool       invRelRcvd;
   SiAllSdus  ev;
   SiUpSAPCb *tCb;

   TRC3(SiLiSntUDatInd)
   UNUSED(pst);
   UNUSED(srvInfo);

   SIDBGP(DBGMASK_LI, (siCb.init.prntBuf, "%s\n\nUDatInd : L3 -> L4      \n",
                       SI_STR)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n"));
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI062, (ErrVal) ziCb.protState,
                 "SiUiSntUDatInd() failed, ISUP is not active\n");
#endif
      siDropMsg(mBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: set the initialized flag to TRUE */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_LI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   invRelRcvd = FALSE;
   /* get mtp control block */
   if (((nCb = SIMTPSAP(suId)) == NULLP) || (nCb->state != SI_BND))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         (nCb)?"For suId 0x%x state 0x%x not bound\n":
            "For suId 0x%x control block does not exist \n",
               suId, (nCb)?nCb->state:0));


#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI063, (ErrVal) suId, 
                 "SiLiSntUDatInd() Failed, invalid suId");
#endif
      siInitUstaDgn(LSI_USTA_DGNVAL_SUID, (PTR) &suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_LI_INV_EVT, LSI_CAUSE_INV_MSAP, TRUE, 
                     (CirId)suId, SIMSAP_INV);
      siDropMsg(mBuf);
      RETVALUE(ROK);
   }

/* si039.220 - Debug flag changed from DBG4 to DBG5 as DBG4 should be used for error
               cases in mf and not in Tx & Rx
*/
#ifdef DBG5
   /* print received message */
   if (siCb.init.dbgMask & SIDBGMASK_MSGRX)
   {
       SPrntMsg(mBuf, (S16) cgAdr, (S16) cdAdr);
   }
#endif
   /* Do trace if need before checking the interface block */
   /* do trace if needed */
   if (nCb->trc)
      siTrcBuf(cgAdr, NULLP, TL5MSGRX, SAP_MTP, mBuf);

   siProcIncSegm = FALSE;

   ret = SFndLenMsg(mBuf, &bufLen);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "error in finding length of the message \n"));
      SILOGERROR(ERRCLS_DEBUG, ESI064, (ErrVal) suId, 
                 "SFndLenMsg() Failed, SiLiSntUDatInd");
      siDropMsg(mBuf);
      RETVALUE(ROK);
   }
#endif

   /* if under minimum isup message len from mtp3, drop */
   if (bufLen < 3)
   {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Length of the message too less %d\n", bufLen)); 
       siDropMsg(mBuf);
       RETVALUE(ROK);
   }

   /* extract cic from the message */
   ret = SRemPreMsgMult(tmpBuf, (MsgLen) CIC_LEN, mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "error in extracting cic from the message\n")); 
      SILOGERROR(ERRCLS_DEBUG, ESI065, (ErrVal) suId, 
                 "SRemPreMsgMult() Failed, SiLiSntUDatInd");
      siDropMsg(mBuf);
      RETVALUE(ROK);
   }
#endif

   cicVal = 0;
   cicVal = PutHiByte(cicVal, tmpBuf[1]);
   cicVal = PutLoByte(cicVal, tmpBuf[0]);

   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));

   /* Get the interface block from the phyDpc, opc, NT, swtch */
   siCir = NULLP;
   if (siFindIntf(&siIntfCb, 0, cgAdr, nCb->cfg.nwId, nCb->cfg.ssf,
                        cdAdr, SIINTF_KEY_2) == ROK)
   {
      /* fill the cic and interface id */
      key.k2.cic = cicVal;
      key.k2.intfId = siIntfCb->cfg.intfId;
      siFindCir(&siCb.cirHlCp, &siCir, &key, 0, KEY_CICINTF);
   } 
   else
   {
      /* the intf block could not be found. Should handle this
       * as circuit not equipped, however the swtch info is not
       * available and could not sent out UCIC. We have to return.
       */

      /* Generate Alarm to Layer management */
/* si007.220 - Modification. Modified code in order to send correct alarm with
 * dpc (not interface Id) when the interface could not be found.
 */
      siInitUstaDgn(LSI_USTA_DGNVAL_DPC, (PTR) &cgAdr,
                    LSI_USTA_DGNVAL_SUID, (PTR) &suId,
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE,
                     LCM_EVENT_LI_INV_EVT, LSI_CAUSE_INV_INTF,
                     TRUE, 0, SI_ALRM_INTF_NOTCFGD);
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
       "Error searching INTF for phyDpc:%ld opc:%ld ssf:%d\n",
               cgAdr, cdAdr, nCb->cfg.ssf)); 
      /* si012.220, ADDITION: Added following lines to drop mBuf 
                              and return RFAILED */
      siDropMsg(mBuf);
      RETVALUE(RFAILED);

   }
/* si052.220 : Modification - Moved section up. UPU Interface state changes. 
               While processing UCIC msg, intf state made available and 
               stop T4 timer
*/

   /* On receipt of User part available or any other message, timer T4 is
    * stopped and user part (DPC) is marked available again and traffic is
    * restarted.
   */
   if (siIntfCb->state == SI_INTF_UNAVAIL)
   {
      SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "Dpc state was unavailable. making available\n"));
/* si003.220 - Modification. Status Indication should be SIMTP_RMTUSRAV when
 * t4Runing is TRUE, and it should be SIMTP_RESUME when t4Runing is FALSE.
 * Also added code to retrieve Upper SAP control block before referencing it
 * to avoid possible core dump.
 */
#if SIT_PARAMETER
      if( NULLP == (tCb = SIUPSAP(siIntfCb->cfg.sapId)) )
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI071, (ErrVal) siIntfCb->cfg.swtch,
                    "SiLiSntStaCfm() Failed, SAP not found");
#endif
         RETVALUE(RFAILED);
      }
      /* generate status indication to call control */
      MFINITSDU(&tCb->mfMsgCtl, ret, (U8) 0, (U8) SI_STAREQ,
                (ElmtHdr *) NULLP, (ElmtHdr *) &ev, (U8) NOTPRSNT,
                siIntfCb->cfg.swtch, (U32) MF_ISUP);
#endif /* SIT_PARAMETER */
      if (siIntfCb->t4Runing)
      {
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "t4 was running . stopping it.\n"));
         siStopIntfTmr(siIntfCb, TMR_T4);
         siIntfCb->t4Runing = FALSE;
         siIntfCb->state = SI_INTF_AVAIL;

         /* si009.220, ADDED: for itu97 or etsi version 3, should stop the
          * pause timer and restart the call release procedure
          */
/* si029.220: Modification - added INDIA switch */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
         if ((siIntfCb->cfg.swtch == LSI_SW_ITU97) ||
             (siIntfCb->cfg.swtch == LSI_SW_RUSS2000) ||
             (siIntfCb->cfg.swtch == LSI_SW_ITU2000) ||
             (siIntfCb->cfg.swtch == LSI_SW_ETSIV3) ||
             (siIntfCb->cfg.swtch == LSI_SW_INDIA))
         {
            siStopIntfTmr(siIntfCb, TMR_PAUSE);
            siProcResumeCir(nCb, tCb, siIntfCb);
         }
#endif

         
#if SIT_PARAMETER
/*Addition - add a judgement to avoid the siCir be used when it is NUllP*/
/*lixinxin 2006/09/28*/
        {
             SiCirCb *siCir2 = NULLP;
             
             if (siCir == NULLP)
             {
                 key.k3.intfId = siIntfCb->cfg.intfId;
                 siFindCir(&siCb.cirHlCp, &siCir2, &key, 0, KEY_INTF);
             }
             else
             {
                 siCir2 = siCir;
             }

             if (siCir2 != NULLP)
             {
                 SiUiSitStaInd(&tCb->pst, tCb->suId, 0, 0, siCir2->cfg.cirId,
                               FALSE, SIT_STA_USRPARTA, &ev.m.siStaEvnt, NULLP);
             }
         }
/*-------------------------------------------------------------------*/
#endif /* SIT_PARAMETER */
      }
#if SIT_PARAMETER
      else
      {
/*Addition - add a judgement to avoid the siCir be used when it is NUllP*/
/*lixinxin 2006/09/28*/
         SiCirCb *siCir2 = NULLP;
         
         if (siCir == NULLP)
         {
             key.k3.intfId = siIntfCb->cfg.intfId;
             siFindCir(&siCb.cirHlCp, &siCir2, &key, 0, KEY_INTF);
         }
         else
         {
             siCir2 = siCir;
         }
               
         if (siCir2 != NULLP)
         {
             SiUiSitStaInd(&tCb->pst, tCb->suId, 0, 0, siCir2->cfg.cirId,
                           FALSE, SIT_STA_RESUMEIND, &ev.m.siStaEvnt, NULLP);
         }
/*-------------------------------------------------------------------*/
      }
#endif /* SIT_PARAMETER */
      siInitUstaDgn(LSI_USTA_DGNVAL_INTF, (PTR) &siIntfCb->cfg.intfId,
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP);

      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE,
                     LSI_EVENT_USERPART, LSI_CAUSE_AVAILABLE,
                     TRUE, (SiInstId) siIntfCb->cfg.intfId, SIMTP_RESUME);
   }

   /* decode message header */
   MFDECPDUHDR(&nCb->mfMsgCtl, ret, mBuf, (ElmtHdr *) &hdr, 
               &siPduHdrMsgDef[0], TRUE, TRUE, siIntfCb->cfg.swtch, 
               (U32) MF_ISUP);
   SIDBGP(DBGMASK_LI, (siCb.init.prntBuf, "MsgIdx:%d 0x%x\n",
             nCb->mfMsgCtl.msgIdx, nCb->mfMsgCtl.msgIdx)); 

   if (siCir == NULLP)
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "message rcvd at unequipped cic %d dpc %ld\n",
                        cicVal, cgAdr)); 
      /* generates an alarm - invalid CIC value - indicating the DPC */
/* si053.220: Modification - changed LSI_USTA_DGNVAL_INTF to LSI_USTA_DGNVAL_DPCfor &cgAdr */  
      siInitUstaDgn(LSI_USTA_DGNVAL_CIC, (PTR) &cicVal,
                    LSI_USTA_DGNVAL_DPC, (PTR) &cgAdr, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_LI_INV_EVT, LSI_CAUSE_INV_CIRCUIT, TRUE, 
                     (CirId) cicVal, SI_ALRM_CIR_UNEQUPD);
      {
          if ((hdr.msgType.pres) && ((nCb->mfMsgCtl.msgIdx == MI_UNEQUIPCIC) 
              || (nCb->mfMsgCtl.msgIdx == MI_CONFUSION)))
          {
             SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                          "UNEQUIPCIC/COF received on unequipped cic\n"));  
             siDropMsg(mBuf);
             RETVALUE(ROK);
          }
      }
 
      /* handle CQM on unequipped CIC */
      if ((ret == ROK) && /* header decoding OKay */
          (nCb->mfMsgCtl.msgIdx == MI_CIRGRPQRY))
      {
         /* increment the statistics */
#if (SI_LMINT3 || SMSI_LMINT3)
         if (siIntfCb != NULLP)
         {
            siUpdIntfSts(siIntfCb->cfg.intfId, LSI_STS_RX,
                         nCb->mfMsgCtl.msgType);
         }
#else
         siUpdNSAPRxSts(nCb, nCb->mfMsgCtl.msgType);
#endif
         siHndlCQMonUneqCIC(nCb, cgAdr, cdAdr, cicVal, &message);
         siDropMsg(mBuf);
         if (nCb->mfMsgCtl.uBuf != NULLP)
         {
            siDropMsg(nCb->mfMsgCtl.uBuf);
            nCb->mfMsgCtl.uBuf = NULLP; 
         }
          RETVALUE(ROK);
      }

      switch (siIntfCb->cfg.swtch)
      {






#if SS7_ITU97
         case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
         case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
         case LSI_SW_RUSS2000:
#endif
         case LSI_SW_ITU  :
            switch (nCb->mfMsgCtl.msgIdx)
            {
               /* IAM */
               case MI_INIADDR       :
 
               /* continuity check request */
               case MI_CONTCHKREQ    :
 
               /* circuit group supervision message */
               case MI_CIRGRPQRY     :
               case MI_CIRGRPQRYRES  :
               case MI_CIRGRPBLK     :
               case MI_CIRGRPBLKACK  :
               case MI_CIRGRPUBLK    :
               case MI_CIRGRPUBLKACK :
               case MI_CIRGRPRES     :
               case MI_CIRGRPRESACK  :
                  
                  /* circuit supervision message */
               case MI_BLOCK         :
               case MI_BLOCKACK      :
               case MI_UNBLK         :
               case MI_UNBLKACK      :
               case MI_RESCIR        :
                  /* Code to call siGenCirMsg function with the interface valid
                   * flag as TRUE when generating a UCIC message
                   */
                  /* si009.220, MODIFIED: provide the valid interface ID */
                  siGenCirMsg(cicVal, cdAdr, siIntfCb->cfg.intfId, cgAdr, TRUE, 
                              siIntfCb->cfg.swtch, M_UNEQUIPCIC, MI_UNEQUIPCIC, 
                              NULLP, nCb->cfg.ssf, nCb->cfg.nwId);
                  siDropMsg(mBuf);
                  RETVALUE(ROK);
               default: 
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                  "Default message recvd at unequipped cic ...dumped\n")); 
#if (ERRCLASS & ERRCLS_DEBUG)
                  SILOGERROR(ERRCLS_DEBUG, ESI066, (ErrVal) suId, 
                         "SiLiSntUDatInd() Failed: invalid msg on uneq. cic");
#endif
                  siDropMsg(mBuf);
                  RETVALUE(ROK);
            }

/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added China variant */	 
#if SS7_CHINA
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
#if (SS7_Q767 || SS7_RUSSIA || SS7_NTT || SS7_INDIA || SS7_CHINA)
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "Message at unequipped cic is dumped\n")); 
            siDropMsg(mBuf);
            RETVALUE(ROK);
#endif
#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "swtch %d is invalid for handling uneq. cic\n",
                        siIntfCb->cfg.swtch )); 
            SILOGERROR(ERRCLS_DEBUG, ESI067, (ErrVal) suId, 
                 "SiLiSntUDatInd Failed, siIntfCb->cfg.swtch invalid");
            siDropMsg(mBuf);
            RETVALUE(ROK);
#endif
      }
   }
#if SI_RESET_RMTUNEQSTATE
   switch (nCb->mfMsgCtl.msgIdx)
   {
      /* On receiving messages CVT, CVR, CQM, CQR and UCIC,
       * the remotely unequipped circuit states will not be
       * affected, fall through to break.
       */
      case MI_CIRVALTEST     :
      case MI_CIRVALRSP      :
      case MI_CIRGRPQRY      :
      case MI_CIRGRPQRYRES   :
      case MI_UNEQUIPCIC     :
/* si034.220 : Modification - Drop as Unequip CIC Msg for CHINA */
#ifdef SS7_CHINA
      if ((siIntfCb->cfg.swtch == LSI_SW_CHINA) && 
	       (nCb->mfMsgCtl.msgIdx == MI_UNEQUIPCIC))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Unequip CIC! dumping msg\n")); 
         siDropMsg(mBuf);
         RETVALUE(ROK);
      }
#endif
         break;
      /* On receiving any other messages, the remotely unequipped
       * circuit states will be removed if any.
       */
      default:
         if( (siCir->transStat[SICIR_MTREMST] == SICIR_ST_UNEQPD  ) ||
             (siCir->transStat[SICIR_HWREMST] == SICIR_ST_UNEQPD  )
           )
         {
            siCir->transStat[SICIR_MTREMST] = SICIR_ST_IDLE;
            siCir->transStat[SICIR_HWREMST] = SICIR_ST_IDLE;

            /* Generate Alarm to Layer management */
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &siCir->cfg.cic,
                          LSI_USTA_DGNVAL_NONE, NULLP,
                          LSI_USTA_DGNVAL_NONE, NULLP,
                          LSI_USTA_DGNVAL_NONE, NULLP);
            siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE,
                          LCM_EVENT_LI_INV_EVT, LSI_CAUSE_INV_EVNT, FALSE);
         }
         break;
   }
#endif

   /* decode message header error */
   if (ret != ROK)
   {
#if (SI_LMINT3 || SMSI_LMINT3)
      siUpdErrSts(siCir, LSI_STS_PDUFMTERR);
#endif
      if (ret == MFRESFAILURE)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "error in decoding msg header MFRESFAILURE\n")); 
#if (ERRCLASS & ERRCLS_ADD_RES)
         SILOGERROR(ERRCLS_ADD_RES, ESI068, (ErrVal) suId, 
                 "SiLiSntUDatInd Failed, resource failure in decoding header");
#endif
         siDropMsg(mBuf);
         RETVALUE(ROK);
      }
      if (ret == MFDEBUGERR)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "error in decoding msg header MFDEBUGGER  \n")); 
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI069, (ErrVal) suId, 
                 "SiLiSntUDatInd Failed, sofware error in decoding header");
#endif
         siDropMsg(mBuf);
         RETVALUE(ROK);
      }

      /* message header decode error */
#ifdef DBG4
      siMfPrntErr(&nCb->mfMsgCtl);
#endif
      /* initialize cause/diagnostic element */
      MFINITELMT(&nCb->mfMsgCtl, ret, NULLP, (ElmtHdr *) &causeDgn, 
                &meCauseIndV, (U8) PRSNT_DEF, siIntfCb->cfg.swtch, 
                (U32) MF_ISUP);
      causeDgn.recommend.pres = NOTPRSNT;

      siErrMapFunc(&nCb->mfMsgCtl, &causeDgn);
      causeDgn.dgnVal.len = 1;
      {
         U8    msgType;

         if (SExamMsg(&msgType, mBuf, 0) != ROK )
         {
            causeDgn.dgnVal.pres = NOTPRSNT;
         }
         else
            causeDgn.dgnVal.val[0] = msgType;
      }

      /* set the cause value: message type non-existent or not implemented */
      causeDgn.causeVal.val = SIT_CCNOMSGTYP;
      switch (siIntfCb->cfg.swtch)
      {
#if SS7_ITU97
         case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
         case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
         case LSI_SW_RUSS2000:
#endif
/* si034.220: Addition - added China variant */	 
#if SS7_CHINA
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
#endif
         case  LSI_SW_ITU:
            /* si034.220: Addition - added CHINA switch */
            /* si029.220: Addition - added INDIA switch */
            if ((siIntfCb->cfg.swtch == LSI_SW_ITU) || 
               (siIntfCb->cfg.swtch == LSI_SW_ETSI) || 
               (siIntfCb->cfg.swtch == LSI_SW_ETSIV3) || 
               (siIntfCb->cfg.swtch == LSI_SW_ITU97) || 
               (siIntfCb->cfg.swtch == LSI_SW_ITU2000) || 
               (siIntfCb->cfg.swtch == LSI_SW_RUSS2000) || 
               (siIntfCb->cfg.swtch == LSI_SW_FTZ) ||
               (siIntfCb->cfg.swtch == LSI_SW_INDIA)|| 
               (siIntfCb->cfg.swtch == LSI_SW_CHINA)) 
            {
               ret = siChkMsgComp(nCb, siCir, mBuf, cgAdr, cicVal, &causeDgn);
               switch (ret)
               {
                  case ROK:
                     break;
                  case MC_DROPMSG:
                     SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                        "MsgComp returns DROPMSG\n")); 
                     siDropMsg(mBuf);
                     RETVALUE(ROK);
                  default:
                     break;
               }
               break;
            }
#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
               "swtch %d is invalid \n", siIntfCb->cfg.swtch )); 
     
            SILOGERROR(ERRCLS_DEBUG, ESI070, (ErrVal) suId, 
                 "SiLiSntUDatInd Failed, siIntfCb->cfg.swtch invalid");
            siDropMsg(mBuf);
            RETVALUE(ROK);
#endif
       }
   }

   /* increment receive counters after header decoding is performed OK */
#if (SI_LMINT3 || SMSI_LMINT3)
   if (siIntfCb != NULLP)
      siUpdIntfSts(siIntfCb->cfg.intfId, LSI_STS_RX, nCb->mfMsgCtl.msgType);
#else
   siUpdNSAPRxSts(nCb, nCb->mfMsgCtl.msgType);
   siUpdCirRxSts(siCir, nCb->mfMsgCtl.msgType);
#endif

   siCon = siCir->siCon;
   switch (nCb->mfMsgCtl.msgIdx)
   {
      case MI_BLOCK:
      case MI_BLOCKACK:
      case MI_UNBLK:
      case MI_UNBLKACK:
      case MI_RESCIR:
      case MI_UNEQUIPCIC:
/* si034.220 : Modification - Drop as Unequip CIC Msg for CHINA */
#ifdef SS7_CHINA
      if ((siIntfCb->cfg.swtch == LSI_SW_CHINA) && 
	       (nCb->mfMsgCtl.msgIdx == MI_UNEQUIPCIC))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Unequip CIC! dumping msg\n")); 
         siDropMsg(mBuf);
         RETVALUE(ROK);
      }
#endif
      case MI_CIRGRPQRY:
      case MI_CIRGRPQRYRES:
      case MI_CIRGRPBLK:
      case MI_CIRGRPBLKACK:
      case MI_CIRGRPUBLK:
      case MI_CIRGRPUBLKACK:
      case MI_CIRGRPRES:
      case MI_CIRGRPRESACK:
      case MI_USRPARTA:
      case MI_USRPARTT:
      case MI_CIRVALRSP:
      case MI_CIRVALTEST:
      case MI_EXIT:
/* si029.220: Addition - added INDIA flag */
#if (SS7_SINGTEL || SS7_RUSSIA || SS7_INDIA)
      case MI_CHARGE:
#endif
         break;
      case MI_RELCOMP:
         /* now this is a response to Reset Req. we don't need a conn block
          * otherwise fall through 
          */
         if ((siCir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK) ||
             (siCir->transStat[SICIR_HWLOCST] == SICIR_ST_WTRESACK))
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                "Waiting for reset ack therefore con block not req\n")); 
            break;
         }
         else
         {
            /* stop the reset message related timers. The following scenario will
             * cause the reset timer T16 and T17 are still running even when the
             * circuit are in idle state. 
             * 1) ISUP sent reset on the circuit, the timer T16 and T17 are 
             *    started
             * 2) ISUP sent a GRS which includes the circuit has previousely 
             *    sent reset message
             * 3) ISUP received GRA corresponding to GRS, all the affected 
             *    circuits are set to Idle. However the timer T16 and T17 are 
             *    not stopped
             * 4) When the RLC is received corresponding to the reset message,
             *    ISUP will not process this RLC as the acknowledge of reset 
             *    message because the state of circuit is already set to Idle
             */
              
            if ((siCir->transStat[SICIR_MTLOCST] == SICIR_ST_IDLE) ||
                (siCir->transStat[SICIR_HWLOCST] == SICIR_ST_IDLE))
            {
               if (siIsTmrRunning(siCir->timers, MAXSIMTIMER, TMR_T16) == ROK)
               {
                  /* stop reset timer */
                  siStopCirTmr(siCir, TMR_T16);
               }
               if (siIsTmrRunning(siCir->timers, MAXSIMTIMER, TMR_T17) == ROK)
               {
                  /* stop reset timer */
                  siStopCirTmr(siCir, TMR_T17);
               }
            }
         }

      default:
         if (siCon == NULLP)
         {                      
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
            /* and this is not a non-single rate call, allocate a conn. Cb */
            if (siCir->ctrlMultiRateCir == NULLP)              
#endif
            {
               siCon = siGetIncCon(siCir, nCb);
               if (siCon == NULLP)
               {
                  SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                         "Can not allocate a connection block\n")); 

                  siDropMsg(mBuf);
                  RETVALUE(ROK);
               }
               /* si025.220 - Modified: changed arguments in siGetLnkSel */
               /* si009.220 - Modified: to pass cic into siGetLnkSel. */
               siGetLnkSel(nCb, &siCon->lnkSel, siIntfCb->cfg.swtch, siCir);
            }
         }   

         {
            /* If exchange is subject to load control (i.e., timer T3 is 
             * running), drop all call control messages. */
            for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
            if (siCir->timers[tmrNum].tmrEvnt == TMR_T3)
            {
               SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                         "TMRT3 was running\n")); 
               siDropMsg(mBuf);
               RETVALUE(ROK);
            }
         }

   } /* end switch...*/
/*si052.220: Deletion - Moved the section up */

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate call */
   if (siCir->ctrlMultiRateCir != NULLP)
   {
      /* this is a non-single rate call. Check if the message received on the
       * non-controlling ckts. 
       */
      ret = siChkMRateCtrlCkts(siCir, &message, nCb->mfMsgCtl.msgIdx);
      if (ret != ROK)
      {
          SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
           "received a message on non-contrl cic for a \
            non-single rate call.\n")); 
#if (ERRCLASS & ERRCLS_DEBUG)
          SILOGERROR(ERRCLS_DEBUG, ESI072, (ErrVal) suId, 
            "SiLiSntUDatInd, received call realted message on non-ctrl cic");
#endif
          siDropMsg(mBuf);
          RETVALUE(ROK);
      }
      
      /* check if this circuit is allocated a conn cb. If yes, update the 
       * siCon. This is because of the dual seizure happened, however we 
       * processs it during the connection state matrix function. We have to 
       * allocate one conn to this circuit
       */
      if (siCir->siCon != NULLP)
         siCon = siCir->siCon;

   }   
#endif

   /* move this assignment of xchgType after checking for intfCb and
    * non-single rate call
    */ 
   /* if there is a connection, then update the switch type in
    * the message control block to the connection switch type
   */
   if (siCon != NULLP)
   {
      siCon->mCallCb->mfMsgCtl.xchgType = siCon->xchgType;
   }

   /* if received message is Passalong */
   if (nCb->mfMsgCtl.msgIdx == MI_PASSALNG)
   {
/* si034.220 : Modification - Drop as Pass along not applicable in CHINA */	   
#if (SS7_Q767 || SS7_RUSSIA || SS7_NTT || SS7_CHINA)
      if ((siIntfCb->cfg.swtch == LSI_SW_Q767) || 
          (siIntfCb->cfg.swtch == LSI_SW_RUSSIA) || 
          (siIntfCb->cfg.swtch == LSI_SW_NTT) ||
          (siIntfCb->cfg.swtch == LSI_SW_CHINA))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Passalong ! dumping msg\n")); 
         siDropMsg(mBuf);
         RETVALUE(ROK);
      }
#endif
      /* if out of sequience message, ignore it */
      if (!siCon)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no associated connection block . Dumping\n")); 
         siDropMsg(mBuf);
         RETVALUE(ROK);
      }
      /* if not final destination */
      if ((dest = siChkPslgDst(siCir)) == FALSE)
      {
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
            "For passalong message it is not final destination\n")); 
         /* si013.220, Modificaiton: Added to code to drop mBuf if the pass-
                                     along message was not generated */
         ret = siGenPslg(siCir, siCir->siCon, mBuf);
         if (ret != ROK)
            siDropMsg(mBuf);
         RETVALUE(ret);
      }

      /* remove passalong message type */
      SRemPreMsg(&i, mBuf);
      
      /* decode message header */
      MFDECPDUHDR(&nCb->mfMsgCtl, ret, mBuf, (ElmtHdr *) &hdr, 
                  &siPduHdrMsgDef[0], TRUE, TRUE, siIntfCb->cfg.swtch, 
                  (U32) MF_ISUP);
      if (ret != ROK)
      {
         if (ret == MFRESFAILURE)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "error in decoding msg header MFRESFAILURE\n")); 
#if (ERRCLASS & ERRCLS_ADD_RES)
            SILOGERROR(ERRCLS_ADD_RES, ESI073, (ErrVal) suId, 
                 "SiLiSntUDatInd Failed, resource failure in decoding header");
#endif
            siDropMsg(mBuf);
            RETVALUE(ROK);
         }
         if (ret == MFDEBUGERR)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "error in decoding msg header MFDEBUGGER  \n")); 
#if (ERRCLASS & ERRCLS_DEBUG)
            SILOGERROR(ERRCLS_DEBUG, ESI074, (ErrVal) suId, 
                 "SiLiSntUDatInd Failed, sofware error in decoding header");
#endif
            siDropMsg(mBuf);
            RETVALUE(ROK);
         }
         /* message header decode error */
#ifdef DBG4
         siMfPrntErr(&nCb->mfMsgCtl);
#endif
         /* initialize cause/diagnostic element */
         MFINITELMT(&nCb->mfMsgCtl, ret, NULLP, (ElmtHdr *) &causeDgn, 
                    &meCauseIndV, (U8) PRSNT_DEF, siIntfCb->cfg.swtch, 
                    (U32) MF_ISUP);

         causeDgn.recommend.pres = NOTPRSNT;
         siErrMapFunc(&nCb->mfMsgCtl, &causeDgn);
         switch (siIntfCb->cfg.swtch)
         {
#if SS7_ITU97
            case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
         case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
         case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
            case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added China variant */	 
#if SS7_CHINA
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
            case  LSI_SW_ITU:

               /* si034.220: Addition - added CHINA switch */
               /* si029.220: Addition - added INDIA switch */
               if ((siIntfCb->cfg.swtch == LSI_SW_ITU) || 
                  (siIntfCb->cfg.swtch == LSI_SW_ETSI) || 
                  (siIntfCb->cfg.swtch == LSI_SW_ETSIV3) || 
                  (siIntfCb->cfg.swtch == LSI_SW_ITU2000) || 
                  (siIntfCb->cfg.swtch == LSI_SW_RUSS2000) || 
                  (siIntfCb->cfg.swtch == LSI_SW_ITU97) || 
                  (siIntfCb->cfg.swtch == LSI_SW_FTZ) ||
                  (siIntfCb->cfg.swtch == LSI_SW_INDIA) || 
                  (siIntfCb->cfg.swtch == LSI_SW_CHINA)) 
               {
                  ret = siChkMsgComp(nCb, siCir, mBuf, cgAdr, cicVal, 
                                     &causeDgn);
                  switch (ret)
                  {
                     case ROK:
                        break;
                     case MC_DROPMSG:
                        SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                           "MsgComp returns DROPMSG\n")); 
                        siDropMsg(mBuf);
                        RETVALUE(ROK);
                     default:
                        break;
                  }
                  break;
               }

#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
               "swtch %d is invalid \n", siIntfCb->cfg.swtch )); 
            SILOGERROR(ERRCLS_DEBUG, ESI075, (ErrVal) suId, 
                 "SiLiSntUDatInd Failed, siIntfCb->cfg.swtch invalid");
            siDropMsg(mBuf);
            RETVALUE(ROK);
#endif
         }
      }
   }

   /* check if the message is expected in this state of the call */
   if (siChkifMsgExp(siCir->cfg.cirId, siCon, nCb->mfMsgCtl.msgIdx) == TRUE)
   {
      SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "As per state matrix MsgIdx %d is expected\n",
                           nCb->mfMsgCtl.msgIdx)); 
      /* decode message */
      MFDECPDU(&nCb->mfMsgCtl, ret1, (ElmtHdr *) &message);
      /* Only compare against ROK when returned from decoding */
      if (ret1 != ROK)
      {
         if( ret1 == MFUNXENDOFMSG ) /* if message is terminated 
                     unexpectedly */
         {
            siDropMsg(mBuf);
            if (nCb->mfMsgCtl.uBuf != NULLP)
            {
               siDropMsg(nCb->mfMsgCtl.uBuf);
               nCb->mfMsgCtl.uBuf = NULLP;
            }
            RETVALUE(ROK);
         }
         if (ret1 == MFRESFAILURE)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Resfailure error in message decoding\n"));  
#if (ERRCLASS & ERRCLS_ADD_RES)
            SILOGERROR(ERRCLS_ADD_RES, ESI076, (ErrVal) suId, 
                "SiLiSntUDatInd Failed, resource failure in decoding header");
#endif
            siDropMsg(mBuf);
            if (nCb->mfMsgCtl.uBuf != NULLP)
            {
               siDropMsg(nCb->mfMsgCtl.uBuf);
               nCb->mfMsgCtl.uBuf = NULLP;
            }
            RETVALUE(ROK);
         }
         if (ret1 == MFDEBUGERR)
         {
             SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MFDEBUGGER error in message decoding\n"));  
#if (ERRCLASS & ERRCLS_DEBUG)
            SILOGERROR(ERRCLS_DEBUG, ESI077, (ErrVal) suId, 
                    "SiLiSntUDatInd Failed, sofware error in decoding header");
#endif
            siDropMsg(mBuf);
            if (nCb->mfMsgCtl.uBuf != NULLP)
            {
               siDropMsg(nCb->mfMsgCtl.uBuf);
               nCb->mfMsgCtl.uBuf = NULLP;
            }
            RETVALUE(ROK);
         }
         /* message decode error */
#ifdef DBG4
         siMfPrntErr(&nCb->mfMsgCtl);
#endif
         /* initialize cause/diagnostic element */
         MFINITELMT(&nCb->mfMsgCtl, ret, NULLP, (ElmtHdr *) &causeDgn, 
                    &meCauseIndV, (U8) PRSNT_DEF, siIntfCb->cfg.swtch, 
                    (U32) MF_ISUP);
         causeDgn.recommend.pres = NOTPRSNT;
         siErrMapFunc(&nCb->mfMsgCtl, &causeDgn);

         switch(nCb->mfMsgCtl.msgIdx)
         {
            case MI_RELSE:
               if (siCon->tCallCb != NULLP)
               { 
                  causeDgn.causeVal.val  = CCNOPARAMPASS;
                  {
                     siGenRelUp(siCir->cfg.cirId, siCon, &causeDgn);
                     siDropMsg(mBuf);
                     if (nCb->mfMsgCtl.uBuf != NULLP)
                     {
                        siDropMsg(nCb->mfMsgCtl.uBuf);
                        nCb->mfMsgCtl.uBuf = NULLP;
                     }
                     RETVALUE(ROK);
                  }
               }
               nCb->mfMsgCtl.ee[0].siMfCauseDgn.causeVal.pres = NOTPRSNT;
               break;

            case MI_FACREQ:
               /* send Facility Reject */
               siGenMFacRej(siCir->cfg.cirId, siCon, &causeDgn, &message);
               siDropMsg(mBuf);
               if (nCb->mfMsgCtl.uBuf != NULLP)
               {
                  siDropMsg(nCb->mfMsgCtl.uBuf);
                  nCb->mfMsgCtl.uBuf = NULLP;
               }
               RETVALUE(ROK);

            default:
               RelCall = FALSE;
               /* Check action for MF_NA for Tokens with Message Elements */
               if (ret1 == SIMF_DISCPARM)
                  nCb->mfMsgCtl.ee[0].siMfCauseDgn.causeVal.pres = NOTPRSNT;
               else
               {
                  switch(ret1)
                  {
                     case SIMF_REL_CAUSE28:
                        causeDgn.causeVal.val = CCADDRINCOMP;
                        RelCall = TRUE;
                        break;
                     case SIMF_REL_CAUSE111:
                        causeDgn.causeVal.val = SIT_CCPROTERR;
                        RelCall = TRUE;
                        break;
                     case SIMF_REL_CCPROTERR:
                        causeDgn.causeVal.val = SIT_CCPROTERR;
                        RelCall = TRUE;
                        break;
                     case SIMF_REL_CAUSE65:
                        causeDgn.causeVal.val = SIT_CCBCAPNOTIMP;
                        RelCall = TRUE;
                        break;
                     case SIMF_DISCMSG_CFN_CAUSE110:
                        causeDgn.causeVal.val = CCNOPARAMDISCMSG;
                        msgIdx = nCb->mfMsgCtl.msgIdx;
                        if (siCon != NULLP)
                        {
                           /* send confusion */
                           siGenConf(siCon, siCir, &causeDgn);
                           nCb->mfMsgCtl.msgIdx = msgIdx;
                        }
                        else
                           /* send confusion */
                           /* si018.220: Modification - modify intfId and 
                            * intfflg so that when CNF is sent, statistics 
                            * counter is increased. */
                           siGenConfNoCon(nCb, key.k2.intfId, cgAdr, TRUE, 
                                 cdAdr, cicVal, &causeDgn, 
                                 siIntfCb->cfg.swtch);
                        break;
                     case SIMF_DISCMSG:
                        break;
                     default:
                        break;
                  }

                  if ((RelCall) && (siCon != NULLP))
                     siGenRelUpLw(siCir->cfg.cirId, siCon, &causeDgn);

                  siDropMsg(mBuf);
                  if (nCb->mfMsgCtl.uBuf != NULLP)
                  {
                     siDropMsg(nCb->mfMsgCtl.uBuf);
                     nCb->mfMsgCtl.uBuf = NULLP;
                  }

                  RETVALUE(ROK);
               }
         }
      }
      if (nCb->mfMsgCtl.ee[0].siMfCauseDgn.causeVal.pres)
      {
         /* initialize cause/diagnostic element */
         MFINITELMT(&nCb->mfMsgCtl, ret, NULLP, (ElmtHdr *) &causeDgn, 
                    &meCauseIndV, (U8) PRSNT_DEF, siIntfCb->cfg.swtch, 
                    (U32) MF_ISUP);
         causeDgn.recommend.pres = NOTPRSNT;
         siErrMapFunc(&nCb->mfMsgCtl, &causeDgn);
         switch(nCb->mfMsgCtl.msgIdx)
         {
            case MI_FACREQ:
               /* send Facility Reject */
               siGenMFacRej(siCir->cfg.cirId, siCon, &causeDgn, &message);
               siDropMsg(mBuf);
               if (nCb->mfMsgCtl.uBuf != NULLP)
               {
                  siDropMsg(nCb->mfMsgCtl.uBuf);
                  nCb->mfMsgCtl.uBuf = NULLP;
               }
               RETVALUE(ROK);
            default:
               if (ret == SIMF_DISCPARM)
                  nCb->mfMsgCtl.ee[0].siMfCauseDgn.causeVal.pres = NOTPRSNT;
               break;
         }
      }

      if (nCb->mfMsgCtl.uBuf != NULLP)
      {
         /*  Get pointer to upper control block */
         tCb = SIUPSAP(siIntfCb->cfg.sapId);

         /* attach SAP control block to siCon */
         if ((siCon) && (siCon->tCallCb == NULLP))
            siCon->tCallCb = tCb;
         
         switch (siIntfCb->cfg.swtch)
         {
#if SS7_ITU97
            case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
         case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
         case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
            case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added China variant */	 
#if SS7_CHINA
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
            case LSI_SW_ITU:
               /* do parameter comaptibility checking */
               /*  Get pointer to upper control block */
               ret = siChkParmComp(nCb, siCir, siCon, &message, TRUE);
               switch (ret)
               {
                  case ROK:
                     break;
                  case PC_INVRELMSG:
                     invRelRcvd = TRUE;
                     break;
                  case RFAILED:
                     SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "Parameter comp returns Failure , \
                       Dropping and returnign\n")); 
                     siDropMsg(mBuf);
                     RETVALUE(ROK);
                   case PC_DROPMSG:
                     SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "Parameter comp indicates Drop Message\n")); 
                     siDropMsg(mBuf);
                     RETVALUE(ROK);
               }
               break;
            default:
               break;
         }
      } /* end if (nCb->mfMsgCtl.uBuf != NULLP) */  
   } /* end if (!siChkifMsgExp....) */
   else
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
              "MsgIdx %d is not expected as per state matrix\n",
              nCb->mfMsgCtl.msgIdx)); 
   }

   /* if waiting the second segment of a segmented message:
      in case any other message except the ones listed below is 
      received before the segmentation message containing the 
      second segment, the exchange should react as if the second 
      segment is lost, i.e. the timer T34(T36) is stopped and 
      the call continues */
   if (siCon && 
       ((siCon->incC.msgToSegm != NULLP) ||
        (siCon->outC.msgToSegm != NULLP)))
   {
      SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "Previous message was segmented\n")); 
      switch (siIntfCb->cfg.swtch)
      {

#if SS7_ITU97
         case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
         case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
         case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added China variant */	 
#if SS7_CHINA
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         case LSI_SW_ITU:
            switch (nCb->mfMsgCtl.msgIdx)
            {
               case MI_SEGMMSG:
               case MI_CONTINUITY:
               case MI_BLOCK:
               case MI_UNBLK:
               case MI_BLOCKACK:
               case MI_UNBLKACK:
               case MI_CIRGRPQRY:
               case MI_CIRGRPQRYRES:
               case MI_CIRGRPBLKACK:
               case MI_CIRGRPBLK:
               case MI_CIRGRPUBLK:
               case MI_CIRGRPUBLKACK:
               case MI_CIRGRPRES:
               case MI_CIRGRPRESACK:
               case MI_RELCOMP:
                  break;
               default:
                  if ((siCir->cfg.cirId == siCon->incC.cirId) &&
                       (siCon->incC.msgToSegm != NULLP))
                  {
                     if (nCb->mfMsgCtl.msgIdx == MI_RELSE)
                     {
                        U8 msgType;
                        
                        SExamMsg(&msgType, siCon->incC.msgToSegm, 0);
                        if (msgType == M_INIADDR)
                        {
                           SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                           "Rel after segmd IAM rcvd. clearing con\n")); 
                           /* Generate Release Complete Message to Lower 
                            * Layer */
                           /* prepare Pdu header */
                           hdr.eh.pres      = PRSNT_NODEF;
                           hdr.msgType.pres = PRSNT_NODEF;
                           hdr.msgType.val  = (U8) M_RELCOMP;
                           
                           MFINITPDU(&nCb->mfMsgCtl, ret, (U8) 0, 
                                     (U8) MI_RELCOMP, (ElmtHdr *)NULLP, 
                                     (ElmtHdr *) &message, (U8) PRSNT_DEF,
                                     siIntfCb->cfg.swtch, (U32) MF_ISUP);
                           
                           siGenPdu(nCb, &hdr, &message, siIntfCb->cfg.swtch, 
                                    siCir->opc, siCir->cfg.intfId, 
                                    siCir->phyDpc, TRUE,
                                    siCir->cfg.cic, siCon->lnkSel, 
                                    siGetPriority(hdr.msgType.val, 
                                       siIntfCb->cfg.swtch), NULLP);
                           siClearIncCon(siCon);
                           RETVALUE(ROK);
                        }
                        siStopConTmr(siCon, TMR_T36I);
                        SPutMsg(siCon->incC.msgToSegm);
                        siCon->incC.msgToSegm = NULLP;             
                     }
                     else
                     {
                        msgIdx               = nCb->mfMsgCtl.msgIdx;
                        tempBuf              = nCb->mfMsgCtl.mp;
                        siReassblSegms(siCon, &(siCon->incC), SEGM_TMR);
                        nCb->mfMsgCtl.msgIdx = msgIdx;
                        nCb->mfMsgCtl.mp     = tempBuf;
                     }
                  }
                  else
                     if ((siCir->cfg.cirId == siCon->outC.cirId) &&
                         (siCon->outC.msgToSegm != NULLP))
                     {
                        if (nCb->mfMsgCtl.msgIdx == MI_RELSE)         
                        {       
                           SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                           "Segm Msg, el is sequence.Dropping segm\n")); 
                           siStopConTmr(siCon, TMR_T36O);
                           SPutMsg(siCon->outC.msgToSegm);
                           siCon->outC.msgToSegm = NULLP;
                        }
                        else
                        {
                           msgIdx               = nCb->mfMsgCtl.msgIdx;
                           tempBuf              = nCb->mfMsgCtl.mp;
                           siReassblSegms(siCon, &(siCon->outC), SEGM_TMR);
                           nCb->mfMsgCtl.msgIdx = msgIdx;
                           nCb->mfMsgCtl.mp     = tempBuf;
                        }
                     }
                  break;   
            }
            break;
#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "swtch %d invalid when handling prev.segm msg\n",
                          siIntfCb->cfg.swtch)); 
            SILOGERROR(ERRCLS_DEBUG, ESI078, (ErrVal) suId,
                 "SiLiSntUDatInd Failed, siIntfCb->cfg.swtch invalid");
            siDropMsg(mBuf);
            if (nCb->mfMsgCtl.uBuf != NULLP)
            {
               siDropMsg(nCb->mfMsgCtl.uBuf);
               nCb->mfMsgCtl.uBuf = NULLP;
            }
            RETVALUE(ROK);
#endif
      }
   }  /* end of "if waiting the second segment..." */

   switch (nCb->mfMsgCtl.msgIdx)
   {
      case MI_RELCOMP:
         /* RLC is both mntc. or call processing message */
         if ((siCir->transStat[SICIR_MTLOCST] == SICIR_ST_WTRESACK) ||
             (siCir->transStat[SICIR_HWLOCST] == SICIR_ST_WTRESACK))
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "RLC in wait for reset ack received\n")); 
            siCir->pduSp = &message;
            siProcCirMsg(siCir, MI_RELCOMP, FALSE);
         }
         else
         {
            siCon->pduSp = &message;
            if ((!siCon->incC.conPrcs) && (!siCon->outC.conPrcs))
               siCon->incC.cirId = siCir->cfg.cirId;

            /* jump into state matrix */
            siActDat(siCir->cfg.cirId, siCon, nCb->mfMsgCtl.msgIdx);
            if (nCb->mfMsgCtl.uBuf != NULLP)
            {
               siDropMsg(nCb->mfMsgCtl.uBuf);
               nCb->mfMsgCtl.uBuf = NULLP;
            }

            if (siProcIncSegm)
            {
               mBuf = NULLP;
               siProcIncSegm = FALSE;
            }
         }
         break;

      case MI_FACIL:
/* si034.220 : Modification - Drop as Facility Msg not reqd for CHINA */
#ifdef SS7_CHINA
      if ((siIntfCb->cfg.swtch == LSI_SW_CHINA) && 
	         (nCb->mfMsgCtl.msgIdx == MI_FACIL))
       {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Facility ! dumping msg\n")); 
         siDropMsg(mBuf);
         RETVALUE(ROK);
       }
#endif
         siCon->evntType      = MI_FACIL;

      case MI_FACREQ:
         if (nCb->mfMsgCtl.msgIdx == MI_FACREQ)
             siCon->evntType = MI_FACREQ;
         else
             nCb->mfMsgCtl.msgIdx = MI_FACREQ;

      case MI_INIADDR:
      case MI_ADDCOMP:
      case MI_ANSWER:
      case MI_CALLMODCOMP:
/* si034.220 : Modification - Drop as Call Modification Completed Msg for CHINA */
#ifdef SS7_CHINA
      if ((siIntfCb->cfg.swtch == LSI_SW_CHINA) && 
	      (nCb->mfMsgCtl.msgIdx == MI_CALLMODCOMP))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Call Mod Completed ! dumping msg\n")); 
         siDropMsg(mBuf);
         RETVALUE(ROK);
      }
#endif
      case MI_CALLMODREQ:
/* si034.220 : Modification - Drop as Call Modification Request Msg for CHINA */
#ifdef SS7_CHINA
      if ((siIntfCb->cfg.swtch == LSI_SW_CHINA) && 
	       (nCb->mfMsgCtl.msgIdx == MI_CALLMODREQ))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Call Mod Request ! dumping msg\n")); 
         siDropMsg(mBuf);
         RETVALUE(ROK);
      }
#endif
      case MI_CALLMODREJ:
/* si034.220 : Modification - Drop as Call Modification Reject Msg for CHINA */
#ifdef SS7_CHINA
      if ((siIntfCb->cfg.swtch == LSI_SW_CHINA) && 
	       (nCb->mfMsgCtl.msgIdx == MI_CALLMODREJ))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Call Mod Reject ! dumping msg\n")); 
         siDropMsg(mBuf);
         RETVALUE(ROK);
      }
#endif
      case MI_CALLPROG:
      case MI_CONFUSION:
      case MI_CONNCT:
      case MI_CONTINUITY:
      case MI_CONTCHKREQ:
      case MI_FACACC:
      case MI_FACREJ:
      case MI_FWDTFER:
      case MI_INFORMTN:
      case MI_INFOREQ:
      case MI_RELSE:
      case MI_RESUME:
      case MI_SUBADDR:
      case MI_SUSPND:
      case MI_USR2USR:
      case MI_LOOPBCKACK:
/* si034.220 : Modification - Drop as Loop Back Ack Msg for CHINA */
#ifdef SS7_CHINA
      if ((siIntfCb->cfg.swtch == LSI_SW_CHINA) && 
	       (nCb->mfMsgCtl.msgIdx == MI_LOOPBCKACK))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Loop Back Ack! dumping msg\n")); 
         siDropMsg(mBuf);
         RETVALUE(ROK);
      }
#endif
         siCon->pduSp = &message;
         if ((!siCon->incC.conPrcs) && (!siCon->outC.conPrcs))
            siCon->incC.cirId = siCir->cfg.cirId;

         /* jump into state matrix */
         siActDat(siCir->cfg.cirId, siCon, nCb->mfMsgCtl.msgIdx);
         /* Since on receiving the invalid release RLC is 
            sent therefore do not send RLC on getting RelResp 
         */
         if ( (nCb->mfMsgCtl.msgIdx == MI_RELSE) && (invRelRcvd) )
         {
            SiPduHdr       pduHdr;
            SiAllPdus      rlcmsg;

            if( siCir->cfg.cirId == siCon->incC.cirId )
               siCir->siCon->incC.relResp = FALSE;
            if( siCir->cfg.cirId == siCon->outC.cirId )
               siCir->siCon->outC.relResp = FALSE;
            /* Sending RLC */
            /* Generate Release Complete */
            /* prepare Pdu header */
            pduHdr.eh.pres      = PRSNT_NODEF;
            pduHdr.msgType.pres = PRSNT_NODEF;
            pduHdr.msgType.val  = (U8) M_RELCOMP;
            /* initialize Release Complete */
            cmMemset((U8 *)&rlcmsg, NOTPRSNT, sizeof(SiAllPdus));
            rlcmsg.m.relComplete.causeDgn.eh.pres = PRSNT_NODEF;
            rlcmsg.m.relComplete.causeDgn.location.pres = PRSNT_NODEF;
            rlcmsg.m.relComplete.causeDgn.location.val = siCon->tCallCb->
                           cfg.relLocation;
            rlcmsg.m.relComplete.causeDgn.cdeStand.pres = PRSNT_NODEF;
            rlcmsg.m.relComplete.causeDgn.cdeStand.val = SIT_CSTD_CCITT; 
            rlcmsg.m.relComplete.causeDgn.causeVal.pres = PRSNT_NODEF;
            rlcmsg.m.relComplete.causeDgn.causeVal.val = CCNOPARAMDISC;
                  
            siGenPdu(siCon->mCallCb, &pduHdr, &rlcmsg, 
                  siCon->tCallCb->cfg.swtch, siCir->opc,
                  siCir->cfg.intfId, siCir->phyDpc, TRUE,
                  siCir->cfg.cic, siCon->lnkSel, 
                  siGetPriority(M_RELCOMP, siCon->tCallCb->cfg.swtch), NULLP);
         }
         if (nCb->mfMsgCtl.uBuf != NULLP)
         {
            siDropMsg(nCb->mfMsgCtl.uBuf);
            nCb->mfMsgCtl.uBuf = NULLP;
         }

         if (siProcIncSegm == TRUE)
         {
            mBuf          = NULLP;
            siProcIncSegm = FALSE;
         }
         break;
#if (SS7_ETSI || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      case MI_LOOPPRVNT:
         /* loop prevention msg only valid for ETSI, ETSIV3 or ITU97 */
         if ((siIntfCb->cfg.swtch != LSI_SW_ETSI) &&
             (siIntfCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (siIntfCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (siIntfCb->cfg.swtch != LSI_SW_ITU2000) &&
             (siIntfCb->cfg.swtch != LSI_SW_ITU97))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "Loopprvnt rcvd for non-etsi or non-itu97 variant %d \n", 
                siIntfCb->cfg.swtch)); 
            siDropMsg(mBuf);
            if (nCb->mfMsgCtl.uBuf != NULLP)
            {
               siDropMsg(nCb->mfMsgCtl.uBuf);
               nCb->mfMsgCtl.uBuf = NULLP;
            }
            RETVALUE(ROK);
         }
/* si024.220: Deletion - remove the call transfer reference check since
 * it is only an optional parameter */

         /* check if acting as transit */
         if ((siCon->incC.conPrcs) && (siCon->outC.conPrcs))
         {
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
             "connection acting as Transit con->inc/outC.conPrcs SET\n")); 
            /* check whether to send on incoming or outgoing ckt */
            if (siCon->incC.cir->cfg.cic == cicVal)
            {
               byte1 = (U8) GetHiByte(siCon->outC.cir->cfg.cic);
               ret   = SAddPreMsg((Data) byte1, mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
               if (ret != ROK)
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SAddPreMsg failed .Dropping\n")); 
                  SILOGERROR(ERRCLS_DEBUG, ESI079, (ErrVal)ret, 
                                             "SAddPstMsg() Failed");
                  siDropMsg(mBuf);
                  if (nCb->mfMsgCtl.uBuf != NULLP)
                  {
                     siDropMsg(nCb->mfMsgCtl.uBuf);
                     nCb->mfMsgCtl.uBuf = NULLP;
                  }
                  RETVALUE(ROK);
               }
#endif
               byte2 = (U8) GetLoByte(siCon->outC.cir->cfg.cic);
               ret   = SAddPreMsg((Data) byte2, mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
               if (ret != ROK)
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SAddPreMsg failed .Dropping\n")); 
                  SILOGERROR(ERRCLS_DEBUG, ESI080, (ErrVal)ret, 
                               "SAddPstMsg() Failed");
                  siDropMsg(mBuf);
                  if (nCb->mfMsgCtl.uBuf != NULLP)
                  {
                     siDropMsg(nCb->mfMsgCtl.uBuf);
                     nCb->mfMsgCtl.uBuf = NULLP;
                  }
                  RETVALUE(ROK);
               }
#endif
                siSndMsg(siCon->mCallCb, mBuf, siCon->outC.cir->opc, 
                        siCon->outC.cir->cfg.intfId, siCon->outC.cir->phyDpc,
                        TRUE, siCon->lnkSel, FALSE, 
                        siGetPriority(M_LOOPPRVNT,
                        siCon->tCallCb->cfg.swtch), 
                        siCon->tCallCb->cfg.swtch);    
            }  
            else /* send msg on incoming circuit */
            {
               byte1 = (U8) GetHiByte(siCon->incC.cir->cfg.cic);
               ret   = SAddPreMsg((Data) byte1, mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
               if (ret != ROK)
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SAddPreMsg failed .Dropping\n")); 
                  SILOGERROR(ERRCLS_DEBUG, ESI081, (ErrVal)ret, 
                                             "SAddPstMsg() Failed");
                  siDropMsg(mBuf);
                  if (nCb->mfMsgCtl.uBuf != NULLP)
                  {
                     siDropMsg(nCb->mfMsgCtl.uBuf);
                     nCb->mfMsgCtl.uBuf = NULLP;
                  }
                  RETVALUE(ROK);
               }
#endif
               byte2 = (U8) GetLoByte(siCon->incC.cir->cfg.cic);
               ret   = SAddPreMsg((Data) byte2, mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
               if (ret != ROK)
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SAddPreMsg failed .Dropping\n")); 
                  SILOGERROR(ERRCLS_DEBUG, ESI082, (ErrVal)ret, 
                               "SAddPstMsg() Failed");
                  siDropMsg(mBuf);
                  if (nCb->mfMsgCtl.uBuf != NULLP)
                  {
                     siDropMsg(nCb->mfMsgCtl.uBuf);
                     nCb->mfMsgCtl.uBuf = NULLP;
                  }
                  RETVALUE(ROK);
               }
#endif
                siSndMsg(siCon->mCallCb, mBuf, siCon->incC.cir->opc, 
                        siCon->incC.cir->cfg.intfId,
                        siCon->incC.cir->phyDpc, TRUE, siCon->lnkSel, 
                        FALSE, siGetPriority(M_LOOPPRVNT,
                                  siCon->tCallCb->cfg.swtch),
                        siCon->tCallCb->cfg.swtch);
            }
            if (nCb->mfMsgCtl.uBuf != NULLP)
            {
               siDropMsg(nCb->mfMsgCtl.uBuf);
               nCb->mfMsgCtl.uBuf = NULLP;
            }
            RETVALUE(ROK);
         } /* acting as transit */

/* si024.220: Modification - check to see whether to stop timer */
         /* if transfer reference is same as one sent(if any), stop ECT timer*/
         if (message.m.loopPrvnt.calTrnsfrRef.eh.pres != NOTPRSNT)
         {
            if ((siCon->callTRef.tRefUsed == TRUE) &&
                (siCon->callTRef.tRefVal == 
                 message.m.loopPrvnt.calTrnsfrRef.callTrnsfr.val))
            {
               siStopConTmr(siCon, TMR_TECT);
            }
         }
         /* send loop prevention indication to the upper layer */
         siGenCnStInd(siCir, &message, nCb->mfMsgCtl.msgIdx);
         break;
#endif  /* SS7_ETSI || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */

      case MI_OVERLOAD:
/* si034.220 : Modification - Drop as Overload Msg for CHINA */
#ifdef SS7_CHINA
      if ((siIntfCb->cfg.swtch == LSI_SW_CHINA) && 
	       (nCb->mfMsgCtl.msgIdx == MI_OVERLOAD))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Overload ! dumping msg\n")); 
         siDropMsg(mBuf);
         RETVALUE(ROK);
      }
#endif

         /* Overload message can be received for Outgoing calls only */
         if (siCon->outC.conPrcs == TRUE)
         {
            /* Stop all connection timers */
            for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
               if (siCon->timers[tmrNum].tmrEvnt != TMR_NONE)
                  siRmvConTq(siCon, tmrNum);
 
            /* Start timer T3 */
            siStartCirTmr(TMR_T3, siCir);
 
            /* send Status Indication (eventType = OVERLOAD) to Upper Layer */
            SiUiSitStaInd(&siCon->tCallCb->pst, siCon->tCallCb->suId,
               siCon->suInstId, siCon->key.k1.spInstId, siCir->cfg.cirId,
               FALSE, SIT_STA_OVERLOAD, NULLP, NULLP);
         } 
         else
         {
             SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Overload message rcvd for incoming calls\n")); 
         }

         break;

      case MI_UNEQUIPCIC:
/* si034.220 : Modification - Drop as Unequip CIC Msg for CHINA */
#ifdef SS7_CHINA
      if ((siIntfCb->cfg.swtch == LSI_SW_CHINA) && 
	       (nCb->mfMsgCtl.msgIdx == MI_UNEQUIPCIC))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Unequip CIC! dumping msg\n")); 
         siDropMsg(mBuf);
         RETVALUE(ROK);
      }
#endif
         /* directly use fsm event index since we know it here */
         siProcCirMsg(siCir, CEI_UCIC, TRUE);
         break;

      case MI_BLOCK:
      case MI_UNBLK:
      case MI_BLOCKACK:
      case MI_UNBLKACK:
      case MI_RESCIR:
         /* process circuit requests */
         siCir->pduSp = (SiAllPdus *)&message;
/* si023:220: addition - add statement to set noRspFlgToLw to FALSE
 * so that responses to these messages from CC will be sent to the
 * network.
 */
         siCir->noRspFlgToLw = FALSE;
         siProcCirMsg(siCir, nCb->mfMsgCtl.msgIdx, FALSE);
         break;

      case MI_NETRESMGT:
      case MI_IDENTREQ:
/* si034.220 : Modification - Drop as Identity Request Msg for CHINA */
#ifdef SS7_CHINA
      if ((siIntfCb->cfg.swtch == LSI_SW_CHINA) && 
	       (nCb->mfMsgCtl.msgIdx == MI_IDENTREQ))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Identitiy Req.! dumping msg\n")); 
         siDropMsg(mBuf);
         RETVALUE(ROK);
      }
#endif
      case MI_IDENTRSP:
/* si034.220 : Modification - Drop as Identity Response Msg for CHINA */
#ifdef SS7_CHINA
      if ((siIntfCb->cfg.swtch == LSI_SW_CHINA) && 
	       (nCb->mfMsgCtl.msgIdx == MI_IDENTRSP))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Identitiy Res.! dumping msg\n")); 
         siDropMsg(mBuf);
         RETVALUE(ROK);
      }
#endif
         /* si029.220: Addition - added INDIA switch */
         if ( ((siIntfCb->cfg.swtch == LSI_SW_ITU) || 
               (siIntfCb->cfg.swtch == LSI_SW_FTZ) || 
               (siIntfCb->cfg.swtch == LSI_SW_ITU97) || 
               (siIntfCb->cfg.swtch == LSI_SW_ETSIV3) || 
               (siIntfCb->cfg.swtch == LSI_SW_ITU2000) || 
               (siIntfCb->cfg.swtch == LSI_SW_RUSS2000) || 
               (siIntfCb->cfg.swtch == LSI_SW_ETSI) ||
               (siIntfCb->cfg.swtch == LSI_SW_INDIA)) 
               && (siCir->siCon != NULLP))
            /* send indication to the upper layer */
            siGenCnStInd(siCir, &message, nCb->mfMsgCtl.msgIdx);
         else {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
               "swtch ! (ITU/FTZ/ETSI) for NETRESMGT/IDENTREQ/RSP\n"));  
         }
         break;


#if SS7_ITU2000
      case MI_SUBDIRNUM:  
         /* send indication to the upper layer */
         siGenCnStInd(siCir, &message, nCb->mfMsgCtl.msgIdx);
         break;
#endif

/* si029.220: Addition - added SS7_INDIA flag for charge info message */
#if (SS7_SINGTEL || SS7_RUSSIA || SS7_INDIA)
      case MI_CHARGE:
            if (siChkifMsgExp(siCir->cfg.cirId, siCon, nCb->mfMsgCtl.msgIdx)
                 == FALSE)
         {
#if (SI_LMINT3 || SMSI_LMINT3)
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &siCir->cfg.cirId,
                          LSI_USTA_DGNVAL_EVENT, (PTR) &nCb->mfMsgCtl.msgIdx,
                          LSI_USTA_DGNVAL_NONE, NULLP,
                          LSI_USTA_DGNVAL_NONE, NULLP);
            siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE,
                            LCM_EVENT_LI_INV_EVT, LSI_CAUSE_INV_EVNT, FALSE);
#endif
            siDropMsg(mBuf);
            if (nCb->mfMsgCtl.uBuf != NULLP)
            {
               siDropMsg(nCb->mfMsgCtl.uBuf);
               nCb->mfMsgCtl.uBuf = NULLP;
            }
            RETVALUE(ROK);
         }
         siGenCnStInd(siCir, &message, nCb->mfMsgCtl.msgIdx);
         break;
#endif

      case MI_SEGMMSG:
         /* si034.220: Addition - added China switch */ 
         /* si029.220: Addition - added INDIA switch */
         if (!((siIntfCb->cfg.swtch == LSI_SW_ITU) ||
              (siIntfCb->cfg.swtch == LSI_SW_ETSI) ||
              (siIntfCb->cfg.swtch == LSI_SW_ETSIV3) ||
              (siIntfCb->cfg.swtch == LSI_SW_ITU97) ||
              (siIntfCb->cfg.swtch == LSI_SW_ITU2000) || 
              (siIntfCb->cfg.swtch == LSI_SW_RUSS2000) || 
              (siIntfCb->cfg.swtch == LSI_SW_FTZ) ||
              (siIntfCb->cfg.swtch == LSI_SW_INDIA) ||
              (siIntfCb->cfg.swtch == LSI_SW_CHINA)))
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "swtch ! (ITU/ETSI/FTZ/INDIA/CHINA) for SEGMMSG\n")); 
            break;
         }        

         if ((siCir->cfg.cirId == siCon->incC.cirId) &&
             (siCon->incC.msgToSegm != NULLP))
         {
            if (nCb->mfMsgCtl.uBuf != NULLP)
            {
               siDropMsg(nCb->mfMsgCtl.uBuf);
               nCb->mfMsgCtl.uBuf = NULLP;
            }
            ret = siReassblSegms(siCon, &(siCon->incC), SEGM_MSG);
            if (ret != ROK)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Error in reassempling the segm\n"));  

               siDropMsg(mBuf);
               /* Clear the connection for the segmented 
                * IAM because there are errors in the reassembling.
                * The retuned value is not ROK can be the reason that the 
                * message is drop because the indicator in PC is indicated
                * as discarded message when there is unrecognized parameter
                * in the first IAM.
                */
               if ((siCon->incC.conState == ST_WTFORACM) ||
                   (siCon->incC.conState == ST_WTFORCONTIN))
               {
                  siClearIncCon(siCon);
               }
               RETVALUE(ROK);
            }
         }
         else
            if ((siCir->cfg.cirId == siCon->outC.cirId) && 
                (siCon->outC.msgToSegm != NULLP))
            {
               if (nCb->mfMsgCtl.uBuf != NULLP)
               {
                  siDropMsg(nCb->mfMsgCtl.uBuf);
                  nCb->mfMsgCtl.uBuf = NULLP;
               }
               ret = siReassblSegms(siCon, &(siCon->outC), SEGM_MSG);
               if (ret != ROK)
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Error in reassempling the segm\n"));  

                  siDropMsg(mBuf);
                  /* Clear the connection for the segmented 
                   * IAM because there are errors in the reassembling
                   * The retuned value is not ROK can be the reason that the 
                   * message is drop because the indicator in PC is indicated
                   * as discarded message when there is unrecognized parameter
                   * in the first IAM.
                   */
                  if ((siCon->outC.conState == ST_WTFORACM) ||
                      (siCon->outC.conState == ST_WTFORCONTIN))
                  {
                     siClearOutCon(siCon);
                  }
                  RETVALUE(ROK);
               }

                
            }
         break;


      case MI_USRPARTA:
         /* if switch is CCITT, stop timer and send indication to SM */
         /* si029.220: Addition - added INDIA switch */
         if ((siIntfCb->cfg.swtch == LSI_SW_ITU) || 
             (siIntfCb->cfg.swtch == LSI_SW_ITU97) || 
             (siIntfCb->cfg.swtch == LSI_SW_ITU2000) || 
             (siIntfCb->cfg.swtch == LSI_SW_RUSS2000) || 
             (siIntfCb->cfg.swtch == LSI_SW_ETSIV3) || 
             (siIntfCb->cfg.swtch == LSI_SW_ETSI) ||
             (siIntfCb->cfg.swtch == LSI_SW_INDIA))
         {
            /* stop t4 */
/* si007.220 - Modification. Modified code in order to send alarm using intfId
 * rather than dpc.
 */
            siInitUstaDgn(LSI_USTA_DGNVAL_INTF, (PTR) &siIntfCb->cfg.intfId, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                           LSI_EVENT_USERPART, LSI_CAUSE_AVAILABLE, TRUE, 
                           siCir->cfg.cirId, SIMTP_RMTUSRAV);
         }
         {

            tCb = SIUPSAP(siIntfCb->cfg.sapId);

            /* generate status indication to call control */
            MFINITSDU(&tCb->mfMsgCtl, ret, (U8) MI_USRPARTA, (U8) SI_STAREQ, 
                (ElmtHdr *) &message.m.usrPrtAvTst, (ElmtHdr *) &ev, 
                (U8) PRSNT_NODEF, siIntfCb->cfg.swtch, (U32) MF_ISUP);

            SiUiSitStaInd(&tCb->pst, tCb->suId, 0, 0, siCir->cfg.cirId,
                  FALSE, SIT_STA_USRPARTA, &ev.m.siStaEvnt, NULLP); 
#ifdef SI_PROVE
            SPrint("Receive user part available message  \n");
#endif
         }
          break;
      case MI_USRPARTT:
         /* if switch is CCITT, send User Part Available Message */
         /* si029.220: Addition - added INDIA switch */
         if ((siIntfCb->cfg.swtch == LSI_SW_ITU) || 
             (siIntfCb->cfg.swtch == LSI_SW_ITU97) || 
             (siIntfCb->cfg.swtch == LSI_SW_ITU2000) || 
             (siIntfCb->cfg.swtch == LSI_SW_RUSS2000) || 
             (siIntfCb->cfg.swtch == LSI_SW_ETSIV3) || 
             (siIntfCb->cfg.swtch == LSI_SW_ETSI) ||
             (siIntfCb->cfg.swtch == LSI_SW_INDIA) ||
             (siIntfCb->cfg.swtch == LSI_SW_CHINA))
         {
            siGenCirMsg(siCir->key.k2.cic, siCir->opc, siCir->key.k2.intfId,
                  siCir->phyDpc, TRUE, siIntfCb->cfg.swtch, M_USRPARTA, 
                  MI_USRPARTA, NULLP, siIntfCb->cfg.ssf, siIntfCb->cfg.nwId);
         } 
         else 
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "swtch !(ITU/ETSI) for USRPARTT\n"));  
         }

         break;

      case MI_CIRGRPQRY:
      case MI_CIRGRPQRYRES:
      case MI_CIRGRPBLKACK:
      case MI_CIRGRPBLK:
      case MI_CIRGRPUBLK:
      case MI_CIRGRPUBLKACK:
      case MI_CIRGRPRES:
      case MI_CIRGRPRESACK:
         siCir->pduSp = &message;
         siProcCirGrMsg(siCir, nCb->mfMsgCtl.msgIdx, (SiAllPdus *)&message);
         break;
/* si029.220: Addition - added SS7_INDIA */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      case MI_PRERELINF:
         /* send indication to the upper layer */
         siGenCnStInd(siCir, &message, nCb->mfMsgCtl.msgIdx);
         break;

      case MI_APPTRAN:
         /* send indication to the upper layer */
         siGenCnStInd(siCir, &message, nCb->mfMsgCtl.msgIdx);
         break;
#endif /* SS7_ETSIV3 */

/* si034.220: Addition - new messages handling for CHINA variant */
#if SS7_CHINA
      case MI_METPULSE:  
         /* send indication to the upper layer */
         siGenCnStInd(siCir, &message, nCb->mfMsgCtl.msgIdx);
         break;
      
      case MI_CLGPTYCLR:  
         /* send indication to the upper layer */
         siGenCnStInd(siCir, &message, nCb->mfMsgCtl.msgIdx);
         break;
     
     case MI_OPERATOR:  
         /* send indication to the upper layer */
         siGenCnStInd(siCir, &message, nCb->mfMsgCtl.msgIdx);
         break;
#endif /* if SS7_CHINA */
   }
   siDropMsg(mBuf);
   if (nCb->mfMsgCtl.uBuf != NULLP)
   {
      siDropMsg(nCb->mfMsgCtl.uBuf);
      nCb->mfMsgCtl.uBuf = NULLP;
   }
   RETVALUE(ROK);
} /* End of SiLiSntUDatInd */


/*
*
*      Fun:   Status Indication
*
*      Desc:  This function provides for an indication of status of the
*             signalling point.
*   
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiLiSntStaInd
(
Pst *pst,                   /* bind configuration */
SuId suId,                  /* service user id */
Dpc adr,                    /* affected point code */
Status status,              /* status */
Priority priority           /* priority */
)
#else
PUBLIC S16 SiLiSntStaInd(pst, suId, adr, status, priority)
Pst *pst;                   /* bind configuration */
SuId suId;                  /* service user id */
Dpc adr;                    /* affected point code */
Status status;              /* status */
Priority priority;          /* priority */
#endif
{
   SiNSAPCb   *nCb;
   SiUpSAPCb  *tCb;
   SiIntfCb    *siIntfCb;

   TRC3(SiLiSntStaInd)
   UNUSED(pst);

   SIDBGP(DBGMASK_LI, 
          (siCb.init.prntBuf, 
           "%sSiLiSntStaInd (suId=%#x, dpc=%#lx, status=%#x, priority = %#x\n",
            SI_STR, suId, adr, status, priority)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI083, (ErrVal) ziCb.protState,
                 "SiUiSntStaInd() failed, ISUP is not active\n");
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_LI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   /* get mtp control block */
   if (((nCb = SIMTPSAP(suId)) == NULLP) || (nCb->state != SI_BND))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             (nCb)?"For suId %#x state %#x not bound\n":
                   "For suId %#x control block does not exist \n",
             suId, (nCb) ? nCb->state : 0));

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI084, (ErrVal) suId, 
                 "SiLiSntStaInd() Failed, invalid suId");
#endif
      siInitUstaDgn(LSI_USTA_DGNVAL_SUID, (PTR) &suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_LI_INV_EVT, LSI_CAUSE_INV_MSAP, TRUE, 
                     (CirId)suId, SIMSAP_INV);
      RETVALUE(ROK);
   }

   /* for restart begin and end the dpc from MTP3 is not valid
    * Return from here as ISUP dumps this indication in any case
    */
   switch (status)
   {
      case SN_RSTBEG:      /* Fall Through */
      case SN_RSTEND:          
         RETVALUE(ROK);
      default:
         break;
   }
   
   /* find the first intf control block */
   if (siFindIntf(&siIntfCb, 0, adr, nCb->cfg.nwId, nCb->cfg.ssf, 0,
                        SIINTF_KEY_3) != ROK)
   {  
      SIDBGP(SIDBGMASK_CERR,
             (siCb.init.prntBuf, 
              "intf (%#lx) control block unavailable\n", adr));  
      RETVALUE(RFAILED);
   }     

   /* now process dpc status for all intf with different OPC */
   /* get pointer to the upper control block */
   tCb = SIUPSAP(siIntfCb->cfg.sapId);

   do
   {
      /* now check if swtch, NT and phyDpc are matching */
      if ((siIntfCb->cfg.nwId == nCb->cfg.nwId) &&
          (SICMPNT(siIntfCb->cfg.ssf, nCb->cfg.ssf)) &&
          (siIntfCb->cfg.phyDpc == adr))
      {
         siProcIntfStatus(nCb, tCb, siIntfCb, status, priority);
#ifdef ZI
         ziRunTimeUpd(ZI_INTF_CB, CMPFTHA_UPD_REQ, (PTR) siIntfCb);
         ziUpdPeer();
#endif
      }
   } while(cmHashListGetNext(&siCb.intfHlCp.k3Cp, (PTR) siIntfCb,
       (PTR *) &siIntfCb) == ROK);

   RETVALUE(ROK);
}

#ifdef SI_SPT

#ifdef SPT2

/*
*
*       Fun:   SiLiSptBndCfm
*
*       Desc:  Function to process bind confirmation from SCCP
*              
*       Ret:   ROK - ok
*
*       Notes: none
*
*       File:  ci_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SiLiSptBndCfm 
(
Pst  *pst,
SuId suId,
U8   status
)
#else
PUBLIC S16 SiLiSptBndCfm (pst, suId, status)
Pst  *pst;
SuId suId;
U8   status;
#endif
{
   SiNSAPCb *nCb;

   TRC2(SiLiSptBndCfm)
   UNUSED(pst);

   SIDBGP(DBGMASK_LI, (siCb.init.prntBuf, 
                      "%s\n\nBndCfm : L3 -> L4      SPT intf\n", SI_STR)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI085, (ErrVal) ziCb.protState,
                 "SiUiSptBndCfm() failed, ISUP is not active\n");
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_LI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */
  
   if ((suId < (SuId) 0) || (suId >= (SuId) siCb.genCfg.nmbNSaps) ||
       ((nCb = SISCCPSAP(suId)) == NULLP))
   {
      SIDBGP(DBGMASK_LI, (siCb.init.prntBuf, 
                         "SptBndCfm(): SCCP SAP is unavailable, (suId = %x)", 
                         suId)); 
#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI086, (ErrVal) suId,
                 "SiLiSptBndCfm(), NSAP not configured");
#endif
      siInitUstaDgn(LSI_USTA_DGNVAL_SUID, (PTR) &suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_LI_INV_EVT, LSI_CAUSE_INV_SSAP, TRUE, 
                     (CirId)suId, SISSAP_INV);
      RETVALUE(RFAILED);
   }

   if (nCb->state != SI_WT_BNDCFM)
      RETVALUE(ROK);

   siStopNSAPTmr(nCb, TMR_TINT);
   nCb->bndRetryCnt = 0;

   if (status == CM_BND_NOK)
   {
      nCb->state       = SI_UNBND;
      siInitUstaDgn(LSI_USTA_DGNVAL_SUID, (PTR) &suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP, LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_BND_FAIL, LCM_EVENT_BND_FAIL, TRUE, 
                     suId, SI_ALRM_NSAP_NOTBOUND);
      RETVALUE(ROK);
   }

   nCb->state = SI_BND;

#ifdef ZI
   ziRunTimeUpd(ZI_SCCPSAP_CB, CMPFTHA_UPD_REQ, (PTR) nCb);
   ziUpdPeer();
#endif /* ZI */

   RETVALUE(ROK);
}/* SiLiSptBndCfm */

#endif /* SPT2 */


/*
*
*      Fun:   Unit Data Indication
*
*      Desc:  This function provides for an exchange of user
*             data units.
*   
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiLiSptUDatInd
(
Pst        *pst,            /* bind configuration */
SuId       suId,            /* service user id */
Dpc        opc,             /* originating point code */
SpUDatEvnt *uData,          /* SCCP Address */
Buffer     *mBuf            /* pointer to the data buffer */
)
#else
PUBLIC S16 SiLiSptUDatInd(pst, suId, opc, uData, mBuf)
Pst        *pst;            /* bind configuration */
SuId       suId;            /* service user id */
Dpc        opc;             /* originating point code */
SpUDatEvnt *uData;          /* SCCP Address */
Buffer     *mBuf;           /* pointer to the data buffer */
#endif
{
   SiNSAPCb   *sCb;
   SiIntfCb   *siIntfCb;
   S16        bufLen;
   SiPduHdr   hdr;
   S16        ret;
   SiAllPdus  message;
   CirId      cirId;
   SiCauseDgn causeDgn;
   SiCon      *siCon;
   SiInstId   callRef;

   TRC3(SiLiSptUDatInd)
   UNUSED(pst);

   SIDBGP(DBGMASK_LI, (siCb.init.prntBuf, 
                      "%s\n\nUDatInd : L3 -> L4      SPT intf\n", SI_STR)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI087, (ErrVal) ziCb.protState,
                 "SiUiSptUDatInd() failed, ISUP is not active\n");
#endif
      siDropMsg(mBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_LI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   /* get SCCP SAP control block */
   if (((sCb = SISCCPSAP(suId)) == NULLP) || (sCb->state != SI_BND))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         (sCb)?"For suId 0x%x state 0x%x not bound\n":
            "For suId 0x%x control block does not exist \n",
               suId, (sCb)?sCb->state:0));


#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI088, (ErrVal) suId, 
                 "SiLiSptUDatInd() Failed, invalid suId");
#endif
      siInitUstaDgn(LSI_USTA_DGNVAL_SUID, (PTR) &suId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_LI_INV_EVT, LSI_CAUSE_INV_SSAP, TRUE, 
                     (CirId)suId, SISSAP_INV);
      siDropMsg(mBuf);
      RETVALUE(ROK);
   }

   /* do trace if needed */
   if (sCb->trc)
      siTrcBuf(opc, NULLP, TL5MSGRX, SAP_SCCP, mBuf);

/* si039.220 - Debug flag changed from DBG4 to DBG5 as DBG4 should be used for error
               cases in mf and not in Tx & Rx
*/
#ifdef DBG5
   /* print received message */
   if (siCb.init.dbgMask & SIDBGMASK_MSGRX)
   {
       SPrntMsg(mBuf, suId, sCb->spId);
   }
#endif

   ret = SFndLenMsg(mBuf, &bufLen);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "error in finding length of the message \n"));
      SILOGERROR(ERRCLS_DEBUG, ESI089, (ErrVal) suId, 
                 "SFndLenMsg() Failed, SiLiSptUDatInd");
      siDropMsg(mBuf);
      RETVALUE(ROK);
   }
#endif

   /* if under minimum isup message len from mtp3, drop */
   if (bufLen < 1)
   {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                              "invalid message length %#x\n", bufLen)); 
       siDropMsg(mBuf);
       RETVALUE(ROK);
   }

   if (siFindIntf(&siIntfCb, 0, opc, sCb->cfg.nwId, sCb->cfg.ssf,
                  uData->cdAddr.pc, SIINTF_KEY_2) != ROK)
   {
      siInitUstaDgn(LSI_USTA_DGNVAL_ADDRS, (PTR) &uData->cdAddr,
                    LSI_USTA_DGNVAL_SUID, (PTR) &suId,
                    LSI_USTA_DGNVAL_NONE, NULLP,
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE,
                     LCM_EVENT_LI_INV_EVT, LSI_CAUSE_INV_INTF,
                     TRUE, circuit, SI_ALRM_INTF_NOTCFGD);
      RETVALUE(ret);
   }

   /* decode message header */
   MFDECPDUHDR(&sCb->mfMsgCtl, ret, mBuf, (ElmtHdr *) &hdr, 
               &siPduHdrMsgDef[0], TRUE, TRUE, siIntfCb->cfg.swtch, 
               (U32) MF_ISUP);
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
             "Decode PDU header failed\n"));  
      /* message header decode error */
#ifdef DBG4
      siMfPrntErr(&sCb->mfMsgCtl);
#endif
      siDropMsg(mBuf);
      RETVALUE(ROK);
   }

#if (SI_LMINT3 || SMSI_LMINT3)
   if (siFindIntf(&siIntfCb, 0, uData->cgAddr.pc,
                  sCb->cfg.nwId, sCb->cfg.ssf,
                  0, SIINTF_KEY_3) == ROK)
   {
      siUpdIntfSts(siIntfCb->cfg.intfId, LSI_STS_RX,
                   sCb->mfMsgCtl.msgType);
   }
#endif

   /* decode message */
   MFDECPDU(&sCb->mfMsgCtl, ret, (ElmtHdr *) &message);
   if (((ret != MFREOM) && (ret != ROK)) || 
       (sCb->mfMsgCtl.ee[0].siMfCauseDgn.causeVal.pres))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "PDU decode failed\n"));  
      /* message decode error */
#ifdef DBG4
      siMfPrntErr(&sCb->mfMsgCtl);
#endif
      switch (sCb->mfMsgCtl.msgIdx)
      {
         case MI_FACREQ:
            /* send Facility Reject */
            /* initialize cause/diagnostic element */
            MFINITELMT(&sCb->mfMsgCtl, ret, NULLP, (ElmtHdr *) &causeDgn, 
                       &meCauseIndV, (U8) PRSNT_DEF, siIntfCb->cfg.swtch, 
                       (U32) MF_ISUP);

            causeDgn.recommend.pres = NOTPRSNT;
            siErrMapFunc(&sCb->mfMsgCtl, &causeDgn);
            siGenSFacRej(sCb, &causeDgn,
                         message.m.facRequest.callRef.pntCde.val,
                         0, opc, FALSE, &message, siIntfCb->cfg.swtch);
            siDropMsg(mBuf);
            RETVALUE(ROK);
         default:
            siDropMsg(mBuf);
            RETVALUE(ROK);
      }
   }

   switch (sCb->mfMsgCtl.msgIdx)
   {
      case MI_FACACC:
         switch (siIntfCb->cfg.swtch)
         {
#if SS7_ITU97
           case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
           case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
           case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
           case LSI_SW_INDIA:
#endif
           case LSI_SW_ITU:
               /* in no CallRef in received message */
               if ((message.m.facAccept.callRef.eh.pres == NOTPRSNT) ||
                   (!message.m.facAccept.callRef.callId.val))
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no callRef in facAccept \n"));  
                  siDropMsg(mBuf);
                  RETVALUE(ROK);
               }
               callRef = message.m.facAccept.callRef.callId.val;
               break;
/* si034.220: Addition - added China variant */	 
#if SS7_CHINA
         case LSI_SW_CHINA:
               /* in no CallRef in received message */
               if ((message.m.facAccept.callRefA.eh.pres == NOTPRSNT) ||
                   (!message.m.facAccept.callRefA.callId.val))
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no callRef in facAccept \n"));  
                  siDropMsg(mBuf);
                  RETVALUE(ROK);
               }
               callRef = message.m.facAccept.callRefA.callId.val;
               break;
#endif /* if SS7_CHINA */
            default:
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                  "FACACCPT: invalid switch %#x\n", siIntfCb->cfg.swtch));  
               siDropMsg(mBuf);
               RETVALUE(ROK);
         }
         break;
      case MI_FACREJ:
         /* in no CallRef in received message */
         switch (siIntfCb->cfg.swtch)
         {
#if SS7_ITU97
            case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
           case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
           case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
            case LSI_SW_INDIA:
#endif
            case LSI_SW_ITU:
               if ((message.m.facReject.callRef.eh.pres == NOTPRSNT) ||
                   (!message.m.facReject.callRef.callId.val))
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no callRef in facReject \n"));  
                  siDropMsg(mBuf);
                  RETVALUE(ROK);
               }
               callRef = message.m.facReject.callRef.callId.val;
               break;
/* si034.220: Addition - added China variant */	 
#if SS7_CHINA
         case LSI_SW_CHINA:
               /* in no CallRef in received message */
               if ((message.m.facAccept.callRefA.eh.pres == NOTPRSNT) ||
                   (!message.m.facAccept.callRefA.callId.val))
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no callRef in facAccept \n"));  
                  siDropMsg(mBuf);
                  RETVALUE(ROK);
               }
               callRef = message.m.facAccept.callRefA.callId.val;
               break;
#endif /* if SS7_CHINA */
            default:
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "FACREJ: invalid switch %#x\n", siIntfCb->cfg.swtch));  
               siDropMsg(mBuf);
               RETVALUE(ROK);
         }
         break;
      case MI_FACREQ:
         /* in no CallRef in received message */
         switch (siIntfCb->cfg.swtch)
         {
#if SS7_ITU97
           case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
           case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
           case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
           case LSI_SW_INDIA:
#endif
           case LSI_SW_ITU:
               if ((message.m.facRequest.callRef.eh.pres == NOTPRSNT) ||
                   (!message.m.facRequest.callRef.callId.val))
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no callRef in facReq \n"));  
                  siDropMsg(mBuf);
                  RETVALUE(ROK);
               }
               callRef = message.m.facRequest.callRef.callId.val;
               break;
/* si034.220: Addition - added China variant */	 
#if SS7_CHINA
         case LSI_SW_CHINA:
               /* in no CallRef in received message */
               if ((message.m.facAccept.callRefA.eh.pres == NOTPRSNT) ||
                   (!message.m.facAccept.callRefA.callId.val))
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no callRef in facAccept \n"));  
                  siDropMsg(mBuf);
                  RETVALUE(ROK);
               }
               callRef = message.m.facAccept.callRefA.callId.val;
               break;
#endif /* if SS7_CHINA */
            default:
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "FACREQ  : invalid switch %#x\n", siIntfCb->cfg.swtch));  
               siDropMsg(mBuf);
               RETVALUE(ROK);
         }
         break;
      case MI_USR2USR:
         /* no CallRef in received message */
         switch (siIntfCb->cfg.swtch)
         {
#if SS7_ITU97
           case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
           case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
           case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
           case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added China variant */	 
#if SS7_CHINA
         case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
           case LSI_SW_ITU:
               if ((message.m.usr2Usr.callRef.eh.pres == NOTPRSNT) ||
                   (!message.m.usr2Usr.callRef.callId.val))
               {
                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no callRef in usr2usr   \n"));  
                  siDropMsg(mBuf);
                  RETVALUE(ROK);
               }
               callRef = message.m.usr2Usr.callRef.callId.val;
               break;
            default:
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "USR2USR : invalid switch %#x\n", siIntfCb->cfg.swtch));  
               siDropMsg(mBuf);
               RETVALUE(ROK);
               break;
         }
         break;
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                                "Unknown PDU (idx = %#x) received, dropped\n",
                                sCb->mfMsgCtl.msgIdx));
         siDropMsg(mBuf);
         RETVALUE(ROK);
   }
   /* find connection */
   siFindInst(&siCb.conHlCp, &siCon, (SiInstKey *) &callRef);
   if (siCon == NULLP)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                            "Can not allocate a connection block\n")); 

      siDropMsg(mBuf);
      RETVALUE(ROK);
   }
   if (opc == siCon->incC.phyDpc)
      cirId = siCon->incC.cir->cfg.cirId;
   else
      cirId = siCon->outC.cir->cfg.cirId;

   siCon->pduSp = &message;

   /* jump into state matrix */
   siActDat(cirId, siCon, sCb->mfMsgCtl.msgIdx);

   /* release message buffer */
   siDropMsg(mBuf);
   RETVALUE(ROK);
} /* end of SiLiSptUDatInd */


/*
*
*      Fun:   Status Indication
*
*      Desc:  This function provides for an indication of status of the
*             message that could not reach the destination.
*   
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiLiSptStaInd
(
Pst *pst,                   /* bind configuration */
SuId suId,                  /* service user id */
Dpc adr,                    /* point code */
SpUDatEvnt *uData,          /* SCCP Address */
RCause rsnRet,              /* reason returned */
Buffer *mBuf                /* pointer to the data buffer */
)
#else
PUBLIC S16 SiLiSptStaInd(pst, suId, adr, uData, rsnRet, mBuf)
Pst *pst;                   /* bind configuration */
SuId suId;                  /* service user id */
Dpc adr;                    /* point code */
SpUDatEvnt *uData;          /* SCCP Address */
RCause rsnRet;              /* reason returned */
Buffer *mBuf;               /* pointer to the data buffer */
#endif
{
   TRC3(SiLiSptStaInd)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(adr);
   UNUSED(uData);
   UNUSED(rsnRet);

   SIDBGP(DBGMASK_LI, (siCb.init.prntBuf, 
                      "%s\n\nStaInd  : L3 -> L4      SPT intf\n",
                      SI_STR)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI090, (ErrVal) ziCb.protState,
                 "SiUiSptStaInd() failed, ISUP is not active\n");
#endif
      siDropMsg(mBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_LI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   siDropMsg(mBuf);
   RETVALUE(ROK);
} /* end of SiLiSptStaInd */


/*
*
*       Fun:   Coordinated Indication
*
*       Desc:  
*              
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiLiSptCordInd
(
Pst *pst,                  /* Bind Configuration */
SuId suId,                 /* Service User Id */
Ssn aSsn,                  /* Affected Subsystem */
Smi smi                    /* subsystem multiplicity indicator */
)
#else
PUBLIC S16 SiLiSptCordInd(pst, suId, aSsn, smi)
Pst *pst;                  /* Bind Configuration */
SuId suId;                 /* Service User Id */
Ssn aSsn;                  /* Calling Address */
Smi smi;                   /* subsystem multiplicity indicator */
#endif
{
   TRC3(SiLiSptCordInd)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(aSsn);
   UNUSED(smi);

   SIDBGP(DBGMASK_LI, (siCb.init.prntBuf, 
                      "%s\n\nCordInd : L3 -> L4      SPT intf\n",
                      SI_STR)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI091, (ErrVal) ziCb.protState,
                 "SiUiSitCordInd() failed, ISUP is not active\n");
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_LI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   RETVALUE(ROK);
} /* end of SiLiSptCordInd */


/*
*
*       Fun:   Coordinated Confirmation
*
*       Desc:  
*              
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiLiSptCordCfm
(
Pst *pst,                  /* Bind Configuration */
SuId suId,                 /* Service User Id */
Ssn aSsn,                  /* Affected Subsystem */
Smi smi                    /* subsystem multiplicity indicator */
)
#else
PUBLIC S16 SiLiSptCordCfm(pst, suId, aSsn, smi)
Pst *pst;                  /* Bind Configuration */
SuId suId;                 /* Service User Id */
Ssn aSsn;                  /* Calling Address */
Smi smi;                   /* subsystem multiplicity indicator */
#endif
{
   TRC3(SiLiSptCordCfm)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(aSsn);
   UNUSED(smi);

   SIDBGP(DBGMASK_LI, (siCb.init.prntBuf,
                       "%s\n\nCordCfm : L3 -> L4      SPT intf\n",
                       SI_STR)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI092, (ErrVal) ziCb.protState,
                 "SiUiSptCordCfm() failed, ISUP is not active\n");
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_LI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   RETVALUE(ROK);
} /* end of SiLiSptCordCfm */


/*
*
*       Fun:   State Indication
*
*       Desc:  
*              
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiLiSptSteInd
(
Pst *pst,                  /* Bind Configuration */
SuId suId,                 /* Service User Id */
Dpc aDpc,                  /* affected destination point code */
Ssn aSsn,                  /* Affected Subsystem */
UStat uStat,               /* user status */
Smi smi                    /* subsystem multiplicity indicator */
)
#else
PUBLIC S16 SiLiSptSteInd(pst, suId, aDpc, aSsn, uStat, smi)
Pst *pst;                  /* Bind Configuration */
SuId suId;                 /* Service User Id */
Dpc aDpc;                  /* affected destination point code */
Ssn aSsn;                  /* affected subsystem number */
UStat uStat;               /* user status */
Smi smi;                   /* subsystem multiplicity indicator */
#endif
{
   TRC3(SiLiSptSteInd)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(aDpc);
   UNUSED(aSsn);
   UNUSED(uStat);
   UNUSED(smi);

   SIDBGP(DBGMASK_LI, (siCb.init.prntBuf, 
                      "%s\n\nSteInd  : L3 -> L4      SPT intf\n",
                      SI_STR)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI093, (ErrVal) ziCb.protState,
                 "SiUiSptSteInd() failed, ISUP is not active\n");
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_LI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   RETVALUE(ROK);
} /* end of SiLiSptSteInd */


/*
*
*       Fun:   PC State Indication
*
*       Desc:  
*              
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiLiSptPCSteInd
(
Pst *pst,                  /* Bind Configuration */
SuId suId,                 /* Service User Id */
Dpc aDpc,                  /* affected destination point code */
Sps sps                    /* signalling point status */
)
#else
PUBLIC S16 SiLiSptPCSteInd(pst, suId, aDpc, sps)
Pst *pst;                  /* Bind Configuration */
SuId suId;                 /* Service User Id */
Dpc aDpc;                  /* affected destination point code */
Sps sps;                   /* signalling point status */
#endif
{
   TRC3(SiLiSptPCSteInd)
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(aDpc);
   UNUSED(sps);

   SIDBGP(DBGMASK_LI, (siCb.init.prntBuf,
                      "%s\n\nPCSteInd L3 -> L4      SPT intf\n",
                      SI_STR)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI094, (ErrVal) ziCb.protState,
                 "SiUiSptPCSteInd() failed, ISUP is not active\n");
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_LI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   RETVALUE(ROK);
} /* end of SiLiSptPCSteInd */
#endif


/*
*     interface functions to layer management
*/


/*
*
*      Fun:   Configuration Request
*
*      Desc:  This function is used by the Layer Management to
*             configure the layer. The layer will only
*             accept a Connect Request on a SAP after it has been
*             configured.
*
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiMiLsiCfgReq
(
Pst     *pst,
SiMngmt *cfg           /* configuration */
)
#else
PUBLIC S16 SiMiLsiCfgReq(pst, cfg)
Pst     *pst;
SiMngmt *cfg;          /* configuration */
#endif
{
   Pst rpst;
#if (SI_LMINT3 || SMSI_LMINT3)
   U8  reason;
#endif

   TRC3(SiMiLsiCfgReq)

   if (cfg == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "pointer to configuration strutcure is NULLP"));  

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI095, (ErrVal) 0, 
                 "SiMiLsiCfgReq() Failed, invalid config pointer");
#endif
     RETVALUE(RFAILED);
   }

   SIDBGP(DBGMASK_MI, (siCb.init.prntBuf,
          "%sSiMiLsiCfgReq(cfg->hdr{ent=%#x, inst=%#x, msgType=%#x, \
          elmnt=%#x})", SI_STR, cfg->hdr.entId.ent, cfg->hdr.entId.inst,
          cfg->hdr.msgType, cfg->hdr.elmId.elmnt)); 

   siBldReplyPst(&rpst, &cfg->hdr, pst);

   /* validate message parameters */
   if ((cfg->hdr.entId.ent != siCb.init.ent)   ||   /* entity id */
       (cfg->hdr.entId.inst != siCb.init.inst) ||   /* instance id */
       (cfg->hdr.msgType != TCFG))               /* message type */
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                             "(ent, nst, msgType) = (%#x, %#x, %#x)\n",
                             cfg->hdr.entId.ent, cfg->hdr.entId.inst,
                             cfg->hdr.msgType));  

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI096, (ErrVal) 0, 
                 "SiMiLsiCfgReq() Failed, invalid header");
#endif

#ifdef SI_LMINT3
      /* initialize the reason value */
      reason = LCM_REASON_INVALID_PAR_VAL;

      if (cfg->hdr.entId.ent != siCb.init.ent)
         reason = LCM_REASON_INVALID_ENTITY;
      else if (cfg->hdr.entId.inst != siCb.init.inst)
         reason = LCM_REASON_INVALID_INSTANCE;
      else if (cfg->hdr.msgType != TCFG)
         reason = LCM_REASON_INVALID_MSGTYPE;

#endif
      SISNDLSICFGCFM(&rpst, cfg, LCM_PRIM_NOK, reason, 0, SIGEN_CFG_NOK);
      RETVALUE(RFAILED);
   }

   switch (cfg->hdr.elmId.elmnt)
   {
      case STGEN:       /* general */
         siCfgGen(&rpst, cfg);
         break;

      case STISAP:       /* isup SAP */
         siCfgISAP(&rpst, cfg);
         break;

      case STNSAP:       /* network sap configuration */
         siCfgNSAP(&rpst, cfg);
         break;

      case STICIR:         /* circuit configuration */
         siCfgSiCirCb(&rpst, cfg);
         break;

#ifdef SI_218_COMP
      case STROUT:         /* routing configuration */
#if (!(SI_LMINT3 || SMSI_LMINT3))
      case STDELROUT:     /* delete Rout */
#endif
         SIDBGP(DBGMASK_MI, (siCb.init.prntBuf,
         "Routing by ISUP is no longer supported in 2.19 release") ); 
         /* si006.220, MODIFIED: use the hash define LCM_REASON_NOT_APPL
          * instead of 0 
          */
         SISNDLSICFGCFM(&rpst, cfg, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 0, 
                        SIGEN_CFG_OK);
         break;
#endif

      case SI_STINTF:    /* INTF configuration */
         siCfgSiIntfCb(&rpst, cfg);
         break;

      default: /* invalid configuration */
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI097, (ErrVal) cfg->hdr.elmId.elmnt, 
                    "SiMiLsiCfgReq() Failed, invalid request");
#endif

         SISNDLSICFGCFM(&rpst, cfg, LCM_PRIM_NOK, LCM_REASON_INVALID_ELMNT,
                        0, SIGEN_CFG_NOK);
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* end of SiMiLsiCfgReq */


/*
*
*      Fun:   Status Request
*
*      Desc:  This function is used by the Layer Management to
*             gather solicited status information.
*
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiMiLsiStaReq
(
Pst *pst,
SiMngmt *sta           /* status */
)
#else
PUBLIC S16 SiMiLsiStaReq(pst, sta)
Pst *pst;
SiMngmt *sta;          /* status */
#endif
{
   Pst rpst;
#if (SI_LMINT3 || SMSI_LMINT3)
   U8  reason;
#endif

   TRC3(SiMiLsiStaReq)

   if (sta == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "pointer to status strutcure is NULLP"));  

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI098, (ErrVal) 0, 
                 "SiMiLsiStaReq() Failed, invalid status pointer");
#endif
     RETVALUE(RFAILED);
   }

   SIDBGP(DBGMASK_MI, (siCb.init.prntBuf,
          "%sSiMiLsiStaReq(cfg->hdr{ent=%#x, inst=%#x, msgType=%#x, \
          elmnt=%#x})", SI_STR, sta->hdr.entId.ent, sta->hdr.entId.inst,
          sta->hdr.msgType, sta->hdr.elmId.elmnt)); 

   siBldReplyPst(&rpst, &sta->hdr, pst);

   if (!siCb.init.cfgDone)
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "SiMiLsiStaReq() Failed, gen config not done\n"));
      SISNDLSISTACFM(&rpst, sta, LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE,
                     0, SI_STA_NOK);
      RETVALUE(RFAILED);
   } 

   /* validate message parameters */
   if ((sta->hdr.entId.ent != siCb.init.ent)   ||   /* entity id */
       (sta->hdr.entId.inst != siCb.init.inst) ||   /* instance id */
       (sta->hdr.msgType != TSSTA))              /* message type */
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI099, (ErrVal) 0, 
                 "SiMiLsiStaReq() Failed, invalid header");
#endif

#if (SI_LMINT3 || SMSI_LMINT3)
      /* initialize the reason value */
      reason = LCM_REASON_INVALID_PAR_VAL;

      if (sta->hdr.entId.ent != siCb.init.ent)
         reason = LCM_REASON_INVALID_ENTITY;
      else if (sta->hdr.entId.inst != siCb.init.inst)
         reason = LCM_REASON_INVALID_INSTANCE;
      else if (sta->hdr.msgType != TSSTA)
         reason = LCM_REASON_INVALID_MSGTYPE;

#endif
      SISNDLSISTACFM(&rpst, sta, LCM_PRIM_NOK, reason, 0, SI_STA_NOK);
      RETVALUE(RFAILED);
   }

   SGetDateTime(&sta->t.ssta.dt);

   /* collect status here */
   switch (sta->hdr.elmId.elmnt)
   {
#if (SI_LMINT3 || SMSI_LMINT3)
      case STSID:
         siGetSId(&sta->t.ssta.cfm.s.sid);
         sta->cfm.status = LCM_PRIM_OK;
         SiMiLsiStaCfm(&rpst, sta);
         break;

      case SI_STCIRGRP:
         siStaCirGr(&rpst, sta);
         break;

      case SI_STINTF:
         {
            SiIntfCb *intfCb;
         
            /* If the interface does not exist, its state is changed to 
             * unequipped, and a successful confirmation is returned when  
             * LSI_PARAMETER is defined. 
             */
#ifndef LSI_PARAMETER
            if (siFindIntf(&intfCb, sta->t.ssta.elmntId.intfId, 0, 0, 0, 0, 
                           SIINTF_KEY_1) == RFAILED)
            {
               sta->cfm.status = LCM_PRIM_NOK;
               sta->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
               SiMiLsiStaCfm(&rpst, sta);
               RETVALUE(RFAILED);
            }

            sta->t.ssta.cfm.s.intf.state = intfCb->state;
#else
            if (siFindIntf(&intfCb, sta->t.ssta.elmntId.intfId, 0, 0, 0, 0, 
                           SIINTF_KEY_1) == RFAILED)
               intfCb = NULLP;

            if (intfCb)
               sta->t.ssta.cfm.s.intf.state = intfCb->state;
            else
               sta->t.ssta.cfm.s.intf.state = SI_INTF_UNEQUIP;
#endif
                                                    
            sta->cfm.status = LCM_PRIM_OK;
            sta->cfm.reason = LCM_REASON_NOT_APPL;
            SiMiLsiStaCfm(&rpst, sta);
         }
         break;
#else
      case STICIR:      /* circuit */
         SIDBGP(DBGMASK_MI, (siCb.init.prntBuf, "STICIR : circuit  \n")); 
         siStaSiCirCb(&rpst, sta);
         break;

#endif /* (SI_LMINT3 || SMSI_LMINT3) */

      /* si006.220, MODIFIED: remove the flag SI_RUG */
      /* si001.220, ADDED: Changes for rolling upgrade */
      case STNSAP:
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "STNSAP: lower SAP \n"));   
         siStaNSAP(&rpst, sta);
         break;
      
      case STISAP:
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "STISAP: upper SAP \n"));   
         siStaUpSAP(&rpst, sta);
         break;

     default:/* invalid status request */
         SIDBGP(DBGMASK_MI, (siCb.init.prntBuf, 
                "invalid status request  \n")); 
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI100, (ErrVal) 0, 
                    "SiMiLsiStaReq() Failed, invalid header");
#endif
         SISNDLSISTACFM(&rpst, sta, LCM_PRIM_NOK, LCM_REASON_INVALID_ELMNT, 
                         sta->hdr.elmId.elmnt, SI_STA_NOK);
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of SiMiLsiStaReq */


/*
*
*      Fun:   Statistics Request
*
*      Desc:  This function is used by the Layer Management to
*             gather solicited statistics information.
*
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiMiLsiStsReq
(
Pst     *pst,
Action  action,           /* action */
SiMngmt *sts              /* statistics */
)
#else
PUBLIC S16 SiMiLsiStsReq(pst, action, sts)
Pst     *pst;
Action  action;           /* action */
SiMngmt *sts;             /* statistics */
#endif
{
#if (SI_LMINT3 || SMSI_LMINT3)
   U8  reason;
#endif
   Pst rpst;

   TRC3(SiMiLsiStsReq)

   if (sts == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "pointer to statistics strutcure is NULLP"));  

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI101, (ErrVal) 0, 
                 "SiMiLsiStaReq() Failed, invalid statistics pointer");
#endif
     RETVALUE(RFAILED);
   }

   SIDBGP(DBGMASK_MI, (siCb.init.prntBuf,
         "%sSiMiLsiStsReq(action=%#x, cfg->hdr{ent=%#x, inst=%#x, \
msgType=%#x, elmnt=%#x})",
                      SI_STR,
                      action,
                      sts->hdr.entId.ent,
                      sts->hdr.entId.inst,
                      sts->hdr.msgType,
                      sts->hdr.elmId.elmnt) ); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI102, (ErrVal) ziCb.protState,
                 "SiMiLsiStsReq() failed, ISUP is not active\n");
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_MI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   siBldReplyPst(&rpst, &sts->hdr, pst);

   if (!siCb.init.cfgDone)
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                             "SiMiLsiStsReq() Failed, gen config not done\n"));
      SISNDLSISTSCFM(&rpst, sts, LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE,
                     action, 0, SI_STS_NOK);
      RETVALUE(RFAILED);
   } 

   /* validate message parameters */
   if ((sts->hdr.entId.ent != siCb.init.ent)   ||   /* entity id */
       (sts->hdr.entId.inst != siCb.init.inst) ||   /* instance id */
       (sts->hdr.msgType != TSTS)           ||   /* message type */
       (action > NOZEROSTS))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI103, (ErrVal) 0, 
                 "SiMiLsiStsReq() Failed, invalid header");
#endif

#if (SI_LMINT3 || SMSI_LMINT3)
      /* initialize the reason value */
      reason = LCM_REASON_INVALID_PAR_VAL;

      if (sts->hdr.entId.ent != siCb.init.ent)
         reason = LCM_REASON_INVALID_ENTITY;
      else if (sts->hdr.entId.inst != siCb.init.inst)
         reason = LCM_REASON_INVALID_INSTANCE;
      else if (sts->hdr.msgType != TSTS)
         reason = LCM_REASON_INVALID_MSGTYPE;
#endif
      SISNDLSISTSCFM(&rpst, sts, LCM_PRIM_NOK, reason, action, 0, SI_STS_NOK);
      RETVALUE(RFAILED);
   }

   SGetDateTime(&sts->t.sts.dt);

   switch (sts->hdr.elmId.elmnt)
   {
      case STICIR:       /* circuit error counters */
         siStsSiCirCb(&rpst, action, sts);
         break;

#if (SI_LMINT3 || SMSI_LMINT3)

      case STGEN:        /* layerwide error counters */
         siStsGen(&rpst, action, sts);
         break;

      case SI_STINTF:
         siStsSiIntfCb(&rpst, action, sts);
         break;

#else /* !(SI_LMINT3 || SMSI_LMINT3) */

      case STNSAP:       /* network SAP */
         siStsNSAP(&rpst, action, sts);
         break;

#endif/* !(SI_LMINT3 || SMSI_LMINT3) */

      default: /* invalid statistic request */
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI104, (ErrVal) 0, 
                    "SiMiLsiStsReq() Failed, invalid header");
#endif
         SISNDLSISTSCFM(&rpst, sts, LCM_PRIM_NOK, LCM_REASON_INVALID_ELMNT,
                        action, sts->hdr.elmId.elmnt, SI_STS_NOK);

         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of SiMiLsiStsReq */


/*
*
*      Fun:   Control Request
*
*      Desc:  This function is used by the Layer Management to
*          control asynchronous port.
*   
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  ci_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiMiLsiCntrlReq
(
Pst     *pst,
SiMngmt *cntrl           /* control */
)
#else
PUBLIC S16 SiMiLsiCntrlReq(pst, cntrl)
Pst     *pst;
SiMngmt *cntrl;          /* control */
#endif
{
   Pst rpst;
#if (SI_LMINT3 || SMSI_LMINT3)
   U8  reason;
#endif
#ifdef ZI
   /* si006.220, MODIFIED: change to boolean value */
   Bool  stbyAllwd;   /* Whether primitive is allowed in standby */
#endif

   TRC3(SiMiLsiCntrlReq)

   SIDBGP(DBGMASK_MI, (siCb.init.prntBuf,
       "%sSiMiLsiCntrlReq(cfg->hdr{ent=%#x, nst=%#x, msgType=%#x, elmnt=%#x, \
subaction=%#x, ction%#x})",
                      SI_STR, 
                      cntrl->hdr.entId.ent,
                      cntrl->hdr.entId.inst,
                      cntrl->hdr.msgType,
                      cntrl->hdr.elmId.elmnt,
                      cntrl->t.cntrl.subAction,
                      cntrl->t.cntrl.action) ); 

#ifdef ZI
   /* si006.220, MODIFIED: changed code to allow the control request
    * on deleting object and shutting down layer on both active and
    * standby copy
    */
   stbyAllwd = FALSE;
   if (cntrl->t.cntrl.subAction == SAELMNT) /* specified element */
      stbyAllwd = TRUE;

   if ( (ziCb.protState != ACTIVE) && (stbyAllwd == FALSE))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI105, (ErrVal) ziCb.protState,
                 "SiMiLsiCntrlReq() failed, ISUP is not active\n");
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_MI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   siBldReplyPst(&rpst, &cntrl->hdr, pst);

   /* si006.220, MODIFIED: return a successful confirmation if the 
    * configuration is not done. This is because of TCR21 to support
    * the repeated shut down control request.
    * For other actions, should be done after conguration finished
    */
   if (!siCb.init.cfgDone)
   {  
      if (cntrl->t.cntrl.action != ASHUTDOWN)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "Gen config not done, element cntrl request failed\n"));
         SISNDLSICNTRLCFM(&rpst, cntrl, LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE,
                       0, SI_CNTRL_NOK);
         RETVALUE(RFAILED);
      }
      else
      {
         /* return a successful confirmation for repeated shutdown */
         SISNDLSICNTRLCFM(&rpst, cntrl, LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                       0, SI_CNTRL_OK);
         RETVALUE(ROK);
      }
   } 

   /* validate message parameters */
   if ((cntrl == NULLP) ||
       (cntrl->hdr.entId.ent != siCb.init.ent)   ||   /* entity id */
       (cntrl->hdr.entId.inst != siCb.init.inst) ||   /* instance id */
       (cntrl->hdr.msgType != TCNTRL))             /* message type */
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI106, (ErrVal) 0, 
                 "SiMiLsiCntrlReq() Failed, invalid header");
#endif

#if (SI_LMINT3 || SMSI_LMINT3)
      if (cntrl == NULLP)
         reason = LCM_REASON_INVALID_PAR_VAL;
      else if (cntrl->hdr.entId.ent != siCb.init.ent)
         reason = LCM_REASON_INVALID_ENTITY;
      else if (cntrl->hdr.entId.inst != siCb.init.inst)
         reason = LCM_REASON_INVALID_INSTANCE;
      else if (cntrl->hdr.msgType != TSSTA)
         reason = LCM_REASON_INVALID_MSGTYPE;
#endif
      SISNDLSICNTRLCFM(&rpst, cntrl, LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE,
                       0, SI_CNTRL_NOK);
      RETVALUE(RFAILED);
   }

   switch(cntrl->t.cntrl.subAction)
   {
      case SAELMNT:        /* specified element */
         siCntrlElmnt(&rpst, cntrl);
         break;

#if SI_ACNT
      case SAACNT:        /* accounting */
         siCntrlAcntInd(&rpst, cntrl);
         break;
#endif

      case SAUSTA:        /* unsolicited status */
         siCntrlUstaInd(&rpst, cntrl);
         break;

      case SATRC:        /* trace */
         siCntrlTrcInd(&rpst, cntrl);
         break;

     case SADBG: /* debug mask */
        siCntrlDbg(&rpst, cntrl);
        break;

     default: /* invalid control request */
         SIDBGP(DBGMASK_MI, (siCb.init.prntBuf, "invalid subAction=%#x\n",
                            cntrl->t.cntrl.subAction)); 
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI107, (ErrVal) 0, 
                    "SiMiLsiCntrlReq() Failed, invalid subaction");
#endif
         SISNDLSICNTRLCFM(&rpst, cntrl, LCM_PRIM_NOK, 
                          LCM_REASON_INVALID_SUBACTION, 
                          cntrl->t.cntrl.subAction, SI_CNTRL_NOK);
        RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of SiMiLsiCntrlReq */



#ifdef SI_FTHA
/*
*
*   Fun  :  System agent control Request
*
*   Desc :  Processes system agent control request
*           primitive
*
*   Ret  :  ROK  - ok
*
*   Notes:  None
*
*   File :  si_bdy1.c
*
*
*/

#ifdef ANSI
PUBLIC S16 SiMiShtCntrlReq
(
Pst     *pst,                 /* post structure          */
ShtCntrlReqEvnt *reqInfo      /* system agent control request event */
)
#else
PUBLIC S16 SiMiShtCntrlReq(pst, reqInfo)
Pst     *pst;                 /* post structure   */
ShtCntrlReqEvnt *reqInfo;         /* system agent control request event */
#endif
{

    Pst repPst;            /* reply post structure */
    ProcId dstProcId;
    Ent dstEnt;
    Inst dstInst;
    ShtCntrlCfmEvnt cfmInfo;  /* system agent control confirm event */
    SiNSAPCb  *nCb;
#ifdef IW
    IwCcSap    *cCb;        /* CC-IW SAP Control block pointer */
    IwRmSap    *rCb;
    U32         maxCcSap;     /* Max range of SAPs               */
#else    
    SiUpSAPCb *tCb;
#endif
    S16 i;

    TRC3(SiMiShtCntrlReq)


    /* fill reply pst structure */

    repPst.dstProcId = pst->srcProcId;
    repPst.srcProcId = SFndProcId();

    repPst.dstEnt    = pst->srcEnt;
    repPst.dstInst   = pst->srcInst;
    repPst.srcEnt    = siCb.init.ent;
    repPst.srcInst   = siCb.init.inst;

    repPst.prior     = reqInfo->hdr.response.prior;
    repPst.route     = reqInfo->hdr.response.route;
    repPst.region    = reqInfo->hdr.response.mem.region;
    repPst.pool      = reqInfo->hdr.response.mem.pool;
    repPst.selector  = reqInfo->hdr.response.selector;

    repPst.event     = EVTSHTCNTRLCFM;

      /* fill reply transaction Id */
    cfmInfo.transId = reqInfo->hdr.transId;

     /* check if general configuration done */
   if (!siCb.init.cfgDone)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "Gen config not done, element cntrl request failed\n"));
      cfmInfo.status.status  = LCM_PRIM_NOK;
      cfmInfo.status.reason = LCM_REASON_GENCFG_NOT_DONE;
      SiMiShtCntrlCfm(&repPst, &cfmInfo);
      RETVALUE(RFAILED);
   }


      /* fill status value */
    cfmInfo.status.reason = LCM_REASON_NOT_APPL;
    /* si001.220, ADDED: changes for rollup */
#ifdef SI_RUG
    cfmInfo.reqType = reqInfo->reqType;
#endif /* SI_RUG */

    switch (reqInfo->reqType)
    {
       case SHT_REQTYPE_BND_ENA:   /* system agent control bind enable */

           dstProcId = reqInfo->s.bndEna.dstProcId;
           dstEnt    = reqInfo->s.bndEna.dstEnt.ent;
           dstInst   = reqInfo->s.bndEna.dstEnt.inst;
          switch (reqInfo->s.bndEna.grpType)
          {
             case SHT_GRPTYPE_ALL:
                /* go through all the sap control blocks and start bind  *
                 * enable procedure on those SAPs for which              *
                 * (pst->dstProcId == reqInfo->s.bndEna.dstProcId) && *
                 * (pst->dstEnt == reqInfo->s.bndEna.dstEnt) &&       *
                 * (pst->dstInst == reqInfo-.s.bndEna.dstInst)        */

                for (i=0; i< siCb.genCfg.nmbNSaps; i++)
                {
                   if (((nCb = SIMTPSAP(i)) != NULLP) &&
                        (nCb->pst.dstProcId == dstProcId) &&
                        (nCb->pst.dstEnt == dstEnt) &&
                        (nCb->pst.dstInst == dstInst))
                   {
#ifdef SI_RUG
                      /* Bind cannot be performed in SAP does not have valid 
                       * remote interface version i.e. version sync not done
                       * If the first
                       * The SAPs in this group should have the same version
                       * info. If the first SAP has invalid version info, the 
                       * rest of them will have it too, and vice versa 
                       */
                      if (nCb->remIntfValid == FALSE)
                      {
                         cfmInfo.status.reason = LCM_REASON_SWVER_NAVAIL;
                         break;
                      }
#endif /* SI_RUG */
                      if (nCb->contEntity != ENTSM)
                      {
                         siBindMTPSAP(nCb);
#ifdef ZI
                         ziRunTimeUpd(ZI_MTP3SAP_CB, CMPFTHA_UPD_REQ,
                                      (PTR) nCb);
#endif /* ZI */
                      }   
                   }
                }

#ifdef SI_SPT
                for (i=0; i< siCb.genCfg.nmbNSaps; i++)
                {
                   if (((nCb = SISCCPSAP(i)) != NULLP) &&
                        (nCb->pst.dstProcId == dstProcId) &&
                        (nCb->pst.dstEnt == dstEnt) &&
                        (nCb->pst.dstInst == dstInst))
                   {
#ifdef SI_RUG
                      /* Bind cannot be performed in SAP does not have valid 
                       * remote interface version i.e. version sync not done
                       * If the first
                       * The SAPs in this group should have the same version
                       * info. If the first SAP has invalid version info, the 
                       * rest of them will have it too, and vice versa 
                       */
                      if (nCb->remIntfValid == FALSE)
                      {
                         cfmInfo.status.reason = LCM_REASON_SWVER_NAVAIL;
                         break;
                      }
#endif /* SI_RUG */
                      if (nCb->contEntity != ENTSM)
                      {
                         siBindSCCPSAP(nCb);
#ifdef ZI
                         ziRunTimeUpd(ZI_SCCPSAP_CB, CMPFTHA_UPD_REQ,
                                      (PTR) nCb);
#endif /* ZI */
                      }   
                   }
                }
#endif 

                /* process for RM sap */
#ifdef IW

                if (((rCb = IWGETRMSAP(0)) != NULLP) &&
                    (rCb->pst.dstProcId == dstProcId) &&
                    (rCb->pst.dstEnt == dstEnt) &&
                    (rCb->pst.dstInst == dstInst))
                {
                   if (rCb->contEntity != ENTSM)
                   {
                      rCb->state = IW_BND_CONT;
                      iwStartRmSapTmr((PTR)rCb, TMR_TBNDCFM);
                      IwLiRmtBndReq(&rCb->pst, rCb->suId, rCb->spId);
#ifdef ZI
                      ziRunTimeUpd(ZI_IWRMSAP_CB, CMPFTHA_UPD_REQ, (PTR)rCb);
#endif
                   }
                }

#endif  /* IW */

                break;

             case SHT_GRPTYPE_ENT:
                /* go through all the sap control blocks and start bind  *
                 * enable procedure on those SAPs for which              *
                 * (pst->dstEnt == reqInfo->s.bndEna.dstEnt) &&       *
                 * (pst->dstInst == reqInfo-.s.bndEna.dstInst)        */

                /* call function for all SAPs */

                for (i=0; i< siCb.genCfg.nmbNSaps; i++)
                {
                   if (((nCb = SIMTPSAP(i)) != NULLP) &&
                        (nCb->pst.dstEnt == dstEnt) &&
                        (nCb->pst.dstInst == dstInst))
                   {
#ifdef SI_RUG
                      /* Bind cannot be performed in SAP does not have valid 
                       * remote interface version i.e. version sync not done
                       * If the first
                       * The SAPs in this group should have the same version
                       * info. If the first SAP has invalid version info, the 
                       * rest of them will have it too, and vice versa 
                       */
                      if (nCb->remIntfValid == FALSE)
                      {
                         cfmInfo.status.reason = LCM_REASON_SWVER_NAVAIL;
                         break;
                      }
#endif /* SI_RUG */
                      if (nCb->contEntity != ENTSM)
                      {
                         siBindMTPSAP(nCb);
#ifdef ZI
                         ziRunTimeUpd(ZI_MTP3SAP_CB, CMPFTHA_UPD_REQ, 
                                      (PTR) nCb);
#endif /* ZI */
                      }
                   }
                }

#ifdef SI_SPT
                for (i=0; i< siCb.genCfg.nmbNSaps; i++)
                {
                   if (((nCb = SISCCPSAP(i)) != NULLP) &&
                        (nCb->pst.dstEnt == dstEnt) &&
                        (nCb->pst.dstInst == dstInst))
                   {
#ifdef SI_RUG
                      /* Bind cannot be performed in SAP does not have valid 
                       * remote interface version i.e. version sync not done
                       * If the first
                       * The SAPs in this group should have the same version
                       * info. If the first SAP has invalid version info, the 
                       * rest of them will have it too, and vice versa 
                       */
                      if (nCb->remIntfValid == FALSE)
                      {
                         cfmInfo.status.reason = LCM_REASON_SWVER_NAVAIL;
                         break;
                      }
#endif /* SI_RUG */
                      if (nCb->contEntity != ENTSM)
                      {
                         siBindSCCPSAP(nCb);
#ifdef ZI
                         ziRunTimeUpd(ZI_SCCPSAP_CB, CMPFTHA_UPD_REQ, 
                                      (PTR) nCb);
#endif /* ZI */
                      }   
                   }
                }
#endif  /* SI_SPT */                
#ifdef IW

                if (((rCb = IWGETRMSAP(0)) != NULLP) &&
                    (rCb->pst.dstEnt == dstEnt) &&
                    (rCb->pst.dstInst == dstInst))
                {  
                   if (rCb->contEntity != ENTSM)
                   {
                      rCb->state = IW_BND_CONT;
                      iwStartRmSapTmr((PTR)rCb, TMR_TBNDCFM);
                      IwLiRmtBndReq(&rCb->pst, rCb->suId, rCb->spId);
#ifdef ZI
                      ziRunTimeUpd(ZI_IWRMSAP_CB, CMPFTHA_UPD_REQ, (PTR)rCb);
#endif
                   }
                }

#endif  /* IW */

                break;

             default:
                cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
                break;
          }
          break;

       case SHT_REQTYPE_UBND_DIS:  /* system agent control unbind disable */

          dstProcId = reqInfo->s.ubndDis.dstProcId;
          dstEnt    = reqInfo->s.ubndDis.dstEnt.ent;
          dstInst   = reqInfo->s.ubndDis.dstEnt.inst;
          
          /* si001.220, ADDED: Changes for ISUP rollup */
#ifdef SI_RUG
          /* Delete the stored version information for that SAP 
           * Loop in the stored version information store and 
           * delete all version information entries to that dest
           */
          for(i = siCb.numIntfInfo - 1; i >= 0; i--)
          {
             if(siCb.intfInfo[i].grpType == reqInfo->s.ubndDis.grpType)
             {
                switch(siCb.intfInfo[i].grpType)
                {
                   case SHT_GRPTYPE_ALL:
                      if (siCb.intfInfo[i].dstProcId == dstProcId &&
                          siCb.intfInfo[i].dstEnt.ent == dstEnt &&
                          siCb.intfInfo[i].dstEnt.inst == dstInst)
                      {
#ifdef ZI
                         /* Delete the stored interface versin block at the 
                          * standby
                          */
                         ziRunTimeUpd(ZI_VERINFO_CB, CMPFTHA_ACTN_DEL, 
                                      (PTR)&siCb.intfInfo[i]);
#endif /* ZI */
                         /* delete the stored version information by copying the
                          * last version info into current location 
                          */
                         cmMemcpy((U8*) &siCb.intfInfo[i],
                                  (U8*) &siCb.intfInfo[siCb.numIntfInfo-1],
                                  sizeof(ShtVerInfo));
                         siCb.numIntfInfo--;
                      }
                      break;
 
                   case SHT_GRPTYPE_ENT:
                      if (siCb.intfInfo[i].dstEnt.ent == dstEnt &&
                          siCb.intfInfo[i].dstEnt.inst == dstInst)
                      {
#ifdef ZI
                         /* Delete the stored interface versin block at the 
                          * standby
                          */
                         ziRunTimeUpd(ZI_VERINFO_CB, CMPFTHA_ACTN_DEL, 
                                      (PTR)&siCb.intfInfo[i]);
#endif /* ZI */
                         /* delete the version information by copying the
                          * last version info into current location 
                          */
                         cmMemcpy((U8*) &siCb.intfInfo[i],
                                  (U8*) &siCb.intfInfo[siCb.numIntfInfo-1],
                                  sizeof(ShtVerInfo));
                         siCb.numIntfInfo--;
                      }
                      break;

                    default:
                       cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
                       break;

                } /* switch siCb.numIntfInfo */
             } /* end of if siCb.numIntfInfo */
          } /* for (i = 0) */
#endif /* SN_RUG */

          switch (reqInfo->s.ubndDis.grpType)
          {
             case SHT_GRPTYPE_ALL:
                /* go through all the sap control blocks and start unbind *
                 * disable procedure on those SAPs for which              *
                 * (pst->dstProcId == reqInfo->s.ubndDis.dstProcId) && *
                 * (pst->dstEnt == reqInfo->s.ubndDis.dstEnt) &&       *
                 * (pst->dstInst == reqInfo-.s.ubndDis.dstInst)        */

                /* call function for all SAPs */
                /* unbind for all saps - upper and lower saps */

#ifdef IW
                maxCcSap = (iwCp.maxNmbCcEnt * iwCp.maxNmbSwtch * LIW_MAX_NT);
                for (i = 0; i < (Cntr) maxCcSap; i++)
                {
                   cCb = IWGETCCSAP(i);

                   /* if CC SAP exists and dstprocid matches */
                   if ((cCb) &&
                       (cCb->pst.dstProcId == dstProcId) &&
                       (cCb->pst.dstEnt == dstEnt)       &&
                       (cCb->pst.dstInst == dstInst))
                   {
                      /* Disable the SAP and clear the connections
                       * associated with it.
                       */
                      iwUbndDisCcSap(cCb);
                      /* Sap state is made unbound in iwUbndDisCcSap */
                   }
                }
#else    /* If only ISUP is available, then process on basis of
          * ISUP's upper SAP.
          */
                for (i = 0; i < (Cntr) siCb.genCfg.nmbSaps; i++)
                {
                   if ( ((tCb = SIUPSAP(i)) != NULLP) &&
                       (tCb->pst.dstProcId == dstProcId) &&
                       (tCb->pst.dstEnt == dstEnt)       &&
                       (tCb->pst.dstInst == dstInst))
                   {
                      /* si001.220, ADDED: Mark the remote intf version as 
                       * invalid on SAP being unbound
                       */
#ifdef SI_RUG
                      tCb->remIntfValid = FALSE;
#endif
                        tCb->state = SI_UNBND;
                        siRelUpSAPCon(tCb);
#ifdef ZI
                      ziRunTimeUpd(ZI_UPSAP_CB, CMPFTHA_UPD_REQ,
                                   (PTR) tCb);
#endif /* ZI */
                   }
                }
#endif /* IW */

                /* disbale for lower - mtp , sccp saps */

                for (i=0; i< siCb.genCfg.nmbNSaps; i++)
                {
                   if (((nCb = SIMTPSAP(i)) != NULLP) &&
                       (nCb->pst.dstProcId == dstProcId) &&
                       (nCb->pst.dstEnt == dstEnt) &&
                       (nCb->pst.dstInst == dstInst))
                   {
                      if (nCb->contEntity != ENTSM)
                      {
                         nCb->state = SI_UNBND;
                         siRelNSAPCon(nCb);
#ifdef ZI
                         ziRunTimeUpd(ZI_MTP3SAP_CB, CMPFTHA_UPD_REQ, 
                                     (PTR) nCb);
#endif

                      }
                   }
                }

#ifdef SI_SPT
                for (i=0; i< siCb.genCfg.nmbNSaps; i++)
                {
                   if (((nCb = SISCCPSAP(i)) != NULLP) &&
                       (nCb->pst.dstProcId == dstProcId) &&
                       (nCb->pst.dstEnt == dstEnt) &&
                       (nCb->pst.dstInst == dstInst))
                   {
                      if (nCb->contEntity != ENTSM)
                      {
                         nCb->state = SI_UNBND;
                         siRelNSAPCon(nCb);
#ifdef ZI
                         ziRunTimeUpd(ZI_SCCPSAP_CB, CMPFTHA_UPD_REQ, 
                                     (PTR) nCb);
#endif

                      }
                   }
                }
#endif /* SI_SPT */

                /* diable for RM sap */
#ifdef IW

                /* Currently one SAP towards RM is supported */
                rCb = IWGETRMSAP(0); 
                if ((rCb != NULLP) &&
                   (rCb->pst.dstProcId == dstProcId) &&
                   (rCb->pst.dstEnt == dstEnt) &&
                   (rCb->pst.dstInst == dstInst))
                {
                   if (rCb->contEntity != ENTSM)
                   {
                      iwUbndDisRmSap(rCb);
                      /* sby is updated in above */
                   }
                }
#endif /* IW */
                break;

             case SHT_GRPTYPE_ENT:
                /* go through all the sap control blocks and start unbind *
                 * disable procedure on those SAPs for which              *
                 * (pst->dstEnt == reqInfo->s.ubndDis.dstEnt) &&       *
                 * (pst->dstInst == reqInfo-.s.ubndDis.dstInst)        */

                /* call function for all SAPs */
#ifdef IW
                maxCcSap = (iwCp.maxNmbCcEnt * iwCp.maxNmbSwtch * LIW_MAX_NT);
                for (i = 0; i < (Cntr) maxCcSap; i++)
                {
                   cCb = IWGETCCSAP(i);

                   /* if CC SAP exists and dstprocid matches */
                   if ((cCb) &&
                       (cCb->pst.dstEnt == dstEnt) &&
                       (cCb->pst.dstInst == dstInst))

                   {
                      /* Disable the SAP and clear the connections
                       * associated with it.
                       */
                      iwUbndDisCcSap(cCb);
                   }
                }
#else    /* If only ISUP is available, then process on basis of
          * ISUP's upper SAP.
          */
                for (i = 0; i < (Cntr) siCb.genCfg.nmbSaps; i++)
                {
                   if (((tCb = SIUPSAP(i)) != NULLP) &&
                       (tCb->pst.dstEnt == dstEnt) &&
                       (tCb->pst.dstInst == dstInst))
                   {
                      /* si001.220, ADDED: Mark the remote intf version as 
                       * invalid on SAP being unbound
                       */
#ifdef SI_RUG
                      tCb->remIntfValid = FALSE;
#endif
                      tCb->state = SI_UNBND;
                      siRelUpSAPCon(tCb);

#ifdef ZI
                      ziRunTimeUpd(ZI_UPSAP_CB, CMPFTHA_UPD_REQ,
                                   (PTR) tCb);
#endif /* ZI */
                   }
                }
#endif /* IW */


                for (i=0; i< siCb.genCfg.nmbNSaps; i++)
                {
                   if (((nCb = SIMTPSAP(i)) != NULLP) &&
                       (nCb->pst.dstEnt == dstEnt) &&
                       (nCb->pst.dstInst == dstInst))
                   {
                      if (nCb->contEntity != ENTSM)
                      {
                         nCb->state = SI_UNBND;
                         siRelNSAPCon(nCb);
#ifdef ZI
                         ziRunTimeUpd(ZI_MTP3SAP_CB, CMPFTHA_UPD_REQ,
                                        (PTR) nCb);
#endif

                      }
                   }
                }

#ifdef SI_SPT

                for (i=0; i< siCb.genCfg.nmbNSaps; i++)
                {
                   if (((nCb = SISCCPSAP(i)) != NULLP) &&
                       (nCb->pst.dstEnt == dstEnt) &&
                       (nCb->pst.dstInst == dstInst))
                   {
                      if (nCb->contEntity != ENTSM)
                      {
                         nCb->state = SI_UNBND;
                         siRelNSAPCon(nCb);
#ifdef ZI
                         ziRunTimeUpd(ZI_SCCPSAP_CB,
                                      CMPFTHA_UPD_REQ, (PTR) nCb);
#endif

                      }
                   }
                }
#endif /* SI_SPT */
               
                /* disable for RM sap */
#ifdef IW

                /* Currently one SAP towards RM is supported */
                rCb = IWGETRMSAP(0); 
                if ((rCb != NULLP) &&
                    (rCb->pst.dstEnt == dstEnt) &&
                    (rCb->pst.dstInst == dstInst))
                {
                   if (rCb->contEntity != ENTSM)
                   {
                      iwUbndDisRmSap(rCb);
                      /* sby is updated in above */
                   }
                }

#endif /* IW */
                break;

             default:
                cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
                break;
           }
           break;

       /* si001.220, ADDED: Changes for rollup */
#ifdef SI_RUG
       case SHT_REQTYPE_GETVER:      /* system agent get version */
          siGetVer(&cfmInfo.t.gvCfm);
          break;

       case SHT_REQTYPE_SETVER:      /* system agent set version */
          siSetVer(&reqInfo->s.svReq, &cfmInfo.status);
#ifdef ZI
          /* send the interface version to standby */
          if (cfmInfo.status.reason == LCM_REASON_NOT_APPL)
             ziRunTimeUpd(ZI_VERINFO_CB, CMPFTHA_ACTN_MOD, 
                          (PTR)&reqInfo->s.svReq);
#endif /* ZI */
          break;
#endif /* SI_RUG */

          default:
          cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
          break;
    }

    /* response is sent without waiting for bind or unbind to complete */
    /* if we are not able to find any SAP to start bind enable or unbind
       disable, still a sucess response is returned by the protocol layer */

    if (cfmInfo.status.reason != LCM_REASON_NOT_APPL)
       cfmInfo.status.status = LCM_PRIM_NOK;
    else
       cfmInfo.status.status = LCM_PRIM_OK;

#ifdef ZI
    ziUpdPeer();
#endif

    /* send the response */
    SiMiShtCntrlCfm(&repPst, &cfmInfo);
    RETVALUE(ROK);
} /* end SiMiShtCntrlReq */
#endif /* SI_FTHA */


#ifdef SI_UTSI_ENHANCE
/* schubert.zhang add circuit connection state check */
#ifdef SI_CC_CHECK
/*
*
*      Fun:   ISUP Check request
*
*      Desc:  This function provides for an circuit connection state
*             check
*   
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  si_bdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SiUiSitChkReq
(
Pst        *pst,            /* bind configuration */
SpId       spId,            /* service user id */
CirId      circuit,         /* circuit ID code */
U8         cirNum           /* number of circuit */
)
#else
PUBLIC S16 SiUiSitChkReq(pst, spId, circuit, cirNum)
Pst        *pst;            /* bind configuration */
SpId       spId;            /* service user id */
CirId      circuit;         /* circuit ID code */
U8         cirNum;          /* number of circuit */
#endif
{
   SiUpSAPCb    *tCb;
   SiCirCb      *cir;
   SiCirKey     key;
   U8           i;
   SiChkStaEvnt chkStaEvnt;

   TRC3(SiUiSitChkReq)
   UNUSED(pst);

   SIDBGP(DBGMASK_UI, (siCb.init.prntBuf, 
                      "%s\n\nChkReq  :       L4 <- L5\n", SI_STR)); 

#ifdef ZI
   if (ziCb.protState != ACTIVE)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESIXXX, (ErrVal) ziCb.protState,
                 "SiUiSitChkReq() failed, ISUP is not active\n");
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      /* si001.220, MODIFIED: change the initialized flag to TRUE in order to 
       * initalize the UstaDgnVal
       */
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_UI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   if (((tCb = SIUPSAP(spId)) == NULLP) || (tCb->state != SI_BND))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                              (tCb) ? "spId = 0x%x state 0x%x not bound\n":
                                  "spId = 0x%x control block non-existent \n",
                              spId, (tCb) ? tCb->state : 0));

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI021, (ErrVal) spId, 
                 "SiUiSitChkReq() Failed, invalid spId");
#endif
      siInitUstaDgn(LSI_USTA_DGNVAL_SPID, (PTR) &spId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LCM_CAUSE_INV_SAP, TRUE, 
                     (CirId) spId, SIISAP_INV);
      RETVALUE(RFAILED);
   }   

   if ((0 == cirNum) || (cirNum > 32))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "cirNum = %d\n",
                              cirNum));

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESIXXX, (ErrVal) cirNum, 
                 "SiUiSitChkReq() Failed, invalid cirNum");
#endif
      RETVALUE(RFAILED);
   }
   
   chkStaEvnt.cirNum = cirNum;
   for (i = 0; i < cirNum; i++)
   {
     cmMemset((U8 *)&key, 0, sizeof(SiCirKey));
     key.k1.cirId = circuit+i;
     siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CIR);
     if (((SiCirCb *) NULLP != cir) && ((SiCon *) NULLP != cir->siCon))
     {
       if (key.k1.cirId == cir->siCon->incC.cirId)
         chkStaEvnt.conSta[i] = cir->siCon->incC.conState;
       else if (key.k1.cirId == cir->siCon->outC.cirId)
         chkStaEvnt.conSta[i] = cir->siCon->outC.conState;
       else
         chkStaEvnt.conSta[i] = ST_IDLE;
     }
     else
     {
       chkStaEvnt.conSta[i] = ST_IDLE;
     }

     switch (chkStaEvnt.conSta[i])
     {
       case ST_IDLE:
            chkStaEvnt.conSta[i] = SI_CON_STA_IDLE;
            break;

       case ST_WTFORANSWR:
       case ST_ANSWRD:
       case ST_SUSP:
            chkStaEvnt.conSta[i] = SI_CON_STA_STAB;
            break;

       default:
            chkStaEvnt.conSta[i] = SI_CON_STA_TRAN;
            break;
     }
   }

   SiUiSitChkCfm(&tCb->pst, tCb->suId, circuit, &chkStaEvnt);
   RETVALUE(ROK);
} /* end of SiUiSitChkReq */

#endif /* SI_CC_CHECK */
#endif /* SI_UTSI_ENHANCE */

  
/********************************************************************30**
  
         End of file:     ci_bdy1.c@@/main/45 - Wed Jul 25 13:20:30 2001

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  bn    1. initial release
             ---  jrl   2. trillium development system checkpoint (dvs)
                           at version: 1.0.0.0

1.2          ---  bn    1. add ifdef SP around calls to SiLiSptBndReq

1.3          ---  bn    1. add support for ansi

1.4          ---  jrl   1. move portions to ci_bdy5.c

1.5          ---  jrl   1. add ifdef SP around sCb in SiUiSitBndReq

1.6          ---  jrl   1. move siSndMsg from ci_bdy5.c to here

1.7          ---  jrl   1. text changes
             ---  rk    2. miscellaneous changes
             ---  rk    3. add ifdef SP around spt includes

1.8          ---  rk    1. miscellaneous changes

1.9          ---  bn    1. removed struct siBearCfg *siProfTbl from public
                           variable declarations
             ---        2. removed siInit.acnt = TRUE; in control request for
                           case of STICIR/ADISIMM.
             ---        3. initialize cirCtl for BOTHWAY circuits during 
                           circuit configuration.
             ---        4. allow TpUiTptCnStReq without spInstId (in some cases
                           it may not be known yet)
             ---        5. changed validation of suInstId in TpUiTptCnStReq
                           and TpUiTptRelReq

1.10         ---  bn    1. added validation of connection in SiUiSitCnStReq. 


1.11         ---  bn    1. remove timers array and tmrCnt from SiCb

1.12         ---  bn    1. change sicon to siCon in SiUiSitCnStReq

1.13         ---  bn    1. add support for ansi 92.
             ---  bn    2. changed timer routines to common functions.
             ---  bn    3. added include cm5.x and cm5.h.
             ---  bn    4. change return( to RETVALUE(

1.14         ---  bn    1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.15         ---  bn    1. change srvInfo to SSF_NAT for ansi88 and and92 and
                           shift both 6 to the left instead of 4.
             ---  bn    2. added case SN_RMTUSRUNAV to SiLiSntStaInd.

1.16         ---  bn    1. changed to support new interfaces

1.17         ---  bn    1. generate management status and statistic confirm
                           for both loosely and tightly coupled layer manager.
             ---  bn    2. add case for LOOPBCKACK in SiUiSitStaReq.
             ---  fmg   3. removed unused variable i from SiUiSitBndReq
             ---  fmg   4. added brackets in SiMiLsiCfgReq
             ---  bn    5. initialize cbMLstPtr and cbSLstPtr to NULLP during
                           general configuration.

1.18         ---  bn    1. si001.22
             ---  bn    2. added functionality for continuity recheck 
                           procedures
             ---  bn    3. added support for Q.767 and Singapore Telecom.

1.19         ---  bn    1. remove if 1

1.20         ---  bn    1. text changes

1.21         ---  bn    1. si006.23
             ---  bn    2. added Italian Q.767 feature.

1.22         ---  bn    1. text changes
              
1.23         ---  bn    1. chnaged SW_... to LSI_SW_...
             ---  bn    2. miscelenious changes.
              
1.24         ---  bn    1. changed ifdef SP to ifdef SI_SPT.
             ---  bn    2. corrected gcc compile warnings.

1.25         ---  bn    1. removed reinitialization of the cause in case
                           of decode errors in SiLiSntUDatInd.

1.26         ---  bn    1. si001.26 (drop received message when get second
                           IAM in error).
             ---  bn    2. si004.26 (allow outgoing Connection Request to 
                           unblock locally blocked circuits).
             ---  bn    3. removed validation of the circuit profile.
             ---  bn    4. changed LSI_SW_CCITT to LSI_SW_ITU and 
                           LSI_SW_ANSI?? to LSI_SW_ANS??.

1.27         ---  bn    1. removed print statement from general configuration.

1.28         ---  bn    1. necessary recovery actions placed in error scenarios

1.29         ---  bn    1. initialized con->outC.conPrcs in SiUiSitStaReq for
                           the case of conrinuity recheck.
             ---  dm    2. added cast to CirId to 1st parameter in siGenAlarm 
                           function calls

1.30         ---  dm    1. change cirCnt

1.31         ---  dm    1. Corrected typo in SPutSBuf function calls.

1.32         ---  pc    1. added ETSI variant for SI
             ---  bn    2. corrected processing of the message with unknown
                           circuit for ANSI92.
             ---  bn    3. corrected handling of the busy circuit case in
                           SiUiSitConReq.


1.33         ---  bn    1. text change

1.34         ---  dm    1. added GT_FTZ variant for SI
             ---  dm    2. corrected typo in SiMiLsiCfgReq
             ---  dm    3. added segmentation
             ---  dm    4. added TCCRt for ANSI
             ---  dm    5. added defines for PAUSE and RESUME status 
                           indications to call control
             ---  dm    6. fixed typo in SiUiSitUDatInd about facility msgs.
             ---  dm    7. added include cm_ss7.[hx]

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.35         ---      dm   1. corrected typo in SiUiSitStaReq (si00x.210)
             ---      bn   2. changed CfgReq to allow reconfiguration
             ---      ao   3. Moved OPC from general config to upper SAP
                              config
             ---      ao   4. added allocation of statistic buffer for
                              SCCP lower SAP
             ---      ao   5. added opc to siBldUData function call
             ---      ao   6. corrected gcc compile warnings.
             ---      ao   7. added status indication to upper layer for
                              indications from MTP-3
             ---      dm   8. added alarm in SiLiSntStaInd when  a message
                              with invalid CIC has been received (si00x.210).
             ---      dm   9. Added different congestion level indications
 
1.35         ---      ao   1. corrected SiLiSntStaInd was using wrong
                              pointer when sending status indication
             ---      ao   2. changed alarm type in SiMiLsnStsReq from
                              SI_STA_NOK to SI_STS_NOK
             ---      ao   3. added check for connection control block
                              when receiving data from MTP-3
             ---      ao   4. modified SiUiSitStaReq to store suInstId
                              when event is LPA and no suInstId is present
                              in the connection control block 
             ---      ao   5. Added status indication SI_CNTRL_OK when
                              control request is successful.
             ---      ao   6. changed init of calling party number in 
                              SiUiSitConReq when presentation is restricted
             ---      ao   7. If the Circuit is configured for INCOMING or 
                              is in use then Generate StatInd with eventType
                              as REATTMEMP
             ---      ao   8. Fixed problem with errorcheck when reconfigure
                              lower and upper SAP.
             ---      ao   9. Corrected dual seizure method
             ---      rh   10. used ESI108, nstead of ESI051, in STICIR 
                               configuration request in case of incorrect SAP
                           11. proper logerror message added for incorrect 
                               action field in case of SATRC
                           12. In SiUiSitBndReq(), check for upper SAP state 
                               is added.
                           13. added UCIC sending facility for incoming
                               IAM, circuit group and circuit messages from
                               the lower layer.
                           14. Corrections for ISUP router.
             ---      ao   15. Correction in ConReq to handle collision fo
                               ConInd and ConReq.

             ---      aa   16. Correction in StaReq to use tCb instead of con
             ---      rh   17. the alarm sent to layer manager when configuring
                               NSAP before gen config. was wrong
                           18. Changes in SiUiSitConReq() and SiUiSitStaReq()
                               to check if a connection CB already exists before

1.36         ---      ao   1. Added control request to rebind the n/w SAP.
             ---      rh   2. changes for giving priority to outgoing call
                              on a controlling circuit on a CRM collision.
                           3. Changes for PAUSE/RESUME in SiLiSntStaInd() 
                              and SiMiLsiCfgReq()
                           4. added 'uBuf' to upper layer primitives
                           5. Moved siSndMsg() to si_bdy5.c
                           6. text changes
1.36+        si003    ao   1. Fixed problem in initializing clli in 
                              SiMiLsiCfgReq. Length was not set.
             si004    ao   2. Added initialization of relLocation and
                              passOnFlag in config request.
             si007    rh   1. Disabled stopping all timers on the circuit
                              when MTP3 RESUME is received.
             si009    rh   1. added local and remote circuit group to 
                              handle circuit group collision
             si011    ao   2. changed initialization of staEvnt in 
                              the default case of SiUiSitStaReq.

             si013    rs   1. Modified the handling of unexpected messages.
                           2. Added Support for handling message and parameter
                              compatibility procedures.
                           3. Modified the segmentation procedures to handle
                              the case where messages other than Segmenatation
                              message are received before the expiry of the 
                              Segmentation timer.
             si014    ao   1. Removed setting of congestion flag is 
                              SiLiSntStaInd.
1.37         ---      rs   1. Code modifications for DPC control block
                              - modified SiMiLsiCfgReq and SiMiLsiCntrlReq 
                              - changed SiLiSntStaInd to start/stop timers
                                with respect to dpc control block.
                              - Corrected UPT(user part test msg) handling
                              - Added CVT(circuit validation test) procedures
             ---           2. Misc changes
                              - Added SiUiSitUMsgReq primitive to pass umsg. 
                              - removed congest and flwCrntl flags from 
                                circuit control block. 
                              - Rearranged Statistics procedure
                              - corrected some configuration problems 
                              - moved accounting info under SI_ACNT option 
                              - Changed the handling of PAUSE such that after
                                recv first PAUSE from MTP-3, for subsequent
                                pause(s), only status ind and alarm will be
                                sent; "toBeRelsd" flag will not be set and 
                                also no relind will be sent to upper layer.
             ---      rs   3. Replaced errorind with release indication 
                              wherever applicable.
             ---      rs   4. Changes to support unreasonable signalling
                              information.
             ---      rs   5. Modified the handling of overload message. 
                              Timer T3 is started on receiving overload 
                              message and an
                              overload indication sent up to call control.
             ---      rs   6. Change the control request such that when a
                              circuit deletion is requested, a check is made 
                              to determine if circuit group procedure 
                              related to this circuit are in progress.
                              If any circuit group procedures are in progress 
                              and the control request is Forced Del (comes in 
                              elmntInst2), the circuit group control block is 
                              also deallocated.
             ---      rh   1. Changed the layer management primitives
                              to increase modularity.
             ---      rs   1. Changed primitives to get connection control
                              block either from the spInstId or the circuit
                              passed. 

1.37         ---      rh   1. SITVER2 behavior was added for RMTUSRUNAV
                              status indication from MTP-3
                           2. Alarm generation when n/w msg is received and
                              T4 is running
             ---      ym   1. Changes in handling of resume indication 
                              to enable sending RelCfm on getting RLC from
                              the peer.
             ---      rs   1. Removed a check in connection request where
                              circuit passed in connection request was 
                              matched against the outC.cirId which is not
                              initialized yet.
             ---           2. Set the circuit swtch before calling circuit
                              validation procedure.
             ---      ym   1. Change in SiLiSntStaInd , additional check
                              for siCon is added.
             ---      rh   1. Changes to update the protocol switch in
                              circuit control block when MTP-3 pause is
                              received in SITVER2 mode (for CLRDFLT and
                              CLRTRANS actions).
             ---      rh   1. Changes in statistics receive updates
                              for circuit and circuit group PDUs.
 
1.38         ---      ym   1. Modifications for DEBUG prints
             ---      rh   2. LMINT3 support added
             ---      ao   3. Added Russian variant
             ---      rh   4. Move the DPC handling procedures to ci_bdy5.c.
             ---      rh   5. Modified the statistics and Alarm procedures.
             ---      rh   6. Added support for primitive loss for Error
                             Release indications.
1.39         ---      rh   1. Added Bind confirm for upper and lower i/f.
1.39+        ---      ym   1. A check for the calling party category in 
                              the connection request for test calls is 
                              added.And priority of PAM is corrected.
                           2. Cause is properly intialised on getting conreq
                              on an incoming circuit.
                           3. Unrecognised parameters in Rel for ANSI
                              are not dropped.
                           4. In case of loopback ack and usrparta 
                              tcallcb is initialised.
                           5. The remote unequipped state is cleared
                              on getting any message from peer.
             ---      ym   1. Unexpected end of message is handled
                              in SiLiSntUDatInd primitive.
             ---      ym   1. The recommend field in cause parameter is 
                              set to NOTPRSNT.
                           2. The typeCntrl checking on getting CRMReq is
                              corrected.
                           3. The handling of ConReq for ANS92 variant
                              (after getting CRA) is corrected.
                           4. The handling of REL msg with unrecognised 
                              parameter is corrected.
             ---      ym   1. A status indication is generated to CC on 
                              getting any message on the unavailable DPC.
                              This change is under SIT_PARAMETER compile 
                              option as it changes the SIT interface.
             ---      ym   1. Error mapping function is called after 
                              initialisation of the causeDgn structure.
                           2. Unrecognised buffer is made NULLP if it is 
                              deallocated .
                           3. Suspend Indication is handled properly for
                              paused DPC.
                           4. The invocation of siInitUstaDgn function
                              is corrected for the value parameters.
                           5. Use of uninitialised variable is corrected 
                              in SiUiSitStaReq. 
             ---           1. siCir is replaced with cir in SiUiSitSuspReq.
                           2. CVT is handled on an unequipped circuit.
                           3. The #s are started at 1 col.
                           4. The handling of USRPARTA is corrected.
             ---      ym   1. The suInstId is copied from the RelRsp to 
                              give the CCR indication with proper suInstId.
                           2. tCb is defined for the SIT_PARAMETER not 
                              defined in SiLiSntUDatInd.
                           3. Received OPC is used as DPC while sending 
                              CONF/UCIC to the peer.
                           4. siGenAlarmNew is put under LMINT3 options.
                           5. Proper diagnostic is filled on getting invalid
                              message.
                           6. Reattempt indication is generated on getting
                              ConReq after sending RSC.
1.40         ---      ym   1. Changes related to addition of NTT variant in
                              ISUP.
            si026.214 ym   1. The restart begin and end are dumped in the
                              interface function itself as DPC sent by mtp3
                              is invalid.
            si029.214 tz   1. Added code to generate status indication to
                              the layer manager whenever we reset the remote
                              unequipped state of the circuit to IDLE on
                              receiving a message from peer. This change is
                              within SI_RESET_RMTUNEQSTATE compile time flag.
            si030.214 rrb  1. Changed the code to initialize the upper SAP
                              msgCtl.uBuf field to NULLP in the end of all
                              upper interface primitive to avoid accessing
                              stale pointer in case of tightly coupled upper
                              interface.

1.42         ---      dvs  1. miscellaneous chages
1.43         ---      ym   1. NT compilation warnings are removed.

/main/44     ---      rrb  1. Modified code in SiLiSptUDatInd to use the OPC 
                              received in Facility Request message
                              instead of the "dfltOpc" field from SCCP SAP.
                           2. Also removed the sanity check of validating
                              the OPC received in the "call reference"
                              parameter of ISUP message.
            si001.218 tz   1. Changed code so that when the compile time flag
                              SI_RESET_RMTUNEQSTATE is defined, the remotely
                              unequipped circuit states will be removed only
                              when we receive the messages other than CVT, CVR,
                              CQM, CQR and UCIC from the peer.
                           2. Changed code so that the behavior of receiving
                              messages on an unequipped circuit for Bellcore
                              variant is the same as that of ANSI'92. Before
                              this change, the behavior of Bellcore is the same
                              as that of ITU if ANSI'92 is not enabled.
            si002.218 bsp  1. Correction in SiLiSntUDatInd for handling  
                              facility and facility req msg
                           2. Used nmbNSaps, nmbSaps fields of siGenCfg 
                              instead of Saps counter as upper bound when
                              searching for SAP control block in SiLiSntBndCfm,
                              SiLiSptBndCfm.
                           3. Added codes to update the switch type in message
                              control block to the swtich type of the 
                              connection if there exist a connectin in function
                              SiUiSntUDatInd
                      sk   1. Addition for system agent control req 
                              SiMiShtCntrl
             ---      hy   1. Added codes to check the confusion message
                              option flag (cirFlg) for sending CFN for 
                              Bellcore variant in function SiLiSntUDatInd
                           2. Added codes to support LOP message for ITU97, 
                              ETSIV3 variant in SiLiSntUDatInd.
                           3. Added codes to assign the value of xchgType in
                              SiUiSitConReq, SiUiSitCnStReq and SiUiSitConRsp
                           4. Added codes to support receiving PRI and APM 
                              message in SiUiSitUDatInd for ETSI v3 variant.
                           5. Changes to support non-single rate calls.
                           6. Fixed the bugs for checking the non-single rate
                              message on ctrl circuit when spInstId is present 
                              in sit interface primitives.
                           7. Deleted the code for checking if the outgoing 
                              circuit is involved in a non-single rate call 
                              when the spInstId is present in SiUiSitConReq.
                           8. Added code to generate alarms if the siCir is 
                              NULLP when sending CFN from CC with spInstId 
                              presented in SiUiSitStaReq. 
                           9. Changes the code to use the correct field in 
                              siConEvnt for transfer rate fro ANS95
                           10. Call a function siSanChkConEvtCkts() to perform 
                               sanity check of the circuit which allocating
                               conn Cb in funciton SiUiSitConReq.
                     bsp   11. Changed hash define names which were changed 
                               in sit.h to resolve clash between sit.h and int.h
                     hy    12. changes for removal of swtch and ssf field in
                               circuit control block.
                     bsp   13. Removed SITVER2 flag.
                           14. Removed internal router related code.
                     hy    15. Changes for supporting segmentation in ANS92
                               and ANS95
                     bsp   16. Patch propogation related changes.
                               . Corrected a typo error in functrion 
                                 SiUiSitFtzReq.
                               . Next intf control block to be checked even if
                                 ssf, swtch, phydpc does not match
                               . Corrected the function calls to siUpdIntfSts
                                 to be made only with an actual interface id.
                               . Changed the second parameter of siInitUstaDgn.
                                 With the previous parameter, there was a 
                                 possible chance that it could have been 
                                 equal to NULL, which would have caused an 
                                 error
                               . Changed the position of stopping TMR_TRELRSP 
                                 and TMR_TFNLRELRSP in SiUiSitRelRsp
                     hy    17. Remove the checking on receipt of SiUiSitUMsgReq
                               on non-controlling circuit in a non-single rate 
                               conn 
                           18. Remove the #if 1 or #if 0 tags in the file
                           19. Change #if SI_218_COMP to #ifdef SI_218_COMP
                           20. Added code to initialize the staEvnt structure
                               in case of SIT_STA_CONFUSION in SiUiSitStaReq 
                               function
                           21. Additional patch propogation related:
                               . In SiUiSitUMsgReq, get siCir when spInstId is 
                                 a valid value
                               . Added code to SiLiSntUDatInd such that when 
                                 RLC is received, and the circuit state is 
                                 idle, timers T16 & T17, if running, are stopped
                           22. Fixed a bug in SiMiLsiStsReq function. The 
                               msgType in hdr should be TSTS when SI_LMINT3 or
                               SMSI_LMINT3 is defined.
                     sk    1. Update sby after sending bndreq to service
                              provider
                     hy    1. Added a case default on the switch
                              statement in SiUiSitPtCdeStaReq
                           2. Moved the checking of cfg, sta and sts pointer 
                              at the beginning of the function and initialize
                              the reason value to LCM_REASON_INVALID_PAR_VAL
                              in funcition SiMiLsiCfgReq, SiMiLsiStaReq and
                              SiMiLsiStsReq.
                           3. Initialized the congLevel in SiUiSitPtCdeStaReq.
                           4. Modified the code to cast the sayType to U8 when
                              siTrcBuf is called.
                           5. Removed the include of lrm.h.
/main/45     ---      hy    1. Modified SiMiLsiStaReq so that, under
                              LSI_PARAMETER compile flag, if the intf does not
                              exist, its state is changed to unequipped, and a
                              success for the reqest is returned
                           2. Added code to SiLiSntUDatInd such that the
                              connection is  cleared when there were errors 
                              when reassembled the segmented IAM message.
                           3. Made changes to SiUiSntUDatInd such that siTrcBuf
                              is called before CIC is extracted from receivd msg
                           4. Made changes to SiUiSntUDatInd so that the return
                              value of MFDECPDU is only compared against ROK and
                              not MFREOM 
                           5. Deleted the call to SGetMsg in SiUiSitUMsgReq
                              because it is called from SCpyMsgMsg with the
                              same parameters
                     hy    1. Added case for CRA in status request 
                              (SiUiSitStaReq) from call control 
                           2. Added a cause value in outgoing CFN msg when there 
                              is unrecognized parameter in the received msg  
                              in function SiLiSntUDatInd.
                     mm    1. Modified SiLiSntUDatInd to call siGenCirMsg with 
                              the interface valid flag as TRUE when generating
                              a UCIC msg. This is done so that the UCIC stat-
                              tics counter is incremented accordingly
           si001.220 hy    1. Added code to support the request for the version
                              numbers been used on the SAP by LM in function
                              SiMiLsiStaReq.
                           2. Modified code to support rollup in the handling
                              of upper interface bind request in function
                              SiUiSitBndReq.
                           3. Modified code to supprt get version and set 
                              version from system manager in fucntion
                              SiMiShtCntrlReq
                           4. Changed the initialized flag to TRUE when calling
                              siGenAlarmNew within ZI hash define.
                           5. Added the initialization of cir in function
                              SiUiSitRelReq.
           si003.220 mm    1. In SiLiSntUDatInd, added code in initialize cause/
                              diagnositic element part in case that the value of 
                              ret1 falls into MFCCINVINFOEL for ANSI and Bellcore.
                           2. On receipt of user part available or any other message,
                              the status indication should return SIMTP_RMTUSRAV if
                              t4Runing is TRUE, and should return SIMTP_RESUME if
                              t4Runing is FALSE.
           si005.220 mm    1. In function SiUiSitConReq, SiUiSitConRsp, SiUiSitRelRsp,
                              SiUiSitDatReq, SiUiSitResmReq, SiUisitFacReq and
                              SiUiSitFacRsp, Modified code to return RFAILED if 
                              con->tCallCb is NULLP.
           si006.220 hy    1. In SiMiLsiCfgReq, use hash define 
                              LCM_REASON_NOT_APPL instead of 0 when returning
                              a successful confirmation.
                           2. In SiMiLsiCntrlReq, modified code to allow the 
                              deletion on the standby copy and repeated 
                              shutdown layer request.
                           3. In SiMiLsiStaReq, removed flag SI_RUG to support
                              query on SAP other than the version related info.
           si007.220 mm    1. In function SiLiSntUDatInd modified code so that when 
                              intfId is not found, dpc is sent in alarm to layer
                              manager. Otherwise intfId is sent instead.
           si009.220 hy    1. In function SiLiSntUDatInd, modified code to 
                              provide valid interface id when calling function
                              siGenCirMsg to send the UCIC message.
                           2. In function SiLiSntUDatInd, added code to process
                              circuit resume procedure if previous receiving 
                              MTP-STATUS primitive with cause "user part 
                              unavailable-inaccessible remote user" for ITU97
                              or ETSIV3 variants.
                     mm    3. In function SiUiSitUMsgReq and SiLiSntUDatInd
                              modified code so that cic could be passed into
                              function siGetLnkSel.
           si012.220 km    1. In function SiLiSntUDatInd added code to drop mBuf
                              when interface is not found and return RFAILED
           si013.220 km    1. In function SiUiSitUMsgReq added code to drop 
                              mBuf when an unrecognized message cannot be
                              copied into it succussfully
                           2. In function SiLiSntUDatInd added code to drop
                              mBuf if siGenPslg didn't generate passalong msg
           si014.220 km    1. For a COT related message, changed the location 
                              of getting an instance in SiUiSitStaReq. The new
                              location only assigns an instance when a 
                              connection control block does does not exist
           si016.220 tz    1. Modified code to add NULLP check for siStaEvnt
                              in SitStaReq before dereference.
           si018.220 tz    1. Modified code to assign intfId  a valid value
                              intfflg TRUE such that in the TX statistics
                              CNF and CVT counters are updated.
           si023.220 tz    1. Added statement to set noRspFlgToLw.
           si024.220 tz    1. Deleted CAK generation in ISUP for SINGTEL.
                           2. Modified code so that LOP message should be processed
                              even if there is no parameters.
           si025.220 tz    1. Modified arguments in siGetLnkSel call.
           si029.220 tz    1. Added INDIA flag and switch where applicable.
           si034220  rk    1. Added CHINA flag and switch where applicable.
           si039.220 rk    1. SILOGERROR not correct in functions SiUiSitConReq,
                              SiUiSitConRsp, SiUiSitCnStReq, SiUiSitRelRsp, 
                              SiUiSitResmReq. It always used SiUiSitBndReq.
                              Respective functions relaced for SILOGERROR
                           2. For SprntMsg, DBG4 flag was being used.
                              Changed it to DBG5 flag.
           si042.220 bn    1. Added ITU2000 and Russian 2000 ISUP variants.
           si045.220 ng    1. Added a check for configuration bit
           si046.220 ng    1. DELETION : No action on receiving the IAM on unequiped circuit 
           si047.220   ng   1. Proper pointer type passed in SFndLenMsg
           si052.220 rk    1  UPU Interface state changes. While processing UCIC msg,
                              intf state made available and stop T4 timer
           si053.220 vp    1  Modified to indicate the proper type in 
                              generating alarm
	  si054.220 vp     1 Added Code to update error counter
	  si055.220 vp     1 Changed NULL to NULLP
*********************************************************************91*/
