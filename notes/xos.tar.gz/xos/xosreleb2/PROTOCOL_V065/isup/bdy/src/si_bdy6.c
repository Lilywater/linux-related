/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

    Name:     ISUP - body 6

    Type:     C source file

    Desc:     C source code for ISUP Layer Management internal functions
              supplied by Trillium. These functions are called by Layer
              Management primitives supplied in ci_bdy1.c and other ISUP
              internal structures to update ISUP layer management related
              structures.

    File:     ci_bdy6.c

    Sid:      ci_bdy6.c@@/main/10 - Wed Jul 25 13:20:56 2001

    Prg:      rh

*********************************************************************21*/


/************************************************************************

     Note: 

     This file has been extracted to support the following options:

     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif

************************************************************************/


/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.             description
*     --------    ----------------------------------------------
*
*/


/* header include files (.h) */

#include "envopt.h"        /* environment options                          */  
#include "envdep.h"        /* environment dependent                        */
#include "envind.h"        /* environment independent                      */

#include "gen.h"           /* general layer                                */
#include "ssi.h"           /* system services                              */
#include "cm_ss7.h"        /* general SS7 layer                            */
#include "cm_hash.h"       /* hash-list header                             */
#include "lsi.h"           /* layer management                             */
#include "si_mf.h"         /* message functions                            */
#include "cm5.h"           /* timers                                       */
#include "ci_db.h"         /* ISUP data base                               */
#include "sit.h"           /* ISUP                                         */
#include "snt.h"           /* MTP3                                         */
#ifdef SI_SPT
#include "spt.h"           /* SCCP                                         */
#endif
#ifdef SI_FTHA
#include "sht.h"           /* sht interface */
#endif
#include "si.h"            /* ISUP                                         */
#include "si_err.h"        /* ISUP error                                   */
#ifdef IW
#include "cm_atm.h"          /* common ATM defines                 */
#include "cm_cc.h"           /* Common Call Control Hash Defs      */
#include "rmt.h"             /* resource manager defines           */
#include "cct.h"             /* Call Control Interface Header      */
#include "liw.h"             /* ISUP PSIF Layer Management Headers */
#include "iw.h"              /* ISUP PSIF Hash Defines             */
#include "iw_err.h"          /* ISUP PSIF Error Defines            */
#include "iw_ptli.h"         /* o/g SIT i/f funcs. hash defs       */
#endif

#ifdef ZI
#include "cm_pftha.h"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.h"       /* common PSF */
#include "cm_psfft.h"      /* common PSF */
#endif
#include "lzi.h"           /* ISUP PSF management */
#include "zi.h"            /* ISUP PSF */
#include "zi_err.h"        /* ISUP PSF error codes */
#endif /* ZI */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer                                */
#include "ssi.x"           /* system services                              */
#include "cm_ss7.x"        /* general SS7 layer                            */
#include "cm_lib.x"        /* common library functions                     */
#include "cm_hash.x"       /* hash-list structure                          */
#include "lsi.x"           /* layer management                             */
#include "si_mf.x"         /* message functions                            */
#include "cm5.x"           /* timers                                       */
#include "ci_db.x"         /* ISUP data base                               */
#include "sit.x"           /* ISUP                                         */
#include "snt.x"           /* MTP3                                         */
#ifdef SI_SPT
#include "spt.x"           /* SCCP                                         */
#endif
#ifdef SI_FTHA
#include "sht.x"           /* sht interface */
#endif
#include "si.x"            /* ISUP                                         */

#ifdef IW
#include "cm_atm.x"          /* common ATM defines                  */
#include "cm_cc.x"           /* Common Call Control Typedefs        */
#include "rmt.x"             /* resource manager function decls.    */
#include "cct.x"             /* Call Control Interface              */
#include "liw.x"             /* ISUP PSIF Layer Management typedefs */
#include "iw.x"              /* ISUP PSIF Typedefs                  */
#endif
#ifdef ZI
#include "cm_pftha.x"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.x"       /* common PSF */
#include "cm_psfft.x"      /* common PSF */
#endif
#include "lzi.x"           /* ISUP PSF management */
#include "zi.x"            /* ISUP PSF */
#endif /* ZI */


/* local defines */


/* local externs */
PRIVATE S16 siInitHlCp ARGS((Void)); /* initialize hash lists during gen cfg */
PRIVATE S16 siRegInitTmr ARGS((Void));  /* initialize timers during gen cfg. */

PRIVATE S16 siCntrlSiCirCb    ARGS((Pst *pst, SiMngmt *cntrl));
PRIVATE S16 siCntrlNSAP       ARGS((Pst *pst, SiMngmt *cntrl));
PRIVATE S16 siCntrlSiIntfCb    ARGS((Pst *pst, SiMngmt *cntrl));
PRIVATE S16 siCntrlSiCirGrpCb ARGS((Pst *pst, SiMngmt *cntrl));

/* si006.220, ADDED: added function prototype used in force block of 
 * circuits
 */
#if (SI_LMINT3 || SMSI_LMINT3)
PRIVATE S16 siCntrlForBlkCirGr ARGS((Pst *pst, SiMngmt *cntrl));
#endif

/* forward references */


/* public variable declarations */


/* support functions */


/*
*
*       Fun:   siInitHlCp
*
*       Desc:  Initialize hash table structures in ISUP during general config.
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PRIVATE S16 siInitHlCp
(
Void
)
#else
PRIVATE S16 siInitHlCp()
#endif
{
   TRC3(siInitHlCp)

   /* initialising the interface hash list for key 1 : intf id */
   /* si030.220: Modification - changed the bin size from 
    * siCb.genCfg.nmbIntf to SI_HSH_LST_SIZ, and key type from 
    * DEF to U32MOD to get better search performance.
    */
   if (cmHashListInit(&siCb.intfHlCp.k1Cp, SI_HSH_LST_SIZ,
                           SIOFFSETOF(SiIntfCb, hlk1), (Bool) FALSE,
                              (U16) CM_HASH_KEYTYPE_U32MOD,
                                 siCb.init.region, siCb.init.pool) !=
                                       ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Hash list init for interface for k1Cp failed\n"));  
#if (ERRCLASS & ERRCLS_ADD_RES)
      SILOGERROR(ERRCLS_ADD_RES, ESI752, (ErrVal) 0,
                 "siInitHlCp(): hashlist init for intf k1Cp failed");
#endif 
      RETVALUE(RFAILED);
   }

   /* initialising the interface hash list for key 2 : dpc, NT, opc, swtch */
   /* si030.220: Modification - changed the bin size from 
    * siCb.genCfg.nmbIntf to SI_HSH_LST_SIZ, and key type from 
    * DEF to ANY to get better search performance.
    */
   if (cmHashListInit(&siCb.intfHlCp.k2Cp, SI_HSH_LST_SIZ,
                           SIOFFSETOF(SiIntfCb, hlk2), (Bool) FALSE,
                              (U16) CM_HASH_KEYTYPE_ANY,
                                 siCb.init.region, siCb.init.pool) !=
                                       ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Hash list init for interface for k2Cp failed\n"));  
      /* deinit intf control block hash list on key 1 */
      cmHashListDeinit(&siCb.intfHlCp.k1Cp);
#if (ERRCLASS & ERRCLS_ADD_RES)
      SILOGERROR(ERRCLS_ADD_RES, ESI753, (ErrVal) 0,
                 "siInitHlCp(): hashlist init for intf k2Cp failed");
#endif 
      RETVALUE(RFAILED);
   }

 
   /* initialising the interface hash list for key 3 : dpc, NT, swtch */
   /* note that multiple entries are possible in this hash list */
   /* si030.220: Modification - changed the bin size from 
    * siCb.genCfg.nmbIntf to SI_HSH_LST_SIZ, and key type from 
    * DEF to ANY to get better search performance.
    */
   if (cmHashListInit(&siCb.intfHlCp.k3Cp, SI_HSH_LST_SIZ,
                           SIOFFSETOF(SiIntfCb, hlk3), (Bool) TRUE,
                              (U16) CM_HASH_KEYTYPE_ANY,
                                 siCb.init.region, siCb.init.pool) !=
                                       ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Hash list init for interface for k3Cp failed\n"));  
      /* deinit intf control block hash list on key 1 */
      cmHashListDeinit(&siCb.intfHlCp.k1Cp);
      /* deinit intf control block hash list on key 2 */
      cmHashListDeinit(&siCb.intfHlCp.k2Cp);
#if (ERRCLASS & ERRCLS_ADD_RES)
      SILOGERROR(ERRCLS_ADD_RES, ESI754, (ErrVal) 0,
                 "siInitHlCp(): hashlist init for intf k3Cp failed");
#endif 
      RETVALUE(RFAILED);
   }

   /* hash list based on circuit id for the circuits */
   /* si030.220: Modification - changed key type from 
    * DEF to U32MOD to get better search performance.
    */
   if (ROK != cmHashListInit(&siCb.cirHlCp.chCp, SI_HSH_LST_SIZ, 
                             SIOFFSETOF(SiCirCb, chl), FALSE, 
                             CM_HASH_KEYTYPE_U32MOD, siCb.init.region, siCb.init.pool))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "cmHashListInit failed\n"));  
      /* deinit intf control block hash list on key 1 */
      cmHashListDeinit(&siCb.intfHlCp.k1Cp);
      /* deinit intf control block hash list on key 2 */
      cmHashListDeinit(&siCb.intfHlCp.k2Cp);
      /* deinit intf control block hash list on key 3 */
      cmHashListDeinit(&siCb.intfHlCp.k3Cp);
#if (ERRCLASS & ERRCLS_ADD_RES)
      SILOGERROR(ERRCLS_ADD_RES, ESI755, (ErrVal) RFAILED,
                 "SIINITHlCp(): cmHashListInit() for circuit id failed");
#endif 
      RETVALUE(RFAILED);
   }
   /* hash list based on cic + dpc for the circuits */
   /* si030.220: Modification - changed key type from 
    * DEF to ANY to get better search performance.
    */
   if (ROK != cmHashListInit(&siCb.cirHlCp.ichCp, SI_HSH_LST_SIZ, 
                             SIOFFSETOF(SiCirCb, ichl), FALSE, 
                             CM_HASH_KEYTYPE_ANY, siCb.init.region, siCb.init.pool))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "cmHashListInit failed\n"));  

#if (ERRCLASS & ERRCLS_ADD_RES)
      SILOGERROR(ERRCLS_ADD_RES, ESI756, (ErrVal) RFAILED,
                 "SIINITHlCp(): cmHashListInit() for cic and dpc failed");
#endif 
      cmHashListDeinit(&siCb.cirHlCp.chCp);
      /* deinit intf control block hash list on key 1 */
      cmHashListDeinit(&siCb.intfHlCp.k1Cp);
      /* deinit intf control block hash list on key 2 */
      cmHashListDeinit(&siCb.intfHlCp.k2Cp);
      /* deinit intf control block hash list on key 3 */
      cmHashListDeinit(&siCb.intfHlCp.k3Cp);
      RETVALUE(RFAILED);
   }
   /* hash list based on dpc for the circuits */
   /* si030.220: Modification - changed key type from 
    * DEF to U32MOD to get better search performance.
    */
   if (ROK != cmHashListInit(&siCb.cirHlCp.ihCp, SI_HSH_LST_SIZ, 
                             SIOFFSETOF(SiCirCb, ihl), TRUE, 
                             CM_HASH_KEYTYPE_U32MOD, siCb.init.region, siCb.init.pool))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "cmHashListInit failed\n"));  

#if (ERRCLASS & ERRCLS_ADD_RES)
      SILOGERROR(ERRCLS_ADD_RES, ESI757, (ErrVal) RFAILED,
                 "SIINITHlCp(): cmHashListInit() for dpc failed");
#endif 
      cmHashListDeinit(&siCb.cirHlCp.ichCp);
      cmHashListDeinit(&siCb.cirHlCp.chCp);
      /* deinit intf control block hash list on key 1 */
      cmHashListDeinit(&siCb.intfHlCp.k1Cp);
      /* deinit intf control block hash list on key 2 */
      cmHashListDeinit(&siCb.intfHlCp.k2Cp);
      /* deinit intf control block hash list on key 3 */
      cmHashListDeinit(&siCb.intfHlCp.k3Cp);
      RETVALUE(RFAILED);
   }

   /* hash list based on spInstId for the connections */
   /* si030.220: Modification - changed key type from 
    * DEF to U32MOD to get better search performance.
    */
   if (ROK != cmHashListInit(&siCb.conHlCp.instCp, SI_HSH_LST_SIZ, 
                             SIOFFSETOF(SiCon, hl), FALSE, 
                             CM_HASH_KEYTYPE_U32MOD, siCb.init.region, siCb.init.pool))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "cmHashListInit failed\n"));  

#if (ERRCLASS & ERRCLS_ADD_RES)
      SILOGERROR(ERRCLS_ADD_RES, ESI758, (ErrVal) RFAILED,
                 "SIINITHlCp(): siIntfCbHTblInit() failed");
#endif 
      cmHashListDeinit(&siCb.cirHlCp.ihCp);
      cmHashListDeinit(&siCb.cirHlCp.ichCp);
      cmHashListDeinit(&siCb.cirHlCp.chCp);

      /* deinit intf control block hash list on key 1 */
      cmHashListDeinit(&siCb.intfHlCp.k1Cp);
      /* deinit intf control block hash list on key 2 */
      cmHashListDeinit(&siCb.intfHlCp.k2Cp);
      /* deinit intf control block hash list on key 3 */
      cmHashListDeinit(&siCb.intfHlCp.k3Cp);
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK); 
}


/*
*
*       Fun:   SIINITTmr
*
*       Desc:  Register and initialize timer queue structures in 
*              ISUP during general config.
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PRIVATE S16 siRegInitTmr
(
Void
)
#else
PRIVATE S16 siRegInitTmr()
#endif
{
   U16 i;

   TRC3(siRegInitTmr)

   if (ROK != SRegTmr(siCb.init.ent, siCb.init.inst, siCb.genCfg.timeRes, siActvTmr))
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf, "SRegTmr failed\n"));  
#if (ERRCLASS & ERRCLS_ADD_RES)
      SILOGERROR(ERRCLS_ADD_RES, ESI759, (ErrVal) 0,
                 "siRegInitTmr(): SRegTmr() failed");
#endif
      RETVALUE(RFAILED);
   }

   /* initialize timing queues */
   siCb.conTqCp.tmrLen     = TQNUMENT;
   siCb.nsapTqCp.tmrLen    = TQNUMENT;
   siCb.intfCbTqCp.tmrLen   = TQNUMENT;
   siCb.cirTqCp.tmrLen     = TQNUMENT;
   siCb.cirGrpTqCp.tmrLen  = TQNUMENT;
 
   for (i = 0; i < TQNUMENT; i++)
   {
      siCb.conTq[i].first    = NULLP;
      siCb.cirTq[i].first    = NULLP;
      siCb.cirGrpTq[i].first = NULLP;
      siCb.intfCbTq[i].first  = NULLP;
      siCb.nsapTq[i].first   = NULLP;
   }

   RETVALUE(ROK); 
}


/*
*
*       Fun:   siCfgGen
*
*       Desc:  ISUP general configuration
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siCfgGen
(
Pst     *pst,
SiMngmt *cfg
)
#else
PUBLIC S16 siCfgGen (pst, cfg)
Pst     *pst;
SiMngmt *cfg;
#endif
{
   Size siSMemSz;     /* static memory buffer size */
   S16  ret;
   U16  i;

   TRC3(siCfgGen)

#ifndef SI_LMINT3
   UNUSED(pst);
#endif

   /* si001.220, ADDED: Changes for rollup */
#ifdef SI_RUG
   /* validate layer interface version */
   if (cfg->t.cfg.s.siGen.sm.intfVer > LSIIFVER)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
             "Invalid layer interface version %d \n", 
              cfg->t.cfg.s.siGen.sm.intfVer));  
#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESIXXX, 
                 (ErrVal) cfg->t.cfg.s.siGen.sm.intfVer,
                 "SiMiLsiCfgReq() Failed, Invalid layer interface version");
#endif 
      SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_VERSION_MISMATCH,
                     0, SIGEN_CFG_NOK);
      RETVALUE(RFAILED);
   }
#endif /* SI_RUG */

   /* si009.220, ADDED: added check for link selector option */
   /* si025.220: Modification - added LSIV4, remove the
    * check failure action and fill the default value. */
#if (LSIV3 || LSIV4)
   if ((cfg->t.cfg.s.siGen.lnkSelOpt != LSI_LNKSEL_LD_DISTR) &&
      (cfg->t.cfg.s.siGen.lnkSelOpt != LSI_LNKSEL_CIC))
   {
      /* fill default value - load distribution. When SM is using
       * LSIV4, this field may not be filled with valid value, 
       * but general configuration should not fail due to this. */
      cfg->t.cfg.s.siGen.lnkSelOpt = LSI_LNKSEL_LD_DISTR;
   }
#endif /* LSIV3 || LSIV4 */

   if (siCb.init.cfgDone == TRUE)
   {
      siCb.rstTmr                  = FALSE;
      siCb.genCfg.sccpSup          = cfg->t.cfg.s.siGen.sccpSup;
      siCb.genCfg.poolTrUpper      = cfg->t.cfg.s.siGen.poolTrUpper;
      siCb.genCfg.poolTrLower      = cfg->t.cfg.s.siGen.poolTrLower;
 
         /* copy the timer configuration structre to isup genCfg block */
      (Void) cmMemcpy((U8 *) &(siCb.genCfg.cirGrTmr),
                      (U8 *) &(cfg->t.cfg.s.siGen.cirGrTmr),
                      sizeof(SiCirGrTmrCfg));
 
      /* configure layer management post structure */
      siCb.init.lmPst.selector        = cfg->t.cfg.s.siGen.sm.selector;
      siCb.init.lmPst.region          = cfg->t.cfg.s.siGen.sm.region;
      siCb.init.lmPst.pool            = cfg->t.cfg.s.siGen.sm.pool;
      siCb.init.lmPst.prior           = cfg->t.cfg.s.siGen.sm.prior;
      siCb.init.lmPst.route           = cfg->t.cfg.s.siGen.sm.route;
      siCb.init.lmPst.dstProcId       = cfg->t.cfg.s.siGen.sm.dstProcId;
      siCb.init.lmPst.dstEnt          = cfg->t.cfg.s.siGen.sm.dstEnt;
      siCb.init.lmPst.dstInst         = cfg->t.cfg.s.siGen.sm.dstInst;
      siCb.init.lmPst.srcProcId       = siCb.init.procId;
      siCb.init.lmPst.srcEnt          = siCb.init.ent;
      siCb.init.lmPst.srcInst         = siCb.init.inst;
      siCb.init.lmPst.event           = EVTNONE;
/* si009.220 - Addition: added link selector option configuration. */
/* si025.220 - Modification - added LSIV4 */
#if (LSIV3 || LSIV4)     
      siCb.genCfg.lnkSelOpt           = cfg->t.cfg.s.siGen.lnkSelOpt;
#endif  
      /* si001.220, ADDED: fill in the layer intf ver info */
#ifdef SI_RUG
      siCb.init.lmPst.intfVer         = cfg->t.cfg.s.siGen.sm.intfVer;
#endif /* SI_RUG */
   }
   else
   {
      siCb.genCfg.nmbSaps     = cfg->t.cfg.s.siGen.nmbSaps;
      siCb.genCfg.nmbNSaps    = cfg->t.cfg.s.siGen.nmbNSaps;
      siCb.genCfg.nmbCir      = cfg->t.cfg.s.siGen.nmbCir;
      siCb.genCfg.nmbCirGrp   = cfg->t.cfg.s.siGen.nmbCirGrp;
      siCb.genCfg.nmbCalRef   = cfg->t.cfg.s.siGen.nmbCalRef;
      siCb.genCfg.nmbIntf      = cfg->t.cfg.s.siGen.nmbIntf;
      siCb.cirCnt             = 0;
      siCb.rstTmr             = FALSE;
      siCb.lastSpInstId       = 0;
      siCb.genCfg.sccpSup     = cfg->t.cfg.s.siGen.sccpSup;
/* si009.220 - Addition: added link selector option configuration. */
/* si025.220 - Modification - added LSIV4 */
#if (LSIV3 || LSIV4)     
      siCb.genCfg.lnkSelOpt   = cfg->t.cfg.s.siGen.lnkSelOpt;
#endif      
      siCb.genCfg.poolTrUpper = cfg->t.cfg.s.siGen.poolTrUpper;
      siCb.genCfg.poolTrLower = cfg->t.cfg.s.siGen.poolTrLower;
      siCb.genCfg.timeRes     = cfg->t.cfg.s.siGen.timeRes;
 
      siCb.nmbRunCalls        = 0;
      /* copy the timer configuration structre to isup genCfg block */
      (Void) cmMemcpy((U8 *) &(siCb.genCfg.cirGrTmr),
                      (U8 *) &(cfg->t.cfg.s.siGen.cirGrTmr),
                      sizeof(SiCirGrTmrCfg));
 
       /* configure layer management post structure */
       siCb.init.lmPst.selector  = cfg->t.cfg.s.siGen.sm.selector;
       siCb.init.lmPst.region    = cfg->t.cfg.s.siGen.sm.region;
       siCb.init.lmPst.pool      = cfg->t.cfg.s.siGen.sm.pool;
       siCb.init.lmPst.prior     = cfg->t.cfg.s.siGen.sm.prior;
       siCb.init.lmPst.route     = cfg->t.cfg.s.siGen.sm.route;
       siCb.init.lmPst.dstProcId = cfg->t.cfg.s.siGen.sm.dstProcId;
       siCb.init.lmPst.dstEnt    = cfg->t.cfg.s.siGen.sm.dstEnt;
       siCb.init.lmPst.dstInst   = cfg->t.cfg.s.siGen.sm.dstInst;
       siCb.init.lmPst.srcProcId = siCb.init.procId;
       siCb.init.lmPst.srcEnt    = siCb.init.ent;
       siCb.init.lmPst.srcInst   = siCb.init.inst;
       siCb.init.lmPst.event     = EVTNONE;
      /* si001.220, ADDED: fill in the layer intf ver info */
#ifdef SI_RUG
       siCb.init.lmPst.intfVer   = cfg->t.cfg.s.siGen.sm.intfVer;
#endif /* SI_RUG */
 
       siSMemSz = ((Size) siCb.genCfg.nmbSaps * 
                   ( (Size) SBUFSIZE ((Size) sizeof(SiUpSAPCb *)) +
                     (Size) SBUFSIZE ((Size) sizeof(SiUpSAPCb))) ) +

                   ((Size) siCb.genCfg.nmbNSaps *
                    ( (Size) SBUFSIZE ( (Size) (sizeof(SiNSAPCb *) * 2)) +
                      (Size) SBUFSIZE ( (Size) (sizeof(SiNSAPCb) * 2))) ) +
                  (Size) siCb.genCfg.nmbCir *
                  ((Size) SBUFSIZE ((Size) (sizeof(SiCirCb))) +
                   (Size) SBUFSIZE ((Size) (sizeof(SiCirSts)))) +
#if (SI_LMINT3 || SMSI_LMINT3)
                  (siCb.genCfg.nmbIntf *
                   (Size)SBUFSIZE(sizeof(SiIntfSts))) +
#else
                  (Size) siCb.genCfg.nmbNSaps *
                  (Size) SBUFSIZE ((Size) (sizeof(SiNSAPSts))) +
#endif
                  (Size) siCb.genCfg.nmbCirGrp *
                  (Size) SBUFSIZE ((Size) (sizeof(SiCirGrp))) +
                  (Size) siCb.genCfg.nmbCalRef *
                  (Size) SBUFSIZE ((Size) (sizeof(SiCon)))+
                  ((Size)SBUFSIZE((Size)siCb.genCfg.nmbIntf *
                                  sizeof(SiIntfCb *))) +
                  (siCb.genCfg.nmbIntf *
                   (Size)SBUFSIZE(sizeof(SiIntfCb)));

      /* si001.220, ADDED: Added the size for storing the version 
       * information sent by systme manager
       */
#ifdef SI_RUG
      siSMemSz += (Size) SBUFSIZE((Size) (siCb.genCfg.nmbSaps + 
                         siCb.genCfg.nmbNSaps) * 
                         ((Size) SBUFSIZE((Size) sizeof(ShtVerInfo)))); 
       
#endif /* SI_RUG */
      
      /* interface control block hash list size */
      /* three hash lists are maintained for the interface */
      siSMemSz += (Size)SBUFSIZE(((Size)siCb.genCfg.nmbIntf * 
                        CM_HASH_BINSIZE) * 3);
       
      /* circuit control block hash list size */
      /* 3 hash lists are maintained for circuits */
      siSMemSz += (Size)SBUFSIZE(((Size) SI_HSH_LST_SIZ 
                  * CM_HASH_BINSIZE) * 3);
       
      /* dpc control block hash list size */
      siSMemSz += (Size)SBUFSIZE((Size) SI_HSH_LST_SIZ * CM_HASH_BINSIZE);
 
      ret = SGetSMem(siCb.init.region, (Size) siSMemSz, &siCb.init.pool);
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "   SGetSMem   failed   \n"));  
#if (ERRCLASS & ERRCLS_ADD_RES)
         SILOGERROR(ERRCLS_ADD_RES, ESI760, (ErrVal) ret,
                    "SiMiLsiCfgReq() Failed, SGetSMem failed");
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                        0, SIGEN_CFG_NOK);

         RETVALUE(RFAILED);
      }
 
      ret = SGetSBuf(siCb.init.region, siCb.init.pool, (Data **) &siCb.upSAPLst,
                     (Size) (siCb.genCfg.nmbSaps * (sizeof(SiUpSAPCb *))));
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "   SGetSBuf   failed   \n"));  
#if (ERRCLASS & ERRCLS_ADD_RES)
         SILOGERROR(ERRCLS_ADD_RES, ESI761, (ErrVal) ret,
                    "SiMiLsiCfgReq() Failed, SGetSMem failed");
#endif 
         /* return memory before exiting */
         SPutSMem (siCb.init.region, siCb.init.pool);
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                        0, SIGEN_CFG_NOK);
         RETVALUE(RFAILED);
      }
 
      ret = SGetSBuf(siCb.init.region, siCb.init.pool, (Data **) &siCb.mtpSAPLst,
                     (Size) (siCb.genCfg.nmbNSaps * (sizeof(SiNSAPCb *))));
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "   SGetSBuf   failed   \n"));  
#if (ERRCLASS & ERRCLS_ADD_RES)
         SILOGERROR(ERRCLS_ADD_RES, ESI762, (ErrVal) ret,
                    "SiMiLsiCfgReq() Failed, SGetSBuf failed");
#endif 
         /* return memory before exiting */
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.upSAPLst,
                  (Size) (siCb.genCfg.nmbSaps * (sizeof(SiUpSAPCb *))));
         SPutSMem (siCb.init.region, siCb.init.pool);

         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                        0, SIGEN_CFG_NOK);
         RETVALUE(RFAILED);
      }

      ret = SGetSBuf(siCb.init.region, siCb.init.pool, 
                     (Data **) &siCb.sccpSAPLst, 
                     (Size) (siCb.genCfg.nmbNSaps * (sizeof(SiNSAPCb *))));
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                "   SGetSBuf   failed   \n"));  
#if (ERRCLASS & ERRCLS_ADD_RES)
         SILOGERROR(ERRCLS_ADD_RES, ESI763, (ErrVal) ret,
                    "SiMiLsiCfgReq() Failed, SGetSBuf failed");
#endif 
         /* return memory before exiting */
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.upSAPLst,
                  (Size) (siCb.genCfg.nmbSaps * (sizeof(SiUpSAPCb *))));
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)siCb.mtpSAPLst,
                  (Size) (siCb.genCfg.nmbNSaps * (sizeof(SiNSAPCb *))));
         SPutSMem (siCb.init.region, siCb.init.pool);

         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                        0, SIGEN_CFG_NOK);
         RETVALUE(RFAILED);
      }

      /* si001.220, ADDED: Allocate the memory for storing the version 
       * information sent by systme manager
       */
#ifdef SI_RUG
      ret = SGetSBuf(siCb.init.region, siCb.init.pool, (Data **) &siCb.intfInfo,
                     (Size) ((siCb.genCfg.nmbSaps + siCb.genCfg.nmbNSaps) * 
                             (sizeof(ShtVerInfo))));
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                      "   SGetSBuf   failed   \n"));  
#if (ERRCLASS & ERRCLS_ADD_RES)
         SILOGERROR(ERRCLS_ADD_RES, ESI761, (ErrVal) ret,
                    "SiMiLsiCfgReq() Failed, SGetSMem failed");
#endif 
         /* return memory before exiting */
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.upSAPLst,
                  (Size) (siCb.genCfg.nmbSaps * (sizeof(SiUpSAPCb *))));
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.mtpSAPLst,
                  (Size) (siCb.genCfg.nmbNSaps * (sizeof(SiNSAPCb *))));
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.sccpSAPLst,
                  (Size) (siCb.genCfg.nmbNSaps * (sizeof(SiNSAPCb *))));
         SPutSMem (siCb.init.region, siCb.init.pool);
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                        0, SIGEN_CFG_NOK);
         RETVALUE(RFAILED);
      }
#endif /* SI_RUG */

      if (RFAILED == siInitHlCp())
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "siInitHlCp failed\n"));
         /* return memory before exiting */
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.upSAPLst,
                  (Size) (siCb.genCfg.nmbSaps * (sizeof(SiUpSAPCb *))));
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.mtpSAPLst,
                  (Size) (siCb.genCfg.nmbNSaps * (sizeof(SiNSAPCb *))));
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.sccpSAPLst,
                  (Size) (siCb.genCfg.nmbNSaps * (sizeof(SiNSAPCb *))));
         /* si001.220, ADDED: return memory for interface version pointer */
#ifdef SI_RUG
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.intfInfo,
                  (Size) ((siCb.genCfg.nmbSaps + siCb.genCfg.nmbNSaps) * 
                          (sizeof(ShtVerInfo))));
#endif /* SI_RUG */
         SPutSMem (siCb.init.region, siCb.init.pool);

         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_HASHING_FAILED,
                        0, SIGEN_CFG_NOK);

         RETVALUE(RFAILED);
      }

      if (RFAILED == siRegInitTmr())
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "siRegInitTmr failed\n"));  
         /* deinitialize hash lists */
         cmHashListDeinit(&siCb.conHlCp.instCp);  
         cmHashListDeinit(&siCb.cirHlCp.ihCp);
         cmHashListDeinit(&siCb.cirHlCp.ichCp);
         cmHashListDeinit(&siCb.cirHlCp.chCp);
         /* deinit intf control block hash list on key 1 */
         cmHashListDeinit(&siCb.intfHlCp.k1Cp);
         /* deinit intf control block hash list on key 2 */
         cmHashListDeinit(&siCb.intfHlCp.k2Cp);
         /* deinit intf control block hash list on key 3 */
         cmHashListDeinit(&siCb.intfHlCp.k3Cp);
         /* return memory before exiting */
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.upSAPLst,
                  (Size) (siCb.genCfg.nmbSaps * (sizeof(SiUpSAPCb *))));
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.mtpSAPLst,
                  (Size) (siCb.genCfg.nmbNSaps * (sizeof(SiNSAPCb *))));
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.sccpSAPLst,
                  (Size) (siCb.genCfg.nmbNSaps * (sizeof(SiNSAPCb *))));
         /* si001.220, ADDED: return memory for interface version pointer */
#ifdef SI_RUG
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.intfInfo,
                  (Size) ((siCb.genCfg.nmbSaps + siCb.genCfg.nmbNSaps) * 
                          (sizeof(ShtVerInfo))));
#endif /* SI_RUG */
         SPutSMem (siCb.init.region, siCb.init.pool);

         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_REGTMR_FAIL,
                        0, SIGEN_CFG_NOK); 
         RETVALUE(RFAILED);
      }
 
      for (i = 0; i < (U16) siCb.genCfg.nmbSaps; i++)
         *(siCb.upSAPLst + i) = NULLP;
 
      for (i = 0; i < (U16) siCb.genCfg.nmbNSaps; i++)
      {
         *(siCb.mtpSAPLst + i)    = NULLP;
         *(siCb.sccpSAPLst + i)   = NULLP;
      }
 
      siCb.init.cfgDone = TRUE;
   }

   /* send confirmation to the stack manager */
   /* si006.220, MODIFIED: use the hash define LCM_REASON_NOT_APPL
    * instead of 0 
    */
   SISNDLSICFGCFM(pst, cfg, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 0, SIGEN_CFG_OK);
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCfgISAP
*
*       Desc:  Configure/reconfigure upper SAP
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siCfgISAP
(
Pst     *pst,
SiMngmt *cfg 
)
#else
PUBLIC S16 siCfgISAP (pst, cfg)
Pst     *pst;
SiMngmt *cfg; 
#endif
{
   SiUpSAPCb *cb;
   S16       ret;
   U16       i;
   SpId      sapId;

   TRC3(siCfgISAP)

   if (!siCb.init.cfgDone)
   {
#if (ERRCLASS & ERRCLS_INT_PAR) 
      SILOGERROR(ERRCLS_INT_PAR, ESI764, (ErrVal) cfg->hdr.elmId.elmntInst1, 
                 "siCfgISAP(): gen config not done");
#endif

      SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE,
                     0, SIISAP_CFG_NOK);
      RETVALUE(RFAILED);
   }

#if (SI_LMINT3 || SMSI_LMINT3)
   sapId = cfg->t.cfg.s.siSap.sapId;
#else
   sapId = cfg->hdr.elmId.elmntInst1;
#endif

   /* error check on parameters */
   if (sapId >= (S16)siCb.genCfg.nmbSaps)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                             "elmntInst1 %d GE nmbSaps in genCfg %d\n",
                             sapId, siCb.genCfg.nmbSaps));  
#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI765, (ErrVal) sapId,
                 "siCfgISAP(): Invalid STISAP id");
#endif
      SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_EXCEED_CONF_VAL,
                     sapId, SIISAP_CFG_NOK);
      RETVALUE(RFAILED);
   }

   /* si001.220, ADDED: changes for rolling upgrade */
#ifdef SI_RUG
   /* validate interface version */
   if (cfg->t.cfg.s.siSap.remIntfValid == TRUE)
   {
      if (cfg->t.cfg.s.siSap.remIntfVer > SITIFVER)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "Error: Invalid SIT version number %d\n",
                 cfg->t.cfg.s.siSap.remIntfVer));  
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESIXXX, 
                    (ErrVal) cfg->t.cfg.s.siSap.remIntfVer,
                    "siCfgISAP(): Invalid SIT version number");
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, 
                        LCM_REASON_VERSION_MISMATCH, 0, SIISAP_CFG_NOK);
         RETVALUE(RFAILED);
      }
   }
#endif /* SI_RUG */
   cb = SIUPSAP(sapId);

   /* if this is request for a new SAP */
   if (cb == NULLP)
   {
      if (ROK != SGetSBuf(siCb.init.region, siCb.init.pool, (Data **) &cb,
                          (Size) sizeof(SiUpSAPCb)) )
      {
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                               "SGetSBuf() failed, can't allocate SAP Cb\n"));
#if (ERRCLASS & ERRCLS_ADD_RES)
         SILOGERROR(ERRCLS_ADD_RES, ESI766, (ErrVal) 0, 
                    "siCfgISAP(): Failed to allocate buffer for upper SAP");
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                        sapId, SIISAP_CFG_NOK);
         RETVALUE(RFAILED);
      }
      *(siCb.upSAPLst + sapId) = cb;

      /* copy the ssf information */
      cb->cfg.ssf = cfg->t.cfg.s.siSap.ssf;

      /* copy sap configuration parameters */
      switch(cb->cfg.swtch = cfg->t.cfg.s.siSap.swtch)
      {
#ifdef SS7_ITU97
         case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
        case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
        case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
       case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         case LSI_SW_ITU:
            break;
         default:
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                                   "invalid protocol switch %d\n",
                                   cfg->t.cfg.s.siSap.swtch));  
#if (ERRCLASS & ERRCLS_INT_PAR)
            SILOGERROR(ERRCLS_INT_PAR, ESI767, (ErrVal) sapId, 
                       "siCfgISAP(): Invalid STISAP switch");
#endif
            /* return memory before exiting */
            SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) cb,
                     (Size) sizeof(SiUpSAPCb));
            SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_INVALID_PAR_VAL,
                           sapId, SIISAP_CFG_NOK);
            RETVALUE(RFAILED);
      }

      cb->cfg.sidIns         = cfg->t.cfg.s.siSap.sidIns;
      cb->cfg.sidVer         = cfg->t.cfg.s.siSap.sidVer;
      cb->cfg.natAddrInd     = cfg->t.cfg.s.siSap.natAddrInd;
      cb->cfg.sidNPlan       = cfg->t.cfg.s.siSap.sidNPlan;
      cb->cfg.sidPresInd     = cfg->t.cfg.s.siSap.sidPresInd;
      cb->cfg.incSidPresRes  = cfg->t.cfg.s.siSap.incSidPresRes;
      cb->cfg.sidPresRes     = cfg->t.cfg.s.siSap.sidPresRes;
      cb->cfg.reqOpt         = cfg->t.cfg.s.siSap.reqOpt;
      cb->cfg.sid.length     = cfg->t.cfg.s.siSap.sid.length;

      for (i = 0; i < ADRLEN; i++)
         cb->cfg.sid.strg[i] = 0;

      siAscAdrToBcd(&cfg->t.cfg.s.siSap.sid.strg[0], &cb->cfg.sid.strg[0]);

      if (cfg->t.cfg.s.siSap.sid.length & 0x1)
      {
         cb->sidOddEven      = NMB_ODD;
         cb->cfg.sid.length  = (U8) ((cfg->t.cfg.s.siSap.sid.length >> 1) + 
                                        NMB_ODD);
      }
      else
      {
         cb->sidOddEven      = NMB_EVEN;
         cb->cfg.sid.length  = (U8) (cfg->t.cfg.s.siSap.sid.length >> 1);
      }
      cb->cfg.relLocation    = cfg->t.cfg.s.siSap.relLocation;
      cb->cfg.passOnFlag     = cfg->t.cfg.s.siSap.passOnFlag;
      cb->cfg.allCallMod     = cfg->t.cfg.s.siSap.allCallMod;
      cb->cfg.maxLenU2U      = cfg->t.cfg.s.siSap.maxLenU2U;
#if (SI_LMINT3 || SMSI_LMINT3)
      cb->cfg.sapId          = sapId;
#endif

      /* copy the timer configuration structre to isup control block */
      (Void) cmMemcpy((U8 *) &(cb->cfg.tmr), 
                      (U8 *) &(cfg->t.cfg.s.siSap.tmr), sizeof(SiTmrCfg)); 

      cb->suId                  = 0;
      cb->spId                  = sapId;
      cb->state                 = SI_UNBND;

      cb->pst.selector          = cfg->t.cfg.s.siSap.selector;
      cb->pst.region            = cfg->t.cfg.s.siSap.mem.region;
      cb->pst.pool              = cfg->t.cfg.s.siSap.mem.pool;
      cb->pst.prior             = cfg->t.cfg.s.siSap.prior;
      cb->pst.route             = cfg->t.cfg.s.siSap.route;
      cb->pst.dstProcId         = PROCIDNC;
      cb->pst.dstEnt            = ENTNC;
      cb->pst.dstInst           = INSTNC;
      cb->pst.srcProcId         = siCb.init.procId;
      cb->pst.srcEnt            = siCb.init.ent;
      cb->pst.srcInst           = siCb.init.inst;
      cb->pst.event             = EVTNONE;

      /* si001.220, ADDED: changes for rolling upgrade 
       * Please note that remIntfValid and remIntfVer fields
       * in cb->cfg are not used for remote version control
       * within ISUP. Instead it use remIntfValid in cb and
       * remIntfVer in cb->pst
       */
#ifdef SI_RUG
      cb->remIntfValid = FALSE;

      if (cfg->t.cfg.s.siSap.remIntfValid == TRUE)
      {
         cb->remIntfValid = TRUE;
         cb->pst.intfVer = cfg->t.cfg.s.siSap.remIntfVer;
         /* Mark version controlling entity as Layer Manager for 
          * upper SAP if version configuration is done by the LM
          */
         cb->verContEnt = ENTSM; /* version controller is SM */
      }
      else
         cb->verContEnt = ENTNC; /* version controller unknown */
#endif /* SI_RUG */
   }
   else
   {
      /* following parameters are allowed to be reconfigured */
      /* if variant is being changed */
      if (cb->cfg.swtch != cfg->t.cfg.s.siSap.swtch)
      {
         switch(cb->cfg.swtch = cfg->t.cfg.s.siSap.swtch)
         {
            case LSI_SW_ITU:
               break;
#ifdef SS7_ITU97
            case LSI_SW_ITU97:
               break;
#endif
#ifdef SS7_ITU2000
            case LSI_SW_ITU2000:
               break;
#endif
#ifdef SS7_RUSS2000
            case LSI_SW_RUSS2000:
               break;
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
            break;
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
       case LSI_SW_CHINA:
           break;
#endif /* if SS7_CHINA */
             default:
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid STISAP swtch %d\n", cfg->t.cfg.s.siSap.swtch)); 
#if (ERRCLASS & ERRCLS_INT_PAR)
               SILOGERROR(ERRCLS_INT_PAR, ESI768, (ErrVal) sapId,
                           "siCfgISAP(): Invalid STISAP switch");
#endif
               /* return memory before exiting */
               SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) cb,
                          (Size) sizeof(SiUpSAPCb));
               SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, 
                              LCM_REASON_INVALID_PAR_VAL, 0, SIISAP_CFG_NOK);
               RETVALUE(RFAILED);
         }
         /* new bind request is required */
         cb->state = SI_UNBND;
      }
      /* if ssf is changed then SAP is unbound */
      if (cb->cfg.ssf != cfg->t.cfg.s.siSap.ssf)
      {
         cb->cfg.ssf = cfg->t.cfg.s.siSap.ssf;
         cb->state = SI_UNBND;
      }

      cb->cfg.sidIns        = cfg->t.cfg.s.siSap.sidIns;
      cb->cfg.sidVer        = cfg->t.cfg.s.siSap.sidVer;
      cb->cfg.natAddrInd    = cfg->t.cfg.s.siSap.natAddrInd;
      cb->cfg.sidNPlan      = cfg->t.cfg.s.siSap.sidNPlan;
      cb->cfg.sidPresInd    = cfg->t.cfg.s.siSap.sidPresInd;
      cb->cfg.incSidPresRes = cfg->t.cfg.s.siSap.incSidPresRes;
      cb->cfg.sidPresRes    = cfg->t.cfg.s.siSap.sidPresRes;
      cb->cfg.reqOpt        = cfg->t.cfg.s.siSap.reqOpt;
      cb->cfg.sid.length    = cfg->t.cfg.s.siSap.sid.length;

      for (i = 0; i < ADRLEN; i++)
         cb->cfg.sid.strg[i] = 0;
      siAscAdrToBcd(&cfg->t.cfg.s.siSap.sid.strg[0], &cb->cfg.sid.strg[0]);
      if (cfg->t.cfg.s.siSap.sid.length & 0x1)
      {
         cb->sidOddEven        = NMB_ODD;
         cb->cfg.sid.length = (U8) ((cfg->t.cfg.s.siSap.sid.length >> 1) + 
                                        NMB_ODD);
      }
      else
      {
         cb->sidOddEven         = NMB_EVEN;
         cb->cfg.sid.length  = (U8) (cfg->t.cfg.s.siSap.sid.length >> 1);
      }
      cb->cfg.relLocation    = cfg->t.cfg.s.siSap.relLocation;
      cb->cfg.passOnFlag     = cfg->t.cfg.s.siSap.passOnFlag;
      cb->cfg.allCallMod     = cfg->t.cfg.s.siSap.allCallMod;
      cb->cfg.maxLenU2U      = cfg->t.cfg.s.siSap.maxLenU2U;
#if (SI_LMINT3 || SMSI_LMINT3) 
      cb->cfg.sapId          = sapId;
#endif

      /* copy the timer configuration structre to isup control block */
      (Void) cmMemcpy((U8 *) &(cb->cfg.tmr), 
                      (U8 *) &(cfg->t.cfg.s.siSap.tmr), sizeof(SiTmrCfg)); 

      /* These values should be written only when a sap is being 
       * configured or reconfigured and the sap is in unbound state.
       * CCorrect values will be filled when following this configuration
       * binding is done.
       * If the sap is in bound state these values should not be 
       * initialized.
       */
      if (cb->state == SI_UNBND)
      {
         cb->suId                  = 0;
         cb->pst.dstProcId         = PROCIDNC;
         cb->pst.dstEnt            = ENTNC;
         cb->pst.dstInst           = INSTNC;
      }
      cb->spId                  = sapId;
      cb->pst.selector          = cfg->t.cfg.s.siSap.selector;
      cb->pst.region            = cfg->t.cfg.s.siSap.mem.region;
      cb->pst.pool              = cfg->t.cfg.s.siSap.mem.pool;
      cb->pst.prior             = cfg->t.cfg.s.siSap.prior;
      cb->pst.route             = cfg->t.cfg.s.siSap.route;
      cb->pst.srcProcId         = siCb.init.procId;
      cb->pst.srcEnt            = siCb.init.ent;
      cb->pst.srcInst           = siCb.init.inst;
      cb->pst.event             = EVTNONE;

      /* si001.220, ADDED: changes for rolling upgrade */
#ifdef SI_RUG
      if (cfg->t.cfg.s.siSap.remIntfValid == TRUE)
      {
         cb->remIntfValid = TRUE;
         cb->pst.intfVer = cfg->t.cfg.s.siSap.remIntfVer;
      }
#endif /* SI_RUG */
   }

   /* initialize message control */  
   MFINITPROF(&cb->mfCfgProf, ret, NMB_IMSG, NMB_IPRIM, siAllPduDefs, 
              siAllSduDefs, SIT_MF_MAX_REPELMT, (MF_IGNORE | MF_ISUP), 
              NULLP);
   MFINITMSGCTL(&cb->mfMsgCtl, ret, &cb->mfCfgProf, 0);

   /* send confirmation to the stack manager */
   /* si006.220, MODIFIED: use the hash define instead of 0 */
   SISNDLSICFGCFM(pst, cfg, LCM_PRIM_OK, LCM_REASON_NOT_APPL, sapId, 
                  SIISAP_CFG_OK);
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCfgNSAP
*
*       Desc:  Configure/reconfigure a network SAP
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siCfgNSAP
(
Pst     *pst,
SiMngmt *cfg
)
#else
PUBLIC S16 siCfgNSAP(pst, cfg)
Pst     *pst;
SiMngmt *cfg;
#endif
{
   SiNSAPCb   *cb;
   SpId     nsapId;
   S16    ret;
#if (!(SI_LMINT3 || SMSI_LMINT3))
   U8     *buf;
   U16    i;
#endif
   /* si001.220, ADDED: added a local flag for rolling upgrade */
#ifdef SI_RUG
   Bool   found;       /* flag to indicate if the version info is in the 
                        * stored version structure */
   U16    index;
#endif /* SI_RUG */

   TRC3(siCfgNSAP)

   if (!siCb.init.cfgDone)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Configure layer first !     \n"));  
     
#if (ERRCLASS & ERRCLS_INT_PAR) 
      SILOGERROR(ERRCLS_INT_PAR, ESI769, (ErrVal) cfg->hdr.elmId.elmntInst1, 
                 "siCfgNSAP(): gen config not done");
#endif
      SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE,
                     0, SINSAP_CFG_NOK);
      RETVALUE(RFAILED);
   }
#if (SI_LMINT3 || SMSI_LMINT3)
      nsapId = cfg->t.cfg.s.siNSap.nsapId;
#else
      nsapId = (SpId)cfg->hdr.elmId.elmntInst1;
#endif
#ifdef SI_218_COMP
   cfg->t.cfg.s.siNSap.nwId = cfg->t.cfg.s.siNSap.swtch;
#endif
   if ((cfg->t.cfg.s.siNSap.sapType == SAP_MTP) ||
       (cfg->t.cfg.s.siNSap.sapType == SAP_M3UA))
   {
      /* error check on parameters */
      if (nsapId >= (SpId) siCb.genCfg.nmbNSaps)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                                "Error: MTP-3 nsapId (%#x) > %#x\n",
                                nsapId, siCb.genCfg.nmbNSaps));  
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI770, (ErrVal) nsapId,
                    "siCfgNSAP(): Invalid STNSAP id");
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_EXCEED_CONF_VAL,
                        0, SINSAP_CFG_NOK);
         RETVALUE(RFAILED);
      }

      /* si001.220, ADDED: changes for rolling upgrade */
#ifdef SI_RUG
      /* validate interface version */
      if (cfg->t.cfg.s.siNSap.remIntfValid == TRUE)
      {
         if (cfg->t.cfg.s.siNSap.remIntfVer > SNTIFVER)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "Error: Invalid SNT version number %d\n",
                    cfg->t.cfg.s.siNSap.remIntfVer));  
#if (ERRCLASS & ERRCLS_INT_PAR)
            SILOGERROR(ERRCLS_INT_PAR, ESIXXX, 
                       (ErrVal) cfg->t.cfg.s.siNSap.remIntfVer,
                       "siCfgNSAP(): Invalid SNT version number");
#endif
            SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, 
                           LCM_REASON_VERSION_MISMATCH, 0, SINSAP_CFG_NOK);
            RETVALUE(RFAILED);
         }
      }
#endif /* SI_RUG */

      /* if this is a new SAP */
      if (NULLP == (cb = SIMTPSAP(nsapId)))
      {
         if (ROK != SGetSBuf(siCb.init.region, siCb.init.pool, (Data **) &cb,
                             (Size) sizeof(SiNSAPCb)) )
         {
            SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                                  "Can't allocate NSAP block (%#x, %#x)\n",
                                  nsapId, cfg->t.cfg.s.siNSap.sapType));  
#if (ERRCLASS & ERRCLS_ADD_RES)
            SILOGERROR(ERRCLS_ADD_RES, ESI771, (ErrVal) 0, 
                    "SiMiLsiCfgReq() Failed, SGetSBuf failed in STNSAP");
#endif
            SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                           nsapId, SINSAP_CFG_NOK);
            RETVALUE(RFAILED);
         }

#if (!(SI_LMINT3 || SMSI_LMINT3))
         if (SGetSBuf(siCb.init.region, siCb.init.pool, (Data **) &cb->sts,
                        (Size) sizeof(SiNSAPSts)) != ROK)
         {
            SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                 "[LMINT2] Can't allocate NSAP (%#x, %#x) statistics buffer\n",
                                  nsapId, cfg->t.cfg.s.siNSap.sapType));  
#if (ERRCLASS & ERRCLS_ADD_RES)
            SILOGERROR(ERRCLS_ADD_RES, ESI772, (ErrVal) 0, 
                       "SiMiLsiCfgReq() Failed, SGetSBuf failed in STNSAP");
#endif
            /* return memory before exiting */
            SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) cb,
                     (Size) sizeof(SiNSAPCb));

            SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                           nsapId, SINSAP_CFG_NOK);
            RETVALUE(RFAILED);
         }
#endif /* !(SI_LMINT3 || SMSI_LMINT3) */

         *(siCb.mtpSAPLst + nsapId) = cb;
         cb->suId          = nsapId;
         cb->srvInfo       = (U8) (cfg->t.cfg.s.siNSap.ssf << 6);
         cb->srvInfo      |= SI_ISUP;
         cb->trc           = FALSE;
         cb->cfg.nwId      = cfg->t.cfg.s.siNSap.nwId;
         cb->cfg.nsapId    = cfg->t.cfg.s.siNSap.nsapId;
         cb->cfg.ssf       = cfg->t.cfg.s.siNSap.ssf;
         cb->state         = SI_UNBND;
         cb->cfg.sapType   = cfg->t.cfg.s.siNSap.sapType;

         cmMemcpy((U8 *)&cb->cfg.tINT, (U8 *)&cfg->t.cfg.s.siNSap.tINT,
                  sizeof(TmrCfg));

         /* initialize timers */
         cmInitTimers(cb->timers, MAXSIMTIMER);

         /* si001.220, ADDED: changes for rolling upgrade */
#ifdef SI_RUG
          cb->remIntfValid = FALSE;
          if (cfg->t.cfg.s.siNSap.remIntfValid == TRUE)
          {
             cb->remIntfValid = TRUE;
             cb->pst.intfVer = cfg->t.cfg.s.siNSap.remIntfVer;
          }

          /* if the remote ver is not configured by LM, check if we already have
           * the needed information stored in the version structure.
           */
          if (cb->remIntfValid == FALSE)
          {
             found = FALSE;
             for (index = 0; index < siCb.numIntfInfo && found == FALSE; index++)
             {
                if ((siCb.intfInfo[index].intf.intfId == SNTIF) ||
                    (siCb.intfInfo[index].intf.intfId == SPTIF))
                {
                   switch (siCb.intfInfo[index].grpType)
                   {
                      case SHT_GRPTYPE_ALL:
                         if ((siCb.intfInfo[index].dstProcId ==
                              cfg->t.cfg.s.siNSap.dstProcId) &&
                             (siCb.intfInfo[index].dstEnt.ent ==
                              cfg->t.cfg.s.siNSap.dstEnt) &&
                             (siCb.intfInfo[index].dstEnt.inst ==
                              cfg->t.cfg.s.siNSap.dstInst))
                            found = TRUE;
                         break;
                      case SHT_GRPTYPE_ENT:
                         if ((siCb.intfInfo[index].dstEnt.ent ==
                              cfg->t.cfg.s.siNSap.dstEnt) &&
                             (siCb.intfInfo[index].dstEnt.inst ==
                              cfg->t.cfg.s.siNSap.dstInst))
                            found = TRUE;
                         break;
                      default:
                         /* not possible */
                         break;
                   }
                }
             }
             if (found == TRUE)
             {
                cb->pst.intfVer = siCb.intfInfo[index-1].intf.intfVer;
                cb->remIntfValid = TRUE;
             }
          }
#endif /* SI_RUG */
      }
   }
   else
   {
      if (cfg->t.cfg.s.siNSap.sapType == SAP_SCCP)
      {
         if (nsapId >= (SpId)siCb.genCfg.nmbNSaps)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                                   "Error: SCCP nsapId (%#x) > %#x\n",
                                nsapId, siCb.genCfg.nmbNSaps));  
#if (ERRCLASS & ERRCLS_INT_PAR)
            SILOGERROR(ERRCLS_INT_PAR, ESI773, (ErrVal) nsapId,
                       "siCfgNSAP(): Invalid STNSAP id");
#endif
            SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                           0, SINSAP_CFG_NOK);
            RETVALUE(RFAILED);
         }

#ifdef SI_SPT
         /* si001.220, ADDED: changes for rolling upgrade */
#ifdef SI_RUG
         /* validate interface version */
         if (cfg->t.cfg.s.siNSap.remIntfValid == TRUE)
         {
            if (cfg->t.cfg.s.siNSap.remIntfVer > SPTIFVER)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Error: Invalid SPT version number %d\n",
                       cfg->t.cfg.s.siNSap.remIntfVer));  
#if (ERRCLASS & ERRCLS_INT_PAR)
               SILOGERROR(ERRCLS_INT_PAR, ESIXXX, 
                          (ErrVal) cfg->t.cfg.s.siNSap.remIntfVer,
                          "siCfgNSAP(): Invalid SPT version number");
#endif
               SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, 
                              LCM_REASON_VERSION_MISMATCH, 0, SINSAP_CFG_NOK);
               RETVALUE(RFAILED);
            }
         }
#endif /* SI_RUG */
#endif /* SI_SPT */

         /* if this is a new SAP */
         if (NULLP == (cb = SISCCPSAP(nsapId)))
         {
            if (ROK != SGetSBuf(siCb.init.region, siCb.init.pool, (Data **) &cb,
                           (Size) sizeof(SiNSAPCb)) )
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "SGetSBuf failed\n"));  
#if (ERRCLASS & ERRCLS_ADD_RES)
               SILOGERROR(ERRCLS_ADD_RES, ESI774, (ErrVal) 0,
                    "SiMiLsiCfgReq(): SGetSBuf() failed in STNSAP");
#endif
               SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                              nsapId, SINSAP_CFG_NOK);
               RETVALUE(RFAILED);
            }

#if (!(SI_LMINT3 || SMSI_LMINT3))
            ret = SGetSBuf(siCb.init.region, siCb.init.pool, (Data **) &cb->sts,
                           (Size) sizeof(SiNSAPSts));

            if (ret != ROK)
            {
               SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                                     "Can't allocate NSAP block (%#x, %#x)\n",
                                     nsapId, cfg->t.cfg.s.siNSap.sapType));  
#if (ERRCLASS & ERRCLS_ADD_RES)
               SILOGERROR(ERRCLS_ADD_RES, ESI775, (ErrVal) ret,
                          "siCfgNSAP(): SGetSBuf() failed in STNSAP");
#endif
               /* return memory before exiting */
               SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) cb,
                        (Size) sizeof(SiNSAPCb));

               SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                              0, SINSAP_CFG_NOK);
               RETVALUE(RFAILED);
            }
#endif /* (!(SI_LMINT3 || SMSI_LMINT3)) */

            *(siCb.sccpSAPLst + nsapId) = cb;

            cb->suId          = nsapId;
            cb->srvInfo       = (U8) (cfg->t.cfg.s.siNSap.ssf << 6);
            cb->srvInfo      |= SI_ISUP;
            cb->trc           = FALSE;
            cb->cfg.nwId      = cfg->t.cfg.s.siNSap.nwId;
            cb->cfg.ssf       = cfg->t.cfg.s.siNSap.ssf;
            cb->state         = SI_UNBND;
            cb->cfg.sapType   = cfg->t.cfg.s.siNSap.sapType;

            cmMemcpy((U8 *)&cb->cfg.tINT, 
                     (U8 *)&cfg->t.cfg.s.siNSap.tINT, sizeof(TmrCfg));
            /* initialize timers */
            cmInitTimers(cb->timers, MAXSIMTIMER);

            /* si001.220, ADDED: changes for rolling upgrade */
#ifdef SI_RUG
            cb->remIntfValid = FALSE;
            if (cfg->t.cfg.s.siNSap.remIntfValid == TRUE)
            {
               cb->remIntfValid = TRUE;
               cb->pst.intfVer = cfg->t.cfg.s.siNSap.remIntfVer;
            }
            /* if the remote ver is not configured by LM, check if we already 
             * have the needed information stored in the version structure.
             */
            if (cb->remIntfValid == FALSE)
            {
               found = FALSE;
               for (index = 0; index < siCb.numIntfInfo && found == FALSE; 
                    index++)
               {
                  if ((siCb.intfInfo[index].intf.intfId == SNTIF) ||
                      (siCb.intfInfo[index].intf.intfId == SPTIF))
                  {
                     switch (siCb.intfInfo[index].grpType)
                     {
                        case SHT_GRPTYPE_ALL:
                           if ((siCb.intfInfo[index].dstProcId ==
                                cfg->t.cfg.s.siNSap.dstProcId) &&
                               (siCb.intfInfo[index].dstEnt.ent ==
                                cfg->t.cfg.s.siNSap.dstEnt) &&
                               (siCb.intfInfo[index].dstEnt.inst ==
                                cfg->t.cfg.s.siNSap.dstInst))
                              found = TRUE;
                           break;
                        case SHT_GRPTYPE_ENT:
                           if ((siCb.intfInfo[index].dstEnt.ent ==
                                cfg->t.cfg.s.siNSap.dstEnt) &&
                               (siCb.intfInfo[index].dstEnt.inst ==
                                cfg->t.cfg.s.siNSap.dstInst))
                              found = TRUE;
                           break;
                        default:
                           /* not possible */
                           break;
                     }
                  }
               }
               if (found == TRUE)
               {
                  cb->pst.intfVer = siCb.intfInfo[index-1].intf.intfVer;
                  cb->remIntfValid = TRUE;
               }
            }
#endif /* SI_RUG */
         }
      }
   }

   cb->spId        = (SpId) cfg->t.cfg.s.siNSap.spId;
   cb->bndRetryCnt = 0;

   /* unbind the sap if network Id or ssf does not match */
   if ( (cb->cfg.nwId != cfg->t.cfg.s.siNSap.nwId) ||
            (cb->cfg.ssf != cfg->t.cfg.s.siNSap.ssf) )
   {
      cb->state       = SI_UNBND;
      cb->cfg.nwId = cfg->t.cfg.s.siNSap.nwId;
      cb->cfg.ssf = cfg->t.cfg.s.siNSap.ssf;
   }

#if (!(SI_LMINT3 || SMSI_LMINT3))
   /* init/reinit statistics and other parameters */
   buf = (U8 *) cb->sts;
   for (i = 0; i < sizeof (SiNSAPSts); i++)
   {
      *buf++ = 0;
   }
#endif /* (!(SI_LMINT3 || SMSI_LMINT3)) */

   cb->pst.selector    = cfg->t.cfg.s.siNSap.selector;
   cb->pst.region      = cfg->t.cfg.s.siNSap.mem.region;
   cb->pst.pool        = cfg->t.cfg.s.siNSap.mem.pool;
   cb->pst.prior       = cfg->t.cfg.s.siNSap.prior;
   cb->pst.route       = cfg->t.cfg.s.siNSap.route;
   cb->pst.dstProcId   = cfg->t.cfg.s.siNSap.dstProcId;
   cb->pst.dstEnt      = cfg->t.cfg.s.siNSap.dstEnt;
   cb->pst.dstInst     = cfg->t.cfg.s.siNSap.dstInst;
   cb->pst.srcProcId   = siCb.init.procId;
   cb->pst.srcEnt      = siCb.init.ent;
   cb->pst.srcInst     = siCb.init.inst;

   /* si001.220, ADDED: changes for rolling upgrade */
#ifdef SI_RUG
   if (cfg->t.cfg.s.siNSap.remIntfValid == TRUE)
   {
      cb->remIntfValid = TRUE;
      cb->pst.intfVer = cfg->t.cfg.s.siNSap.remIntfVer;
   }
#endif /* SI_RUG */

   cb->cfg.sapType   = cfg->t.cfg.s.siNSap.sapType;
   cb->cfg.nwId     = cfg->t.cfg.s.siNSap.nwId;
   cb->lnkSel          = 0;
   cb->cfg.selector    = cfg->t.cfg.s.siNSap.selector;
   cb->cfg.mem.region  = cfg->t.cfg.s.siNSap.mem.region;
   cb->cfg.mem.pool    = cfg->t.cfg.s.siNSap.mem.pool;
   cb->cfg.prior       = cfg->t.cfg.s.siNSap.prior;
   cb->cfg.route       = cfg->t.cfg.s.siNSap.route;
   cb->cfg.dstProcId   = cfg->t.cfg.s.siNSap.dstProcId;
   cb->cfg.dstEnt      = cfg->t.cfg.s.siNSap.dstEnt;
   cb->cfg.dstInst     = cfg->t.cfg.s.siNSap.dstInst;

   /* initialize the mem structure of mfMsgCtl since it is not
    * initialzed in the function siMfInitMsgCtl when macro
    * MFINITMSGCTL is called. If it is not properly initialized
    * and in case the memory is corrupted, invalid memory region
    * and pool may be used causing a crash of ISUP.
    */
   cb->mfMsgCtl.mem.region = cfg->t.cfg.s.siNSap.mem.region;
   cb->mfMsgCtl.mem.pool   = cfg->t.cfg.s.siNSap.mem.pool;

#ifdef SI_FTHA
#ifdef SI_DIS_SAP
              cb->contEntity = ENTSM;  /* stack manager controlling entity */
#else
              cb->contEntity = ENTNC;  /* unknown controlling entity */
#endif
#endif /* SI_FTHA */


   /* initialize message control */  
   MFINITPROF(&cb->mfCfgProf, ret, NMB_IMSG, NMB_IPRIM, siAllPduDefs, 
              siAllSduDefs, SIT_MF_MAX_REPELMT, (MF_IGNORE | MF_ISUP), 
              NULLP);
   MFINITMSGCTL(&cb->mfMsgCtl, ret, &cb->mfCfgProf, 0);

   /* report successful configuration to the stack manager */
   /* si006.220, MODIFIED: use the hash define instead of 0 */
   SISNDLSICFGCFM(pst, cfg, LCM_PRIM_OK, LCM_REASON_NOT_APPL, nsapId, 
                  SINSAP_CFG_OK);
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCfgSiIntfCb
*
*       Desc:  Configure/reconfigure an ISUP DPC control block
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siCfgSiIntfCb
(
Pst     *pst,
SiMngmt *cfg
)
#else
PUBLIC S16 siCfgSiIntfCb (pst, cfg)
Pst     *pst;
SiMngmt *cfg;
#endif
{
   SiIntfCb  *siIntfCb;
   S16       ret;
   SiUpSAPCb *tCb;
   SiNSAPCb  *sCb;
   SiNSAPCb  *mCb;
/* si044.220 : Addition : Bulk cir cfg Changes Circuit configuration
                          & reconfiguration */
#ifdef BULK_CIR_CFG
   U32 i;
   CirId cirId;
   Cic cic;
#endif /* if BULK_CIR_CFG */
#ifdef SI_218_COMP
   SiUpSAPCb *tmpCb;
#endif
#ifdef IW
   U16     nmbDpcCic;
#endif
/* si025.220: Addition - Added interface version variable */
#ifdef LSIV4
   CmIntfVer   intfVer;   /* interface version */
#endif

   TRC3(siCfgSiIntfCb)

/* si025.220: Addition - Added interface version initialization */
#ifdef LSIV4
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = LSIIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif

   if (!siCb.init.cfgDone)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "Configure layer first!\n"));  
#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI776, (ErrVal) cfg->hdr.elmId.elmntInst1,
                 "siCfgSiIntfCb(): gen config not done");
#endif
      SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE,
                     cfg->t.cfg.s.siIntfCb.intfId, SI_STINTF_CFG_NOK);
      RETVALUE(RFAILED);
   }
#ifdef SI_218_COMP
   cfg->t.cfg.s.siIntfCb.nwId = cfg->t.cfg.s.siIntfCb.swtch;
   tmpCb = siGetCbPtr(cfg->t.cfg.s.siIntfCb.swtch,
                      cfg->t.cfg.s.siIntfCb.ssf);
   if (tmpCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "Can't find upper SAP\n"));  
#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI777, (ErrVal) cfg->hdr.elmId.elmntInst1,
                 "siCfgSiIntfCb(): Upper SAP pointer is NULLP");
#endif
      RETVALUE(RFAILED);
   }
   cfg->t.cfg.s.siIntfCb.sapId = tmpCb->cfg.sapId;
#endif

   /* check if this interface is already configured */
   if (siFindIntf(&siIntfCb, cfg->t.cfg.s.siIntfCb.intfId, 0, 0, 0, 0,
                        SIINTF_KEY_1) != RFAILED)
   {
      /* Reconfiguration is allowed only if protocol variant and 
         ssf are same */
      if ( (siIntfCb->cfg.nwId != cfg->t.cfg.s.siIntfCb.nwId) ||
            (siIntfCb->cfg.ssf != cfg->t.cfg.s.siIntfCb.ssf))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
          "nwId/ssf mismatch: DPC control block(%#lx/%#x); request(%#lx/%#x)\n",
            siIntfCb->cfg.nwId, siIntfCb->cfg.ssf, 
               cfg->t.cfg.s.siIntfCb.nwId, cfg->t.cfg.s.siIntfCb.ssf));
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI778, (ErrVal) cfg->t.cfg.s.siIntfCb.intfId,
                    "siCfgSiIntfCb(): SI_STINTF nwId/ssf does not match");
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_RECONFIG_FAIL,
                        siIntfCb->cfg.intfId, SI_STINTF_CFG_NOK);
         RETVALUE(RFAILED);
      }
   }
   else
   {
      /* check if there is already an interface configured for 
         given values of phyDpc, nwId , NT and opc 
      */
      ret = siFindIntf(&siIntfCb, 0, cfg->t.cfg.s.siIntfCb.phyDpc, 
                  cfg->t.cfg.s.siIntfCb.nwId, cfg->t.cfg.s.siIntfCb.ssf,
                     cfg->t.cfg.s.siIntfCb.opc, SIINTF_KEY_2);
      if (ret == ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
            "Attempt to configure a redundant intf (%ld)\n",
               cfg->t.cfg.s.siIntfCb.intfId));
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "Diag:Prev intf %ld (dpc:%ld NT:%d nwId:%lx opc:%ld)\n",
               siIntfCb->cfg.intfId, siIntfCb->cfg.phyDpc, siIntfCb->cfg.ssf,
                  siIntfCb->cfg.nwId, siIntfCb->cfg.opc));
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_ADD_RES, ESI779, (ErrVal) siIntfCb->cfg.intfId, 
                     "siCfgSiIntfCb() : an interface id already exists");
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MISC_FAILURE,
                        cfg->t.cfg.s.siIntfCb.intfId, SI_STINTF_CFG_NOK);
         RETVALUE(RFAILED);

      }
      /* new Interface to be configured */
      if (++siCb.intfCnt > siCb.genCfg.nmbIntf)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                                "Attempt to configure > allowed %#x DPCs\n",
                                siCb.genCfg.nmbIntf));  
         siCb.intfCnt--;
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI780, (ErrVal) cfg->t.cfg.s.siIntfCb.intfId,
                    "siCfgSiIntfCb(): SI_STINTF out of range ");
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_EXCEED_CONF_VAL,
                        cfg->t.cfg.s.siIntfCb.intfId, SI_STINTF_CFG_NOK);
         RETVALUE(RFAILED);
      }

      /* Validate the lower sap */
      if ((tCb = SIUPSAP(cfg->t.cfg.s.siIntfCb.sapId)) == NULLP) 
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                       "Lower sap for sapId=%d not found\n",
                       cfg->t.cfg.s.siIntfCb.sapId));
         siCb.intfCnt--;
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI781, 
                    (ErrVal) cfg->t.cfg.s.siIntfCb.sapId,
                    "siCfgSiIntfCb(): Upper sap for sapId not found");
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_INVALID_SAP,
                        cfg->t.cfg.s.siIntfCb.intfId, SI_STINTF_CFG_NOK);
         RETVALUE(RFAILED);
      } 
      
      if ((tCb->cfg.swtch != cfg->t.cfg.s.siIntfCb.swtch) ||
          (tCb->cfg.ssf != cfg->t.cfg.s.siIntfCb.ssf))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "swtch=%d and ssf=%d for configured upper SAP don't match swtch=%d and ssf=%d for interface\n",
                        tCb->cfg.swtch, tCb->cfg.ssf, cfg->t.cfg.s.siIntfCb.swtch,
                        cfg->t.cfg.s.siIntfCb.ssf)); 
         siCb.intfCnt--;
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI782,
                    (ErrVal) cfg->t.cfg.s.siIntfCb.sapId,
                    "siCfgSiIntfCb(): swtch and ssf don't match in interface and sap");
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MISC_FAILURE,
                        cfg->t.cfg.s.siIntfCb.intfId, SI_STINTF_CFG_NOK);
         RETVALUE(RFAILED);
      } 
     
      /* Allocate memory for the Interface control block */
      if (ROK != SGetSBuf(siCb.init.region, siCb.init.pool, (Data **) &siIntfCb,
                    (Size) sizeof(SiIntfCb)) )
      {
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf, "SGetSbuf failed\n"));  
         siCb.intfCnt--;
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_ADD_RES, ESI783, (ErrVal) ret, 
                    "siCfgSiIntfCb(): SGetSBuf() failed in SI_STINTF");
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                        cfg->t.cfg.s.siIntfCb.intfId, SI_STINTF_CFG_NOK);
         RETVALUE(RFAILED);
      }

      siIntfCb->cfg.nwId    = cfg->t.cfg.s.siIntfCb.nwId;
      siIntfCb->cfg.swtch   = cfg->t.cfg.s.siIntfCb.swtch;
      siIntfCb->cfg.sapId   = cfg->t.cfg.s.siIntfCb.sapId;
      siIntfCb->cfg.ssf     = cfg->t.cfg.s.siIntfCb.ssf;
      siIntfCb->cfg.intfId  = cfg->t.cfg.s.siIntfCb.intfId;
      siIntfCb->cfg.phyDpc  = cfg->t.cfg.s.siIntfCb.phyDpc;
      siIntfCb->cfg.opc     = cfg->t.cfg.s.siIntfCb.opc;
      siIntfCb->state       = SI_INTF_AVAIL;
      siIntfCb->t4Runing    = FALSE;
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      siIntfCb->cfg.checkTable = cfg->t.cfg.s.siIntfCb.checkTable;
#endif /* SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      siIntfCb->cfg.trunkType = cfg->t.cfg.s.siIntfCb.trunkType;
#endif

      /* Get the corrosponding SCCP SAP Id */
      sCb = siGetSCbPtr(siIntfCb->cfg.nwId, siIntfCb->cfg.ssf); 
      if(sCb == NULLP)
         siIntfCb->ssapId = (siCb.genCfg.nmbSaps + 1);
      else
         siIntfCb->ssapId = sCb->cfg.nsapId; 

      /* Get the corrosponding MTP3/M3UA SAP Id */
      mCb = siGetMCbPtr(siIntfCb->cfg.nwId, siIntfCb->cfg.ssf);
      if((mCb == NULLP) && (sCb == NULLP))
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "No SCCP or MTP3/M3UA sap found corresponding to \
                 nwId=%ld and ssf=%d for configured for Interface",
                 cfg->t.cfg.s.siIntfCb.nwId,
                 cfg->t.cfg.s.siIntfCb.ssf)); 
         siCb.intfCnt--;
/* si035.220 - Addition - Prevention check for memory leak */
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siIntfCb,
	          (Size) sizeof(SiIntfCb));
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI784,
                    (ErrVal) cfg->t.cfg.s.siIntfCb.sapId,
                    "siCfgSiIntfCb(): Lower sap not found corresponding \
                     to nwId and ssf in Interface configuration");
                    
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MISC_FAILURE,
                        cfg->t.cfg.s.siIntfCb.intfId, SI_STINTF_CFG_NOK);
         RETVALUE(RFAILED);

      }
      else
      {
         if (mCb == NULLP)
            siIntfCb->msapId = (siCb.genCfg.nmbSaps + 1);
         else
            siIntfCb->msapId = mCb->cfg.nsapId;
      }

      /* add interface to the hash tables */
      cmMemset((U8 *)&siIntfCb->key, '\0', sizeof(SiIntfKey));
      siIntfCb->key.k1.intfId = siIntfCb->cfg.intfId;

      siIntfCb->key.k2.phyDpc = siIntfCb->cfg.phyDpc;
      siIntfCb->key.k2.ssf = siIntfCb->cfg.ssf;
      siIntfCb->key.k2.nwId = siIntfCb->cfg.nwId;
      siIntfCb->key.k2.opc = siIntfCb->cfg.opc;

      siIntfCb->key.k3.phyDpc = siIntfCb->cfg.phyDpc;
      siIntfCb->key.k3.ssf = siIntfCb->cfg.ssf;
      siIntfCb->key.k3.nwId = siIntfCb->cfg.nwId;
/* si025.220: Addtion - Added initialization of lnkSel */
      siIntfCb->lnkSel = 0;

      if ((ret = siAddIntf(&siCb.intfHlCp, siIntfCb)) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "siAddIntf failed\n"));  
         siCb.intfCnt--;
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siIntfCb,
                  (Size) sizeof(SiIntfCb));
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI785, (ErrVal) ret,
                    "siCfgSiIntfCb(): siAddIntf() failed in SI_STINTF");
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_HASHING_FAILED,
                        cfg->t.cfg.s.siIntfCb.intfId, SI_STINTF_CFG_NOK);
         RETVALUE(RFAILED);
      }
      /* init timer structure */
      cmInitTimers(siIntfCb->timers, MAXSIMTIMER);

#if (SI_LMINT3 || SMSI_LMINT3)
/* si045.220 :Modified Delete interface in case of SGetSbuf fails */

      if (SGetSBuf(siCb.init.region, siCb.init.pool, (Data **) &siIntfCb->sts,
                   (Size) sizeof(SiIntfSts)) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "SGetSBuf failed\n"));  
		
           /* delete the interface block from the hashlists */
            siDelIntf(&siCb.intfHlCp, siIntfCb);
         
            siCb.intfCnt--;

         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siIntfCb,
                  (Size) sizeof(SiIntfCb));

#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI786, (ErrVal) ret,
                    "siCfgSiIntfCb(): can not allocate stastics buffer");
#endif

         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                        cfg->t.cfg.s.siIntfCb.intfId, SI_STINTF_CFG_NOK);
         RETVALUE(RFAILED);

      }
/* si045.220 :End Delete interface in case of SGetSbuf fails */
      /* initialize counters to zero */
      cmMemset((U8 *) siIntfCb->sts, '\0', sizeof(SiIntfSts));
#endif /* (SI_LMINT3 || SMSI_LMINT3) */

#ifdef IW

      nmbDpcCic = siGetNmbDpcCic(siIntfCb->cfg.swtch);
      ret = SGetSBuf(siCb.init.region, siCb.init.pool, 
                     (Data **) &siIntfCb->cirProf, 
                     (Size) (nmbDpcCic));
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf, "SGetSBuf failed\n"));  
           
/* si045.220 :Modified Delete interface in case of SGetSbuf fails */
	/* delete the interface block from the hashlists */
            siDelIntf(&siCb.intfHlCp, (Data*) siIntfCb);
/* si045.220 :End Delete interface in case of SGetSbuf fails */
        
	 siCb.intfCnt--;
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)siIntfCb,
                  (Size) sizeof(SiIntfCb));
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_ADD_RES, ESI787, (ErrVal) ret, 
                    "SiMiLsiCfgReq() Failed, can't allocate circuit profile");
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                        0, SI_STINTF_CFG_NOK);
         RETVALUE(RFAILED);
      }
      cmMemset(siIntfCb->cirProf, '\0', nmbDpcCic);
#endif /* IW */
   }

   /* copy the timer configuration structre to dpc control block */
   (Void) cmMemcpy((U8 *) &(siIntfCb->cfg.dpcCbTmr), 
                   (U8 *) &(cfg->t.cfg.s.siIntfCb.dpcCbTmr),
                   sizeof(SiDpcCbTmrCfg)); 
    siIntfCb->cfg.pauseActn = cfg->t.cfg.s.siIntfCb.pauseActn;



/* si044.220 : Addition - Bulk cir cfg Specific changes added */

#ifdef BULK_CIR_CFG
/* Bulk cir cfg Changes: configure SI_MAX_BULK_CIR_CFG circuits per intf at this point
* start cirId for each intf will be intfId and the next cirId
* is the intfId + siCb.genCfg.nmbIntf
*
   {
      U32 availMem;
      if ((ret = SRegInfoShow(DFLT_REGION, &availMem)) != ROK)
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "SRegInfoShow failed\n"));  
   } */
   /* cirId = SI_MAX_BULK_CIR_CFG * (siIntfCb->cfg.intfId - 1) + 1; */
   /* cic = SI_MAX_BULK_CIR_CFG * (siIntfCb->cfg.intfId - 1); */


   cirId = siIntfCb->cfg.intfId;
   cic = 0;
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Configuring %ld circuits for intf %ld, from cirId: %ld, cic: %d\n",
                       SI_MAX_BULK_CIR_CFG,siIntfCb->cfg.intfId, cirId, cic));  
   for (i = 0; i < SI_MAX_BULK_CIR_CFG; i++)
   {
      if ((ret = siConfigCircuit(cirId, cic, siIntfCb->cfg.intfId, siIntfCb))
          != ROK)
      {
         SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf, "Circuit cfg failed, cirId: %ld\n",cirId));
      }
      /* cirId ++; */
      cirId += siCb.genCfg.nmbIntf;
      cic ++;
   }
#endif /* ifdef BULK_CIR_CFG */

/* si025.220: Addtion - added link selection option initializations.
 * They are reconfigurable. */
#ifdef LSIV4
      /* if SM is using inftVer 3 (LSIV3), here is LSIV4,
       * ISUP should behave as LSIV3 by taking the configured
       * values from LSIV3 interface.
       */
      switch(intfVer)
      {
         case 0x0300:
            siIntfCb->cfg.lnkSelOpt = siCb.genCfg.lnkSelOpt;
            break;

         case 0x0400:
            siIntfCb->cfg.lnkSelOpt = cfg->t.cfg.s.siIntfCb.lnkSelOpt;
            break;

         case 0x0100:
         case 0x0200:
            siIntfCb->cfg.lnkSelOpt =  LSI_LNKSEL_LD_DISTR;
            break;

         default:
            /* invalid interface version number */
            RETVALUE(RINVIFVER);
      } /* switch */

      /* set to default values if they are invalid */
      if ((siIntfCb->cfg.lnkSelOpt != LSI_LNKSEL_LD_DISTR) &&
          (siIntfCb->cfg.lnkSelOpt != LSI_LNKSEL_CIC))
      {
          /* set to default value */
          siIntfCb->cfg.lnkSelOpt = LSI_LNKSEL_LD_DISTR;
      }
#endif

   /* si006.220, MODIFIED: use the hash define instead of 0 */
   SISNDLSICFGCFM(pst, cfg, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 
                  cfg->t.cfg.s.siIntfCb.intfId, SI_STINTF_CFG_OK);

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCfgSiCirCb
*
*       Desc:  Configure/reconfigure a circuit control block
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siCfgSiCirCb
(
Pst     *pst,
SiMngmt *cfg
)
#else
PUBLIC S16 siCfgSiCirCb (pst, cfg)
Pst     *pst;
SiMngmt *cfg;
#endif
{
   SiCirKey    key;
   SiIntfCb    *siIntfCb;
   SiCirCb     *siCir;
   U16         i;
   S16         ret;

   TRC3(siCfgSiCirCb)

   if (!siCb.init.cfgDone)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "Configure layer first !     \n"));  

#if (ERRCLASS & ERRCLS_INT_PAR) 
      SILOGERROR(ERRCLS_INT_PAR, ESI789, (ErrVal) cfg->hdr.elmId.elmntInst1, 
                 "siCfgSiCirCb(): gen config not done");
#endif

      SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE,
                     0, SICIR_CFG_NOK);
      RETVALUE(RFAILED);
   }

   /* check if the interface control block is already configured */
   if (siFindIntf(&siIntfCb, cfg->t.cfg.s.siCir.intfId, 0, 0, 0, 0, SIINTF_KEY_1)
                     == RFAILED)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "siFindIntf failed for intfId %ld\n", cfg->t.cfg.s.siCir.intfId));  
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI790, (ErrVal) cfg->t.cfg.s.siCir.intfId,
                 "siCfgSiCirCb(): intf block for this circuit not found");
#endif

      SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_INVALID_PAR_VAL,
                     cfg->t.cfg.s.siCir.cirId, SICIR_CFG_NOK);
      RETVALUE(RFAILED);
   }

   /* check if circuit is already configured */
   key.k1.cirId = cfg->t.cfg.s.siCir.cirId;
   siFindCir(&siCb.cirHlCp, &siCir, &key, 0, KEY_CIR);
   if (siCir != (SiCirCb *) NULLP)
   {
      /* circuit already cfgd - following parameters can be re-cfgd */
      switch (cfg->t.cfg.s.siCir.typeCntrl)
      {
         /* In this case ISUP allows both incoming and outgoing
          * connections on this circuit. However, in case of dual
          * siezure:
          *
          * o This ISUP stack acts as a controlling end
          *   - if the CIC is odd numbered and point code of this
          *     node is less than the point code of peer node, or,
          *   - if the CIC is even numbered and point code of this
          *     node is greater than the point code of peer node.
          *
          * o Peer ISUP stack acts as a controlling end,
          *   - if the CIC is odd numbered and point code of this
          *     node is greater than the point code of the peer node,
          *     or,
          *   - if the CIC is even numbered and point code of this
          *     node is less than the point code of the peer node.
          */
         case BOTHWAY:
            if ( siIntfCb->cfg.opc < siIntfCb->cfg.phyDpc )
            {
               if (cfg->t.cfg.s.siCir.cic & OE_ODD)
                  siCir->cirCtl = TRUE;
               else
                  siCir->cirCtl = FALSE;
            }
            else
            {
               if (cfg->t.cfg.s.siCir.cic & OE_ODD)
                  siCir->cirCtl = FALSE;
               else
                  siCir->cirCtl = TRUE;
            }
            break;

         /* In this case ISUP allows both incoming and outgoing
          * connections on this circuit. However, in case of dual
          * siezure, this ISUP stack acts as the controlling end.
          */
         case CONTROLLING:
            siCir->cirCtl = TRUE;
            break;

         /* In this case ISUP allows both incoming and outgoing
          * connections on this circuit. However, in case of dual
          * siezure, peer ISUP stack acts as the controlling end.
          */
         case CONTROLLED:
            siCir->cirCtl = FALSE;
            break;

         /* In this case ISUP allows only incoming connections on
          * this circuit.
          */
         case INCOMING:
            siCir->cirCtl = FALSE;
            break;

         /* In this case ISUP allows only outgoing connections on
          * this circuit.
          */
         case OUTGOING:
            siCir->cirCtl = TRUE;
            break;

         default:
            SIDBGP(SIDBGMASK_CERR,
                   (siCb.init.prntBuf,
                    "siCfgSiCirCb(): Invalid circuit control type specified %c.\n",
                    cfg->t.cfg.s.siCir.typeCntrl));  
#if (ERRCLASS & ERRCLS_DEBUG)
            SILOGERROR(ERRCLS_DEBUG, ESI791, (ErrVal) cfg->t.cfg.s.siCir.intfId,
                       "siCfgSiCirCb(): Invalid circuit control type specified");
#endif
      
            SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_INVALID_PAR_VAL,
                           cfg->t.cfg.s.siCir.cirId, SICIR_CFG_NOK);
            RETVALUE(RFAILED);
      }

      siCir->cfg.typeCntrl       = cfg->t.cfg.s.siCir.typeCntrl;
#ifdef SI_218_COMP
      siCir->cfg.bearProf        = cfg->t.cfg.s.siCir.bearProf;
#endif
      siCir->cfg.contReq         = cfg->t.cfg.s.siCir.contReq;

      /* copy the timer configuration structre to circuit 
         control block */
      (Void) cmMemcpy((U8 *) &(siCir->cfg.cirTmr), 
                      (U8 *) &(cfg->t.cfg.s.siCir.cirTmr),
                      sizeof(SiCirTmrCfg)); 

   }
   else
   {
      if (++(siCb.cirCnt) > siCb.genCfg.nmbCir)
      {
         SIDBGP(SIDBGMASK_CERR,
                (siCb.init.prntBuf,
                 "Attempt to configure > %#lx circuits\n", 
                 siCb.genCfg.nmbCir));  
         siCb.cirCnt--;
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI792, (ErrVal) cfg->t.cfg.s.siCir.cirId, 
                    "siCfgSiCirCb(): STICIR circuit out of range ");
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_EXCEED_CONF_VAL,
                        cfg->t.cfg.s.siCir.cirId, SICIR_CFG_NOK);
         RETVALUE(RFAILED);
      }

      if (ROK != SGetSBuf(siCb.init.region, siCb.init.pool, (Data **) &siCir,
                     (Size) sizeof(SiCirCb)) )
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SGetSBuf   failed   \n"));  
         siCb.cirCnt--;
#if (ERRCLASS & ERRCLS_ADD_RES)
         SILOGERROR(ERRCLS_ADD_RES, ESI793, (ErrVal) 0, 
                    "siCfgSiCirCb(): SGetSBuf() failed in STICIR");
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                        cfg->t.cfg.s.siCir.cirId, SICIR_CFG_NOK);
         RETVALUE(RFAILED);
      }

      ret = SGetSBuf(siCb.init.region, siCb.init.pool, (Data **) &siCir->sts,
                     (Size) sizeof(SiCirSts));
      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SGetSBuf   failed   \n"));  
         siCb.cirCnt--;
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCir->sts,
                  (Size) sizeof(SiCirSts));

#if (ERRCLASS & ERRCLS_ADD_RES)
         SILOGERROR(ERRCLS_ADD_RES, ESI794, (ErrVal) 0, 
                    "siCfgSiCirCb(): SGetSBuf() failed in STICIR");
#endif
         SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL,
                        cfg->t.cfg.s.siCir.cirId, SICIR_CFG_NOK);
         RETVALUE(RFAILED);
      }

      cmMemset((U8 *)siCir->sts, '\0', sizeof(SiCirSts));
      cmMemset((U8 *)&siCir->key, '\0', sizeof(SiCirKey));

      switch (cfg->t.cfg.s.siCir.typeCntrl)
      {
         /* In this case ISUP allows both incoming and outgoing
          * connections on this circuit. However, in case of dual
          * siezure:
          *
          * o This ISUP stack acts as a controlling end
          *   - if the CIC is odd numbered and point code of this
          *     node is less than the point code of peer node, or,
          *   - if the CIC is even numbered and point code of this
          *     node is greater than the point code of peer node.
          *
          * o Peer ISUP stack acts as a controlling end,
          *   - if the CIC is odd numbered and point code of this
          *     node is greater than the point code of the peer node,
          *     or,
          *   - if the CIC is even numbered and point code of this
          *     node is less than the point code of the peer node.
          */
         case BOTHWAY:
            if ( siIntfCb->cfg.opc < siIntfCb->cfg.phyDpc )
            {
               if (cfg->t.cfg.s.siCir.cic & OE_ODD)
                  siCir->cirCtl = TRUE;
               else
                  siCir->cirCtl = FALSE;
            }
            else
            {
               if (cfg->t.cfg.s.siCir.cic & OE_ODD)
                  siCir->cirCtl = FALSE;
               else
                  siCir->cirCtl = TRUE;
            }
            break;

         /* In this case ISUP allows both incoming and outgoing
          * connections on this circuit. However, in case of dual
          * siezure, this ISUP stack acts as the controlling end.
          */
         case CONTROLLING:
            siCir->cirCtl = TRUE;
            break;

         /* In this case ISUP allows both incoming and outgoing
          * connections on this circuit. However, in case of dual
          * siezure, peer ISUP stack acts as the controlling end.
          */
         case CONTROLLED:
            siCir->cirCtl = FALSE;
            break;

         /* In this case ISUP allows only incoming connections on
          * this circuit.
          */
         case INCOMING:
            siCir->cirCtl = FALSE;
            break;

         /* In this case ISUP allows only outgoing connections on
          * this circuit.
          */
         case OUTGOING:
            siCir->cirCtl = TRUE;
            break;

         default:
            SIDBGP(SIDBGMASK_CERR,
                   (siCb.init.prntBuf,
                    "siCfgSiCirCb(): Invalid circuit control type specified %c.\n",
                    cfg->t.cfg.s.siCir.typeCntrl));  
            siCb.cirCnt--;
            SPutSBuf(siCb.init.region, siCb.init.pool,
                     (Data *) siCir->sts, (Size) sizeof(SiCirSts));
#if (ERRCLASS & ERRCLS_DEBUG)
            SILOGERROR(ERRCLS_DEBUG, ESI795, (ErrVal) cfg->t.cfg.s.siCir.intfId,
                       "siCfgSiCirCb(): Invalid circuit control type specified");
#endif
      
            SISNDLSICFGCFM(pst, cfg, LCM_PRIM_NOK, LCM_REASON_INVALID_PAR_VAL,
                           cfg->t.cfg.s.siCir.cirId, SICIR_CFG_NOK);
            RETVALUE(RFAILED);
      }

#ifdef IW
      /* Set the bit in the DPC's circuit configuration profile */
      siIntfCb->cirProf[cfg->t.cfg.s.siCir.cic] = 1;
#endif
      siCir->key.k1.cirId    = cfg->t.cfg.s.siCir.cirId;
      siCir->key.k2.cic      = cfg->t.cfg.s.siCir.cic;
      siCir->key.k2.intfId   = cfg->t.cfg.s.siCir.intfId;
      siCir->key.k3.intfId   = cfg->t.cfg.s.siCir.intfId;
      siCir->phyDpc          = siIntfCb->cfg.phyDpc;
      SISTATECHNG(siCir->calProcStat, CALL_IDLE);
      siCir->siCon           = NULLP;
      siCir->pIntfCb         = siIntfCb;
      for (i = 0; i < NUMCIREVTGRP; i++)
      {
         siCir->transStat[i] = SICIR_ST_IDLE;
         siCir->cirGr[i]     = NULLP;
      }
      siCir->noRspFlgToUp = FALSE;
      siCir->noRspFlgToLw = FALSE;

      siCir->resFlag      = FALSE;
      
      cmInitTimers(siCir->timers, MAXSIMTIMER);
      
      siCir->cfg.cirId           = cfg->t.cfg.s.siCir.cirId;
      siCir->cfg.cic             = cfg->t.cfg.s.siCir.cic;
      siCir->cfg.intfId          = cfg->t.cfg.s.siCir.intfId;
      siCir->opc                 = siIntfCb->cfg.opc;      
      siCir->cfg.typeCntrl       = cfg->t.cfg.s.siCir.typeCntrl;
#ifdef SI_218_COMP
      siCir->cfg.bearProf        = cfg->t.cfg.s.siCir.bearProf;
#endif
      siCir->cfg.contReq         = cfg->t.cfg.s.siCir.contReq;
      siCir->cfg.cirFlg          = cfg->t.cfg.s.siCir.cirFlg;

      /* copy the timer configuration structre to dpc control block */
      (Void) cmMemcpy((U8 *) &(siCir->cfg.cirTmr), 
                      (U8 *) &(cfg->t.cfg.s.siCir.cirTmr),
                      sizeof(SiCirTmrCfg)); 

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* for non-single rate connection related fields */
      siCir->cfg.slotId          = cfg->t.cfg.s.siCir.slotId;
      siCir->cfg.ctrlMult        = cfg->t.cfg.s.siCir.ctrlMult;
      siCir->nextMultiRateCir    = NULLP;
      siCir->ctrlMultiRateCir    = NULLP;
#endif
      
      /* add to Circuit List */
      siAddCir(&siCb.cirHlCp, siCir);
   }

   /* report successful configuration to the stack manager */
   /* si006.220, MODIFIED: use the hash define instead of 0 */
   SISNDLSICFGCFM(pst, cfg, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 
                  cfg->t.cfg.s.siCir.cirId, SICIR_CFG_OK);
   RETVALUE(ROK);
}

/* si044.220 : Addition - Bulk cir cfg Changes for configuring
               reconfiguring the circuits 
*/
#ifdef BULK_CIR_CFG

/*
*
*       Fun:   siConfigCircuit
*
*       Desc:  Configure/reconfigure a circuit control block
*
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siConfigCircuit
(
CirId cirId,
Cic   cic,
SiInstId intfId,
SiIntfCb *siIntfCb
)
#else
PUBLIC S16 siConfigCircuit(cirId, cic, intfId, siIntfCb)
CirId cirId,;
Cic   cic;
SiInstId intfId;
SiIntfCb *siIntfCb;
#endif
{
   SiCirCb     *siCir;
   SiCirTmrCfg cirTmr;
   U16         i;
   S16         ret;

   TRC3(siConfigCircuit)

   if (++(siCb.cirCnt) > siCb.genCfg.nmbCir)
   {
         SIDBGP(SIDBGMASK_CERR,
                (siCb.init.prntBuf,
                 "Attempt to configure > %#lx circuits\n",
                 siCb.genCfg.nmbCir));
         RETVALUE(RFAILED);
   }
   if (ROK != SGetSBuf(siCb.init.region, siCb.init.pool, (Data **) &siCir,
                      (Size) sizeof(SiCirCb)) )
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "   SGetSBuf   failed   \n"));
#if (ERRCLASS & ERRCLS_ADD_RES)
      SILOGERROR(ERRCLS_ADD_RES, ESI793, (ErrVal) 0,
                 "siCfgSiCirCb(): SGetSBuf() failed in STICIR");
#endif
      RETVALUE(RFAILED);
   }

   ret = SGetSBuf(siCb.init.region, siCb.init.pool, (Data **) &siCir->sts,
                  (Size) sizeof(SiCirSts));
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "   SGetSBuf   failed   \n"));
      SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCir->sts,
               (Size) sizeof(SiCirSts));

#if (ERRCLASS & ERRCLS_ADD_RES)
      SILOGERROR(ERRCLS_ADD_RES, ESI794, (ErrVal) 0,
                 "siCfgSiCirCb(): SGetSBuf() failed in STICIR");
#endif
      RETVALUE(RFAILED);
   }

   cmMemset((U8 *)siCir->sts, '\0', sizeof(SiCirSts));
   cmMemset((U8 *)&siCir->key, '\0', sizeof(SiCirKey));

   if ( siIntfCb->cfg.opc < siIntfCb->cfg.phyDpc )
   {
      if (cic & OE_ODD)
         siCir->cirCtl = TRUE;
      else
         siCir->cirCtl = FALSE;
   }
   else
   {
      if (cic & OE_ODD)
         siCir->cirCtl = FALSE;
      else
         siCir->cirCtl = TRUE;
   }
#ifdef IW
   /* Set the bit in the DPC's circuit configuration profile */
   siIntfCb->cirProf[cic] = 1;
#endif

   siCir->key.k1.cirId    = cirId;
   siCir->key.k2.cic      = cic;
   siCir->key.k2.intfId   = intfId;
   siCir->key.k3.intfId   = intfId;
   siCir->phyDpc          = siIntfCb->cfg.phyDpc;
   SISTATECHNG(siCir->calProcStat, CALL_IDLE);
   siCir->siCon           = NULLP;
   siCir->pIntfCb         = siIntfCb;
   for (i = 0; i < NUMCIREVTGRP; i++)
   {
      siCir->transStat[i] = SICIR_ST_IDLE;
      siCir->cirGr[i]     = NULLP;
   }
   siCir->noRspFlgToUp = FALSE;
   siCir->noRspFlgToLw = FALSE;

   siCir->resFlag      = FALSE;

   cmInitTimers(siCir->timers, MAXSIMTIMER);

   siCir->cfg.cirId           = cirId;
   siCir->cfg.cic             = cic;
   siCir->cfg.intfId          = intfId;
   siCir->opc                 = siIntfCb->cfg.opc;
   siCir->cfg.typeCntrl       = BOTHWAY;
   siCir->cfg.contReq         = 0;
   siCir->cfg.cirFlg          = 0;

   cirTmr.t3.enb = TRUE;
   cirTmr.t3.val = 0;

   cirTmr.t12.enb = TRUE;
   cirTmr.t12.val = 15;

   cirTmr.t13.enb = TRUE;
   cirTmr.t13.val = 30;

   cirTmr.t14.enb = TRUE;
   cirTmr.t14.val = 15;
   cirTmr.t15.enb = TRUE;
   cirTmr.t15.val = 60;

   cirTmr.t16.enb = TRUE;
   cirTmr.t16.val = 10;

   cirTmr.t17.enb = TRUE;
   cirTmr.t17.val = 20;

   /* copy the timer configuration structre to dpc control block */
   (Void) cmMemcpy((U8 *) &(siCir->cfg.cirTmr),
                   (U8 *) &(cirTmr),
                   sizeof(SiCirTmrCfg));

#if (SS7_ANS95 || SS7_ITU97 || SS7_ETSIV3)
   /* for non-single rate connection related fields */
   siCir->cfg.slotId          = 0;
   siCir->cfg.ctrlMult        = 0;
   siCir->nextMultiRateCir    = NULLP;
   siCir->ctrlMultiRateCir    = NULLP;
#endif

   /* add to Circuit List */
   siAddCir(&siCb.cirHlCp, siCir);

   RETVALUE(ROK);
}
#endif /* ifdef BULK_CIR_CFG */


#ifdef SI_ACNT
/*
*
*       Fun:   siCntrlAcntInd
*
*       Desc:  Control accounting indication to layer manager.
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siCntrlAcntInd
(
Pst     *pst,
SiMngmt *cntrl
)
#else
PUBLIC S16 siCntrlAcntInd (pst, cntrl)
Pst     *pst;
SiMngmt *cntrl;
#endif
{
   TRC3(siCntrlAcntInd)

   switch (cntrl->t.cntrl.action)
   {
      case AENA:        /* enable */
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case AENA\n"));  
         siCb.init.acnt = TRUE;
         break;

      case ADISIMM:     /* disable - immediately */
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "case ADISIMM\n"));  
         siCb.init.acnt = FALSE;
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid cntrl.action = %#x\n", cntrl->t.cntrl.action));  
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI796, (ErrVal) 0,
                    "SiMiLsiCntrlReq() Failed, invalid subaction");
#endif
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_ACTION,
                          cntrl->t.cntrl.action, SI_CNTRL_NOK);
         RETVALUE(RFAILED);
   }

   /* si006.220, MODIFIED: use the hash define instead of 0 */
   SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 0, 
                    SI_CNTRL_OK);
   
   /* si001.220, ADDED: Updated to the standby copy */
#ifdef ZI
   {
      ziRunTimeUpd(ZI_LYR_CB, CMPFTHA_UPD_REQ, (PTR) &siCb); 
      ziUpdPeer(); 
   }
#endif
   RETVALUE(ROK);
}
#endif


/*
*
*       Fun:   siCntrlUstaInd
*
*       Desc:  Control unsolicited status (alarms) indication to layer manager
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siCntrlUstaInd
(
Pst     *pst,
SiMngmt *cntrl
)
#else
PUBLIC S16 siCntrlUstaInd (pst, cntrl)
Pst     *pst;
SiMngmt *cntrl;
#endif
{
   TRC3(siCntrlUstaInd)

   switch (cntrl->t.cntrl.action)
   {
      case AENA :        /* enable */
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case AENA \n"));   
         siCb.init.usta = TRUE;
         break;

      case ADISIMM :     /* disable - immediately */
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case ADISIMM \n"));   
         siCb.init.usta = FALSE;
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                                "invalid cntrl.action = %#x\n",
                                cntrl->t.cntrl.action));  
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI797, (ErrVal) 0,
                    "SiMiLsiCntrlReq() Failed, invalid subaction");
#endif
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_ACTION,
                          cntrl->t.cntrl.action, SI_CNTRL_NOK);
         RETVALUE(RFAILED);
   }
   /* si006.220, MODIFIED: use the hash define instead of 0 */
   SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 0, 
                    SI_CNTRL_OK);

   /* si001.220, ADDED: Updated to the standby copy */
#ifdef ZI
   {
      ziRunTimeUpd(ZI_LYR_CB, CMPFTHA_UPD_REQ, (PTR) &siCb); 
      ziUpdPeer(); 
   }
#endif
   RETVALUE(ROK);
}


/*
*
*       Fun:   siCntrlTrcInd
*
*       Desc:  Control trace indications to layer management
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siCntrlTrcInd
(
Pst     *pst,
SiMngmt *cntrl
)
#else
PUBLIC S16 siCntrlTrcInd (pst, cntrl)
Pst     *pst;
SiMngmt *cntrl;
#endif
{
   SpId     nsapId;
   SpId     nsapType;
   SiNSAPCb *cb;

   TRC2(siCntrlTrcInd)

   /* get cb with MTP 3 or SCCP */
#if (SI_LMINT3 || SMSI_LMINT3)
   nsapType = cntrl->t.cntrl.s.siTrc.nsapType;
   nsapId   = cntrl->t.cntrl.s.siTrc.nsapId;
#else
   nsapType = cntrl->hdr.elmId.elmntInst2;
   nsapId   = cntrl->hdr.elmId.elmntInst1;
#endif
   switch (nsapType)
   {
      case SAP_MTP :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case SAP_MTP \n"));   
         cb = SIMTPSAP(nsapId);
         break;

      case SAP_M3UA :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case SAP_M3UA \n"));   
         cb = SIMTPSAP(nsapId);
         break;

      case SAP_SCCP :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case SAP_SCCP \n"));   
         cb = SISCCPSAP(nsapId);
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "invalid sap type : %d\n", 
                                nsapType));
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_PAR_VAL,
                          nsapType, SI_CNTRL_NOK);
         RETVALUE(RFAILED);
   }

   if (cb == NULLP)
   {  
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                             "no NSAP found for sapId= %#x\n", nsapId));
      SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_PAR_VAL,
                       nsapId, SI_CNTRL_NOK);
      RETVALUE(RFAILED);
   } 

   switch (cntrl->t.cntrl.action)
   {
      case AENA :        /* enable */
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case AENA \n"));   
         cb->trc = TRUE;
         break;

      case ADISIMM :     /* disable - immediately */
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case ADISIMM \n"));   
         cb->trc = FALSE;
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "cntrl.action invalid %d\n", cntrl->t.cntrl.action));  
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI798, (ErrVal) 0,
                    "SiMiLsiCntrlReq() Failed, invalid subaction");
#endif
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_ACTION,
                          cntrl->t.cntrl.action, SI_CNTRL_NOK);
         RETVALUE(RFAILED);
   }

   /* si006.220, MODIFIED: use the hash define instead of 0 */
   SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 0, 
                    SI_CNTRL_OK);

#ifdef ZI
   {
      U8 cbType;
      cbType = ZI_MTP3SAP_CB;

      if ((nsapType == SAP_MTP) || (nsapType == SAP_M3UA))
         cbType = ZI_MTP3SAP_CB;
      else if (nsapType == SAP_SCCP)
         cbType = ZI_SCCPSAP_CB;

      ziRunTimeUpd(cbType, CMPFTHA_UPD_REQ, (PTR) cb);
      ziUpdPeer();
   }
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siCntrlDbg
*
*       Desc:  Control debugging prints 
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siCntrlDbg 
(
Pst     *pst,
SiMngmt *cntrl
)
#else
PUBLIC S16 siCntrlDbg (pst, cntrl)
Pst     *pst;
SiMngmt *cntrl;
#endif
{
   TRC2(siCntrlDbg)

#ifdef DEBUGP
   switch (cntrl->t.cntrl.action)
   {
      case AENA: /* enable debug class */
#if (SI_LMINT3 || SMSI_LMINT3)
         siCb.init.dbgMask |= cntrl->t.cntrl.s.siDbg.dbgMask;
#else
         siCb.init.dbgMask |= cntrl->t.cntrl.param.siDbg.dbgMask;
#endif
         break;

      case ADISIMM: /* disable debug class */
#if (SI_LMINT3 || SMSI_LMINT3)
         siCb.init.dbgMask &= ~(cntrl->t.cntrl.s.siDbg.dbgMask);
#else
         siCb.init.dbgMask &= ~(cntrl->t.cntrl.param.siDbg.dbgMask);
#endif
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "invalid action=%#x\n",
                                cntrl->t.cntrl.action));  
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_ACTION,
                          cntrl->t.cntrl.action, SI_CNTRL_NOK);
         break;
   }

#endif /* ifdef DEBUGP */

   /* si006.220, MODIFIED: use the hash define instead of 0 */
   SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 0, 
                    SI_CNTRL_OK);

   /* si001.220, ADDED: Updated to the standby copy */
#ifdef DEBUGP
#ifdef ZI
   {
      ziRunTimeUpd(ZI_LYR_CB, CMPFTHA_UPD_REQ, (PTR) &siCb); 
      ziUpdPeer(); 
   }
#endif /* ZI */
#endif /* ifdef DEBUGP */

   RETVALUE(ROK);
}/* siCntrlDbg */


/*
*
*       Fun:   siCntrlSiCirGrpCb
*
*       Desc:  Process control request for an ISUP circuit group
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PRIVATE S16 siCntrlSiCirGrpCb
(
Pst         *pst,
SiMngmt     *cntrl
)
#else
PRIVATE S16 siCntrlSiCirGrpCb(pst, cntrl)
Pst     *pst;
SiMngmt *cntrl;
#endif
{
   SiStaEvnt   staEvnt;
   SiCirKey    key;   /* Key structure for validating the circuit */
   SiCirCb     *siCir;/* Circuit control block associated with the request */
#if (SI_LMINT3 || SMSI_LMINT3)
   SiElmntCntrl *eCntrl;
#endif
   Cntr        i;
   U8          evntType;
   SiIntfCb  *siIntfCb;

   TRC3(siCntrlSiCirGrpCb);
   
   /* si006.220, ADDED: added a function to implement the force block
    * of circuit group
    */
#if (SI_LMINT3 || SMSI_LMINT3)
   if (cntrl->t.cntrl.action == ABLK)
   {
      siCntrlForBlkCirGr(pst, cntrl);
      RETVALUE(ROK);
   }
#endif

   /* Find the circuit control block associated with the 
      main circuit on which request comes 
    */
#if (SI_LMINT3 || SMSI_LMINT3)
   key.k1.cirId= cntrl->t.cntrl.s.siElmnt.elmntId.circuit;
#else
   key.k1.cirId= cntrl->t.cntrl.sigpt.cirId;
#endif
   siFindCir(&siCb.cirHlCp, &siCir, &key, 0, KEY_CIR); 
   /* if circuit block can not be found */
   if( siCir == (SiCirCb *)NULLP )
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                              "no circuit block associated with cirId:%#lx\n",
                              key.k1.cirId));  
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI799, (ErrVal ) 0,
                 "siCntrlSiCirGrpCb(): circuit control block not found");
#endif

      SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_PAR_VAL,
                       key.k1.cirId, SI_CNTRL_NOK);
      RETVALUE(ROK); 
   }

   /* Find the interface block associated with this circuit */
   siIntfCb = siCir->pIntfCb;
   if (siIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
         "Can not find intf block for %ld associated with cirid in req\n",
                  siCir->cfg.intfId));
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI800, (ErrVal ) siCir->cfg.intfId,
              " Can not find the intf block associated with intfid\n");
#endif
      RETVALUE(RFAILED);
   }

   cmMemset((U8 *)&staEvnt, (U8)NOTPRSNT, sizeof(SiStaEvnt));

#if (SI_LMINT3 || SMSI_LMINT3)
   eCntrl = &cntrl->t.cntrl.s.siElmnt;

   staEvnt.cgsmti.eh.pres       = PRSNT_NODEF;
   staEvnt.cgsmti.typeInd.pres  = PRSNT_NODEF;
   staEvnt.cgsmti.typeInd.val   = eCntrl->elmntParam.cirgr.cgsmti;

   staEvnt.rangStat.eh.pres     = PRSNT_NODEF;
   staEvnt.rangStat.range.pres  = PRSNT_NODEF;
   staEvnt.rangStat.range.val   = eCntrl->elmntParam.cirgr.range;


   if (cntrl->t.cntrl.action != ARST)
   {
      if (staEvnt.rangStat.range.val)
      {
         staEvnt.rangStat.status.pres = PRSNT_NODEF;
         staEvnt.rangStat.status.len  = 
               ((U8)( (U8) eCntrl->elmntParam.cirgr.range >> 0x03) + 1);
         for (i = 0; i < (Cntr) staEvnt.rangStat.status.len; i++)
            staEvnt.rangStat.status.val[i] = eCntrl->elmntParam.cirgr.status[i];
      }
      else
         staEvnt.rangStat.status.pres = NOTPRSNT;
   }
           
#else /* !(SI_LMINT3 || SMSI_LMINT3) */

   staEvnt.cgsmti.eh.pres       = PRSNT_NODEF;
   staEvnt.cgsmti.typeInd.pres  = PRSNT_NODEF;
   staEvnt.cgsmti.typeInd.val   = cntrl->t.cntrl.param.cirgrp.cgsmti;

   staEvnt.rangStat.eh.pres     = PRSNT_NODEF;
   staEvnt.rangStat.range.pres  = PRSNT_NODEF;
   staEvnt.rangStat.range.val   = cntrl->t.cntrl.param.cirgrp.range;

   if (cntrl->t.cntrl.action != ARST)
   {
      if (staEvnt.rangStat.range.val)
      {
         staEvnt.rangStat.status.pres = PRSNT_NODEF;
         staEvnt.rangStat.status.len  = 
             ((U8)( (U8) cntrl->t.cntrl.param.cirgrp.range >> 0x03) + 1);
         for (i = 0; i < staEvnt.rangStat.status.len; i++)
            staEvnt.rangStat.status.val[i] = cntrl->t.cntrl.param.cirgrp.status[i];
      }
      else
         staEvnt.rangStat.status.pres = NOTPRSNT;
   }
#endif /* !(SI_LMINT3 || SMSI_LMINT3) */

   switch (cntrl->t.cntrl.action)
   {
      case AENA  :     /* Unblock the circuit group */
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case AENA \n"));   
         evntType = SIT_STA_CGUREQ;
         break;

      case ADISIMM  :  /* block the circuit group   */
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case ADISIMM \n"));   
         evntType = SIT_STA_CGBREQ;
         break;

      case ARST :     /* Reset the circuit group   */
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case ARST \n"));   
         evntType = SIT_STA_GRSREQ;
         break;

      case ADGN:      /* Circuit Query */
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case ADGN \n"));   
         evntType = SIT_STA_CGQRYREQ;
         break;

      default:        /* Other cases */
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                                "invalid cntrl.action = %#x\n",
                                cntrl->t.cntrl.action));  
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI801, (ErrVal ) cntrl->t.cntrl.action,
                    "[action] in LM ckt grp request unrecognised ");
#endif
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_ACTION,
                          cntrl->t.cntrl.action, SI_CNTRL_NOK);
         RETVALUE(RFAILED);
    }

    /* send circuit group management request to the state machine */
    if (siMngCirGrpReq(siCir, evntType, &staEvnt) != ROK)
    {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "siCntrlSiCirGrpCb failed\n"));
#if (ERRCLASS & ERRCLS_DEBUG)
       SILOGERROR(ERRCLS_DEBUG, ESI802, (ErrVal ) cntrl->t.cntrl.action,
                  "Can't process LM circuit grp CntrlReq");
#endif
       SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_MISC_FAILURE,
                        key.k1.cirId, SI_CNTRL_NOK);
    }

    /* return confirmation to layer management */
   /* si006.220, MODIFIED: use the hash define instead of 0 */
    SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 0, 
                     SI_CNTRL_OK);
    RETVALUE(ROK);
}


/*
*
*       Fun:   siCntrlSiCirCb
*
*       Desc:  Process control request for an ISUP circuit
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PRIVATE S16 siCntrlSiCirCb
(
Pst    *pst,
SiMngmt *cntrl
)
#else
PRIVATE S16 siCntrlSiCirCb (pst, cntrl)
Pst    *pst;
SiMngmt *cntrl;
#endif
{
   SiCirKey key;
   SiCirCb  *siCir;
   U16      idx;
   CirId  cirId;
   S16     flag;
   SiIntfCb  *siIntfCb;

   TRC3(siCntrlSiCirCb)

#if (SI_LMINT3 || SMSI_LMINT3)
   cirId  = cntrl->t.cntrl.s.siElmnt.elmntId.circuit;
   flag   = cntrl->t.cntrl.s.siElmnt.elmntParam.cir.flag;
#else
   cirId  = cntrl->t.cntrl.sigpt.cirId;
   flag   = cntrl->hdr.elmId.elmntInst2;
#endif

   /* find circuit */
   key.k1.cirId = cirId;
   siFindCir(&siCb.cirHlCp, &siCir, &key, 0, KEY_CIR);

   if (siCir == NULLP)
   {
       SIDBGP(SIDBGMASK_CERR,
              (siCb.init.prntBuf, "no circuit associated with cirId = %#lx\n", 
              key.k1.cirId));  

#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI803, (ErrVal ) 0,
                 "Can not find the circuit indicated in the request");
#endif
      /* si006.220, MODIFIED: return a successful confirmation for deletion
       * of circuit
       */
      if (cntrl->t.cntrl.action == ADEL)
      {
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                          key.k1.cirId, SI_CNTRL_OK);
      }
      else
      {
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_PAR_VAL,
                          key.k1.cirId, SI_CNTRL_NOK);
      }
      RETVALUE(ROK);
   }
   /* find interface block associated with this circuit */
   siIntfCb = siCir->pIntfCb;
   if (siIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
        "interface (id:%ld) mapping is not found ! but cirblk is found\n",
               siCir->cfg.intfId));
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI804, (ErrVal ) siCir->cfg.intfId,
                 "Can not find the intf indicated ");
#endif
      RETVALUE(RFAILED);
   }

   switch (cntrl->t.cntrl.action)
   {
      case AENA :        /* enable - unblock */
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case AENA \n"));   
         siMngCirUnBlk(siCir, flag);
         break;

      case ADISIMM :     /* disable - block */
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case ADISIMM \n"));   
         siMngCirBlk(siCir, flag);
         break;

      case ARST :        /* reset */
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case ARST \n"));   
         siMngCirRes(siCir, (U8 )flag);
         break;

      case ADEL:
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case ADEL \n"));   
         if (siCir->siCon != NULLP)
         {
            if (flag != LSI_CNTRL_CIR_FORCE)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                                 "Active Connection.can't delete circuit\n"));
               SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, 
                                LCM_REASON_LYR_SPECIFIC, 0, SI_CNTRL_NOK);
               RETVALUE(ROK);
            } /* end if */
            else
            {
               /* check the type of connection */
               if (siCir->siCon->incC.cirId == cirId)
               {
                  /* forced delete is valid for releasing states only */
                  switch (siCir->siCon->incC.conState)
                  {
                     case ST_WTFORRLCRRS :
                     case ST_WTFORRELCMP :
                     case ST_WTFORRELRSP :
/* si038.220 : Fix related to SR 53021. Circuit not getting deleted if interface  does not exist */
		     case ST_IDLE:
                        siCir->siCon->incC.relResp = FALSE;
                        siClearIncCon(siCir->siCon);
                        break;

                     default:
                        SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                               "can not delete active/establishing conn.\n"));
                        SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, 
                                         LCM_REASON_LYR_SPECIFIC,
                                         0, SI_CNTRL_NOK);
                        RETVALUE(ROK);
                  }
               } /* end if */
               else if (siCir->siCon->outC.cirId == cirId)
               {
                  /* forced delete is valid for releasing states only */
                  switch (siCir->siCon->outC.conState)
                  {
                     case ST_WTFORRLCRRS :
                     case ST_WTFORRELCMP :
                     case ST_WTFORRELRSP :
/* si038.220 : Fix related to SR 53021. Circuit not getting deleted if interface  does not exist */
		     case ST_IDLE:
                        siCir->siCon->outC.relResp = FALSE;
                        siClearOutCon(siCir->siCon);
                        break;

                     default:
                        SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                               "can not delete active/establishing conn.\n"));
                        SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, 
                                         LCM_REASON_LYR_SPECIFIC,
                                         0, SI_CNTRL_NOK);
                        RETVALUE(ROK);
                  }
               } /* end else if */
            } /* end else */
         } /* end if */
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         else
         {
            /* check if this circuit involved in a non-single rate connection
             * if so, clear the non-single rate conn.
             */
            if (siCir->ctrlMultiRateCir != NULLP)
            {

               /* it is a non-single rate call */
               if (siCir->ctrlMultiRateCir->siCon)
               {
                  if (flag != LSI_CNTRL_CIR_FORCE)
                  {
                     SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                            "Active non-single rate Connection.can't delete circuit\n"));
                     SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, 
                                      LCM_REASON_LYR_SPECIFIC, 0, SI_CNTRL_NOK);
                     RETVALUE(ROK);
                  } /* end if */
                  else
                  {
                     /* check if this is a incoming or outgoing call, and
                      * clear that conn in the releasing state 
                      */
                     if (siCir->ctrlMultiRateCir->siCon->incC.cirId == 
                         siCir->ctrlMultiRateCir->cfg.cirId)
                     {
                        /* forced delete is valid for releasing states only */
                        switch (siCir->ctrlMultiRateCir->siCon->incC.conState)
                        {
                           case ST_WTFORRLCRRS :
                           case ST_WTFORRELCMP :
                           case ST_WTFORRELRSP :
                              siCir->ctrlMultiRateCir->siCon->incC.relResp = FALSE;
                              siClearIncCon(siCir->ctrlMultiRateCir->siCon);
                              break;

                           default:
                              SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "can not\
                                 delete active/establishing non-single conn.\n"));
                              SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, 
                                               LCM_REASON_LYR_SPECIFIC,
                                               0, SI_CNTRL_NOK);
                              RETVALUE(ROK);
                         } /* end of switch */
                      } /* end of if */   
                      else
                      {
                         if (siCir->ctrlMultiRateCir->siCon->outC.cirId == 
                             siCir->ctrlMultiRateCir->cfg.cirId)
                         {
                            /* forced delete is valid for releasing states only */
                            switch (siCir->ctrlMultiRateCir->siCon->outC.conState)
                            {
                               case ST_WTFORRLCRRS :
                               case ST_WTFORRELCMP :
                               case ST_WTFORRELRSP :
                                  siCir->ctrlMultiRateCir->siCon->outC.relResp = FALSE;
                                  siClearOutCon(siCir->ctrlMultiRateCir->siCon);
                                  break;

                               default:
                                  SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,\
                                        "can not delete active/establishing \
                                          non-single rateconn.\n"));
                                  SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, 
                                                   LCM_REASON_LYR_SPECIFIC,
                                                   0, SI_CNTRL_NOK);
                                  RETVALUE(ROK);
                            }
                         } /* end if */
                      } /* end else if */
                   } /* end else */
                } /* end if (siCir->ctrlMultiRateCir->siCon) */
             } /* end if (siCir->ctrlMultiRateCir) */
         } /* end else for non-single rate conn. */
#endif

         /* if circuit group procedures are going on then check
            if this request is for forced delete. If yes then
            stop all circuit & circuit group timers and deallocate
            circuit group & circuit control block */
         for (idx=0; idx< NUMCIREVTGRP; idx++)
         {
            if (siCir->cirGr[idx] != NULLP)
            {
               if (flag != LSI_CNTRL_CIR_FORCE)
               {
                   SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                          "can't delete circuit without FORCED_DEL flag\n"));

                   SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, 
                                    LCM_REASON_LYR_SPECIFIC, 0, SI_CNTRL_NOK);
                   RETVALUE(ROK);
               }

               /* Forced Delete */
               siStopCirGrTmr(siCir->cirGr[idx], TMR_ALL);
               SPutSBuf(siCb.init.region, siCb.init.pool, 
                        (Data *)siCir->cirGr[idx], (Size) sizeof(SiCirGrp));
            }
         }

         /* Need to deallocated the SiCirSts pointer and make other
          * pointer to interface cb, PDU and SDU structure as NULLP if 
          * force delete. 
          * For the nextMultiRateCir and ctrlMultiRateCir pointer in 
          * ANS95, ITU97 and ETSI v3, we already make them NULLP while 
          * we clear the non-single rate connection above.
          */
         if (siCir->sts != NULLP)
         {
            SPutSBuf(siCb.init.region, siCb.init.pool, 
                     (Data *)siCir->sts, (Size) sizeof(SiCirSts));
         }

         if ((siCir->pIntfCb != NULLP) ||
             (siCir->pduSp != NULLP) || (siCir->sduSp != NULLP))
         {
            /* make them to NULLP */
            if (siCir->pIntfCb != NULLP)
               siCir->pIntfCb = NULLP;
            else 
            {
               if (siCir->pduSp != NULLP)
                  siCir->pduSp = NULLP;
               else
                  siCir->sduSp = NULLP;
            }      
         }

         /* stop circuit timers */
         siStopAllCirTmr(siCir);
         /* delete circuit from the hash list */
         siDelCir(&siCb.cirHlCp, siCir);
#ifdef ZI
         /* si006.220, MODIFIED: runtime update only for active copy since we 
          * support the deletion on standby copy also as per TCR21
          */
         if (ziCb.protState == ACTIVE)
            ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_DELETE_REQ, (PTR) siCir);
#endif
         /* release the memory */
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCir, 
                  (Size) sizeof(SiCirCb));

         siCb.cirCnt--;

#ifdef ZI
         /* si006.220, MODIFIED: runtime update only for active copy since we 
          * support the deletion on standby copy also as per TCR21
          */
         if (ziCb.protState == ACTIVE)
            ziUpdPeer();
#endif
         break;

      default:
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                                   "invalid action %d\n",
                                   cntrl->t.cntrl.action));  
#if (ERRCLASS & ERRCLS_INT_PAR)
            SILOGERROR(ERRCLS_INT_PAR, ESI805, (ErrVal) 0, 
                       "SiMiLsiCntrlReq() Failed, invalid action");
#endif
            SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, 
                             LCM_REASON_INVALID_ACTION, cntrl->t.cntrl.action, 
                             SI_CNTRL_NOK);
            RETVALUE(RFAILED);
   }

   /* si006.220, MODIFIED: use the hash define instead of 0 */
   SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 0, 
                    SI_CNTRL_OK);
   RETVALUE(ROK);
}

#if (SI_LMINT3 || SMSI_LMINT3)


/*
*
*       Fun:   siRelNSAPCon
*
*       Desc:  Release all connections associated with a N/w SAP(MTP-3/SCCP)
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: 
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siRelNSAPCon 
(
SiNSAPCb *nCb
)
#else
PUBLIC S16 siRelNSAPCon (nCb)
SiNSAPCb *nCb;
#endif
{
   SiCon *con;
   SiCon *prevCon;
   SiCon *nextCon;
#ifdef SI_SPT
   Bool    prevCbDel;
   SiCirCb *tmpCir;
#endif

   TRC2(siRelNSAPCon)

   con     = NULLP;
   prevCon = NULLP;
   nextCon = NULLP;
#ifdef SI_SPT
   prevCbDel = FALSE;
#endif

   switch (nCb->cfg.sapType)
   { 
      case SAP_MTP:
      case SAP_M3UA:
         /* Get the first element */
         if (cmHashListGetNext(&siCb.conHlCp.instCp, (PTR)NULLP,
                  (PTR *)&con) == ROK)
         {
            do 
            {  
               con = nextCon;
               /* Prior to processing get the next connection */
               if (cmHashListGetNext(&siCb.conHlCp.instCp, (PTR)con,
                     (PTR *) &nextCon) != ROK)
                   nextCon = NULLP;

               if (con && (con->mCallCb == nCb))
               {
                  /* reset the associated circuits */
                  if (con->incC.conPrcs == TRUE)
                  {
                     /* simualte a n/w initiated RSC; donot send RLC on 
                      * receiving reset confirmation from upper layer */
                     if (con->outC.conPrcs)
                     {
                        con->outC.cir->noRspFlgToLw = TRUE;
                        siProcCirMsg(con->outC.cir, CEI_RES, TRUE);
                     }
   
                     /* simulate a n/w initiated RSC - don't send the RLC back */
                     con->incC.cir->noRspFlgToLw = TRUE;
                     siProcCirMsg(con->incC.cir, CEI_RES, TRUE);
                  }
                  /* process outgoing (only) connection control blocks */
                  else if (con->outC.conPrcs == TRUE)
                  {
                     con->outC.cir->noRspFlgToLw = TRUE;
                     siProcCirMsg(con->outC.cir, CEI_RES, TRUE);
                  }
               }
            } while(nextCon);
         }
         break;

#ifdef SI_SPT
      case SAP_SCCP:
         while (cmHashListGetNext(&siCb.conHlCp.instCp, (PTR) prevCon, 
                                  (PTR *) &con) == ROK) 
         {
            if (con && (con->sCallCb == nCb) && (con->sccpUsed))
            {
               /* reset the associated circuits */
               if (con->incC.conPrcs == TRUE)
               {
                  /* simualte a n/w initiated RSC; donot send RLC on 
                   * receiving reset confirmation from upper layer */
                  if (con->outC.conPrcs)
                  {
                     con->outC.cir->noRspFlgToLw = TRUE;
                     siProcCirMsg(con->outC.cir, CEI_RES, TRUE);
                  }

                  /* simulate a n/w initiated RSC - don't send the RLC back */
                  con->incC.cir->noRspFlgToLw = TRUE;
                  siProcCirMsg(con->incC.cir, CEI_RES, TRUE);
               }
               /* process outgoing (only) connections */
               else if (con->outC.conPrcs == TRUE)
               {
                  tmpCir = con->outC.cir;
                  con->outC.cir->noRspFlgToLw = TRUE;
                  siProcCirMsg(con->outC.cir, CEI_RES, TRUE);
                  if (tmpCir->siCon == NULLP)
                     prevCbDel = TRUE;
               }
            }

            if (!prevCbDel) 
               prevCon = con;
            else
               prevCbDel = FALSE;
         }
         break;
#endif

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI806, (ErrVal) nCb->cfg.sapType,
                    "siRelNSAPCon() Failed, unknown NSAP type");
#endif
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
}/* siRelNSAPCon */


/*
*
*       Fun:   siRelUpSAPCon
*
*       Desc:  Release connections associated with an ISUP upper SAP
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: 
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siRelUpSAPCon 
(
SiUpSAPCb *tCb
)
#else
PUBLIC S16 siRelUpSAPCon (tCb)
SiUpSAPCb *tCb;
#endif
{
   SiCon *con;
   SiCon *prevCon;

   TRC2(siRelUpSAPCon)

   con     = NULLP;
   prevCon = NULLP;

   while (cmHashListGetNext(&siCb.conHlCp.instCp, (PTR) prevCon, 
                            (PTR *) &con) == ROK) 
   {
      if (con && (con->tCallCb == tCb))
      {
         /* process incoming and transit connection control blocks */
         if (con->incC.conPrcs == TRUE)
         {
            /* if there is an outgoing call associated clear it first */
            if (con->outC.conPrcs)
            {
               /* simulate an outgoing reset request */
               con->outC.cir->noRspFlgToUp = TRUE;
               siProcCirEvt(con->outC.cir, CEI_RESREQ, TRUE);
            }

            /* simulate an outgoing reset request */
            con->incC.cir->noRspFlgToUp = TRUE;
            siProcCirEvt(con->incC.cir, CEI_RESREQ, TRUE);
         }
         /* process outgoing (only) connection control blocks */
         else if (con->outC.conPrcs == TRUE)
         {
            con->outC.cir->noRspFlgToUp = TRUE;
            siProcCirEvt(con->outC.cir, CEI_RESREQ, TRUE);
         }
      }
      prevCon = con;
   }

   RETVALUE(ROK);
}/* siRelUpSAPCon */


/*
*
*       Fun:   siCntrlNSAPNew
*
*       Desc:  Process NSAP control request - LMINT3 semantics
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PRIVATE  S16 siCntrlNSAPNew
(
Pst *pst,
SiMngmt *cntrl
)
#else
PRIVATE S16 siCntrlNSAPNew (pst, cntrl)
Pst *pst;
SiMngmt *cntrl;
#endif
{
   SiNSAPCb *cb;

   TRC3(siCntrlNSAPNew)

   switch (cntrl->t.cntrl.s.siElmnt.elmntParam.nsap.nsapType)
   {
      case SAP_MTP:
      case SAP_M3UA:
         if ((cb = SIMTPSAP(cntrl->t.cntrl.s.siElmnt.elmntId.sapId)) == NULLP)
         {
            /* si006.220, MODIFIED: return a successful confirmation for 
             * deletion of NSAP
             */
            if (cntrl->t.cntrl.action == ADEL)
            {
               cntrl->cfm.status = LCM_PRIM_OK;
               cntrl->cfm.reason = LCM_REASON_NOT_APPL;
            }
            else
            {
               cntrl->cfm.status = LCM_PRIM_NOK;
               cntrl->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
            }
            SiMiLsiCntrlCfm(pst, cntrl);
            RETVALUE(ROK);
         }
         switch (cntrl->t.cntrl.action)
         {
            case ABND_ENA:
               /* si001.220, ADDED: Added code to check the remote version 
                * number is valid or not. Otherwise, generate a negative
                * response
                */
#ifdef SI_RUG
               /* Bind cannot be performed in SAP does not have valid remote
                * interface version i.e. version sync not done
                */
               if (cb->remIntfValid == FALSE)
               {
                  cntrl->cfm.status = LCM_PRIM_NOK;
                  cntrl->cfm.reason = LCM_REASON_SWVER_NAVAIL;
                  SiMiLsiCntrlCfm(pst, cntrl);
                  RETVALUE(RFAILED);
               }
#endif /* SI_RUG */
               siBindMTPSAP(cb);
#ifdef SI_FTHA
               cb->contEntity = ENTNC;
#endif               
#ifdef ZI
               ziRunTimeUpd(ZI_MTP3SAP_CB, CMPFTHA_UPD_REQ, (PTR) cb);
#endif
               break;

            case AUBND_DIS:
               cb->state = SI_UNBND;  
               siRelNSAPCon(cb);
#ifdef SI_FTHA
               cb->contEntity = ENTSM;
#endif /* SI_FTHA */               
#ifdef ZI
               ziRunTimeUpd(ZI_MTP3SAP_CB, CMPFTHA_UPD_REQ, (PTR) cb);
#endif
               break;

            /* si006.220, ADDED: added deletion of NSAP. The sap should
             * be in the unbound state and all the interface associated 
             * with this sap should be already removed
             */
            case ADEL:
            {
               SpId       sapId;     /* sapId of deleted SAP */

               sapId = cntrl->t.cntrl.s.siElmnt.elmntId.sapId;

               /* check the sap state */
               if (cb->state != SI_UNBND)
               {
                  cntrl->cfm.status = LCM_PRIM_NOK;
                  cntrl->cfm.reason = LCM_CAUSE_INV_STATE;
                  SiMiLsiCntrlCfm(pst, cntrl);
                  RETVALUE(RFAILED);
               }

               /* check if there exists interface control block associated
                * with this SAP
                */
               if ((siFndIntfInSAP(sapId, cntrl->hdr.elmId.elmnt,
                    cntrl->t.cntrl.s.siElmnt.elmntParam.nsap.nsapType)) == ROKDNA)
               {
                  cntrl->cfm.status = LCM_PRIM_NOK;
                  cntrl->cfm.reason = LCM_CAUSE_INV_STATE;
                  SiMiLsiCntrlCfm(pst, cntrl);
                  RETVALUE(RFAILED);
               }

#ifdef ZI
               /* si006.220, MODIFIED: runtime update only for active copy 
                * since we support the deletion on standby copy also as 
                * per TCR21
                */
               if (ziCb.protState == ACTIVE)
                  ziRunTimeUpd(ZI_MTP3SAP_CB, CMPFTHA_DELETE_REQ, (PTR) cb);
#endif
               /* delete the sap */
               SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cb,
                        (Size) sizeof(SiNSAPCb));
               *(siCb.mtpSAPLst + sapId) = NULLP;
               break;
            }
            default: /* invalid action */
               cntrl->cfm.status = LCM_PRIM_NOK;
               cntrl->cfm.reason = LCM_REASON_INVALID_ACTION;
               SiMiLsiCntrlCfm(pst, cntrl);
               RETVALUE(RFAILED);
         }
         break;

#ifdef SI_SPT
      case SAP_SCCP:
         if (siCb.genCfg.sccpSup == TRUE)
         {
            if ((cb = SISCCPSAP(cntrl->t.cntrl.s.siElmnt.elmntId.sapId)) == 
                    NULLP)
            {
               /* si006.220, MODIFIED: return a successful confirmation for 
                * deletion of NSAP
                */
               if (cntrl->t.cntrl.action == ADEL)
               {
                  cntrl->cfm.status = LCM_PRIM_OK;
                  cntrl->cfm.reason = LCM_REASON_NOT_APPL;
               }
               else
               {
                  cntrl->cfm.status = LCM_PRIM_NOK;
                  cntrl->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
               }
               SiMiLsiCntrlCfm(pst, cntrl);
               RETVALUE(ROK);
            }
            switch (cntrl->t.cntrl.action)
            {
               case ABND_ENA:
                  /* si001.220, ADDED: Added code to check the remote version 
                   * number is valid or not. Otherwise, generate a negative
                   * response
                   */
#ifdef SI_RUG
                  /* Bind cannot be performed in SAP does not have valid remote
                   * interface version i.e. version sync not done
                   */
                  if (cb->remIntfValid == FALSE)
                  {
                     cntrl->cfm.status = LCM_PRIM_NOK;
                     cntrl->cfm.reason = LCM_REASON_SWVER_NAVAIL;
                     SiMiLsiCntrlCfm(pst, cntrl);
                     RETVALUE(RFAILED);
                  }
#endif /* SI_RUG */
                  siBindSCCPSAP(cb);
#ifdef SI_FTHA 
                  cb->contEntity = ENTNC;
#endif                   
#ifdef ZI
                  ziRunTimeUpd(ZI_SCCPSAP_CB, CMPFTHA_UPD_REQ, 
                            (PTR) cb);
#endif
                  break;

               case AUBND_DIS:
                  cb->state = SI_UNBND;
                  siRelNSAPCon(cb);
#ifdef SI_FTHA
                  cb->contEntity = ENTSM;
#endif                  
#ifdef ZI
                  ziRunTimeUpd(ZI_SCCPSAP_CB, CMPFTHA_UPD_REQ, 
                            (PTR) cb);
#endif
                  break;

               /* si006.220, ADDED: added deletion of NSAP. */
               case ADEL:
               {
                  SpId       sapId;     /* sapId of deleted SAP */

                  sapId = cntrl->t.cntrl.s.siElmnt.elmntId.sapId;

                  /* check the sap state */
                  if (cb->state != SI_UNBND)
                  {
                     cntrl->cfm.status = LCM_PRIM_NOK;
                     cntrl->cfm.reason = LCM_CAUSE_INV_STATE;
                     SiMiLsiCntrlCfm(pst, cntrl);
                     RETVALUE(RFAILED);
                  }

                  /* check if there exists interface control block associated
                   * with this SAP
                   */
                  if ((siFndIntfInSAP(sapId, cntrl->hdr.elmId.elmnt,
                       cntrl->t.cntrl.s.siElmnt.elmntParam.nsap.nsapType)) 
                       == ROKDNA)
                  {
                     cntrl->cfm.status = LCM_PRIM_NOK;
                     cntrl->cfm.reason = LCM_CAUSE_INV_STATE;
                     SiMiLsiCntrlCfm(pst, cntrl);
                     RETVALUE(RFAILED);
                  }

#ifdef ZI
                  if (ziCb.protState == ACTIVE)
                     ziRunTimeUpd(ZI_SCCPSAP_CB, CMPFTHA_DELETE_REQ, (PTR) cb);
#endif
                  /* delete the sap */
                  SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cb,
                           (Size) sizeof(SiNSAPCb));
                  *(siCb.sccpSAPLst + sapId) = NULLP;
                  break;
               }

               default: /* invalid action */
                  cntrl->cfm.status = LCM_PRIM_NOK;
                  cntrl->cfm.reason = LCM_REASON_INVALID_ACTION;
                  SiMiLsiCntrlCfm(pst, cntrl);
                  RETVALUE(RFAILED);
            }

         }
         else /* SCCP not supported in the system */
         {
            cntrl->cfm.status = LCM_PRIM_NOK;
            cntrl->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
            SiMiLsiCntrlCfm(pst, cntrl);
         }
         break;
#endif /* SI_SPT */

      default: /* invalid SAP type */
         cntrl->cfm.status = LCM_PRIM_NOK;
         cntrl->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
         SiMiLsiCntrlCfm(pst, cntrl);
         RETVALUE(RFAILED);
   }

   cntrl->cfm.status = LCM_PRIM_OK;
   cntrl->cfm.reason = LCM_REASON_NOT_APPL;
   SiMiLsiCntrlCfm(pst, cntrl);

#ifdef ZI
   /* si006.220, MODIFIED: runtime update only for active copy since we 
    * support the deletion on standby copy also as per TCR21
    */
   if (ziCb.protState == ACTIVE) 
      ziUpdPeer();
#endif

   RETVALUE(ROK);
}

/*
*
*       Fun:   siCntrlUpSAP
*
*       Desc:  control upper SAP
*              
*       Ret:   ROK - ok; RFAILED - failed
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PRIVATE S16 siCntrlUpSAP
(
Pst     *pst,
SiMngmt *cntrl
)
#else
PRIVATE S16 siCntrlUpSAP (pst, cntrl)
Pst     *pst;
SiMngmt *cntrl;
#endif
{
   SiUpSAPCb *tCb;
   SpId      spId;

   TRC2(siCntrlUpSAP)

   /* si006.220, DELETED: modified code to support the deletion of ISAP */

   spId = cntrl->t.cntrl.s.siElmnt.elmntId.sapId;

   /* si006.220, MODIFIED: return a successful confirmation for deletion of ISAP
    * if the upper SAP control block could not be found
    */
   if ((spId > (SpId)siCb.genCfg.nmbSaps) || (spId < 0))
   {
      SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_SAP,
                       sapId, SIISAP_INV);
      RETVALUE(ROK);
   }
   if (NULLP == (tCb = SIUPSAP(spId)))
   {
      if (cntrl->t.cntrl.action == ADEL)
      {
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                          sapId, SI_CNTRL_OK);
      }
      else
      {
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_SAP,
                          sapId, SIISAP_INV);
      }
      RETVALUE(ROK);
   }

   /* si006.220, MODIFIED: modified code to support the deletion of ISAP */
   switch (cntrl->t.cntrl.action)
   {
      case AUBND_DIS:
         tCb->state = SI_UNBND;
   
         /* si001.220, ADDED: If the version controlling entity for upper SAP is
          * Layer Manager the do not mark the remote interface version in the SAP
          * as invalid. Otherwise mark the remote intf version as invalid on SAP
          * being unbound
          */
#ifdef SI_RUG
         if (tCb->verContEnt == ENTNC)
            tCb->remIntfValid = FALSE;
#endif

         siRelUpSAPCon(tCb);
#ifdef ZI
         ziRunTimeUpd(ZI_UPSAP_CB, CMPFTHA_UPD_REQ, (PTR) tCb);
#endif
         break;

      case ADEL:
      {
         /* check the sap state */
         if (tCb->state != SI_UNBND)
         {
            cntrl->cfm.status = LCM_PRIM_NOK;
            cntrl->cfm.reason = LCM_CAUSE_INV_STATE;
            SiMiLsiCntrlCfm(pst, cntrl);
            RETVALUE(RFAILED);
         }

         /* check if there exists interface control block associated
          * with this SAP
          */
         if ((siFndIntfInSAP(spId, cntrl->hdr.elmId.elmnt,0)) == ROKDNA)
         {
            cntrl->cfm.status = LCM_PRIM_NOK;
            cntrl->cfm.reason = LCM_CAUSE_INV_STATE;
            SiMiLsiCntrlCfm(pst, cntrl);
            RETVALUE(RFAILED);
         }

#ifdef ZI
         if (ziCb.protState == ACTIVE) 
            ziRunTimeUpd(ZI_UPSAP_CB, CMPFTHA_DELETE_REQ, (PTR) tCb);
#endif
         /* delete the sap */
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)tCb,
                  (Size) sizeof(SiUpSAPCb));
         *(siCb.upSAPLst + spId) = NULLP;
         break;
      }

      default: /* invalid action */
         cntrl->cfm.status = LCM_PRIM_NOK;
         cntrl->cfm.reason = LCM_REASON_INVALID_ACTION;
         SiMiLsiCntrlCfm(pst, cntrl);
         RETVALUE(RFAILED);
   }

   cntrl->cfm.status = LCM_PRIM_OK;
   cntrl->cfm.reason = LCM_REASON_NOT_APPL;
   SiMiLsiCntrlCfm(pst, cntrl);

#ifdef ZI
   /* si006.220, MODIFIED: runtime update only for active copy since we 
    * support the deletion on standby copy also as per TCR21
    */
   if (ziCb.protState == ACTIVE) 
      ziUpdPeer();
#endif

   RETVALUE(ROK);
} /* siCntrlUpSAP */


/*
*
*       Fun:   siCntrlGrpSAP
*
*       Desc:  Control a group of SAPs (upper/network) based on a specific
*              criteria
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PRIVATE S16 siCntrlGrpSAP 
(
Pst *pst,
SiMngmt *cntrl
)
#else
PRIVATE S16 siCntrlGrpSAP (pst, cntrl)
Pst *pst;
SiMngmt *cntrl;
#endif
{
   SiUpSAPCb *tCb;
   SiNSAPCb  *nCb;
   Cntr      i;
   U8        dstProcId;
#ifdef IW
   IwCcSap    *cCb;        /* CC-IW SAP Control block pointer */
   IwRmSap    *rCb;        /* IW-RM SAP Control block pointer */
   U32         maxVal;     /* Max range of SAPs               */
#endif
   
   TRC2(siCntrlGrpSAP)
   
   dstProcId = (U8 )cntrl->t.cntrl.s.siElmnt.elmntId.dstProcId;

#ifdef IW
   maxVal = (iwCp.maxNmbCcEnt * iwCp.maxNmbSwtch * LIW_MAX_NT);
#endif
   switch (cntrl->hdr.elmId.elmnt)
   {
      case STGRPUPSAP:
         switch (cntrl->t.cntrl.action)
         {
            case AUBND_DIS:
               /* If ISUP-PSIF is also enabled then the visible upper
                * SAPs are the upper SAPs of PSIF.
                */
#ifdef IW
               for (i = 0; i < (Cntr) maxVal; i++)
               {
                  cCb = IWGETCCSAP(i);

                  /* if CC SAP exists and dstprocid matches */
                  if ((cCb) && (cCb->pst.dstProcId == dstProcId))
                  {
                     /* Disable the SAP and clear the connections
                      * associated with it.
                      */
                     iwUbndDisCcSap(cCb); 
                  }
               }
#else    /* If only ISUP is available, then process on basis of
          * ISUPs upper SAP.
          */
               for (i = 0; i < (Cntr) siCb.genCfg.nmbSaps; i++)
               {
                  if ( ((tCb = SIUPSAP(i)) != NULLP) &&
                       (tCb->pst.dstProcId == dstProcId))
                  {
                     tCb->state = SI_UNBND;
                     /* si001.220, ADDED: If the version controlling entity 
                      * for upper SAP is Layer Manager the do not mark the 
                      * remote interface version in the SAP as invalid. 
                      * Otherwise mark the remote intf version as invalid on SAP
                      * being unbound
                      */
#ifdef SI_RUG
                     if (tCb->verContEnt == ENTNC)
                        tCb->remIntfValid = FALSE;
#endif
                     siRelUpSAPCon(tCb);

#ifdef ZI
                      ziRunTimeUpd(ZI_UPSAP_CB, CMPFTHA_UPD_REQ, 
                                   (PTR) tCb);
#endif
                  }
               }
#endif
               break;

            default:
               cntrl->cfm.status = LCM_PRIM_NOK;
               cntrl->cfm.reason = LCM_REASON_INVALID_ACTION;
               SiMiLsiCntrlCfm(pst, cntrl);
               RETVALUE(RFAILED);
         }
         break;

      case STGRPNSAP:
         switch (cntrl->t.cntrl.action)
         {
            case ABND_ENA:
               /* si001.220, ADDED: Added code to check the remote 
                * version number is valid or not. Otherwise, generate 
                * a negative response
                * This check should be performed before sending a bind req
                */
#ifdef SI_RUG
               for (i = 0; i < (Cntr) siCb.genCfg.nmbNSaps; i++)
               {
                  if ( ((nCb = SIMTPSAP(i)) != NULLP) &&
                     (nCb->pst.dstProcId == dstProcId))
                  {
                     /* Bind cannot be performed in SAP does not have valid 
                      * remote interface version i.e. version sync not done
                      */
                     if (nCb->remIntfValid == FALSE)
                     {
                        cntrl->cfm.status = LCM_PRIM_NOK;
                        cntrl->cfm.reason = LCM_REASON_SWVER_NAVAIL;
                        SiMiLsiCntrlCfm(pst, cntrl);
                        RETVALUE(RFAILED);
                     }
                  }   
               }
#endif /* SI_RUG */
               for (i = 0; i < (Cntr) siCb.genCfg.nmbNSaps; i++)
               {
                  if ( ((nCb = SIMTPSAP(i)) != NULLP) &&
                     (nCb->pst.dstProcId == dstProcId))
                  {
                     siBindMTPSAP(nCb);
#ifdef SI_FTHA
                     nCb->contEntity = ENTNC;
#endif
#ifdef ZI
                     ziRunTimeUpd(ZI_MTP3SAP_CB, CMPFTHA_UPD_REQ, (PTR) nCb);
#endif
                  }
               }
               break;

            case AUBND_DIS:
               for (i = 0; i < (Cntr) siCb.genCfg.nmbNSaps; i++)
               {
                  if ( ((nCb = SIMTPSAP(i)) != NULLP) &&
                     (nCb->pst.dstProcId == dstProcId))
                  {
                     nCb->state = SI_UNBND;
                     siRelNSAPCon(nCb);
#ifdef SI_FTHA
                     nCb->contEntity = ENTSM;
#endif
#ifdef ZI
                     ziRunTimeUpd(ZI_MTP3SAP_CB, CMPFTHA_UPD_REQ,
                                    (PTR) nCb);
#endif
                  }
               }
               break;

            default:
               cntrl->cfm.status = LCM_PRIM_NOK;
               cntrl->cfm.reason = LCM_REASON_INVALID_ACTION;
               SiMiLsiCntrlCfm(pst, cntrl);
               RETVALUE(RFAILED);
         }

#ifdef SI_SPT
         if (siCb.genCfg.sccpSup)
         {
            switch (cntrl->t.cntrl.action)
            {
               case ABND_ENA:
                  /* si001.220, ADDED: Added code to check the remote 
                   * version number is valid or not. Otherwise, generate 
                   * a negative response
                   * This check should be performed before sending a bind req
                   */
#ifdef SI_RUG
                  for (i = 0; i < (Cntr) siCb.genCfg.nmbNSaps; i++)
                  {
                     if ( ((nCb = SISCCPSAP(i)) != NULLP) &&
                          (nCb->pst.dstProcId == dstProcId))
                     {
                        /* Bind cannot be performed in SAP does not have valid
                         *  remote interface version i.e. version sync not done
                         */
                        if (nCb->remIntfValid == FALSE)
                        {
                           cntrl->cfm.status = LCM_PRIM_NOK;
                           cntrl->cfm.reason = LCM_REASON_SWVER_NAVAIL;
                           SiMiLsiCntrlCfm(pst, cntrl);
                           RETVALUE(RFAILED);
                        }
                     }
                  }
#endif /* SI_RUG */
                  for (i = 0; i < (Cntr) siCb.genCfg.nmbNSaps; i++)
                  {
                     if ( ((nCb = SISCCPSAP(i)) != NULLP) &&
                          (nCb->pst.dstProcId == dstProcId))
                     {
                        siBindSCCPSAP(nCb);
#ifdef SI_FTHA
                        nCb->contEntity = ENTNC;
#endif
#ifdef ZI
                        ziRunTimeUpd(ZI_SCCPSAP_CB,
                                     CMPFTHA_UPD_REQ, (PTR) nCb);
#endif
                     }
                  }
                  break;

               case AUBND_DIS:
                  for (i = 0; i < (Cntr) siCb.genCfg.nmbNSaps; i++)
                  {
                     if ( ((nCb = SISCCPSAP(i)) != NULLP) &&
                          (nCb->pst.dstProcId == dstProcId))
                     {
                        nCb->state = SI_UNBND;
                        siRelNSAPCon(nCb);
#ifdef SI_FTHA
                        nCb->contEntity = ENTSM;
#endif
#ifdef ZI
                        ziRunTimeUpd(ZI_SCCPSAP_CB,
                                           CMPFTHA_UPD_REQ, (PTR) nCb);
#endif
                        }
                     }
                     break;

               default:
                  cntrl->cfm.status = LCM_PRIM_NOK;
                  cntrl->cfm.reason = LCM_REASON_INVALID_ACTION;
                  SiMiLsiCntrlCfm(pst, cntrl);
                  RETVALUE(RFAILED);
            }

         } /* end if sccpSup */
#endif /* SI_SPT */

#ifdef IW
         /* Currently one SAP towards RM is supported */
         rCb = IWGETRMSAP(0);
         if (rCb == NULLP)
         {
            cntrl->cfm.status = LCM_PRIM_NOK;
            cntrl->cfm.reason = LCM_REASON_INVALID_SAP;
            SiMiLsiCntrlCfm(pst, cntrl);
            RETVALUE(RFAILED);
         }

               /* Proceed if the destination proc id matches */
         if (rCb->pst.dstProcId != dstProcId)
            break;

         switch (cntrl->t.cntrl.action)
         {
            case ABND_ENA: /* Bind enable */
               if (IW_UNBND == rCb->state)
               {
                  rCb->state = IW_BND_CONT;
                  iwStartRmSapTmr((PTR)rCb, TMR_TBNDCFM);
                  IwLiRmtBndReq(&rCb->pst, rCb->suId, rCb->spId);
#ifdef SI_FTHA
                  rCb->contEntity = ENTNC;
#endif
#ifdef ZI
                  ziRunTimeUpd(ZI_IWRMSAP_CB, CMPFTHA_UPD_REQ, (PTR)rCb);
#endif
               }
               break;

            case AUBND_DIS:/* Unbind disable */
               /* Disable the RM SAP */
               iwUbndDisRmSap(rCb);
#ifdef SI_FTHA
               rCb->contEntity = ENTSM;
#endif
               /* Peer updated in iwUbndDisRmSap for ZI */
               break;

            default: /* default actions */
               cntrl->cfm.status = LCM_PRIM_NOK;
               cntrl->cfm.reason = LCM_REASON_INVALID_ACTION;
               SiMiLsiCntrlCfm(pst, cntrl);
               break;
         }
#endif
         break;

      case STALLSAP:
      {
         SiCon *con;

         if (cntrl->t.cntrl.action != AUBND_DIS)
         {
            cntrl->cfm.status = LCM_PRIM_NOK;
            cntrl->cfm.reason = LCM_REASON_INVALID_ACTION;
            SiMiLsiCntrlCfm(pst, cntrl);
            RETVALUE(RFAILED);
         }

#ifdef IW
         for (i = 0; i < (Cntr)maxVal; i++)
#else
         for (i = 0; i < (Cntr) siCb.genCfg.nmbSaps; i++)
#endif
         {
#ifdef IW
            cCb = IWGETCCSAP(i);
            
            /* If SAP control block is not present proceed */
            if (!cCb)
               continue;
            /* Mark the state of the SAP as unbound */
            cCb->state = IW_UNBND;
#ifdef ZI
            ziRunTimeUpd(ZI_IWCCSAP_CB, CMPFTHA_UPD_REQ, (PTR)cCb);
            ziUpdPeer();  /* Send the update message to peer PSF */
#endif
            /* Find corresponding lower SAP towards ISUP */
            tCb = siGetCbPtr(cCb->swtch, cCb->ssf);
#else
            tCb = SIUPSAP(i);
#endif
            if (tCb != NULLP)
            {
               
#ifdef IW
               /* ISUP's Upper SAP status is not changed as it is not
                * visible if PSIF is defined 
                */
#else
               tCb->state = SI_UNBND;
               /* si001.220, ADDED: If the version controlling entity 
                * for upper SAP is Layer Manager the do not mark the 
                * remote interface version in the SAP as invalid. 
                * Otherwise mark the remote intf version as invalid on SAP
                * being unbound
                */
#ifdef SI_RUG
               if (tCb->verContEnt == ENTNC)
                  tCb->remIntfValid = FALSE;
#endif /* SI_RUG */
#endif

               /* start deleting connections */
               con     = NULLP;

               while (cmHashListGetNext(&siCb.conHlCp.instCp, (PTR) NULLP, 
                                       (PTR *) &con) == ROK) 
               {
                  if (con && (con->tCallCb == tCb))
                  {
                     /* process incoming & transit connection control blocks */
                     if (con->incC.conPrcs == TRUE)
                     {
                        con->incC.relResp = FALSE;

                        /* if there is an outgoing call, clear it first */
                        if (con->outC.conPrcs)
                           con->outC.relResp = FALSE;
#ifdef ZI
                        ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, 
                                     (PTR) con);
#endif
                        /* this will clear connection control block */
                        siClearIncCon(con);
                     }
                     /* process outgoing (only) connection control blocks */
                     else if (con->outC.conPrcs == TRUE)
                     {
                        con->outC.relResp = FALSE;
#ifdef ZI
                        ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, 
                                     (PTR) con);
#endif
                        /* this will clear connection control block */
                        siClearOutCon(con);
                     }
                  }
               }
#ifdef IW
               /* If PSIF is defined then do not update the ISUP upper
                * SAP
                */
#else
#ifdef ZI
               ziRunTimeUpd(ZI_UPSAP_CB, CMPFTHA_UPD_REQ, (PTR) tCb);
#endif
#endif
            }
         }

         for (i = 0; i < (Cntr) siCb.genCfg.nmbNSaps; i++)
         {
            nCb = SIMTPSAP(i);
            if (nCb != NULLP)
            {
               nCb->state = SI_UNBND;
#ifdef SI_FTHA
               nCb->contEntity = ENTSM;
#endif

               con     = NULLP;

               while (cmHashListGetNext(&siCb.conHlCp.instCp, (PTR) NULLP, 
                                       (PTR *) &con) == ROK) 
               {
                  if (con && (con->mCallCb == nCb))
                  {
                     if (con->incC.conPrcs == TRUE)
                     {
                        if (con->outC.conPrcs)
                           con->outC.relResp = FALSE;

                        con->incC.relResp = FALSE;
#ifdef ZI
                        ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, 
                                     (PTR) con);
#endif
                        /* this will clear connection control block */
                        siClearIncCon(con);
                     }
                     /* process outgoing (only) connection control blocks */
                     else if (con->outC.conPrcs == TRUE)
                     {
                        con->outC.relResp = FALSE;
#ifdef ZI
                        ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, 
                                     (PTR) con);
#endif
                        siClearOutCon(con);
                     }
                  }
               }

#ifdef ZI
               ziRunTimeUpd(ZI_MTP3SAP_CB, CMPFTHA_UPD_REQ, (PTR) nCb);
#endif
            }
         }         
#ifdef SI_SPT 
         if (siCb.genCfg.sccpSup)
         {
            for (i = 0; i < (Cntr) siCb.genCfg.nmbNSaps; i++)
            {
               nCb = SISCCPSAP(i);

               if (nCb != NULLP)
               {
                  nCb->state = SI_UNBND;
#ifdef SI_FTHA
                  nCb->contEntity = ENTSM;
#endif                  

                  con     = NULLP;

                  while (cmHashListGetNext(&siCb.conHlCp.instCp, (PTR) NULLP, 
                                          (PTR *) &con) == ROK) 
                  {
                     if (con && (con->sCallCb == nCb))
                     {
                        if (con->incC.conPrcs == TRUE)
                        {
                           if (con->outC.conPrcs)
                              con->outC.relResp = FALSE;

                           con->incC.relResp = FALSE;
#ifdef ZI
                           ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, 
                                       (PTR) con);
#endif
                           /* this will clear connection control block */
                           siClearIncCon(con);
                        }
                        /* process outgoing (only) connection control blocks */
                        else if (con->outC.conPrcs == TRUE)
                        {
                           con->outC.relResp = FALSE;
#ifdef ZI
                           ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, 
                                       (PTR) con);
#endif
                           siClearOutCon(con);
                        }
                     }
                  }

#ifdef ZI
                  ziRunTimeUpd(ZI_SCCPSAP_CB, CMPFTHA_UPD_REQ, (PTR) nCb);
#endif
               }
            }         
         }
#endif /* SI_SPT */

#ifdef IW
         /* Currently one SAP towards RM is supported */
         rCb = IWGETRMSAP(0);
         if (rCb)
         {
            /* Disable the RM SAP */
            iwUbndDisRmSap(rCb);
#ifdef SI_FTHA
            rCb->contEntity = ENTSM;
#endif
         }
#endif
      }

   } /* case elmnt */

   cntrl->cfm.status = LCM_PRIM_OK;
   cntrl->cfm.reason = LCM_REASON_NOT_APPL;
   SiMiLsiCntrlCfm(pst, cntrl);

#ifdef ZI
   ziUpdPeer();
#endif

   RETVALUE(ROK); 
}/* siCntrlGrpSAP */


#ifdef IW
/*
*
*       Fun:   siGetNmbDpcCic
*
*       Desc:  
*
*       Ret:   U16 nmbDpcCic
*
*       Notes: 
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC U16 siGetNmbDpcCic
(
Swtch swtch
)
#else
PUBLIC U16 siGetNmbDpcCic (swtch)
Swtch swtch;
#endif
{

   U16  nmbDpcCic;

   TRC2(siGetNmbDpcCic)

   switch (swtch)
   {
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
        case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
        case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
       case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         nmbDpcCic = 4096;
         break;
      
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "Invalid variant type %#x, return the default value\n",swtch));  
         nmbDpcCic = 4096;
         break;
   }

   RETVALUE(nmbDpcCic);

}
#endif /* IW */

/*
*
*       Fun:   siCntrlSiLyr
*
*       Desc:  Perform ISUP layer-wide control request
*              
*       Ret:   ROK - ok; RFAILED - failed
*
*       Notes: Presently, only action supported is ASHUTDOWN - which 
*              de-initializes the ISUP layer.
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PRIVATE S16 siCntrlSiLyr 
(
Pst *pst,
SiMngmt *cntrl
)
#else
PRIVATE S16 siCntrlSiLyr (pst, cntrl)
Pst *pst;
SiMngmt *cntrl;
#endif
{
   SiUpSAPCb *tCb;
   SiNSAPCb  *nCb;
   SiIntfCb   *intfCb;
   SiCirCb   *cir;
   Cntr      i;

   TRC2(siCntrlSiLyr)

   /* ASHUTDOWN is the only supported action presently */
   if (cntrl->t.cntrl.action != ASHUTDOWN)
   {
      cntrl->cfm.status = LCM_PRIM_NOK;
      cntrl->cfm.reason = LCM_REASON_INVALID_ACTION;
      SiMiLsiCntrlCfm(pst, cntrl);
      RETVALUE(RFAILED);
   }

   /* start shutdown */
   /* deallocate upper SAP control blocks */
   for (i = 0; i < (Cntr) siCb.genCfg.nmbSaps; i++)
   {
      tCb = SIUPSAP(i);

      if (tCb != NULLP)
      {
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) tCb, 
                  (Size) sizeof(SiUpSAPCb));
      }
      *(siCb.upSAPLst + i) = NULLP; /* reset the pointer */
   }
   SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.upSAPLst, 
            (Size) (siCb.genCfg.nmbSaps * sizeof(SiUpSAPCb *)) );

   /* deallocate MTP-3 NSAP control blocks */
   for (i = 0; i < (Cntr) siCb.genCfg.nmbNSaps; i++)
   {
      nCb = SIMTPSAP(i);

      if (nCb != NULLP)
      {
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) nCb, 
                  (Size) sizeof(SiNSAPCb));
      }
      *(siCb.mtpSAPLst + i) = NULLP;
   }
   SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.mtpSAPLst, 
            (Size) (siCb.genCfg.nmbNSaps * sizeof(SiNSAPCb *)) );

   /* deallocate SCCP NSAP control blocks */
   for (i = 0; i < (Cntr) siCb.genCfg.nmbNSaps; i++)
   {
      nCb = SISCCPSAP(i);

      if (nCb != NULLP)
      {
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) nCb, 
                  (Size) sizeof(SiNSAPCb));
      }
      *(siCb.sccpSAPLst + i) = NULLP;
   }
   SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siCb.sccpSAPLst, 
            (Size) (siCb.genCfg.nmbNSaps * sizeof(SiNSAPCb *)) );

   /* deallocate circuit control blocks 
    * -- this clears the ISUP layer of all the connection,
    * -- circuit group & circuit control blocks. */
   cir     = NULLP;
   while (1)
   {
      if (cmHashListGetNext(&siCb.cirHlCp.chCp, (PTR) NULLP, 
                            (PTR *) &cir) == ROK)
      {
         if (cir != NULLP)
         {
            /* stop running circuit timers */
            siStopAllCirTmr(cir);

            /* if there is a connection associated with the circuit */
            if (cir->siCon) 
            {
               siStopConTmr(cir->siCon, TMR_ALL);

               /* this circuit is attached to incoming half of connection */
               if (cir == cir->siCon->incC.cir)
               {
                  cir->siCon->incC.relResp   = FALSE;
                  cir->siCon->incC.toBeRelsd = FALSE;
                  siClearIncCon(cir->siCon);
               }
               else if (cir == cir->siCon->outC.cir)
               {
                  cir->siCon->outC.relResp   = FALSE;
                  cir->siCon->outC.toBeRelsd = FALSE;
                  siClearOutCon(cir->siCon);
               }
            }

            for (i = 0; i < NUMCIREVTGRP; i++)
            {
               /* circuit group control block exists */
               if (cir->cirGr[i] != NULLP)
               {
                  /* stop circuit group timers */
                  siStopCirGrTmr(cir->cirGr[i], TMR_ALL);
                  /* reinitialize and deallocate circuit group control block */
                  SPutSBuf(siCb.init.region, siCb.init.pool, 
                           (Data *) cir->cirGr[i], (Size) sizeof (SiCirGrp));
                  cir->cirGr[i] = NULLP;
               }
            }

            /* delete circuit control block from hash list, reinitialize mem 
               and deallocate */
            siDelCir(&siCb.cirHlCp, cir);
            if (cir->sts)
               SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)cir->sts,
                        sizeof(SiCirSts));
            SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) cir, 
                     (Size) sizeof (SiCirCb));
         }

      } /* end if cmHashListGetNext ... */
      else 
         break;
   } /* end while */

   /* deallocate DPC control blocks */
   intfCb = NULLP;
   while (1)
   {
      if (cmHashListGetNext(&siCb.intfHlCp.k1Cp, (PTR) NULLP, 
                            (PTR *) &intfCb) == ROK)
      {
         if (intfCb != NULLP)
         {
            /* stop timers, remove from hash list, reinitialize, deallocate */
            siStopIntfTmr(intfCb, TMR_ALL);
            /* delete the interface block from the hashlists */
            siDelIntf(&siCb.intfHlCp, intfCb);

            if (intfCb->sts)
               SPutSBuf(siCb.init.region, siCb.init.pool, (Data *)intfCb->sts,
                        sizeof(SiIntfSts));
#ifdef IW
            if (intfCb->cirProf)
               SPutSBuf(siCb.init.region, siCb.init.pool,
                     (Data *) intfCb->cirProf, 
                     (Size) (siGetNmbDpcCic(intfCb->cfg.swtch)));
#endif /* IW */
            SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) intfCb, 
                     (Size) sizeof (SiIntfCb));
         }
      }
      else
         break;
   }

   /* deinitialize hash lists */
   cmHashListDeinit(&siCb.conHlCp.instCp);  
   cmHashListDeinit(&siCb.cirHlCp.ihCp);
   cmHashListDeinit(&siCb.cirHlCp.ichCp);
   cmHashListDeinit(&siCb.cirHlCp.chCp);
   cmHashListDeinit(&siCb.intfHlCp.k1Cp);
   cmHashListDeinit(&siCb.intfHlCp.k2Cp);
   cmHashListDeinit(&siCb.intfHlCp.k3Cp);

   /* deregister all the timer queues */
   SDeregTmr(siCb.init.ent, siCb.init.inst, siCb.genCfg.timeRes, siActvTmr);

   /* return static memory */
   SPutSMem(siCb.init.region, siCb.init.pool);

   /* reinitialize the layer using the exising values */
   siInitSiCb(siCb.init.ent, siCb.init.inst, siCb.init.region, 
              siCb.init.reason);

   cntrl->cfm.status = LCM_PRIM_OK;
   cntrl->cfm.reason = LCM_REASON_NOT_APPL;
   SiMiLsiCntrlCfm(pst, cntrl);
   RETVALUE(ROK);
}/* siCntrlSiLyr */

#endif /* SI_LMINT3 || SMSI_LMINT3 */


/*
*
*       Fun:   siCntrlNSAP
*
*       Desc:  Process control request for a network SAP
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PRIVATE S16 siCntrlNSAP
(
Pst     *pst, 
SiMngmt *cntrl
)
#else
PRIVATE S16 siCntrlNSAP (pst, cntrl)
Pst     *pst;
SiMngmt *cntrl;
#endif
{
#if (!(SI_LMINT3 || SMSI_LMINT3))
   SiNSAPCb *cb;
#endif

   TRC3(siCntrlNSAP)

#if (SI_LMINT3 || SMSI_LMINT3)
   siCntrlNSAPNew(pst, cntrl);
   RETVALUE(ROK);
#else /* SI_LMINT3 || SMSI_LMINT3 */

   if (cntrl->t.cntrl.action != ABND)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI807, (ErrVal) cntrl->hdr.elmId.elmntInst1,
                 "SiUiSitCntrlReq() failed, invalid action");
#endif
      SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_ACTION,
                       cntrl->t.cntrl.action, SI_CNTRL_NOK);
      RETVALUE(RFAILED);
   }

   if (NULLP == (cb = SIMTPSAP(cntrl->hdr.elmId.elmntInst1)) )
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI808, (ErrVal) cntrl->hdr.elmId.elmntInst1,
                 "SiUiSitCntrlReq() rebind, invalid MTP-3 SAP pointer");
#endif
      SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_PAR_VAL,
                       cntrl->hdr.elmId.elmntInst1, SIMSAP_INV);
      RETVALUE(RFAILED);
   }

   if (cb->state != SI_BND)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI809, (ErrVal) cntrl->hdr.elmId.elmntInst1, 
                 "SiUiSitCntrlReq() rebind, MTP-3 SAP not bound");
#endif
      SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_STATE,
                       cntrl->hdr.elmId.elmntInst1, SI_CNTRL_NOK);
      RETVALUE(RFAILED);
   }
   /* bind Service provider */
   SiLiSntBndReq(&cb->pst, cb->suId, cb->spId, cb->srvInfo);

#ifdef SI_SPT
   if (siCb.genCfg.sccpSup)
   {
      /* get Sap control block */
      if (NULLP == (cb = SISCCPSAP(cntrl->hdr.elmId.elmntInst1)) )
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI810, 
                    (ErrVal) cntrl->hdr.elmId.elmntInst1,
                    "SiUiSitCntrlReq() rebind, invalid SCCP SAP pointer");
#endif
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_SAP,
                          cntrl->hdr.elmId.elmntInst1, SISSAP_INV);
         RETVALUE(RFAILED);
      }

      if (cb->state != SI_BND)
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI811, 
                    (ErrVal) cntrl->hdr.elmId.elmntInst1,
                    "SiUiSitCntrlReq() rebind, SCCP SAP not bound");
#endif
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_STATE,
                          cntrl->hdr.elmId.elmntInst1, SIMSAP_INV);
         RETVALUE(RFAILED);
      }

      /* bind Service provider */
      SiLiSptBndReq(&cb->pst, cb->suId, cb->spId, (U8) SS_ISUP);
   }
#endif
   RETVALUE(ROK);

#endif /* SI_LMINT3 || SMSI_LMINT3 */
}


/*
*
*       Fun:   siCntrlSiIntfCb
*
*       Desc:  Process control request for ISUP DPC control block
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PRIVATE S16 siCntrlSiIntfCb
(
Pst    *pst, 
SiMngmt *cntrl
)
#else
PRIVATE S16 siCntrlSiIntfCb (pst, cntrl)
Pst    *pst; 
SiMngmt *cntrl;
#endif
{
   SiCirKey key;
   SiCirCb  *siCir;
   SiIntfCb  *siIntfCb;
   S16      ret;
   U16      idx;
   SiInstId intfId;

   TRC3(siCntrlSiIntfCb)

#if (SI_LMINT3 || SMSI_LMINT3)
   intfId    = cntrl->t.cntrl.s.siElmnt.elmntId.intfId;
#else
   intfId    = cntrl->t.cntrl.sigpt.intfId;
#endif
   
   /* initialise the circuit ctrl block pointer */
   siCir = NULLP;
   idx = 0;

   if ((ret = siFindIntf(&siIntfCb, intfId, 0, 0, 0, 0, SIINTF_KEY_1)) == 
                     RFAILED)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                         "cmHashListFind() failed for intf=%#lx\n", intfId));  
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI812, (ErrVal) intfId,
                 "SiMiLsiCntrlReq() Failed, invalid intf");
#endif
      /* si006.220, MODIFIED: return a successful confirmation for deletion
       * of interface control block
       */
      if (cntrl->t.cntrl.action == ADEL)
      {
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                          intfId, SI_CNTRL_OK);
      }
      else 
      {
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_PAR_VAL,
                          intfId, SI_CNTRL_NOK);
      }
      RETVALUE(RFAILED);
   }

   switch (cntrl->t.cntrl.action)
   {
      case AENA :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case AENA \n"));   
         key.k3.intfId = intfId;
         /* si010.220, MODIFIED: make the interface state available first in order
          * to send out the unblock message. In patch si009.220, we added check on
          * interface state when ISUP sends out message
          */
         siIntfCb->state = SI_INTF_AVAIL;
         for (idx = 0;; idx++)
         {
            if (!siCir)
               siFindCir(&siCb.cirHlCp, &siCir, &key, idx, KEY_INTF);
            else
            {
               if (cmHashListGetNext(&siCb.cirHlCp.ihCp, (PTR) siCir, 
                     (PTR *) &siCir) != ROK) break;
               else
                  if (siCir->cfg.intfId != intfId)
                     break;
            }
            if (siCir != NULLP)
            {
               siMngCirUnBlk(siCir, TRUE);
            }
            else
               break;
         }
         siIntfCb->state = SI_INTF_AVAIL;
#ifdef ZI
         ziRunTimeUpd(ZI_INTF_CB, CMPFTHA_UPD_REQ, (PTR) siIntfCb);
#endif
         break;

      case ADISIMM  :
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case ADISIMM \n"));   
         key.k3.intfId = intfId;
         for (idx = 0;; idx++)
         {
            if (!siCir)
               siFindCir(&siCb.cirHlCp, &siCir, &key, idx, KEY_INTF);
            else
            {
               if (cmHashListGetNext(&siCb.cirHlCp.ihCp, (PTR) siCir, 
                     (PTR *) &siCir) != ROK) break;
               else
                  if (siCir->cfg.intfId != intfId)
                     break;
            }
            if (siCir != NULLP)
            {
               siMngCirBlk(siCir, TRUE);
            }
            else
               break;
         }
         siIntfCb->state = SI_INTF_UNAVAIL;
#ifdef ZI
         ziRunTimeUpd(ZI_INTF_CB, CMPFTHA_UPD_REQ, (PTR) siIntfCb);
#endif
         break;

      case ADEL:
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case ADEL \n"));   
         key.k3.intfId = intfId;

         /* If any circuit is configured for this DPC
            this request will be rejected */
         siFindCir(&siCb.cirHlCp, &siCir, &key, idx, KEY_INTF); 
         if (siCir != NULLP)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                                   "circuits exists towards the DPC :%ld\n",
                                   key.k3.intfId));  

#if (ERRCLASS & ERRCLS_DEBUG)
            SILOGERROR(ERRCLS_DEBUG, ESI813, (ErrVal) intfId,
                       "SiUiSitCntrlReq() circuit, configured for this DPC");
#endif
            SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, 
                             LCM_REASON_LYR_SPECIFIC, intfId, SI_CNTRL_NOK);
            RETVALUE(RFAILED);
         }

         siStopIntfTmr(siIntfCb, TMR_ALL);
         siCb.intfCnt--;

         /* The interface sts control block & initial cfg 
          * profile of circuits, for PSIF- -ISUP, are released before 
          * releasing the interface control block
          */
#if (SI_LMINT3 || SMSI_LMINT3)
         if (siIntfCb->sts)
         {  
            SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siIntfCb->sts,
                     (Size) sizeof(SiIntfSts));
         }
#endif /* (SI_LMINT3 || SMSI_LMINT3) */
#ifdef IW
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siIntfCb->cirProf,
                  (Size) siGetNmbDpcCic(siIntfCb->cfg.swtch));
#endif


         siDelIntf(&siCb.intfHlCp, siIntfCb);
#ifdef ZI
         /* si006.220, MODIFIED: runtime update only for active copy 
          * since we support the deletion on standby copy also as 
          * per TCR21
          */
         if (ziCb.protState == ACTIVE)
            ziRunTimeUpd(ZI_INTF_CB, CMPFTHA_DELETE_REQ, (PTR) siIntfCb);
#endif
         SPutSBuf(siCb.init.region, siCb.init.pool, (Data *) siIntfCb, 
                  sizeof(SiIntfCb));
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "invalid action= %#x\n", 
                                 cntrl->t.cntrl.action));  
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI814, (ErrVal) 0,
                     "SiMiLsiCntrlReq() Failed, invalid action");
#endif
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_ACTION,
                          cntrl->t.cntrl.action, SI_CNTRL_NOK);
         RETVALUE(RFAILED);
   }

   /* si006.220, MODIFIED: use the hash define instead of 0 */
   SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_OK, LCM_REASON_NOT_APPL, intfId, 
                    SI_CNTRL_OK);

#ifdef ZI
   /* si006.220, MODIFIED: runtime update only for active copy since we 
    * support the deletion on standby copy also as per TCR21
    */
   if (ziCb.protState == ACTIVE) 
      ziUpdPeer();
#endif

   RETVALUE(ROK);
}


/*
*
*       Fun:   siBindMTPSAP
*
*       Desc:  Bind an MTP-3 Network SAP
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siBindMTPSAP
(
SiNSAPCb *mCb
)
#else
PUBLIC S16 siBindMTPSAP (mCb)
SiNSAPCb *mCb;
#endif
{
   TRC3(siBindMTPSAP)

#ifdef SNT2
   if ((mCb->state == SI_BND) || (mCb->state == SI_WT_BNDCFM))
      RETVALUE(ROK);
   else
   {
      mCb->state       = SI_WT_BNDCFM;
      mCb->bndRetryCnt = 0;
      siStartNSAPTmr(TMR_TINT, mCb);
   }
#else
   if (mCb->state == SI_BND)
      RETVALUE(ROK); 
   else
      mCb->state = SI_BND;
#endif

   SiLiSntBndReq(&mCb->pst, mCb->suId, mCb->spId, mCb->srvInfo);

   RETVALUE(ROK);
} /* siBindMTPSAP */

#ifdef SI_SPT

/*
*
*       Fun:   siBindSCCPSAP
*
*       Desc:  Bind an SCCP network SAP
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siBindSCCPSAP
(
SiNSAPCb *sCb
)
#else
PUBLIC S16 siBindSCCPSAP (sCb)
SiNSAPCb *sCb;
#endif
{
   TRC3(siBindSCCPSAP)

#ifdef SPT2
   if ((sCb->state == SI_BND) || (sCb->state == SI_WT_BNDCFM))
      RETVALUE(ROK);
   else
   {
      sCb->state       = SI_WT_BNDCFM;
      sCb->bndRetryCnt = 0;
      siStartNSAPTmr(TMR_TINT, sCb);
   }
#else
   if (sCb->state == SI_BND)
      RETVALUE(ROK); 
   else
      sCb->state = SI_BND;
#endif
   SiLiSptBndReq(&sCb->pst, sCb->suId, sCb->spId, (U8) SS_ISUP);
   
   RETVALUE(ROK);
}
#endif /* SI_SPT */


/*
*
*       Fun:   siCntrlElmnt
*
*       Desc:  Control an ISUP control block 
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siCntrlElmnt
(
Pst     *pst,
SiMngmt *cntrl
)
#else
PUBLIC S16 siCntrlElmnt (pst, cntrl)
Pst     *pst;
SiMngmt *cntrl;
#endif
{
  /* si006.220, ADDED: added a variable */
#ifdef ZI
   Bool  stbyAllwd;   /* Whether primitive is allowed in standby */
#endif

   TRC3(siCntrlElmnt)

   /* si006.220, ADDED: added the check to allow only the control request
    * on deleting object and shutting down layer to be performed on standby copy
    */
#ifdef ZI
   stbyAllwd = FALSE;
   switch(cntrl->hdr.elmId.elmnt)
   {
      case STICIR:        /* circuit */
      case STNSAP:        /* network SAP */
      case SI_STINTF :   /* INTF */
#if (SI_LMINT3 || SMSI_LMINT3)
      case STISAP:       /* upper SAP */
#endif
         if (cntrl->t.cntrl.action == ADEL)
            stbyAllwd = TRUE;
         break;

#if (SI_LMINT3 || SMSI_LMINT3)
      case STGEN:        /* general layer specific control requests */
         stbyAllwd = TRUE;
         break;
#endif

      default:
         break;
   }

   if ((ziCb.protState != ACTIVE) && (stbyAllwd == FALSE))
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "ISUP inactive\n") );
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESIXXX, (ErrVal) ziCb.protState,
                 "SiCntrlElmnt() failed, ISUP is not active\n");
#endif
#if (SI_LMINT3 || SMSI_LMINT3)
      siInitUstaDgn(LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, (PTR) pst->event, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_MI_INV_EVT, LCM_CAUSE_PROT_NOT_ACTIVE, 
                    TRUE);
#endif
      RETVALUE(RFAILED);
   }
#endif /* ZI */

   switch (cntrl->hdr.elmId.elmnt)
   {
      case STICIR :      /* circuit */
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case STICIR \n"));   
         siCntrlSiCirCb(pst, cntrl);
         break;

      case SI_STCIRGRP : /* circuit group */
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case SI_STCIRGRP \n"));   
         /* handles circuit group Unblocking/blocking/Reset requests */
         siCntrlSiCirGrpCb(pst, cntrl);
         break;

      case STNSAP:
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case STNSAP \n"));   
         siCntrlNSAP(pst, cntrl);
         break;

      case SI_STINTF :   /* INTF */ 
         SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf, "case SI_STINTF \n"));   
         /* args: dpc, action, NSAP id*/
         siCntrlSiIntfCb(pst, cntrl);
         /* find INTF */
         break;

#if (SI_LMINT3 || SMSI_LMINT3)
      case STISAP:
         siCntrlUpSAP(pst, cntrl);
         break;

      case STGRPUPSAP:
      case STGRPNSAP:
      case STALLSAP:
         siCntrlGrpSAP(pst, cntrl);
         break;

      case STGEN: /* general layer specific control requests */
         siCntrlSiLyr(pst, cntrl);
         break;

#ifdef SI_218_COMP
      case STROUT: /* control route */
         SIDBGP(DBGMASK_MI, (siCb.init.prntBuf,
         "Routing capability is no longer supported in 2.19 release") ); 
         /* si006.220, MODIFIED: use the hash define instead of 0 */
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 
                          cntrl->hdr.elmId.elmnt, SI_CNTRL_OK);
         break;
#endif

#endif /* SI_LMINT3 || SMSI_LMINT3 */

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "invalid hdr.elmId.elmnt %d\n", cntrl->hdr.elmId.elmnt));  
#if (ERRCLASS & ERRCLS_INT_PAR)
         SILOGERROR(ERRCLS_INT_PAR, ESI815, (ErrVal) 0, 
                    "SiMiLsiCntrlReq() Failed, invalid header");
#endif
         SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_NOK, LCM_REASON_INVALID_ELMNT,
                          cntrl->hdr.elmId.elmnt, SI_CNTRL_NOK);
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end siCntrlElmt */



/*
*
*       Fun:   siStsSiCirCb
*
*       Desc:  Process circuit statistics request from layer manager
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siStsSiCirCb
(
Pst     *pst,
Action  action,
SiMngmt *sts
)
#else
PUBLIC S16 siStsSiCirCb (pst, action, sts)
Pst     *pst;
Action  action;
SiMngmt *sts;
#endif
{
   SiCirKey key;
   SiCirCb  *siCir;

   TRC3(siStsSiCirCb)
   UNUSED(pst);

   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));
#if (SI_LMINT3 || SMSI_LMINT3)
   key.k1.cirId = sts->t.sts.elmntId.circuit;
#else
   /* find circuit */
   key.k1.cirId = PutHiWord(key.k1.cirId, sts->hdr.elmId.elmntInst1);
   key.k1.cirId = PutLoWord(key.k1.cirId, sts->hdr.elmId.elmntInst2);
#endif
   siFindCir(&siCb.cirHlCp, &siCir, &key, 0, KEY_CIR);
   if (siCir == NULLP)
   {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                              "no circuit block for cirId=%#lx\n",
                              key.k1.cirId));  

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI816, (ErrVal) 0, 
                 "SiMiLsiStsReq() Failed, invalid circuit");
#endif
      SISNDLSISTSCFM(&siCb.init.lmPst, sts, LCM_PRIM_NOK, 
                     LCM_REASON_INVALID_PAR_VAL, action, 
                     key.k1.cirId, SI_STS_NOK);
      RETVALUE(RFAILED);
   }

   /* move statistic counters into statistic structure */
#if (SI_LMINT3 || SMSI_LMINT3)
   (Void) cmMemcpy((U8 *) &(sts->t.sts.s.cir), (U8 *) siCir->sts,
                   sizeof(SiCirSts)); 
#else
   (Void) cmMemcpy((U8 *) &(sts->t.sts.s.siCirSts), (U8 *) siCir->sts,
                   sizeof(SiCirSts)); 
#endif

   if (action == ZEROSTS)
      (Void) cmMemset((U8 *)siCir->sts, NULLD, sizeof(SiCirSts));

   /* generate statistics confirm to layer manager */
   SISNDLSISTSCFM(&siCb.init.lmPst, sts, LCM_PRIM_OK, 0, action, 
                  key.k1.cirId, SI_STS_OK);
   RETVALUE(ROK);
}

#if (SI_LMINT3 || SMSI_LMINT3)

/*
*
*       Fun:   siStaCirGr
*
*       Desc:  Update the Layer Management of the status of a group of circuits
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siStaCirGr 
(
Pst *pst,
SiMngmt *sta
)
#else
PUBLIC S16 siStaCirGr (pst, sta)
Pst *pst;
SiMngmt *sta;
#endif
{
   SiCirKey key;
   SiCirCb  *siCir;
   U8     i;

   TRC2(siStaCirGr)

   cmMemset((U8 *) &key, '\0', sizeof(SiCirKey));

   key.k1.cirId = sta->t.ssta.elmntId.circuit;

   for (i = 0; ((i <= sta->t.ssta.param.cirgr.range) &&
                (i < MAX_SIZ_STATUS)); i++, key.k1.cirId++)
   {
      siFindCir(&siCb.cirHlCp, &siCir, &key, 0, KEY_CIR);
      siGetCirState(siCir, &sta->t.ssta.cfm.s.cir.state[i]);
   }
   sta->t.ssta.param.cirgr.range = (i-1);
   sta->cfm.status = LCM_PRIM_OK;
   sta->cfm.reason = LCM_REASON_NOT_APPL;
   SiMiLsiStaCfm(pst, sta);

   RETVALUE(ROK);
}/* siStaCirGr */


/*
*
*       Fun:   siUpdErrSts
*
*       Desc:  Update given type of error statistics - layerwide/circuitwise
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siUpdErrSts 
(
SiCirCb *cir,
U8      stsType
)
#else
PUBLIC S16 siUpdErrSts (cir, stsType)
SiCirCb *cir;
U8      stsType;
#endif
{
   SiErrSts *sts;

   TRC2(siUpdErrSts)

#if (SI_LMINT3 || SMSI_LMINT3)

   sts = (SiErrSts *)((cir == NULLP) ? &siCb.sts : cir->sts);

   switch (stsType)
   {
      case LSI_STS_T5EXP:
         sts->t5Exp++;
         break;

      case LSI_STS_T13EXP:
         sts->t13Exp++;
         break;

      case LSI_STS_T15EXP:
         sts->t15Exp++;
         break;

      case LSI_STS_T17EXP:
         sts->t17Exp++;
         break;

      case LSI_STS_T19EXP:
         sts->t19Exp++;
         break;

      case LSI_STS_T21EXP:
         sts->t21Exp++;
         break;

      case LSI_STS_T23EXP:
         sts->t23Exp++;
         break;

      case LSI_STS_ABNRMLREL:
         sts->abnrmlRel++;
         break;

      case LSI_STS_BLOREQ:
         sts->blkReq++;
         break;

      case LSI_STS_NOCGBA:
         sts->noAckCgba++;
         break;

      case LSI_STS_NOCGUA:
         sts->noAckCgua++;
         break;

      case LSI_STS_ABNRMLCGBA:
         sts->abnrmlAckCgba++;
         break;

      case LSI_STS_ABNRMLCGUA:
         sts->abnrmlAckCgua++;
         break;

      case LSI_STS_UNXCGBA:
         sts->unxCgba++;
         break;

      case LSI_STS_UNXCGUA:
         sts->unxCgua++;
         break;

      case LSI_STS_UNXBLA:
         sts->unxBla++;
         break;

      case LSI_STS_UNXUBA:
         sts->unxUba++;
         break;

      case LSI_STS_PDUFMTERR:
         sts->pduFmtErr++;
         break;

      case LSI_STS_RELUNRECINFO:
         sts->relUnrecInfo++;
         break;

      case LSI_STS_RELFAIL:
         sts->relFail++;
         break;

/*si054.220 :  Added New case for LSI_STS_UNXEVT */
      case LSI_STS_UNXEVT:
	 sts->unxEvt++;
         break;

      default:
         break;
   }
#else
   UNUSED(cir);
   UNUSED(stsType);
   UNUSED(sts);
#endif
   RETVALUE(ROK);
}/* siUpdErrSts */


/*
*
*       Fun:   siStsGen
*
*       Desc:  Collect layerwide statistics ounters and send back the
*              statistics confirmation to layer manager
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siStsGen 
(
Pst     *pst,
Action  action,
SiMngmt *sts
)
#else
PUBLIC S16 siStsGen (pst, action, sts)
Pst     *pst;
Action  action;
SiMngmt *sts;
#endif
{
   TRC2(siStsGen)
   UNUSED(pst);

   cmMemcpy((U8 *) &sts->t.sts.s.gen, (U8 *) &siCb.sts, sizeof(SiErrSts));

   if (action == ZEROSTS)
      cmMemset((U8 *) &siCb.sts, '\0', sizeof(SiErrSts));

   /* generate statistics confirm to layer manager */
   sts->cfm.status = LCM_PRIM_OK;
   sts->cfm.reason = LCM_REASON_NOT_APPL;
   SiMiLsiStsCfm(&siCb.init.lmPst, action, sts);
   RETVALUE(ROK);

}/* siStsGen */


/*
*
*       Fun:   siStsSiDpcCb
*
*       Desc:  Collect transmit/receive statistics counters for the given
*              destination point code
*              
*       Ret:   ROK - oK; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siStsSiIntfCb 
(
Pst     *pst,
Action  action,
SiMngmt *sts
)
#else
PUBLIC S16 siStsSiIntfCb (pst, action, sts)
Pst     *pst;
Action  action;
SiMngmt *sts;
#endif
{
   SiIntfCb *siIntfCb;

   TRC2(siStsSiIntfCb)
   UNUSED(pst);

   if (siFindIntf(&siIntfCb, sts->t.sts.elmntId.intfId, 0, 0, 0, 0, 
                     SIINTF_KEY_1) == RFAILED)
   {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                              "no control block for INTF (%#lx)\n",
                              sts->t.sts.elmntId.intfId));  

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI817, (ErrVal) sts->t.sts.elmntId.intfId, 
                 "siStsSiDpcCb() Failed, invalid INTF");
#endif
      sts->cfm.status = LCM_PRIM_NOK;
      sts->cfm.reason =  LCM_REASON_INVALID_PAR_VAL;
      SiMiLsiStsCfm(&siCb.init.lmPst, action, sts);
      RETVALUE(RFAILED);
   }

   /* move statistic counters into statistic structure */
   (Void) cmMemcpy((U8 *) &(sts->t.sts.s.intf), (U8 *) siIntfCb->sts,
                   sizeof(SiIntfSts)); 

   if (action == ZEROSTS)
      (Void) cmMemset((U8 *) siIntfCb->sts, NULLD, sizeof(SiIntfSts));

   /* generate statistics confirm to layer manager */
   sts->cfm.status = LCM_PRIM_OK;
   sts->cfm.reason = LCM_REASON_NOT_APPL;
   SiMiLsiStsCfm(&siCb.init.lmPst, action, sts);
   RETVALUE(ROK);
}/* siStsSiDpcCb */


/*
*
*       Fun:   
*
*       Desc:  
*              
*       Ret:   
*
*       Notes: 
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siUpdIntfSts 
(
Dpc phyDpc,
U8  stsType,
U8  msgType
)
#else
PUBLIC S16 siUpdIntfSts (phyDpc, stsType, msgType)
Dpc phyDpc;
U8  stsType;
U8  msgType;
#endif
{
   SiIntfCb  *intfCb;
   SiPduSts *pduSts;
   S16      ret;

   TRC2(siUpdIntfSts)

   /* find interface control block */
   if (siFindIntf(&intfCb, phyDpc, 0, 0, 0, 0, SIINTF_KEY_1) != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
              "dpc (%#lx) control block unavailable\n", phyDpc));  
      RETVALUE(RFAILED);
   }

   if (intfCb->sts == NULLP)
      RETVALUE(RFAILED);

   if (stsType == LSI_STS_RX)
      pduSts = &intfCb->sts->pdu.rx;
   else
      pduSts = &intfCb->sts->pdu.tx;

   switch (msgType)
   {
      case M_ADDCOMP:
         pduSts->acm++;
         break;
      case M_ANSWER:
         pduSts->anm++;
         break;
      case M_BLOCKACK:
         pduSts->bla++;
         break;
      case M_BLOCK:
         pduSts->blo++;
         break;
      case M_CONTCHKREQ:
         pduSts->ccr++;
         break;
      case M_CONFUSION:
         pduSts->cfn++;
         break;
      case M_CIRGRPBLK:
         pduSts->cgb++;
         break;
      case M_CIRGRPBLKACK:
         pduSts->cgba++;
         break;
      case M_CIRGRPUBLK:
         pduSts->cgu++;
         break;
      case M_CIRGRPUBLKACK:
         pduSts->cgua++;
         break;
      case M_CONNCT:
         pduSts->con++;
         break;
      case M_CONTINUITY:
         pduSts->cot++;
         break;
      case M_CALLPROG:
         pduSts->cpg++;
         break;
      case M_CIRGRPQRY:
         pduSts->cqm++;
         break;
      case M_CIRGRPQRYRES:
         pduSts->cqr++;
         break;
      case M_CHARGE:
         pduSts->crg++;
         break;
      case M_FACACC:
         pduSts->faa++;
         break;
      case M_FACIL:
         pduSts->fac++;
         break;
      case M_FACREQ:
         pduSts->farMsg++;
         break;
      case M_FWDTFER:
         pduSts->fot++;
         break;
      case M_FACREJ:
         pduSts->frj++;
         break;
      case M_CIRGRPRESACK:
         pduSts->gra++;
         break;
      case M_CIRGRPRES:
         pduSts->grs++;
         break;
      case M_INIADDR:
         pduSts->iam++;
         break;
      case M_IDENTREQ:
         pduSts->idr++;
         break;
      case M_INFORMTN:
         pduSts->inf++;
         break;
      case M_INFOREQ:
         pduSts->inr++;
         break;
      case M_IDENTRSP:
         pduSts->irs++;
         break;
      case M_LOOPPRVNT:
         pduSts->lop++;
         break;
      case M_LOOPBCKACK:
         pduSts->lpa++;
         break;
      case M_NETRESMGT:
         pduSts->nrm++;
         break;
      case M_OVERLOAD:
         pduSts->olm++;
         break;
      case M_PASSALNG:
         pduSts->pam++;
         break;
      case M_RELSE:
         pduSts->rel++;
         break;
      case M_RESUME:
         pduSts->res++;
         break;
      case M_RELCOMP:
         pduSts->rlc++;
         break;
      case M_RESCIR:
         pduSts->rsc++;
         break;
      case M_SUBADDR:
         pduSts->sam++;
         break;
      case M_SEGMMSG:
         pduSts->sgm++;
         break;
      case M_SUSPND:
         pduSts->sus++;
         break;
      case M_UNBLKACK:
         pduSts->uba++;
         break;
      case M_UNBLK:
         pduSts->ubl++;
         break;
      case M_UNEQUIPCIC:
         pduSts->ucic++;
         break;
      case M_USRPARTA:
         pduSts->upa++;
         break;
      case M_USRPARTT:
         pduSts->upt++;
         break;
      case M_USR2USR:
         pduSts->usr++;
         break;

      default: /* national messages */
         switch (intfCb->cfg.swtch)
         {





/* si029.220: Modificaiton - added ITU97 and INDIA switch */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
            case LSI_SW_ETSIV3:
            case LSI_SW_ITU97:
            case LSI_SW_RUSS2000:
            case LSI_SW_ITU2000:
            case LSI_SW_INDIA:
               switch(msgType)
               {
                  case M_PRERELINF: /* pre-release message */
                     pduSts->pri++;
                     break;
                  case M_APPTRAN: /* application transport message */
                     pduSts->apn++;
                     break;
               }
               break;
#endif
/* si034.220: Modificaiton - added CHINA switch */
#if SS7_CHINA
            case LSI_SW_CHINA:
               switch(msgType)
               {
		 case M_CLGPTYCLR:
		     pduSts->cpc++;
                     break;
                 case M_METPULSE:
		     pduSts->mpm++;
                     break;
                 case M_OPERATOR:
		     pduSts->opr++;
                     break;
               }
               break;
#endif /* SS7_CHINA */
         }
   }

   /* ret is dummy */
   ret = ((stsType == LSI_STS_RX) ?  intfCb->sts->total.rx++ : 
                                     intfCb->sts->total.tx++);

   RETVALUE(ROK);   
}/* siUpdIntfSts */


/*
*
*       Fun:   siInitUstaDgnVal
*
*       Desc:  Initialize a dignostic value for an alarm
*              
*       Ret:   ROK - ok
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PRIVATE S16 siInitUstaDgnVal 
(
SiUstaDgn *dgnPtr,
U8        idx,
U8        type,
PTR       value
)
#else
PRIVATE S16 siInitUstaDgnVal (dgnPtr, idx, type, value)
SiUstaDgn *dgnPtr;
U8        idx;
U8        type;
PTR       value;
#endif
{
   U8 i;

   TRC2(siInitUstaDgnVal)

   switch (dgnPtr->dgnVal[idx].type = type)
   {
      case LSI_USTA_DGNVAL_NONE:
         break;

      case LSI_USTA_DGNVAL_EVENT:
         dgnPtr->dgnVal[idx].t.event = *(Event *)value;
         break;

      case LSI_USTA_DGNVAL_SPID:
         dgnPtr->dgnVal[idx].t.spId = *(SpId *)value;
         break;

      case LSI_USTA_DGNVAL_SUID:
         dgnPtr->dgnVal[idx].t.suId = *(SuId *)value;
         break;

      case LSI_USTA_DGNVAL_SPINSTID:
         dgnPtr->dgnVal[idx].t.spInstId = *(SpInstId *)value;
         break;

      case LSI_USTA_DGNVAL_SUINSTID:
         dgnPtr->dgnVal[idx].t.suInstId = *(SuInstId *)value;
         break;

      case LSI_USTA_DGNVAL_CIRCUIT:
         dgnPtr->dgnVal[idx].t.cirId = *(CirId *)value;
         break;

      case LSI_USTA_DGNVAL_CIC:
         dgnPtr->dgnVal[idx].t.cic = *(Cic *)value;
         break;

      case LSI_USTA_DGNVAL_INTF:
         dgnPtr->dgnVal[idx].t.intfId = *(SiInstId *)value;
         break;
/* si007.220 - Addition. Added code to deal with LSI_USTA_DGNVAL_CIC.
 */
      case LSI_USTA_DGNVAL_DPC:
         dgnPtr->dgnVal[idx].t.dpc = *(Dpc *)value;
         break;
         
      case LSI_USTA_DGNVAL_ADDRS:
         dgnPtr->dgnVal[idx].t.addrStatus.length = ((Addrs *)value)->length;
         for (i = 0; i < ((Addrs *)value)->length; i++)
             dgnPtr->dgnVal[idx].t.addrStatus.strg[i] = 
                                             ((Addrs *)value)->strg[i];
         break;

      case LSI_USTA_DGNVAL_SWTCH:
         dgnPtr->dgnVal[idx].t.swtch = *(Swtch *)value;
         break;

      case LSI_USTA_DGNVAL_RANGE:
         dgnPtr->dgnVal[idx].t.range = *(U8 *)value;
         break;

      case LSI_USTA_DGNVAL_STATUS_OCTS:
         dgnPtr->dgnVal[idx].t.addrStatus.length = ((TknStr *)value)->len;
         for (i = 0; i < ((TknStr *)value)->len; i++)
             dgnPtr->dgnVal[idx].t.addrStatus.strg[i] = 
                                             ((TknStr *)value)->val[i];
         break;

#ifdef SI_RUG
      case LSI_USTA_DGNVAL_VER:
         dgnPtr->dgnVal[idx].t.intfVer = *(CmIntfVer *)value;
         break;
#endif /* SI_RUG */

      default:
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
}/* siInitUstaDgnVal */


/*
*
*       Fun:   siGenAlarmNew
*
*       Desc:  Generates unsolicited status indications (alarms) for the
*              LMINT3 Interface
*              
*       Ret:   none
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC Void siGenAlarmNew 
(
Pst  *smPst,
U16   category,
U16   event,
U16   cause,
Bool dgnInitialized
)
#else
PUBLIC Void siGenAlarmNew (smPst, category, event, cause, 
                           dgnInitialized)
Pst  *smPst;
U16   category;
U16   event;
U16   cause;
Bool dgnInitialized;
#endif
{
   SiMngmt usta;

   TRC2(siGenAlarmNew)

   /* if unsolicited status is enabled send indication to the layer manager */
   /* si001.220, MODIFIED: if general configuration not done the lmPst is not
    * valid and we can't generated any alarm
    */
   if ((siCb.init.usta == TRUE) && (siCb.init.cfgDone == TRUE))
   {               
      /* si001.220, ADDED: added the code to assign the fields of hdr */
      usta.hdr.msgType    = TUSTA;
      usta.hdr.entId.ent  = siCb.init.ent;
      usta.hdr.entId.inst = siCb.init.inst;

      SGetDateTime(&usta.t.usta.alarm.dt);

      usta.t.usta.alarm.category = category;
      usta.t.usta.alarm.event    = event;
      usta.t.usta.alarm.cause    = cause;
      /* if diagnostics values are to be used */
      if (dgnInitialized == TRUE)
         cmMemcpy((U8 *) &usta.t.usta.dgn, (U8 *) &siCb.ustaDgn, 
                  sizeof(SiUstaDgn));

      SiMiLsiStaInd(smPst, &usta);
   }

   RETVOID; 
}/* siGenAlarmNew */

#else /* !(SI_LMINT3 || SMSI_LMINT3) */


/*
*
*       Fun:   siStaSiCirCb
*
*       Desc:  check the ISUP circuit status.
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siStaSiCirCb
(
Pst     *pst,
SiMngmt *sta
)
#else
PUBLIC S16 siStaSiCirCb (pst, sta)
Pst     *pst;
SiMngmt *sta;
#endif
{
   SiCirKey key;
   SiCirCb  *siCir;
#if (!(SI_LMINT3 || SMSI_LMINT3))
   U8       i;
#endif

   TRC3(siStaSiCirCb)

   /* find circuit */
   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));

   key.k1.cirId = PutHiWord(key.k1.cirId, sta->hdr.elmId.elmntInst1);
   key.k1.cirId = PutLoWord(key.k1.cirId, sta->hdr.elmId.elmntInst2);
   siFindCir(&siCb.cirHlCp, &siCir, &key, 0, KEY_CIR);

   /* circuit not found is not an error in the LMINT3 interface.
    * the layer will return the state 'unequipped' to LM. LM can check
    * if the circuit is configured by trying to reset it via management
    * interface. If the reset attempt fails, then circuit is not configured.
    */
   if (siCir == NULLP)
   {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                              "no circuit configured for cirId=:%lx\n",
                              key.k1.cirId));  
#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI818, (ErrVal) 0,
                 "siStaSiCirCb() Failed, invalid circuit");
#endif
      SISNDLSISTACFM(pst, sta, LCM_PRIM_NOK, LCM_REASON_INVALID_PAR_VAL,
                     key.k1.cirId, SI_STA_NOK);
      RETVALUE(RFAILED);
   }

   /* initialize circuit status structure */
   for (i = 0; i < NUMCIREVTGRP; i++)
      sta->t.ssta.s.siCirSta.transState[i] = siCir->transStat[i];
   sta->t.ssta.s.siCirSta.callState = siCir->calProcStat;

   sta->cfm.status = LCM_PRIM_OK;
   sta->cfm.reason = 0;
   SiMiLsiStaCfm(pst, sta);

   RETVALUE(ROK);
}


/*
*
*       Fun:   siStsNSAP
*
*       Desc:  Process NSAP statistics request from layer manager
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siStsNSAP
(
Pst     *pst,
Action  action,
SiMngmt *sts
)
#else
PUBLIC S16 siStsNSAP (pst, action, sts)
Pst     *pst;
Action  action;
SiMngmt *sts;
#endif
{
   SiNSAPCb *nCb;

   TRC3(siStsNSAP)

   nCb = NULLP;

   /* get mtp control block */
   if ((nCb = SIMTPSAP(sts->hdr.elmId.elmntInst1)) == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "lower cb not found with elmntInst1:%d\n", sts->hdr.elmId.elmntInst1));

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI819, (ErrVal) sts->hdr.elmId.elmntInst1,
                       "siStsNSAP() Failed, Invalid STNSAP id");
#endif
      SISNDLSISTSCFM(pst, sts, LCM_PRIM_NOK, LCM_PRIM_INVALID_PAR_VAL,
                     action, sts->hdr.elmId.elmntInst1, SI_STS_NOK);
      RETVALUE(RFAILED);
   }
 
   /* move statistic counters into statistic structure */
   (Void) cmMemcpy((U8 *) &(sts->t.sts.s.siSts), (U8 *) nCb->sts,
                   sizeof(SiNSAPSts));
 
   if (action == ZEROSTS)
      (Void) cmMemset((U8 *)&(nCb->sts), NULLD, sizeof(SiNSAPSts));

   /* generate statistics confirm to layer manager */
#if (SI_LMINT3 || SMSI_LMINT3)
   sts->cfm.status = LCM_PRIM_OK;
   sts->cfm.reason = LCM_REASON_NOT_APPL;
#endif
   SiMiLsiStsCfm(&siCb.init.lmPst, action, sts);
   RETVALUE(ROK);
}


/*
*
*       Fun:   siUpdTxSts
*
*       Desc:  Update transmit status over NSAP and/or circuit
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siUpdTxSts 
(
SiNSAPCb *nCb,
Cic      cic,
SiInstId intfId,
U8       msgType
)
#else
PUBLIC S16 siUpdTxSts (nCb, cic, intfId, msgType)
SiNSAPCb *nCb;
Cic      cic;
SiInstId intfId;
U8       msgType;
#endif
{
   SiCirKey key;
   SiCirCb  *cir;

   TRC2(siUpdTxSts)

   siUpdNSAPTxSts(nCb, msgType);
   cmMemset((U8 *)&key, '\0', sizeof(SiCirKey));

   key.k2.cic = cic;
   key.k2.intfId = intfId;
   siFindCir(&siCb.cirHlCp, &cir, &key, 0, KEY_CICINTF);

   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                             "no circuit block for cic=%#x, dpc=%#lx\n",
                             key.k2.cic, key.k2.intfId));  

#if (ERRCLASS & ERRCLS_INT_PAR)
      SILOGERROR(ERRCLS_INT_PAR, ESI820, (ErrVal) 0, 
                 "siUpdTxSts() Failed, invalid circuit");
#endif
      RETVALUE(RFAILED);
   }

   siUpdCirTxSts(cir, msgType);
   RETVALUE(ROK);
}/* siUpdTxSts */


/*
*
*       Fun:   siUpdNSAPRxSts
*
*       Desc:  Update receive statistics at an NSAP
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siUpdNSAPRxSts
(
SiNSAPCb *mCb,
U8       msgType
)
#else
PUBLIC S16 siUpdNSAPRxSts (mCb, msgType)
SiNSAPCb *mCb;
U8       msgType;
#endif
{
   TRC3(siUpdNSAPRxSts)

   switch (msgType)
   {
      case M_ADDCOMP:
         mCb->sts->adrCmpltRx++;
         break;
   
      case M_ANSWER:
         mCb->sts->answerRx++;
         break;
   
      case M_CALLPROG:
         mCb->sts->progressRx++;
         break;
   
      case M_CONTINUITY:
         mCb->sts->contiRx++;
         break;
   
      case M_CONTCHKREQ:
         mCb->sts->conChkReqRx++;
         break;
   
      case M_LOOPBCKACK:
         mCb->sts->loopBckAckRx++;
         break;
   
      case M_CONFUSION:
         mCb->sts->confusRx++;
         break;
   
      case M_CALLMODREQ:
         mCb->sts->callModReqRx++;
         break;
   
      case M_CALLMODREJ:
         mCb->sts->callModRejRx++;
         break;
   
      case M_CALLMODCOMP:
         mCb->sts->callModComRx++;
         break;
   
      case M_SUSPND:
         mCb->sts->suspRx++;
         break;
   
      case M_RESUME:
         mCb->sts->resmRx++;
         break;
   
      case M_FWDTFER:
         mCb->sts->forwRx++;
         break;
   
      case M_CONNCT:
         mCb->sts->conRx++;
         break;
   
      case M_RELSE:
         mCb->sts->relRx++;
         break;
   
      case M_OVERLOAD:
         mCb->sts->overldRx++;
         break;
   
      case M_RELCOMP:
         mCb->sts->relCmpltRx++;
         break;
   
      case M_FACIL:
         mCb->sts->facRx++;
         break;
   
      case M_FACACC:
         mCb->sts->facAckRx++;
         break;
   
      case M_FACREJ:
         mCb->sts->facRejRx++;
         break;
   
      case M_INIADDR:
         mCb->sts->initAdrRx++;
         break;
   
      case M_INFORMTN:
         mCb->sts->infoRx++;
         break;
   
      case M_INFOREQ:
         mCb->sts->infoReqRx++;
         break;
   
      case M_PASSALNG:
         mCb->sts->passAlongRx++;
         break;
   
      case M_SUBADDR:
         mCb->sts->subsAdrRx++;
         break;
   
      case M_USR2USR:
         mCb->sts->usrToUsrRx++;
         break;
   
      case M_UNEQUIPCIC:
         mCb->sts->uneqCirIdRx++;
         break;
   
      case M_NETRESMGT:
         mCb->sts->netResMgmtRx++;
         break;
   
      case M_IDENTREQ:
         mCb->sts->netIdReqRx++;
         break;
   
      case M_IDENTRSP:
         mCb->sts->netIdRspRx++;
         break;
   

      default: 
         switch (mCb->cfg.swtch)
         {

/* si029.220: Addition - added INDIA switch */
#if (SS7_RUSSIA || SS7_INDIA) 
            case LSI_SW_RUSSIA:
            case LSI_SW_INDIA:
               switch (msgType)
               {
                  case M_CHARGE:
                     mCb->sts->chargeRx++;
                     break;

                  default:
                     break;
               }
               break;
#endif


/* si029.220: Modification - regroup the statistics counters */

#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
            case LSI_SW_ETSIV3:
            case LSI_SW_ITU97:
            case LSI_SW_RUSS2000:
            case LSI_SW_ITU2000:
               switch (msgType)
               {
                  case M_LOOPPRVNT:
                     mCb->sts->loopPrvntRx++;
                     break;
                     
                  case M_PRERELINF:
                     mCb->sts->preRelRx++;
                     break;

                  case M_APPTRAN:
                     mCb->sts->appTranRx++;
                     break;

                  default:
                     break;
               }
               break;
#endif
/* si029.220: Addition - added statistics for INDIA variant */
#ifdef SS7_INDIA
            case LSI_SW_INDIA:
               switch (msgType)
               {
                  case M_PRERELINF:
                     mCb->sts->preRelRx++;
                     break;

                  case M_APPTRAN:
                     mCb->sts->appTranRx++;
                     break;

                  default:
                     break;
               }
               break;
#endif

/* si034.220: Modificaiton - added CHINA switch */
#if SS7_CHINA
            case LSI_SW_CHINA:
               switch(msgType)
               {
		 case M_CLGPTYCLR:
                     mCb->sts->cpcRx++;
                     break;
                 case M_METPULSE:
                     mCb->sts->mpmRx++;
                     break;
                 case M_OPERATOR:
                     mCb->sts->oprRx++;
                     break;
                 default:
                     break;
               }
               break;
#endif /* SS7_CHINA */


            
            default:
               break;
         }
         break;
   }
   RETVALUE(ROK);
}


/*
*
*       Fun:   siUpdNSAPTxSts
*
*       Desc:  Update tx. statistics at an NSAP
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siUpdNSAPTxSts
(
SiNSAPCb *mCb,
U8       msgType
)
#else
PUBLIC S16 siUpdNSAPTxSts (mCb, msgType)
SiNSAPCb *mCb;
U8       msgType;
#endif
{
   TRC3(siUpdNSAPTxSts)

   switch (msgType)
   {
      case M_ADDCOMP:
         mCb->sts->adrCmpltTx++;
         break;
   
      case M_ANSWER:
         mCb->sts->answerTx++;
         break;
   
      case M_CALLPROG:
         mCb->sts->progressTx++;
         break;
   
      case M_CONTINUITY:
         mCb->sts->contiTx++;
         break;
   
      case M_CONTCHKREQ:
         mCb->sts->conChkReqTx++;
         break;
   
      case M_LOOPBCKACK:
         mCb->sts->loopBckAckTx++;
         break;
   
      case M_CONFUSION:
         mCb->sts->confusTx++;
         break;
   
      case M_CALLMODREQ:
         mCb->sts->callModReqTx++;
         break;
   
      case M_CALLMODREJ:
         mCb->sts->callModRejTx++;
         break;
   
      case M_CALLMODCOMP:
         mCb->sts->callModComTx++;
         break;
   
      case M_SUSPND:
         mCb->sts->suspTx++;
         break;
   
      case M_RESUME:
         mCb->sts->resmTx++;
         break;
   
      case M_FWDTFER:
         mCb->sts->forwTx++;
         break;
   
      case M_CONNCT:
         mCb->sts->conTx++;
         break;
   
      case M_RELSE:
         mCb->sts->relTx++;
         break;
   
      case M_OVERLOAD:
         mCb->sts->overldTx++;
         break;
   
      case M_RELCOMP:
         mCb->sts->relCmpltTx++;
         break;
   
      case M_FACIL:
         mCb->sts->facTx++;
         break;
   
      case M_FACACC:
         mCb->sts->facAckTx++;
         break;
   
      case M_FACREJ:
         mCb->sts->facRejTx++;
         break;
   
      case M_INIADDR:
         mCb->sts->initAdrTx++;
         break;
   
      case M_INFORMTN:
         mCb->sts->infoTx++;
         break;
   
      case M_INFOREQ:
         mCb->sts->infoReqTx++;
         break;
   
      case M_PASSALNG:
         mCb->sts->passAlongTx++;
         break;
   
      case M_SUBADDR:
         mCb->sts->subsAdrTx++;
         break;
   
      case M_USR2USR:
         mCb->sts->usrToUsrTx++;
         break;
   
      case M_UNEQUIPCIC:
         mCb->sts->uneqCirIdTx++;
         break;
   
      case M_NETRESMGT:
         mCb->sts->netResMgmtTx++;
         break;
   
      case M_IDENTREQ:
         mCb->sts->netIdReqTx++;
         break;
   
      case M_IDENTRSP:
         mCb->sts->netIdRspTx++;
         break;
      default: 
         switch (mCb->cfg.swtch)
         {

/* si029.220: Addition - added INDIA switch */
#if (SS7_RUSSIA || SS7_INDIA)
            case LSI_SW_RUSSIA:
            case LSI_SW_INDIA:
               switch (msgType)
               {
                  case M_CHARGE:
                     mCb->sts->chargeTx++;
                     break;

                  default:
                     break;
               }
               break;
#endif

/* si029.220: Modification - regroup the statistics counters */

#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
            case LSI_SW_ETSIV3:
            case LSI_SW_ITU97:
            case LSI_SW_RUSS2000:
            case LSI_SW_ITU2000:
               switch (msgType)
               {
                  case M_LOOPPRVNT:
                     mCb->sts->loopPrvntTx++;
                     break;
                     
                  case M_PRERELINF:
                     mCb->sts->preRelTx++;
                     break;

                  case M_APPTRAN:
                     mCb->sts->appTranTx++;
                     break;

                  default:
                     break;
               }
               break;
#endif
/* si029.220: Addition - added statistics for INDIA variant */
#ifdef SS7_INDIA
            case LSI_SW_INDIA:
               switch (msgType)
               {
                  case M_PRERELINF:
                     mCb->sts->preRelTx++;
                     break;

                  case M_APPTRAN:
                     mCb->sts->appTranTx++;
                     break;

                  default:
                     break;
               }
               break;
#endif

/* si034.220: Modificaiton - added CHINA switch */
#if SS7_CHINA
            case LSI_SW_CHINA:
               switch(msgType)
               {
		 case M_CLGPTYCLR:
                     mCb->sts->cpcTx++;
                     break;
                 case M_METPULSE:
                     mCb->sts->mpmTx++;
                     break;
                 case M_OPERATOR:
                     mCb->sts->oprTx++;
                     break;
                 default:
                     break;
               }
               break;
#endif /* SS7_CHINA */


            
            default:
               break;
         }
          break;
   }

   RETVALUE(ROK);
}


/*
*
*       Fun:   siUpdCirRxSts
*
*       Desc:  Update circuit recieve statistics.
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siUpdCirRxSts
(
SiCirCb *cir,
U8      msgType
)
#else
PUBLIC S16 siUpdCirRxSts (cir, msgType)
SiCirCb *cir;
U8      msgType;
#endif
{
   TRC2(siUpdCirRxSts)

   switch (msgType)
   {
      case M_BLOCK:
         cir->sts->blockRx++;
         break;

      case M_BLOCKACK:
         cir->sts->blockAckRx++;
         break;

      case M_UNBLK:
         cir->sts->unblockRx++;
         break;

      case M_UNBLKACK:
         cir->sts->unblockAckRx++;
         break;

      case M_RESCIR:
         cir->sts->cirResRx++;
         break;

      case M_CIRGRPQRY:
         cir->sts->cirGrQRx++;
         break;

      case M_CIRGRPQRYRES:
         cir->sts->cirGrQAckRx++;
         break;

      case M_CIRGRPBLK:
         cir->sts->cirGrBlockRx++;
         break;

      case M_CIRGRPBLKACK:
         cir->sts->cirGrBlockAckRx++;
         break;

      case M_CIRGRPUBLK:
         cir->sts->cirGrUnBlockRx++;
         break;

      case M_CIRGRPUBLKACK:
         cir->sts->cirGrUnBlockAckRx++;
         break;

      case M_CIRGRPRES:
         cir->sts->cirGrResRx++;
         break;

      case M_CIRGRPRESACK:
         cir->sts->cirGrResAckRx++;
         break;

      case M_USRPARTA:
         cir->sts->usrPrtAvRx++;
         break;

      case M_USRPARTT:
         cir->sts->usrPrtTstRx++;
         break;


      default:
         break;
   }

   RETVALUE(ROK);
}


/*
*
*       Fun:   siUpdCirTxSts
*
*       Desc:  Update circuit transmit statistics.
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siUpdCirTxSts
(
SiCirCb *cir,
U8      msgType
)
#else
PUBLIC S16 siUpdCirTxSts (cir, msgType)
SiCirCb *cir;
U8      msgType;
#endif
{
   TRC2(siUpdCirTxSts)

   switch (msgType)
   {
      case M_BLOCK:
         cir->sts->blockTx++;
         break;

      case M_BLOCKACK:
         cir->sts->blockAckTx++;
         break;

      case M_UNBLK:
         cir->sts->unblockTx++;
         break;

      case M_UNBLKACK:
         cir->sts->unblockAckTx++;
         break;

      case M_RESCIR:
         cir->sts->cirResTx++;
         break;

      case M_CIRGRPQRY:
         cir->sts->cirGrQTx++;
         break;

      case M_CIRGRPQRYRES:
         cir->sts->cirGrQAckTx++;
         break;

      case M_CIRGRPBLK:
         cir->sts->cirGrBlockTx++;
         break;

      case M_CIRGRPBLKACK:
         cir->sts->cirGrBlockAckTx++;
         break;

      case M_CIRGRPUBLK:
         cir->sts->cirGrUnBlockTx++;
         break;

      case M_CIRGRPUBLKACK:
         cir->sts->cirGrUnBlockAckTx++;
         break;

      case M_CIRGRPRES:
         cir->sts->cirGrResTx++;
         break;

      case M_CIRGRPRESACK:
         cir->sts->cirGrResAckTx++;
         break;

      case M_USRPARTA:
         cir->sts->usrPrtAvTx++;
         break;

      case M_USRPARTT:
         cir->sts->usrPrtTstTx++;
         break;


      default:
         break;
   }
   RETVALUE(ROK);
}


/*
*
*       Fun:   siGenAlarm
*
*       Desc:  generates alarm to Layer Manager (LMINT2)
*
*       Ret:   ROK - ok found
*
*       Notes: None
*
*       File:  ci_bdy6.c
*
*/

#ifdef ANSI
PUBLIC S16 siGenAlarm
(
Pst   *lmPst,
CirId cirId,
U16 event
)
#else
PUBLIC S16 siGenAlarm(lmPst, cirId, event)
Pst   *lmPst;
CirId cirId;
U16 event;
#endif
{
   SiMngmt usta;

   TRC2(siGenAlarm)

   /* if unsolicited status is enabled send Status Indication to the Stack 
      Manager */
   if (siCb.init.usta == TRUE) 
   {               
      SGetDateTime(&usta.t.usta.dt);

      usta.t.usta.evnt = event;

      usta.t.usta.circuit = cirId;

      SiMiLsiStaInd(lmPst, &usta);
   } 
   RETVALUE(ROK);
} /* end of siGenAlarm */

#endif /* !(SI_LMINT3 || SMSI_LMINT3) */


/*
*
*       Fun:   siInitUstaDgn
*
*       Desc:  Initialize diagnostics value structure for unsolicited status
*              indications
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: This function initializes 'ustaDgn' field in 'SiCb' structure.
*              This is a null function for LMINT2
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siInitUstaDgn 
(
U8  type1,
PTR val1, 
U8  type2,
PTR val2, 
U8  type3,
PTR val3, 
U8  type4,
PTR val4
)
#else
PUBLIC S16 siInitUstaDgn (type1, val1, type2, val2, type3, val3, type4, val4)
U8  type1;
PTR val1;
U8  type2;
PTR val2;
U8  type3;
PTR val3;
U8  type4;
PTR val4;
#endif
{
#if (SI_LMINT3 || SMSI_LMINT3)

   TRC2(siInitUstaDgn)
      /* initialize structure to zero */
      cmMemset((U8 *) &siCb.ustaDgn, '\0', sizeof(SiUstaDgn));
   siInitUstaDgnVal(&siCb.ustaDgn, 0x00, type1, val1);
   siInitUstaDgnVal(&siCb.ustaDgn, 0x01, type2, val2);
   siInitUstaDgnVal(&siCb.ustaDgn, 0x02, type3, val3);
   siInitUstaDgnVal(&siCb.ustaDgn, 0x03, type4, val4);
#else

   UNUSED(type1);
   UNUSED(type2);
   UNUSED(type3);
   UNUSED(type4);
   UNUSED(val1);
   UNUSED(val2);
   UNUSED(val3);
   UNUSED(val4);

#endif

   RETVALUE(ROK);
}/* siInitUstaDgn */

#ifdef SI_ACNT
  
/*
*
*       Fun:    siGenBill
*
*       Desc:   Generates Accounting Message to Manager
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy6.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siGenBill
(
SiCon *con 
)
#else
PUBLIC S16 siGenBill(con)
SiCon *con;
#endif
{
   SiMngmt acnt;
   REG1 U8 i;

   TRC2(siGenBill)
   if (siCb.init.acnt)
   {
      SGetDateTime(&acnt.t.siAcnt.dt);  
      siCalDur(con);
      acnt.t.siAcnt.acntRec.calDura = con->calDura;
      acnt.t.siAcnt.acntRec.dstAdr.length = con->dstAdr.length;
      for (i = 0; i < ADRLEN; i++)
         acnt.t.siAcnt.acntRec.dstAdr.strg[i] = con->dstAdr.strg[i]; 
      acnt.t.siAcnt.acntRec.srcAdr.length = con->srcAdr.length;
      for (i = 0; i < ADRLEN; i++)
         acnt.t.siAcnt.acntRec.srcAdr.strg[i] = con->srcAdr.strg[i]; 
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* Since we generate the billing records to layer manager only 
       * for outgoing connection, we use the numMulRateCkts in the
       * outgoing circuit connection.
       */
      acnt.t.siAcnt.acntRec.numCirUsed = con->outC.numMulRateCkts;
#endif
      SiMiLsiAcntInd(&siCb.init.lmPst, &acnt);
   } 
   else 
   {  
      SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "siGenBill: siCb.init.acnt is not SET\n"));  
   } 
   RETVALUE(ROK);
} /* end of siGenBill */

/*
*
*       Fun:    siCalDur
*
*       Desc:   Computes Call Duration
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   ci_bdy6.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siCalDur
(
SiCon *con 
)
#else
PUBLIC S16 siCalDur(con)
SiCon *con;
#endif
{
   REG1 Ticks timeTicks;
   Ticks crntTime;
   REG2 S32 var;
   REG3 S32 var1;
   REG4 U8 *buf;

   TRC2(siCalDur)
   buf = (U8 *) &con->calDura;
  
   SGetSysTime(&crntTime);

   if (crntTime < con->calDura)
      timeTicks = crntTime + (MAXSEGCNT - con->calDura);
   else
      timeTicks = crntTime - con->calDura;
   *buf++ = (U8) (timeTicks / 864000);
   var = timeTicks % 864000;
   *buf++ = (U8) (var / 36000);
   var1 = var % 36000;
   *buf++ = (U8) (var1 / 600);
   *buf++ = (U8) ((var1 % 600) / 10);
   RETVALUE(ROK);
} /* end of siCalDur */

#endif /* SI_ACNT */


/*
*
*       Fun:    siTrcBuf
*
*       Desc:   Trace Event Function. Called every time an event needs to be
*               traced. The first MAX_LSI_TRC number of bytes of a buffer are 
*               traced. MAX_LSI_TRC is defined in lsi.h as 16.
*
*       Ret:    ROK
*
*       Notes:  None
*
*       File:   ci_bdy6.c
*
*/
  
#ifdef ANSI
PUBLIC Void siTrcBuf
(
Dpc phyDpc,             /* dpc */
SiInstId intfId,        /* interface Id */
U16 evnt,               /* event */
U8 sapType,             /* sap type */
Buffer *mBuf            /* pointer to buffer */
)
#else
PUBLIC Void siTrcBuf(phyDpc, intfId, evnt, sapType, mBuf)
Dpc phyDpc;             /* dpc */
SiInstId intfId;        /* interface Id */
U16 evnt;               /* event */
U8 sapType;             /* sap type */
Buffer *mBuf;           /* poinTer to buffer */
#endif
{

   S16 ret;             /* return code */
   SiMngmt siMngmt;     /* management */
   S16 i;               /* index */

   TRC2(siTrcBuf)

   /* si001.220, ADDED: If general configuration is not done the lmPst is
    * not valid and we can't generate any traces
    */
   if (!siCb.init.cfgDone)
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
             "siTrcBuf : General config is not done\n"));
      RETVOID;
   }

   /* prepare management structure */
   siMngmt.hdr.msgType = TTRC;
   siMngmt.t.trc.evnt = evnt;
   siMngmt.t.trc.phyDpc = phyDpc;
   siMngmt.t.trc.sapType = sapType;

   ret = SFndLenMsg(mBuf,(MsgLen*) &siMngmt.t.trc.length);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   SFndLenMsg   failed   \n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI821, (ErrVal) 0, 
                 "siTrcBuf() Failed, SFndLenMsg failed");
      RETVOID;
   }
#endif
   /* validate message length */
   if (siMngmt.t.trc.length > MAX_LSI_TRC)
   {
      siMngmt.t.trc.length = MAX_LSI_TRC;
   }

   /* copy first bytes of buffer */
   for (i = 0; i < siMngmt.t.trc.length; i++)
      if ((ret = SExamMsg(&siMngmt.t.trc.evntParm[i], mBuf, i)) != ROK)
         break;

   /* put time stamp in management block */
   SGetDateTime(&siMngmt.t.trc.dt);

   SiMiLsiTrcInd(&siCb.init.lmPst, &siMngmt);

   RETVOID;
} /* end of siTrcBuf */

/* si006.220, MODIFIED: removed the SI_RUG flag */
/* si001.220, ADDED: Added functions for rolling upgrade */

/*
*
*       Fun:   siStaNSAP
*
*       Desc:  Update the Layer Management of the status of version number 
*              on the lower SAP
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siStaNSAP 
(
Pst *pst,             /* responding post structure */
SiMngmt *sta          /* status request */
)
#else
PUBLIC S16 siStaNSAP (pst, sta)
Pst *pst;             /* responding post structure */
SiMngmt *sta;         /* status request */
#endif
{
   SiNSAPCb *cb;      /* lower SAP control block */

   TRC2(siStaNSAP)

   if ((sta->t.ssta.elmntId.sapId > (SpId)siCb.genCfg.nmbSaps) ||
       (sta->t.ssta.elmntId.sapId < 0))
   {
      sta->cfm.status = LCM_PRIM_NOK;
      sta->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
      SiMiLsiStaCfm(pst, sta);
      RETVALUE(RFAILED);
   }

   switch (sta->t.ssta.param.nsap.nsapType)
   {
      case SAP_MTP:
      case SAP_M3UA:
         if ((cb = SIMTPSAP(sta->t.ssta.elmntId.sapId)) == NULLP)
         {
            sta->cfm.status = LCM_PRIM_NOK;
            sta->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
            SiMiLsiStaCfm(pst, sta);
            RETVALUE(RFAILED);
         }

         /* si025.220, Modified: add LSIV4 flag */
         /* si009.220, Modified: add LSIV3 flag */
         /* si006.220, MODIFIED: modified the code to support the query on 
          * SAP other than the version related information
          */
#if (LSIV2 || LSIV3 || LSIV4)
         sta->t.ssta.cfm.s.siSAPVer.suId = cb->suId;
         sta->t.ssta.cfm.s.siSAPVer.spId = cb->spId;
         sta->t.ssta.cfm.s.siSAPVer.state = cb->state;
#endif /* LSIV2 || LSIV3 || LSIV4 */
#ifdef SI_RUG
         /* SAP version number */
         sta->t.ssta.cfm.s.siSAPVer.selfIntfVer = SNTIFVER;
         sta->t.ssta.cfm.s.siSAPVer.remIntfValid = cb->remIntfValid;
         sta->t.ssta.cfm.s.siSAPVer.remIntfVer = cb->pst.intfVer;
#endif /* SI_RUG */
         break;

#ifdef SI_SPT
      case SAP_SCCP:
         if (siCb.genCfg.sccpSup == TRUE)
         {
            if ((cb = SISCCPSAP(sta->t.ssta.elmntId.sapId)) == NULLP)
            {
               sta->cfm.status = LCM_PRIM_NOK;
               sta->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
               SiMiLsiStaCfm(pst, sta);
               RETVALUE(RFAILED);
            }
            /* si025.220, Modified: add LSIV4 flag */
            /* si009.220, Modified: add LSIV3 flag */
            /* si006.220, MODIFIED: modified the code to support the query on 
             * SAP other than the version related information
             */
#if (LSIV2 || LSIV3 || LSIV4)
            sta->t.ssta.cfm.s.siSAPVer.suId = cb->suId;
            sta->t.ssta.cfm.s.siSAPVer.spId = cb->spId;
            sta->t.ssta.cfm.s.siSAPVer.state = cb->state;
#endif /* LSIV2 || LSIV3 || LSIV4 */
#ifdef SI_RUG
            /* SAP version number */
            sta->t.ssta.cfm.s.siSAPVer.selfIntfVer = SPTIFVER;
            sta->t.ssta.cfm.s.siSAPVer.remIntfValid = cb->remIntfValid;
            sta->t.ssta.cfm.s.siSAPVer.remIntfVer = cb->pst.intfVer;
#endif /* SI_RUG */
         }   
         break;
#endif /* SI_SPT */

      default: /* invalid SAP type */
         sta->cfm.status = LCM_PRIM_NOK;
         sta->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
         SiMiLsiStaCfm(pst, sta);
         RETVALUE(RFAILED);
   }       
   sta->cfm.status = LCM_PRIM_OK;
   sta->cfm.reason = LCM_REASON_NOT_APPL;
   SiMiLsiStaCfm(pst, sta);

   RETVALUE(ROK);
} /* end of siStaNSAP */


/*
*
*       Fun:   siStaUpSAP
*
*       Desc:  Update the Layer Management of the status of version number 
*              on the upper SAP
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siStaUpSAP 
(
Pst *pst,              /* responding post structure */
SiMngmt *sta           /* Status request */
)
#else
PUBLIC S16 siStaUpSAP (pst, sta)
Pst *pst;              /* responding post structure */
SiMngmt *sta;          /* Status request */
#endif
{
   SiUpSAPCb *tCb;     /* upper SAP control block */
   SpId      spId;     /* upper SAP Id */

   TRC2(siStaUpSAP)

   spId = sta->t.ssta.elmntId.sapId;

   if ((spId > (SpId)siCb.genCfg.nmbSaps) || 
       (spId < 0) ||
       (NULLP == (tCb = SIUPSAP(spId))))
   {
      sta->cfm.status = LCM_PRIM_NOK;
      sta->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
      SiMiLsiStaCfm(pst, sta);
      RETVALUE(RFAILED);
   }
   /* si025.220, add LSIV4 flag */
   /* si009.220, add LSIV3 flag */
   /* si006.220, MODIFIED: modified the code to support the query on 
    * SAP other than the version related information
    */
#if (LSIV2 || LSIV3 || LSIV4)
   sta->t.ssta.cfm.s.siSAPVer.suId = tCb->suId;
   sta->t.ssta.cfm.s.siSAPVer.spId = tCb->spId;
   sta->t.ssta.cfm.s.siSAPVer.state = tCb->state;
#endif /* LSIV2 || LSIV3 || LSIV4 */
#ifdef SI_RUG
   /* SAP version info */
   sta->t.ssta.cfm.s.siSAPVer.selfIntfVer = SITIFVER;
   sta->t.ssta.cfm.s.siSAPVer.remIntfValid = tCb->remIntfValid;
   sta->t.ssta.cfm.s.siSAPVer.remIntfVer = tCb->pst.intfVer;
#endif /* SI_RUG */
   sta->cfm.status = LCM_PRIM_OK;
   sta->cfm.reason = LCM_REASON_NOT_APPL;
   SiMiLsiStaCfm(pst, sta);

   RETVALUE(ROK);
} /* end of siStaUpSAP */

#ifdef SI_RUG

/*
 *
 *      Fun:   Get Interface Version Handling
 *
 *      Desc:  Processes system agent control request primitive
 *             to get interface version for all interface implemented 
 *             by the protocol.
 *
 *      Ret:   ROK   - ok
 *
 *      Notes: None
 *
 *      File:  ci_bdy6.c
 *
 */
#ifdef ANSI
PUBLIC S16 siGetVer
(
ShtGetVerCfm *getVerCfmInfo   /* to return interface version information */
)
#else
PUBLIC S16 siGetVer(getVerCfmInfo)
ShtGetVerCfm *getVerCfmInfo;  /* to return interface version information */
#endif
{
   TRC3 (siGetVer)

   /* Fill the upper interface IDs and their ver number */
   getVerCfmInfo->numUif = 1;
   getVerCfmInfo->uifList[0].intfId = SITIF;
   getVerCfmInfo->uifList[0].intfVer = SITIFVER;

   /* Fill the lower interface IDs and their ver number */
   getVerCfmInfo->numLif = 1;
   getVerCfmInfo->lifList[0].intfId = SNTIF;
   getVerCfmInfo->lifList[0].intfVer = SNTIFVER;
   

#ifdef SI_SPT
   getVerCfmInfo->numLif = 2;
   getVerCfmInfo->lifList[1].intfId = SPTIF;
   getVerCfmInfo->lifList[1].intfVer = SPTIFVER;
#endif

#ifdef ZI 
   /* Fill peer interface ID and version number */
   ziGetVer(&getVerCfmInfo->pif);
#endif /* ZI */

   RETVALUE(ROK);
} /* End of siGetVer */


/*
 *
 *      Fun:   Set Interface Version Handling
 *
 *      Desc:  Processes system agent control request primitive
 *             to set interface version.
 *
 *      Ret:   ROK   - ok
 *
 *      Notes: None
 *
 *      File:  ci_bdy6.c
 *
 */
#ifdef ANSI
PUBLIC S16 siSetVer
(
ShtVerInfo *setVerInfo,        /* version information to set */
CmStatus   *status             /* status to return */
)
#else
PUBLIC S16 siSetVer(setVerInfo, status)
ShtVerInfo *setVerInfo;        /* version information to set */
CmStatus   *status;            /* status to return */
#endif
{
   Bool       found;     /* Flag to indicate if found in the stored structure */
   U16        i;         /* index */
   ShtVerInfo *intfInf;  /* interface version info */
   SiUpSAPCb  *tCb;      /* upper SAP control block */
   SiNSAPCb   *nCb;      /* lower SAP control block */
   Cntr       j;         /* index */

   TRC2(siSetVer)

   found = FALSE;
   /* Validate Set Version Information */
#ifdef ZI
   /* See if this is applicable to PSF. If PSF says it is not applicable (RNA)
    * we analyze further.                      
    */
   if(ziSetVer(&setVerInfo->intf, status) != RNA)
      RETVALUE(ROK);
#endif /* ZI */

   switch(setVerInfo->intf.intfId)
   {
      case SITIF:
         if (setVerInfo->intf.intfVer > SITIFVER)
            status->reason = LCM_REASON_VERSION_MISMATCH;
         break;

      case SNTIF:
         if (setVerInfo->intf.intfVer > SNTIFVER)
            status->reason = LCM_REASON_VERSION_MISMATCH;
         break;

#ifdef SI_SPT
      case SPTIF:
         if (setVerInfo->intf.intfVer > SPTIFVER)
            status->reason = LCM_REASON_VERSION_MISMATCH;
         break;
#endif /* SI_SPT */

      default:
         status->reason = LCM_REASON_INVALID_PAR_VAL;
   }
   if (status->reason != LCM_REASON_NOT_APPL )
      RETVALUE(RFAILED);

   /* validate grptype */
   if ((setVerInfo->grpType != SHT_GRPTYPE_ALL) &&
       (setVerInfo->grpType != SHT_GRPTYPE_ENT))
   {
      status->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   /* See if stored information already exists */
   for(i = 0; i < siCb.numIntfInfo && found == FALSE; i++)
   {
      intfInf = &siCb.intfInfo[i];
      if (intfInf->intf.intfId == setVerInfo->intf.intfId)
      {
         if (intfInf->grpType == setVerInfo->grpType)
         {
            /* Stored information found. Replace the information with new *
             * version information specified in this set version request  */
            switch(setVerInfo->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if (intfInf->dstProcId == setVerInfo->dstProcId &&
                     intfInf->dstEnt.ent == setVerInfo->dstEnt.ent &&
                     intfInf->dstEnt.inst == setVerInfo->dstEnt.inst)
                  {
                     intfInf->intf.intfVer = setVerInfo->intf.intfVer;
                     found = TRUE;
                  }
                  break;

               case SHT_GRPTYPE_ENT:
                  if (intfInf->dstEnt.ent == setVerInfo->dstEnt.ent &&
                     intfInf->dstEnt.inst == setVerInfo->dstEnt.inst )
                  {
                     intfInf->intf.intfVer = setVerInfo->intf.intfVer;
                     found = TRUE;
                  }
                  break;
               default:
                  /* not possible */
                  break;
            }
         }
      }
   }

   /* In the worst case we should be required to store one version *
    * information for every configured sap in the layer.           */
   if (found == FALSE)
   {
      if (siCb.numIntfInfo < (siCb.genCfg.nmbSaps + siCb.genCfg.nmbNSaps))
      {
         cmMemcpy ((U8 *)&siCb.intfInfo[i], (U8 *)setVerInfo, sizeof(ShtVerInfo));
         siCb.numIntfInfo++;
      }
      else
      {
         status->reason = LCM_REASON_EXCEED_CONF_VAL;
         RETVALUE(RFAILED);
      }
   }

   /* Information in set version stored. Now update the SAPs */
   switch (setVerInfo->intf.intfId)
   {
      case SITIF:
         for (j = 0; j < (Cntr) siCb.genCfg.nmbSaps; j++)
         {
            if ((tCb = SIUPSAP(j)) == NULLP)
               continue;

             /* If it is an unbound SAP then the remote entity, instance 
              * and proc ID would not be available and hence we should  
              * wait for bind to happen to set the remote interface ver  
              */
            if (tCb->state != SI_BND)
               continue;

            /* now match on dstproc/ent/inst */
            found = FALSE;
            switch(setVerInfo->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if(tCb->pst.dstProcId == setVerInfo->dstProcId &&
                     tCb->pst.dstEnt == setVerInfo->dstEnt.ent &&
                     tCb->pst.dstInst == setVerInfo->dstEnt.inst)
                  {
                     found = TRUE;
                  }
                  break;
               case SHT_GRPTYPE_ENT:
                  if(tCb->pst.dstEnt == setVerInfo->dstEnt.ent &&
                     tCb->pst.dstInst == setVerInfo->dstEnt.inst)
                  {
                     found = TRUE;
                  }
                  break;
               default:
                  /* not possible */
                  break;
            }
            if (found == TRUE)
            {
               tCb->pst.intfVer = setVerInfo->intf.intfVer;
               tCb->remIntfValid = TRUE;
            }
         }
         break;

      case SNTIF:
         for (j = 0; j < (Cntr) siCb.genCfg.nmbNSaps; j++)
         {
            if ((nCb = SIMTPSAP(j)) == NULLP)
               continue;

            /* now match on dstproc/ent/inst */
            found = FALSE;
            switch(setVerInfo->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if (nCb->pst.dstProcId == setVerInfo->dstProcId &&
                      nCb->pst.dstEnt == setVerInfo->dstEnt.ent &&
                      nCb->pst.dstInst == setVerInfo->dstEnt.inst)
                     found = TRUE;
                  break;

               case SHT_GRPTYPE_ENT:
                  if (nCb->pst.dstEnt == setVerInfo->dstEnt.ent &&
                      nCb->pst.dstInst == setVerInfo->dstEnt.inst)
                     found = TRUE;
                  break;

               default:
                  /* not possible */
                  break;
            }
            if (found == TRUE)
            {
               nCb->pst.intfVer = setVerInfo->intf.intfVer;
               nCb->remIntfValid = TRUE;
            }
         }
         break;

#ifdef SI_SPT
      case SPTIF:
         for (j = 0; j < (Cntr) siCb.genCfg.nmbNSaps; j++)
         {
            if ((nCb = SISCCPSAP(j)) == NULLP)
               continue;

            /* now match on dstproc/ent/inst */
            found = FALSE;
            switch(setVerInfo->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if (nCb->pst.dstProcId == setVerInfo->dstProcId &&
                      nCb->pst.dstEnt == setVerInfo->dstEnt.ent &&
                      nCb->pst.dstInst == setVerInfo->dstEnt.inst)
                     found = TRUE;
                  break;

               case SHT_GRPTYPE_ENT:
                  if (nCb->pst.dstEnt == setVerInfo->dstEnt.ent &&
                      nCb->pst.dstInst == setVerInfo->dstEnt.inst)
                     found = TRUE;
                  break;

               default:
                  /* not possible */
                  break;
            }
            if (found == TRUE)
            {
               nCb->pst.intfVer = setVerInfo->intf.intfVer;
               nCb->remIntfValid = TRUE;
            }
         }
         break;
#endif /* SI_SPT */

      default:
          /* not possible */
         break;
   }

   RETVALUE(ROK);
} /* End of siSetVer */

#endif /* SI_RUG */


/* si006.220, ADDED: added a function to check if exists an interface control
 * block associated with a SAP to be deleted.
 */
/*
*
*       Fun:   siFndIntfInSAP
*
*       Desc:  Check if exists an interface control block associated with
*              the lower/upper SAP to be deleted. 
*              
*       Ret:   ROK - ok; ROKDNA - found interface; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 siFndIntfInSAP 
(
SpId    sapId,           /* sapId of deleted SAP */
S16     elmnt,           /* upper or lower sap */
S16     nsapType         /* lower sap type */
)
#else
PUBLIC S16 siFndIntfInSAP (sapId, elmnt, nsapType)
SpId    sapId;           /* sapId of deleted SAP */
S16     elmnt;           /* upper or lower sap */
S16     nsapType;        /* lower sap type */
#endif
{
   SiIntfCb   *intfCb;   /* interface cb */
   SiIntfCb   *prevIntf; /* interface cb */
  
   TRC2(siFndIntfInSAP)

   intfCb = NULLP;
   prevIntf = NULLP;

   /* search the hash list sequebtially */
   while (cmHashListGetNext(&siCb.intfHlCp.k1Cp, (PTR) prevIntf, 
          (PTR *) &intfCb) == ROK)
   {
      if (intfCb)
      {
         switch (elmnt)
         {
            /* lower SAP */
            case STNSAP:
            {  

               if ((nsapType == SAP_MTP || nsapType == SAP_M3UA) &&
                   (intfCb->msapId == sapId))
               {
                  RETVALUE(ROKDNA);
               }
#ifdef SI_SPT
               if (nsapType == SAP_SCCP && intfCb->ssapId == sapId)
               {
                  RETVALUE(ROKDNA);
               }
#endif /* SI_SPT */
               break;
            }
#if (SI_LMINT3 || SMSI_LMINT3)
            /* upper SAP */
            case STISAP:
               if (intfCb->cfg.sapId == sapId)
               {
                  RETVALUE(ROKDNA);
               }
               break;
#endif
            default:
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid sap type %d\n", elmnt));  
               RETVALUE(RFAILED); 
         } /* end of switch */
      } /* end of if */   

      prevIntf = intfCb;
      intfCb = NULLP;

   } /* end of while */

   /* could not find */
   RETVALUE(ROK);
} /* end of siFndIntfInSAP */


/* si006.220, ADDED: added function to handle the force block procedures */
#if (SI_LMINT3 || SMSI_LMINT3)
/*
*
*       Fun:   siCntrlForBlkCirGr
*
*       Desc:  Process control request for force blocking on a ISUP circuit
*              group. Even if the circuit indicated in the control request is
*              not configured, ISUP still sends out CGB to the network. This 
*              procedure is called force blocking. It is used in a distributed
*              ISUP environment.
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy6.c
*
*/
#ifdef ANSI
PRIVATE S16 siCntrlForBlkCirGr
(
Pst         *pst,
SiMngmt     *cntrl
)
#else
PRIVATE S16 siCntrlForBlkCirGr(pst, cntrl)
Pst     *pst;
SiMngmt *cntrl;
#endif
{
   SiPduHdr  pduHdr;
   SiNSAPCb  *cb;
   SpId      sapId;
   SiElmntCntrl *eCntrl;
/* si009.220 - Modified: add LSIV3 flag */   
/* si025.220: Modification - added LSIV4 */
#if (LSIV2 || LSIV3 || LSIV4)
   SiAllPdus allPdus;
   S16       ret;
   LnkSel    lnkSel;
   Buffer    *mBuf;            /* message buffer */
   Swtch     swtch;
   Cic       cic;
   Dpc       opc;
   Dpc       phyDpc;
   Cntr      i;
#endif 
   Buffer    *uBuf;

   TRC3(siCntrlForceGrpCb);
   
   sapId = cntrl->t.cntrl.s.siElmnt.elmntId.sapId;
/* si025.220 - Modified: add LSIV4 flag */
/* si009.220 - Modified: add LSIV3 flag */   
#if (LSIV2 || LSIV3 || LSIV4)
   swtch = cntrl->t.cntrl.s.siElmnt.elmntParam.forblk.swtch;
   cic = cntrl->t.cntrl.s.siElmnt.elmntParam.forblk.cic;
   opc = cntrl->t.cntrl.s.siElmnt.elmntParam.forblk.opc;
   phyDpc = cntrl->t.cntrl.s.siElmnt.elmntParam.forblk.phyDpc;
#endif
   uBuf = NULLP;

   /* get the network SAP */
   if ((cb = SIMTPSAP(sapId)) == NULLP)
   {
      cntrl->cfm.status = LCM_PRIM_NOK;
      cntrl->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
      SiMiLsiCntrlCfm(pst, cntrl);
      RETVALUE(ROK);
   }

   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_CIRGRPBLK;

   eCntrl = &cntrl->t.cntrl.s.siElmnt;
/* si009.220 - Modified: to pass cic into siGetLnkSel and add LSIV3 flag. */ 
/* si025.220 - Modified: add LSIV4 flag. */
#if (LSIV2 || LSIV3 || LSIV4)  
   /* si025.220: Modification - modify the link selection. Since ISUP may not
    * have the circuit and interface configured in this case, we can not
    * search the circuit and pass the circuit control block pointer to the
    * siGetLnkSel function. Also if the interface is not configured in this
    * ISUP instance, there is no way to increment the lnkSel counter inside
    * the interface control block. So we are forced to choose lnkSel as per
    * cic value. */

   lnkSel = 0; /* initialize to 0 */
   switch(swtch)
   {
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
     case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
     case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - addded INDIA switch */
#ifdef SS7_INDIA
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
       case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         lnkSel = (LnkSel) (cic & MOD15);
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SILOGERROR(ERRCLS_DEBUG, ESIXXX, (ErrVal) swtch,
                 "siCntrlForBlkCirGr Failed, invalid switch");
/* si051.220: Addition - Control Confirm added */      
         cntrl->cfm.status = LCM_PRIM_NOK;
         cntrl->cfm.reason = LCM_REASON_MISC_FAILURE;
         SiMiLsiCntrlCfm(pst, cntrl);
         RETVALUE(ROK);
         break;
#endif
   }

   MFINITPDU(&cb->mfMsgCtl, ret, (U8) 0, (U8) MI_CIRGRPBLK,
             NULLP, (ElmtHdr *) &allPdus, (U8) PRSNT_DEF,
             swtch, (U32) MF_ISUP);

   allPdus.m.cirGrpBlk.cgsmti.eh.pres       = PRSNT_NODEF;
   allPdus.m.cirGrpBlk.cgsmti.typeInd.pres  = PRSNT_NODEF;
   allPdus.m.cirGrpBlk.cgsmti.typeInd.val   = eCntrl->elmntParam.forblk.cgsmti;

   allPdus.m.cirGrpBlk.rangStat.eh.pres     = PRSNT_NODEF;
   allPdus.m.cirGrpBlk.rangStat.range.pres  = PRSNT_NODEF;
   allPdus.m.cirGrpBlk.rangStat.range.val   = eCntrl->elmntParam.forblk.range;

   allPdus.m.cirGrpBlk.rangStat.status.pres = PRSNT_NODEF;
   allPdus.m.cirGrpBlk.rangStat.status.len  = 
               ((U8)( (U8) eCntrl->elmntParam.forblk.range >> 0x03) + 1);
   for (i = 0; i < (Cntr) allPdus.m.cirGrpBlk.rangStat.status.len; i++)
      allPdus.m.cirGrpBlk.rangStat.status.val[i] = 
                                       eCntrl->elmntParam.forblk.status[i];

   /* build message */
   ret = siBldMsg(cb, cic, &pduHdr, &allPdus, cb->pst.region, cb->pst.pool,
                  &mBuf, swtch, uBuf);
   if (ret != ROK)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   siBldMsg   failed   \n"));  
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESIXXX, (ErrVal) 0, 
                 "siCntrlForBlkCirGr() Failed, siBldMsg failed ");
#endif
      cntrl->cfm.status = LCM_PRIM_NOK;
      cntrl->cfm.reason = LCM_REASON_MISC_FAILURE;
      SiMiLsiCntrlCfm(pst, cntrl);
      RETVALUE(ROK);
   }
   /* send message */
   siSndMsg(cb, mBuf, opc, 0, phyDpc, FALSE, lnkSel, TRUE, PRI_ZERO, swtch);
#endif /* LSIV2 || LSIV3 || LSIV4 */

   /* return confirmation to layer management */
   SISNDLSICNTRLCFM(pst, cntrl, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 0, 
                    SI_CNTRL_OK);
   RETVALUE(ROK);
} /* end of siCntrlForBlkCirGr */
#endif


#ifdef CP_OAM_DATA_SHOW
S16 siPrintCfgInfo()
{
    printf("------ISUP config print --------------------------\n");
    printf("--------------------------------\n");

    printf("\n[SiGenCfg]\n");
    printf("nmbSaps nmbNSaps nmbCir nmbIntf nmbCirGrp nmbCalRef\n");
    printf("I4       I4       I4      I4       I4        I4    \n");
    printf("--------------------------------\n");

    printf(" %-7d %-8d %-8d %-8d %-8d %-8d\n", 
    siCb.genCfg.nmbSaps,
    siCb.genCfg.nmbNSaps,
    siCb.genCfg.nmbCir,
    siCb.genCfg.nmbIntf,
    siCb.genCfg.nmbCirGrp,
    siCb.genCfg.nmbCalRef);
 
    printf("--------------------------------\n");

    RETVALUE(ROK);
}
#endif


  
/********************************************************************30**
  
         End of file:     ci_bdy6.c@@/main/10 - Wed Jul 25 13:20:56 2001

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rh   1. initial release.
                      ym   1. Function siCntrlSiCirGrpCb is added to 
                              handle circuit group request for blocking/
                              unblocking/reset .
1.2          ---      ao   1. Pointer to statistic data was wrong in 
                              siStsSiCirCb and siStsNSAP.
                      ym   1. Changes in siCntrlSiIntfCb function . 
             ---      rs   1. Modifications to delete the DPC control
                              block after it is delete from hash list.
             ---      ym   1. Modifications for Debug prints 
1.3          ---      ao   1. Added Russian variant
1.4          ---      dvs  1. rev sync
1.4+         ---      ym   1. Confirmation is corrected for route config.
                              DPC config. and delete route, control request 
                              on ISUP circuit, Traces and statistics for
                              the lower SAP.
                           2. Parameters are corrected in siGenAlarmNew.
              ---     ym   1. In circuit configuration cirFlg is updated.
              ---     ym   1. Call duration calculation is corrected if 
                              there is no roll over.
              ---     ym   1. siFindCir is replaced with cmHashListGetNext
                              to improve performance in handling of CntrlReq 
                              to disable or enable DPC.
              ---     ym   1. Statistics related to different messages
                              are updated taking into account the 
                              possibility of same message type across 
                              variants.
                           2. The cfm is updated for SI_LMINT3 and
                              SMSI_LMINT3 options only.
1.5          ---      ym   1. Changes related to addition of NTT variant in
                              ISUP.
1.8          ---      ym   1. The calculation for the maximum required
                              size is corrected.
             ---      tz   1. Added code to delete the DPC timers first
                              before the DPC control block is removed.
                           2. Changed code to make sure the index of the
                              circuit state indicator is less than
                              MAX_SIZ_STATUS.
                           3. Changed code to update the range value in the
                              the circuit group to be the actual value that
                              has been used.
             ---      tz   1. Added code to initialize the upper SAP id in
                              the ISAP configuration to the SAP id received
                              from the layer manager.
                           2. Changed code to update the sapId in the ISUP
                              control block to be that received from the 
                              layer manager.
             ---      tz   1. Added code to initialize the upper SAP id in
                              the ISAP configuration to the SAP id received
                              from the layer manager during the ISAP
                              configuration.
                           2. Changed code to update the sapId in the ISUP
                              control block to be that received from the
                              layer manager during the ISAP configuration.
             ---      tz   1. Changed code so that the address length in
                              route entry is correctly assigned.
                           2. Added error checking for function call of
                              siDelRout.
             ---      bsp  1. Removed code related to unused variable tmr in
                              SiUstaDgnVal
             ---      rrb  2. Incorporated changes in siCfgSiCirCb function to
                              accomodate CONTROLLING and CONTROLLED type
                              of circuits.
             ---      ym   1. siRelNSAPCon is modified to perform the GetNext
                              from a deleted connection block too.
                           2. siCir is initialised properly in siCntrlSiIntfCb. 
                           3. dstProcId is compared for RM SAP on getting any
                              request for group of lower SAPs.
                           4. NT compilation warnings are removed.

/main/9      ---      rrb  1. Corrected code to initialize "cir->sts" field
                              in siStsSiCirCb function.
                           2. Added code to copy more NSAP configuration
                              fields to NSAP cfg structure and especially
                              to initialize the mem of mfMsgCtl in the NSAP.
            si002.218 bsp  1. Used nmbNSaps, nmbSaps fields of siGenCfg instead
                              of Saps counter as upper bound when searching for
                              SAP control block in siCntrlGrpSAP, siCntrlSiLyr
                              funtions.
                       sk  1. Support for tcr18.02 , group operation on saps from
                              system agent, and controlling entity in saps
             ---       hy  1. Removed the configuration of bearProf field in 
                              function siCfgSiCirCb 
                           2. Changed the reason field on getting the control
                              request for deleting a non-existed route in
                              siCntrlRoute 
                           3. Added the configuration of availTest field in 
                              function siCfgSiIntfCb for ans'95 variant.
                           4. Added variant type for ANS95, ITU97 and ETSI v3
                           5. Added error checking for tmpCb in siCfgIntfCb.
                           6. Added code to assign the ssf in the cir
                              cb from IntfCb in siCntrlSiCirCb.
                           7. changes for removal of swtch and ssf field in
                              circuit control block.
                           8. Changes for handing of non-single rate 
                              connection.
                           9. Added code to deallocate the SiCirSts pointer
                              and make other pointer as NULLP in a circuit
                              when force delete the circuit in siCntrlSiCirCb.
                       ym  1. SI_218_MSAP_COMP is changed to SI_218_COMP.
                      bsp  2. Changed hash define names which were changed
                              in sit.h to resolve clash between sit.h and 
                              int.h
                           3. Changed code for upper sap configuration to
                              check sap state before writing come fields
                           4. Removed SITVER2 flag.
                           5. Removed internal router code. Removed 
                              configuration, deletion and CntrlReq
                           6. Patch propogation changes:
                              . Added break statements in siCntrlGrpSAP to 
                                switch statements for the SAP_MTP & SAP_SCCP 
                                cases
                              . Changed siCntrlGrpSap such that nsapType 
                                field is ignored.
                       hy  1. Remove the #if 1 or #if 0 tags in the file.
                           2. fixed a bug in function siCntrlElmnt if 
                              SI_218_COMP is defined.
                           3. Change #if SI_218_COMP to #ifdef SI_218_COMP
                       sk  1. Update sby after sending bndreq to service
                              provider
                       bsp 1. Fixed cmHashListGetNext bug in siRelNSAPCon
                              when processing SCCP SAPs
                       hy  1. Added default case for switch statement on
                              variant type in siGetNmbDpcCic.
                       sk  1. Added the initialization of cbType in 
                              siCntrlTrcInd
                       hy  1. Removed the include of lrm.h.
/main/10     ---        hy  1. Modified siCntrlSiIntfCb so that the interface
                              sts counters & initial cfg profile of circuits,
                              for PSIF-ISUP, are released before releasing the
                              interface control block
                           2. Modified siStaSiCirCb such that SiMiLsiStaCfm is
                              called directly rather calling the primitive via
                              the SISNDLSISTACFM macro
                           3. Deleted the code to check the force deleted flag
                              before removing the sts and some pointer in 
                              siCirCb when ISUP deleted the circuit control 
                              block in siCntrlSiCirCb
           si001.220   hy  1. Added code to handle the configuration of 
                              version number from LM at lower SAP and upper SAP.
                           2. Added code to allocate the memory for storing
                              the version information during and store the layer
                              interface ver info in the general configuration 
                              from LM.
                           3. Added new function siStaNSAP and siStaUpSAP.
                           4. Added code to check the remote version number 
                              valid flag when bind enable the lower SAP
                              in function siCntrlNSAPNew ans siCntrlGrpSAP.
                           5. Added code to mark the remote intf version as
                              invalid in function siCntrlUpSAP and 
                              siCntrlGrpSAP.
                           6. Added new functions siGetVer and siSetVer
                           7. Checked general configuration is done or not in
                              function siGenAlarmNeNeww and siTrcBuf.
                           8. Added runtime updation for acnt, usta and dbgMask
                           9. Added code to assign the fields in hdr of
                              alarm in function siGenAlarmNew.
                          10. Added case for version number in siInitUstaDgnVal 
                          11. Assigned the length of charge number in function
                              siGenBill.
           si002.220   mm  1. In function siCfgSiCirCb, added code for 
                              reconfiguration of firstCic and numCir.
           si006.220   hy  1. Used the hash define LCM_REASON_NOT_APPL instead
                              of 0 when returning a successful configuration/
                              control confirmation.
                           2. Modified code to return a successful confirmation
                              when received a repeated control request on
                              deleting action and shutting down the layer.
                           3. In siCntrlElmnt, added the check to allow only
                              the deletion and shutting down the layer to be
                              performed on standby copy.
                           4. Modified code to support deletion of upper/lower
                              SAPs.
                           5. Modified function siStaNSAP and siStaUpSAP to 
                              support the query on SAP information other
                              than version related info.
                           6. Added control request on force blocking a
                              group of circuits.
           si007.220   mm  1. In function siInitUstaDgnVal, added code to deal 
                              the situation when type is LSI_USTA_DGNVAL_DPC.
           si009.220   mm  1. In function siCfgGen, added link selector option
                              field so that link selector could be configurable
                              and reconfigurable.
                           2. Modified code so that when calling siGetLnkSel an
                              extra parameter cic will be passed in.
                           3. Added LSIV3 flag for transaction logic to support 
                              rolling upgrade from LSIV1 to LSIV3.
           si010.220   hy  1. When handling the enable interface control
                              request, set the interface state available first
           si025.220   tz  1. Added interface link seletion option and link
                              selection bits.
                           2. Added LSIV4 to LSIV3 conditions.
           si029.220   tz  1. Added INDIA variant.
           si030.220   tz  1. Changed hash list key type from default to proper
                              values to get better search performance.
                           2. Changed hash list bin size from max number of
                              interfaces configured in general configuration
                              for interface hash list in order to save memory
                              space.
           si034.220  rk   1. Added CHINA flag and switch where applicable.
           si035.220  rk   1. Checks introduced to prevent memory leaks.
           si038.220  rk   1. Fix related to SR 53021. Circuit not getting
                              deleted if interface  does not exist 
           si042.220  bn   1. Added ITU2000 and Russian 2000 ISUP variants.
           si043.220  rk   1. BHARTI Specific changes for circuit 
                              configuration/reconfiguration added 
           si044.220  rk   1. Bulk cir cfg Specific changes for circuit 
                              configuration/reconfiguration added 
		           2. Deletion - If statistics buffer allocation fails siIntfCb should not be freed
	  si045.220   ng   1. Modified - Delete the Interface control block in case of SGetMBuf fails for 
			      stat buffers
          si047.220   ng   1. Proper pointer type passed in SFndLenMsg
          si051.220   rk   1. Control Confirm added
	  si054.220   vp   1. Added New case for LSI_STS_UNXEVT 
*********************************************************************91*/
