/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

    Name:     ISUP - external - mos

    Type:     C source file

    Desc:     Functions required for scheduling and initialization.

    File:     ci_ex_ms.c

    Sid:      ci_ex_ms.c@@/main/41 - Wed Mar 14 15:34:28 2001
 
    Prg:      bn

*********************************************************************21*/


/************************************************************************

     Note: 

     This file has been extracted to support the following options:

     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif

************************************************************************/


/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#ifdef IW
#include "cct.h"           /* ISUP PSIF Interface to Generic Call Control */
#include "rmt.h"           /* PSIF Interface to Resource Manager */
#endif
#include "lsi.h"           /* layer manager */
#include "si_mf.h"         /* message functions */
#include "cm_hash.h"       /* hash-list header */
#include "cm5.h"           /* common timers  */
#include "ci_db.h"         /* isup data base */
#include "snt.h"           /* mtp level 3 layer */
#ifdef SI_SPT
#include "spt.h"           /* sccp layer */
#endif
#include "sit.h"           /* isup layer */
#ifdef SI_FTHA
#include "sht.h"           /* sht header file */
#endif
#include "si.h"            /* isup */
#include "si_err.h"        /* isup error */
#ifdef IW
#include "cm_atm.h"          /* common ATM defines                 */
#include "cm_cc.h"           /* Common Call Control Hash Defs      */
#include "rmt.h"             /* resource manager defines           */
#include "cct.h"             /* Call Control Interface Header      */
#include "liw.h"             /* ISUP PSIF Layer Management Headers */
#include "iw.h"              /* ISUP PSIF Hash Defines             */
#include "iw_err.h"          /* ISUP PSIF Error Defines            */
#include "iw_ptli.h"         /* o/g SIT i/f funcs. hash defs       */
#endif

#ifdef ZI
#include "cm_pftha.h"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.h"      /* common ftha */
#include "cm_psfft.h"     /* common ftha */
#endif
#include "lzi.h"           /* ISUP PSF management */
#include "zi.h"            /* ISUP PSF */
#include "zi_err.h"        /* ISUP PSF error codes */
#endif /* ZI */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* general SS7 layer */
#include "cm_hash.x"       /* hash-list structure */
#include "lsi.x"           /* layer manager */
#include "si_mf.x"         /* message functions */
#include "cm5.x"           /* common timers  */
#include "ci_db.x"         /* isup data base */
#include "snt.x"           /* mtp level 3 layer */
#ifdef SI_SPT
#include "spt.x"           /* sccp layer */
#endif
#include "sit.x"           /* isup layer */
#ifdef SI_FTHA
#include "sht.x"           /* FTHA */
#endif
#include "si.x"            /* isup */


#ifdef IW
#include "cm_atm.x"          /* common ATM defines                  */
#include "cm_cc.x"           /* Common Call Control Typedefs        */
#include "rmt.x"             /* resource manager function decls.    */
#include "cct.x"             /* Call Control Interface              */
#include "liw.x"             /* ISUP PSIF Layer Management typedefs */
#include "iw.x"              /* ISUP PSIF Typedefs                  */
#endif
#ifdef ZI 
#include "cm_pftha.x"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.x"      /* common ftha */
#include "cm_psfft.x"     /* common ftha */
#endif
#include "lzi.x"           /* ISUP PSF management */
#include "zi.x"            /* ISUP PSF */
#endif /* ZI */


/* local defines */

/* local typedefs */
  
/* local externs */

/* forward references */


/* public variable declarations */

  
/*
*     support functions
*/

  
/*
*
*       Fun:   initialize external
*
*       Desc:  Initializes variables used to interface with Upper/Lower
*              Layer  
*
*       Ret:   ROK  - ok
*
*       Notes: None
*
*       File:  ci_ex_ms.c
*
*/

#ifdef ANSI  
PUBLIC S16 siInitExt
(
void
)
#else
PUBLIC S16 siInitExt()
#endif
{
   TRC2(siInitExt)
   RETVALUE(ROK);
} /* end of siInitExt */

   
/*
*
*       Fun:    activate task
*
*       Desc:   Processes received event from Upper/Lower Layer
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   ci_ex_ms.c
*
*/
  
#ifdef ANSI
PUBLIC S16 siActvTskNew
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 siActvTskNew(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   /* si001.220, ADDED: added a return value */
   S16 ret;

   TRC3(siActvTskNew)

   /* si001.220, ADDED: initialize the return value */
   ret = ROK;

#ifdef IW
   /* The value of EVTRMTBNDCFM clashes with the EVT for ZI , therefore
    * if IW is enabled then depending upon the srcEnt (CC/RM) the corresponding
    * activate task function is called prior to switching on the event 
    */
   if ((pst->srcEnt == ENTCC) || (pst->srcEnt == ENTRM))
   {
      /* Call the PSIF activate function */
      iwActvTskNew(pst, mBuf);
      RETVALUE(ROK);
   }
#endif

#ifdef SI_FTHA
   
   if ((pst->srcEnt == ENTSH) && 
       (pst->event == EVTSHTCNTRLREQ))
   {
       cmUnpkMiShtCntrlReq(SiMiShtCntrlReq, pst, mBuf);
       RETVALUE(ROK);
   }

#endif  /* SI_FTHA */
   /* si001.220, MODIFIED: modified the function to have a return value */
   switch(pst->event)
   {

      /* unpacking functions for ISUP primitives coming in from lower layer */
#ifdef SI_SPT
#ifdef LCSILISPT
      case EVTSPTSTAIND:                     /* Status indication */
         siDropMsg(mBuf);
         break;
      case EVTSPTUDATIND:                    /* Unit data indication */
         ret = cmUnpkSptUDatInd(SiLiSptUDatInd, pst, mBuf);
         break;
      case EVTSPTCRDIND:
         siDropMsg(mBuf);
         break;
      case EVTSPTCRDCFM:
         siDropMsg(mBuf);
         break;
      case EVTSPTSTEIND:
         siDropMsg(mBuf);
         break;
      case EVTSPTPCSTEIND:
         siDropMsg(mBuf);
         break;
#ifdef SPT2
      case EVTSPTBNDCFM:
         ret = cmUnpkSptBndCfm(SiLiSptBndCfm, pst, mBuf);
         break;
#endif /* SPT2 */
#endif /* SI_SPT */
#endif /* SI_SPT */
#ifdef LCSILISNT

#ifdef SNT2
      case EVTSNTSTACFM:
         ret = cmUnpkSntStaCfm(SiLiSntStaCfm, pst, mBuf);
         break;

      case EVTSNTBNDCFM:
         ret = cmUnpkSntBndCfm(SiLiSntBndCfm, pst, mBuf);
         break;
#endif /* SNT2 */

      case EVTSNTSTAIND:                     /* Status indication */
         ret = cmUnpkSntStaInd(SiLiSntStaInd, pst, mBuf);
         break;

      case EVTSNTUDATIND:                    /* Unit data indication */
         ret = cmUnpkSntUDatInd(SiLiSntUDatInd, pst, mBuf);
         break;
#endif

#ifdef LCSIUISIT

      /* unpacking functions for ISUP primitives coming in from upper layer */
      case EVTSITBNDREQ:                     /* Bind Request */
         ret = cmUnpkSitBndReq(SiUiSitBndReq, pst, mBuf);
         break;
      case EVTSITCNSTREQ:                    /* Connection Progress Status 
                                                Request */
         ret = cmUnpkSitCnStReq(SiUiSitCnStReq, pst, mBuf);
         break;
      case EVTSITCONREQ:                     /* Connect Request */
         ret = cmUnpkSitConReq(SiUiSitConReq, pst, mBuf);
         break;
      case EVTSITCONRSP:                     /* Connect Response */
         ret = cmUnpkSitConRsp(SiUiSitConRsp, pst, mBuf);
         break;
      case EVTSITDATREQ:                     /* Data request */
         ret = cmUnpkSitDatReq(SiUiSitDatReq, pst, mBuf);
         break;
      case EVTSITFACREQ:                     /* Facility Request */
         ret = cmUnpkSitFacReq(SiUiSitFacReq, pst, mBuf);
         break;
      case EVTSITFACRSP:                     /* Facility Response */
         ret = cmUnpkSitFacRsp(SiUiSitFacRsp, pst, mBuf);
         break;
      case EVTSITRELREQ:                     /* Connection Release Request */
         ret = cmUnpkSitRelReq(SiUiSitRelReq, pst, mBuf);
         break;
      case EVTSITRELRSP:                     /* Connection Release Response */
         ret = cmUnpkSitRelRsp(SiUiSitRelRsp, pst, mBuf);
         break;
      case EVTSITRESMREQ:                    /* Call Resume Request */
         ret = cmUnpkSitResmReq(SiUiSitResmReq, pst, mBuf);
         break;
      case EVTSITSTAREQ:                     /* Call Status Request */
         ret = cmUnpkSitStaReq(SiUiSitStaReq, pst, mBuf);
         break;
      case EVTSITSUSPREQ:                    /* Call Suspend Request */
         ret = cmUnpkSitSuspReq(SiUiSitSuspReq, pst, mBuf);
         break;

      case EVTSITUMSGREQ:                    /* Unrecog Message Request */
         ret = cmUnpkSitUMsgReq(SiUiSitUMsgReq, pst, mBuf);
         break;

      case EVTSITPTCDESTAREQ:
         ret = cmUnpkSitPtCdeStaReq(SiUiSitPtCdeStaReq, pst, mBuf);
         break;
#endif

#ifdef LCSIMILSI
      case EVTLSICNTRLREQ:                  /* Control Request */
         ret = cmUnpkLsiCntrlReq(SiMiLsiCntrlReq, pst, mBuf);
         break;
      case EVTLSISTSREQ:                    /* Statistics Request */
         ret = cmUnpkLsiStsReq(SiMiLsiStsReq, pst, mBuf);
         break;
      case EVTLSISTAREQ:                    /* Status Request */
         ret = cmUnpkLsiStaReq(SiMiLsiStaReq, pst, mBuf);
         break;
      case EVTLSICFGREQ:                    /* Configuration Request */
         ret = cmUnpkLsiCfgReq(SiMiLsiCfgReq, pst, mBuf);
         break;
#endif

#ifdef IW

#ifdef LCIWMILIW
      case LIW_EVTCNTRLREQ:
      case LIW_EVTSTAREQ:
      case LIW_EVTCFGREQ:
         /* to be handled by ISUP PSIF */
         iwActvTskNew(pst, mBuf);
         break;
#endif

#endif /* IW */

#ifdef ZI

      case EVTZIPIDATREQ:
      case EVTZIPIDATCFM:
      case EVTZISISCHREQ:
      case EVTZIMILZICFGREQ:       /* PSF config request */
      case EVTZIMILZISTAREQ:       /* PSF status request */
      case EVTZIMILZICNTRLREQ:     /* PSF control request */
#ifdef TDS_CORE2      
      case EVTZIMILZISTSREQ:       /* PSF statistics request */
#endif      
         ziActvTsk(pst, mBuf);
         break;

#endif /* ZI */

      default:
/* si054.220 : Added Code to update error counter */
#if(SI_LMINT3 || SMSI_LMINT3)
          siUpdErrSts(NULL,LSI_STS_UNXEVT);
#endif
#if (ERRCLASS & ERRCLS_DEBUG)
         SIDBGP(SIDBGMASK_CERR,(siCb.init.prntBuf,
                "event:value %#x not recognised\n", pst->event ));  

         SILOGERROR(ERRCLS_DEBUG, ESI840, (ErrVal) 0, 
                    "siActvTskNew() Failed, invalid event");
         SPutMsg(mBuf);
         break;
#endif
   }
   /* si001.220, ADDED: changes for rollup */
#ifdef SI_RUG
   /* Generate an alarm on receiving an interface primitive with invalid
    * version number on any of hte product interfaces.
    */
   if ((ret == RINVIFVER) && (siCb.init.cfgDone == TRUE))
   {
      siInitUstaDgn(LSI_USTA_DGNVAL_EVENT, (PTR) &pst->event, 
                    LSI_USTA_DGNVAL_VER, (PTR) &pst->intfVer, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                    LCM_EVENT_INV_EVT, LCM_CAUSE_DECODE_ERR, 
                    TRUE);
    }
#endif /* SI_RUG */
   SExitTsk();
   RETVALUE(ROK);
} /* end of siActvTskNew */

  
/********************************************************************30**
  
         End of file:     ci_ex_ms.c@@/main/41 - Wed Mar 14 15:34:28 2001
 
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  bn    1. initial release
             ---  jrl   2. trillium development system checkpoint (dvs)
                           at version: 1.0.0.0

1.2          ---  jrl   1. add cm1.h include, reorder includes
 
1.3          ---  bn    1. corrected unpacking of SiUiSitStaReq.

1.4          ---  jrl   1. text changes

1.5          ---  lc    1. added unpacking of configuration parameters
                           for ANSI variant  
             ---  lc    2. added unpacking of upper interface parameters
                           for ANSI variant  

1.6          ---  jrl   1. change return types to Void
             ---  jrl   2. remove mf.h, mf.x ci_db.h and ci_db.x includes

1.7          ---  jrl   1. text changes
             ---  jrl   2. replaced while(TRUE) with for (;;)

1.8          ---  jrl   1. add ifdef LCSIUISIT around unpacking for
                           tokens

1.9          ---  bn    1. changed unpacking of spt parameters

1.10         ---  bn    1. add ifdef SP around siUnpkLiSptStaInd and
                           siUnpkLiSptUDatInd events

1.11         ---  bn    1. add ifdef SP around siUnpkLiSptStaInd and
                           siUnpkLiSptUDatInd functions

1.12         ---  rk    1. miscellaneous changes

1.13         ---  bn    1. add siUnpkMiLsiCntrlReq

1.14         ---  rk    1. changed siActvTsk to use EVTSTAXXREQ for isup 
                           status request to remove conflict with layer 
                           management 
             ---  rk    2. fixed typo in siUnpkMSICfgReq, case STISAP
             ---  rk    3. fixed siUnpkMiLSICntrlReq to define cntrl, not *cntrl.
             ---  rk    4. fixed siUnpkMiLSIStsReq to unpack action (was packed).
             ---  rk    5. change siUnpk(U32,U16,S16,U8) to CMCHKUNPKLOG(SUnpk, ...)

1.15         ---  bn    1. add support for ansi 92.
             ---  bn    2. change return( to RETVALUE(
             ---  bn    3. change LCLM to LCSILM

1.16         ---  bn    1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.17         ---  bn    1. add unpacking of SiOpFwdCalIndA for ansi 88.

1.18         ---  bn    1. add ifdef SP around include spt.x and spt.h
             ---  bn    2. changed to new interfaces.

1.19         ---  bn    1. corrected unpacking of Isup SAP configuration req.

1.20         ---  bn    1. change defines

1.21         ---  bn    1. corrected unpacking of Isup SAP configuration req.
             ---  fmg   2. changed LCSILM to LCSMSIMILSI
             ---  fmg   3. include cm_gen.[hx]
             ---  bn    4. changed status to S16 from U8 in SiLiSntStaInd.
             ---  bn    5. added unpacking of clli in general configuration.

1.22         ---  bn    1. added functionality for continuity recheck 
                           procedures
             ---  bn    2. added support for Q.767 and Singapore Telecom.

1.23         ---  bn    1. text changes

1.24         ---  bn    1. moved prototypes of siUnpkRangStat, and 
                           siUnpkCirGrpSupMTypInd to si.x, changed them to
                           PUBLIC.

1.25         ---  bn    1. text changes

1.26         ---  bn    1. corrections for Italian Q767.

1.27         ---  bn    1. added unpacking of backward vad to unpacking of 
                           siConEvnt structure for Italian Q767.
             ---  bn    2. changed unpacking of ciruit from U16 to U32.
             ---  bn    3. removed #include cm2.x

1.28         ---  bn    1. changed ifdef SP to ifdef SI_SPT.
             ---  bn    2. corrected gcc compiler warnings.

1.29         ---  kss   1. Added proper LCSIMILSI #ifdef construct in
                           siActvTskNew
             ---  bn    2. changed unpacking of siGen.nmbCir to U32.

1.30         ---  bn    1. necessary recovery actions placed in error scenarios
             ---  bn    2. misceleneous corrections.
             ---  bn    3. made all unpacking calls macros.

1.31         ---  pc    1. added support for ETSI SI

1.32         ---  bn    1. text change

1.33         ---  dm    1. removed repeated including of cm_gen.[hx]
             ---  dm    1. added support for GT_FTZ SI.
             ---  dm    2. moved unpacking funcs. for message elements 
                           and events in sit.c
             ---  dm    3. added tCCRt unpacking for ANSI.
             ---  dm    4. added segmentation
             ---  dm    5. added event type in the FacReq and FacRsp
             ---  dm    6. added include cm_ss7.x
             ---  dm    7. removed siActvTsk and removed SEL_LC_OLD case
                           in siUnpkSiUiSitBndReq

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.34         ---      ao   1. Moved OPC from general config to upper SAP
                              config
             ---      ao   2. corrected gcc compile warnings.

1.35         ---      ao   1. PAUSE/RESUME changes.  
             ---      rh   2. new PAUSE/RESUME changes
             ---      rh   2. support for unrecognised parameters unpacking
1.36         ---      ao   1. added unpacking of relLocation and passOnFlag
                              for upper SAP config.
             ---      ao   2. corrected unpacking of clli, outTrkGrpN,
                              and route address.
             ---      rs   3. Added STDELROUT in Cfg unpacking function.

             ---      rs   4. Adding unpacking info for dpc control block
                              configuration/control block. 
             ---           5. Added unpacking of unrecognized primitive. 
1.37         ---      ym   1. Unpacking function siUnPkMiLsiCntrlReq is 
                              updated to handle new fields in the 
                              control message structure for circuit grp
                              control request.
             ---      ym   1. Events for PSF are added in siActvTsk.
1.38         ---      ym   1. File header is updated to the new one. 
                           2. Error codes are updated.
1.38+        ---      tz   1. EVTCCTSTAREQ is handled for ISUP-PSIF.
                              Note that this change is under IW_COT_NEW
                              compile option.  
1.39         ---      dvs  1. miscellaneous changes
1.40         ---      ym   1. The value of EVTRMTBNDCFM clashes with the 
                              EVT for ZI , therefore if IW is enabled then 
                              depending upon the srcEnt (CC/RM) the 
                              corresponding activate task function is 
                              called prior to switching on the event
/main/41     ---      sk   1. Addition of unpacking system agent
                              primitive (tcr18.02)
                      hy   1. Removed include of lrm.h
           si001.220  hy   1. Changes for rollup in function siActvTskNew
	  si054.220   vp     1 Added Code to update error counter
*********************************************************************91*/

