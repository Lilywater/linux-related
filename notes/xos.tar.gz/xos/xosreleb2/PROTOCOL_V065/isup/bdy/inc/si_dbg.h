#ifndef _SI_DBG_H_
#define _SI_DBG_H_


EXTERN Void siSetDbgMaskFromShell(U32 dbgMask);
  

#endif

