/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

    Name:   ISUP Message Database.

    Type:   C include file

    Desc:   Defines required by the message functions

    File:   ci_db.h

    Sid:      ci_db.h@@/main/23 - Wed Mar 14 15:32:10 2001

    Prg:    na

*********************************************************************21*/

#ifndef __CIDBH__
#define __CIDBH__


/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.             description
*     --------     ----------------------------------------------
*     1000029      SS7 - ISUP
*
*/

/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.             description
*     --------     ----------------------------------------------
*     1000029      SS7 - ISUP
*
*/


/*
 *
 * All comments enclosed in brackets "()" are references to page numbers in: 
 *
 * CCITT Blue Book
 * ---------------
 * Specifications of Signalling System No. 7
 * Recommendations Q.721-Q.766
 * ISBN 92-61-03521-3
 *
 */


/* defines */

/* si029.220: Modification - increase max number of switches due to the
 * addition of Indian variant */

/* si034.220: Modification - increase max number of switches due to the
 * addition of China variant */
#define SI_MAX_SWITCH     18      /* maximum switches */


/* message tags (pg. 213 ) */

#define M_ADDCOMP         0x06   /* Address complete */
#define M_ANSWER          0x09   /* Answer */
#define M_BLOCK           0x13   /* Blocking */
#define M_BLOCKACK        0x15   /* Blocking acknowledgement  */
#define M_CALLMODCOMP     0x1d   /* Call modification completed */
#define M_CALLMODREQ      0x1c   /* Call modification request */
#define M_CALLMODREJ      0x1e   /* Call modification reject */
#define M_CALLPROG        0x2c   /* Call progress */
#define M_CIRGRPBLK       0x18   /* Circuit group blocking */
#define M_CIRGRPBLKACK    0x1a   /* Circuit group blocking acknowledgement */
#define M_CIRGRPQRY       0x2a   /* Circuit group query */
#define M_CIRGRPQRYRES    0x2b   /* Circuit group query response */
#define M_CIRGRPRES       0x17   /* Circuit group reset */
#define M_CIRGRPRESACK    0x29   /* Circuit group reset acknowledgement */
#define M_CIRGRPUBLK      0x19   /* Circuit group unblocking */
#define M_CIRGRPUBLKACK   0x1b   /* Circuit group unblocking acknowledgement */
#define M_CONFUSION       0x2f   /* Confusion */
#define M_CONNCT          0x07   /* Connect */
#define M_CONTINUITY      0x05   /* Continuity */
#define M_CONTCHKREQ      0x11   /* Continuity Check Request */
#define M_DELREL          0x27   /* Delayed Release */
#define M_FACACC          0x20   /* Facility Accepted */
#define M_FACREJ          0x21   /* Facility Rejected */
#define M_FACREQ          0x1f   /* Facility Request */
#define M_FWDTFER         0x08   /* Forward Transfer */
#define M_INFORMTN        0x04   /* Information */
#define M_INFOREQ         0x03   /* Information request */
#define M_INIADDR         0x01   /* Intial Address */
#define M_LOOPBCKACK      0x24   /* Loop back acknowledgement */
#define M_OVERLOAD        0x30   /* Overload */
#define M_PASSALNG        0x28   /* Pass-along */
#define M_RELSE           0x0c   /* Release */
#define M_RELCOMP         0x10   /* Release complete */
#define M_RESCIR          0x12   /* Reset circuit */
#define M_RESUME          0x0e   /* Resume */
#define M_SUBADDR         0x02   /* Subsequent address */
#define M_SUSPND          0x0d   /* Suspend */
#define M_UNBLK           0x14   /* Unblocking */
#define M_UNBLKACK        0x16   /* Unblocking acknowledgement */
#define M_UNEQUIPCIC      0x2e   /* Unequiped Cicuit Identification Code */
#define M_USR2USR         0x2d   /* User to user */

#define M_CUGSELVALRSP    0x26   /* Clsd. usr. grp. sel. val. rsp. */
#define M_CUGSELVALREQ    0x25   /* Clsd. usr. grp. sel. val. req. */
#define M_CIRVALRSP       0xeb   /* Circuit validation response */
#define M_CIRVALTEST      0xec   /* Circuit validation test */
#define M_EXIT            0xed   /* Exit */
#define M_FACINF          0x23   /* Facility information */
#define M_FACDEACT        0x22   /* Facility deactivation */
#define M_CIRRESERVE      0xea   /* Circuit Reservation */
#define M_CIRRESACK       0xe9   /* Circuit Reservation Acknowledgement */
#define M_FACIL           0x33   /* Facility  Message */
#define M_IDENTREQ        0x36   /* Identification Request Message */
#define M_IDENTRSP        0x37   /* Identification Response Message */
#define M_NETRESMGT       0x32   /* Network Resource Management Message */
#define M_USRPARTA        0x35   /* User Part Available Message */
#define M_USRPARTT        0x34   /* User Part Test Message */
#define M_MALCLLPRNT      0xff   /* Malicious call print */
#define M_CHARGE          0x31   /* Charge Info */
#define M_COM             0xe0   /* Call Offering Message */
#define M_TRFFCHGE        0xfe   /* Tariff Change */
#define M_CHARGEACK       0xfd   /* Charge Acknowledge */

#define M_LOOPPRVNT       0x40   /* Loop Prevention */
/* ITU 2000 message */
#define M_SUBDIRNUM       0x43   /* Subsequent directory number*/

#define M_GTCHRG          0xfd   /* charging */
#define M_GTCHRGEXT       0xfa   /* charging extended */
#define M_GTCHRGEXTACK    0xfb   /* charging extended acknowledge */
#define M_GTHANGUP        0xfc   /* hanging up of A-tln */
#define M_GTFACINF        0x23   /* Facility information */
#define M_GTUSRINF        0x24   /* user information */
#define M_GTNATMSG        0xff   /* National message */

#define M_SEGMMSG         0x38   /* segmentation */

#define M_CALLCLEAR       0xfc   /* Call Line Clear */
#define M_RINGSEND        0xff   /* Ringing Send Message */
#define M_CHGNTT          0xfe   /* charging message in NTT */

#define M_APPTRAN         0x41   /* Application transport message */
#define M_PRERELINF       0x42   /* Pre-release information message */
/* si034.220: Addition - New message tags for China variant */
#define M_CLGPTYCLR       0xfc   /* Calling Party Clear Message */
#define M_METPULSE        0xfd   /* Metering Pulse Message */
#define M_OPERATOR        0xfe   /* Operator Message */

/* message indexes */

#define MI_ADDCOMP        0x00   /* Address complete */
#define MI_ANSWER         0x01   /* Answer */
#define MI_CALLMODCOMP    0x02   /* Call modification completed */
#define MI_CALLMODREQ     0x03   /* Call modification request */
#define MI_CALLMODREJ     0x04   /* Call modification reject */
#define MI_CALLPROG       0x05   /* Call progress */
#define MI_CONFUSION      0x06   /* Confusion */
#define MI_CONNCT         0x07   /* Connect */
#define MI_CONTINUITY     0x08   /* Continuity */
#define MI_CONTCHKREQ     0x09   /* Continuity Check Request */
#define MI_FACACC         0x0a   /* Facility Accepted */
#define MI_FACREJ         0x0b   /* Facility Rejected */
#define MI_FACREQ         0x0c   /* Facility Request */
#define MI_FWDTFER        0x0d   /* Forward Transfer */
#define MI_INFORMTN       0x0e   /* Information */
#define MI_INFOREQ        0x0f   /* Information request */
#define MI_INIADDR        0x10   /* Intial Address */
#define MI_RELSE          0x11   /* Release */
#define MI_RELCOMP        0x12   /* Release complete */
#define MI_RESUME         0x13   /* Resume */
#define MI_SUBADDR        0x14   /* Subsequent address */
#define MI_SUSPND         0x15   /* Suspend */
#define MI_USR2USR        0x16   /* User to user */
#define MI_CIRRESERVE     0x17   /* Circuit Reservation */
#define MI_CIRRESACK      0x18   /* Circuit Reservation Acknowledgement */

#define MI_BLOCK          0x19   /* Blocking */
#define MI_BLOCKACK       0x1a   /* Blocking acknowledgement  */
#define MI_UNBLK          0x1b   /* Unblocking */
#define MI_UNBLKACK       0x1c   /* Unblocking acknowledgement */
#define MI_RESCIR         0x1d   /* Reset circuit */

#define MI_OVERLOAD       0x1e   /* Overload */
#define MI_PASSALNG       0x1f   /* Pass-along */
#define MI_CIRGRPUBLK     0x20   /* Circuit group unblocking */
#define MI_UNEQUIPCIC     0x21   /* Unequiped Cicuit Identification Code */

#define MI_CIRGRPQRY      0x22   /* Circuit group query */
#define MI_CIRGRPQRYRES   0x23   /* Circuit group query response */
#define MI_CIRGRPBLK      0x24   /* Circuit group blocking */
#define MI_CIRGRPBLKACK   0x25   /* Circuit group blocking acknowledgement */
#define MI_LOOPBCKACK     0x26   /* Loop back acknowledgement */
#define MI_CIRGRPUBLKACK  0x27   /* Circuit group unblocking acknowledgement */
#define MI_CIRGRPRES      0x28   /* Circuit group reset */
#define MI_CIRGRPRESACK   0x29   /* Circuit group reset acknowledgement */

#define MI_FACIL          0x2a   /* Facility  Message */
#define MI_IDENTREQ       0x2b   /* Identification Request Message */
#define MI_IDENTRSP       0x2c   /* Identification Response Message */
#define MI_NETRESMGT      0x2d   /* Network Resource Management Message */
#define MI_USRPARTA       0x2e   /* User Part Available Message user */
#define MI_USRPARTT       0x2f   /* User Part Test Message */

#define MI_CUGSELVALREQ   0x30   /* Clsd. usr. grp. sel. val. req. */
#define MI_CUGSELVALRSP   0x31   /* Clsd. usr. grp. sel. val. rsp. */
#define MI_CIRVALRSP      0x32   /* Circuit validation response */
#define MI_CIRVALTEST     0x33   /* Circuit validation test */
#define MI_EXIT           0x34   /* Exit */
#define MI_FACINF         0x35   /* Facility information */
#define MI_FACDEACT       0x36   /* Facility deactivation */

#define MI_MALCLLPRNT     0x37   /* Malicious call print */
#define MI_CHARGE         0x38   /* Charge Info */
#define MI_TRFFCHGE       0x39   /* Tariff Change */
#define MI_CHARGEACK      0x3a   /* Charge Acknowledge */
#define MI_COM            0x3b   /* Call Offering Message */
#define MI_LOOPPRVNT      0x3c   /* Loop Prevention Message */

#define MI_GTCHRG         0x3d   /* charging */
#define MI_GTCHRGEXT      0x3e   /* charging extended */
#define MI_GTCHRGEXTACK   0x3f   /* charging extended acknowledge */
#define MI_GTHANGUP       0x40   /* hanging up of A-tln */
#define MI_GTFACINF       0x41   /* Facility information */
#define MI_GTUSRINF       0x42   /* user information */
#define MI_GTNATMSG       0x43   /* National message */

#define MI_SEGMMSG        0x44   /* segmentation */

#define MI_CALLCLEAR      0x45   /* Call Line Clear */
#define MI_RINGSEND       0x46   /* Ringing Send Message */
#define MI_CHGNTT         0x47   /* Charging message for NTT */

#define MI_APPTRAN        0x48  /* Application transport message */
#define MI_PRERELINF      0x49  /* Pre-release information message */

/* si034.220: Addition - New messages for China variant */
#define MI_CLGPTYCLR       0x4a  /* calling party clear message */
#define MI_METPULSE        0x4b  /* Metering pulse message */
#define MI_OPERATOR        0x4c  /* operator message */
/* ITU 2000 message */
#define MI_SUBDIRNUM       0x4d   /* Subsequent directory number*/

/* si034.220: Modification - value changes due to introduction
   of new messages
*/   
#define NMB_IMSG          0x4e   /* number messages */

#define NMB_ICCMSG        0x19   /* number messages for CC state machine */

#define IEI_CONREQ        0x19   /* connect request */
#define IEI_CONRSP        0x1a   /* connect response */
#define IEI_CNSTREQ       0x1b   /* connect status request */
#define IEI_RELREQ        0x1c   /* release request */
#define IEI_RELRSP        0x1d   /* release response */
#define IEI_INFREQ        0x1e   /* information request */
#define IEI_SUSPREQ       0x1f   /* suspend request */
#define IEI_RESREQ        0x20   /* resume request */
#define IEI_FACREQ        0x21   /* facility request */
#define IEI_FACRSP        0x22   /* facility response */
#define IEI_STAREQ        0x23   /* status request */
#define IEI_CIRRES        0x24   /* circuit reset */
#define IEI_BLKREQ        0x25   /* block request */
#define IEI_FTZREQ        0x26   /* ftz utilities request */

#define NMB_IPRIM         14     /* number of primitives */

#define MI_UNKNOWN        0xff   /* message type unknown */

#define NMB_ICON_EVNT     (NMB_ICCMSG + NMB_IPRIM + 1)  /* number of connect events */

/* Special Information Element IDs (not listed) */

/* si029.220: Modification - changed message header element to 0xffff
 * to allow 0xff to be used by charge band parameter */
#define ME_HEDR           0xffff /* Mask for Message Header Element */
#define ME_PASSALNG       0xef   /* Pass Along */

/* Information Element ID tags (pg 215) */

#define ME_ACCTPORT       0x03   /* Access transport */
#define ME_AUTOCONGLVL    0x27   /* Automatic congestion level */
#define ME_BACKCALLIND    0x11   /* Backward call indicators */
#define ME_CALLMODIND     0x17   /* Call modification indicators */
#define ME_CALREF         0x01   /* Call reference */
#define ME_CALDPARTNUM    0x04   /* Called party's number */
#define ME_CALGPARTNUM    0x0a   /* Calling party number */
#define ME_CALGPARTCAT    0x09   /* Calling party category */
#define ME_CAUSIND        0x12   /* Cause indicator */
#define ME_CGRPSUPMTYPIND 0x15   /* Circuit grp supervision msg. type */
#define ME_CIRCSTEIND     0x26   /* Cicuit state indicator */   
#define ME_CLSDUGRPINTCDE 0x1a   /* Closed user group interlock code */
#define ME_CONNUMB        0x21   /* Connected number */
#define ME_CONREQ         0x0d   /* Connection request */
#define ME_CONTIND        0x10   /* Continuity indicators */
#define ME_ENDOP          0x00   /* End of optional parameters */
#define ME_EVNTINFO       0x24   /* Event inforamtion */
#define ME_FACIND         0x18   /* Facility indicator */
#define ME_FWDCALLIND     0x07   /* Forward call indicator */
#define ME_INFOIND        0x0f   /* Information indicators */
#define ME_INFOREQIND     0x0e   /* Information request indicators */
#define ME_NATCONIND      0x06   /* Nature of connection indicators */
#define ME_OPBACKCALLIND  0x29   /* Optional backward call indicator */
#define ME_OPFWDCALLIND   0x08   /* Optional foreward call indicator */
#define ME_ORIGCALDNUM    0x28   /* Original Called Number */
#define ME_RANGSTAT       0x16   /* Range and Status */
#define ME_REDIRGNUM      0x0b   /* Redirecting number */
#define ME_REDIRINFO      0x13   /* Redirection information */
#define ME_REDIRNUM       0x0c   /* Redirection number */
#define ME_SIGPTCDE       0x1e   /* Signal point code */
#define ME_SUBSEQNUM      0x05   /* Subsequent number */
#define ME_SUSPRESIND     0x22   /* Suspend/Resume indicators */
#define ME_TRANNETSEL     0x23   /* Transit network selection */
#define ME_TRANSMEDREQ    0x02   /* Transmission medium requirement */
#define ME_USRSERVINFO    0x1d   /* User service information */
#define ME_USR2USRIND     0x2a   /* User to User indicators */
#define ME_USR2USRINFO    0x20   /* User to User information */

#define ME_ACCDELINFO     0x2e   /* access delivery information */
#define ME_CLLDIVERS      0x36   /* call Diversion information */
#define ME_CLLHISTORY     0x2d   /* call history information */
#define ME_ECHOCNTRL      0x37   /* echo control */
#define ME_NOTIFINDC      0x2c   /* generic notification */
#define ME_GENNMB         0xc0   /* generic number */
#define ME_MCIDREQ        0x3b   /* MCID request indicators */
#define ME_MCIDRSP        0x3c   /* MCID response indicators */
#define ME_MSGCOMP        0x38   /* message compatibility info */
#define ME_MLPPPREC       0x3a   /* MLPP precedence */
#define ME_NETSPFAC       0x2f   /* network specific facility */
#define ME_ORISCCDE       0x2b   /* originating ISC point code */
#define ME_PARCOMPIN      0x39   /* parameter compatibility info */
#define ME_PROPDLYCTR     0x31   /* propagation delay counter */
#define ME_REDIRRESTR     0x40   /* redirection restriction */
#define ME_REMOTOPER      0x32   /* remote operations */
#define ME_SERVACT        0x33   /* service activation */
#define ME_TRANSMEDPRM    0x3e   /* Transmission media prime */
#define ME_TRANSMEDUSD    0x35   /* Transmission media used */
#define ME_USRSERVINFOPR  0x30   /* User service information prime */
#define ME_LOCNMB         0x3f   /* location number */

/* Information Element ID tags - ANSI or ANSI 92 specific */

#define ME_CHARGENUM      0xeb   /* Charge number */
#define ME_CGRPCHARIND    0xe5   /* Circuit group characteristic ind. */
#define ME_CIRIDNAME      0xe8   /* Circuit ID name */
#define ME_CIRVALRSPIND   0xe6   /* Circuit validation response ind. */
#define ME_CLLI           0xe9   /* Common language location ind. */
#define ME_ORGLINEINF     0xea   /* Original line information */
#define ME_OUTGTRKGRPNUM  0xe7   /* Outgoing trunk group number */

/* Information Element ID tags - ANSI specific */

#define ME_CLSDUGRPCHKRSP 0x1c   /* Closed user group check response */
#define ME_FACINFIND      0x19   /* Facility information indicator */
#define ME_INDEX          0x1b   /* Index */

/* Information Element ID tags - ANSI 92 specific */
#define ME_BUSINESSGRP    0xc6   /* Business group */
#define ME_CARRIERID      0xc5   /* Carrier Idenification */
#define ME_CARSELINF      0xee   /* Carrier Selection Information */
#define ME_EGRESS         0xc3   /* Egress Service */
#define ME_GENADDR        0xc0   /* Generic Adress */
#define ME_GENDIGITS      0xc1   /* Generic Digits */
#define ME_JURISINF       0xc4   /* Jurisdiction Information */
#define ME_NETTRANS       0xef   /* Network Transport */
#define ME_NOTIFIND       0xe1   /* Notification Indicator */
#define ME_SERVACTA       0xe2   /* Service Activation */
#define ME_SPECPROCREQ    0xed   /* Special Processing Request */
#define ME_TRANSREQ       0xe3   /* Transaction Request */
#define ME_SERVCODE       0xec   /* service code indicator */

/* Information Element ID tags - BELLCORE specific */

#define ME_HOPCOUNTER     0x3d   /* Hop counter */

#define ME_REDIRCAP       0x4e   /* Redirect Capability */
#define ME_REDIRCNTR      0x77   /* Redirect Counter */
#define ME_GENNAME        0xc7   /* Generic Name */

/* Information Element ID tags - SINGTEL specific */

#define ME_CHRGEINFO      0xff   /* Call charge info */
#define ME_CHRGERTEINFO   0xfe   /* Charge rate info */
#define ME_TRNKOFF        0xfd   /* Trunk offering info */

/* Information Element ID tags - Q767 Italy specific */

#define ME_FWDVAD         0xfd   /* Forward vad indicator */
#define ME_BACKVAD        0xfc   /* Backward vad indicator */

/* Information Element ID tags - ETSI specific */

#define ME_CALLTRNSFRNMB  0x45   /* Call Transfer Number */
#define ME_CALLTRNSFRREF  0x43   /* Call Transfer Reference */
#define ME_CCBSPARAM      0x4b   /* CCBS Parameter */
#define ME_LOOPPRVNTIND   0x44   /* Loop Prevention Indicator */
#define ME_FREEPHIND      0x41   /* Free Phone Indicator */
#define ME_USRTSRVINFO    0x34   /* User Teleservice Information */

/* Information Element ID tags - GT_FTZ specific */

#define ME_GTNPSSCPRICLS  0xfe   /* Nat. Par.: subscriber priority class */
#define ME_GTNATPARFF     0xff   /* Nat. Par.: FF (multitype) */
#define ME_GTNPCHRGINF    0xfd   /* Nat. Par.: charging information */
#define ME_GTNPSSP        0xfc   /* Nat. Par.: service switching point */
#define ME_GTNPINCDPNO    0xfb   /* Nat. Par.: intelligent network CdPNo */
#define ME_GTNPSPV        0xfa   /* Nat. Par.: semipermanent connection */
#define ME_GTNPEXCHTRKID  0xf9   /* Nat. Par.: exchange and trung ID */
#define ME_GTNPTLN2TLNSG  0xf7   /* Nat. Par.: Tln to Tln signalling */
#define ME_GTNPCHGPTYID   0xf6   /* Nat. Par.: charged party identification */
#define ME_GTFACINDINFOR  0x19   /* Facility Indicator Information */
#define ME_GTNPUKK        0xf5   /* Nat. Par.: originating party information */

/* Information Element ID tags - Russian specific */

#define ME_BILLZONEINFO   0xff   /* Billing Zone Number */

/* Information Element code for NTT variant */
#define ME_CHRGINFOTYPE    0xfa  /* Charging information type */
#define ME_CHRGINFORMATION 0xfb  /* Charge information */ 
#define ME_MSGAREAINFO       0xfd   /* Message Area Information */
#define ME_CHRGINFODELAY     0xf2   /* Charge information delay */
#define ME_CARRIERINFOTRANS  0xf1   /* Carrier Info transfer */
#define ME_SUBSNUMBER        0xf9   /* Subscriber Number */
#define ME_REASPROHIBCLLNGNO 0xf5   /* Reas for prohibng callng number */
#define ME_SUPPLUSERTYPE     0xf3   /* Supplementary user type */
#define ME_NWFUNCTYPE        0xfe   /* N/w function type */

/* Information Element code for ANSI 95 variant */
#define ME_CIRASGNMAP        0x25   /* Circuit Assignment Map */
#define ME_OPTRSERVICEINFO   0xc2   /* Operator Service Info */

/* Information Element code for ITU 97 variant */
#define ME_CONFTRTIND        0x72   /* conference treatment indicators */
#define ME_UIDACTIONIND      0x74   /* UID action indicator */
#define ME_DISPLAYINFO       0x73   /* display information */
#define ME_BACKWARDGVNS      0x4d   /* backward GVNS */
#define ME_FORWARDGVNS       0x4c   /* forward GVNS */
#define ME_NETMGMTCONTROLS   0x5b   /* n/w management controls */
#define ME_CORRELATIONID     0x65   /* correlation Id */
#define ME_CALLDIVTRTIND     0x6e   /* call diversion trt ind */
#define ME_CALLINNMB         0x6f   /* call IN number */
#define ME_CALLOFFERTRTIND   0x70   /* call offering trt ind */
#define ME_SCFID             0x66   /* SCF Id */
#define ME_UIDCAPIND         0x75   /* UID capability indicator */
#define ME_COLLCALLREQ       0x79   /* collect call request */
#define ME_CCSS              0x4b   /* CCSS */

/* Information Element code for ETSIV3 variant */
#define ME_APPTRAN           0x78   /* application transport param */

/* si029.220: Addition - added charge band for India variant */
#define ME_CHRGEBND          0xff   /* charge band */

/* si034.220: Addition - added charge information for China variant */
#define ME_CHRGINFO          0xfe   /* charge information */

/* si040.220 ITU2000 parameters */

#define ME_CADDIRNMB          0x7d   /* Called Directory Number */
#define ME_CALGGEOLOC         0x0a   /* Calling geodetic location */
#define ME_CCNRPOSIND         0x7a   /* CCNR Possible indicator */
#define ME_HTRINFO            0x82   /* HTR Information  */
#define ME_NETROUTNUM         0x84   /* Network Routing Number  */
#define ME_NUMPOTRFWDINDO     0x8d   /* Number Portability Forward Info */
#define ME_ORIGCALDINNUM      0x78   /* Original Called IN  Number */
#define ME_PIVOTCAP           0x7b   /* Pivot Capability */
#define ME_PIVOTCNTR          0x87   /* Pivot Counter */
#define ME_PIVOTRTGBKINFO     0x89   /* Pivot Routing Backward Info */
#define ME_PIVOTRTGFWINFO     0x88   /* Pivot Routing Forward Info */
#define ME_PIVOTRTGIND        0x7c   /* Pivot Routing Indicators */
#define ME_PIVOTSTAT          0x86   /* Pivot Status */
#define ME_QONRELCAP          0x85   /* Query on Release Capability */
#define ME_REDIRBKINFO        0x8c   /* Redirect Backward Info */
#define ME_REDIRFWINFO        0x8b   /* Redirect Forward Info */
#define ME_REDIRSTAT          0x8a   /* Redirect Status */

/* Special Information Element indecies  (not listed) */

#define MEI_HEDR          0x00   /* Mask for Message Header Element */
#define MEI_OPPTR         0x01   /* Pointer to optional parameters */
#define MEI_PASSALNG      0x02   /* Pointer to optional parameters */

/* Information Element ID indecies  */

#define MEI_ACCTPORT      0x03   /* Access transport */
#define MEI_AUTOCONGLVL   0x04   /* Automatic congestion level */
#define MEI_BACKCALLIND   0x05   /* Backward call indicators */
#define MEI_CALLMODIND    0x06   /* Call modification indicators */
#define MEI_CALREF        0x07   /* Call reference */
#define MEI_CALDPARTNUM   0x08   /* Called party's number */
#define MEI_CALGPARTNUM   0x09   /* Calling party number */
#define MEI_CALGPARTCAT   0x0a   /* Calling party category */
#define MEI_CAUSIND       0x0b   /* Cause indicator */
#define MEI_CGRPSUPMTYPIND 0x0c  /* Circuit group supervision msg type */
#define MEI_CIRCSTEIND    0x0d   /* Cicuit state indicator */   
#define MEI_CLSDUGRPINTCDE 0x0e  /* Closed user group interlock code */
#define MEI_CONNUMB       0x0f   /* Connected number */
#define MEI_CONREQ        0x10   /* Connection request */
#define MEI_CONTIND       0x11   /* Continuity indicators */
#define MEI_ENDOP         0x12   /* End of optional parameters */
#define MEI_EVNTINFO      0x13   /* Event inforamtion */
#define MEI_FACIND        0x14   /* Facility indicator */
#define MEI_FWDCALLIND    0x15   /* Forward call indicator */
#define MEI_INFOIND       0x16   /* Information indicators */
#define MEI_INFOREQIND    0x17   /* Information request indicators */
#define MEI_NATCONIND     0x18   /* Nature of connection indicators */
#define MEI_OPBACKCALLIND 0x19   /* Optional backward call indicator */
#define MEI_OPFWDCALLIND  0x1a   /* Optional foreward call indicator */
#define MEI_ORIGCALDNUM   0x1b   /* Original Called Number */
#define MEI_RANGSTAT      0x1c   /* Range and Status */
#define MEI_REDIRGNUM     0x1d   /* Redirecting number */
#define MEI_REDIRINFO     0x1e   /* Redirection information */
#define MEI_REDIRNUM      0x1f   /* Redirection number */
#define MEI_SIGPTCDE      0x20   /* Signal point code */
#define MEI_SUBSEQNUM     0x21   /* Subsequent number */
#define MEI_SUSPRESIND    0x22   /* Suspend/Resume indicators */
#define MEI_TRANNETSEL    0x23   /* Transit network selection */
#define MEI_TRANSMEDREQ   0x24   /* Transmission medium reuirement */
#define MEI_USRSERVINFO   0x25   /* User service information */
#define MEI_USR2USRIND    0x26   /* User to User indicators */
#define MEI_USR2USRINFO   0x27   /* User to User information */

#define MEI_ACCDELINFO    0x28   /* access delivery information */
#define MEI_CLLDIVERS     0x29   /* call Diversion information */
#define MEI_CLLHISTORY    0x2a   /* call history information */
#define MEI_ECHOCNTRL     0x2b   /* echo control */
#define MEI_NOTIFINDC     0x2c   /* generic nnotification */
#define MEI_GENNMB        0x2d   /* generic number */
#define MEI_MCIDREQ       0x2e   /* MCID request indicators */
#define MEI_MCIDRSP       0x2f   /* MCID response indicators */
#define MEI_MSGCOMP       0x30   /* message compatibility info */
#define MEI_MLPPPREC      0x31   /* MLPP precedence */
#define MEI_NETSPFAC      0x32   /* network specific facility */
#define MEI_ORISCCDE      0x33   /* originating ISC point code */
#define MEI_PARCOMPIN     0x34   /* parameter compatibility info */
#define MEI_PROPDLYCTR    0x35   /* propagation delay counter */
#define MEI_REDIRRESTR    0x36   /* redirection restriction */
#define MEI_REMOTOPER     0x37   /* remote operations */
#define MEI_TRANSMEDPRM   0x38   /* Transmission media prime */
#define MEI_TRANSMEDUSD   0x39   /* Transmission media used */
#define MEI_USRSERVINFOPR 0x3a   /* User service information prime */

#define MEI_CHARGENUM     0x3b  /* Charge number */
#define MEI_CGRPCHARIND   0x3c  /* Circuit group characteristic ind. */
#define MEI_CIRIDNAME     0x3d  /* Circuit ID name */
#define MEI_CIRVALRSPIND  0x3e  /* Circuit validation response ind. */
#define MEI_CLSDUGRPCHKRSP 0x3f  /* Closed user group check response */
#define MEI_CLLI           0x40  /* Common language location ind. */
#define MEI_FACINFIND      0x41  /* Facility information indicator */
#define MEI_INDEX          0x42  /* Index */
#define MEI_ORGLINEINF     0x43  /* Original line information */
#define MEI_OUTGTRKGRPNUM  0x44  /* Outgoing trunk group number */

/* Information Element ID indecies - ANSI 92 specific */

#define MEI_BUSINESSGRP    0x45  /* Business group */
#define MEI_CARRIERID      0x46  /* Carrier Idenification */
#define MEI_CARSELINF      0x47  /* Carrier Selection Information */
#define MEI_EGRESS         0x48  /* Egress Service */
#define MEI_GENADDR        0x49  /* Generic Adress */
#define MEI_GENDIGITS      0x4a  /* Generic Digits */
#define MEI_JURISINF       0x4b  /* Jurisdiction Information */
#define MEI_NETTRANS       0x4c  /* Network Transport */
#define MEI_NOTIFIND       0x4d  /* Notification Indicator */
#define MEI_SERVACTA       0x4e  /* Service Activation */
#define MEI_SPECPROCREQ    0x4f  /* Special Processing Request */
#define MEI_TRANSREQ       0x50  /* Transaction Request */
#define MEI_SERVCODE       0x68   /* service code indicator */

/* Information Element ID tags - SINGTEL specific */

#define MEI_CHRGEINFO      0x51   /* Call charge info */
#define MEI_CHRGERTEINFO   0x52   /* Charge rate info */
#define MEI_TRNKOFF        0x53   /* Trunk offering info */

/* Information Element ID tags - Q767 Italy specific */

#define MEI_FWDVAD         0x54   /* Forward vad indicator */
#define MEI_BACKVAD        0x55   /* Backward vad indicator */

/* Information Element ID tags - ETSI specific */

#define MEI_CALLTRNSFRNMB  0x56   /* Call Transfer Number */
#define MEI_CALLTRNSFRREF  0x57   /* Call Transfer Reference */
#define MEI_CCBSPARAM      0x58   /* CCBS Parameter */
#define MEI_LOOPPRVNTIND   0x59   /* Loop Prevention Indicator */
#define MEI_FREEPHIND      0x5a   /* Free Phone Indicator */
#define MEI_USRTSRVINFO    0x5b   /* User Teleservice Information */

/* ITU Element ID tag */

#define MEI_SERVACT        0x5c   /* Service Activation */

/* Information Element ID tags - GT_FTZ specific */

#define MEI_GTNPSSCPRICLS  0x5d   /* Nat. Par.: subscriber priority class */
#define MEI_GTNATPARFF     0x5e   /* Nat. Par.: FF (multitype) */
#define MEI_GTNPCHRGINF    0x5f   /* Nat. Par.: charging information */
#define MEI_GTNPSSP        0x60   /* Nat. Par.: service switching point */
#define MEI_GTNPINCDPNO    0x61   /* Nat. Par.: intelligent network CdPNo */
#define MEI_GTNPSPV        0x62   /* Nat. Par.: semipermanent connection */
#define MEI_GTNPEXCHTRKID  0x63   /* Nat. Par.: exchange and trung ID */
#define MEI_GTNPTLN2TLNSG  0x64   /* Nat. Par.: Tln to Tln signalling */
#define MEI_GTNPCHGPTYID   0x65   /* Nat. Par.: charged party identification */
#define MEI_GTFACINDINFOR  0x66   /* Facility Indicator Information */
#define MEI_GTNPUKK        0x67   /* Nat. Par.: originating party information */

/* Info Element ID tags */
#define MEI_LOCNMB         0x68   /* location number */

#define MEI_BILLZONEINFO   0x69   /* Billing Zone Number */

/* Information Element  - BELLCORE specific */
#define MEI_HOPCOUNTER     0x6a   /* Hop counter */
#define MEI_GENNAME        0x6b   /* Generic Name */
#define MEI_REDIRCAP       0x6c   /* Redirect Capability */
#define MEI_REDIRCNTR      0x6d   /* Redirect Counter */

#define MEI_CHRGINFOTYPE      0x6e   /* Charging information type */
#define MEI_CHRGINFORMATION   0x6f   /* Charge information */
#define MEI_MSGAREAINFO       0x70   /* Message Area Information */
#define MEI_CHRGINFODELAY     0x71   /* Charge information delay */
#define MEI_CARRIERINFOTRANS  0x72   /* Carrier Info transfer */
#define MEI_SUBSNUMBER        0x73   /* Subscriber Number */
#define MEI_REASPROHIBCLLNGNO 0x74   /* Reas for prohibng callng number */
#define MEI_SUPPLUSERTYPE     0x75   /* Supplementary user type */
#define MEI_NWFUNCTYPE        0x76   /* N/w function type */

/* Defines for ANSI 95 variant */
#define MEI_CIRASGNMAP        0x77   /* Circuit Assignment Map */
#define MEI_OPTRSERVICEINFO   0x78   /* Operator Service Info */

/* Defines for ITU 97 variant */
#define MEI_CONFTRTIND        0x79   /* confrence treatment indicators */
#define MEI_UIDACTIONIND      0x7a   /* UID action indicator */
#define MEI_DISPLAYINFO       0x7b   /* display information */
#define MEI_BACKWARDGVNS      0x7c   /* backward GVNS */
#define MEI_FORWARDGVNS       0x7d   /* forward GVNS */
#define MEI_NETMGMTCONTROLS   0x7e   /* n/w management controls */
#define MEI_CORRELATIONID     0x7f   /* correlation Id */
#define MEI_CALLDIVTRTIND     0x80   /* call diversion trt ind */
#define MEI_CALLINNMB         0x81   /* call IN number */
#define MEI_CALLOFFERTRTIND   0x82   /* call offering trt ind */
#define MEI_SCFID             0x83   /* SCF Id */
#define MEI_UIDCAPIND         0x84   /* UID capability indicator */
#define MEI_COLLCALLREQ       0x85   /* collect call request */
#define MEI_CCSS              0x86   /* CCSS */

/* Information Element code for ETSIV3 variant */
#define MEI_APPTRAN           0x87   /* application transport param */
/* si029.220: Addition - added charge band index */
#define MEI_CHRGEBND          0x88   /* charge band */
/* si034.220: Addition - added charge information index */
#define MEI_CHRGINFO          0x89   /* charge information */

/* si040.220 ITU2000 parameters */

#define MEI_CADDIRNMB          0x8a   /* Called Directory Number */
#define MEI_CALGGEOLOC         0x8b   /* Calling geodetic location */
#define MEI_CCNRPOSIND         0x8c   /* CCNR Possible indicator */
#define MEI_HTRINFO            0x8d   /* HTR Information  */
#define MEI_NETROUTNUM         0x8e   /* Network Routing Number  */
#define MEI_NUMPOTRFWDINDO     0x8f   /* Number Portability Forward Info */
#define MEI_ORIGCALDINNUM      0x90   /* Original Called IN  Number */
#define MEI_PIVOTCAP           0x91   /* Pivot Capability */
#define MEI_PIVOTCNTR          0x92   /* Pivot Counter */
#define MEI_PIVOTRTGBKINFO     0x93   /* Pivot Routing Backward Info */
#define MEI_PIVOTRTGFWINFO     0x94   /* Pivot Routing Forward Info */
#define MEI_PIVOTRTGIND        0x95   /* Pivot Routing Indicators */
#define MEI_PIVOTSTAT          0x96   /* Pivot Status */
#define MEI_QONRELCAP          0x97   /* Query on Release Capability */
#define MEI_REDIRBKINFO        0x98   /* Redirect Backward Info */
#define MEI_REDIRFWINFO        0x99   /* Redirect Forward Info */
#define MEI_REDIRSTAT          0x9a   /* Redirect Status */



#endif /* __CIDBH__ */


/********************************************************************30**
  
         End of file:     ci_db.h@@/main/23 - Wed Mar 14 15:32:10 2001
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
  
1.1          ---      bn   1. text changes

1.2          ---      bn   1. corrected values for M_BLOCK and M_BLOCKACK

1.3          ---      rhk  1. Added new message and element definitions
                              for ANSI.
             ---      rhk  2. Removed M_RES defines.

1.4          ---      rhk  1. change value of ME_RANGSTAT from 0x26 to 0x16

1.5          ---      rhk  1. Added support for ANSI 92
             ---      rhk  2. Changed ANS to ANS88.

1.6          ---      rhk  1. corrections for common elements shared between
                              ANS88 and ANS92

1.7          ---      rhk  1. Moved defines for Circuit reservation messages
                              to be included in matrix.
             ---      bn   2. Added #if (SS7_ANS88 || SS7_ANS92) where necessary

1.8          ---      bn   1. change ANS88 to SS7_ANS88, ANS92 to
                              SS7_ANS92

1.9          ---      bn   1. added defines for new messages and elements for
                              SW_Q767 and SW_SINGTEL

1.10         ---      bn   1. added Italian feature to Q.767

1.11         ---      bn   1. corrections for Italian Q767.

1.12         ---      bn   1. miscellaneous changes

1.13         ---      bn   1. corrected define for continuity indicator.
             ---      dm   2. corrected define for Special Processing
                              Request1.

1.14         ---      pc   1. added ETSI option for SI

1.15         ---      dm   1. added GT_FTZ option for SI
             ---      dm   2. added service code indicator parameter for ANSI92

1.16         ---      rh   1. text changes

1.17         ---      dvs  1. Ver corrections

1.18         ---      ao   1. Added defined for Russian variant
1.18+        ---      ym   1. The define for Originating ISC code is corrected.
1.19         ---      ym   1. Changes related to addition of NTT variant in
                              ISUP.
1.20         ---      dvs  1. miscellaneous changes
1.21         ---      dvs  1. miscellaneous changes
1.22         ---      bsp  1. Merged the database from ISUP 2.16 (LPR for
                              Bellcore GR-317 variant of ISUP) with the
                              database from ISUP 2.17 (LPR for NTT variant
                              of ISUP).
/main/23     ---      bsp  1. Added defines for tokens added in ci_db.c 
                              for ITU 97, ANSI 95 and ETSI v3 variants.
            si029.220 tz   1. Increased the max number of switches due to 
                              the addition of Indian variant.
                           2. Added parameter code and index for charge 
                              band parameter.
                           3. modified the message header parameter code.
           si034220  rk    1. Added CHINA flag and switch where applicable.
           si042.220 bn    1. Added ITU2000 and Russian 2000 ISUP variants.
*********************************************************************91*/
