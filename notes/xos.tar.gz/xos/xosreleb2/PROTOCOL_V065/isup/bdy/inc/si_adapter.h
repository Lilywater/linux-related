#ifndef SI_ADAPTER_H
#define SI_ADAPTER_H




#define FILL_EVENT_HEADER(evnthdr, p_suId, p_suInstId, p_spInstId, p_circuit, p_event, p_subEvent)  \
{                                \
evnthdr.suId = p_suId;               \
evnthdr.suInstId = p_suInstId;       \
evnthdr.spInstId = p_spInstId;       \
evnthdr.cirId    = p_circuit;        \
evnthdr.event    = p_event;          \
evnthdr.subEvent = p_subEvent;       \
}

//#pragma pack(1)

typedef struct SiEventHdr_t
{
   SuId       suId;
   SiInstId   suInstId;
   SiInstId   spInstId;
   CirId      cirId;
   Event      event;
   U8         subEvent;
}SiEventHdr;

typedef struct si2UaMsg_tag
{
   SiEventHdr  siEventHdr;
   Buffer *mBuf;

}Si2UaMsg;

//#pragma pack()


#ifdef LCSILISNT_XOS


typedef struct isup2ATT_tag
{
t_XOSCOMMHEAD XosHdr;
Dpc opc;
Dpc dpc;
U8  buf[1];
}isup2ATT;


#endif


#ifdef __cplusplus
extern "C" {
#endif

#ifdef LCSIUISIT_XOS

extern U32  SiSendMsg2UA(Pst *pPst, SiEventHdr *pEventHdr, Buffer *mBuf);
extern S16  aPkSitBndCfm (Pst *pst,SuId suId,U8   status);
extern S16  aPkSitConInd(Pst *pst,SuId suId, SiInstId suInstId,SiInstId spInstId,CirId circuit,SiConEvnt *siConEvnt,Buffer *uBuf);
extern S16  aPkSitConCfm(Pst *pst,SuId suId,SiInstId suInstId,SiInstId spInstId,CirId circuit,SiConEvnt *siConEvnt,Buffer *uBuf);
extern S16  aPkSitCnStInd(Pst *pst,SuId suId,SiInstId suInstId, SiInstId  spInstId,CirId circuit,SiCnStEvnt *siCnStEvnt,U8 evntType,Buffer *uBuf);
extern S16  aPkSitStaInd(Pst *pst, SuId suId, SiInstId suInstId, SiInstId spInstId, CirId  circuit, Bool globalFlag, U8 eventType, SiStaEvnt *siStaEvnt,Buffer *uBuf);
extern S16  aPkSitRelInd(Pst *pst, SuId suId, SiInstId  suInstId,SiInstId spInstId, CirId circuit,SiRelEvnt *siRelEvnt,Buffer *uBuf);
extern S16  aPkSitRelCfm(Pst *pst, SuId suId, SiInstId suInstId, SiInstId spInstId, CirId circuit,SiRelEvnt *siRelEvnt,Buffer *uBuf);
extern S16  aPkSitDatInd(Pst *pst,SuId suId,SiInstId suInstId,SiInstId spInstId,CirId circuit,SiInfoEvnt *siInfoEvnt,Buffer *uBuf);
extern S16  aPkSitFacCfm(Pst *pst, SuId  suId, SiInstId suInstId,SiInstId spInstId, CirId circuit, U8 evntType,SiFacEvnt *siFacEvnt,Buffer *uBuf);
extern S16  aPkSitFacInd(Pst  *pst, SuId suId, SiInstId  suInstId, SiInstId spInstId, CirId circuit,U8 evntType,SiFacEvnt *siFacEvnt,Buffer *uBuf);
extern S16  aPkSitResmInd(Pst *pst, SuId  suId, SiInstId suInstId, SiInstId spInstId, CirId circuit,SiResmEvnt *siResmEvnt,Buffer *uBuf);
extern S16  aPkSitSuspInd(Pst *pst, SuId suId, SiInstId suInstId, SiInstId spInstId, CirId circuit,SiSuspEvnt *siSuspEvnt,Buffer *uBuf);
extern S16  aPkSitUMsgInd(Pst *pst,SuId suId, SiInstId suInstId,SiInstId spInstId, CirId circuit, Buffer *uBuf);
extern S16  aPkSitPtCdeStaCfm(Pst  *pst,SuId suId,SiInstId intfId,U8 status,U8 congLevel);

#endif //LCSIUISIT_XOS

#ifdef __cplusplus
}
#endif


#endif //SI_ADAPTER_H
