/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

  
/********************************************************************20**
  
    Name:      isup - error
  
    Type:      C include file
  
    Desc:      Error defines required by isup.
  
    File:      si_err.h

    Sid:      si_err.h@@/main/23 - Wed Mar 14 15:31:17 2001

*********************************************************************21*/
#include "si.h" /* ISUP defines */
  
#ifndef __SIERRH__
#define __SIERRH__
  
  
/* defines */

#define  ESIBASE     ERRSI        /* reserved */
#define  ESIXXX      ESIBASE      /* reserved */


#define   ESI001      (ERRSI +    1)    /*    ci_bdy1.c: 425 */
#define   ESI002      (ERRSI +    2)    /*    ci_bdy1.c: 448 */
#define   ESI003      (ERRSI +    3)    /*    ci_bdy1.c: 484 */
#define   ESI004      (ERRSI +    4)    /*    ci_bdy1.c: 577 */
#define   ESI005      (ERRSI +    5)    /*    ci_bdy1.c: 603 */
#define   ESI006      (ERRSI +    6)    /*    ci_bdy1.c: 896 */
#define   ESI007      (ERRSI +    7)    /*    ci_bdy1.c:1129 */
#define   ESI008      (ERRSI +    8)    /*    ci_bdy1.c:1153 */
#define   ESI009      (ERRSI +    9)    /*    ci_bdy1.c:1333 */
#define   ESI010      (ERRSI +   10)    /*    ci_bdy1.c:1471 */
#define   ESI011      (ERRSI +   11)    /*    ci_bdy1.c:1493 */
#define   ESI012      (ERRSI +   12)    /*    ci_bdy1.c:1724 */
#define   ESI013      (ERRSI +   13)    /*    ci_bdy1.c:1802 */
#define   ESI014      (ERRSI +   14)    /*    ci_bdy1.c:1919 */
#define   ESI015      (ERRSI +   15)    /*    ci_bdy1.c:1944 */
#define   ESI016      (ERRSI +   16)    /*    ci_bdy1.c:2215 */
#define   ESI017      (ERRSI +   17)    /*    ci_bdy1.c:2336 */
#define   ESI018      (ERRSI +   18)    /*    ci_bdy1.c:2361 */
#define   ESI019      (ERRSI +   19)    /*    ci_bdy1.c:2511 */
#define   ESI020      (ERRSI +   20)    /*    ci_bdy1.c:2625 */
#define   ESI021      (ERRSI +   21)    /*    ci_bdy1.c:2650 */
#define   ESI022      (ERRSI +   22)    /*    ci_bdy1.c:2845 */
#define   ESI023      (ERRSI +   23)    /*    ci_bdy1.c:2960 */
#define   ESI024      (ERRSI +   24)    /*    ci_bdy1.c:2986 */
#define   ESI025      (ERRSI +   25)    /*    ci_bdy1.c:3243 */
#define   ESI026      (ERRSI +   26)    /*    ci_bdy1.c:3407 */
#define   ESI027      (ERRSI +   27)    /*    ci_bdy1.c:3432 */
#define   ESI028      (ERRSI +   28)    /*    ci_bdy1.c:3706 */
#define   ESI029      (ERRSI +   29)    /*    ci_bdy1.c:3835 */
#define   ESI030      (ERRSI +   30)    /*    ci_bdy1.c:3860 */
#define   ESI031      (ERRSI +   31)    /*    ci_bdy1.c:4059 */
#define   ESI032      (ERRSI +   32)    /*    ci_bdy1.c:4168 */
#define   ESI033      (ERRSI +   33)    /*    ci_bdy1.c:4379 */
#define   ESI034      (ERRSI +   34)    /*    ci_bdy1.c:4582 */
#define   ESI035      (ERRSI +   35)    /*    ci_bdy1.c:4769 */
#define   ESI036      (ERRSI +   36)    /*    ci_bdy1.c:4817 */
#define   ESI037      (ERRSI +   37)    /*    ci_bdy1.c:4902 */
#define   ESI038      (ERRSI +   38)    /*    ci_bdy1.c:4928 */
#define   ESI039      (ERRSI +   39)    /*    ci_bdy1.c:5125 */
#define   ESI040      (ERRSI +   40)    /*    ci_bdy1.c:5238 */
#define   ESI041      (ERRSI +   41)    /*    ci_bdy1.c:5263 */
#define   ESI042      (ERRSI +   42)    /*    ci_bdy1.c:5460 */
#define   ESI043      (ERRSI +   43)    /*    ci_bdy1.c:5579 */
#define   ESI044      (ERRSI +   44)    /*    ci_bdy1.c:5604 */
#define   ESI045      (ERRSI +   45)    /*    ci_bdy1.c:5720 */
#define   ESI046      (ERRSI +   46)    /*    ci_bdy1.c:5753 */
#define   ESI047      (ERRSI +   47)    /*    ci_bdy1.c:5785 */
#define   ESI048      (ERRSI +   48)    /*    ci_bdy1.c:5848 */
#define   ESI049      (ERRSI +   49)    /*    ci_bdy1.c:5896 */
#define   ESI050      (ERRSI +   50)    /*    ci_bdy1.c:5944 */
#define   ESI051      (ERRSI +   51)    /*    ci_bdy1.c:6062 */
#define   ESI052      (ERRSI +   52)    /*    ci_bdy1.c:6096 */
#define   ESI053      (ERRSI +   53)    /*    ci_bdy1.c:6222 */
#define   ESI054      (ERRSI +   54)    /*    ci_bdy1.c:6307 */
#define   ESI055      (ERRSI +   55)    /*    ci_bdy1.c:6317 */
#define   ESI056      (ERRSI +   56)    /*    ci_bdy1.c:6354 */
#define   ESI057      (ERRSI +   57)    /*    ci_bdy1.c:6412 */
#define   ESI058      (ERRSI +   58)    /*    ci_bdy1.c:6435 */
#define   ESI059      (ERRSI +   59)    /*    ci_bdy1.c:6523 */
#define   ESI060      (ERRSI +   60)    /*    ci_bdy1.c:6542 */
#define   ESI061      (ERRSI +   61)    /*    ci_bdy1.c:6561 */
#define   ESI062      (ERRSI +   62)    /*    ci_bdy1.c:6666 */
#define   ESI063      (ERRSI +   63)    /*    ci_bdy1.c:6694 */
#define   ESI064      (ERRSI +   64)    /*    ci_bdy1.c:6721 */
#define   ESI065      (ERRSI +   65)    /*    ci_bdy1.c:6744 */
#define   ESI066      (ERRSI +   66)    /*    ci_bdy1.c:7028 */
#define   ESI067      (ERRSI +   67)    /*    ci_bdy1.c:7055 */
#define   ESI068      (ERRSI +   68)    /*    ci_bdy1.c:7109 */
#define   ESI069      (ERRSI +   69)    /*    ci_bdy1.c:7120 */
#define   ESI070      (ERRSI +   70)    /*    ci_bdy1.c:7233 */
#define   ESI071      (ERRSI +   71)    /*    ci_bdy1.c:7404 */
#define   ESI072      (ERRSI +   72)    /*    ci_bdy1.c:7436 */
#define   ESI073      (ERRSI +   73)    /*    ci_bdy1.c:7510 */
#define   ESI074      (ERRSI +   74)    /*    ci_bdy1.c:7521 */
#define   ESI075      (ERRSI +   75)    /*    ci_bdy1.c:7612 */
#define   ESI076      (ERRSI +   76)    /*    ci_bdy1.c:7647 */
#define   ESI077      (ERRSI +   77)    /*    ci_bdy1.c:7663 */
#define   ESI078      (ERRSI +   78)    /*    ci_bdy1.c:8250 */
#define   ESI079      (ERRSI +   79)    /*    ci_bdy1.c:8431 */
#define   ESI080      (ERRSI +   80)    /*    ci_bdy1.c:8449 */
#define   ESI081      (ERRSI +   81)    /*    ci_bdy1.c:8476 */
#define   ESI082      (ERRSI +   82)    /*    ci_bdy1.c:8494 */
#define   ESI083      (ERRSI +   83)    /*    ci_bdy1.c:8911 */
#define   ESI084      (ERRSI +   84)    /*    ci_bdy1.c:8936 */
#define   ESI085      (ERRSI +   85)    /*    ci_bdy1.c:9038 */
#define   ESI086      (ERRSI +   86)    /*    ci_bdy1.c:9061 */
#define   ESI087      (ERRSI +   87)    /*    ci_bdy1.c:9160 */
#define   ESI088      (ERRSI +   88)    /*    ci_bdy1.c:9187 */
#define   ESI089      (ERRSI +   89)    /*    ci_bdy1.c:9216 */
#define   ESI090      (ERRSI +   90)    /*    ci_bdy1.c:9566 */
#define   ESI091      (ERRSI +   91)    /*    ci_bdy1.c:9634 */
#define   ESI092      (ERRSI +   92)    /*    ci_bdy1.c:9700 */
#define   ESI093      (ERRSI +   93)    /*    ci_bdy1.c:9772 */
#define   ESI094      (ERRSI +   94)    /*    ci_bdy1.c:9838 */
#define   ESI095      (ERRSI +   95)    /*    ci_bdy1.c:9906 */
#define   ESI096      (ERRSI +   96)    /*    ci_bdy1.c:9930 */
#define   ESI097      (ERRSI +   97)    /*    ci_bdy1.c:9985 */
#define   ESI098      (ERRSI +   98)    /*    ci_bdy1.c:10037 */
#define   ESI099      (ERRSI +   99)    /*    ci_bdy1.c:10065 */
#define   ESI100      (ERRSI +  100)    /*    ci_bdy1.c:10132 */
#define   ESI101      (ERRSI +  101)    /*    ci_bdy1.c:10186 */
#define   ESI102      (ERRSI +  102)    /*    ci_bdy1.c:10207 */
#define   ESI103      (ERRSI +  103)    /*    ci_bdy1.c:10241 */
#define   ESI104      (ERRSI +  104)    /*    ci_bdy1.c:10288 */
#define   ESI105      (ERRSI +  105)    /*    ci_bdy1.c:10374 */
#define   ESI106      (ERRSI +  106)    /*    ci_bdy1.c:10408 */
#define   ESI107      (ERRSI +  107)    /*    ci_bdy1.c:10455 */
#define   ESI108      (ERRSI +  108)    /*    ci_bdy1.c:11147 */

#define   ESI109      (ERRSI +  109)    /*    ci_bdy2.c:1070 */
#define   ESI110      (ERRSI +  110)    /*    ci_bdy2.c:1080 */
#define   ESI111      (ERRSI +  111)    /*    ci_bdy2.c:1164 */
#define   ESI112      (ERRSI +  112)    /*    ci_bdy2.c:1234 */
#define   ESI113      (ERRSI +  113)    /*    ci_bdy2.c:1321 */
#define   ESI114      (ERRSI +  114)    /*    ci_bdy2.c:1376 */
#define   ESI115      (ERRSI +  115)    /*    ci_bdy2.c:1384 */
#define   ESI116      (ERRSI +  116)    /*    ci_bdy2.c:1393 */
#define   ESI117      (ERRSI +  117)    /*    ci_bdy2.c:1510 */
#define   ESI118      (ERRSI +  118)    /*    ci_bdy2.c:1577 */
#define   ESI119      (ERRSI +  119)    /*    ci_bdy2.c:1586 */
#define   ESI120      (ERRSI +  120)    /*    ci_bdy2.c:1595 */
#define   ESI121      (ERRSI +  121)    /*    ci_bdy2.c:1712 */
#define   ESI122      (ERRSI +  122)    /*    ci_bdy2.c:1790 */
#define   ESI123      (ERRSI +  123)    /*    ci_bdy2.c:1799 */
#define   ESI124      (ERRSI +  124)    /*    ci_bdy2.c:1913 */
#define   ESI125      (ERRSI +  125)    /*    ci_bdy2.c:1978 */
#define   ESI126      (ERRSI +  126)    /*    ci_bdy2.c:1987 */
#define   ESI127      (ERRSI +  127)    /*    ci_bdy2.c:2090 */
#define   ESI128      (ERRSI +  128)    /*    ci_bdy2.c:2148 */
#define   ESI129      (ERRSI +  129)    /*    ci_bdy2.c:2211 */
#define   ESI130      (ERRSI +  130)    /*    ci_bdy2.c:2319 */
#define   ESI131      (ERRSI +  131)    /*    ci_bdy2.c:2328 */
#define   ESI132      (ERRSI +  132)    /*    ci_bdy2.c:2508 */
#define   ESI133      (ERRSI +  133)    /*    ci_bdy2.c:2517 */
#define   ESI134      (ERRSI +  134)    /*    ci_bdy2.c:2583 */
#define   ESI135      (ERRSI +  135)    /*    ci_bdy2.c:2632 */
#define   ESI136      (ERRSI +  136)    /*    ci_bdy2.c:2772 */
#define   ESI137      (ERRSI +  137)    /*    ci_bdy2.c:2781 */
#define   ESI138      (ERRSI +  138)    /*    ci_bdy2.c:2871 */
#define   ESI139      (ERRSI +  139)    /*    ci_bdy2.c:2880 */
#define   ESI140      (ERRSI +  140)    /*    ci_bdy2.c:2974 */
#define   ESI141      (ERRSI +  141)    /*    ci_bdy2.c:2983 */
#define   ESI142      (ERRSI +  142)    /*    ci_bdy2.c:3106 */
#define   ESI143      (ERRSI +  143)    /*    ci_bdy2.c:3115 */
#define   ESI144      (ERRSI +  144)    /*    ci_bdy2.c:3177 */
#define   ESI145      (ERRSI +  145)    /*    ci_bdy2.c:3186 */
#define   ESI146      (ERRSI +  146)    /*    ci_bdy2.c:3275 */
#define   ESI147      (ERRSI +  147)    /*    ci_bdy2.c:3395 */
#define   ESI148      (ERRSI +  148)    /*    ci_bdy2.c:3450 */
#define   ESI149      (ERRSI +  149)    /*    ci_bdy2.c:3459 */
#define   ESI150      (ERRSI +  150)    /*    ci_bdy2.c:3566 */
#define   ESI151      (ERRSI +  151)    /*    ci_bdy2.c:3639 */
#define   ESI152      (ERRSI +  152)    /*    ci_bdy2.c:3650 */
#define   ESI153      (ERRSI +  153)    /*    ci_bdy2.c:3818 */
#define   ESI154      (ERRSI +  154)    /*    ci_bdy2.c:3842 */
#define   ESI155      (ERRSI +  155)    /*    ci_bdy2.c:3894 */
#define   ESI156      (ERRSI +  156)    /*    ci_bdy2.c:3911 */
#define   ESI157      (ERRSI +  157)    /*    ci_bdy2.c:4089 */
#define   ESI158      (ERRSI +  158)    /*    ci_bdy2.c:4176 */
#define   ESI159      (ERRSI +  159)    /*    ci_bdy2.c:4363 */
#define   ESI160      (ERRSI +  160)    /*    ci_bdy2.c:4372 */
#define   ESI161      (ERRSI +  161)    /*    ci_bdy2.c:4391 */
#define   ESI162      (ERRSI +  162)    /*    ci_bdy2.c:4430 */
#define   ESI163      (ERRSI +  163)    /*    ci_bdy2.c:4445 */
#define   ESI164      (ERRSI +  164)    /*    ci_bdy2.c:4487 */
#define   ESI165      (ERRSI +  165)    /*    ci_bdy2.c:4505 */
#define   ESI166      (ERRSI +  166)    /*    ci_bdy2.c:4610 */
#define   ESI167      (ERRSI +  167)    /*    ci_bdy2.c:4664 */
#define   ESI168      (ERRSI +  168)    /*    ci_bdy2.c:4717 */
#define   ESI169      (ERRSI +  169)    /*    ci_bdy2.c:4792 */
#define   ESI170      (ERRSI +  170)    /*    ci_bdy2.c:4906 */
#define   ESI171      (ERRSI +  171)    /*    ci_bdy2.c:4915 */
#define   ESI172      (ERRSI +  172)    /*    ci_bdy2.c:5026 */
#define   ESI173      (ERRSI +  173)    /*    ci_bdy2.c:5211 */
#define   ESI174      (ERRSI +  174)    /*    ci_bdy2.c:5258 */
#define   ESI175      (ERRSI +  175)    /*    ci_bdy2.c:5267 */
#define   ESI176      (ERRSI +  176)    /*    ci_bdy2.c:5368 */
#define   ESI177      (ERRSI +  177)    /*    ci_bdy2.c:5377 */
#define   ESI178      (ERRSI +  178)    /*    ci_bdy2.c:5446 */
#define   ESI179      (ERRSI +  179)    /*    ci_bdy2.c:5490 */
#define   ESI180      (ERRSI +  180)    /*    ci_bdy2.c:5545 */
#define   ESI181      (ERRSI +  181)    /*    ci_bdy2.c:5554 */
#define   ESI182      (ERRSI +  182)    /*    ci_bdy2.c:5618 */
#define   ESI183      (ERRSI +  183)    /*    ci_bdy2.c:5627 */
#define   ESI184      (ERRSI +  184)    /*    ci_bdy2.c:5726 */
#define   ESI185      (ERRSI +  185)    /*    ci_bdy2.c:5860 */
#define   ESI186      (ERRSI +  186)    /*    ci_bdy2.c:5946 */
#define   ESI187      (ERRSI +  187)    /*    ci_bdy2.c:6021 */
#define   ESI188      (ERRSI +  188)    /*    ci_bdy2.c:6030 */
#define   ESI189      (ERRSI +  189)    /*    ci_bdy2.c:6094 */
#define   ESI190      (ERRSI +  190)    /*    ci_bdy2.c:6103 */
#define   ESI191      (ERRSI +  191)    /*    ci_bdy2.c:6208 */
#define   ESI192      (ERRSI +  192)    /*    ci_bdy2.c:6254 */
#define   ESI193      (ERRSI +  193)    /*    ci_bdy2.c:6263 */
#define   ESI194      (ERRSI +  194)    /*    ci_bdy2.c:6357 */
#define   ESI195      (ERRSI +  195)    /*    ci_bdy2.c:6366 */
#define   ESI196      (ERRSI +  196)    /*    ci_bdy2.c:6423 */
#define   ESI197      (ERRSI +  197)    /*    ci_bdy2.c:6432 */
#define   ESI198      (ERRSI +  198)    /*    ci_bdy2.c:6523 */
#define   ESI199      (ERRSI +  199)    /*    ci_bdy2.c:6532 */
#define   ESI200      (ERRSI +  200)    /*    ci_bdy2.c:6619 */
#define   ESI201      (ERRSI +  201)    /*    ci_bdy2.c:6628 */
#define   ESI202      (ERRSI +  202)    /*    ci_bdy2.c:6720 */
#define   ESI203      (ERRSI +  203)    /*    ci_bdy2.c:6750 */
#define   ESI204      (ERRSI +  204)    /*    ci_bdy2.c:6762 */
#define   ESI205      (ERRSI +  205)    /*    ci_bdy2.c:6841 */
#define   ESI206      (ERRSI +  206)    /*    ci_bdy2.c:6961 */
#define   ESI207      (ERRSI +  207)    /*    ci_bdy2.c:7012 */
#define   ESI208      (ERRSI +  208)    /*    ci_bdy2.c:7021 */
#define   ESI209      (ERRSI +  209)    /*    ci_bdy2.c:7031 */
#define   ESI210      (ERRSI +  210)    /*    ci_bdy2.c:7117 */
#define   ESI211      (ERRSI +  211)    /*    ci_bdy2.c:7196 */
#define   ESI212      (ERRSI +  212)    /*    ci_bdy2.c:7205 */
#define   ESI213      (ERRSI +  213)    /*    ci_bdy2.c:7215 */
#define   ESI214      (ERRSI +  214)    /*    ci_bdy2.c:7239 */
#define   ESI215      (ERRSI +  215)    /*    ci_bdy2.c:7342 */
#define   ESI216      (ERRSI +  216)    /*    ci_bdy2.c:7351 */
#define   ESI217      (ERRSI +  217)    /*    ci_bdy2.c:7361 */
#define   ESI218      (ERRSI +  218)    /*    ci_bdy2.c:7505 */
#define   ESI219      (ERRSI +  219)    /*    ci_bdy2.c:7678 */
#define   ESI220      (ERRSI +  220)    /*    ci_bdy2.c:7687 */
#define   ESI221      (ERRSI +  221)    /*    ci_bdy2.c:7697 */
#define   ESI222      (ERRSI +  222)    /*    ci_bdy2.c:7940 */
#define   ESI223      (ERRSI +  223)    /*    ci_bdy2.c:7972 */
#define   ESI224      (ERRSI +  224)    /*    ci_bdy2.c:8075 */
#define   ESI225      (ERRSI +  225)    /*    ci_bdy2.c:8246 */
#define   ESI226      (ERRSI +  226)    /*    ci_bdy2.c:8255 */
#define   ESI227      (ERRSI +  227)    /*    ci_bdy2.c:8265 */
#define   ESI228      (ERRSI +  228)    /*    ci_bdy2.c:8584 */
#define   ESI229      (ERRSI +  229)    /*    ci_bdy2.c:8615 */
#define   ESI230      (ERRSI +  230)    /*    ci_bdy2.c:8807 */
#define   ESI231      (ERRSI +  231)    /*    ci_bdy2.c:8816 */
#define   ESI232      (ERRSI +  232)    /*    ci_bdy2.c:8826 */
#define   ESI233      (ERRSI +  233)    /*    ci_bdy2.c:9035 */
#define   ESI234      (ERRSI +  234)    /*    ci_bdy2.c:9308 */
#define   ESI235      (ERRSI +  235)    /*    ci_bdy2.c:9340 */
#define   ESI236      (ERRSI +  236)    /*    ci_bdy2.c:9519 */
#define   ESI237      (ERRSI +  237)    /*    ci_bdy2.c:9528 */
#define   ESI238      (ERRSI +  238)    /*    ci_bdy2.c:9538 */
#define   ESI239      (ERRSI +  239)    /*    ci_bdy2.c:9670 */
#define   ESI240      (ERRSI +  240)    /*    ci_bdy2.c:9679 */
#define   ESI241      (ERRSI +  241)    /*    ci_bdy2.c:9689 */
#define   ESI242      (ERRSI +  242)    /*    ci_bdy2.c:9809 */
#define   ESI243      (ERRSI +  243)    /*    ci_bdy2.c:9818 */
#define   ESI244      (ERRSI +  244)    /*    ci_bdy2.c:9828 */
#define   ESI245      (ERRSI +  245)    /*    ci_bdy2.c:9986 */
#define   ESI246      (ERRSI +  246)    /*    ci_bdy2.c:10046 */
#define   ESI247      (ERRSI +  247)    /*    ci_bdy2.c:10052 */
#define   ESI248      (ERRSI +  248)    /*    ci_bdy2.c:10072 */
#define   ESI249      (ERRSI +  249)    /*    ci_bdy2.c:10190 */
#define   ESI250      (ERRSI +  250)    /*    ci_bdy2.c:10237 */
#define   ESI251      (ERRSI +  251)    /*    ci_bdy2.c:10248 */
#define   ESI252      (ERRSI +  252)    /*    ci_bdy2.c:10267 */
#define   ESI253      (ERRSI +  253)    /*    ci_bdy2.c:10346 */
#define   ESI254      (ERRSI +  254)    /*    ci_bdy2.c:10355 */
#define   ESI255      (ERRSI +  255)    /*    ci_bdy2.c:10371 */
#define   ESI256      (ERRSI +  256)    /*    ci_bdy2.c:10437 */
#define   ESI257      (ERRSI +  257)    /*    ci_bdy2.c:10446 */
#define   ESI258      (ERRSI +  258)    /*    ci_bdy2.c:10456 */
#define   ESI259      (ERRSI +  259)    /*    ci_bdy2.c:10470 */
#define   ESI260      (ERRSI +  260)    /*    ci_bdy2.c:10562 */
#define   ESI261      (ERRSI +  261)    /*    ci_bdy2.c:10627 */
#define   ESI262      (ERRSI +  262)    /*    ci_bdy2.c:10636 */
#define   ESI263      (ERRSI +  263)    /*    ci_bdy2.c:10652 */
#define   ESI264      (ERRSI +  264)    /*    ci_bdy2.c:10726 */
#define   ESI265      (ERRSI +  265)    /*    ci_bdy2.c:10735 */
#define   ESI266      (ERRSI +  266)    /*    ci_bdy2.c:10744 */
#define   ESI267      (ERRSI +  267)    /*    ci_bdy2.c:10785 */
#define   ESI268      (ERRSI +  268)    /*    ci_bdy2.c:10799 */
#define   ESI269      (ERRSI +  269)    /*    ci_bdy2.c:10813 */
#define   ESI270      (ERRSI +  270)    /*    ci_bdy2.c:10831 */
#define   ESI271      (ERRSI +  271)    /*    ci_bdy2.c:10935 */
#define   ESI272      (ERRSI +  272)    /*    ci_bdy2.c:10944 */
#define   ESI273      (ERRSI +  273)    /*    ci_bdy2.c:10953 */
#define   ESI274      (ERRSI +  274)    /*    ci_bdy2.c:11048 */
#define   ESI275      (ERRSI +  275)    /*    ci_bdy2.c:11057 */
#define   ESI276      (ERRSI +  276)    /*    ci_bdy2.c:11066 */
#define   ESI277      (ERRSI +  277)    /*    ci_bdy2.c:11166 */
#define   ESI278      (ERRSI +  278)    /*    ci_bdy2.c:11175 */
#define   ESI279      (ERRSI +  279)    /*    ci_bdy2.c:11184 */
#define   ESI280      (ERRSI +  280)    /*    ci_bdy2.c:11272 */
#define   ESI281      (ERRSI +  281)    /*    ci_bdy2.c:11281 */
#define   ESI282      (ERRSI +  282)    /*    ci_bdy2.c:11290 */
#define   ESI283      (ERRSI +  283)    /*    ci_bdy2.c:11465 */
#define   ESI284      (ERRSI +  284)    /*    ci_bdy2.c:11474 */
#define   ESI285      (ERRSI +  285)    /*    ci_bdy2.c:11483 */
#define   ESI286      (ERRSI +  286)    /*    ci_bdy2.c:11526 */
#define   ESI287      (ERRSI +  287)    /*    ci_bdy2.c:11540 */
#define   ESI288      (ERRSI +  288)    /*    ci_bdy2.c:11668 */
#define   ESI289      (ERRSI +  289)    /*    ci_bdy2.c:11680 */
#define   ESI290      (ERRSI +  290)    /*    ci_bdy2.c:11778 */
#define   ESI291      (ERRSI +  291)    /*    ci_bdy2.c:11787 */
#define   ESI292      (ERRSI +  292)    /*    ci_bdy2.c:11796 */
#define   ESI293      (ERRSI +  293)    /*    ci_bdy2.c:11937 */
#define   ESI294      (ERRSI +  294)    /*    ci_bdy2.c:11946 */
#define   ESI295      (ERRSI +  295)    /*    ci_bdy2.c:12003 */
#define   ESI296      (ERRSI +  296)    /*    ci_bdy2.c:12144 */
#define   ESI297      (ERRSI +  297)    /*    ci_bdy2.c:12257 */
#define   ESI298      (ERRSI +  298)    /*    ci_bdy2.c:12303 */
#define   ESI299      (ERRSI +  299)    /*    ci_bdy2.c:12385 */
#define   ESI300      (ERRSI +  300)    /*    ci_bdy2.c:12436 */
#define   ESI301      (ERRSI +  301)    /*    ci_bdy2.c:12482 */
#define   ESI302      (ERRSI +  302)    /*    ci_bdy2.c:12563 */

#define   ESI303      (ERRSI +  303)    /*    ci_bdy3.c:1161 */
#define   ESI304      (ERRSI +  304)    /*    ci_bdy3.c:1171 */
#define   ESI305      (ERRSI +  305)    /*    ci_bdy3.c:1181 */
#define   ESI306      (ERRSI +  306)    /*    ci_bdy3.c:1294 */
#define   ESI307      (ERRSI +  307)    /*    ci_bdy3.c:1348 */
#define   ESI308      (ERRSI +  308)    /*    ci_bdy3.c:1357 */
#define   ESI309      (ERRSI +  309)    /*    ci_bdy3.c:1492 */
#define   ESI310      (ERRSI +  310)    /*    ci_bdy3.c:1599 */
#define   ESI311      (ERRSI +  311)    /*    ci_bdy3.c:1608 */
#define   ESI312      (ERRSI +  312)    /*    ci_bdy3.c:1754 */
#define   ESI313      (ERRSI +  313)    /*    ci_bdy3.c:1763 */
#define   ESI314      (ERRSI +  314)    /*    ci_bdy3.c:1898 */
#define   ESI315      (ERRSI +  315)    /*    ci_bdy3.c:2015 */
#define   ESI316      (ERRSI +  316)    /*    ci_bdy3.c:2024 */
#define   ESI317      (ERRSI +  317)    /*    ci_bdy3.c:2151 */
#define   ESI318      (ERRSI +  318)    /*    ci_bdy3.c:2219 */
#define   ESI319      (ERRSI +  319)    /*    ci_bdy3.c:2228 */
#define   ESI320      (ERRSI +  320)    /*    ci_bdy3.c:2237 */
#define   ESI321      (ERRSI +  321)    /*    ci_bdy3.c:2364 */
#define   ESI322      (ERRSI +  322)    /*    ci_bdy3.c:2446 */
#define   ESI323      (ERRSI +  323)    /*    ci_bdy3.c:2455 */
#define   ESI324      (ERRSI +  324)    /*    ci_bdy3.c:2580 */
#define   ESI325      (ERRSI +  325)    /*    ci_bdy3.c:2644 */
#define   ESI326      (ERRSI +  326)    /*    ci_bdy3.c:2653 */
#define   ESI327      (ERRSI +  327)    /*    ci_bdy3.c:2715 */
#define   ESI328      (ERRSI +  328)    /*    ci_bdy3.c:2724 */
#define   ESI329      (ERRSI +  329)    /*    ci_bdy3.c:2798 */
#define   ESI330      (ERRSI +  330)    /*    ci_bdy3.c:2807 */
#define   ESI331      (ERRSI +  331)    /*    ci_bdy3.c:2915 */
#define   ESI332      (ERRSI +  332)    /*    ci_bdy3.c:2973 */
#define   ESI333      (ERRSI +  333)    /*    ci_bdy3.c:2982 */
#define   ESI334      (ERRSI +  334)    /*    ci_bdy3.c:3058 */
#define   ESI335      (ERRSI +  335)    /*    ci_bdy3.c:3067 */
#define   ESI336      (ERRSI +  336)    /*    ci_bdy3.c:3169 */
#define   ESI337      (ERRSI +  337)    /*    ci_bdy3.c:3258 */
#define   ESI338      (ERRSI +  338)    /*    ci_bdy3.c:3267 */
#define   ESI339      (ERRSI +  339)    /*    ci_bdy3.c:3372 */
#define   ESI340      (ERRSI +  340)    /*    ci_bdy3.c:3381 */
#define   ESI341      (ERRSI +  341)    /*    ci_bdy3.c:3498 */
#define   ESI342      (ERRSI +  342)    /*    ci_bdy3.c:3507 */
#define   ESI343      (ERRSI +  343)    /*    ci_bdy3.c:3649 */
#define   ESI344      (ERRSI +  344)    /*    ci_bdy3.c:3658 */
#define   ESI345      (ERRSI +  345)    /*    ci_bdy3.c:3774 */
#define   ESI346      (ERRSI +  346)    /*    ci_bdy3.c:3832 */
#define   ESI347      (ERRSI +  347)    /*    ci_bdy3.c:3841 */
#define   ESI348      (ERRSI +  348)    /*    ci_bdy3.c:3944 */
#define   ESI349      (ERRSI +  349)    /*    ci_bdy3.c:4001 */
#define   ESI350      (ERRSI +  350)    /*    ci_bdy3.c:4010 */
#define   ESI351      (ERRSI +  351)    /*    ci_bdy3.c:4019 */
#define   ESI352      (ERRSI +  352)    /*    ci_bdy3.c:4118 */
#define   ESI353      (ERRSI +  353)    /*    ci_bdy3.c:4127 */
#define   ESI354      (ERRSI +  354)    /*    ci_bdy3.c:4136 */
#define   ESI355      (ERRSI +  355)    /*    ci_bdy3.c:4378 */
#define   ESI356      (ERRSI +  356)    /*    ci_bdy3.c:4387 */
#define   ESI357      (ERRSI +  357)    /*    ci_bdy3.c:4396 */
#define   ESI358      (ERRSI +  358)    /*    ci_bdy3.c:4471 */
#define   ESI359      (ERRSI +  359)    /*    ci_bdy3.c:4570 */
#define   ESI360      (ERRSI +  360)    /*    ci_bdy3.c:4579 */
#define   ESI361      (ERRSI +  361)    /*    ci_bdy3.c:4692 */
#define   ESI362      (ERRSI +  362)    /*    ci_bdy3.c:4701 */
#define   ESI363      (ERRSI +  363)    /*    ci_bdy3.c:4710 */
#define   ESI364      (ERRSI +  364)    /*    ci_bdy3.c:4887 */
#define   ESI365      (ERRSI +  365)    /*    ci_bdy3.c:4934 */
#define   ESI366      (ERRSI +  366)    /*    ci_bdy3.c:4943 */
#define   ESI367      (ERRSI +  367)    /*    ci_bdy3.c:5047 */
#define   ESI368      (ERRSI +  368)    /*    ci_bdy3.c:5056 */
#define   ESI369      (ERRSI +  369)    /*    ci_bdy3.c:5065 */
#define   ESI370      (ERRSI +  370)    /*    ci_bdy3.c:5122 */
#define   ESI371      (ERRSI +  371)    /*    ci_bdy3.c:5174 */
#define   ESI372      (ERRSI +  372)    /*    ci_bdy3.c:5183 */
#define   ESI373      (ERRSI +  373)    /*    ci_bdy3.c:5192 */
#define   ESI374      (ERRSI +  374)    /*    ci_bdy3.c:5243 */
#define   ESI375      (ERRSI +  375)    /*    ci_bdy3.c:5297 */
#define   ESI376      (ERRSI +  376)    /*    ci_bdy3.c:5306 */
#define   ESI377      (ERRSI +  377)    /*    ci_bdy3.c:5315 */
#define   ESI378      (ERRSI +  378)    /*    ci_bdy3.c:5373 */
#define   ESI379      (ERRSI +  379)    /*    ci_bdy3.c:5418 */
#define   ESI380      (ERRSI +  380)    /*    ci_bdy3.c:5427 */
#define   ESI381      (ERRSI +  381)    /*    ci_bdy3.c:5525 */
#define   ESI382      (ERRSI +  382)    /*    ci_bdy3.c:5534 */
#define   ESI383      (ERRSI +  383)    /*    ci_bdy3.c:5639 */
#define   ESI384      (ERRSI +  384)    /*    ci_bdy3.c:5776 */
#define   ESI385      (ERRSI +  385)    /*    ci_bdy3.c:5782 */
#define   ESI386      (ERRSI +  386)    /*    ci_bdy3.c:5872 */
#define   ESI387      (ERRSI +  387)    /*    ci_bdy3.c:5945 */
#define   ESI388      (ERRSI +  388)    /*    ci_bdy3.c:5954 */
#define   ESI389      (ERRSI +  389)    /*    ci_bdy3.c:6015 */
#define   ESI390      (ERRSI +  390)    /*    ci_bdy3.c:6024 */
#define   ESI391      (ERRSI +  391)    /*    ci_bdy3.c:6033 */
#define   ESI392      (ERRSI +  392)    /*    ci_bdy3.c:6097 */
#define   ESI393      (ERRSI +  393)    /*    ci_bdy3.c:6146 */
#define   ESI394      (ERRSI +  394)    /*    ci_bdy3.c:6155 */
#define   ESI395      (ERRSI +  395)    /*    ci_bdy3.c:6164 */
#define   ESI396      (ERRSI +  396)    /*    ci_bdy3.c:6225 */
#define   ESI397      (ERRSI +  397)    /*    ci_bdy3.c:6272 */
#define   ESI398      (ERRSI +  398)    /*    ci_bdy3.c:6281 */
#define   ESI399      (ERRSI +  399)    /*    ci_bdy3.c:6375 */
#define   ESI400      (ERRSI +  400)    /*    ci_bdy3.c:6384 */
#define   ESI401      (ERRSI +  401)    /*    ci_bdy3.c:6483 */
#define   ESI402      (ERRSI +  402)    /*    ci_bdy3.c:6492 */
#define   ESI403      (ERRSI +  403)    /*    ci_bdy3.c:6588 */
#define   ESI404      (ERRSI +  404)    /*    ci_bdy3.c:6597 */
#define   ESI405      (ERRSI +  405)    /*    ci_bdy3.c:6681 */
#define   ESI406      (ERRSI +  406)    /*    ci_bdy3.c:6690 */
#define   ESI407      (ERRSI +  407)    /*    ci_bdy3.c:6699 */
#define   ESI408      (ERRSI +  408)    /*    ci_bdy3.c:6833 */
#define   ESI409      (ERRSI +  409)    /*    ci_bdy3.c:6842 */
#define   ESI410      (ERRSI +  410)    /*    ci_bdy3.c:6851 */
#define   ESI411      (ERRSI +  411)    /*    ci_bdy3.c:6919 */
#define   ESI412      (ERRSI +  412)    /*    ci_bdy3.c:6965 */
#define   ESI413      (ERRSI +  413)    /*    ci_bdy3.c:6974 */
#define   ESI414      (ERRSI +  414)    /*    ci_bdy3.c:6983 */
#define   ESI415      (ERRSI +  415)    /*    ci_bdy3.c:7026 */
#define   ESI416      (ERRSI +  416)    /*    ci_bdy3.c:7088 */
#define   ESI417      (ERRSI +  417)    /*    ci_bdy3.c:7097 */
#define   ESI418      (ERRSI +  418)    /*    ci_bdy3.c:7106 */
#define   ESI419      (ERRSI +  419)    /*    ci_bdy3.c:7212 */
#define   ESI420      (ERRSI +  420)    /*    ci_bdy3.c:7277 */
#define   ESI421      (ERRSI +  421)    /*    ci_bdy3.c:7291 */
#define   ESI422      (ERRSI +  422)    /*    ci_bdy3.c:7532 */
#define   ESI423      (ERRSI +  423)    /*    ci_bdy3.c:7709 */
#define   ESI424      (ERRSI +  424)    /*    ci_bdy3.c:7718 */
#define   ESI425      (ERRSI +  425)    /*    ci_bdy3.c:7727 */
#define   ESI426      (ERRSI +  426)    /*    ci_bdy3.c:7799 */
#define   ESI427      (ERRSI +  427)    /*    ci_bdy3.c:7910 */
#define   ESI428      (ERRSI +  428)    /*    ci_bdy3.c:8003 */
#define   ESI429      (ERRSI +  429)    /*    ci_bdy3.c:8012 */
#define   ESI430      (ERRSI +  430)    /*    ci_bdy3.c:8021 */
#define   ESI431      (ERRSI +  431)    /*    ci_bdy3.c:8226 */
#define   ESI432      (ERRSI +  432)    /*    ci_bdy3.c:8422 */
#define   ESI433      (ERRSI +  433)    /*    ci_bdy3.c:8481 */
#define   ESI434      (ERRSI +  434)    /*    ci_bdy3.c:8490 */
#define   ESI435      (ERRSI +  435)    /*    ci_bdy3.c:8499 */
#define   ESI436      (ERRSI +  436)    /*    ci_bdy3.c:9127 */
#define   ESI437      (ERRSI +  437)    /*    ci_bdy3.c:9190 */
#define   ESI438      (ERRSI +  438)    /*    ci_bdy3.c:9199 */
#define   ESI439      (ERRSI +  439)    /*    ci_bdy3.c:9208 */
#define   ESI440      (ERRSI +  440)    /*    ci_bdy3.c:9250 */
#define   ESI441      (ERRSI +  441)    /*    ci_bdy3.c:9335 */
#define   ESI442      (ERRSI +  442)    /*    ci_bdy3.c:9344 */
#define   ESI443      (ERRSI +  443)    /*    ci_bdy3.c:9353 */
#define   ESI444      (ERRSI +  444)    /*    ci_bdy3.c:9550 */
#define   ESI445      (ERRSI +  445)    /*    ci_bdy3.c:9613 */
#define   ESI446      (ERRSI +  446)    /*    ci_bdy3.c:9622 */
#define   ESI447      (ERRSI +  447)    /*    ci_bdy3.c:9631 */
#define   ESI448      (ERRSI +  448)    /*    ci_bdy3.c:9647 */
#define   ESI449      (ERRSI +  449)    /*    ci_bdy3.c:9761 */
#define   ESI450      (ERRSI +  450)    /*    ci_bdy3.c:9815 */
#define   ESI451      (ERRSI +  451)    /*    ci_bdy3.c:9824 */
#define   ESI452      (ERRSI +  452)    /*    ci_bdy3.c:9931 */
#define   ESI453      (ERRSI +  453)    /*    ci_bdy3.c:9955 */
#define   ESI454      (ERRSI +  454)    /*    ci_bdy3.c:10007 */
#define   ESI455      (ERRSI +  455)    /*    ci_bdy3.c:10016 */
#define   ESI456      (ERRSI +  456)    /*    ci_bdy3.c:10125 */
#define   ESI457      (ERRSI +  457)    /*    ci_bdy3.c:10149 */
#define   ESI458      (ERRSI +  458)    /*    ci_bdy3.c:10195 */
#define   ESI459      (ERRSI +  459)    /*    ci_bdy3.c:10204 */
#define   ESI460      (ERRSI +  460)    /*    ci_bdy3.c:10216 */
#define   ESI461      (ERRSI +  461)    /*    ci_bdy3.c:10276 */
#define   ESI462      (ERRSI +  462)    /*    ci_bdy3.c:10285 */
#define   ESI463      (ERRSI +  463)    /*    ci_bdy3.c:10296 */
#define   ESI464      (ERRSI +  464)    /*    ci_bdy3.c:10360 */
#define   ESI465      (ERRSI +  465)    /*    ci_bdy3.c:10369 */
#define   ESI466      (ERRSI +  466)    /*    ci_bdy3.c:10378 */
#define   ESI467      (ERRSI +  467)    /*    ci_bdy3.c:10390 */
#define   ESI468      (ERRSI +  468)    /*    ci_bdy3.c:10484 */
#define   ESI469      (ERRSI +  469)    /*    ci_bdy3.c:10551 */
#define   ESI470      (ERRSI +  470)    /*    ci_bdy3.c:10560 */
#define   ESI471      (ERRSI +  471)    /*    ci_bdy3.c:10571 */
#define   ESI472      (ERRSI +  472)    /*    ci_bdy3.c:10641 */
#define   ESI473      (ERRSI +  473)    /*    ci_bdy3.c:10647 */
#define   ESI474      (ERRSI +  474)    /*    ci_bdy3.c:10656 */
#define   ESI475      (ERRSI +  475)    /*    ci_bdy3.c:10700 */
#define   ESI476      (ERRSI +  476)    /*    ci_bdy3.c:10714 */
#define   ESI477      (ERRSI +  477)    /*    ci_bdy3.c:10728 */
#define   ESI478      (ERRSI +  478)    /*    ci_bdy3.c:10746 */
#define   ESI479      (ERRSI +  479)    /*    ci_bdy3.c:10849 */
#define   ESI480      (ERRSI +  480)    /*    ci_bdy3.c:10858 */
#define   ESI481      (ERRSI +  481)    /*    ci_bdy3.c:10867 */
#define   ESI482      (ERRSI +  482)    /*    ci_bdy3.c:10941 */
#define   ESI483      (ERRSI +  483)    /*    ci_bdy3.c:10950 */
#define   ESI484      (ERRSI +  484)    /*    ci_bdy3.c:10959 */
#define   ESI485      (ERRSI +  485)    /*    ci_bdy3.c:11038 */
#define   ESI486      (ERRSI +  486)    /*    ci_bdy3.c:11047 */
#define   ESI487      (ERRSI +  487)    /*    ci_bdy3.c:11056 */
#define   ESI488      (ERRSI +  488)    /*    ci_bdy3.c:11145 */
#define   ESI489      (ERRSI +  489)    /*    ci_bdy3.c:11154 */
#define   ESI490      (ERRSI +  490)    /*    ci_bdy3.c:11163 */
#define   ESI491      (ERRSI +  491)    /*    ci_bdy3.c:11241 */
#define   ESI492      (ERRSI +  492)    /*    ci_bdy3.c:11335 */
#define   ESI493      (ERRSI +  493)    /*    ci_bdy3.c:11344 */
#define   ESI494      (ERRSI +  494)    /*    ci_bdy3.c:11353 */
#define   ESI495      (ERRSI +  495)    /*    ci_bdy3.c:11391 */
#define   ESI496      (ERRSI +  496)    /*    ci_bdy3.c:11405 */
#define   ESI497      (ERRSI +  497)    /*    ci_bdy3.c:11535 */
#define   ESI498      (ERRSI +  498)    /*    ci_bdy3.c:11544 */
#define   ESI499      (ERRSI +  499)    /*    ci_bdy3.c:11553 */
#define   ESI500      (ERRSI +  500)    /*    ci_bdy3.c:11629 */
#define   ESI501      (ERRSI +  501)    /*    ci_bdy3.c:11686 */
#define   ESI502      (ERRSI +  502)    /*    ci_bdy3.c:11736 */
#define   ESI503      (ERRSI +  503)    /*    ci_bdy3.c:11745 */
#define   ESI504      (ERRSI +  504)    /*    ci_bdy3.c:11754 */
#define   ESI505      (ERRSI +  505)    /*    ci_bdy3.c:11926 */
#define   ESI506      (ERRSI +  506)    /*    ci_bdy3.c:11935 */
#define   ESI507      (ERRSI +  507)    /*    ci_bdy3.c:11944 */
#define   ESI508      (ERRSI +  508)    /*    ci_bdy3.c:12026 */
#define   ESI509      (ERRSI +  509)    /*    ci_bdy3.c:12125 */
#define   ESI510      (ERRSI +  510)    /*    ci_bdy3.c:12134 */
#define   ESI511      (ERRSI +  511)    /*    ci_bdy3.c:12257 */
#define   ESI512      (ERRSI +  512)    /*    ci_bdy3.c:12394 */
#define   ESI513      (ERRSI +  513)    /*    ci_bdy3.c:12455 */
#define   ESI514      (ERRSI +  514)    /*    ci_bdy3.c:12464 */
#define   ESI515      (ERRSI +  515)    /*    ci_bdy3.c:12473 */
#define   ESI516      (ERRSI +  516)    /*    ci_bdy3.c:12577 */
#define   ESI517      (ERRSI +  517)    /*    ci_bdy3.c:12586 */
#define   ESI518      (ERRSI +  518)    /*    ci_bdy3.c:12595 */

#define   ESI519      (ERRSI +  519)    /*    ci_bdy4.c:1257 */
#define   ESI520      (ERRSI +  520)    /*    ci_bdy4.c:1443 */
#define   ESI521      (ERRSI +  521)    /*    ci_bdy4.c:1535 */
#define   ESI522      (ERRSI +  522)    /*    ci_bdy4.c:1658 */
#define   ESI523      (ERRSI +  523)    /*    ci_bdy4.c:1683 */
#define   ESI524      (ERRSI +  524)    /*    ci_bdy4.c:1754 */
#define   ESI525      (ERRSI +  525)    /*    ci_bdy4.c:1981 */
#define   ESI526      (ERRSI +  526)    /*    ci_bdy4.c:2050 */
#define   ESI527      (ERRSI +  527)    /*    ci_bdy4.c:2110 */
#define   ESI528      (ERRSI +  528)    /*    ci_bdy4.c:2163 */
#define   ESI529      (ERRSI +  529)    /*    ci_bdy4.c:2197 */
#define   ESI530      (ERRSI +  530)    /*    ci_bdy4.c:2236 */
#define   ESI531      (ERRSI +  531)    /*    ci_bdy4.c:2513 */
#define   ESI532      (ERRSI +  532)    /*    ci_bdy4.c:2660 */
#define   ESI533      (ERRSI +  533)    /*    ci_bdy4.c:7014 */
#define   ESI534      (ERRSI +  534)    /*    ci_bdy4.c:7168 */
#define   ESI535      (ERRSI +  535)    /*    ci_bdy4.c:7499 */
#define   ESI536      (ERRSI +  536)    /*    ci_bdy4.c:7507 */
#define   ESI537      (ERRSI +  537)    /*    ci_bdy4.c:7870 */
#define   ESI538      (ERRSI +  538)    /*    ci_bdy4.c:8183 */
#define   ESI539      (ERRSI +  539)    /*    ci_bdy4.c:8282 */
#define   ESI540      (ERRSI +  540)    /*    ci_bdy4.c:8672 */
#define   ESI541      (ERRSI +  541)    /*    ci_bdy4.c:8883 */
#define   ESI542      (ERRSI +  542)    /*    ci_bdy4.c:8982 */
#define   ESI543      (ERRSI +  543)    /*    ci_bdy4.c:9594 */
#define   ESI544      (ERRSI +  544)    /*    ci_bdy4.c:9605 */
#define   ESI545      (ERRSI +  545)    /*    ci_bdy4.c:9631 */
#define   ESI546      (ERRSI +  546)    /*    ci_bdy4.c:10387 */
#define   ESI547      (ERRSI +  547)    /*    ci_bdy4.c:10562 */
#define   ESI548      (ERRSI +  548)    /*    ci_bdy4.c:10569 */
#define   ESI549      (ERRSI +  549)    /*    ci_bdy4.c:11041 */
#define   ESI550      (ERRSI +  550)    /*    ci_bdy4.c:11451 */
#define   ESI551      (ERRSI +  551)    /*    ci_bdy4.c:11520 */
#define   ESI552      (ERRSI +  552)    /*    ci_bdy4.c:11532 */
#define   ESI553      (ERRSI +  553)    /*    ci_bdy4.c:11546 */
#define   ESI554      (ERRSI +  554)    /*    ci_bdy4.c:11561 */
#define   ESI555      (ERRSI +  555)    /*    ci_bdy4.c:13120 */
#define   ESI556      (ERRSI +  556)    /*    ci_bdy4.c:13132 */

#define   ESI557      (ERRSI +  557)    /*    ci_bdy5.c:1144 */
#define   ESI558      (ERRSI +  558)    /*    ci_bdy5.c:1160 */
#define   ESI559      (ERRSI +  559)    /*    ci_bdy5.c:1179 */
#define   ESI560      (ERRSI +  560)    /*    ci_bdy5.c:1266 */
#define   ESI561      (ERRSI +  561)    /*    ci_bdy5.c:1280 */
#define   ESI562      (ERRSI +  562)    /*    ci_bdy5.c:1295 */
#define   ESI563      (ERRSI +  563)    /*    ci_bdy5.c:1422 */
#define   ESI564      (ERRSI +  564)    /*    ci_bdy5.c:1497 */
#define   ESI565      (ERRSI +  565)    /*    ci_bdy5.c:1772 */
#define   ESI566      (ERRSI +  566)    /*    ci_bdy5.c:1861 */
#define   ESI567      (ERRSI +  567)    /*    ci_bdy5.c:1874 */
#define   ESI568      (ERRSI +  568)    /*    ci_bdy5.c:2957 */
#define   ESI569      (ERRSI +  569)    /*    ci_bdy5.c:3118 */
#define   ESI570      (ERRSI +  570)    /*    ci_bdy5.c:5176 */
#define   ESI571      (ERRSI +  571)    /*    ci_bdy5.c:5190 */
#define   ESI572      (ERRSI +  572)    /*    ci_bdy5.c:5258 */
#define   ESI573      (ERRSI +  573)    /*    ci_bdy5.c:5272 */
#define   ESI574      (ERRSI +  574)    /*    ci_bdy5.c:5458 */
#define   ESI575      (ERRSI +  575)    /*    ci_bdy5.c:5564 */
#define   ESI576      (ERRSI +  576)    /*    ci_bdy5.c:5611 */
#define   ESI577      (ERRSI +  577)    /*    ci_bdy5.c:5710 */
#define   ESI578      (ERRSI +  578)    /*    ci_bdy5.c:5724 */
#define   ESI579      (ERRSI +  579)    /*    ci_bdy5.c:5745 */
#define   ESI580      (ERRSI +  580)    /*    ci_bdy5.c:5769 */
#define   ESI581      (ERRSI +  581)    /*    ci_bdy5.c:5854 */
#define   ESI582      (ERRSI +  582)    /*    ci_bdy5.c:5868 */
#define   ESI583      (ERRSI +  583)    /*    ci_bdy5.c:5882 */
#define   ESI584      (ERRSI +  584)    /*    ci_bdy5.c:5899 */
#define   ESI585      (ERRSI +  585)    /*    ci_bdy5.c:5915 */
#define   ESI586      (ERRSI +  586)    /*    ci_bdy5.c:5995 */
#define   ESI587      (ERRSI +  587)    /*    ci_bdy5.c:6009 */
#define   ESI588      (ERRSI +  588)    /*    ci_bdy5.c:6025 */
#define   ESI589      (ERRSI +  589)    /*    ci_bdy5.c:6079 */
#define   ESI590      (ERRSI +  590)    /*    ci_bdy5.c:6317 */
#define   ESI591      (ERRSI +  591)    /*    ci_bdy5.c:6435 */
#define   ESI592      (ERRSI +  592)    /*    ci_bdy5.c:6478 */
#define   ESI593      (ERRSI +  593)    /*    ci_bdy5.c:6538 */
#define   ESI594      (ERRSI +  594)    /*    ci_bdy5.c:6631 */
#define   ESI595      (ERRSI +  595)    /*    ci_bdy5.c:6687 */
#define   ESI596      (ERRSI +  596)    /*    ci_bdy5.c:6873 */
#define   ESI597      (ERRSI +  597)    /*    ci_bdy5.c:6888 */
#define   ESI598      (ERRSI +  598)    /*    ci_bdy5.c:6906 */
#define   ESI599      (ERRSI +  599)    /*    ci_bdy5.c:7023 */
#define   ESI600      (ERRSI +  600)    /*    ci_bdy5.c:7057 */
#define   ESI601      (ERRSI +  601)    /*    ci_bdy5.c:7077 */
#define   ESI602      (ERRSI +  602)    /*    ci_bdy5.c:7093 */
#define   ESI603      (ERRSI +  603)    /*    ci_bdy5.c:7124 */
#define   ESI604      (ERRSI +  604)    /*    ci_bdy5.c:7136 */
#define   ESI605      (ERRSI +  605)    /*    ci_bdy5.c:7216 */
#define   ESI606      (ERRSI +  606)    /*    ci_bdy5.c:7232 */
#define   ESI607      (ERRSI +  607)    /*    ci_bdy5.c:7248 */
#define   ESI608      (ERRSI +  608)    /*    ci_bdy5.c:7267 */
#define   ESI609      (ERRSI +  609)    /*    ci_bdy5.c:7296 */
#define   ESI610      (ERRSI +  610)    /*    ci_bdy5.c:7315 */
#define   ESI611      (ERRSI +  611)    /*    ci_bdy5.c:7347 */
#define   ESI612      (ERRSI +  612)    /*    ci_bdy5.c:7362 */
#define   ESI613      (ERRSI +  613)    /*    ci_bdy5.c:7384 */
#define   ESI614      (ERRSI +  614)    /*    ci_bdy5.c:7405 */
#define   ESI615      (ERRSI +  615)    /*    ci_bdy5.c:7420 */
#define   ESI616      (ERRSI +  616)    /*    ci_bdy5.c:7434 */
#define   ESI617      (ERRSI +  617)    /*    ci_bdy5.c:7509 */
#define   ESI618      (ERRSI +  618)    /*    ci_bdy5.c:7517 */
#define   ESI619      (ERRSI +  619)    /*    ci_bdy5.c:7544 */
#define   ESI620      (ERRSI +  620)    /*    ci_bdy5.c:7565 */
#define   ESI621      (ERRSI +  621)    /*    ci_bdy5.c:7581 */
#define   ESI622      (ERRSI +  622)    /*    ci_bdy5.c:7609 */
#define   ESI623      (ERRSI +  623)    /*    ci_bdy5.c:7623 */
#define   ESI624      (ERRSI +  624)    /*    ci_bdy5.c:7666 */
#define   ESI625      (ERRSI +  625)    /*    ci_bdy5.c:7685 */
#define   ESI626      (ERRSI +  626)    /*    ci_bdy5.c:7700 */
#define   ESI627      (ERRSI +  627)    /*    ci_bdy5.c:8368 */
#define   ESI628      (ERRSI +  628)    /*    ci_bdy5.c:8655 */
#define   ESI629      (ERRSI +  629)    /*    ci_bdy5.c:8679 */
#define   ESI630      (ERRSI +  630)    /*    ci_bdy5.c:8760 */
#define   ESI631      (ERRSI +  631)    /*    ci_bdy5.c:10479 */
#define   ESI632      (ERRSI +  632)    /*    ci_bdy5.c:10488 */
#define   ESI633      (ERRSI +  633)    /*    ci_bdy5.c:11077 */
#define   ESI634      (ERRSI +  634)    /*    ci_bdy5.c:11204 */
#define   ESI635      (ERRSI +  635)    /*    ci_bdy5.c:11349 */
#define   ESI636      (ERRSI +  636)    /*    ci_bdy5.c:11758 */
#define   ESI637      (ERRSI +  637)    /*    ci_bdy5.c:11931 */
#define   ESI638      (ERRSI +  638)    /*    ci_bdy5.c:11939 */
#define   ESI639      (ERRSI +  639)    /*    ci_bdy5.c:11981 */
#define   ESI640      (ERRSI +  640)    /*    ci_bdy5.c:12054 */
#define   ESI641      (ERRSI +  641)    /*    ci_bdy5.c:12063 */
#define   ESI642      (ERRSI +  642)    /*    ci_bdy5.c:12072 */
#define   ESI643      (ERRSI +  643)    /*    ci_bdy5.c:12081 */
#define   ESI644      (ERRSI +  644)    /*    ci_bdy5.c:12323 */
#define   ESI645      (ERRSI +  645)    /*    ci_bdy5.c:12375 */
#define   ESI646      (ERRSI +  646)    /*    ci_bdy5.c:12540 */
#define   ESI647      (ERRSI +  647)    /*    ci_bdy5.c:12603 */
#define   ESI648      (ERRSI +  648)    /*    ci_bdy5.c:12658 */
#define   ESI649      (ERRSI +  649)    /*    ci_bdy5.c:12668 */
#define   ESI650      (ERRSI +  650)    /*    ci_bdy5.c:12737 */
#define   ESI651      (ERRSI +  651)    /*    ci_bdy5.c:12746 */
#define   ESI652      (ERRSI +  652)    /*    ci_bdy5.c:12755 */
#define   ESI653      (ERRSI +  653)    /*    ci_bdy5.c:12805 */
#define   ESI654      (ERRSI +  654)    /*    ci_bdy5.c:12926 */
#define   ESI655      (ERRSI +  655)    /*    ci_bdy5.c:13033 */
#define   ESI656      (ERRSI +  656)    /*    ci_bdy5.c:13045 */
#define   ESI657      (ERRSI +  657)    /*    ci_bdy5.c:13101 */
#define   ESI658      (ERRSI +  658)    /*    ci_bdy5.c:13111 */
#define   ESI659      (ERRSI +  659)    /*    ci_bdy5.c:13384 */
#define   ESI660      (ERRSI +  660)    /*    ci_bdy5.c:13436 */
#define   ESI661      (ERRSI +  661)    /*    ci_bdy5.c:13551 */
#define   ESI662      (ERRSI +  662)    /*    ci_bdy5.c:13561 */
#define   ESI663      (ERRSI +  663)    /*    ci_bdy5.c:13571 */
#define   ESI664      (ERRSI +  664)    /*    ci_bdy5.c:13600 */
#define   ESI665      (ERRSI +  665)    /*    ci_bdy5.c:13644 */
#define   ESI666      (ERRSI +  666)    /*    ci_bdy5.c:13711 */
#define   ESI667      (ERRSI +  667)    /*    ci_bdy5.c:13784 */
#define   ESI668      (ERRSI +  668)    /*    ci_bdy5.c:13795 */
#define   ESI669      (ERRSI +  669)    /*    ci_bdy5.c:13923 */
#define   ESI670      (ERRSI +  670)    /*    ci_bdy5.c:14310 */
#define   ESI671      (ERRSI +  671)    /*    ci_bdy5.c:14320 */
#define   ESI672      (ERRSI +  672)    /*    ci_bdy5.c:14330 */
#define   ESI673      (ERRSI +  673)    /*    ci_bdy5.c:14474 */
#define   ESI674      (ERRSI +  674)    /*    ci_bdy5.c:14487 */
#define   ESI675      (ERRSI +  675)    /*    ci_bdy5.c:14589 */
#define   ESI676      (ERRSI +  676)    /*    ci_bdy5.c:14680 */
#define   ESI677      (ERRSI +  677)    /*    ci_bdy5.c:14702 */
#define   ESI678      (ERRSI +  678)    /*    ci_bdy5.c:14813 */
#define   ESI679      (ERRSI +  679)    /*    ci_bdy5.c:14876 */
#define   ESI680      (ERRSI +  680)    /*    ci_bdy5.c:14886 */
#define   ESI681      (ERRSI +  681)    /*    ci_bdy5.c:14988 */
#define   ESI682      (ERRSI +  682)    /*    ci_bdy5.c:15179 */
#define   ESI683      (ERRSI +  683)    /*    ci_bdy5.c:15249 */
#define   ESI684      (ERRSI +  684)    /*    ci_bdy5.c:15264 */
#define   ESI685      (ERRSI +  685)    /*    ci_bdy5.c:15403 */
#define   ESI686      (ERRSI +  686)    /*    ci_bdy5.c:15416 */
#define   ESI687      (ERRSI +  687)    /*    ci_bdy5.c:15578 */
#define   ESI688      (ERRSI +  688)    /*    ci_bdy5.c:15612 */
#define   ESI689      (ERRSI +  689)    /*    ci_bdy5.c:15629 */
#define   ESI690      (ERRSI +  690)    /*    ci_bdy5.c:15682 */
#define   ESI691      (ERRSI +  691)    /*    ci_bdy5.c:15706 */
#define   ESI692      (ERRSI +  692)    /*    ci_bdy5.c:15735 */
#define   ESI693      (ERRSI +  693)    /*    ci_bdy5.c:15757 */
#define   ESI694      (ERRSI +  694)    /*    ci_bdy5.c:15768 */
#define   ESI695      (ERRSI +  695)    /*    ci_bdy5.c:15781 */
#define   ESI696      (ERRSI +  696)    /*    ci_bdy5.c:15797 */
#define   ESI697      (ERRSI +  697)    /*    ci_bdy5.c:15844 */
#define   ESI698      (ERRSI +  698)    /*    ci_bdy5.c:15855 */
#define   ESI699      (ERRSI +  699)    /*    ci_bdy5.c:15869 */
#define   ESI700      (ERRSI +  700)    /*    ci_bdy5.c:15891 */
#define   ESI701      (ERRSI +  701)    /*    ci_bdy5.c:15934 */
#define   ESI702      (ERRSI +  702)    /*    ci_bdy5.c:15947 */
#define   ESI703      (ERRSI +  703)    /*    ci_bdy5.c:16051 */
#define   ESI704      (ERRSI +  704)    /*    ci_bdy5.c:16133 */
#define   ESI705      (ERRSI +  705)    /*    ci_bdy5.c:16157 */
#define   ESI706      (ERRSI +  706)    /*    ci_bdy5.c:16176 */
#define   ESI707      (ERRSI +  707)    /*    ci_bdy5.c:16189 */
#define   ESI708      (ERRSI +  708)    /*    ci_bdy5.c:16272 */
#define   ESI709      (ERRSI +  709)    /*    ci_bdy5.c:16283 */
#define   ESI710      (ERRSI +  710)    /*    ci_bdy5.c:16487 */
#define   ESI711      (ERRSI +  711)    /*    ci_bdy5.c:16499 */
#define   ESI712      (ERRSI +  712)    /*    ci_bdy5.c:16628 */
#define   ESI713      (ERRSI +  713)    /*    ci_bdy5.c:16698 */
#define   ESI714      (ERRSI +  714)    /*    ci_bdy5.c:16800 */
#define   ESI715      (ERRSI +  715)    /*    ci_bdy5.c:16817 */
#define   ESI716      (ERRSI +  716)    /*    ci_bdy5.c:16908 */
#define   ESI717      (ERRSI +  717)    /*    ci_bdy5.c:17007 */
#define   ESI718      (ERRSI +  718)    /*    ci_bdy5.c:17131 */
#define   ESI719      (ERRSI +  719)    /*    ci_bdy5.c:17150 */
#define   ESI720      (ERRSI +  720)    /*    ci_bdy5.c:17168 */
#define   ESI721      (ERRSI +  721)    /*    ci_bdy5.c:17184 */
#define   ESI722      (ERRSI +  722)    /*    ci_bdy5.c:17269 */
#define   ESI723      (ERRSI +  723)    /*    ci_bdy5.c:17285 */
#define   ESI724      (ERRSI +  724)    /*    ci_bdy5.c:17301 */
#define   ESI725      (ERRSI +  725)    /*    ci_bdy5.c:17320 */
#define   ESI726      (ERRSI +  726)    /*    ci_bdy5.c:17349 */
#define   ESI727      (ERRSI +  727)    /*    ci_bdy5.c:17368 */
#define   ESI728      (ERRSI +  728)    /*    ci_bdy5.c:17386 */
#define   ESI729      (ERRSI +  729)    /*    ci_bdy5.c:17399 */
#define   ESI730      (ERRSI +  730)    /*    ci_bdy5.c:17420 */
#define   ESI731      (ERRSI +  731)    /*    ci_bdy5.c:17440 */
#define   ESI732      (ERRSI +  732)    /*    ci_bdy5.c:17455 */
#define   ESI733      (ERRSI +  733)    /*    ci_bdy5.c:17469 */
#define   ESI734      (ERRSI +  734)    /*    ci_bdy5.c:17487 */
#define   ESI735      (ERRSI +  735)    /*    ci_bdy5.c:17544 */
#define   ESI736      (ERRSI +  736)    /*    ci_bdy5.c:17575 */
#define   ESI737      (ERRSI +  737)    /*    ci_bdy5.c:17589 */
#define   ESI738      (ERRSI +  738)    /*    ci_bdy5.c:17608 */
#define   ESI739      (ERRSI +  739)    /*    ci_bdy5.c:17628 */
#define   ESI740      (ERRSI +  740)    /*    ci_bdy5.c:17655 */
#define   ESI741      (ERRSI +  741)    /*    ci_bdy5.c:17669 */
#define   ESI742      (ERRSI +  742)    /*    ci_bdy5.c:17732 */
#define   ESI743      (ERRSI +  743)    /*    ci_bdy5.c:17740 */
#define   ESI744      (ERRSI +  744)    /*    ci_bdy5.c:17794 */
#define   ESI745      (ERRSI +  745)    /*    ci_bdy5.c:17843 */
#define   ESI746      (ERRSI +  746)    /*    ci_bdy5.c:17917 */
#define   ESI747      (ERRSI +  747)    /*    ci_bdy5.c:17925 */
#define   ESI748      (ERRSI +  748)    /*    ci_bdy5.c:18016 */
#define   ESI749      (ERRSI +  749)    /*    ci_bdy5.c:18024 */
#define   ESI750      (ERRSI +  750)    /*    ci_bdy5.c:18032 */
#define   ESI751      (ERRSI +  751)    /*    ci_bdy5.c:18063 */

#define   ESI752      (ERRSI +  752)    /*    ci_bdy6.c: 293 */
#define   ESI753      (ERRSI +  753)    /*    ci_bdy6.c: 311 */
#define   ESI754      (ERRSI +  754)    /*    ci_bdy6.c: 333 */
#define   ESI755      (ERRSI +  755)    /*    ci_bdy6.c: 353 */
#define   ESI756      (ERRSI +  756)    /*    ci_bdy6.c: 367 */
#define   ESI757      (ERRSI +  757)    /*    ci_bdy6.c: 388 */
#define   ESI758      (ERRSI +  758)    /*    ci_bdy6.c: 411 */
#define   ESI759      (ERRSI +  759)    /*    ci_bdy6.c: 462 */
#define   ESI760      (ERRSI +  760)    /*    ci_bdy6.c: 629 */
#define   ESI761      (ERRSI +  761)    /*    ci_bdy6.c: 645 */
#define   ESI762      (ERRSI +  762)    /*    ci_bdy6.c: 662 */
#define   ESI763      (ERRSI +  763)    /*    ci_bdy6.c: 683 */
#define   ESI764      (ERRSI +  764)    /*    ci_bdy6.c: 797 */
#define   ESI765      (ERRSI +  765)    /*    ci_bdy6.c: 819 */
#define   ESI766      (ERRSI +  766)    /*    ci_bdy6.c: 838 */
#define   ESI767      (ERRSI +  767)    /*    ci_bdy6.c: 905 */
#define   ESI768      (ERRSI +  768)    /*    ci_bdy6.c:1034 */
#define   ESI769      (ERRSI +  769)    /*    ci_bdy6.c:1171 */
#define   ESI770      (ERRSI +  770)    /*    ci_bdy6.c:1196 */
#define   ESI771      (ERRSI +  771)    /*    ci_bdy6.c:1214 */
#define   ESI772      (ERRSI +  772)    /*    ci_bdy6.c:1230 */
#define   ESI773      (ERRSI +  773)    /*    ci_bdy6.c:1271 */
#define   ESI774      (ERRSI +  774)    /*    ci_bdy6.c:1287 */
#define   ESI775      (ERRSI +  775)    /*    ci_bdy6.c:1305 */
#define   ESI776      (ERRSI +  776)    /*    ci_bdy6.c:1454 */
#define   ESI777      (ERRSI +  777)    /*    ci_bdy6.c:1469 */
#define   ESI778      (ERRSI +  778)    /*    ci_bdy6.c:1491 */
#define   ESI779      (ERRSI +  779)    /*    ci_bdy6.c:1517 */
#define   ESI780      (ERRSI +  780)    /*    ci_bdy6.c:1533 */
#define   ESI781      (ERRSI +  781)    /*    ci_bdy6.c:1549 */
#define   ESI782      (ERRSI +  782)    /*    ci_bdy6.c:1567 */
#define   ESI783      (ERRSI +  783)    /*    ci_bdy6.c:1583 */
#define   ESI784      (ERRSI +  784)    /*    ci_bdy6.c:1625 */
#define   ESI785      (ERRSI +  785)    /*    ci_bdy6.c:1663 */
#define   ESI786      (ERRSI +  786)    /*    ci_bdy6.c:1680 */
#define   ESI787      (ERRSI +  787)    /*    ci_bdy6.c:1701 */
#define   ESI788      (ERRSI +  788)    /*    ci_bdy6.c:1729 */
#define   ESI789      (ERRSI +  789)    /*    ci_bdy6.c:1782 */
#define   ESI790      (ERRSI +  790)    /*    ci_bdy6.c:1798 */
#define   ESI791      (ERRSI +  791)    /*    ci_bdy6.c:1885 */
#define   ESI792      (ERRSI +  792)    /*    ci_bdy6.c:1962 */
#define   ESI793      (ERRSI +  793)    /*    ci_bdy6.c:1977 */
#define   ESI794      (ERRSI +  794)    /*    ci_bdy6.c:1996 */
#define   ESI795      (ERRSI +  795)    /*    ci_bdy6.c:2082 */
#define   ESI796      (ERRSI +  796)    /*    ci_bdy6.c:2241 */
#define   ESI797      (ERRSI +  797)    /*    ci_bdy6.c:2299 */
#define   ESI798      (ERRSI +  798)    /*    ci_bdy6.c:2400 */
#define   ESI799      (ERRSI +  799)    /*    ci_bdy6.c:2552 */
#define   ESI800      (ERRSI +  800)    /*    ci_bdy6.c:2569 */
#define   ESI801      (ERRSI +  801)    /*    ci_bdy6.c:2693 */
#define   ESI802      (ERRSI +  802)    /*    ci_bdy6.c:2706 */
#define   ESI803      (ERRSI +  803)    /*    ci_bdy6.c:2772 */
#define   ESI804      (ERRSI +  804)    /*    ci_bdy6.c:2787 */
#define   ESI805      (ERRSI +  805)    /*    ci_bdy6.c:3051 */
#define   ESI806      (ERRSI +  806)    /*    ci_bdy6.c:3194 */
#define   ESI807      (ERRSI +  807)    /*    ci_bdy6.c:4270 */
#define   ESI808      (ERRSI +  808)    /*    ci_bdy6.c:4281 */
#define   ESI809      (ERRSI +  809)    /*    ci_bdy6.c:4292 */
#define   ESI810      (ERRSI +  810)    /*    ci_bdy6.c:4309 */
#define   ESI811      (ERRSI +  811)    /*    ci_bdy6.c:4321 */
#define   ESI812      (ERRSI +  812)    /*    ci_bdy6.c:4390 */
#define   ESI813      (ERRSI +  813)    /*    ci_bdy6.c:4470 */
#define   ESI814      (ERRSI +  814)    /*    ci_bdy6.c:4492 */
#define   ESI815      (ERRSI +  815)    /*    ci_bdy6.c:4687 */
#define   ESI816      (ERRSI +  816)    /*    ci_bdy6.c:4749 */
#define   ESI817      (ERRSI +  817)    /*    ci_bdy6.c:5041 */
#define   ESI818      (ERRSI +  818)    /*    ci_bdy6.c:5640 */
#define   ESI819      (ERRSI +  819)    /*    ci_bdy6.c:5698 */
#define   ESI820      (ERRSI +  820)    /*    ci_bdy6.c:5771 */
#define   ESI821      (ERRSI +  821)    /*    ci_bdy6.c:6971 */

#define   ESI822      (ERRSI +  822)    /*    ci_bdy7.c: 326 */
#define   ESI823      (ERRSI +  823)    /*    ci_bdy7.c: 344 */
#define   ESI824      (ERRSI +  824)    /*    ci_bdy7.c: 537 */
#define   ESI825      (ERRSI +  825)    /*    ci_bdy7.c: 673 */
#define   ESI826      (ERRSI +  826)    /*    ci_bdy7.c: 781 */
#define   ESI827      (ERRSI +  827)    /*    ci_bdy7.c: 827 */
#define   ESI828      (ERRSI +  828)    /*    ci_bdy7.c: 937 */
#define   ESI829      (ERRSI +  829)    /*    ci_bdy7.c: 984 */
#define   ESI830      (ERRSI +  830)    /*    ci_bdy7.c:1093 */
#define   ESI831      (ERRSI +  831)    /*    ci_bdy7.c:1122 */
#define   ESI832      (ERRSI +  832)    /*    ci_bdy7.c:1529 */
#define   ESI833      (ERRSI +  833)    /*    ci_bdy7.c:1617 */
#define   ESI834      (ERRSI +  834)    /*    ci_bdy7.c:1691 */
#define   ESI835      (ERRSI +  835)    /*    ci_bdy7.c:1910 */
#define   ESI836      (ERRSI +  836)    /*    ci_bdy7.c:2309 */
#define   ESI837      (ERRSI +  837)    /*    ci_bdy7.c:2482 */
#define   ESI838      (ERRSI +  838)    /*    ci_bdy7.c:2584 */
#define   ESI839      (ERRSI +  839)    /*    ci_bdy7.c:3053 */

#define   ESI840      (ERRSI +  840)    /*   ci_ex_ms.c: 483 */

#define   ESI841      (ERRSI +  841)    /*    si_acc1.c:1004 */
#define   ESI842      (ERRSI +  842)    /*    si_acc1.c:1008 */
#define   ESI843      (ERRSI +  843)    /*    si_acc1.c:1017 */
#define   ESI844      (ERRSI +  844)    /*    si_acc1.c:1020 */
#define   ESI845      (ERRSI +  845)    /*    si_acc1.c:1029 */
#define   ESI846      (ERRSI +  846)    /*    si_acc1.c:1032 */
#define   ESI847      (ERRSI +  847)    /*    si_acc1.c:1036 */

#define   ESI848      (ERRSI +  848)    /*    si_bdy1.c: 425 */
#define   ESI849      (ERRSI +  849)    /*    si_bdy1.c: 448 */
#define   ESI850      (ERRSI +  850)    /*    si_bdy1.c: 484 */
#define   ESI851      (ERRSI +  851)    /*    si_bdy1.c: 577 */
#define   ESI852      (ERRSI +  852)    /*    si_bdy1.c: 603 */
#define   ESI853      (ERRSI +  853)    /*    si_bdy1.c: 896 */
#define   ESI854      (ERRSI +  854)    /*    si_bdy1.c:1129 */
#define   ESI855      (ERRSI +  855)    /*    si_bdy1.c:1153 */
#define   ESI856      (ERRSI +  856)    /*    si_bdy1.c:1333 */
#define   ESI857      (ERRSI +  857)    /*    si_bdy1.c:1471 */
#define   ESI858      (ERRSI +  858)    /*    si_bdy1.c:1493 */
#define   ESI859      (ERRSI +  859)    /*    si_bdy1.c:1724 */
#define   ESI860      (ERRSI +  860)    /*    si_bdy1.c:1802 */
#define   ESI861      (ERRSI +  861)    /*    si_bdy1.c:1919 */
#define   ESI862      (ERRSI +  862)    /*    si_bdy1.c:1944 */
#define   ESI863      (ERRSI +  863)    /*    si_bdy1.c:2215 */
#define   ESI864      (ERRSI +  864)    /*    si_bdy1.c:2336 */
#define   ESI865      (ERRSI +  865)    /*    si_bdy1.c:2361 */
#define   ESI866      (ERRSI +  866)    /*    si_bdy1.c:2511 */
#define   ESI867      (ERRSI +  867)    /*    si_bdy1.c:2625 */
#define   ESI868      (ERRSI +  868)    /*    si_bdy1.c:2650 */
#define   ESI869      (ERRSI +  869)    /*    si_bdy1.c:2845 */
#define   ESI870      (ERRSI +  870)    /*    si_bdy1.c:2960 */
#define   ESI871      (ERRSI +  871)    /*    si_bdy1.c:2986 */
#define   ESI872      (ERRSI +  872)    /*    si_bdy1.c:3243 */
#define   ESI873      (ERRSI +  873)    /*    si_bdy1.c:3407 */
#define   ESI874      (ERRSI +  874)    /*    si_bdy1.c:3432 */
#define   ESI875      (ERRSI +  875)    /*    si_bdy1.c:3706 */
#define   ESI876      (ERRSI +  876)    /*    si_bdy1.c:3835 */
#define   ESI877      (ERRSI +  877)    /*    si_bdy1.c:3860 */
#define   ESI878      (ERRSI +  878)    /*    si_bdy1.c:4059 */
#define   ESI879      (ERRSI +  879)    /*    si_bdy1.c:4168 */
#define   ESI880      (ERRSI +  880)    /*    si_bdy1.c:4379 */
#define   ESI881      (ERRSI +  881)    /*    si_bdy1.c:4582 */
#define   ESI882      (ERRSI +  882)    /*    si_bdy1.c:4769 */
#define   ESI883      (ERRSI +  883)    /*    si_bdy1.c:4817 */
#define   ESI884      (ERRSI +  884)    /*    si_bdy1.c:4902 */
#define   ESI885      (ERRSI +  885)    /*    si_bdy1.c:4928 */
#define   ESI886      (ERRSI +  886)    /*    si_bdy1.c:5125 */
#define   ESI887      (ERRSI +  887)    /*    si_bdy1.c:5238 */
#define   ESI888      (ERRSI +  888)    /*    si_bdy1.c:5263 */
#define   ESI889      (ERRSI +  889)    /*    si_bdy1.c:5460 */
#define   ESI890      (ERRSI +  890)    /*    si_bdy1.c:5579 */
#define   ESI891      (ERRSI +  891)    /*    si_bdy1.c:5604 */
#define   ESI892      (ERRSI +  892)    /*    si_bdy1.c:5720 */
#define   ESI893      (ERRSI +  893)    /*    si_bdy1.c:5753 */
#define   ESI894      (ERRSI +  894)    /*    si_bdy1.c:5785 */
#define   ESI895      (ERRSI +  895)    /*    si_bdy1.c:5848 */
#define   ESI896      (ERRSI +  896)    /*    si_bdy1.c:5896 */
#define   ESI897      (ERRSI +  897)    /*    si_bdy1.c:5944 */
#define   ESI898      (ERRSI +  898)    /*    si_bdy1.c:6062 */
#define   ESI899      (ERRSI +  899)    /*    si_bdy1.c:6096 */
#define   ESI900      (ERRSI +  900)    /*    si_bdy1.c:6222 */
#define   ESI901      (ERRSI +  901)    /*    si_bdy1.c:6307 */
#define   ESI902      (ERRSI +  902)    /*    si_bdy1.c:6317 */
#define   ESI903      (ERRSI +  903)    /*    si_bdy1.c:6354 */
#define   ESI904      (ERRSI +  904)    /*    si_bdy1.c:6412 */
#define   ESI905      (ERRSI +  905)    /*    si_bdy1.c:6435 */
#define   ESI906      (ERRSI +  906)    /*    si_bdy1.c:6523 */
#define   ESI907      (ERRSI +  907)    /*    si_bdy1.c:6542 */
#define   ESI908      (ERRSI +  908)    /*    si_bdy1.c:6561 */
#define   ESI909      (ERRSI +  909)    /*    si_bdy1.c:6666 */
#define   ESI910      (ERRSI +  910)    /*    si_bdy1.c:6694 */
#define   ESI911      (ERRSI +  911)    /*    si_bdy1.c:6721 */
#define   ESI912      (ERRSI +  912)    /*    si_bdy1.c:6744 */
#define   ESI913      (ERRSI +  913)    /*    si_bdy1.c:7028 */
#define   ESI914      (ERRSI +  914)    /*    si_bdy1.c:7055 */
#define   ESI915      (ERRSI +  915)    /*    si_bdy1.c:7109 */
#define   ESI916      (ERRSI +  916)    /*    si_bdy1.c:7120 */
#define   ESI917      (ERRSI +  917)    /*    si_bdy1.c:7233 */
#define   ESI918      (ERRSI +  918)    /*    si_bdy1.c:7404 */
#define   ESI919      (ERRSI +  919)    /*    si_bdy1.c:7436 */
#define   ESI920      (ERRSI +  920)    /*    si_bdy1.c:7510 */
#define   ESI921      (ERRSI +  921)    /*    si_bdy1.c:7521 */
#define   ESI922      (ERRSI +  922)    /*    si_bdy1.c:7612 */
#define   ESI923      (ERRSI +  923)    /*    si_bdy1.c:7647 */
#define   ESI924      (ERRSI +  924)    /*    si_bdy1.c:7663 */
#define   ESI925      (ERRSI +  925)    /*    si_bdy1.c:8250 */
#define   ESI926      (ERRSI +  926)    /*    si_bdy1.c:8431 */
#define   ESI927      (ERRSI +  927)    /*    si_bdy1.c:8449 */
#define   ESI928      (ERRSI +  928)    /*    si_bdy1.c:8476 */
#define   ESI929      (ERRSI +  929)    /*    si_bdy1.c:8494 */
#define   ESI930      (ERRSI +  930)    /*    si_bdy1.c:8911 */
#define   ESI931      (ERRSI +  931)    /*    si_bdy1.c:8936 */
#define   ESI932      (ERRSI +  932)    /*    si_bdy1.c:9038 */
#define   ESI933      (ERRSI +  933)    /*    si_bdy1.c:9061 */
#define   ESI934      (ERRSI +  934)    /*    si_bdy1.c:9160 */
#define   ESI935      (ERRSI +  935)    /*    si_bdy1.c:9187 */
#define   ESI936      (ERRSI +  936)    /*    si_bdy1.c:9216 */
#define   ESI937      (ERRSI +  937)    /*    si_bdy1.c:9566 */
#define   ESI938      (ERRSI +  938)    /*    si_bdy1.c:9634 */
#define   ESI939      (ERRSI +  939)    /*    si_bdy1.c:9700 */
#define   ESI940      (ERRSI +  940)    /*    si_bdy1.c:9772 */
#define   ESI941      (ERRSI +  941)    /*    si_bdy1.c:9838 */
#define   ESI942      (ERRSI +  942)    /*    si_bdy1.c:9906 */
#define   ESI943      (ERRSI +  943)    /*    si_bdy1.c:9930 */
#define   ESI944      (ERRSI +  944)    /*    si_bdy1.c:9985 */
#define   ESI945      (ERRSI +  945)    /*    si_bdy1.c:10037 */
#define   ESI946      (ERRSI +  946)    /*    si_bdy1.c:10065 */
#define   ESI947      (ERRSI +  947)    /*    si_bdy1.c:10132 */
#define   ESI948      (ERRSI +  948)    /*    si_bdy1.c:10186 */
#define   ESI949      (ERRSI +  949)    /*    si_bdy1.c:10207 */
#define   ESI950      (ERRSI +  950)    /*    si_bdy1.c:10241 */
#define   ESI951      (ERRSI +  951)    /*    si_bdy1.c:10288 */
#define   ESI952      (ERRSI +  952)    /*    si_bdy1.c:10374 */
#define   ESI953      (ERRSI +  953)    /*    si_bdy1.c:10408 */
#define   ESI954      (ERRSI +  954)    /*    si_bdy1.c:10455 */
#define   ESI955      (ERRSI +  955)    /*    si_bdy1.c:11147 */

#define   ESI956      (ERRSI +  956)    /*    si_bdy2.c:1070 */
#define   ESI957      (ERRSI +  957)    /*    si_bdy2.c:1080 */
#define   ESI958      (ERRSI +  958)    /*    si_bdy2.c:1164 */
#define   ESI959      (ERRSI +  959)    /*    si_bdy2.c:1234 */
#define   ESI960      (ERRSI +  960)    /*    si_bdy2.c:1321 */
#define   ESI961      (ERRSI +  961)    /*    si_bdy2.c:1376 */
#define   ESI962      (ERRSI +  962)    /*    si_bdy2.c:1384 */
#define   ESI963      (ERRSI +  963)    /*    si_bdy2.c:1393 */
#define   ESI964      (ERRSI +  964)    /*    si_bdy2.c:1510 */
#define   ESI965      (ERRSI +  965)    /*    si_bdy2.c:1577 */
#define   ESI966      (ERRSI +  966)    /*    si_bdy2.c:1586 */
#define   ESI967      (ERRSI +  967)    /*    si_bdy2.c:1595 */
#define   ESI968      (ERRSI +  968)    /*    si_bdy2.c:1712 */
#define   ESI969      (ERRSI +  969)    /*    si_bdy2.c:1790 */
#define   ESI970      (ERRSI +  970)    /*    si_bdy2.c:1799 */
#define   ESI971      (ERRSI +  971)    /*    si_bdy2.c:1913 */
#define   ESI972      (ERRSI +  972)    /*    si_bdy2.c:1978 */
#define   ESI973      (ERRSI +  973)    /*    si_bdy2.c:1987 */
#define   ESI974      (ERRSI +  974)    /*    si_bdy2.c:2090 */
#define   ESI975      (ERRSI +  975)    /*    si_bdy2.c:2148 */
#define   ESI976      (ERRSI +  976)    /*    si_bdy2.c:2211 */
#define   ESI977      (ERRSI +  977)    /*    si_bdy2.c:2319 */
#define   ESI978      (ERRSI +  978)    /*    si_bdy2.c:2328 */
#define   ESI979      (ERRSI +  979)    /*    si_bdy2.c:2508 */
#define   ESI980      (ERRSI +  980)    /*    si_bdy2.c:2517 */
#define   ESI981      (ERRSI +  981)    /*    si_bdy2.c:2583 */
#define   ESI982      (ERRSI +  982)    /*    si_bdy2.c:2632 */
#define   ESI983      (ERRSI +  983)    /*    si_bdy2.c:2772 */
#define   ESI984      (ERRSI +  984)    /*    si_bdy2.c:2781 */
#define   ESI985      (ERRSI +  985)    /*    si_bdy2.c:2871 */
#define   ESI986      (ERRSI +  986)    /*    si_bdy2.c:2880 */
#define   ESI987      (ERRSI +  987)    /*    si_bdy2.c:2974 */
#define   ESI988      (ERRSI +  988)    /*    si_bdy2.c:2983 */
#define   ESI989      (ERRSI +  989)    /*    si_bdy2.c:3106 */
#define   ESI990      (ERRSI +  990)    /*    si_bdy2.c:3115 */
#define   ESI991      (ERRSI +  991)    /*    si_bdy2.c:3177 */
#define   ESI992      (ERRSI +  992)    /*    si_bdy2.c:3186 */
#define   ESI993      (ERRSI +  993)    /*    si_bdy2.c:3275 */
#define   ESI994      (ERRSI +  994)    /*    si_bdy2.c:3395 */
#define   ESI995      (ERRSI +  995)    /*    si_bdy2.c:3450 */
#define   ESI996      (ERRSI +  996)    /*    si_bdy2.c:3459 */
#define   ESI997      (ERRSI +  997)    /*    si_bdy2.c:3566 */
#define   ESI998      (ERRSI +  998)    /*    si_bdy2.c:3639 */
#define   ESI999      (ERRSI +  999)    /*    si_bdy2.c:3650 */
#define   ESI1000      (ERRSI + 1000)    /*    si_bdy2.c:3818 */
#define   ESI1001      (ERRSI + 1001)    /*    si_bdy2.c:3842 */
#define   ESI1002      (ERRSI + 1002)    /*    si_bdy2.c:3894 */
#define   ESI1003      (ERRSI + 1003)    /*    si_bdy2.c:3911 */
#define   ESI1004      (ERRSI + 1004)    /*    si_bdy2.c:4089 */
#define   ESI1005      (ERRSI + 1005)    /*    si_bdy2.c:4176 */
#define   ESI1006      (ERRSI + 1006)    /*    si_bdy2.c:4363 */
#define   ESI1007      (ERRSI + 1007)    /*    si_bdy2.c:4372 */
#define   ESI1008      (ERRSI + 1008)    /*    si_bdy2.c:4391 */
#define   ESI1009      (ERRSI + 1009)    /*    si_bdy2.c:4430 */
#define   ESI1010      (ERRSI + 1010)    /*    si_bdy2.c:4445 */
#define   ESI1011      (ERRSI + 1011)    /*    si_bdy2.c:4487 */
#define   ESI1012      (ERRSI + 1012)    /*    si_bdy2.c:4505 */
#define   ESI1013      (ERRSI + 1013)    /*    si_bdy2.c:4610 */
#define   ESI1014      (ERRSI + 1014)    /*    si_bdy2.c:4664 */
#define   ESI1015      (ERRSI + 1015)    /*    si_bdy2.c:4717 */
#define   ESI1016      (ERRSI + 1016)    /*    si_bdy2.c:4792 */
#define   ESI1017      (ERRSI + 1017)    /*    si_bdy2.c:4906 */
#define   ESI1018      (ERRSI + 1018)    /*    si_bdy2.c:4915 */
#define   ESI1019      (ERRSI + 1019)    /*    si_bdy2.c:5026 */
#define   ESI1020      (ERRSI + 1020)    /*    si_bdy2.c:5211 */
#define   ESI1021      (ERRSI + 1021)    /*    si_bdy2.c:5258 */
#define   ESI1022      (ERRSI + 1022)    /*    si_bdy2.c:5267 */
#define   ESI1023      (ERRSI + 1023)    /*    si_bdy2.c:5368 */
#define   ESI1024      (ERRSI + 1024)    /*    si_bdy2.c:5377 */
#define   ESI1025      (ERRSI + 1025)    /*    si_bdy2.c:5446 */
#define   ESI1026      (ERRSI + 1026)    /*    si_bdy2.c:5490 */
#define   ESI1027      (ERRSI + 1027)    /*    si_bdy2.c:5545 */
#define   ESI1028      (ERRSI + 1028)    /*    si_bdy2.c:5554 */
#define   ESI1029      (ERRSI + 1029)    /*    si_bdy2.c:5618 */
#define   ESI1030      (ERRSI + 1030)    /*    si_bdy2.c:5627 */
#define   ESI1031      (ERRSI + 1031)    /*    si_bdy2.c:5726 */
#define   ESI1032      (ERRSI + 1032)    /*    si_bdy2.c:5860 */
#define   ESI1033      (ERRSI + 1033)    /*    si_bdy2.c:5946 */
#define   ESI1034      (ERRSI + 1034)    /*    si_bdy2.c:6021 */
#define   ESI1035      (ERRSI + 1035)    /*    si_bdy2.c:6030 */
#define   ESI1036      (ERRSI + 1036)    /*    si_bdy2.c:6094 */
#define   ESI1037      (ERRSI + 1037)    /*    si_bdy2.c:6103 */
#define   ESI1038      (ERRSI + 1038)    /*    si_bdy2.c:6208 */
#define   ESI1039      (ERRSI + 1039)    /*    si_bdy2.c:6254 */
#define   ESI1040      (ERRSI + 1040)    /*    si_bdy2.c:6263 */
#define   ESI1041      (ERRSI + 1041)    /*    si_bdy2.c:6357 */
#define   ESI1042      (ERRSI + 1042)    /*    si_bdy2.c:6366 */
#define   ESI1043      (ERRSI + 1043)    /*    si_bdy2.c:6423 */
#define   ESI1044      (ERRSI + 1044)    /*    si_bdy2.c:6432 */
#define   ESI1045      (ERRSI + 1045)    /*    si_bdy2.c:6523 */
#define   ESI1046      (ERRSI + 1046)    /*    si_bdy2.c:6532 */
#define   ESI1047      (ERRSI + 1047)    /*    si_bdy2.c:6619 */
#define   ESI1048      (ERRSI + 1048)    /*    si_bdy2.c:6628 */
#define   ESI1049      (ERRSI + 1049)    /*    si_bdy2.c:6720 */
#define   ESI1050      (ERRSI + 1050)    /*    si_bdy2.c:6750 */
#define   ESI1051      (ERRSI + 1051)    /*    si_bdy2.c:6762 */
#define   ESI1052      (ERRSI + 1052)    /*    si_bdy2.c:6841 */
#define   ESI1053      (ERRSI + 1053)    /*    si_bdy2.c:6961 */
#define   ESI1054      (ERRSI + 1054)    /*    si_bdy2.c:7012 */
#define   ESI1055      (ERRSI + 1055)    /*    si_bdy2.c:7021 */
#define   ESI1056      (ERRSI + 1056)    /*    si_bdy2.c:7031 */
#define   ESI1057      (ERRSI + 1057)    /*    si_bdy2.c:7117 */
#define   ESI1058      (ERRSI + 1058)    /*    si_bdy2.c:7196 */
#define   ESI1059      (ERRSI + 1059)    /*    si_bdy2.c:7205 */
#define   ESI1060      (ERRSI + 1060)    /*    si_bdy2.c:7215 */
#define   ESI1061      (ERRSI + 1061)    /*    si_bdy2.c:7239 */
#define   ESI1062      (ERRSI + 1062)    /*    si_bdy2.c:7342 */
#define   ESI1063      (ERRSI + 1063)    /*    si_bdy2.c:7351 */
#define   ESI1064      (ERRSI + 1064)    /*    si_bdy2.c:7361 */
#define   ESI1065      (ERRSI + 1065)    /*    si_bdy2.c:7505 */
#define   ESI1066      (ERRSI + 1066)    /*    si_bdy2.c:7678 */
#define   ESI1067      (ERRSI + 1067)    /*    si_bdy2.c:7687 */
#define   ESI1068      (ERRSI + 1068)    /*    si_bdy2.c:7697 */
#define   ESI1069      (ERRSI + 1069)    /*    si_bdy2.c:7940 */
#define   ESI1070      (ERRSI + 1070)    /*    si_bdy2.c:7972 */
#define   ESI1071      (ERRSI + 1071)    /*    si_bdy2.c:8075 */
#define   ESI1072      (ERRSI + 1072)    /*    si_bdy2.c:8246 */
#define   ESI1073      (ERRSI + 1073)    /*    si_bdy2.c:8255 */
#define   ESI1074      (ERRSI + 1074)    /*    si_bdy2.c:8265 */
#define   ESI1075      (ERRSI + 1075)    /*    si_bdy2.c:8584 */
#define   ESI1076      (ERRSI + 1076)    /*    si_bdy2.c:8615 */
#define   ESI1077      (ERRSI + 1077)    /*    si_bdy2.c:8807 */
#define   ESI1078      (ERRSI + 1078)    /*    si_bdy2.c:8816 */
#define   ESI1079      (ERRSI + 1079)    /*    si_bdy2.c:8826 */
#define   ESI1080      (ERRSI + 1080)    /*    si_bdy2.c:9035 */
#define   ESI1081      (ERRSI + 1081)    /*    si_bdy2.c:9308 */
#define   ESI1082      (ERRSI + 1082)    /*    si_bdy2.c:9340 */
#define   ESI1083      (ERRSI + 1083)    /*    si_bdy2.c:9519 */
#define   ESI1084      (ERRSI + 1084)    /*    si_bdy2.c:9528 */
#define   ESI1085      (ERRSI + 1085)    /*    si_bdy2.c:9538 */
#define   ESI1086      (ERRSI + 1086)    /*    si_bdy2.c:9670 */
#define   ESI1087      (ERRSI + 1087)    /*    si_bdy2.c:9679 */
#define   ESI1088      (ERRSI + 1088)    /*    si_bdy2.c:9689 */
#define   ESI1089      (ERRSI + 1089)    /*    si_bdy2.c:9809 */
#define   ESI1090      (ERRSI + 1090)    /*    si_bdy2.c:9818 */
#define   ESI1091      (ERRSI + 1091)    /*    si_bdy2.c:9828 */
#define   ESI1092      (ERRSI + 1092)    /*    si_bdy2.c:9986 */
#define   ESI1093      (ERRSI + 1093)    /*    si_bdy2.c:10046 */
#define   ESI1094      (ERRSI + 1094)    /*    si_bdy2.c:10052 */
#define   ESI1095      (ERRSI + 1095)    /*    si_bdy2.c:10072 */
#define   ESI1096      (ERRSI + 1096)    /*    si_bdy2.c:10190 */
#define   ESI1097      (ERRSI + 1097)    /*    si_bdy2.c:10237 */
#define   ESI1098      (ERRSI + 1098)    /*    si_bdy2.c:10248 */
#define   ESI1099      (ERRSI + 1099)    /*    si_bdy2.c:10267 */
#define   ESI1100      (ERRSI + 1100)    /*    si_bdy2.c:10346 */
#define   ESI1101      (ERRSI + 1101)    /*    si_bdy2.c:10355 */
#define   ESI1102      (ERRSI + 1102)    /*    si_bdy2.c:10371 */
#define   ESI1103      (ERRSI + 1103)    /*    si_bdy2.c:10437 */
#define   ESI1104      (ERRSI + 1104)    /*    si_bdy2.c:10446 */
#define   ESI1105      (ERRSI + 1105)    /*    si_bdy2.c:10456 */
#define   ESI1106      (ERRSI + 1106)    /*    si_bdy2.c:10470 */
#define   ESI1107      (ERRSI + 1107)    /*    si_bdy2.c:10562 */
#define   ESI1108      (ERRSI + 1108)    /*    si_bdy2.c:10627 */
#define   ESI1109      (ERRSI + 1109)    /*    si_bdy2.c:10636 */
#define   ESI1110      (ERRSI + 1110)    /*    si_bdy2.c:10652 */
#define   ESI1111      (ERRSI + 1111)    /*    si_bdy2.c:10726 */
#define   ESI1112      (ERRSI + 1112)    /*    si_bdy2.c:10735 */
#define   ESI1113      (ERRSI + 1113)    /*    si_bdy2.c:10744 */
#define   ESI1114      (ERRSI + 1114)    /*    si_bdy2.c:10785 */
#define   ESI1115      (ERRSI + 1115)    /*    si_bdy2.c:10799 */
#define   ESI1116      (ERRSI + 1116)    /*    si_bdy2.c:10813 */
#define   ESI1117      (ERRSI + 1117)    /*    si_bdy2.c:10831 */
#define   ESI1118      (ERRSI + 1118)    /*    si_bdy2.c:10935 */
#define   ESI1119      (ERRSI + 1119)    /*    si_bdy2.c:10944 */
#define   ESI1120      (ERRSI + 1120)    /*    si_bdy2.c:10953 */
#define   ESI1121      (ERRSI + 1121)    /*    si_bdy2.c:11048 */
#define   ESI1122      (ERRSI + 1122)    /*    si_bdy2.c:11057 */
#define   ESI1123      (ERRSI + 1123)    /*    si_bdy2.c:11066 */
#define   ESI1124      (ERRSI + 1124)    /*    si_bdy2.c:11166 */
#define   ESI1125      (ERRSI + 1125)    /*    si_bdy2.c:11175 */
#define   ESI1126      (ERRSI + 1126)    /*    si_bdy2.c:11184 */
#define   ESI1127      (ERRSI + 1127)    /*    si_bdy2.c:11272 */
#define   ESI1128      (ERRSI + 1128)    /*    si_bdy2.c:11281 */
#define   ESI1129      (ERRSI + 1129)    /*    si_bdy2.c:11290 */
#define   ESI1130      (ERRSI + 1130)    /*    si_bdy2.c:11465 */
#define   ESI1131      (ERRSI + 1131)    /*    si_bdy2.c:11474 */
#define   ESI1132      (ERRSI + 1132)    /*    si_bdy2.c:11483 */
#define   ESI1133      (ERRSI + 1133)    /*    si_bdy2.c:11526 */
#define   ESI1134      (ERRSI + 1134)    /*    si_bdy2.c:11540 */
#define   ESI1135      (ERRSI + 1135)    /*    si_bdy2.c:11668 */
#define   ESI1136      (ERRSI + 1136)    /*    si_bdy2.c:11680 */
#define   ESI1137      (ERRSI + 1137)    /*    si_bdy2.c:11778 */
#define   ESI1138      (ERRSI + 1138)    /*    si_bdy2.c:11787 */
#define   ESI1139      (ERRSI + 1139)    /*    si_bdy2.c:11796 */
#define   ESI1140      (ERRSI + 1140)    /*    si_bdy2.c:11937 */
#define   ESI1141      (ERRSI + 1141)    /*    si_bdy2.c:11946 */
#define   ESI1142      (ERRSI + 1142)    /*    si_bdy2.c:12003 */
#define   ESI1143      (ERRSI + 1143)    /*    si_bdy2.c:12144 */
#define   ESI1144      (ERRSI + 1144)    /*    si_bdy2.c:12257 */
#define   ESI1145      (ERRSI + 1145)    /*    si_bdy2.c:12303 */
#define   ESI1146      (ERRSI + 1146)    /*    si_bdy2.c:12385 */
#define   ESI1147      (ERRSI + 1147)    /*    si_bdy2.c:12436 */
#define   ESI1148      (ERRSI + 1148)    /*    si_bdy2.c:12482 */
#define   ESI1149      (ERRSI + 1149)    /*    si_bdy2.c:12563 */

#define   ESI1150      (ERRSI + 1150)    /*    si_bdy3.c:1161 */
#define   ESI1151      (ERRSI + 1151)    /*    si_bdy3.c:1171 */
#define   ESI1152      (ERRSI + 1152)    /*    si_bdy3.c:1181 */
#define   ESI1153      (ERRSI + 1153)    /*    si_bdy3.c:1294 */
#define   ESI1154      (ERRSI + 1154)    /*    si_bdy3.c:1348 */
#define   ESI1155      (ERRSI + 1155)    /*    si_bdy3.c:1357 */
#define   ESI1156      (ERRSI + 1156)    /*    si_bdy3.c:1492 */
#define   ESI1157      (ERRSI + 1157)    /*    si_bdy3.c:1599 */
#define   ESI1158      (ERRSI + 1158)    /*    si_bdy3.c:1608 */
#define   ESI1159      (ERRSI + 1159)    /*    si_bdy3.c:1754 */
#define   ESI1160      (ERRSI + 1160)    /*    si_bdy3.c:1763 */
#define   ESI1161      (ERRSI + 1161)    /*    si_bdy3.c:1898 */
#define   ESI1162      (ERRSI + 1162)    /*    si_bdy3.c:2015 */
#define   ESI1163      (ERRSI + 1163)    /*    si_bdy3.c:2024 */
#define   ESI1164      (ERRSI + 1164)    /*    si_bdy3.c:2151 */
#define   ESI1165      (ERRSI + 1165)    /*    si_bdy3.c:2219 */
#define   ESI1166      (ERRSI + 1166)    /*    si_bdy3.c:2228 */
#define   ESI1167      (ERRSI + 1167)    /*    si_bdy3.c:2237 */
#define   ESI1168      (ERRSI + 1168)    /*    si_bdy3.c:2364 */
#define   ESI1169      (ERRSI + 1169)    /*    si_bdy3.c:2446 */
#define   ESI1170      (ERRSI + 1170)    /*    si_bdy3.c:2455 */
#define   ESI1171      (ERRSI + 1171)    /*    si_bdy3.c:2580 */
#define   ESI1172      (ERRSI + 1172)    /*    si_bdy3.c:2644 */
#define   ESI1173      (ERRSI + 1173)    /*    si_bdy3.c:2653 */
#define   ESI1174      (ERRSI + 1174)    /*    si_bdy3.c:2715 */
#define   ESI1175      (ERRSI + 1175)    /*    si_bdy3.c:2724 */
#define   ESI1176      (ERRSI + 1176)    /*    si_bdy3.c:2798 */
#define   ESI1177      (ERRSI + 1177)    /*    si_bdy3.c:2807 */
#define   ESI1178      (ERRSI + 1178)    /*    si_bdy3.c:2915 */
#define   ESI1179      (ERRSI + 1179)    /*    si_bdy3.c:2973 */
#define   ESI1180      (ERRSI + 1180)    /*    si_bdy3.c:2982 */
#define   ESI1181      (ERRSI + 1181)    /*    si_bdy3.c:3058 */
#define   ESI1182      (ERRSI + 1182)    /*    si_bdy3.c:3067 */
#define   ESI1183      (ERRSI + 1183)    /*    si_bdy3.c:3169 */
#define   ESI1184      (ERRSI + 1184)    /*    si_bdy3.c:3258 */
#define   ESI1185      (ERRSI + 1185)    /*    si_bdy3.c:3267 */
#define   ESI1186      (ERRSI + 1186)    /*    si_bdy3.c:3372 */
#define   ESI1187      (ERRSI + 1187)    /*    si_bdy3.c:3381 */
#define   ESI1188      (ERRSI + 1188)    /*    si_bdy3.c:3498 */
#define   ESI1189      (ERRSI + 1189)    /*    si_bdy3.c:3507 */
#define   ESI1190      (ERRSI + 1190)    /*    si_bdy3.c:3649 */
#define   ESI1191      (ERRSI + 1191)    /*    si_bdy3.c:3658 */
#define   ESI1192      (ERRSI + 1192)    /*    si_bdy3.c:3774 */
#define   ESI1193      (ERRSI + 1193)    /*    si_bdy3.c:3832 */
#define   ESI1194      (ERRSI + 1194)    /*    si_bdy3.c:3841 */
#define   ESI1195      (ERRSI + 1195)    /*    si_bdy3.c:3944 */
#define   ESI1196      (ERRSI + 1196)    /*    si_bdy3.c:4001 */
#define   ESI1197      (ERRSI + 1197)    /*    si_bdy3.c:4010 */
#define   ESI1198      (ERRSI + 1198)    /*    si_bdy3.c:4019 */
#define   ESI1199      (ERRSI + 1199)    /*    si_bdy3.c:4118 */
#define   ESI1200      (ERRSI + 1200)    /*    si_bdy3.c:4127 */
#define   ESI1201      (ERRSI + 1201)    /*    si_bdy3.c:4136 */
#define   ESI1202      (ERRSI + 1202)    /*    si_bdy3.c:4378 */
#define   ESI1203      (ERRSI + 1203)    /*    si_bdy3.c:4387 */
#define   ESI1204      (ERRSI + 1204)    /*    si_bdy3.c:4396 */
#define   ESI1205      (ERRSI + 1205)    /*    si_bdy3.c:4471 */
#define   ESI1206      (ERRSI + 1206)    /*    si_bdy3.c:4570 */
#define   ESI1207      (ERRSI + 1207)    /*    si_bdy3.c:4579 */
#define   ESI1208      (ERRSI + 1208)    /*    si_bdy3.c:4692 */
#define   ESI1209      (ERRSI + 1209)    /*    si_bdy3.c:4701 */
#define   ESI1210      (ERRSI + 1210)    /*    si_bdy3.c:4710 */
#define   ESI1211      (ERRSI + 1211)    /*    si_bdy3.c:4887 */
#define   ESI1212      (ERRSI + 1212)    /*    si_bdy3.c:4934 */
#define   ESI1213      (ERRSI + 1213)    /*    si_bdy3.c:4943 */
#define   ESI1214      (ERRSI + 1214)    /*    si_bdy3.c:5047 */
#define   ESI1215      (ERRSI + 1215)    /*    si_bdy3.c:5056 */
#define   ESI1216      (ERRSI + 1216)    /*    si_bdy3.c:5065 */
#define   ESI1217      (ERRSI + 1217)    /*    si_bdy3.c:5122 */
#define   ESI1218      (ERRSI + 1218)    /*    si_bdy3.c:5174 */
#define   ESI1219      (ERRSI + 1219)    /*    si_bdy3.c:5183 */
#define   ESI1220      (ERRSI + 1220)    /*    si_bdy3.c:5192 */
#define   ESI1221      (ERRSI + 1221)    /*    si_bdy3.c:5243 */
#define   ESI1222      (ERRSI + 1222)    /*    si_bdy3.c:5297 */
#define   ESI1223      (ERRSI + 1223)    /*    si_bdy3.c:5306 */
#define   ESI1224      (ERRSI + 1224)    /*    si_bdy3.c:5315 */
#define   ESI1225      (ERRSI + 1225)    /*    si_bdy3.c:5373 */
#define   ESI1226      (ERRSI + 1226)    /*    si_bdy3.c:5418 */
#define   ESI1227      (ERRSI + 1227)    /*    si_bdy3.c:5427 */
#define   ESI1228      (ERRSI + 1228)    /*    si_bdy3.c:5525 */
#define   ESI1229      (ERRSI + 1229)    /*    si_bdy3.c:5534 */
#define   ESI1230      (ERRSI + 1230)    /*    si_bdy3.c:5639 */
#define   ESI1231      (ERRSI + 1231)    /*    si_bdy3.c:5776 */
#define   ESI1232      (ERRSI + 1232)    /*    si_bdy3.c:5782 */
#define   ESI1233      (ERRSI + 1233)    /*    si_bdy3.c:5872 */
#define   ESI1234      (ERRSI + 1234)    /*    si_bdy3.c:5945 */
#define   ESI1235      (ERRSI + 1235)    /*    si_bdy3.c:5954 */
#define   ESI1236      (ERRSI + 1236)    /*    si_bdy3.c:6015 */
#define   ESI1237      (ERRSI + 1237)    /*    si_bdy3.c:6024 */
#define   ESI1238      (ERRSI + 1238)    /*    si_bdy3.c:6033 */
#define   ESI1239      (ERRSI + 1239)    /*    si_bdy3.c:6097 */
#define   ESI1240      (ERRSI + 1240)    /*    si_bdy3.c:6146 */
#define   ESI1241      (ERRSI + 1241)    /*    si_bdy3.c:6155 */
#define   ESI1242      (ERRSI + 1242)    /*    si_bdy3.c:6164 */
#define   ESI1243      (ERRSI + 1243)    /*    si_bdy3.c:6225 */
#define   ESI1244      (ERRSI + 1244)    /*    si_bdy3.c:6272 */
#define   ESI1245      (ERRSI + 1245)    /*    si_bdy3.c:6281 */
#define   ESI1246      (ERRSI + 1246)    /*    si_bdy3.c:6375 */
#define   ESI1247      (ERRSI + 1247)    /*    si_bdy3.c:6384 */
#define   ESI1248      (ERRSI + 1248)    /*    si_bdy3.c:6483 */
#define   ESI1249      (ERRSI + 1249)    /*    si_bdy3.c:6492 */
#define   ESI1250      (ERRSI + 1250)    /*    si_bdy3.c:6588 */
#define   ESI1251      (ERRSI + 1251)    /*    si_bdy3.c:6597 */
#define   ESI1252      (ERRSI + 1252)    /*    si_bdy3.c:6681 */
#define   ESI1253      (ERRSI + 1253)    /*    si_bdy3.c:6690 */
#define   ESI1254      (ERRSI + 1254)    /*    si_bdy3.c:6699 */
#define   ESI1255      (ERRSI + 1255)    /*    si_bdy3.c:6833 */
#define   ESI1256      (ERRSI + 1256)    /*    si_bdy3.c:6842 */
#define   ESI1257      (ERRSI + 1257)    /*    si_bdy3.c:6851 */
#define   ESI1258      (ERRSI + 1258)    /*    si_bdy3.c:6919 */
#define   ESI1259      (ERRSI + 1259)    /*    si_bdy3.c:6965 */
#define   ESI1260      (ERRSI + 1260)    /*    si_bdy3.c:6974 */
#define   ESI1261      (ERRSI + 1261)    /*    si_bdy3.c:6983 */
#define   ESI1262      (ERRSI + 1262)    /*    si_bdy3.c:7026 */
#define   ESI1263      (ERRSI + 1263)    /*    si_bdy3.c:7088 */
#define   ESI1264      (ERRSI + 1264)    /*    si_bdy3.c:7097 */
#define   ESI1265      (ERRSI + 1265)    /*    si_bdy3.c:7106 */
#define   ESI1266      (ERRSI + 1266)    /*    si_bdy3.c:7212 */
#define   ESI1267      (ERRSI + 1267)    /*    si_bdy3.c:7277 */
#define   ESI1268      (ERRSI + 1268)    /*    si_bdy3.c:7291 */
#define   ESI1269      (ERRSI + 1269)    /*    si_bdy3.c:7532 */
#define   ESI1270      (ERRSI + 1270)    /*    si_bdy3.c:7709 */
#define   ESI1271      (ERRSI + 1271)    /*    si_bdy3.c:7718 */
#define   ESI1272      (ERRSI + 1272)    /*    si_bdy3.c:7727 */
#define   ESI1273      (ERRSI + 1273)    /*    si_bdy3.c:7799 */
#define   ESI1274      (ERRSI + 1274)    /*    si_bdy3.c:7910 */
#define   ESI1275      (ERRSI + 1275)    /*    si_bdy3.c:8003 */
#define   ESI1276      (ERRSI + 1276)    /*    si_bdy3.c:8012 */
#define   ESI1277      (ERRSI + 1277)    /*    si_bdy3.c:8021 */
#define   ESI1278      (ERRSI + 1278)    /*    si_bdy3.c:8226 */
#define   ESI1279      (ERRSI + 1279)    /*    si_bdy3.c:8422 */
#define   ESI1280      (ERRSI + 1280)    /*    si_bdy3.c:8481 */
#define   ESI1281      (ERRSI + 1281)    /*    si_bdy3.c:8490 */
#define   ESI1282      (ERRSI + 1282)    /*    si_bdy3.c:8499 */
#define   ESI1283      (ERRSI + 1283)    /*    si_bdy3.c:9127 */
#define   ESI1284      (ERRSI + 1284)    /*    si_bdy3.c:9190 */
#define   ESI1285      (ERRSI + 1285)    /*    si_bdy3.c:9199 */
#define   ESI1286      (ERRSI + 1286)    /*    si_bdy3.c:9208 */
#define   ESI1287      (ERRSI + 1287)    /*    si_bdy3.c:9250 */
#define   ESI1288      (ERRSI + 1288)    /*    si_bdy3.c:9335 */
#define   ESI1289      (ERRSI + 1289)    /*    si_bdy3.c:9344 */
#define   ESI1290      (ERRSI + 1290)    /*    si_bdy3.c:9353 */
#define   ESI1291      (ERRSI + 1291)    /*    si_bdy3.c:9550 */
#define   ESI1292      (ERRSI + 1292)    /*    si_bdy3.c:9613 */
#define   ESI1293      (ERRSI + 1293)    /*    si_bdy3.c:9622 */
#define   ESI1294      (ERRSI + 1294)    /*    si_bdy3.c:9631 */
#define   ESI1295      (ERRSI + 1295)    /*    si_bdy3.c:9647 */
#define   ESI1296      (ERRSI + 1296)    /*    si_bdy3.c:9761 */
#define   ESI1297      (ERRSI + 1297)    /*    si_bdy3.c:9815 */
#define   ESI1298      (ERRSI + 1298)    /*    si_bdy3.c:9824 */
#define   ESI1299      (ERRSI + 1299)    /*    si_bdy3.c:9931 */
#define   ESI1300      (ERRSI + 1300)    /*    si_bdy3.c:9955 */
#define   ESI1301      (ERRSI + 1301)    /*    si_bdy3.c:10007 */
#define   ESI1302      (ERRSI + 1302)    /*    si_bdy3.c:10016 */
#define   ESI1303      (ERRSI + 1303)    /*    si_bdy3.c:10125 */
#define   ESI1304      (ERRSI + 1304)    /*    si_bdy3.c:10149 */
#define   ESI1305      (ERRSI + 1305)    /*    si_bdy3.c:10195 */
#define   ESI1306      (ERRSI + 1306)    /*    si_bdy3.c:10204 */
#define   ESI1307      (ERRSI + 1307)    /*    si_bdy3.c:10216 */
#define   ESI1308      (ERRSI + 1308)    /*    si_bdy3.c:10276 */
#define   ESI1309      (ERRSI + 1309)    /*    si_bdy3.c:10285 */
#define   ESI1310      (ERRSI + 1310)    /*    si_bdy3.c:10296 */
#define   ESI1311      (ERRSI + 1311)    /*    si_bdy3.c:10360 */
#define   ESI1312      (ERRSI + 1312)    /*    si_bdy3.c:10369 */
#define   ESI1313      (ERRSI + 1313)    /*    si_bdy3.c:10378 */
#define   ESI1314      (ERRSI + 1314)    /*    si_bdy3.c:10390 */
#define   ESI1315      (ERRSI + 1315)    /*    si_bdy3.c:10484 */
#define   ESI1316      (ERRSI + 1316)    /*    si_bdy3.c:10551 */
#define   ESI1317      (ERRSI + 1317)    /*    si_bdy3.c:10560 */
#define   ESI1318      (ERRSI + 1318)    /*    si_bdy3.c:10571 */
#define   ESI1319      (ERRSI + 1319)    /*    si_bdy3.c:10641 */
#define   ESI1320      (ERRSI + 1320)    /*    si_bdy3.c:10647 */
#define   ESI1321      (ERRSI + 1321)    /*    si_bdy3.c:10656 */
#define   ESI1322      (ERRSI + 1322)    /*    si_bdy3.c:10700 */
#define   ESI1323      (ERRSI + 1323)    /*    si_bdy3.c:10714 */
#define   ESI1324      (ERRSI + 1324)    /*    si_bdy3.c:10728 */
#define   ESI1325      (ERRSI + 1325)    /*    si_bdy3.c:10746 */
#define   ESI1326      (ERRSI + 1326)    /*    si_bdy3.c:10849 */
#define   ESI1327      (ERRSI + 1327)    /*    si_bdy3.c:10858 */
#define   ESI1328      (ERRSI + 1328)    /*    si_bdy3.c:10867 */
#define   ESI1329      (ERRSI + 1329)    /*    si_bdy3.c:10941 */
#define   ESI1330      (ERRSI + 1330)    /*    si_bdy3.c:10950 */
#define   ESI1331      (ERRSI + 1331)    /*    si_bdy3.c:10959 */
#define   ESI1332      (ERRSI + 1332)    /*    si_bdy3.c:11038 */
#define   ESI1333      (ERRSI + 1333)    /*    si_bdy3.c:11047 */
#define   ESI1334      (ERRSI + 1334)    /*    si_bdy3.c:11056 */
#define   ESI1335      (ERRSI + 1335)    /*    si_bdy3.c:11145 */
#define   ESI1336      (ERRSI + 1336)    /*    si_bdy3.c:11154 */
#define   ESI1337      (ERRSI + 1337)    /*    si_bdy3.c:11163 */
#define   ESI1338      (ERRSI + 1338)    /*    si_bdy3.c:11241 */
#define   ESI1339      (ERRSI + 1339)    /*    si_bdy3.c:11335 */
#define   ESI1340      (ERRSI + 1340)    /*    si_bdy3.c:11344 */
#define   ESI1341      (ERRSI + 1341)    /*    si_bdy3.c:11353 */
#define   ESI1342      (ERRSI + 1342)    /*    si_bdy3.c:11391 */
#define   ESI1343      (ERRSI + 1343)    /*    si_bdy3.c:11405 */
#define   ESI1344      (ERRSI + 1344)    /*    si_bdy3.c:11535 */
#define   ESI1345      (ERRSI + 1345)    /*    si_bdy3.c:11544 */
#define   ESI1346      (ERRSI + 1346)    /*    si_bdy3.c:11553 */
#define   ESI1347      (ERRSI + 1347)    /*    si_bdy3.c:11629 */
#define   ESI1348      (ERRSI + 1348)    /*    si_bdy3.c:11686 */
#define   ESI1349      (ERRSI + 1349)    /*    si_bdy3.c:11736 */
#define   ESI1350      (ERRSI + 1350)    /*    si_bdy3.c:11745 */
#define   ESI1351      (ERRSI + 1351)    /*    si_bdy3.c:11754 */
#define   ESI1352      (ERRSI + 1352)    /*    si_bdy3.c:11926 */
#define   ESI1353      (ERRSI + 1353)    /*    si_bdy3.c:11935 */
#define   ESI1354      (ERRSI + 1354)    /*    si_bdy3.c:11944 */
#define   ESI1355      (ERRSI + 1355)    /*    si_bdy3.c:12026 */
#define   ESI1356      (ERRSI + 1356)    /*    si_bdy3.c:12125 */
#define   ESI1357      (ERRSI + 1357)    /*    si_bdy3.c:12134 */
#define   ESI1358      (ERRSI + 1358)    /*    si_bdy3.c:12257 */
#define   ESI1359      (ERRSI + 1359)    /*    si_bdy3.c:12394 */
#define   ESI1360      (ERRSI + 1360)    /*    si_bdy3.c:12455 */
#define   ESI1361      (ERRSI + 1361)    /*    si_bdy3.c:12464 */
#define   ESI1362      (ERRSI + 1362)    /*    si_bdy3.c:12473 */
#define   ESI1363      (ERRSI + 1363)    /*    si_bdy3.c:12577 */
#define   ESI1364      (ERRSI + 1364)    /*    si_bdy3.c:12586 */
#define   ESI1365      (ERRSI + 1365)    /*    si_bdy3.c:12595 */

#define   ESI1366      (ERRSI + 1366)    /*    si_bdy4.c:1257 */
#define   ESI1367      (ERRSI + 1367)    /*    si_bdy4.c:1443 */
#define   ESI1368      (ERRSI + 1368)    /*    si_bdy4.c:1535 */
#define   ESI1369      (ERRSI + 1369)    /*    si_bdy4.c:1658 */
#define   ESI1370      (ERRSI + 1370)    /*    si_bdy4.c:1683 */
#define   ESI1371      (ERRSI + 1371)    /*    si_bdy4.c:1754 */
#define   ESI1372      (ERRSI + 1372)    /*    si_bdy4.c:1981 */
#define   ESI1373      (ERRSI + 1373)    /*    si_bdy4.c:2050 */
#define   ESI1374      (ERRSI + 1374)    /*    si_bdy4.c:2110 */
#define   ESI1375      (ERRSI + 1375)    /*    si_bdy4.c:2163 */
#define   ESI1376      (ERRSI + 1376)    /*    si_bdy4.c:2197 */
#define   ESI1377      (ERRSI + 1377)    /*    si_bdy4.c:2236 */
#define   ESI1378      (ERRSI + 1378)    /*    si_bdy4.c:2513 */
#define   ESI1379      (ERRSI + 1379)    /*    si_bdy4.c:2660 */
#define   ESI1380      (ERRSI + 1380)    /*    si_bdy4.c:7014 */
#define   ESI1381      (ERRSI + 1381)    /*    si_bdy4.c:7168 */
#define   ESI1382      (ERRSI + 1382)    /*    si_bdy4.c:7499 */
#define   ESI1383      (ERRSI + 1383)    /*    si_bdy4.c:7507 */
#define   ESI1384      (ERRSI + 1384)    /*    si_bdy4.c:7870 */
#define   ESI1385      (ERRSI + 1385)    /*    si_bdy4.c:8183 */
#define   ESI1386      (ERRSI + 1386)    /*    si_bdy4.c:8282 */
#define   ESI1387      (ERRSI + 1387)    /*    si_bdy4.c:8672 */
#define   ESI1388      (ERRSI + 1388)    /*    si_bdy4.c:8883 */
#define   ESI1389      (ERRSI + 1389)    /*    si_bdy4.c:8982 */
#define   ESI1390      (ERRSI + 1390)    /*    si_bdy4.c:9594 */
#define   ESI1391      (ERRSI + 1391)    /*    si_bdy4.c:9605 */
#define   ESI1392      (ERRSI + 1392)    /*    si_bdy4.c:9631 */
#define   ESI1393      (ERRSI + 1393)    /*    si_bdy4.c:10387 */
#define   ESI1394      (ERRSI + 1394)    /*    si_bdy4.c:10562 */
#define   ESI1395      (ERRSI + 1395)    /*    si_bdy4.c:10569 */
#define   ESI1396      (ERRSI + 1396)    /*    si_bdy4.c:11041 */
#define   ESI1397      (ERRSI + 1397)    /*    si_bdy4.c:11451 */
#define   ESI1398      (ERRSI + 1398)    /*    si_bdy4.c:11520 */
#define   ESI1399      (ERRSI + 1399)    /*    si_bdy4.c:11532 */
#define   ESI1400      (ERRSI + 1400)    /*    si_bdy4.c:11546 */
#define   ESI1401      (ERRSI + 1401)    /*    si_bdy4.c:11561 */
#define   ESI1402      (ERRSI + 1402)    /*    si_bdy4.c:13120 */
#define   ESI1403      (ERRSI + 1403)    /*    si_bdy4.c:13132 */

#define   ESI1404      (ERRSI + 1404)    /*    si_bdy5.c:1144 */
#define   ESI1405      (ERRSI + 1405)    /*    si_bdy5.c:1160 */
#define   ESI1406      (ERRSI + 1406)    /*    si_bdy5.c:1179 */
#define   ESI1407      (ERRSI + 1407)    /*    si_bdy5.c:1266 */
#define   ESI1408      (ERRSI + 1408)    /*    si_bdy5.c:1280 */
#define   ESI1409      (ERRSI + 1409)    /*    si_bdy5.c:1295 */
#define   ESI1410      (ERRSI + 1410)    /*    si_bdy5.c:1422 */
#define   ESI1411      (ERRSI + 1411)    /*    si_bdy5.c:1497 */
#define   ESI1412      (ERRSI + 1412)    /*    si_bdy5.c:1772 */
#define   ESI1413      (ERRSI + 1413)    /*    si_bdy5.c:1861 */
#define   ESI1414      (ERRSI + 1414)    /*    si_bdy5.c:1874 */
#define   ESI1415      (ERRSI + 1415)    /*    si_bdy5.c:2957 */
#define   ESI1416      (ERRSI + 1416)    /*    si_bdy5.c:3118 */
#define   ESI1417      (ERRSI + 1417)    /*    si_bdy5.c:5176 */
#define   ESI1418      (ERRSI + 1418)    /*    si_bdy5.c:5190 */
#define   ESI1419      (ERRSI + 1419)    /*    si_bdy5.c:5258 */
#define   ESI1420      (ERRSI + 1420)    /*    si_bdy5.c:5272 */
#define   ESI1421      (ERRSI + 1421)    /*    si_bdy5.c:5458 */
#define   ESI1422      (ERRSI + 1422)    /*    si_bdy5.c:5564 */
#define   ESI1423      (ERRSI + 1423)    /*    si_bdy5.c:5611 */
#define   ESI1424      (ERRSI + 1424)    /*    si_bdy5.c:5710 */
#define   ESI1425      (ERRSI + 1425)    /*    si_bdy5.c:5724 */
#define   ESI1426      (ERRSI + 1426)    /*    si_bdy5.c:5745 */
#define   ESI1427      (ERRSI + 1427)    /*    si_bdy5.c:5769 */
#define   ESI1428      (ERRSI + 1428)    /*    si_bdy5.c:5854 */
#define   ESI1429      (ERRSI + 1429)    /*    si_bdy5.c:5868 */
#define   ESI1430      (ERRSI + 1430)    /*    si_bdy5.c:5882 */
#define   ESI1431      (ERRSI + 1431)    /*    si_bdy5.c:5899 */
#define   ESI1432      (ERRSI + 1432)    /*    si_bdy5.c:5915 */
#define   ESI1433      (ERRSI + 1433)    /*    si_bdy5.c:5995 */
#define   ESI1434      (ERRSI + 1434)    /*    si_bdy5.c:6009 */
#define   ESI1435      (ERRSI + 1435)    /*    si_bdy5.c:6025 */
#define   ESI1436      (ERRSI + 1436)    /*    si_bdy5.c:6079 */
#define   ESI1437      (ERRSI + 1437)    /*    si_bdy5.c:6317 */
#define   ESI1438      (ERRSI + 1438)    /*    si_bdy5.c:6435 */
#define   ESI1439      (ERRSI + 1439)    /*    si_bdy5.c:6478 */
#define   ESI1440      (ERRSI + 1440)    /*    si_bdy5.c:6538 */
#define   ESI1441      (ERRSI + 1441)    /*    si_bdy5.c:6631 */
#define   ESI1442      (ERRSI + 1442)    /*    si_bdy5.c:6687 */
#define   ESI1443      (ERRSI + 1443)    /*    si_bdy5.c:6873 */
#define   ESI1444      (ERRSI + 1444)    /*    si_bdy5.c:6888 */
#define   ESI1445      (ERRSI + 1445)    /*    si_bdy5.c:6906 */
#define   ESI1446      (ERRSI + 1446)    /*    si_bdy5.c:7023 */
#define   ESI1447      (ERRSI + 1447)    /*    si_bdy5.c:7057 */
#define   ESI1448      (ERRSI + 1448)    /*    si_bdy5.c:7077 */
#define   ESI1449      (ERRSI + 1449)    /*    si_bdy5.c:7093 */
#define   ESI1450      (ERRSI + 1450)    /*    si_bdy5.c:7124 */
#define   ESI1451      (ERRSI + 1451)    /*    si_bdy5.c:7136 */
#define   ESI1452      (ERRSI + 1452)    /*    si_bdy5.c:7216 */
#define   ESI1453      (ERRSI + 1453)    /*    si_bdy5.c:7232 */
#define   ESI1454      (ERRSI + 1454)    /*    si_bdy5.c:7248 */
#define   ESI1455      (ERRSI + 1455)    /*    si_bdy5.c:7267 */
#define   ESI1456      (ERRSI + 1456)    /*    si_bdy5.c:7296 */
#define   ESI1457      (ERRSI + 1457)    /*    si_bdy5.c:7315 */
#define   ESI1458      (ERRSI + 1458)    /*    si_bdy5.c:7347 */
#define   ESI1459      (ERRSI + 1459)    /*    si_bdy5.c:7362 */
#define   ESI1460      (ERRSI + 1460)    /*    si_bdy5.c:7384 */
#define   ESI1461      (ERRSI + 1461)    /*    si_bdy5.c:7405 */
#define   ESI1462      (ERRSI + 1462)    /*    si_bdy5.c:7420 */
#define   ESI1463      (ERRSI + 1463)    /*    si_bdy5.c:7434 */
#define   ESI1464      (ERRSI + 1464)    /*    si_bdy5.c:7509 */
#define   ESI1465      (ERRSI + 1465)    /*    si_bdy5.c:7517 */
#define   ESI1466      (ERRSI + 1466)    /*    si_bdy5.c:7544 */
#define   ESI1467      (ERRSI + 1467)    /*    si_bdy5.c:7565 */
#define   ESI1468      (ERRSI + 1468)    /*    si_bdy5.c:7581 */
#define   ESI1469      (ERRSI + 1469)    /*    si_bdy5.c:7609 */
#define   ESI1470      (ERRSI + 1470)    /*    si_bdy5.c:7623 */
#define   ESI1471      (ERRSI + 1471)    /*    si_bdy5.c:7666 */
#define   ESI1472      (ERRSI + 1472)    /*    si_bdy5.c:7685 */
#define   ESI1473      (ERRSI + 1473)    /*    si_bdy5.c:7700 */
#define   ESI1474      (ERRSI + 1474)    /*    si_bdy5.c:8368 */
#define   ESI1475      (ERRSI + 1475)    /*    si_bdy5.c:8655 */
#define   ESI1476      (ERRSI + 1476)    /*    si_bdy5.c:8679 */
#define   ESI1477      (ERRSI + 1477)    /*    si_bdy5.c:8760 */
#define   ESI1478      (ERRSI + 1478)    /*    si_bdy5.c:10479 */
#define   ESI1479      (ERRSI + 1479)    /*    si_bdy5.c:10488 */
#define   ESI1480      (ERRSI + 1480)    /*    si_bdy5.c:11077 */
#define   ESI1481      (ERRSI + 1481)    /*    si_bdy5.c:11204 */
#define   ESI1482      (ERRSI + 1482)    /*    si_bdy5.c:11349 */
#define   ESI1483      (ERRSI + 1483)    /*    si_bdy5.c:11758 */
#define   ESI1484      (ERRSI + 1484)    /*    si_bdy5.c:11931 */
#define   ESI1485      (ERRSI + 1485)    /*    si_bdy5.c:11939 */
#define   ESI1486      (ERRSI + 1486)    /*    si_bdy5.c:11981 */
#define   ESI1487      (ERRSI + 1487)    /*    si_bdy5.c:12054 */
#define   ESI1488      (ERRSI + 1488)    /*    si_bdy5.c:12063 */
#define   ESI1489      (ERRSI + 1489)    /*    si_bdy5.c:12072 */
#define   ESI1490      (ERRSI + 1490)    /*    si_bdy5.c:12081 */
#define   ESI1491      (ERRSI + 1491)    /*    si_bdy5.c:12323 */
#define   ESI1492      (ERRSI + 1492)    /*    si_bdy5.c:12375 */
#define   ESI1493      (ERRSI + 1493)    /*    si_bdy5.c:12540 */
#define   ESI1494      (ERRSI + 1494)    /*    si_bdy5.c:12603 */
#define   ESI1495      (ERRSI + 1495)    /*    si_bdy5.c:12658 */
#define   ESI1496      (ERRSI + 1496)    /*    si_bdy5.c:12668 */
#define   ESI1497      (ERRSI + 1497)    /*    si_bdy5.c:12737 */
#define   ESI1498      (ERRSI + 1498)    /*    si_bdy5.c:12746 */
#define   ESI1499      (ERRSI + 1499)    /*    si_bdy5.c:12755 */
#define   ESI1500      (ERRSI + 1500)    /*    si_bdy5.c:12805 */
#define   ESI1501      (ERRSI + 1501)    /*    si_bdy5.c:12926 */
#define   ESI1502      (ERRSI + 1502)    /*    si_bdy5.c:13033 */
#define   ESI1503      (ERRSI + 1503)    /*    si_bdy5.c:13045 */
#define   ESI1504      (ERRSI + 1504)    /*    si_bdy5.c:13101 */
#define   ESI1505      (ERRSI + 1505)    /*    si_bdy5.c:13111 */
#define   ESI1506      (ERRSI + 1506)    /*    si_bdy5.c:13384 */
#define   ESI1507      (ERRSI + 1507)    /*    si_bdy5.c:13436 */
#define   ESI1508      (ERRSI + 1508)    /*    si_bdy5.c:13551 */
#define   ESI1509      (ERRSI + 1509)    /*    si_bdy5.c:13561 */
#define   ESI1510      (ERRSI + 1510)    /*    si_bdy5.c:13571 */
#define   ESI1511      (ERRSI + 1511)    /*    si_bdy5.c:13600 */
#define   ESI1512      (ERRSI + 1512)    /*    si_bdy5.c:13644 */
#define   ESI1513      (ERRSI + 1513)    /*    si_bdy5.c:13711 */
#define   ESI1514      (ERRSI + 1514)    /*    si_bdy5.c:13784 */
#define   ESI1515      (ERRSI + 1515)    /*    si_bdy5.c:13795 */
#define   ESI1516      (ERRSI + 1516)    /*    si_bdy5.c:13923 */
#define   ESI1517      (ERRSI + 1517)    /*    si_bdy5.c:14310 */
#define   ESI1518      (ERRSI + 1518)    /*    si_bdy5.c:14320 */
#define   ESI1519      (ERRSI + 1519)    /*    si_bdy5.c:14330 */
#define   ESI1520      (ERRSI + 1520)    /*    si_bdy5.c:14474 */
#define   ESI1521      (ERRSI + 1521)    /*    si_bdy5.c:14487 */
#define   ESI1522      (ERRSI + 1522)    /*    si_bdy5.c:14589 */
#define   ESI1523      (ERRSI + 1523)    /*    si_bdy5.c:14680 */
#define   ESI1524      (ERRSI + 1524)    /*    si_bdy5.c:14702 */
#define   ESI1525      (ERRSI + 1525)    /*    si_bdy5.c:14813 */
#define   ESI1526      (ERRSI + 1526)    /*    si_bdy5.c:14876 */
#define   ESI1527      (ERRSI + 1527)    /*    si_bdy5.c:14886 */
#define   ESI1528      (ERRSI + 1528)    /*    si_bdy5.c:14988 */
#define   ESI1529      (ERRSI + 1529)    /*    si_bdy5.c:15179 */
#define   ESI1530      (ERRSI + 1530)    /*    si_bdy5.c:15249 */
#define   ESI1531      (ERRSI + 1531)    /*    si_bdy5.c:15264 */
#define   ESI1532      (ERRSI + 1532)    /*    si_bdy5.c:15403 */
#define   ESI1533      (ERRSI + 1533)    /*    si_bdy5.c:15416 */
#define   ESI1534      (ERRSI + 1534)    /*    si_bdy5.c:15578 */
#define   ESI1535      (ERRSI + 1535)    /*    si_bdy5.c:15612 */
#define   ESI1536      (ERRSI + 1536)    /*    si_bdy5.c:15629 */
#define   ESI1537      (ERRSI + 1537)    /*    si_bdy5.c:15682 */
#define   ESI1538      (ERRSI + 1538)    /*    si_bdy5.c:15706 */
#define   ESI1539      (ERRSI + 1539)    /*    si_bdy5.c:15735 */
#define   ESI1540      (ERRSI + 1540)    /*    si_bdy5.c:15757 */
#define   ESI1541      (ERRSI + 1541)    /*    si_bdy5.c:15768 */
#define   ESI1542      (ERRSI + 1542)    /*    si_bdy5.c:15781 */
#define   ESI1543      (ERRSI + 1543)    /*    si_bdy5.c:15797 */
#define   ESI1544      (ERRSI + 1544)    /*    si_bdy5.c:15844 */
#define   ESI1545      (ERRSI + 1545)    /*    si_bdy5.c:15855 */
#define   ESI1546      (ERRSI + 1546)    /*    si_bdy5.c:15869 */
#define   ESI1547      (ERRSI + 1547)    /*    si_bdy5.c:15891 */
#define   ESI1548      (ERRSI + 1548)    /*    si_bdy5.c:15934 */
#define   ESI1549      (ERRSI + 1549)    /*    si_bdy5.c:15947 */
#define   ESI1550      (ERRSI + 1550)    /*    si_bdy5.c:16051 */
#define   ESI1551      (ERRSI + 1551)    /*    si_bdy5.c:16133 */
#define   ESI1552      (ERRSI + 1552)    /*    si_bdy5.c:16157 */
#define   ESI1553      (ERRSI + 1553)    /*    si_bdy5.c:16176 */
#define   ESI1554      (ERRSI + 1554)    /*    si_bdy5.c:16189 */
#define   ESI1555      (ERRSI + 1555)    /*    si_bdy5.c:16272 */
#define   ESI1556      (ERRSI + 1556)    /*    si_bdy5.c:16283 */
#define   ESI1557      (ERRSI + 1557)    /*    si_bdy5.c:16487 */
#define   ESI1558      (ERRSI + 1558)    /*    si_bdy5.c:16499 */
#define   ESI1559      (ERRSI + 1559)    /*    si_bdy5.c:16628 */
#define   ESI1560      (ERRSI + 1560)    /*    si_bdy5.c:16698 */
#define   ESI1561      (ERRSI + 1561)    /*    si_bdy5.c:16800 */
#define   ESI1562      (ERRSI + 1562)    /*    si_bdy5.c:16817 */
#define   ESI1563      (ERRSI + 1563)    /*    si_bdy5.c:16908 */
#define   ESI1564      (ERRSI + 1564)    /*    si_bdy5.c:17007 */
#define   ESI1565      (ERRSI + 1565)    /*    si_bdy5.c:17131 */
#define   ESI1566      (ERRSI + 1566)    /*    si_bdy5.c:17150 */
#define   ESI1567      (ERRSI + 1567)    /*    si_bdy5.c:17168 */
#define   ESI1568      (ERRSI + 1568)    /*    si_bdy5.c:17184 */
#define   ESI1569      (ERRSI + 1569)    /*    si_bdy5.c:17269 */
#define   ESI1570      (ERRSI + 1570)    /*    si_bdy5.c:17285 */
#define   ESI1571      (ERRSI + 1571)    /*    si_bdy5.c:17301 */
#define   ESI1572      (ERRSI + 1572)    /*    si_bdy5.c:17320 */
#define   ESI1573      (ERRSI + 1573)    /*    si_bdy5.c:17349 */
#define   ESI1574      (ERRSI + 1574)    /*    si_bdy5.c:17368 */
#define   ESI1575      (ERRSI + 1575)    /*    si_bdy5.c:17386 */
#define   ESI1576      (ERRSI + 1576)    /*    si_bdy5.c:17399 */
#define   ESI1577      (ERRSI + 1577)    /*    si_bdy5.c:17420 */
#define   ESI1578      (ERRSI + 1578)    /*    si_bdy5.c:17440 */
#define   ESI1579      (ERRSI + 1579)    /*    si_bdy5.c:17455 */
#define   ESI1580      (ERRSI + 1580)    /*    si_bdy5.c:17469 */
#define   ESI1581      (ERRSI + 1581)    /*    si_bdy5.c:17487 */
#define   ESI1582      (ERRSI + 1582)    /*    si_bdy5.c:17544 */
#define   ESI1583      (ERRSI + 1583)    /*    si_bdy5.c:17575 */
#define   ESI1584      (ERRSI + 1584)    /*    si_bdy5.c:17589 */
#define   ESI1585      (ERRSI + 1585)    /*    si_bdy5.c:17608 */
#define   ESI1586      (ERRSI + 1586)    /*    si_bdy5.c:17628 */
#define   ESI1587      (ERRSI + 1587)    /*    si_bdy5.c:17655 */
#define   ESI1588      (ERRSI + 1588)    /*    si_bdy5.c:17669 */
#define   ESI1589      (ERRSI + 1589)    /*    si_bdy5.c:17732 */
#define   ESI1590      (ERRSI + 1590)    /*    si_bdy5.c:17740 */
#define   ESI1591      (ERRSI + 1591)    /*    si_bdy5.c:17794 */
#define   ESI1592      (ERRSI + 1592)    /*    si_bdy5.c:17843 */
#define   ESI1593      (ERRSI + 1593)    /*    si_bdy5.c:17917 */
#define   ESI1594      (ERRSI + 1594)    /*    si_bdy5.c:17925 */
#define   ESI1595      (ERRSI + 1595)    /*    si_bdy5.c:18016 */
#define   ESI1596      (ERRSI + 1596)    /*    si_bdy5.c:18024 */
#define   ESI1597      (ERRSI + 1597)    /*    si_bdy5.c:18032 */
#define   ESI1598      (ERRSI + 1598)    /*    si_bdy5.c:18063 */

#define   ESI1599      (ERRSI + 1599)    /*    si_bdy6.c: 293 */
#define   ESI1600      (ERRSI + 1600)    /*    si_bdy6.c: 311 */
#define   ESI1601      (ERRSI + 1601)    /*    si_bdy6.c: 333 */
#define   ESI1602      (ERRSI + 1602)    /*    si_bdy6.c: 353 */
#define   ESI1603      (ERRSI + 1603)    /*    si_bdy6.c: 367 */
#define   ESI1604      (ERRSI + 1604)    /*    si_bdy6.c: 388 */
#define   ESI1605      (ERRSI + 1605)    /*    si_bdy6.c: 411 */
#define   ESI1606      (ERRSI + 1606)    /*    si_bdy6.c: 462 */
#define   ESI1607      (ERRSI + 1607)    /*    si_bdy6.c: 629 */
#define   ESI1608      (ERRSI + 1608)    /*    si_bdy6.c: 645 */
#define   ESI1609      (ERRSI + 1609)    /*    si_bdy6.c: 662 */
#define   ESI1610      (ERRSI + 1610)    /*    si_bdy6.c: 683 */
#define   ESI1611      (ERRSI + 1611)    /*    si_bdy6.c: 797 */
#define   ESI1612      (ERRSI + 1612)    /*    si_bdy6.c: 819 */
#define   ESI1613      (ERRSI + 1613)    /*    si_bdy6.c: 838 */
#define   ESI1614      (ERRSI + 1614)    /*    si_bdy6.c: 905 */
#define   ESI1615      (ERRSI + 1615)    /*    si_bdy6.c:1034 */
#define   ESI1616      (ERRSI + 1616)    /*    si_bdy6.c:1171 */
#define   ESI1617      (ERRSI + 1617)    /*    si_bdy6.c:1196 */
#define   ESI1618      (ERRSI + 1618)    /*    si_bdy6.c:1214 */
#define   ESI1619      (ERRSI + 1619)    /*    si_bdy6.c:1230 */
#define   ESI1620      (ERRSI + 1620)    /*    si_bdy6.c:1271 */
#define   ESI1621      (ERRSI + 1621)    /*    si_bdy6.c:1287 */
#define   ESI1622      (ERRSI + 1622)    /*    si_bdy6.c:1305 */
#define   ESI1623      (ERRSI + 1623)    /*    si_bdy6.c:1454 */
#define   ESI1624      (ERRSI + 1624)    /*    si_bdy6.c:1469 */
#define   ESI1625      (ERRSI + 1625)    /*    si_bdy6.c:1491 */
#define   ESI1626      (ERRSI + 1626)    /*    si_bdy6.c:1517 */
#define   ESI1627      (ERRSI + 1627)    /*    si_bdy6.c:1533 */
#define   ESI1628      (ERRSI + 1628)    /*    si_bdy6.c:1549 */
#define   ESI1629      (ERRSI + 1629)    /*    si_bdy6.c:1567 */
#define   ESI1630      (ERRSI + 1630)    /*    si_bdy6.c:1583 */
#define   ESI1631      (ERRSI + 1631)    /*    si_bdy6.c:1625 */
#define   ESI1632      (ERRSI + 1632)    /*    si_bdy6.c:1663 */
#define   ESI1633      (ERRSI + 1633)    /*    si_bdy6.c:1680 */
#define   ESI1634      (ERRSI + 1634)    /*    si_bdy6.c:1701 */
#define   ESI1635      (ERRSI + 1635)    /*    si_bdy6.c:1729 */
#define   ESI1636      (ERRSI + 1636)    /*    si_bdy6.c:1782 */
#define   ESI1637      (ERRSI + 1637)    /*    si_bdy6.c:1798 */
#define   ESI1638      (ERRSI + 1638)    /*    si_bdy6.c:1885 */
#define   ESI1639      (ERRSI + 1639)    /*    si_bdy6.c:1962 */
#define   ESI1640      (ERRSI + 1640)    /*    si_bdy6.c:1977 */
#define   ESI1641      (ERRSI + 1641)    /*    si_bdy6.c:1996 */
#define   ESI1642      (ERRSI + 1642)    /*    si_bdy6.c:2082 */
#define   ESI1643      (ERRSI + 1643)    /*    si_bdy6.c:2241 */
#define   ESI1644      (ERRSI + 1644)    /*    si_bdy6.c:2299 */
#define   ESI1645      (ERRSI + 1645)    /*    si_bdy6.c:2400 */
#define   ESI1646      (ERRSI + 1646)    /*    si_bdy6.c:2552 */
#define   ESI1647      (ERRSI + 1647)    /*    si_bdy6.c:2569 */
#define   ESI1648      (ERRSI + 1648)    /*    si_bdy6.c:2693 */
#define   ESI1649      (ERRSI + 1649)    /*    si_bdy6.c:2706 */
#define   ESI1650      (ERRSI + 1650)    /*    si_bdy6.c:2772 */
#define   ESI1651      (ERRSI + 1651)    /*    si_bdy6.c:2787 */
#define   ESI1652      (ERRSI + 1652)    /*    si_bdy6.c:3051 */
#define   ESI1653      (ERRSI + 1653)    /*    si_bdy6.c:3194 */
#define   ESI1654      (ERRSI + 1654)    /*    si_bdy6.c:4270 */
#define   ESI1655      (ERRSI + 1655)    /*    si_bdy6.c:4281 */
#define   ESI1656      (ERRSI + 1656)    /*    si_bdy6.c:4292 */
#define   ESI1657      (ERRSI + 1657)    /*    si_bdy6.c:4309 */
#define   ESI1658      (ERRSI + 1658)    /*    si_bdy6.c:4321 */
#define   ESI1659      (ERRSI + 1659)    /*    si_bdy6.c:4390 */
#define   ESI1660      (ERRSI + 1660)    /*    si_bdy6.c:4470 */
#define   ESI1661      (ERRSI + 1661)    /*    si_bdy6.c:4492 */
#define   ESI1662      (ERRSI + 1662)    /*    si_bdy6.c:4687 */
#define   ESI1663      (ERRSI + 1663)    /*    si_bdy6.c:4749 */
#define   ESI1664      (ERRSI + 1664)    /*    si_bdy6.c:5041 */
#define   ESI1665      (ERRSI + 1665)    /*    si_bdy6.c:5640 */
#define   ESI1666      (ERRSI + 1666)    /*    si_bdy6.c:5698 */
#define   ESI1667      (ERRSI + 1667)    /*    si_bdy6.c:5771 */
#define   ESI1668      (ERRSI + 1668)    /*    si_bdy6.c:6971 */

#define   ESI1669      (ERRSI + 1669)    /*    si_bdy7.c: 326 */
#define   ESI1670      (ERRSI + 1670)    /*    si_bdy7.c: 344 */
#define   ESI1671      (ERRSI + 1671)    /*    si_bdy7.c: 537 */
#define   ESI1672      (ERRSI + 1672)    /*    si_bdy7.c: 673 */
#define   ESI1673      (ERRSI + 1673)    /*    si_bdy7.c: 781 */
#define   ESI1674      (ERRSI + 1674)    /*    si_bdy7.c: 827 */
#define   ESI1675      (ERRSI + 1675)    /*    si_bdy7.c: 937 */
#define   ESI1676      (ERRSI + 1676)    /*    si_bdy7.c: 984 */
#define   ESI1677      (ERRSI + 1677)    /*    si_bdy7.c:1093 */
#define   ESI1678      (ERRSI + 1678)    /*    si_bdy7.c:1122 */
#define   ESI1679      (ERRSI + 1679)    /*    si_bdy7.c:1529 */
#define   ESI1680      (ERRSI + 1680)    /*    si_bdy7.c:1617 */
#define   ESI1681      (ERRSI + 1681)    /*    si_bdy7.c:1691 */
#define   ESI1682      (ERRSI + 1682)    /*    si_bdy7.c:1910 */
#define   ESI1683      (ERRSI + 1683)    /*    si_bdy7.c:2309 */
#define   ESI1684      (ERRSI + 1684)    /*    si_bdy7.c:2482 */
#define   ESI1685      (ERRSI + 1685)    /*    si_bdy7.c:2584 */
#define   ESI1686      (ERRSI + 1686)    /*    si_bdy7.c:3053 */

#define   ESI1687      (ERRSI + 1687)    /*     si_err.h: 893 */

#define   ESI1688      (ERRSI + 1688)    /*   si_ex_ms.c: 483 */

#define   ESI1689      (ERRSI + 1689)    /*    si_ptli.c: 568 */
#define   ESI1690      (ERRSI + 1690)    /*    si_ptli.c: 628 */
#define   ESI1691      (ERRSI + 1691)    /*    si_ptli.c: 673 */
#define   ESI1692      (ERRSI + 1692)    /*    si_ptli.c: 965 */
#define   ESI1693      (ERRSI + 1693)    /*    si_ptli.c:1011 */

#define   ESI1694      (ERRSI + 1694)    /*    si_ptmi.c: 668 */
#define   ESI1695      (ERRSI + 1695)    /*    si_ptmi.c: 708 */
#define   ESI1696      (ERRSI + 1696)    /*    si_ptmi.c: 751 */
#define   ESI1697      (ERRSI + 1697)    /*    si_ptmi.c: 794 */
#define   ESI1698      (ERRSI + 1698)    /*    si_ptmi.c: 836 */
#define   ESI1699      (ERRSI + 1699)    /*    si_ptmi.c: 876 */
#define   ESI1700      (ERRSI + 1700)    /*    si_ptmi.c: 914 */
#define   ESI1701      (ERRSI + 1701)    /*    si_ptmi.c: 994 */

#define   ESI1702      (ERRSI + 1702)    /*    si_ptui.c:1338 */
#define   ESI1703      (ERRSI + 1703)    /*    si_ptui.c:1399 */
#define   ESI1704      (ERRSI + 1704)    /*    si_ptui.c:1455 */
#define   ESI1705      (ERRSI + 1705)    /*    si_ptui.c:1511 */
#define   ESI1706      (ERRSI + 1706)    /*    si_ptui.c:1567 */
#define   ESI1707      (ERRSI + 1707)    /*    si_ptui.c:1626 */
#define   ESI1708      (ERRSI + 1708)    /*    si_ptui.c:1685 */
#define   ESI1709      (ERRSI + 1709)    /*    si_ptui.c:1741 */
#define   ESI1710      (ERRSI + 1710)    /*    si_ptui.c:1797 */
#define   ESI1711      (ERRSI + 1711)    /*    si_ptui.c:1853 */
#define   ESI1712      (ERRSI + 1712)    /*    si_ptui.c:1915 */
#define   ESI1713      (ERRSI + 1713)    /*    si_ptui.c:1971 */
#define   ESI1714      (ERRSI + 1714)    /*    si_ptui.c:2031 */
#define   ESI1715      (ERRSI + 1715)    /*    si_ptui.c:2083 */
#define   ESI1716      (ERRSI + 1716)    /*    si_ptui.c:2132 */

#define SILOGERROR(errCls, errCode, errVal, errDesc) \
        SLogError(siCb.init.ent, siCb.init.inst, siCb.init.procId, \
                  __FILE__, __LINE__, \
                  errCls, errCode, errVal, errDesc)

#endif

/********************************************************************30**
  
         End of file:     si_err.h@@/main/23 - Wed Mar 14 15:31:17 2001
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  bn    1. text changes
             ---  jrl   2. trillium development system checkpoint (dvs)
                           at version: 1.0.0.0

1.2          ---  bn    1. add error codes for ansi

1.3          ---  rk    1. text changes

1.4          ---  jrl   1. add error codes

1.5          ---  rhk   1. add error codes

1.6          ---  rhk   1. add error codes

1.7          ---  bn    1. add error codes

1.8          ---  bn    1. add error codes

1.9          ---  bn    1. add error codes

1.10         ---  bn    1. add error codes

1.11         ---  bn    1. add error codes

1.12         ---  bn    1. add error codes

1.13         ---  bn    1. changed error codes

1.14         ---  bn    1. changed error codes.
             ---  bn    2. defined SILOGERROR macro.
             ---  dm    3. removed ERRSI

1.15         ---  pc    1. added ETSI variant error codes.

1.16         ---  dm    1. added GT_FTZ variant error codes.

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------

1.17         ---      rh   1. used ESI1687, ESI088, ESI091, ESI898 
             ---      rh   2. new error defines for 2.12
  
1.18         ---      rh   1. text changes
  
1.19         ---      rs   1. Generated new error defines.

1.20         ---      ym   1. File header is updated to the new one.            
                           2. Error codes are regenerated and updated.
1.21         ---      dvs  1. miscellaneous changes
1.22         ---      ym   1. Error codes are updated for ISUP v2.18
/main/23     ---      hy   1. Error codes are updated for ISUP v2.19
*********************************************************************91*/
