#ifndef __SI_BINDH__

#define __SI_BINDH__


void siBndItReq(void);

#endif