/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     isup
  
     Type:     C include file
  
     Desc:     Defines required by isup.
  
     File:     si.h

     Sid:      si.h@@/main/26 - Wed Jul 25 13:20:13 2001

     Prg:      na
  
*********************************************************************21*/
  
#ifndef __SIH__
#define __SIH__ 

  
/* si001.220, ADDED: added the define dependency check for rollup */
/******************* Define dependency checks (DO NOT CHANGE !!) **********/
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#ifndef TDS_CORE2
#error "Rolling upgrade feature available in CORE II only"
#endif 
#endif

#ifdef SI_RUG
#ifndef TDS_ROLL_UPGRADE_SUPPORT
#error "SI_RUG can not be defined without TDS_ROLL_UPGRADE_SUPPORT"
#endif 
#endif

#ifdef SI_RUG
#ifndef SNT2
#error "SNT2 flag is mandatory for rolling upgrade. Please enable"
#endif 
#endif

#ifdef SI_RUG
#ifndef SPT2
#error "SPT2 flag is mandatory for rolling upgrade. Please enable"
#endif 
#endif

#ifdef SI_RUG
#ifndef SI_FTHA
#error "SI_FTHA flag is mandatory for rolling upgrade. Please enable"
#endif 
#endif

#ifdef SI_RUG
#ifndef SI_LMINT3 
#error "SI_LMINT3 flag is mandatory for rolling upgrade. Please enable"
#endif 
#endif

#ifdef SI_RUG
#ifdef SI_218_COMP 
#error "SI_218_COMP flag can't be defined for rolling upgrade. Please disable"
#endif 
#endif

#ifdef SI_RUG
#ifdef SI_OLD_DEFINES
#error "SI_OLD_DEFINES flag can't be defined for rolling upgrade. Please disable"
#endif 
#endif



/* global defines */
#if (ERRCLASS & ERRCLS_INT_PAR)
#define SIUPSAP(spId) \
   (((spId >= (SpId)siCb.genCfg.nmbSaps) || (spId < 0)) ? \
      (SiUpSAPCb *)NULLP : *(siCb.upSAPLst + spId))

#define SIMTPSAP(suId) \
   (((suId >= (SuId)siCb.genCfg.nmbNSaps) || (suId < 0)) ? \
      (SiNSAPCb *)NULLP : *(siCb.mtpSAPLst + suId))


#define SISCCPSAP(suId) \
   (((suId >= (SuId)siCb.genCfg.nmbNSaps) || (suId < 0)) ? \
      (SiNSAPCb *)NULLP : *(siCb.sccpSAPLst + suId))
#else
#define SIUPSAP(spId)   *(siCb.upSAPLst   + spId)
#define SIMTPSAP(suId)  *(siCb.mtpSAPLst  + suId)
#define SISCCPSAP(suId) *(siCb.sccpSAPLst + suId)
#endif /* ERRCLASS & ERRCLS_INT_PAR */
/* NOTE: these macros are included to improve readability of ISUP code
 * when LMINT3 and LMINT2 layer management interfaces co-exist. These
 * will be removed once LMINT2 interface support is removed
 */
#if (SI_LMINT3 || SMSI_LMINT3) 

#define SISNDLSICFGCFM(pst, cfgPtr, statusval, reasonval, oldId, oldCause) \
       { \
          cfgPtr->cfm.status = statusval; \
          cfgPtr->cfm.reason = reasonval; \
          SiMiLsiCfgCfm(pst, cfgPtr); \
       } 

#define SISNDLSICNTRLCFM(pst, cntrlPtr, statusval, reasonval, oldId, oldCause) \
       { \
          cntrlPtr->cfm.status = statusval; \
          cntrlPtr->cfm.reason = reasonval; \
          SiMiLsiCntrlCfm(pst, cntrlPtr); \
       } 

#define SISNDLSISTACFM(pst, sstaPtr, statusval, reasonval, oldId, oldCause) \
       { \
          sstaPtr->cfm.status = statusval; \
          sstaPtr->cfm.reason = reasonval; \
          SiMiLsiStaCfm(pst, sstaPtr); \
       }
 
#define SISNDLSISTSCFM(pst, stsPtr, statusval, reasonval, action, \
                       oldId, oldCause) \
       { \
          stsPtr->cfm.status = statusval; \
          stsPtr->cfm.reason = reasonval; \
          SiMiLsiStsCfm(pst, action, stsPtr); \
       }
#define SISNDLSISTAIND(smPstPtr, category, event, cause, dgnInitialized, \
                       oldId, oldCause) \
        siGenAlarmNew(smPstPtr, category, event, cause, dgnInitialized)

/* obsolete alarms : don't send these under new interface */
#define SISNDOLDLSISTAIND(smPstPtr, oldId, oldCause)

#else /* !(SI_LMINT3 || SMSI_LMINT3) */

/* NOTE:
 * In the LMINT2 interface, the confirmations for the request primitives
 * in case of errors were alarms. This is maintained in the new code
 * for backward compatibility. These won't exist after LMINT2 support
 * is taken away from ISUP.
 */
#define SISNDLSICFGCFM(pst, cfgPtr, status, reason, oldId, oldCause) \
       siGenAlarm( ((siCb.init.cfgDone == TRUE) ? &siCb.init.lmPst : pst), \
                   (CirId) oldId, oldCause);

#define SISNDLSICNTRLCFM(pst, cntrlPtr, statusval, reasonval, oldId, oldCause) \
       siGenAlarm( ((siCb.init.cfgDone == TRUE) ? &siCb.init.lmPst : pst), \
                   (CirId) oldId, oldCause);

#define SISNDLSISTACFM(pst, cntrlPtr, status, reason, oldId, oldCause) \
       siGenAlarm( ((siCb.init.cfgDone == TRUE) ? &siCb.init.lmPst : pst), \
                   (CirId) oldId, oldCause);

#define SISNDLSISTSCFM(pst, stsPtr, status, reason, action, oldId, oldCause) \
       siGenAlarm( ((siCb.init.cfgDone == TRUE) ? &siCb.init.lmPst : pst), \
                   (CirId) oldId, oldCause);

#define SISNDLSISTAIND(smPstPtr, category, event, cause, ustaDgnPtr, oldId, \
                       oldCause) \
        siGenAlarm(smPstPtr, oldId, oldCause);

/* IMPORTANT NOTE: this macro defines the alarms that will disappear 
 * eventually 
 */
#define SISNDOLDLSISTAIND(smPstPtr, oldId, oldCause) \
        siGenAlarm(smPstPtr, oldId, oldCause);

#endif /* !(SI_LMINT3 || SMSI_LMINT3) */

#define MNGT_REQ          1      /* request from layer manager */

#define CIC_LEN           2      /* length of cic field in a message */

/* direction of suspend */

#define FROM_LWR          1      /* direction from lower */
#define FROM_UPR          2      /* direction from upper */
#define FROM_GRP          3      /* group */

/* direction of request */

#define DIR_UP            0      /* direction up */
#define DIR_DOWN          1      /* direction down */

#define SI_ISUP           5      /* ISUP */

/* unequipped state */

#define CIRUNEQP          3      /* unequipped  */

/* locally blocked */

#define LOCLBLK           1      /* locally blocked */

/* masks for blocking  types */
#define MAINTBLK          0x03   /* maintenance blocking */
#define HRDWRBLK          0x30   /* hardware blocking */

/* maintenance states */
#define MTIDLE            0x00   /* maintenance idle */
#define MTLOCBLK          0x01   /* maintenance locally blocked */
#define MTRMTBLK          0x02   /* maintenance remotely blocked */
#define MTLOCRMTBLK       0x03   /* maintenance locally and remotely blocked */

/* hardware states */
#define HWIDLE            0x00   /* hardware idle */
#define HWLOCBLK          0x10   /* hardware locally blocked */
#define HWRMTBLK          0x20   /* hardware remotely blocked */
#define HWLOCRMTBLK       0x30   /* hardware locally and remotely blocked */

/* call processing states */
#define CALL_IDLE         0x0c   /* idle */
#define INCBUSY           0x04   /* incoming busy */
#define OUTBUSY           0x08   /* outgoing busy */
#define TRANS             0x00   /* transient */

/* connection states */
#define ST_IDLE           0x00   /* idle */
#define ST_WTFORCONTIN    0x01   /* waiting for continuity */
#define ST_WTFORACM       0x02   /* waiting for ACM */
#define ST_WTFORANSWR     0x03   /* waitning for answer */
#define ST_ANSWRD         0x04   /* answered */
#define ST_SUSP           0x05   /* suspended */
#define ST_WTFORRELCMP    0x06   /* waiting for rel complete */
#define ST_WTFORRELRSP    0x07   /* waiting for rel response from upper laye*/
#define ST_WTFORRLCRRS    0x08   /* waiting for reset complete */
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
#define ST_WTFORCOTIAM    0x09   /* waiting for IAM and COT */
#define ST_WTFORIAM       0x0a   /* waiting for IAM */
#define NMB_IN_CON_ST     0x0b   /* number of connection states */
#define ST_WTFORCOTCRA    0x09   /* waiting for continuity rep and CRA */
#define ST_WTFORCOTREP    0x0a   /* waiting for COT have CRA */
#define ST_WTFORCRA       0x0b   /* waiting for CRA */
#define ST_WTFORDIGS      0x0c   /* waiting for digits */
#define NMB_OUT_CON_ST    0x0d   /* number of connection states */
#else
#define NMB_IN_CON_ST     0x09   /* number of connection states */
#define NMB_OUT_CON_ST    0x09   /* number of connection states */
#endif

#define MAX_NMB_CON_ST       0x0d   /* max number of states for all variants */
/* define related to TCO 0003 */
#define SILAYERNAME "ISUP"
#define SI_STR      "\n\n------------------------------------------------------------------\n\n"
/* Macro to change the state of the connection */
/* si004.220 - Modification. Modified code to avoid possibly using variable
 * var uninitialized.
 */
#define SISTATECHNG(var,newstate) \
             {                                                                \
		var=newstate;\
		SIDBGP(SIDBGMASK_STATE, (siCb.init.prntBuf,"%s: %d -> %s [%d]\n",\
                                        #var,var,#newstate,newstate));        \
             }

#define SIDBGP(class,arg)   {DBGP(&siCb.init, SILAYERNAME, class, arg)}

#define SIRETIFNPRES(field) \
if( field == NOTPRSNT )\
{\
   SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,"%s is expected to be present.\n",\
               #field));\
   RETVALUE(RFAILED);\
}

#define SISTR2STREINCCPY(src,dst) {\
U16   i;\
if( src.pres )\
for( i=0; i<src.len; i++)\
   dst.val[dst.len++] = src.val[i];\
}

#define SISTRE2STRECPY(src,dst) {\
U16   i;\
dst.pres = src.pres;\
dst.len = src.len;\
for( i=0; i<src.len; i++)\
   dst.val[i]= src.val[i];\
}

#define SISTRE2STRCPY(src,dst,offset) {\
U16   i;\
dst.pres = src.pres;\
dst.len = src.len-offset;\
for( i=0; i<dst.len; i++)\
   dst.val[i]= src.val[i+offset];\
}


/* This macro takes the two subsystem service information fields and
   compares the Network type ids in them */
#define SICMPNT(first,second) (first == second)

/* macro to build the linkage of the invloved circuits for a 
 * non-single rate call
 */
#define BLDMRATELNK(mcir, prevcir, ctrlcir) \
{ \
   (mcir)->ctrlMultiRateCir = ctrlcir; \
   (prevcir)->nextMultiRateCir = mcir; \
   (mcir)->nextMultiRateCir = NULLP; \
}

/* defines for cb state */

#define SI_UNBND          0      /* SAP/NSAP - not bound */
#define SI_BND            1      /* SAP/NSAP - bound */
#define SI_WT_BNDCFM      2      /* NSAP - waiting for bind confirm */

#define SI_MAX_INTRETRY   2      /* maximum number of bind retries */

#define INC               1      /* incoming */
#define OUTTYPE           2      /* outgoing */

/* priority */

#define PRIORUTY_0        0      /* priority 0 */
#define PRIORUTY_1        1      /* priority 1 */ 
#define PRIORUTY_2        2      /* priority 2 */ 

/* type of alarms to manager */

#define CONG              1      /* congestion */
#define FLCTRL            2      /* flow control */
 
/* timer events */

#define TMR_T1I           0x11   /* timer 1 for incoming side */
#define TMR_T1O           0x12   /* timer 1 for outgoing side */
#define TMR_T2I           0x21   /* timer 2 for incoming side */
#define TMR_T2O           0x22   /* timer 2 for outgoing side */
#define TMR_T3I           0x31   /* timer 3 for incoming side */
#define TMR_T3O           0x32   /* timer 3 for outgoing side */
#define TMR_T5I           0x51   /* timer 5 for incoming side */
#define TMR_T5O           0x52   /* timer 5 for outgoing side */
#define TMR_T6I           0x61   /* timer 6 for incoming side */
#define TMR_T6O           0x62   /* timer 6 for outgoing side */
#define TMR_T7I           0x71   /* timer 7 for incoming side */
#define TMR_T7O           0x72   /* timer 7 for outgoing side */
#define TMR_T8            0x41   /* timer 8 for incoming side */
#define TMR_T9            0x73   /* timer 9 for outgoing side */
#define TMR_T33I          0x15   /* timer 33 for incoming side */
#define TMR_T33O          0x16   /* timer 33 */
#define TMR_T36I          0x81   /* timer 34(36) for incoming side */
#define TMR_T36O          0x82   /* timer 34(36) for outgoing side */
#define TMR_TCCRI         0x91   /* timer CCR */
#define TMR_TCCRO         0x92   /* timer CCR */
#define TMR_TEX           0x77   /* timer to send Exit message */

#define TMR_T3            0x03   /* timer 4 */
#define TMR_T4            0x04   /* timer 4 */
#define TMR_T10           0x0a   /* timer 10 */
#define TMR_T11           0x0b   /* timer 11 */
#define TMR_T12           0x0c   /* timer 12 */
#define TMR_T13           0x0d   /* timer 13 */
#define TMR_T14           0x0e   /* timer 14 */
#define TMR_T15           0x0f   /* timer 15 */
#define TMR_T16           0x10   /* timer 16 */
#define TMR_T17           0x11   /* timer 17 */
#define TMR_T18           0x12   /* timer 18 */
#define TMR_T19           0x13   /* timer 19 */
#define TMR_T20           0x14   /* timer 20 */
#define TMR_T21           0x15   /* timer 21 */
#define TMR_T22           0x16   /* timer 22 */
#define TMR_T23           0x17   /* timer 23 */
#define TMR_T24           0x18   /* timer 24 */
#define TMR_T25           0x19   /* timer 25 */
#define TMR_T26           0x1a   /* timer 26 */
#define TMR_T27           0x1b   /* timer 27 */
#define TMR_T28           0x1c   /* timer 28 */
#define TMR_T31           0x1d   /* timer 31 */
#define TMR_T32           0x1e   /* timer 32 */
#define TMR_T34           0x1f   /* timer 34 */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
#define TMR_TFGR          0x22   /* timer started when first group blocking
                                    or reset message received */
#endif
#define TMR_TVAL          0x23   /* circuit validation timer */

#define TMR_TCRM          0x25   /* circuit reservation message timer */
#define TMR_TCRA          0x26   /* circuit reservation ack. timer */
#if (SS7_ETSI || SS7_ITU97 || SS7_ETSIV3)
#define TMR_TECT          0x27   /* loop prevention msg timer */
#endif
#if SS7_FTZ
#define TMR_GTCHG         0xa1   /* GT_FTZ CGHEA msg timer */
#endif
#define TMR_PAUSE         0x28   /* GT_FTZ PAUSE msg timer */
#define TMR_TINT          0x29   /* Interface timer for BINDCFM */
#define TMR_TSTAENQ       0x30   /* Interface timer for status enequiry */
#define TMR_TRELRSP       0x31   /* Interface minor timer for awaiting release 
                                    response - incoming connection */
#define TMR_TFNLRELRSP    0x32   /* Interface major timer for awaiting release 
                                    response - incoming connection*/

#define TMR_ALL           0xff   /* all timers */

#define NOTUSED           0      /* not used */

#define MAXSIMTIMER       4      /* maximum number of simultaneous timers */
/* si044.220 : Addition - Bulk circuit cfg specific Changes introduced */
#ifdef BULK_CIR_CFG
#define SI_HSH_LST_SIZ    32768    /* hash list size */
#else
#define SI_HSH_LST_SIZ    256    /* hash list size */
#endif /* if BULK_CIR_CFG */

#define MAXSEGCNT         0x7FFFFFFF   /* maximum segment count */

#define MAX_MSG_LEN       272    /* maximum length of the message */

#define TQNUMENT          512    /* timing queue number of entries */

#define MOD15             0x0f   /* modulo 15 mask */
#define MOD31             0x1f   /* modulo 31 mask */
/* si025.220: Modificaiton - modify the MOD values */
#define MOD63             0x3f   /* modulo 63 mask */
#define MOD255            0xff   /* modulo 255 mask */


/* circuit group states */
#define SICG_ST_IDLE      0x00   /* circuit group idle state */
/* local states of circuit groups */
#define SICG_ST_WTCGBACK  0x01   /* waiting for CGBA */
#define SICG_ST_WTCGUACK  0x02   /* waiting for CGUA */
#define SICG_ST_WTCGRACK  0x03   /* waiting for GRA  */
/* remote states of circuit groups */
#define SICG_ST_WTCGBRSP  0x04   /* waiting for CGB response */
#define SICG_ST_WTCGURSP  0x05   /* waiting for CGU response */
#define SICG_ST_WTCGRRSP  0x06   /* waiting for GRS response */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
#define SICG_ST_WTGRPAGN  0x07   /* waiting for ANSI92 second group message */
#endif

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
#define NMB_SICIRGR_ST    8      /* number of circuit group maintenace states */
#else
#define NMB_SICIRGR_ST    7      /* number of circuit group maintenace states */
#endif

/* incoming events for local circuit states */
#define CEI_BLOREQ        0x00   /* i/c circuit event: block request       */ 
#define CEI_BLA           0x01   /* i/c circuit event: block ack msg       */
#define CEI_UBLREQ        0x02   /* i/c circuit event: unblock request     */
#define CEI_UBA           0x03   /* i/c circuit event: unblock ack message */
#define CEI_RESREQ        0x04   /* i/c circuit event: reset request       */
#define CEI_RESACK        0x05   /* i/c circuit event: reset ack (RLC) msg */
#define CEI_MTCGBREQ      0x06   /* i/c circuit event: mntc CGB request    */
#define CEI_MTCGBA        0x07   /* i/c circuit event: mntc CGBA message   */
#define CEI_MTCGUREQ      0x08   /* i/c circuit event: mntc CGU request    */
#define CEI_MTCGUA        0x09   /* i/c circuit event: mntc CGUA message   */
#define CEI_HWCGBREQ      0x0A   /* i/c circuit event: h/w CGB request     */
#define CEI_HWCGBA        0x0B   /* i/c circuit event: h/w CGBA message    */
#define CEI_HWCGUREQ      0x0C   /* i/c circuit event: h/w CGU request     */
#define CEI_HWCGUA        0x0D   /* i/c circuit event: h/w CGUA message    */
#define CEI_GRSREQ        0x0E   /* i/c circuit event: GRS request         */
#define CEI_GRA           0x0F   /* i/c circuit event: GRA message         */
/* incoming events for remote circuit states */
#define CEI_BLO           0x10   /* i/c circuit event: block msg           */
#define CEI_BLORSP        0x11   /* i/c circuit event: block response      */
#define CEI_UBL           0x12   /* i/c circuit event: unblock message     */
#define CEI_UBLRSP        0x13   /* i/c circuit event: unblock response    */
#define CEI_RES           0x14   /* i/c circuit event: reset message       */
#define CEI_RESRSP        0x15   /* i/c circuit event: reset response      */
#define CEI_MTCGB         0x16   /* i/c circuit event: mntc CGB message    */
#define CEI_MTCGBRSP      0x17   /* i/c circuit event: mntc CGB response   */
#define CEI_MTCGU         0x18   /* i/c circuit event: mntc CGU message    */
#define CEI_MTCGURSP      0x19   /* i/c circuit event: mntc CGU response   */
#define CEI_HWCGB         0x1A   /* i/c circuit event: h/w CGB message     */
#define CEI_HWCGBRSP      0x1B   /* i/c circuit event: h/w CGB response    */
#define CEI_HWCGU         0x1C   /* i/c circuit event: h/w CGU message     */
#define CEI_HWCGURSP      0x1D   /* i/c circuit event: h/w CGU response    */
#define CEI_GRS           0x1E   /* i/c circuit event: GRS message         */
#define CEI_GRSRSP        0x1F   /* i/c circuit event: GRS response        */
#define CEI_UCIC          0x20   /* i/c circuit event: UCIC message        */

#define NMB_SICIR_INC_EVT 33     /* number of incoming circuit mgmt. events */

/* incoming events for local circuit group states */
#define CGEI_CGBREQ       0x00   /* i/c cir. group event: CGB request   */
#define CGEI_CGBACK       0x01   /* i/c cir. group event: CGBA message  */
#define CGEI_CGUREQ       0x02   /* i/c cir. group event: CGU request   */
#define CGEI_CGUACK       0x03   /* i/c cir. group event: CGUA message  */
#define CGEI_GRSREQ       0x04   /* i/c cir. group event: GRS request       */
#define CGEI_GRSACK       0x05   /* i/c cir. group event: GRA message       */
/* incoming events for remote circuit group states */
#define CGEI_CGB          0x06   /* i/c cir. group event: CGB message  */
#define CGEI_CGBRSP       0x07   /* i/c cir. group event: CGB response */
#define CGEI_CGU          0x08   /* i/c cir. group event: CGU message  */
#define CGEI_CGURSP       0x09   /* i/c cir. group event: CGU response */
#define CGEI_GRS          0x0A   /* i/c cir. group event: GRS message       */
#define CGEI_GRSRSP       0x0B   /* i/c cir. group event: GRS response      */
#define CGEI_CGQRYREQ     0x0C   /* i/c cir. group event: query request     */
#define CGEI_CGQRY        0x0D   /* i/c cir. group event: query request     */
#define CGEI_CGQRYRSP     0x0E   /* i/c cir. group event: query response    */

#define NMB_SICIRGR_INC_EVT 22   /* number of incoming circuit group events */

/* query states */
#define SICIR_QRY_ST0     0x00   /* transient                                 */
#define SICIR_QRY_ST1     0x01   /* unequipped                                */
#define SICIR_QRY_ST2     0x02   /* inc. busy, active                         */
#define SICIR_QRY_ST3     0x03   /* inc. busy, locally mntc. blocked          */
#define SICIR_QRY_ST4     0x04   /* inc. busy, remotely mntc. blocked         */
#define SICIR_QRY_ST5     0x05   /* inc. busy, locally & remotely mntc. blked */
#define SICIR_QRY_ST6     0x06   /* out. busy, active                         */
#define SICIR_QRY_ST7     0x07   /* out. busy, locally mntc. blocked          */
#define SICIR_QRY_ST8     0x08   /* out. busy, remotely mntc. blocked         */
#define SICIR_QRY_ST9     0x09   /* out. busy, locally & remotely mntc. blked */
#define SICIR_QRY_ST10    0x0a   /* idle                                      */
#define SICIR_QRY_ST11    0x0b   /* idle, locally mntc. blocked               */
#define SICIR_QRY_ST12    0x0c   /* idle, remotely mntc. blocked              */
#define SICIR_QRY_ST13    0x0d   /* idle, locally & remotely mntc. blocked    */

/* keys define for interface block hashlists */
#define SIINTF_KEY_1      0      /* action on hashlist on intfid           */
#define SIINTF_KEY_2      1      /* action on hashlist on dpc,NT,swtch,opc */
#define SIINTF_KEY_3      2      /* action on hashlist on dpc,NT,swtch     */

/* type of list */

#define KEY_CIR           0      /* circuit */
#define KEY_CICINTF       1      /* cic and interface */
#define KEY_INTF           2      /* interface */

#define PRI_ZERO          0      /* priority 0 - lowest */
#define PRI_ONE           1      /* priority 1 */
#define PRI_TWO           2      /* priority 2 */

#define MAXSILISNT        5      /* maximum number of lower interfaces with 
                                    mtp level 3 */
#define MAXSILISPT        3      /* maximum number of lower interfaces with 
                                    sccp */
#define MAXSIMI           3      /* maximum number of interfaces with the sm */

#define SI_NUMCIR_EV      10     /* number of circuit events */
#define SI_NUMCIRGR_EV    14     /* number of circuit group events */

#define MAX_CIR_BLK92     24     /* maximum number of circuits to block or 
                                    unblock */
#define MAX_CIR_BLK       32     /* maximum number of circuits to block or 
                                    unblock */
/* si013.220, ADD: Added constant for the maximum circuits that can be 
                   be blocked/unblocked for the ITU variant */
#define MAX_CIR_BLK_ITU   256    /* maximum number of circuits to block or
                                    unblock */
#define MAX_CIR_QUERA     24     /* max number of circts in query req ANSI*/
#define MAX_CIR_QUER      32     /* maximum number of circts in query request*/
#define MAX_CIR_BLK92_INT 32     /* maximum number of circuits to block or
                                    unblock for ANSI international */
#define MAX_CIR_QUERA_INT 32     /* max number of circts in query req 
                                    ANSI international */

#define MAX_CIR_GRS_NTT   12     /* Max number of circuits in GRS for
                                    NTT */
/* si033.220, ADD: Add constant for the Max number of circuits for group reset */
#define MAX_CIR_GRS       32     /* Max number of circuits in GRS */
#define MAX_RES_BYTES     4      /* maximum number of bytes in reset request */
#define MAX_ANS92_BYTES   3      /* maximum number of bytes in status of 
                                    grpoup messages  */
#define BIT_8             0x80   /* masking bit 8 in the octet, need to go to
                                    the next octet */

#define CALLPROC          0x0c   /* mask call processing states in query 
                                    response */

#define REL28             0x02   /* release connection with cause 28 */
#define REL111            0x03   /* release connection with cause 111 */

#define NMB_MGTMSG_RSNT   0x03   /* number of circuit timer restart */
#define NMB_GMGTMSG_RSNT  0x02   /* number of circuit group timer restart */

#define MSGCSGM           0x98   /* Message compatibility for segmentation*/
#define SEGM_MSG          TRUE   /* Event for siReassblMsg: SGM received */
#define SEGM_TMR          FALSE  /* Event for siReassblMsg: T34 expired  */

/* values for circuit flag */
#define SI_CIRFLG_CARIND    0x0c      /* carrier indication   */
#define SI_CIRFLG_ALARM     0x30      /* alarm   */
#define SI_CIRFLG_COTCHK    0xc0      /* continuity check requirement */

/* mask for circuit flag */
#define SI_CIRFLG_COTCHKCFN  0xc2     
                       /* mask for continuity check and confusion bits */
#define SI_CIRFLG_ALMCARINT  0x3d  
                       /* mask for carrier ind, alarm and nat/internat bits */


/* MTP-L3 ANSI: uses these values */
/*
#define MAX_SIMSG_LEN     538
#define MAX_SIMTP2_LEN    266
*/ 
/* MTP-L3 ITU-T: uses these values */
#define MAX_SIMSG_LEN     536    /* max length of the isup message  */
#define MAX_SIMSG_LENANS  530    /* max length of the isup msg for ANSI*/

#define MAX_SIMTP2_LEN    268    /* max length of msgs carried by MTP2*/
#define MAX_SIMTP2_LENANS 265    /* max len of msgs by MTP2 for ANSI*/


#define SGM_MAX_NO_OF_IES 10     /* Max number of message elements in SGM */

#define MAX_UNREG_PC      10     /* Max number of unrecognized parameter */
#define PC_PASSONPAR        0    /* pass on the unrecognized parameter */
#define PC_RELEASE          1    /* parameter compat action release */
#define PC_DISCMSG_SNDCONF  2    /* param compat action discard message and 
                                    send confusion */
#define PC_DISCMSG          3    /* parameter compat action discard message */
#define PC_DROPMSG          7    /* parameter compat action discard message */
#define PC_DISCPAR_SNDCONF  4    /* param compat action discard parameter and 
                                    send confusion */
#define PC_DISCPAR          5    /* param compat action discard parameter */
#define PC_SNDCONF          6    /* send confusion */
#define PC_INVRELMSG        0xfe /* Invalid release message */
#define PC_NOACTION         0xff    /* no action is taken */

#define PASSON_NTPOSS_RELCALL  0x00
#define PASSON_NTPOSS_ASSUME00 0x60
#define PASSON_NTPOSS_DISCMSG  0x20
#define PASSON_NTPOSS_DISCPARM 0x40
#define CHKBITS_E_C            0x14
/* 
 * The value 14 is arrived as follows
 * HGFE DCBA
 * 0001 0100
 * Once we are here, actions are to be taken based on the 
 * values of bit C and E as bits B and D should be 0. 
 *    E   D C B 
 *    0   0 0 0   Pass on parameter (0x00)
 *    1   0 0 0   Discard parameter (0x10)
 *    0   0 1 0   Pass on parameter (don't send a notif)  (0x04)
 *    1   0 1 0   Discard parameter and send notification (0x14)
 */
#define PASSON_PARM            0x00
#define DISCPARM               0x10
#define PASSON_PARM_SND_NOTIF  0x04
#define DISCPARM_SNDNOTIF      0x14
/*
 * IJ bits are introduced in ITU97 in parameter compatibility info param.
 * They are used for broadband/narrowband interworking
 * PONM LKJI (2nd octet of instruction indicator)   
 *        00           Pass on (0x00)
 *        01           Discard message (0x01)
 *        10           Release call (0x02)
 *        11           Discard parameter (0x03)
 */
#define PC_BRN_PASSON             0x00
#define PC_BRN_DISCMSG            0x01
#define PC_BRN_RELCALL            0x02
#define PC_BRN_DISCPARM           0x03
#define CHKBITS_I_J            0x03

#define MC_DROPMSG              2
#define MC_PASSONMSG            1
#define PASSONMSG               0x00 
#define DISCMSG                 0x08 
#define PASSONMSG_SND_NOTIF     0x04 
#define DISCMSG_SNDNOTIF        0x0c
#define CHKMC_BITS_C_D          0x0c
/*
 * GF bits are introduced in ITU97 in mssage compatibility info param.
 * They are used for broadband/narrowband interworking
 * HGFE CDBA
 *  00           Pass on (0x00)
 *  01           Discard message (0x20)
 *  10           Release call (0x40)
 *  11           Reserve, assume "00" (0x60)
 */
#define CHKMC_BITS_F_G          0x60
#define BRN_DISCMSG             0x20
#define BRN_RELCALL             0x40
#define BRN_PASSONMSG           0x00
#define BRN_RESERVE             0x60
#define BRNBAND_ITWK            0x04  /* braodband/narrow-band interworking */

#define SIDISJNT                0
#define SIINTSECT               1
#define SISUPSET                2
#define SISUBSET                3
#define SIEQLSET                4

#define SI_INTSET_FLG           0x01
#define SI_SUPSET_FLG           0x02
#define SI_SUBSET_FLG           0x04
#define SI_EQLSET_FLG           0x08
#define SI_DISJNT_FLG           0x10

#define SIOFFSETOF(X, Y)        (U32)( &(((X *)NULLP)->Y))
#define SISIZEOF(X, Y)          ((Size) sizeof( (((X *)0)->Y)) )


#define SI_MAX_NO_OF_CIR       32 /* max. num of ckt in non-single rate conn */
#define SI_MAX_CIR_24          24 /* max. num of ckt in non-singel rate conn 
                                     or E1 trunck type */
#define SI_SINGLE              0  /* single rate connection */
#define SI_ANSI_MAXOCT         0x3 /* max. bytes in CAM map format for ANS95 */

#ifdef IW
#define SI_REL_UPLW            0x10 /* release up and low */
#endif

/* In our interpretation, the multirate connection type call are defined as a 
   call involving more than one circuit with TMR value is one of 2*64, 384, 
   1536, 1920 kbits/s and can exist on specific cic (values) as governed
   by Table 3 part 1 in Q763(the starting ckt are fixed and known)
   for ITU97 and ETSI v3. 
   The reason is that when the dual seizure occured between two multirate 
   connection type call with same N. If the starting ckt is not fixed by two
   ends, both calls will end of discarding. See the following example:
   Exchange 1: has a 384 kbit/s outgoing call on ckt 10 sending to exchange 2; 
               and it receives a 384 kbit/s incoming call on ckt 13 from 
               exchange 2. The Point Code of exchange is 1.
   Exchange 2: In the meaning time, it receives a 384 kbit/s incoming call
               on ckt 10 while it has a 384 kbit/s outgoing call on ckt 13.
               the Point Code of exchange is 2.
   If we use the CIC value in which the exchange receives incoming IAM divided
   by the number of 64 kbit/s(which is 6 here), the interger part of this 
   operation will determine which call should control.
   Exchange 1 will get this intergar part as 2 (13/6), the higher PC should 
   controll. It will accept the incoming call and clear its outgoing call.
   While exchange 2 will get 1 (10/6), the lower PC should controll. It will 
   accept the incoming call from exchange 1. However this call is already
   cleared by exchange 1.
   Because of this mismatch between two exchanges, both calls are discarded.
   The starting ckt should be known by two exchanges.
   For ANS95, the multirate connecition type calls refer to the calls with
   information transfer rate of 384, 1472, 1536 and 1920 kbit/s
   */
#define SI_MULTI_CONN          1  /* multirate connection type call */
#define SI_N64_CONN            2  /* N*64 kbit/s connection type call */
#define INCOMING_CTRL         (RFAILED + 1)  
                              /* incoming conn control the circuit in dual seizure */
#define OUTGOING_CTRL        (RFAILED + 2)  
                              /* ougoing conn control the circuit in dual seizure */

#define UPDATECAUSE(_cDgn,_val, cbPtr) \
{ \
   (_cDgn).eh.pres       = PRSNT_NODEF; \
   (_cDgn).causeVal.pres = PRSNT_NODEF; \
   (_cDgn).causeVal.val  = (_val); \
   (_cDgn).cdeStand.pres = PRSNT_NODEF; \
   (_cDgn).cdeStand.val  = CSTD_CCITT;  \
   (_cDgn).location.pres = PRSNT_NODEF; \
   (_cDgn).location.val  = cbPtr->cfg.relLocation;\
}

#define IAMSEGIND      0x10   /* IAM segmentation indicator */
#define FWDCALLINDBIT  0x4    /* bit of forward call indicator in IAM */

#ifdef SLS_8BIT
#undef SLS_8BIT
#define  SLS_8BIT    1       /* Use 8 bit SLS */
#else /* SLS_8BIT */
#define SLS_8BIT     0       /* Do not use 8 bit SLS */
#endif /* SLS_8BIT */

/* si003.220 : Code Addition
 * Added new define for the maximum bits in an octet
 */
#define MAXBITS_IN_OCTET 8
#endif

#define SI_MAX_ALLOWED_SPINSTID 0xFFFFFFFE
/* si044.220 : Addition : Bulk circuit cfg define */
#define SI_MAX_BULK CIR_CFG 4000

  
/********************************************************************30**
  
         End of file:     si.h@@/main/26 - Wed Jul 25 13:20:13 2001

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  bn    1. text changes
             ---  jrl   2. trillium development system checkpoint (dvs)
                           at version: 1.0.0.0

1.2          ---  bn    1. add TMR_TEX and TMR_TFGR defines

1.3          ---  rk    1. miscellaneous changes

1.4          ---  rk    1. miscellaneous changes

1.5          ---  bn    1. text changes
             ---  bn    2. changes to support ansi 92

1.6          ---  bn    1. changed MAXSIUI to MAXSIUISIT.
             ---  bn    2. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.7          ---  bn    1. moved circuit states to lm_pt.h.

1.8          ---  bn    1. added define for BIT_8.
             
1.9          ---  bn    1. moved defines for SAP types to lsi.h

1.10         ---  bn    1. changed defines for timer t4
             ---  bn    2. added defines for new timers tCCR, 
                           t27 and t34
             ---  bn    3. added defines for REL28 and REL111
                           action codes.

1.11         ---  bn    1. changed define for TMR_T8 from 0x70 to 0x41.

1.12         ---  bn    1. additions for Italian Q767.

1.13         ---  bn    1. add CIRRESREQLOC define

1.14         ---  bn    1. moved define for CIRRESREQLOC to sit.h

1.15         ---  pc    1. added ETSI variant for SI
             ---  bn    2. added define for MAX_CIR_QUERA.

1.16         ---  dm    1. added FTZ variant for SI.
             ---  dm    2. added defines for segmentation.

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.17         ---      dm   1. changed TMR_T36I/O values (si00x.210)
             ---      ao   2. added CIRGRBLKACKRSP and CIRGRUNBLKACKRSP
             ---      ao   3. added definitions for hardware and maintenace
                              locally and remotely blocked

1.18         ---      rh   4. PAUSE/RESUME changes 
1.18+        si013    rs   1. Message/Parameter Compatibility Changes
             ---      rh   1. Made MAXSIUISIT a private hash define in 
                              si_ptui.c
1.19         ---      rs   1. Added define SI_FORCED_DEL
             ---      rh   1. Added hash defines for offset and size 
                              calculations
1.20         ---      ym   1. Modifications for Debug prints
1.20+        ---      ym   1. New defines are added for max circuit for ANSI 
                              international.
             ---      ym   1. Define for invalid release message is added.
             ---      ym   1. Define for the maximum size of the message
                              for ANSI and ITU corrected.
1.21         ---      ym   1. Changes related to addition of NTT variant in
                              ISUP.
            si032.214 tz   1. Changed code to avoid confusion about the
                              meaning of defined parameters. The variables
                              PASSON_PARM_NO_NOTIF and PASSONMSG_NO_NOTIF
                              were changed to PASSON_PARM_SND_NOTIF and
                              PASSONMSG_SND_NOTIF.
1.23         ---      dvs  1. miscellaneous changes
1.24         ---      ym   1. OUT define is changed to OUTTYPE for NT
                              compilation.
/main/25     ---      ym   1. MAXSILISNT is incremented by one to 
                              take into account the addition of tightly
                              coupled function for M3UA
                      hy   1. Added hash defines for checking 
                              broad-narrowband interworking related info.  
                           2. Added hash defines for non-single call 
                              related info.
                      bsp  3. Removed TGRES timer because timer is no
                              longer run with the phasing out of SITVER2.
                      hy   4. Add hash defined IAMSEGIND and FWDCALLINDBIT 
                              SI_ANSI_MAXOCT
                           5. Add hash defines SI_CIRFLG_COTCHKCFN and
                              SI_CIRFLG_ALMCARINT
                           6. Add hash defines SI_INTSET_FLG, SI_SUPSET_FLG
                              SI_SUBSET_FLG, SI_EQLSET_FLG and
                              SI_DISJNT_FLG
/main/26     ---     bsp  1. Added hash define SI_REL_UPLW 
           si001.220 hy   1. Added defines dependency checks for rollup.
	   si003.220 mm   1. Added new define MAXBITS_IN_OCTET for CGB/
	                     CGU range zero.
	   si004.220 mm   1. Modified macro SISTATECHNG to avoid possibly 
	                     using variable var uninitialized.
           si013.220 km   1. Added MAX_CIR_BLK_ITU define for the maximum
                             number of circuits that can be blocked/un-
                             blocked at any one time
           si025.220 tz   1. Modified modulo defines.
           si033.220 rk   1. Added constant MAX_CIR_GRS for the Max number of
                             circuits for group reset
           si034.220 rk   1. Added CHINA flag and switch where applicable.
           si043.220 rk   1. BHARTI specific Changes introduced
           si044.220 rk   1. Bulk circuit cfg specific Changes introduced
*********************************************************************91*/

