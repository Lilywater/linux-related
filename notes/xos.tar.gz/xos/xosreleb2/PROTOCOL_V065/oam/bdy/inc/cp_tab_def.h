#ifndef _CP_TAB_DEF_H_
#define _CP_TAB_DEF_H_

#include "oam_tab_def.h"

/*-------------------  protocol moudle define ---------------------- */
/* definition for protocol module id base */
#ifndef CP_MODULE_ID_BASE
#define CP_MODULE_ID_BASE 0x20
#endif

typedef enum
{
  CP_MODULE_ID_VOIP_TUCL=CP_MODULE_ID_BASE+1,
	CP_MODULE_ID_VOIP_SCTP,
	CP_MODULE_ID_VOIP_SIP,
	CP_MODULE_ID_VOIP_H248,
	CP_MODULE_ID_SS7_M3UA,
	CP_MODULE_ID_SS7_SCCP,
	CP_MODULE_ID_SS7_TCAP,
	CP_MODULE_ID_SS7_MAP,
	CP_MODULE_ID_SS7_ISUP,
} MibMoudleId;

/*-------------------  protocol moudle define ---------------------- */


/*-------------------  protocol table define ---------------------- */
/* VOIP TUCL Table ID */
#define APP_TABLE_ID_VOIP_TUCL_GEN xwCpTuclGenCfg
 
/* VOIP SCTP Table ID */
#define APP_TABLE_ID_VOIP_SCTP_GEN      xwCpSctpGenCfg
#define APP_TABLE_ID_VOIP_SCTP_SRC_ADDR xwCpSctpNetAddrCfg

/* VOIP SIP Table ID */
#define APP_TABLE_ID_VOIP_SIP_GEN  xwCpSipSoGenCfg
#define APP_TABLE_ID_VOIP_SIP_ENT  xwCpSipSoEntCfg
#define APP_TABLE_ID_VOIP_SIP_HDR  xwCpSipSoHdrCfg
#define APP_TABLE_ID_VOIP_SIP_REUA xwCpSipSoReUaCfg

/* VOIP H248 Table ID */
#define APP_TABLE_ID_VOIP_H248_MGCSRVR xwCpH248MGCSrvrCfg
#define APP_TABLE_ID_VOIP_H248_MGCENT  xwCpH248MGCPeerEntCfgTable
#define APP_TABLE_ID_VOIP_H248_MGSRVR  xwCpH248MGSrvrCfg
#define APP_TABLE_ID_VOIP_H248_MGENT   xwCpH248MGPeerEntCfgTable

/* SS7 Common Table ID */
#define APP_TABLE_ID_SS7_NWK  xwCpSS7NwkTable     /* SS7 Network Config */
#define APP_TABLE_ID_SS7_UP   xwCpSS7UpTable      /* SS7 UP Config */
#define APP_TABLE_ID_SS7_SPC  xwCpSS7SpcTable     /* SS7 SPC Config */
#define APP_TABLE_ID_SS7_SSN  xwCpSS7SsnTable     /* SS7 SSN Config */
#define APP_TABLE_ID_COM_IP   xwCpComIpTable      /* COMMON IP Config */

/* SS7 M3UA Table ID */
#define APP_TABLE_ID_SS7_M3UA_GEN   xwCpM3uaGenCfg    /* M3UA General Config */
#define APP_TABLE_ID_SS7_M3UA_NODE  xwCpM3uaNodeCfg
#define APP_TABLE_ID_SS7_M3UA_PSP   xwCpM3uaPspTable
#define APP_TABLE_ID_SS7_M3UA_PS    xwCpM3uaPsTable
#define APP_TABLE_ID_SS7_M3UA_ROUTE xwCpM3uaRouteTable

/* SS7 SCCP Table ID */
#define APP_TABLE_ID_SS7_SCCP_GEN       xwCpSccpGenCfg       /* SCCP General Config */
#define APP_TABLE_ID_SS7_SCCP_NW_ATTR   xwCpSccpNwCfgTable   /* SCCP Network Attribution Config */
#define APP_TABLE_ID_SS7_SCCP_GT_RULE   xwCpSccpGtRuleTable  /* SCCP Global Title Rule Config */
#define APP_TABLE_ID_SS7_SCCP_GT_ADDR   xwCpSccpGtAddrTable  /* SCCP Globle Title Address Config */
#define APP_TABLE_ID_SS7_SCCP_ROUTE     xwCpSccpRteTable     /* SCCP Route Config */
#define APP_TABLE_ID_SS7_SCCP_ROUTE_SSN xwCpSccpRteSsnTable  /* SCCP Route SSN Config */

/* SS7 TCAP Table ID*/
#define APP_TABLE_ID_SS7_TCAP_GEN   xwCpTcapGenCfg    /* TCAP General Config */

/* SS7 MAP Table ID */
#define APP_TABLE_ID_SS7_MAP_GEN   xwCpMapGenCfg   /* MAP General Config */
#define APP_TABLE_ID_SS7_MAP_SAP   xwCpMapSapCfg   /* MAP SAP Config */
#define APP_TABLE_ID_SS7_MAP_ACN   xwCpMapAcnCfg   /* MAP ACN Config */

/* SS7 ISUP Table ID */
#define APP_TABLE_ID_SS7_ISUP_GEN      xwCpIsupGenCfg    /* ISUP General Config */
#define APP_TABLE_ID_SS7_ISUP_SAP      xwCpIsupUSapCfgTable
#define APP_TABLE_ID_SS7_ISUP_PROFILE  xwCpIsupProfileCfgTable

/* SS7 ISUP UA Table ID */
#define APP_TABLE_ID_SS7_ISUP_INTF    xwSSIsupUaSiTable 
#define APP_TABLE_ID_SS7_ISUP_SUBROUT xwSSIsupUaSsrTable 
#define APP_TABLE_ID_SS7_ISUP_CIRGRP  xwSSIsupUaScmTable 
/*-------------------  protocol table define ---------------------- */


#endif/*_CP_TAB_DEF_H_*/

