/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SIP layer portable management interface

     Type:     C source file

     Desc:     C source code for the SCTP layer layer management
               service user primitives used in loosely coupled
               systems.

     File:     smsoptmi.c

     Sid:      smsoptmi.c@@/main/4 - Tue Apr 20 12:45:34 2004

     Prg:      wvdl

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_tpt.h"        /* common transport */
#include "cm_tkns.h"       /* common tokens */
#include "lso.h"           /* SIP layer manager interface */
#include "so_err.h"        /* SIP error defines */

/* header/extern include files (.x) */
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_tkns.x"       /* common tokens */
#include "cm_tpt.x"        /* common transport */
#include "cm_mblk.x"       /* cm_mblk */
#include "lso.x"           /* SIP layer manager interface */

/* local defines */
#define SM_MAX_MILSO_SEL              2

#ifndef LCSMSOMILSO
#define PTSMSOMILSO
#else
#ifndef SM
#define PTSMSOMILSO
#else
#endif
#endif

/* forward references */
#ifdef PTSMSOMILSO
PRIVATE S16 PtMiLsoCfgReq     ARGS((Pst             *pst,
                                    SoMngmt         *cfg));
PRIVATE S16 PtMiLsoCntrlReq   ARGS((Pst             *pst,
                                    SoMngmt         *cntrl));
PRIVATE S16 PtMiLsoStaReq     ARGS((Pst             *pst,
                                    SoMngmt         *sta));
PRIVATE S16 PtMiLsoStsReq     ARGS((Pst             *pst,
                                    Action          action,
                                    SoMngmt         *sts));
#ifdef LSO_ACNT                                    
PRIVATE S16 PtMiLsoAcntReq    ARGS((Pst             *pst,
                                    SoMngmt         *acnt));
#endif /* LSO_ACNT */
#endif /* PTSMSOMILSO */

/* Configuration request primitive */
PRIVATE LsoCfgReq SmMiLsoCfgReqMt[SM_MAX_MILSO_SEL] =
{
#ifdef LCSMSOMILSO
   cmPkLsoCfgReq,          /* 0 - loosely coupled (default mechanism) */
#else
   PtMiLsoCfgReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SoMiLsoCfgReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLsoCfgReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Control request primitive */
PRIVATE LsoCntrlReq SmMiLsoCntrlReqMt[SM_MAX_MILSO_SEL] =
{
#ifdef LCSMSOMILSO
   cmPkLsoCntrlReq,        /* 0 - loosely coupled (default mechanism) */
#else
   PtMiLsoCntrlReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SoMiLsoCntrlReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLsoCntrlReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Status request primitive */
PRIVATE LsoStaReq SmMiLsoStaReqMt[SM_MAX_MILSO_SEL] =
{
#ifdef LCSMSOMILSO
   cmPkLsoStaReq,          /* 0 - loosely coupled (default mechanism) */
#else
   PtMiLsoStaReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SoMiLsoStaReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLsoStaReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Statistics request primitive */
PRIVATE LsoStsReq SmMiLsoStsReqMt[SM_MAX_MILSO_SEL] =
{
#ifdef LCSMSOMILSO
   cmPkLsoStsReq,          /* 0 - loosely coupled (default mechanism) */
#else
   PtMiLsoStsReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SoMiLsoStsReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLsoStsReq,          /* 1 - tightly coupled, portable */
#endif
};

#ifdef LSO_ACNT
/* Accounting request primitive */
PRIVATE LsoAcntReq SmMiLsoAcntReqMt[SM_MAX_MILSO_SEL] =
{
#ifdef LCSMSOMILSO
   cmPkLsoAcntReq,       /* 0 - loosely coupled (default mechanism) */
#else
   PtMiLsoAcntReq,         /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SoMiLsoAcntReq,         /* 1 - tightly coupled, layer management */
#else
   PtMiLsoAcntReq,         /* 1 - tightly coupled, portable */
#endif
};
#endif /* LSO_ACNT */

/* Primitive Mapping Dispatching Functions */

/*
*
*       Fun:   Configuration request
*
*       Desc:  This function is used to configure SIP layer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsoptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 SmMiLsoCfgReq
(
Pst     *pst,             /* post structure */
SoMngmt *cfg              /* configure */
)
#else
PUBLIC S16 SmMiLsoCfgReq(pst, cfg)
Pst     *pst;             /* post structure */
SoMngmt *cfg;             /* configure */
#endif
{
   TRC3(SmMiLsoCfgReq)

   /* jump to specific primitive depending on configured selector */
   (*SmMiLsoCfgReqMt[pst->selector])(pst, cfg);

   RETVALUE(ROK);
} /* SmMiLsoCfgReq */

/*
*
*       Fun:   Control request
*
*       Desc:  This function is used to control SIP layer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsoptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 SmMiLsoCntrlReq
(
Pst     *pst,             /* post structure */
SoMngmt *cntrl            /* control */
)
#else
PUBLIC S16 SmMiLsoCntrlReq(pst, cntrl)
Pst     *pst;             /* post structure */
SoMngmt *cntrl;           /* control */
#endif
{
   TRC3(SmMiLsoCntrlReq)

   /* jump to specific primitive depending on configured selector */
   (*SmMiLsoCntrlReqMt[pst->selector])(pst, cntrl);

   RETVALUE(ROK);
} /* SmMiLsoCntrlReq */

/*
*
*       Fun:   Status request
*
*       Desc:  This function is used to send a Status Request to SIP layer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsoptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 SmMiLsoStaReq
(
Pst     *pst,             /* post structure */
SoMngmt *sta              /* solicited status */
)
#else
PUBLIC S16 SmMiLsoStaReq(pst, sta)
Pst     *pst;             /* post structure */
SoMngmt *sta;             /* solicited status */
#endif
{
   TRC3(SmMiLsoStaReq)

   /* jump to specific primitive depending on configured selector */
   (*SmMiLsoStaReqMt[pst->selector])(pst, sta);

   RETVALUE(ROK);
} /* SmMiLsoStaReq */

/*
*
*       Fun:   Statistics request
*
*       Desc:  This function is used to send a Statistics request to SIP layer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsoptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 SmMiLsoStsReq
(
Pst     *pst,           /* post structure */
Action  action,         /* zeroing action */
SoMngmt *sts            /* statistics */
)
#else
PUBLIC S16 SmMiLsoStsReq(pst, action, sts)
Pst     *pst;           /* post structure */
Action  action;         /* zeroing action */
SoMngmt *sts;           /* statistics */
#endif
{
   TRC3(SmMiLsoStsReq)

   /* jump to specific primitive depending on configured selector */
   (*SmMiLsoStsReqMt[pst->selector])(pst, action, sts);

   RETVALUE(ROK);
} /* SmMiLsoStsReq */

#ifdef LSO_ACNT
/*
*
*       Fun:   Accounting request
*
*       Desc:  This function is used to send an Accounting request to SIP layer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsoptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 SmMiLsoAcntReq
(
Pst     *pst,             /* post structure */
SoMngmt *acnt             /* accounting */
)
#else
PUBLIC S16 SmMiLsoAcntReq(pst, acnt)
Pst     *pst;             /* post structure */
SoMngmt *acnt;            /* accounting */
#endif
{
   TRC3(SmMiLsoAcntReq)

   /* jump to specific primitive depending on configured selector */
   (*SmMiLsoAcntReqMt[pst->selector])(pst, acnt);

   RETVALUE(ROK);
} /* SmMiLsoAcntReq */
#endif /* LSO_ACNT */

#ifdef PTSMSOMILSO
/* Portable Stub Functions */

/*
*
*       Fun:   Portable configure Request for SIP layer
*
*       Desc:
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsoptmi.c
*
*/

#ifdef ANSI
PRIVATE S16 PtMiLsoCfgReq
(
Pst     *pst,               /* post structure */
SoMngmt *cfg                /* configure */
)
#else
PRIVATE S16 PtMiLsoCfgReq(pst, cfg)
Pst     *pst;               /* post structure */
SoMngmt *cfg;               /* configure */
#endif
{
   TRC3(PtMiLsoCfgReq);

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(cfg);

   RETVALUE(ROK);
} /* PtMiLsoCfgReq */

/*
*
*       Fun:   Portable Control Request for SIP layer
*
*       Desc:
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsoptmi.c
*
*/

#ifdef ANSI
PRIVATE S16 PtMiLsoCntrlReq
(
Pst     *pst,               /* post structure */
SoMngmt *cntrl              /* control */
)
#else
PRIVATE S16 PtMiLsoCntrlReq(pst, cntrl)
Pst     *pst;               /* post structure */
SoMngmt *cntrl;             /* control */
#endif
{
   TRC3(PtMiLsoCntrlReq);

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(cntrl);

   RETVALUE(ROK);
} /* PtMiLsoCntrlReq */

/*
*
*       Fun:   Portable Status Request for SIP layer
*
*       Desc:
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsoptmi.c
*
*/

#ifdef ANSI
PRIVATE S16 PtMiLsoStaReq
(
Pst     *pst,               /* post structure */
SoMngmt *sta                /* solicited status */
)
#else
PRIVATE S16 PtMiLsoStaReq(pst, sta)
Pst     *pst;               /* post structure */
SoMngmt *sta;               /* solicited status */
#endif
{
   TRC3(PtMiLsoStaReq);

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(sta);

   RETVALUE(ROK);
} /* PtMiLsoStaReq */

/*
*
*       Fun:   Portable Statistics Request for SIP layer
*
*       Desc:
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsoptmi.c
*
*/

#ifdef ANSI
PRIVATE S16 PtMiLsoStsReq
(
Pst     *pst,           /* post structure */
Action  action,         /* zeroing action */
SoMngmt *sts            /* statistics */
)
#else
PRIVATE S16 PtMiLsoStsReq(pst, action, sts)
Pst     *pst;               /* post structure */
Action  action;             /* zeroing action */
SoMngmt *sts;               /* statistics */
#endif
{
   TRC3(PtMiLsoStsReq);

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(action);
   UNUSED(sts);

   RETVALUE(ROK);
} /* PtMiLsoStsReq */

#ifdef LSO_ACNT
/*
*
*       Fun:   Portable Accounting Request for SIP layer
*
*       Desc:
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsoptmi.c
*
*/

#ifdef ANSI
PRIVATE S16 PtMiLsoAcntReq
(
Pst     *pst,               /* post structure */
SoMngmt *acnt               /* accounting */
)
#else
PRIVATE S16 PtMiLsoAcntReq(pst, acnt)
Pst     *pst;               /* post structure */
SoMngmt *acnt;              /* accounting */
#endif
{
   TRC3(PtMiLsoAcntReq);

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(acnt);

   RETVALUE(ROK);
} /* PtMiLsoAcntReq */
#endif /* LSO_ACNT */
#endif /* PTSMSOMILSO */


/********************************************************************30**

         End of file:     smsoptmi.c@@/main/4 - Tue Apr 20 12:45:34 2004

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/4      ---      ms  1. Initial Release 
*********************************************************************91*/
