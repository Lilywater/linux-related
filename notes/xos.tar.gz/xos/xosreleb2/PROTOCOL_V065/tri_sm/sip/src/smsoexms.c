/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     smsoexms.c - stack manager - interface with SIP layer

     Type:     C source file

     Desc:     Sample C source code for the stack manager.
               - SIP layer interface primitives.
               - Functions required for unpacking layer management
                 service provider primitives in loosely coupled systems.
               - FTHA for SIP present here as well.

     File:     smsoexms.c

     Sid:      smsoexms.c@@/main/4 - Tue Apr 20 12:45:32 2004

     Prg:      wvdl

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lhi.h"           /* HIT LM defines                  */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "so.h"            /* SIP layer defines               */
#include "so_trans.h"      /* Transaction module defines      */
#include "so_err.h"        /* SIP error defines               */
#include "so_cm.h"         /* SIP layer utility functions     */
#ifdef SO_ACC
#include "so_acc.h"        /* defines for SIP test layer      */
#endif

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lhi.x"           /* HIT Layer manager defines       */
#include "lso.x"           /* Layer management SIP            */
#include "sot.x"           /* SOT interface defines           */
#include "so_tcm.x"        /* Transport module structures     */
#include "so.x"            /* SIP layer structures            */
#include "so_trans.x"      /* Transaction module structures   */
#include "so_utl.x"        /* SIP layer utility functions     */
#include "so_cm.x"         /* SIP layer common functions      */
#include "so_dns.x"        /* SIP DNS library                 */
#ifdef SO_ACC
#include "so_acc.x"        /* typedefs for SIP test layer     */
#include "so_accmp.x"      /* event-structure compare functions */
#endif


/* forward references */
PUBLIC S16 smSoActvTsk ARGS((Pst    *pst,
                             Buffer *mBuf));

/* public routines */

/*
*
*       Fun:    activate task
*
*       Desc:   Processes received event from SIP layer
*
*       Ret:    ROK  - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   smsoexms.c
*
*/


#ifdef ANSI
PUBLIC S16 smSoActvTsk
(
Pst    *pst,                /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 smSoActvTsk(pst, mBuf)
Pst    *pst;                /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   S16         ret;           /* return code */
   Mem         sMem;          /* mem block passed to unpacking code */
   S16         maxBlockSize;  /* maximum block size */
   CmMemListCp mPtr;

   TRC3(smSoActvTsk)

   ret = ROK;

   sMem.region = soCb.init.region;
   sMem.pool   = soCb.init.pool;                         

   if (soCb.cfg.maxBlkSize > 0) 
   {
      maxBlockSize = soCb.cfg.maxBlkSize;
   }
   else 
   {
      maxBlockSize = 2048;
   }

   /* Used for mem allocation, mostly for TknStrOSXL's */
   cmInitMemCp(&mPtr, maxBlockSize, &sMem);
   
   switch(pst->event)
   {
#ifdef LCSMSOMILSO
                   
      case EVTLSOCFGCFM:             /* Config confirm */
         ret = cmUnpkLsoCfgCfm(SmMiLsoCfgCfm, pst, mBuf);
         break;

      case EVTLSOCNTRLCFM:           /* Control confirm */
         ret = cmUnpkLsoCntrlCfm(SmMiLsoCntrlCfm, pst, mBuf);
         break;

      case EVTLSOSTACFM:             /* Status Confirm */
         ret = cmUnpkLsoStaCfm(SmMiLsoStaCfm, pst, mBuf);
         break;

      case EVTLSOSTSCFM:             /* Statistics Confirm */
         ret = cmUnpkLsoStsCfm(SmMiLsoStsCfm, pst, mBuf);
         break;

      case EVTLSOSTAIND:             /* Status Indication */
         ret = cmUnpkLsoStaInd(SmMiLsoStaInd, pst, mBuf);
         break;

      case EVTLSOTRCIND:             /* Trace Indication */
         ret = cmUnpkLsoTrcInd(SmMiLsoTrcInd, pst, mBuf);
         break;

#ifdef LSO_ACNT

      case EVTLSOACNTCFM:            /* Accounting Confirm */
         ret = cmUnpkLsoAcntCfm(SmMiLsoAcntCfm, pst, mBuf, &mPtr);
         break;

      case EVTLSOACNTIND:            /* Accounting Indication */
         ret = cmUnpkLsoAcntInd(SmMiLsoAcntInd, pst, mBuf, &mPtr);
         break;
#endif /* LSO_ACNT */

#endif /* LCSMSOMILSO */

      default:
         /* we should never get here, especially if tightly coupled */
         SPutMsg(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
        SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, \
                   __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal)ESMXXX, 
                   (ErrVal)pst->event, "smSoActvTsk () Failed"); 
#endif
         ret = RFAILED;
         break;
   }
   
   SExitTsk();

   RETVALUE(ret);
} /* smSoActvTsk */


/********************************************************************30**

         End of file:     smsoexms.c@@/main/4 - Tue Apr 20 12:45:32 2004

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/4      ---      ms  1. Initial Release 
*********************************************************************91*/
