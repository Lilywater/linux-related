/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     smsobdy1.c - Dummy Stack Manager (Layer Manager) for the
               SIP layer.
     Type:     C source file

     Desc:     C code for layer manager service provider primitives that
               are usually supplied by the customer.
               - Copy contents to the queue.
               - Display the results of the received primitive.

     File:     smsobdy1.c

     Sid:      smsobdy1.c@@/main/4 - Tue Apr 20 12:45:29 2004

     Prg:      wvdl

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lhi.h"           /* HIT LM defines                  */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "so.h"            /* SIP layer defines               */
#include "so_trans.h"      /* Transaction module defines      */
#include "so_err.h"        /* SIP error defines               */
#include "so_cm.h"         /* SIP layer utility functions     */
#ifdef SO_ACC
#include "so_acc.h"        /* defines for SIP test layer      */
#endif
#ifdef SO_TEST_SV_TYPE
#include "sv.h"            /* defines for SIP application layer */
#endif

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lhi.x"           /* HIT Layer manager defines       */
#include "lso.x"           /* Layer management SIP            */
#include "sot.x"           /* SOT interface defines           */
#include "so_tcm.x"        /* Transport module structures     */
#include "so.x"            /* SIP layer structures            */
#include "so_trans.x"      /* Transaction module structures   */
#include "so_utl.x"        /* SIP layer utility functions     */
#include "so_cm.x"         /* SIP layer common functions      */
#include "so_dns.x"        /* SIP DNS library                 */
#ifdef SO_ACC
#include "so_acc.x"        /* typedefs for SIP test layer     */
#include "so_accmp.x"      /* event-structure compare functions */
#endif
#ifdef SO_TEST_SV_TYPE
#include "sv.x"            /* defines for SIP application layer */
#endif


/* forward references */
PUBLIC S16 smSoActvInit ARGS((Ent    ent,
                              Inst   inst,
                              Region region,
                              Reason reason));

PUBLIC S16 SmMiLsoCfgCfm ARGS((Pst     *pst,
                               SoMngmt *cfg));
PUBLIC S16 SmMiLsoCntrlCfm ARGS((Pst     *pst,
                                 SoMngmt *cntrl));
PUBLIC S16 SmMiLsoStaCfm ARGS((Pst     *pst,
                               SoMngmt *sta));
PUBLIC S16 SmMiLsoStsCfm ARGS((Pst     *pst,
                               SoMngmt *sts));
PUBLIC S16 SmMiLsoTrcInd ARGS((Pst     *pst,
                               SoMngmt *trc,
                               Buffer  *mBuf));
PUBLIC S16 SmMiLsoStaInd ARGS((Pst     *pst,
                               SoMngmt *usta));
PUBLIC S16 SmMiLsoAcntCfm ARGS((Pst     *pst,
                                SoMngmt *acnt));

/* public routines */

/*
*
*       Fun:   dummy Activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsobdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 smSoActvInit
(
Ent    ent,                   /* entity */
Inst   inst,                  /* instance */
Region region,                /* region */
Reason reason                 /* reason */
)
#else
PUBLIC S16 smSoActvInit(ent, inst, region, reason)
Ent    ent;                   /* entity */
Inst   inst;                  /* instance */
Region region;                /* region */
Reason reason;                /* reason */
#endif
{
   TRC3(smSoActvInit)

   UNUSED(ent);
   UNUSED(inst);
   UNUSED(region);
   UNUSED(reason);

   RETVALUE(ROK);
} /* smSoActvInit */

/*
 *
 *       Fun:    SmMiLsoCfgCfm
 *
 *       Desc:   Dummy Configuration Confirm
 *
 *       Ret:    ROK     - succeeded
 *
 *       Notes:  None
 *
 *       File:   smsobdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLsoCfgCfm
(
Pst     *pst,
SoMngmt *cfg
)
#else
PUBLIC S16 SmMiLsoCfgCfm(pst, cfg)
Pst     *pst;
SoMngmt *cfg;
#endif /* ANSI */
{
#ifdef SO_ACC
   /* local variables */
   SoAccMsgQElm    qElm;
#endif /* SO_ACC */

   TRC3(SmMiLsoCfgCfm)

   UNUSED(pst);

#ifdef SO_ACC
   SOACCDBGP((soAccCb.init.prntBuf,
              "\nSM <--CfgCfm-- SIP: elmId=%s transId=%ld"
              " status=%s reason=%s\n",
              soAccTag2Str(soAccElmIDs, cfg->hdr.elmId.elmnt),
              cfg->hdr.transId,
              soAccTag2Str(soAccLCMStatus, cfg->cfm.status),
              soAccTag2Str(soAccLCMReason, cfg->cfm.reason)));

   /* Pack primitive data in queue structure */
   SO_ACC_ZERO((U8 *) &(qElm), sizeof(SoAccMsgQElm));

   qElm.intfName = SO_ACC_LSO;
   qElm.t.lsoRcvEvnt.primType = SO_ACC_LSOCFGCFM;

   /* copy the header structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.hdr),
                   (U8 *) &(cfg->hdr),
                   (PTR) sizeof(Header));

   /* copy the confirm status structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.cfm),
                   (U8 *) &(cfg->cfm),
                   (PTR) sizeof(CmStatus));

   /* config confirm returns no info in the SoCfg structure */

   /* push it onto the message queue */
   (Void) soAccPushMsg(&qElm);

#endif /* SO_ACC */
#ifdef SO_TEST_SV_TYPE

   /*
    * Print The Success Or Failure Of Configuration Attempt.
    */
   if ((cfg->cfm.status == LCM_PRIM_OK) ||
       (cfg->cfm.status == LCM_PRIM_OK_NDONE))
   {
      if (cfg->hdr.elmId.elmnt == STGEN)
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: General "
                        "Configuration Success "));

      if (cfg->hdr.elmId.elmnt == STTSAP)
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: TSAP    "
                        "Configuration Success "));

      if (cfg->hdr.elmId.elmnt == STSIPENT)
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: Entity  "
                        "Configuration Success "));

      if (cfg->hdr.elmId.elmnt == STSSAP)
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: User SAP"
                        " Configuration Success "));
   }

   else
   {
      if (cfg->hdr.elmId.elmnt == STGEN)
      {
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: General "
                        "Configuration Failure (%d, %d)",
                        cfg->cfm.status, cfg->cfm.reason));
      }

      if (cfg->hdr.elmId.elmnt == STTSAP)
      {
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: TSAP    "
                        "Configuration Failure (%d, %d)",
                        cfg->cfm.status, cfg->cfm.reason));
      }

      if (cfg->hdr.elmId.elmnt == STSIPENT)
      {
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: Entity  "
                        "Configuration Failure (%d, %d)",
                        cfg->cfm.status, cfg->cfm.reason));
      }

      if (cfg->hdr.elmId.elmnt == STSSAP)
      {
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: User SAP"
                        " Configuration Failure (%d, %d)",
                        cfg->cfm.status, cfg->cfm.reason));
      }
   }

#endif /* SO_TEST_SV_TYPE */

   RETVALUE(ROK);

} /* SmMiLsoCfgCfm */

/*
 *
 *       Fun:    SmMiLsoCntrlCfm
 *
 *       Desc:   Dummy Control Confirm
 *
 *       Ret:    ROK     - succeeded
 *
 *       Notes:  None
 *
 *       File:   smsobdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLsoCntrlCfm
(
Pst     *pst,
SoMngmt *cntrl
)
#else
PUBLIC S16 SmMiLsoCntrlCfm(pst, cntrl)
Pst     *pst;
SoMngmt *cntrl;
#endif /* ANSI */
{
#ifdef SO_ACC   
   /* local variables */
   SoAccMsgQElm    qElm;
#endif /* SO_ACC */

   TRC3(SmMiLsoCntrlCfm)
   UNUSED(pst);

#ifdef SO_ACC
   SOACCDBGP((soAccCb.init.prntBuf,
              "\nSM <--CntrlCfm-- SIP: elmId=%s transId=%ld"
              " status=%s reason=%s action=%s subaction=%s\n",
              soAccTag2Str(soAccElmIDs, cntrl->hdr.elmId.elmnt),
              cntrl->hdr.transId,
              soAccTag2Str(soAccLCMStatus, cntrl->cfm.status),
              soAccTag2Str(soAccLCMReason, cntrl->cfm.reason),
              soAccTag2Str(soAccLCMAction, cntrl->t.cntrl.action),
              soAccTag2Str(soAccLCMSubAction, cntrl->t.cntrl.subAction)));

   /* Pack primitive data in queue structure */
   SO_ACC_ZERO((U8 *) &(qElm), sizeof(SoAccMsgQElm));

   qElm.intfName = SO_ACC_LSO;
   qElm.t.lsoRcvEvnt.primType = SO_ACC_LSOCNTRLCFM;

   /* copy the header structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.hdr),
                   (U8 *) &(cntrl->hdr),
                   (PTR) sizeof(Header));

   /* copy the confirm status structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.cfm),
                   (U8 *) &(cntrl->cfm),
                   (PTR) sizeof(CmStatus));

   /* control confirm returns no info in the SoCntrl structure */

   /* push it onto the message queue */
   (Void) soAccPushMsg(&qElm);

#endif /* SO_ACC */
#ifdef SO_TEST_SV_TYPE
 
   /*
    * Print The Success Or Failure Of Configuration Attempt.
    */
   if ((cntrl->cfm.status == LCM_PRIM_OK) ||
       (cntrl->cfm.status == LCM_PRIM_OK_NDONE))
   {
      if (cntrl->hdr.elmId.elmnt == STGEN)
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: General "
                        "Control Primitive Success "));

      if (cntrl->hdr.elmId.elmnt == STTSAP)
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: TSAP    "
                        "Control Primitive Success "));

      if (cntrl->hdr.elmId.elmnt == STSIPENT)
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: Entity  "
                        "Control Primitive Success "));

      if (cntrl->hdr.elmId.elmnt == STTPTSRV)
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager:Transport"
                        " Control Primitive Success "));

      if (cntrl->hdr.elmId.elmnt == STSSAP)
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: User SAP"
                        " Control Primitive Success "));

      if (cntrl->hdr.elmId.elmnt == STGRSSAP)
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: UserGSAP"
                        " Control Primitive Success "));
   }

   else
   {
      if (cntrl->hdr.elmId.elmnt == STGEN)
      {
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: General "
                        "Control Primitive Failure (%d, %d)",
                        cntrl->cfm.status, cntrl->cfm.reason));
      }

      if (cntrl->hdr.elmId.elmnt == STTSAP)
      {
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: TSAP    "
                        "Control Primitive Failure (%d, %d)",
                        cntrl->cfm.status, cntrl->cfm.reason));
      }

      if (cntrl->hdr.elmId.elmnt == STSIPENT)
      {
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: Entity  "
                        "Control Primitive Failure (%d, %d)",
                        cntrl->cfm.status, cntrl->cfm.reason));
      }

      if (cntrl->hdr.elmId.elmnt == STTPTSRV)
      {
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager:Transport"
                        " Control Primitive Failure (%d, %d)",
                        cntrl->cfm.status, cntrl->cfm.reason));
      }

      if (cntrl->hdr.elmId.elmnt == STSSAP)
      {
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: User SAP"
                        "Control Primitive Failure (%d, %d)",
                        cntrl->cfm.status, cntrl->cfm.reason));
      }

      if (cntrl->hdr.elmId.elmnt == STGRSSAP)
      {
         SV_DEBUG_INFO ((svCb.prntBuf, "\nStack Manager: UserGSAP"
                        "Control Primitive Failure (%d, %d)",
                        cntrl->cfm.status, cntrl->cfm.reason));
      }
   }

  UNUSED(cntrl);
#endif /* SO_TEST_SV_TYPE*/

   RETVALUE(ROK);
} /* SmMiLsoCntrlCfm */

/*
 *
 *       Fun:    SmMiLsoStaInd
 *
 *       Desc:   Dummy Status Indication
 *
 *       Ret:    ROK     - succeeded
 *
 *       Notes:  None
 *
 *       File:   smsobdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLsoStaInd
(
Pst     *pst,
SoMngmt *usta
)
#else
PUBLIC S16 SmMiLsoStaInd(pst, usta)
Pst     *pst;
SoMngmt *usta;
#endif /* ANSI */
{
#ifdef SO_ACC
   /* local variables */
   SoAccMsgQElm    qElm;
   SoUsta          *p;
#endif /* SO_ACC */

   TRC3(SmMiLsoStaInd)
   UNUSED(pst);

#ifdef SO_ACC
   p = &usta->t.usta;

   SOACCDBGP((soAccCb.init.prntBuf,
              "\nSM <---StaInd--- SIP: elmId=%s"
              " category=%s event=%s cause=%s\n",
              soAccTag2Str(soAccElmIDs, usta->hdr.elmId.elmnt),
              soAccTag2Str(soAccLCMCategory,p->alarm.category),
              soAccTag2Str(soAccLCMEvent, p->alarm.event),
              soAccTag2Str(soAccLCMCause, p->alarm.cause)));

   /* Pack primitive data in queue structure */
   SO_ACC_ZERO((U8 *) &(qElm), sizeof(SoAccMsgQElm));

   qElm.intfName = SO_ACC_LSO;
   qElm.t.lsoRcvEvnt.primType = SO_ACC_LSOSTAIND;

   /* copy the header structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.hdr),
                   (U8 *) &(usta->hdr),
                   (PTR) sizeof(Header));

   /* copy the confirm status structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.cfm),
                   (U8 *) &(usta->cfm),
                   (PTR) sizeof(CmStatus));

   /* copy the alarm info structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.p.lsoStaInd),
                   (U8 *) &(usta->t.usta),
                   (PTR) sizeof(SoUsta));

   /* push it onto the message queue */
   (Void) soAccPushMsg(&qElm);
#else
   UNUSED(usta);
#endif /* SO_ACC */

   RETVALUE(ROK);
} /* SmMiLsoStaInd */

/*
 *
 *       Fun:    SmMiLsoTrcInd
 *
 *       Desc:   Dummy Trace Indication
 *
 *       Ret:    ROK     - succeeded
 *
 *       Notes:  None
 *
 *       File:   smsobdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLsoTrcInd
(
Pst     *pst,
SoMngmt *trc,
Buffer  *mBuf
)
#else
PUBLIC S16 SmMiLsoTrcInd(pst, trc, mBuf)
Pst     *pst;
SoMngmt *trc;
Buffer  *mBuf;
#endif /* ANSI */
{
#ifdef SO_ACC
   /* local variables */
   SoAccMsgQElm    qElm;
#endif /* SO_ACC */
#ifdef SO_TEST_SV_TYPE
    MsgLen msgLen;
    Data   buffer[SV_SIPMSG_LEN];
#endif

   TRC3(SmMiLsoTrcInd)
   UNUSED(pst);

#ifdef SO_ACC
   SOACCDBGP((soAccCb.init.prntBuf,
              "\nSM <---TrcInd--- SIP: elmId=%s evnt=%u\n",
              soAccTag2Str(soAccElmIDs, trc->hdr.elmId.elmnt),
              trc->t.trc.evnt));

   /* Pack primitive data in queue structure */
   SO_ACC_ZERO((U8 *) &(qElm), sizeof(SoAccMsgQElm));

   qElm.intfName = SO_ACC_LSO;
   qElm.t.lsoRcvEvnt.primType = SO_ACC_LSOTRCIND;

   /* copy the header structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.hdr),
                   (U8 *) &(trc->hdr),
                   (PTR) sizeof(Header));

   /* copy the confirm status structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.cfm),
                   (U8 *) &(trc->cfm),
                   (PTR) sizeof(CmStatus));

   /* copy the trace information structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.p.lsoTrcInd.trc),
                   (U8 *) &(trc->t.trc),
                   (PTR) sizeof(SoTrc));

   /* copy the buffer pointer */
   qElm.t.lsoRcvEvnt.p.lsoTrcInd.mBuf = mBuf;

   /* push it onto the message queue */
   (Void) soAccPushMsg(&qElm);

#endif /* SO_ACC */
#ifdef SO_TEST_SV_TYPE
   
   /*------ Send The Message To UserInterface For Logging -----*/
   SFndLenMsg (mBuf, &msgLen);
   SRemPreMsgMult (buffer, msgLen, mBuf);

   (Void) svSendDebugInfo ((Txt *)buffer, msgLen);

#endif /* SO_TEST_SV_TYPE */

   /* modify by weigy at 060811 */
   SO_TXN_DEL_MBUF (mBuf);

   RETVALUE(ROK);

} /* SmMiLsoTrcInd */

/*
 *
 *       Fun:    SmMiLsoStaCfm
 *
 *       Desc:   Dummy Status Confirm
 *
 *       Ret:    ROK     - succeeded
 *
 *       Notes:  None
 *
 *       File:   smsobdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLsoStaCfm
(
Pst     *pst,
SoMngmt *sta
)
#else
PUBLIC S16 SmMiLsoStaCfm(pst, sta)
Pst     *pst;
SoMngmt *sta;
#endif /* ANSI */
{
#ifdef SO_ACC
   /* local variables */
   SoAccMsgQElm    qElm;
   Txt             *ptNmb;
#endif /* SO_ACC */

   TRC3(SmMiLsoStaCfm)
   UNUSED(pst);

#ifdef SO_ACC
   SOACCDBGP((soAccCb.init.prntBuf,
              "\nSM <---StaCfm--- SIP: elmId=%s transId=%ld"
              " status=%s reason=%s\n",
              soAccTag2Str(soAccElmIDs, sta->hdr.elmId.elmnt),
              sta->hdr.transId,
              soAccTag2Str(soAccLCMStatus, sta->cfm.status),
              soAccTag2Str(soAccLCMReason, sta->cfm.reason)));

   /* Pack primitive data in queue structure */
   SO_ACC_ZERO((U8 *) &(qElm), sizeof(SoAccMsgQElm));

   qElm.intfName              = SO_ACC_LSO;
   qElm.t.lsoRcvEvnt.primType = SO_ACC_LSOSTACFM;

   /* copy the header structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.hdr),
                   (U8 *) &(sta->hdr),
                   (PTR) sizeof(Header));

   /* copy the confirm status structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.cfm),
                   (U8 *) &(sta->cfm),
                   (PTR) sizeof(CmStatus));

   /* copy the solicited status info */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.p.lsoStaCfm),
                   (U8 *) &(sta->t.ssta),
                   (PTR) sizeof(SoSsta));

   /* make a local copy of the ptNmb */
   if (qElm.t.lsoRcvEvnt.hdr.elmId.elmnt == STSID)
   {
      ptNmb = qElm.t.lsoRcvEvnt.p.lsoStaCfm.s.sysId.ptNmb;
      cmMemcpy((U8 *)soAccCb.lsoPtrCb.ptNmb,
               (U8 *)ptNmb,
               (PTR) (cmStrlen((U8 *)ptNmb) + 1));

      /* point the QElm pointer to the saved string */
      qElm.t.lsoRcvEvnt.p.lsoStaCfm.s.sysId.ptNmb = soAccCb.lsoPtrCb.ptNmb;
   }

   /* push it onto the message queue */
   (Void) soAccPushMsg(&qElm);
#else
   UNUSED(sta);
#endif /* SO_ACC */

   RETVALUE(ROK);
} /* SmMiLsoStaCfm */

/*
 *
 *       Fun:    SmMiLsoStsCfm
 *
 *       Desc:   Dummy Statistics Confirm
 *
 *       Ret:    ROK     - succeeded
 *
 *       Notes:  None
 *
 *       File:   smsobdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLsoStsCfm
(
Pst     *pst,
SoMngmt *sts
)
#else
PUBLIC S16 SmMiLsoStsCfm(pst, sts)
Pst     *pst;
SoMngmt *sts;
#endif /* ANSI */
{
#ifdef SO_ACC
   /* local variables */
   SoAccMsgQElm    qElm;
#endif /* SO_ACC */

   TRC3(SmMiLsoStsCfm)
   UNUSED(pst);

#ifdef SO_ACC
   SOACCDBGP((soAccCb.init.prntBuf,
              "\nSM <---StsCfm--- SIP: elmId=%s transId=%ld"
              " status=%s reason=%s\n",
              soAccTag2Str(soAccElmIDs, sts->hdr.elmId.elmnt),
              sts->hdr.transId,
              soAccTag2Str(soAccLCMStatus, sts->cfm.status),
              soAccTag2Str(soAccLCMReason, sts->cfm.reason)));

   /* Pack primitive data in queue structure */
   SO_ACC_ZERO((U8 *) &(qElm), sizeof(SoAccMsgQElm));

   qElm.intfName = SO_ACC_LSO;
   qElm.t.lsoRcvEvnt.primType = SO_ACC_LSOSTSCFM;

   /* copy the header structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.hdr),
                   (U8 *) &(sts->hdr),
                   (PTR) sizeof(Header));

   /* copy the confirm status structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.cfm),
                   (U8 *) &(sts->cfm),
                   (PTR) sizeof(CmStatus));

   /* copy the solicited status info */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.p.lsoStsCfm),
                   (U8 *) &(sts->t.sts),
                   (PTR) sizeof(SoSts));

   /* push it onto the message queue */
   (Void) soAccPushMsg(&qElm);
#else
   UNUSED(sts);
#endif /* SO_ACC */

   RETVALUE(ROK);
} /* SmMiLsoStsCfm */

#ifdef LSO_ACNT
/*
 *
 *       Fun:    SmMiLsoAcntCfm
 *
 *       Desc:   Dummy Accounting Confirm
 *
 *       Ret:    ROK     - succeeded
 *
 *       Notes:  None
 *
 *       File:   smsobdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLsoAcntCfm
(
Pst     *pst,
SoMngmt *acnt
)
#else
PUBLIC S16 SmMiLsoAcntCfm(pst, acnt)
Pst     *pst;
SoMngmt *acnt;
#endif /* ANSI */
{
#ifdef SO_ACC
   /* local variables */
   SoAccMsgQElm    qElm;
#endif /* SO_ACC */

   TRC3(SmMiLsoAcntCfm)
   UNUSED(pst);

#ifdef SO_ACC
   SOACCDBGP((soAccCb.init.prntBuf,
              "\nSM <--AcntCfm--- SIP: elmId=%s transId=%ld"
              " status=%s reason=%s\n",
              soAccTag2Str(soAccElmIDs, acnt->hdr.elmId.elmnt),
              acnt->hdr.transId,
              soAccTag2Str(soAccLCMStatus, acnt->cfm.status),
              soAccTag2Str(soAccLCMReason, acnt->cfm.reason)));

   /* Pack primitive data in queue structure */
   SO_ACC_ZERO((U8 *) &(qElm), sizeof(SoAccMsgQElm));

   qElm.intfName = SO_ACC_LSO;
   qElm.t.lsoRcvEvnt.primType = SO_ACC_LSOACNTCFM;

   /* copy the header structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.hdr),
                   (U8 *) &(acnt->hdr),
                   (PTR) sizeof(Header));

   /* copy the confirm status structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.cfm),
                   (U8 *) &(acnt->cfm),
                   (PTR) sizeof(CmStatus));

   /* copy the accounting info */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.p.lsoAcnt),
                   (U8 *) &(acnt->t.acnt),
                   (PTR) sizeof(SoAcnt));

   /* Must allocate memory for To and From tknstrOSXL */
   soUtlCpyTknStrOSXL(&qElm.t.lsoRcvEvnt.p.lsoAcnt.acntInfo.remoteAddr,
                   &acnt->t.acnt.acntInfo.remoteAddr, NULLP);
   soUtlCpyTknStrOSXL(&qElm.t.lsoRcvEvnt.p.lsoAcnt.acntInfo.localAddr,
                   &acnt->t.acnt.acntInfo.localAddr, NULLP);

   /* push it onto the message queue */
   (Void) soAccPushMsg(&qElm);
#else
   UNUSED(acnt);
#endif /* SO_ACC */

   RETVALUE(ROK);
} /* SmMiLsoAcntCfm */

/*
 *
 *       Fun:    SmMiLsoAcntInd
 *
 *       Desc:   Dummy Accounting Indication
 *
 *       Ret:    ROK     - succeeded
 *
 *       Notes:  None
 *
 *       File:   smsobdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLsoAcntInd
(
Pst     *pst,
SoMngmt *acnt
)
#else
PUBLIC S16 SmMiLsoAcntInd(pst, acnt)
Pst     *pst;
SoMngmt *acnt;
#endif /* ANSI */
{
#ifdef SO_ACC
   /* local variables */
   SoAccMsgQElm    qElm;
#endif /* SO_ACC */

   TRC3(SmMiLsoAcntInd)
   UNUSED(pst);

#ifdef SO_ACC
   SOACCDBGP((soAccCb.init.prntBuf,
              "\nSM <--AcntInd--- SIP: elmId=%s type=%u origin=%u\n",
              soAccTag2Str(soAccElmIDs, acnt->hdr.elmId.elmnt),
              acnt->t.acnt.acntInfo.type,
              acnt->t.acnt.acntInfo.origin));

   /* Pack primitive data in queue structure */
   SO_ACC_ZERO((U8 *) &(qElm), sizeof(SoAccMsgQElm));

   qElm.intfName = SO_ACC_LSO;
   qElm.t.lsoRcvEvnt.primType = SO_ACC_LSOACNTIND;

   /* copy the header structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.hdr),
                   (U8 *) &(acnt->hdr),
                   (PTR) sizeof(Header));

   /* copy the confirm status structure */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.cfm),
                   (U8 *) &(acnt->cfm),
                   (PTR) sizeof(CmStatus));

   /* copy the accounting info */
   (Void) cmMemcpy((U8 *) &(qElm.t.lsoRcvEvnt.p.lsoAcnt),
                   (U8 *) &(acnt->t.acnt),
                   (PTR) sizeof(SoAcnt));

   /* Must allocate memory for TknStrings "to" and "from" in ACNT info */
   soUtlCpyTknStrOSXL(&qElm.t.lsoRcvEvnt.p.lsoAcnt.acntInfo.remoteAddr,
                   &acnt->t.acnt.acntInfo.remoteAddr, NULLP);
   soUtlCpyTknStrOSXL(&qElm.t.lsoRcvEvnt.p.lsoAcnt.acntInfo.localAddr,
                   &acnt->t.acnt.acntInfo.localAddr, NULLP);

   /* push it onto the message queue */
   (Void) soAccPushMsg(&qElm);
#else
   UNUSED(acnt);
#endif /* SO_ACC */

   RETVALUE(ROK);
} /* SmMiLsoAcntInd */
#endif /* LSO_ACNT */

/********************************************************************30**

         End of file:     smsobdy1.c@@/main/4 - Tue Apr 20 12:45:29 2004

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/4      ---      ms  1. Initial Release 
*********************************************************************91*/
