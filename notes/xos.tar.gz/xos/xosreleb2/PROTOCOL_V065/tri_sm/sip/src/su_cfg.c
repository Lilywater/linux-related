/**********************************************************************

         (c) COPYRIGHT 1989-2003 by 
         Beijing Xinwei Telecom Technology co., ltd. ShenZhen R&D center
         All rights reserved.

     
**********************************************************************/

/**********************************************************************

     Name:     su_cfg.c 

     Type:     C source file

     Desc:     C code for general, SAP and entity configuration 

     Create :  2006-04-27 chendh
     

**********************************************************************/
#ifdef SO_SUCFG_SUPPORT

/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lhi.h"           /* HIT LM interface defines        */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "cst.h"           /* Compression module define       */
#include "so_cm.h"         /* SIP layer utility functions     */
#include "su_cfg.h"       /* SIP User defines                */
#include "so.h"            /* SIP Layer defines               */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lhi.x"           /* HIT LM interface defines        */
#include "lso.x"           /* Layer management SIP            */
#include "cst.x"           /* Compression module              */
#include "sot.x"           /* SOT interface defines           */
#include "so_cm.x"         /* SIP layer utility functions     */
#include "su_cfg.x"       /* SIP User structures             */

EXTERN U32 g_soDbgMask;

#ifndef SO_TEST_NMS_TYPE
/* global variables */
PRIVATE TranId   g_cfgTransId = 0;
PRIVATE SoGenReCfg  g_genReCfg;
PRIVATE SoEntReCfg  g_entReCfg;
PRIVATE SuUserIntf g_suCfgIntf; /* configure infomation*/
#endif

Void suFillPst       ARGS((Pst *pst));
Void suStr2IP        ARGS((Txt  *word, /* text buffer */
								  CmInetAddr *address    /* target address */));


#ifndef SO_TEST_NMS_TYPE

PRIVATE Void suGenCfgReq     ARGS((TranId transId));
PRIVATE Void suTSapCfgReq    ARGS((TranId transId,
                                   SpId   spId,
                                   SuId   suId));


PRIVATE S16 suGetServerAddr  ARGS((CmTptAddr *addr,
								  Txt       *hostName,
								  S32       idx));

PRIVATE S16 suBuildProxyAddr ARGS((SoDfltPrxCfg   *dfltPrx  /* default proxy config */));

PRIVATE Void suSSapCfgReq    ARGS((TranId transId,
                                   SpId   spId));

PRIVATE Void suEntCfgReq     ARGS((TranId transId,
                                   U8     entityType));

EXTERN S16  suSoEnableBnd   ARGS((TranId transId,
                                   SuId   tSapId));
EXTERN S16  suSoEnableEnt   ARGS((TranId transId));

EXTERN S16  suSoEnableTrace ARGS((TranId   transId));


#define SV_MAX_LISOT_SEL         3       /* maximum no. selectors */

#endif /* SO_TEST_NMS_TYPE */



/**********************************************************************
*
*       Fun:   suFillPst
*
*       Desc:  Fills the Post Structure
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*
**********************************************************************/
#ifdef ANSI
PUBLIC Void suFillPst
(
Pst   *pst
)
#else
PRIVATE Void suFillPst(pst)
Pst   *pst;   
#endif   
{
   TRC2(suFillPst)
   /*---------- Fill default values in Pst structure ----------*/
   pst->dstProcId = SFndProcId();
   pst->srcProcId = SFndProcId();
   pst->prior     = PRIOR0;
   pst->route     = RTESPEC;
   pst->event     = EVTNONE;
   pst->region    = DFLT_REGION; 
   pst->pool      = DFLT_POOL; 
   pst->selector  = SV_TC;

   RETVOID;
}


/*********************************************************************
*
*       Fun:   suStr2IP
*
*       Desc:  Converts a string into an IP
*
*       Ret:   Void
*
*       Notes: The IP will be in Network Byte Order
*
*
*********************************************************************/
#ifdef ANSI
PUBLIC Void suStr2IP
(
Txt            *word,                    /* text buffer */
CmInetAddr     *address                  /* target address */
)
#else
PUBLIC Void suStr2IP(word, address)
Txt            *word;                    /* text buffer */
CmInetAddr     *address;                 /* target address */
#endif
{
   /* local variable */
   U32            tmpU32;            /* temporary */
   
   /* start with the IP part contained in the first word */
   cmInetAddr(word, &(tmpU32));

   address->address = CM_INET_NTOH_U32(tmpU32);

   RETVOID;
}/* suStr2IP */

#ifndef SO_TEST_NMS_TYPE

/********************************************************************
*
*       Fun:   suConfigureUa
*
*       Desc:  Setup the SO Layer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*
********************************************************************/
#ifdef ANSI
PUBLIC   Void   suConfigureUa
(
SuUserIntf *userIntf
)
#else
PUBLIC   Void   suConfigureUa(userIntf)
SuUserIntf *userIntf;
#endif
{

   TRC2(suConfigureUa)

   g_cfgTransId = 0;

   memcpy(&g_suCfgIntf,userIntf,sizeof(SuUserIntf));

   /*----------------- General Configuration ------------------*/
   suGenCfgReq (g_cfgTransId++);

   /*-----------------TUCL SAP Configuration ------------------*/
   suTSapCfgReq (g_cfgTransId++, SO_HI_SP_ID_1, SO_HI_SU_ID_1);

#ifdef SO_DNS
   /*-------------- TUCL DNS SAP Configuration ----------------*/
   suTSapCfgReq (g_cfgTransId++, SO_HI_SP_ID_2, SO_HI_SU_ID_2);
#endif

   /*---------------- SIP Entity Configuration ----------------*/
   suEntCfgReq (g_cfgTransId++, LSO_ENT_UA);

   /*------------- Service User SAP Configuration -------------*/
   suSSapCfgReq (g_cfgTransId++, SO_SV_SP_ID_1);

   /* these function invoked by user*/

   /*------------------ Bind and Enable TSAP ------------------*/
   suSoEnableBnd (g_cfgTransId++, SO_HI_SU_ID_1);

#ifdef SO_DNS
   suSoEnableBnd (g_cfgTransId++, SO_HI_SU_ID_2);
#endif

   /*------------------- Enable SIP Entity  -------------------*/
   suSoEnableEnt (g_cfgTransId++);

   /*---------------- Enable TSAP Level Trace -----------------*/
   suSoEnableTrace (g_cfgTransId++);
//#endif

   RETVOID;
} /* suConfigureUa */

/********************************************************************
*
*       Fun:   suReConfigureUa
*
*       Desc:  Setup the SO Layer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*
********************************************************************/
#ifdef ANSI
PUBLIC   Void   suReConfigureUa
(
SuUserIntf *userIntf
)
#else
PUBLIC   Void   suReConfigureUa(userIntf)
SuUserIntf *userIntf;
#endif
{

   TRC2(suReConfigureUa)

#ifdef SO_UA
#ifdef SO_DNS
	if (userIntf->DNSserverIP[0] != '\0')
	{

		sprintf(g_suCfgIntf.DNSserverIP,userIntf->DNSserverIP);
		sprintf(g_suCfgIntf.DNSserverHostname,userIntf->DNSserverHostname);
		g_suCfgIntf.DNSserverPort = userIntf->DNSserverPort;

		g_genReCfg.dnsReCfg.dnsTptAddr.type = CM_TPTADDR_IPV4;

		suStr2IP (g_suCfgIntf.DNSserverIP, &(g_genReCfg.dnsReCfg.dnsTptAddr.u.ipv4TptAddr));
		g_genReCfg.dnsReCfg.dnsTptAddr.u.ipv4TptAddr.port = g_suCfgIntf.DNSserverPort;
		
	}
#endif

	sprintf(g_suCfgIntf.proxyIP,userIntf->proxyIP);
	sprintf(g_suCfgIntf.proxyHostname,userIntf->proxyHostname);
	g_suCfgIntf.proxyPort = userIntf->proxyPort;
	
	suBuildProxyAddr (&g_entReCfg.e.uaReCfg.dfltPrxCfg);
#endif
	
	/*svSendReCfgReq (&genReCfgG, &entReCfgG, svCb.callInfo.transId++);*/

	{
		SoMngmt        soMngmt;
		Pst            pst;
		
		TRC2 (svSendReCfgReq)
			
		soMngmt.hdr.msgType          = SO_SIPMESSAGE_REQUEST;
		soMngmt.hdr.entId.ent        = ENTSO;
		soMngmt.hdr.entId.inst       = SO_APPINST0;
		soMngmt.hdr.elmId.elmntInst1 = SO_APPINST1;
		soMngmt.hdr.elmId.elmntInst2 = SO_APPINST2;
		soMngmt.hdr.elmId.elmntInst3 = SO_APPINST3;
		soMngmt.hdr.transId          = g_cfgTransId++;
		
#ifdef LCSOMILSO
		soMngmt.hdr.response.selector = SV_LC;
#else
		soMngmt.hdr.response.selector = SV_TC;
#endif
		soMngmt.hdr.response.prior     = PRIOR0;
		soMngmt.hdr.response.route     = RTESPEC;
		soMngmt.hdr.response.mem.region= DFLT_REGION; 
		soMngmt.hdr.response.mem.pool  = DFLT_POOL; 
		soMngmt.hdr.response.mem.spare = 0; 
		
		suFillPst(&pst);
		pst.srcEnt   = ENTSM;
		pst.srcInst  = SO_APPINST_0;
		pst.dstEnt   = ENTSO;
		pst.dstInst  = SO_APPINST_0;
		
		/*---------------- Do general Reconfiguration ---------------*/
		
		soMngmt.hdr.elmId.elmnt      = STGEN;
		cmMemcpy ((U8 *)&(soMngmt.t.cfg.r.genReCfg),
			(CONSTANT U8 *)&g_genReCfg, 
			sizeof (SoGenReCfg));
		SmMiLsoCfgReq (&(pst), &(soMngmt));
		
		/*---------------- Do Entity  Reconfiguration ---------------*/
		
		soMngmt.hdr.elmId.elmnt      = STSIPENT;
		soMngmt.t.cfg.c.entCfg.entId = 0;
		soMngmt.t.cfg.c.entCfg.type  = LSO_ENT_UA;
		
		cmMemcpy ((U8 *)&(soMngmt.t.cfg.r.entReCfg), (CONSTANT U8 *)&g_entReCfg, sizeof (SoEntReCfg));
		SmMiLsoCfgReq (&(pst), &(soMngmt));
	}   

   RETVOID;
} /* suReConfigureUa */

/*********************************************************************
*
*       Fun:   suTSapCfgReq
*
*       Desc:  Set up the TSAP configuration structure
*
*       Ret:   ROK
*              RFAILED
*
*
*********************************************************************/
#ifdef ANSI
PRIVATE Void suTSapCfgReq
(
TranId           transId,
SpId             spId,
SuId             suId 
)
#else
PRIVATE Void suTSapCfgReq (transId, spId, suId)
TranId           transId;
SpId             spId;
SuId             suId;
#endif
{
   /* local variables */
   SoMngmt      soMngmt;
   SoTSapCfg    *tSapCfg; 
   SoTSapReCfg  *tSapReCfg;
   Pst          pst;

   TRC2 (suTSapCfgReq)

   tSapCfg   = &(soMngmt.t.cfg.c.tSapCfg);
   tSapReCfg = &(soMngmt.t.cfg.r.tSapReCfg);

   cmMemset ((U8 *) tSapCfg  , 0, sizeof (SoTSapCfg));   
   cmMemset ((U8 *) tSapReCfg, 0, sizeof (SoTSapReCfg));   
   
   tSapCfg->tSapId       = suId;
   tSapCfg->spId         = spId;
   tSapCfg->memId.region = DFLT_REGION;
   tSapCfg->memId.pool   = DFLT_POOL;
   tSapCfg->dstProcId    = SFndProcId();
   tSapCfg->dstEnt       = ENTHI;
   tSapCfg->dstInst      = SO_APPINST0;
   tSapCfg->dstPrior     = PRIOR0;
   tSapCfg->dstRoute     = RTESPEC;
#ifdef LCSOLIHIT
   tSapCfg->dstSel       = SV_LC;
#else
   tSapCfg->dstSel       = SV_TC;
#endif

#ifndef HI_MULTI_THREADED
#ifdef SV_LOAD
   tSapCfg->dstSel       = SV_TC;
#endif
#endif

   tSapCfg->suConIdHlBins= SO_HL_SIZE;
   tSapCfg->tptAddrHlBins= SO_HL_SIZE;

   /*--------- Fill TSAP Reconfiguration information ----------*/
   tSapReCfg->tPar.type                    = CM_TPTPARAM_SOCK; 
   tSapReCfg->tPar.u.sockParam.listenQSize = SO_TPTPARAM_QSIZE;
   tSapReCfg->tPar.u.sockParam.numOpts     = 0;
   
   tSapReCfg->maxBndRetry  = SO_TSAP_BNDRETRY;
   tSapReCfg->bndTmCfg.enb = TRUE;
   tSapReCfg->bndTmCfg.val = SO_TSAP_BNDTM;
 
   soMngmt.hdr.msgType          = SO_SIPMESSAGE_REQUEST;
   soMngmt.hdr.entId.ent        = ENTSO;
   soMngmt.hdr.entId.inst       = SO_APPINST0;
   soMngmt.hdr.elmId.elmnt      = STTSAP;
   soMngmt.hdr.elmId.elmntInst1 = SO_APPINST1;
   soMngmt.hdr.elmId.elmntInst2 = SO_APPINST2;
   soMngmt.hdr.elmId.elmntInst3 = SO_APPINST3;
   soMngmt.hdr.transId          = transId;
#ifdef LCSOMILSO
   soMngmt.hdr.response.selector= SV_LC;
#else
   soMngmt.hdr.response.selector= SV_TC;
#endif
   soMngmt.hdr.response.prior   = PRIOR0;
   soMngmt.hdr.response.route   = RTESPEC;
   soMngmt.hdr.response.mem.region = DFLT_REGION; 
   soMngmt.hdr.response.mem.pool   = DFLT_POOL; 
   soMngmt.hdr.response.mem.spare  = 0; /* chendh modify it*/

   suFillPst (&pst);
   pst.srcEnt   = ENTSM;
   pst.srcInst  = SO_APPINST0;
   pst.dstEnt   = ENTSO;
   pst.dstInst  = SO_APPINST0;

   /*------------- Send the configuration request -------------*/
    SmMiLsoCfgReq (&(pst), &(soMngmt));

   RETVOID;
} /* suTSapCfgReq */

/********************************************************************
*
*       Fun:   suGenCfgReq
*
*       Desc:  Set up the general configuration structure
*
*       Ret:   Void
*
*
********************************************************************/

#ifdef ANSI
PRIVATE Void suGenCfgReq
(
TranId           transId          /* transaction ID */
)
#else
PRIVATE Void suGenCfgReq(transId)
TranId           transId;          /* transaction ID */
#endif
{
   /* local variables */
   SoMngmt     soMngmt;   
   SoGenCfg    *genCfg; 
   SoGenReCfg  *genReCfg;
   Pst         pst;

   TRC2(suGenCfgReq)


   genCfg   = &(soMngmt.t.cfg.c.genCfg);
   genReCfg = &(soMngmt.t.cfg.r.genReCfg);
   cmMemset ((U8 *) genCfg  , 0, sizeof (SoGenCfg));   
   cmMemset ((U8 *) genReCfg, 0, sizeof (SoGenReCfg));   

  /*----------- Fill General Configuration Parameters ---------*/

   cmMemcpy((U8 *) (genCfg->protVer), 
            (CONSTANT U8 *) SO_PROTVER,
            (PTR) LSO_PROTVER_SZ);
  
   genCfg->maxNmbSSaps     = SO_MAX_SSAP;
   genCfg->maxNmbTSaps     = SO_MAX_TSAP;
   genCfg->maxNmbUA        = SO_MAX_UA;
   genCfg->maxNmbNS        = SO_MAX_NS;
   genCfg->maxNmbRemReg    = SO_MAX_REMREG;
   genCfg->maxNmbActCalls  = SO_MAX_ACT_CALL;
   genCfg->maxTransPerEnt  = SO_MAX_TRAN_ENT;
   genCfg->resThreshUpper  = SO_RES_THR_UP;
   genCfg->resThreshLower  = SO_RES_THR_LOW;
   genCfg->maxPendLocReq   = SO_MAX_PEND_LOC;
   genCfg->maxBlkSize      = SO_BLKSZ;
   genCfg->locRegSz        = LSO_CACHE_MIN_MEM_SIZE;
   genCfg->remRegSz        = LSO_CACHE_MIN_MEM_SIZE;
   genCfg->mtu             = SO_MTU;

#ifdef SO_ABNF_MT_LIB
   genCfg->nmbEDThreads    = 2;
#endif

#ifdef SO_UA
   genCfg->maxNumRegPerEnt = SO_MAX_REG_PER_ENTITY;
   genCfg->maxNumCnctPerEnt= SO_MAX_CNCT_PER_ENTITY;
#endif

#ifdef SO_DNS
   genCfg->dnsCfg.useDns           = TRUE;
   genCfg->dnsCfg.useDnsCache      = TRUE;
   genCfg->dnsCfg.dnsACacheSz      = SO_DNS_A_CACHE_SZ;
   genCfg->dnsCfg.dnsSrvCacheSz    = SO_DNS_SRV_CACHE_SZ;
#ifdef SO_ENUM
   genCfg->dnsCfg.dnsNaptrCacheSz  = SO_DNS_NAPTR_CACHE_SZ;
#endif
#endif

#ifdef SO_NS
#ifdef SO_LCS
   genCfg->locSrvCfg.locCachePres  = FALSE;
   genCfg->locSrvCfg.locCacheSz    = SO_LOCSRV_SZ;
   genCfg->locSrvCfg.locSrchHlBins = SO_HL_SIZE;
#endif
#endif

   genCfg->lmPst.dstProcId = SFndProcId();
   genCfg->lmPst.srcProcId = SFndProcId(); 
   genCfg->lmPst.dstEnt    = ENTSM;
   genCfg->lmPst.dstInst   = SO_APPINST_0;
   genCfg->lmPst.srcEnt    = ENTSO;
   genCfg->lmPst.srcInst   = SO_APPINST_0;
   genCfg->lmPst.prior     = PRIOR0;
   genCfg->lmPst.route     = RTESPEC;
   genCfg->lmPst.event     = EVTNONE;
   genCfg->lmPst.region    = DFLT_REGION; 
   genCfg->lmPst.pool      = DFLT_POOL; 
#ifdef LCSOMILSO
   genCfg->lmPst.selector  = SV_LC;
#else
   genCfg->lmPst.selector  = SV_TC;
#endif

#ifdef SO_COMPRESS
  /*-- Fill the SV layer as compression/decompression module --*/
   genCfg->compPst.dstProcId = SFndProcId();
   genCfg->compPst.srcProcId = SFndProcId(); 
   genCfg->compPst.dstEnt    = ENTSV;
   genCfg->compPst.dstInst   = SO_APPINST_0;
   genCfg->compPst.srcEnt    = ENTSO;
   genCfg->compPst.srcInst   = SO_APPINST_0;
   genCfg->compPst.prior     = PRIOR0;
   genCfg->compPst.route     = RTESPEC;
   genCfg->compPst.event     = EVTNONE;
   genCfg->compPst.region    = DFLT_REGION; 
   genCfg->compPst.pool      = DFLT_POOL; 
   genCfg->compPst.selector  = SV_LC;
#endif

   cmMemcpy((U8 *) genCfg->nodeIdStr, (CONSTANT U8 *) SO_NODEIDSTR, sizeof(SO_NODEIDSTR));

#ifdef DEBUGP
   genCfg->dbgMask         = g_soDbgMask;
#endif
#ifdef SV_LOAD
   genCfg->dbgMask         = g_soDbgMask;
#endif

  /*------------- Fill General Reconfiguration Part -----------*/

   genReCfg->GMToffset     = SO_GMT_OFFSET;

#ifdef SO_DNS
   genReCfg->dnsReCfg.dnsTptAddr.type = CM_TPTADDR_IPV4;

   suStr2IP (g_suCfgIntf.DNSserverIP, &(genReCfg->dnsReCfg.dnsTptAddr.u.ipv4TptAddr));

   genReCfg->dnsReCfg.dnsTptAddr.u.ipv4TptAddr.port = g_suCfgIntf.DNSserverPort;

   /*------ Address and port of the DNS listening server ------*/
   genReCfg->dnsReCfg.locAddr.type                  = CM_TPTADDR_IPV4;
   genReCfg->dnsReCfg.locAddr.u.ipv4TptAddr.address = CM_INET_INADDR_ANY;
   genReCfg->dnsReCfg.locAddr.u.ipv4TptAddr.port    = CM_INPORT_ANY;

   /*---- Transport parameters for the DNS listening server ---*/
   genReCfg->dnsReCfg.dnsTptParam.type              = CM_TPTPARAM_SOCK;
   genReCfg->dnsReCfg.dnsTptParam.u.sockParam.listenQSize
                                                    = SO_TPTPARAM_QSIZE;     
   genReCfg->dnsReCfg.dnsTptParam.u.sockParam.numOpts = 0;

   genReCfg->dnsReCfg.tSapId          = SO_HI_SU_ID_2;
   genReCfg->dnsReCfg.tptSrvId        = SO_TPTSRV_DNS;
   genReCfg->dnsReCfg.maxDnsRetry     = SO_DNS_RETRY;
   genReCfg->dnsReCfg.dnsQueryTmr.enb = TRUE;
   genReCfg->dnsReCfg.dnsQueryTmr.val = SO_DNS_QUERY_TM;
   genReCfg->dnsReCfg.maxDnsCacheExp  = SO_DNS_CACHE_EXP;
#endif

   /*-------- Setup the Transaction Module Timer Values -------*/
   genReCfg->tmrReTxCfg.t1         = SO_RETX_T1;
   genReCfg->tmrReTxCfg.t2         = SO_RETX_T2;
   genReCfg->tmrReTxCfg.t4         = SO_RETX_T4;

#if (defined(SO_NAT) && defined(SO_USE_UDP_SRVR))
   genReCfg->tmrReTxCfg.natTmrVal  = SO_NAT_TMR;
#endif 

#ifdef SO_NS
#ifdef SO_LCS
   genReCfg->locSrvReCfg.dfltLocCacheExp = SO_LOC_CACHE_DFLT_EXP;
   genReCfg->locSrvReCfg.maxLocCacheExp  = SO_LOC_CACHE_MAX_EXP;
#endif
#endif

  /*Hdr for Mngmt*/
   soMngmt.hdr.msgType          = SO_SIPMESSAGE_REQUEST;
   soMngmt.hdr.entId.ent        = ENTSO;
   soMngmt.hdr.entId.inst       = SO_APPINST0;
   soMngmt.hdr.elmId.elmnt      = STGEN;
   soMngmt.hdr.elmId.elmntInst1 = SO_APPINST1;
   soMngmt.hdr.elmId.elmntInst2 = SO_APPINST2;
   soMngmt.hdr.elmId.elmntInst3 = SO_APPINST3;
   soMngmt.hdr.transId          = transId;
#ifdef LCSOMILSO
   soMngmt.hdr.response.selector= SV_LC;
#else
   soMngmt.hdr.response.selector= SV_TC;
#endif
   soMngmt.hdr.response.prior   = PRIOR0;
   soMngmt.hdr.response.route   = RTESPEC;
   soMngmt.hdr.response.mem.region = DFLT_REGION; 
   soMngmt.hdr.response.mem.pool   = DFLT_POOL; 
   soMngmt.hdr.response.mem.spare  = 0; /* chendh modify it*/

   suFillPst(&pst);
   pst.srcEnt   = ENTSM;
   pst.srcInst  = SO_APPINST_0;
   pst.dstEnt   = ENTSO;
   pst.dstInst  = SO_APPINST_0;

   /*------------- Send the configuration request -------------*/
   SmMiLsoCfgReq (&(pst), &(soMngmt));

   /*------ Save The Current Configuration Parameters ---------*/
   cmMemcpy ( (U8 *) &g_genReCfg, (CONSTANT U8 *)genReCfg, sizeof (SoGenReCfg));

   RETVOID;
} /* suGenCfgReq */

/********************************************************************
*
*       Fun:   suEntCfgReq
*
*       Desc:  Set up the Entity configuration structure
*
*       Ret:   ROK
*              RFAILED
*
*
********************************************************************/

#ifdef ANSI
PRIVATE Void suEntCfgReq
(
TranId   transId,
U8       entityType
)
#else
PRIVATE Void suEntCfgReq (transId, entityType)
TranId   transId;
U8       entityType;
#endif
{
   S16            ret;
   SoMngmt        soMngmt;
   SoEntCfg       *entCfg;
   SoEntReCfg     *entReCfg;
   SoTptSrvLstCfg *tptSrvLst;
   Pst            pst;
   CmTptAddr      srvAddr;
   Txt            hostName[SU_DOMAIN_LEN];
   S16            domainNameLen;

   TRC2 (suEntCfgReq)

   cmMemset ((U8 *) &srvAddr, 0, sizeof (CmTptAddr));
   cmMemset ((U8 *) hostName, 0, SU_DOMAIN_LEN);

   entCfg     = &(soMngmt.t.cfg.c.entCfg);
   entReCfg   = &(soMngmt.t.cfg.r.entReCfg);
   tptSrvLst  = &(soMngmt.t.cfg.c.entCfg.tptSrvLstCfg);
   cmMemset ((U8 *) entCfg  , 0, sizeof (SoEntCfg));   
   cmMemset ((U8 *) entReCfg, 0, sizeof (SoEntReCfg));   
   cmMemset ((U8 *) tptSrvLst,0, sizeof (SoTptSrvLstCfg));   

   /*---------------- Configuration Parameter -----------------*/

   entCfg->entId                 = 0;
   entCfg->type                  = entityType;
#ifdef SO_UA
   entCfg->e.uaCfg.callIdHlBins        = SO_HL_SIZE;
   entCfg->e.uaCfg.callHdlHlBins       = SO_HL_SIZE;
   entCfg->e.uaCfg.regAddrHlBins       = SO_HL_SIZE;
   entCfg->e.uaCfg.regContactHlBins    = SO_HL_SIZE;
   entCfg->e.uaCfg.regHlBins           = SO_HL_SIZE;
   entCfg->e.uaCfg.clientTransHlBins   = SO_HL_SIZE;
   entCfg->e.uaCfg.serverTransHlBins   = SO_HL_SIZE;
#endif

   domainNameLen = cmStrlen(g_suCfgIntf.domainName) < SU_DOMAIN_LEN ? cmStrlen(g_suCfgIntf.domainName) : SU_DOMAIN_LEN;
   cmMemcpy ((U8 *) &(entCfg->domainName), 
             g_suCfgIntf.domainName,
              domainNameLen);
   entCfg->domainName[domainNameLen] = 0;

   /*----------- Configuration One Transport Server ------------*/

   /*------- Configure A UDP server1 -------*/
   if (g_suCfgIntf.listenPort[0] != 0)
   {
       tptSrvLst->nmbTptSrv                = 1;
       tptSrvLst->tptSrvCfg[0].tSapId      = SO_HI_SU_ID_1;
       tptSrvLst->tptSrvCfg[0].tptSrvId    = 1;
       tptSrvLst->tptSrvCfg[0].nmbSSap     = 1;
       tptSrvLst->tptSrvCfg[0].sSapLst[0]  = SO_SV_SP_ID_1;

       tptSrvLst->tptSrvCfg[0].tptProt     = LSO_TPTPROT_UDP_PRIOR;
       tptSrvLst->tptSrvCfg[0].tptAddr.type= CM_TPTADDR_IPV4;

       ret = suGetServerAddr (&tptSrvLst->tptSrvCfg[0].tptAddr,
                               tptSrvLst->tptSrvCfg[0].hostname,
                               0);
       if (ret != ROK)
          printf ("\n Wrong Server Address \n");

       tptSrvLst->tptSrvCfg[0].tPar.type                = CM_TPTPARAM_SOCK;
       tptSrvLst->tptSrvCfg[0].tPar.u.sockParam.numOpts = 0;
       tptSrvLst->tptSrvCfg[0].tPar.u.sockParam.listenQSize = SO_TPTPARAM_QSIZE;

       /*------- Configure A TCP server1 -------*/
       if (entityType == LSO_ENT_UA)
       {
           tptSrvLst->nmbTptSrv                += 1;

           cmMemcpy ((U8 *) &tptSrvLst->tptSrvCfg[1],
                     (CONSTANT U8 *) &tptSrvLst->tptSrvCfg[0],
                     sizeof (SoTptSrvCfg));

           tptSrvLst->tptSrvCfg[1].tptSrvId    = 2;
           tptSrvLst->tptSrvCfg[1].tptProt     = LSO_TPTPROT_TCP;
       }
   }

   if (g_suCfgIntf.listenPort[1] != 0)
   {
       /*------- Configure A UDP server2 -------*/
       tptSrvLst->nmbTptSrv                += 1;
       tptSrvLst->tptSrvCfg[2].tSapId      = SO_HI_SU_ID_1;
       tptSrvLst->tptSrvCfg[2].tptSrvId    = 3;
       tptSrvLst->tptSrvCfg[2].nmbSSap     = 1;
       tptSrvLst->tptSrvCfg[2].sSapLst[0]  = SO_SV_SP_ID_1;

       tptSrvLst->tptSrvCfg[2].tptProt     = LSO_TPTPROT_UDP_PRIOR;
       tptSrvLst->tptSrvCfg[2].tptAddr.type= CM_TPTADDR_IPV4;

       ret = suGetServerAddr (&tptSrvLst->tptSrvCfg[2].tptAddr,
                               tptSrvLst->tptSrvCfg[2].hostname,
                               1);
       if (ret != ROK)
          printf ("\n Wrong Server Address \n");

       tptSrvLst->tptSrvCfg[2].tPar.type                = CM_TPTPARAM_SOCK;
       tptSrvLst->tptSrvCfg[2].tPar.u.sockParam.numOpts = 0;
       tptSrvLst->tptSrvCfg[2].tPar.u.sockParam.listenQSize = SO_TPTPARAM_QSIZE;

       /*------- Configure A TCP server2 -------*/
       if (entityType == LSO_ENT_UA)
       {
           tptSrvLst->nmbTptSrv                += 1;

           cmMemcpy ((U8 *) &tptSrvLst->tptSrvCfg[3],
                     (CONSTANT U8 *) &tptSrvLst->tptSrvCfg[2],
                     sizeof (SoTptSrvCfg));

           tptSrvLst->tptSrvCfg[3].tptSrvId    = 4;
           tptSrvLst->tptSrvCfg[3].tptProt     = LSO_TPTPROT_TCP;
       }
   }

   /*---------------Re-Configuration Parameter ----------------*/
   entReCfg->hdrCfg.insDate      = g_suCfgIntf.insDates;
   entReCfg->hdrCfg.insAllow     = g_suCfgIntf.insAllow;
   entReCfg->hdrCfg.insExpires   = g_suCfgIntf.insExpires;
   entReCfg->hdrCfg.insUAHdr     = g_suCfgIntf.insUAHdr;
   entReCfg->hdrCfg.insSupported = g_suCfgIntf.insSupported;
   entReCfg->hdrCfg.insAccept    = g_suCfgIntf.insAccept;
   entReCfg->hdrCfg.maxFwd       = g_suCfgIntf.maxFwd;

   if ((cmStrlen(g_suCfgIntf.insOrg)) != 0)
   {
      entReCfg->hdrCfg.insOrg.pres = PRSNT_NODEF;
      cmMemcpy ((U8 *) entReCfg->hdrCfg.insOrg.str, 
                g_suCfgIntf.insOrg,
                cmStrlen(g_suCfgIntf.insOrg) < LSO_STR_SZ ? cmStrlen(g_suCfgIntf.insOrg) : LSO_STR_SZ);
   }
   else
   {
      entReCfg->hdrCfg.insOrg.pres = NOTPRSNT;
   }

   if ((cmStrlen(g_suCfgIntf.insSubject)) != 0)
   {
      entReCfg->hdrCfg.insSubject.pres = PRSNT_NODEF;
      cmMemcpy ((U8 *) entReCfg->hdrCfg.insSubject.str, 
                g_suCfgIntf.insSubject,
                cmStrlen (g_suCfgIntf.insSubject) < LSO_STR_SZ ? cmStrlen(g_suCfgIntf.insSubject) : LSO_STR_SZ);
   }
   else
   {
      entReCfg->hdrCfg.insSubject.pres = NOTPRSNT;
   }

   entReCfg->snd100Always        = FALSE;
   entReCfg->useCompact          = FALSE;
   entReCfg->alwRecurse          = FALSE;
   entReCfg->decodeSDP           = TRUE;
   entReCfg->tptInActvTmr        = SO_TCP_ACTV_TM;

#ifdef SO_TLS
   entReCfg->tlsInActvTmr        = SO_TCP_ACTV_TM;
#endif

#ifdef SO_SESSTIMER
   if (g_suCfgIntf.sessTmrVal == 0)
   {
      entReCfg->useSessTmr          = FALSE;
   }
   else
   {
      entReCfg->useSessTmr          = TRUE;
   }
   entReCfg->sessTmrVal          = g_suCfgIntf.sessTmrVal;
   entReCfg->minSe               = g_suCfgIntf.minSe;
#endif
   
   if (entityType == LSO_ENT_UA)
   {
#ifdef SO_UA
      entReCfg->e.uaReCfg.threshUpper           = SO_LOCREG_THRESH_UPPER;
      entReCfg->e.uaReCfg.threshLower           = SO_LOCREG_THRESH_LOWER;
      entReCfg->e.uaReCfg.alw3rdParty           = TRUE;
      entReCfg->e.uaReCfg.dfltExpiresInRegister = g_suCfgIntf.dfltExpiresInRegister;
      entReCfg->e.uaReCfg.dfltExpiresInInvite   = SO_LOCREG_DFLT_EXP_INV;
      entReCfg->e.uaReCfg.alertUsrOnExp         = g_suCfgIntf.alertUsrOnExp;
      entReCfg->e.uaReCfg.refreshOnExp          = g_suCfgIntf.refreshOnExp;
      entReCfg->e.uaReCfg.chkLocUsrReg          = FALSE;
      entReCfg->e.uaReCfg.insTmStamp            = FALSE;

      if ((cmStrlen(g_suCfgIntf.regSrvAddr)) != 0)
      {
         entReCfg->e.uaReCfg.regSrvAddr.type = CM_TPTADDR_IPV4;
         suStr2IP (g_suCfgIntf.regSrvAddr, &(entReCfg->e.uaReCfg.regSrvAddr.u.ipv4TptAddr));
         entReCfg->e.uaReCfg.regSrvAddr.u.ipv4TptAddr.port = g_suCfgIntf.regSrvPort;
      }
      else
      {
         entReCfg->e.uaReCfg.regSrvAddr.type = CM_TPTADDR_NOTPRSNT;
      }

      entReCfg->e.uaReCfg.addContact            = TRUE;
      entReCfg->e.uaReCfg.useIpContact          = TRUE;
      entReCfg->e.uaReCfg.relProvRspReq         = g_suCfgIntf.relProvRspReq;
      entReCfg->e.uaReCfg.relProvRspSupp        = g_suCfgIntf.relProvRspSupp;
#ifdef SO_COMPRESS
      entReCfg->e.uaReCfg.sigCompSupp           = TRUE;
#endif
      entReCfg->e.uaReCfg.insUserAgent.pres     = NOTPRSNT;
      entReCfg->e.uaReCfg.insServer.pres        = NOTPRSNT;

      entReCfg->e.uaReCfg.dfltPrxCfg.useDfltPrx    = FALSE;
      entReCfg->e.uaReCfg.dfltPrxCfg.rcvDfltPrxOnly= FALSE;
      entReCfg->e.uaReCfg.dfltPrxCfg.looseRouter   = TRUE;
#ifdef SO_COMPRESS
      entReCfg->e.uaReCfg.dfltPrxCfg.sigCompSupp   = TRUE;
#endif

      ret = suBuildProxyAddr (&entReCfg->e.uaReCfg.dfltPrxCfg);
      if (ret != ROK)
      {
         printf ("\n Wrong Proxy Server Address \n");
         /*exit (0);*/
      }
#endif
   } /* UA Entity Re Configuration */
   else
   {
#ifdef SO_NS
      entReCfg->e.nsReCfg.proxyReCfg.prxState      = LSO_PRX_STATELESS;
      entReCfg->e.nsReCfg.proxyReCfg.recordRoute   = 1;
      entReCfg->e.nsReCfg.proxyReCfg.useIpRecRoute = 1;
#endif
   } /* Proxy Entity Re Configuration */


   soMngmt.hdr.msgType          = SO_SIPMESSAGE_REQUEST;
   soMngmt.hdr.entId.ent        = ENTSO;
   soMngmt.hdr.entId.inst       = SO_APPINST0;
   soMngmt.hdr.elmId.elmnt      = STSIPENT;
   soMngmt.hdr.elmId.elmntInst1 = SO_APPINST1;
   soMngmt.hdr.elmId.elmntInst2 = SO_APPINST2;
   soMngmt.hdr.elmId.elmntInst3 = SO_APPINST3;
   soMngmt.hdr.transId          = transId;

#ifdef LCSOMILSO
   soMngmt.hdr.response.selector = SV_LC;
#else
   soMngmt.hdr.response.selector = SV_TC;
#endif
   soMngmt.hdr.response.prior     = PRIOR0;
   soMngmt.hdr.response.route     = RTESPEC;
   soMngmt.hdr.response.mem.region= DFLT_REGION; 
   soMngmt.hdr.response.mem.pool  = DFLT_POOL; 
   soMngmt.hdr.response.mem.spare = 0;  /* chendh modify it*/

   suFillPst(&pst);
   pst.srcEnt   = ENTSM;
   pst.srcInst  = SO_APPINST_0;
   pst.dstEnt   = ENTSO;
   pst.dstInst  = SO_APPINST_0;

   /*------------- Send the configuration request -------------*/
   SmMiLsoCfgReq (&(pst), &(soMngmt));

   /*------ Save The Current Configuration Parameters ---------*/
   cmMemcpy ( (U8 *) &g_entReCfg, (CONSTANT U8 *)entReCfg, sizeof (SoEntReCfg));
  
   RETVOID;
} 

/********************************************************************
*
*       Fun:   suSSapCfgReq
*
*       Desc:  Set up the SSAP configuration structure
*
*       Ret:   ROK
*              RFAILED
*
*
********************************************************************/
#ifdef ANSI
PRIVATE Void suSSapCfgReq
(
TranId     transId,
SpId       spId
)
#else
PRIVATE Void suSSapCfgReq (transId, spId)
TranId     transId;
SpId       spId;
#endif
{
   SoMngmt   soMngmt;
   SoSSapCfg *sSapCfg; 
   Pst       pst;

   TRC2 (suSSapCfgReq)

   sSapCfg = &(soMngmt.t.cfg.c.sSapCfg);
   cmMemset ((U8 *) sSapCfg,  0, sizeof (SoSSapCfg));   

   sSapCfg->sSapId        = spId;
#ifdef LWLCSOUISOT
   sSapCfg->sel           = SV_LWLC;
#else
   sSapCfg->sel           = SV_TC;
#endif
   sSapCfg->memId.region  = DFLT_REGION;
   sSapCfg->memId.pool    = DFLT_POOL;
   sSapCfg->prior         = PRIOR0;
   sSapCfg->route         = RTESPEC;
   sSapCfg->entId         = 0;
   sSapCfg->numCLegHlBins = SO_HL_SIZE;
   sSapCfg->numTransHlBins= SO_HL_SIZE;
   
   soMngmt.hdr.msgType          = SO_SIPMESSAGE_REQUEST;
   soMngmt.hdr.entId.ent        = ENTSO;
   soMngmt.hdr.entId.inst       = SO_APPINST0;
   soMngmt.hdr.elmId.elmnt      = STSSAP;
   soMngmt.hdr.elmId.elmntInst1 = SO_APPINST1;
   soMngmt.hdr.elmId.elmntInst2 = SO_APPINST2;
   soMngmt.hdr.elmId.elmntInst3 = SO_APPINST3;
   soMngmt.hdr.transId          = transId;
#ifdef LCSOMILSO
   soMngmt.hdr.response.selector= SV_LC;
#else
   soMngmt.hdr.response.selector= SV_TC;
#endif
   soMngmt.hdr.response.prior   = PRIOR0;
   soMngmt.hdr.response.route   = RTESPEC;
   soMngmt.hdr.response.mem.region = DFLT_REGION; 
   soMngmt.hdr.response.mem.pool   = DFLT_POOL; 
   soMngmt.hdr.response.mem.spare  = 0;  /* chendh modify it*/

   suFillPst (&pst);
   pst.srcEnt   = ENTSM;
   pst.srcInst  = SO_APPINST_0;
   pst.dstEnt   = ENTSO;
   pst.dstInst  = SO_APPINST_0;

   /*------------- Send the configuration request -------------*/
   SmMiLsoCfgReq (&(pst), &(soMngmt));

   RETVOID;
}

/*********************************************************************
*
*       Fun:   suStr2Port
*
*       Desc:  Converts a string into Port
*
*       Ret:   Void
*
*       Notes: None
*
*
*********************************************************************/
#ifdef ANSI
PUBLIC Void suStr2Port
(
Txt            *word,                     /* text buffer */
CmInetAddr     *address                   /* target address */
)
#else
PUBLIC Void suStr2Port(word, address)
Txt            *word;                     /* text buffer */
CmInetAddr     *address;                  /* target address */
#endif
{
   /* local variable */
   U16            i;
   U32            tmpU32;

   tmpU32 = 0;

   for (i = 0; (word[i] != '\n') && (word[i] != '\0'); i++)
   {
      tmpU32 += word[i] - '0';
      tmpU32 *= 10;
   }
   tmpU32 /= 10;

   address->port = (U16) tmpU32;

   RETVOID;
}/* suStr2Port */

/*********************************************************************
*
*       Fun:   suGetServerAddr
*
*       Desc:  Converts IP address,  port and hostname  specified
*              in string format into structure format.
*
*       Ret:   
*
*       Notes: ROK/RFAILED
*
*
*********************************************************************/
#ifdef ANSI
PUBLIC S16 suGetServerAddr
(
CmTptAddr *addr,
Txt       *hostName,
S32       idx
)
#else
PUBLIC S16 suGetServerAddr (addr, hostName, idx)
CmTptAddr *addr;
Txt       *hostName;
S32       idx;
#endif
{
   TRC2(suGetServerAddr)

   /* read off the IP address and port */
   if (cmStrlen(g_suCfgIntf.LocalIP[idx]) != 0)
   {
      suStr2IP (g_suCfgIntf.LocalIP[idx], &(addr->u.ipv4TptAddr));
   }

   addr->u.ipv4TptAddr.port = (U16) g_suCfgIntf.listenPort[idx];

   if (cmStrlen(g_suCfgIntf.localHostname[idx]) != 0)
   {
      cmMemcpy((U8 *) hostName,
               (CONSTANT U8 *) g_suCfgIntf.localHostname[idx],
               (PTR) cmStrlen((CONSTANT U8 *) g_suCfgIntf.localHostname[idx]) + 1);
   }

   RETVALUE(ROK);

} /* suGetServerAddr */

/*********************************************************************
*
*       Fun:   suBuildProxyAddr
*
*       Desc:  Converts a string into default proxy configuration type
*
*       Ret:   Void
*
*       Notes: 
*
*
*********************************************************************/
#ifdef ANSI
PUBLIC S16 suBuildProxyAddr
(
SoDfltPrxCfg   *dfltPrx  /* default proxy config */
)
#else
PUBLIC S16 suBuildProxyAddr(string, dfltPrx)
SoDfltPrxCfg   *dfltPrx; /* default proxy config */
#endif
{   
   dfltPrx->useDfltPrx     = FALSE;
   dfltPrx->rcvDfltPrxOnly = FALSE;

   dfltPrx->looseRouter    = TRUE;

#ifdef SO_COMPRESS
   dfltPrx->sigCompSupp    = TRUE;
#endif

   /* fill the IP address and port */
   if (g_suCfgIntf.proxyIP[0] != '\0')
   {
      dfltPrx->useDfltPrx         = TRUE;
      dfltPrx->rcvDfltPrxOnly     = TRUE;
      dfltPrx->choice             = LSO_DFLT_PRX_TPT_ADDR;
      dfltPrx->t.dfltPrxAddr.type = CM_TPTADDR_IPV4;
      suStr2IP (g_suCfgIntf.proxyIP, &(dfltPrx->t.dfltPrxAddr.u.ipv4TptAddr));
      dfltPrx->t.dfltPrxAddr.u.ipv4TptAddr.port = (U16)g_suCfgIntf.proxyIP;
   }

   else if (g_suCfgIntf.proxyHostname[0] != '\0')
   {
      dfltPrx->useDfltPrx     = TRUE;
      dfltPrx->rcvDfltPrxOnly = TRUE;
      dfltPrx->choice         = LSO_DFLT_PRX_DOMAIN_NAME;
       cmMemcpy((U8 *) dfltPrx->t.domainName,
                (CONSTANT U8 *) g_suCfgIntf.proxyHostname,
                (PTR ) cmStrlen((CONSTANT U8 *) g_suCfgIntf.proxyHostname) + 1);
   }

   RETVALUE(ROK);

}/* svBuildProxyAddr */

/*
*
*       Fun:   suSoEnableBnd
*
*       Desc:  Send a Control Request to Enable the
*              Bind Request
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*
*/
#ifdef ANSI
PUBLIC S16 suSoEnableBnd
(
TranId   transId,
SuId     tSapId
)
#else
PUBLIC S16 suSoEnableBnd (transId, tSapId)
TranId   transId;
SuId     tSapId;
#endif
{

   SoMngmt soMngmt;
   Pst     pst;
   SoCntrl *cntrl;

   TRC2(svSoEnableBnd)

   soMngmt.hdr.msgType             = SO_SIPMESSAGE_REQUEST;
   soMngmt.hdr.entId.ent           = ENTSO;
   soMngmt.hdr.entId.inst          = SO_APPINST0;
   soMngmt.hdr.elmId.elmnt         = STTSAP;
   soMngmt.hdr.elmId.elmntInst1    = SO_APPINST1;
   soMngmt.hdr.elmId.elmntInst2    = SO_APPINST2;
   soMngmt.hdr.elmId.elmntInst3    = SO_APPINST3;
   soMngmt.hdr.transId             = transId;
#ifdef LCSOMILSO
   soMngmt.hdr.response.selector = SV_LC;
#else
   soMngmt.hdr.response.selector = SV_TC;
#endif
   soMngmt.hdr.response.prior      = PRIOR0;
   soMngmt.hdr.response.route      = RTESPEC;
   soMngmt.hdr.response.mem.region = DFLT_REGION; 
   soMngmt.hdr.response.mem.pool   = DFLT_POOL; 
   soMngmt.hdr.response.mem.spare  = 0; 

   suFillPst(&pst);
   pst.srcEnt   = ENTSM;
   pst.srcInst  = SO_APPINST_0;
   pst.dstEnt   = ENTSO;
   pst.dstInst  = SO_APPINST_0;

   cntrl = &soMngmt.t.cntrl;

   cntrl->s.sapId   = tSapId;
   cntrl->action    = ABND_ENA;
   cntrl->subAction = SAELMNT;

   SmMiLsoCntrlReq (&pst, &soMngmt);

   RETVALUE (ROK);

}/* suSoEnableBnd */

/*
*
*       Fun:   suSoEnableTrace
*
*       Desc:  Send a Control Request to Enable the
*              TSAP Trace
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*
*/
#ifdef ANSI
PRIVATE S16 suSoEnableTrace
(
TranId   transId
)
#else
PRIVATE S16 suSoEnableTrace (transId)
TranId   transId;
#endif
{

   SoMngmt soMngmt;
   Pst     pst;
   SoCntrl *cntrl;

   TRC2(svSoEnableTrace)

   soMngmt.hdr.msgType             = SO_SIPMESSAGE_REQUEST;
   soMngmt.hdr.entId.ent           = ENTSO;
   soMngmt.hdr.entId.inst          = SO_APPINST0;
   soMngmt.hdr.elmId.elmnt         = STTSAP;
   soMngmt.hdr.elmId.elmntInst1    = SO_APPINST1;
   soMngmt.hdr.elmId.elmntInst2    = SO_APPINST2;
   soMngmt.hdr.elmId.elmntInst3    = SO_APPINST3;
   soMngmt.hdr.transId             = transId;
#ifdef LCSOMILSO
   soMngmt.hdr.response.selector = SV_LC;
#else
   soMngmt.hdr.response.selector = SV_TC;
#endif
   soMngmt.hdr.response.prior      = PRIOR0;
   soMngmt.hdr.response.route      = RTESPEC;
   soMngmt.hdr.response.mem.region = DFLT_REGION; 
   soMngmt.hdr.response.mem.pool   = DFLT_POOL; 
   soMngmt.hdr.response.mem.spare  = 0; 

   suFillPst(&pst);
   pst.srcEnt   = ENTSM;
   pst.srcInst  = SO_APPINST_0;
   pst.dstEnt   = ENTSO;
   pst.dstInst  = SO_APPINST_0;

   cntrl = &soMngmt.t.cntrl;

   cntrl->action     = AENA;
   cntrl->subAction  = SATRC;
   cntrl->s.sapId    = SO_HI_SU_ID_1;
   cntrl->s.trcCntrl.trcLen    = 1000;
   cntrl->s.trcCntrl.trcMask   = LSO_TRC_EVENT_RX | LSO_TRC_EVENT_TX;

   SmMiLsoCntrlReq (&pst, &soMngmt);

   RETVALUE (ROK);

}/* suSoEnableTrace */

/*
*
*       Fun:   suSoEnableEnt
*
*       Desc:  Send a Control Request to Enable the
*              Entity
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*
*/
#ifdef ANSI
PUBLIC S16 suSoEnableEnt
(
TranId   transId
)
#else
PUBLIC S16 suSoEnableEnt(transId)
TranId   transId;
#endif
{

   SoMngmt soMngmt;
   Pst     pst;
   SoCntrl *cntrl;

   TRC2(svSoEnableEnt)

   soMngmt.hdr.msgType             = SO_SIPMESSAGE_REQUEST;
   soMngmt.hdr.entId.ent           = ENTSO;
   soMngmt.hdr.entId.inst          = SO_APPINST0;
   soMngmt.hdr.elmId.elmnt         = STSIPENT;
   soMngmt.hdr.elmId.elmntInst1    = SO_APPINST1;
   soMngmt.hdr.elmId.elmntInst2    = SO_APPINST2;
   soMngmt.hdr.elmId.elmntInst3    = SO_APPINST3;
   soMngmt.hdr.transId             = transId;
#ifdef LCSOMILSO
   soMngmt.hdr.response.selector = SV_LC;
#else
   soMngmt.hdr.response.selector = SV_TC;
#endif
   soMngmt.hdr.response.prior      = PRIOR0;
   soMngmt.hdr.response.route      = RTESPEC;
   soMngmt.hdr.response.mem.region = DFLT_REGION; 
   soMngmt.hdr.response.mem.pool   = DFLT_POOL; 
   soMngmt.hdr.response.mem.spare  = 0; 

   suFillPst(&pst);
   pst.srcEnt   = ENTSM;
   pst.srcInst  = SO_APPINST_0;
   pst.dstEnt   = ENTSO;
   pst.dstInst  = SO_APPINST_0;

   cntrl = &soMngmt.t.cntrl;

   cntrl->s.entId   = 0;
   cntrl->action    = AENA;
   cntrl->subAction = SAELMNT;

   SmMiLsoCntrlReq (&pst, &soMngmt);

   RETVALUE (ROK);

}/* suSoEnableEnt */


#endif /*SO_TEST_NMS_TYPE*/
#endif /*SO_SUCFG_SUPPORT*/

