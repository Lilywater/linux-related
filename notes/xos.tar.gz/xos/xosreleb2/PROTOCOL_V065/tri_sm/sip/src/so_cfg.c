/**********************************************************************

         (c) COPYRIGHT 1989-2003 by 
         Beijing Xinwei Telecom Technology co., ltd. ShenZhen R&D center
         All rights reserved.

     
**********************************************************************/

/**********************************************************************

     Name:     so_cfg.c 

     Type:     C source file

     Desc:     C code for general, SAP and entity configuration 

     Create :  2006-04-27 chendh
     

**********************************************************************/

/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lhi.h"           /* HIT LM interface defines        */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "cst.h"           /* Compression module define       */
#include "so_cm.h"         /* SIP layer utility functions     */
#include "su_cfg.h"       /* SIP User defines                */
#include "so.h"            /* SIP Layer defines               */


#ifdef CP_OAM_SUPPORT
#include "so_cfg.h" 
#include "sm.h"

#include "xosshell.h"
#include "cp_tab_def.h"

#include "oam_interface.h"
#endif

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lhi.x"           /* HIT LM interface defines        */
#include "lso.x"           /* Layer management SIP            */
#include "cst.x"           /* Compression module              */
#include "sot.x"           /* SOT interface defines           */
#include "so_cm.x"         /* SIP layer utility functions     */
#include "su_cfg.x"       /* SIP User structures             */

#include "so_tcm.x"
#include "so.x"
#include "hi_init.h"

#ifdef CP_OAM_SUPPORT
#include "so_oam.x"
#include "so_cfg.x" 
#include "sm.x"
#endif /*CP_OAM_SUPPORT*/

EXTERN U32 g_soDbgMask;

U32 g_sipUaModId;

#define SU_LOCAL_DBGP(_args)                                  \
{                                                             \
    /*---------------- Print Debug Information -------------*/\
	/*U8 prntBuf[1024];										  \
     sprintf (prntBuf, "[%s: %d] ", __FILE__, __LINE__); \
     sprintf _args;*/                                           \
}

#ifdef CP_OAM_SUPPORT

/* global variables */
PRIVATE TranId   g_cfgTransId = 0;

PUBLIC CmLListCp gSoSmQ[SIP_CONFIG_Q_TOTAL_NUM];
SoNmsConfigData g_SoNmsCfgData;

unsigned int soNmsCfgTbl[SM_SIPCFG_TBL_CNT]={APP_TABLE_ID_COM_IP,\
                        APP_TABLE_ID_VOIP_SIP_GEN,\
                        APP_TABLE_ID_VOIP_SIP_ENT,	\
                        APP_TABLE_ID_VOIP_SIP_HDR,\
                        APP_TABLE_ID_VOIP_SIP_REUA};

/* definition in su_cfg.c */
EXTERN Void soNmsFillPst       ARGS((Pst *pst));
EXTERN Void suStr2IP        ARGS((Txt  *word, /* text buffer */
								  CmInetAddr *address    /* target address */));

PRIVATE Void soNmsGenCfgReq     ARGS((TranId transId));
PRIVATE Void soNmsTSapCfgReq    ARGS((TranId transId,
                                   SpId   spId,
                                   SuId   suId));

PRIVATE Void soNmsSSapCfgReq    ARGS((TranId transId,
                                   SpId   spId));

PRIVATE Void soNmsEntCfgReq     ARGS((TranId transId,
                                   U8     entityType));


/**********************************************************************
*
*       Fun:   soNmsFillPst
*
*       Desc:  Fills the Post Structure
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*
**********************************************************************/
#ifdef ANSI
PUBLIC Void soNmsFillPst
(
Pst   *pst
)
#else
PRIVATE Void soNmsFillPst(pst)
Pst   *pst;   
#endif   
{
   TRC2(soNmsFillPst)

   /*---------- Fill default values in Pst structure ----------*/
   pst->srcEnt   = ENTSM;
   pst->srcInst  = SO_APPINST_0;
   pst->dstEnt   = ENTSO;
   pst->dstInst  = SO_APPINST_0;

   pst->dstProcId = SFndProcId();
   pst->srcProcId = SFndProcId();
   pst->prior     = PRIOR0;
   pst->route     = RTESPEC;
   pst->event     = EVTNONE;
   pst->region    = DFLT_REGION; 
   pst->pool      = DFLT_POOL;
   
   #ifdef LCSOMILSO 
	   pst->selector  = SV_LC;
   #else
	   pst->selector  = SV_TC;
   #endif
   

   RETVOID;
}

/********************************************************************************************************
  Function: smSoSendReqQ() 
  Description: sccp get msg buffer from sm queue, and send it out
  Calls:
  Called By: 
  Input:   smMsg: msg buffer get from sm queue 
               
  Output:  send LSP message to SP ENTITY

  
  Return:   ROK:success; 
                RFAILED: failure
  Others:
 ********************************************************************************************************/
S16 smSoSendReqQ(CmLList *node)
{
    Pst smSoPst;
    Header *msgHeader;
    S16 ret = ROK;
   
    TRC2(smSoSendReqQ);      
    msgHeader = (Header *)cmLListNode(node);


    soNmsFillPst(&smSoPst);

    switch(msgHeader->msgType)
    {
        case TCFG:
            ret = SmMiLsoCfgReq(&smSoPst, (SoMngmt *)cmLListNode(node));
            break;
        case TCNTRL:
            ret = SmMiLsoCntrlReq(&smSoPst, (SoMngmt *)cmLListNode(node));
            break;
        case TSTS:
            ret = SmMiLsoStsReq(&smSoPst, NOZEROSTS, (SoMngmt *)cmLListNode(node));
            break;
        case TSSTA:
            ret = SmMiLsoStaReq(&smSoPst, (SoMngmt *)cmLListNode(node));
            break;
        default:
            RETVALUE(RFAILED);
    }

    RETVALUE(ret);
}

/********************************************************************
*
*       Fun:   soNmsConfigureUa
*
*       Desc:  Setup the SO Layer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*
********************************************************************/
PUBLIC   Void   soNmsConfigureUa()
{

   TRC2(soNmsConfigureUa)

   g_cfgTransId = 0;   

   /*----------------- General Configuration ------------------*/
   soNmsGenCfgReq (g_cfgTransId++);

   /*-----------------TUCL SAP Configuration ------------------*/
   soNmsTSapCfgReq (g_cfgTransId++, SO_HI_SP_ID_1, SO_HI_SU_ID_1);

#ifdef SO_DNS
   /*-------------- TUCL DNS SAP Configuration ----------------*/
   soNmsTSapCfgReq (g_cfgTransId++, SO_HI_SP_ID_2, SO_HI_SU_ID_2);
#endif /*SO_DNS*/

   /*---------------- SIP Entity Configuration ----------------*/
   soNmsEntCfgReq (g_cfgTransId++, LSO_ENT_UA);

   /*------------- Service User SAP Configuration -------------*/
   soNmsSSapCfgReq (g_cfgTransId++, SO_SV_SP_ID_1);

   RETVOID;
} /* suNmsConfigureUa */

PUBLIC   Void   soNmsGenCfgReq(TranId  transId)
{
	/* local variables */
	CmLList *node;
	SoMngmt     *soMngmt;   
	SoGenCfg    *genCfg; 
	SoGenReCfg  *genReCfg;
	Pst         pst;
	
	TRC2(soNmsGenCfgReq)
		
	/* alloc a node for save sm msg info */
	if( ROK != smGetQNode(&node, sizeof(SoMngmt)))
	{
		RETVOID;
	}
	
	soMngmt = (SoMngmt *)cmLListNode(node) ;
	soMngmt->hdr.msgLen = sizeof( SoMngmt);
			
	genCfg   = &(soMngmt->t.cfg.c.genCfg);
	genReCfg = &(soMngmt->t.cfg.r.genReCfg);
	cmMemset ((U8 *) genCfg  , 0, sizeof (SoGenCfg));   
	cmMemset ((U8 *) genReCfg, 0, sizeof (SoGenReCfg));   
	
	/*----------- Fill General Configuration Parameters ---------*/
	
	cmMemcpy((U8 *) (genCfg->protVer), 
		(CONSTANT U8 *) SO_PROTVER,
		(PTR) LSO_PROTVER_SZ);
	
	genCfg->maxNmbSSaps     = SO_MAX_SSAP;
	genCfg->maxNmbTSaps     = SO_MAX_TSAP;
	genCfg->maxNmbUA        = SO_MAX_UA;
	genCfg->maxNmbNS        = SO_MAX_NS;
	genCfg->maxNmbRemReg    = SO_MAX_REMREG;
	genCfg->maxNmbActCalls  = SO_MAX_ACT_CALL;
	genCfg->maxTransPerEnt  = SO_MAX_TRAN_ENT;
	genCfg->resThreshUpper  = SO_RES_THR_UP;
	genCfg->resThreshLower  = SO_RES_THR_LOW;
	genCfg->maxPendLocReq   = SO_MAX_PEND_LOC;
	genCfg->maxBlkSize      = SO_BLKSZ;
	genCfg->locRegSz        = LSO_CACHE_MIN_MEM_SIZE;
	genCfg->remRegSz        = LSO_CACHE_MIN_MEM_SIZE;
	genCfg->mtu             = SO_MTU;
	
#ifdef SO_ABNF_MT_LIB
	genCfg->nmbEDThreads    = 2;
#endif
	
#ifdef SO_UA
	genCfg->maxNumRegPerEnt = SO_MAX_REG_PER_ENTITY;
	genCfg->maxNumCnctPerEnt= SO_MAX_CNCT_PER_ENTITY;
#endif
	
#ifdef SO_DNS
	genCfg->dnsCfg.useDns           = TRUE;
	genCfg->dnsCfg.useDnsCache      = TRUE;
	genCfg->dnsCfg.dnsACacheSz      = SO_DNS_A_CACHE_SZ;
	genCfg->dnsCfg.dnsSrvCacheSz    = SO_DNS_SRV_CACHE_SZ;
#ifdef SO_ENUM
	genCfg->dnsCfg.dnsNaptrCacheSz  = SO_DNS_NAPTR_CACHE_SZ;
#endif
#endif
	
#ifdef SO_NS
#ifdef SO_LCS
	genCfg->locSrvCfg.locCachePres  = FALSE;
	genCfg->locSrvCfg.locCacheSz    = SO_LOCSRV_SZ;
	genCfg->locSrvCfg.locSrchHlBins = SO_HL_SIZE;
#endif
#endif
	
	genCfg->lmPst.dstProcId = SFndProcId();
	genCfg->lmPst.srcProcId = SFndProcId(); 
	genCfg->lmPst.dstEnt    = ENTSM;
	genCfg->lmPst.dstInst   = SO_APPINST_0;
	genCfg->lmPst.srcEnt    = ENTSO;
	genCfg->lmPst.srcInst   = SO_APPINST_0;
	genCfg->lmPst.prior     = PRIOR0;
	genCfg->lmPst.route     = RTESPEC;
	genCfg->lmPst.event     = EVTNONE;
	genCfg->lmPst.region    = DFLT_REGION; 
	genCfg->lmPst.pool      = DFLT_POOL; 
#ifdef LCSOMILSO
	genCfg->lmPst.selector  = SV_LC;
#else
	genCfg->lmPst.selector  = SV_TC;
#endif
	
#ifdef SO_COMPRESS
	/*-- Fill the SV layer as compression/decompression module --*/
	genCfg->compPst.dstProcId = SFndProcId();
	genCfg->compPst.srcProcId = SFndProcId(); 
	genCfg->compPst.dstEnt    = ENTSV;
	genCfg->compPst.dstInst   = SO_APPINST_0;
	genCfg->compPst.srcEnt    = ENTSO;
	genCfg->compPst.srcInst   = SO_APPINST_0;
	genCfg->compPst.prior     = PRIOR0;
	genCfg->compPst.route     = RTESPEC;
	genCfg->compPst.event     = EVTNONE;
	genCfg->compPst.region    = DFLT_REGION; 
	genCfg->compPst.pool      = DFLT_POOL; 
	genCfg->compPst.selector  = SV_LC;
#endif
	
	cmMemcpy((U8 *) genCfg->nodeIdStr, (CONSTANT U8 *) SO_NODEIDSTR, sizeof(SO_NODEIDSTR));
	
#ifdef DEBUGP
	genCfg->dbgMask         = g_soDbgMask;
#endif
#ifdef SV_LOAD
	genCfg->dbgMask         = g_soDbgMask;
#endif
	
	/*------------- Fill General Reconfiguration Part -----------*/
	
	genReCfg->GMToffset     = SO_GMT_OFFSET;
	
#ifdef SO_DNS
	genReCfg->dnsReCfg.dnsTptAddr.type = CM_TPTADDR_IPV4;
	
	suStr2IP (SO_REM_ADDR_DNS, &(genReCfg->dnsReCfg.dnsTptAddr.u.ipv4TptAddr));
	
	genReCfg->dnsReCfg.dnsTptAddr.u.ipv4TptAddr.port = SO_REM_PORT_DNS;
	
	/*------ Address and port of the DNS listening server ------*/
	genReCfg->dnsReCfg.locAddr.type                  = CM_TPTADDR_IPV4;
	genReCfg->dnsReCfg.locAddr.u.ipv4TptAddr.address = CM_INET_INADDR_ANY;
	genReCfg->dnsReCfg.locAddr.u.ipv4TptAddr.port    = CM_INPORT_ANY;
	
	/*---- Transport parameters for the DNS listening server ---*/
	genReCfg->dnsReCfg.dnsTptParam.type              = CM_TPTPARAM_SOCK;
	genReCfg->dnsReCfg.dnsTptParam.u.sockParam.listenQSize
		= SO_TPTPARAM_QSIZE;     
	genReCfg->dnsReCfg.dnsTptParam.u.sockParam.numOpts = 0;
	
	genReCfg->dnsReCfg.tSapId          = SO_HI_SU_ID_2;
	genReCfg->dnsReCfg.tptSrvId        = SO_TPTSRV_DNS;
	genReCfg->dnsReCfg.maxDnsRetry     = SO_DNS_RETRY;
	genReCfg->dnsReCfg.dnsQueryTmr.enb = TRUE;
	genReCfg->dnsReCfg.dnsQueryTmr.val = SO_DNS_QUERY_TM;
	genReCfg->dnsReCfg.maxDnsCacheExp  = SO_DNS_CACHE_EXP;
#endif
	
	/*-------- Setup the Transaction Module Timer Values -------*/
	genReCfg->tmrReTxCfg.t1         = g_SoNmsCfgData.soNmsGenCfg.tracnT1;
	genReCfg->tmrReTxCfg.t2         = g_SoNmsCfgData.soNmsGenCfg.tracnT2;
	genReCfg->tmrReTxCfg.t4         = g_SoNmsCfgData.soNmsGenCfg.tracnT4;
	
#if (defined(SO_NAT) && defined(SO_USE_UDP_SRVR))
	genReCfg->tmrReTxCfg.natTmrVal  = SO_NAT_TMR;
#endif 
	
#ifdef SO_NS
#ifdef SO_LCS
	genReCfg->locSrvReCfg.dfltLocCacheExp = SO_LOC_CACHE_DFLT_EXP;
	genReCfg->locSrvReCfg.maxLocCacheExp  = SO_LOC_CACHE_MAX_EXP;
#endif
#endif
	
	/*Hdr for Mngmt*/
	soMngmt->hdr.msgType          = SO_SIPMESSAGE_REQUEST;
	soMngmt->hdr.entId.ent        = ENTSO;
	soMngmt->hdr.entId.inst       = SO_APPINST0;
	soMngmt->hdr.elmId.elmnt      = STGEN;
	soMngmt->hdr.elmId.elmntInst1 = SO_APPINST1;
	soMngmt->hdr.elmId.elmntInst2 = SO_APPINST2;
	soMngmt->hdr.elmId.elmntInst3 = SO_APPINST3;
	soMngmt->hdr.transId          = transId;
#ifdef LCSOMILSO
	soMngmt->hdr.response.selector= SV_LC;
#else
	soMngmt->hdr.response.selector= SV_TC;
#endif
	soMngmt->hdr.response.prior   = PRIOR0;
	soMngmt->hdr.response.route   = RTESPEC;
	soMngmt->hdr.response.mem.region = DFLT_REGION; 
	soMngmt->hdr.response.mem.pool   = DFLT_POOL; 
	soMngmt->hdr.response.mem.spare  = 0; /* chendh modify it*/
	
	soNmsFillPst(&pst);
	
	/*------------- Add to queue -------------*/
	cmLListAdd2Tail(&gSoSmQ[SIP_GENCFG_Q], node);
	
	RETVOID;
}

/*********************************************************************
*
*       Fun:   soNmsTSapCfgReq
*
*       Desc:  Set up the TSAP configuration structure
*
*       Ret:   ROK
*              RFAILED
*
*
*********************************************************************/
PRIVATE Void soNmsTSapCfgReq
(
TranId           transId,
SpId             spId,
SuId             suId 
)
{
	CmLList *node;
	SoMngmt     *soMngmt;   
	SoTSapCfg    *tSapCfg; 
    SoTSapReCfg  *tSapReCfg;
    Pst          pst;

    TRC2 (soNmsTSapCfgReq)
		
	/* alloc a node for save sm msg info */
	if( ROK != smGetQNode(&node, sizeof(SoMngmt)))
	{
		RETVOID;
	}
	
	soMngmt = (SoMngmt *)cmLListNode(node) ;
	soMngmt->hdr.msgLen = sizeof( SoMngmt);
	
	tSapCfg   = &(soMngmt->t.cfg.c.tSapCfg);
	tSapReCfg = &(soMngmt->t.cfg.r.tSapReCfg);
	
	cmMemset ((U8 *) tSapCfg  , 0, sizeof (SoTSapCfg));   
	cmMemset ((U8 *) tSapReCfg, 0, sizeof (SoTSapReCfg));   
	
	tSapCfg->tSapId       = suId;
	tSapCfg->spId         = spId;
	tSapCfg->memId.region = DFLT_REGION;
	tSapCfg->memId.pool   = DFLT_POOL;
	tSapCfg->dstProcId    = SFndProcId();
	tSapCfg->dstEnt       = ENTHI;
	tSapCfg->dstInst      = SO_APPINST0;
	tSapCfg->dstPrior     = PRIOR0;
	tSapCfg->dstRoute     = RTESPEC;
#ifdef LCSOLIHIT
	tSapCfg->dstSel       = SV_LC;
#else
	tSapCfg->dstSel       = SV_TC;
#endif
	
#ifndef HI_MULTI_THREADED
#ifdef SV_LOAD
	tSapCfg->dstSel       = SV_TC;
#endif
#endif
	
	tSapCfg->suConIdHlBins= SO_HL_SIZE;
	tSapCfg->tptAddrHlBins= SO_HL_SIZE;
	
	/*--------- Fill TSAP Reconfiguration information ----------*/
	tSapReCfg->tPar.type                    = CM_TPTPARAM_SOCK; 
	tSapReCfg->tPar.u.sockParam.listenQSize = SO_TPTPARAM_QSIZE;
	tSapReCfg->tPar.u.sockParam.numOpts     = 0;
	
	tSapReCfg->maxBndRetry  = SO_TSAP_BNDRETRY;
	tSapReCfg->bndTmCfg.enb = TRUE;
	tSapReCfg->bndTmCfg.val = SO_TSAP_BNDTM;
	
	soMngmt->hdr.msgType          = SO_SIPMESSAGE_REQUEST;
	soMngmt->hdr.entId.ent        = ENTSO;
	soMngmt->hdr.entId.inst       = SO_APPINST0;
	soMngmt->hdr.elmId.elmnt      = STTSAP;
	soMngmt->hdr.elmId.elmntInst1 = SO_APPINST1;
	soMngmt->hdr.elmId.elmntInst2 = SO_APPINST2;
	soMngmt->hdr.elmId.elmntInst3 = SO_APPINST3;
	soMngmt->hdr.transId          = transId;
#ifdef LCSOMILSO
	soMngmt->hdr.response.selector= SV_LC;
#else
	soMngmt->hdr.response.selector= SV_TC;
#endif
	soMngmt->hdr.response.prior   = PRIOR0;
	soMngmt->hdr.response.route   = RTESPEC;
	soMngmt->hdr.response.mem.region = DFLT_REGION; 
	soMngmt->hdr.response.mem.pool   = DFLT_POOL; 
	soMngmt->hdr.response.mem.spare  = 0; /* chendh modify it*/
	
	soNmsFillPst (&pst);
	
	/*------------- Add to queue -------------*/
	if(suId == SO_HI_SU_ID_1)
	{
		/* TSAP configuration */
		cmLListAdd2Tail(&gSoSmQ[SIP_TSAPCFG_Q], node);
	}
	else 
	{
		/* DNS TSAP configuration */
		cmLListAdd2Tail(&gSoSmQ[SIP_TSAPDNSCFG_Q], node);
	}

	RETVOID;
} /* soNmsTSapCfgReq */

/********************************************************************
*
*       Fun:   suEntCfgReq
*
*       Desc:  Set up the Entity configuration structure
*
*       Ret:   ROK
*              RFAILED
*
*
********************************************************************/
#ifdef ANSI
PRIVATE Void soNmsEntCfgReq
(
TranId   transId,
U8       entityType
)
#else
PRIVATE Void soNmsEntCfgReq (transId, entityType)
TranId   transId;
U8       entityType;
#endif
{
	CmLList		  *node;
	SoMngmt        *soMngmt;
	SoEntCfg       *entCfg;
	SoEntReCfg     *entReCfg;
	SoTptSrvLstCfg *tptSrvLst;
	Pst            pst;
		
	TRC2 (soNmsEntCfgReq)
		
	/* alloc a node for save sm msg info */
	if( ROK != smGetQNode(&node, sizeof(SoMngmt)))
	{
		RETVOID;
	}
	
	soMngmt = (SoMngmt *)cmLListNode(node) ;
	soMngmt->hdr.msgLen = sizeof( SoMngmt);
		
		
	entCfg     = &(soMngmt->t.cfg.c.entCfg);
	entReCfg   = &(soMngmt->t.cfg.r.entReCfg);
	tptSrvLst  = &(soMngmt->t.cfg.c.entCfg.tptSrvLstCfg);
	cmMemset ((U8 *) entCfg  , 0, sizeof (SoEntCfg));   
	cmMemset ((U8 *) entReCfg, 0, sizeof (SoEntReCfg));   
	cmMemset ((U8 *) tptSrvLst,0, sizeof (SoTptSrvLstCfg));   
	
	/*---------------- Configuration Parameter -----------------*/
	
	entCfg->entId                 = 0;
	entCfg->type                  = entityType;
#ifdef SO_UA
	entCfg->e.uaCfg.callIdHlBins        = SO_HL_SIZE;
	entCfg->e.uaCfg.callHdlHlBins       = SO_HL_SIZE;
	entCfg->e.uaCfg.regAddrHlBins       = SO_HL_SIZE;
	entCfg->e.uaCfg.regContactHlBins    = SO_HL_SIZE;
	entCfg->e.uaCfg.regHlBins           = SO_HL_SIZE;
	entCfg->e.uaCfg.clientTransHlBins   = SO_HL_SIZE;
	entCfg->e.uaCfg.serverTransHlBins   = SO_HL_SIZE;
#endif
	
	cmMemcpy ((U8 *) &(entCfg->domainName), 
		(CONSTANT U8 *)SO_UA_DOMAINNAME,
		sizeof(SO_UA_DOMAINNAME));
	entCfg->domainName[sizeof(SO_UA_DOMAINNAME)] = 0;
	
	/*----------- Configuration One Transport Server ------------*/
	
	/*------- Configure A UDP server -------*/
	tptSrvLst->nmbTptSrv                = 1;
	tptSrvLst->tptSrvCfg[0].tSapId      = SO_HI_SU_ID_1;
	tptSrvLst->tptSrvCfg[0].tptSrvId    = 1;
	tptSrvLst->tptSrvCfg[0].nmbSSap     = 1;
	tptSrvLst->tptSrvCfg[0].sSapLst[0]  = SO_SV_SP_ID_1;
	
	tptSrvLst->tptSrvCfg[0].tptProt     = LSO_TPTPROT_UDP_PRIOR;
	tptSrvLst->tptSrvCfg[0].tptAddr.type= CM_TPTADDR_IPV4;
	
	/* fill server addr */
	/* read off the IP address and port */

	tptSrvLst->tptSrvCfg[0].tptAddr.u.ipv4TptAddr.address = CM_INET_NTOH_U32(g_SoNmsCfgData.soNmsEntCfg.IpAddr);
	tptSrvLst->tptSrvCfg[0].tptAddr.u.ipv4TptAddr.port = g_SoNmsCfgData.soNmsEntCfg.listenPort;
	
	cmMemcpy((U8 *) tptSrvLst->tptSrvCfg[0].hostname,
		(CONSTANT U8 *) g_SoNmsCfgData.soNmsEntCfg.domainName,
		(PTR) cmStrlen((CONSTANT U8 *) g_SoNmsCfgData.soNmsEntCfg.domainName) + 1);

	
	tptSrvLst->tptSrvCfg[0].tPar.type                = CM_TPTPARAM_SOCK;
	tptSrvLst->tptSrvCfg[0].tPar.u.sockParam.numOpts = 0;
	tptSrvLst->tptSrvCfg[0].tPar.u.sockParam.listenQSize = SO_TPTPARAM_QSIZE;
	
	/*------- Configure A TCP server -------*/
	if (entityType == LSO_ENT_UA)
	{
		tptSrvLst->nmbTptSrv                += 1;
		
		cmMemcpy ((U8 *) &tptSrvLst->tptSrvCfg[1],
			(CONSTANT U8 *) &tptSrvLst->tptSrvCfg[0],
			sizeof (SoTptSrvCfg));
		
		tptSrvLst->tptSrvCfg[1].tptSrvId    = 2;
		tptSrvLst->tptSrvCfg[1].tptProt     = LSO_TPTPROT_TCP;
	}
	
	/*---------------Re-Configuration Parameter ----------------*/
	entReCfg->hdrCfg.insDate      = g_SoNmsCfgData.soNmsHdrCfg.insDates;
	entReCfg->hdrCfg.insAllow     = g_SoNmsCfgData.soNmsHdrCfg.insAllow;
	entReCfg->hdrCfg.insExpires   = g_SoNmsCfgData.soNmsHdrCfg.insExpires;
	entReCfg->hdrCfg.insUAHdr     = g_SoNmsCfgData.soNmsHdrCfg.insUAHdr;
	entReCfg->hdrCfg.insSupported = g_SoNmsCfgData.soNmsHdrCfg.insSupported;
	entReCfg->hdrCfg.insAccept    = g_SoNmsCfgData.soNmsHdrCfg.insAccept;
	entReCfg->hdrCfg.maxFwd       = g_SoNmsCfgData.soNmsHdrCfg.maxFwd;
	
	entReCfg->hdrCfg.insOrg.pres  = PRSNT_NODEF;
	cmMemcpy ((U8 *) entReCfg->hdrCfg.insOrg.str, 
		(CONSTANT U8 *)g_SoNmsCfgData.soNmsHdrCfg.insOrg,
		cmStrlen((CONSTANT U8 *)g_SoNmsCfgData.soNmsHdrCfg.insOrg) < LSO_STR_SZ ? cmStrlen((CONSTANT U8 *)g_SoNmsCfgData.soNmsHdrCfg.insOrg) : LSO_STR_SZ);
	
	entReCfg->hdrCfg.insSubject.pres  = PRSNT_NODEF;
	cmMemcpy ((U8 *) entReCfg->hdrCfg.insSubject.str, 
		(CONSTANT U8 *)g_SoNmsCfgData.soNmsHdrCfg.insSubject,
		cmStrlen((CONSTANT U8 *)g_SoNmsCfgData.soNmsHdrCfg.insSubject) < LSO_STR_SZ ? cmStrlen((CONSTANT U8 *)g_SoNmsCfgData.soNmsHdrCfg.insSubject) : LSO_STR_SZ);
	
	entReCfg->snd100Always        = FALSE;
	entReCfg->useCompact          = FALSE;
	entReCfg->alwRecurse          = FALSE;
	entReCfg->decodeSDP           = TRUE;
	entReCfg->tptInActvTmr        = SO_TCP_ACTV_TM;
	
#ifdef SO_TLS
	entReCfg->tlsInActvTmr        = SO_TCP_ACTV_TM;
#endif
	
#ifdef SO_SESSTIMER
	entReCfg->useSessTmr          = FALSE;
#endif
	
	if (entityType == LSO_ENT_UA)
	{
#ifdef SO_UA
		entReCfg->e.uaReCfg.threshUpper           = SO_LOCREG_THRESH_UPPER;
		entReCfg->e.uaReCfg.threshLower           = SO_LOCREG_THRESH_LOWER;
		entReCfg->e.uaReCfg.alw3rdParty           = TRUE;
		entReCfg->e.uaReCfg.dfltExpiresInRegister = g_SoNmsCfgData.soNmsReUaCfg.dfltExpiresInRegister;
		entReCfg->e.uaReCfg.dfltExpiresInInvite   = SO_LOCREG_DFLT_EXP_INV;
		entReCfg->e.uaReCfg.alertUsrOnExp         = (Bool)g_SoNmsCfgData.soNmsReUaCfg.alertUsrOnExp;
		entReCfg->e.uaReCfg.refreshOnExp          = g_SoNmsCfgData.soNmsReUaCfg.refreshOnExp;
		entReCfg->e.uaReCfg.chkLocUsrReg          = FALSE;
		entReCfg->e.uaReCfg.insTmStamp            = FALSE;
		entReCfg->e.uaReCfg.addContact            = TRUE;
		entReCfg->e.uaReCfg.useIpContact          = TRUE;
		entReCfg->e.uaReCfg.relProvRspReq         = FALSE;
		entReCfg->e.uaReCfg.relProvRspSupp        = FALSE;
#ifdef SO_COMPRESS
		entReCfg->e.uaReCfg.sigCompSupp           = TRUE;
#endif
		entReCfg->e.uaReCfg.insUserAgent.pres     = NOTPRSNT;
		entReCfg->e.uaReCfg.insServer.pres        = NOTPRSNT;
		
		entReCfg->e.uaReCfg.dfltPrxCfg.useDfltPrx    = FALSE;
		entReCfg->e.uaReCfg.dfltPrxCfg.rcvDfltPrxOnly= FALSE;
		entReCfg->e.uaReCfg.dfltPrxCfg.looseRouter   = TRUE;
#ifdef SO_COMPRESS
		entReCfg->e.uaReCfg.dfltPrxCfg.sigCompSupp   = TRUE;
#endif
	
/* ��ʱ������ */
#if 0
		ret = suBuildProxyAddr (&entReCfg->e.uaReCfg.dfltPrxCfg);
		if (ret != ROK)
		{
			printf ("\n Wrong Proxy Server Address \n");
			/*exit (0);*/
		}
#endif

#endif
	} /* UA Entity Re Configuration */
	else
	{
#ifdef SO_NS
		entReCfg->e.nsReCfg.proxyReCfg.prxState      = LSO_PRX_STATELESS;
		entReCfg->e.nsReCfg.proxyReCfg.recordRoute   = 1;
		entReCfg->e.nsReCfg.proxyReCfg.useIpRecRoute = 1;
#endif
	} /* Proxy Entity Re Configuration */
	
	
	soMngmt->hdr.msgType          = SO_SIPMESSAGE_REQUEST;
	soMngmt->hdr.entId.ent        = ENTSO;
	soMngmt->hdr.entId.inst       = SO_APPINST0;
	soMngmt->hdr.elmId.elmnt      = STSIPENT;
	soMngmt->hdr.elmId.elmntInst1 = SO_APPINST1;
	soMngmt->hdr.elmId.elmntInst2 = SO_APPINST2;
	soMngmt->hdr.elmId.elmntInst3 = SO_APPINST3;
	soMngmt->hdr.transId          = transId;
	
#ifdef LCSOMILSO
	soMngmt->hdr.response.selector = SV_LC;
#else
	soMngmt->hdr.response.selector = SV_TC;
#endif
	soMngmt->hdr.response.prior     = PRIOR0;
	soMngmt->hdr.response.route     = RTESPEC;
	soMngmt->hdr.response.mem.region= DFLT_REGION; 
	soMngmt->hdr.response.mem.pool  = DFLT_POOL; 
	soMngmt->hdr.response.mem.spare = 0;  /* chendh modify it*/
	
	soNmsFillPst(&pst);
	
	/*------------- add node to queue -------------*/
	cmLListAdd2Tail(&gSoSmQ[SIP_ENTCFG_Q], node);
	
	RETVOID;
} 

/********************************************************************
*
*       Fun:   soNmsSSapCfgReq
*
*       Desc:  Set up the SSAP configuration structure
*
*       Ret:   ROK
*              RFAILED
*
*
********************************************************************/

#ifdef ANSI
PRIVATE Void soNmsSSapCfgReq
(
TranId     transId,
SpId       spId
)
#else
PRIVATE Void soNmsSSapCfgReq (transId, spId)
TranId     transId;
SpId       spId;
#endif
{
	CmLList		  *node;
	SoMngmt   *soMngmt;
	SoSSapCfg *sSapCfg; 
	Pst       pst;
	
	TRC2 (soNmsSSapCfgReq)

	/* alloc a node for save sm msg info */
	if( ROK != smGetQNode(&node, sizeof(SoMngmt)))
	{
		RETVOID;
	}
	
	soMngmt = (SoMngmt *)cmLListNode(node) ;
	soMngmt->hdr.msgLen = sizeof( SoMngmt);
	
	sSapCfg = &(soMngmt->t.cfg.c.sSapCfg);
	cmMemset ((U8 *) sSapCfg,  0, sizeof (SoSSapCfg));   
	
	sSapCfg->sSapId        = spId;
#ifdef LCSOUISOT
	sSapCfg->sel           = SV_LC_SS;
#elif LWLCSOUISOT
	sSapCfg->sel           = SV_LWLC_SS;
#else
	sSapCfg->sel           = SV_TC;
#endif
	sSapCfg->memId.region  = DFLT_REGION;
	sSapCfg->memId.pool    = DFLT_POOL;
	sSapCfg->prior         = PRIOR0;
	sSapCfg->route         = RTESPEC;
	sSapCfg->entId         = 0;
	sSapCfg->numCLegHlBins = SO_HL_SIZE;
	sSapCfg->numTransHlBins= SO_HL_SIZE;
	
	soMngmt->hdr.msgType          = SO_SIPMESSAGE_REQUEST;
	soMngmt->hdr.entId.ent        = ENTSO;
	soMngmt->hdr.entId.inst       = SO_APPINST0;
	soMngmt->hdr.elmId.elmnt      = STSSAP;
	soMngmt->hdr.elmId.elmntInst1 = SO_APPINST1;
	soMngmt->hdr.elmId.elmntInst2 = SO_APPINST2;
	soMngmt->hdr.elmId.elmntInst3 = SO_APPINST3;
	soMngmt->hdr.transId          = transId;
#ifdef LCSOMILSO
	soMngmt->hdr.response.selector= SV_LC;
#else
	soMngmt->hdr.response.selector= SV_TC;
#endif
	soMngmt->hdr.response.prior   = PRIOR0;
	soMngmt->hdr.response.route   = RTESPEC;
	soMngmt->hdr.response.mem.region = DFLT_REGION; 
	soMngmt->hdr.response.mem.pool   = DFLT_POOL; 
	soMngmt->hdr.response.mem.spare  = 0;  /* chendh modify it*/
	
	soNmsFillPst (&pst);
	
	/*------------- add node to queue -------------*/
	cmLListAdd2Tail(&gSoSmQ[SIP_SSAPFG_Q], node);
	
	RETVOID;
}

/*
*
*       Fun:   soSoEnableBnd
*
*       Desc:  Send a Control Request to Enable the
*              Bind Request
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*
*/
#ifdef ANSI
PUBLIC S16 SoNmsEnableBnd
(
TranId   transId,
SuId     tSapId
)
#else
PUBLIC S16 SoNmsEnableBnd (transId, tSapId)
TranId   transId;
SuId     tSapId;
#endif
{

   SoMngmt soMngmt;
   Pst     pst;
   SoCntrl *cntrl;

   TRC2(SoNmsEnableBnd)

   soMngmt.hdr.msgType             = SO_SIPMESSAGE_REQUEST;
   soMngmt.hdr.entId.ent           = ENTSO;
   soMngmt.hdr.entId.inst          = SO_APPINST0;
   soMngmt.hdr.elmId.elmnt         = STTSAP;
   soMngmt.hdr.elmId.elmntInst1    = SO_APPINST1;
   soMngmt.hdr.elmId.elmntInst2    = SO_APPINST2;
   soMngmt.hdr.elmId.elmntInst3    = SO_APPINST3;
   soMngmt.hdr.transId             = transId;
#ifdef LCSOMILSO
   soMngmt.hdr.response.selector = SV_LC;
#else
   soMngmt.hdr.response.selector = SV_TC;
#endif
   soMngmt.hdr.response.prior      = PRIOR0;
   soMngmt.hdr.response.route      = RTESPEC;
   soMngmt.hdr.response.mem.region = DFLT_REGION; 
   soMngmt.hdr.response.mem.pool   = DFLT_POOL; 
   soMngmt.hdr.response.mem.spare  = 0; 

   soNmsFillPst(&pst);
   pst.srcEnt   = ENTSM;
   pst.srcInst  = SO_APPINST_0;
   pst.dstEnt   = ENTSO;
   pst.dstInst  = SO_APPINST_0;

   cntrl = &soMngmt.t.cntrl;

   cntrl->s.sapId   = tSapId;
   cntrl->action    = ABND_ENA;
   cntrl->subAction = SAELMNT;

   SmMiLsoCntrlReq (&pst, &soMngmt);

   RETVALUE (ROK);

}/* SoNmsEnableBnd */

/*
*
*       Fun:   suSoEnableEnt
*
*       Desc:  Send a Control Request to Enable the
*              Entity
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*
*/
#ifdef ANSI
PUBLIC S16 SoNmsEnableEnt
(
TranId   transId
)
#else
PUBLIC S16 SoNmsEnableEnt(transId)
TranId   transId;
#endif
{

   SoMngmt soMngmt;
   Pst     pst;
   SoCntrl *cntrl;

   TRC2(SoNmsEnableEnt)

   soMngmt.hdr.msgType             = SO_SIPMESSAGE_REQUEST;
   soMngmt.hdr.entId.ent           = ENTSO;
   soMngmt.hdr.entId.inst          = SO_APPINST0;
   soMngmt.hdr.elmId.elmnt         = STSIPENT;
   soMngmt.hdr.elmId.elmntInst1    = SO_APPINST1;
   soMngmt.hdr.elmId.elmntInst2    = SO_APPINST2;
   soMngmt.hdr.elmId.elmntInst3    = SO_APPINST3;
   soMngmt.hdr.transId             = transId;
#ifdef LCSOMILSO
   soMngmt.hdr.response.selector = SV_LC;
#else
   soMngmt.hdr.response.selector = SV_TC;
#endif
   soMngmt.hdr.response.prior      = PRIOR0;
   soMngmt.hdr.response.route      = RTESPEC;
   soMngmt.hdr.response.mem.region = DFLT_REGION; 
   soMngmt.hdr.response.mem.pool   = DFLT_POOL; 
   soMngmt.hdr.response.mem.spare  = 0; 

   soNmsFillPst(&pst);
   pst.srcEnt   = ENTSM;
   pst.srcInst  = SO_APPINST_0;
   pst.dstEnt   = ENTSO;
   pst.dstInst  = SO_APPINST_0;

   cntrl = &soMngmt.t.cntrl;

   cntrl->s.entId   = 0;
   cntrl->action    = AENA;
   cntrl->subAction = SAELMNT;

   SmMiLsoCntrlReq (&pst, &soMngmt);

   RETVALUE (ROK);

}/* SoNmsEnableEnt */

PUBLIC Void SoNmsBndEnblStck()
{	
	S16 rc;
	SoNmsEnableBnd (g_cfgTransId++, SO_HI_SU_ID_1);

	SoNmsEnableEnt (g_cfgTransId++);
	
} 

#endif /* CP_OAM_SUPPORT*/



