/**********************************************************************

         (c) COPYRIGHT 1989-2003 by 
         Beijing Xinwei Telecom Technology co., ltd. ShenZhen R&D center
         All rights reserved.

     
**********************************************************************/

/**********************************************************************

     Name:     su_cfg.h 

     Type:     C include file

     Desc:     Defines MACO 

     Create :  2006-04-27 chendh
     

**********************************************************************/
#ifndef SU_CFG_H
#define SU_CFG_H

#define SO_NODEIDSTR "2F156A"
#define SO_UA_DOMAINNAME "UA.domain.com"
#define SO_ORGANIZATION "XINWEI"
#define SO_SUBJECT_STR  "Message From XINWEI"

#define SO_APPINST_0			0
#define SO_APPINST0             0
#define SO_APPINST1             1
#define SO_APPINST2             2
#define SO_APPINST3             3



/*--------------- Common configuration defines ----------------*/
#ifndef SO_PROTVER

#define SO_PROTVER            "2.0"
#define SO_MAX_SSAP           5
#define SO_MAX_TSAP           5
#define SO_MAX_UA             1
#define SO_MAX_NS             0
#define SO_MAX_REMREG         250
#define SO_MAX_ACT_CALL       500
#define SO_MAX_TRAN_ENT       500
#define SO_RES_THR_UP         5
#define SO_RES_THR_LOW        2
#define SO_MAX_PEND_LOC       50
#define SO_BLKSZ              2048
#define SO_LOCREG_SZ          16
#define SO_REMREG_SZ          16
#define SO_MTU                2048
#define SO_MAX_REG_PER_ENTITY  1
#define SO_MAX_CNCT_PER_ENTITY 1

#define SO_TPTPARAM_QSIZE     1

#define SO_DNS_A_CACHE_SZ     1024
#define SO_DNS_SRV_CACHE_SZ   1024
#define SO_DNS_NAPTR_CACHE_SZ 1024
#define SO_LOCSRV_SZ          1024
#define SO_HL_SIZE            50


#define SO_TSAP_SUID          0
#define SO_TSAP_SPID          0 

#define SO_GMT_OFFSET         2            
#define SO_REM_ADDR_DNS      "172.16.1.210"
#define SO_REM_PORT_DNS      53           
#define SO_TPTSRV_DNS        0           
#define SO_DNS_RETRY         3            
#define SO_1_SECOND          10
#define SO_1_HOUR            7200
#define SO_2_HOUR            14400
#define SO_DNS_QUERY_TM      2 * SO_1_SECOND
#define SO_DNS_CACHE_EXP     12 * SO_1_HOUR
#define SO_MCAST_CACHE_DFLT_EXP SO_1_HOUR
#define SO_MCAST_CACHE_MAX_EXP  SO_2_HOUR


#define  SO_500_MSECONDS     5
#define  SO_4_SECONDS        40
#define  SO_2_SECONDS        20
#define SO_10_SECONDS        100
#define  SO_20_SECONDS       200

#define SO_RETX_T1            SO_500_MSECONDS
#define SO_RETX_T2            SO_4_SECONDS
#define SO_RETX_T4            SO_2_SECONDS


#define SO_NAT_TMR              SO_20_SECONDS
#define SO_LOC_CACHE_DFLT_EXP   SO_1_HOUR
#define SO_LOC_CACHE_MAX_EXP    SO_2_HOUR


#define SO_LOCREG_THRESH_UPPER    0
#define SO_LOCREG_THRESH_LOWER    0
#define SO_LOCREG_DFLT_EXP_REG    SO_1_HOUR
#define SO_60_SECONDS             120
#define SO_LOCREG_DFLT_EXP_INV    SO_60_SECONDS
#define SO_TSAP_BNDRETRY          5
#define SO_TSAP_BNDTM             20*SO_1_SECOND
#define SO_TCP_ACTV_TM            60*SO_1_SECOND

#define SV_ENT_GET_IP_TXT(_entId) "127.0.0.1"

#define SV_ENT_GET_IP_U32(_entId) 0x00000000

#define SO_SV_IP_STR_SZ        16
#define SO_SV_PORT_STR_SZ      8

#define SV_LC                 0
#define SV_TC                 1
#define SV_LWLC				  2
#define SV_LC_SS              3
#define SV_LWLC_SS            4
#define HI_SO_TC              9

/* defines for TUCL general configuration */
#define SO_TUCL_MAX_TSAP      SO_MAX_TSAP
#define SO_TUCL_MAX_CON       5000
#define SO_TUCL_FDS           1000
#define SO_TUCL_FDBINS        1000
#define SO_TUCL_STP_THRESH    5
#define SO_TUCL_DRP_THRESH    2
#define SO_TUCL_STRT_THRESH   4

/* defines for TUCL upper SAP configuration */
#define SO_TUCL_CONG_STRT     15000
#define SO_TUCL_CONG_DRP      20000
#define SO_TUCL_CONG_STP      10000
#define SO_TUCL_NMB_HLBINS    2

#endif

#define SU_IPV4_LEN			32
#define SU_DOMAIN_LEN       64
#define SU_TUCL_SOCKET_NUM    5

#define SU_CTYPE_LEN32      32


#endif /*SU_CFG_H*/
