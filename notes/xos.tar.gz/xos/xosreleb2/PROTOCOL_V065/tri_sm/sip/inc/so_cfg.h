/**********************************************************************

         (c) COPYRIGHT 1989-2003 by 
         Beijing Xinwei Telecom Technology co., ltd. ShenZhen R&D center
         All rights reserved.

     
**********************************************************************/

/**********************************************************************

     Name:     so_cfg.h 

     Type:     C include file

     Desc:     Defines MACO 

     Create :  2006-04-27 chendh
     

**********************************************************************/
#ifndef SO_CFG_H
#define SO_CFG_H

#ifndef ACTVINST
#define ACTVINST 0
#endif

#define SO_SRC_INSTANCE0  0
#define SO_DST_INSTANCE0  0

/*--------------------------------------------------------*/
/*SIP ���ñ���Χ1 ~ 20*/
#define SM_SIPGENCFG_TBL     1
#define SM_SIPENTCFG_TBL     2
#define SM_SIPHDRCFG_TBL     3
#define SM_SIPREUACFG_TBL    4
#define SM_CPOAMCOMIP_TBL    5
#define SM_SIPCFG_TBL_CNT    5


#endif /*SO_CFG_H*/