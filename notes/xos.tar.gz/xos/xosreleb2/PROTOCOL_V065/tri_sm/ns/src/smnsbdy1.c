/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     smnsbdy1.c
  
     Type:     C source file
  
     Desc:     Management Entity body file for NTSS interface
 
     File:     smnsbdy1.c

     Sid:      smnsbdy1.c 1.1  -  05/13/98 17:20:39
  
     Prg:      ag
  
*********************************************************************21*/
 

/* header include files (.h) */
#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system service interface */
#include "lns.h"           /* NTSS layer management */
#include "smns_err.h"      /* errors */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system service interface */
#include "lns.x"           /* NTSS layer management */


/* local defines */

/* local typedefs */

/* local externs */
  
/* forward references */

/* local function definition */

/* functions in other modules */

/* public variable declarations */

/* control variables for testing */

/* private variable declarations */


/*
 * support functions
 */


/*
 * interface functions to system services
 */

#ifdef SM

/*
*
*       Fun:   smNsActvInit
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*
*       Notes: None
*
*       File:  smnsbdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smNsActvInit
(
Ent ent,                /* entity */
Inst inst,              /* instance */
Region region,          /* region */
Reason reason           /* reason */
)
#else
PUBLIC S16 smNsActvInit(ent, inst, region, reason)
Ent ent;                /* entity */
Inst inst;              /* instance */
Region region;          /* region */
Reason reason;          /* reason */
#endif
{
   TRC2(smNsActvInit)

   RETVALUE(ROK);

} /* end of smNsActvInit */



/*
*
*       Fun:   SmMiLnsStaCfm
*
*       Desc:  Stack manager status confirm from NTSS
*
*       Ret:   ROK on success, RFAILED on error
*
*       Notes: none
*
*       File:  smnsbdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLnsStaCfm
(
Pst *pst,                       /* post */
NsMngmt *sta                    /* status */
)
#else
PUBLIC S16 SmMiLnsStaCfm(pst, sta)
Pst *pst;                       /* post */
NsMngmt *sta;                   /* status */
#endif
{
   Txt pBuf[PRNTSZE];

   TRC3(SmMiLnsStaCfm)

  /* validate status confirm */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sta == NULLP)                              /* NULL status confirm */
   {
      SMNSLOGERROR(ERRCLS_INT_PAR, ESMNS001, sta, \
                   "[SM] [NTSS] SmMiLnsStaCfm(): NULL status confirm\n",pst);

      RETVALUE(RFAILED);
   }

   if ((sta->hdr.entId.ent != ENTNS)              /* invaid ent id */
         || (sta->hdr.msgType != TSSTA))          /* invalid message type */
   {
      sprintf(pBuf, "[NTSS] SmMiLnsStaInd(): Invalid status confirm - \
              ent=%d, msgType=%d\n", sta->hdr.entId.ent, sta->hdr.msgType);
      SMNSLOGERROR(ERRCLS_INT_PAR, ESMNS002, 0, pBuf,pst);

      RETVALUE (RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */


#ifdef DBSMMILNS
   sprintf(pBuf, "SmMiLnsStaCfm:");
   SPrint(pBuf);

   sprintf(pBuf, "Date: %d/%d/%d - %d:%d.%d.%d", 
         sta->t.ssta.dt.month,
         sta->t.ssta.dt.day,
         sta->t.ssta.dt.year,
         sta->t.ssta.dt.hour,
         sta->t.ssta.dt.min,
         sta->t.ssta.dt.sec,
         sta->t.ssta.dt.tenths);
   SPrint(pBuf);

   switch(sta->hdr.elmId.elmnt)
   {
      case STSID:
         sprintf(pBuf, "System Id: %d.%d %d %d - PN# %s",
                 sta->t.ssta.s.sysId.mVer,
                 sta->t.ssta.s.sysId.mRev,
                 sta->t.ssta.s.sysId.bVer,
                 sta->t.ssta.s.sysId.bRev,
                 sta->t.ssta.s.sysId.ptNmb);
         SPrint(pBuf);
         break;

      case STSPOOL:
         sprintf(pBuf, "SPool: max %ld, min %ld, crnt %ld, buf %ld",
                 sta->t.ssta.s.nsSPool.maxSize,
                 sta->t.ssta.s.nsSPool.minSize,
                 sta->t.ssta.s.nsSPool.crntSize,
                 sta->t.ssta.s.nsSPool.bufSize);
         SPrint(pBuf);
         break;

      case STDPOOL:
         sprintf(pBuf, "DPool: max %ld, min %ld, crnt %ld",
                 sta->t.ssta.s.nsDPool.maxSize,
                 sta->t.ssta.s.nsDPool.minSize,
                 sta->t.ssta.s.nsDPool.crntSize);
         SPrint(pBuf);

         break;

      case STDQ:
         sprintf(pBuf, "Dq: prior %d, size %d",
                 sta->hdr.elmId.elmntInst1, (U16)sta->t.ssta.s.nsDq.size);
         SPrint(pBuf);
         break;

      case STENT:
         sprintf(pBuf, "Ent: ent %d, nmbInst %d, maxInst %d",
                 sta->hdr.elmId.elmntInst1,
                 sta->t.ssta.s.nsEnt.nmbInst,
                 sta->t.ssta.s.nsEnt.maxInst);
         SPrint(pBuf);
         break;
   }
#endif /* DBSMMILNS */

   RETVALUE(ROK);

} /* end of SmMiLnsStaCfm */


/*
*
*       Fun:   SmMiLnsStsCfm
*
*       Desc:  Stack manager statistics confirm
*
*       Ret:   ROK on success, RFAILED on error
*
*       Notes: none
*
*       File:  smnsbdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLnsStsCfm
(
Pst *pst,                       /* post */
Action action,                  /* action */
NsMngmt *sts                    /* statistics */
)
#else
PUBLIC S16 SmMiLnsStsCfm(pst, action, sts)
Pst *pst;                       /* post */
Action action;                  /* action */
NsMngmt *sts;                   /* statistics */
#endif
{
   Txt pBuf[PRNTSZE];

   TRC3(SmMiLnsStsCfm)

  /* validate statistics confirm */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sts == NULLP)                              /* NULL stat cfm */
   {
      SMNSLOGERROR(ERRCLS_INT_PAR, ESMNS003, sts,
                   "[SM] [NTSS] SmMiLnsStsCfm(): NULL statistics cfm\n",pst);

      RETVALUE(RFAILED);
   }

   if ((sts->hdr.entId.ent != ENTNS)              /* invaid ent id */
         || (sts->hdr.msgType != TSTS))          /* invalid message type */
   {
      sprintf(pBuf, "[NTSS] SmMiLnsStsCfm(): Invalid statistics confirm - \
              ent=%d, msgType=%d\n", sts->hdr.entId.ent, sts->hdr.msgType);

      SMNSLOGERROR(ERRCLS_INT_PAR, ESMNS004, 0, pBuf,pst);

      RETVALUE (RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

#ifdef DBSMMILNS
   sprintf(pBuf, "SmMiLnsStsCfm:");
   SPrint(pBuf);

   sprintf(pBuf, "Date: %d/%d/%d - %d:%d.%d.%d", 
         sts->t.sts.dt.month,
         sts->t.sts.dt.day,
         sts->t.sts.dt.year,
         sts->t.sts.dt.hour,
         sts->t.sts.dt.min,
         sts->t.sts.dt.sec,
         sts->t.sts.dt.tenths);
   SPrint(pBuf);

   switch(sts->hdr.elmId.elmnt)
   {
      case STLOOP:
         sprintf(pBuf, 
            "Loop: actv %ld, idle %ld permActv %ld, NormActv %ld, TmrActv %ld",
            sts->t.sts.s.nsLoop.loopActvCnt,
            sts->t.sts.s.nsLoop.loopIdleCnt,
            sts->t.sts.s.nsLoop.loopPermCnt,
            sts->t.sts.s.nsLoop.loopNormCnt,
            sts->t.sts.s.nsLoop.loopTmrCnt);
         SPrint(pBuf);
         break;

      case STDQ:
         sprintf(pBuf, "Dq: system task %d, emp %ld, not empt %ld",
                 sts->hdr.elmId.elmntInst1,
                 sts->t.sts.s.nsDq.emptyCnt,
                 sts->t.sts.s.nsDq.notEmptyCnt);
         SPrint(pBuf);
         break;

      case STENT:
         sprintf(pBuf, "Ent: ent %d, inst %d, actv %ld",
                 sts->hdr.elmId.elmntInst1,
                 sts->hdr.elmId.elmntInst2,
                 sts->t.sts.s.nsEnt.actvCnt);
         SPrint(pBuf);
         break;
   }
#endif /* DBSMMILNS */

   RETVALUE(ROK);

} /* end of SmMiLnsStsCfm */


/*
*
*       Fun:   SmMiLnsStaInd
*
*       Desc:  Stack manager status Indication from NTSS
*
*       Ret:   ROK on success, RFAILED on error
*
*       Notes: none
*
*       File:  smnsbdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLnsStaInd
(
Pst *pst,                       /* post */
NsMngmt *sta                    /* status */
)
#else
PUBLIC S16 SmMiLnsStaInd(pst, sta)
Pst *pst;                       /* post */
NsMngmt *sta;                   /* status */
#endif
{
   Txt pBuf[PRNTSZE];

   TRC3(SmMiLnsStaInd)

  /* validate status indication */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sta == NULLP)                              /* NULL stat ind */
   {
      SMNSLOGERROR(ERRCLS_INT_PAR, ESMNS005, sta,
                   "[SM] [NTSS] SmMiLnsStaInd(): NULL status ind\n",pst);

      RETVALUE(RFAILED);
   }

   if ((sta->hdr.entId.ent != ENTNS)              /* invaid ent id */
         || (sta->hdr.msgType != TUSTA))          /* invalid message type */
   {
      sprintf(pBuf, "[NTSS] SmMiLnsStaInd(): Invalid status indication - \
              ent=%d, msgType=%d\n", sta->hdr.entId.ent, sta->hdr.msgType);

      SMNSLOGERROR(ERRCLS_INT_PAR, ESMNS006, 0, pBuf,pst);

      RETVALUE (RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */


#ifdef DBSMMILNS
   switch(sta->t.usta.evnt)
   {
      case ERROR_LOG:
          sprintf(pBuf , "SmMiLnsStaInd: Error %d Logged\n", 
                      sta->hdr.elmId.elmntInst1);
          SPrint(pBuf);
          break;
      default:
          sprintf(pBuf , "SmMiLnsStaInd: Receiving wrong event  %d \n", 
                      sta->t.usta.evnt);
          SPrint(pBuf);
          break;
   }
#endif /* DBSMMILNS */

   RETVALUE(ROK);

} /* end of SmMiLnsStaInd */

#endif /* SM */


/********************************************************************30**
  
         End of file: smnsbdy1.c 1.1  -  05/13/98 17:20:39
  
*********************************************************************31*/
  

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/
  

/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ag   1. initial release.
  
*********************************************************************91*/
