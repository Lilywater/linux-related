/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     smnsptmi.c
  
     Type:     C source file
  
     Desc:     SM->NS runtime function resolution
 
     File:     smnsptmi.c

     Sid:      smnsptmi.c 1.1  -  05/13/98 17:20:48
  
     Prg:      ag
  
*********************************************************************21*/
  

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system service interface */
#include "lns.h"           /* NTSS layer management */
#include "smns_err.h"      /* stack manager/NTSS errors */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system service interface */
#include "lns.x"           /* NTSS layer management */

/* local defines */
#define SM_MAX_NS_SEL   2  /* max number of selectors */

#ifndef LCSMNSMILNS
#define PTSMMILNS        /* portable, stack manager, NTSS interface */
#else
#ifndef NS
#define PTSMMILNS        /* portable, stack manager, NTSS interface */
#endif  /* NS */
#endif


/* local typedefs */

/* local externs */
  
/* forward references */
#ifdef PTSMMILNS
PRIVATE S16 PtMiLnsStaReq   ARGS((Pst *pst, NsMngmt *sta ));
PRIVATE S16 PtMiLnsStsReq   ARGS((Pst *pst, Action action, NsMngmt *sts ));
PRIVATE S16 PtMiLnsCntrlReq ARGS((Pst *pst, NsMngmt *cntrl ));
#endif /* PTSMMILNS */

/* local function definition */

/* functions in other modules */

/* public variable declarations */

/* control variables for testing */

/* private variable declarations */
#ifdef DBSMMILNS
PUBLIC  Bool dbSmMiLns = FALSE;     /* debug info for NTSS mngmt interface */
PRIVATE Txt  prntBuf[PRNTSZE];
#endif


/*
the following matrices define the mapping between the primitives
called by the layer management interface of NTSS and the corresponding
primitives in NTSS.
 
The parameter SM_MAX_NS_SEL defines the maximum number of layer manager entities
on top of NTSS. There is an array of functions per primitive
invoked by NTSS. Every array is SM_MAX_NS_SEL long (i.e. there
are as many functions as the number of service users).
 
The dispatching is performed by the configurable variable: selector.
The selector is configured during general configuration.
 
The selectors are:
 
 0 - loosely coupled - (#define LCSMNSMILNS)
 1 - Lns (#define NS)
 
*/
 
#ifdef NS_ENB_MGMT 

/* Statistics request primitive */
 
PRIVATE LnsStsReq SmMiLnsStsReqMt[SM_MAX_NS_SEL] =
{
#ifdef LCSMNSMILNS
   smPkMiLnsStsReq,        /* 0 - loosely coupled */
#else
   PtMiLnsStsReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef NS
   NsMiLnsStsReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLnsStsReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Status request primitive */
 
PRIVATE LnsStaReq SmMiLnsStaReqMt[SM_MAX_NS_SEL] =
{
#ifdef LCSMNSMILNS
   smPkMiLnsStaReq,        /* 0 - loosely coupled  */
#else
   PtMiLnsStaReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef NS
   NsMiLnsStaReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLnsStaReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Control request primitive */
 
PRIVATE LnsCntrlReq SmMiLnsCntrlReqMt[SM_MAX_NS_SEL] =
{
#ifdef LCSMNSMILNS
   smPkMiLnsCntrlReq,        /* 0 - loosely coupled */
#else
   PtMiLnsCntrlReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef NS
   NsMiLnsCntrlReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLnsCntrlReq,          /* 1 - tightly coupled, portable */
#endif
};

/*
*     layer management interface functions 
*/


/*
*
*       Fun:   Status request
*
*       Desc:  This function is used to send a status request to NTSS
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smnsptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLnsStaReq
(
Pst *pst,                 /* post structure */
NsMngmt *sta              /* status */
)
#else
PUBLIC S16 SmMiLnsStaReq(pst, sta)
Pst *pst;                 /* post structure */   
NsMngmt *sta;             /* status */
#endif
{
   TRC3(SmMiLnsStaReq)

#ifdef DBSMMILNS
   if (dbSmMiLns)
   {
      sprintf(prntBuf, "[SM] [NTSS] Invoking Status Request\n\n");
      SPrint(prntBuf);
   }
#endif

   /* jump to specific primitive depending on configured selector */
   (*SmMiLnsStaReqMt[pst->selector])(pst, sta); 

   RETVALUE(ROK);

} /* end of SmMiLnsStaReq */


/*
*
*       Fun:   control request
*
*       Desc:  This function is used to send a control request to NTSS
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smnsptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLnsCntrlReq
(
Pst *pst,                 /* post structure */
NsMngmt *cntrl            /* control */
)
#else
PUBLIC S16 SmMiLnsCntrlReq(pst, cntrl)
Pst *pst;                 /* post structure */   
NsMngmt *cntrl;           /* control */
#endif
{
   TRC3(SmMiLnsCntrlReq)

#ifdef DBSMMILNS
   if (dbSmMiLns)
   {
      sprintf(prntBuf, "[SM] [NTSS] Invoking Control Request\n\n");
      SPrint(prntBuf);
   }
#endif

   /* jump to specific primitive depending on configured selector */
   (*SmMiLnsCntrlReqMt[pst->selector])(pst, cntrl); 

   RETVALUE(ROK);

} /* end of SmMiLnsCntrlReq */


/*
*
*       Fun:   Statistics request
*
*       Desc:  This function is used to request statistics from NTSS
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smnsptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLnsStsReq
(
Pst *pst,                 /* post structure */
Action action,
NsMngmt *sts              /* statistics */
)
#else
PUBLIC S16 SmMiLnsStsReq(pst, action, sts)
Pst *pst;                 /* post structure */   
Action action;
NsMngmt *sts;             /* statistics */
#endif
{
   TRC3(SmMiLnsStsReq)

#ifdef DBSMMILNS
   if (dbSmMiLns)
   {
      sprintf(prntBuf, "[SM] [NTSS] Invoking Statistics Request\n\n");
      SPrint(prntBuf);
   }
#endif

   /* jump to specific primitive depending on configured selector */
   (*SmMiLnsStsReqMt[pst->selector])(pst, action, sts); 

   RETVALUE(ROK);

} /* end of SmMiLnsStsReq */


#ifdef PTSMMILNS

/*
*
*       Fun:   Portable status Request NTSS
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smnsptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLnsStaReq
(
Pst *pst,                   /* post structure */
NsMngmt *sta                /* status */
)
#else
PRIVATE S16 PtMiLnsStaReq(pst, sta)
Pst *pst;                   /* post structure */
NsMngmt *sta;               /* status */
#endif
{
   TRC3(PtMiLnsStaReq)

   UNUSED(sta);
  
#if (ERRCLASS & ERRCLS_DEBUG)
   SMNSLOGERROR(ERRCLS_DEBUG,ESMNS008, (ErrVal)pst->selector,  \
                                    "PtMiLnsStaReq:Invalid selector", pst);
#endif /* ERRCLASS & ERRCLS_DEBUG */

   RETVALUE(ROK);

} /* end of PtMiLnsStaReq */



/*
*
*       Fun:   Portable Control Request NTSS
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smnsptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLnsCntrlReq
(
Pst *pst,                   /* post structure */
NsMngmt *cntrl              /* control */
)
#else
PRIVATE S16 PtMiLnsCntrlReq(pst, cntrl)
Pst *pst;                   /* post structure */
NsMngmt *cntrl;             /* control */
#endif
{
   TRC3(PtMiLnsCntrlReq)

   UNUSED(cntrl);

#if (ERRCLASS & ERRCLS_DEBUG)
   SMNSLOGERROR(ERRCLS_DEBUG, ESMNS009, (ErrVal)pst->selector, \
                                     "PtMiLnsCntrlReq:Invalid selector", pst);
#endif /* ERRCLASS & ERRCLS_DEBUG */

   RETVALUE(ROK);

} /* end of PtMiLnsCntrlReq */


/*
*
*       Fun:   Portable statistics Request NTSS
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smnsptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLnsStsReq
(
Pst *pst,                   /* post structure */
Action action,              /* action */
NsMngmt *sts                /* statistics */
)
#else
PRIVATE S16 PtMiLnsStsReq(pst, action, sts)
Pst *pst;                   /* post structure */
Action action;              /* action */
NsMngmt *sts;               /* statistics */
#endif
{
   TRC3(PtMiLnsStsReq)

   UNUSED(action);
   UNUSED(sts);

#if (ERRCLASS & ERRCLS_DEBUG)
   SMNSLOGERROR(ERRCLS_DEBUG,ESMNS010, (ErrVal)pst->selector, \
                                     "PtMiLnsStsReq:Invalid selector", pst);
#endif /* ERRCLASS & ERRCLS_DEBUG */

   RETVALUE(ROK);

} /* end of PtMiLnsStsReq */
#endif /* PTSMMILNS */

#endif /* NS_ENB_MGMT */


/********************************************************************30**
  
         End of file: smnsptmi.c 1.1  -  05/13/98 17:20:48
  
*********************************************************************31*/
  

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/
  

/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ag   1. initial release.
  
*********************************************************************91*/
