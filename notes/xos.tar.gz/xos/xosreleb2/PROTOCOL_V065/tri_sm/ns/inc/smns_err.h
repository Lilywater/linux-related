/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     smns_err.h
  
     Type:     C include file
  
     Desc:     Management Entity errors for NTSS
 
     File:     smns_err.h

     Sid:      smns_err.h 1.1  -  05/13/98 17:20:35
  
     Prg:      ag
  
*********************************************************************21*/

#ifndef __SMNSERRH__
#define __SMNSERRH__


/* defines */
  
#define SMNSLOGERROR(errCls, errCode,errVal, errDesc, pst) \
        SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,\
                   __FILE__, __LINE__, \
                  errCls, errCode, (ErrVal)errVal, errDesc)


#define  ESMNSBASE   0                 /* reserved */
#define  ESMNSXXX    (ESMNSBASE + 0)   /* reserved */

#define   ESMNS001      (ESMNSBASE +    1)    /*   smnsbdy1.c: 205 */
#define   ESMNS002      (ESMNSBASE +    2)    /*   smnsbdy1.c: 216 */
#define   ESMNS003      (ESMNSBASE +    3)    /*   smnsbdy1.c: 323 */
#define   ESMNS004      (ESMNSBASE +    4)    /*   smnsbdy1.c: 335 */
#define   ESMNS005      (ESMNSBASE +    5)    /*   smnsbdy1.c: 424 */
#define   ESMNS006      (ESMNSBASE +    6)    /*   smnsbdy1.c: 436 */

#define   ESMNS007      (ESMNSBASE +    7)    /*   smnsexms.c: 164 */

#define   ESMNS008      (ESMNSBASE +    8)    /*   smnsptmi.c: 379 */
#define   ESMNS009      (ESMNSBASE +    9)    /*   smnsptmi.c: 420 */
#define   ESMNS010      (ESMNSBASE +   10)    /*   smnsptmi.c: 463 */

#endif /* __SMNSERRH__ */


/********************************************************************30**
  
         End of file: smns_err.h 1.1  -  05/13/98 17:20:35
  
*********************************************************************31*/
  

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/
  

/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ag   1. initial release.
  
*********************************************************************91*/
