/**********************************************************************

         (c) COPYRIGHT 1989-2003 by 
         Beijing Xinwei Telecom Technology co., ltd. ShenZhen R&D center
         All rights reserved.

     
**********************************************************************/

/**********************************************************************

     Name:     mg_cfg.c 

     Type:     C source file

     Desc:     C code for general, SAP and entity configuration 

     Create :  2006-04-27 chendh
     

**********************************************************************/

/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timers defines */
#include "cm_hash.h"       /* common hash list defines */
#include "cm_inet.h"       /* common INET defines */
#include "cm_llist.h"      /* common linked list defines */

#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */

#include "hit.h"           /* HIT interface defines           */
#include "lmg.h"           /* Layer management, SIP           */
#include "mgt.h"           /* MGT interface defines           */
#include "mg.h"            /* SIP Layer defines               */
#include "mg_cfg.h" 
#include "sm.h"
#ifdef HI
#include "lhi.h"
#include "hit.h"           /* HI layer */
#include "hi.h"
#endif
#include "mg_err.h"        /* MG error defines */

/* header/extern include files (.x) */
#include "gen.x"           /* general layer typedefs */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_inet.x"       /* common INET */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "hit.x"           /* HIT interface defines           */
#include "mgt.x"           /* SOT interface defines           */
#include "lmg.x"           /* Layer management SIP            */
#include "cst.x"           /* Compression module              */
#include "mg.x"

#include "sm.x"

#ifdef SSI_WITH_CLI_ENABLED
#include "clishell.h"      /* XOS header */
#include "xosroot.h"
#include "mg_dbg_cfg.h"
#endif /*SSI_WITH_CLI_ENABLED*/
#include "mg_cfg.x"

#include "cm_inet.h"

#ifdef CP_OAM_SUPPORT
#include "xosshell.h"
#include "oam_interface.h"
#include "mg_nms.h"
#include "cp_tab_def.h"
#include "cp_oam_stru.h"
#endif /*CP_OAM_SUPPORT*/
//CP_SS7_GLOBAL gstCpSs7Global;  /*cdw add 2006.9.20*/
#ifdef CP_OAM_SUPPORT
U32 g_megacoUaModId = 0;

/* global variables */
PRIVATE TranId   g_cfgTransId = 0;


PUBLIC CmLListCp gMgSmQ[MGCO_CONFIG_Q_TOTAL_NUM];
MgNmsConfigData g_MgNmsCfgData;

Bool g_taskRegComp = FALSE;
Bool g_mgCfgEnbFinish = FALSE;
PUBLIC S16 MgcoInit();

#ifdef GCP_MGC
unsigned int mgCfgTbl[3]={APP_TABLE_ID_VOIP_H248_MGCSRVR,\
                         APP_TABLE_ID_VOIP_H248_MGCENT, APP_TABLE_ID_COM_IP};
#else
unsigned int mgCfgTbl[3]={APP_TABLE_ID_VOIP_H248_MGSRVR,\
                         APP_TABLE_ID_VOIP_H248_MGENT, APP_TABLE_ID_COM_IP};
#endif
/* definition in mg_cfg.c */

void TestPrintCfgedSrvr();
void TestPrintCfgedPeerEnt();

Void mgNmsGenCfgReq     ARGS((void));
Void mgNmsTSapCfgReq    ARGS((SpId   spId, SuId   suId));
Void mgNmsSSapCfgReq    ARGS((SpId   spId));
Void mgNmsPeerEntCfgReq     ARGS((SpId   spId));
Void mgNmsSrvrCfgReq     ARGS((SpId spId, SuId suId));
PRIVATE U32 mgGetTransId     ARGS((void));

#ifdef SSI_WITH_CLI_ENABLED
extern PUBLIC S16 ssiInit();
#endif /*SSI_WITH_CLI_ENABLED*/

/********************************************************************************************************
  Function: smMgSendReqQ() 
  Description: sccp get msg buffer from sm queue, and send it out
  Calls:
  Called By: 
  Input:   smMsg: msg buffer get from sm queue 
               
  Output:  send LSP message to SP ENTITY

  
  Return:   ROK:success; 
                RFAILED: failure
  Others:
 ********************************************************************************************************/
S16 smMgSendReqQ(CmLList *node)
{
    Pst smMgPst;
    Header *msgHeader;
    S16 ret = ROK;
   
    TRC2(smMgSendReqQ);   
	
    msgHeader = (Header *)cmLListNode(node);
	if(msgHeader == NULL)
	{
		printf("smMgSendReqQ ERROR: msgHeader == NULL\r\n");
		//return -1;
	}
    MuFillDefPst(&smMgPst);
	/*---------- Fill default values in Pst structure ----------*/
    smMgPst.srcEnt   = ENTSM;
    smMgPst.srcInst  = MG_SRC_INSTANCE0;
    smMgPst.dstEnt   = ENTMG;
    smMgPst.dstInst  = MG_DST_INSTANCE0;

#ifdef LCMGMILMG
	smMgPst.selector  = MU_LC;
#else
	smMgPst.selector  = MU_TC;
#endif

	switch(msgHeader->msgType)
	{
	case TCFG:
		ret = MgMiLmgCfgReq(&smMgPst, (MgMngmt *)cmLListNode(node));
		break;
	case TCNTRL:
		ret = MgMiLmgCntrlReq(&smMgPst, (MgMngmt *)cmLListNode(node));
		break;
	case TSTS:
		ret = MgMiLmgStsReq(&smMgPst, NOZEROSTS, (MgMngmt *)cmLListNode(node));
		break;
	case TSSTA:
		ret = MgMiLmgStaReq(&smMgPst, (MgMngmt *)cmLListNode(node));
		break;
	default:
		RETVALUE(RFAILED);
	}

	return ret;    
}


/********************************************************************
*
*       Fun:   mgNmsConfigure
*
*       Desc:  Setup the gcp Layer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*
********************************************************************/
PUBLIC   Void   mgNmsConfigure()
{

    TRC2(mgNmsConfigure)

    g_cfgTransId = 0;

    /*----------------- General Configuration ------------------*/
    mgNmsGenCfgReq();

    /*-----------------TUCL SAP Configuration ------------------*/
    mgNmsTSapCfgReq(MG_HI_SIPID, MU_SUID0);

	/*------------- Service User SAP Configuration -------------*/
    mgNmsSSapCfgReq(MU_SUID0); 

    /*---------------- MGCO Peer Entity Configuration FOR MG side----------*/
#ifdef GCP_MG
    mgNmsPeerEntCfgReq(MU_SUID0);
#endif

    /*--------- Service User Transport Server Configuration ----*/
    mgNmsSrvrCfgReq(MU_SUID0,MU_SUID0);

    RETVOID;
} /* suNmsConfigureUa */

Void   mgNmsGenCfgReq()
{
    /* local variables */
    MgMngmt     *mgMngmt;   
    MgGenCfg    *genCfg;     
    CmLList		*node;    

    TRC2(mgNmsGenCfgReq)
        
	/* alloc a node for save sm msg info */
	if( ROK != smGetQNode(&node, sizeof(MgMngmt)))
	{
		RETVOID;
	}
	
	mgMngmt = (MgMngmt *)cmLListNode(node);

	mgMngmt->hdr.msgLen = sizeof( MgMngmt);

    genCfg = &(mgMngmt->t.cfg.c.genCfg);
    cmMemset ((U8 *) genCfg  , 0, sizeof (MgGenCfg));   

   /*----------- Fill General Configuration Parameters ---------*/
  
    genCfg->maxSSaps          = MGCO_MAX_SSAP;
    genCfg->maxTSaps          = MGCO_MAX_TSAP;
    genCfg->maxServers        = MGCO_MAX_SERVER;
    genCfg->maxConn           = MGCO_MAX_CONN;
    genCfg->maxTxn            = MGCO_MAX_TXN;
    genCfg->maxPeer           = MGCO_MAX_PEER;
    genCfg->resThUpper        = MGCO_RES_UPPER;
    genCfg->resThLower        = MGCO_RES_LOWER;
    genCfg->timeRes           = MGCO_TIME_RES;
    genCfg->numBlks           = MGCO_NUM_BLKS;
    genCfg->maxBlkSize        = MGCO_MAX_BLK_SIZE;
    genCfg->numBinsTxnIdHl    = MGCO_NUM_BINS_TXNID_HL;
    genCfg->numBinsNameHl     = MGCO_NUM_BINS_NAME_HL;
    genCfg->numBinsTptSrvrHl  = MGCO_NUM_BINS_TPT_SRVR_HL;

#ifdef GCP_MG
	 genCfg->entType           = LMG_ENT_GW;
#elif GCP_MGC
    genCfg->entType            = LMG_ENT_GC;
#else
	 genCfg->entType           = LMG_NONE;
#endif /*GCP_MG*/

    genCfg->indicateRetx      = MGCO_INDICATE_RETX;
    genCfg->resOrder          = MGCO_RES_ORDER;

#ifdef GCP_VER_1_3
    genCfg->reCfg.rspAckEnb = MGCO_RSP_ACK_ENB; 
#endif /* GCP_VER_1_3 */
    
#ifdef CM_ABNF_MT_LIB         
    genCfg->noEDInst     = 3;             /* total no. of ED instances */
    genCfg->firstInst    = 1;             /* first ED instance no */  
    genCfg->edEncTmr.enb = FALSE;         /* encode timer */
    genCfg->edEncTmr.val = 50;
    genCfg->edDecTmr.enb = TRUE;          /* decode timer */
    genCfg->edDecTmr.val = 50;
#endif /* CM_ABNF_MT_LIB */    

#if (defined(GCP_CH) && defined(GCP_VER_1_5))
    genCfg->numBinsPeerCmdHl        = 20;         /* for Peer Cmd Ctl List     */
    genCfg->numBinsTransReqHl       = 50;         /* for Trans Req list        */
    genCfg->numBinsTransIndRspCmdHl = 50;         /* for For Trans IndRsp List */
#endif /* GCP_CH && GCP_VER_1_5 */

#ifdef GCP_MG
    genCfg->maxMgCmdTimeOut.enb = PRSNT_NODEF;   /* Maximum MG Command TimeOut*/
    genCfg->maxMgCmdTimeOut.val = 20;
#endif /* GCP_MG */
 
#ifdef GCP_MGC
    genCfg->maxMgcCmdTimeOut.enb = PRSNT_NODEF;       /* Maximum MGc Command TimeOut*/
    genCfg->maxMgcCmdTimeOut.val = 20;    
#endif /* GCP_MGC */

#if (defined(GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))
    genCfg->limit.pres.pres                 = PRSNT_NODEF;   /* Pending Limit */
    genCfg->limit.mgcOriginatedPendingLimit = 136;
    genCfg->limit.mgOriginatedPendingLimit  = 200;
#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */
    genCfg->lmPst.dstProcId = SFndProcId();
    genCfg->lmPst.srcProcId = SFndProcId();
    genCfg->lmPst.dstEnt    = ENTSM/*ENTMG*/;
    genCfg->lmPst.dstInst   = 0;
    genCfg->lmPst.srcEnt    = ENTSM;
    genCfg->lmPst.srcInst   = 0;
    genCfg->lmPst.prior     = PRIOR0;
    genCfg->lmPst.route     = 0;
    genCfg->lmPst.event     = 0;
    genCfg->lmPst.region    = 0;
    genCfg->lmPst.pool      = 0;
#ifdef LCMGMILMG
	genCfg->lmPst.selector = 0;
#else
	genCfg->lmPst.selector = 1;
#endif  /*LCMGMILMG*/

    /*Hdr for Mngmt*/       
	mgMngmt->hdr.msgType          = TCFG;
	mgMngmt->hdr.entId.ent        = ENTMG;
	mgMngmt->hdr.entId.inst       = MG_APPINST0;
	mgMngmt->hdr.elmId.elmnt      = STGEN;
	mgMngmt->hdr.elmId.elmntInst1 = MG_APPINST1;
	mgMngmt->hdr.elmId.elmntInst2 = MG_APPINST2;
	mgMngmt->hdr.elmId.elmntInst3 = MG_APPINST3;
	mgMngmt->hdr.transId          = 0;
#ifdef LMINT3
    mgMngmt->hdr.transId = mgGetTransId(); 
    mgMngmt->hdr.response.prior     = PRIOR0;
	mgMngmt->hdr.response.route     = RTESPEC;
	mgMngmt->hdr.response.mem.region= DFLT_REGION; 
	mgMngmt->hdr.response.mem.pool  = DFLT_POOL; 
	mgMngmt->hdr.response.mem.spare = 0;  /* chendh modify it*/
#ifdef LCMGMILMG
	mgMngmt->hdr.response.selector = 0;
#else
	mgMngmt->hdr.response.selector = 1;
#endif  /*LCMGMILMG*/
#endif  /*LMINT3*/    

	/*------------- add node to queue -------------*/
	cmLListAdd2Tail(&gMgSmQ[MGCO_GENCFG_Q], node);

   RETVOID;

}

/*********************************************************************
*
*       Fun:   mgNmsTSapCfgReq
*
*       Desc:  Set up the TSAP configuration structure
*
*       Ret:   ROK
*              RFAILED
*
*
*********************************************************************/
Void mgNmsTSapCfgReq
(
SpId             spId,
SuId             suId 
)
{
    /* local variables */
    CmLList		 *node;
    MgMngmt      *mgMngmt;
    MgTSAPCfg    *tSapCfg; 
    MgTSAPReCfg  *tSapReCfg;    

    TRC2 (mgNmsTSapCfgReq)
        
	/* alloc a node for save sm msg info */
	if( ROK != smGetQNode(&node, sizeof(MgMngmt)))
	{
		RETVOID;
	}
	
	mgMngmt = (MgMngmt *)cmLListNode(node);
	mgMngmt->hdr.msgLen = sizeof( MgMngmt);

    tSapCfg   = &(mgMngmt->t.cfg.c.tSAPCfg);
    tSapReCfg = &(tSapCfg->reCfg);

    cmMemset ((U8 *) tSapCfg, 0, sizeof (MgTSAPCfg));   
    cmMemset ((U8 *) tSapReCfg, 0, sizeof (MgTSAPReCfg));   

    tSapCfg->tSAPId       = suId;
    tSapCfg->spId         = spId;
    tSapCfg->provType     = LMG_PROV_TYPE_TUCL;
    tSapCfg->memId.region = DFLT_REGION;
    tSapCfg->memId.pool   = DFLT_POOL;
    tSapCfg->dstProcId    = SFndProcId();
    tSapCfg->dstEnt       = ENTHI;
    tSapCfg->dstInst      = 0;
    tSapCfg->dstPrior     = PRIOR0;
    tSapCfg->dstRoute     = RTESPEC;
#ifdef LCMGMILMG
	tSapCfg->dstSel = 0;
#else
	tSapCfg->dstSel = 1;
#endif  /*LCMGMILMG*/
    tSapCfg->bndTmrCfg.enb = TRUE;
    tSapCfg->bndTmrCfg.val = 5; 
#ifdef    GCP_PROV_SCTP
    tSapCfg->numBinsAssocHl = 10;       /* size of Association Hash list */
#endif    /* GCP_PROV_SCTP */
#ifdef    GCP_PROV_MTP3
    tSapCfg->mgMtpNwCfg.upSwtch             = LMG_SW_ITU;
    tSapCfg->mgMtpNwCfg.pcLen               = DPC14;
    tSapCfg->mgMtpNwCfg.subService          = SSF_INTL;
    tSapCfg->mgMtpNwCfg.sls                 = LMG_ITU_SLS_RANGE;
    tSapCfg->mgMtpNwCfg.maxBinsMgcoMtpHl    = 10;
    tSapCfg->mgMtpNwCfg.defStatusEnqTmr.enb = TRUE;
    tSapCfg->mgMtpNwCfg.defStatusEnqTmr.val = 15;
    tSapCfg->mgMtpNwCfg.defRstEndTmr.enb    = TRUE;
    tSapCfg->mgMtpNwCfg.defRstEndTmr.val    = 5;
#endif   /* GCP_PROV_MTP3 */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    tSapCfg->remIntfValid = TRUE;          /* remote interface version is valid */
    tSapCfg->remIntfVer   = MGTIFVER;            /* remote interface version */
#endif  

   /*--------- Fill TSAP Reconfiguration information ----------*/
    tSapReCfg->dnsCfg.dnsAccess                  = LMG_DNS_DISABLED;
    tSapReCfg->dnsCfg.dnsAddr.type               = CM_TPTADDR_IPV4;
    tSapReCfg->dnsCfg.dnsAddr.u.ipv4TptAddr.port = (U16)53;
    tSapReCfg->dnsCfg.dnsAddr.u.ipv4TptAddr.address  = (CmInetIpAddr)MG_DNS_IP_CFG;
    tSapReCfg->dnsCfg.dnsRslvTmr.enb             = FALSE;
    tSapReCfg->dnsCfg.dnsRslvTmr.val             = 60;  /* 60 sec */
    tSapReCfg->dnsCfg.maxRetxCnt                 = 4;
#if (defined(GCP_MGCP) || defined(TDS_ROLL_UPGRADE_SUPPORT))   
    tSapReCfg->dnsCfg.ttl = 1000;
#endif /* GCP_MGCP || TDS_ROLL_UPGRADE_SUPPORT */      
    tSapReCfg->tMax = 340;
    tSapReCfg->tptParam.type = CM_TPTPARAM_SOCK;
#ifdef WIN32
    tSapReCfg->tptParam.u.sockParam.listenQSize = 1;
#else
    tSapReCfg->tptParam.u.sockParam.listenQSize = 5;
#endif
    tSapReCfg->tptParam.u.sockParam.numOpts = 0;
#if (defined(GCP_MGCP) || defined(TDS_ROLL_UPGRADE_SUPPORT))   
    tSapReCfg->defDisConThold = 2;
    tSapReCfg->defSuspThold   = 1;
#endif /* GCP_MGCP || TDS_ROLL_UPGRADE_SUPPORT */
#if (defined(GCP_MGCO) || defined(TDS_ROLL_UPGRADE_SUPPORT))   
    tSapReCfg->idleTmr.enb = FALSE;
#endif /* GCP_MGCO || TDS_ROLL_UPGRADE_SUPPORT */   
   
	/*Hdr for Mngmt*/       
	mgMngmt->hdr.msgType          = TCFG;
	mgMngmt->hdr.entId.ent        = ENTMG;
	mgMngmt->hdr.entId.inst       = MG_APPINST0;
	mgMngmt->hdr.elmId.elmnt      = STTSAP;
	mgMngmt->hdr.elmId.elmntInst1 = MG_APPINST1;
	mgMngmt->hdr.elmId.elmntInst2 = MG_APPINST2;
	mgMngmt->hdr.elmId.elmntInst3 = MG_APPINST3;
	mgMngmt->hdr.transId          = 0;
#ifdef LMINT3
    mgMngmt->hdr.transId = mgGetTransId();     /* transaction Id - mandatory */
    mgMngmt->hdr.response.prior     = PRIOR0;
	mgMngmt->hdr.response.route     = RTESPEC;
	mgMngmt->hdr.response.mem.region= DFLT_REGION; 
	mgMngmt->hdr.response.mem.pool  = DFLT_POOL; 
	mgMngmt->hdr.response.mem.spare = 0;  /* chendh modify it*/
#ifdef LCMGMILMG
	mgMngmt->hdr.response.selector = 0;
#else
	mgMngmt->hdr.response.selector = 1;
#endif  /*LCMGMILMG*/
#endif  /*LMINT3*/    

	/*------------- add node to queue -------------*/
	cmLListAdd2Tail(&gMgSmQ[MGCO_TSAPCFG_Q], node);
    
   RETVOID;
} /* mgNmsTSapCfgReq */

/********************************************************************
*
*       Fun:   suEntCfgReq
*
*       Desc:  Set up the Entity configuration structure
*
*       Ret:   ROK
*              RFAILED
*
*
********************************************************************/

#ifdef ANSI
Void mgNmsPeerEntCfgReq
(
SpId     spId
)
#else
Void mgNmsPeerEntCfgReq (spId)
SpId     spId;
#endif
{

    /* local variables */
	S16          idx; 
    U8           priority;
    U32          address;
    S32          port;
    U16          len;
	U16  ipIdx;	
    
    CmLList		 *node;
	MgMngmt      *mgMngmt;
	MgGcpEntCfg  *entPeerCfg;	
        
	TRC2 (mgNmsPeerEntCfgReq)
	
	/* alloc a node for save sm msg info */
	if( ROK != smGetQNode(&node, sizeof(MgMngmt)))
	{
		RETVOID;
	}
	
	mgMngmt = (MgMngmt *)cmLListNode(node);
	mgMngmt->hdr.msgLen = sizeof( MgMngmt);
 			
	entPeerCfg = (MgGcpEntCfg  *)&(mgMngmt->t.cfg.c.mgGcpEntCfg);
	cmMemset ((U8 *) entPeerCfg  , 0, sizeof (MgGcpEntCfg));   
  
#ifdef GCP_MGC 
    	idx      = g_MgNmsCfgData.mgMGCPeerEntCfgTab.mgId;
    	priority = 0;
    	port     = g_MgNmsCfgData.mgMGCPeerEntCfgTab.port;
//    address  = CM_INET_NTOH_U32(g_MgNmsCfgData.mgMGCPeerEntCfgTab.ipAddr);
//	address = CM_INET_NTOH_U32(g_MgNmsCfgData.mgIPAddrTab[1].IpAddr);
//	address = CM_INET_NTOH_U32(gstCpSs7Global.IPTab[g_MgNmsCfgData.mgMGCPeerEntCfgTab.IpIndex].IpAddr);
	for(ipIdx=0;ipIdx<xwCpComIpTable_ROW_NUM;ipIdx++)
		{
	 		if(gstCpSs7Global.IPTab[ipIdx].IpIndex == g_MgNmsCfgData.mgMGCPeerEntCfgTab.IpIndex)	
				address = CM_INET_NTOH_U32(gstCpSs7Global.IPTab[ipIdx].IpAddr);
		}
	len = (U8)cmStrlen((CONSTANT U8 *)g_MgNmsCfgData.mgMGCPeerEntCfgTab.name);
	if(len > 0)
    	cmMemcpy ((U8 *) entPeerCfg->peerCfg[idx].name, 
		 (CONSTANT U8 *)g_MgNmsCfgData.mgMGCPeerEntCfgTab.name,len);
    	entPeerCfg->peerCfg[idx].name[len] = '\0';
#else 
    	idx      = g_MgNmsCfgData.mgMGPeerEntCfgTab.mgcId;

	if(!((idx == 0)||(idx == 1)))   /*cdw add by 2006.7.31*/
	{
		printf("\nconfigure data mgcId is invalid, mgcId can only be 0 or 1\n");
     		printf("input a char to exit:\n");  
		getch();
		exit(0);
	}	
    	priority = g_MgNmsCfgData.mgMGPeerEntCfgTab.mgcPriority;
    	port     = g_MgNmsCfgData.mgMGPeerEntCfgTab.port;
//    	address  = CM_INET_NTOH_U32(g_MgNmsCfgData.mgMGPeerEntCfgTab.ipAddr);
//	address = CM_INET_NTOH_U32(g_MgNmsCfgData.mgIPAddrTab[0].IpAddr);
	for(ipIdx=0;ipIdx<xwCpComIpTable_ROW_NUM;ipIdx++)
		{
	 		if(gstCpSs7Global.IPTab[ipIdx].IpIndex == g_MgNmsCfgData.mgMGPeerEntCfgTab.IpIndex)	
				address = CM_INET_NTOH_U32(gstCpSs7Global.IPTab[ipIdx].IpAddr);
		}
	len = (U8)cmStrlen((CONSTANT U8 *)g_MgNmsCfgData.mgMGPeerEntCfgTab.name);
    	if(len > 0)
    	cmMemcpy ((U8 *) entPeerCfg->peerCfg[idx].name, 
		 (CONSTANT U8 *)g_MgNmsCfgData.mgMGPeerEntCfgTab.name,len);
    	entPeerCfg->peerCfg[idx].name[len] = '\0';
#endif
        
	/*---------------- Configuration Parameter -----------------*/

    entPeerCfg->numPeer = 1;
	entPeerCfg->peerCfg[idx].sSAPId            = spId;
    entPeerCfg->peerCfg[idx].peerAddrTbl.count = 1;
    entPeerCfg->peerCfg[idx].peerAddrTbl.netAddr[0].type          = CM_NETADDR_IPV4;
    entPeerCfg->peerCfg[idx].peerAddrTbl.netAddr[0].u.ipv4NetAddr = address;
    entPeerCfg->peerCfg[idx].port = port;
	entPeerCfg->peerCfg[idx].mtuSize        = 1500;

#if (defined(GCP_MGCO) || defined(TDS_ROLL_UPGRADE_SUPPORT))
	{
		U8 tmpMid[64] = {0};
		U8 *pAddress;
		cmInetNtoa(CM_INET_NTOH_U32(address),&pAddress);
		if(pAddress != NULL)
		{
			sprintf(tmpMid,"[%s]:%d",pAddress,port);
			len = (U8)cmStrlen( (U8 *) tmpMid);
    		entPeerCfg->peerCfg[idx].mid.pres = PRSNT_NODEF;
    		entPeerCfg->peerCfg[idx].mid.len = len;
    		cmMemcpy((U8 *)entPeerCfg->peerCfg[idx].mid.val, (CONSTANT U8*)tmpMid, len);			

		}
		else
		{
			printf("[MG]ERROR: invoke cmInetNtoa() failed.maybe the address.%x\r\n",address);
		}
			
	}
#endif /*(defined(GCP_MGCO) || defined(TDS_ROLL_UPGRADE_SUPPORT))*/

#ifdef GCP_MG
    entPeerCfg->peerCfg[idx].encodingScheme = LMG_ENCODE_TXT;
    entPeerCfg->peerCfg[idx].mgcPriority    = priority;
    entPeerCfg->peerCfg[idx].transportType  = LMG_TPT_UDP;
    
/*    entPeerCfg->peerCfg[idx].tos.pres       = NOTPRSNT;   */
    entPeerCfg->peerCfg[idx].tsapId         = 0;
#endif

    /*Hdr for Mngmt*/     
	mgMngmt->hdr.msgType          = TCFG;
	mgMngmt->hdr.entId.ent        = ENTMG;
	mgMngmt->hdr.entId.inst       = MG_APPINST0;
	mgMngmt->hdr.elmId.elmnt      = STGCPENT;
	mgMngmt->hdr.elmId.elmntInst1 = MG_APPINST1;
	mgMngmt->hdr.elmId.elmntInst2 = MG_APPINST2;
	mgMngmt->hdr.elmId.elmntInst3 = MG_APPINST3;
	mgMngmt->hdr.transId          = 0;
#ifdef LMINT3
    mgMngmt->hdr.transId = mgGetTransId();          /* transaction Id - mandatory */
    mgMngmt->hdr.response.prior     = PRIOR0;
	mgMngmt->hdr.response.route     = RTESPEC;
	mgMngmt->hdr.response.mem.region= DFLT_REGION; 
	mgMngmt->hdr.response.mem.pool  = DFLT_POOL; 
	mgMngmt->hdr.response.mem.spare = 0;  /* chendh modify it*/
#ifdef LCMGMILMG
	mgMngmt->hdr.response.selector = 0;
#else
	mgMngmt->hdr.response.selector = 1;
#endif  /*LCMGMILMG*/
#endif  /*LMINT3*/

	
	/*------------- add node to queue -------------*/
	cmLListAdd2Tail(&gMgSmQ[MGCO_GCPENTCFG_Q], node);

	
	RETVOID;
} 

/********************************************************************
*
*       Fun:   mgNmsSSapCfgReq
*
*       Desc:  Set up the SSAP configuration structure
*
*       Ret:   ROK
*              RFAILED
*
*
********************************************************************/

#ifdef ANSI
Void mgNmsSSapCfgReq
(
SpId       spId
)
#else
Void mgNmsSSapCfgReq (spId)
SpId       spId;
#endif
{
    /* local variables */
    MgMngmt      *mgMngmt;
    MgSSAPCfg    *sSapCfg; 
    MgSSAPReCfg  *sSapReCfg;    
    CmLList		*node;
	U16 ipIdx;

    TRC2 (mgNmsSSapCfgReq)

	/* alloc a node for save sm msg info */
    if( ROK != smGetQNode(&node, sizeof(MgMngmt)))
    {
	    RETVOID;
    }
	
    mgMngmt = (MgMngmt *)cmLListNode(node);
	mgMngmt->hdr.msgLen = sizeof( MgMngmt);

    sSapCfg   = &(mgMngmt->t.cfg.c.sSAPCfg);
    sSapReCfg = &(sSapCfg->reCfg);

    cmMemset ((U8 *) sSapCfg, 0, sizeof (MgSSAPCfg));   
    cmMemset ((U8 *) sSapReCfg, 0, sizeof (MgSSAPReCfg));   

    sSapCfg->sSAPId = spId;  
#ifdef LCMGMILMG
 #ifdef CP_UA_IF_TYPE_SS	
	sSapCfg->sel = MGT_SEL_LWLC_SS;
 #else
    sSapCfg->sel = MGT_SEL_LC;
 #endif /*CP_UA_IF_TYPE_SS*/
#else
	sSapCfg->sel = 1;
#endif  /*LCMGMILMG*/                     
    	sSapCfg->memId.region  = DFLT_REGION;      
    	sSapCfg->memId.pool    = DFLT_POOL;
    	sSapCfg->prior         = PRIOR0;             
    	sSapCfg->route         = RTESPEC;            
    	sSapCfg->protocol      = LMG_PROTOCOL_MGCO;        
    	sSapCfg->userInfo.dname.netAddr.type          = CM_NETADDR_IPV4;    
    	sSapCfg->userInfo.dname.namePres.pres         = NOTPRSNT;

#ifdef GCP_MGC
//	sSapCfg->userInfo.dname.netAddr.u.ipv4NetAddr = CM_INET_NTOH_U32(g_MgNmsCfgData.mgMGCSrvrCfgTab.address); 	
//	sSapCfg->userInfo.dname.netAddr.u.ipv4NetAddr = CM_INET_NTOH_U32(g_MgNmsCfgData.mgIPAddrTab[0].IpAddr);
	for(ipIdx=0;ipIdx<xwCpComIpTable_ROW_NUM;ipIdx++)
		{
	 		if(gstCpSs7Global.IPTab[ipIdx].IpIndex == g_MgNmsCfgData.mgMGCSrvrCfgTab.IpIndex)	
				sSapCfg->userInfo.dname.netAddr.u.ipv4NetAddr = CM_INET_NTOH_U32(gstCpSs7Global.IPTab[ipIdx].IpAddr);
		}
	sSapCfg->userInfo.port.pres = PRSNT_NODEF;
	sSapCfg->userInfo.port.val = g_MgNmsCfgData.mgMGCSrvrCfgTab.listenport;
#elif GCP_MG
//	sSapCfg->userInfo.dname.netAddr.u.ipv4NetAddr = CM_INET_NTOH_U32(g_MgNmsCfgData.mgMGSrvrCfgTab.address);
//	sSapCfg->userInfo.dname.netAddr.u.ipv4NetAddr = CM_INET_NTOH_U32(g_MgNmsCfgData.mgIPAddrTab[1].IpAddr); 
	for(ipIdx=0;ipIdx<xwCpComIpTable_ROW_NUM;ipIdx++)
		{
	 		if(gstCpSs7Global.IPTab[ipIdx].IpIndex == g_MgNmsCfgData.mgMGSrvrCfgTab.IpIndex)	
				sSapCfg->userInfo.dname.netAddr.u.ipv4NetAddr = CM_INET_NTOH_U32(gstCpSs7Global.IPTab[ipIdx].IpAddr);
		}
	sSapCfg->userInfo.port.pres = PRSNT_NODEF;
	sSapCfg->userInfo.port.val = g_MgNmsCfgData.mgMGSrvrCfgTab.port;
#endif
    
    sSapCfg->userInfo.pres.pres = PRSNT_NODEF;
    sSapCfg->userInfo.id.pres = NOTPRSNT;
#if (defined(GCP_MGCO) || defined(TDS_ROLL_UPGRADE_SUPPORT))
    sSapCfg->userInfo.mid.pres = NOTPRSNT;
#endif /* GCP_MGCO || TDS_ROLL_UPGRADE_SUPPORT */
    
#ifdef   GCP_PROV_MTP3 
    sSapCfg->userInfo.selfPc.pres = PRSNT_NODEF;
    sSapCfg->userInfo.selfPc.val  = SELF_PC_VAL;  
#endif   /* GCP_PROV_MTP3 */   
    sSapCfg->startTxnNum = 50;      
    sSapCfg->endTxnNum   = 60;       
#ifdef GCP_MG
    sSapCfg->initReg  = FALSE;       
    sSapCfg->mwdTimer = 10;        
#if (defined(GCP_MGCP) || defined(TDS_ROLL_UPGRADE_SUPPORT))    
    sSapCfg->mgcpVersion = LMG_VER_PROF_MGCP_RFC2705_1_0;        
#endif /* GCP_MGCP || TDS_ROLL_UPGRADE_SUPPORT */
#endif /* GCP_MG */
#if (defined(GCP_MGCO) || defined(TDS_ROLL_UPGRADE_SUPPORT)) 
#ifdef GCP_VER_1_5     
    sSapCfg->minMgcoVersion = LMG_VER_PROF_MGCO_H248_1_0; 
    sSapCfg->maxMgcoVersion = LMG_VER_PROF_MGCO_H248_2_0; 
#else
    sSapCfg->minMgcoVersion = (U32)LMG_VER_PROF_MGCO_H248_1_0; 
    sSapCfg->maxMgcoVersion = (U32)LMG_VER_PROF_MGCO_H248_2_0; 
#endif
#endif /* GCP_MGCO || TDS_ROLL_UPGRADE_SUPPORT */
#ifdef TDS_ROLL_UPGRADE_SUPPORT     
    sSapCfg->remIntfValid = TRUE;     
    sSapCfg->remIntfVer   = MGTIFVER;     
    sSapCfg->dstProcId    = SFndProcId(); 
#endif   
#if (defined(GCP_CH) && defined(GCP_VER_1_5))
    sSapCfg->chEnabled = TRUE;        
#endif /* GCP_CH && GCP_VER_1_5 */ 

/*--------- Fill TSAP Reconfiguration information ----------*/
    sSapReCfg->initRetxTmr.enb   = TRUE;
    sSapReCfg->initRetxTmr.val   = 20;
    sSapReCfg->provRspTmr.enb    = TRUE;
    sSapReCfg->provRspTmr.val    = 50;
    sSapReCfg->provRspDelay      = 2;
    sSapReCfg->atMostOnceTmr.enb = TRUE;
    sSapReCfg->atMostOnceTmr.val = 30; 

    /*Hdr for Mngmt*/     
	mgMngmt->hdr.msgType          = TCFG;
	mgMngmt->hdr.entId.ent        = ENTMG;
	mgMngmt->hdr.entId.inst       = MG_APPINST0;
	mgMngmt->hdr.elmId.elmnt      = STSSAP;
	mgMngmt->hdr.elmId.elmntInst1 = MG_APPINST1;
	mgMngmt->hdr.elmId.elmntInst2 = MG_APPINST2;
	mgMngmt->hdr.elmId.elmntInst3 = MG_APPINST3;
	mgMngmt->hdr.transId          = 0;
#ifdef LMINT3
    mgMngmt->hdr.transId = mgGetTransId();          /* transaction Id - mandatory */
    mgMngmt->hdr.response.prior     = PRIOR0;
	mgMngmt->hdr.response.route     = RTESPEC;
	mgMngmt->hdr.response.mem.region= DFLT_REGION; 
	mgMngmt->hdr.response.mem.pool  = DFLT_POOL; 
	mgMngmt->hdr.response.mem.spare = 0;  /* chendh modify it*/
#ifdef LCMGMILMG
	mgMngmt->hdr.response.selector = 0;
#else
	mgMngmt->hdr.response.selector = 1;
#endif  /*LCMGMILMG*/
#endif  /*LMINT3*/    

    /*------------- add node to queue -------------*/
    cmLListAdd2Tail(&gMgSmQ[MGCO_SSAPCFG_Q], node);
	
    RETVOID;
}

#ifdef ANSI
Void   mgNmsSrvrCfgReq
(
SpId   spId,
SuId   suId
)
#else
Void   mgNmsSrvrCfgReq(spId, suId)
SpId   spId;
SuId   suId;    
#endif
{
    /* local variables */
    MgMngmt       *mgMngmt;
    MgTptSrvrCfg  *srvrCfg;     
    CmLList		 *node;
	U16 ipIdx;

#ifdef GCP_MGC	
	U16           startPort;
    U16           endPort;
	U16           idx;
    U16           i;
	U16        listenPort;
#endif /*GCP_MGC*/

    TRC2 (mgNmsSrvrCfgReq)

	/* alloc a node for save sm msg info */
    if( ROK != smGetQNode(&node, sizeof(MgMngmt)))
    {
	   RETVOID;
    }
	
    mgMngmt = (MgMngmt *)cmLListNode(node);
	mgMngmt->hdr.msgLen = sizeof( MgMngmt);

    srvrCfg   = &(mgMngmt->t.cfg.c.tptSrvrCfg);

    cmMemset ((U8 *) srvrCfg, 0, sizeof (MgTptSrvrCfg)); 

    /* Transport Server Configure (MGC side) */
#ifdef GCP_MGC
    	startPort     = g_MgNmsCfgData.mgMGCSrvrCfgTab.startport;
    	endPort       = g_MgNmsCfgData.mgMGCSrvrCfgTab.endport;
	listenPort =  g_MgNmsCfgData.mgMGCSrvrCfgTab.listenport;

   	 if((startPort > endPort)||(startPort==0)||(endPort==0))  /*calculate the server's numbers */
   		 {
   	 		srvrCfg->count = 1;
       	#ifdef CP_OAM_DATA_SHOW
	   		printf("\n******   the MGC only have ONE Server(transport port):%d   ******\n", g_MgNmsCfgData.mgMGCSrvrCfgTab.listenport);
	 	#endif  	
		}
    	else
    		{
			if((startPort<=listenPort)&&(endPort>=listenPort))
       			srvrCfg->count = 1 + (endPort - startPort);
	    		else
   	    			srvrCfg->count = 2 + (endPort - startPort);
    		}
	if(srvrCfg->count > LMG_MAX_DEF_LSTNR)
		{
			srvrCfg->count = LMG_MAX_DEF_LSTNR;
			printf("\nWarning!!! the configured port's numbers bigger than the max port(%d).\n",LMG_MAX_DEF_LSTNR);
		}
   	idx = srvrCfg->count;
	
    for(i=0;i<idx;i++)
    {
    srvrCfg->srvr[i].isDefault = TRUE;
    srvrCfg->srvr[i].sSAPId    = suId;
    srvrCfg->srvr[i].tSAPId    = spId;
    srvrCfg->srvr[i].protocol  = LMG_PROTOCOL_MGCO;
    srvrCfg->srvr[i].transportType = LMG_TPT_UDP;
#if (defined(GCP_MGCO) || defined(TDS_ROLL_UPGRADE_SUPPORT))  
    srvrCfg->srvr[i].encodingScheme = LMG_ENCODE_TXT;
#endif /* GCP_MGCO || TDS_ROLL_UPGRADE_SUPPORT */
    srvrCfg->srvr[i].tptParam.type = CM_TPTPARAM_SOCK;
    srvrCfg->srvr[i].tptParam.u.sockParam.listenQSize = 0;
    srvrCfg->srvr[i].tptParam.u.sockParam.numOpts = 2;
    srvrCfg->srvr[i].tptParam.u.sockParam.sockOpts[0].option = CM_SOCKOPT_OPT_RX_BUF_SIZE;
    srvrCfg->srvr[i].tptParam.u.sockParam.sockOpts[0].optVal.value = 64*1024;
    srvrCfg->srvr[i].tptParam.u.sockParam.sockOpts[0].level = CM_SOCKOPT_LEVEL_SOCKET;
    srvrCfg->srvr[i].tptParam.u.sockParam.sockOpts[1].option = CM_SOCKOPT_OPT_TX_BUF_SIZE;
    srvrCfg->srvr[i].tptParam.u.sockParam.sockOpts[1].optVal.value = 64*1024;	/* mdf by leon.teng on 2002-6-17 */
    srvrCfg->srvr[i].tptParam.u.sockParam.sockOpts[1].level = CM_SOCKOPT_LEVEL_SOCKET;

    srvrCfg->srvr[i].lclTptAddr.type = CM_TPTADDR_IPV4;
//    srvrCfg->srvr[i].lclTptAddr.u.ipv4TptAddr.address = CM_INET_NTOH_U32(g_MgNmsCfgData.mgMGCSrvrCfgTab.address);
//	srvrCfg->srvr[i].lclTptAddr.u.ipv4TptAddr.address = CM_INET_NTOH_U32(g_MgNmsCfgData.mgIPAddrTab[0].IpAddr);
//	srvrCfg->srvr[i].lclTptAddr.u.ipv4TptAddr.address = CM_INET_NTOH_U32(gstCpSs7Global.IPTab[g_MgNmsCfgData.mgMGCSrvrCfgTab.IpIndex].IpAddr);
	for(ipIdx=0;ipIdx<xwCpComIpTable_ROW_NUM;ipIdx++)
		{
	 		if(gstCpSs7Global.IPTab[ipIdx].IpIndex == g_MgNmsCfgData.mgMGCSrvrCfgTab.IpIndex)	
				srvrCfg->srvr[i].lclTptAddr.u.ipv4TptAddr.address = CM_INET_NTOH_U32(gstCpSs7Global.IPTab[ipIdx].IpAddr);
		}
    if(i==0)
    srvrCfg->srvr[i].lclTptAddr.u.ipv4TptAddr.port = listenPort;
    else
    	{
    		srvrCfg->srvr[i].lclTptAddr.u.ipv4TptAddr.port = startPort + i - 1;
			if(srvrCfg->srvr[i].lclTptAddr.u.ipv4TptAddr.port == listenPort)   /*cdw add by 2006.7.28*/
				{
					startPort++;    /* cdw add for fixing a bug that 2 tpt server are same on 2006.10.10 */
					srvrCfg->srvr[i].lclTptAddr.u.ipv4TptAddr.port = listenPort+1;	/*add end*/
				}
    	}
    }
#endif

    /* Transport Server Configure (MG side) */
#ifdef GCP_MG
    srvrCfg->count = 1;
    srvrCfg->srvr[0].isDefault = g_MgNmsCfgData.mgMGSrvrCfgTab.isDefault;
    srvrCfg->srvr[0].sSAPId = suId;
    srvrCfg->srvr[0].tSAPId = spId;
    srvrCfg->srvr[0].protocol = LMG_PROTOCOL_MGCO;
    srvrCfg->srvr[0].transportType = LMG_TPT_UDP;
#if (defined(GCP_MGCO) || defined(TDS_ROLL_UPGRADE_SUPPORT))  
    srvrCfg->srvr[0].encodingScheme = LMG_ENCODE_TXT;
#endif /* GCP_MGCO || TDS_ROLL_UPGRADE_SUPPORT */
    srvrCfg->srvr[0].tptParam.type = CM_TPTPARAM_SOCK;
    srvrCfg->srvr[0].tptParam.u.sockParam.listenQSize = 0;
    srvrCfg->srvr[0].tptParam.u.sockParam.numOpts = 2;
    srvrCfg->srvr[0].tptParam.u.sockParam.sockOpts[0].option = CM_SOCKOPT_OPT_RX_BUF_SIZE;
    srvrCfg->srvr[0].tptParam.u.sockParam.sockOpts[0].optVal.value = 64*1024;
    srvrCfg->srvr[0].tptParam.u.sockParam.sockOpts[0].level = CM_SOCKOPT_LEVEL_SOCKET;
    srvrCfg->srvr[0].tptParam.u.sockParam.sockOpts[1].option = CM_SOCKOPT_OPT_TX_BUF_SIZE;
    srvrCfg->srvr[0].tptParam.u.sockParam.sockOpts[1].optVal.value = 64*1024;	/* mdf by leon.teng on 2002-6-17 */
    srvrCfg->srvr[0].tptParam.u.sockParam.sockOpts[1].level = CM_SOCKOPT_LEVEL_SOCKET;

    srvrCfg->srvr[0].lclTptAddr.type = CM_TPTADDR_IPV4;
//    srvrCfg->srvr[0].lclTptAddr.u.ipv4TptAddr.address = CM_INET_NTOH_U32(g_MgNmsCfgData.mgMGSrvrCfgTab.address);
//	srvrCfg->srvr[0].lclTptAddr.u.ipv4TptAddr.address = CM_INET_NTOH_U32(g_MgNmsCfgData.mgIPAddrTab[1].IpAddr);
//	srvrCfg->srvr[0].lclTptAddr.u.ipv4TptAddr.address = CM_INET_NTOH_U32(gstCpSs7Global.IPTab[g_MgNmsCfgData.mgMGSrvrCfgTab.IpIndex].IpAddr);
	for(ipIdx=0;ipIdx<xwCpComIpTable_ROW_NUM;ipIdx++)
		{
	 		if(gstCpSs7Global.IPTab[ipIdx].IpIndex == g_MgNmsCfgData.mgMGSrvrCfgTab.IpIndex)	
				srvrCfg->srvr[0].lclTptAddr.u.ipv4TptAddr.address = CM_INET_NTOH_U32(gstCpSs7Global.IPTab[ipIdx].IpAddr);
		}
	srvrCfg->srvr[0].lclTptAddr.u.ipv4TptAddr.port = g_MgNmsCfgData.mgMGSrvrCfgTab.port;
#endif
    /*Hdr for Mngmt*/    
	mgMngmt->hdr.msgType          = TCFG;
	mgMngmt->hdr.entId.ent        = ENTMG;
	mgMngmt->hdr.entId.inst       = MG_APPINST0;
	mgMngmt->hdr.elmId.elmnt      = STSERVER;
	mgMngmt->hdr.elmId.elmntInst1 = MG_APPINST1;
	mgMngmt->hdr.elmId.elmntInst2 = MG_APPINST2;
	mgMngmt->hdr.elmId.elmntInst3 = MG_APPINST3;
	mgMngmt->hdr.transId          = 0;
#ifdef LMINT3
    mgMngmt->hdr.transId = mgGetTransId();          /* transaction Id - mandatory */
    mgMngmt->hdr.response.prior     = PRIOR0;
	mgMngmt->hdr.response.route     = RTESPEC;
	mgMngmt->hdr.response.mem.region= DFLT_REGION; 
	mgMngmt->hdr.response.mem.pool  = DFLT_POOL; 
	mgMngmt->hdr.response.mem.spare = 0;  /* chendh modify it*/
#ifdef LCMGMILMG
	mgMngmt->hdr.response.selector = 0;
#else
	mgMngmt->hdr.response.selector = 1;
#endif  /*LCMGMILMG*/
#endif  /*LMINT3*/    

    /*------------- add node to queue -------------*/
    cmLListAdd2Tail(&gMgSmQ[MGCO_STSRVCFG_Q], node);

    RETVOID;   
}

U32 mgGetTransId()
{
    return g_cfgTransId++;
}

/*
 *       Fun:    mgcoSmDefHdr - fill in default management header
 *       Desc:
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *       Notes:  None
		 File:   mg_acc3.c
 *
 */
PUBLIC Void mgcoSmDefHdr
(
Header *hdr
)
{
	hdr->msgType             = TCNTRL;
	hdr->entId.ent           = ENTMG;
	hdr->entId.inst          = MG_APPINST0;
	hdr->elmId.elmnt         = STTSAP;
	hdr->elmId.elmntInst1    = MG_APPINST1;
	hdr->elmId.elmntInst2    = MG_APPINST2;
	hdr->elmId.elmntInst3    = MG_APPINST3;
	hdr->transId             = mgGetTransId();
#ifdef LCMGMILMG
	hdr->response.selector = MU_LC;
#else
	hdr->response.selector = MU_TC;
#endif
	hdr->response.prior      = PRIOR0;
	hdr->response.route      = RTESPEC;
	hdr->response.mem.region = DFLT_REGION; 
	hdr->response.mem.pool   = DFLT_POOL; 
	hdr->response.mem.spare  = 0; 

	RETVOID;
} /* end of mgAccDefHdr() */

PUBLIC S16 MgTsapEnbCtrl(Pst *pst,SpId spId)
{
	/* do tsap cntrlreq - abnd_ena, bind, servopen sequence */
	/* send cntrlreq - abnd_ena to tsap */
	MgMngmt mgt;

	mgt.hdr.elmId.elmnt = STTSAP;
	mgcoSmDefHdr(&mgt.hdr);
	mgt.t.cntrl.action = ABND_ENA;
	mgt.t.cntrl.spId = spId;

	return SmMiLmgCntrlReq(pst, &mgt);
}

PUBLIC S16 MgSsapEnbCtrl(Pst *pst,SpId spId)
{
	/* SSAP 0 bind and enable sequence */
	/* issue CntrlReq - AENA for SSAP */
	MgMngmt mgt;
	
	mgcoSmDefHdr(&mgt.hdr);
	mgt.hdr.elmId.elmnt = STSSAP;
	mgt.t.cntrl.action = AENA;
	mgt.t.cntrl.spId = spId;

	return SmMiLmgCntrlReq(pst, &mgt);
}

/* invoked IN mg_nms.c*/
PUBLIC Void MGSapEnbCtrl()
{
	SpId spId = MG_HI_SIPID;
	Pst pst;	

	MuFillDefPst(&pst);
    pst.srcEnt   = ENTSM;
    pst.srcInst  = MG_APPINST0;
    pst.dstEnt   = ENTMG;
    pst.dstInst  = MG_APPINST0;

#ifdef LCMULIMGT
    pst.selector  = MU_LC;
#else
    pst.selector  = MU_TC;
#endif

	MgTsapEnbCtrl(&pst,spId);
	MgSsapEnbCtrl(&pst,0);

	g_mgCfgEnbFinish = TRUE;
}

/**********************************************************************
*
*       Fun:   MuFillDefPst
*
*       Desc:  Fills the defult Post Structure
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*
**********************************************************************/
#ifdef ANSI
PUBLIC Void MuFillDefPst
(
Pst   *pst
)
#else
PRIVATE Void MuFillDefPst(pst)
Pst   *pst;   
#endif   
{
   TRC2(MuFillDefPst)
   /*---------- Fill default values in Pst structure ----------*/
   pst->dstProcId = SFndProcId();
   pst->srcProcId = SFndProcId();
   pst->prior     = PRIOR0;
   pst->route     = RTESPEC;
   pst->event     = EVTNONE;
   pst->region    = DFLT_REGION; 
   pst->pool      = DFLT_POOL; 

   RETVOID;
}


#ifdef SSI_WITH_CLI_ENABLED   
PUBLIC Void  RegisterXosCli()
{
	XS32 retPrtl = 0;	
	XS32 retMgco;
	
	/*Э����ʾ��*/
	retPrtl = XOS_RegistCmdPrompt( SYSTEM_MODE, "prtl",  "Э��ģʽ", "�޲���" );

	retMgco = XOS_RegistCmdPrompt( retPrtl, "megaco", "MEGACO Э��", "�޲���" );

	XOS_RegistCommand(retMgco,
		              mgcoPrintMgCb,
					  "showmgcb",
					  "��ӡ���ƿ�",
					  "�޲���\r\n");

	XOS_RegistCommand(retMgco,
		              mgcoPrintGenCfg,
					  "showgencfg",
					  "��ӡͨ��������Ϣ",
					  "�޲���\r\n");

	XOS_RegistCommand(retMgco,
		              mgcoPrintTSAPLst,
					  "showtsap",
					  "��ӡTSAP���ƿ顣",
					  "�޲�����һ������������Ϊ0~9�����֣����޲���ʱ��ӡ����TSAP��Ϣ\r\n");

	XOS_RegistCommand(retMgco,
		              mgcoPrintSSAPLst,
					  "showssap",
					  "��ӡSSAP���ƿ顣",
					  "�޲�����һ������������Ϊ0~9�����֣����޲���ʱ��ӡ����SSAP��Ϣ\r\n");

	XOS_RegistCommand(retMgco,
		              mgcoPrintPeerLst,
					  "showpeer",
					  "��ӡ�Զ���Ϣ",
					  "�޲�����һ������������Ϊ0~9�����֣����޲���ʱ��ӡ���жԶ���Ϣ\r\n");

	XOS_RegistCommand(retMgco,
		              mgcoPrintPeerLstSts,
					  "showpeersts",
					  "��ӡ�Զ�ͳ����Ϣ",
					  "�޲���\r\n");

	XOS_RegistCommand(retMgco,
		              showTraceLevel,
					  "showdbgmask",
					  "��ʾdbgmask��Ϣ",
					  "�޲���\r\n");
	
	XOS_RegistCommand(retMgco,
		              mgSetTraceLevel,
					  "setdbgmask",
					  "����Э��ջ���Լ���",
					  "һ������:dbgMask  (����\"����+help\"��ʾ��ϸ������Ϣ)\r\n");
	
}
#endif


/*
 *            Changed the order of registration and attaching of
 *            tasks. The order now is -
 *            1) Register all the tasks with SSI
 *            2) Create a system thread
 *            3) Attach all the tasks with the thread
 *
 *            Also, attaching of the permanent test task has been
 *            moved towards the end of this function after the
 *            initialization code has been completed. This is
 *            done so as not to run into issues on Windows in
 *            multithreaded mode.
 */
#ifdef ANSI
PUBLIC S16 MgcoInit
(
void
)
#else
PUBLIC S16 MgcoInit()
#endif /* ANSI */
{
   S16 rc;
   Txt   prBuf[PRNTSZE];   /* SPrint buffer */
   
   SSTskId		mgTskId;
#ifdef GCP_VER_1_5      
#endif
#ifdef CP_OAM_SUPPORT
EXTERN Bool g_taskRegComp;
#endif
   TRC1(MgcoInit)


   if (SRegTTsk((Ent)ENTSM, (Inst)0, (Ttype)TTNORM, PRIOR0,
              smActvInit, smActvTsk ) != ROK)
   {
      sprintf(prBuf, "SRegTTsk() failed for smActvInit()\n");
      SPrint(prBuf);
      RETVALUE(RFAILED);
   }

   /* Register MGCP, TUCL and stack manager, MR, perm tasks */
   if (SRegTTsk((Ent)ENTMG, (Inst)0, (Ttype)TTNORM, PRIOR0,
              mgActvInit, mgActvTsk ) != ROK)
   {
      sprintf(prBuf, "SRegTTsk() failed for mgActvInit()\n");
      SPrint(prBuf);
      RETVALUE(RFAILED);
   }

   /* Create a single thread and attach all task to this normal and perm task on it */
   if (SCreateSTsk ((SSTskPrior) 13, &mgTskId) != ROK)
   {
      sprintf(prBuf, "SCreateSTsk failed\n");
      SPrint(prBuf);
      RETVALUE(RFAILED);
   }

   if (SAttachTTsk (ENTMG, (Inst)0, mgTskId) != ROK)
   {
      sprintf(prBuf, "ENTMG, SAttachTTsk failed\n");
      SPrint(prBuf);
      SDestroySTsk(mgTskId);
      RETVALUE(RFAILED);
   }

   if (SAttachTTsk (ENTSM, (Inst)0, mgTskId) != ROK)
   {
      sprintf(prBuf, "ENTSM, SAttachTTsk failed\n");
      SPrint(prBuf);
      SDestroySTsk(mgTskId);
      RETVALUE(RFAILED);
   }

#ifdef GCP_PERF
    perfTstmps.sndMsgCnt = 0;
    perfTstmps.recvMsgCnt = 0;
    perfTstmps.takeTimeStamp = FALSE;
#endif

#ifdef GCP_PERF_ACC
    perfTstmps.msgCnt = 0;
    perfTstmps.takeTimeStamp = FALSE;
#endif 

#ifdef LEAK_TEST
   if(ROK != mgInitLeakTst())
   {
      SPrint("Hash List Init Failed");
   }
#endif  /* LEAK_TEST */

/*cdw mov this to mgActvInit
#ifdef SSI_WITH_CLI_ENABLED   
   RegisterXosCli();
#endif
*/

   /* shutdown provider layer by default */
   
   rc = hi_init_fun(0);

#ifdef CP_OAM_SUPPORT
g_taskRegComp = TRUE;
#endif

   RETVALUE(ROK);
} /* end of MgcoInit() */
#endif /*CP_OAM_SUPPORT*/