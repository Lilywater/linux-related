/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     smmgexms.c - Layer manager for MGCP - external interface for loose
               coupling
  
     Type:     C source file
  
     Desc:     C code for smMgActvTsk - layer manager activation function for
               MGCP
  
     File:     smmgexms.c
  
     Sid:      smmgexms.c@@/main/6 - Wed Mar 30 07:47:07 2005
  
     Prg:      nct
  
*********************************************************************21*/

/*

  smmgexms.c - external interface for loose coupling in MG->SM direction

Following functions are provided in this file:
         prUnpkMiLprCfgReq    - Unpack configuration request
*/

/*
 *     this software may be combined with the following TRILLIUM
 *     software:
 *
 *     part no.                      description
 *     --------    ----------------------------------------------
 *     1000XXX                      MGCP v 1.1
 */

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timers defines */
#include "cm_hash.h"       /* common hash list defines */
#include "cm_inet.h"       /* common INET defines */
#include "cm_llist.h"      /* common linked list defines */
#include "cm_mblk.h"       /* memory management */
#include "cm_tkns.h"       /* common tokens */
#include "cm_abnf.h"
#include "cm_tpt.h"        /* common transport defines */
#include "hit.h"           /* HI layer */
#include "cm_sdp.h"        /* SDP related constants */
#include "cm_dns.h"         /* common DNS libraru defines */
#ifdef ZG
#include "cm_ftha.h"        /* common FTHA defines */
#include "cm_psfft.h"       /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"             /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#include "mgt.h"           /* MGT defines */

#ifdef    GCP_PROV_SCTP
#include "lsb.h"           /* layer management defines for SCTP */
#endif    /* GCP_PROV_SCTP */

#include "lmg.h"           /* layer management defines for MGCP */
#include "lhi.h"
#include "mg.h"            /* defines and macros for MGCP */
#include "mg_err.h"        /* MG error defines */
#ifdef ZG_ACC_TEST
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#include "zg_acc.h"        /* PSF Acceptance test defines */
#endif /* ZG_ACC_TEST */

#ifdef GCP_ACC_TESTS
#include "mg_acc.h"        /* defines for MGCP acceptance tests */
#include "mg_macro.h"      /* defines for MGT-related macros */
#endif /* GCP_ACC_TESTS */

/* header/extern include files (.x) */
#include "gen.x"           /* general layer typedefs */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_inet.x"       /* common INET */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_abnf.x"
#include "cm_tpt.x"        /* common transport types */
#include "hit.x"           /* HI layer */
#include "cm_sdp.x"        /* SDP related types */
#include "cm_dns.x"         /* common DNS libraru defines */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"             /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#include "mgt.x"           /* MGT types */

#ifdef    GCP_PROV_SCTP
#include "lsb.x"           /* layer management defines for SCTP */
#endif    /* GCP_PROV_SCTP */
#ifdef GCP_PROV_MTP3
#include "cm_ss7.x"          /* layer management typedefs for MGCP */
#endif
#include "lmg.x"           /* layer management typedefs for MGCP */
#include "lhi.x"
#include "mg.x"            /* typedefs for MGCP */
#ifdef ZG_ACC_TEST
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#include "zg_acc.x"        /* PSF Acceptance test typedefs */
#endif /* ZG_ACC_TEST */
#ifdef GCP_ACC_TESTS
#include "l4.x"            /* typedefs for MGCP provider */
#include "mu.x"            /* typedefs for MGCP user */

#include "mg_acc.x"        /* typedefs for MGCP acceptance tests */
#include "mg_act.x"        /* function declarations */
#endif  /* GCP_ACC_TESTS */
#ifdef MEM_DEBUG
#include "mem_dbg.x"
#endif


/* local defines */

/* local typedefs */

/* forward references */

/* public variable declarations */

/* public variable definitions */

/* private variable definitions */

/* public routines */
/*
 *
 *       Fun:    smMgActvTsk - SM task activation for MG->SM
 *
 *       Desc:   calls SmMiLmgXXXCfm/Ind based on post->event
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
         File:   smmgexms.c
 *
 */

#ifdef ANSI
PUBLIC S16 smMgActvTsk
(
Pst      *post,
Buffer   *mBuf
)
#else
PUBLIC S16 smMgActvTsk(post, mBuf)
Pst      *post;
Buffer   *mBuf;
#endif /* ANSI */
{
   TRC3(smMgActvTsk)
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (post == (Pst *)NULLP)
   {
      (Void)mgPutMsg(mBuf);
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   switch (post->event)
   {
#ifdef LCSMMGMILMG
      case EVTLMGSTAIND:             /* Status Indication */
      {
         (Void)cmUnpkLmgStaInd(SmMiLmgStaInd, post, mBuf);
         break;
      }
      case EVTLMGTRCIND:
      {
         (Void)cmUnpkLmgTrcInd(SmMiLmgTrcInd, post, mBuf);
         break;
      }
      case EVTLMGCFGCFM:
      {
         (Void)cmUnpkLmgCfgCfm(SmMiLmgCfgCfm, post, mBuf);
         break;
      }
      case EVTLMGCNTRLCFM:
      {
         (Void)cmUnpkLmgCntrlCfm(SmMiLmgCntrlCfm, post, mBuf);
         break;
      }
      case EVTLMGSTACFM:
      {
         (Void)cmUnpkLmgStaCfm(SmMiLmgStaCfm, post, mBuf);
         break;
      }
      case EVTLMGSTSCFM:
      {
         (Void)cmUnpkLmgStsCfm(SmMiLmgStsCfm, post, mBuf);
         break;
      }
#endif
      default:
      {
         (Void) mgPutMsg(mBuf);
         break;
      }
   }
   SExitTsk();
   RETVALUE(ROK);
} /* end of smMgActvTsk() */

/********************************************************************30**
  
         End of file:     smmgexms.c@@/main/6 - Wed Mar 30 07:47:07 2005
  
*********************************************************************31*/

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      nct  1.Initial version
1.2          ---      bbk  1. Fixed C++ compilation warnings
/main/3      ---      vj   1. Added support for 1.2 release
/main/4      ---      ra   1. GCP 1.3 release
/main/5      ---      ka   1. Changes for Release v 1.4
/main/6      ---      pk   1. GCP 1.5 release
*********************************************************************91*/
