/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     smmgptmi.c - Layer Management Interface for MGCP
  
     Type:     C source file
  
     Desc:     C code for SmMiLmgXxxReq functions
  
      File:    smmgptmi.c
  
     Sid:      smmgptmi.c@@/main/6 - Wed Mar 30 07:47:26 2005
  
     Prg:      nct
  
*********************************************************************21*/
/*

  smmgptmi.c - Layer Management Interface for MGCP - SmMiLmgXxxReq functions

Following functions are provided in this file:
         prUnpkMiLprCfgReq    - Unpack configuration request
*/
/*
 *     this software may be combined with the following TRILLIUM
 *     software:
 *
 *     part no.                      description
 *     --------    ----------------------------------------------
 *     1000XXX                      MGCP v 1.1
 */

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timers defines */
#include "cm_hash.h"       /* common hash list defines */
#include "cm_inet.h"       /* common INET defines */
#include "cm_llist.h"      /* common linked list defines */
#include "cm_mblk.h"       /* memory management */
#include "cm_tkns.h"       /* common tokens */
#include "cm_abnf.h"
#include "cm_tpt.h"        /* common transport defines */
#include "hit.h"           /* HI layer */
#include "cm_sdp.h"        /* SDP related constants */
#include "cm_dns.h"         /* common DNS libraru defines */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#include "mgt.h"           /* MGT defines */

#ifdef    GCP_PROV_SCTP
#include "lsb.h"           /* layer management defines for SCTP */
#endif    /* GCP_PROV_SCTP */

#include "lmg.h"           /* layer management defines for MGCP */
#include "lhi.h"
#ifdef ZG
#include "cm_ftha.h"        /* common FTHA defines */
#include "cm_psfft.h"       /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"             /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */
#include "mg.h"            /* defines and macros for MGCP */
#include "mg_err.h"        /* MG error defines */
#ifdef GCP_ACC_TESTS
#include "mg_acc.h"        /* defines for MGCP acceptance tests */
#endif /* GCP_ACC_TESTS */
#include "mg_macro.h"      /* defines for MGT-related macros */
#ifdef ZG_ACC_TEST
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#include "zg_acc.h"        /* PSF Acceptance test defines */
#endif /* ZG_ACC_TEST */
#include "smmg_err.h"

/* header/extern include files (.x) */
#include "gen.x"           /* general layer typedefs */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_inet.x"       /* common INET */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_abnf.x"
#include "cm_tpt.x"        /* common transport types */
#include "hit.x"           /* HI layer */
#include "cm_sdp.x"        /* SDP related types */
#include "cm_dns.x"         /* common DNS libraru defines */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"             /* SHT Interface typedef's  */
#endif /* MG_FTHA  || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#include "mgt.x"           /* MGT types */

#ifdef    GCP_PROV_SCTP
#include "lsb.x"           /* layer management defines for SCTP */
#endif    /* GCP_PROV_SCTP */
#ifdef    GCP_PROV_MTP3
#include "cm_ss7.x"
#endif
#include "lmg.x"           /* layer management typedefs for MGCP */
#include "lhi.x"
#include "mg.x"            /* typedefs for MGCP */
#ifdef ZG_ACC_TEST
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#include "zg_acc.x"        /* PSF Acceptance test typedefs */
#endif /* ZG_ACC_TEST */
#ifdef GCP_ACC_TESTS
#include "l4.x"            /* typedefs for MGCP provider */
#include "mu.x"            /* typedefs for MGCP user */

#include "mg_acc.x"        /* typedefs for MGCP acceptance tests */
#include "mg_act.x"        /* Test function declarations */
#include "mg_msg.x"        /* Message function declarations */
#include "dm.x"
#endif /* GCP_ACC_TESTS */


/*local defines */
#define SM_MAX_MG_SEL 4

/*local typedefs */

/*forward references */

PUBLIC S16 PtMiLmgCfgReq      ARGS((Pst *post, MgMngmt *cfg));
PUBLIC S16 PtMiLmgStsReq      ARGS((Pst *post, Action action, MgMngmt *sts));
PUBLIC S16 PtMiLmgStaReq      ARGS((Pst *post, MgMngmt *ssta));
PUBLIC S16 PtMiLmgCntrlReq    ARGS((Pst *post, MgMngmt *cntrl));

/* public variable declarations */

/* public variable definitions */

/* private variable definitions */

/* public routines */

/* Following matrices define the mapping between the primitives called by the
 * layer manager (as SmMiLmgXXXReq) and the corresponding primitives of the 
 * MGCP layer (layer management service provider) (as MgMiLmgXXXReq).
 * Each primitive is mapped to one of SM_MAX_MG_SEL functions in the array.
 * The mapping is based on post->selector.
 * Selector          #define     Coupling      Mgimitive
 * 0 (SEL_LC_NEW)   LCSMMGMILMG  loose         cmPkMiLmgXXXReq
 * 1                 MG          tight         MgMiLmgXXXReq
 * 2+                            tight         PtMiLmgXXXReq
 */

PRIVATE LmgCfgReq smMiLmgCfgReqMt[] =
{
#ifdef LCSMMGMILMG
   cmPkLmgCfgReq,
#else
   PtMiLmgCfgReq,
#endif

#ifdef MG
   MgMiLmgCfgReq,
#else
   PtMiLmgCfgReq,
#endif

#if (defined(GCP_ACC_TESTS) && !defined(GCP_SIMULATION))
   DmMiLmgCfgReq,
#else
   PtMiLmgCfgReq,
#endif

   PtMiLmgCfgReq
};


PRIVATE LmgStsReq smMiLmgStsReqMt[] =
{
#ifdef LCSMMGMILMG
   cmPkLmgStsReq,
#else
   PtMiLmgStsReq,
#endif

#ifdef MG
   MgMiLmgStsReq,
#else
   PtMiLmgStsReq,
#endif

#if (defined(GCP_ACC_TESTS) && !defined(GCP_SIMULATION))
   DmMiLmgStsReq,
#else
   PtMiLmgStsReq,
#endif /* GCP_ACC_TESTS && !GCP_SIMULATION */
   PtMiLmgStsReq
};


PRIVATE LmgStaReq smMiLmgStaReqMt[] =
{
#ifdef LCSMMGMILMG
   cmPkLmgStaReq,
#else
   PtMiLmgStaReq,
#endif

#ifdef MG
   MgMiLmgStaReq,
#else
   PtMiLmgStaReq,
#endif

#if (defined(GCP_ACC_TESTS) && !defined(GCP_SIMULATION))
   DmMiLmgStaReq,
#else
   PtMiLmgStaReq,
#endif

   PtMiLmgStaReq
};


PRIVATE LmgCntrlReq smMiLmgCntrlReqMt[] =
{
#ifdef LCSMMGMILMG
   cmPkLmgCntrlReq,
#else
   PtMiLmgCntrlReq,
#endif

#ifdef MG
   MgMiLmgCntrlReq,
#else
   PtMiLmgCntrlReq,
#endif

#if (defined(GCP_ACC_TESTS) && !defined(GCP_SIMULATION))
   DmMiLmgCntrlReq,
#else
   PtMiLmgCntrlReq,
#endif

   PtMiLmgCntrlReq
};


/*
 *
 *       Fun:    SmMiLmgCfgReq - Configuration request
 *
 *       Desc:  
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
         File:   smmgptmi.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLmgCfgReq
(
Pst     *post,       /* post structure */
MgMngmt *cfg        /* management structure */
)
#else
PUBLIC S16 SmMiLmgCfgReq(post, cfg)
Pst     *post;       /* post structure */
MgMngmt *cfg;       /* management structure */
#endif
{
#ifdef MG_RUG
   U8       protocol;
#endif /* MG_RUG */

   TRC3(SmMiLmgCfgReq)

#ifdef MG_RUG
   MGACC_GET_PROTOCOL(mgAccCb,protocol);
#ifdef GCP_MGCP
   if(MG_ACC_MGCP == protocol)
   {
      cfg->t.cfg.bitVector = LMG_GCP_MGCP_BIT;
   }
#endif /* GCP_MGCP */
#ifdef GCP_MGCO
   if(MG_ACC_MGCO == protocol)
   {
      cfg->t.cfg.bitVector = LMG_GCP_MGCO_BIT;
   }
#endif /* GCP_MGCO */
#endif /* MG_RUG */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (post == (Pst *) NULLP || post->selector >= SM_MAX_MG_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif

   RETVALUE((*(smMiLmgCfgReqMt[post->selector]))(post, cfg));
} /* end of SmMiLmgCfgReq() */

/*
 *
 *       Fun:    SmMiLmgStsReq - Statistics request
 *
 *       Desc:  
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
         File:   smmgptmi.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLmgStsReq
(
Pst     *post,       /* post structure */
Action action,
MgMngmt *sts        /* management structure */
)
#else
PUBLIC S16 SmMiLmgStsReq(post, action, sts)
Pst     *post;       /* post structure */
Action action;
MgMngmt *sts;       /* management structure */
#endif
{
   TRC3(SmMiLmgStsReq)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (post == (Pst *) NULLP || post->selector >= SM_MAX_MG_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif

   RETVALUE((*(smMiLmgStsReqMt[post->selector]))(post, action, sts));
} /* end of SmMiLmgStsReq() */

/*
 *
 *       Fun:    SmMiLmgStaReq - Status request
 *
 *       Desc:  
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
         File:   smmgptmi.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLmgStaReq
(
Pst     *post,       /* post structure */
MgMngmt *ssta        /* management structure */
)
#else
PUBLIC S16 SmMiLmgStaReq(post, ssta)
Pst     *post;       /* post structure */
MgMngmt *ssta;       /* management structure */
#endif
{
   TRC3(SmMiLmgStaReq)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (post == (Pst *) NULLP || post->selector >= SM_MAX_MG_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif

   RETVALUE((*(smMiLmgStaReqMt[post->selector]))(post, ssta));
} /* end of SmMiLmgStaReq() */

/*
 *
 *       Fun:    SmMiLmgCntrlReq - Control request
 *
 *       Desc:  
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
         File:   smmgptmi.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLmgCntrlReq
(
Pst     *post,       /* post structure */
MgMngmt *cntrl        /* management structure */
)
#else
PUBLIC S16 SmMiLmgCntrlReq(post, cntrl)
Pst     *post;       /* post structure */
MgMngmt *cntrl;       /* management structure */
#endif
{
   TRC3(SmMiLmgCntrlReq)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (post == (Pst *) NULLP || post->selector >= SM_MAX_MG_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif

   RETVALUE((*(smMiLmgCntrlReqMt[post->selector]))(post, cntrl));
} /* end of SmMiLmgCntrlReq() */

/*
 *
 *       Fun:    PtMiLmgCfgReq - portable configuration request
 *
 *       Desc:  
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
         File:   smmgptmi.c
 *
 */

#ifdef ANSI
PUBLIC S16 PtMiLmgCfgReq
(
Pst     *post,       /* post structure */
MgMngmt *cfg        /* management structure */
)
#else
PUBLIC S16 PtMiLmgCfgReq(post, cfg)
Pst     *post;       /* post structure */
MgMngmt *cfg;       /* management structure */
#endif
{
   TRC3(PtMiLmgCfgReq)
#if (ERRCLASS & ERRCLS_DEBUG)
   SMMGLOGERROR(post, ERRCLS_DEBUG, ESMMG001, ERRZERO, 
      "Improper selector for SmMiLmgCfgReq");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   UNUSED(post);
   UNUSED(cfg);
   RETVALUE(RFAILED);
} /* end of PtMiLmgCfgReq() */

/*
 *
 *       Fun:    PtMiLmgStsReq - portable statistics request
 *
 *       Desc:  
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
         File:   smmgptmi.c
 *
 */

#ifdef ANSI
PUBLIC S16 PtMiLmgStsReq
(
Pst     *post,       /* post structure */
Action action,
MgMngmt *sts        /* management structure */
)
#else
PUBLIC S16 PtMiLmgStsReq(post, action, sts)
Pst     *post;       /* post structure */
Action action;
MgMngmt *sts;       /* management structure */
#endif
{
   TRC3(PtMiLmgStsReq)
#if (ERRCLASS & ERRCLS_DEBUG)
   SMMGLOGERROR(post, ERRCLS_DEBUG, ESMMG002, ERRZERO, 
      "Improper selector for SmMiLmgStsReq");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   UNUSED(post);
   UNUSED(action);
   UNUSED(sts);
   RETVALUE(RFAILED);
} /* end of PtMiLmgStsReq() */

/*
 *
 *       Fun:    PtMiLmgStaReq - portable status request
 *
 *       Desc:  
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
         File:   smmgptmi.c
 *
 */

#ifdef ANSI
PUBLIC S16 PtMiLmgStaReq
(
Pst     *post,       /* post structure */
MgMngmt *ssta        /* management structure */
)
#else
PUBLIC S16 PtMiLmgStaReq(post, ssta)
Pst     *post;       /* post structure */
MgMngmt *ssta;       /* management structure */
#endif
{
   TRC3(PtMiLmgStaReq)
#if (ERRCLASS & ERRCLS_DEBUG)
   SMMGLOGERROR(post, ERRCLS_DEBUG, ESMMG003, ERRZERO, 
      "Improper selector for SmMiLmgStaReq");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   UNUSED(post);
   UNUSED(ssta);
   RETVALUE(RFAILED);
} /* end of PtMiLmgStaReq() */

/*
 *
 *       Fun:    PtMiLmgCntrlReq - portable control request
 *
 *       Desc:  
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
         File:   smmgptmi.c
 *
 */

#ifdef ANSI
PUBLIC S16 PtMiLmgCntrlReq
(
Pst     *post,       /* post structure */
MgMngmt *cntrl        /* management structure */
)
#else
PUBLIC S16 PtMiLmgCntrlReq(post, cntrl)
Pst     *post;       /* post structure */
MgMngmt *cntrl;       /* management structure */
#endif
{
   TRC3(PtMiLmgCntrlReq)
#if (ERRCLASS & ERRCLS_DEBUG)
   SMMGLOGERROR(post, ERRCLS_DEBUG, ESMMG004, ERRZERO, 
      "Improper selector for SmMiLmgCntrlReq");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   UNUSED(post);
   UNUSED(cntrl);
   RETVALUE(RFAILED);
} /* end of PtMiLmgCntrlReq() */

/********************************************************************30**
  
         End of file:     smmgptmi.c@@/main/6 - Wed Mar 30 07:47:26 2005
  
*********************************************************************31*/

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      nct  1.Initial version
1.2          ---      bbk  1. Fixed C++ compilation warnings
/main/3      ---      vj   1. Added support for release 1.2
/main/4      ---      ra   1. GCP 1.3 release
/main/5      ---      ka   1. Changes for Release v 1.4
/main/6      ---      pk   1. GCP 1.5 release
*********************************************************************91*/
