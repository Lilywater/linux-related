/* header include files (.h) */
#include "envopt.h"        /* Environment options */  
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */

#include "gen.h"           /* General layer */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common Timer Library */
#include "cm_hash.h"       /* Hash library */
#include "cm_llist.h"      /* Doubly Linked List library */
#include "cm_inet.h"       /* Common Sockets Library */
#include "cm_tpt.h"        /* Common Transport Defines */
#include "cm_tkns.h"       /* Common Tokens Defines */
#include "cm_sdp.h"        /* Session Description Protocol Defines */
#include "cm_mblk.h"       /* Common Memory Manager Defines */
#include "cm_abnf.h"       /* Common ABNF  Defines */
#include "cm_dns.h"        /* common DNS library */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include "cm_ss7.h"      /* SS7 common Defines */
#include "snt.h"         /* MTP3 Interface Defines */
#endif   /* GCP_PROV_MTP3 */

#include "mgt.h"           /* MGT Interface Defines */
#include "lmg.h"           /* MGCP Layer Management */
#include "mg_err.h"        /* MGCP Error Codes */
#include "mg.h"            /* MGCP Defines */
#ifdef ZG
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#endif /* ZG */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer */
#include "ssi.x"           /* System services */
#include "cm5.x"           /* Common Timer Library */
#include "cm_hash.x"       /* Hash library */
#include "cm_llist.x"      /* Doubly Linked List library */
#include "cm_inet.x"       /* Common Sockets Library */
#include "cm_tpt.x"        /* Common Transport Definitions */
#include "cm_tkns.x"       /* Common Tokens Defines */
#include "cm_lib.x"        /* Common library functions */
#include "cm_sdp.x"        /* Session Description Protocol Defines */
#include "cm_mblk.x"       /* Common Memory Manager Defines */
#include "cm_abnf.x"       /* Common ABNF  Defines */
#include "cm_dns.x"        /* common dns library */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include "cm_ss7.x"      /* SS7 common structure */
#include "snt.x"         /* MTP3 Interface structure */
#endif   /* GCP_PROV_MTP3 */


#include "mgt.x"           /* MGT Interface Structures */
#include "lmg.x"           /* MGCP Layer Management */
#include "mg.x"            /* MGCP Data Structures */
#include "mg_db.x"         /* MGCP ABNF Datbase */
#ifdef ZG
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#endif /* ZG */

#ifdef GCP_MGCO
#include "mgco_db.x"       /* MEGACO ABNF Database */
#endif /* GCP_MGCO */

#ifdef GCP_ASN
#include "mgasnwrp.h"
#endif
#ifdef CP_OAM_SUPPORT
#include "mg_nms.h"
#include "mg_cfg.h"
#include "xosshell.h"
#include "h248_oam.x"
#include "mg_cfg.x"
#include "sm.h"
#include "sm.x"
#include "cp_tab_def.h"
#include "oam_tab_def.h"
#endif

EXTERN void mgResetCfgData(void);/*cdw add by 2006.7.31*/

S16 mg_init_fun(SSTskId mgTskId)
{
   
   /* Register MGCP, TUCL and stack manager, MR, perm tasks */
   if (SRegTTsk((Ent)ENTMG, (Inst)0, (Ttype)TTNORM, PRIOR0,
              mgActvInit, mgActvTsk ) != ROK)
   {
      SPrint("SRegTTsk() failed for mgActvInit()\n");
      RETVALUE(RFAILED);
   }

   if(mgTskId == 0)
   {
	   /* Create a single thread and attach all task to this normal and perm task on it */
	   if (SCreateSTsk ((SSTskPrior) 13, &mgTskId) != ROK)
	   {
	      SPrint( "SCreateSTsk failed\n");
	      RETVALUE(RFAILED);
	   }
   	}

   if (SAttachTTsk (ENTMG, (Inst)0, mgTskId) != ROK)
   {
      SPrint("ENTMG, SAttachTTsk failed\n");
      SDestroySTsk(mgTskId);
      RETVALUE(RFAILED);
   }

/*cdw add by 2006.7.13*/
#ifdef CP_OAM_SUPPORT


   if( ROK != smRegCb((Ent)ENTMG, gMgSmQ, sizeof(gMgSmQ)/sizeof(CmLListCp), smMgSendReqQ, mgResetCfgData))
   {
      RETVALUE(RFAILED);
   }

	if( OAM_CALL_SUCC != register_msg_proc(CP_MODULE_ID_VOIP_H248,  APP_SYNC_MSG,  mgNmSyncCallback, NULL))
	{
      RETVALUE(RFAILED);
   } 
   (unsigned char)get_resource(xwCpH248MGCSrvrCfg, sizeof(MgMGCSrvrCfgTab), xwCpH248MGCSrvrCfg_ROW_NUM);
   (unsigned char)get_resource(xwCpH248MGCPeerEntCfgTable, sizeof(MgMGCPeerEntCfgTab), xwCpH248MGCPeerEntCfgTable_ROW_NUM);
   (unsigned char)get_resource(xwCpH248MGSrvrCfg, sizeof(MgMGSrvrCfgTab), xwCpH248MGSrvrCfg_ROW_NUM);
   (unsigned char)get_resource(xwCpH248MGPeerEntCfgTable, sizeof(MgMGPeerEntCfgTab), xwCpH248MGPeerEntCfgTable_ROW_NUM);
   (unsigned char)get_resource(xwCpComIpTable, sizeof(CP_OAM_COM_IP_TAB), xwCpComIpTable_ROW_NUM);

   if( OAM_CALL_SUCC != app_register(CP_MODULE_ID_VOIP_H248, &mgCfgTbl[0], sizeof(mgCfgTbl)/sizeof(mgCfgTbl[0])))
   {
      RETVALUE(RFAILED);
   }
#endif

   return ROK;
}

S16 mgInitCfgData()
{
#ifdef CP_OAM_SUPPORT
   if( ROK != smRegCb((Ent)ENTMG, gMgSmQ, sizeof(gMgSmQ)/sizeof(CmLListCp), smMgSendReqQ, mgResetCfgData))
   {
      RETVALUE(RFAILED);
   }

	if( OAM_CALL_SUCC != register_msg_proc(CP_MODULE_ID_VOIP_H248,  APP_SYNC_MSG,  mgNmSyncCallback, NULL))
	{
      RETVALUE(RFAILED);
   } 
#ifdef GCP_MGC
   (unsigned char)get_resource(xwCpH248MGCSrvrCfg, sizeof(MgMGCSrvrCfgTab), xwCpH248MGCSrvrCfg_ROW_NUM);
   (unsigned char)get_resource(xwCpH248MGCPeerEntCfgTable, sizeof(MgMGCPeerEntCfgTab), xwCpH248MGCPeerEntCfgTable_ROW_NUM);
#else
   (unsigned char)get_resource(xwCpH248MGSrvrCfg, sizeof(MgMGSrvrCfgTab), xwCpH248MGSrvrCfg_ROW_NUM);
   (unsigned char)get_resource(xwCpH248MGPeerEntCfgTable, sizeof(MgMGPeerEntCfgTab), xwCpH248MGPeerEntCfgTable_ROW_NUM);
#endif
	(unsigned char)get_resource(xwCpComIpTable, sizeof(CP_OAM_COM_IP_TAB), xwCpComIpTable_ROW_NUM);

   if(OAM_CALL_SUCC != app_register(CP_MODULE_ID_VOIP_H248, &mgCfgTbl[0], sizeof(mgCfgTbl)/sizeof(mgCfgTbl[0])))
   {
      RETVALUE(RFAILED); 
   }
#endif

}


void mgBndHiReq(void)
{
	
}

