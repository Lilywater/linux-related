/**********************************************************************

         (c) COPYRIGHT 1989-2003 by 
         Beijing Xinwei Telecom Technology co., ltd. ShenZhen R&D center
         All rights reserved.

     
**********************************************************************/

/**********************************************************************

     Name:     mg_cfg.h 

     Type:     C include file

     Desc:     Defines MACO 

     Create :  2006-04-27 chendh
     

**********************************************************************/
#ifndef MG_CFG_H
#define MG_CFG_H

#ifndef ACTVINST
#define ACTVINST 0
#endif

#define MG_APPINST0             0
#define MG_APPINST1             1
#define MG_APPINST2             2
#define MG_APPINST3             3

#define    MACHINEMG1_MID       "<mid1.xinwei.com>"
#define MU_LC                   0
#define MU_TC                   1

#define MG_SRC_INSTANCE0		0
#define MG_DST_INSTANCE0		0

#define MU_SPID0				0
#define MG_HI_SIPID				2
#define MU_SUID0				0

#define MGCO_MAX_SSAP           2
#define MGCO_MAX_TSAP           3
#define MGCO_MAX_SERVER         10
#define MGCO_MAX_CONN           10
#define MGCO_MAX_TXN            2000
#define MGCO_MAX_PEER           20
#define MGCO_RES_UPPER          5
#define MGCO_RES_LOWER          3
#define MGCO_TIME_RES           10
#define MGCO_NUM_BLKS           3
#define MGCO_MAX_BLK_SIZE       2048
#define MGCO_NUM_BINS_TXNID_HL  149
#define MGCO_NUM_BINS_NAME_HL   149
#define MGCO_NUM_BINS_TPT_SRVR_HL    149
#define MGCO_INDICATE_RETX      TRUE
#define MGCO_RES_ORDER          LMG_RES_IPV4
#define MGCO_RSP_ACK_ENB        0x10
#define MG_MY_MID_CFG           "<mid1.ccpu.com>"
#define MG_MY_DOMAIN_NAME_CFG   "changdawei.szxinwei.com.cn"   
#define MG_MYADDR_IP_CFG        0xa80002be
#define MG_DNS_IP_CFG           0x23000002

/*--------------------------------------------------------*/
/*MGCO ���ñ���Χ1 ~ 20*/

#define SM_MGMGCENTCFG_TBL      1
#define SM_MGMGCSRVRCFG_TBL     2
#define SM_MGMGENTCFG_TBL       3
#define SM_MGMGSRVRCFG_TBL      4




/*----------------------------------------------------------*/

#define NMS_CTYPE_LEN16  16
#define NMS_CTYPE_LEN32  32
#define NMS_CTYPE_LEN64  64

#ifdef __cplusplus
extern "C" {
#endif

#ifdef MG_MOCK_START
EXTERN S16 MgcoAppInit(U32 megacoUaModId);
#endif /*MG_MOCK_START*/

#ifdef __cplusplus
}
#endif

extern unsigned int mgCfgTbl[3];
extern PUBLIC S16 MgcoInit();

#endif /*MG_CFG_H*/