/**********************************************************************

    Name:   si_nms.h 

    Type:   C include file

    Desc:   

    File:   si_nms.h

    Sid:    

    Created by: 

**********************************************************************/


#ifndef _SI_NMS_H_
#define _SI_NMS_H_


#ifdef __cplusplus
extern "C" {
#endif
/*--------------------------------------------------------*/

/*--------------------------------------------------------*/
extern void TestPrintGen();
extern void TestPrintNwAttr();
extern int  siTestPrint();
//extern S16  siRecvInitCfg(unsigned short msgtype, tb_record* prow);
extern void siInitCfgData();
//extern S16  siCfgMsg();
//extern S16  smSendCfgReq();
//extern unsigned char siNmSyncCallback(unsigned short msgtype, unsigned int sepuense, unsigned char pack_end, tb_record* prow);

#ifdef __cplusplus
}
#endif



#endif

