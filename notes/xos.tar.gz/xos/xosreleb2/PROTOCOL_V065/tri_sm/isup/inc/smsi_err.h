/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     stack manager - interface with isup - error
  
     Type:     C include file
  
     Desc:     Error defines required by the stack manager.
   
     File:     smsi_err.h
  
     Sid:      smsi_err.h@@/main/9 - Wed Mar 14 15:23:22 2001
  
     Prg:      mc 
  
*********************************************************************21*/

#ifndef __SMSIERRH_
#define __SMSIERRH_


/* defines */
  
/* management interface isup error codes */

#define  ESMSIBASE   (ERRSMSI   + 0)   /* reserved */
#define  ESMSIXXX    (ESMSIBASE + 0)   /* reserved */

#define   ESMSI001      (ERRSMSI +    1)    /*   smsibdy1.c: 230 */
#define   ESMSI002      (ERRSMSI +    2)    /*   smsibdy1.c: 237 */
#define   ESMSI003      (ERRSMSI +    3)    /*   smsibdy1.c: 238 */
#define   ESMSI004      (ERRSMSI +    4)    /*   smsibdy1.c: 239 */
#define   ESMSI005      (ERRSMSI +    5)    /*   smsibdy1.c: 310 */
#define   ESMSI006      (ERRSMSI +    6)    /*   smsibdy1.c: 317 */
#define   ESMSI007      (ERRSMSI +    7)    /*   smsibdy1.c: 318 */
#define   ESMSI008      (ERRSMSI +    8)    /*   smsibdy1.c: 319 */
#define   ESMSI009      (ERRSMSI +    9)    /*   smsibdy1.c: 404 */
#define   ESMSI010      (ERRSMSI +   10)    /*   smsibdy1.c: 411 */
#define   ESMSI011      (ERRSMSI +   11)    /*   smsibdy1.c: 412 */
#define   ESMSI012      (ERRSMSI +   12)    /*   smsibdy1.c: 413 */
#define   ESMSI013      (ERRSMSI +   13)    /*   smsibdy1.c: 490 */
#define   ESMSI014      (ERRSMSI +   14)    /*   smsibdy1.c: 497 */
#define   ESMSI015      (ERRSMSI +   15)    /*   smsibdy1.c: 498 */
#define   ESMSI016      (ERRSMSI +   16)    /*   smsibdy1.c: 499 */

#define   ESMSI017      (ERRSMSI +   17)    /*   smsiexms.c: 252 */

#define   ESMSI018      (ERRSMSI +   18)    /*   smsiptmi.c: 415 */
#define   ESMSI019      (ERRSMSI +   19)    /*   smsiptmi.c: 450 */
#define   ESMSI020      (ERRSMSI +   20)    /*   smsiptmi.c: 487 */
#define   ESMSI021      (ERRSMSI +   21)    /*   smsiptmi.c: 521 */

#endif /* __SMSIERRH__*/


/********************************************************************30**

         End of file:     smsi_err.h@@/main/9 - Wed Mar 14 15:23:22 2001

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      bn   1. initial release.

1.2          ---      bn   1. added error codes.

1.3          ---      bn   1. changed error codes.

1.4          ---      pc   1. added error codes for ETSI variant

1.5          ---      dm   1. added error codes for GT_FTZ variant

1.6          ---      rh   1. modified copyright header

1.7          ---      rh   1. Generated new ERR codes .
1.8          ---      ym   1. Copyright header is updated.
/main/9      ---      hy   1. Copyright header and error codes are 
                              updated for 2.19 release.
*********************************************************************91*/
