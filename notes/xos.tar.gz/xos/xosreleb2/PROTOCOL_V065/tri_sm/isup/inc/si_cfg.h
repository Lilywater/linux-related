/**********************************************************************

    Name:   si_cfg.h - Configuration for the ISUP

    Type:   C include file

    Desc:   #define and macros for the ISUP layer Configuration

    File:   si_cfg.h

    Sid:    si_cfg.h - 2003/05/14

    Created by: 

**********************************************************************/
#ifndef _SI_CFG_H_
#define _SI_CFG_H_

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_llist.h"
#include "lsi.h"           /* layer management, isup */
#ifdef SI_FTHA
#include "sht.h"           /* system agent */
#endif
#include "smsi_err.h"      /* isup - error code */
#ifdef ZI
#include "zi_act.h"        /* zi acceptance test hashdefs */
#include "zi_acc.h"        /* zi accpt hdr file */
#endif /* if ZI is defined */
/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* general SS7 layer */
#include "lsi.x"           /* layer management, isup */
#ifdef SI_FTHA
#include "sht.x"           /* system agent */
#endif
#ifdef ZI
#include "cm5.x"           /* common timer routines */
#include "zi_acc.x"        /* zi accpt hdr file */
#endif

#include "cm_llist.x"
#include "cm_lib.x"


/*---------------------- Local Define ----------------------*/

/*#define SI_INST_0	0	/* map instance 0 */
#define SI_REG		0	/* memory region id */

#ifndef SI_POOL
#define SI_POOL	0	       /* pool value */
#endif
#define SI_SEL_LC	0	/* selector 0 (loosely-coupled) */
#define SI_SEL_TC	2	/* selector 1 (tightly-coupled) */

#ifndef ACTVINST
#define ACTVINST 0
#endif

/* selector definition */
#define SI_UI_SEL_LC 0 /* loosely coupled */
#define SI_UI_SEL_PT 1 /* LOOSELY COUPLED - PORTABLE */
#define SI_UI_SEL_CC 2 /* TIGHTLY COUPLED - CC */
#define SI_UI_SEL_IW 3 /* TIGHTLY COUPLED - ISUP Wrapper */
#define SI_UI_SEL_XOS 4 /* LOOSELY COUPLED - XOS */

#define SI_LI_SEL_LC 0 /* loosely coupled */
#define SI_LI_SEL_PT 1 /* LOOSELY COUPLED - PORTABLE */
#define SI_LI_SEL_L3 2 /* TIGHTLY COUPLED - MTP3 */
#define SI_LI_SEL_IT 3 /* TIGHTLY COUPLED - M3UA */
#define SI_LI_SEL_XOS 4 /* LOOSELY COUPLED - XOS */



/*---------------------ISUP initializing configure----------------------------*/ 

#define ISUP_TBL_NUM   9

/* -----Macro define for isup general configure------ */
#define SS_TICK_CNT     1  /* tick */

#define PCM_MAXNUM_CIR  31

#define SI_NMB_PROFILE  4		/* Max Number of ISUP Saps (UPPER) (U8)*/
#define SI_NMB_SAPS		4		/* Max Number of ISUP Saps (UPPER) (U8)*/
#define SI_NMB_NSAPS	4		/* Max Number of Network Saps (LOWER) (U8)*/
#define SI_NMB_INTF	    10		/* Max Number of interface (U16)*/
#define SI_NMB_CIR		10000	/* Max Number of circuit (U16)*/	
#define SI_NMB_CIRGRP	1000		/* Max Number of circuit group (U16)*/
#define SI_NMB_CALREL	1000		/* Max number of Dpc */
#define SI_NMB_ROUT       5     /* Max Number of routes */
#define SI_NMB_SUBROUT   20     /* Max Number of routes */


#define POOL_TR_UPPER    1     /* upper pool threshold */
#define POOL_TR_LOWER   0     /* lower pool threshold */

/* ----------Macro define for Timer ---------- */
/**--**  General timers configure */
#define ISUP_T18      (15*1000)   /* 15-60s, group blocking sent */
#define ISUP_T19      (5*60*1000) /* 5-15m, initial group blocking sent */
#define ISUP_T20      (15*1000)   /* 5-15s, group unblocking sent */
#define ISUP_T21      (5*60*1000) /* 5-15m, initial group unblocking sent */
#define ISUP_T22      (15*1000)   /* 5-15s, group reset sent */
#define ISUP_T23      (5*60*1000) /* 5-15m, initial group reset sent */
#define ISUP_T28      (10*1000)   /* 10s, circuit group query sent */

/**--**  USAP timers configure */
#define ISUP_T01      (15*1000)        /* 15-60s, Release message sent */
#define ISUP_T02      (3*60*1000)     /* 3m, Suspend message received by controlling exchange */
#define ISUP_T05      (5*60*1000)    /* 5-15m, Initial release message sent */
#define ISUP_T06        (2*60*1000)    /* 2m,Suspend (network) received by controlling exchange */
#define ISUP_T07      (20*1000)        /* 20-30s, Latest address message sent */
#define ISUP_T08      (10*1000)    /* 10-15s, Initial address message received by incoming international exchange*/
#define ISUP_T09        (3*60*1000)     /* 3m, When national controlling or outgoing international exchange receives ACM */
#define ISUP_T27      (4*60*1000)     /* 4m, continuity check failure indication is received */
#define ISUP_T31      (5*60*1000)     /* 5-15m, Release of ISDN User Part signalling connection based on CO SCCP */
#define ISUP_T33      (12*1000)        /* 12-15s, INR  message sent */
#define ISUP_T34      (2*1000)          /* 2-4s, indication of a segmented message is received on an IAM, ACM, CPG, ANM or CON message */
#define ISUP_T36      (10*1000)         /* 10-15s, When transit or incoming international exchange receives continuity check request message */
/* #define ISUP_T41      (5*60*1000)    5-15m, indication of a segmented message is received on an IAM, ACM, CPG, ANM or CON message */

#define ISUP_TRELRSP  (5*1000)    /* 5s, waiting for release response */
#define ISUP_TRELRSPF (1*60*1000) /* 1m, waiting for final release response */

/**--**  NSAP timers */
#define ISUP_TBNDNSAP (10*1000)   /* 10s, NSAP (Bind Confirm) timer */

/**--**  interface timers configure */
#define ISUP_T04        (5*60*1000)   /* 5-15m,At receipt of MTP-STATUS primitive with the cause "remote user unavailable" */

#define ISUP_TPAUSE   (15*1000)   /* 15s, waiting for PAUSE to be effective */
#define ISUP_TSTAENQ  (10*60*1000)/* 10m, status enquiry timer */
/**--**  circuit timers configure */
#define ISUP_T03        (2*60*1000)   /* 2m, Overload message received */
#define ISUP_T12      (15*1000)     /* 15-60s, Blocking message sent */
#define ISUP_T13      (5*60*1000)   /* 5-15m, Initial blocking message sent */
#define ISUP_T14      (15*1000)       /* 15-60s, unblocking message sent */
#define ISUP_T15      (5*60*1000)   /* 5-15m, Initial unblocking  message sent */
#define ISUP_T16      (15*1000)       /* 15-60s, reset  message sent */
#define ISUP_T17      (5*60*1000)   /* 5-15m, Initial reset message sent */

/* Timer resolution */
#define SI_TMR_MS_NUM        100 /* the ms of a timer unit */

/*  General configure */

/* ----------Macro define for Timer end ---------- */
#define SI_CIR_TYPE_BOTHWAY   0          /*  */
#define SI_CIR_TYPE_OUT       1         /*  */
#define SI_CIR_TYPE_IN        2         /*  */

#define SI_CIR_CTRL_EVEN      0         /* ż���ص�· */
#define SI_CIR_CTRL_ODD       1         /* �����ص�· */
#define SI_CIR_CTRL_ALL       2         /*  */
#define SI_CIR_CTRL_NONE      3         /*  */

#define SI_CIR_DEF_CONTREQ CONTCHK_NOTREQ   

/*----------------------ISUP ���ñ���Χ----------------------*/
#define SMSI_START_TBL            3                      /* ISUP��ֵ�ķ�Χ����Сֵ */

#define SMSI_SS7_NET_TAB           (SMSI_START_TBL - 2)   /* general configure table value */
#define SMSI_SS7_OPC_TAB           (SMSI_START_TBL - 1 )   /* general configure table value */

#define SMSI_GENCFG_TBL           (SMSI_START_TBL + 0)   /* general configure table value */
#define SMSI_SAPCFG_TBL           (SMSI_START_TBL + 1)   /* upsap configure table value */
#define SMSI_NSAPCFG_TBL          (SMSI_START_TBL + 2)   /* nsap configure table value */
#define SMSI_INTFCFG_TBL          (SMSI_START_TBL + 3)   /* intf configure table value */
#define SMSI_CIRCFG_TBL           (SMSI_START_TBL + 4)   /* cir configure table value */

/*----------------------------------------------------------*/

extern U32 siCfgTbl[ISUP_TBL_NUM];
/************************************************************************
* Timer value and Flag
*************************************************************************
*/
#define TMR_VAL_MS(ms)       ((ms)/(SI_TMR_MS_NUM))
#define TMR_ENB(tmrVal)      ((tmrVal) ? TRUE : FALSE)

#define TMR_VAL_S(s)       (((s)*1000)/(SI_TMR_MS_NUM))

#define MAX_SLOT_BIT 5
#define BEGIN_PCM_ID  1
#define GET_CIR_ID(PcmId, SlotId) ((((PcmId)-BEGIN_PCM_ID)<< MAX_SLOT_BIT) + (SlotId))

/*-------------------------------------------------------------------------*/

typedef enum SI_CFG_QUEUE_ID
{
        SI_CFG_GEN_QUE,
        SI_CFG_USAP_QUE,
        SI_CFG_NSAP_QUE,
        SI_CFG_INTF_QUE,
        SI_CFG_CIR_QUE,
        SI_CFG_QUE_NUM
}SI_CFG_QUEUE_ID;



typedef struct _SiGenCfgTab
{
	U8     LnkSelOpt;            /*  */
	U16    nmbSaps;              /* Number of ISUP Saps                      */
	U16    nmbNSaps;             /* Number of Network Saps                   */
	U32    nmbCir;               /* Number of circuits                       */
	U16    nmbIntf;              /* Number of interfaces                     */
	U16    nmbCirGrp;            /* Max number of circuit groups             */
	U32    nmbCalRef;            /* Number of Call References                */
}SiGenCfgTab;




typedef struct _SiSapCfgTab
{
    U32        OprType;
    SpId       SapId; 
    U8         nwId;
    U8         profileId;
    U8         autoInfoReq;  
    U8         relLocation;
}SiSapCfgTab;


/* timer val unit is ms */
typedef struct _SiProfileCfgTab
{
    U32        profileId;
    U32        t1;  
    U32        t5;  
    U32        t7;
    U32        t9;
    U32        t2;
    U32        t6;
    U32        t8;
    U32        t27;
    U32        t33;
    U32        tRELRSP;
    U32        tFNLRELRSP;
}SiProfileCfgTab;



typedef struct _SiIntfCfgTab
{
    U32           OprType;
    SiInstId      intfId;        /* Interface id                             */
    SiInstId      nwId;          /* Network Id                               */
    U32           opcIdx;        /* physical originating point code  index of spc table  */
    U32           dpcIdx;        /* physical destination point code  index of spc table  */
    U8            lnkSelOpt;     /* link select option  when LSIV4        */
    U8            trunkType;     /* trunk type*/
    U8            pauseActn;     /* DPC pause action options */
    
}SiIntfCfgTab;




typedef struct _SiSubRouteCfgTab
{
    U32 OprType;
    U32 subRtId;
    U32 intfId;

    U32 CallSrcId;
    U32 SigRuleId;
    U32 CirType;
    U32 CtrlMode;
    U32 CtrlSelMath;
    U32 NonCtrlSelMath;
    U32 ResvPerc;

}SiSubRouteCfgTab;


typedef struct _SiCirGrpCfgTab
{   
    U32 OprType;
	U32 cirGrpId;
    U32 subRtId;
    U32 locPcmId;
    U32 fstTimeSlot;
    Cic fstCIC;
    U32 cirNum;
    U8  conReq;
}SiCirGrpCfgTab;




typedef struct _SiCfgData
{
    /*----------SI config----------*/
    TskInit            CfgInit;
    U32                siGenNum;
    SiGenCfgTab        siGenTab;
    U32                siNSapNum;         /*nsapId ֵ�ļ���ʹ��*/
    U32                siProfileNum;
    SiProfileCfgTab    siProfileTab[SI_NMB_PROFILE]; /* timer table*/
    U32		           siSapNum;
    SiSapCfgTab		   siSapTab[SI_NMB_SAPS];
    U32		           siIntfNum;
    SiIntfCfgTab	   siIntfTab[SI_NMB_INTF];
    U32		           siCirGrpNum;
    SiCirGrpCfgTab     siCirGrpTab[SI_NMB_CIRGRP];
    U32	               siSubRouteNum;
    SiSubRouteCfgTab   siSubRouteTab[SI_NMB_SUBROUT];
}SiCfgData;

#define SM_SI_LAYERNAME "SM_ISUP"
#define SM_SIDBGP(class,arg)   {DBGP(&gSiCfgData.CfgInit, SM_SI_LAYERNAME, class, arg)}

extern CmLListCp gSiSmQ[SI_CFG_QUE_NUM];


/*----------------------------------------------------------------*/
extern SiCfgData gSiCfgData;


/*------------------------ extern function --------------------------*/
#ifdef __cplusplus
extern "C" {
#endif
    /* function add cfg data to List*/
    extern S16 smSiGenCfgList();
    extern S16 smSiSapCfgList();
    extern S16 smSiNSapCfgList();
    extern S16 smSiIntfCfgList();
    extern S16 smSiCirCfgList();
    
    
    extern Void smSiHdrInit(Header *hdr);
    extern U32 smSiGetTransId();
    extern S16 smSiSendReqQ(CmLList *node);
    extern Void smSiPstInit(Pst *smSiPst);
	extern S16 smSiAddIntf(U16 nRec);
	extern S16 smSiModIntf(U16 nRec);
	extern S16 smSiDelIntf(U16 nRec);
	extern S16 smSiAddCir(U16 nIndex);
	extern S16 smSiModCir(U16 nIndex);
	extern S16 smSiDelCir(U16 nIndex);
	extern S16 smSiModSap(U16 nIndex);
    
#ifdef __cplusplus
}
#endif

#endif /* _SI_CFG_H_ */

