/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


  
/********************************************************************20**
  
     Name:     stack manager - interface with isup

     Type:     C source file
  
     Desc:     Sample C source code for the stack manager.
               - isup interface primitives.
               - Functions required for unpacking layer management
                 service provider primitives in loosely coupled systems.

     File:     smsiexms.c
  
     Sid:      smsiexms.c@@/main/13 - Wed Mar 14 15:23:29 2001

     Prg:      mc
  
*********************************************************************21*/
  
  
/*
*     The functions provided in this file correspond to the functions
*     provided in the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*
*/

/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000029     SS7 - ISUP
*
*/
  
  
/* header include files (.h) */
  
#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lsi.h"           /* isup layer management */
#if ZI
#include "lzi.h"           /* ISUP-PS layer management */
#endif 
#if IW
#include "liw.h"           /* PSIF-ISUP layer management */
#endif 
/* si001.220, ADDED: changes for rollup testing */
#ifdef SI_FTHA
#include "sht.h"           /* system agent */
#endif
#include "smsi_err.h"      /* stack management (q.saal)errors */
  
/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* general SS7 layer */
#include "lsi.x"           /* isup layer management */
/* si001.220, ADDED: changes for rollup testing */
#ifdef SI_FTHA
#include "sht.x"           /* system agent */
#endif

  
/* local defines */
  
/* local typedefs */
  
/* local externs */
  
/* forward references */

/* functions in other modules */
#ifdef __cplusplus
EXTERN "C" {
#endif

#ifdef ZI
EXTERN S16 smZiActvTsk      ARGS((Pst *pst, Buffer *mBuf));
#endif

#ifdef IW
EXTERN S16 smIwActvTsk      ARGS((Pst *pst, Buffer *mBuf));
#endif

#ifdef __cplusplus
}
#endif

/* public variable declarations */
  
/* private variable declarations */


/*
*
*       Fun:    activate task
*
*       Desc:   Processes received event from MTP 3
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   smsiexms.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smSiActvTsk
(
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 smSiActvTsk(pst, mBuf)
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{

   TRC3(smSiActvTsk)

   switch(pst->event)
   {
#ifdef LCSMSIMILSI
      case EVTLSISTACFM:             /* Status Confirm */
         cmUnpkLsiStaCfm(SmMiLsiStaCfm, pst, mBuf);
         break;
      case EVTLSISTSCFM:             /* Statistics Confirm */
         cmUnpkLsiStsCfm(SmMiLsiStsCfm, pst, mBuf);
         break;
      case EVTLSISTAIND:             /* Status Indication */
         cmUnpkLsiStaInd(SmMiLsiStaInd, pst, mBuf);
         break;
#if SI_ACNT
      case EVTLSIACNTIND:            /* Accounting Indication */
         cmUnpkLsiAcntInd(SmMiLsiAcntInd, pst, mBuf);
         break;
#endif
      case EVTLSITRCIND:             /* Trace Indication */
         cmUnpkLsiTrcInd(SmMiLsiTrcInd, pst, mBuf);
         break;

#if SMSI_LMINT3
      case EVTLSICFGCFM:             /* Config confirm */
         cmUnpkLsiCfgCfm(SmMiLsiCfgCfm, pst, mBuf);
         break;

      case EVTLSICNTRLCFM:           /* Control confirm */
         cmUnpkLsiCntrlCfm(SmMiLsiCntrlCfm, pst, mBuf);
         break;
#endif /* SMSI_LMINT3 */

#endif

#ifdef IW
#ifdef LCSMIWMILIW
      case LIW_EVTCFGCFM :     
      case LIW_EVTSTACFM : 
      case LIW_EVTSTAIND : 
      case LIW_EVTCNTRLCFM : 
         smIwActvTsk(pst, mBuf);         
         break;
#endif
#endif /* IW */

#ifdef ZI
#ifdef LCSMZIMILZI
      case EVTZIMILZICFGCFM :
      case EVTZIMILZISTACFM :
      case EVTZIMILZICNTRLCFM :
      case EVTZIMILZISTAIND :
#ifdef TDS_CORE2      
      case EVTZIMILZISTSCFM:
      case EVTZIMILZITRCIND:
#endif
          smZiActvTsk(pst, mBuf);
          break;
#endif /* LCSMSZIMILZI */
#endif /* ZI */
/* si001.220, ADDED: changes for rollup acc tesing */
#ifdef SITST
#ifdef CM_FTHA
      case EVTSHTCNTRLCFM:
         /* Process a control confirm */
         cmUnpkMiShtCntrlCfm(ShMiShtCntrlCfm, pst, mBuf);
         break;
#endif /* SI_FTHA */
#endif /* SITST */
      default:
         SPutMsg(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
         SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, 
                 __LINE__, ERRCLS_DEBUG, ESMSI017, ERRZERO, "smSiActvTsk() \
                 failed, invalid event");
#endif /* ERRCLASS */
         break;
   }
   SExitTsk();
   RETVALUE(ROK);
} /* end of smSiActvTsk */

  
/********************************************************************30**
  
         End of file:     smsiexms.c@@/main/13 - Wed Mar 14 15:23:29 2001

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      bn   1. initial release.

1.2          ---      bn   1. added looback ack transmitted and received 
                              counter to sap statistics structure.

1.3          ---      bn   1. miscellaneous changes

1.4          ---      bn   1. changed unpacking of usta structure.
             ---      bn   2. added unpacking of trace indication.
             ---      bn   3. added new events smSiActvTsk.

1.5          ---      bn   1. change prototypes

1.6          ---      aa   1. Added the cm_gen.x under includes and removed 
                              compilation warnings

1.7          ---      bn   1. Moved to new error logging primitive SLogError 
             ---      bn   2. added macros for unpacking functions.
 
1.8          ---      pc   1. added ETSI variant for SI

1.9          ---      dm   1. added GT_FTZ variant for SI
             ---      dm   2. added include cm_ss7.x
1.10         ---      rs   1. moved the accounting procedures under SI_ACNT 
                              flag
1.11         ---      rh   1. text changes
1.12         ---      dvs  1. rev sync  
/main/13     ---      sk   1. Addition for new primitives in core2 for ISUP PSF
          si001.220   nb   1. Addition for rollup testing.
          si042.220   bn   1. put case EVTSHTCNTRLCFM: inside #ifdef CM_FTHA
*********************************************************************91*/
