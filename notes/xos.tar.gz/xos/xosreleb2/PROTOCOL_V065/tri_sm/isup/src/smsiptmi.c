
/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     stack manager - portable sccp
  
     Type:     C source file
  
     Desc:     C source code for the sccp layer management
               service user primitives used in loosely coupled
               systems.
 
     File:     smsiptmi.c
  
     Sid:      smsiptmi.c@@/main/17 - Wed Mar 14 15:23:34 2001
   
     Prg:      fmg
  
*********************************************************************21*/
 

/*
  
Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.
 
The following functions are provided in this file:
 
     SmMiLsiCfgReq      Configure Request
     SmMiLsiStaReq      Status Request
     SmMiLsiStsReq      Statistics Request
     SmMiLsiCntrlReq    Control Request
 
It is assumed that the following functions are provided in the
layer managment service provider file:
 
     SmMiLsiStaInd        Status Indication
     SmMiLsiStaCfm        Status Confirm
     SmMiLsiStsCfm        Statistics Confirm
     SmMiLsiAcntInd       Accounting Indication
 
*/   
  

/*
*     This software may be used with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000029     SS7 - ISUP
*
*/


/* header include files (.h) */
  
#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
 
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lsi.h"           /* layer management, isup */
#include "sit.h"           /* isup layer */
#include "smsi_err.h"      /* stack manager error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* general SS7 layer */
#include "lsi.x"           /* layer management, isup */


/* local defines */
 
#define MAXSIMI         3

/* local typedefs */
  
/* local externs */
  
/* forward references */
PRIVATE S16 PtMiLsiCfgReq   ARGS((Pst *pst, SiMngmt *cfg));
PRIVATE S16 PtMiLsiStaReq   ARGS((Pst *pst, SiMngmt *sta));
PRIVATE S16 PtMiLsiStsReq   ARGS((Pst *pst, Action action, SiMngmt *sts));
PRIVATE S16 PtMiLsiCntrlReq ARGS((Pst *pst, SiMngmt *cntrl));
 
/* functions in other modules */
  
/* public variable declarations */
  
/* private variable declarations */

/*
the following matrices define the mapping between the primitives
called by the layer management interface of ISUP and the corresponding
primitives in ISUP.
 
The parameter MAXSPII defines the maximum number of layer manager entities
on top of ISUP. There is an array of functions per primitive
invoked by ISUP. Every array is MAXSPII long (i.e. there
are as many functions as the number of service users).
 
The dispatching is performed by the configurable variable: selector.
The selector is configured during general configuration.
 
The selectors are:
 
   0 - loosely coupled - new interface, forawrd cabability (#define LCSMSIMILS)
   1 - loosely coupled - old interface, backward cabability no longer supported
   2 - Lsi (#define SI)
 
*/

/* Configuration request primitive */
 
PRIVATE LsiCfgReq SmMiLsiCfgReqMt[MAXSIMI] =
{
#ifdef LCSMSIMILSI
   cmPkLsiCfgReq,          /* 0 - loosely coupled - fc */
#else
   PtMiLsiCfgReq,          /* 0 - tightly coupled, portable */
#endif
   PtMiLsiCfgReq,          /* 1 - tightly coupled, portable */
#ifdef SI
   SiMiLsiCfgReq,          /* 2 - tightly coupled, layer management */
#else
   PtMiLsiCfgReq,          /* 2 - tightly coupled, portable */
#endif
};

/* Statistics request primitive */
 
PRIVATE LsiStsReq SmMiLsiStsReqMt[MAXSIMI] =
{
#ifdef LCSMSIMILSI
   cmPkLsiStsReq,          /* 0 - loosely coupled - fc */
#else
   PtMiLsiStsReq,          /* 0 - tightly coupled, portable */
#endif
   PtMiLsiStsReq,          /* 1 - tightly coupled, portable */
#ifdef SI
   SiMiLsiStsReq,          /* 2 - tightly coupled, layer management */
#else
   PtMiLsiStsReq,          /* 2 - tightly coupled, portable */
#endif
};

/* Status request primitive */
 
PRIVATE LsiStaReq SmMiLsiStaReqMt[MAXSIMI] =
{
#ifdef LCSMSIMILSI
   cmPkLsiStaReq,          /* 0 - loosely coupled - fc */
#else
   PtMiLsiStaReq,          /* 0 - tightly coupled, portable */
#endif
   PtMiLsiStaReq,          /* 1 - tightly coupled, portable */
#ifdef SI
   SiMiLsiStaReq,          /* 2 - tightly coupled, layer management */
#else
   PtMiLsiStaReq,          /* 2 - tightly coupled, portable */
#endif
};

/* Control request primitive */
 
PRIVATE LsiCntrlReq SmMiLsiCntrlReqMt[MAXSIMI] =
{
#ifdef LCSMSIMILSI
   cmPkLsiCntrlReq,          /* 0 - loosely coupled - fc */
#else
   PtMiLsiCntrlReq,          /* 0 - tightly coupled, portable */
#endif
   PtMiLsiCntrlReq,          /* 1 - tightly coupled, portable */
#ifdef SI
   SiMiLsiCntrlReq,          /* 2 - tightly coupled, layer management */
#else
   PtMiLsiCntrlReq,          /* 2 - tightly coupled, portable */
#endif
};

/*
*     layer management interface functions 
*/
 
/*
*
*       Fun:   Configuration request
*
*       Desc:  This function is used to configure ISUP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsiptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsiCfgReq
(
Pst *pst,                 /* post structure */
SiMngmt *cfg              /* configure */
)
#else
PUBLIC S16 SmMiLsiCfgReq(pst, cfg)
Pst *pst;                 /* post structure */   
SiMngmt *cfg;             /* configure */
#endif
{
   TRC3(SmMiLsiCfgReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLsiCfgReqMt[pst->selector])(pst, cfg); 
   RETVALUE(ROK);
} /* end of SmMiLsiCfgReq */

/*
*
*       Fun:   Status request
*
*       Desc:  This function is used to send a status request to ISUP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsiptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsiStaReq
(
Pst *pst,                 /* post structure */
SiMngmt *sta              /* status */
)
#else
PUBLIC S16 SmMiLsiStaReq(pst, sta)
Pst *pst;                 /* post structure */   
SiMngmt *sta;             /* status */
#endif
{
   TRC3(SmMiLsiStaReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLsiStaReqMt[pst->selector])(pst, sta); 
   RETVALUE(ROK);
} /* end of SmMiLsiStaReq */

/*
*
*       Fun:   Statistics request
*
*       Desc:  This function is used to request statistics from ISUP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsiptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsiStsReq
(
Pst *pst,                 /* post structure */
Action action,
SiMngmt *sts              /* statistics */
)
#else
PUBLIC S16 SmMiLsiStsReq(pst, action, sts)
Pst *pst;                 /* post structure */   
Action action;
SiMngmt *sts;             /* statistics */
#endif
{
   TRC3(SmMiLsiStsReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLsiStsReqMt[pst->selector])(pst, action, sts); 
   RETVALUE(ROK);
} /* end of SmMiLsiStsReq */

/*
*
*       Fun:   Control request
*
*       Desc:  This function is used to send control request to ISUP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsiptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsiCntrlReq
(
Pst *pst,                 /* post structure */
SiMngmt *cntrl            /* control */
)
#else
PUBLIC S16 SmMiLsiCntrlReq(pst, cntrl)
Pst *pst;                 /* post structure */   
SiMngmt *cntrl;           /* control */
#endif
{
   TRC3(SmMiLsiCntrlReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLsiCntrlReqMt[pst->selector])(pst, cntrl); 
   RETVALUE(ROK);
} /* end of SmMiLsiCntrlReq */


/*
*
*       Fun:   Portable configure Request ISUP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsiptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLsiCfgReq
(
Pst *pst,                   /* post structure */
SiMngmt *cfg                /* configure */
)
#else
PRIVATE S16 PtMiLsiCfgReq(pst, cfg)
Pst *pst;                   /* post structure */
SiMngmt *cfg;               /* configure */
#endif
{
   TRC3(PtMiLsiCfgReq);
   UNUSED(cfg);
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, 
                 __LINE__, ERRCLS_DEBUG, ESMSI018, ERRZERO, "PtMiLsiCfgReq() \
                 called");
   RETVALUE(ROK);
} /* end of PtMiLsiCfgReq */


/*
*
*       Fun:   Portable status Request ISUP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsiptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLsiStaReq
(
Pst *pst,                   /* post structure */
SiMngmt *sta                /* status */
)
#else
PRIVATE S16 PtMiLsiStaReq(pst, sta)
Pst *pst;                   /* post structure */
SiMngmt *sta;               /* status */
#endif
{
   TRC3(PtMiLsiStaReq);
   UNUSED(sta);
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, 
        __LINE__, ERRCLS_DEBUG, ESMSI019, ERRZERO, "PtMiLsiStaReq() called");
   RETVALUE(ROK);
} /* end of PtMiLsiStaReq */


/*
*
*       Fun:   Portable statistics Request ISUP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsiptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLsiStsReq
(
Pst *pst,                   /* post structure */
Action action,
SiMngmt *sts                /* statistics */
)
#else
PRIVATE S16 PtMiLsiStsReq(pst, action, sts)
Pst *pst;                   /* post structure */
Action action;
SiMngmt *sts;               /* statistics */
#endif
{
   TRC3(PtMiLsiStsReq);
   UNUSED(sts);
   UNUSED(action);
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, 
        __LINE__, ERRCLS_DEBUG, ESMSI020, ERRZERO, "PtMiLsiStaReq() called");
   RETVALUE(ROK);
} /* end of PtMiLsiStsReq */


/*
*
*       Fun:   Portable control Request ISUP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsiptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLsiCntrlReq
(
Pst *pst,                   /* post structure */
SiMngmt *cntrl              /* control */
)
#else
PRIVATE S16 PtMiLsiCntrlReq(pst, cntrl)
Pst *pst;                   /* post structure */
SiMngmt *cntrl;             /* control */
#endif
{
   TRC3(PtMiLsiCntrlReq);
   UNUSED(cntrl);
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, 
        __LINE__, ERRCLS_DEBUG, ESMSI021, ERRZERO, "PtMiLsiCntrlReq() called");
   RETVALUE(ROK);
} /* end of PtMiLsiCntrlReq */


/********************************************************************30**

         End of file:     smsiptmi.c@@/main/17 - Wed Mar 14 15:23:34 2001

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---   bn   1. initial release

1.2          ---   bn   1. corrected packing of Isup SAP configuration req.

1.3          ---   bn   1. corrected packing of NSAP configuration req.
             ---   fmg  2. added ifdef SSINT1 and SSINT2 to packing
             ---   bn   3. added packing of clli in general configuration.

1.4          ---   bn   1. added packing of additional timers in SAP and
                           circuit configuration structures

1.5          ---   bn   1. changed packing of cirId in STICIR to U32 from U16.

1.6          ---   bn   1. removed #include cm2.x

1.7          ---   bn   1. change prototypes

1.8          ---   bn   1. changed nmbCir in siGen to U32.

1.9          ---   bn   1. Moved to new error logging primitive SLogError
             ---   bn   2. added macros for unpacking functions.

1.10         ---   pc   1. added ETSI variant for SI

1.11         ---   dm   1. added GT_FTZ variant for SI
             ---   dm   2. added segmentation
             ---   dm   3. added tCCRt
             ---   dm   4. added include cm_ss7.x

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.12         ---      bn   1. removed SSINT1.
             ---      bn   2. moved packing of opc from general to ISUP SAP 
                              configuration structure.
1.13         ---      rh   1. Changes for PAUSE/RESUME 
1.14         ---      ao   1. added packing of relLocation and passOnFlag 
                              for upper SAP config.
             ---      rs   1. Added STDELROUT case in Cfg packing function
1.14         ---      rs   1. Added packing of dpcCb configuration/control
                              request.
                           2. Moved t4/tPAUSE to dpcCb timers.
                      ym   1. Packing function smPkMiLsiCntrlReq
                              is updated to handle the additional
                              fields in control req for circuit group
                              operations like block/unblock/reset.
                      ym   1. Status field is not properly packed.
1.15         ---      rh   1. remove cm_gen.[xh] dependency. now the file
                              should be compiled with CMFILE_REORG_1 flag
1.16         ---      sk   2. Changed file header                  
/main/17     ---      hy   1. Updated the file header for 2.19 release
*********************************************************************91*/
