/****************************************
**
**	Subsystem	: common platform 
**	File		: si_cfg.c
**	Created	By	:
**	Created	On	: 
**	
**	Purpose: 
**	  This file	contains isup db map to lmi function
**	
**	History:
**	Programmer	Date		 Rev	Description
**	---------------	---------- --------	------------------------------
***************************************/
/*lixinxin         */
#ifdef CP_OAM_SUPPORT
#include "si_cfg.h"
#include "si_nms.h"
#include "cm5.x"
#include "sm.x"
#include "sit.h"

#include "sm.h"
#include "lit.h"           /* layer management M3UA  */




#include "xosshell.h"
#include "si_oam.x"


#include "cp_oam_stru.x"
#include "cp_oam_stru.h"


#include "cp_tab_def.h"


U32   gSiTransId = 0;
CmLListCp gSiSmQ[SI_CFG_QUE_NUM];
SiCfgData gSiCfgData;

U32 siCfgTbl[ISUP_TBL_NUM] = {	APP_TABLE_ID_SS7_NWK,\
								APP_TABLE_ID_SS7_UP,\
								APP_TABLE_ID_SS7_SPC,\
								APP_TABLE_ID_SS7_ISUP_GEN,\
								APP_TABLE_ID_SS7_ISUP_SAP,\
								APP_TABLE_ID_SS7_ISUP_PROFILE,\
								APP_TABLE_ID_SS7_ISUP_INTF,\
								APP_TABLE_ID_SS7_ISUP_SUBROUT,\
								APP_TABLE_ID_SS7_ISUP_CIRGRP\
};

/************************************************************************
* Initialize the LM request header
************************************************************************/
Void smSiHdrInit(Header *hdr) 
{

	TRC2(smSiHdrInit);

	hdr->elmId.elmnt = 0;
	hdr->elmId.elmntInst1 = 0;
	hdr->elmId.elmntInst2 = 0;
	hdr->elmId.elmntInst3 = 0;
	
	hdr->entId.ent = ENTSI;
	hdr->entId.inst = ACTVINST;
	
	hdr->seqNmb = 0;
	hdr->version = 0;
	hdr->msgType = 0;
	hdr->msgLen = sizeof(SiMngmt);
	
#if (SI_LMINT3 || SMSI_LMINT3)	
	hdr->transId = smSiGetTransId();

#ifdef LCSIMILSI
	hdr->response.selector = SI_SEL_LC;	/* LC */
#else
	hdr->response.selector = SI_SEL_TC;	/* TC */
#endif
	hdr->response.mem.region = SI_REG;
	hdr->response.mem.pool = SI_POOL;
	
#ifdef SI_218_COMP	
	hdr->response.route = RTESPEC;
#endif  /* SI_218_COMP */

	hdr->response.prior = PRIOR1;
#endif /* (SI_LMINT3 || SMSI_LMINT3) */
   
	RETVOID;
}

/************************************************************************
* Э������ת��
************************************************************************/
S16 siSwtchTrans(Swtch* DesSwType, Swtch SRcSwType)
{   
    switch(SRcSwType)
    {
    case EN_CP_SW_ANSI88:
        *DesSwType = LSI_SW_ANS88;
        break;
    case EN_CP_SW_ANSI92:
        *DesSwType = LSI_SW_ANS92;
        break;
    case EN_CP_SW_ANSI96:
        *DesSwType = LSI_SW_ANS95;
        break;
    case EN_CP_SW_ITU88:
    case EN_CP_SW_ITU92:
    case EN_CP_SW_ITU96:
        *DesSwType = LSI_SW_ITU;
    	break;
    case EN_CP_SW_CHINA:
        *DesSwType = LSI_SW_CHINA;
    	break;
    
    default:    
        *DesSwType = LSI_SW_CHINA;
    	break;

    }
    RETVALUE(ROK);
}


/************************************************************************
* ��·��������ת��
************************************************************************/
U8 siCirCtrlType(U32 cirType, U32 ctrlMode, U32 Opc, U32 Dpc, Cic cic)
{   
    U8 siCrtlType;
    

    /*˫���·������£����ѡ��ż���أ���OPC>DPCʱ��
      ʹ��ż����·��Ϊ���ص�·                        */
    if (cirType == SI_CIR_TYPE_BOTHWAY)
    {
        switch(ctrlMode) 
        {
        case SI_CIR_CTRL_EVEN:
            if (Opc > Dpc)
            {
                if (cic & OE_ODD)
                {
                    siCrtlType = CONTROLLED;                    
                }
                else
                {
                    siCrtlType = CONTROLLING;
                }
            }
            else
            {          
                if (cic & OE_ODD)
                {
                    siCrtlType = CONTROLLING;                    
                }
                else
                {
                    siCrtlType = CONTROLLED;
                }
            }
            break;
        case SI_CIR_CTRL_ODD:
            if (Opc > Dpc)
            {
                if (cic & OE_ODD)
                {
                    siCrtlType = CONTROLLING;                    
                }
                else
                {
                    siCrtlType = CONTROLLED;
                }
            }
            else
            {          
                if (cic & OE_ODD)
                {
                    siCrtlType = CONTROLLED;                    
                }
                else
                {
                    siCrtlType = CONTROLLING;
                }
            }
            break;
        case SI_CIR_CTRL_ALL:
            siCrtlType = CONTROLLING;    
            break;
        case SI_CIR_CTRL_NONE:
              siCrtlType = CONTROLLED;
            break;
        default:
            break;
        }
      
    }
    else if (cirType == SI_CIR_TYPE_OUT)
    {
        siCrtlType = CONTROLLING; 
    }
    else if (cirType == SI_CIR_TYPE_IN)
    {
        siCrtlType = CONTROLLED;
    }

    return siCrtlType;
   
}

U32 smSiGetUSapId(U8 nwId, SpId *sapId)
{
    U32 k;
   
	for(k = 0; k < gSiCfgData.siSapNum; k++)
	{
	    if (nwId == gSiCfgData.siSapTab[k].nwId)
	    {
	         *sapId = gSiCfgData.siSapTab[k].SapId;
	         RETVALUE(ROK);
	    }
	}

	RETVALUE(RFAILED);

}



/************************************************************************
* General configuration
************************************************************************/
S16 smSiGenCfgList()
{
    CmLList *pNode;
    SiGenCfgTab *siGen;
    SiMngmt *pSiMngmt;
    
    TRC2(smSiGenCfgList);        
    
    
    /* if the sccp general config data do not receive, return failure*/
    if( gSiCfgData.siGenNum != 1)
    {
        RETVALUE(RFAILED);
    }
    
    
    /* get all data for config*/
    siGen = &gSiCfgData.siGenTab;
    
    /* alloc a node for save sm msg info */
    if( ROK != smGetQNode(&pNode, sizeof(SiMngmt)))
    {
         SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "smSiGenCfgList(smGetQNode is failed)\n" )); 
        RETVALUE(RFAILED);
    }

    pSiMngmt = (SiMngmt*)cmLListNode(pNode) ;
    cmMemset((U8 *) pSiMngmt, '\0', sizeof(SiMngmt));
 
    smSiHdrInit(&pSiMngmt->hdr);
    
    pSiMngmt->hdr.msgType = TCFG;                 /* configuration */
    pSiMngmt->hdr.elmId.elmnt = STGEN;            /* general */
    
    pSiMngmt->t.cfg.s.siGen.nmbSaps = siGen->nmbSaps;
    pSiMngmt->t.cfg.s.siGen.nmbNSaps = siGen->nmbNSaps;
    pSiMngmt->t.cfg.s.siGen.nmbCir = siGen->nmbCir;
    pSiMngmt->t.cfg.s.siGen.nmbIntf = siGen->nmbIntf;
    pSiMngmt->t.cfg.s.siGen.nmbCirGrp = siGen->nmbCirGrp;
    pSiMngmt->t.cfg.s.siGen.nmbCalRef = siGen->nmbCalRef;
#ifdef SI_218_COMP   
    pSiMngmt->t.cfg.s.siGen.nmbRouts = SI_NMB_ROUT;
#endif
    
    pSiMngmt->t.cfg.s.siGen.timeRes = SS_TICK_CNT;
    pSiMngmt->t.cfg.s.siGen.sccpSup = FALSE;
    
    pSiMngmt->t.cfg.s.siGen.poolTrUpper = POOL_TR_UPPER;
    pSiMngmt->t.cfg.s.siGen.poolTrLower = POOL_TR_LOWER;
    
#if (LSIV3 || LSIV4)
    pSiMngmt->t.cfg.s.siGen.lnkSelOpt = siGen->LnkSelOpt;            /* link selector option */
#endif  
    
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.t18.val = TMR_VAL_MS(ISUP_T18);
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.t18.enb = TMR_ENB(pSiMngmt->t.cfg.s.siGen.cirGrTmr.t18.val);
    
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.t19.val = TMR_VAL_MS(ISUP_T19);
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.t19.enb = TMR_ENB(pSiMngmt->t.cfg.s.siGen.cirGrTmr.t19.val);
    
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.t20.val = TMR_VAL_MS(ISUP_T20);
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.t20.enb = TMR_ENB(pSiMngmt->t.cfg.s.siGen.cirGrTmr.t20.val);
    
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.t21.val = TMR_VAL_MS(ISUP_T21);
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.t21.enb = TMR_ENB(pSiMngmt->t.cfg.s.siGen.cirGrTmr.t21.val);
    
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.t22.val = TMR_VAL_MS(ISUP_T22);
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.t22.enb = TMR_ENB(pSiMngmt->t.cfg.s.siGen.cirGrTmr.t22.val);
    
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.t23.val = TMR_VAL_MS(ISUP_T23);
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.t23.enb = TMR_ENB(pSiMngmt->t.cfg.s.siGen.cirGrTmr.t23.val);
    
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.t28.val = TMR_VAL_MS(ISUP_T28);
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.t28.enb = TMR_ENB(pSiMngmt->t.cfg.s.siGen.cirGrTmr.t28.val);
    
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.tFGR.val = TMR_VAL_MS(ISUP_TFGR);
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.tFGR.enb = TMR_ENB(pSiMngmt->t.cfg.s.siGen.cirGrTmr.tFGR.val);
#endif
    
#ifdef SI_218_COMP
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.tGRES.val = TMR_VAL_MS(ISUP_TGRES);
    pSiMngmt->t.cfg.s.siGen.cirGrTmr.tGRES.enb = TMR_ENB(pSiMngmt->t.cfg.s.siGen.cirGrTmr.tGRES.val);
#endif
    
    /* set SM post, this post is from SI to SM */
    pSiMngmt->t.cfg.s.siGen.sm.dstProcId = SFndProcId();
    pSiMngmt->t.cfg.s.siGen.sm.srcProcId = SFndProcId();
    pSiMngmt->t.cfg.s.siGen.sm.dstEnt    = ENTSM;
    pSiMngmt->t.cfg.s.siGen.sm.dstInst   = ACTVINST;
    pSiMngmt->t.cfg.s.siGen.sm.srcEnt    = ENTSI;
    pSiMngmt->t.cfg.s.siGen.sm.srcInst   = ACTVINST;
    pSiMngmt->t.cfg.s.siGen.sm.prior     = PRIOR0;
    pSiMngmt->t.cfg.s.siGen.sm.route     = RTESPEC;
    pSiMngmt->t.cfg.s.siGen.sm.event     = EVTNONE;
    pSiMngmt->t.cfg.s.siGen.sm.region    = SI_REG;
    pSiMngmt->t.cfg.s.siGen.sm.pool      = SI_POOL;
    pSiMngmt->t.cfg.s.siGen.sm.selector  = SI_SEL_LC;
    pSiMngmt->t.cfg.s.siGen.sm.intfVer   = LSIIFVER;
    
    /* add to configure list */   
    cmLListAdd2Tail(&gSiSmQ[SI_CFG_GEN_QUE], pNode);
    
    RETVALUE(ROK);
}

U32 smSiGetProfile(U8 profileId, SiProfileCfgTab **pPrfTab)
{
    U32 k;
   
	for(k = 0; k < gSiCfgData.siProfileNum; k++)
	{
	    if (profileId == gSiCfgData.siProfileTab[k].profileId)
	    {
	         *pPrfTab = &gSiCfgData.siProfileTab[k];
	         RETVALUE(ROK);
	    }
	}

	RETVALUE(RFAILED);

}



void smSiSetSapTimer(SiSAPCfg *pSapCfg, U8 profileId)
{
    SiProfileCfgTab *pPrfTab=NULL;

    pSapCfg->tmr.t31.val   = TMR_VAL_MS(ISUP_T31);
	pSapCfg->tmr.t31.enb   = TMR_ENB(pSapCfg->tmr.t31.val);


	pSapCfg->tmr.t34.val   = TMR_VAL_MS(ISUP_T36); /* trillium's wrong */
	pSapCfg->tmr.t34.enb   = TMR_ENB(pSapCfg->tmr.t34.val);

	pSapCfg->tmr.t36.val  = TMR_VAL_MS(ISUP_T34); /* trillium's wrong */
	pSapCfg->tmr.t36.enb  = TMR_ENB(pSapCfg->tmr.t36.val);

    /*
	pSiMngmt->t.cfg.s.siSap.tmr.tCCR.val  = TMR_VAL_MS(ISUP_T41);
	pSiMngmt->t.cfg.s.siSap.tmr.tCCR.enb  = TMR_ENB(pSiMngmt->t.cfg.s.siSap.tmr.tCCR.val);
	*/

    if( 0 == profileId || ROK != smSiGetProfile(profileId, &pPrfTab))
    {

		pSapCfg->tmr.t1.val    = TMR_VAL_MS(ISUP_T01);
		pSapCfg->tmr.t1.enb    = TMR_ENB(pSapCfg->tmr.t1.val);

		pSapCfg->tmr.t5.val    = TMR_VAL_MS(ISUP_T05);
		pSapCfg->tmr.t5.enb    = TMR_ENB(pSapCfg->tmr.t5.val);

		pSapCfg->tmr.t7.val    = TMR_VAL_MS(ISUP_T07);
		pSapCfg->tmr.t7.enb    = TMR_ENB(pSapCfg->tmr.t7.val);


	    pSapCfg->tmr.t9.val    = TMR_VAL_MS(ISUP_T09);
		pSapCfg->tmr.t9.enb    = TMR_ENB(pSapCfg->tmr.t9.val);

		

		pSapCfg->tmr.t2.val    = TMR_VAL_MS(ISUP_T02);
		pSapCfg->tmr.t2.enb    = TMR_ENB(pSapCfg->tmr.t2.val);

		
		pSapCfg->tmr.t6.val    = TMR_VAL_MS(ISUP_T06);
		pSapCfg->tmr.t6.enb    = TMR_ENB(pSapCfg->tmr.t6.val);

		
		pSapCfg->tmr.t8.val    = TMR_VAL_MS(ISUP_T08);
		pSapCfg->tmr.t8.enb    = TMR_ENB(pSapCfg->tmr.t8.val);

		pSapCfg->tmr.t27.val   = TMR_VAL_MS(ISUP_T27);
		pSapCfg->tmr.t27.enb   = TMR_ENB(pSapCfg->tmr.t27.val);

		
	    pSapCfg->tmr.t33.val   = TMR_VAL_MS(ISUP_T33);
		pSapCfg->tmr.t33.enb   = TMR_ENB(pSapCfg->tmr.t33.val);


		pSapCfg->tmr.tRELRSP.val = TMR_VAL_MS(ISUP_TRELRSP);
		pSapCfg->tmr.tRELRSP.enb = TMR_ENB(pSapCfg->tmr.tRELRSP.val);

		pSapCfg->tmr.tFNLRELRSP.val = TMR_VAL_MS(ISUP_TRELRSPF);
		pSapCfg->tmr.tFNLRELRSP.enb = TMR_ENB(pSapCfg->tmr.tFNLRELRSP.val);


    }
    else
    {

        pSapCfg->tmr.t1.val    = TMR_VAL_S(pPrfTab->t1);
		pSapCfg->tmr.t1.enb    = TMR_ENB(pSapCfg->tmr.t1.val);

		pSapCfg->tmr.t5.val    = TMR_VAL_S(pPrfTab->t5);
		pSapCfg->tmr.t5.enb    = TMR_ENB(pSapCfg->tmr.t5.val);

		pSapCfg->tmr.t7.val    = TMR_VAL_S(pPrfTab->t7);
		pSapCfg->tmr.t7.enb    = TMR_ENB(pSapCfg->tmr.t7.val);


	    pSapCfg->tmr.t9.val    = TMR_VAL_S(pPrfTab->t9);
		pSapCfg->tmr.t9.enb    = TMR_ENB(pSapCfg->tmr.t9.val);

		

		pSapCfg->tmr.t2.val    = TMR_VAL_S(pPrfTab->t2);
		pSapCfg->tmr.t2.enb    = TMR_ENB(pSapCfg->tmr.t2.val);

		
		pSapCfg->tmr.t6.val    = TMR_VAL_S(pPrfTab->t6);
		pSapCfg->tmr.t6.enb    = TMR_ENB(pSapCfg->tmr.t6.val);

		
		pSapCfg->tmr.t8.val    = TMR_VAL_S(pPrfTab->t8);
		pSapCfg->tmr.t8.enb    = TMR_ENB(pSapCfg->tmr.t8.val);

		pSapCfg->tmr.t27.val   = TMR_VAL_S(pPrfTab->t27);
		pSapCfg->tmr.t27.enb   = TMR_ENB(pSapCfg->tmr.t27.val);

		
	    pSapCfg->tmr.t33.val   = TMR_VAL_S(pPrfTab->t33);
		pSapCfg->tmr.t33.enb   = TMR_ENB(pSapCfg->tmr.t33.val);


		pSapCfg->tmr.tRELRSP.val = TMR_VAL_S(pPrfTab->tRELRSP);
		pSapCfg->tmr.tRELRSP.enb = TMR_ENB(pSapCfg->tmr.tRELRSP.val);

		pSapCfg->tmr.tFNLRELRSP.val = TMR_VAL_S(pPrfTab->tFNLRELRSP);
		pSapCfg->tmr.tFNLRELRSP.enb = TMR_ENB(pSapCfg->tmr.tFNLRELRSP.val);

    }
	
	


}

/************************************************************************
* Sap configuration
************************************************************************/
S16 smSiSapCfgList()
{
    
    CmLList  *pNode;
    SiMngmt  *pSiMngmt;
    SiSAPCfg *pSapCfg;
    U8 i;
    CP_SS7_NETWORK_TAB *pNwTab;
    
    TRC2(smSiSapCfgList);        

	for(i = 0; i < gSiCfgData.siSapNum; i++)
    {
                
        /* alloc a node for save sm msg info */
        if( ROK != smGetQNode(&pNode, sizeof(SiMngmt)))
        {
            SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "smGetQNode  failed)\n" )); 
            RETVALUE(RFAILED);
        }
        
        pSiMngmt = (SiMngmt*)cmLListNode(pNode) ;
        cmMemset((U8 *) pSiMngmt, '\0', sizeof(SiMngmt));
        
        smSiHdrInit(&pSiMngmt->hdr);
        
        pSiMngmt->hdr.msgType = TCFG;                 /* configuration */
        pSiMngmt->hdr.elmId.elmnt = STISAP;            /* Sap */
        pSiMngmt->hdr.elmId.elmntInst1= gSiCfgData.siSapTab[i].SapId;


        pSapCfg = &pSiMngmt->t.cfg.s.siSap;
        
        
#if (SI_LMINT3 || SMSI_LMINT3)
        pSapCfg->sapId = (SpId) gSiCfgData.siSapTab[i].SapId;
#endif

       if(ROK != CpSs7GetNwTab(gSiCfgData.siSapTab[i].nwId,&pNwTab))
        {
             SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetNwTab si error)\n" )); 
             RETVALUE(RFAILED);
        }
        
       if ( ROK != siSwtchTrans( &pSapCfg->swtch, (Swtch)pNwTab->SwType))
       {
             RETVALUE(RFAILED);
       }
        pSapCfg->ssf           = pNwTab->SubService;       /* network type */
        
        pSapCfg->sidIns        = FALSE;           /* SID insertion Flag */
        pSapCfg->sidVer        = FALSE;           /* SID insertion Flag */
        pSapCfg->sid.length    = 0;               /* SID */
        pSapCfg->natAddrInd    = ADDR_NOTPRSNT;   /* SID Numbering Plan */
        pSapCfg->sidNPlan      = NP_UNK;          /* SID Numbering Plan */
        pSapCfg->sidPresInd    = PI_ALLOW;   
        pSapCfg->incSidPresRes = FALSE;   
        pSapCfg->sidPresRes    = FALSE;   
        pSapCfg->reqOpt        = (gSiCfgData.siSapTab[i].autoInfoReq>0?TRUE:FALSE);   
        pSapCfg->allCallMod    = TRUE;
        pSapCfg->maxLenU2U     = 0xff;
        pSapCfg->passOnFlag    = TRUE;
        pSapCfg->relLocation   = gSiCfgData.siSapTab[i].relLocation;
        pSapCfg->mem.region    = SI_REG;
        pSapCfg->mem.pool      = SI_POOL;
        pSapCfg->prior         = PRIOR0;
        pSapCfg->route         = RTESPEC;
#ifdef LCSIUISIT_XOS
        pSapCfg->selector      = SI_UI_SEL_XOS;
#else
#ifdef LCSIUISIT
        pSapCfg->selector      = SI_UI_SEL_LC;
#else
#ifdef CC
        pSapCfg->selector      = SI_UI_SEL_CC;
#else  
        pSapCfg->selector      = SI_UI_SEL_IW;
#endif //CC
#endif //LCSIUISIT
#endif //LCSIUISIT_XOS
        
        /* set connection timers */
        smSiSetSapTimer(pSapCfg, gSiCfgData.siSapTab[i].profileId);
        

        cmLListAdd2Tail(&gSiSmQ[SI_CFG_USAP_QUE], pNode);
        
    }

    RETVALUE(ROK);      
}


/************************************************************************
* NSap configuration
************************************************************************/
S16 smSiNSapCfgList()
{
    
    CmLList* pNode;
    SiMngmt* pSiMngmt;
    U8 i;

    U8 NwIdindex = 0xff;
    CP_SS7_NETWORK_TAB *pNwTab;
    SiNSAPCfg *psiNSapCfg;
    
    
    TRC2(smSiNSapCfgList); 

    for(i = 0; i < gstCpSs7Global.UPTabNum; i++)
    {
        if(gstCpSs7Global.UPTab[i].Si != EN_CP_SI_ISUP)
        {
             continue;
        }

        if( ROK != CpSs7GetNwTab(gstCpSs7Global.UPTab[i].NwId,&pNwTab))
        {
            SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetNwTab  failed \n" )); 
            RETVALUE(RFAILED);
        }
        
        /* alloc a node for save sm msg info */
        if( ROK != smGetQNode(&pNode, sizeof(SiMngmt)))
        {
             SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "smGetQNode  failed\n" )); 
            RETVALUE(RFAILED);
        }

        pSiMngmt = (SiMngmt*)cmLListNode(pNode) ;
        cmMemset((U8 *) pSiMngmt, '\0', sizeof(SiMngmt));
        smSiHdrInit(&pSiMngmt->hdr);
        pSiMngmt->hdr.msgType = TCFG;                 /* configuration */
        pSiMngmt->hdr.elmId.elmnt = STNSAP;            /* NSAP */
        pSiMngmt->hdr.elmId.elmntInst1 = gSiCfgData.siNSapNum;
        
        psiNSapCfg = &pSiMngmt->t.cfg.s.siNSap;
#if (SI_LMINT3 || SMSI_LMINT3)
        psiNSapCfg->nsapId = gSiCfgData.siNSapNum;
#endif
        
        
        psiNSapCfg->nwId = gstCpSs7Global.UPTab[i].NwId;
        
        psiNSapCfg->spId = gstCpSs7Global.UPTab[i].UpIndex;
        psiNSapCfg->ssf = (U8)pNwTab->SubService;   /* network type */
        
        
        if (pNwTab->BearType == EN_CP_NWKBEAR_M3UA)
        {
            psiNSapCfg->sapType = SAP_M3UA;
        }
        else if (pNwTab->BearType == EN_CP_NWKBEAR_MTP3)
        {
            psiNSapCfg->sapType = SAP_MTP;
        }
        else
        {
            SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "sapType  error \n" )); 
            RETVALUE(RFAILED);
        }
        

        switch(psiNSapCfg->sapType)
        {
        case SAP_MTP:
            psiNSapCfg->dstEnt = ENTSN;
        	break;
        case SAP_M3UA:
            psiNSapCfg->dstEnt = ENTIT;
            
        	break;
        case SAP_SCCP:
            psiNSapCfg->dstEnt = ENTSP;
            break;
        default:
            SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "sapType error \n" )); 
            RETVALUE(RFAILED);
            break;
        }

        psiNSapCfg->mem.region = SI_REG;
        psiNSapCfg->mem.pool = SI_POOL;

        psiNSapCfg->dstInst = ACTVINST;
        psiNSapCfg->dstProcId = SFndProcId();
        psiNSapCfg->prior = PRIOR0;
        psiNSapCfg->route = RTESPEC;
#ifdef LCSILISNT
        psiNSapCfg->selector = SI_LI_SEL_LC;
#else  
#ifdef L3
        psiNSapCfg->selector = SI_LI_SEL_L3; //MTP3
#endif //L3
#ifdef IT
        psiNSapCfg->selector = SI_LI_SEL_IT;
#endif //IT
#ifdef LCSILISNT_XOS
        psiNSapCfg->selector = SI_LI_SEL_XOS;
#endif //LCSILISNT_XOS
#endif //LCSILISNT


        
        cmLListAdd2Tail(&gSiSmQ[SI_CFG_NSAP_QUE], pNode);
        
    }
    RETVALUE(ROK);
}




/************************************************************************
* Interface configuration
************************************************************************/
S16 smSiIntfCfgList()
{
    
    CmLList  *pNode;
    SiMngmt  *pSiMngmt;
    SiIntfCbCfg  *pSiIntfCfg;
    U8 i;
    
    U8 NwIdindex = 0xff;
    U8 index = 0xff;
    Dpc opc=0;
    Dpc phyDpc=0;

    CP_SS7_NETWORK_TAB *pNwTab;
    
    
    TRC2(smSiIntfCfgList); 
 
    for(i = 0; i < gSiCfgData.siIntfNum; i++)
    {
        
        /* alloc a node for save sm msg info */
        if( ROK != smGetQNode(&pNode, sizeof(SiMngmt)))
        {
             SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "smGetQNode si failed)\n" )); 
            RETVALUE(RFAILED);
        }

        if( ROK != CpSs7GetOPC(gSiCfgData.siIntfTab[i].opcIdx, &opc))
        {
            SM_SIDBGP(SIDBGMASK_ERR, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetOPC si failed)\n" )); 
            RETVALUE(RFAILED);
        }
        if( ROK != CpSs7GetDPC(gSiCfgData.siIntfTab[i].dpcIdx, &phyDpc))
        {
            SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetOPC si failed)\n" )); 
            RETVALUE(RFAILED);
        }


        pSiMngmt = (SiMngmt*)cmLListNode(pNode) ;

        cmMemset((U8 *) pSiMngmt, '\0', sizeof(SiMngmt));
        smSiHdrInit(&pSiMngmt->hdr);

        pSiIntfCfg = &pSiMngmt->t.cfg.s.siIntfCb;
        
        pSiMngmt->hdr.msgType     = TCFG;                 /* configuration */
        pSiMngmt->hdr.elmId.elmnt = SI_STINTF;            /* interface */
        pSiIntfCfg->intfId        = (SiInstId)gSiCfgData.siIntfTab[i].intfId;
        pSiIntfCfg->nwId          = (SiInstId)gSiCfgData.siIntfTab[i].nwId;
        pSiIntfCfg->opc           = opc;
        pSiIntfCfg->phyDpc        = phyDpc;
        pSiIntfCfg->pauseActn     = gSiCfgData.siIntfTab[i].pauseActn;   /* default: clear all calls upon rx. PAUSE */


#ifdef LSIV4
        pSiIntfCfg->lnkSelOpt     = gSiCfgData.siIntfTab[i].lnkSelOpt;
#endif

#if (SS7_ANS95 || SS7_ITU97 || SS7_ETSIV3)
        pSiIntfCfg->trunkType     = gSiCfgData.siIntfTab[i].trunkType == 1? TRUE:FALSE;      /* truck type E1(TRUE)/T1(FALSE) at intf   */
#endif
        
        if(ROK != CpSs7GetNwTab(pSiIntfCfg->nwId,&pNwTab))
        {
             SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetNwTab si error)\n" )); 
             RETVALUE(RFAILED);
        }
        
      
        if ( ROK != siSwtchTrans(&pSiIntfCfg->swtch, (Swtch)pNwTab->SwType))
        {
               RETVALUE(RFAILED);
        }
        
        pSiIntfCfg->ssf      = (U8)pNwTab->SubService;


        if( ROK != smSiGetUSapId((U8)pNwTab->NwId, &pSiIntfCfg->sapId))
        {
             SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "smSiGetUSapId error)\n" )); 
             RETVALUE(RFAILED);
        }
        
        
        /* interface relates timers */
        pSiIntfCfg->dpcCbTmr.t4.val = TMR_VAL_MS(ISUP_T04);
        pSiIntfCfg->dpcCbTmr.t4.enb = TMR_ENB(pSiMngmt->t.cfg.s.siIntfCb.dpcCbTmr.t4.val);
        
        pSiIntfCfg->dpcCbTmr.tPAUSE.val = TMR_VAL_MS(ISUP_TPAUSE);
        pSiIntfCfg->dpcCbTmr.tPAUSE.enb = TMR_ENB(pSiMngmt->t.cfg.s.siIntfCb.dpcCbTmr.tPAUSE.val);
        
        pSiIntfCfg->dpcCbTmr.tSTAENQ.val = TMR_VAL_MS(ISUP_TSTAENQ);
        pSiIntfCfg->dpcCbTmr.tSTAENQ.enb = TMR_ENB(pSiMngmt->t.cfg.s.siIntfCb.dpcCbTmr.tSTAENQ.val);

        
        
        cmLListAdd2Tail(&gSiSmQ[SI_CFG_INTF_QUE], pNode);
        
    }
    RETVALUE(ROK);
}


/************************************************************************
* circuit configuration
************************************************************************/
S16 smSiCirCfgList()
{
    
    CmLList* pNode;
    SiMngmt* pSiMngmt;
    U8 i;
    U32 k;
    U8 l;
    
    SiInstId intfId;
    U32 ctrlMode;
    U32 cirType;
    U32  opcIdx;
    U32  dpcIdx;
    U32 Opc;
    U32 Dpc;
    SiCirCfg *pSiCirCfg;

    
    TRC2(smSiCirCfgList); 
    
    
    for(i = 0; i < gSiCfgData.siCirGrpNum; i++)
    {

        if( 0 == gSiCfgData.siCirGrpTab[i].locPcmId)
        {
            SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "locPcmId is 0 \n" )); 
            continue;
        }
        
        for(k = 0; k < gSiCfgData.siSubRouteNum; k++)
        {
            if (gSiCfgData.siSubRouteTab[k].subRtId == gSiCfgData.siCirGrpTab[i].subRtId)
            {
                intfId = gSiCfgData.siSubRouteTab[k].intfId;
                cirType= gSiCfgData.siSubRouteTab[k].CirType;
                ctrlMode = gSiCfgData.siSubRouteTab[k].CtrlMode;
                break;
            }
        }

        for (l = 0; l < gSiCfgData.siIntfNum; l++)
        {
            if (gSiCfgData.siIntfTab[l].intfId == intfId)
            {
                 opcIdx = gSiCfgData.siIntfTab[l].opcIdx;
                 dpcIdx = gSiCfgData.siIntfTab[l].dpcIdx;
                 break;
            }
        }

        if( ROK != CpSs7GetOPC(opcIdx, &Opc))
        {
            SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetOPC  failed\n" )); 
            RETVALUE(RFAILED);
        }
        if( ROK != CpSs7GetDPC(dpcIdx, &Dpc))
        {
            SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetOPC  failed\n" )); 
            RETVALUE(RFAILED);
        }
        
        
        for(k= 0; k < gSiCfgData.siCirGrpTab[i].cirNum; k++)
        {
            /* alloc a node for save sm msg info */
            if( ROK != smGetQNode(&pNode, sizeof(SiMngmt)))
            {
                SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "smGetQNode  failed)\n" )); 
                RETVALUE(RFAILED);
            }
            
            pSiMngmt = (SiMngmt*)cmLListNode(pNode) ;
            cmMemset((U8 *) pSiMngmt, '\0', sizeof(SiMngmt));
            smSiHdrInit(&pSiMngmt->hdr);
            pSiMngmt->hdr.msgType = TCFG;                 /* configuration */
            pSiMngmt->hdr.elmId.elmnt = STICIR;            /* interface */
            
            pSiCirCfg = &pSiMngmt->t.cfg.s.siCir;
            
            pSiCirCfg->cirId     = GET_CIR_ID(gSiCfgData.siCirGrpTab[i].locPcmId, (gSiCfgData.siCirGrpTab[i].fstTimeSlot +k) );
            pSiCirCfg->cic       = (Cic)(gSiCfgData.siCirGrpTab[i].fstCIC + k);
            pSiCirCfg->intfId    = intfId;
            pSiCirCfg->typeCntrl =  siCirCtrlType(cirType,ctrlMode, Opc, Dpc, pSiCirCfg->cic);
            pSiCirCfg->cirFlg    |=  LSI_CIRFLG_CFN_ON;
            pSiCirCfg->contReq    = (gSiCfgData.siCirGrpTab[i].conReq>0? TRUE:FALSE);
            
            
            /* circuit timers */
            pSiCirCfg->cirTmr.t3.val  = TMR_VAL_MS(ISUP_T03);
            pSiCirCfg->cirTmr.t3.enb  = TMR_ENB(pSiCirCfg->cirTmr.t3.val);
            
            pSiCirCfg->cirTmr.t12.val = TMR_VAL_MS(ISUP_T12);
            pSiCirCfg->cirTmr.t12.enb = TMR_ENB(pSiCirCfg->cirTmr.t12.val);
            
            pSiCirCfg->cirTmr.t13.val = TMR_VAL_MS(ISUP_T13);
            pSiCirCfg->cirTmr.t13.enb = TMR_ENB(pSiCirCfg->cirTmr.t13.val);
            
            pSiCirCfg->cirTmr.t14.val = TMR_VAL_MS(ISUP_T14);
            pSiCirCfg->cirTmr.t14.enb = TMR_ENB(pSiCirCfg->cirTmr.t14.val);
            
            pSiCirCfg->cirTmr.t15.val = TMR_VAL_MS(ISUP_T15);
            pSiCirCfg->cirTmr.t15.enb = TMR_ENB(pSiCirCfg->cirTmr.t15.val);
            
            pSiCirCfg->cirTmr.t16.val = TMR_VAL_MS(ISUP_T16);
            pSiCirCfg->cirTmr.t16.enb = TMR_ENB(pSiCirCfg->cirTmr.t16.val);
            
            pSiCirCfg->cirTmr.t17.val = TMR_VAL_MS(ISUP_T17);
            pSiCirCfg->cirTmr.t17.enb = TMR_ENB(pSiCirCfg->cirTmr.t17.val);
            
            
            
            cmLListAdd2Tail(&gSiSmQ[SI_CFG_CIR_QUE], pNode);
        }
        
    }
    RETVALUE(ROK);
}
U32 smSiGetTransId()
{
    return gSiTransId++;
}

/********************************************************************************************************
  Function: smSiSendReqQ
  Description: sccp get msg buffer from sm queue, and send it out
  Calls:
  Called By: 
  Input:   smMsg: msg buffer get from sm queue 
               
  Output:  send LSP message to SP ENTITY

  
  Return:   ROK:success; 
                RFAILED: failure
  Others:
 ********************************************************************************************************/
S16 smSiSendReqQ(CmLList *node)
{
    Pst smSiPst;
    Header *msgHeader;
    S16 ret = ROK;
   
    TRC2(smSiSendReqQ);      
    msgHeader = (Header *)cmLListNode(node);


    smSiPstInit(&smSiPst);
    switch(msgHeader->msgType)
    {
        case TCFG:
            ret = SmMiLsiCfgReq(&smSiPst, (SiMngmt *)cmLListNode(node));
            break;
        case TCNTRL:
            ret = SmMiLsiCntrlReq(&smSiPst, (SiMngmt *)cmLListNode(node));
            break;
        case TSTS:
            ret = SmMiLsiStsReq(&smSiPst, NOZEROSTS, (SiMngmt *)cmLListNode(node));
            break;
        case TSSTA:
            ret = SmMiLsiStaReq(&smSiPst, (SiMngmt *)cmLListNode(node));
            break;
        default:
            RETVALUE(RFAILED);
    }

    RETVALUE(ret);
}

Void smSiPstInit(Pst *smSiPst)
{
	TRC2(smSiPstInit);
	
	cmMemset((U8 *)smSiPst, 0, sizeof(Pst));
	
#ifdef LCSIMILSI
	smSiPst->selector = SI_SEL_LC;
#else
	smSiPst->selector = SI_SEL_TC;
#endif
	
	smSiPst->event     = 0;
	smSiPst->region    = SI_REG;       /* region */
	smSiPst->pool      = SP_POOL;           /* pool */
	smSiPst->prior     = PRIOR1;                  /* priority */
	smSiPst->route     = RTESPEC;                  /* route */
	smSiPst->dstProcId = SFndProcId();   /* destination processor id */
	smSiPst->dstEnt    = ENTSI;             /* dst entity   (always ENTSP) */
	smSiPst->dstInst   = ACTVINST;         /* dst instance (unused) */
	smSiPst->srcProcId = SFndProcId();   /* source processor id */
	smSiPst->srcEnt    = ENTSM;            /* source entity */
	smSiPst->srcInst   = ACTVINST;         /* src instance (unused) */
  
	RETVOID;
	
}



S16 smSiAddIntf(U16 nIndex)
{
    CmLList  *pNode;
    SiMngmt  *pSiMngmt;
    SiIntfCbCfg  *pSiIntfCfg;
    
    Dpc opc = 0;
    Dpc phyDpc = 0;
    
    CP_SS7_NETWORK_TAB *pNwTab;
    
    
    TRC2(smSiAddIntf); 
    
    /* alloc a node for save sm msg info */
    if( ROK != smGetQNode(&pNode, sizeof(SiMngmt)))
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "smGetQNode si failed)\n" )); 
        RETVALUE(RFAILED);
    }
    
    if( ROK != CpSs7GetOPC(gSiCfgData.siIntfTab[nIndex].opcIdx, &opc))
    {
        SM_SIDBGP(SIDBGMASK_ERR, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetOPC si failed)\n" )); 
        RETVALUE(RFAILED);
    }
    if( ROK != CpSs7GetDPC(gSiCfgData.siIntfTab[nIndex].dpcIdx, &phyDpc))
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetDPC si failed)\n" )); 
        RETVALUE(RFAILED);
    }
    
    
    pSiMngmt = (SiMngmt*)cmLListNode(pNode) ;
    
    cmMemset((U8 *) pSiMngmt, '\0', sizeof(SiMngmt));
    smSiHdrInit(&pSiMngmt->hdr);
    
    pSiIntfCfg = &pSiMngmt->t.cfg.s.siIntfCb;
    
    pSiMngmt->hdr.msgType     = TCFG;                 /* configuration */
    pSiMngmt->hdr.elmId.elmnt = SI_STINTF;            /* interface */
    pSiIntfCfg->intfId        = (SiInstId)gSiCfgData.siIntfTab[nIndex].intfId;
    pSiIntfCfg->nwId          = (SiInstId)gSiCfgData.siIntfTab[nIndex].nwId;
    pSiIntfCfg->opc           = opc;
    pSiIntfCfg->phyDpc        = phyDpc;
    pSiIntfCfg->pauseActn     = gSiCfgData.siIntfTab[nIndex].pauseActn;   /* default: clear all calls upon rx. PAUSE */
    
    
#ifdef LSIV4
    pSiIntfCfg->lnkSelOpt     = gSiCfgData.siIntfTab[nIndex].lnkSelOpt;
#endif
    
#if (SS7_ANS95 || SS7_ITU97 || SS7_ETSIV3)
    pSiIntfCfg->trunkType     = gSiCfgData.siIntfTab[nIndex].trunkType == 1? TRUE:FALSE;      /* truck type E1(TRUE)/T1(FALSE) at intf   */
#endif
    
    if(ROK != CpSs7GetNwTab(pSiIntfCfg->nwId,&pNwTab))
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetNwTab si error)\n" )); 
        RETVALUE(RFAILED);
    }
    
    
    if ( ROK != siSwtchTrans(&pSiIntfCfg->swtch, (Swtch)pNwTab->SwType))
    {
        RETVALUE(RFAILED);
    }
    
    pSiIntfCfg->ssf      = (U8)pNwTab->SubService;
    
    
    if( ROK != smSiGetUSapId((U8)pNwTab->NwId, &pSiIntfCfg->sapId))
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "smSiGetUSapId error)\n" )); 
        RETVALUE(RFAILED);
    }
    
    
    /* interface relates timers */
    pSiIntfCfg->dpcCbTmr.t4.val = TMR_VAL_MS(ISUP_T04);
    pSiIntfCfg->dpcCbTmr.t4.enb = TMR_ENB(pSiMngmt->t.cfg.s.siIntfCb.dpcCbTmr.t4.val);
    
    pSiIntfCfg->dpcCbTmr.tPAUSE.val = TMR_VAL_MS(ISUP_TPAUSE);
    pSiIntfCfg->dpcCbTmr.tPAUSE.enb = TMR_ENB(pSiMngmt->t.cfg.s.siIntfCb.dpcCbTmr.tPAUSE.val);
    
    pSiIntfCfg->dpcCbTmr.tSTAENQ.val = TMR_VAL_MS(ISUP_TSTAENQ);
    pSiIntfCfg->dpcCbTmr.tSTAENQ.enb = TMR_ENB(pSiMngmt->t.cfg.s.siIntfCb.dpcCbTmr.tSTAENQ.val);
    
    
    
    cmLListAdd2Tail(&gSiSmQ[SI_CFG_INTF_QUE], pNode);
    
    
    RETVALUE(ROK);
}



S16 smSiModIntf(U16 nIndex)
{
    CmLList  *pNode;
    SiMngmt  *pSiMngmt;
    SiIntfCbCfg  *pSiIntfCfg;
    
    Dpc opc = 0;
    Dpc phyDpc = 0;
    
    CP_SS7_NETWORK_TAB *pNwTab;
    
    TRC2(smSiModIntf);
    
    /* alloc a node for save sm msg info */
    if( ROK != smGetQNode(&pNode, sizeof(SiMngmt)))
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "smGetQNode si failed)\n" )); 
        RETVALUE(RFAILED);
    }
    
    if( ROK != CpSs7GetOPC(gSiCfgData.siIntfTab[nIndex].opcIdx, &opc))
    {
        SM_SIDBGP(SIDBGMASK_ERR, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetOPC si failed)\n" )); 
        RETVALUE(RFAILED);
    }
    if( ROK != CpSs7GetDPC(gSiCfgData.siIntfTab[nIndex].dpcIdx, &phyDpc))
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetOPC si failed)\n" )); 
        RETVALUE(RFAILED);
    }
    
    
    pSiMngmt = (SiMngmt*)cmLListNode(pNode) ;
    
    cmMemset((U8 *) pSiMngmt, '\0', sizeof(SiMngmt));
    smSiHdrInit(&pSiMngmt->hdr);
    
    pSiIntfCfg = &pSiMngmt->t.cfg.s.siIntfCb;
    
    pSiMngmt->hdr.msgType     = TCFG;                 /* configuration */
    pSiMngmt->hdr.elmId.elmnt = SI_STINTF;            /* interface */
    pSiIntfCfg->intfId        = (SiInstId)gSiCfgData.siIntfTab[nIndex].intfId;
    pSiIntfCfg->nwId          = (SiInstId)gSiCfgData.siIntfTab[nIndex].nwId;
    pSiIntfCfg->opc           = opc;
    pSiIntfCfg->phyDpc        = phyDpc;
    pSiIntfCfg->pauseActn    = gSiCfgData.siIntfTab[nIndex].pauseActn;   /* default: clear all calls upon rx. PAUSE */
    
    
#ifdef LSIV4
    pSiIntfCfg->lnkSelOpt     = gSiCfgData.siIntfTab[nIndex].lnkSelOpt;
#endif
    
#if (SS7_ANS95 || SS7_ITU97 || SS7_ETSIV3)
    pSiIntfCfg->trunkType     = gSiCfgData.siIntfTab[nIndex].trunkType == 1? TRUE:FALSE;      /* truck type E1(TRUE)/T1(FALSE) at intf   */
#endif
    
    if(ROK != CpSs7GetNwTab(pSiIntfCfg->nwId,&pNwTab))
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetNwTab si error)\n" )); 
        RETVALUE(RFAILED);
    }
    
    
    if ( ROK != siSwtchTrans(&pSiIntfCfg->swtch, (Swtch)pNwTab->SwType))
    {
        RETVALUE(RFAILED);
    }
    
    pSiIntfCfg->ssf      = (U8)pNwTab->SubService;
    
    
    if( ROK != smSiGetUSapId((U8)pNwTab->NwId, &pSiIntfCfg->sapId))
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "smSiGetUSapId error)\n" )); 
        RETVALUE(RFAILED);
    }
    
    
    /* interface relates timers */
    pSiIntfCfg->dpcCbTmr.t4.val = TMR_VAL_MS(ISUP_T04);
    pSiIntfCfg->dpcCbTmr.t4.enb = TMR_ENB(pSiMngmt->t.cfg.s.siIntfCb.dpcCbTmr.t4.val);
    
    pSiIntfCfg->dpcCbTmr.tPAUSE.val = TMR_VAL_MS(ISUP_TPAUSE);
    pSiIntfCfg->dpcCbTmr.tPAUSE.enb = TMR_ENB(pSiMngmt->t.cfg.s.siIntfCb.dpcCbTmr.tPAUSE.val);
    
    pSiIntfCfg->dpcCbTmr.tSTAENQ.val = TMR_VAL_MS(ISUP_TSTAENQ);
    pSiIntfCfg->dpcCbTmr.tSTAENQ.enb = TMR_ENB(pSiMngmt->t.cfg.s.siIntfCb.dpcCbTmr.tSTAENQ.val);
    
    
    
    cmLListAdd2Tail(&gSiSmQ[SI_CFG_INTF_QUE], pNode);
    
    
    RETVALUE(ROK);
}

S16 smSiDelIntf(U16 nIndex)
{
    CmLList  *pNode;
    SiMngmt  *pSiMngmt;

    TRC2(smSiModIntf);
    
    /* alloc a node for save sm msg info */
    if( ROK != smGetQNode(&pNode, sizeof(SiMngmt)))
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "smGetQNode is failed)\n" )); 
        RETVALUE(RFAILED);
    }
    
    
    pSiMngmt = (SiMngmt*)cmLListNode(pNode) ;
    
    cmMemset((U8 *) pSiMngmt, '\0', sizeof(SiMngmt));
    smSiHdrInit(&pSiMngmt->hdr);
    
    
    pSiMngmt->hdr.msgType     = TCNTRL;               /* contr */
    pSiMngmt->hdr.elmId.elmnt = SI_STINTF;            /* interface */
    pSiMngmt->t.cntrl.action = ADEL;
	pSiMngmt->t.cntrl.subAction = SAELMNT;
#if (SI_LMINT3 || SMSI_LMINT3)
    pSiMngmt->t.cntrl.s.siElmnt.elmntId.intfId = (SiInstId)gSiCfgData.siIntfTab[nIndex].intfId;
#else
    pSiMngmt->t.cntrl.sigpt.intfId = (SiInstId)gSiCfgData.siIntfTab[nIndex].intfId;
#endif
    
    
    cmLListAdd2Tail(&gSiSmQ[SI_CFG_INTF_QUE], pNode);

    /*�����һ���Ƶ�ɾ����λ�ã�������һ*/
    gSiCfgData.siIntfNum--;
    gSiCfgData.siIntfTab[nIndex] = gSiCfgData.siIntfTab[gSiCfgData.siIntfNum];
    
    
    RETVALUE(ROK);
}





S16 smSiAddCir(U16 nIndex)
{
    
    CmLList* pNode;
    SiMngmt* pSiMngmt;
    U32 k;
    U8 l;
    
    SiInstId intfId;
    U32 ctrlMode;
    U32 cirType;
    U32  opcIdx;
    U32  dpcIdx;
    U32 Opc;
    U32 Dpc;
    SiCirCfg *pSiCirCfg;
    
    
    TRC2(smSiCirCfgList); 
    
    if( 0 == gSiCfgData.siCirGrpTab[nIndex].locPcmId)
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "locPcmId is 0 \n" )); 
        RETVALUE(RFAILED);
    }
    
    for(k = 0; k < gSiCfgData.siSubRouteNum; k++)
    {
        if (gSiCfgData.siSubRouteTab[k].subRtId == gSiCfgData.siCirGrpTab[nIndex].subRtId)
        {
            intfId = gSiCfgData.siSubRouteTab[k].intfId;
            cirType= gSiCfgData.siSubRouteTab[k].CirType;
            ctrlMode = gSiCfgData.siSubRouteTab[k].CtrlMode;
            break;
        }
    }
    
    for (l = 0; l < gSiCfgData.siIntfNum; l++)
    {
        if (gSiCfgData.siIntfTab[l].intfId == intfId)
        {
            opcIdx = gSiCfgData.siIntfTab[l].opcIdx;
            dpcIdx = gSiCfgData.siIntfTab[l].dpcIdx;
            break;
        }
    }
    
    if( ROK != CpSs7GetOPC(opcIdx, &Opc))
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetOPC  failed\n" )); 
        RETVALUE(RFAILED);
    }
    if( ROK != CpSs7GetDPC(dpcIdx, &Dpc))
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetOPC  failed\n" )); 
        RETVALUE(RFAILED);
    }
    
    
    for(k= 0; k < gSiCfgData.siCirGrpTab[nIndex].cirNum; k++)
    {
        /* alloc a node for save sm msg info */
        if( ROK != smGetQNode(&pNode, sizeof(SiMngmt)))
        {
            SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "smGetQNode  failed)\n" )); 
            RETVALUE(RFAILED);
        }
        
        pSiMngmt = (SiMngmt*)cmLListNode(pNode) ;
        cmMemset((U8 *) pSiMngmt, '\0', sizeof(SiMngmt));
        smSiHdrInit(&pSiMngmt->hdr);
        pSiMngmt->hdr.msgType = TCFG;                 /* configuration */
        pSiMngmt->hdr.elmId.elmnt = STICIR;            /* interface */
        
        pSiCirCfg = &pSiMngmt->t.cfg.s.siCir;
        
        pSiCirCfg->cirId     = GET_CIR_ID(gSiCfgData.siCirGrpTab[nIndex].locPcmId, (gSiCfgData.siCirGrpTab[nIndex].fstTimeSlot +k) );
        pSiCirCfg->cic       = (Cic)(gSiCfgData.siCirGrpTab[nIndex].fstCIC + k);
        pSiCirCfg->intfId    = intfId;
        pSiCirCfg->typeCntrl =  siCirCtrlType(cirType,ctrlMode, Opc, Dpc, pSiCirCfg->cic);
        pSiCirCfg->cirFlg    |=  LSI_CIRFLG_CFN_ON;
        pSiCirCfg->contReq    = (gSiCfgData.siCirGrpTab[nIndex].conReq>0? TRUE:FALSE);
        
        
        /* circuit timers */
        pSiCirCfg->cirTmr.t3.val  = TMR_VAL_MS(ISUP_T03);
        pSiCirCfg->cirTmr.t3.enb  = TMR_ENB(pSiCirCfg->cirTmr.t3.val);
        
        pSiCirCfg->cirTmr.t12.val = TMR_VAL_MS(ISUP_T12);
        pSiCirCfg->cirTmr.t12.enb = TMR_ENB(pSiCirCfg->cirTmr.t12.val);
        
        pSiCirCfg->cirTmr.t13.val = TMR_VAL_MS(ISUP_T13);
        pSiCirCfg->cirTmr.t13.enb = TMR_ENB(pSiCirCfg->cirTmr.t13.val);
        
        pSiCirCfg->cirTmr.t14.val = TMR_VAL_MS(ISUP_T14);
        pSiCirCfg->cirTmr.t14.enb = TMR_ENB(pSiCirCfg->cirTmr.t14.val);
        
        pSiCirCfg->cirTmr.t15.val = TMR_VAL_MS(ISUP_T15);
        pSiCirCfg->cirTmr.t15.enb = TMR_ENB(pSiCirCfg->cirTmr.t15.val);
        
        pSiCirCfg->cirTmr.t16.val = TMR_VAL_MS(ISUP_T16);
        pSiCirCfg->cirTmr.t16.enb = TMR_ENB(pSiCirCfg->cirTmr.t16.val);
        
        pSiCirCfg->cirTmr.t17.val = TMR_VAL_MS(ISUP_T17);
        pSiCirCfg->cirTmr.t17.enb = TMR_ENB(pSiCirCfg->cirTmr.t17.val);
        
        
        
        cmLListAdd2Tail(&gSiSmQ[SI_CFG_CIR_QUE], pNode);
    }
    
    
    RETVALUE(ROK);
}



S16 smSiModCir(U16 nIndex)
{
    
    CmLList* pNode;
    SiMngmt* pSiMngmt;
    U32 k;
    U8 l;
    
    SiInstId intfId;
    U32 ctrlMode;
    U32 cirType;
    U32  opcIdx;
    U32  dpcIdx;
    U32 Opc;
    U32 Dpc;
    SiCirCfg *pSiCirCfg;
    
    
    TRC2(smSiCirCfgList); 
    
    if( 0 == gSiCfgData.siCirGrpTab[nIndex].locPcmId)
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "locPcmId is 0 \n" )); 
        RETVALUE(RFAILED);
    }
    
    for(k = 0; k < gSiCfgData.siSubRouteNum; k++)
    {
        if (gSiCfgData.siSubRouteTab[k].subRtId == gSiCfgData.siCirGrpTab[nIndex].subRtId)
        {
            intfId = gSiCfgData.siSubRouteTab[k].intfId;
            cirType= gSiCfgData.siSubRouteTab[k].CirType;
            ctrlMode = gSiCfgData.siSubRouteTab[k].CtrlMode;
            break;
        }
    }
    
    for (l = 0; l < gSiCfgData.siIntfNum; l++)
    {
        if (gSiCfgData.siIntfTab[l].intfId == intfId)
        {
            opcIdx = gSiCfgData.siIntfTab[l].opcIdx;
            dpcIdx = gSiCfgData.siIntfTab[l].dpcIdx;
            break;
        }
    }
    
    if( ROK != CpSs7GetOPC(opcIdx, &Opc))
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetOPC  failed\n" )); 
        RETVALUE(RFAILED);
    }
    if( ROK != CpSs7GetDPC(dpcIdx, &Dpc))
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetOPC  failed\n" )); 
        RETVALUE(RFAILED);
    }
    
    
    for(k= 0; k < gSiCfgData.siCirGrpTab[nIndex].cirNum; k++)
    {
        /* alloc a node for save sm msg info */
        if( ROK != smGetQNode(&pNode, sizeof(SiMngmt)))
        {
            SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "smGetQNode  failed)\n" )); 
            RETVALUE(RFAILED);
        }
        
        pSiMngmt = (SiMngmt*)cmLListNode(pNode) ;
        cmMemset((U8 *) pSiMngmt, '\0', sizeof(SiMngmt));
        smSiHdrInit(&pSiMngmt->hdr);
        pSiMngmt->hdr.msgType = TCFG;                 /* configuration */
        pSiMngmt->hdr.elmId.elmnt = STICIR;            /* interface */
        
        pSiCirCfg = &pSiMngmt->t.cfg.s.siCir;
        
        pSiCirCfg->cirId     = GET_CIR_ID(gSiCfgData.siCirGrpTab[nIndex].locPcmId, (gSiCfgData.siCirGrpTab[nIndex].fstTimeSlot +k) );
        pSiCirCfg->cic       = (Cic)(gSiCfgData.siCirGrpTab[nIndex].fstCIC + k);
        pSiCirCfg->intfId    = intfId;
        pSiCirCfg->typeCntrl =  siCirCtrlType(cirType,ctrlMode, Opc, Dpc, pSiCirCfg->cic);
        pSiCirCfg->cirFlg    |=  LSI_CIRFLG_CFN_ON;
        pSiCirCfg->contReq    = (gSiCfgData.siCirGrpTab[nIndex].conReq>0? TRUE:FALSE);
        
        
        /* circuit timers */
        pSiCirCfg->cirTmr.t3.val  = TMR_VAL_MS(ISUP_T03);
        pSiCirCfg->cirTmr.t3.enb  = TMR_ENB(pSiCirCfg->cirTmr.t3.val);
        
        pSiCirCfg->cirTmr.t12.val = TMR_VAL_MS(ISUP_T12);
        pSiCirCfg->cirTmr.t12.enb = TMR_ENB(pSiCirCfg->cirTmr.t12.val);
        
        pSiCirCfg->cirTmr.t13.val = TMR_VAL_MS(ISUP_T13);
        pSiCirCfg->cirTmr.t13.enb = TMR_ENB(pSiCirCfg->cirTmr.t13.val);
        
        pSiCirCfg->cirTmr.t14.val = TMR_VAL_MS(ISUP_T14);
        pSiCirCfg->cirTmr.t14.enb = TMR_ENB(pSiCirCfg->cirTmr.t14.val);
        
        pSiCirCfg->cirTmr.t15.val = TMR_VAL_MS(ISUP_T15);
        pSiCirCfg->cirTmr.t15.enb = TMR_ENB(pSiCirCfg->cirTmr.t15.val);
        
        pSiCirCfg->cirTmr.t16.val = TMR_VAL_MS(ISUP_T16);
        pSiCirCfg->cirTmr.t16.enb = TMR_ENB(pSiCirCfg->cirTmr.t16.val);
        
        pSiCirCfg->cirTmr.t17.val = TMR_VAL_MS(ISUP_T17);
        pSiCirCfg->cirTmr.t17.enb = TMR_ENB(pSiCirCfg->cirTmr.t17.val);
        
        
        
        cmLListAdd2Tail(&gSiSmQ[SI_CFG_CIR_QUE], pNode);
    }
    
    
    RETVALUE(ROK);
}


S16 smSiDelCir(U16 nIndex)
{
    
    CmLList* pNode;
    SiMngmt* pSiMngmt;
    U32 k;

    
    TRC2(smSiCirCfgList); 
    
    
    if( 0 == gSiCfgData.siCirGrpTab[nIndex].locPcmId)
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "locPcmId is 0 \n" )); 
        RETVALUE(RFAILED);
    }

    
    for(k= 0; k < gSiCfgData.siCirGrpTab[nIndex].cirNum; k++)
    {
        /* alloc a node for save sm msg info */
        if( ROK != smGetQNode(&pNode, sizeof(SiMngmt)))
        {
            SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "smGetQNode  failed)\n" )); 
            RETVALUE(RFAILED);
        }
        
        pSiMngmt = (SiMngmt*)cmLListNode(pNode) ;
        cmMemset((U8 *) pSiMngmt, '\0', sizeof(SiMngmt));
        smSiHdrInit(&pSiMngmt->hdr);
        pSiMngmt->hdr.msgType = TCNTRL;                 /* configuration */
        pSiMngmt->hdr.elmId.elmnt = STICIR;            /* interface */
		pSiMngmt->t.cntrl.action = ADEL;
		pSiMngmt->t.cntrl.subAction = SAELMNT;

#if (SI_LMINT3 || SMSI_LMINT3)
        pSiMngmt->t.cntrl.s.siElmnt.elmntId.circuit = GET_CIR_ID(gSiCfgData.siCirGrpTab[nIndex].locPcmId, (gSiCfgData.siCirGrpTab[nIndex].fstTimeSlot +k) );;
        pSiMngmt->t.cntrl.s.siElmnt.elmntParam.cir.flag = LSI_CNTRL_CIR_FORCE;
#else
        pSiMngmt->t.cntrl.sigpt.cirId = GET_CIR_ID(gSiCfgData.siCirGrpTab[nIndex].locPcmId, (gSiCfgData.siCirGrpTab[nIndex].fstTimeSlot +k) );;
        pSiMngmt->hdr.elmId.elmntInst2 = LSI_CNTRL_CIR_FORCE;
#endif
        
        cmLListAdd2Tail(&gSiSmQ[SI_CFG_CIR_QUE], pNode);

    }
    
    /*�����һ���Ƶ�ɾ����λ�ã�������һ*/
    gSiCfgData.siCirGrpNum--;
    gSiCfgData.siCirGrpTab[nIndex] = gSiCfgData.siCirGrpTab[gSiCfgData.siCirGrpNum];
	
    RETVALUE(ROK);
}




S16 smSiModSap(U16 nIndex)
{
    
    CmLList  *pNode;
    SiMngmt  *pSiMngmt;
    SiSAPCfg *pSapCfg;
    U8 i;
    CP_SS7_NETWORK_TAB *pNwTab;
    
    TRC2(smSiSapCfgList);        

         
        /* alloc a node for save sm msg info */
        if( ROK != smGetQNode(&pNode, sizeof(SiMngmt)))
        {
            SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "smGetQNode  failed)\n" )); 
            RETVALUE(RFAILED);
        }
        
        pSiMngmt = (SiMngmt*)cmLListNode(pNode) ;
        cmMemset((U8 *) pSiMngmt, '\0', sizeof(SiMngmt));
        
        smSiHdrInit(&pSiMngmt->hdr);
        
        pSiMngmt->hdr.msgType = TCFG;                 /* configuration */
        pSiMngmt->hdr.elmId.elmnt = STISAP;            /* Sap */
        pSiMngmt->hdr.elmId.elmntInst1 = gSiCfgData.siSapTab[nIndex].SapId;


        pSapCfg = &pSiMngmt->t.cfg.s.siSap;
        
        
#if (SI_LMINT3 || SMSI_LMINT3)
        pSapCfg->sapId = (SpId) gSiCfgData.siSapTab[nIndex].SapId;
#endif

       if(ROK != CpSs7GetNwTab(gSiCfgData.siSapTab[nIndex].nwId,&pNwTab))
        {
             SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "CpSs7GetNwTab si error)\n" )); 
             RETVALUE(RFAILED);
        }
        
       if ( ROK != siSwtchTrans( &pSapCfg->swtch, (Swtch)pNwTab->SwType))
       {
             RETVALUE(RFAILED);
       }
        pSapCfg->ssf           = pNwTab->SubService;       /* network type */
        
        pSapCfg->sidIns        = FALSE;           /* SID insertion Flag */
        pSapCfg->sidVer        = FALSE;           /* SID insertion Flag */
        pSapCfg->sid.length    = 0;               /* SID */
        pSapCfg->natAddrInd    = ADDR_NOTPRSNT;   /* SID Numbering Plan */
        pSapCfg->sidNPlan      = NP_UNK;          /* SID Numbering Plan */
        pSapCfg->sidPresInd    = PI_ALLOW;   
        pSapCfg->incSidPresRes = FALSE;   
        pSapCfg->sidPresRes    = FALSE;   
        pSapCfg->reqOpt        = (gSiCfgData.siSapTab[nIndex].autoInfoReq>0?TRUE:FALSE);   
        pSapCfg->allCallMod    = TRUE;
        pSapCfg->maxLenU2U     = 0xff;
        pSapCfg->passOnFlag    = TRUE;
        pSapCfg->relLocation   = gSiCfgData.siSapTab[nIndex].relLocation;
        pSapCfg->mem.region    = SI_REG;
        pSapCfg->mem.pool      = SI_POOL;
        pSapCfg->prior         = PRIOR0;
        pSapCfg->route         = RTESPEC;
#ifdef LCSIUISIT_XOS
        pSapCfg->selector      = SI_UI_SEL_XOS;
#else
#ifdef LCSIUISIT
        pSapCfg->selector      = SI_UI_SEL_LC;
#else
#ifdef CC
        pSapCfg->selector      = SI_UI_SEL_CC;
#else  
        pSapCfg->selector      = SI_UI_SEL_IW;
#endif //CC
#endif //LCSIUISIT
#endif //LCSIUISIT_XOS
        
        /* set connection timers */
        smSiSetSapTimer(pSapCfg, gSiCfgData.siSapTab[nIndex].profileId);
        

        cmLListAdd2Tail(&gSiSmQ[SI_CFG_USAP_QUE], pNode);
        


    RETVALUE(ROK);      
}

#endif  //endif CP_OAM_SUPPORT
