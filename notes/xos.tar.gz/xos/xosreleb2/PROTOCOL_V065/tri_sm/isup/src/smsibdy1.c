/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


  
/********************************************************************20**
  
     Name:     stack manager - isup - body 1
  
     Type:     C source file
  
     Desc:     Prototype C source code for the Layer Management
               service provider. This file is needed for the 
               ISUP software test sample.

     File:     smsibdy1.c
  
     Sid:      smsibdy1.c@@/main/10 - Wed Mar 14 15:23:25 2001

     Prg:      bn
  
*********************************************************************21*/
  

/*
  
Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.

The following functions are provided in this file for the
layer management service user:
  
     SmMiLsiStaInd      Status Indication
     SmMiLsiStsCfm      Statistics Confirm
     SmMiLsiStaCfm      Status Confirm
     SmMiLsiAcntInd     Accounting Indication
     SmMiLsiTrcInd      Trace Indication

It should be noted that not all of these functions may be required
by a particular layer management service user.

It is assumed that the following functions are provided in the
layer managment service user file:
  
     SmMiLsiCfgReq      Configure Request
     SmMiLsiStaReq      Status Request
     SmMiLsiStsReq      Statistics Request
     SmMiLsiCntrlReq    Control Request
  
*/
  

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lsi.h"           /* layer management, isup */
#ifdef SI_FTHA
#include "sht.h"           /* system agent */
#endif
#include "smsi_err.h"      /* isup - error code */
#ifdef SITST
#include "si_acc.h"        /* zi accpt hdr file */
#endif /* SITST */
#ifdef ZI
#include "zi_act.h"        /* zi acceptance test hashdefs */
#include "zi_acc.h"        /* zi accpt hdr file */
#endif /* if ZI is defined */
/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* general SS7 layer */
#include "lsi.x"           /* layer management, isup */
#ifdef SI_FTHA
#include "sht.x"           /* system agent */
#endif
#ifdef SITST
#include "si_acc.x"        /* zi accpt hdr file */
#endif /* SITST */
#ifdef ZI
#include "cm5.x"           /* common timer routines */
#include "zi_acc.x"        /* zi accpt hdr file */
#endif


/* local defines */

/* local typedefs */
  
/* local externs */
  
/* forward references */
  
/* functions in other modules */
#ifdef SS7_TEST
extern S16 siCcStartCon ARGS ((CirId circuit));
#endif

#ifdef SITST
EXTERN  Queue   siAccLmRxQ;     /* Acceptance Test LM message receive queue */
#endif /* SITST */
/* public variable declarations */

/* private variable declarations */


/*
*     support functions
*/


/*
*     interface functions to layer management service user
*/

#ifdef SMSI_LMINT3


/*
*
*       Fun:   SmMiLsiCfgCfm
*
*       Desc:  Layer management function to process configuration 
*              confirmation primitive received from the ISUP layer
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  smsibdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLsiCfgCfm 
(
Pst *pst,
SiMngmt *cfm
)
#else
PUBLIC S16 SmMiLsiCfgCfm (pst, cfm)
Pst *pst;
SiMngmt *cfm;
#endif
{
#ifdef SITST
   Buffer  *mBuf;
   S16     retval;
#endif

   TRC2(SmMiLsiCfgCfm)
#ifdef SITST

#ifndef LCSMSIMILSI
   pst->event = EVTLSICFGCFM;
#endif
   retval = SGetMsg(pst->region, pst->pool, &mBuf);
   if (retval != ROK)
   {
      SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId, 
                __FILE__, __LINE__, ERRCLS_DEBUG, ESMSI001, 0,
                "SGetMsg failed"); 
      RETVALUE(retval);
   }

   /* pack the following and pass the buffer to the acceptance test
      engine */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ESMSI002, pst);
   CMCHKPKLOG(cmPkHeader,   &cfm->hdr, mBuf, ESMSI003, pst);
   CMCHKPKLOG(cmPkPst,      pst,       mBuf, ESMSI004, pst);

   /* now queue the message */
   SQueueFirst(mBuf, &siAccLmRxQ);

#endif /* SITST */
#ifdef ZI
   zixtopchk(SMMILSICFGCFM, 
       (U8 *) & pst,
       (U8 *) & cfm,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL
    );
 
#endif /* if ZI is defined */
   RETVALUE(ROK);
}/* SmMiLsiCfgCfm */


/*
*
*       Fun:   SmMiLsiCntrlCfm
*
*       Desc:  Layer management function to process control confirm 
*              received from the ISUP layer
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  smsibdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLsiCntrlCfm 
(
Pst *pst,
SiMngmt *cfm
)
#else
PUBLIC S16 SmMiLsiCntrlCfm (pst, cfm)
Pst *pst;
SiMngmt *cfm;
#endif
{
#ifdef SITST
   Buffer  *mBuf;
   S16     retval;
#endif

   TRC2(SmMiLsiCntrlCfm)

#ifdef SITST

#ifndef LCSMSIMILSI
   pst->event = EVTLSICNTRLCFM;
#endif

   retval = SGetMsg(pst->region, pst->pool, &mBuf);
   if (retval != ROK)
   {
      SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId, 
                __FILE__, __LINE__, ERRCLS_DEBUG, ESMSI005, 0,
                "SGetMsg failed"); 
      RETVALUE(retval);
   }

   /* pack the following and pass the buffer to the acceptance test
      engine */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ESMSI006, pst);
   CMCHKPKLOG(cmPkHeader,   &cfm->hdr, mBuf, ESMSI007, pst);
   CMCHKPKLOG(cmPkPst,      pst,       mBuf, ESMSI008, pst);

   /* now queue the message */
   SQueueFirst(mBuf, &siAccLmRxQ);

#endif /* SITST */
#ifdef ZI
   zixtopchk(SMMILSICNTRLCFM ,
       (U8 *) & pst,
       (U8 *) & cfm,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL
    );
#endif /* if ZI is defined */
   RETVALUE(ROK);
}/* SmMiLsiCntrlCfm */


#endif /* SMSI_LMINT3 */


    
/*
*
*       Fun:   Statistics Confirm
*
*       Desc:  This function is used by the ISUP to present
*              solicited statistics information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smsibdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsiStsCfm
(
Pst *pst,              /* post structure */
Action action,         /* action */
SiMngmt *sts           /* confirmed statistics */
)
#else
PUBLIC S16 SmMiLsiStsCfm(pst, action, sts)
Pst *pst;              /* post structure */
Action action;         /* action */
SiMngmt *sts;          /* confirmed statistics */
#endif
{
#ifdef SITST
#if (SI_LMINT3 || SMSI_LMINT3)
   Buffer  *mBuf;
   S16     retval;
#endif
#endif

   TRC2(SmMiLsiStsCfm)

#ifndef ZI
   UNUSED(action);
#endif

#if (SI_LMINT3 || SMSI_LMINT3)

#ifdef SITST

#ifndef LCSMSIMILSI
   pst->event = EVTLSISTSCFM;
#endif

   retval = SGetMsg(pst->region, pst->pool, &mBuf);
   if (retval != ROK)
   {
      SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId, 
                __FILE__, __LINE__, ERRCLS_DEBUG, ESMSI009, 0,
                "SGetMsg failed"); 
      RETVALUE(retval);
   }

   /* pack the following and pass the buffer to the acceptance test
      engine */
   CMCHKPKLOG(cmPkCmStatus, &sts->cfm, mBuf, ESMSI010, pst);
   CMCHKPKLOG(cmPkHeader,   &sts->hdr, mBuf, ESMSI011, pst);
   CMCHKPKLOG(cmPkPst,      pst,       mBuf, ESMSI012, pst);

   /* now queue the message */
   SQueueFirst(mBuf, &siAccLmRxQ);

#endif /* SITST */

#endif
#ifdef ZI
   zixtopchk(SMMILSISTSCFM ,
       (U8 *) & pst ,
       (U8 *) & action ,
       (U8 *) & sts ,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL
    );
#endif /* if ZI is defined */
   RETVALUE(ROK);
} /* end of SmMiLsiStsCfm */

    
/*
*
*       Fun:   Status Confirm
*
*       Desc:  This function is used by the ISUP to present
*              solicited status information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smsibdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsiStaCfm
(
Pst *pst,              /* post structure */
SiMngmt *sta           /* confirmed statistics */
)
#else
PUBLIC S16 SmMiLsiStaCfm(pst, sta)
Pst *pst;              /* post structure */
SiMngmt *sta;          /* confirmed statistics */
#endif
{
#ifdef SITST
#if (SI_LMINT3 || SMSI_LMINT3)
   Buffer  *mBuf;
   S16     retval;
#endif
#endif

   TRC2(SmMiLsiStaCfm)

#ifdef SITST

#if (SI_LMINT3 || SMSI_LMINT3)

#ifndef LCSMSIMILSI
   pst->event = EVTLSISTACFM;
#endif

   retval = SGetMsg(pst->region, pst->pool, &mBuf);
   if (retval != ROK)
   {
      SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId, 
                __FILE__, __LINE__, ERRCLS_DEBUG, ESMSI013, 0,
                "SGetMsg failed"); 
      RETVALUE(retval);
   }

   /* pack the following and pass the buffer to the acceptance test
      engine */
   /* si001.220, ADDED: changes for rollup test */
#ifdef SI_RUG
   CMCHKPKLOG(cmPkIntfVer, sta->t.ssta.cfm.s.siSAPVer.remIntfVer, mBuf, 
              ESMSIXXX, pst);
   CMCHKPKLOG(SPkU8, sta->t.ssta.cfm.s.siSAPVer.remIntfValid, mBuf, 
              ESMSIXXX, pst);
   CMCHKPKLOG(cmPkIntfVer, sta->t.ssta.cfm.s.siSAPVer.selfIntfVer, mBuf, 
              ESMSIXXX, pst);
#endif
   CMCHKPKLOG(cmPkCmStatus, &sta->cfm, mBuf, ESMSI014, pst);
   CMCHKPKLOG(cmPkHeader,   &sta->hdr, mBuf, ESMSI015, pst);
   CMCHKPKLOG(cmPkPst,      pst,       mBuf, ESMSI016, pst);

   /* now queue the message */
   SQueueFirst(mBuf, &siAccLmRxQ);

#endif /* LMINT */
#endif /* SITST */
#ifdef ZI
   zixtopchk(SMMILSISTACFM ,
       (U8 *) & pst ,
       (U8 *) & sta ,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL
    );
#endif /* if ZI is defined */
   RETVALUE(ROK);
} /* end of SmMiLsiStaCfm */

/*
*
*       Fun:   Status Indication
*
*       Desc:  This function is used by the ISUP to present
*              unsolicited status information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smsibdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsiStaInd
(
Pst *pst,              /* post structure */
SiMngmt *sta           /* unsolicited status */
)
#else
PUBLIC S16 SmMiLsiStaInd(pst, sta)
Pst *pst;              /* post structure */
SiMngmt *sta;          /* unsolicited status */
#endif
{
  /* si001.220, ADDED: changes for rollup testing */
#ifdef SITST
#ifdef SI_RUG
   S16 retval;
   Buffer  *mBuf;
#endif
#endif /* SITST */

   TRC2(SmMiLsiStaInd)

#if (SS7_TEST || ZI)
   /* parameters used */
#else
   UNUSED(sta);
#endif
#ifndef LCSMSIMILSI
   pst->event = EVTLSISTAIND;
#endif
#ifdef SS7_TEST
   if (sta->t.usta.evnt == SIMTP_RESUME)
   {
      siCcStartCon(sta->t.usta.circuit);
   }
#endif
   /* si001.220, ADDED: changes for rollup testing */
#ifdef SITST
#ifdef SI_RUG
   retval = SGetMsg(pst->region, pst->pool, &mBuf);
   if (retval != ROK)
   {
      SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                __FILE__, __LINE__, ERRCLS_DEBUG, ESMSI009, 0,
                "SGetMsg failed");
      RETVALUE(retval);
   }

   /* pack the following and pass the buffer to the acceptance test
      engine */
   CMCHKPKLOG(cmPkCmAlarm, &sta->t.usta.alarm, mBuf, ESMSI012, pst); 
   CMCHKPKLOG(cmPkPst,      pst,       mBuf, ESMSI012, pst);
   /* now queue the message */
   SQueueFirst(mBuf, &siAccLmRxQ);
#endif /* SI_RUG */
#endif /* SITST */
#ifdef ZI
   zixtopchk(SMMILSISTAIND ,
       (U8 *) & pst ,
       (U8 *) & sta ,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL
    );
#endif /* if ZI is defined */
   RETVALUE(ROK);
} /* end of SmMiLsiStaInd */

  
/*
*
*       Fun:   Trace Indication
*
*       Desc:  This function is used by the ISUP to present trace
*              information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smsibdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsiTrcInd
(
Pst *pst,              /* post structure */
SiMngmt *trc           /* trace */
)
#else
PUBLIC S16 SmMiLsiTrcInd(pst, trc)
Pst *pst;              /* post structure */
SiMngmt *trc;          /* trace */
#endif
{
   TRC2(SmMiLsiTrcInd)
#ifdef ZI
   zixtopchk(SMMILSITRCIND ,
       (U8 *) & pst ,
       (U8 *) & trc ,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL
    );
#else
   UNUSED(pst);
   UNUSED(trc);
#endif /* if ZI is defined */
   RETVALUE(ROK);
} /* end of SmMiLsiTrcInd */

#if SI_ACNT
/*
*
*       Fun:   Accounting Indication
*
*       Desc:  This function is used by the ISUP to present
*              Accounting information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smsibdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsiAcntInd
(
Pst *pst,              /* post structure */
SiMngmt *acnt          /* unsolicited status */
)
#else
PUBLIC S16 SmMiLsiAcntInd(pst, acnt)
Pst *pst;              /* post structure */
SiMngmt *acnt;         /* unsolicited status */
#endif
{
   TRC2(SmMiLsiAcntInd)
#ifdef ZI
   zixtopchk(SMMILSIACNTIND,
       (U8 *) & pst ,
       (U8 *) & acnt,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL,
       (U8 *) NULL
    );
#endif /* if ZI is defined */
    RETVALUE(ROK);
} /* end of SmMiLsiAcntInd */
#endif

/* si001.220, ADDED: changes for isup rollup testing */
#ifdef SITST
#ifdef SI_RUG
/*
 *
 *      Fun  : Control Request Confirmation
 *
 *      Desc : This function is used to indicate the status of a previous
 *             control request via the system agent interface.
 *
 *      Ret  : ROK      - ok
 *
 *      Notes: None
 *
 *      File :  smsibdy1.c
 *
 */
#ifdef ANSI
PUBLIC S16 ShMiShtCntrlCfm
(
Pst     *shpst,                                   /* post structure       */
ShtCntrlCfmEvnt *cfmInfo                         /* control confirm      */
)
#else
PUBLIC S16 ShMiShtCntrlCfm(shpst, cfmInfo)
Pst     *shpst;                                   /* post structure       */
ShtCntrlCfmEvnt *cfmInfo;                        /* control confirm      */
#endif
{
   S16 ret1;
   Buffer *mBuf;

   TRC3(ShMiShtCntrlCfm)

   if ((cfmInfo->transId != (SIACC_TRANSID1)) ||
       (cfmInfo->status.status != LCM_PRIM_OK))
   {
#if (ERRCLS & ERRCLS_INT_PAR)
      LSILOGERROR(ERRCLS_INT_PAR, (ErrVal)ESMSAXXX, (ErrVal)0, 
                  "ShMiShtCntrlCfm() Failed")
#endif
   }
   if ((cfmInfo->reqType == SHT_REQTYPE_GETVER) ||
       (cfmInfo->reqType == SHT_REQTYPE_SETVER))
   {
      ret1 = SGetMsg(shpst->region, shpst->pool, &mBuf);
      if (ret1 != ROK)
      {
         SLogError(shpst->srcEnt, shpst->srcInst, shpst->srcProcId, __FILE__, 
                   __LINE__, ERRCLS_ADD_RES, ESMXXX, (ErrVal) ret1,
                   "SGetMsg failed");
         RETVALUE(ret1);
      }
      CMCHKPK(cmPkIntf, &cfmInfo->t.gvCfm.pif, mBuf);
#ifdef SI_SPT
      CMCHKPK(cmPkIntf, &cfmInfo->t.gvCfm.lifList[1], mBuf);
#endif
      CMCHKPK(cmPkIntf, &cfmInfo->t.gvCfm.lifList[0], mBuf);
      CMCHKPK(SPkS16, cfmInfo->t.gvCfm.numLif, mBuf);
      CMCHKPK(cmPkIntf, &cfmInfo->t.gvCfm.uifList[0], mBuf);
      CMCHKPK(SPkS16, cfmInfo->t.gvCfm.numUif, mBuf);
      CMCHKPK(SPkU8, cfmInfo->reqType, mBuf);
      CMCHKPK(cmPkCmStatus, &cfmInfo->status, mBuf);
      CMCHKPK(cmPkTranId, cfmInfo->transId, mBuf);
      cmPkPst(shpst, mBuf);
      SQueueLast(mBuf, &siAccLmRxQ);
      RETVALUE(ROK);
   }

   RETVALUE(ROK);
} /* end of ShMiShtCntrlCfm */
#endif /* SI_RUG */
#endif /* SITST */


/*
*
*       Fun:   Activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsibdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smSiActvInit
(
Ent ent,                      /* entity */
Inst inst,                    /* instance */
Region region,                /* region */
Reason reason                 /* reason */
)
#else
PUBLIC S16 smSiActvInit(ent, inst, region, reason)
Ent ent;                      /* entity */
Inst inst;                    /* instance */
Region region;                /* region */
Reason reason;                /* reason */
#endif
{
   TRC3(smSiActvInit)
   
   UNUSED(ent);
   UNUSED(inst);
   UNUSED(region);
   UNUSED(reason);

   RETVALUE(ROK);
} /* end of smSiActvInit */

/********************************************************************30**
  
         End of file:     smsibdy1.c@@/main/10 - Wed Mar 14 15:23:25 2001

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

 
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      bn   1. initial release

1.2          ---      bn   1. Added the SS7_TEST logic

1.3          ---      aa   1. Added the extern declaration of ssCcStartCon 
                              function

1.4          ---      dm   1. Added include cm_ss7.x

1.5          ---      rs   1. Moved accounting procedures under SI_ACNT flag.

1.6          ---      rh   1. modified copyright header

1.7          ---      rs   1. Added changes for acceptance tests
1.7+         ---      ym   1. Compilation errors are corrected. 
1.8          ---      dvs  1. miscellaneous changes
/main/10     ---      sk   1. Extra arguments to zixtopchk
                           2. NT compilation warnings corrected
          si001.220   nb   1. Added changes for rollup acceptance tests.
*********************************************************************91*/
