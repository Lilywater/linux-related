/**********************************************************************

    Name:   si_nms.c 

    Type:   C source file

    Desc:   

    File:   si_nms.c

    Sid:    

    Created by: 

**********************************************************************/
//#include <stdio.h>
//#include <string.h>
//nclude <stdlib.h>

#ifdef CP_OAM_SUPPORT
#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lns.h"           /* NTSS layer mgmt */

#include "ss_err.h"        /* errors */
#include "ss_dep.h"        /* implementation-specific */
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */


#include "cm5.x"

#include "oam_interface.h"
#include "si_nms.h"
#include "si_cfg.h"
#include "sm.h"
#include "sm.x"
#include "xosshell.h"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"
#include "si_oam.x"
#include "cp_tab_def.h"
#include "si_bind.h"
#include "oam_tab_def.h"


//extern S32 g_slot_control ;
extern int getTblRec (int iTbId, int iRecId, char *szBuf);
extern int parseFile() ;

#ifdef CP_OAM_DATA_SHOW
extern S16 siPrintCfgInfo();
#endif

#ifdef STR_TST
extern S16 StrCcCfg();
#endif




void siInitCfgData()
{
    cmMemset((U8 *) &gSiCfgData, '\0', sizeof(SiCfgData));
    
    gSiCfgData.siGenNum = 0;
    gSiCfgData.siSapNum= 0;
    gSiCfgData.siSapNum = 0;
    gSiCfgData.siIntfNum= 0;
    gSiCfgData.siCirGrpNum = 0;
#ifdef DEBUGP
    gSiCfgData.CfgInit.dbgMask = 0xffffffff;
#endif
    return;
}


/*��oam����SM����Ϣ��prow �ж�����*/
S16 smSiRecvCfgFromOam(unsigned short msgtype, tb_record* prow)
{
    CP_OAM_SS7_NETWORK_TAB*  pNetworkTab;
    CP_OAM_SS7_UP_TAB*  pUpTab;
    CP_OAM_SS7_SPC_TAB*  pSpcTab;
    
    SiCfgGenTab*      pSiGenCfg;
    SiCfgSapTab*      pSiSapCfg;
    SiCfgIntfTab*     pSiIntfCfg;
    SiCfgCirGrpTab*   pSiCirCfg;
    SiCfgSubRouteTab* pSubRouteCfg;
	SiCfgProfileTab*  pProfileCfg;
    
    S16  n = 0;
    
    if (prow == NULLP)
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
            "smSiRecvCfgFromOam(prow is NULLP, RETVALUE(RFAILED))\n"));   
        RETVALUE(RFAILED);
    }
    
    while(prow)
    {
        switch(prow->tableid)
        {
        case APP_TABLE_ID_SS7_NWK:
            {
                pNetworkTab = (CP_OAM_SS7_NETWORK_TAB*) prow->panytbrow;
                
                CpSs7SetOneNwkTab(EN_CP_OPR_ADD,  pNetworkTab);
                break;
            }
        case APP_TABLE_ID_SS7_UP:
            {
                pUpTab = (CP_OAM_SS7_UP_TAB*)prow->panytbrow;

                CpSs7SetOneUpTab(EN_CP_OPR_ADD,  pUpTab);
                break;
            }
        case APP_TABLE_ID_SS7_SPC:
            {
                pSpcTab = (CP_OAM_SS7_SPC_TAB*)prow->panytbrow;

                CpSs7SetOneSpcTab(EN_CP_OPR_ADD,  pSpcTab);
                break;
            }
            
            
        case APP_TABLE_ID_SS7_ISUP_GEN:
            pSiGenCfg = (SiCfgGenTab *) prow->panytbrow;
            
            if (gSiCfgData.siGenNum >= 1)
            {
                SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
                    "smSiRecvCfgFromOam(gSiCfgData.siGenNum: %#x >= 1, RETVALUE(RFAILED))\n", (gSiCfgData.siGenNum + 1) )); 
                break;
            }
            else
            {
                gSiCfgData.siGenNum++;
            }
            
            gSiCfgData.siGenTab.LnkSelOpt = pSiGenCfg->LnkSelOpt;
            gSiCfgData.siGenTab.nmbCalRef = pSiGenCfg->nmbCalRef;
            
            gSiCfgData.siGenTab.nmbCirGrp = pSiGenCfg->nmbCirGrp;
            gSiCfgData.siGenTab.nmbCir = pSiGenCfg->nmbCir;
            gSiCfgData.siGenTab.nmbIntf = pSiGenCfg->nmbIntf;
            gSiCfgData.siGenTab.nmbNSaps = pSiGenCfg->nmbNSaps;
            gSiCfgData.siGenTab.nmbSaps = pSiGenCfg->nmbSaps;

            
            
            break;
            
        case APP_TABLE_ID_SS7_ISUP_SAP:
            pSiSapCfg = (SiCfgSapTab *) prow->panytbrow;
            
            
            if (gSiCfgData.siSapNum >= SI_NMB_SAPS)
            {
                SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
                    "smSiRecvCfgFromOam(gSiCfgData.siSapNum: %#x >= SI_NMB_SAPS, RETVALUE(RFAILED))\n", (gSiCfgData.siSapNum + 1) )); 
                break;
            }
            else
            {
                n = gSiCfgData.siSapNum++;
            }   
            
            gSiCfgData.siSapTab[n].SapId       = pSiSapCfg->SapId;
            gSiCfgData.siSapTab[n].nwId        = pSiSapCfg->nwId;
            gSiCfgData.siSapTab[n].profileId   = pSiSapCfg->profileId;
            gSiCfgData.siSapTab[n].autoInfoReq = (U8)pSiSapCfg->autoInfoReq;
            gSiCfgData.siSapTab[n].relLocation = (U8)pSiSapCfg->location;
            
            break;
            

        case APP_TABLE_ID_SS7_ISUP_INTF:
            pSiIntfCfg = (SiCfgIntfTab *) prow->panytbrow;
            
            
            if (gSiCfgData.siIntfNum >= SI_NMB_INTF)
            {
                SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
                    "smSiRecvCfgFromOam(gSiCfgData.siNSapNum: %#x >= SI_NMB_INTF, RETVALUE(RFAILED))\n", (gSiCfgData.siNSapNum + 1) )); 
                break;
            }
            else
            {
                n = gSiCfgData.siIntfNum++;
            }   
            
            gSiCfgData.siIntfTab[n].intfId    = pSiIntfCfg->intfId;
            
            gSiCfgData.siIntfTab[n].nwId      = pSiIntfCfg->nwId;

            gSiCfgData.siIntfTab[n].opcIdx    = pSiIntfCfg->opcIdx;
            gSiCfgData.siIntfTab[n].dpcIdx    = pSiIntfCfg->dpcInx;

            gSiCfgData.siIntfTab[n].lnkSelOpt = pSiIntfCfg->lnkSelOpt;
            gSiCfgData.siIntfTab[n].trunkType = (U8)pSiIntfCfg->trunkType;
            gSiCfgData.siIntfTab[n].pauseActn =  (U8)pSiIntfCfg->pauseActn;
            
            
            break;
            
         case APP_TABLE_ID_SS7_ISUP_SUBROUT:
            
            pSubRouteCfg = (SiCfgSubRouteTab *) prow->panytbrow;
            
            
            if (gSiCfgData.siSubRouteNum >= SI_NMB_SUBROUT)
            {
                SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
                    "smSiRecvCfgFromOam(gSiCfgData.siSubRouteNum: %#x >= 1, RETVALUE(RFAILED))\n", (gSiCfgData.siSubRouteNum + 1) )); 
                break;
            }
            else
            {
                n = gSiCfgData.siSubRouteNum++;
            }
            

            gSiCfgData.siSubRouteTab[n].CirType= pSubRouteCfg->CirType;
            gSiCfgData.siSubRouteTab[n].CtrlMode= pSubRouteCfg->CtrlMode;
            gSiCfgData.siSubRouteTab[n].CtrlSelMath= pSubRouteCfg->CtrlSelMath;
            gSiCfgData.siSubRouteTab[n].intfId = pSubRouteCfg->intfId;
            gSiCfgData.siSubRouteTab[n].subRtId= pSubRouteCfg->subRtId;
            
            break;
            
        case APP_TABLE_ID_SS7_ISUP_CIRGRP:
            pSiCirCfg = (SiCfgCirGrpTab *) prow->panytbrow;

            if (pSiCirCfg->cirNum > PCM_MAXNUM_CIR)
            {
                SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
                    "smSiRecvCfgFromOam(pSiCirCfg->cirNum: %#x >= PCM_MAXNUM_CIR, RETVALUE(RFAILED))\n", pSiCirCfg->cirNum )); 
                break;
            }
            
            if (gSiCfgData.siCirGrpNum >= SI_NMB_CIR)
            {
                SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
                    "smSiRecvCfgFromOam(gSiCfgData.siCirGrpNum: %#x >= SI_NMB_CIR, RETVALUE(RFAILED))\n", (gSiCfgData.siCirGrpNum + 1) )); 
                break;
            }
            else
            {
                n = gSiCfgData.siCirGrpNum++;
            }   

			gSiCfgData.siCirGrpTab[n].cirGrpId    = pSiCirCfg->cirGrpId;
            gSiCfgData.siCirGrpTab[n].cirNum      = pSiCirCfg->cirNum;
            gSiCfgData.siCirGrpTab[n].fstCIC      = pSiCirCfg->fstCIC;
            gSiCfgData.siCirGrpTab[n].fstTimeSlot = pSiCirCfg->fstTimeSlot;
            gSiCfgData.siCirGrpTab[n].subRtId     = pSiCirCfg->subRtId;
            gSiCfgData.siCirGrpTab[n].locPcmId    = pSiCirCfg->locPcmId;
            
			gSiCfgData.siCirGrpTab[n].conReq = pSiCirCfg->conReq;
            break;

		case APP_TABLE_ID_SS7_ISUP_PROFILE:
            pProfileCfg = (SiCfgProfileTab *) prow->panytbrow;
            
            
            if (gSiCfgData.siProfileNum >= SI_NMB_PROFILE)
            {
                SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
                    "smSiRecvCfgFromOam(gSiCfgData.siProfileNum: %#x >= SI_NMB_PROFILE, RETVALUE(RFAILED))\n", (gSiCfgData.siSapNum + 1) )); 
                break;
            }
            else
            {
                n = gSiCfgData.siProfileNum++;
            }   
            
            gSiCfgData.siProfileTab[n].t1         = pProfileCfg->t1;
            gSiCfgData.siProfileTab[n].t2         = pProfileCfg->t2;
            gSiCfgData.siProfileTab[n].t5         = pProfileCfg->t5;
            gSiCfgData.siProfileTab[n].t6         = pProfileCfg->t6;
            gSiCfgData.siProfileTab[n].t7         = pProfileCfg->t7;
			gSiCfgData.siProfileTab[n].t8         = pProfileCfg->t8;
            gSiCfgData.siProfileTab[n].t9         = pProfileCfg->t9;
            gSiCfgData.siProfileTab[n].t27        = pProfileCfg->t27;
            gSiCfgData.siProfileTab[n].t33        = pProfileCfg->t33;
            gSiCfgData.siProfileTab[n].tFNLRELRSP = pProfileCfg->tFNLRELRSP;
            gSiCfgData.siProfileTab[n].tRELRSP    = pProfileCfg->tRELRSP;
           
            break;
        default:
            break;
        }
        
        prow = prow->next;
    }
    
    RETVALUE(ROK);
}


S16 smSiCfgList()
{

    S16 ret = ROK;
    
    /*siTestPrint();*/
    
    
    /* static config data only be done in config start phase, and it would not change after system started*/
    if( gSmCb[ENTSI].smStatus == SM_INIT_CFG_STATE)
    {
        ret = smSiGenCfgList();
        if( ROK != ret)
        {
            RETVALUE(ret);
        }
        
        ret = smSiSapCfgList();
        if( ROK != ret)
        {
            RETVALUE(ret);
        }
        ret = smSiNSapCfgList();        
        if( ROK != ret)
        {
            RETVALUE(ret);
        }
        
        ret = smSiIntfCfgList();        
        if( ROK != ret)
        {
            RETVALUE(ret);
        }
        
        ret = smSiCirCfgList();        		
        if( ROK != ret)
        {
            RETVALUE(ret);
        }
        
    }
    
    RETVALUE(ROK);
}



unsigned char siNmSyncCallback(unsigned short msgtype, unsigned int sepuense, unsigned char pack_end, tb_record* prow)
{
    /*��oam����Ϣ��SM*/
    if(ROK != smSiRecvCfgFromOam(msgtype, prow))
    {
        opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
            "siNmSyncCallback(smSiRecvCfgFromOam is RFAILED)\n"));
        RETVALUE(RFAILED);
    } 	
    
    if(TRUE == pack_end)
    {
        /*��ȫ����������ݼӵ�sm������������*/
        if(ROK != smSiCfgList())
        {
            opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
            SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
            "siNmSyncCallback(smSiCfgList is RFAILED)\n"));
            RETVALUE(RFAILED);
        } 	

#ifdef STR_TST
        StrCcCfg();
#endif        
        /* oam send out a config req message to sm, cfg start */
        if( ROK != smSendCfgReq(ENTSI, SM_INIT_CFG_STATE))
        {
            opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
            SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
             "siNmSyncCallback(smSendCfgReq is RFAILED)\n"));        
            RETVALUE(RFAILED);                         
        }
        
        /* wait initial cofiguration finished*/
        ssWaitSema(&gSmCb[ENTSI].sema);
        
        /* send response to subagent*/
        if(SM_SUCCESS_STATE ==  gSmCb[ENTSI].smStatus)
        {
            /* All the initialization configuration data is processed successfully */
            opt_response_batch(sepuense, OAM_RESPONSE_OK);
            siBndItReq();            /* ISUP BND M3UA */
        }
        else 
        {
            opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
        }

        smReset(ENTSI);
        
    }

#ifdef CP_OAM_DATA_SHOW
   siPrintCfgInfo();
    /* print end*/
#endif /*CP_OAM_DATA_SHOW*/
    
    RETVALUE(RFAILED) ;
}


void smSiResetCfgData()
{
    smOamDataReorg((U16*)&gSiCfgData.siSapNum, (U8 *)&gSiCfgData.siSapTab[0].OprType, sizeof(SiSapCfgTab));
    smOamDataReorg((U16*)&gSiCfgData.siIntfNum, (U8 *)&gSiCfgData.siIntfTab[0].OprType, sizeof(SiIntfCfgTab));
    smOamDataReorg((U16*)&gSiCfgData.siCirGrpNum, (U8 *)&gSiCfgData.siCirGrpTab[0].OprType, sizeof(SiCirGrpCfgTab));
    smOamDataReorg((U16*)&gSiCfgData.siSubRouteNum, (U8 *)&gSiCfgData.siSubRouteTab[0].OprType, sizeof(SiSubRouteCfgTab));
}





S16 siDynCfgMsg(tb_record *prow)
{
    
    U16  i;
    S16 ret = ROK;
    
    if(gSmCb[ENTSI].smStatus == SM_DYN_STATE)
    {
        //Intf
        for(i = 0; i < gSiCfgData.siIntfNum; i++)
        {
            ret = ROK;
            
            switch(gSiCfgData.siIntfTab[i].OprType)
            {
            case(EN_CP_OPR_ADD):
                ret = smSiAddIntf(i);
                break;
            case(EN_CP_OPR_MOD):
                ret = smSiModIntf(i);
                break;
            case(EN_CP_OPR_DEL):
                ret = smSiDelIntf(i);
                break;
            default:
                break;
            }
            
            //���󷵻�
            if(ROK != ret)
            {
                RETVALUE(ret);
            }
        }
        
        
        //subRoute ����Ҫ��̬����

        //Group circuit
        for(i = 0; i < gSiCfgData.siCirGrpNum; i++)
        {
            ret = ROK;
            
            switch(gSiCfgData.siCirGrpTab[i].OprType)
            {
            case(EN_CP_OPR_ADD):
                    ret = smSiAddCir(i);
                break;
            case(EN_CP_OPR_MOD):
                   ret = smSiModCir(i);
                break;
            case(EN_CP_OPR_DEL):
                   ret = smSiDelCir(i);
                break;
            default:
                break;
            }
            
            //���󷵻�
            if(ROK != ret)
            {
                RETVALUE(ret);
            }
        }

		for(i = 0; i < gSiCfgData.siSapNum; i++)
        {
            ret = ROK;
            
            switch(gSiCfgData.siSapTab[i].OprType)
            {
            case(EN_CP_OPR_ADD):
                break;
            case(EN_CP_OPR_MOD):
                   ret = smSiModSap(i);
                break;
            case(EN_CP_OPR_DEL):
                break;
            default:
                break;
            }
            
            //���󷵻�
            if(ROK != ret)
            {
                RETVALUE(ret);
            }
        }
        
    }
	
	RETVALUE(ROK);
}
	

/*��oam����SM����Ϣ��prow �ж�����*/
S16 smSiRecvDynCfg(unsigned short msgtype, tb_record* prow)
{
    SiCfgIntfTab*     pSiIntfCfg;
    SiCfgCirGrpTab*   pSiCirCfg;
    SiCfgSubRouteTab* pSubRouteCfg;
	SiCfgProfileTab*  pProfileCfg;
	SiCfgSapTab*      pSapCfg;
    
    S16  n = 0;
	U16 i;
    
    if (prow == NULLP)
    {
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
            "smSiRecvCfgFromOam(prow is NULLP, RETVALUE(RFAILED))\n"));
        RETVALUE(RFAILED);
    }
    
    while(prow)
    {
        switch(prow->tableid)
        {
        case APP_TABLE_ID_SS7_ISUP_INTF:
            pSiIntfCfg = (SiCfgIntfTab *) prow->panytbrow;
            
            
            switch(msgtype)
            {
            case SA_INSERT_MSG:
                
                if (gSiCfgData.siIntfNum >= SI_NMB_INTF)
                {
                    SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
                        "smSiRecvCfgFromOam(gSiCfgData.siNSapNum: %#x >= SI_NMB_INTF, RETVALUE(RFAILED))\n", (gSiCfgData.siNSapNum + 1) )); 
                    break;
                }
                else
                {
                    n = gSiCfgData.siIntfNum++;
                }
                
                gSiCfgData.siIntfTab[n].intfId    = pSiIntfCfg->intfId;
                
                gSiCfgData.siIntfTab[n].nwId      = pSiIntfCfg->nwId;
                
                gSiCfgData.siIntfTab[n].opcIdx    = pSiIntfCfg->opcIdx;
                gSiCfgData.siIntfTab[n].dpcIdx    = pSiIntfCfg->dpcInx;
                
                gSiCfgData.siIntfTab[n].lnkSelOpt = pSiIntfCfg->lnkSelOpt;
                gSiCfgData.siIntfTab[n].trunkType = (U8)pSiIntfCfg->trunkType;
                gSiCfgData.siIntfTab[n].pauseActn =  (U8)pSiIntfCfg->pauseActn;
                
                /* */
                gSiCfgData.siIntfTab[n].OprType = EN_CP_OPR_ADD;
                    break;
                
            case SA_UPDATE_MSG:
                for(n = 0; n < gSiCfgData.siIntfNum; n++)
                {
                    if(gSiCfgData.siIntfTab[n].intfId == pSiIntfCfg->intfId)
                    {
                        gSiCfgData.siIntfTab[n].lnkSelOpt = pSiIntfCfg->lnkSelOpt;
                        gSiCfgData.siIntfTab[n].pauseActn =  (U8)pSiIntfCfg->pauseActn;
                        
                        gSiCfgData.siIntfTab[n].OprType = EN_CP_OPR_MOD;
                            break;
                    }
                } 
                break;
            case SA_DELETE_MSG:
                for(n = 0; n < gSiCfgData.siIntfNum; n++)
                {
                    if(gSiCfgData.siIntfTab[n].intfId == pSiIntfCfg->intfId)
                    {
                        for(i = 0; i < gSiCfgData.siSubRouteNum; i++)
                        { 
                            if (gSiCfgData.siSubRouteTab[i].intfId == pSiIntfCfg->intfId)
                            {
                                SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf,
                                "delIntf is failed, There is subroute in the intf, \n" )); 
                                RETVALUE(RFAILED);
                            }
                        }
						
                        gSiCfgData.siIntfTab[n].OprType = EN_CP_OPR_DEL;
                        
                        break;
                    }
                } 
                break;
               
            default:
				 ;
            }
            
            
            break;
            
        case APP_TABLE_ID_SS7_ISUP_SUBROUT:
                
            pSubRouteCfg = (SiCfgSubRouteTab *) prow->panytbrow;
            
            switch(msgtype)
            {
            case SA_INSERT_MSG:
                
                if (gSiCfgData.siSubRouteNum >= SI_NMB_SUBROUT)
                {
                    SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
                        "smSiRecvCfgFromOam(gSiCfgData.siSubRouteNum: %#x >= 1, RETVALUE(RFAILED))\n", (gSiCfgData.siSubRouteNum + 1) )); 
                    break;
                }
                else
                {
                    n = gSiCfgData.siSubRouteNum++;
                }
                
                gSiCfgData.siSubRouteTab[n].CirType = pSubRouteCfg->CirType;
                gSiCfgData.siSubRouteTab[n].CtrlMode = pSubRouteCfg->CtrlMode;
                gSiCfgData.siSubRouteTab[n].CtrlSelMath = pSubRouteCfg->CtrlSelMath;
                gSiCfgData.siSubRouteTab[n].intfId = pSubRouteCfg->intfId;
                gSiCfgData.siSubRouteTab[n].subRtId = pSubRouteCfg->subRtId;
                
                break;
            case SA_UPDATE_MSG:  /* ����ISUPЭ��ջ����Ҫ�޸�, CallSrcId,SigRuleId*/
				
                break;
            case SA_DELETE_MSG:
                for(n = 0; n < gSiCfgData.siSubRouteNum; n++)
                {
                    if (gSiCfgData.siSubRouteTab[n].subRtId == pSubRouteCfg->subRtId)
                    {
                        for (i = 0; i < gSiCfgData.siCirGrpNum; i++)
                        {
                            if (gSiCfgData.siCirGrpTab[i].subRtId == pSubRouteCfg->subRtId)
                            {
                               SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
                                "delsubroute is failed, There is cirGrp in the subroute, \n" )); 
							   
                               RETVALUE(RFAILED);

                            }
                        }
						
						gSiCfgData.siSubRouteNum--;
                        gSiCfgData.siSubRouteTab[n] = gSiCfgData.siSubRouteTab[gSiCfgData.siSubRouteNum];
                    }
                }
                break;
            default:
				;
            }
            
            break;
                
        case APP_TABLE_ID_SS7_ISUP_CIRGRP:
            pSiCirCfg = (SiCfgCirGrpTab *) prow->panytbrow;
            
            
            switch(msgtype) 
            {
            case SA_INSERT_MSG:
                
                if (pSiCirCfg->cirNum > PCM_MAXNUM_CIR)
                {
                    SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
                        "smSiRecvCfgFromOam(pSiCirCfg->cirNum: %#x >= PCM_MAXNUM_CIR, RETVALUE(RFAILED))\n", pSiCirCfg->cirNum )); 
                    break;
                }
                
                if (gSiCfgData.siCirGrpNum >= SI_NMB_CIR)
                {
                    SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
                        "smSiRecvCfgFromOam(gSiCfgData.siCirGrpNum: %#x >= SI_NMB_CIR, RETVALUE(RFAILED))\n", (gSiCfgData.siCirGrpNum + 1) )); 
                    break;
                }
                else
                {
                    n = gSiCfgData.siCirGrpNum++;
                } 
                
		    	gSiCfgData.siCirGrpTab[n].cirGrpId    = pSiCirCfg->cirGrpId;
                gSiCfgData.siCirGrpTab[n].cirNum      = pSiCirCfg->cirNum;
                gSiCfgData.siCirGrpTab[n].fstCIC      = pSiCirCfg->fstCIC;
                gSiCfgData.siCirGrpTab[n].fstTimeSlot = pSiCirCfg->fstTimeSlot;
                gSiCfgData.siCirGrpTab[n].subRtId     = pSiCirCfg->subRtId;
                gSiCfgData.siCirGrpTab[n].locPcmId    = pSiCirCfg->locPcmId;
	    		gSiCfgData.siCirGrpTab[n].conReq      = pSiCirCfg->conReq;

                
                gSiCfgData.siCirGrpTab[n].OprType = EN_CP_OPR_ADD;
                
                break;
            case SA_UPDATE_MSG:
                for(n = 0; n < gSiCfgData.siCirGrpNum; n++)
                { 
                    if (gSiCfgData.siCirGrpTab[n].cirGrpId == pSiCirCfg->cirGrpId)
                    {
                        /* 
                        gSiCfgData.siCirGrpTab[n].cirNum= pSiCirCfg->cirNum;
                        gSiCfgData.siCirGrpTab[n].fstCIC= pSiCirCfg->fstCIC;
                        gSiCfgData.siCirGrpTab[n].fstTimeSlot= pSiCirCfg->fstTimeSlot;
                        gSiCfgData.siCirGrpTab[n].subRtId= pSiCirCfg->subRtId;
                        gSiCfgData.siCirGrpTab[n].locPcmId = pSiCirCfg->locPcmId;
                        */
						gSiCfgData.siCirGrpTab[n].conReq = pSiCirCfg->conReq;
						
                        gSiCfgData.siCirGrpTab[n].OprType = EN_CP_OPR_MOD;
                        
                    }
                }
                
                break;
            case SA_DELETE_MSG:
                
                for(n = 0; n < gSiCfgData.siCirGrpNum; n++)
                {
                    if (gSiCfgData.siCirGrpTab[n].cirGrpId== pSiCirCfg->cirGrpId)
                    {
                        
                        gSiCfgData.siCirGrpTab[n].OprType = EN_CP_OPR_DEL;
                    }
                }
                break;
            default:
				;
            }
            
            break;
 
            
        case APP_TABLE_ID_SS7_ISUP_PROFILE:
            pProfileCfg = (SiCfgProfileTab *) prow->panytbrow;
                
                
            switch(msgtype)
            {
            case SA_INSERT_MSG:
                
                pProfileCfg = (SiCfgProfileTab *) prow->panytbrow;
                
                
                if (gSiCfgData.siProfileNum >= SI_NMB_PROFILE)
                {
                    SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, 
                        "smSiRecvCfgFromOam(gSiCfgData.siProfileNum: %#x >= SI_NMB_PROFILE, RETVALUE(RFAILED))\n", (gSiCfgData.siSapNum + 1) )); 
                    break;
                }
                else
                {
                    n = gSiCfgData.siProfileNum++;
                }   
                
                gSiCfgData.siProfileTab[n].t1         = pProfileCfg->t1;
                gSiCfgData.siProfileTab[n].t2         = pProfileCfg->t2;
                gSiCfgData.siProfileTab[n].t5         = pProfileCfg->t5;
                gSiCfgData.siProfileTab[n].t6         = pProfileCfg->t6;
                gSiCfgData.siProfileTab[n].t7         = pProfileCfg->t7;
                gSiCfgData.siProfileTab[n].t8         = pProfileCfg->t8;
                gSiCfgData.siProfileTab[n].t9         = pProfileCfg->t9;
                gSiCfgData.siProfileTab[n].t27        = pProfileCfg->t27;
                gSiCfgData.siProfileTab[n].t33        = pProfileCfg->t33;
                gSiCfgData.siProfileTab[n].tFNLRELRSP = pProfileCfg->tFNLRELRSP;
                gSiCfgData.siProfileTab[n].tRELRSP    = pProfileCfg->tRELRSP;
                
                /* */
                //gSiCfgData.siProfileTab[n].OprType = EN_CP_OPR_ADD;
                break;
            
            case SA_UPDATE_MSG:
                for(n = 0; n < gSiCfgData.siProfileNum; n++)
                {
                    if(gSiCfgData.siProfileTab[n].profileId == pProfileCfg->profileId)
                    {
                        gSiCfgData.siProfileTab[n].t1         = pProfileCfg->t1;
                        gSiCfgData.siProfileTab[n].t5         = pProfileCfg->t5;
                        gSiCfgData.siProfileTab[n].t7         = pProfileCfg->t7;
                        gSiCfgData.siProfileTab[n].t8         = pProfileCfg->t8;
                        gSiCfgData.siProfileTab[n].t9         = pProfileCfg->t9;
                        gSiCfgData.siProfileTab[n].t33        = pProfileCfg->t33;
                        
                        for(i = 0; i < gSiCfgData.siSapNum; i++)
                        {
                            gSiCfgData.siSapTab[i].profileId = pProfileCfg->profileId;
                            
                            gSiCfgData.siSapTab[i].OprType   = EN_CP_OPR_MOD;
                            
                        }
							
                        break;
                    }
                } 
                break;
            case SA_DELETE_MSG:
                for(n = 0; n < gSiCfgData.siProfileNum; n++)
                {
                    if(gSiCfgData.siProfileTab[n].profileId == pProfileCfg->profileId)
                    {
                        for(i = 0; i < gSiCfgData.siSapNum; i++)
                        { 
                            if (gSiCfgData.siSapTab[i].profileId == pProfileCfg->profileId)
                            {
                                SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf,
                                    "delprofile is failed, There is profile in the USap, \n" )); 
                                RETVALUE(RFAILED);
                            }
                        }
                        
                        gSiCfgData.siProfileNum--;
                        gSiCfgData.siProfileTab[n] = gSiCfgData.siProfileTab[gSiCfgData.siProfileNum];
                        
                        break;
                    }
                } 
                break;
                    
                default:
                    ;
                }
                
                break;

        case APP_TABLE_ID_SS7_ISUP_SAP:
            pSapCfg = (SiCfgSapTab *) prow->panytbrow;
                
                
            switch(msgtype)
            {

            case SA_UPDATE_MSG:
                for(n = 0; n < gSiCfgData.siSapNum; n++)
                {
                    if(gSiCfgData.siSapTab[n].SapId == pSapCfg->SapId)
                    {
                        gSiCfgData.siSapTab[n].profileId   = pSapCfg->profileId;
						gSiCfgData.siSapTab[n].autoInfoReq = pSapCfg->autoInfoReq;
						gSiCfgData.siSapTab[n].relLocation = pSapCfg->location;

                        gSiCfgData.siIntfTab[n].OprType = EN_CP_OPR_MOD;
                        break;
                    }
                } 
                break;
                    
            default:
                ;
            }
        	     
            break;


        default:
            break; 
                
        }
        
     prow = prow->next;
   }
   
   RETVALUE(ROK);
}





/************************************************************************/
/* ��̬���� ISUP����: ���ӡ�ɾ��                                        */
/************************************************************************/
unsigned char siDynCfgCallback(unsigned int tableid, unsigned short msgtype, unsigned int sequence, unsigned char pack_end, tb_record *prow)
{
    /*dynamic callback return value initilized fail*/
    prow->head.col_index = OAM_ERRCOL_UNKNOWN;
    
    if(SA_INSERT_MSG == msgtype)
        prow->head.err_no = OAM_RESPONSE_INSERT_ERROR;
    else if(SA_UPDATE_MSG == msgtype)
        prow->head.err_no = OAM_RESPONSE_UPDATE_ERROR;
    else if(SA_DELETE_MSG == msgtype)
        prow->head.err_no = OAM_RESPONSE_DELETE_ERROR;
    else 
        prow->head.err_no = OAM_RESPONSE_PARAM_ERROR;
    
    if(NULL == prow)
    {
        opt_response_row(sequence, prow);
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf, "siDynCfgCallback ISUP recv null"));
        RETVALUE(RFAILED);
    }
    
    if(gSmCb[ENTSI].smStatus == SM_STATUS_TOTAL_NUM)
    {
        gSmCb[ENTSI].smStatus = SM_DYN_STATE;
    }
    else
    {
        opt_response_row(sequence, prow);
        SM_SIDBGP(DBGMASK_MI, (gSiCfgData.CfgInit.prntBuf,  "siDynCfgCallback: gSmCb[ENTSI].smStatus != SM_DYN_STATE."));
        RETVALUE(RFAILED);

    }
    
    //�õ����ݣ��浽gSiCfgData
    if(ROK != smSiRecvDynCfg(msgtype, prow))
    {
       
        opt_response_row(sequence, prow);
        //SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "siDynCfgCallback ISUP recv dynamic config data error");
        smReset(ENTSI);
		RETVALUE(RFAILED);
    }   
    
    if(TRUE == pack_end)
    {
        //�����ݼӵ� gSpSmQ
        if(ROK != siDynCfgMsg(prow ))
        {
            opt_response_row(sequence, prow);
            //SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "siDynCfgCallback ISUP dync config error");
            smReset(ENTSI);
		    RETVALUE(RFAILED);
        }   
        
        /* send out a config req message to sm*/
        if(ROK != smSendCfgReq(ENTSI, SM_DYN_STATE))
        {
            opt_response_row(sequence, prow);
            //SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "siDynCfgCallback send sm cfg req message error");
            smReset(ENTSI);
		    RETVALUE(RFAILED);                   
        }
        
        /* wait dynamic cofiguration finished*/
        ssWaitSema(&gSmCb[ENTSI].sema);
        
        /* send response to subagent*/
        if(SM_SUCCESS_STATE ==  gSmCb[ENTSI].smStatus)
        {
            prow->head.col_index = OAM_ERRCOL_OK;
            prow->head.err_no = OAM_RESPONSE_OK;
            /* All the initialization configuration data is processed successfully */
            opt_response_row(sequence, prow);
        }
        else 
        {
            opt_response_row(sequence, prow);
        }
        
        smReset(ENTSI);
        
    }
    
    RETVALUE(ROK) ;
}


S16 smSiInitCfg()
{
    U32 appId;
	t_XOSMUTEXID *plock = NULL;

    siInitCfgData(); 
    
    if( ROK != smRegCb((Ent)ENTSI, gSiSmQ, (U8)(sizeof(gSiSmQ)/sizeof(CmLListCp)), smSiSendReqQ, smSiResetCfgData))
    {
        RETVALUE(RFAILED);
    }
    
    if( OAM_CALL_SUCC != register_msg_proc(CP_MODULE_ID_SS7_ISUP,  APP_SYNC_MSG,  siNmSyncCallback, NULL))
    {
        RETVALUE(RFAILED);
    } 
    
    
    /******  intf  ******/
    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_ISUP, APP_TABLE_ID_SS7_ISUP_INTF, SA_INSERT_MSG,  siDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 	
    
    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_ISUP, APP_TABLE_ID_SS7_ISUP_INTF, SA_UPDATE_MSG,  siDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 	
    
    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_ISUP, APP_TABLE_ID_SS7_ISUP_INTF, SA_DELETE_MSG,  siDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 	
    
    /******  subroute  ******/
    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_ISUP, APP_TABLE_ID_SS7_ISUP_SUBROUT, SA_INSERT_MSG,  siDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 	
    
    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_ISUP, APP_TABLE_ID_SS7_ISUP_SUBROUT, SA_UPDATE_MSG,  siDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 	
    
    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_ISUP, APP_TABLE_ID_SS7_ISUP_SUBROUT, SA_DELETE_MSG,  siDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 	
    
    
    /******  cirgroup  ******/
    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_ISUP, APP_TABLE_ID_SS7_ISUP_CIRGRP, SA_INSERT_MSG,  siDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 	
    
    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_ISUP, APP_TABLE_ID_SS7_ISUP_CIRGRP, SA_UPDATE_MSG,  siDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 	
    
    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_ISUP, APP_TABLE_ID_SS7_ISUP_CIRGRP, SA_DELETE_MSG,  siDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 	
    
    /******  SAP  ******/
    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_ISUP, APP_TABLE_ID_SS7_ISUP_SAP, SA_UPDATE_MSG,  siDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 
    
    /******  profile(timer)  ******/
    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_ISUP, APP_TABLE_ID_SS7_ISUP_PROFILE, SA_INSERT_MSG,  siDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 	
    
    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_ISUP, APP_TABLE_ID_SS7_ISUP_PROFILE, SA_UPDATE_MSG,  siDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 	
    
    if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_ISUP, APP_TABLE_ID_SS7_ISUP_PROFILE, SA_DELETE_MSG,  siDynCfgCallback, plock))
    {
        RETVALUE(RFAILED);
    } 
    
    (unsigned char)get_resource(xwCpSS7NwkTable, sizeof(CP_OAM_SS7_NETWORK_TAB), xwCpSS7NwkTable_ROW_NUM);
    (unsigned char)get_resource(xwCpSS7UpTable, sizeof(CP_OAM_SS7_UP_TAB), xwCpSS7UpTable_ROW_NUM);
    (unsigned char)get_resource(xwCpSS7SpcTable, sizeof(CP_OAM_SS7_SPC_TAB), xwCpSS7SpcTable_ROW_NUM);
    
    (unsigned char)get_resource(xwCpIsupGenCfg, sizeof(SiCfgGenTab), xwCpIsupGenCfg_ROW_NUM);
    (unsigned char)get_resource(xwCpIsupUSapCfgTable, sizeof(SiCfgSapTab), xwCpIsupUSapCfgTable_ROW_NUM);
    (unsigned char)get_resource(xwCpIsupProfileCfgTable, sizeof(SiCfgProfileTab), xwCpIsupProfileCfgTable_ROW_NUM);
    
    (unsigned char)get_resource(xwSSIsupUaSiTable, sizeof(SiCfgIntfTab), xwSSIsupUaSiTable_ROW_NUM);
    (unsigned char)get_resource(xwSSIsupUaSsrTable, sizeof(SiCfgSubRouteTab), xwSSIsupUaSsrTable_ROW_NUM);
    (unsigned char)get_resource(xwSSIsupUaScmTable, sizeof(SiCfgCirGrpTab), xwSSIsupUaScmTable_ROW_NUM);
    
    
    appId =CP_MODULE_ID_SS7_ISUP;
    
    if( OAM_CALL_SUCC != app_register(appId, &siCfgTbl[0], sizeof(siCfgTbl)/sizeof(siCfgTbl[0])))
    {
        RETVALUE(RFAILED);
    }
    
    
    
    RETVALUE(ROK);
}

#endif  //endif CP_OAM_SUPPORT








