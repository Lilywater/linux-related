/* ***************************************************************************
 *        (c) COPYRIGHT 1995-2006 by Xinwei, Inc.
 *                   All rights reserved.
 *
 * Sa3_ex_ms.c:  
 *          This file include the sample usage of sctp protocol.
 *           
 * Author:
 *          zhouguishuang
 * Date:
 *          2006-4-21
 * Last Modified:
 *
 ****************************************************************************/
/*#include "sm.h"*/

#include "sb_common.h"
#include "xosshell.h"
#ifdef CP_OAM_SUPPORT
#include "cp_tab_def.h"
#endif
#include "sb_cfg.h"

#include "xosshell.h"

#ifdef CP_OAM_SUPPORT

#include "sb_oam.x"
#include "sm.x"
#endif

SbCfgGenWG  sbCfgGenWg;
SbCfgAddrWG sbCfgAddrWG;
CmLListCp sbCmListSQ[SCTP_CONFIG_Q_TOTAL_NUM];

#ifdef CP_OAM_SUPPORT
U32 sbCfgTbl[]={APP_TABLE_ID_COM_IP,APP_TABLE_ID_VOIP_SCTP_GEN, APP_TABLE_ID_VOIP_SCTP_SRC_ADDR};
#endif

PUBLIC CmInetIpAddr  loopBkAddrV = (CmInetIpAddr)0x7F000001;

PUBLIC CmIpv4NetAddr localNAddrLst_1V[5] =
{ 
      0x00000000,
      0x00000000,
	  0x00000000,
	  0x00000000,
	  0x00000000
};  /* end localAddrLst_1 */

PUBLIC CmIpv4NetAddr localNAddrLst_2V[] =
{ 
      0x00000000,
      0x00000000,
	  0x00000000,
	  0x00000000,
	  0x00000000
};  /* end localAddrLst_2 */

PUBLIC U32 peerNAddrLst_1V[] =
{
      0x00000000,
      0x00000000,
	  0x00000000,
	  0x00000000,
	  0x00000000
};  /* end peerNAddrLst_1V */


U8          addrType = CM_NETADDR_IPV4;



void sbCfgInit(void)
{
    U8 i = 0;
    memset((U8 *)&sbCfgGenWg, 0, sizeof(SbCfgGenWG));
    
    sbCfgGenWg.maxNmbSctSaps    = 0;
    sbCfgGenWg.maxNmbTSaps      = 0;
    sbCfgGenWg.maxNmbEndp       = 0;
    sbCfgGenWg.maxNmbAssoc      = 0;
    sbCfgGenWg.maxNmbDstAddr    = 0;
    sbCfgGenWg.maxNmbSrcAddr    = 0;
    sbCfgGenWg.maxNmbTxChunks   = 0;
    sbCfgGenWg.maxNmbRxChunks   = 00;
    sbCfgGenWg.maxNmbInStrms    = 00;
    sbCfgGenWg.maxNmbOutStrms   = 0;
    sbCfgGenWg.initARwnd        = 0;
    sbCfgGenWg.mtuInitial       = 0;   
    sbCfgGenWg.performMtu       = 0;
	sbCfgGenWg.UseFlcAssocChunks = 0;
	sbCfgGenWg.UsePerAssocChunks =0;
	
	sbCfgAddrWG.srcNAddrIndex1   =  0;
	sbCfgAddrWG.srcNAddrIndex2   =  0;
	sbCfgAddrWG.srcNAddrIndex3   =  0;
	sbCfgAddrWG.srcNAddrIndex4   =  0;
	sbCfgAddrWG.srcNAddrIndex5   =  0;
	sbCfgAddrWG.NmbsrcNAddr    =  0;

    printf("init sctp Cfg finished.\n\r");
}


/*****************************************************************************
*
*       ����:   sbGetLmPstV
*
*       ����:   ��ȡ�����Ͷ�ݽṹ��Ϣ��
*
*       ����ֵ:   ʧ��  RFAILED
*                 �ɹ�  ROK
*
*       ע��:  
*
*       �ļ�:  sb_cfg.c
*
*/
#ifdef ANSI
PUBLIC  Void  sbGetLmPstV
(
Pst *lmPst
)
#else
PUBLIC  Void sbGetLmPstV(lmPst)
Pst  *lmPst;          /* pointer to lmPst structure */
#endif
{
   TRC2(sbGetLmPstV)

#ifdef LCSBMILSB
   lmPst->selector     = SEL_LC;
#else
   lmPst->selector     = SEL_TC;     /* tightly coupled */
#endif
   lmPst->dstProcId = SFndProcId();  /* dst proc id */
   lmPst->srcProcId = SFndProcId();  /* src proc id */
   lmPst->dstEnt    = ENTSM;         /* dst entity */
   lmPst->dstInst   = 0;            /* dst inst */
   lmPst->srcEnt    = ENTSB;         /* src entity */
   lmPst->srcInst   = 0;            /* src inst */

   lmPst->region    = DFLT_REGION;        /* region */
   lmPst->pool      = DFLT_POOL;       /* pool */
   lmPst->prior     = PRIOR0;        /* priority */
   lmPst->route     = RTESPEC;       /* route */

#ifdef LCSMSBMILSB
   lmPst->selector     = SEL_LC;     /* loosely coupled */
#else
   lmPst->selector     = SEL_TC;     /* tightly coupled */
#endif

   RETVOID;

} /* sbGetLmPstV */



 






/*****************************************************************************
*
*       ����:   setResponseV
*
*       ����:   ��������Ϣ��
*
*       ����ֵ:   ʧ��  RFAILED
*                 �ɹ�  ROK
*
*       ע��:  
*
*       �ļ�:  sb_cfg.c
*
*/
#ifdef ANSI
PUBLIC void setResponseV
(
Resp *resp
)
#else
PUBLIC void setResponseV(resp)
Resp *resp;
#endif
{

#ifdef LCSBMILSB
   resp->selector = SEL_LC;
#else
   resp->selector = SEL_TC;
#endif

   resp->prior = PRIOR0;
   resp->route = RTESPEC;
   resp->mem.region  = DFLT_REGION;
   resp->mem.pool = DFLT_POOL;
   RETVOID;
}







/*****************************************************************************
*
*       ����:   sbSetGenCfg
*
*       ����:   ����SCT GENERAL ��Ϣ��
*
*       ����ֵ:   ʧ��:           RFAILED
*                 �ɹ�:           ROK
*
*       ע��:  sbSetGenCfg(&sbMgmt);
*
*       �ļ�:  sb_cfg.c
*
*/
PUBLIC  void sbSetGenCfg
(
SbMgmt *sbCfgPtr   /* configuration structure received from test routine */
)
{
   SbGenCfg *genCfg;
   SbGenReCfg *genreCfg;

   setResponseV(&sbCfgPtr->hdr.response);
   sbCfgPtr->hdr.elmId.elmnt = STSBGEN;
   genCfg = &(sbCfgPtr->t.cfg.s.genCfg);
   genreCfg = &(sbCfgPtr->t.cfg.s.genCfg.reConfig);
   /* Keep separate for reconfiguration */
   
   /* set configuration parameters */
#ifdef SB_IPV6_SUPPORTED   /* sb032.102 : IPV6 Support Added */
   genCfg->ipv6SrvcReqdFlg = TRUE;
#endif
   genCfg->serviceType    = HI_SRVC_RAW_SCTP; /*HI_SRVC_RAW_SCTP;HI_SRVC_RAW_SCTP HI_SRVC_UDP;  /* use packectized TCP data */
   genCfg->maxNmbSctSaps  = sbCfgGenWg.maxNmbSctSaps;
   genCfg->maxNmbTSaps    = sbCfgGenWg.maxNmbTSaps;
   genCfg->maxNmbAssoc    = sbCfgGenWg.maxNmbAssoc;
   genCfg->maxNmbEndp     = sbCfgGenWg.maxNmbEndp;
   genCfg->maxNmbDstAddr  = sbCfgGenWg.maxNmbDstAddr;
   genCfg->maxNmbSrcAddr  = sbCfgGenWg.maxNmbSrcAddr;
   genCfg->maxNmbTxChunks = sbCfgGenWg.maxNmbTxChunks;
   genCfg->maxNmbRxChunks = sbCfgGenWg.maxNmbRxChunks;
   genCfg->maxNmbInStrms  = sbCfgGenWg.maxNmbInStrms;
   genCfg->maxNmbOutStrms = sbCfgGenWg.maxNmbOutStrms;
   genCfg->initARwnd      = sbCfgGenWg.initARwnd;
   genCfg->mtuInitial     = sbCfgGenWg.mtuInitial;
   genCfg->mtuMinInitial  = sbCfgGenWg.mtuInitial;
   genCfg->mtuMaxInitial  = sbCfgGenWg.mtuInitial;
   genCfg->performMtu     = sbCfgGenWg.performMtu;
   genCfg->timeRes = 1; 
   sbGetLmPstV(&genCfg->smPst);
    /*  SB_VER13 - Added for version 13 */
   cmMemcpy(genCfg->hostname,(CONSTANT U8 *)"www.xinwei.com", 
                            cmStrlen((CONSTANT U8 *)"www.xinwei.com"));
   genCfg->useHstName = FALSE;

   genreCfg->maxInitReTx = 8;
   genreCfg->maxAssocReTx = 5;
   genreCfg->maxPathReTx = 2;
   genreCfg->altAcceptFlg = TRUE;
   genreCfg->keyTm = 5000;  /* initial value for MD 5key expiry timer */
   genreCfg->alpha = 12;
   genreCfg->beta = 25;
   RETVOID;
} /* end of sbSetGenCfg */







/*****************************************************************************
*
*       ����:   sbSetSctSapCfg
*
*       ����:   ����SCT SAP��
*
*       ����ֵ:   ʧ��:           RFAILED
*                 �ɹ�:           ROK
*
*       ע��:  sbSetSctSapCfg(&sbMgmt, SAP_1)��
*
*       �ļ�:  sb_cfg.c
*
*/
PUBLIC  void sbSetSctSapCfg
(
SbMgmt *sbCfgPtr,   /* configuration structure received from test routine */
U8      specCfg      /* Number of the specific configuration */
)
{
   SbSctSapCfg *sctSapCfg;
   SbSctSapReCfg *sctSapReCfg;

   TRC2(sbSetSctSapCfg)

   setResponseV(&sbCfgPtr->hdr.response);
   sbCfgPtr->hdr.elmId.elmnt = STSBSCTSAP;
   sctSapCfg = &(sbCfgPtr->t.cfg.s.sctSapCfg);
   sctSapReCfg = &(sbCfgPtr->t.cfg.s.sctSapCfg.reConfig);
   
   

   /* set configuration parameters */
   sctSapCfg->swtch = LSB_SW_RFC_REL0;
#ifdef LCITLISCT
   sctSapCfg->sel = SEL_LC;
#else
   sctSapCfg->sel = SEL_TC;
#endif
   sctSapCfg->memId.region = DFLT_REGION;
   sctSapCfg->memId.pool = DFLT_POOL;
   sctSapCfg->prior = PRIOR0;
   sctSapCfg->route = RTESPEC;
   
   /* we make this slightly longer than the recommended 200ms since
      debug printing might slow the layer down a bit */
   sctSapReCfg->maxAckDelayTm = 5;       /* Equivalent of 500 ms */
   sctSapReCfg->maxAckDelayDg = 2;
   sctSapReCfg->rtoInitial = ACC_RTO_INIT;
   sctSapReCfg->rtoMin = ACC_RTO_INIT;
   sctSapReCfg->rtoMax = ACC_RTO_INIT;
   sctSapReCfg->cookieLife = 30000;        /* 1000ms = 1 second */
   sctSapReCfg->intervalTm = 15;   
   sctSapReCfg->freezeTm = 15;  
   
   sctSapReCfg->hBeatEnable = FALSE; /* SB_VER13-hBeatEnable added */
   sctSapReCfg->flcUpThr = sbCfgGenWg.UsePerAssocChunks;
   sctSapReCfg->flcLowThr = sbCfgGenWg.UseFlcAssocChunks;

   /* sb042.102 - Added change for rolling upgrade */
#ifdef SB_RUG
   sctSapReCfg->remIntfValid = TRUE;
   sctSapReCfg->remIntfVer = SCTIFVER;
#endif /* SB_RUG */

            switch(specCfg)
            {
             case SAP_1:
                sctSapCfg->spId = SPID_0;
                sctSapReCfg->negAbrtFlg = FALSE;
                sctSapReCfg->handleInitFlg = TRUE;
                break;
             case SAP_2:
                sctSapCfg->spId = SPID_1;
                sctSapReCfg->negAbrtFlg = TRUE;
                sctSapReCfg->handleInitFlg = FALSE;
                break;
             case SAP_3:
                sctSapCfg->spId = SPID_2;
                sctSapReCfg->negAbrtFlg = FALSE;
                sctSapReCfg->handleInitFlg = TRUE;
                break;

             case SAP_4:
                sctSapCfg->spId = SPID_3;
                sctSapReCfg->negAbrtFlg = FALSE;
                sctSapReCfg->handleInitFlg = TRUE;
                break;
             case SAP_5:
                sctSapCfg->spId = SPID_4;
                sctSapReCfg->negAbrtFlg = TRUE;
                sctSapReCfg->handleInitFlg = FALSE;
                break;
             case SAP_6:
                sctSapCfg->spId = SPID_5;
                sctSapReCfg->negAbrtFlg = FALSE;
                sctSapReCfg->handleInitFlg = TRUE;
                break;

             case SAP_7:
                sctSapCfg->spId = SPID_6;
                sctSapReCfg->negAbrtFlg = FALSE;
                sctSapReCfg->handleInitFlg = TRUE;
                break;
             case SAP_8:
                sctSapCfg->spId = SPID_7;
                sctSapReCfg->negAbrtFlg = TRUE;
                sctSapReCfg->handleInitFlg = FALSE;
                break;
             case SAP_9:
                sctSapCfg->spId = SPID_8;
                sctSapReCfg->negAbrtFlg = FALSE;
                sctSapReCfg->handleInitFlg = TRUE;
                break;
             case SAP_10:
                sctSapCfg->spId = SPID_9;
                sctSapReCfg->negAbrtFlg = FALSE;
                sctSapReCfg->handleInitFlg = TRUE;
                break;                
             /* sb042.102 - Added change for rolling upgrade */                          
#ifdef SB_RUG
             case SAP_11:
                sctSapCfg->spId = SPID_10;
                sctSapReCfg->negAbrtFlg = FALSE;
                sctSapReCfg->handleInitFlg = TRUE;
                sctSapReCfg->remIntfValid = TRUE;
                sctSapReCfg->remIntfVer = SCTIFVER;
                break;
             case SAP_12:
                sctSapCfg->spId = SPID_11;
                sctSapReCfg->negAbrtFlg = FALSE;
                sctSapReCfg->handleInitFlg = TRUE;
                sctSapReCfg->remIntfValid = TRUE;
                sctSapReCfg->remIntfVer = SCTIFVER-1;
                break;
#endif /* SB_RUG */
             default:
                break;
            }
   RETVOID;
} /* end of sbSetSctSapCfg */








/*****************************************************************************
*
*       ����:   sbSetTSapCfg
*
*       ����:   ����TSAP��
*
*       ����ֵ:   ʧ��:           RFAILED
*                 �ɹ�:           ROK
*
*       ע��:  sbSetTSapCfg(&sbMgmt, SAP_1);
*
*       �ļ�:  sb_cfg.c
*
*/
PUBLIC  Void sbSetTSapCfg
(
SbMgmt      *sbCfgPtr,/* configuration structure received from test routine */
U8          specCfg   /* Number of the specific configuration */
)
{
   SbTSapCfg      *tSapCfg;
   SbTSapReCfg    *tSapReCfg;
   SctNetAddrLst  *srcNAddrLst;
   U8             i;

   TRC2(sbSetTSapCfg)
   setResponseV(&sbCfgPtr->hdr.response);
   sbCfgPtr->hdr.elmId.elmnt = STSBTSAP;
   tSapCfg = &(sbCfgPtr->t.cfg.s.tSapCfg);
   tSapReCfg = &(sbCfgPtr->t.cfg.s.tSapCfg.reConfig);
   srcNAddrLst = &(sbCfgPtr->t.cfg.s.tSapCfg.srcNAddrLst);

   /* set configuration parameters */
   tSapCfg->swtch = LSB_SW_RFC_REL0;
#ifdef LCHIUIHIT
   tSapCfg->sel = SEL_LC;
#else
   tSapCfg->sel = SEL_TC;
#endif

   tSapCfg->ent = ENTHI;
   tSapCfg->inst = DEF_ENT;
   tSapCfg->procId = SFndProcId();
   tSapCfg->memId.region = DFLT_REGION;
   tSapCfg->memId.pool = DFLT_POOL;
   tSapCfg->prior = PRIOR0;
   tSapCfg->route = RTESPEC;

   /*set reconfiguration parameters*/
   tSapReCfg->tIntTmr = 10;     /* Depend on timer tick*/
   tSapReCfg->maxBndRetry = 3;

   /* SB_VER13 - Parameter added for DNS interface */
   tSapReCfg->sbDnsCfg.dnsAddr.type = CM_NETADDR_IPV4;
   tSapReCfg->sbDnsCfg.dnsAddr.u.ipv4TptAddr.port = 53;
   tSapReCfg->sbDnsCfg.dnsAddr.u.ipv4TptAddr.address = loopBkAddrV;

   /* sb044.102: added for changes in protocol layer. Now DNS open request *
    * will be called if DNS is configured in TSAP                          */

   tSapReCfg->sbDnsCfg.useDnsLib = FALSE;
     

   tSapReCfg->sbDnsCfg.dnsTmOut    = 3;
   tSapReCfg->sbDnsCfg.maxRtxCnt   = 3;

   /* sb042.102 - Added change for rolling upgrade */
#ifdef SB_RUG
   tSapReCfg->remIntfValid = TRUE;
   tSapReCfg->remIntfVer = HITIFVER;
#endif /* SB_RUG */

   switch(specCfg)
   {
      case SAP_1:
         tSapReCfg->spId = SPID_0;
         tSapCfg->suId = SUID_0;
         tSapCfg->srcNAddrLst.nmb = sbCfgAddrWG.NmbsrcNAddr;
         /* sb032.102 : IPV6 Support Added */
         if( addrType == CM_NETADDR_IPV4) 
         {
            for (i = 0; (i < tSapCfg->srcNAddrLst.nmb ); i++)
            {
                /* IPV4 addresses  */
               tSapCfg->srcNAddrLst.nAddr[i].type = CM_TPTADDR_IPV4;
               tSapCfg->srcNAddrLst.nAddr[i].u.ipv4NetAddr = localNAddrLst_1V[i];
            }
         }
         break;

      case SAP_2:
         tSapReCfg->spId = SPID_1;
         tSapCfg->suId = SUID_1;
         tSapCfg->srcNAddrLst.nmb = sbCfgAddrWG.NmbsrcNAddr;

         if( addrType == CM_NETADDR_IPV4)
         {
            for (i = 0; (i < tSapCfg->srcNAddrLst.nmb); i++)
            {  /* IPV4 addresses  */
               tSapCfg->srcNAddrLst.nAddr[i].type = CM_TPTADDR_IPV4;
               tSapCfg->srcNAddrLst.nAddr[i].u.ipv4NetAddr = localNAddrLst_1V[i];/*localNAddrLst_1V[i];*/
            }
         }
         break;

      case SAP_3:
         tSapReCfg->spId = SPID_2;
         tSapCfg->suId = SUID_2;
         tSapCfg->srcNAddrLst.nmb = sbCfgAddrWG.NmbsrcNAddr;
         /* sb032.102 : IPV6 Support Added */
         if( addrType == CM_NETADDR_IPV4) 
         {
            for (i = 0; (i < tSapCfg->srcNAddrLst.nmb ); i++)
            {
                /* IPV4 addresses  */
               tSapCfg->srcNAddrLst.nAddr[i].type = CM_TPTADDR_IPV4;
               tSapCfg->srcNAddrLst.nAddr[i].u.ipv4NetAddr = localNAddrLst_1V[i];/*localNAddrLst_1V[i];*/
            }
         }
         break;

      case SAP_4:
         tSapReCfg->spId = SPID_3;
         tSapCfg->suId = SUID_3;
         tSapCfg->srcNAddrLst.nmb = sbCfgAddrWG.NmbsrcNAddr;
         /* sb032.102 : IPV6 Support Added */
         if( addrType == CM_NETADDR_IPV4) 
         {
            for (i = 0; (i < tSapCfg->srcNAddrLst.nmb ); i++)
            {
                /* IPV4 addresses  */
               tSapCfg->srcNAddrLst.nAddr[i].type = CM_TPTADDR_IPV4;
               tSapCfg->srcNAddrLst.nAddr[i].u.ipv4NetAddr = localNAddrLst_1V[i];/*localNAddrLst_1V[i];*/
            }
         }
         break;
      case SAP_5:
         tSapReCfg->spId = SPID_4;
         tSapCfg->suId = SUID_4;
         tSapCfg->srcNAddrLst.nmb = sbCfgAddrWG.NmbsrcNAddr;
         /* sb032.102 : IPV6 Support Added */
         if( addrType == CM_NETADDR_IPV4) 
         {
            for (i = 0; (i < tSapCfg->srcNAddrLst.nmb ); i++)
            {
                /* IPV4 addresses  */
               tSapCfg->srcNAddrLst.nAddr[i].type = CM_TPTADDR_IPV4;
               tSapCfg->srcNAddrLst.nAddr[i].u.ipv4NetAddr = localNAddrLst_1V[i];/*localNAddrLst_1V[i];*/
            }
         }
         break;
      case SAP_6:
         tSapReCfg->spId = SPID_5;
         tSapCfg->suId = SUID_5;
         tSapCfg->srcNAddrLst.nmb = sbCfgAddrWG.NmbsrcNAddr;
         /* sb032.102 : IPV6 Support Added */
         if( addrType == CM_NETADDR_IPV4) 
         {
            for (i = 0; (i < tSapCfg->srcNAddrLst.nmb ); i++)
            {
                /* IPV4 addresses  */
               tSapCfg->srcNAddrLst.nAddr[i].type = CM_TPTADDR_IPV4;
               tSapCfg->srcNAddrLst.nAddr[i].u.ipv4NetAddr = localNAddrLst_1V[i];/*localNAddrLst_1V[i];*/
            }
         }
         break;
      case SAP_7:
         tSapReCfg->spId = SPID_6;
         tSapCfg->suId = SUID_6;
         tSapCfg->srcNAddrLst.nmb = sbCfgAddrWG.NmbsrcNAddr;
         /* sb032.102 : IPV6 Support Added */
         if( addrType == CM_NETADDR_IPV4) 
         {
            for (i = 0; (i < tSapCfg->srcNAddrLst.nmb ); i++)
            {
                /* IPV4 addresses  */
               tSapCfg->srcNAddrLst.nAddr[i].type = CM_TPTADDR_IPV4;
               tSapCfg->srcNAddrLst.nAddr[i].u.ipv4NetAddr = localNAddrLst_1V[i];/*localNAddrLst_1V[i];*/
            }
         }
         break;



      default:
		  break;

   } /* end switch */
   RETVOID;
} /* end of sbSetTSapCfg */


/*****************************************************************************
   ���û��OAM��ô��ͨ������̨�ֹ����á�����ͨ��OAM���á� 
 *****************************************************************************/

PUBLIC  Void  sbSetSmPstV
(
Pst *smPst
)
{
#ifdef LCSMSBMILSB
   smPst->selector  = SEL_LC;
#else
   smPst->selector  = SEL_TC;
#endif

   smPst->dstProcId = SFndProcId();
   smPst->srcProcId = SFndProcId();
   smPst->dstEnt    = ENTSB;
   smPst->dstInst   = DEF_ENT;
   smPst->srcEnt    = ENTSM;
   smPst->srcInst   = DEF_ENT;
   smPst->prior     = PRIOR0;
   smPst->route     = RTESPEC;
   smPst->region    = DFLT_REGION;
   smPst->pool      = DFLT_POOL;
}           



S16 smSbSendReqQ(CmLList *node)
{
    Pst smSbPst;
    Header *msgHeader;
    S16 ret = ROK;
   
    TRC2(smSbSendReqQ);      
    msgHeader = (Header *)cmLListNode(node);


    sbSetSmPstV(&smSbPst);
    switch(msgHeader->msgType)
    {
        case TCFG:
            ret = SmMiLsbCfgReq(&smSbPst, (SbMgmt *)cmLListNode(node));
            break;

        default:
            RETVALUE(RFAILED);
    }

    RETVALUE(ret);
}

/*****************************************************************************
*
*       ����:   sctp_config_gen
*
*       ����:   ����SCTP GEN������
*
*       ����ֵ: ��
*
*       �ļ�:  sb_cfg.c
*
*/
void sctp_config_gen(void)
{
    SbMgmt  sbMgmt;
    Pst     smPst;


#ifdef LCSMSBMILSB
   smPst.selector  = SEL_LC;
#else
   smPst.selector  = SEL_TC;
#endif

   smPst.dstProcId = SFndProcId();
   smPst.srcProcId = SFndProcId();
   smPst.dstEnt    = ENTSB;
   smPst.dstInst   = DEF_ENT;
   smPst.srcEnt    = ENTSM;
   smPst.srcInst   = DEF_ENT;
   smPst.prior     = PRIOR0;
   smPst.route     = RTESPEC;
   smPst.region    = DFLT_REGION;
   smPst.pool      = DFLT_POOL;
           
   printf("CONFIG GEN SCTP!\n");
   sbSetGenCfg(&sbMgmt);
   sbMgmt.hdr.transId = 10001;
   setResponseV(&sbMgmt.hdr.response);
   (Void) SmMiLsbCfgReq(&smPst, &sbMgmt);
   
   return;
}



/*****************************************************************************
*
*       ����:   sctp_config_sctsap
*
*       ����:   ����SCTP SCTSAP������
*
*       ����ֵ: ��
*
*       �ļ�:  sb_cfg.c
*
*/
void sctp_config_sctsap(void)
{
    SbMgmt  sbMgmt;
    Pst     smPst;
    U8      i=0;
    
    if( sbGlobalCb.sbInit.cfgDone != TRUE )  
    {   
        printf("\n[SCTP]ERROR:DO SCTP general config first.\n");
        RETVOID;
    }/* if( sbGlobalCb.sbInit.cfgDone == TRUE ) */
       
#ifdef LCSMSBMILSB
   smPst.selector  = SEL_LC;
#else
   smPst.selector  = SEL_TC;
#endif

   smPst.dstProcId = SFndProcId();
   smPst.srcProcId = SFndProcId();
   smPst.dstEnt    = ENTSB;
   smPst.dstInst   = DEF_ENT;
   smPst.srcEnt    = ENTSM;
   smPst.srcInst   = DEF_ENT;
   smPst.prior     = PRIOR0;
   smPst.route     = RTESPEC;
   smPst.region    = DFLT_REGION;
   smPst.pool      = DFLT_POOL;

   printf("CONFIG SCTSAP!\n");
   sbMgmt.hdr.transId=10002;
   for(i=1;i<=sbCfgGenWg.maxNmbSctSaps;i++)
   {
        sbSetSctSapCfg(&sbMgmt, i);
        sbMgmt.hdr.transId += 100;
        setResponseV(&sbMgmt.hdr.response);
        (void) SmMiLsbCfgReq(&smPst, &sbMgmt);
   }
   
   return;
}



/*****************************************************************************
*
*       ����:   sctp_config_tsap
*
*       ����:   ����SCTP TSAP������
*
*       ����ֵ: ��
*
*       �ļ�:  sb_cfg.c
*
*/
void sctp_config_tsap(void)
{
    SbMgmt  sbMgmt;
    Pst     smPst;
    U8      i=0;
    
    if( sbGlobalCb.sbInit.cfgDone != TRUE )  
    {   
        printf("\n[SCTP]ERROR:DO SCTP general config first.\n");
        RETVOID;
    }/* if( sbGlobalCb.sbInit.cfgDone == TRUE ) */
#ifdef LCSMSBMILSB
   smPst.selector  = SEL_LC;
#else
   smPst.selector  = SEL_TC;
#endif

   smPst.dstProcId = SFndProcId();
   smPst.srcProcId = SFndProcId();
   smPst.dstEnt    = ENTSB;
   smPst.dstInst   = DEF_ENT;
   smPst.srcEnt    = ENTSM;
   smPst.srcInst   = DEF_ENT;
   smPst.prior     = PRIOR0;
   smPst.route     = RTESPEC;
   smPst.region    = DFLT_REGION;
   smPst.pool      = DFLT_POOL;
           
   printf("CONFIG TSAP!\n");
   sbMgmt.hdr.transId=10003;   
   for(i=1;i<=sbCfgGenWg.maxNmbTSaps;i++)
   {
       sbSetTSapCfg(&sbMgmt, i);
       sbMgmt.hdr.transId +=100;
       setResponseV(&sbMgmt.hdr.response);
       (void) SmMiLsbCfgReq(&smPst, &sbMgmt);       
   }
  
   return;
}





#ifdef CP_OAM_SUPPORT


/*****************************************************************************
*
*       ����:   sctp_config_gen
*
*       ����:   ����SCTP GEN������
*
*       ����ֵ: ��
*
*       �ļ�:  sb_cfg.c
*
*/
S16 sctp_oam_config_gen(void)
{
    SbMgmt      *sbMgmt;
    CmLList     *node;

    TRC2(sctp_oam_config_gen);  
    
    SPrint("CONFIG GEN SCTP!\n");
    /* alloc a node for save sm msg info */
    if( ROK != smGetQNode(&node, sizeof(SbMgmt)))
    {
        RETVALUE(RFAILED);
    }
    sbMgmt = (SbMgmt *)cmLListNode(node) ;
    sbMgmt->hdr.msgLen = sizeof( SbMgmt);

    sbSetGenCfg(sbMgmt);
    sbMgmt->hdr.msgType = TCFG; 
    sbMgmt->hdr.transId = 0;
    setResponseV(&sbMgmt->hdr.response);
   
    cmLListAdd2Tail(&sbCmListSQ[SCTP_GEN_Q], node);
    
    return ROK;
}



/*****************************************************************************
*
*       ����:   sctp_oam_config_sctsap
*
*       ����:   ����SCTP SCTSAP������
*
*       ����ֵ: ��
*
*       �ļ�:  sb_cfg.c
*
*/
S16 sctp_oam_config_sctsap(void)
{
    SbMgmt      *sbMgmt;
    CmLList     *node;

    
    U8      i=0;
    TRC2(sctp_oam_config_sctsap);     
   printf("CONFIG SCTSAP!\n");
   
   
   for(i=1;i<=sbCfgGenWg.maxNmbSctSaps;i++)
   {
        /* alloc a node for save sm msg info */
        if( ROK != smGetQNode(&node, sizeof(SbMgmt)))
        {
            RETVALUE(RFAILED);
        }        
        sbMgmt = (SbMgmt *)cmLListNode(node) ;
        sbMgmt->hdr.msgLen = sizeof(SbMgmt);
        
        sbMgmt->hdr.msgType = TCFG; 
        sbMgmt->hdr.transId=0;
        sbSetSctSapCfg(sbMgmt, i);
        setResponseV(&sbMgmt->hdr.response);
        
        cmLListAdd2Tail(&sbCmListSQ[SCTP_SCTSAP_Q], node);
   }
   
   return ROK;
}



/*****************************************************************************
*
*       ����:   sctp_oam_config_tsap
*
*       ����:   ����SCTP TSAP������
*
*       ����ֵ: ��
*
*       �ļ�:  sb_cfg.c
*
*/
S16 sctp_oam_config_tsap(void)
{
    SbMgmt      *sbMgmt;
    CmLList     *node;
    U8      i=0;
    
    TRC2(sctp_oam_config_tsap);     
    printf("CONFIG TSAP!\n");
    
   
   for(i=1;i<=sbCfgGenWg.maxNmbTSaps;i++)
   {
        /* alloc a node for save sm msg info */
        if( ROK != smGetQNode(&node, sizeof(SbMgmt)))
        {
            RETVALUE(RFAILED);
        }        
        sbMgmt = (SbMgmt *)cmLListNode(node) ;
        sbMgmt->hdr.msgLen = sizeof(SbMgmt);
        
        sbMgmt->hdr.msgType = TCFG; 
        sbMgmt->hdr.transId=0;
        sbSetTSapCfg(sbMgmt, i);
        setResponseV(&sbMgmt->hdr.response);
        
        cmLListAdd2Tail(&sbCmListSQ[SCTP_TSAP_Q], node);
   }

   return ROK;
}

#endif /*#ifdef CP_OAM_SUPPORT*/


