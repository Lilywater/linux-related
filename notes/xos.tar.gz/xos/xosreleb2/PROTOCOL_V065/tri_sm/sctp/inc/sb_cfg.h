
/* ***************************************************************************
 *        (c) COPYRIGHT 1995-2006 by Xinwei, Inc.
 *                   All rights reserved.
 *
 * sb_cfg.h:  
 *          Sctp protocol initialize function.
 *           
 * Author:
 *          zhouguishuang
 * Date:
 *          2006-5-9
 * Last Modified:
 *
 ****************************************************************************/

#ifndef __SB_CFGH__
#define __SB_CFGH__

/*#include "sb_common.h"*/


#define SM_SCTPGENCFG_TBL           10
#define SM_SCTPGENADDR_TBL          20

typedef struct  _sbSfgGenWG
{
   U32         maxNmbSctSaps;   /* max no. SCT SAPS */
   U32         maxNmbTSaps;     /* max no. Transport SAPS */
   U32         maxNmbEndp;      /* max no. endpoints */
   U32         maxNmbAssoc;     /* max no. associations */
   U32         maxNmbDstAddr;   /* max no. dest. addresses */
   U32         maxNmbSrcAddr;   /* max no. src. addresses */
   U32         maxNmbTxChunks;  /* max no. outgoing chunks */
   U32         maxNmbRxChunks;  /* max no. recv chunks */
   U32         maxNmbInStrms;   /* max no. in streams PER ASSOCIATION */
   U32         maxNmbOutStrms;  /* max no. out streams PER ASSOCIATION */
   U32         initARwnd;       /* max receiver window space */
   U32         mtuInitial;      /* Initial MTU size */
   U32         performMtu;      /* Perform path MTU discovery */
   U32         UsePerAssocChunks;  /* Use of per association's data chunks */   
   U32         UseFlcAssocChunks;  /* Flow control of association's data chunks */     
}SbCfgGenWG;


typedef struct  _sbSfgAddrWG
{
   U32         srcNAddrIndex1;     /* Initial minimum MTU size */
   U32         srcNAddrIndex2;     /* Initial maximum MTU size */ 
   U32         srcNAddrIndex3;     /* Initial maximum MTU size */ 
   U32         srcNAddrIndex4;     /* Initial maximum MTU size */ 
   U32         srcNAddrIndex5;     /* Initial maximum MTU size */ 
   U32         NmbsrcNAddr;     /* number of source address used */    
}SbCfgAddrWG;



typedef enum SCTP_CONFIG_QUEUE_ID
{
    SCTP_GEN_Q,
    SCTP_SCTSAP_Q,
    SCTP_TSAP_Q,
    SCTP_ASSCO_Q,
    SCTP_ENDP_Q,
    SCTP_ROUTE_Q,
    SCTP_NID_DPC_Q,
    SCTP_STA_Q,
    SCTP_CTRL_Q,
    SCTP_STS_Q,
    SCTP_CONFIG_Q_TOTAL_NUM
}SCTP_CONFIG_QUEUE_ID;


extern SbCfgGenWG   sbCfgGenWg;
extern SbCfgAddrWG  sbCfgAddrWG;
extern CmLListCp sbCmListSQ[SCTP_CONFIG_Q_TOTAL_NUM];


extern U16 sbCfgAddrTbl;
extern PUBLIC CmIpv4NetAddr localNAddrLst_1V[];

#ifdef  CP_OAM_SUPPORT
extern U32 sbCfgTbl[];
extern Bool g_sctptaskRegComp;
extern Bool g_sctpregisterFlag;
#endif

S16 sctp_oam_config_gen(void);
S16 sctp_oam_config_sctsap(void);
S16 sctp_oam_config_tsap(void);

#endif  /* __SB_CFGH__ */


/****************************************************************************

         End of file:     sb_cfg.h
         
*****************************************************************************/
