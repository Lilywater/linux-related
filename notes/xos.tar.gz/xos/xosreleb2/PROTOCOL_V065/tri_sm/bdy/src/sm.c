#ifdef CP_OAM_SUPPORT
/****************************************
**
**	File		: sm.c
**	Created	By	: 
**	Created	On	:
**	
**	Purpose: 
**	
**	History:
**	Programmer	Date		
***************************************/
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_err.h"        /* common error */
#include "cm_llist.h"


#include "ss_err.h"        /* system services error code*/
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* common timer */
#include "cm_lib.x"        /* Common Portable Library */
#include "cm_llist.x"
#include "cm_ss7.x"

#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */

#include "sm.h"
#include "sm.x"
#include "xosshell.h"
#include "envdep.h"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"

/*-----------------------------------------------------------------------------*/
SmCb gSmCb[ENTLAST + 1];
CmTqCp gSmTqCp;                             /* sm timer entry point */
CmTqType gSmTq[ENTLAST + 1];                /* sm timer queue, only one timer started with each entity*/

/********************************************************************************************************
  Function: smRegCb() 
  Description: entity reg information into itself smCb and init the resources
  Calls:
  Called By: 
  Input:    
  Output:  
  Return:   ROK:success; 
                RFAILED: failure
  Others:
 ********************************************************************************************************/
S16  smRegCb(Ent entId, CmLListCp *smSaQ, U8 reqQNum, FUNC_SM_SEND_REQQ smSendReqQ, FUNC_SM_RESET_CFG_DATA smResetCfgData)
{
    U8 i;
    
    TRC2(smRegCb);
    
    if( entId > ENTLAST)
    {
        RETVALUE(RFAILED);
    }

    /* save entity information into smCb */
    gSmCb[entId].smStatus = SM_INIT_CFG_STATE;
    gSmCb[entId].ReqQNum = reqQNum;

    gSmCb[entId].smSendReqQ = smSendReqQ;
    gSmCb[entId].smResetCfgData = smResetCfgData;

    /* create a semaphone for wait initial configuration finished*/
    ssInitSema(&gSmCb[entId].sema ,0);

    /* create a semaphome for queue operation, because insert 
    and delete node maybe done in two task at the same time*/
    ssInitSema(&gSmCb[entId].semaQ ,1);

    /* init sm timer*/
   cmInitTimers(gSmCb[entId].smTimer, SM_TIMER_TOTAL_NUM);

    /* reg sm req msg queue for buffer sm message in prority order*/
    gSmCb[entId].smReqQ = smSaQ;
    for( i = 0; i < reqQNum; i ++) 
    {
        cmLListInit(&gSmCb[entId].smReqQ[i]);
    }
    RETVALUE(ROK);        

}

/********************************************************************************************************
  Function: smGetQNode() 
  Description: alloc a sm queue node, and there are a block of memory in it for buffer sm msg infomation
  Calls:
  Called By: 
  Input:    size: memory size
  Output:  node: sm queue node
  Return:   ROK:success; 
                RFAIL: failure
  Others:
 ********************************************************************************************************/
S16 smGetQNode(CmLList **node, U16 size)
{
    Data *nodePtr;
    
    TRC2(smGetQNode);
    if( ROK != SGetSBuf(SM_REG, SM_POOL, (Data * *) node,  sizeof(CmLList)))
    {
        RETVALUE(RFAILED);
    }
    if( ROK != SGetSBuf(SM_REG, SM_POOL, (Data * *) &nodePtr,  size))
    {
        SPutSBuf( SM_REG, SM_POOL, (Data *)(*node), sizeof(CmLList));
        RETVALUE(RFAILED);        
    }
    (*node)->node = (PTR)nodePtr;
    RETVALUE(ROK);       
}

/********************************************************************************************************
  Function: smSendCfgReq() 
  Description: when stack recive configuration data, it will be stored into local structure and create sm info to prority queue; and 
                    send a cfg req message to sm which notify sm can start configuration.
  Calls:
  Called By: 
  Input:    entid: the enity which receive configuration data
               
  Output:  

  
  Return:   ROK:success; 
                RFAILED: failure
  Others:
 ********************************************************************************************************/
S16 smSendCfgReq(Ent entId, U8 smStatus)
{
    Buffer *msg;
    Pst pst;
    
    TRC2(smSendCfgReq);

    /* ssi must have a msg buffer when call SPstTsk, even it is not useful*/
    if( ROK != SGetMsg(SM_REG, SM_POOL, (Buffer * *)&msg))
    {
        RETVALUE(RFAILED);
    }
        
    pst.selector = SM_SEL_LC;

    pst.event     = EVTCFGXXREQ;
    pst.region = SM_REG;       /* region */
    pst.pool = SM_POOL;           /* pool */
    pst.prior = PRIOR1;                  /* priority */
    pst.route = RTESPEC;                  /* route */
    pst.dstProcId = SFndProcId();   /* destination processor id */
    pst.dstEnt = ENTSM;             /* dst entity  */
    pst.dstInst = ACTVINST;         /* dst instance (unused) */
    pst.srcProcId = SFndProcId();   /* source processor id */
    pst.srcEnt = entId;            /* source entity */
    pst.srcInst = ACTVINST;         /* src instance (unused) */

    SPkU8(smStatus, msg);
        
    if( ROK != SPstTsk( &pst, msg))
    {
        RETVALUE(RFAILED);
    }
    RETVALUE(ROK);    
}

/********************************************************************************************************
  Function: smHandleCfgReq() 
  Description: sm handle the config req msg from subagent
  Calls:
  Called By: 
  Input:    entid: the enity which receive configuration data
               
  Output:  

  
  Return:   ROK:success; 
                RFAILED: failure
  Others:
 ********************************************************************************************************/
S16 smHandleCfgReq(Pst *pst, Buffer *msg)
{
    U8 smStatus;

    SUnpkU8( &smStatus, msg);
		
    /* there are no information here, release it at first*/
    SPutMsg(msg);
		
    gSmCb[pst->srcEnt].smStatus = smStatus;

//    smStartTmr(SM_PRORITY_QUEUE_TIMER, SM_TIMER_LEN, &gSmCb[pst->srcEnt]);
    
    /* send out msg in protity queue, and start a sm timer for waiting response*/
    if( ROK != smDoCfg( pst->srcEnt))
    {
        RETVALUE(RFAILED);
    }
    
    RETVALUE(ROK);    
}

/********************************************************************************************************
  Function: cpSmStartTmr() 
  Description: start sm timer, which is waiting cfg resp.
  Calls:
  Called By: 
  Input:    timer: timerId, which is equal with entid, because one sm timer will be started for each entity
  Output:  
  Return:   ROK:success; 
                RFAIL: failure
  Others:
 ********************************************************************************************************/
Void smStartTmr( S16 timer, U32 timerLen, SmCb *cb )
{

    CmTmrArg arg;

    TRC2(smStartTmr)


    if (cb == NULLP)
    {
     	 RETVOID;
    }
    smStopTmr(timer, cb);
    arg.tq = gSmTq;
    arg.tqCp = &gSmTqCp;
    arg.timers = cb->smTimer;
    arg.cb = (PTR) cb;
    arg.evnt = (U8) timer;
    arg.wait = timerLen;
    arg.tNum = 0;
    arg.max = SM_TIMER_TOTAL_NUM;
    cmPlcCbTq(&arg);
    RETVOID;
}

/********************************************************************************************************
  Function: smStopTmr() 
  Description: stop sm timer, which is waiting cfg resp.
  Calls:
  Called By: 
  Input:    timer: timerId, which is equal with entid, because one sm timer will be started for each entity
  Output:  
  Return:   ROK:success; 
                RFAIL: failure
  Others:
 ********************************************************************************************************/
Void smStopTmr(S16 timer, SmCb *cb)
{

    CmTmrArg arg;
    S16 i;

    TRC2(smStopTmr);


    if (cb == NULLP)
    {
     	 RETVOID;
    }

    arg.tq = gSmTq;
    arg.tqCp = &gSmTqCp;
    for( i = 0; i < SM_TIMER_TOTAL_NUM; i++)
    {
        if(cb->smTimer[i].tmrEvnt == timer)
        {
            break;
        }
    }
    if( i == SM_TIMER_TOTAL_NUM)
    {
        RETVOID;
    }
    arg.timers = &(cb->smTimer[i]);
    arg.cb = (PTR) cb;
    arg.evnt = timer;
    arg.wait = 0;
    arg.tNum = 0;
    arg.max = SM_TIMER_TOTAL_NUM;
    cmRmvCbTq(&arg);
    RETVOID;    
}


/********************************************************************************************************
  Function: smDoCfg() 
  Description: sm send highest prority LMI request message which exist in the sm queue
  Calls:
  Called By: 
  Input:    entId: entity id
               
  Output:  send sm message to entity

  
  Return:   ROK:success; 
                RFAILED: failure
  Others:
 ********************************************************************************************************/
S16 smDoCfg(Ent entId)
{
    U8 i;
    CmLList *node;

    TRC2(smDoCfg);

    /* check sm queue, send all msg buffered in the highest prority queue*/
    for( i = 0; i < gSmCb[entId].ReqQNum; i++)
    {
       if( cmLListLen(&gSmCb[entId].smReqQ[i]) != 0)
       {
             break;
       }
    }
    /* if all buffer queue are empty, that mean current operation has success, give response to agent*/
    if( i == gSmCb[entId].ReqQNum )
    {
        gSmCb[entId].smStatus = SM_SUCCESS_STATE;
        RETVALUE(ROK);     
    }
    /* send all buffered msg out*/
    for( node = cmLListFirst(&gSmCb[entId].smReqQ[i]);
           node;
           node = cmLListNext(&gSmCb[entId].smReqQ[i]) )
    {
        if( NULLP == gSmCb[entId].smSendReqQ)
        {
            RETVALUE(ROK);     
        }
        if( ROK != gSmCb[entId].smSendReqQ(node))
        {
            RETVALUE(RFAILED); 
        }        
    }
    RETVALUE(ROK);     
    
}


/********************************************************************************************************
  Function: smSndResponseToOam() 
  Description: sm finish operation and send response to master agent
  Calls:
  Called By: 
  Input:   
               
               
  Output:  

  
  Return:   ROK:success; 
                RFAILED: failure
  Others:
 ********************************************************************************************************/
Void smSndResponseToOam(Ent entId, S16 cause) 
{
   TRC2(smSndResponseToOam);
   
    if(SM_SUCCESS_STATE ==  gSmCb[entId].smStatus)
    {
      /* All the configuration data is processed successfully */
		ssPostSema(&gSmCb[entId].sema);
    }
    else if( SM_FAILURE_STATE ==  gSmCb[entId].smStatus)
    {
		ssPostSema(&gSmCb[entId].sema);
    }
    else 
    {
        ;
    }
    RETVOID;
}


/********************************************************************************************************
  Function: smReset() 
  Description: reset smCb after operation finish
  Calls:
  Called By: 
  Input:    
  Output:  
  Return:   
  Others:
 ********************************************************************************************************/
void smReset(Ent entId)
{
    U8 i;

    gSmCb[entId].smStatus = SM_STATUS_TOTAL_NUM;     
    for( i = 0; i < gSmCb[entId].ReqQNum; i++)
    {
        smFlushQ(entId, &gSmCb[entId].smReqQ[i]);
    }   
//    smStopTmr(SM_PRORITY_QUEUE_TIMER, &gSmCb[entId]);
    if(NULLP != gSmCb[entId].smResetCfgData) 
    {
        gSmCb[entId].smResetCfgData();                   /* init the global config data for next times' usage*/
    }
}


/********************************************************************************************************
  Function: smFlushQ() 
  Description: flush a sm queue
  Calls:
  Called By: 
  Input:    queue: sm queue
  Output:  
  Return:   ROK:success; 
                RFAIL: failure
  Others:
 ********************************************************************************************************/
S16 smFlushQ(Ent entId, CmLListCp *queue)
{
    CmLList *node;
    Header *msgHeader;
  
    TRC2(smFlushQ);


    while( queue->first != NULLP)
    {
        ssWaitSema(&gSmCb[entId].semaQ);
        node = cmLListDelFrm(queue, queue->first);
        ssPostSema(&gSmCb[entId].semaQ);
        msgHeader = ( Header *)node->node;
        /* we alway use msgheader->msgLen to save memory size*/
        smPutQNode( node, msgHeader->msgLen);
    }

    
    RETVALUE(ROK);       
}



/********************************************************************************************************
  Function: smPutQNode() 
  Description: free a sm queue node and the memory it pointer to
  Calls:
  Called By: 
  Input:    node: sm queue node, size: the memory size
  Output:  
  Return:   ROK:success; 
                RFAIL: failure
  Others:
 ********************************************************************************************************/
S16 smPutQNode(CmLList *node, U16 size)
{
    S16 ret = ROK;
  
    TRC2(smPutQNode);
    if( ROK != SPutSBuf(SM_REG, SM_POOL, (Data *) node->node, size))
    {
        ret = RFAILED;
    }
    if( ROK != SPutSBuf(SM_REG, SM_POOL, (Data *) node, sizeof(CmLList)))
    {
        ret = RFAILED;
    }
    RETVALUE(ret);       
}

/********************************************************************************************************
 * Function: smOamDataReorg() 
 * Description: reorganize the buffer data
 * Calls:
 * Called By: 
 * Input: 
 * Output: 
 * Return: Initialization result.
 * Others:
 ********************************************************************************************************/
Void smOamDataReorg(U16 *itemNum, U8 *itemOpr, U16 itemSize)
{
    U16 curItemPos;
    U8 *enumOprType, *lastItem;
        
    TRC2(smOamDataReorg);

    for( curItemPos = 0; curItemPos < *itemNum; curItemPos++)
    {
        enumOprType = itemOpr + itemSize * curItemPos;
        /* if add or mod operation, just change the opr type into invalid, 
        the item would be keep in global variant*/
        if( *((U32 *)enumOprType)  == EN_CP_OPR_ADD || *((U32 *)enumOprType)  == EN_CP_OPR_MOD)
        {
            *((U32 *)enumOprType)  = EN_CP_OPR_INVALID;
        }
        /* if get or del  operation, remove the item*/
        if( *((U32 *)enumOprType)  == EN_CP_OPR_GET ||*((U32 *)enumOprType)  == EN_CP_OPR_DEL)
        {
            if(curItemPos == *itemNum - 1 )
            {
                *((U32 *)enumOprType)  = EN_CP_OPR_INVALID;
                (*itemNum) -- ;
                
            }
            else
            {
                lastItem = itemOpr + itemSize * (*itemNum - 1);
                cmMemcpy(enumOprType, lastItem, itemSize);
                (*itemNum) -- ;
            }
        }
    }
    RETVOID;

}


/********************************************************************************************************
  Function: smHandleResp() 
  Description: sm handle response message, that mean dequeue corresponding request message, send the next proity message until
                    all buffered message are sent out.
  Calls:
  Called By: 
  Input:    smResp  : response message 
               
  Output:  

  
  Return:   ROK:success; 
                RFAILED: failure
  Others:
 ********************************************************************************************************/
S16 smHandleResp(Pst *pst, Buffer *smResp)
{
    CmStatus status;
    TranId   ReqTid, RspTid;
    CmLList *node;
    U32 qid;


    TRC2(smHandleResp);

   
    /* the queue id which send last time is saved in the global variant*/
    for( qid = 0; qid < gSmCb[pst->srcEnt].ReqQNum; qid++)
    {
       if( cmLListLen(&gSmCb[pst->srcEnt].smReqQ[qid]) != 0)
       {
             break;
       }
    }
    /* if all queue are emtpy, just return back, because maybe there are some resend mode in the system*/
    if( qid ==  gSmCb[pst->srcEnt].ReqQNum)
    {
        RETVALUE(ROK);
    }    
    
    if( ROK != smGetTidFromSmMsg(smResp, &RspTid))
    {
        RETVALUE(RFAILED); 
    }
    /* go through the msg queue to find out corresponding request sm info and delete it*/
    for( node = cmLListFirst(&gSmCb[pst->srcEnt].smReqQ[qid]);
           node;
           node = cmLListNext(&gSmCb[pst->srcEnt].smReqQ[qid]) )
    {
        if( ROK != smGetTidFromSmQNode(node, &ReqTid))
        {
            RETVALUE(RFAILED); 
        }
        if( ReqTid != RspTid)
        {
            continue;
        }
        if( ROK != smGetRspStatusFromSmMsg(smResp, &status))
        {
            smPutQNode( node, (( Header *)node->node)->msgLen);
            RETVALUE(RFAILED); 
        }
        if(  LCM_PRIM_OK == status.status)
        {
             /* for configuration sucessful response, free the node and continue do the configuraiton*/
            if( ROK == smDeleteQNode(pst->srcEnt, &gSmCb[pst->srcEnt].smReqQ[qid], node))
            {
                smPutQNode( node, (( Header *)node->node)->msgLen);
            }
            else
            {
                printf("SM: ENT[%d] smDeleteQNode Failed!\r\n", pst->srcEnt);
            }
            break;
        }
        else
        {
            printf("SM: Config Rsp from ENT[%d] with Failed status (%d) !\r\n", pst->srcEnt, status.status);
        }

        if( SM_INIT_CFG_STATE ==  gSmCb[pst->srcEnt].smStatus)
        {
            gSmCb[pst->srcEnt].smStatus = SM_FAILURE_STATE;
            RETVALUE(status.reason);
        }     
        
         /* if it is failure response, and for dynamic configuration, return failure to subagent*/
        if( SM_DYN_STATE ==  gSmCb[pst->srcEnt].smStatus)
        {
            gSmCb[pst->srcEnt].smStatus = SM_FAILURE_STATE;
            RETVALUE(status.reason);
        }     
        
    }
    /* current queue has operation finished, operate the next queue*/
    if( cmLListLen(&gSmCb[pst->srcEnt].smReqQ[qid]) == 0)
    {
        smDoCfg(pst->srcEnt);
    }
    RETVALUE(ROK);     
}


/********************************************************************************************************
  Function: smGetTidFromSmMsg() 
  Description: get transId field from sm message
  Calls:
  Called By: 
  Input:    msg: sm message, alway Header structure in the front of message
  Output:  tid:   tranaction identity in the msg
  Return:   ROK:success; 
                RFAIL: failure
  Others:
 ********************************************************************************************************/
S16 smGetTidFromSmMsg(Buffer *msg, TranId *tid)
{
    Header   msgHeader;

    TRC2(smGetTidFromSmMsg);

    cmUnpkHeader(&msgHeader, msg);

    *tid = msgHeader.transId;

    cmPkHeader(&msgHeader, msg);

    RETVALUE(ROK);  
    
}


/********************************************************************************************************
  Function: smGetTidFromSmQNode() 
  Description: get transId field from node in sm queue
  Calls:
  Called By: 
  Input:    msg: sm message, alway Header structure in the front of message
  Output:  tid:   tranaction identity in the msg
  Return:   ROK:success; 
                RFAIL: failure
  Others:
 ********************************************************************************************************/
S16 smGetTidFromSmQNode(CmLList *node, TranId *tid)
{
    Header   *smHeader;

    TRC2(smGetTidFromSmQNode);

    smHeader = (Header *)(node->node);
    *tid = smHeader->transId;
    RETVALUE(ROK);  
    
}

/********************************************************************************************************
  Function: smGetRspStatusFromSmMsg() 
  Description: get response status field from sm response message
  Calls:
  Called By: 
  Input:    msg: sm message, alway Header structure in the front of message
  Output:  status:   status in the sm response msg
  Return:   ROK:success; 
                RFAIL: failure
  Others:
 ********************************************************************************************************/
S16 smGetRspStatusFromSmMsg(Buffer *msg, CmStatus *status)
{
    
    Header   msgHeader;
    CmStatus msgStatus;

    TRC2(smGetRspStatusFromSmMsg);

    cmUnpkHeader(&msgHeader, msg);
    cmUnpkCmStatus( &msgStatus, msg);

    *status = msgStatus;

    cmPkCmStatus( &msgStatus, msg);
    cmPkHeader(&msgHeader, msg);

    RETVALUE(ROK);  

   
}



/********************************************************************************************************
  Function: smDeleteQNode() 
  Description: delete a queue node from queue
  Calls:
  Called By: 
  Input:    queue: sm queue
  Output:  
  Return:   ROK:success; 
                RFAIL: failure
  Others:
 ********************************************************************************************************/
S16 smDeleteQNode(Ent entId, CmLListCp *queue, CmLList *node)
{
    CmLList *result;
  
    TRC2(smDeleteQNode);

    ssWaitSema(&gSmCb[entId].semaQ);
    result = cmLListDelFrm(queue, node);
    ssPostSema(&gSmCb[entId].semaQ);

    if(result == NULLP)
    {
        RETVALUE(RFAILED); 
    }
    RETVALUE(ROK);       
}


/********************************************************************************************************
  Function: smInit() 
  Description: init smCb in the system initial period
  Calls:
  Called By: 
  Input:    
  Output:  
  Return:  
  Others:
 ********************************************************************************************************/
void smInit(void)
{
    U8 i;

    for( i = 0; i < ENTLAST + 1; i++)
    {
        gSmCb[i].entId = i;
        gSmCb[i].inst = 0;
        gSmCb[i].smStatus = SM_STATUS_TOTAL_NUM;          
/* smTimer, sema, semaQ, smReqQ will be set in smRegCb */
                                                          
        gSmCb[i].smReqQ = NULLP;                   
/* smSeqQ, smSendSeqQTimeoutHdl will be set in smRegSeqQ */	
        gSmCb[i].ReqQNum = 0;        
        gSmCb[i].smSendReqQ = NULLP;
/* ReqQNum, smSendReqQ, will be set in smRegCb */
    }    
}
#endif /*CP_OAM_SUPPORT*/
