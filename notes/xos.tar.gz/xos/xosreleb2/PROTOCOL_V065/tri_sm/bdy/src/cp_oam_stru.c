#ifdef CP_OAM_SUPPORT
#include "xosshell.h"
#include "envdep.h"
#include "envopt.h"
#include "envind.h"
#include "gen.h"
#include "ssi.h"
#include "gen.x"
#include "cm_ss7.x"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"

CP_SS7_GLOBAL gstCpSs7Global;

U32 CpSs7SetOneNwkTab(U32 OprType, CP_OAM_SS7_NETWORK_TAB* pSs7NwkTab)
{
    U32 i;
    U32 Temp;

    if ( (CP_OAM_SS7_NETWORK_TAB*)NULLP == pSs7NwkTab )
    {
        CPDBGP(CP_ERR_NULLPOINTNWK);
        RETVALUE(RFAILED);
    }
    
    switch ( OprType )
    {
        case EN_CP_OPR_MOD:
        {
            break;
        }

        case EN_CP_OPR_ADD:
        {
            Temp = 0;
            for ( i = 0; i < gstCpSs7Global.NwkTabNum; i++ )
            {
                if ( pSs7NwkTab->NwId == gstCpSs7Global.NwkTab[i].NwId )
                {
                    Temp++;
                }
            }

            if ( 1 == Temp )
            {
                RETVALUE(ROK);
            }
            else
            {
                if ( ( 0 != Temp ) && ( CP_SS7_MAX_NWKTAB == gstCpSs7Global.NwkTabNum ) )
                {
                    CPDBGP(CP_ERR_RESOURCENWK);
                    RETVALUE(RFAILED);
                }

                gstCpSs7Global.NwkTab[gstCpSs7Global.NwkTabNum].BearType = pSs7NwkTab->BearType;
                gstCpSs7Global.NwkTab[gstCpSs7Global.NwkTabNum].NwApp= pSs7NwkTab->NwApp;
                gstCpSs7Global.NwkTab[gstCpSs7Global.NwkTabNum].NwId = pSs7NwkTab->NwId;
                gstCpSs7Global.NwkTab[gstCpSs7Global.NwkTabNum].SubService = pSs7NwkTab->SubService;
                gstCpSs7Global.NwkTab[gstCpSs7Global.NwkTabNum].SwType = pSs7NwkTab->SwType;
                
                gstCpSs7Global.NwkTabNum++;
            }
            break;
        }

        case EN_CP_OPR_DEL:
        {
            break;
        }

        case EN_CP_OPR_GET:
        {
            break;
        }

        case EN_CP_OPR_INVALID:
        {
            break;
        }

        default:
        {
            CPDBGP(CP_ERR_OPERATION);
            RETVALUE(RFAILED);
            break;
        }
    }
    RETVALUE(ROK);
}

U32 CpSs7SetOneSsnTab(U32 OprType, CP_OAM_SS7_SSN_TAB* pSs7SsnTab)
{
    U32 i;
    U32 Temp;

    if ( (CP_OAM_SS7_SSN_TAB*)NULLP == pSs7SsnTab )
    {
        CPDBGP(CP_ERR_NULLPOINTSSN);
        RETVALUE(RFAILED);
    }
    
    switch ( OprType )
    {
        case EN_CP_OPR_MOD:
        {
            break;
        }

        case EN_CP_OPR_ADD:
        {
            Temp = 0;
            for ( i = 0; i < gstCpSs7Global.SSNTabNum; i++ )
            {
                if ( (pSs7SsnTab->SsnIndex-1) == gstCpSs7Global.SSNTab[i].SsnIndex)
                {
                    Temp++;
                }
            }

            if ( 1 == Temp )
            {
                RETVALUE(ROK);
            }
            else
            {
                if ( ( 0 != Temp ) && ( CP_SS7_MAX_SSNTAB == gstCpSs7Global.SSNTabNum) )
                {
                    CPDBGP(CP_ERR_RESOURCESSN);
                    RETVALUE(RFAILED);
                }

                /*decrease 1 because UPTBL upIndex decrease 1*/
                gstCpSs7Global.SSNTab[gstCpSs7Global.SSNTabNum].UpIndex = pSs7SsnTab->UpIndex - 1;
                gstCpSs7Global.SSNTab[gstCpSs7Global.SSNTabNum].Ssn = pSs7SsnTab->Ssn;
                /*decrease 1 because sapid begin with 0*/
                gstCpSs7Global.SSNTab[gstCpSs7Global.SSNTabNum].SsnIndex = pSs7SsnTab->SsnIndex - 1;
                gstCpSs7Global.SSNTab[gstCpSs7Global.SSNTabNum].SsnUsr = pSs7SsnTab->SsnUsr;
                
                gstCpSs7Global.SSNTabNum++;
            }
            break;
        }

        case EN_CP_OPR_DEL:
        {
            break;
        }

        case EN_CP_OPR_GET:
        {
            break;
        }

        case EN_CP_OPR_INVALID:
        {
            break;
        }

        default:
        {
            CPDBGP(CP_ERR_OPERATION);
            RETVALUE(RFAILED);
            break;
        }
    }
    RETVALUE(ROK);
}

U32 CpSs7SetOneUpTab(U32 OprType, CP_OAM_SS7_UP_TAB* pSs7UpTab)
{
    U32 i;
    U32 Temp;

    if ( (CP_OAM_SS7_UP_TAB*)NULLP == pSs7UpTab )
    {
        CPDBGP(CP_ERR_NULLPOINTUP);
        RETVALUE(RFAILED);
    }
    
    switch ( OprType )
    {
        case EN_CP_OPR_MOD:
        {
            break;
        }

        case EN_CP_OPR_ADD:
        {
            Temp = 0;
            for ( i = 0; i < gstCpSs7Global.UPTabNum; i++ )
            {
                if ( (pSs7UpTab->UpIndex-1) == gstCpSs7Global.UPTab[i].UpIndex)
                {
                    Temp++;
                }
            }

            if ( 1 == Temp )
            {
                RETVALUE(ROK);
            }
            else
            {
                if ( ( 0 != Temp ) && ( CP_SS7_MAX_UPTAB == gstCpSs7Global.UPTabNum) )
                {
                    CPDBGP(CP_ERR_RESOURCEUP);
                    RETVALUE(RFAILED);
                }

                gstCpSs7Global.UPTab[gstCpSs7Global.UPTabNum].NwId = pSs7UpTab->NwId;
                /*decrease 1 because sapid begin with 0*/
                gstCpSs7Global.UPTab[gstCpSs7Global.UPTabNum].UpIndex = pSs7UpTab->UpIndex -1;
                gstCpSs7Global.UPTab[gstCpSs7Global.UPTabNum].Si = pSs7UpTab->Si;
                
                gstCpSs7Global.UPTabNum++;
            }
            break;
        }

        case EN_CP_OPR_DEL:
        {
            break;
        }

        case EN_CP_OPR_GET:
        {
            break;
        }

        case EN_CP_OPR_INVALID:
        {
            break;
        }

        default:
        {
            CPDBGP(CP_ERR_OPERATION);
            RETVALUE(RFAILED);
            break;
        }
    }
    RETVALUE(ROK);
}

U32 CpSs7SetOneSpcTab(U32 OprType, CP_OAM_SS7_SPC_TAB* pSs7SpcTab)
{
    U32 i;
    U32 Temp;

    if ( (CP_OAM_SS7_SPC_TAB*)NULLP == pSs7SpcTab )
    {
        CPDBGP(CP_ERR_NULLPOINTSPC);
        RETVALUE(RFAILED);
    }
    
    switch ( OprType )
    {
        case EN_CP_OPR_MOD:
        {
            break;
        }

        case EN_CP_OPR_ADD:
        {
            Temp = 0;
            for ( i = 0; i < gstCpSs7Global.SPCTabNum; i++ )
            {
                if ( pSs7SpcTab->SpcIndex== gstCpSs7Global.SPCTab[i].SpcIndex)
                {
                    Temp++;
                }
            }

            if ( 1 == Temp )
            {
                RETVALUE(ROK);
            }
            else
            {
                if ( ( 0 != Temp ) && ( CP_SS7_MAX_SPCTAB == gstCpSs7Global.SPCTabNum) )
                {
                    CPDBGP(CP_ERR_RESOURCESPC);
                    RETVALUE(RFAILED);
                }
                
                gstCpSs7Global.SPCTab[gstCpSs7Global.SPCTabNum].Spc = pSs7SpcTab->Spc;
                gstCpSs7Global.SPCTab[gstCpSs7Global.SPCTabNum].SpcIndex = pSs7SpcTab->SpcIndex;
                gstCpSs7Global.SPCTab[gstCpSs7Global.SPCTabNum].LocalFlag = pSs7SpcTab->LocalFlag;
                gstCpSs7Global.SPCTab[gstCpSs7Global.SPCTabNum].NwId = pSs7SpcTab->NwId;
                
                gstCpSs7Global.SPCTabNum++;
            }
            break;
        }

        case EN_CP_OPR_DEL:
        {
            break;
        }

        case EN_CP_OPR_GET:
        {
            break;
        }

        case EN_CP_OPR_INVALID:
        {
            break;
        }

        default:
        {
            CPDBGP(CP_ERR_OPERATION);
            RETVALUE(RFAILED);
            break;
        }
    }
    RETVALUE(ROK);
}

U32 CpComSetOneIpTab(U32 OprType, CP_OAM_COM_IP_TAB* pComIpTab)
{
    U32 i;
    U32 Temp;

    if ( (CP_OAM_COM_IP_TAB*)NULLP == pComIpTab )
    {
        CPDBGP(CP_ERR_NULLPOINTIP);
        RETVALUE(RFAILED);
    }
    
    switch ( OprType )
    {
        case EN_CP_OPR_MOD:
        {
            break;
        }

        case EN_CP_OPR_ADD:
        {
            Temp = 0;
            for ( i = 0; i < gstCpSs7Global.IPTabNum; i++ )
            {
                if ( pComIpTab->IpIndex== gstCpSs7Global.IPTab[i].IpIndex)
                {
                    Temp++;
                }
            }

            if ( 1 == Temp )
            {
                RETVALUE(ROK);
            }
            else
            {
                if ( ( 0 != Temp ) && ( CP_COM_MAX_IPTAB == gstCpSs7Global.IPTabNum) )
                {
                    CPDBGP(CP_ERR_RESOURCEIP);
                    RETVALUE(RFAILED);
                }
                
                gstCpSs7Global.IPTab[gstCpSs7Global.IPTabNum].IpIndex= pComIpTab->IpIndex;
                gstCpSs7Global.IPTab[gstCpSs7Global.IPTabNum].LocalFlag = pComIpTab->LocalFlag;
                gstCpSs7Global.IPTab[gstCpSs7Global.IPTabNum].IpAddr = pComIpTab->IpAddr;
                
                gstCpSs7Global.IPTabNum++;
            }
            break;
        }

        case EN_CP_OPR_DEL:
        {
            break;
        }

        case EN_CP_OPR_GET:
        {
            break;
        }

        case EN_CP_OPR_INVALID:
        {
            break;
        }

        default:
        {
            CPDBGP(CP_ERR_OPERATION);
            RETVALUE(RFAILED);
            break;
        }
    }
    RETVALUE(ROK);
}

U32 CpSs7GetNwTab(U32 nwId,CP_SS7_NETWORK_TAB **pNwTab)
{
   U32 i;

    for (i = 0; i < gstCpSs7Global.NwkTabNum; i++)
    {
        if ( gstCpSs7Global.NwkTab[i].NwId == nwId)
        {
            *pNwTab = &(gstCpSs7Global.NwkTab[i]);
            RETVALUE(ROK);
        }
    }

    CPDBGP(CP_ERR_INVALIDINDEXNWK);
    RETVALUE(RFAILED);
}

/* add by pangxianfeng */
U32  CpSs7GetOPC(U32 opcIdx,U32 *opc)
{
    U8 i;

    for(i=0; i<gstCpSs7Global.SPCTabNum; i++)
    {
        if( opcIdx == (U8)gstCpSs7Global.SPCTab[i].SpcIndex) 
        {
            if (1 == gstCpSs7Global.SPCTab[i].LocalFlag)
            {
                *opc = gstCpSs7Global.SPCTab[i].Spc;
                RETVALUE(ROK);
            }
            else
            {
                CPDBGP(CP_ERR_OPCINDEX);
                RETVALUE(RFAILED);
            }
            
        }
    }
    
    CPDBGP(CP_ERR_INVALIDINDEXSPC);
    RETVALUE(RFAILED);

}

/* add by pangxianfeng */
U32 CpSs7GetDPC(U32 dpcIdx,U32 *phyDpc)
{
    U8 i;

    for(i=0; i<gstCpSs7Global.SPCTabNum; i++)
    {
        if( dpcIdx == gstCpSs7Global.SPCTab[i].SpcIndex )
        {
            if ( 0 == gstCpSs7Global.SPCTab[i].LocalFlag )
            {
                *phyDpc = gstCpSs7Global.SPCTab[i].Spc;
                RETVALUE(ROK);
            }
            else
            {
                CPDBGP(CP_ERR_DPCINDEX);
                RETVALUE(RFAILED);
            }
        }
    }

   CPDBGP(CP_ERR_INVALIDINDEXSPC);
   RETVALUE(RFAILED);
}


/* chenning ���ӣ���M3UA��ʼ��Route��ʱ��Ҫ��ȡDPC��OPC��*/
/*����Route���������б��غͶԶ�֮�֣���������������DPC����OPC 2006/9/15*/
U32 CpSs7GetSPC(U32 spcIdx,U32 *spc)
{
   U32 i=0;

   for(i=0; i<gstCpSs7Global.SPCTabNum; i++)
   {
      if( spcIdx == gstCpSs7Global.SPCTab[i].SpcIndex )
      {
          *spc = gstCpSs7Global.SPCTab[i].Spc;
          RETVALUE(ROK);
      }
   }
   
   CPDBGP(CP_ERR_INVALIDINDEXSPC);
   RETVALUE(RFAILED);
}

/* chenning ���ӣ��ڳ�ʼ��ʱ��������IP����ת��ΪIPֵ 2006/9/15*/
U32 CpComGetIpAddr(U32 ipIdx, U32 *ipaddr)
{
    U32 i = 0;

    for (i = 0; i<gstCpSs7Global.IPTabNum; i++)
    {
        if ( gstCpSs7Global.IPTab[i].IpIndex == ipIdx )
        {
            *ipaddr = gstCpSs7Global.IPTab[i].IpAddr;
            RETVALUE(ROK);
        }
    }

    CPDBGP(CP_ERR_INVALIDINDEXIP);
    RETVALUE(RFAILED);
}

U32 CpComGetSrcIpAddr(U32 ipIdx, U32 *ipaddr)
{
    U32 i = 0;

    for (i = 0; i<gstCpSs7Global.IPTabNum; i++)
    {
        if ( gstCpSs7Global.IPTab[i].IpIndex == ipIdx )
        {
            if ( 1 == gstCpSs7Global.IPTab[i].LocalFlag )
            {
                *ipaddr = gstCpSs7Global.IPTab[i].IpAddr;
                RETVALUE(ROK);
            }
            else
            {
                CPDBGP(CP_ERR_LOCALIPINDEX);
                RETVALUE(RFAILED);
            }
            
        }
    }

    CPDBGP(CP_ERR_INVALIDINDEXIP);
    RETVALUE(RFAILED);
}

U32 CpComGetDesIpAddr(U32 ipIdx, U32 *ipaddr)
{
    U32 i = 0;

    for (i = 0; i<gstCpSs7Global.IPTabNum; i++)
    {
        if ( gstCpSs7Global.IPTab[i].IpIndex == ipIdx )
        {
            if ( 0 == gstCpSs7Global.IPTab[i].LocalFlag )
            {
                *ipaddr = gstCpSs7Global.IPTab[i].IpAddr;
                RETVALUE(ROK);
            }
            else
            {
                CPDBGP(CP_ERR_REMOTEIPINDEX);
                RETVALUE(RFAILED);
            }
            
        }
    }

    CPDBGP(CP_ERR_INVALIDINDEXIP);
    RETVALUE(RFAILED);
}

#endif /*CP_OAM_SUPPORT*/