/****************************************
**
**  Subsystem   : common protocols 
**  File        : sm.h
**  Created By  : 
**  Created On  : 
**  
**  Purpose: 
**  marco required by stack manager functions
**  
**  History:
**  Programmer  Date        
**  --------------- ---------- -------- ------------------------------
***************************************/
#ifndef _SM_H_
#define _SM_H_

/*#define SM_INST_0	0*/	/* map instance 0 */
#define SM_REG		0	/* memory region id */
#define SM_POOL		0	/* pool value */

#ifndef ACTVINST
#define ACTVINST 0
#endif

/* Local Define */
#define SM_SEL_LC	0	/* selector 0 (loosely-coupled) */
#define SM_SEL_TC	1	/* selector 1 (tightly-coupled) */

/* sm wait response message timer len, 1s now */
#define SM_TIMER_RES            10
#define SM_TIMER_LEN            90
#define SM_SG_TIMER_LEN         30


#endif

