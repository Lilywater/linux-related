/**********************************************************************

    Name:   sp_cfg.h - Configuration for the SCCP

    Type:   C include file

    Desc:   #define and macros for the SCCP layer Configuration

    File:   sp_cfg.h

    Sid:    sp_cfg.h - 2003/05/14

    Created by: 

**********************************************************************/
#ifndef _SP_CFG_H_
#define _SP_CFG_H_

/* Local Define */
/*#define SP_INST_0 0 /* map instance 0 */
#define SP_REG    0 /* memory region id */
#ifndef SP_POOL
#define SP_POOL 0        /* pool value */
#endif
#define SP_SEL_LC 0 /* selector 0 (loosely-coupled) */
#define SP_SEL_TC 1 /* selector 1 (tightly-coupled) */
#define SP_SEL_ST 1 /* selector 1 (tightly-coupled) */
#define SP_SEL_SI 2 /* selector 2 (tightly-coupled) */
#define SP_SEL_RA 3 /* selector 3 (tightly-coupled) */
#define SP_SEL_RN 4 /* selector 4 (tightly-coupled) */
#define SP_SEL_GA 5 /* selector 5 (tightly-coupled) */
/* Lower SAP */
#define SP_SEL_SN 1 /* selector 1 (tightly-coupled) */
#define SP_SEL_IT 2 /* selector 1 (tightly-coupled) */

#ifndef ACTVINST
#define ACTVINST 0
#endif

/**********************************************************/
/*   �궨��*/
#define MAX_SCCP_NW_ATTRI_NUM       10   /*SCCP ���������*/
#define MAX_SCCP_GT_RULE_NUM        10
#define MAX_SCCP_GT_ADDRESS_NUM     1000
#define MAX_SCCP_ROUTE_NUM          200          /* according to the mib spec */
#define MAX_SCCP_ROUTE_SSN_NUM      256
/**********************************************************/


/*---------------------SCCP initializing configure----------------------------*/ 

/* Macro define for sccp general configure */
#define SP_GEN_NMB_SAPS   10    /* Max Number of SCCP Saps (UPPER) (U8)*/
#define SP_GEN_NMB_NSAPS  10    /* Max Number of Network Saps (LOWER) (U8)*/
#define SP_GEN_NMB_ASSO   10    /* Max Number of Associations (U16)*/ 
#define SP_GEN_NUB_SSN_OF_RTE  5          /* Max number of SSNs for each route */

#define SP_GEN_NMB_ADJDPC 4   /* Max Number of Adjacent Point Codes (U16)*/
#define SP_GEN_NMB_XUD_CB 20    /* Nmb of ext. unit data Cb (CCITT92) (U16)*/
#ifdef SP_CFGMG
#define SP_GEN_MNGMNT_ON  1   /* flag to turn on management messages (Bool)*/
#define SP_GEN_MNGMNT_OFF 0   /* flag to turn off management messages (Bool)*/
#define SP_GEN_MNGMNT       SP_GEN_MNGMNT_ON   
#endif
#define SP_GEN_SOG_THRESH           1   /* OOS Grant Thresh */
#define SP_GEN_SSN_TIME_RES     10    /* Time Resolution */
#define SP_GEN_ASMB_TIME_RES    10    /* Time Resolution */
#define SP_GEN_ATK_DEC_TIME_RES 10    /* Time Resolution */
#define SP_GEN_REC_TIME_RES       10  /* Primitive recovery time Resolution */    

#define SP_MAX_RL_LVL               2     /* Macro define for sccp maximum restriction levels(RL)*/
#define SP_MAX_RSL_LVL              4     /* Macro define for sccp maximum restriction Sub levels(RSL)*/



#ifdef SPCO
#define SP_GEN_NMB_CON      5000    /* max number of connections */
#define SP_GEN_CON_THRESH   3      /* Connection Threshold */
#define SP_GEN_QUE_THRESH   3       /* Queue Threshold */
#define SP_GEN_IT_THRESH        3       /* Queue Threshold */
#define SP_GEN_CON_TIME_RES   10    /* connection Timer resolution */
/* add by shu.bu 2003/12/09 for resource audit */
#endif /* SPCO */
#ifdef SNT2
#define SP_GEN_TINT_TMR     30    /* interface timer, based on recTimeRes */
                                                  /* this timer used for repeated bind req */
#define SP_GEN_DEF_STA_ENQ_TMR  5   /* status enquiry timer based on recTimeRes */
                                                           /* used for enquiring PC status from MTP3 */
#endif


/* Macro define for sccp general configure */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
#define SP_NETWORK_DEF_SRT_TMR    (120 *SS_TICKS_SEC/SP_GEN_SSN_TIME_RES); /* default SRT timer */
#endif
#define SP_NETWORK_NI_IND           INAT_IND
#define SP_DEF_HOP_CNT                 15
#define SP_NETWORK_DEF_ATTACK_TMR   (60 *SS_TICKS_SEC/SP_GEN_SSN_TIME_RES); /* default ATTACK timer */
#define SP_NETWORK_DEF_DECAY_TMR       (60 *SS_TICKS_SEC/SP_GEN_SSN_TIME_RES); /* default DECAY timer */
#define SP_NETWORK_DEF_CONG_TMR      (60 *SS_TICKS_SEC/SP_GEN_SSN_TIME_RES); /* default CONG timer */
#ifdef SS7_JAPAN
#define SP_NETWORK_JTTMNGMNTON    FALSE
#endif

/* Macro define for sccp nsap configure */
#define SP_NSAP_MSG_LEN       4091


/* Macro define for sccp route configure */
#define SP_ROUTE_FLAG               LSP_NW_BROADBAND
#define SP_ROUTE_SSN_ACC         SP_OFFLINE

#define SP_ROUTE_ONLINE            SP_ONLINE
#define SP_ROUTE_OFFLINE          SP_OFFLINE

#define SP_SSN_ACC                    SS_ACC
#define SP_SSN_INACC                 SS_INACC


/*----------------------------------------------------------*/
extern unsigned int spCfgTbl[10];



/*-------------------------------------------------------------------------*/

typedef enum SCCP_CONFIG_QUEUE_ID
{
    SCCP_GEN_Q,
    SCCP_NETWORK_Q,
    SCCP_SAP_Q,
    SCCP_NSAP_Q,
    SCCP_ASSCO_Q,
    SCCP_DB_Q,
    SCCP_ROUTE_Q,
    SCCP_STA_Q,
    SCCP_CTRL_Q,
    SCCP_STS_Q,
    SCCP_CONFIG_Q_TOTAL_NUM
}SCCP_CONFIG_QUEUE_ID;


typedef struct _SpGenCfgTab
{
    U32        NmbNws;
    U32        NmbAsso;
    U32        NmbActns;
    U32        NmbAddrs;
    U32        NmbRtes; 
    U32        NmbXUdCb;
    U32        NmbCon;
    U32        GuaTmr;/*Default guard timer. */
    U32        RstEndTmr;/*Default restart end timer. */
}SpGenCfgTab;

typedef struct _SpNwAttrCfgTab
{
    U32           NwAttrId;
    U32           SwitchType;
    U32           SstTmr;
    U32           IgnTmr;
    U32           CrdTmr;
    U32           AsmbTmr;
    U32           FrzTmr;
    U32           ConTmr;
    U32           IasTmr;
    U32           IarTmr;
    U32           RelTmr;
    U32           RepRelTmr;
    U32           IntTmr;
    U32           RstTmr;
}SpNwAttrCfgTab;

typedef struct _SpGtRuleCfgTab
{
    U32           OprType;
    U32           RuleId;
    U32           NwId;
    U32           GtFormat;
    U32           TransType;
    U32           NumberPlan;
    U32           NatAddrInd;
    U32           StartDigit;
    U32           EndDigit;
}SpGtRuleCfgTab;

typedef struct _SpGtAddressCfgTab
{
    U32         OprType;
    U32         GtId;
    U32         NwId;
    U32         InRuleId;
    U32         StartDigit;
    U32         EndDigit;
    U8           InGtAddr[32];
    U32         SsfInd;
    U32         Ssf;
    U32         NiInd;
    U32         RteInd;
    U32         SpcInd;
    U32         SpcIndex;
    U32         SsnInd;
    U32         Ssn;
    U32         OutRuleId;
    U8           OutGtAddr[32];
    U32         ReplGt; 
}SpGtAddressCfgTab;

typedef struct _SpRouteCfgTab
{
    U32      OprType;
    U32      RteId;
    U32      SpcIndex;
    U32      NwId;
    U32      UpIndex;
    U32      SsnNum;
    U32      SsnId[5];
}SpRouteCfgTab;

typedef struct _SpRouteSsnCfgTab
{
   U32      OprType;
  U32      RteSsnId;
  U32      Ssn;
}SpRouteSsnCfgTab;

typedef struct _SpConfigData
{
  U16                      SccpGenNum;
  SpGenCfgTab              SccpGen;
  U16                      SccpNwAttriNum;
  SpNwAttrCfgTab           SccpNwAttri[MAX_SCCP_NW_ATTRI_NUM];
  U16                      SccpGtRuleNum;
  SpGtRuleCfgTab           SccpGtRule[MAX_SCCP_GT_RULE_NUM];
  U16                      SccpGtAddressNum;
  SpGtAddressCfgTab        SccpGtAddress[MAX_SCCP_GT_ADDRESS_NUM];
  U16                      SccpRouteNum;
  SpRouteCfgTab            SccpRoute[MAX_SCCP_ROUTE_NUM];
  U16                      SccpRouteSsnNum;
  SpRouteSsnCfgTab         SccpRouteSsn[MAX_SCCP_ROUTE_SSN_NUM];
}SpConfigData;

/*----------------------------------------------------------------*/
extern CmLListCp gSpSmQ[SCCP_CONFIG_Q_TOTAL_NUM];


/*----------------------------------------------------------------*/
extern SpConfigData gSpCfgData;

/*------------------------ extern function --------------------------*/
#ifdef __cplusplus
extern "C" {
#endif
extern S16 sccpGenCfg();
extern Void spHdrInit(Header *hdr);
extern U32 spGetTransId();
extern S16 sccpAddSpc(U16 nRec);
extern S16 sccpAddSsn(U16 nRec);
extern S16 sccpAddGtRule(U16 nRec);
extern S16 sccpDelGtRule(U16 nRec);
extern S16 sccpModGtRule(U16 nRec, tb_record* prow);
extern S16 sccpAddGtAddress(U16 nRec);
extern S16 sccpDelGtAddress(U16 nRec);
extern S16 sccpModGtAddress(U16 nRec, tb_record* prow);
extern S16 sccpAddRoute(U16 nRec);
extern S16 sccpDelRoute(U16 nRec);
extern S16 sccpModRoute(U16 nRec, tb_record* prow);
extern S16 sccpAddRouteSsn(U16 nRec);
extern S16 sccpDelRouteSsn(U16 nRec);
extern S16 sccpModRouteSsn(U16 nRec, tb_record* prow);
extern U8 spGetVariant( U8 swType);
extern U8 spGetSwType( U8 swType);
extern S16 ascHexAdrToBcd(LngAddrs *inpBuf, ShrtAddrs *bcdBuf);
extern U32 spGetSpcLen(U8 swType);
extern Void smSpPstInit(Pst *smSpPst);
extern S16 smSpSendReqQ(CmLList *node);

#ifdef __cplusplus
}
#endif

#endif /* _SP_CFG_H_ */

