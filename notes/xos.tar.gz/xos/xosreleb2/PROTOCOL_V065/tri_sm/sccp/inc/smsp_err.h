/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     stack manager - sccp - error
  
     Type:     C include file
  
     Desc:     Error defines required by the stack manager.
   
     File:     smsp_err.h
  
     Sid:      smsp_err.h@@/main/6_1 - Tue Jan 22 15:04:45 2002
  
     Prg:      fmg
  
*********************************************************************21*/

#ifndef __SMSPERRH_
#define __SMSPERRH_


/* defines */
  
/* management interface - SCCP error codes */

#define  ESMSPBASE   (ERRSMSP   + 0)   /* reserved */
#define  ESMSPXXX    (ESMSPBASE + 0)   /* reserved */

#define   ESMSP001      (ERRSMSP +    1)    /*   smspbdy1.c: 238 */
#define   ESMSP002      (ERRSMSP +    2)    /*   smspbdy1.c: 240 */
#define   ESMSP003      (ERRSMSP +    3)    /*   smspbdy1.c: 241 */
#define   ESMSP004      (ERRSMSP +    4)    /*   smspbdy1.c: 243 */
#define   ESMSP005      (ERRSMSP +    5)    /*   smspbdy1.c: 277 */
#define   ESMSP006      (ERRSMSP +    6)    /*   smspbdy1.c: 278 */
#define   ESMSP007      (ERRSMSP +    7)    /*   smspbdy1.c: 280 */
#define   ESMSP008      (ERRSMSP +    8)    /*   smspbdy1.c: 391 */
#define   ESMSP009      (ERRSMSP +    9)    /*   smspbdy1.c: 399 */
#define   ESMSP010      (ERRSMSP +   10)    /*   smspbdy1.c: 400 */
#define   ESMSP011      (ERRSMSP +   11)    /*   smspbdy1.c: 403 */
#define   ESMSP012      (ERRSMSP +   12)    /*   smspbdy1.c: 405 */
#define   ESMSP013      (ERRSMSP +   13)    /*   smspbdy1.c: 409 */
#define   ESMSP014      (ERRSMSP +   14)    /*   smspbdy1.c: 416 */
#define   ESMSP015      (ERRSMSP +   15)    /*   smspbdy1.c: 418 */
#define   ESMSP016      (ERRSMSP +   16)    /*   smspbdy1.c: 420 */
#define   ESMSP017      (ERRSMSP +   17)    /*   smspbdy1.c: 423 */
#define   ESMSP018      (ERRSMSP +   18)    /*   smspbdy1.c: 425 */
#define   ESMSP019      (ERRSMSP +   19)    /*   smspbdy1.c: 427 */
#define   ESMSP020      (ERRSMSP +   20)    /*   smspbdy1.c: 429 */
#define   ESMSP021      (ERRSMSP +   21)    /*   smspbdy1.c: 431 */
#define   ESMSP022      (ERRSMSP +   22)    /*   smspbdy1.c: 438 */
#define   ESMSP023      (ERRSMSP +   23)    /*   smspbdy1.c: 441 */
#define   ESMSP024      (ERRSMSP +   24)    /*   smspbdy1.c: 444 */
#define   ESMSP025      (ERRSMSP +   25)    /*   smspbdy1.c: 448 */
#define   ESMSP026      (ERRSMSP +   26)    /*   smspbdy1.c: 501 */
#define   ESMSP027      (ERRSMSP +   27)    /*   smspbdy1.c: 507 */
#define   ESMSP028      (ERRSMSP +   28)    /*   smspbdy1.c: 512 */
#define   ESMSP029      (ERRSMSP +   29)    /*   smspbdy1.c: 517 */
#define   ESMSP030      (ERRSMSP +   30)    /*   smspbdy1.c: 522 */
#define   ESMSP031      (ERRSMSP +   31)    /*   smspbdy1.c: 530 */
#define   ESMSP032      (ERRSMSP +   32)    /*   smspbdy1.c: 533 */
#define   ESMSP033      (ERRSMSP +   33)    /*   smspbdy1.c: 536 */
#define   ESMSP034      (ERRSMSP +   34)    /*   smspbdy1.c: 539 */
#define   ESMSP035      (ERRSMSP +   35)    /*   smspbdy1.c: 587 */
#define   ESMSP036      (ERRSMSP +   36)    /*   smspbdy1.c: 588 */
#define   ESMSP037      (ERRSMSP +   37)    /*   smspbdy1.c: 589 */
#define   ESMSP038      (ERRSMSP +   38)    /*   smspbdy1.c: 591 */
#define   ESMSP039      (ERRSMSP +   39)    /*   smspbdy1.c: 640 */
#define   ESMSP040      (ERRSMSP +   40)    /*   smspbdy1.c: 641 */
#define   ESMSP041      (ERRSMSP +   41)    /*   smspbdy1.c: 642 */
#define   ESMSP042      (ERRSMSP +   42)    /*   smspbdy1.c: 644 */

#define   ESMSP043      (ERRSMSP +   43)    /*   smspexms.c: 260 */

#define   ESMSP044      (ERRSMSP +   44)    /*   smspptmi.c: 413 */
#define   ESMSP045      (ERRSMSP +   45)    /*   smspptmi.c: 451 */
#define   ESMSP046      (ERRSMSP +   46)    /*   smspptmi.c: 492 */
#define   ESMSP047      (ERRSMSP +   47)    /*   smspptmi.c: 530 */

#endif /* __SMSPERRH_*/


/********************************************************************30**

         End of file:     smsp_err.h@@/main/6_1 - Tue Jan 22 15:04:45 2002

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg    1. initial release.

1.2          ---  fmg    1. text changes

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.3          ---      ash  1. Added new error codes

/main/6      ---      cp   1. New error codes.  
/main/6_1    ---      rc   1. copy right header changed
           sp001.302  rc   1. Sid correction
*********************************************************************91*/
