/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     layer manager
  
     Type:     C source file
  
     Desc:     Prototype C source code for the Layer Management
               service provider primitives that usually are supplied
               by the customer.

               This is the version used for the SCCP sample code test.
               This file was created out of sm_ptsp.c

     File:     smspbdy1.c
  
     Sid:      smspbdy1.c@@/main/9_1 - Tue Jan 22 15:05:03 2002
  
     Prg:      fmg
  
*********************************************************************21*/
  

/*
  
Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.

The following functions are provided in this file for the
layer management service user:
  
     SmMiLspStaInd      Status Indication
     SmMiLspStaCfm      Status Confirm  
     SmMiLspStsCfm      Status Indication
     StMiLstTrcInd      Trace Indication

     For SMSP_LMINT3

     SmMiLspCfgCfm      Configuration Confirm  
     SmMiLspCntrlCfm    Control Confirm

It should be noted that not all of these functions may be required
by a particular layer management service user.

It is assumed that the following functions are provided in the
layer managment service user file:
  
     SmMiLspCfgReq      Configure Request
     SmMiLspStaReq      Status Request
     SmMiLspStsReq      Statistics Request
     SmMiLspCntrlReq    Control Request
  
*/
  

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* sccp - stack management */
#include "smsp_err.h"      /* sccp - stack manager error codes */
#ifdef SPTST
#include "sp_acc.h"
#endif  
/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */
#include "lsp.x"        /* sccp - stack management */


/* local defines */
#ifdef SPTST
#define LM_GETMSG(p, m, e) { \
    S16 ret; \
    ret = SGetMsg((p)->region, (p)->pool, &(m)); \
    if (ret != ROK) \
    { \
        SLogError(0, 0, 0,  __FILE__, __LINE__, ERRCLS_DEBUG, e, 0, \
                      "SGetMsg failed"); \
        RETVALUE(ret); \
    } \
    }
#endif /* SPTST */
  
/* local typedefs */
  
/* local externs */
#ifdef SPTST
EXTERN Queue lmRxQ;
EXTERN Bool stability_tst;
EXTERN Bool spTstQuiet;
#endif
  
/* forward references */

/* functions in other modules */
  
/* public variable declarations */
  
/* private variable declarations */

PRIVATE Txt pBuf[PRNTSZE];          /* print buffer */

#ifndef SPTST
#define SPACC_V1_PRINT(a) SPrint(a)
#endif


/*
*     support functions
*/


/*
*     interface functions to layer management service user
*/

  
/*
*
*       Fun:   Status Indication
*
*       Desc:  This function is used by the SCCP to present
*              unsolicited status information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smspbdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLspStaInd
(
Pst *pst,                /* post structure */
SpMngmt *sta             /* unsolicited status */
)
#else
PUBLIC S16 SmMiLspStaInd(pst, sta)
Pst *pst;                /* post structure */
SpMngmt *sta;            /* unsolicited status */
#endif
{
   S16 i;                /* loop counter */
#ifdef SPTST
   Buffer *mBuf;         /* message buffer */
#endif /* SPTST */

   TRC2(SmMiLspStaInd)

   sprintf(pBuf, "[SMSP] SmMiLspStaInd ");
   SPACC_V1_PRINT(pBuf);

#ifdef SMSP_LMINT3
   sprintf(pBuf, "category %d, event %d, cause %d, par1 %d, par2 %d\n",
           sta->t.usta.alarm.category, sta->t.usta.alarm.event,
           sta->t.usta.alarm.cause, sta->t.usta.evtRep.evntParm[0],
           sta->t.usta.evtRep.evntParm[1]);
   SPACC_V1_PRINT(pBuf);

#ifdef SPTST
   if (!stability_tst)
   {
      LM_GETMSG(pst, mBuf, ESMSP001)
      for (i = 0; i < (S16) LSP_USTA_EP_MAX; i++)
         CMCHKPKLOG(SPkU8, sta->t.usta.evtRep.evntParm[i], mBuf, ESMSP002, pst);
      CMCHKPKLOG(cmPkCmAlarm, &sta->t.usta.alarm, mBuf, ESMSP003, pst);
      pst->event = EVTLSPSTAIND;
      CMCHKPKLOG(cmPkPst, pst, mBuf, ESMSP004, pst);

      /* queue the message */
      SQueueLast(mBuf, &lmRxQ);
   }
#endif /* SPTST */

#else
   switch(sta->t.usta.evnt)
   {
      case SPSTA_UOS:
         sprintf(pBuf, "User out of service - suid = %d\n",
                 sta->hdr.elmId.elmntInst2);
         break;

      case SPSTA_UIS:
         sprintf(pBuf, "User in service - suid = %d\n",
                 sta->hdr.elmId.elmntInst2);
         break;

      case SPSTA_RE:
         sprintf(pBuf, "Routing error\n");
         break;

      default:
          sprintf(pBuf, "[UNKNOWN EVENT = 0x%x]\n", sta->t.usta.evnt);
          break;
   }

   SPACC_V1_PRINT(pBuf);

#ifdef SPTST
   if (!stability_tst)
   {
      LM_GETMSG(pst, mBuf, ESMSP005)
      CMCHKPKLOG(SPkU16, sta->t.usta.evnt, mBuf, ESMSP006, pst);
      pst->event = EVTLSPSTAIND;
      CMCHKPKLOG(cmPkPst, pst, mBuf, ESMSP007, pst);

      /* queue the message */
      SQueueLast(mBuf, &lmRxQ);
   }
#endif /* SPTST */

#endif /* SMSP_LMINT3 */
   
   RETVALUE(ROK);
} /* SmMiLspStaInd */

  
/*
*
*       Fun:   Trace Indication
*
*       Desc:  This function is used by SCCP to present trace
*              information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smspbdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLspTrcInd
(
Pst       *pst,          /* post structure */
SpMngmt   *trc           /* trace */
)
#else
PUBLIC S16 SmMiLspTrcInd(pst, trc)
Pst       *pst;          /* post structure */
SpMngmt   *trc;          /* trace */
#endif
{
   U16 i;                /* counter */
   U16 j;                /* counter */

   TRC2(SmMiLspTrcInd)

   UNUSED(pst);

   sprintf(pBuf, "Message Trace:   Event = %1d  Length = %3d\n",
           trc->t.trc.evnt, trc->t.trc.len);
   SPrint(pBuf);

   /* We dont print characters since they are not required for 
    * interpreting the header.
    */

   for (i = 0, j = 0; i < trc->t.trc.len; i++, j++)
   {
      if (((j % 16) == 0) && (i != 0))
      {
         sprintf(pBuf + j * 3, "\n");
         SPACC_V1_PRINT(pBuf);
         j = 0;
      }
      sprintf(pBuf + j * 3, "%02x ", trc->t.trc.evntParm[i]);
   } /* for */

   sprintf (pBuf + j * 3," \n\n");
   SPrint(pBuf);
 
   RETVALUE(ROK);
} /* SmMiLspTrcInd */

  
/*
*
*       Fun:   Status Confirm
*
*       Desc:  This function is used by the SCCP to present
*              solicited status information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smspbdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLspStaCfm
(
Pst *pst,                /* post structure */
SpMngmt *sta             /* unsolicited status */
)
#else
PUBLIC S16 SmMiLspStaCfm(pst, sta)
Pst *pst;                /* post structure */
SpMngmt *sta;            /* unsolicited status */
#endif
{
#ifdef SPTST
   Buffer *mBuf;         /* message buffer */
#endif /* SPTST */
   S16 i;                /* counter */

   TRC2(SmMiLspStaCfm)

   UNUSED(sta);
   SPACC_V1_PRINT("SM: received Status Confirmation from SCCP\n");

#ifdef SPTST
   if (!stability_tst)
   {
      LM_GETMSG(pst, mBuf, ESMSP008);

      switch (sta->hdr.elmId.elmnt)
      {
         case STTSAP:    /* fall through */
         case STNSAP:
#ifdef TDS_ROLL_UPGRADE_SUPPORT
            CMCHKPKLOG(cmPkIntfVer, sta->t.ssta.s.spSta.remIntfVer, mBuf, 
                       ESMSP009, pst);
            CMCHKPKLOG(SPkU8, sta->t.ssta.s.spSta.remIntfValid, mBuf, ESMSP010,
                       pst);
            CMCHKPKLOG(cmPkIntfVer, sta->t.ssta.s.spSta.selfIntfVer, mBuf, 
                       ESMSP011, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
            CMCHKPKLOG(SPkS16, sta->t.ssta.s.spSta.status, mBuf, ESMSP012, pst);
            break;

         case STSID:   /* system Id */
            CMCHKPKLOG(cmPkSystemId, &sta->t.ssta.s.sysId, mBuf, ESMSP013, pst);
            break;
            
         case STROUT:
            for (i = (sta->t.ssta.s.spRteSta.nmbSsns - 1); i >= 0; i--)
            {
               CMCHKPKLOG(cmPkSmi, sta->t.ssta.s.spRteSta.ssnSta[i].smi, 
                          mBuf, ESMSP014, pst);
               CMCHKPKLOG(SPkU8, sta->t.ssta.s.spRteSta.ssnSta[i].status, 
                          mBuf, ESMSP015, pst);
               CMCHKPKLOG(cmPkSsn, sta->t.ssta.s.spRteSta.ssnSta[i].ssn, 
                          mBuf, ESMSP016, pst);
            }
            CMCHKPKLOG(SPkU8, sta->t.ssta.s.spRteSta.nmbSsns, 
                       mBuf, ESMSP017, pst);
            CMCHKPKLOG(cmPkSmi, sta->t.ssta.s.spRteSta.pcSta.smi, 
                       mBuf, ESMSP018, pst);
            CMCHKPKLOG(SPkU8, sta->t.ssta.s.spRteSta.pcSta.status, 
                       mBuf, ESMSP019, pst);
            CMCHKPKLOG(SPkU32, sta->t.ssta.s.spRteSta.pcSta.pc, 
                       mBuf, ESMSP020, pst);
            CMCHKPKLOG(cmPkNwId, sta->t.ssta.s.spRteSta.pcSta.nwId, 
                       mBuf, ESMSP021, pst);
            break;
         
         default:
            break;
      } /* switch (sta->hdr.elmId.elmnt) */

      CMCHKPKLOG(cmPkDateTime, &sta->t.ssta.dt, mBuf, ESMSP022, pst);

#if (SP_LMINT3 || SMSP_LMINT3)
      CMCHKPKLOG(cmPkCmStatus, &sta->cfm, mBuf, ESMSP023, pst);
#endif /* SP_LMINT3 */

      CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ESMSP024, pst);

      /* pack confirm information */
      pst->event = EVTLSPSTACFM;
      CMCHKPKLOG(cmPkPst, pst, mBuf, ESMSP025, pst);

      /* queue the message */
      SQueueLast(mBuf, &lmRxQ);
   } /* if (!stability_tst) */
#endif /* SPTST */

   RETVALUE(ROK);
} /* SmMiLspStaCfm */


/*
*
*       Fun:   Statistics Confirm
*
*       Desc:  This function is used by the MTP 2 to present
*              solicited statistics information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smspbdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLspStsCfm
(
Pst *pst,               /* post structure */
Action action,          /* action */
SpMngmt *sts            /* confirmed statistics */
)
#else
PUBLIC S16 SmMiLspStsCfm(pst, action, sts)
Pst *pst;               /* post structure */
Action action;          /* action */
SpMngmt *sts;           /* confirmed statistics */
#endif
{
#ifdef SPTST
   Buffer *mBuf;        /* message buffer */
#endif /* SPTST */

   TRC2(SmMiLspStsCfm)

   UNUSED(action);
   UNUSED(sts);

   SPACC_V1_PRINT("SM: received Statistics Confirmation from SCCP\n");

#ifdef SPTST
   if (!stability_tst)
   {
      LM_GETMSG(pst, mBuf, ESMSP026);

      switch (sts->hdr.elmId.elmnt)
      {
         case STGEN:           /* global statistics */
            CMCHKPKVERLOG(cmPkSpGLBSts, &sts->t.sts.s.spGlbSts, mBuf, 
                          ESMSP027, pst);
            break;

         case STTSAP:          /* upper sap statistics */
            CMCHKPKVERLOG(cmPkSpSAPSts, &sts->t.sts.s.spSapSts, mBuf, 
                          ESMSP028, pst);
            break;

         case STNSAP:          /* lower sap statistics */
            CMCHKPKVERLOG(cmPkSpNSAPSts, &sts->t.sts.s.spNSapSts, mBuf, 
                          ESMSP029, pst);
            break;

         case STROUT:
            CMCHKPKVERLOG(cmPkSpRTESts, &sts->t.sts.s.spRteSts, mBuf, 
                          ESMSP030, pst);
            break;

         default:

            break;
      } /* switch (sts->hdr.elmId.elmnt) */

      CMCHKPKLOG(cmPkDateTime, &sts->t.sts.dt, mBuf, ESMSP031, pst);

#if (SP_LMINT3 || SMSP_LMINT3)
      CMCHKPKLOG(cmPkCmStatus, &sts->cfm, mBuf, ESMSP032, pst);
#endif /* SP_LMINT3 */

      CMCHKPKLOG(cmPkHeader, &sts->hdr, mBuf, ESMSP033, pst);

      pst->event = EVTLSPSTSCFM;
      CMCHKPKLOG(cmPkPst, pst, mBuf, ESMSP034, pst);

      /* queue the message */
      SQueueLast(mBuf, &lmRxQ);
   }
#endif /* SPTST */

   RETVALUE(ROK);
} /* SmMiLspStsCfm */

#ifdef SMSP_LMINT3


/*
*
*       Fun:   Configuration Confirm
*
*       Desc:  This function is used by the SCCP to present
*              configuration confirmation information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smspbdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLspCfgCfm
(
Pst *pst,             /* post structure */
SpMngmt *cfm          /* confirm structure */
)
#else
PUBLIC S16 SmMiLspCfgCfm(pst, cfm)
Pst *pst;             /* post structure */
SpMngmt *cfm;         /* confirm structure */
#endif
{
#ifdef SPTST
   Buffer *mBuf;      /* message buffer */
#endif /* SPTST */

   TRC2(SmMiLspCfgCfm)

#ifdef SPTST
   if (!stability_tst)
   {
      LM_GETMSG(pst, mBuf, ESMSP035)
      CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ESMSP036, pst);
      CMCHKPKLOG(cmPkHeader, &cfm->hdr, mBuf, ESMSP037, pst);
      pst->event = EVTLSPCFGCFM;
      CMCHKPKLOG(cmPkPst, pst, mBuf, ESMSP038, pst);

      /* queue the message */
      SQueueLast(mBuf, &lmRxQ);
   }
#else
   sprintf(pBuf, "SM: Config Cfm from SCCP Proc %x with status %d, reason %d\n",
           pst->srcProcId, cfm->cfm.status, cfm->cfm.reason);
   SPACC_V1_PRINT(pBuf);
#endif /* SPTST */

   RETVALUE(ROK);
} /* SmMiLspCfgCfm */


/*
*
*       Fun:   control Confirm
*
*       Desc:  This function is used by the SCCP to present
*              control confirmation information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smspbdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLspCntrlCfm
(
Pst *pst,             /* post structure */
SpMngmt *cfm          /* confirm */
)
#else
PUBLIC S16 SmMiLspCntrlCfm(pst, cfm)
Pst *pst;             /* post structure */
SpMngmt *cfm;         /* confirm */
#endif
{
#ifdef SPTST
   Buffer *mBuf;      /* message buffer */
#endif /* SPTST */
   TRC2(SmMiLspCntrlCfm)

#ifdef SPTST
   if (!stability_tst)
   {
      LM_GETMSG(pst, mBuf, ESMSP039)
      CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ESMSP040, pst);
      CMCHKPKLOG(cmPkHeader, &cfm->hdr, mBuf, ESMSP041, pst);
      pst->event = EVTLSPCNTRLCFM;
      CMCHKPKLOG(cmPkPst, pst, mBuf, ESMSP042, pst);

      /* queue the message */
      SQueueLast(mBuf, &lmRxQ);
   }
#else

   sprintf(pBuf,"SM: recd Control Cfm from SCCP with status %d, reason %d\n",
           cfm->cfm.status, cfm->cfm.reason);
   SPACC_V1_PRINT(pBuf);
#endif /* SPTST */

   RETVALUE(ROK);
} /* SmMiLspCntrlCfm */
#endif /* SMSP_LMINT3 */


/********************************************************************30**

         End of file:     smspbdy1.c@@/main/9_1 - Tue Jan 22 15:05:03 2002

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release

1.2          ---  fmg   1. miscellaneous changes
             ---  scc   2. split sp_sm.c into this file "smspbdy1.c"
                           and "smspexms.c"
             ---  fmg   3. added some printouts.
1.3          ---  fmg   1. removed redundant function prototypes
1.4          ---  fmg   1. added ISS7_TST logic

1.5          ---  mjp   1. added cm_ss7.h and cm_ss7.x
             ---  mjp   2. changed printing format in SmMiLspStaInd
*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.6          ---      ash  1. New primtives added  for SMSP_LMINT3
                      cp   2. Function SmMiLspTrcInd added.

1.7          sp004.28 cp   1. Changes made for the new GTT framework.
             ---      vb   2. Clean up of the patches
                      cp   3. Misc mod to packing function.

/main/9      ---      cp   1. DFTHA mods.
           sp014.301  rc   2. Rolling upgrade changes: 
                           -  Packing of pst->event is replaced with packing 
                              of whole pst strucure.
                           -  Packing interface version related fields in status
                              confirm
           sp016.301  zq   3. set the event value for pst.
/main/9_1    ---        rc   1. Release 3.2 implementing requirements as per:
                              - ITU 1996
                              - Q752 (ITU 1988, 1992 and 1996)
                              - ANSI 1996
                              - GR-246-CORE, Issue 5
                              - GSM 08.06 Ver 8.0.0 Release 1999
                              - Summary doc on JT-Q711 to JT-Q714 (SCCP Japan)
                              - Audit of signalling connections.
             sp001.302  rc   1. Sid correction
*********************************************************************91*/
