/****************************************
**
**  Subsystem : common platform 
**  File    : sp_cfg.c
**  Created By  :
**  Created On  : 
**  
**  Purpose: 
**    This file contains sccp db map to lmi function
**  
**  History:
**  Programmer  Date     Rev  Description
**  --------------- ---------- -------- ------------------------------
***************************************/
#ifdef CP_OAM_SUPPORT

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_err.h"        /* common error */
#include "cm_llist.h"
#include "cm_llist.x"
#include "cm_ss7.h"        /* common ss7 */


#include "ss_err.h"        /* system services error code*/
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */


#include "lsp.h"           /* layer manager */
#include "cm_hash.h"           /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#include "sht.h"           /* SHT */


/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* common timer */
#include "cm_lib.x"        /* Common Portable Library */
#include "cm_llist.x"

#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */

#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#include "sht.x"           /* SHT */

#include "sm.h"
#include "sm.x"
#include "sp.h"
#include "sp.x"
#include "sp_err.h"
#include "xosshell.h"
#include "cp_tab_def.h"
#include "oam_interface.h"
#include "sp_cfg.h"
#include "sp_nms.h"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"
#include "sp_oam.x"

U32   gSccpTransId = 0;
CmLListCp gSpSmQ[SCCP_CONFIG_Q_TOTAL_NUM];
SpConfigData gSpCfgData;
unsigned int spCfgTbl[10]={
  APP_TABLE_ID_SS7_NWK,       /* SS7 Network Config */
  APP_TABLE_ID_SS7_UP,        /* SS7 UP Config */
  APP_TABLE_ID_SS7_SPC,       /* SS7 SPC Config */
  APP_TABLE_ID_SS7_SSN,        /* SS7 SSN Config */
  APP_TABLE_ID_SS7_SCCP_GEN,    /* SCCP General Config */
  APP_TABLE_ID_SS7_SCCP_NW_ATTR,    /* SCCP Network Attribution Config */
  APP_TABLE_ID_SS7_SCCP_GT_RULE,    /* SCCP Global Title Rule Config */
  APP_TABLE_ID_SS7_SCCP_GT_ADDR,    /* SCCP Globle Title Address Config */
  APP_TABLE_ID_SS7_SCCP_ROUTE,    /* SCCP Route Config */
  APP_TABLE_ID_SS7_SCCP_ROUTE_SSN  /* SCCP Route SSN Config */
                           };


S16 sccpGenCfg()
{
  CmLList *node;
  SpGenCfgTab *sccpGen;
  SpMngmt *spMngmt;
      
  TRC2(spGenCfg);        

  
  /* if the sccp general config data do not receive, return failure*/
  if( gSpCfgData.SccpGenNum != 1)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP General configuration error, Gen config data item num error");
    RETVALUE(RFAILED);
  }

  /* get all data for config*/
  sccpGen = &gSpCfgData.SccpGen;

  /* alloc a node for save sm msg info */
  if( ROK != smGetQNode(&node, sizeof(SpMngmt)))
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP General configuration error, alloc msg failure");
    RETVALUE(LCM_REASON_MEM_NOAVAIL);
  }

  spMngmt = (SpMngmt *)cmLListNode(node) ;
  spMngmt->hdr.msgLen = sizeof( SpMngmt);
  

  spHdrInit(&spMngmt->hdr);

  spMngmt->hdr.msgType = TCFG;                 /* configuration */
  spMngmt->hdr.elmId.elmnt = STGEN;            /* general */

#ifdef LCSPMILSP
  spMngmt->t.cfg.s.spGen.sm.selector = SP_SEL_LC;
#else
  spMngmt->t.cfg.s.spGen.sm.selector = SP_SEL_TC;
#endif

  spMngmt->t.cfg.s.spGen.sm.region = SP_REG;       /* region */
  spMngmt->t.cfg.s.spGen.sm.pool = SP_POOL;           /* pool */
  spMngmt->t.cfg.s.spGen.sm.prior = PRIOR1;                  /* priority */
  spMngmt->t.cfg.s.spGen.sm.route = RTESPEC;                  /* route */
  spMngmt->t.cfg.s.spGen.sm.dstProcId = SFndProcId();   /* destination processor id */
  spMngmt->t.cfg.s.spGen.sm.dstEnt = ENTSM;             /* dst entity   (always ENTSP) */
  spMngmt->t.cfg.s.spGen.sm.dstInst = ACTVINST;         /* dst instance (unused) */
  spMngmt->t.cfg.s.spGen.sm.srcProcId = SFndProcId();   /* source processor id */
  spMngmt->t.cfg.s.spGen.sm.srcEnt = ENTSP;            /* source entity */
  spMngmt->t.cfg.s.spGen.sm.srcInst = ACTVINST;         /* src instance (unused) */

  /* to support set initial value instead of arg:gen or the structure of
  gen difference of cfg.t.cfg.s.genCfg, set value one by one */

  /* configure general configuration */
  spMngmt->t.cfg.s.spGen.nmbNws = sccpGen->NmbNws;
  spMngmt->t.cfg.s.spGen.nmbSaps = SP_GEN_NMB_SAPS;
  spMngmt->t.cfg.s.spGen.nmbNSaps = SP_GEN_NMB_NSAPS;
  spMngmt->t.cfg.s.spGen.nmbAsso = sccpGen->NmbAsso;    /* max associations */
  spMngmt->t.cfg.s.spGen.nmbActns = sccpGen->NmbActns;    /* max actions */
  spMngmt->t.cfg.s.spGen.nmbAddrs = sccpGen->NmbAddrs;    /* max addresses */
  spMngmt->t.cfg.s.spGen.nmbRtes = sccpGen->NmbRtes;    /* max routes */
  spMngmt->t.cfg.s.spGen.nmbXUdCb = sccpGen->NmbXUdCb;   /* control block and reference */
#ifdef SP_CFGMG
  spMngmt->t.cfg.s.spGen.mngmntOn = SP_GEN_MNGMNT;              /* flag to turn on/off management*/
#endif /* SP_CFGMG */
  spMngmt->t.cfg.s.spGen.sogThresh = SP_GEN_SOG_THRESH;            /* OOS Grant Thresh */
  spMngmt->t.cfg.s.spGen.ssnTimeRes = SP_GEN_SSN_TIME_RES;      
  spMngmt->t.cfg.s.spGen.AsmbTimeRes = SP_GEN_ASMB_TIME_RES;
  spMngmt->t.cfg.s.spGen.recTimeRes = SP_GEN_REC_TIME_RES;
  spMngmt->t.cfg.s.spGen.maxRstLvl = SP_MAX_RL_LVL;
  spMngmt->t.cfg.s.spGen.maxRstSubLvl = SP_MAX_RSL_LVL;
  spMngmt->t.cfg.s.spGen.atkDecTimeRes = SP_GEN_ATK_DEC_TIME_RES;
  spMngmt->t.cfg.s.spGen.nmbCon = sccpGen->NmbCon;  /* num of simultaneous con*/   
#ifdef SP_SLR_RANGE
  spMngmt->t.cfg.s.spGen.SlrLowRange = sccpGen->NmbCon + sccpGen->NmbCon/10;/* lower range for SLR */
#endif

#ifdef SPCO
  spMngmt->t.cfg.s.spGen.conThresh = SP_GEN_CON_THRESH; /* min connection threshold */
  spMngmt->t.cfg.s.spGen.queThresh = SP_GEN_QUE_THRESH; /* min queue threshold */
  spMngmt->t.cfg.s.spGen.itThresh = SP_GEN_IT_THRESH; /* min it threshold */
  spMngmt->t.cfg.s.spGen.conTimeRes = SP_GEN_CON_TIME_RES; /* connection timer resolution */  
#endif
  spMngmt->t.cfg.s.spGen.defGuaTmr.val = sccpGen->GuaTmr * SS_TICKS_SEC/SP_GEN_CON_TIME_RES;  /* Guard timer */
  spMngmt->t.cfg.s.spGen.defGuaTmr.enb = TRUE;
  spMngmt->t.cfg.s.spGen.defRstEndTmr.val = sccpGen->RstEndTmr * SS_TICKS_SEC/SP_GEN_SSN_TIME_RES;   
  spMngmt->t.cfg.s.spGen.defRstEndTmr.enb = TRUE;  /* Restart End */
#ifdef SNT2
  spMngmt->t.cfg.s.spGen.tIntTmr.val = SP_GEN_TINT_TMR * SS_TICKS_SEC/SP_GEN_REC_TIME_RES;        /* interval timer */
  spMngmt->t.cfg.s.spGen.tIntTmr.enb = TRUE;
#if 1 /* xingzhou.xu: deletion --06/16/2006 */
 spMngmt->t.cfg.s.spGen.defStatusEnqTmr.val = SP_GEN_DEF_STA_ENQ_TMR * SS_TICKS_SEC/SP_GEN_REC_TIME_RES;
 spMngmt->t.cfg.s.spGen.defStatusEnqTmr.enb = TRUE;
#else
  spMngmt->t.cfg.s.spGen.defStatusEnqTmr.val = 0;
  spMngmt->t.cfg.s.spGen.defStatusEnqTmr.enb = FALSE;
#endif /* deletion */

#endif   

  cmLListAdd2Tail(&gSpSmQ[SCCP_GEN_Q], node);

  RETVALUE(ROK);
}

S16 sccpAddSpc(U16 nRec)
{
  CmLList                  *node;
  SpMngmt                  *spMngmt;
  SpNwCfg                  *nwCfg;
  SpNSAPCfg                *nsapCfg;
  CP_SS7_UP_TAB            *up;
  CP_SS7_SPC_TAB           *spc;
  CP_SS7_NETWORK_TAB       *network;
  SpNwAttrCfgTab           *nwAttri = NULLP;
  U32 i;

  TRC2(sccpAddSpc);        

  /* get all data for config*/
  if( nRec >= gstCpSs7Global.UPTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add spc error, up item can not find.");
    RETVALUE(LSP_REASON_MAXSAP_CFG);
  }
  up = &gstCpSs7Global.UPTab[nRec];

  if( up->Si != EN_CP_SI_SCCP)
  {
    RETVALUE(ROK);
  }

  /* find out network table item*/
  for( i = 0; i < gstCpSs7Global.NwkTabNum; i++)
  {
    if( gstCpSs7Global.NwkTab[i].NwId == up->NwId)
      break;
  }
  if( i == gstCpSs7Global.NwkTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add spc error, Network can not find.");
    RETVALUE(LSP_REASON_NW_NOTCFG);
  }
  network = &gstCpSs7Global.NwkTab[i];

  for( i = 0; i < gSpCfgData.SccpNwAttriNum; i++ )
  {
    if( gSpCfgData.SccpNwAttri[i].SwitchType == network->SwType)
    {
      nwAttri =  &gSpCfgData.SccpNwAttri[i];
      break;
    }
  }

  if ( i == gSpCfgData.SccpNwAttriNum )
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP config nw error, Network attribution can not find.");
    RETVALUE(LSP_REASON_NW_NOTCFG);
  }

  /* find out spc table item*/
  for( i = 0; i < gstCpSs7Global.SPCTabNum; i++)
  {
    if(( gstCpSs7Global.SPCTab[i].LocalFlag == TRUE)
          && ( gstCpSs7Global.SPCTab[i].NwId == up->NwId))
      break;
  }
  if( i == gstCpSs7Global.SPCTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add spc error, Spc can not find.");
    RETVALUE(LSP_REASON_NW_NOTCFG);
  }
  spc = &gstCpSs7Global.SPCTab[i];

  /* alloc a node for save sm msg info */
  if( ROK != smGetQNode(&node, sizeof(SpMngmt)))
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "Sccp add spc error configuration error, alloc Queu node failure");
    RETVALUE(LCM_REASON_MEM_NOAVAIL);
  }

  spMngmt = (SpMngmt *)cmLListNode(node) ;
  spMngmt->hdr.msgLen = sizeof( SpMngmt);

  spHdrInit(&spMngmt->hdr);

  spMngmt->hdr.msgType = TCFG;                 /* configuration */
  spMngmt->hdr.elmId.elmnt = STNW;        /* network */

  nwCfg = &spMngmt->t.cfg.s.spNw;
  nwCfg->nwId = nwAttri->NwAttrId;
  nwCfg->variant = spGetVariant(network->SwType); /* switch */
  nwCfg->pcLen = spGetSpcLen(network->SwType);  /* Dpc Length (bits) */
  nwCfg->selfPc = spc->Spc;
  nwCfg->subService = network->SubService;  /* international */
  nwCfg->defHopCnt = SP_DEF_HOP_CNT;
  if( network->SubService == SSF_INTL
      || network->SubService == SSF_SPARE)
  {
    nwCfg->niInd = INAT_IND;
  }
  else
  {
    nwCfg->niInd = NAT_IND;
  }

#ifdef SS7_JAPAN
  nwCfg->jttMngmntOn =  SP_NETWORK_JTTMNGMNTON;
#endif /* SS7_JAPAN */

  nwCfg->sioPrioImpPres = TRUE;
  if( nwCfg->sioPrioImpPres == TRUE )
  {
    nwCfg->sioPrioImp[0] = 2;
    nwCfg->sioPrioImp[1] = 4;
    nwCfg->sioPrioImp[2] = 5;
    nwCfg->sioPrioImp[3] = 7;
  }

  nwCfg->defSstTmr.val = nwAttri->SstTmr * SS_TICKS_SEC/SP_GEN_SSN_TIME_RES;
  nwCfg->defSstTmr.enb = TRUE;     /* sst timer */

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
  nwCfg->defSrtTmr.val = SP_NETWORK_DEF_SRT_TMR;
  nwCfg->defSrtTmr.enb = TRUE;      /*srt timer*/
#endif   
  nwCfg->defIgnTmr.val = nwAttri->IgnTmr*SS_TICKS_SEC/SP_GEN_SSN_TIME_RES;
  nwCfg->defIgnTmr.enb = TRUE;

  nwCfg->defCrdTmr.val = nwAttri->CrdTmr*SS_TICKS_SEC/SP_GEN_SSN_TIME_RES;
  nwCfg->defCrdTmr.enb = TRUE;

  nwCfg->defAsmbTmr.val = nwAttri->AsmbTmr*SS_TICKS_SEC/SP_GEN_SSN_TIME_RES;
  nwCfg->defAsmbTmr.enb = TRUE;

  nwCfg->defAttackTmr.val = SP_NETWORK_DEF_ATTACK_TMR;
  nwCfg->defAttackTmr.enb = TRUE;

  nwCfg->defDecayTmr.val = SP_NETWORK_DEF_DECAY_TMR;
  nwCfg->defDecayTmr.enb = TRUE;

  nwCfg->defCongTmr.val = SP_NETWORK_DEF_CONG_TMR;
  nwCfg->defCongTmr.enb = TRUE;

  nwCfg->defFrzTmr.val = nwAttri->FrzTmr*SS_TICKS_SEC/SP_GEN_SSN_TIME_RES;
  nwCfg->defFrzTmr.enb = TRUE;

  nwCfg->defConTmr.val = nwAttri->ConTmr*SS_TICKS_SEC/SP_GEN_SSN_TIME_RES;
  nwCfg->defConTmr.enb = TRUE;

  nwCfg->defIasTmr.val = nwAttri->IasTmr*SS_TICKS_SEC/SP_GEN_SSN_TIME_RES;
  nwCfg->defIasTmr.enb = TRUE;

  nwCfg->defIarTmr.val = nwAttri->IarTmr*SS_TICKS_SEC/SP_GEN_SSN_TIME_RES;
  nwCfg->defIarTmr.enb = TRUE;

  nwCfg->defRelTmr.val = nwAttri->RelTmr*SS_TICKS_SEC/SP_GEN_SSN_TIME_RES;
  nwCfg->defRelTmr.enb = TRUE;

  nwCfg->defRepRelTmr.val = nwAttri->RepRelTmr*SS_TICKS_SEC/SP_GEN_SSN_TIME_RES;
  nwCfg->defRepRelTmr.enb = TRUE;

  nwCfg->defIntTmr.val = nwAttri->IntTmr*SS_TICKS_SEC/SP_GEN_SSN_TIME_RES;
  nwCfg->defIntTmr.enb = TRUE;

  nwCfg->defRstTmr.val = nwAttri->RstTmr*SS_TICKS_SEC/SP_GEN_SSN_TIME_RES;
  nwCfg->defRstTmr.enb = TRUE;

  cmLListAdd2Tail(&gSpSmQ[SCCP_NETWORK_Q], node);


  /* alloc a node for save sm msg info */
  if( ROK != smGetQNode(&node, sizeof(SpMngmt)))
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "Sccp add up error configuration error, alloc Queu node failure");
    RETVALUE(LCM_REASON_MEM_NOAVAIL);
  }

  spMngmt = (SpMngmt *)cmLListNode(node) ;
  spMngmt->hdr.msgLen = sizeof(SpMngmt);

  spHdrInit(&spMngmt->hdr);

  spMngmt->hdr.msgType = TCFG;                 /* configuration */
  spMngmt->hdr.elmId.elmnt = STNSAP;        /* network sap*/
  spMngmt->hdr.elmId.elmntInst1 = up->UpIndex;  

  nsapCfg = &spMngmt->t.cfg.s.spNSap;

  /* configure NSAP configuration */
  nsapCfg->msgLen = SP_NSAP_MSG_LEN;  /* Maximum Msg Len */

  nsapCfg->mem.region = SP_REG;
  nsapCfg->mem.pool = SP_POOL;

  /* For TCAP user, where LCSPLISNT defined, use tight couple anyway */
#ifdef LCSPLISNT  
  nsapCfg->selector = SP_SEL_LC;    /* LC for M3ua*/
#elif (defined(SN))
  nsapCfg->selector = SP_SEL_SN;    /* LC for M3ua*/
#elif (defined(IT))
  nsapCfg->selector = SP_SEL_IT;    /* LC for M3ua*/
#endif

  nsapCfg->dstProcId = SFndProcId();  /* local procid */
  nsapCfg->prior = PRIOR2;
  nsapCfg->route = RTESPEC;

  if( network->BearType == EN_CP_NWKBEAR_MTP3)
  {
    nsapCfg->dstEnt = ENTSN;  
    nsapCfg->dstInst = ACTVINST;  
  }
  else
  {
    nsapCfg->dstEnt = ENTIT;   
    nsapCfg->dstInst = ACTVINST; 
  }
  nsapCfg->nwId = nwAttri->NwAttrId;      /* network id */
  nsapCfg->spId = up->UpIndex;

  cmLListAdd2Tail(&gSpSmQ[SCCP_NSAP_Q], node);

  RETVALUE(ROK);
}

S16 sccpAddSsn(U16 nRec)
{
  CmLList              *node;
  SpMngmt              *spMngmt;
  SpSAPCfg             *sapCfg;
  CP_SS7_SSN_TAB       *ssn;
  CP_SS7_UP_TAB        *up;
  CP_SS7_NETWORK_TAB   *network;
  SpNwAttrCfgTab       *nwAttri = NULLP;
  U16 i;
  
  TRC2(sccpAddSsn);        
  
  /* get all data for config*/
  if( nRec >= gstCpSs7Global.SSNTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add ssn error, ssn item can not find.");
    RETVALUE(LSP_REASON_MAXSSN_CFG);
  }
  ssn = &gstCpSs7Global.SSNTab[nRec];

  /* find out network table item*/
  for( i = 0; i < gstCpSs7Global.UPTabNum; i++)
  {
    if( gstCpSs7Global.UPTab[i].UpIndex == ssn->UpIndex)
        break;
  }
  
  if( i == gstCpSs7Global.UPTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add ssn error, up can not find.");
    RETVALUE(LSP_REASON_MAXSAP_CFG);
  }
  up = &gstCpSs7Global.UPTab[i];

  if( up->Si != EN_CP_SI_SCCP)
  {
    RETVALUE(ROK);
  }

  /* find out network table item*/
  for( i = 0; i < gstCpSs7Global.NwkTabNum; i++)
  {
    if( gstCpSs7Global.NwkTab[i].NwId == up->NwId)
        break;
  }
  if( i == gstCpSs7Global.NwkTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add up error, Network can not find.");
    RETVALUE(LSP_REASON_NW_NOTCFG);
  }
  network = &gstCpSs7Global.NwkTab[i];

  for( i = 0; i < gSpCfgData.SccpNwAttriNum; i++ )
  {
    if( gSpCfgData.SccpNwAttri[i].SwitchType == network->SwType)
    {
      nwAttri = &gSpCfgData.SccpNwAttri[i];
      break;
    }
  }

  if ( i == gSpCfgData.SccpNwAttriNum )
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP config nw error, Network attribution can not find.");
    RETVALUE(LSP_REASON_NW_NOTCFG);
  }

  /* alloc a node for save sm msg info */
  if( ROK != smGetQNode(&node, sizeof(SpMngmt)))
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "Sccp add ssn error configuration error, alloc Queu node failure");
    RETVALUE(LCM_REASON_MEM_NOAVAIL);
  }

  spMngmt = (SpMngmt *)cmLListNode(node);
  spMngmt->hdr.msgLen = sizeof(SpMngmt);

  spHdrInit(&spMngmt->hdr);

  spMngmt->hdr.msgType = TCFG;                 /* configuration */
  spMngmt->hdr.elmId.elmnt = STTSAP;      /* upper sap */
  spMngmt->hdr.elmId.elmntInst1 = ssn->SsnIndex;

  sapCfg = &spMngmt->t.cfg.s.spSap;

  /* configure SAP configuration */
  sapCfg->nwId = nwAttri->NwAttrId;         /* Network 1 */

  sapCfg->nmbBpc = 0; /* not support */       
  sapCfg->nmbConPc = 0; 
#ifdef LCSPUISPT
  sapCfg->selector = SP_SEL_LC;   
#elif (defined(ST))
  sapCfg->selector = SP_SEL_ST;   
#elif (defined(SI))
  sapCfg->selector = SP_SEL_SI;   
#elif (defined(RA))
  sapCfg->selector = SP_SEL_RA;   
#elif (defined(RN))
  sapCfg->selector = SP_SEL_RN;   
#elif (defined(GA))
  sapCfg->selector = SP_SEL_GA;   
#endif

  sapCfg->mem.region = SP_REG;
  sapCfg->mem.pool = SP_POOL;
  sapCfg->prior = PRIOR2;
  sapCfg->route = RTESPEC;

  cmLListAdd2Tail(&gSpSmQ[SCCP_SAP_Q], node);

  RETVALUE(ROK);
}

S16 sccpAddGtRule(U16 nRec)
{
  CmLList                *node;
  SpMngmt                *spMngmt;
  SpAssoCfg              *pAssoCfg;
  SpGtRuleCfgTab         *gtRule;
  CP_SS7_NETWORK_TAB     *network;
  U16         i;
  U8          adjFrmt;

  TRC2(sccpAddGtRule);        

  /* get all data for config*/
  if( nRec >= gSpCfgData.SccpGtRuleNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add gt rule error, rule item can not find.");
    RETVALUE(LSP_REASON_MAXASSO_CFG);
  }
  gtRule = &gSpCfgData.SccpGtRule[nRec];

  /* find out network table item*/
  for( i = 0; i < gstCpSs7Global.NwkTabNum; i++)
  {
    if( gstCpSs7Global.NwkTab[i].NwId == gtRule->NwId)
      break;
  }
  
  if( i == gstCpSs7Global.NwkTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add  gt rule error, network can not find.");
    RETVALUE(LSP_REASON_NW_NOTCFG);
  }
  network = &gstCpSs7Global.NwkTab[i];

  /* alloc a node for save sm msg info */
  if( ROK != smGetQNode(&node, sizeof(SpMngmt)))
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "Sccp add gt rule error configuration error, alloc Queu node failure");
    RETVALUE(LCM_REASON_MEM_NOAVAIL);
  }

  spMngmt = (SpMngmt *)cmLListNode(node) ;
  spMngmt->hdr.msgLen = sizeof( SpMngmt);

  spHdrInit(&spMngmt->hdr);

  spMngmt->hdr.msgType = TCFG;                 /* configuration */
  spMngmt->hdr.elmId.elmnt = STASSO;            /* general */

  pAssoCfg = &spMngmt->t.cfg.s.spAsso;

  /* configure association configuration */
  pAssoCfg->rule.sw = spGetVariant(network->SwType);
  pAssoCfg->rule.format = gtRule->GtFormat;

  adjFrmt = pAssoCfg->rule.format;
  switch (adjFrmt)
  {
    case GTFRMT_1:
      pAssoCfg->rule.formatPres = TRUE;
      pAssoCfg->rule.gt.f1.oddEvenPres = FALSE;
      pAssoCfg->rule.gt.f1.oddEven = OE_EVEN;
      pAssoCfg->rule.gt.f1.natAddrPres = TRUE; 
      pAssoCfg->rule.gt.f1.natAddr =gtRule->NatAddrInd;
      break;    
    case GTFRMT_2:
      pAssoCfg->rule.formatPres = TRUE;
      pAssoCfg->rule.gt.f2.tTypePres = TRUE;
      pAssoCfg->rule.gt.f2.tType = gtRule->TransType;
      break;
    case GTFRMT_3:
      pAssoCfg->rule.formatPres = TRUE;
      pAssoCfg->rule.gt.f3.tTypePres = TRUE;
      pAssoCfg->rule.gt.f3.tType = gtRule->TransType;
      pAssoCfg->rule.gt.f3.numPlanPres = TRUE;
      pAssoCfg->rule.gt.f3.numPlan = gtRule->NumberPlan;
      pAssoCfg->rule.gt.f3.encSchPres = FALSE; 
      pAssoCfg->rule.gt.f3.encSch = ES_UNKN;
      break;
    case GTFRMT_4:
      pAssoCfg->rule.formatPres = TRUE;
      pAssoCfg->rule.gt.f4.tTypePres = TRUE;
      pAssoCfg->rule.gt.f4.tType = gtRule->TransType;
      pAssoCfg->rule.gt.f4.numPlanPres = TRUE;
      pAssoCfg->rule.gt.f4.numPlan = gtRule->NumberPlan;
      pAssoCfg->rule.gt.f4.encSchPres = FALSE; 
      pAssoCfg->rule.gt.f4.encSch = ES_UNKN;
      pAssoCfg->rule.gt.f4.natAddrPres = TRUE; 
      pAssoCfg->rule.gt.f4.natAddr = gtRule->NatAddrInd;
      break;
      
    default:
      pAssoCfg->rule.formatPres = FALSE;
      break;
  }

    pAssoCfg->nmbActns = 1; 
    pAssoCfg->actn[0].type = SP_ACTN_FIX; /* Fixed range */
    pAssoCfg->actn[0].param.range.startDigit = gtRule->StartDigit;
    pAssoCfg->actn[0].param.range.endDigit = gtRule->EndDigit; 
    pAssoCfg->fSetType = SP_T_FUNC;

  cmLListAdd2Tail(&gSpSmQ[SCCP_ASSCO_Q], node);

  RETVALUE(ROK);
}

S16 sccpDelGtRule(U16 nRec)
{
  CmLList *node;
  SpMngmt *spMngmt;
  SpAssoCfg   *pAssoCfg;
  SpGtRuleCfgTab *gtRule;
  CP_SS7_NETWORK_TAB *network;
  U16         i;
  U8 adjFrmt;

  TRC2(sccpDelGtRule);        
  
  /* get all data for config*/
  if( nRec >= gSpCfgData.SccpGtRuleNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP del gt rule error, rule item can not find.");
    RETVALUE(LSP_REASON_MAXASSO_CFG);
  }
  gtRule = &gSpCfgData.SccpGtRule[nRec];

  /* find out network table item*/
  for( i = 0; i < gstCpSs7Global.NwkTabNum; i++)
  {
    if( gstCpSs7Global.NwkTab[i].NwId == gtRule->NwId)
      break;
  }

  if( i == gstCpSs7Global.NwkTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP del  gt rule error, network can not find.");
    RETVALUE(LSP_REASON_NW_NOTCFG);
  }
  network = &gstCpSs7Global.NwkTab[i];

  /* alloc a node for save sm msg info */
  if( ROK != smGetQNode(&node, sizeof(SpMngmt)))
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "Sccp del gt rule error configuration error, alloc Queu node failure");
    RETVALUE(LCM_REASON_MEM_NOAVAIL);
  }

  spMngmt = (SpMngmt *)cmLListNode(node) ;
  spMngmt->hdr.msgLen = sizeof( SpMngmt);

  spHdrInit(&spMngmt->hdr);

  spMngmt->hdr.msgType = TCNTRL;                 /* configuration */
  spMngmt->hdr.elmId.elmnt = STDELASSO;            /* general */

  pAssoCfg = &spMngmt->t.cntrl.cfg.spAsso;

  /* configure association configuration */
  pAssoCfg->rule.sw = spGetVariant(network->SwType);
  pAssoCfg->rule.format = gtRule->GtFormat;

  adjFrmt = pAssoCfg->rule.format;
  switch (adjFrmt)
  {
    case GTFRMT_1:
      pAssoCfg->rule.formatPres = TRUE;
      pAssoCfg->rule.gt.f1.oddEvenPres = FALSE;
      pAssoCfg->rule.gt.f1.oddEven = OE_EVEN;
      pAssoCfg->rule.gt.f1.natAddrPres = TRUE; 
      pAssoCfg->rule.gt.f1.natAddr =gtRule->NatAddrInd;
      break;    
    case GTFRMT_2:
      pAssoCfg->rule.formatPres = TRUE;
      pAssoCfg->rule.gt.f2.tTypePres = TRUE;
      pAssoCfg->rule.gt.f2.tType = gtRule->TransType;
      break;
    case GTFRMT_3:
      pAssoCfg->rule.formatPres = TRUE;
      pAssoCfg->rule.gt.f3.tTypePres = TRUE;
      pAssoCfg->rule.gt.f3.tType = gtRule->TransType;
      pAssoCfg->rule.gt.f3.numPlanPres = TRUE;
      pAssoCfg->rule.gt.f3.numPlan = gtRule->NumberPlan;
      pAssoCfg->rule.gt.f3.encSchPres = FALSE; 
      pAssoCfg->rule.gt.f3.encSch = ES_UNKN;
      break;
    case GTFRMT_4:
      pAssoCfg->rule.formatPres = TRUE;
      pAssoCfg->rule.gt.f4.tTypePres = TRUE;
      pAssoCfg->rule.gt.f4.tType = gtRule->TransType;
      pAssoCfg->rule.gt.f4.numPlanPres = TRUE;
      pAssoCfg->rule.gt.f4.numPlan = gtRule->NumberPlan;
      pAssoCfg->rule.gt.f4.encSchPres = FALSE; 
      pAssoCfg->rule.gt.f4.encSch = ES_UNKN;
      pAssoCfg->rule.gt.f4.natAddrPres = TRUE; 
      pAssoCfg->rule.gt.f4.natAddr = gtRule->NatAddrInd;
      break;
      
    default:
      pAssoCfg->rule.formatPres = FALSE;
      break;
  }

  pAssoCfg->nmbActns = 1; 
  pAssoCfg->actn[0].type = SP_ACTN_FIX; /* Fixed range */
  pAssoCfg->actn[0].param.range.startDigit = gtRule->StartDigit;
  pAssoCfg->actn[0].param.range.endDigit = gtRule->EndDigit; 
  pAssoCfg->fSetType = SP_T_FUNC;

  cmLListAdd2Tail(&gSpSmQ[SCCP_ASSCO_Q], node);

  RETVALUE(ROK);
}

S16 sccpModGtRule(U16 nRec, tb_record* prow)
{
  SpCfgGtRuleTab  *pspGtRuleCfg;
  pspGtRuleCfg = (SpCfgGtRuleTab*) prow->panytbrow;

  TRC2(sccpModGtRule);  

  sccpDelGtRule(nRec);

  if(prow->head.mask[0] & 0x04)
    gSpCfgData.SccpGtRule[nRec].NwId = pspGtRuleCfg->NwId;
  if(prow->head.mask[0] & 0x08)
    gSpCfgData.SccpGtRule[nRec].GtFormat = pspGtRuleCfg->GtFormat;
  if(prow->head.mask[0] & 0x10)
    gSpCfgData.SccpGtRule[nRec].TransType = pspGtRuleCfg->TransType;
  if(prow->head.mask[0] & 0x20)
    gSpCfgData.SccpGtRule[nRec].NumberPlan= pspGtRuleCfg->NumberPlan;
  if(prow->head.mask[0] & 0x40)
    gSpCfgData.SccpGtRule[nRec].NatAddrInd = pspGtRuleCfg->NatAddrInd;
  if(prow->head.mask[0] & 0x80)
    gSpCfgData.SccpGtRule[nRec].StartDigit = pspGtRuleCfg->StartDigit;
  if(prow->head.mask[1] & 0x01)
    gSpCfgData.SccpGtRule[nRec].EndDigit = pspGtRuleCfg->EndDigit;

  sccpAddGtRule(nRec);

  RETVALUE(ROK);
}

S16 sccpAddGtAddress(U16 nRec)
{
  CmLList                *node;
  SpMngmt                *spMngmt;
  SpAddrMapCfg           *pAddrMap;
  SpGtAddressCfgTab      *gtAddress;
  SpGtRuleCfgTab         *inGtRule = NULLP, *outGtRule = NULLP;
  CP_SS7_NETWORK_TAB     *inNetwork = NULLP  , *outNetwork = NULLP;
  CP_SS7_SPC_TAB         *spc;
  LngAddrs                inGtAddr, outGtAddr;
  U16                     i;
  U8                      adjFrmt;

  TRC2(sccpAddGtAddress);        

  cmMemset((U8 *)(&inGtAddr), 0, sizeof(inGtAddr));
  cmMemset((U8 *)(&outGtAddr), 0, sizeof(outGtAddr));

  /* get all data for config*/
  if( nRec >= gSpCfgData.SccpGtAddressNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add gt address error, rule item can not find.");
    RETVALUE(LSP_REASON_MAXADDR_CFG);
  }

  gtAddress = &gSpCfgData.SccpGtAddress[nRec];

  /* find out spc table item*/
  for( i = 0; i < gstCpSs7Global.SPCTabNum; i++)
  {
    if( gstCpSs7Global.SPCTab[i].SpcIndex == gtAddress->SpcIndex)
      break;
  }
  if( i == gstCpSs7Global.SPCTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add spc error, Spc can not find.");
    RETVALUE(LSP_REASON_NW_NOTCFG);
  }
  spc = &gstCpSs7Global.SPCTab[i];

  for( i = 0; i < gSpCfgData.SccpGtRuleNum; i++)
  {
    if( gSpCfgData.SccpGtRule[i].RuleId == gtAddress->InRuleId)
      break;
  }
  
  if( i == gSpCfgData.SccpGtRuleNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add  gt address error, gt rule can not find.");
    RETVALUE(LSP_REASON_MAXASSO_CFG);
  }
  inGtRule = &gSpCfgData.SccpGtRule[i];

  /* find out network table item*/
  for( i = 0; i < gstCpSs7Global.NwkTabNum; i++)
  {
    if( gstCpSs7Global.NwkTab[i].NwId == inGtRule->NwId)
      break;
  }
  if( i == gstCpSs7Global.NwkTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add  gt address error, network can not find.");
    RETVALUE(LSP_REASON_NW_NOTCFG);
  }
  inNetwork = &gstCpSs7Global.NwkTab[i];


  /* if RTE_GT, the output have GT code, so GT relate information must be found*/
  /* if RTE_GT and replGt is False, the output have GT code, so GT relate information must be found*/ 
  if(( gtAddress->RteInd == RTE_GT) && (FALSE == gtAddress->ReplGt))
  {

    for( i = 0; i < gSpCfgData.SccpGtRuleNum; i++)
    {
      if( gSpCfgData.SccpGtRule[i].RuleId == gtAddress->OutRuleId)
        break;
    }

    if( i == gSpCfgData.SccpGtRuleNum)
    {
      SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add  gt address error, gt rule can not find.");
      RETVALUE(LSP_REASON_MAXASSO_CFG);
    }

    outGtRule =  &gSpCfgData.SccpGtRule[i];

    /* find out network table item*/
    for( i = 0; i < gstCpSs7Global.NwkTabNum; i++)
    {
      if( gstCpSs7Global.NwkTab[i].NwId == outGtRule->NwId)
        break;
    }
    if( i == gstCpSs7Global.NwkTabNum)
    {
      SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add  gt address error, network can not find.");
      RETVALUE(LSP_REASON_NW_NOTCFG);
    }
    outNetwork = &gstCpSs7Global.NwkTab[i];
  }

  /* alloc a node for save sm msg info */
  if( ROK != smGetQNode(&node, sizeof(SpMngmt)))
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "Sccp add gt address error configuration error, alloc Queu node failure");
    RETVALUE(LCM_REASON_MEM_NOAVAIL);
  }

  spMngmt = (SpMngmt *)cmLListNode(node) ;
  spMngmt->hdr.msgLen = sizeof(SpMngmt);

  spHdrInit(&spMngmt->hdr);

  spMngmt->hdr.msgType = TCFG;                 /* configuration */
  spMngmt->hdr.elmId.elmnt = STADRMAP;            /* general */

  pAddrMap = &spMngmt->t.cfg.s.spAddrMap;

  inGtAddr.length = (U8)cmStrlen(gtAddress->InGtAddr);
  cmMemcpy(inGtAddr.strg, gtAddress->InGtAddr, inGtAddr.length);
  
  ascHexAdrToBcd(&inGtAddr, &pAddrMap->gt.addr);
    pAddrMap->gt.addr.length = (inGtAddr.length + 1) / 2;

  /* Cnfigure the Address Map, alway from the frist to the last digit, find the maximal matching */
  pAddrMap->actn.type = SP_ACTN_FIX;
  pAddrMap->actn.param.range.startDigit = gtAddress->StartDigit;
  pAddrMap->actn.param.range.endDigit = gtAddress->EndDigit;
  pAddrMap->sw = spGetVariant(inNetwork->SwType);
  /* 
  * Since the Rule we have configured dose'nt have any field configured in it
  * we dont need to fill in any fields (apart from addr) of 
  * pAddrMap->gt .
  * replGt = TRUE _now_ means replace outgoing with incoming
  */
  pAddrMap->replGt = gtAddress->ReplGt;  /* For all entries */

  /*I think the below parameters would be set by OAM. */
  pAddrMap->noCplng = FALSE;
  pAddrMap->mode = DOMINANT;
  pAddrMap->numEntity = 1;

  pAddrMap->gt.format = inGtRule->GtFormat;  
  adjFrmt = pAddrMap->gt.format;

  switch (adjFrmt)
  {
    case GTFRMT_1:
      pAddrMap->gt.gt.f1.oddEven = ((inGtAddr.length % 2) ? OE_ODD: OE_EVEN) ;
      pAddrMap->gt.gt.f1.natAddr = inGtRule->NatAddrInd;
      break;    
    case GTFRMT_2:
      pAddrMap->gt.gt.f2.tType = inGtRule->TransType;
      break;
    case GTFRMT_3:
      pAddrMap->gt.gt.f3.tType = inGtRule->TransType;
      pAddrMap->gt.gt.f3.numPlan = inGtRule->NumberPlan;
      pAddrMap->gt.gt.f3.encSch = ((inGtAddr.length % 2) ? ES_BCDODD: ES_BCDEVEN) ;
      break;
    case GTFRMT_4:
      pAddrMap->gt.gt.f4.tType = inGtRule->TransType;
      pAddrMap->gt.gt.f4.numPlan = inGtRule->NumberPlan;
      pAddrMap->gt.gt.f4.encSch = ((inGtAddr.length % 2) ? ES_BCDODD: ES_BCDEVEN) ;
      pAddrMap->gt.gt.f4.natAddr = inGtRule->NatAddrInd;
      break;
      
    default:
      break;
  }

  pAddrMap->outAddr[0].pres = TRUE;                   /* addr present */

  /* if RTE_GT, the output have GT code, so GT relate information must be found*/
  if((gtAddress->RteInd == RTE_GT)&& (FALSE == gtAddress->ReplGt))
  {
    pAddrMap->outAddr[0].sw = spGetVariant(outNetwork->SwType);   /* switch */
  }
  else
  {
    pAddrMap->outAddr[0].sw = spGetVariant(inNetwork->SwType);    /* switch */
  }         

  pAddrMap->outAddr[0].ssfPres = gtAddress->SsfInd;                     /* ssf present */
  pAddrMap->outAddr[0].ssf = gtAddress->Ssf;    /* ssf present */
  pAddrMap->outAddr[0].niInd = gtAddress->NiInd;
  pAddrMap->outAddr[0].rtgInd = gtAddress->RteInd;        /* route on gt/ssn*/
  pAddrMap->outAddr[0].pcInd = gtAddress->SpcInd;       /* pc exists */
  pAddrMap->outAddr[0].pc = spc->Spc;           /* point code */
  pAddrMap->outAddr[0].ssnInd = gtAddress->SsnInd;    /* ssn exists */
  /* when one point according to multi ssn, we have to put
  set it with the first one */
  pAddrMap->outAddr[0].ssn = gtAddress->Ssn;      /* subsystem*/
  /*outGtAddr.length = cmStrlen(gtAddress->OutGtAddr);*/

  if((pAddrMap->outAddr[0].rtgInd == RTE_GT)&&(FALSE == gtAddress->ReplGt))
  {
    pAddrMap->outAddr[0].gt.format = outGtRule->GtFormat;  
    outGtAddr.length = (U8)cmStrlen(gtAddress->OutGtAddr);

    adjFrmt = pAddrMap->gt.format;
    switch (adjFrmt)
    {
      case GTFRMT_1:
        pAddrMap->outAddr[0].gt.gt.f1.oddEven = ((outGtAddr.length % 2) ? OE_ODD: OE_EVEN);
        pAddrMap->outAddr[0].gt.gt.f1.natAddr = outGtRule->NatAddrInd;
        break;    
      case GTFRMT_2:
        pAddrMap->outAddr[0].gt.gt.f2.tType = outGtRule->TransType;
        break;
      case GTFRMT_3:
        pAddrMap->outAddr[0].gt.gt.f3.tType = outGtRule->TransType;
        pAddrMap->outAddr[0].gt.gt.f3.numPlan = outGtRule->NumberPlan;
        pAddrMap->outAddr[0].gt.gt.f3.encSch = ((outGtAddr.length % 2) ? ES_BCDODD: ES_BCDEVEN) ;
        break;
      case GTFRMT_4:
        pAddrMap->outAddr[0].gt.gt.f4.tType = outGtRule->TransType;
        pAddrMap->outAddr[0].gt.gt.f4.numPlan = outGtRule->NumberPlan;
        pAddrMap->outAddr[0].gt.gt.f4.encSch = ((outGtAddr.length % 2) ? ES_BCDODD: ES_BCDEVEN) ;
        pAddrMap->outAddr[0].gt.gt.f4.natAddr = outGtRule->NatAddrInd;
        break;
        
      default:
        break;
    }

    cmMemcpy(outGtAddr.strg, gtAddress->OutGtAddr, outGtAddr.length);
    ascHexAdrToBcd(&outGtAddr, &pAddrMap->outAddr[0].gt.addr);
    pAddrMap->outAddr[0].gt.addr.length = (outGtAddr.length + 1) / 2;
  }

  cmLListAdd2Tail(&gSpSmQ[SCCP_DB_Q], node);
  RETVALUE(ROK);
}

S16 sccpDelGtAddress(U16 nRec)
{
  CmLList               *node;
  SpMngmt               *spMngmt;
  SpAddrMapCfg          *pAddrMap;
  SpGtAddressCfgTab     *gtAddress;
  SpGtRuleCfgTab        *inGtRule = NULLP, *outGtRule = NULLP;
  CP_SS7_NETWORK_TAB    *inNetwork = NULLP  , *outNetwork = NULLP;
  CP_SS7_SPC_TAB        *spc;
  LngAddrs               inGtAddr, outGtAddr;
  U16                    i;
  U8                     adjFrmt;

  TRC2(sccpDelGtAddress);        

  cmMemset((U8 *)(&inGtAddr), 0, sizeof(inGtAddr));
  cmMemset((U8 *)(&outGtAddr), 0, sizeof(outGtAddr));

  /* get all data for config*/
  if( nRec >= gSpCfgData.SccpGtAddressNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP del gt address error, rule item can not find.");
    RETVALUE(LSP_REASON_MAXADDR_CFG);
  }
  gtAddress = &gSpCfgData.SccpGtAddress[nRec];

  /* find out spc table item*/
  for( i = 0; i < gstCpSs7Global.SPCTabNum; i++)
  {
    if( gstCpSs7Global.SPCTab[i].SpcIndex == gtAddress->SpcIndex)
      break;
  }
  if( i == gstCpSs7Global.SPCTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add spc error, Spc can not find.");
    RETVALUE(LSP_REASON_NW_NOTCFG);
  }
  spc = &gstCpSs7Global.SPCTab[i];


  for( i = 0; i < gSpCfgData.SccpGtRuleNum; i++)
  {
    if( gSpCfgData.SccpGtRule[i].RuleId == gtAddress->InRuleId)
      break;
  }
  
  if( i == gSpCfgData.SccpGtRuleNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP del  gt address error, gt rule can not find.");
    RETVALUE(LSP_REASON_MAXASSO_CFG);
  }
  inGtRule =  &gSpCfgData.SccpGtRule[i];

  /* find out network table item*/
  for( i = 0; i < gstCpSs7Global.NwkTabNum; i++)
  {
    if( gstCpSs7Global.NwkTab[i].NwId == inGtRule->NwId)
      break;
  }
  if( i == gstCpSs7Global.NwkTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP del  gt address error, network can not find.");
    RETVALUE(LSP_REASON_NW_NOTCFG);
  }
  inNetwork = &gstCpSs7Global.NwkTab[i];


  /* if RTE_GT, the output have GT code, so GT relate information must be found*/
  /* if RTE_GT and replGt is False, the output have GT code, so GT relate information must be found*/ 
  if(( gtAddress->RteInd == RTE_GT) && (FALSE == gtAddress->ReplGt))
  {
    for( i = 0; i < gSpCfgData.SccpGtRuleNum; i++)
    {
      if( gSpCfgData.SccpGtRule[i].RuleId == gtAddress->OutRuleId)
        break;
    }

    if( i == gSpCfgData.SccpGtRuleNum)
    {
      SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP del  gt address error, gt rule can not find.");
      RETVALUE(LSP_REASON_MAXASSO_CFG);
    }

    outGtRule =  &gSpCfgData.SccpGtRule[i];

    /* find out network table item*/
    for( i = 0; i < gstCpSs7Global.NwkTabNum; i++)
    {
      if( gstCpSs7Global.NwkTab[i].NwId == outGtRule->NwId)
        break;
    }
    if( i == gstCpSs7Global.NwkTabNum)
    {
      SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP del  gt address error, network can not find.");
      RETVALUE(LSP_REASON_NW_NOTCFG);
    }
    outNetwork = &gstCpSs7Global.NwkTab[i];
  }

  /* alloc a node for save sm msg info */
  if( ROK != smGetQNode(&node, sizeof(SpMngmt)))
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "Sccp del gt address error configuration error, alloc Queu node failure");
    RETVALUE(LCM_REASON_MEM_NOAVAIL);
  }

  spMngmt = (SpMngmt *)cmLListNode(node) ;
  spMngmt->hdr.msgLen = sizeof( SpMngmt);

  spHdrInit(&spMngmt->hdr);

  spMngmt->hdr.msgType = TCNTRL;                 /* configuration */
  spMngmt->hdr.elmId.elmnt = STDELADRMAP;            /* general */

  pAddrMap = &spMngmt->t.cntrl.cfg.spAddrMap;

  inGtAddr.length = (U8)cmStrlen(gtAddress->InGtAddr);
  cmMemcpy(inGtAddr.strg, gtAddress->InGtAddr, inGtAddr.length);
  
  ascHexAdrToBcd(&inGtAddr, &pAddrMap->gt.addr);
  pAddrMap->gt.addr.length = (inGtAddr.length + 1) / 2;

  /* Cnfigure the Address Map, alway from the frist to the last digit, find the maximal matching */
  pAddrMap->actn.type = SP_ACTN_FIX;
  pAddrMap->actn.param.range.startDigit = gtAddress->StartDigit;
  pAddrMap->actn.param.range.endDigit = gtAddress->EndDigit;
  pAddrMap->sw = spGetVariant(inNetwork->SwType);
  /* 
  * Since the Rule we have configured dose'nt have any field configured in it
  * we dont need to fill in any fields (apart from addr) of 
  * pAddrMap->gt .
  * replGt = TRUE _now_ means replace outgoing with incoming
  */
  pAddrMap->replGt = gtAddress->ReplGt;  /* For all entries */

  /*I think the below parameters would be set by OAM. */
  pAddrMap->noCplng = FALSE;
  pAddrMap->mode = DOMINANT;
  pAddrMap->numEntity = 1;

  pAddrMap->gt.format = inGtRule->GtFormat;  
  adjFrmt = pAddrMap->gt.format;

  switch (adjFrmt)
  {
    case GTFRMT_1:
      pAddrMap->gt.gt.f1.oddEven = ((inGtAddr.length % 2) ? OE_ODD: OE_EVEN) ;
      pAddrMap->gt.gt.f1.natAddr = inGtRule->NatAddrInd;
      break;    
    case GTFRMT_2:
      pAddrMap->gt.gt.f2.tType = inGtRule->TransType;
      break;
    case GTFRMT_3:
      pAddrMap->gt.gt.f3.tType = inGtRule->TransType;
      pAddrMap->gt.gt.f3.numPlan = inGtRule->NumberPlan;
      pAddrMap->gt.gt.f3.encSch = ((inGtAddr.length % 2) ? ES_BCDODD: ES_BCDEVEN) ;
      break;
    case GTFRMT_4:
      pAddrMap->gt.gt.f4.tType = inGtRule->TransType;
      pAddrMap->gt.gt.f4.numPlan = inGtRule->NumberPlan;
      pAddrMap->gt.gt.f4.encSch = ((inGtAddr.length % 2) ? ES_BCDODD: ES_BCDEVEN) ;
      pAddrMap->gt.gt.f4.natAddr = inGtRule->NatAddrInd;
      break;
      
    default:
      break;
  }

  pAddrMap->outAddr[0].pres = TRUE;                   /* addr present */

  /* if RTE_GT, the output have GT code, so GT relate information must be found*/
  if((gtAddress->RteInd == RTE_GT)&& (FALSE == gtAddress->ReplGt))
  {
    pAddrMap->outAddr[0].sw = spGetVariant(outNetwork->SwType);   /* switch */
  }
  else
  {
    pAddrMap->outAddr[0].sw = spGetVariant(inNetwork->SwType);    /* switch */
  }         

  pAddrMap->outAddr[0].ssfPres = gtAddress->SsfInd;                     /* ssf present */
  pAddrMap->outAddr[0].ssf = gtAddress->Ssf;    /* ssf present */
  pAddrMap->outAddr[0].niInd = gtAddress->NiInd;
  pAddrMap->outAddr[0].rtgInd = gtAddress->RteInd;        /* route on gt/ssn*/
  pAddrMap->outAddr[0].pcInd = gtAddress->SpcInd;       /* pc exists */
  pAddrMap->outAddr[0].pc = spc->SpcIndex;           /* point code */
  pAddrMap->outAddr[0].ssnInd = gtAddress->SsnInd;    /* ssn exists */
  /* when one point according to multi ssn, we have to put
    set it with the first one */
  pAddrMap->outAddr[0].ssn = gtAddress->Ssn;      /* subsystem*/
  /*outGtAddr.length = cmStrlen(gtAddress->OutGtAddr);*/

  if((pAddrMap->outAddr[0].rtgInd == RTE_GT)&&(FALSE == gtAddress->ReplGt))
  {
    pAddrMap->outAddr[0].gt.format = outGtRule->GtFormat;  
    outGtAddr.length = (U8)cmStrlen(gtAddress->OutGtAddr);

    adjFrmt = pAddrMap->gt.format;
    switch (adjFrmt)
    {
      case GTFRMT_1:
        pAddrMap->outAddr[0].gt.gt.f1.oddEven = ((outGtAddr.length % 2) ? OE_ODD: OE_EVEN);
        pAddrMap->outAddr[0].gt.gt.f1.natAddr = outGtRule->NatAddrInd;
        break;    
      case GTFRMT_2:
        pAddrMap->outAddr[0].gt.gt.f2.tType = outGtRule->TransType;
        break;
      case GTFRMT_3:
        pAddrMap->outAddr[0].gt.gt.f3.tType = outGtRule->TransType;
        pAddrMap->outAddr[0].gt.gt.f3.numPlan = outGtRule->NumberPlan;
        pAddrMap->outAddr[0].gt.gt.f3.encSch = ((outGtAddr.length % 2) ? ES_BCDODD: ES_BCDEVEN) ;
        break;
      case GTFRMT_4:
        pAddrMap->outAddr[0].gt.gt.f4.tType = outGtRule->TransType;
        pAddrMap->outAddr[0].gt.gt.f4.numPlan = outGtRule->NumberPlan;
        pAddrMap->outAddr[0].gt.gt.f4.encSch = ((outGtAddr.length % 2) ? ES_BCDODD: ES_BCDEVEN) ;
        pAddrMap->outAddr[0].gt.gt.f4.natAddr = outGtRule->NatAddrInd;
        break;
        
      default:
        break;
    }

    cmMemcpy(outGtAddr.strg, gtAddress->OutGtAddr, outGtAddr.length);
    ascHexAdrToBcd(&outGtAddr, &pAddrMap->outAddr[0].gt.addr);
    pAddrMap->outAddr[0].gt.addr.length = (outGtAddr.length + 1) / 2;
  }

  cmLListAdd2Tail(&gSpSmQ[SCCP_DB_Q], node);
  RETVALUE(ROK);
}

S16 sccpModGtAddress(U16 nRec, tb_record* prow)
{
  SpCfgGtAddressTab       *  pspGtAddrCfg;
  pspGtAddrCfg = (SpCfgGtAddressTab*) prow->panytbrow;

  TRC2(sccpModGtAddress);      

  sccpDelGtAddress(nRec);

  if(prow->head.mask[0] & 0x04)
    gSpCfgData.SccpGtAddress[nRec].NwId = pspGtAddrCfg->NwId;
  if(prow->head.mask[0] & 0x08)
    gSpCfgData.SccpGtAddress[nRec].InRuleId = pspGtAddrCfg->InRuleId;
  if(prow->head.mask[0] & 0x10)
    gSpCfgData.SccpGtAddress[nRec].StartDigit = pspGtAddrCfg->StartDigit;
  if(prow->head.mask[0] & 0x20)
    gSpCfgData.SccpGtAddress[nRec].EndDigit = pspGtAddrCfg->EndDigit;
  if(prow->head.mask[0] & 0x40)
    cmCopy(&pspGtAddrCfg->InGtAddr[0], &gSpCfgData.SccpGtAddress[nRec].InGtAddr[0], 32);
  if(prow->head.mask[0] & 0x80)
    gSpCfgData.SccpGtAddress[nRec].SsfInd = pspGtAddrCfg->SsfInd;
  if(prow->head.mask[1] & 0x01)
    gSpCfgData.SccpGtAddress[nRec].Ssf = pspGtAddrCfg->Ssf;
  if(prow->head.mask[1] & 0x02)
    gSpCfgData.SccpGtAddress[nRec].NiInd = pspGtAddrCfg->NiInd;
  if(prow->head.mask[1] & 0x04)
    gSpCfgData.SccpGtAddress[nRec].RteInd = pspGtAddrCfg->RteInd;
  if(prow->head.mask[1] & 0x08)
    gSpCfgData.SccpGtAddress[nRec].SpcInd = pspGtAddrCfg->SpcInd;
  if(prow->head.mask[1] & 0x10)
    gSpCfgData.SccpGtAddress[nRec].SpcIndex = pspGtAddrCfg->SpcIndex;
  if(prow->head.mask[1] & 0x20)
    gSpCfgData.SccpGtAddress[nRec].SsnInd = pspGtAddrCfg->SsnInd;
  if(prow->head.mask[1] & 0x40)
    gSpCfgData.SccpGtAddress[nRec].Ssn = pspGtAddrCfg->Ssn;
  if(prow->head.mask[1] & 0x80)
    gSpCfgData.SccpGtAddress[nRec].OutRuleId = pspGtAddrCfg->OutRuleId;
  if(prow->head.mask[2] & 0x01)
    cmCopy(&pspGtAddrCfg->OutGtAddr[0], &gSpCfgData.SccpGtAddress[nRec].OutGtAddr[0], 32);
  if(prow->head.mask[2] & 0x02)
    gSpCfgData.SccpGtAddress[nRec].ReplGt = pspGtAddrCfg->ReplGt;

  sccpAddGtAddress(nRec);
  
  RETVALUE(ROK);
}

S16 sccpAddRoute(U16 nRec)
{
  CmLList                 *node;
  SpMngmt                 *spMngmt;
  SpRteCfg                *rteCfg;
  SpRouteCfgTab           *route;
  SpRouteSsnCfgTab        *routeSsn;
  CP_SS7_NETWORK_TAB      *network;
  CP_SS7_UP_TAB           *up;
  CP_SS7_SPC_TAB          *spc;
  U16                      i = 0,j = 0;
  
  TRC2(sccpAddRoute);        
  
  /* get all data for config*/
  if( nRec >= gSpCfgData.SccpRouteNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add route error, route item can not find.");
    RETVALUE(LSP_REASON_MAXROUTE_CFG);
  }
  route = &gSpCfgData.SccpRoute[nRec];

  /* find out spc table item*/
  for( i = 0; i < gstCpSs7Global.SPCTabNum; i++)
  {
    if( gstCpSs7Global.SPCTab[i].SpcIndex == route->SpcIndex)
      break;
  }
  if( i == gstCpSs7Global.SPCTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add spc error, Spc can not find.");
    RETVALUE(LSP_REASON_NW_NOTCFG);
  }
  spc = &gstCpSs7Global.SPCTab[i];

  /* find out up table item*/
  for( i = 0; i < gstCpSs7Global.UPTabNum; i++)
  {
    if( gstCpSs7Global.UPTab[i].UpIndex== route->UpIndex
        && gstCpSs7Global.UPTab[i].Si == EN_CP_SI_SCCP)
      break;
  }
  if( i == gstCpSs7Global.UPTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add route error, UP can not find.");
    RETVALUE(LSP_REASON_MAXSAP_CFG);
  }
  up = &gstCpSs7Global.UPTab[i];

  /* find out network table item*/
  for( i = 0; i < gstCpSs7Global.NwkTabNum; i++)
  {
    if( gstCpSs7Global.NwkTab[i].NwId == up->NwId)
      break;
  }
  if( i == gstCpSs7Global.NwkTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add route error, network can not find.");
    RETVALUE(LSP_REASON_NW_NOTCFG);
  }
  network = &gstCpSs7Global.NwkTab[i];

  /* alloc a node for save sm msg info */
  if( ROK != smGetQNode(&node, sizeof(SpMngmt)))
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "Sccp add route error configuration error, alloc Queu node failure.");
    RETVALUE(LCM_REASON_MEM_NOAVAIL);
  }

  spMngmt = (SpMngmt *)cmLListNode(node) ;
  spMngmt->hdr.msgLen = sizeof( SpMngmt);

  spHdrInit(&spMngmt->hdr);

  spMngmt->hdr.msgType = TCFG;                 /* configuration */
  spMngmt->hdr.elmId.elmnt = STROUT;      /* lower sap */

  rteCfg = &spMngmt->t.cfg.s.spRte;

  /* configure Route configuration */
  /*
  * Routes are used either for CCITT88 or ANSI88
  * Since sccp can run with multiple variants defined,
  * and since point codes are different lengths depending

  /* The status flags for routes are as follows
  *    SP_ADJACENT: route is adjacent to this sccp
  *    SP_TRANS: route is a translator node
  *    SP_ONLINE: route is online
  */
  rteCfg->swtch = spGetSwType(network->SwType);   /* switch */
  rteCfg->dpc = spc->Spc;             /* point code */
  rteCfg->status = SP_ROUTE_OFFLINE;            /* flags */     
#if (SS7_ANS96 || SS7_BELL05)
  rteCfg->replicatedMode = DOMINANT;        /*Mode of replicate node: 
                                              DOMINANT, LOADSHARE, 
                                              DOMINANT_ALTERNATRE,
                                              LOADSHARE_ALTERNAE */
#endif

  rteCfg->nmbBpc = 0;               /* backup present, not support */
#if 0
  if( LSP_SW_ANS96 == rteCfg->swtch )
  {
       if( rteCfg->nmbBpc > 5 ) 
       {
             RETVALUE(LSP_REASON_INV_BPC_NUM);
       }
   }
   else
   {
         if(rteCfg->nmbBpc > 1)
         {
              RETVALUE(LSP_REASON_INV_BPC_NUM);
          }
    }
   
    for( i = 0; i < rteCfg->nmbBpc; i++ )
    {
         rteCfg->bpcList[i].bpc = route->Bpc[i];
       /*The front backup pc has high prior. */
       rteCfg->bpcList[i].prior = MAX_PC_PRIOR - i;
    }
#endif


  rteCfg->nmbSsns = route->SsnNum;

  for (i = 0; i < route->SsnNum; i++)
  {            
    /* find out route ssn table item*/
    for( j = 0; j< gSpCfgData.SccpRouteSsnNum; j++)
    {
      if( gSpCfgData.SccpRouteSsn[j].RteSsnId == route->SsnId[i])
        break;
    }

    if( j == gSpCfgData.SccpRouteSsnNum)
    {
      continue;
    }
    routeSsn = &gSpCfgData.SccpRouteSsn[j];
      
    rteCfg->ssnList[i].ssn = routeSsn->Ssn;  /*  subsystem */
    rteCfg->ssnList[i].status = SP_SSN_INACC;    /* subsystem inaccessible */
     
#if (SS7_ANS96 || SS7_BELL05)
    rteCfg->ssnList[i].replicatedMode = DOMINANT;       /*Mode of replicate Sub System:  
                                                          DOMINANT, LOADSHARE, 
                                                          DOMINANT_ALTERNATRE,
                                                          LOADSHARE_ALTERNAE */
#endif

    rteCfg->ssnList[i].nmbBpc = 0;  /* subsystem has backup, not support */

    rteCfg->ssnList[i].nmbConPc = 0;     /* concerned pc, not support */
  }   

  /*rteCfg->nmbSsns = k;*/                  /*  i  subsystems */
  rteCfg->nSapId = up->UpIndex;   /* nSapId */
  rteCfg->flag = SP_ROUTE_FLAG;     /* flag */

  cmLListAdd2Tail(&gSpSmQ[SCCP_ROUTE_Q], node);
  RETVALUE(ROK);
}

S16 sccpDelRoute(U16 nRec)
{
  CmLList                 *node;
  SpMngmt                 *spMngmt;
  SpDelRteCfg             *rteCfg;
  SpRouteCfgTab           *route;
  CP_SS7_NETWORK_TAB      *network;
  CP_SS7_UP_TAB           *up;
  CP_SS7_SPC_TAB          *spc;
  U16 i;

  TRC2(sccpDelRoute);        
  
  /* get all data for config*/
  if( nRec >= gSpCfgData.SccpRouteNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP del route error, route item can not find.");
    RETVALUE(LSP_REASON_MAXROUTE_CFG);
  }
  route = &gSpCfgData.SccpRoute[nRec];

  /* find out spc table item*/
  for( i = 0; i < gstCpSs7Global.SPCTabNum; i++)
  {
    if( gstCpSs7Global.SPCTab[i].SpcIndex == route->SpcIndex)
      break;
  }
  if( i == gstCpSs7Global.SPCTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP add spc error, Spc can not find.");
    RETVALUE(LSP_REASON_NW_NOTCFG);
  }
  spc = &gstCpSs7Global.SPCTab[i];

  /* find out up table item*/
  for( i = 0; i < gstCpSs7Global.UPTabNum; i++)
  {
    if( gstCpSs7Global.UPTab[i].UpIndex== route->UpIndex
        && gstCpSs7Global.UPTab[i].Si == EN_CP_SI_SCCP)
      break;
  }
  if( i == gstCpSs7Global.UPTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP del route error, UP can not find.");
    RETVALUE(LSP_REASON_MAXSAP_CFG);
  }
  up = &gstCpSs7Global.UPTab[i];

  /* find out network table item*/
  for( i = 0; i < gstCpSs7Global.NwkTabNum; i++)
  {
    if( gstCpSs7Global.NwkTab[i].NwId == up->NwId)
      break;
  }
  if( i == gstCpSs7Global.NwkTabNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP del route error, network can not find.");
    RETVALUE(LSP_REASON_NW_NOTCFG);
  }
  network = &gstCpSs7Global.NwkTab[i];

  /* alloc a node for save sm msg info */
  if( ROK != smGetQNode(&node, sizeof(SpMngmt)))
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "Sccp del route error configuration error, alloc Queu node failure.");
    RETVALUE(LCM_REASON_MEM_NOAVAIL);
  }

  spMngmt = (SpMngmt *)cmLListNode(node) ;
  spMngmt->hdr.msgLen = sizeof( SpMngmt);

  spHdrInit(&spMngmt->hdr);

  spMngmt->hdr.msgType = TCNTRL;                 /* configuration */
  spMngmt->hdr.elmId.elmnt = STDELROUT;     /* lower sap */

  rteCfg = &spMngmt->t.cntrl.cfg.spDelRte;

  /* configure Route configuration */
  /*
  * Routes are used either for CCITT88 or ANSI88
  * Since sccp can run with multiple variants defined,
  * and since point codes are different lengths depending
  * on variant, there can be no overlap. They are differentiated
  * by the switch element.
  */

  /* The status flags for routes are as follows
  *    SP_ADJACENT: route is adjacent to this sccp
  *    SP_TRANS: route is a translator node
  *    SP_ONLINE: route is online
  */
  rteCfg->nSapId = up->UpIndex;
  rteCfg->dpc = spc->Spc;             /* point code */
  rteCfg->ssnPres = FALSE;                  /*  i  subsystems */

  cmLListAdd2Tail(&gSpSmQ[SCCP_ROUTE_Q], node);
  RETVALUE(ROK);
}

S16 sccpModRoute(U16 nRec, tb_record* prow)
{
  SpCfgRouteTab   *pspRouteCfg;
  pspRouteCfg = (SpCfgRouteTab*) prow->panytbrow;
  
  TRC2(sccpModRoute);        

  sccpDelRoute(nRec);
  
  if(prow->head.mask[0] & 0x04)
    gSpCfgData.SccpRoute[nRec].SpcIndex = pspRouteCfg->SpcIndex;
  if(prow->head.mask[0] & 0x08)
    gSpCfgData.SccpRoute[nRec].NwId = pspRouteCfg->NwId;
  if(prow->head.mask[0] & 0x10)
    gSpCfgData.SccpRoute[nRec].UpIndex = pspRouteCfg->UpIndex;
  if(prow->head.mask[0] & 0x20)
    gSpCfgData.SccpRoute[nRec].SsnNum = pspRouteCfg->SsnNum;
  if(prow->head.mask[0] & 0x40)
    gSpCfgData.SccpRoute[nRec].SsnId[0] = pspRouteCfg->SsnIndex1;
  if(prow->head.mask[0] & 0x80)
    gSpCfgData.SccpRoute[nRec].SsnId[1] = pspRouteCfg->SsnIndex2;
  if(prow->head.mask[1] & 0x01)
    gSpCfgData.SccpRoute[nRec].SsnId[2] = pspRouteCfg->SsnIndex3;
  if(prow->head.mask[1] & 0x02)
    gSpCfgData.SccpRoute[nRec].SsnId[3] = pspRouteCfg->SsnIndex4;
  if(prow->head.mask[1] & 0x04)
    gSpCfgData.SccpRoute[nRec].SsnId[4] = pspRouteCfg->SsnIndex5;

  sccpAddRoute(nRec);

  RETVALUE(ROK);
}

S16 sccpAddRouteSsn(U16 nRec)
{
  TRC2(sccpAddRouteSsn);   
  RETVALUE(ROK);
}

S16 sccpDelRouteSsn(U16 nRec)
{
  TRC2(sccpDelRouteSsn);   
  RETVALUE(ROK);
}

S16 sccpModRouteSsn(U16 nRec, tb_record* prow)
{
  SpCfgRouteSsnTab  *pspRouteSsnCfg;
  SpRouteSsnCfgTab   *routeSsn;
  U16 i, j;
  S16 ret = ROK;

  pspRouteSsnCfg = (SpCfgRouteSsnTab*) prow->panytbrow;

  TRC2(sccpModRouteSsn);        

  /* get all data for config*/
  if( nRec >= gSpCfgData.SccpRouteSsnNum)
  {
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP modify route ssn error, route ssn item can not find.");
    RETVALUE(LSP_REASON_MAXRTESSN_CFG);
  }
  routeSsn = &gSpCfgData.SccpRouteSsn[nRec];

  /* find out route table item*/
  for( i = 0; i < gSpCfgData.SccpRouteNum; i++)
  {
    for( j = 0; j < gSpCfgData.SccpRoute[i].SsnNum; j++)
    {
      if( gSpCfgData.SccpRoute[i].SsnId[j] == routeSsn->RteSsnId )
        break;
    }
    if(j == gSpCfgData.SccpRoute[i].SsnNum)
    {
      continue;
    }
    ret = sccpDelRoute(i);
    if( ROK != ret )
    {
      SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP modify route ssn, delete route error.");
    }

    if(prow->head.mask[0] & 0x04)
      gSpCfgData.SccpRouteSsn[nRec].Ssn = pspRouteSsnCfg->Ssn;

    ret = sccpAddRoute(i);
    if( ROK != ret )
    {
      SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "SCCP modify route ssn, add route error.");
    }
  }

  RETVALUE(ret);
}


Void spHdrInit(Header *hdr) 
{

  TRC2(spHdrInit);

  hdr->elmId.elmnt = 0;
  hdr->elmId.elmntInst1 = 0;
  hdr->elmId.elmntInst2 = 0;
  hdr->elmId.elmntInst3 = 0;
  hdr->entId.ent = ENTSP;
  hdr->entId.inst = ACTVINST;
  hdr->seqNmb = 0;
  hdr->version = 0;
  hdr->msgType = 0;
  hdr->msgLen = sizeof(SpMngmt);
#ifdef SP_LMINT3
  hdr->transId = spGetTransId();

#ifdef LCSMSPMILSP
  hdr->response.selector = SP_SEL_LC; /* LC */
#else
  hdr->response.selector = SP_SEL_TC; /* TC */
#endif
  hdr->response.mem.region = SP_REG;
  hdr->response.mem.pool = SP_POOL;
  hdr->response.route = RTESPEC;
  hdr->response.prior = PRIOR1;
#endif /* SP_LMINT3 */
   
  RETVOID;
}


U32 spGetTransId()
{
  return gSccpTransId++;
}

/********************************************************************************************************
  Function: smSpSendReqQ() 
  Description: sccp get msg buffer from sm queue, and send it out
  Calls:
  Called By: 
  Input:   smMsg: msg buffer get from sm queue 
               
  Output:  send LSP message to SP ENTITY

  
  Return:   ROK:success; 
                RFAILED: failure
  Others:
 ********************************************************************************************************/
S16 smSpSendReqQ(CmLList *node)
{
  Pst smSpPst;
  Header *msgHeader;
  S16 ret = ROK;
 
  TRC2(smSpSendReqQ);      
  msgHeader = (Header *)cmLListNode(node);

  smSpPstInit(&smSpPst);
  switch(msgHeader->msgType)
  {
    case TCFG:
      ret = SmMiLspCfgReq(&smSpPst, (SpMngmt *)cmLListNode(node));
      break;
    case TCNTRL:
      ret = SmMiLspCntrlReq(&smSpPst, (SpMngmt *)cmLListNode(node));
      break;
    case TSTS:
      ret = SmMiLspStsReq(&smSpPst, NOZEROSTS, (SpMngmt *)cmLListNode(node));
      break;
    case TSSTA:
      ret = SmMiLspStaReq(&smSpPst, (SpMngmt *)cmLListNode(node));
      break;
    default:
      RETVALUE(RFAILED);
  }

  RETVALUE(ret);
}

Void smSpPstInit(Pst *smSpPst)
{
  TRC2(smSpPstInit);
  
  cmMemset((U8 *)smSpPst, 0, sizeof(Pst));
  
#ifdef LCSMSPMILSP
  smSpPst->selector = SP_SEL_LC;
#else
  smSpPst->selector = SP_SEL_TC;
#endif
  
  smSpPst->event = 0;
  smSpPst->region = SP_REG;       /* region */
  smSpPst->pool = SP_POOL;           /* pool */
  smSpPst->prior = PRIOR1;                  /* priority */
  smSpPst->route = RTESPEC;                  /* route */
  smSpPst->dstProcId = SFndProcId();   /* destination processor id */
  smSpPst->dstEnt = ENTSP;             /* dst entity   (always ENTSP) */
  smSpPst->dstInst = ACTVINST;         /* dst instance (unused) */
  smSpPst->srcProcId = SFndProcId();   /* source processor id */
  smSpPst->srcEnt = ENTSM;            /* source entity */
  smSpPst->srcInst = ACTVINST;         /* src instance (unused) */
  
  RETVOID;
}


U8 spGetVariant( U8 swType)
{
  U8 spSwType;
  
  switch(swType)
  {
    case EN_CP_SW_ANSI88:
    case EN_CP_SW_ANSI92:
    case EN_CP_SW_ANSI96:
      spSwType = LSP_SW_ANS;
      break;
    case EN_CP_SW_CHINA:
      spSwType = LSP_SW_CHINA;
      break;
    case EN_CP_SW_ITU88:
    case EN_CP_SW_ITU92:
    case EN_CP_SW_ITU96:
      spSwType = LSP_SW_ITU;
      break;
    case EN_CP_SW_TTC:
      spSwType = SW_JAPAN;
      break;
    default:
      spSwType = LSP_SW_CHINA;                   
      break;
  }
  return spSwType;
}


/********************************************************************************************************
                         for Sccp Route configure 
********************************************************************************************************/
U8 spGetSwType( U8 swType)
{
  U8 spSwType;
  
  switch( swType)
  {
    case EN_CP_SW_ANSI88:
      spSwType = LSP_SW_ANS88;
      break;
    case EN_CP_SW_ANSI92:
      spSwType = LSP_SW_ANS92;
      break;
    case EN_CP_SW_ANSI96:
      spSwType = LSP_SW_ANS96;
      break;
    case EN_CP_SW_CHINA:
      spSwType = LSP_SW_CHINA;
      break;
    case EN_CP_SW_ITU88:
      spSwType = LSP_SW_ITU88;
      break;
    case EN_CP_SW_ITU92:
      spSwType = LSP_SW_ITU92;
      break;
    case EN_CP_SW_TTC:
      spSwType = SW_JAPAN;
#ifdef SS7_ITU96
    case EN_CP_SW_ITU96:
      spSwType = LSP_SW_ITU96;
      break;
#endif            
    default:
      spSwType = SW_CHINA;            
      break;
  }
  return spSwType;
}

/********************************************************************************************************
  Function: ascHexAdrToBcd() 
  Description: convert the string to BCD code
  Calls:

  
  Return:   ROK:success; 
                RFAILED: failure
  Others:
 ********************************************************************************************************/
S16 ascHexAdrToBcd(LngAddrs *inpBuf, ShrtAddrs *bcdBuf)        /* bcd buffer */
{
  REG1 U8 c;
  REG2 U8 i;
  REG3 U8 *src;
  REG4 U8 *dst;
  S16 d;

  TRC2(cmAscHexAdrToBcd)

  src = inpBuf->strg;
  dst = bcdBuf->strg;

  /* sanity check */
  if (inpBuf->length > LNGADRLEN)
    RETVALUE(RFAILED);

  for (i = inpBuf->length; i; i--)
  {
    d = 0;
    if (!cmIsANumber(&d, c = *src++, (S16) BASE16))
      RETVALUE(RFAILED);
    *dst = (U8)d;
    i--;
    if (!i)
    {
      /* modified by shu.bu 2004/04/21 to fill the spare with 0000 
         instead of 1111 */
      #if 0
      *dst |= (U8)0xf0;
      #else
      *dst &= (U8)0x0f;
      #endif
      break;
    }
    if (!cmIsANumber(&d, c = *src++, (S16) BASE16))
      RETVALUE(RFAILED);
    *dst++ |= (U8) (d << 4);
  }
  bcdBuf->length = (U8) (inpBuf->length % 2) ?
    (U8)((U8)(inpBuf->length + 1)/2) : (U8)(inpBuf->length/2);
  RETVALUE(ROK);
}

U32 spGetSpcLen(U8 swType)
{
  U32 spcLen;
  
  switch( swType)
  {
    case EN_CP_SW_ANSI88:
    case EN_CP_SW_ANSI92:
    case EN_CP_SW_ANSI96:
    case EN_CP_SW_CHINA:
      spcLen = DPC24;
      break;
    case EN_CP_SW_ITU88:
    case EN_CP_SW_ITU92:
    case EN_CP_SW_ITU96:
      spcLen = DPC14;
      break;
    case EN_CP_SW_TTC:
      spcLen = DPC16;
      break;
    default:
      spcLen = DPC_DEFAULT;                   
      break;
  }

  return spcLen;
}


#endif

