/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     layer manager interface with SCCP
  
     Type:     C source file
  
     Desc:     Prototype C source code for the Layer Management
               interface that usually is supplied by the customer.

               This is the version used for the SCCP sample code test.
               This file was created out of sm_ptsp.c

     File:     smspexms.c
  
     Sid:      smspexms.c@@/main/7_1 - Tue Jan 22 15:05:32 2002
  
     Prg:      fmg
  
*********************************************************************21*/
  

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* sccp - stack management */
#include "smsp_err.h"      /* sccp - stack manager error codes */
  
/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */
#include "lsp.x"           /* sccp - stack management */


/* local defines */
  
/* local typedefs */
  
/* local externs */
  
/* functions in other modules */
#ifdef ZP
EXTERN S16 smZpActvTsk ARGS((Pst *pst, Buffer *mBuf));
EXTERN S16 smZpActvInit ARGS((Ent ent, Inst inst, Region region, 
                                         Reason reason));
#endif  /* ZP */
  
/* public variable declarations */
  
/* private variable declarations */


/*
*     support functions
*/


/*
*     interface functions to layer management service user
*/

#ifdef MS       /* mos */

/*
*
*       Fun:   Status Indication
*
*       Desc:  This function is used by the mos to present unsolicited
*              status information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smspexms.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MMSStaInd
(
Mngmt *sta             /* unsolicited status */
)
#else
PUBLIC S16 MMSStaInd(sta)
Mngmt *sta;            /* unsolicited status */
#endif
{
   TRC2(MMSStaInd)
   RETVALUE(ROK);
} /* end of MMSStaInd */


/*
*
*       Fun:   Trace Indication
*
*       Desc:  This function is used by the mos to present trace
*              information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smspexms.c
*
*/
  
#ifdef ANSI
PUBLIC S16 MMSTrcInd
(
SpMngmt *trc             /* trace */
)
#else
PUBLIC S16 MMSTrcInd(trc)
SpMngmt *trc;            /* trace */
#endif
{
   TRC2(MMSTrcInd)
   RETVALUE(ROK);
} /* end of MMSTrcInd */
#endif



/*
*
*       Fun:    activate task
*
*       Desc:   Processes received event from SCCP
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   smspexms.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smSpActvTsk
(
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 smSpActvTsk(pst, mBuf)
Pst *pst;
Buffer *mBuf;               /* message buffer */
#endif
{
   TRC3(smSpActvTsk)

   switch(pst->event)
   {
#ifdef LCSMSPMILSP
      case EVTLSPSTSCFM:             /* Statistics Confirm */
         cmUnpkLspStsCfm(SmMiLspStsCfm, pst, mBuf);
         break;
      case EVTLSPSTAIND:             /* Status Indication */
         cmUnpkLspStaInd(SmMiLspStaInd, pst, mBuf);
         break;
      case EVTLSPSTACFM:             /* Status Confirm */
         cmUnpkLspStaCfm(SmMiLspStaCfm, pst, mBuf);
         break;
      case EVTLSPTRCIND:
         cmUnpkLspTrcInd(SmMiLspTrcInd, pst, mBuf);
         break;
#ifdef SMSP_LMINT3 
      case EVTLSPCFGCFM:             /* config Confirm */
         cmUnpkLspCfgCfm(SmMiLspCfgCfm, pst, mBuf);
         break;
      case EVTLSPCNTRLCFM:           /* control Confirm */
         cmUnpkLspCntrlCfm(SmMiLspCntrlCfm, pst, mBuf);
         break;
#endif /* SMSP_LMINT3 */
#endif
#ifdef ZP
      default:
         /* pass it to PSF */
         smZpActvTsk(pst, mBuf);
         break;
#else
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
             __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal)ESMSP043,
             ERRZERO, "PtMiLspCfgReq () Failed"); 
#endif
         break;
#endif /* ZP */
   }
   SExitTsk();
   RETVALUE(ROK);
} /* end of smSpActvTsk */

  
/*
*
*       Fun:   Activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smspexms.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smSpActvInit
(
Ent ent,                      /* entity */
Inst inst,                    /* instance */
Region region,                /* region */
Reason reason                 /* reason */
)
#else
PUBLIC S16 smSpActvInit(ent, inst, region, reason)
Ent ent;                      /* entity */
Inst inst;                    /* instance */
Region region;                /* region */
Reason reason;                /* reason */
#endif
{
   TRC3(smSpActvInit)

#ifdef ZP
   smZpActvInit(ent, inst, region, reason);
#else
   UNUSED(ent);
   UNUSED(inst);
   UNUSED(region);
   UNUSED(reason);
#endif 

   RETVALUE(ROK);
} /* end of smSpActvInit */


/********************************************************************30**

         End of file:     smspexms.c@@/main/7_1 - Tue Jan 22 15:05:32 2002

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release

1.2          ---  fmg   1. miscellaneous changes
             ---  scc   2. split sp_sm.c into this file "smspexms.c"
                           and "smspbdy1.c"
             ---  fmg   3. removed redundant function prototypes

1.3          ---  mjp   1. replaced  old error function with SPLOGERROR
             ---  mjp   2. added cm_ss7.h and cm_ss7.x
*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.4          ---      ash  1. changes for SMSP_LMINT3
                           2. Unpacking functions fixed for StaInd/StaCfm/
                              StsCfm
             sp009.27      3. Changes for patch updated 
                      cp   4. Removed the unpacking functions as required 
                              by TCO0001.
                           5. Added code for handling EVTLSPTRCIND event.

1.5          sp004.28 cp   1. Added break in the switch in smSpActvTsk.
1.6          ---      vb   1. Clean up of the patches

/main/7      ---      cp   1. DFTHA mods.
/main/7_1    ---      rc   1. copy right header changed
           sp001.302  rc   1. Sid correction
*********************************************************************91*/
