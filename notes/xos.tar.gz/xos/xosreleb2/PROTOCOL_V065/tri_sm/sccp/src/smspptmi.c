/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

  
/********************************************************************20**
  
     Name:     stack manager - portable sccp
  
     Type:     C source file
  
     Desc:     C source code for the sccp layer management
               service user primitives used in loosely coupled
               systems.
 
     File:     smspptmi.c
  
     Sid:      smspptmi.c@@/main/10 - Tue Jan 22 15:05:44 2002
   
     Prg:      fmg
  
*********************************************************************21*/
 

/*
  
Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.
 
The following functions are provided in this file:
 
     SmMiLspCfgReq      Configure Request
     SmMiLspStaReq      Status Request
     SmMiLspStsReq      Statistics Request
     SmMiLspCntrlReq    Control Request

It is assumed that the following functions are provided in the
layer managment service provider file:
 
     SmMiLspStaInd        Status Indication
     SmMiLspStaCfm        Status Confirm
     SmMiLspStsCfm        Statistics Confirm
 
*/   
  

/*
*     This software may be used with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000030     SS7 - SCCP
*
*/


/* header include files (.h) */
  
#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
 
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer management, sccp */
#include "spt.h"           /* sccp layer */
#include "smsp_err.h"      /* sccp - stack manager error codes */


/* header/extern include files (.x) */
  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */
#include "lsp.x"           /* layer management, sccp */


/* local defines */
 
#define MAXSPMI         3

/* local typedefs */
  
/* local externs */
/* sp035.302 - addition - following line added for removal of compilation
 * warning */
#if (!defined(LCSMSPMILSP) || !defined(SP))
/* forward references */
PRIVATE S16 PtMiLspCfgReq   ARGS((Pst *pst, SpMngmt *cfg ));
PRIVATE S16 PtMiLspStaReq   ARGS((Pst *pst, SpMngmt *sta ));
PRIVATE S16 PtMiLspStsReq   ARGS((Pst *pst, Action action, SpMngmt *sts ));
PRIVATE S16 PtMiLspCntrlReq ARGS((Pst *pst, SpMngmt *cntrl ));
#endif /* LCSMSPMILSP || SP */

/* functions in other modules */
  
/* public variable declarations */
  
/* private variable declarations */

/*
the following matrices define the mapping between the primitives
called by the layer management interface of SCCP and the corresponding
primitives in SCCP.
 
The parameter MAXSPMI defines the maximum number of layer manager entities
on top of SCCP. There is an array of functions per primitive
invoked by SCCP. Every array is MAXSPMI long (i.e. there
are as many functions as the number of service users).
 
The dispatching is performed by the configurable variable: selector.
The selector is configured during general configuration.
 
The selectors are:
 
   0 - loosely coupled - new interface, forawrd cabability (#define LCSMSPMILSP)
   1 - Lsp (#define SP)
 
*/

/* Configuration request primitive */
 
PRIVATE LspCfgReq SmMiLspCfgReqMt[MAXSPMI] =
{
#ifdef LCSMSPMILSP
   cmPkLspCfgReq,          /* 0 - loosely coupled - fc */
#else
   PtMiLspCfgReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef SP
   SpMiLspCfgReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLspCfgReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Statistics request primitive */
 
PRIVATE LspStsReq SmMiLspStsReqMt[MAXSPMI] =
{
#ifdef LCSMSPMILSP
   cmPkLspStsReq,          /* 0 - loosely coupled - fc */
#else
   PtMiLspStsReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef SP
   SpMiLspStsReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLspStsReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Status request primitive */
 
PRIVATE LspStaReq SmMiLspStaReqMt[MAXSPMI] =
{
#ifdef LCSMSPMILSP
   cmPkLspStaReq,        /* 0 - loosely coupled - fc */
#else
   PtMiLspStaReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef SP
   SpMiLspStaReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLspStaReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Control request primitive */
 
PRIVATE LspCntrlReq SmMiLspCntrlReqMt[MAXSPMI] =
{
#ifdef LCSMSPMILSP
   cmPkLspCntrlReq,          /* 0 - loosely coupled - fc */
#else
   PtMiLspCntrlReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef SP
   SpMiLspCntrlReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLspCntrlReq,          /* 1 - tightly coupled, portable */
#endif
};


/*
*     layer management interface functions 
*/
 
/*
*
*       Fun:   Configuration request
*
*       Desc:  This function is used to configure SCCP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smspptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLspCfgReq
(
Pst *pst,                 /* post structure */
SpMngmt *cfg              /* configure */
)
#else
PUBLIC S16 SmMiLspCfgReq(pst, cfg)
Pst *pst;                 /* post structure */   
SpMngmt *cfg;             /* configure */
#endif
{
   TRC3(SmMiLspCfgReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLspCfgReqMt[pst->selector])(pst, cfg); 
   RETVALUE(ROK);
} /* end of SmMiLspCfgReq */

/*
*
*       Fun:   Status request
*
*       Desc:  This function is used to send a status request to SCCP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smspptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLspStaReq
(
Pst *pst,                 /* post structure */
SpMngmt *sta              /* status */
)
#else
PUBLIC S16 SmMiLspStaReq(pst, sta)
Pst *pst;                 /* post structure */   
SpMngmt *sta;             /* status */
#endif
{
   TRC3(SmMiLspStaReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLspStaReqMt[pst->selector])(pst, sta); 
   RETVALUE(ROK);
} /* end of SmMiLspStaReq */

/*
*
*       Fun:   Statistics request
*
*       Desc:  This function is used to request statistics from SCCP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smspptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLspStsReq
(
Pst *pst,                 /* post structure */
Action action,
SpMngmt *sts              /* statistics */
)
#else
PUBLIC S16 SmMiLspStsReq(pst, action, sts)
Pst *pst;                 /* post structure */   
Action action;
SpMngmt *sts;             /* statistics */
#endif
{
   TRC3(SmMiLspStsReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLspStsReqMt[pst->selector])(pst, action, sts); 
   RETVALUE(ROK);
} /* end of SmMiLspStsReq */

/*
*
*       Fun:   Control request
*
*       Desc:  This function is used to send control request to SCCP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smspptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLspCntrlReq
(
Pst *pst,                 /* post structure */
SpMngmt *cntrl            /* control */
)
#else
PUBLIC S16 SmMiLspCntrlReq(pst, cntrl)
Pst *pst;                 /* post structure */   
SpMngmt *cntrl;           /* control */
#endif
{
   TRC3(SmMiLspCntrlReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLspCntrlReqMt[pst->selector])(pst, cntrl); 
   RETVALUE(ROK);
} /* end of SmMiLspCntrlReq */

/* sp035.302 - addition - following line added for removal of compilation
 * warning */
#if (!defined(LCSMSPMILSP) || !defined(SP))
/*
*
*       Fun:   Portable configure Request SCCP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smspptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLspCfgReq
(
Pst *pst,                   /* post structure */
SpMngmt *cfg                /* configure */
)
#else
PRIVATE S16 PtMiLspCfgReq(pst, cfg)
Pst *pst;                   /* post structure */
SpMngmt *cfg;               /* configure */
#endif
{
  TRC3(PtMiLspCfgReq);

  UNUSED(cfg);
#if (ERRCLASS & ERRCLS_DEBUG)
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
             __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal) ESMSP044,
             ERRZERO, "PtMiLspCfgReq () Failed"); 
#endif
  RETVALUE(ROK);
} /* end of PtMiLspCfgReq */


/*
*
*       Fun:   Portable status Request SCCP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smspptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLspStaReq
(
Pst *pst,                   /* post structure */
SpMngmt *sta                /* status */
)
#else
PRIVATE S16 PtMiLspStaReq(pst, sta)
Pst *pst;                   /* post structure */
SpMngmt *sta;               /* status */
#endif
{
  TRC3(PtMiLspStaReq);

  UNUSED(sta);
#if (ERRCLASS & ERRCLS_DEBUG)
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
             __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal) ESMSP045,
             ERRZERO, "PtMiLspStaReq () Failed"); 
#endif
  RETVALUE(ROK);
} /* end of PtMiLspStaReq */


/*
*
*       Fun:   Portable statistics Request SCCP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smspptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLspStsReq
(
Pst *pst,                   /* post structure */
Action action,
SpMngmt *sts                /* statistics */
)
#else
PRIVATE S16 PtMiLspStsReq(pst, action, sts)
Pst *pst;                   /* post structure */
Action action;
SpMngmt *sts;               /* statistics */
#endif
{
  TRC3(PtMiLspStsReq);

  UNUSED(action);
  UNUSED(sts);
#if (ERRCLASS & ERRCLS_DEBUG)
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
             __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal) ESMSP046,
             ERRZERO, "PtMiLspStsReq () Failed"); 
#endif
  RETVALUE(ROK);
} /* end of PtMiLspStsReq */


/*
*
*       Fun:   Portable control Request SCCP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smspptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLspCntrlReq
(
Pst *pst,                   /* post structure */
SpMngmt *cntrl              /* control */
)
#else
PRIVATE S16 PtMiLspCntrlReq(pst, cntrl)
Pst *pst;                   /* post structure */
SpMngmt *cntrl;             /* control */
#endif
{
  TRC3(PtMiLspCntrlReq);

  UNUSED(cntrl);
#if (ERRCLASS & ERRCLS_DEBUG)
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
             __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal) ESMSP047,
             ERRZERO, "PtMiLspCntrlReq () Failed"); 
#endif
  RETVALUE(ROK);
} /* end of PtMiLspCntrlReq */

#endif /* LCSMSPMILSP || SP */

/********************************************************************30**

         End of file:     smspptmi.c@@/main/10 - Tue Jan 22 15:05:44 2002

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release

1.2          ---  ak    1. removed inst and ent from spSAPCfg packing.
             ---  ak    2. fix non-ANSI compile bugs.

1.3          ---  fmg   1. don't pack statistics for StsReq

1.4          ---  scc   1.add config sccp management flag  
                          cfg->t.cfg.s.spGen.mngmntOn to 
                          smPkMiLspCfgReq

1.5          ---  scc   1.add changes for ANSI92 and CCITT92 variants 

1.6          ---  fmg   1. removed cm2.x include

1.7          ---  fmg   1. removed text following #endif
             ---  fmg   1. removed redundant prototypes.

1.8          ---  mjp   1. pack subService in STNSAP
             ---  mjp   2. replaced old error function with SPLOGERROR
             ---  mjp   3. CMCHKPKLOG used with all pack functions
             ---  mjp   4. removed old selector from interface matrices
             ---  mjp   5. pack Qlen as U32 not S16
*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.9          ---      ash  1. Changes for supporting SNT2
                           2. Removed general parameter nmbXUdRefCb, 
                              XRefFrzTmrRes , defXRefFrzTmr
                           3. change in control request packing routine for
                              supporting group control request
                           4. Changes for debug TCO
             sp011.27      5. packing for newly added niInd bit in network
                              sap configuration structure
                           6. Removed the packing functions as per 
                              tco0001.
/main/10     ---      rc   1. copy right header changed
            sp035.302  mc   1. Compilation warning for portability
                                   files removed.
*********************************************************************91*/
