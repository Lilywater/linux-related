/*************************************************
  Copyright (C), 1995-2006, XinWei Tech. Co., Ltd.
  
  File name:    it_cfg.c
  
  Subsystem   : sm
  
  Description: ����M3UAЭ���OAM�ӿ�
  ����õ��������γ����÷��͸�SM���Э��ջ����
  
  Others:         

  History: 
  Programmer  Date         Rev    Description
  --------------- ---------- -------- ------------------------------
  chenning   5/18/2006    1.0        created 
*************************************************/ 
#include "it_cfg.h"
#include "xosshell.h"
#include "cp_tab_def.h"
#include "sm.x"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"
/**************** Global Var ************************/
U32   itGlobalTransId = 0;

CmLListCp itGlobalSmQ[EN_IT_CFG_Q_MAX_NUM];

ItCfgGlobal itGlobalTabCfg;
    
U32 itCfgTbl[SM_M3UA_TAB_NUM]=
{
    APP_TABLE_ID_SS7_NWK, 
    APP_TABLE_ID_SS7_SPC,
    APP_TABLE_ID_SS7_UP,
    APP_TABLE_ID_COM_IP,
    APP_TABLE_ID_SS7_M3UA_GEN,
    APP_TABLE_ID_SS7_M3UA_NODE,
    APP_TABLE_ID_SS7_M3UA_PSP,
    APP_TABLE_ID_SS7_M3UA_PS,
    APP_TABLE_ID_SS7_M3UA_ROUTE,
};

extern PUBLIC CmIpv4NetAddr localNAddrLst_1V[5];
/**************** Private  FUNC Declare ************************/
PRIVATE VOID itHdrInit(Header *hdr) ;
PRIVATE U32 itGetTransId(VOID);
PRIVATE VOID smItPstInit(Pst *smSpPst);
PRIVATE U32 itUserIsExtAppBySi(U32 si);
PRIVATE U16 itBuildRteFilter(ItCfgM3uaRouteTab* rtecfg,ItRtFilter * rtFilter,U16 dpcLenType);

/******************* Public FUNC *************************/
S16 smItSendReqQ(CmLList *node)
{
    Pst smItPst;
    Header *msgHeader = (Header*)NULLP;
    S16 ret = ROK;
   
    TRC2(smItSendReqQ);      

    if ( (CmLList*)NULLP == node )
    {
        CPDBGP("smItSendReqQ(node pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    msgHeader = (Header *)cmLListNode(node);

    if ( (Header*)NULLP == msgHeader )
    {
        CPDBGP("smItSendReqQ(msgHeader pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    smItPstInit(&smItPst);
    
    switch(msgHeader->msgType)
    {
        case TCFG:
        {
            ret = SmMiLitCfgReq(&smItPst, (ItMgmt *)cmLListNode(node));
            break;
        }
        case TCNTRL:
        {
            ret = SmMiLitCntrlReq(&smItPst, (ItMgmt *)cmLListNode(node));
            break;
        }
        case TSTS:
        {
            ret = SmMiLitStsReq(&smItPst, NOZEROSTS, (ItMgmt *)cmLListNode(node));
            break;
        }
        case TSSTA:
        {
            ret = SmMiLitStaReq(&smItPst, (ItMgmt *)cmLListNode(node));
            break;
        }
        default:
        {
            CPDBGP("smItSendReqQ(msgHeader->msgType error)\r\n");
            RETVALUE(RFAILED);
        }
    }

    RETVALUE(ret);
}


S16  itTabM3uaGenCfg(VOID)
{
    CmLList *node = (CmLList*)NULLP;
    ItCfgM3uaGenTab* m3uaGen = (ItCfgM3uaGenTab*)NULLP;
    ItCfgM3uaNodeTypeTab* NodeType = (ItCfgM3uaNodeTypeTab*)NULLP;
    ItMgmt *itMngmt = (ItMgmt*)NULLP;
    U32 ret;
    
    TRC2(itTabM3uaGenCfg);        
    
    if (itGlobalTabCfg.GenTabNum != 1)
    {
        CPDBGP("itTabM3uaGenCfg(itGlobalTabCfg.GenTabNum error)\r\n");
        RETVALUE(RFAILED);
    }
    
    if( itGlobalTabCfg.NodeTabNum != 1)
    {
        /* because it is not unique column table, so it can not have default value, but we still need the stack init successful*/
        itGlobalTabCfg.NodeTabNum = 1;
    }

#ifdef ITSG
    if ( LIT_TYPE_SGP != itGlobalTabCfg.NodeTab[0].NodeType)
    {
        CPDBGP("itGlobalTabCfg.NodeTab[0].NodeType Error\r\n");
        RETVALUE(RFAILED);
    }
#else
    if ( LIT_TYPE_ASP != itGlobalTabCfg.NodeTab[0].NodeType)
    {
        CPDBGP("itGlobalTabCfg.NodeTab[0].NodeType Error\r\n");
        RETVALUE(RFAILED);
    }
#endif /* end of ITSG */

    /* get all data for config*/
    m3uaGen = &(itGlobalTabCfg.GenTab[0]);
    NodeType = &(itGlobalTabCfg.NodeTab[0]);

    if ( (ItCfgM3uaGenTab*)NULLP == m3uaGen || (ItCfgM3uaNodeTypeTab*)NULLP == NodeType )
    {
        CPDBGP("itTabM3uaGenCfg(m3uaGen or  NodeType pointer is null)\r\n");
    }
    
    /* alloc a node for save sm msg info */
    ret = smGetQNode(&node, (U16)sizeof(ItMgmt));
    if (ROK != ret)
    {
        CPDBGP("itTabM3uaGenCfg(smGetQNode Return Fail)\r\n");
        RETVALUE(RFAILED);
    }

    if ( (CmLList*)NULLP == node )
    {
        CPDBGP("itTabM3uaGenCfg(node pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    itMngmt = (ItMgmt *)cmLListNode(node) ;
    if ( (ItMgmt*)NULLP == itMngmt )
    {
        CPDBGP("itTabM3uaGenCfg(itMngmt pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    itMngmt->hdr.msgLen = sizeof( ItMgmt );
    
    itHdrInit(&itMngmt->hdr);
	
    itMngmt->hdr.msgType = TCFG;                     /* configuration */
    itMngmt->hdr.elmId.elmnt = STITGEN;            /* general */

#ifdef LCITMILIT
    itMngmt->t.cfg.s.genCfg.smPst.selector = IT_CFG_LOOSE;
#else
    itMngmt->t.cfg.s.genCfg.smPst.selector = IT_CFG_TIGHT;
#endif /* end of LCITMILIT */
    itMngmt->t.cfg.s.genCfg.smPst.region    = IT_CFG_REGION;
    itMngmt->t.cfg.s.genCfg.smPst.pool      = IT_CFG_POOL;
    itMngmt->t.cfg.s.genCfg.smPst.prior     = PRIOR1;
    itMngmt->t.cfg.s.genCfg.smPst.route     = RTESPEC;
    itMngmt->t.cfg.s.genCfg.smPst.dstProcId = SFndProcId();
    itMngmt->t.cfg.s.genCfg.smPst.dstEnt    = ENTSM;
    itMngmt->t.cfg.s.genCfg.smPst.dstInst   = IT_CFG_SM_INST;
    itMngmt->t.cfg.s.genCfg.smPst.srcProcId = SFndProcId();
    itMngmt->t.cfg.s.genCfg.smPst.srcEnt    = ENTIT;
    itMngmt->t.cfg.s.genCfg.smPst.srcInst   = IT_CFG_IT_INST;

    itMngmt->t.cfg.s.genCfg.tmr.tmrAspDn.enb = TRUE;
    itMngmt->t.cfg.s.genCfg.tmr.tmrAspDn.val = IT_CFG_ASPDN_TIMER* SS_TICKS_SEC/IT_TMR_RES;
    itMngmt->t.cfg.s.genCfg.tmr.tmrAsPend.enb = TRUE;
    itMngmt->t.cfg.s.genCfg.tmr.tmrAsPend.val= IT_CFG_ASPPD_TIMER* SS_TICKS_SEC/IT_TMR_RES;
    itMngmt->t.cfg.s.genCfg.tmr.tmrAspM.enb = TRUE;
    itMngmt->t.cfg.s.genCfg.tmr.tmrAspM.val= IT_CFG_ASPM_TIMER* SS_TICKS_SEC/IT_TMR_RES;
    itMngmt->t.cfg.s.genCfg.tmr.tmrAspUp1.enb = TRUE;
    itMngmt->t.cfg.s.genCfg.tmr.tmrAspUp1.val= IT_CFG_ASPUP1_TIMER* SS_TICKS_SEC/IT_TMR_RES;
    itMngmt->t.cfg.s.genCfg.tmr.tmrAspUp2.enb = TRUE;
    itMngmt->t.cfg.s.genCfg.tmr.tmrAspUp2.val = IT_CFG_ASPUP2_TIMER* SS_TICKS_SEC/IT_TMR_RES;
    itMngmt->t.cfg.s.genCfg.tmr.tmrDaud.enb = TRUE;
    itMngmt->t.cfg.s.genCfg.tmr.tmrDaud.val = IT_CFG_DAUD_TIMER* SS_TICKS_SEC/IT_TMR_RES;
    itMngmt->t.cfg.s.genCfg.tmr.tmrDrkm.enb = TRUE;
    itMngmt->t.cfg.s.genCfg.tmr.tmrDrkm.val = IT_CFG_DRKM_TIMER* SS_TICKS_SEC/IT_TMR_RES;
    itMngmt->t.cfg.s.genCfg.tmr.tmrDunaSettle.enb = TRUE;
    itMngmt->t.cfg.s.genCfg.tmr.tmrDunaSettle.val = IT_CFG_DUNA_TIMER* SS_TICKS_SEC/IT_TMR_RES;
    itMngmt->t.cfg.s.genCfg.tmr.tmrRestart.enb = TRUE;
    itMngmt->t.cfg.s.genCfg.tmr.tmrRestart.val = IT_CFG_RESTART_TIMER* SS_TICKS_SEC/IT_TMR_RES;
    itMngmt->t.cfg.s.genCfg.tmr.tmrMtp3Sta.enb =  TRUE;
    itMngmt->t.cfg.s.genCfg.tmr.tmrMtp3Sta.val = IT_CFG_MTP3STA_TIMER* SS_TICKS_SEC/IT_TMR_RES;
    itMngmt->t.cfg.s.genCfg.tmr.tmrSeqCntrl.enb = TRUE;
    itMngmt->t.cfg.s.genCfg.tmr.tmrSeqCntrl.val = IT_CFG_SEQCNTRL_TIMER* SS_TICKS_SEC/IT_TMR_RES;
    itMngmt->t.cfg.s.genCfg.tmr.tmrHeartbeat.enb = TRUE;
    itMngmt->t.cfg.s.genCfg.tmr.tmrHeartbeat.val = m3uaGen->HeartbeatTimer* SS_TICKS_SEC/IT_TMR_RES;

    itMngmt->t.cfg.s.genCfg.nodeType = NodeType->NodeType;
    itMngmt->t.cfg.s.genCfg.dpcLrnFlag = IT_CFG_DPCLRN_FLAG;
    itMngmt->t.cfg.s.genCfg.maxNmbNwk = IT_CFG_NWK_NMB;
    itMngmt->t.cfg.s.genCfg.maxNmbRtEnt = IT_CFG_RTE_NMB;
    itMngmt->t.cfg.s.genCfg.maxNmbDpcEnt = IT_CFG_DPC_NMB;
    itMngmt->t.cfg.s.genCfg.maxNmbNSap = IT_CFG_NSAP_NMB;
    itMngmt->t.cfg.s.genCfg.maxNmbSctSap = IT_CFG_SCTSAP_NMB;
    itMngmt->t.cfg.s.genCfg.maxNmbPs = m3uaGen->MaxPsNum;
    itMngmt->t.cfg.s.genCfg.maxNmbPsp = m3uaGen->MaxPspNum;
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
    itMngmt->t.cfg.s.genCfg.maxNmbLps = m3uaGen->MaxLpsNum;   
#endif /* ITASP && OG_RTE_ON_LPS_STA */
    itMngmt->t.cfg.s.genCfg.maxNmbMsg = m3uaGen->MaxNumMsg;
    itMngmt->t.cfg.s.genCfg.maxNmbRndRbnLs = m3uaGen->MaxNumRndRbnls;
    itMngmt->t.cfg.s.genCfg.maxNmbSlsLs = m3uaGen->MaxNumSlsls;
    itMngmt->t.cfg.s.genCfg.maxNmbSls = m3uaGen->MaxNumSls;
    itMngmt->t.cfg.s.genCfg.drkmSupp = m3uaGen->DrkmSupp;
    itMngmt->t.cfg.s.genCfg.drstSupp = m3uaGen->DrstSupp;
    itMngmt->t.cfg.s.genCfg.tmr.nmbAspUp1 = IT_CFG_ASPUP1_NMB;
    itMngmt->t.cfg.s.genCfg.tmr.maxNmbRkTry = IT_CFG_RKTRY_NMB;
    itMngmt->t.cfg.s.genCfg.qSize = IT_M3UA_QSIZE;
    itMngmt->t.cfg.s.genCfg.congLevel1 = IT_M3UA_CONG_LEVEL1;
    itMngmt->t.cfg.s.genCfg.congLevel2 = IT_M3UA_CONG_LEVEL2;
    itMngmt->t.cfg.s.genCfg.congLevel3 = IT_M3UA_CONG_LEVEL3;
    itMngmt->t.cfg.s.genCfg.timeRes = IT_TMR_RES;

    cmLListAdd2Tail(&itGlobalSmQ[EN_IT_CFG_GEN_Q], node);
    
    RETVALUE(ROK);
}

S16  itTabSs7NwkCfg(U32 NwkIndex)
{
    CmLList *node = (CmLList*)NULLP;
    CP_SS7_NETWORK_TAB *network = (CP_SS7_NETWORK_TAB*)NULLP;
    ItMgmt *itMngmt = (ItMgmt*)NULLP;
    U16  pspIndex;
    U32 ret;

    TRC2(itTabSs7NwkCfg);
    
    if (NwkIndex > CP_SS7_MAX_NWKTAB)
    {
        CPDBGP("itTabSs7NwkCfg(NwkIndex error)\r\n");
        RETVALUE(RFAILED);
    }

    network = &(gstCpSs7Global.NwkTab[NwkIndex]);
    if ( (CP_SS7_NETWORK_TAB*)NULLP == network )
    {
        CPDBGP("itTabSs7NwkCfg(network pointer is null)\r\n");
        RETVALUE(RFAILED);
    }

    if ( IT_NWK_BEAR_M3UA != network->BearType )
    {
        RETVALUE(ROK);
    }
    
    ret = smGetQNode(&node, sizeof(ItMgmt));
    if( ROK != ret)
    {
        CPDBGP("itTabSs7NwkCfg(smGetQNode Return Fail)\r\n");
        RETVALUE(RFAILED);
    }

    if ( (CmLList*)NULLP == node )
    {
        CPDBGP("itTabSs7NwkCfg(node pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    itMngmt = (ItMgmt *)cmLListNode(node) ;
    if ( (ItMgmt*)NULLP == itMngmt )
    {
        CPDBGP("itTabSs7NwkCfg(itMngmt pointer is null)\r\n");
        RETVALUE(RFAILED);
    }

    itMngmt->hdr.msgLen = sizeof( ItMgmt );
    
    itHdrInit(&itMngmt->hdr);
	
    itMngmt->hdr.msgType = TCFG;                    /* Configuration */
    itMngmt->hdr.elmId.elmnt = STITNWK;          /* Network */

    itMngmt->t.cfg.s.nwkCfg.nwkId = network->NwId;

    for(pspIndex=0;pspIndex<LIT_MAX_PSP;pspIndex ++)
    {
        itMngmt->t.cfg.s.nwkCfg.nwkApp[pspIndex] = IT_CFG_NWK_APP;
    }

    itMngmt->t.cfg.s.nwkCfg.ssf = network->SubService;
    itMngmt->t.cfg.s.nwkCfg.slsLen = IT_CFG_NWK_SLS_LEG;

    switch (network->SwType)
    {
        case EN_CP_SW_ANSI88:
        case EN_CP_SW_ANSI92:
        {
            itMngmt->t.cfg.s.nwkCfg.suSwtch = LIT_SW_ANS;
            itMngmt->t.cfg.s.nwkCfg.su2Swtch = LIT_SW2_ANS; 
            itMngmt->t.cfg.s.nwkCfg.dpcLen = DPC24;
            break;
        }
        
        case EN_CP_SW_ITU88:
        case EN_CP_SW_ITU92:
        case EN_CP_SW_ITU96:
        {
            itMngmt->t.cfg.s.nwkCfg.suSwtch = LIT_SW_ITU;
            itMngmt->t.cfg.s.nwkCfg.su2Swtch =  LIT_SW2_ITU;
            itMngmt->t.cfg.s.nwkCfg.dpcLen = DPC14;
            break;
        }

        case EN_CP_SW_CHINA:
        {
            itMngmt->t.cfg.s.nwkCfg.suSwtch = LIT_SW_CHINA;
            itMngmt->t.cfg.s.nwkCfg.su2Swtch =  LIT_SW2_ANS;
            itMngmt->t.cfg.s.nwkCfg.dpcLen = DPC24;
            break;
        }	     

        case EN_CP_SW_TTC:
        {
            itMngmt->t.cfg.s.nwkCfg.suSwtch = LIT_SW_TTC;
            itMngmt->t.cfg.s.nwkCfg.su2Swtch =  LIT_SW2_TTC;
            itMngmt->t.cfg.s.nwkCfg.dpcLen = DPC16;
            break;
        }

        /* For the following types, set the m3ua type as ITU */
        case EN_CP_SW_BICI:
        case EN_CP_SW_ITU97:
        case EN_CP_SW_ITU2000:
        case EN_CP_SW_SINGTEL:
        case EN_CP_SW_Q967:
        {
            itMngmt->t.cfg.s.nwkCfg.suSwtch = LIT_SW_ITU;
            itMngmt->t.cfg.s.nwkCfg.su2Swtch =  LIT_SW2_ITU;
            itMngmt->t.cfg.s.nwkCfg.dpcLen = DPC14;
            break;
        }

        /* For the other types, set the m3ua type as ITU */
        default:
        {
            itMngmt->t.cfg.s.nwkCfg.suSwtch = LIT_SW_ITU;
            itMngmt->t.cfg.s.nwkCfg.su2Swtch =  LIT_SW2_ITU;
            itMngmt->t.cfg.s.nwkCfg.dpcLen = DPC14;
            break;
        }
    }
    
    cmLListAdd2Tail(&itGlobalSmQ[EN_IT_CFG_NETWORK_Q], node);

    RETVALUE(ROK);
}

S16  itTabM3uaPspCfg(U32 PspIndex)
{
    CmLList *node = (CmLList*)NULLP;
    ItMgmt *itMngmt = (ItMgmt*)NULLP;
    ItCfgM3uaPspTab* pspcfg = (ItCfgM3uaPspTab*)NULLP;
    U8 ipnum;
    U32 ret;
    
    TRC2(itTabM3uaPspCfg);
    
    if ((PspIndex >= itGlobalTabCfg.PspTabNum)||(PspIndex >= IT_CFG_MAX_PSPTAB))
    {
        CPDBGP("itTabM3uaPspCfg(PspIndex error)\r\n");
        RETVALUE(RFAILED);
    }
    
    pspcfg = &(itGlobalTabCfg.PspTab[PspIndex]);
    if ( (ItCfgM3uaPspTab*)NULLP == pspcfg )
    {
        CPDBGP("itTabM3uaPspCfg(pspcfg pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    ret = smGetQNode(&node, sizeof(ItMgmt));
    if (ROK != ret)
    {
        CPDBGP("itTabM3uaPspCfg(smGetQNode ret error)\r\n");
        RETVALUE(RFAILED);
    }	

    if ( (CmLList*)NULLP == node )
    {
        CPDBGP("itTabM3uaPspCfg(node pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    itMngmt = (ItMgmt *)cmLListNode(node) ;
    if ( (ItMgmt*)NULLP == itMngmt )
    {
        CPDBGP(("itTabM3uaPspCfg(itMngmt pointer is null)\r\n"));
        RETVALUE(RFAILED);
    }
    
    itMngmt->hdr.msgLen = sizeof( ItMgmt );	
    
    itHdrInit(&itMngmt->hdr);
    itMngmt->hdr.msgType = TCFG;                   /* Configuration */
    itMngmt->hdr.elmId.elmnt = STITPSP;            /* PSP */

    itMngmt->t.cfg.s.pspCfg.pspId = pspcfg->PspID;

    if ((pspcfg->PriDestAddr != pspcfg->DestAddr1)
        && (pspcfg->PriDestAddr != pspcfg->DestAddr2)
        && (pspcfg->PriDestAddr != pspcfg->DestAddr3)
        && (pspcfg->PriDestAddr != pspcfg->DestAddr4))
    {
        CPDBGP("itTabM3uaPspCfg(pspcfg->PriDestAddr eror)\r\n");
        RETVALUE(RFAILED);        
    }

    itMngmt->t.cfg.s.pspCfg.pspType = pspcfg->PspType;
    itMngmt->t.cfg.s.pspCfg.ipspMode = pspcfg->IpspType;
    itMngmt->t.cfg.s.pspCfg.dynRegRkallwd = IT_CFG_DYNREGRK;
    itMngmt->t.cfg.s.pspCfg.dfltLshareMode = pspcfg->DfltLshareMode;
    itMngmt->t.cfg.s.pspCfg.nwkAppIncl = pspcfg->NwkAppIncl;
    itMngmt->t.cfg.s.pspCfg.nwkId = pspcfg->NwkID;
    itMngmt->t.cfg.s.pspCfg.rxTxAspId = IT_CFG_RXTX;

#ifdef ITASP
/*2006/8/16 chenning �޸�Ϊ���ܴ�ӡ���Զ�������ʱ��״̬*/    
    itMngmt->t.cfg.s.pspCfg.autostartstatus = FALSE;
    
    if(pspcfg->PspType == LIT_PSPTYPE_IPSP && pspcfg->IpspType == LIT_IPSPMODE_DE)
    {
        itMngmt->t.cfg.s.pspCfg.cfgForAllLps = TRUE;
    }
    else
    {
        itMngmt->t.cfg.s.pspCfg.cfgForAllLps = FALSE;
    }
#endif /* end of ITASP */

    itMngmt->t.cfg.s.pspCfg.assocCfg.dstPort = pspcfg->DestPort;
    itMngmt->t.cfg.s.pspCfg.assocCfg.locOutStrms = pspcfg->OutStreamNum;
    ipnum = 0;
    
    if (pspcfg->DestAddr1!=0)
    {
        itMngmt->t.cfg.s.pspCfg.assocCfg.dstAddrLst.nAddr[ipnum].type = CM_INET_IPV4ADDR_TYPE;

        itMngmt->t.cfg.s.pspCfg.assocCfg.dstAddrLst.nAddr[ipnum].u.ipv4NetAddr = ntohl(pspcfg->DestAddr1);

        ipnum++;
    }
    if (pspcfg->DestAddr2!=0)
    {
        itMngmt->t.cfg.s.pspCfg.assocCfg.dstAddrLst.nAddr[ipnum].type = CM_INET_IPV4ADDR_TYPE;

        itMngmt->t.cfg.s.pspCfg.assocCfg.dstAddrLst.nAddr[ipnum].u.ipv4NetAddr = ntohl(pspcfg->DestAddr2);

        ipnum++;
    }
    if (pspcfg->DestAddr3!=0)
    {
        itMngmt->t.cfg.s.pspCfg.assocCfg.dstAddrLst.nAddr[ipnum].type = CM_INET_IPV4ADDR_TYPE;

        itMngmt->t.cfg.s.pspCfg.assocCfg.dstAddrLst.nAddr[ipnum].u.ipv4NetAddr = ntohl(pspcfg->DestAddr3);

        ipnum++;
    }
    if (pspcfg->DestAddr4!=0)
    {
        itMngmt->t.cfg.s.pspCfg.assocCfg.dstAddrLst.nAddr[ipnum].type = CM_INET_IPV4ADDR_TYPE;

        itMngmt->t.cfg.s.pspCfg.assocCfg.dstAddrLst.nAddr[ipnum].u.ipv4NetAddr = ntohl(pspcfg->DestAddr4);

        ipnum++;
    }
    itMngmt->t.cfg.s.pspCfg.assocCfg.dstAddrLst.nmb = ipnum;
    itMngmt->t.cfg.s.pspCfg.assocCfg.priDstAddr.type = CM_INET_IPV4ADDR_TYPE;

    itMngmt->t.cfg.s.pspCfg.assocCfg.priDstAddr.u.ipv4NetAddr = ntohl(pspcfg->PriDestAddr);


    cmLListAdd2Tail(&itGlobalSmQ[EN_IT_CFG_PSP_Q], node);
    
    RETVALUE(ROK);
}

S16  itTabM3uaPsCfg(U32 PsIndex)
{
    CmLList *node = (CmLList*)NULLP;
    ItMgmt *itMngmt = (ItMgmt*)NULLP;
    ItCfgM3uaPsTab* pscfg = (ItCfgM3uaPsTab*)NULLP;
    U16 i;
    U32 ret;
    
    TRC2(itTabM3uaPsCfg);
		   
    if ((PsIndex >= itGlobalTabCfg.PsTabNum)||(PsIndex >= IT_CFG_MAX_PSTAB))
    { 
        CPDBGP("itTabM3uaPsCfg(PsIndex error)\r\n");
        RETVALUE(RFAILED);
    }
    
    pscfg = &(itGlobalTabCfg.PsTab[PsIndex]);
    if ( (ItCfgM3uaPsTab*)NULLP == pscfg )
    {
        CPDBGP("itTabM3uaPsCfg(pscfg pointer is null)\r\n");
    }
    
    ret = smGetQNode(&node, sizeof(ItMgmt));
    if (ROK != ret)
    {
        CPDBGP("itTabM3uaPsCfg(smGetQNode ret error)\r\n");
        RETVALUE(RFAILED);
    }	

    if ( (CmLList*)NULLP == node )
    {
        CPDBGP("itTabM3uaPsCfg(node pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    itMngmt = (ItMgmt *)cmLListNode(node) ;
    if ( (ItMgmt*)NULLP == itMngmt )
    {
        CPDBGP("itTabM3uaPsCfg(itMngmt pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    itMngmt->hdr.msgLen = sizeof( ItMgmt );	
    itHdrInit(&itMngmt->hdr);
    itMngmt->hdr.msgType = TCFG;                  /* Configuration */
    itMngmt->hdr.elmId.elmnt = STITPS;            /* PS */
    itMngmt->t.cfg.s.psCfg.psId = pscfg->PsID;
         
    itMngmt->t.cfg.s.psCfg.lclFlag = pscfg->LocalFlag;
    itMngmt->t.cfg.s.psCfg.loadShareMode = pscfg->LoadShareMode;
    itMngmt->t.cfg.s.psCfg.routCtx = pscfg->RoutCtx;
    itMngmt->t.cfg.s.psCfg.mode = pscfg->PsWorkMode;
    itMngmt->t.cfg.s.psCfg.nmbActPspReqd = pscfg->ActivePspRequired;
    itMngmt->t.cfg.s.psCfg.nmbPsp = pscfg->PspNum;
    itMngmt->t.cfg.s.psCfg.nwkId = pscfg->NwkID;
    
    itMngmt->t.cfg.s.psCfg.reqAvail = IT_CFG_REQAVAIL;
    for (i=0;(i<pscfg->PspNum)&&(i<IT_CFG_MAX_PSP_IN_PS);i++)
    {
        itMngmt->t.cfg.s.psCfg.psp[i] = pscfg->Psp[i];
    }
    
    cmLListAdd2Tail(&itGlobalSmQ[EN_IT_CFG_PS_Q], node);
    
    RETVALUE(ROK);
}

S16  itTabM3uaRteCfg(U32 RteIndex)
{
    CmLList *node = (CmLList*)NULLP;
    ItMgmt *itMngmt = (ItMgmt*)NULLP;
    ItCfgM3uaRouteTab* rtecfg = (ItCfgM3uaRouteTab*)NULLP;
    U16 tempIndex,b_find;
    U16 SpcLength;
    U32 ret;
    
    TRC2(itTabM3uaRteCfg);
    
    if ((RteIndex >= itGlobalTabCfg.RouteTabNum)||(RteIndex >= IT_CFG_MAX_ROUTETAB))
    {
        CPDBGP("itTabM3uaRteCfg(RteIndex error)\r\n");
        RETVALUE(RFAILED);
    }
    
    rtecfg = &itGlobalTabCfg.RouteTab[RteIndex];
    if ( (ItCfgM3uaRouteTab*)NULLP == rtecfg )
    {
        CPDBGP("itTabM3uaRteCfg(rtecfg pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    ret = smGetQNode(&node, sizeof(ItMgmt));
    if (ROK != ret)
    {
        CPDBGP("itTabM3uaRteCfg(smGetQNode ret error)\r\n");
        RETVALUE(RFAILED);
    }	

    if ( (CmLList*)NULLP == node )
    {
        CPDBGP("itTabM3uaRteCfg(node pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    itMngmt = (ItMgmt *)cmLListNode(node) ;
    if ( (ItMgmt*)NULLP == itMngmt )
    {
        CPDBGP("itTabM3uaRteCfg(itMngmt pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    itMngmt->hdr.msgLen = sizeof( ItMgmt );	
    itHdrInit(&itMngmt->hdr);
    itMngmt->hdr.msgType = TCFG;                    /* Configuration */
    itMngmt->hdr.elmId.elmnt = STITROUT;            /* PS */

    itMngmt->t.cfg.s.rteCfg.rtType = rtecfg->RouteType;
    itMngmt->t.cfg.s.rteCfg.psId = rtecfg->PsID;
    itMngmt->t.cfg.s.rteCfg.nwkId = rtecfg->NwkID;
    
    itMngmt->t.cfg.s.rteCfg.nSapIdPres = FALSE;
    itMngmt->t.cfg.s.rteCfg.noStatus = FALSE;
    itMngmt->t.cfg.s.rteCfg.nSapId = 0;
    
    if (rtecfg->NwkID >= CP_SS7_MAX_NWKTAB)
    {
        CPDBGP("itTabM3uaRteCfg(rtecfg->NwkID error)\r\n");
        RETVALUE(RFAILED);
    }
    
    b_find = FALSE;
    
    for (tempIndex =0;tempIndex <CP_SS7_MAX_NWKTAB;tempIndex++)
    {
        if (gstCpSs7Global.NwkTab[tempIndex].NwId == rtecfg->NwkID)
        {
            b_find = TRUE;
            break;
        }
    }
    
    if (b_find == FALSE)
    {
        CPDBGP("itTabM3uaRteCfg(b_find is FALSE)\r\n");
        RETVALUE(RFAILED);
    }

    switch ( gstCpSs7Global.NwkTab[tempIndex].SwType )
    {
        case EN_CP_SW_ANSI88:
        case EN_CP_SW_ANSI92:
        {
            SpcLength = DPC24;
            break;
        }
        
        case EN_CP_SW_ITU88:
        case EN_CP_SW_ITU92:
        case EN_CP_SW_ITU96:
        {
            SpcLength = DPC14;
            break;
        }

        case EN_CP_SW_CHINA:
        {
            SpcLength = DPC24;
            break;
        }	     

        case EN_CP_SW_TTC:
        {
            SpcLength = DPC16;
            break;
        }

        /* For the following types, set the m3ua type as ITU */
        case EN_CP_SW_BICI:
        case EN_CP_SW_ITU97:
        case EN_CP_SW_ITU2000:
        case EN_CP_SW_SINGTEL:
        case EN_CP_SW_Q967:
        {
            SpcLength = DPC14;
            break;
        }

        /* For the other types, set the m3ua type as ITU */
        default:
        {
            SpcLength = DPC14;
            break;
        }
    }
    if (ROK != itBuildRteFilter(rtecfg,&(itMngmt->t.cfg.s.rteCfg.rtFilter), SpcLength ))
    {
        CPDBGP("itTabM3uaRteCfg(itBuildRteFilter is RFAILED)\r\n");
        RETVALUE(RFAILED);
    }
    
    cmLListAdd2Tail(&itGlobalSmQ[EN_IT_CFG_ROUTE_Q], node);
    
    RETVALUE(ROK);
}

S16  itTabM3uaLSapCfg(VOID)
{
    CmLList *node = (CmLList*)NULLP;
    ItMgmt *itMngmt = (ItMgmt*)NULLP;

    TRC2(itTabM3uaLSapCfg);
    
    if (ROK != smGetQNode(&node, sizeof(ItMgmt)))
    {
        CPDBGP("itTabM3uaLSapCfg(smGetQNode is RFAILED)\r\n");
        RETVALUE(RFAILED);
    }

    if ( (CmLList*)NULLP == node )
    {
        CPDBGP("itTabM3uaLSapCfg(node pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    itMngmt = (ItMgmt *)cmLListNode(node) ;
    if ( (ItMgmt*)NULLP == itMngmt )
    {
        CPDBGP("itTabM3uaLSapCfg(itMngmt pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    itMngmt->hdr.msgLen = sizeof( ItMgmt );	
    itHdrInit(&itMngmt->hdr);

    itMngmt->hdr.msgType = TCFG;                    /* Configuration */
    itMngmt->hdr.elmId.elmnt = STITSCTSAP;          /* Lower Sap */

    itMngmt->t.cfg.s.sctSapCfg.mem.region = IT_CFG_REGION;
    itMngmt->t.cfg.s.sctSapCfg.mem.pool = IT_CFG_POOL;
    itMngmt->t.cfg.s.sctSapCfg.prior = PRIOR2;
    itMngmt->t.cfg.s.sctSapCfg.route = RTESPEC;
    itMngmt->t.cfg.s.sctSapCfg.tmrPrim.enb = TRUE;
    itMngmt->t.cfg.s.sctSapCfg.tmrPrim.val = IT_CFG_TMR_PRIM* SS_TICKS_SEC/IT_TMR_RES;
    itMngmt->t.cfg.s.sctSapCfg.tmrSta.enb = TRUE;
    itMngmt->t.cfg.s.sctSapCfg.tmrSta.val = IT_CFG_TMR_STA* SS_TICKS_SEC/IT_TMR_RES;
    itMngmt->t.cfg.s.sctSapCfg.ent = ENTSB;
    itMngmt->t.cfg.s.sctSapCfg.inst = IT_CFG_SB_INST;
    itMngmt->t.cfg.s.sctSapCfg.route = RTESPEC;
    itMngmt->t.cfg.s.sctSapCfg.procId = SFndProcId();
    itMngmt->t.cfg.s.sctSapCfg.srcAddrLst.nAddr[0].type = CM_NETADDR_IPV4;
#if 0    
    itMngmt->t.cfg.s.sctSapCfg.srcAddrLst.nAddr[0].u.ipv4NetAddr = htonl(SFndProcId());
#endif
    itMngmt->t.cfg.s.sctSapCfg.srcAddrLst.nAddr[0].u.ipv4NetAddr = localNAddrLst_1V[0];
    
    itMngmt->t.cfg.s.sctSapCfg.srcAddrLst.nmb = 1;
#ifdef LCITLISCT
    itMngmt->t.cfg.s.sctSapCfg.selector = IT_CFG_LOOSE;
#else /* else of LCITMILIT */
    itMngmt->t.cfg.s.sctSapCfg.selector = IT_CFG_TIGHT;
#endif  /* end of LCITMILIT */

    itMngmt->t.cfg.s.sctSapCfg.srcPort = itGlobalTabCfg.NodeTab[0].M3uaPort;
    itMngmt->t.cfg.s.sctSapCfg.suId = 0;
    itMngmt->t.cfg.s.sctSapCfg.spId = 0;
    
    cmLListAdd2Tail(&itGlobalSmQ[EN_IT_CFG_LSAP_Q], node);

    RETVALUE(ROK);
}

S16  itTabM3uaNSapCfg(U32 UpIndex)
{
    CmLList *node = (CmLList*)NULLP;
    ItMgmt *itMngmt = (ItMgmt*)NULLP;
    CP_SS7_UP_TAB *ss7UP = (CP_SS7_UP_TAB*)NULLP;
    U16 i;

    TRC2(itTabM3uaNSapCfg);        
    
    if (itGlobalTabCfg.GenTabNum != 1)
    {
        CPDBGP("itTabM3uaNSapCfg(itGlobalTabCfg.GenTabNum error)\r\n");
        RETVALUE(RFAILED);
    }
    
    if (UpIndex >= gstCpSs7Global.UPTabNum)
    {
        CPDBGP("itTabM3uaNSapCfg(UPTabNum error)\r\n");
        RETVALUE(RFAILED);
    }
    
    ss7UP = &(gstCpSs7Global.UPTab[UpIndex]);
    
    if ( (CP_SS7_UP_TAB*)NULLP == ss7UP )
    {
        CPDBGP("itTabM3uaNSapCfg(Up pointer is null)\r\n");
        RETVALUE(RFAILED);
    }

    /* find out network table item*/
    for ( i = 0; i < gstCpSs7Global.NwkTabNum; i++)
    {
        if( gstCpSs7Global.NwkTab[i].NwId == ss7UP->NwId)
            break;
    }
    
    if (i == gstCpSs7Global.NwkTabNum)
    {
        CPDBGP("itTabM3uaNSapCfg(gstCpSs7Global.NwkTabNum error)\r\n");
        RETVALUE(RFAILED);
    }
    
    for (i=0; i <UpIndex; i++)
    {
        if (gstCpSs7Global.UPTab[i].NwId == ss7UP->NwId
            && gstCpSs7Global.UPTab[i].Si  == ss7UP->Si )
        {
            CPDBGP("itTabM3uaNSapCfg(Up is exist)\r\n");
            RETVALUE(RFAILED);
        }
    }
    
    if (ROK != smGetQNode(&node, sizeof(ItMgmt)))
    {
        CPDBGP("itTabM3uaNSapCfg(smGetQNode is RFAILED)\r\n");
        RETVALUE(RFAILED);
    }

    if ( (CmLList*)NULLP == node )
    {
        CPDBGP("itTabM3uaNSapCfg(node pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    itMngmt = (ItMgmt *)cmLListNode(node) ;
    if ( (ItMgmt*)NULLP == itMngmt )
    {
        CPDBGP("itTabM3uaNSapCfg(itMngmt pointer is null)\r\n");
        RETVALUE(RFAILED);
    }
    
    itMngmt = (ItMgmt *)cmLListNode(node) ;
    itMngmt->hdr.msgLen = sizeof( ItMgmt );	
    itHdrInit(&itMngmt->hdr);

    itMngmt->hdr.msgType = TCFG;                    /* Configuration */
    itMngmt->hdr.elmId.elmnt = STITNSAP;         /* Upper Sap */

    itMngmt->t.cfg.s.nSapCfg.nwkId = ss7UP->NwId;
 
    if( RFAILED == itUserIsExtAppBySi(ss7UP->Si) )
    {
        itMngmt->t.cfg.s.nSapCfg.selector = IT_CFG_TIGHT;
        if (ss7UP->Si == EN_CP_SI_SCCP)
        {
            itMngmt->t.cfg.s.nSapCfg.suType = LIT_SU_SCCP;
#ifdef LCITUISNT /* added by Joe.xu --06/15/2006 */
            itMngmt->t.cfg.s.nSapCfg.selector = IT_SEL_LC; 
#else
            itMngmt->t.cfg.s.nSapCfg.selector = IT_SEL_SP; 
#endif
        }
        else
        {
            itMngmt->t.cfg.s.nSapCfg.suType = ss7UP->Si;
            itMngmt->t.cfg.s.nSapCfg.selector = IT_CFG_TIGHT;
        }
    }
    else
    {
        if (ss7UP->Si == EN_CP_SI_ISUP)
        {
            itMngmt->t.cfg.s.nSapCfg.suType = LIT_SU_ISUP;
#ifdef LCITUISNT_XOS
            itMngmt->t.cfg.s.nSapCfg.selector = IT_SEL_ATT; 
#else 
#ifdef LCITUISNT /* added by Joe.xu --06/15/2006 */
            itMngmt->t.cfg.s.nSapCfg.selector = IT_SEL_LC; 
#else
            itMngmt->t.cfg.s.nSapCfg.selector = IT_SEL_SI; 
#endif
#endif
        }
        else if (ss7UP->Si == EN_CP_SI_TUP)
        {
            itMngmt->t.cfg.s.nSapCfg.suType = LIT_SU_TUP;        
#ifdef LCITUISNT /* added by Joe.xu --06/15/2006 */
            itMngmt->t.cfg.s.nSapCfg.selector = IT_SEL_LC; 
#else
            itMngmt->t.cfg.s.nSapCfg.selector = IT_SEL_TP; 
#endif
        }
        else if (ss7UP->Si == EN_CP_SI_AAL2)
        {
            itMngmt->t.cfg.s.nSapCfg.suType = LIT_SU_AAL2;        
#ifdef LCITUISNT /* added by Joe.xu --06/15/2006 */
            itMngmt->t.cfg.s.nSapCfg.selector = IT_SEL_LC; 
#else
            itMngmt->t.cfg.s.nSapCfg.selector = IT_SEL_AL; 
#endif
        }
    }

    itMngmt->t.cfg.s.nSapCfg.sapId = ss7UP->UpIndex;
    itMngmt->t.cfg.s.nSapCfg.mem.region = IT_CFG_REGION;
    itMngmt->t.cfg.s.nSapCfg.mem.pool = IT_CFG_POOL;
    itMngmt->t.cfg.s.nSapCfg.prior = PRIOR2;
    itMngmt->t.cfg.s.nSapCfg.route = RTESPEC;
    
    cmLListAdd2Tail(&itGlobalSmQ[EN_IT_CFG_NSAP_Q], node);

    RETVALUE(ROK);
}

/**************** Private  FUNC ************************/
PRIVATE void itHdrInit(Header *hdr)
{
    TRC2(itHdrInit);

    hdr->msgType            = 0;
    hdr->msgLen             = sizeof(ItMgmt);
    hdr->entId.ent          = ENTIT;
    hdr->entId.inst         = 0;
    hdr->elmId.elmnt        = 0;
    hdr->elmId.elmntInst1   = 0;
    hdr->elmId.elmntInst2   = 0;
    hdr->elmId.elmntInst3   = 0;
    hdr->seqNmb             = 0;
    hdr->version            = 0;

#ifdef LMINT3
    hdr->response.prior     = PRIOR1;
    hdr->response.route     = RTESPEC;
    hdr->response.mem.region  = DFLT_REGION;
    hdr->response.mem.pool  = DFLT_POOL;
    hdr->transId            = itGetTransId();

#ifdef LCITMILIT
    hdr->response.selector  = 0;
#else
    hdr->response.selector  = 1;
#endif
#endif /* SN_LMINT3 */

    RETVOID;
} 

PRIVATE U32 itGetTransId(VOID)
{
    TRC2(itGetTransId);
    return itGlobalTransId++;
}

PRIVATE Void smItPstInit(Pst *smItPst)
{
    TRC2(smItPstInit);
    /* smsnPst */
#ifdef LCITMILIT
    smItPst->selector = 0;               /* selector,loose coupled */
#else
    smItPst->selector = 1;               /* selector,loose coupled */
#endif
    smItPst->region = IT_CFG_REGION;            /* region */
    smItPst->pool = IT_CFG_POOL;             /* pool */
    smItPst->prior = PRIOR1;                  /* priority */
    smItPst->route = RTESPEC;                  /* route */
    smItPst->dstProcId = SFndProcId();   /* destination processor id */
    smItPst->dstEnt = ENTIT;             /* destination entity*/
    smItPst->dstInst = IT_CFG_IT_INST;          /* destination instance */
    smItPst->srcProcId = SFndProcId();   /* source processor id */
    smItPst->srcEnt = ENTSM;             /* source entity */
    smItPst->srcInst = IT_CFG_SM_INST;          /* source instance */
} /* end of smItPstInit */

PRIVATE U32 itUserIsExtAppBySi(U32 si)
{
    TRC2(itUserIsExtAppBySi);

    if( si == EN_CP_SI_AAL2 || si == EN_CP_SI_ISUP || si == EN_CP_SI_TUP )
    {
        RETVALUE(ROK);
    }
    else
    {
        RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
}

PRIVATE U16 itBuildRteFilter(ItCfgM3uaRouteTab* rtecfg,ItRtFilter * rtFilter,U16 dpcLenType)
{
    U32 dpcMask;

    TRC2(itBuildRteFilter);
    
    switch (dpcLenType)
    {
        case DPC14:
        {
            dpcMask = IT_DPC_14_MASK;
            break;
        }
        
        case DPC16:
        {
            dpcMask = IT_DPC_16_MASK;
            break;
        }
        
        case DPC24:
        {
            dpcMask = IT_DPC_24_MASK;
            break;
        }
        
        default :
        {
            CPDBGP("itBuildRteFilter(dpcLenType error)\r\n");
            RETVALUE(RFAILED);
        }
    }
       
    if ((rtecfg == NULLP)||(rtFilter == NULLP))
    {
        CPDBGP("itBuildRteFilter(rtecfg is nullp or rtFilter is nullp)\r\n");
        RETVALUE(RFAILED);
    }		
    
    rtFilter->dpcMask = 0;
    rtFilter->dpc = 0;
    rtFilter->cicEnd = 0;
    rtFilter->cicStart = 0;
    rtFilter->includeCic = FALSE;
    rtFilter->includeSsn = FALSE;
    rtFilter->includeTrid = FALSE;
    rtFilter->opc = 0;
    rtFilter->opcMask = 0;
    rtFilter->sio = 0;
    rtFilter->sioMask = 0;
    rtFilter->sls = 0;
    rtFilter->slsMask = 0;
    rtFilter->ssn = 0;
    rtFilter->tridEnd = 0;
    rtFilter->tridStart = 0;
    
    switch(rtecfg->RouteMode)
    {
        case EN_RT_DPC:
        {
            rtFilter->dpcMask = dpcMask;
            rtFilter->dpc = rtecfg->DPCValue;
            break;
        }
        
        case EN_RT_OPC:
        {
            rtFilter->opcMask = dpcMask;
            rtFilter->opc = rtecfg->OPCValue;
            break;
        }
        
        case EN_RT_DPC_SIO:
        {
            rtFilter->dpcMask = dpcMask;
            rtFilter->dpc = rtecfg->DPCValue;
            rtFilter->sioMask = IT_RTE_SIO_MASK;
            rtFilter->sio = rtecfg->SIO;
            break;
        }
        
        case EN_RT_DPC_OPC_SIO:
        {
            rtFilter->dpcMask = dpcMask;
            rtFilter->dpc = rtecfg->DPCValue;
            rtFilter->opcMask = dpcMask;
            rtFilter->opc = rtecfg->OPCValue;
            rtFilter->sioMask = IT_RTE_SIO_MASK;
            rtFilter->sio = rtecfg->SIO;
            break;
        }
        
        case EN_RT_DPC_SIO_CIC:
        {
            rtFilter->dpcMask = dpcMask;
            rtFilter->dpc = rtecfg->DPCValue;
            rtFilter->sioMask = IT_RTE_SIO_MASK;
            rtFilter->sio = rtecfg->SIO;
            rtFilter->includeCic = TRUE;
            rtFilter->cicStart = rtecfg->CICStart;
            rtFilter->cicEnd = rtecfg->CICEnd;
            break;
        }
        
        case EN_RT_DPC_OPC_SIO_CIC:
        {
            rtFilter->dpcMask = dpcMask;
            rtFilter->dpc = rtecfg->DPCValue;
            rtFilter->opcMask = dpcMask;
            rtFilter->opc = rtecfg->OPCValue;
            rtFilter->sioMask = IT_RTE_SIO_MASK;
            rtFilter->sio = rtecfg->SIO;
            rtFilter->includeCic = TRUE;
            rtFilter->cicStart = rtecfg->CICStart;
            rtFilter->cicEnd = rtecfg->CICEnd;
            break;
        }
        
        case EN_RT_DPC_SIO_SSN:
        {
            rtFilter->dpcMask = dpcMask;
            rtFilter->dpc = rtecfg->DPCValue;
            rtFilter->sioMask = IT_RTE_SIO_MASK;
            rtFilter->sio = rtecfg->SIO;
            rtFilter->includeSsn = TRUE;
            rtFilter->ssn = rtecfg->SSN;
            break;
        }
        
        case EN_RT_DPC_OPC_SIO_SSN:
        {
            rtFilter->dpcMask = dpcMask;
            rtFilter->dpc = rtecfg->DPCValue;
            rtFilter->opcMask = dpcMask;
            rtFilter->opc = rtecfg->OPCValue;
            rtFilter->sioMask = IT_RTE_SIO_MASK;
            rtFilter->sio = rtecfg->SIO;
            rtFilter->includeSsn = TRUE;
            rtFilter->ssn = rtecfg->SSN;
            break;
        }
        
        case EN_RT_DPC_OPC:
        {
            rtFilter->dpcMask = dpcMask;
            rtFilter->dpc = rtecfg->DPCValue;
            rtFilter->opcMask = dpcMask;
            rtFilter->opc = rtecfg->OPCValue;
            break;
        }
        
        case EN_RT_OPC_SIO:
        {
            rtFilter->opcMask = dpcMask;
            rtFilter->opc = rtecfg->OPCValue;
            rtFilter->sioMask = IT_RTE_SIO_MASK;
            rtFilter->sio = rtecfg->SIO;
            break;
        }
        
        case EN_RT_OPC_SIO_CIC:
        {
            rtFilter->opcMask = dpcMask;
            rtFilter->opc = rtecfg->OPCValue;
            rtFilter->sioMask = IT_RTE_SIO_MASK;
            rtFilter->sio = rtecfg->SIO;
            rtFilter->includeCic = TRUE;
            rtFilter->cicStart = rtecfg->CICStart;
            rtFilter->cicEnd = rtecfg->CICEnd;
            break;
        }

        case EN_RT_DPC_SIO_TRID:
        {
            rtFilter->dpcMask = dpcMask;
            rtFilter->dpc = rtecfg->DPCValue;
            rtFilter->sioMask = IT_RTE_SIO_MASK;
            rtFilter->sio = rtecfg->SIO;
            rtFilter->includeTrid = TRUE;
            rtFilter->tridStart = rtecfg->TridStart;
            rtFilter->tridEnd = rtecfg->TridEnd;
            break;
        }

        case EN_RT_DPC_OPC_SIO_TRID:
        {
            rtFilter->dpcMask = dpcMask;
            rtFilter->dpc = rtecfg->DPCValue;
            rtFilter->opcMask = dpcMask;
            rtFilter->opc = rtecfg->OPCValue;
            rtFilter->sioMask = IT_RTE_SIO_MASK;
            rtFilter->sio = rtecfg->SIO;
            rtFilter->includeTrid = TRUE;
            rtFilter->tridStart = rtecfg->TridStart;
            rtFilter->tridEnd = rtecfg->TridEnd;
            break;
        }

        case EN_RT_OPC_SIO_TRID:
        {
            rtFilter->opcMask = dpcMask;
            rtFilter->opc = rtecfg->OPCValue;
            rtFilter->sioMask = IT_RTE_SIO_MASK;
            rtFilter->sio = rtecfg->SIO;
            rtFilter->includeTrid = TRUE;
            rtFilter->tridStart = rtecfg->TridStart;
            rtFilter->tridEnd = rtecfg->TridEnd;
            break;
        }
        
        default:
        {    
            CPDBGP("itBuildRteFilter(rtecfg->RouteMode error)\r\n");
            RETVALUE(RFAILED);
        }
    }
    RETVALUE(ROK);
}

