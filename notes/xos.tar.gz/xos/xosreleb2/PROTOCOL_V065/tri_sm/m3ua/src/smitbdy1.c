/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**

     Name:     smitbdy1.c - Dummy Stack Manager (Layer Manager) for the
               M3UA layer

     Type:     C source file

     Desc:     C code for layer manager service provider primitives that
               are usually supplied by the customer.  Dumps contents to
               standard output.

     File:     smitbdy1.c

     Sid:      smitbdy1.c@@/main/7 - Thu Apr  1 03:49:13 2004

     Prg:      jdb

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "lit.h"           /* layer management M3UA  */
#include "sct.h"           /* SCT interface */
#include "snt.h"           /* SNT interface */
#ifdef NF_FTHA             
#include "sht.h"           /* SHT Interface header file */
#else
#ifdef IT_FTHA             
#include "sht.h"           /* SHT Interface header file */
#endif /* IT_FTHA */
#endif /* NF_FTHA */
#include "it.h"            /* M3UA internal defines */
#include "it_err.h"        /* M3UA error */
#ifdef ZV
#include "cm_ftha.h"       /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.h"       /* The common LDF defines */
#include "cmzvdvlb.h"       /* The common LDF defines */
#endif
#include "mrs.h"           /* Message Router common define */
#include "lzv.h"           /* common PSF */
#include "zv.h"            /* common PSF */
#endif
#ifdef IT_ACC
#include "it_acc.h"        /* acceptance test */
#endif
#ifdef SIG_INT
#include "sig_int.h"
#endif

/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#ifdef NF_FTHA             
#include "sht.x"           /* SHT Interface header file */
#else
#ifdef IT_FTHA             
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#endif /* NF_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "snt.x"           /* SNT interface */
#include "it.x"            /* M3UA internal typedefs */
#ifdef ZV
#include "cm_ftha.x"          /* common PSF */
#include "cm_psfft.x"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.x"       /* The LDF common data structs */
#include "cmzvdvlb.x"       /* The LDF common data structs */
#endif
#include "mrs.x"       /* The LDF common data structs */
#include "lzv.x"           /* common PSF */
#include "zv.x"            /* common PSF */
#endif
#ifdef IT_ACC
#include "it_acc.x"        /* acceptance test */
#endif
#ifdef SIG_INT
#include "sig_int.x"
#endif




/* local defines */
#define STRTAG(x)                { x, #x }
#define NOT_FOUND                (-1)

/* local typedefs */
typedef struct smItStrTag
{
   S16      tag;
   Txt      *txt;
} SmItStrTag;

/* forward references */
#ifdef DEBUGP
PRIVATE Void smitPrintCfm ARGS((ItMgmt  *mgt));


/* private function definitions */
PRIVATE Txt *smItTag2Str ARGS(( SmItStrTag *tagArray, S16  tag));

/* public variable declarations */
PRIVATE Txt prntBuf[PRNTSZE];
#endif

#ifdef DEBUGP

PRIVATE SmItStrTag statusTable[] =
{
   STRTAG(LCM_PRIM_OK),
   STRTAG(LCM_PRIM_NOK),
   STRTAG(LCM_PRIM_OK_NDONE),
   STRTAG(NOT_FOUND)
};

PRIVATE SmItStrTag reasonTable[] =
{
   STRTAG(LCM_REASON_NOT_APPL),
   STRTAG(LCM_REASON_INVALID_ENTITY),
   STRTAG(LCM_REASON_INVALID_INSTANCE),
   STRTAG(LCM_REASON_INVALID_MSGTYPE),
   STRTAG(LCM_REASON_MEM_NOAVAIL),
   STRTAG(LCM_REASON_INVALID_ELMNT),
   STRTAG(LCM_REASON_RECONFIG_FAIL),
   STRTAG(LCM_REASON_REGTMR_FAIL),
   STRTAG(LCM_REASON_GENCFG_NOT_DONE),
   STRTAG(LCM_REASON_INVALID_ACTION),
   STRTAG(LCM_REASON_INVALID_SUBACTION),
   STRTAG(LCM_REASON_INVALID_STATE),
   STRTAG(LCM_REASON_INVALID_SAP),
   STRTAG(LCM_REASON_INVALID_PAR_VAL),
   STRTAG(LCM_REASON_QINIT_FAIL),
   STRTAG(LCM_REASON_NEG_CFM),
   STRTAG(LCM_REASON_UPDTMR_EXPIRED),
   STRTAG(LCM_REASON_MISC_FAILURE),
   STRTAG(LCM_REASON_EXCEED_CONF_VAL),
   STRTAG(LCM_REASON_HASHING_FAILED),
   STRTAG(LCM_REASON_PEERCFG_NOT_DONE),
   STRTAG(LCM_REASON_PRTLYRCFG_NOT_DONE),
   STRTAG(LIT_REASON_INVALID_PSID),
   STRTAG(LIT_REASON_INVALID_NWKID),
   STRTAG(LIT_REASON_INVALID_PSPID),
   STRTAG(LIT_REASON_INVALID_RTENT),
   STRTAG(LIT_REASON_SERVICE_IN_USE),
   STRTAG(LIT_REASON_MNGMNT_INHIBIT),
   STRTAG(LIT_REASON_INVALID_ASSOCID),
   STRTAG(LIT_REASON_NO_RESPONSE),
   STRTAG(LIT_REASON_INV_PEERTYPE),
   STRTAG(LIT_REASON_INV_PEER_STATE),
   STRTAG(LIT_REASON_MSG_NOT_SENT),
   STRTAG(LIT_REASON_UNREG_RK),
   STRTAG(LIT_REASON_INVALID_RK),
   STRTAG(LIT_REASON_INVALID_RC),
   STRTAG(LIT_REASON_PSID_ALREADY_USED),
   STRTAG(LIT_REASON_RKREGREQ_PEND),
   STRTAG(LIT_REASON_RKDEREGREQ_PEND),
   STRTAG(LIT_REASON_INV_PEER_STATE),
   STRTAG(LIT_REASON_DRKM_NOT_SUPP),
   STRTAG(LIT_REASON_INVALID_THM),
   STRTAG(LIT_REASON_OVERLAPPING_THM),
   STRTAG(LIT_REASON_INVALID_CONG_LEVEL),
   STRTAG(LIT_REASON_INVALID_DPC),
   STRTAG(LIT_REASON_PS_NOT_LOCAL),
   STRTAG(LIT_REASON_NSAP_CFGED_LPS),
   STRTAG(NOT_FOUND)
};

PRIVATE SmItStrTag categoryTable[] =
{
   STRTAG(LCM_CATEGORY_PROTOCOL),
   STRTAG(LCM_CATEGORY_INTERFACE),
   STRTAG(LCM_CATEGORY_INTERNAL),
   STRTAG(LCM_CATEGORY_RESOURCE),
   STRTAG(LCM_CATEGORY_PSF_FTHA),
   STRTAG(LIT_CATEGORY_CNTRL),
   STRTAG(LIT_CATEGORY_STATUS),
   STRTAG(NOT_FOUND)
};

PRIVATE SmItStrTag eventTable[] =
{
   STRTAG(LCM_EVENT_UI_INV_EVT),
   STRTAG(LCM_EVENT_LI_INV_EVT),
   STRTAG(LCM_EVENT_PI_INV_EVT),
   STRTAG(LCM_EVENT_INV_EVT),
   STRTAG(LCM_EVENT_INV_STATE),
   STRTAG(LCM_EVENT_INV_TMR_EVT),
   STRTAG(LCM_EVENT_MI_INV_EVT),
   STRTAG(LCM_EVENT_BND_FAIL),
   STRTAG(LCM_EVENT_NAK),
   STRTAG(LCM_EVENT_TIMEOUT),
   STRTAG(LCM_EVENT_BND_OK),
   STRTAG(LCM_EVENT_SMEM_ALLOC_FAIL),
   STRTAG(LCM_EVENT_DMEM_ALLOC_FAIL),
   STRTAG(LIT_EVENT_MSG_FAIL),
   STRTAG(LIT_EVENT_ESTABLISH_FAIL),
   STRTAG(LIT_EVENT_ESTABLISH_OK),
   STRTAG(LIT_EVENT_ASPM),
   STRTAG(LIT_EVENT_NOTIFY),
   STRTAG(LIT_EVENT_M3UA_PROTO_ERROR),
   STRTAG(LIT_EVENT_ASP_DOWN),
   STRTAG(LIT_EVENT_ASP_ACTIVE),
   STRTAG(LIT_EVENT_ASP_INACTIVE),
   STRTAG(LIT_EVENT_ASSOC_INHIBIT),
   STRTAG(LIT_EVENT_TERM_IND),
   STRTAG(LIT_EVENT_FLC_DROP),
   STRTAG(LIT_EVENT_LI_INV_PAR),
   STRTAG(LIT_EVENT_STATUS_IND),
   STRTAG(LIT_EVENT_SCT_SEND_FAIL),
   STRTAG(LIT_EVENT_HBEAT_LOST),
   STRTAG(LIT_EVENT_AS_DOWN),
   STRTAG(LIT_EVENT_AS_ACTIVE),
   STRTAG(LIT_EVENT_AS_INACTIVE),
   STRTAG(LIT_EVENT_AS_PENDING),
   STRTAG(LIT_EVENT_SCT_COMM_DOWN),
   STRTAG(LIT_EVENT_ASPAC_FAIL),
   STRTAG(LIT_EVENT_ASPIA_FAIL),
   STRTAG(LIT_EVENT_PC_UNAVAILABLE),
   STRTAG(LIT_EVENT_PC_CONGESTED),
   STRTAG(LIT_EVENT_PC_AVAILABLE),
   STRTAG(LIT_EVENT_PC_RESTRICTED),
   STRTAG(LIT_EVENT_PC_USER_PART_UNA),
   STRTAG(LIT_EVENT_EOPEN_OK),
   STRTAG(LIT_EVENT_EOPEN_FAIL),
   STRTAG(LIT_EVENT_PC_RESTRICTED),
   STRTAG(LIT_EVENT_RK_TMOUT),
   STRTAG(LIT_EVENT_REG_FAILURE),
   STRTAG(LIT_EVENT_DEREG_FAILURE),
   STRTAG(LIT_EVENT_RK_REGISTERED),
   STRTAG(LIT_EVENT_RK_DEREGISTERED),
   STRTAG(LIT_EVENT_INV_LCLRKID),
   STRTAG(LIT_EVENT_PS_DELETED),
   STRTAG(LIT_EVENT_RC_GENERATED),
   STRTAG(LIT_EVENT_INV_MSG_RXD),
   STRTAG(LIT_EVENT_DAUD_RXD),
   STRTAG(LIT_EVENT_RC_DELETED),
   STRTAG(LIT_EVENT_PSP_REGD),
   STRTAG(LIT_EVENT_NO_ROUTE_FOUND),
   STRTAG(LIT_EVENT_SRCADDRLST_CHG),
   STRTAG(LIT_EVENT_DSTADDRLST_CHG),
   STRTAG(LIT_EVENT_PRIDSTADDR_CHG),
   /* it006.106 - new events added */
   STRTAG(LIT_EVENT_ECLOSE_OK),
   STRTAG(LIT_EVENT_ECLOSE_NOK),
   STRTAG(NOT_FOUND)
};

PRIVATE SmItStrTag causeTable[] =
{
   STRTAG(LCM_CAUSE_UNKNOWN),
   STRTAG(LCM_CAUSE_OUT_OF_RANGE),
   STRTAG(LCM_CAUSE_INV_SAP),
   STRTAG(LCM_CAUSE_INV_SPID),
   STRTAG(LCM_CAUSE_INV_SUID),
   STRTAG(LCM_CAUSE_INV_NETWORK_MSG),
   STRTAG(LCM_CAUSE_DECODE_ERR),
   STRTAG(LCM_CAUSE_USER_INITIATED),
   STRTAG(LCM_CAUSE_MGMT_INITIATED),
   STRTAG(LCM_CAUSE_INV_STATE),
   STRTAG(LCM_CAUSE_TMR_EXPIRED),
   STRTAG(LCM_CAUSE_INV_MSG_LENGTH),
   STRTAG(LCM_CAUSE_PROT_NOT_ACTIVE),
   STRTAG(LCM_CAUSE_INV_PAR_VAL),
   STRTAG(LIT_CAUSE_INV_VERSION),
   STRTAG(LIT_CAUSE_INV_NWK_APP),
   STRTAG(LIT_CAUSE_UNSUP_MSG_CLASS),
   STRTAG(LIT_CAUSE_UNSUP_MSG_TYPE),
   STRTAG(LIT_CAUSE_INV_TRAFFIC_MODE),
   STRTAG(LIT_CAUSE_UNEXP_MSG),
   STRTAG(LIT_CAUSE_PROTO_ERR),
   STRTAG(LIT_CAUSE_INV_RCTX),
   STRTAG(LIT_CAUSE_INV_STRMID),
   STRTAG(LIT_CAUSE_INV_M3UA_PARMVAL),
   STRTAG(LIT_CAUSE_RETRY_EXCEED),
   STRTAG(LIT_CAUSE_STATUS_CHANGE),
   STRTAG(LIT_CAUSE_MSG_RECEIVED),
   STRTAG(LIT_CAUSE_RFSD_MGMT_BLKD),
   STRTAG(LIT_CAUSE_INV_DPC),
   STRTAG(LIT_CAUSE_RKM_PER_DENIED),
   STRTAG(LIT_CAUSE_OVERLAP_RK),
   STRTAG(LIT_CAUSE_RK_NOT_PRVISONED),
   STRTAG(LIT_CAUSE_INSF_RSRC),
   STRTAG(LIT_CAUSE_UNSUPP_RK_PRMTR),
   STRTAG(LIT_CAUSE_INV_RK),
   STRTAG(LIT_CAUSE_RK_REG_NO_RESP),
   STRTAG(LIT_CAUSE_RK_REG_PARTIAL_RESP),
   STRTAG(LIT_CAUSE_RK_DEREG_NO_RESP),
   STRTAG(LIT_CAUSE_RK_DEREG_PARTIAL_RESP),
   STRTAG(LIT_CAUSE_PSP_ACTIVE),
   STRTAG(LIT_CAUSE_RCTX_UNREG),
   STRTAG(LIT_CAUSE_PS_DELETED),
   STRTAG(LIT_CAUSE_RK_REGISTERED),
   STRTAG(LIT_CAUSE_DAUD_RXD),
   STRTAG(LIT_CAUSE_SCT_TERM_IND),
   STRTAG(LIT_CAUSE_RK_DEREGISTERED),
   STRTAG(LIT_CAUSE_DPC_STATUS_UNKNOWN),
   STRTAG(LIT_CAUSE_PARAM_FIELD_ERROR),
   STRTAG(LIT_CAUSE_UNEXPECTED_PARAM),
   STRTAG(LIT_CAUSE_NO_AS_FOR_ASP),
   STRTAG(LIT_CAUSE_REMOTE_SHUTDOWN),
   STRTAG(LIT_CAUSE_REMOTE_ABORT),
   STRTAG(LIT_CAUSE_COMM_LOST),
   STRTAG(LIT_CAUSE_SCT_RESTART),
   STRTAG(LIT_CAUSE_LOCAL_SCTP_PROCERR),
   STRTAG(LIT_CAUSE_ASSOC_INHIBIT),
   STRTAG(LIT_CAUSE_M3UA_HBEAT_LOST),
   STRTAG(LIT_CAUSE_LOCAL_SHUTDOWN),
   STRTAG(LIT_CAUSE_SHUTDOWN_CMPLT),
   STRTAG(LIT_CAUSE_PEER_ASSOC_PARAMS),
   STRTAG(NOT_FOUND)
};

PRIVATE SmItStrTag elementTable[] =
{
   STRTAG(STITSID),
   STRTAG(STITGEN),
   STRTAG(STITNSAP),
   STRTAG(STITSCTSAP),
   STRTAG(STITNWK),
   STRTAG(STITROUT),
   STRTAG(STITPS),
   STRTAG(STITPSP),
   STRTAG(STITADRTRAN),
   STRTAG(STITAPC),
   STRTAG(NOT_FOUND)
};

#endif /* DEBUGP */


/* private routines */

#ifdef DEBUGP
/*
 *
 *       Fun:    smItTag2Str
 *
 *       Desc:   Converts the tag to its string representation
 *
 *       Ret:    pointer to string representation
 *
 *       Notes:  None
 *
 *       File:   smitbdy1.c
 *
 */

#ifdef ANSI
PRIVATE Txt *smItTag2Str
(
SmItStrTag           *tagArray,
S16                  tag
)
#else
PRIVATE Txt *smItTag2Str(tagArray, tag)
SmItStrTag           *tagArray;
S16                  tag;
#endif /* ANSI */
{
   U16 i;

   TRC3(smItTag2Str)

   for (i = 0; tagArray[i].tag != NOT_FOUND; i++)
   {
      if (tagArray[i].tag == tag)
      {
         break;
      }
   }

   RETVALUE(tagArray[i].txt);
} /* end of smItTag2Str */
#endif

/* public routines */
/*
 *
 *       Fun:    SmMiLitCfgCfm - configuration confirm
 *
 *       Desc:   prints the config confirm status
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
 *       File:   smitbdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLitCfgCfm
(
Pst         *pst,
ItMgmt      *cfg
)
#else
PUBLIC S16 SmMiLitCfgCfm(pst, cfg)
Pst         *pst;
ItMgmt      *cfg;
#endif /* ANSI */
{
#ifdef IT_ACC
   AccMsgQElm QElm;
#endif

   UNUSED(pst);

   TRC3(SmMiLitCfgCfm)

#ifdef IT_ACC
   /* Pack primitive data in queue structure */
   cmMemset((U8 *)&QElm, 0, sizeof(QElm));
   QElm.evntType = ACC_EVT_CFG_CFM; /* Override pst->event */
   QElm.t.mgmtMsg = *cfg;

   (Void) accPushMsg(&QElm);
#endif
#ifdef SIG_INT
   {
      IntMsgQElm qElm;
      qElm.msgType = INT_MSGTYPE_LITCFGCFM;
      qElm.cfm = cfg->cfm;
      intPushMsg(&qElm);
   }
#endif

#ifdef DEBUGP
    if ( IT_DBGMASK_DUMMYSM & itGlobalCb.itInit.dbgMask )
    {
   sprintf(prntBuf,"*[SMIT] CfgCfm: \n");
   SPrint(prntBuf);
   smitPrintCfm(cfg);
    }
#endif

   RETVALUE(ROK);
} /* end of SmMiLitCfgCfm() */

/*
 *
 *       Fun:    SmMiLitStsCfm - statistics confirm
 *
 *       Desc:   prints the statistics confirm status
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
 *       File:   smitbdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLitStsCfm
(
Pst                  *pst,
ItMgmt               *sts
)
#else
PUBLIC S16 SmMiLitStsCfm(pst, sts)
Pst                  *pst;
ItMgmt               *sts;
#endif /* ANSI */
{
#ifdef IT_ACC
   AccMsgQElm QElm;
#endif

   TRC3(SmMiLitStsCfm)

   UNUSED(pst);

#ifdef IT_ACC
   /* Pack primitive data in queue structure */
   cmMemset((U8 *)&QElm, 0, sizeof(QElm));
   QElm.evntType = ACC_EVT_STS_CFM; /* Override pst->event */
   QElm.t.mgmtMsg = *sts;

   (Void) accPushMsg(&QElm);
#endif
#ifdef SIG_INT
   {
      IntMsgQElm qElm;
      qElm.msgType = INT_MSGTYPE_LITSTSCFM;
      qElm.elmnt = sts->hdr.elmId.elmnt;
      qElm.u.lit.u.sts = sts->t.sts;
      intPushMsg(&qElm);
   }
#endif

#ifdef DEBUGP
    if ( IT_DBGMASK_DUMMYSM & itGlobalCb.itInit.dbgMask )
    {
   sprintf(prntBuf, "*[SMIT] StsCfm: \n");
   SPrint(prntBuf);
   smitPrintCfm(sts);
    }
#endif /* DEBUGP */

   RETVALUE(ROK);
} /* end of SmMiLitStsCfm() */

/*
 *
 *       Fun:    SmMiLitStaCfm - status confirm
 *
 *       Desc:   prints the status confirm status
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
 *       File:   smitbdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLitStaCfm
(
Pst                  *pst,
ItMgmt               *ssta
)
#else
PUBLIC S16 SmMiLitStaCfm(pst, ssta)
Pst                  *pst;
ItMgmt               *ssta;
#endif /* ANSI */
{
#ifdef IT_ACC
   AccMsgQElm QElm;
#endif

   TRC3(SmMiLitStaCfm)

   UNUSED(pst);

#ifdef IT_ACC
   /* Pack primitive data in queue structure */
   cmMemset((U8 *)&QElm, 0, sizeof(QElm));
   QElm.evntType = ACC_EVT_STA_CFM; /* Override pst->event */
   QElm.t.mgmtMsg = *ssta;
   if ((QElm.t.mgmtMsg.hdr.elmId.elmnt == STITSID) &&
       (QElm.t.mgmtMsg.cfm.status == ROK))
   {
      cmMemcpy((U8*)QElm.ptNmb, (U8*)ssta->t.ssta.s.sysId.ptNmb, 8);
   }


   (Void) accPushMsg(&QElm);
#endif

#ifdef DEBUGP
    if ( IT_DBGMASK_DUMMYSM & itGlobalCb.itInit.dbgMask )
    {
   sprintf(prntBuf, "*[SMIT] StaCfm: \n");
   SPrint(prntBuf);
  
   smitPrintCfm(ssta);
    }
#endif /* DEBUGP */

   RETVALUE(ROK);
} /* end of SmMiLitStaCfm() */

/*
 *
 *       Fun:    SmMiLitCntrlCfm - control confirm
 *
 *       Desc:   prints the control confirm status
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
 *       File:   smitbdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLitCntrlCfm
(
Pst         *pst,
ItMgmt      *cntrl
)
#else
PUBLIC S16 SmMiLitCntrlCfm(pst, cntrl)
Pst         *pst;
ItMgmt      *cntrl;
#endif /* ANSI */
{
#ifdef IT_ACC
   AccMsgQElm QElm;
#endif

   TRC3(SmMiLitCntrlCfm)

   UNUSED(pst);

#ifdef IT_ACC
   cmMemset((U8 *)&QElm, 0, sizeof(QElm));
   QElm.evntType = ACC_EVT_CNTRL_CFM; /* Override pst->event */
   QElm.t.mgmtMsg = *cntrl;

   (Void) accPushMsg(&QElm);
#endif
#ifdef SIG_INT
   {
      IntMsgQElm qElm;
      qElm.msgType = INT_MSGTYPE_LITCNTRLCFM;
      qElm.cfm = cntrl->cfm;
      intPushMsg(&qElm);
   }
#endif

#ifdef DEBUGP
    if ( IT_DBGMASK_DUMMYSM & itGlobalCb.itInit.dbgMask )
    {
   sprintf(prntBuf,"*[SMIT] CntrlCfm: \n");
   SPrint(prntBuf);
   smitPrintCfm(cntrl);
    }
#endif
   RETVALUE(ROK);
} /* end of SmMiLitCntrlCfm() */

/*
 *
 *       Fun:    SmMiLitStaInd - status indication
 *
 *       Desc:   prints the status indication (alarm)
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
 *       File:   smitbdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLitStaInd
(
Pst         *pst,
ItMgmt      *usta
)
#else
PUBLIC S16 SmMiLitStaInd(pst, usta)
Pst         *pst;
ItMgmt      *usta;
#endif /* ANSI */
{
#ifdef IT_ACC
   AccMsgQElm QElm;
#endif

#ifdef DEBUGP
   S32   id;
   U16   i;
#endif

   TRC3(SmMiLitStaInd)

#ifdef IT_RUG
   if (accCb.curTst.testCb.id == 180004)
   {
      if (pst->intfVer != (LITIFVER - 1))
         RETVALUE(RFAILED);
         
   }
   else
#endif
   UNUSED(pst);

#ifdef IT_ACC
   cmMemset((U8 *)&QElm, 0, sizeof(QElm));
   QElm.t.mgmtMsg = *usta;
   QElm.evntType = ACC_EVT_STA_IND;

#ifdef LIT_RTE_ALARMS
   if ((usta->t.usta.alarm.event != LIT_EVENT_RTE_AVAIL) &&
       (usta->t.usta.alarm.event != LIT_EVENT_RTE_UNAVAIL))
     (Void) accPushMsg(&QElm);
   else
     RETVALUE(ROK);
#else /* LIT_RTE_ALARMS */
   (Void) accPushMsg(&QElm);
#endif /* LIT_RTE_ALARMS */
#endif
#ifdef SIG_INT
   {
      IntMsgQElm qElm;
      qElm.msgType = INT_MSGTYPE_LITSTAIND;
      qElm.elmnt = usta->hdr.elmId.elmnt;
      qElm.alarm = usta->t.usta.alarm;
      qElm.u.lit.u.usta = usta->t.usta;
      intPushMsg(&qElm);
   }
#endif
#ifdef DEBUGP
   switch(usta->hdr.elmId.elmnt)
   {
      case STITNSAP:
         id = usta->t.usta.s.spId;
         break;
      case STITSCTSAP:
         id = usta->t.usta.s.suId;
         break;
      case STITPSP:
         id = usta->t.usta.s.pspId;
         break;
      case STITPS:
         id = usta->t.usta.s.psId;
         break;
      case STITAPC:
         id = usta->t.usta.t.dpcEvt.aPc;
         break;
      default:
         id = -1;
         break;
   }

/*chenning Modify for contrl sta ind printf*/
    if ( IT_DBGMASK_DUMMYSM & itGlobalCb.itInit.dbgMask )
    {
#ifdef BIT_64
   sprintf(prntBuf,
      "*[SMIT] StaInd: cat   = %s,\n"
      "*               event = %s,\n"
      "*               cause = %s,\n"
      "*             element = %s,\n"
      "*               id    = %d\n",
      smItTag2Str(categoryTable, usta->t.usta.alarm.category),
      smItTag2Str(eventTable, usta->t.usta.alarm.event),
      smItTag2Str(causeTable, usta->t.usta.alarm.cause),
      smItTag2Str(elementTable, usta->hdr.elmId.elmnt), id);
#else
   sprintf(prntBuf,
      "*[SMIT] StaInd: cat   = %s,\n"
      "*               event = %s,\n"
      "*               cause = %s,\n"
      "*             element = %s,\n"
      "*               id    = %ld\n",
      smItTag2Str(categoryTable, usta->t.usta.alarm.category),
      smItTag2Str(eventTable, usta->t.usta.alarm.event),
      smItTag2Str(causeTable, usta->t.usta.alarm.cause),
      smItTag2Str(elementTable, usta->hdr.elmId.elmnt), id);
#endif

        SPrint(prntBuf);
   
   switch (usta->t.usta.alarm.event)
   {
      case LIT_EVENT_RK_REGISTERED:
#ifdef BIT_64
         sprintf(prntBuf,
            "*     Routing Context = %d,\n"
            "*         LOCAL RK ID = %d,\n"
            "*               PS ID = %d,\n",
             usta->t.usta.t.drkmEvt.rteCtx,
             usta->t.usta.t.drkmEvt.lclRkId,
             usta->t.usta.t.drkmEvt.psId);
#else
         sprintf(prntBuf,
            "*     Routing Context = %ld,\n"
            "*         LOCAL RK ID = %ld,\n"
            "*               PS ID = %ld,\n",
             usta->t.usta.t.drkmEvt.rteCtx,
             usta->t.usta.t.drkmEvt.lclRkId,
             usta->t.usta.t.drkmEvt.psId);
#endif
         SPrint(prntBuf);
#ifdef BIT_64
         sprintf(prntBuf,
            "*              RK DPC = %d,\n",
             usta->t.usta.t.drkmEvt.rtKey.dpc);
#else
         sprintf(prntBuf,
            "*              RK DPC = %ld,\n",
             usta->t.usta.t.drkmEvt.rtKey.dpc);
#endif
         SPrint(prntBuf);
         sprintf(prntBuf,
            "*         RK NUMB OPC = %d,\n",
             usta->t.usta.t.drkmEvt.rtKey.nmbOpc);
         SPrint(prntBuf);
       for (i = 0; i < usta->t.usta.t.drkmEvt.rtKey.nmbOpc; i++)
         {
#ifdef BIT_64
            sprintf(prntBuf,
               "*              RK OPC = %d,\n",
                usta->t.usta.t.drkmEvt.rtKey.opc[i]);
#else
            sprintf(prntBuf,
               "*              RK OPC = %ld,\n",
                usta->t.usta.t.drkmEvt.rtKey.opc[i]);
#endif
            SPrint(prntBuf);
         }
         sprintf(prntBuf,
            "*         RK NUMB SIO = %d,\n",
             usta->t.usta.t.drkmEvt.rtKey.nmbSio);
         SPrint(prntBuf);
       for (i = 0; i < usta->t.usta.t.drkmEvt.rtKey.nmbSio; i++)
         {
            sprintf(prntBuf,
               "*              RK SIO = %d,\n",
                usta->t.usta.t.drkmEvt.rtKey.sio[i]);
            SPrint(prntBuf);
         }
         sprintf(prntBuf,
            "*         RK NUMB CIC = %d,\n",
             usta->t.usta.t.drkmEvt.rtKey.nmbCic);
         SPrint(prntBuf);
       for (i = 0; i < usta->t.usta.t.drkmEvt.rtKey.nmbCic; i++)
         {
#ifdef BIT_64
            sprintf(prntBuf,
               "*          RK CIC OPC = %d,\n"
               "*        RK CIC LOWER = %d,\n"
               "*        RK CIC UPPER = %d,\n",
                usta->t.usta.t.drkmEvt.rtKey.cicRange[i].opc,
                usta->t.usta.t.drkmEvt.rtKey.cicRange[i].cicStart,
                usta->t.usta.t.drkmEvt.rtKey.cicRange[i].cicEnd);
#else
            sprintf(prntBuf,
               "*          RK CIC OPC = %ld,\n"
               "*        RK CIC LOWER = %d,\n"
               "*        RK CIC UPPER = %d,\n",
                usta->t.usta.t.drkmEvt.rtKey.cicRange[i].opc,
                usta->t.usta.t.drkmEvt.rtKey.cicRange[i].cicStart,
                usta->t.usta.t.drkmEvt.rtKey.cicRange[i].cicEnd);
#endif
            SPrint(prntBuf);
         }
       break;
      case LIT_EVENT_RC_GENERATED:
#ifdef BIT_64
         sprintf(prntBuf,
            "*     Routing Context = %d,\n",
             usta->t.usta.t.drkmEvt.rteCtx);
#else
         sprintf(prntBuf,
            "*     Routing Context = %ld,\n",
             usta->t.usta.t.drkmEvt.rteCtx);
#endif
         SPrint(prntBuf);
       break;
      case LIT_EVENT_RK_DEREGISTERED:
#ifdef BIT_64
         sprintf(prntBuf,
            "*     Routing Context = %d,\n",
             usta->t.usta.t.drkmEvt.rteCtx);
#else
         sprintf(prntBuf,
            "*     Routing Context = %ld,\n",
             usta->t.usta.t.drkmEvt.rteCtx);
#endif
         SPrint(prntBuf);
       break;
      case LIT_EVENT_RK_TMOUT:       
       break;
      case LIT_EVENT_REG_FAILURE:    
#ifdef BIT_64
         sprintf(prntBuf,
            "*         LOCAL RK ID = %d,\n",
             usta->t.usta.t.drkmEvt.lclRkId);
#else
         sprintf(prntBuf,
            "*         LOCAL RK ID = %ld,\n",
             usta->t.usta.t.drkmEvt.lclRkId);
#endif
         SPrint(prntBuf);
       break;
      case LIT_EVENT_DEREG_FAILURE:  
#ifdef BIT_64
         sprintf(prntBuf,
            "*     Routing Context = %d,\n",
             usta->t.usta.t.drkmEvt.rteCtx);
#else
         sprintf(prntBuf,
            "*     Routing Context = %ld,\n",
             usta->t.usta.t.drkmEvt.rteCtx);
#endif
         SPrint(prntBuf);
       break;
      case LIT_EVENT_INV_LCLRKID:    
#ifdef BIT_64
         sprintf(prntBuf,
            "*     Routing Context = %d,\n"
            "*         LOCAL RK ID = %d,\n",
             usta->t.usta.t.drkmEvt.rteCtx,
             usta->t.usta.t.drkmEvt.lclRkId);
#else
         sprintf(prntBuf,
            "*     Routing Context = %ld,\n"
            "*         LOCAL RK ID = %ld,\n",
             usta->t.usta.t.drkmEvt.rteCtx,
             usta->t.usta.t.drkmEvt.lclRkId);
#endif
         SPrint(prntBuf);
       break;
      default:
       break;
   }
    }
#endif /* DEBUGP */

   RETVALUE(ROK);
} /* end of SmMiLitStaInd() */

/*
 *
 *       Fun:    SmMiLitTrcInd - trace indication
 *
 *       Desc:   prints the trace indication
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
 *       File:   smitbdy1.c
 *
 */

#ifdef ANSI
PUBLIC S16 SmMiLitTrcInd
(
Pst                  *pst,
ItMgmt               *trc
)
#else
PUBLIC S16 SmMiLitTrcInd(pst, trc)
Pst                  *pst;
ItMgmt               *trc;
#endif /* ANSI */
{
#ifdef DEBUGP
   U16               i;
   U16               col;
#endif
#ifdef IT_ACC
   AccMsgQElm QElm;
#endif

   TRC3(SmMiLitTrcInd)

   UNUSED(pst);

#ifdef IT_ACC
   cmMemset((U8 *)&QElm, 0, sizeof(QElm));
   QElm.evntType = ACC_EVT_TRC_IND; /* Override pst->event */
   QElm.t.mgmtMsg = *trc;

   (Void) accPushMsg(&QElm);
#endif

#ifdef DEBUGP
   sprintf(prntBuf, "*[SMIT] TrcInd:\n");
   SPrint(prntBuf);

   trc->cfm.reason = LCM_REASON_NOT_APPL;
   trc->cfm.status = LCM_PRIM_OK;

   smitPrintCfm(trc);

   SPrint("\n* Data =");
   col = 9;
   for (i = 0; i < trc->t.trc.len; i++)
   {
      sprintf(prntBuf, " %02X", trc->t.trc.evntParm[i]);
      SPrint(prntBuf);
      col += 3;
      if (col >= 70)
      {
         SPrint("\n*       ");
         col = 9;
      }
   }
   SPrint("\n");
#endif /* DEBUGP */

   RETVALUE(ROK);
} /* end of SmMiLitTrcInd() */



#ifdef DEBUGP
/*
 *
 *       Fun:    smitPrintCfm - print common confirm structures
 *
 *       Desc:
 *
 *       Ret:    Void
 *
 *       Notes:  None
 *
 *       File:   smitbdy1.c
 *
 */

#ifdef ANSI
PRIVATE Void smitPrintCfm
(
ItMgmt               *mgt
)
#else
PRIVATE Void smitPrintCfm(mgt)
ItMgmt               *mgt;
#endif /* ANSI */
{
   TRC2(smitPrintCfm)

   sprintf(prntBuf,
      "*Status = %s\n*Reason = %s\n*Element = %s\n",
      smItTag2Str(statusTable, mgt->cfm.status),
      smItTag2Str(reasonTable, mgt->cfm.reason),
      smItTag2Str(elementTable, mgt->hdr.elmId.elmnt));
   SPrint(prntBuf);

   RETVOID;
} /* end of smitPrintCfm() */
#endif


#ifdef IT_FTHA
#ifdef IT_ACC
/*
*
*       Fun:    ShMiShtCntrlCfm - control confirm
*
*       Desc:   prints the control confirm status
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   smitbdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 ShMiShtCntrlCfm
(
Pst                  *pst,       /* Post structure */
ShtCntrlCfmEvnt      *cntrl      /* Confirm structure */
)
#else
PUBLIC S16 ShMiShtCntrlCfm(pst, cntrl)
Pst                  *pst;
ShtCntrlCfmEvnt      *cntrl;
#endif /* ANSI */
{
   AccMsgQElm QElm;

   TRC3(ShMiShtCntrlCfm)

   UNUSED(pst);

   cmMemset((U8 *)&QElm, 0, sizeof(QElm));
   QElm.evntType = ACC_EVT_SHT_CNTRL_CFM; /* Override pst->event */
   QElm.t.cfmEvnt.transId = cntrl->transId;
   QElm.t.cfmEvnt.status.status = cntrl->status.status;
   QElm.t.cfmEvnt.status.reason = cntrl->status.reason;

   (Void) accPushMsg(&QElm);

#ifdef DEBUGP
   sprintf(prntBuf,"*[SHIT] CntrlCfm: \n");
   SPrint(prntBuf);
   sprintf(prntBuf,
      "*Status = %s\n*Reason = %s\n",
      smItTag2Str(statusTable, cntrl->status.status),
      smItTag2Str(reasonTable, cntrl->status.reason));
   SPrint(prntBuf);
#endif

   RETVALUE(ROK);
} /* end of ShMiShtCntrlCfm() */

#endif /* IT_ACC */
#endif /* IT_FTHA */

/********************************************************************30**

         End of file:     smitbdy1.c@@/main/7 - Thu Apr  1 03:49:13 2004

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/3      ---      mrw  1. Initial version
/main/3      ---      as   1. Updates to Release 1.2
/main/4      ---      sg   1. Updates to Release 1.3
/main/5      ---      sg   1. Update to Release 1.4
/main/5    it001.104  sg   1. Added new reason values in reasonTable.
/main/5    it016.104  vt   1. Added new cause values for SCTP termination
/main/5    it022.104  uv   1. Alarms for route alarms are not to be 
                              queued
/main/6      ---      nt   1. Update to Release 1.5
/main/7      ---      rs   1. Update to Release 1.6.
/main/7    it006.106  sg   1. Added new event values for endpoint close cfm.
*********************************************************************91*/
