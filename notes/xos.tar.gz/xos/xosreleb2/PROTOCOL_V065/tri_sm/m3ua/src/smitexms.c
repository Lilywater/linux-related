/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**

     Name:     smitexms.c - stack manager - interface with M3UA layer

     Type:     C source file

     Desc:     Sample C source code for the stack manager.
               - M3UA layer interface primitives.
               - Functions required for unpacking layer management
                 service provider primitives in loosely coupled systems.

     File:     smitexms.c

     Sid:      smitexms.c@@/main/5 - Tue Dec 30 22:32:18 2003

     Prg:      bk

*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "lit.h"           /* layer management M3UA  */
#include "sct.h"           /* SCT interface */
#include "snt.h"           /* SNT interface */
#ifdef NF_FTHA             
#include "sht.h"           /* SHT Interface header file */
#else
#ifdef IT_FTHA             
#include "sht.h"           /* SHT Interface header file */
#endif /* IT_FTHA */
#endif /* NF_FTHA */
#include "it.h"            /* M3UA internal defines */
#include "it_err.h"        /* M3UA error */
#ifdef ZV
#include "cm_ftha.h"       /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.h"       /* The common LDF defines */
#include "cmzvdvlb.h"       /* The common LDF defines */
#endif
#include "mrs.h"           /* Message Router common define */
#include "lzv.h"           /* common PSF */
#include "zv.h"            /* common PSF */
#endif
#ifdef IT_ACC
#include "it_acc.h"        /* M3UA acceptance testing */
#endif /* IT_ACC */

/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#ifdef NF_FTHA             
#include "sht.x"           /* SHT Interface header file */
#else
#ifdef IT_FTHA             
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#endif /* NF_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "snt.x"           /* SNT interface */
#include "it.x"            /* M3UA internal typedefs */
#ifdef ZV
#include "cm_ftha.x"          /* common PSF */
#include "cm_psfft.x"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.x"       /* The LDF common data structs */
#include "cmzvdvlb.x"       /* The LDF common data structs */
#endif
#include "mrs.x"       /* The LDF common data structs */
#include "lzv.x"           /* common PSF */
#include "zv.x"            /* common PSF */
#endif
#ifdef IT_ACC
#include "it_acc.x"        /* M3UA acceptance testing */
#endif /* IT_ACC */


/*
*
*       Fun:   Activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smitbdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 smItActvInit
(
Ent ent,                      /* entity */
Inst inst,                    /* instance */
Region region,                /* region */
Reason reason                 /* reason */
)
#else
PUBLIC S16 smItActvInit(ent, inst, region, reason)
Ent ent;                      /* entity */
Inst inst;                    /* instance */
Region region;                /* region */
Reason reason;                /* reason */
#endif
{
   TRC3(smItActvInit)

   UNUSED(ent);
   UNUSED(inst);
   UNUSED(region);
   UNUSED(reason);
   RETVALUE(ROK);
} /* end of smItActvInit */


/*
*
*       Fun:    activate task
*
*       Desc:   Processes received event from M3UA layer
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   smitexms.c
*
*/

#ifdef ANSI
PUBLIC S16 smItActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 smItActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   S16 ret;

   TRC3(smItActvTsk)

   ret = ROK;
   switch(pst->event)
   {

#ifdef LCITMILIT
      case EVTLITCFGCFM:             /* Config confirm */
         ret = cmUnpkLitCfgCfm(SmMiLitCfgCfm, pst, mBuf);
         break;
      case EVTLITCNTRLCFM:           /* Control confirm */
         ret = cmUnpkLitCntrlCfm(SmMiLitCntrlCfm, pst, mBuf);
         break;
      case EVTLITSTACFM:             /* Status Confirm */
         ret = cmUnpkLitStaCfm(SmMiLitStaCfm, pst, mBuf);
         break;
      case EVTLITSTSCFM:             /* Statistics Confirm */
         ret = cmUnpkLitStsCfm(SmMiLitStsCfm, pst, mBuf);
         break;
      case EVTLITSTAIND:             /* Status Indication */
         ret = cmUnpkLitStaInd(SmMiLitStaInd, pst, mBuf);
         break;
      case EVTLITTRCIND:             /* Trace Indication */
         ret = cmUnpkLitTrcInd(SmMiLitTrcInd, pst, mBuf);
         break;
#endif
      default:
#ifdef ZV
         /* it may be an event for the PSF */
         smZvActvTsk(pst, mBuf);
#else /* ZN */
         SPutMsg(mBuf);
         ret = RFAILED;
#endif
         break;
   }
   SExitTsk();
   RETVALUE(ret);
} /* end of smItActvTsk */

/* The rest of the functions in this document are included to 
   make the inclusion of the sm_bdy1.c and sm_ex_ms.c files
   possible */


#ifdef IT_ACC
#ifdef SI
/*
*
*       Fun:   ISUP layer manager activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smitexms.c
*
*/

#ifdef ANSI
PUBLIC S16 smSiActvInit
(
Ent ent,                      /* entity */
Inst inst,                    /* instance */
Region region,                /* region */
Reason reason                 /* reason */
)
#else
PUBLIC S16 smSiActvInit(ent, inst, region, reason)
Ent ent;                      /* entity */
Inst inst;                    /* instance */
Region region;                /* region */
Reason reason;                /* reason */
#endif
{
   TRC3(smSiActvInit)

   UNUSED(ent);
   UNUSED(inst);
   UNUSED(region);
   UNUSED(reason);
   RETVALUE(ROK);
} /* end of smSiActvInit */


/*
*
*       Fun:    ISUP layer manager activate task
*
*       Desc:   Processes received event from M3UA layer
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   smitexms.c
*
*/

#ifdef ANSI
PUBLIC S16 smSiActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)               
#else
PUBLIC S16 smSiActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   
   TRC3(smSiActvTsk)

   UNUSED(pst);
   UNUSED(mBuf);

   SExitTsk();
   RETVALUE(ROK);
} /* end of smSiActvTsk */

#endif /* SI */


#ifdef SN
/*
*
*       Fun:   MTP3 layer manager activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smitexms.c
*
*/

#ifdef ANSI
PUBLIC S16 smSnActvInit
(
Ent ent,                      /* entity */
Inst inst,                    /* instance */
Region region,                /* region */
Reason reason                 /* reason */
)
#else
PUBLIC S16 smSnActvInit(ent, inst, region, reason)
Ent ent;                      /* entity */
Inst inst;                    /* instance */
Region region;                /* region */
Reason reason;                /* reason */
#endif
{
   TRC3(smSnActvInit)

   UNUSED(ent);
   UNUSED(inst);
   UNUSED(region);
   UNUSED(reason);
   RETVALUE(ROK);
} /* end of smSnActvInit */


/*
*
*       Fun:    MTP3 layer manager activate task
*
*       Desc:   Processes received event from M3UA layer
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   smitexms.c
*
*/

#ifdef ANSI
PUBLIC S16 smSnActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 smSnActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   
   TRC3(smSnActvTsk)

   UNUSED(pst);
   UNUSED(mBuf);

   SExitTsk();
   RETVALUE(ROK);
} /* end of smSnActvTsk */

#endif /* SN */


#ifdef SP
/*
*
*       Fun:   SCCP layer manager activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smitexms.c
*
*/

#ifdef ANSI
PUBLIC S16 smSpActvInit
(
Ent ent,                      /* entity */
Inst inst,                    /* instance */
Region region,                /* region */
Reason reason                 /* reason */
)
#else
PUBLIC S16 smSpActvInit(ent, inst, region, reason)
Ent ent;                      /* entity */
Inst inst;                    /* instance */
Region region;                /* region */
Reason reason;                /* reason */
#endif
{
   TRC3(smSpActvInit)

   UNUSED(ent);
   UNUSED(inst);
   UNUSED(region);
   UNUSED(reason);
   RETVALUE(ROK);
} /* end of smSpActvInit */


/*
*
*       Fun:    SCCP layer manager activate task
*
*       Desc:   Processes received event from M3UA layer
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   smitexms.c
*
*/

#ifdef ANSI
PUBLIC S16 smSpActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 smSpActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   
   TRC3(smSpActvTsk)

   UNUSED(pst);
   UNUSED(mBuf);

   SExitTsk();
   RETVALUE(ROK);
} /* end of smSpActvTsk */

#endif /* SP */


#ifdef SB
/*
*
*       Fun:   SCTP layer manager activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smitexms.c
*
*/

#ifdef ANSI
PUBLIC S16 smSbActvInit
(
Ent ent,                      /* entity */
Inst inst,                    /* instance */
Region region,                /* region */
Reason reason                 /* reason */
)
#else
PUBLIC S16 smSbActvInit(ent, inst, region, reason)
Ent ent;                      /* entity */
Inst inst;                    /* instance */
Region region;                /* region */
Reason reason;                /* reason */
#endif
{
   TRC3(smSbActvInit)

   UNUSED(ent);
   UNUSED(inst);
   UNUSED(region);
   UNUSED(reason);
   RETVALUE(ROK);
} /* end of smSbActvInit */


/*
*
*       Fun:    SCTP layer manager activate task
*
*       Desc:   Processes received event from M3UA layer
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   smitexms.c
*
*/

#ifdef ANSI
PUBLIC S16 smSbActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 smSbActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   
   TRC3(smSbActvTsk)

   UNUSED(pst);
   UNUSED(mBuf);

   SExitTsk();
   RETVALUE(ROK);
} /* end of smSbActvTsk */

#endif /* SB */


#ifdef NF
#ifndef SN
/*
*
*       Fun:   M3UA Nif layer manager activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smitexms.c
*
*/

#ifdef ANSI
PUBLIC S16 smNfActvInit
(
Ent ent,                      /* entity */
Inst inst,                    /* instance */
Region region,                /* region */
Reason reason                 /* reason */
)
#else
PUBLIC S16 smNfActvInit(ent, inst, region, reason)
Ent ent;                      /* entity */
Inst inst;                    /* instance */
Region region;                /* region */
Reason reason;                /* reason */
#endif
{
   TRC3(smNfActvInit)

   UNUSED(ent);
   UNUSED(inst);
   UNUSED(region);
   UNUSED(reason);
   RETVALUE(ROK);
} /* end of smNfActvInit */


/*
*
*       Fun:    Nif M3UA layer manager activate task
*
*       Desc:   Processes received event from M3UA layer
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   smitexms.c
*
*/

#ifdef ANSI
PUBLIC S16 smNfActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 smNfActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   
   TRC3(smNfActvTsk)

   UNUSED(pst);
   UNUSED(mBuf);

   SExitTsk();
   RETVALUE(ROK);
} /* end of smNfActvTsk */

#endif /* SN */
#endif /* NF */


#ifdef IN
/*
*
*       Fun:   MTP3 layer manager activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smitexms.c
*
*/

#ifdef ANSI
PUBLIC S16 smInActvInit
(
Ent ent,                      /* entity */
Inst inst,                    /* instance */
Region region,                /* region */
Reason reason                 /* reason */
)
#else
PUBLIC S16 smInActvInit(ent, inst, region, reason)
Ent ent;                      /* entity */
Inst inst;                    /* instance */
Region region;                /* region */
Reason reason;                /* reason */
#endif
{
   TRC3(smInActvInit)

   UNUSED(ent);
   UNUSED(inst);
   UNUSED(region);
   UNUSED(reason);
   RETVALUE(ROK);
} /* end of smInActvInit */


/*
*
*       Fun:    MTP3 layer manager activate task
*
*       Desc:   Processes received event from M3UA layer
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   smitexms.c
*
*/

#ifdef ANSI
PUBLIC S16 smInActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 smInActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   
   TRC3(smInActvTsk)

   UNUSED(pst);
   UNUSED(mBuf);

   SExitTsk();
   RETVALUE(ROK);
} /* end of smInActvTsk */

#endif /* IN */


#endif /* IT_ACC */





/********************************************************************30**

         End of file:     smitexms.c@@/main/5 - Tue Dec 30 22:32:18 2003

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/3      ---     bk   1. Initial version
/main/3      ---      as   1. Updates to Release 1.2
/main/4      ---      sg   1. Updates to Release 1.3
/main/5      ---      nt   1. Update to Release 1.5
*********************************************************************91*/
