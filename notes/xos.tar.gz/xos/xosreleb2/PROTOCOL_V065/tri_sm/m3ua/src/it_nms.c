/*************************************************
  Copyright (C), 1995-2006, XinWei Tech. Co., Ltd.
  
  File name:    it_nms.c
  
  Subsystem   : sm
  
  Description: ����M3UAЭ���OAM�ӿ�,�������ܻ��ļ����
  �����ݱ��浽ȫ�ֱ�����
  
  Others:         

  History: 
  Programmer  Date         Rev    Description
  --------------- ---------- -------- ------------------------------
  chenning   5/18/2006    1.0        created 
*************************************************/ 
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_err.h"        /* common error */
#include "cm_llist.h"
#include "cm_ss7.h"        /* common ss7 */
#include "it.h"

#include "ss_err.h"        /* system services error code*/
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* common timer */
#include "cm_lib.x"        /* Common Portable Library */
#include "cm_llist.x"


#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */

#include "it_dbg.h"
#include "it_nms.h"
#include "it_cfg.h"
#include "sm.h"
#include "sm.x"
#include "xosshell.h"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"
#include "it_oam.x"
#include "cp_tab_def.h"
#include "it_bind.h"

/**************** Global Var ************************/

/**************** Private  FUNC Declare ************************/
PRIVATE S16 itRecvInitCfg(tb_record* prow);
PRIVATE S16 itRecvDynCfg(U32 msgtype, tb_record* prow);
PRIVATE S16 itCfgMsg(VOID);
PRIVATE S16 itDynCfgMsg(tb_record *prow);

PRIVATE S16 itVerifyPspTab(ItCfgM3uaPspTab* stPspTab);
PRIVATE S16 itVerifyPsTab(ItCfgM3uaPsTab* stPsTab);
PRIVATE S16 itVerifyRouteTab(ItCfgM3uaRouteTab* stRouteTab);

/*****************        PUBLIC FUNC   **********************/
unsigned char itInitCfgCallback(U16 msgtype, U32 sepuense, U8 pack_end, tb_record* prow)
{
    TRC2(itInitCfgCallback);
    
    if(ROK != itRecvInitCfg(prow))
    {
        opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
        CPDBGP("itInitCfgCallback(itRecvInitCfg is RFAILED)\r\n");
        RETVALUE(RFAILED);
    } 	

    if(TRUE == pack_end)
    {
        if(ROK != itCfgMsg())
        {
            opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
            CPDBGP("itInitCfgCallback(itCfgMsg is RFAILED)\r\n");
            RETVALUE(RFAILED);
        } 	

        /* send out a config req message to sm*/
        if( ROK != smSendCfgReq(ENTIT, SM_INIT_CFG_STATE))
        {
            opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
            CPDBGP("itInitCfgCallback(smSendCfgReq is RFAILED)\r\n");
            RETVALUE(RFAILED);           
        }

        /* wait initial cofiguration finished*/
        ssWaitSema(&gSmCb[ENTIT].sema);

        /* send response to subagent*/
        if(SM_SUCCESS_STATE ==  gSmCb[ENTIT].smStatus)
        {
            /* All the initialization configuration data is processed successfully */
            opt_response_batch(sepuense, OAM_RESPONSE_OK);
            ItLSapBindSb(0);      /* M3UA BND SCTP */
        }
        else 
        {
            opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
        }

        smReset(ENTIT);
    }
#ifdef CP_OAM_DATA_SHOW
    itDbgPrintfConfig();
#endif
    RETVALUE(ROK);
}

VOID itInitCfgData(VOID)
{
    TRC2(itInitCfgData);
        
    itGlobalTabCfg.GenTabNum = 0;
    itGlobalTabCfg.NodeTabNum = 0;
    itGlobalTabCfg.PspTabNum = 0;
    itGlobalTabCfg.PsTabNum = 0;
    itGlobalTabCfg.RouteTabNum = 0;
#ifdef DEBUGP	
    itGlobalTabCfg.CfgInit.dbgMask = 0;
#endif
}

VOID itResetCfgData(VOID)
{
    TRC2(itResetCfgData);
    
    smOamDataReorg((U16*)&itGlobalTabCfg.PspTabNum, (U8 *)&itGlobalTabCfg.PspTab[0].OprType, sizeof(ItCfgM3uaPspTab));
    smOamDataReorg((U16*)&itGlobalTabCfg.PsTabNum, (U8 *)&itGlobalTabCfg.PsTab[0].OprType, sizeof(ItCfgM3uaPsTab));
    smOamDataReorg((U16*)&itGlobalTabCfg.RouteTabNum, (U8 *)&itGlobalTabCfg.RouteTab[0].OprType, sizeof(ItCfgM3uaRouteTab));
}

unsigned char itDynCfgCallback(unsigned int tableid, unsigned short msgtype, unsigned int sequence, unsigned char pack_end, tb_record *prow)
{
    /*dynamic callback return value initilized fail*/
    prow->head.col_index = OAM_ERRCOL_UNKNOWN;
    if(SA_INSERT_MSG == msgtype)
      prow->head.err_no = OAM_RESPONSE_INSERT_ERROR;
    else if(SA_UPDATE_MSG == msgtype)
      prow->head.err_no = OAM_RESPONSE_UPDATE_ERROR;
    else if(SA_DELETE_MSG == msgtype)
      prow->head.err_no = OAM_RESPONSE_DELETE_ERROR;
    else 
      prow->head.err_no = OAM_RESPONSE_PARAM_ERROR;

    if(NULL == prow)
    {
        opt_response_row(sequence, prow);
        CPDBGP("itDynCfgCallback(prow is NULLP)\r\n");
        RETVALUE(RFAILED);
    }

    if(gSmCb[ENTIT].smStatus != SM_STATUS_TOTAL_NUM)
    {
        opt_response_row(sequence, prow);
        CPDBGP("itDynCfgCallback(init configuration do not complete)\r\n");
        RETVALUE(RFAILED);
    }
    else
    {
        gSmCb[ENTIT].smStatus = SM_DYN_STATE;
    }

    if(ROK != itRecvDynCfg(msgtype, prow))
    {
        opt_response_row(sequence, prow);
        CPDBGP("itDynCfgCallback(recv dynamic config data error)\r\n");
        RETVALUE(RFAILED);
    } 	

    if(TRUE == pack_end)
    {
        if(ROK != itDynCfgMsg(prow ))
        {
            opt_response_row(sequence, prow);
            CPDBGP("itDynCfgCallback(dync config error)\r\n");
            RETVALUE(RFAILED);
        } 	

        /* send out a config req message to sm*/
        if( ROK != smSendCfgReq(ENTIT, SM_DYN_STATE))
        {
            opt_response_row(sequence, prow);
            CPDBGP("itDynCfgCallback(smSendCfgReq error)\r\n");
            RETVALUE(RFAILED);                
        }

        /* wait dynamic cofiguration finished*/
        ssWaitSema(&gSmCb[ENTIT].sema);

        /* send response to subagent*/
        if(SM_SUCCESS_STATE ==  gSmCb[ENTIT].smStatus)
        {
            prow->head.col_index = OAM_ERRCOL_OK;
            prow->head.err_no = OAM_RESPONSE_OK;
            /* All the initialization configuration data is processed successfully */
            opt_response_row(sequence, prow);
        }
        else 
        {
            opt_response_row(sequence, prow);
        }
        smReset(ENTIT);
    }
    RETVALUE(ROK) ;
}
/*****************        PRIVATE FUNC   **********************/
PRIVATE S16 itVerifyPspTab(ItCfgM3uaPspTab* stPspTab)
{
    U32 i = 0;

    if ( (ItCfgM3uaPspTab*)NULLP == stPspTab )
    {
        CPDBGP("stPspTab is NULL\r\n");
        RETVALUE(RFAILED);
    }

	if ( 0 == itGlobalTabCfg.PspTabNum )
	{
		RETVALUE(ROK);
	}
	
    for ( i = 0; i < itGlobalTabCfg.PspTabNum; i++ )
    {
        if ( ( stPspTab->DestAddr1 == itGlobalTabCfg.PspTab[i].DestAddr1 ) && \
                ( stPspTab->DestAddr1 == itGlobalTabCfg.PspTab[i].DestAddr1 ) && \
                ( stPspTab->DestAddr1 == itGlobalTabCfg.PspTab[i].DestAddr1 ) && \
                ( stPspTab->DestAddr1 == itGlobalTabCfg.PspTab[i].DestAddr1 ) && \
                ( stPspTab->DestPort== itGlobalTabCfg.PspTab[i].DestPort) && \
                ( stPspTab->DfltLshareMode== itGlobalTabCfg.PspTab[i].DfltLshareMode) && \
                ( stPspTab->IpspType== itGlobalTabCfg.PspTab[i].IpspType) && \
                ( stPspTab->NwkAppIncl== itGlobalTabCfg.PspTab[i].NwkAppIncl) && \
                ( stPspTab->NwkID== itGlobalTabCfg.PspTab[i].NwkID) && \
                ( stPspTab->OutStreamNum== itGlobalTabCfg.PspTab[i].OutStreamNum) && \
                ( stPspTab->PriDestAddr== itGlobalTabCfg.PspTab[i].PriDestAddr) && \
                ( stPspTab->PspType== itGlobalTabCfg.PspTab[i].PspType)  )
            {
                CPDBGP("PspTabs have the same config\r\n");
                RETVALUE(RFAILED);
            }
    }

    RETVALUE(ROK);
}

PRIVATE S16 itVerifyPsTab(ItCfgM3uaPsTab* stPsTab)
{
    U32 i = 0;

    if ( (ItCfgM3uaPsTab*)NULLP == stPsTab )
    {
        CPDBGP("stPsTab is NULL\r\n");
        RETVALUE(RFAILED);
    }

	if ( 0 == itGlobalTabCfg.PsTabNum )
	{
		RETVALUE(ROK);
	}
	
    for ( i = 0; i < itGlobalTabCfg.PsTabNum; i++ )
    {
        if ( ( stPsTab->NwkID == itGlobalTabCfg.PsTab[i].NwkID ) && \
                ( stPsTab->PsWorkMode == itGlobalTabCfg.PsTab[i].PsWorkMode ) && \
                ( stPsTab->RoutCtx == itGlobalTabCfg.PsTab[i].RoutCtx ) && \
                ( stPsTab->LoadShareMode == itGlobalTabCfg.PsTab[i].LoadShareMode ) && \
                ( stPsTab->LocalFlag == itGlobalTabCfg.PsTab[i].LocalFlag ) && \
                ( stPsTab->ActivePspRequired == itGlobalTabCfg.PsTab[i].ActivePspRequired ) && \
                ( stPsTab->PspNum == itGlobalTabCfg.PsTab[i].PspNum ) && \
                ( stPsTab->Psp[0]== itGlobalTabCfg.PsTab[i].Psp[0] ) && \
                ( stPsTab->Psp[1] == itGlobalTabCfg.PsTab[i].Psp[1] ) && \
                ( stPsTab->Psp[2] == itGlobalTabCfg.PsTab[i].Psp[2] ) && \
                ( stPsTab->Psp[3] == itGlobalTabCfg.PsTab[i].Psp[3] ) && \
                ( stPsTab->Psp[4] == itGlobalTabCfg.PsTab[i].Psp[4] ) && \
                ( stPsTab->Psp[5] == itGlobalTabCfg.PsTab[i].Psp[5] ) && \
                ( stPsTab->Psp[6] == itGlobalTabCfg.PsTab[i].Psp[6] ) && \
                ( stPsTab->Psp[7] == itGlobalTabCfg.PsTab[i].Psp[7] ) && \
                ( stPsTab->Psp[8] == itGlobalTabCfg.PsTab[i].Psp[8] ) && \
                ( stPsTab->Psp[9] == itGlobalTabCfg.PsTab[i].Psp[9] ) && \
                ( stPsTab->Psp[10] == itGlobalTabCfg.PsTab[i].Psp[10] ) && \
                ( stPsTab->Psp[11] == itGlobalTabCfg.PsTab[i].Psp[11] ) && \
                ( stPsTab->Psp[12] == itGlobalTabCfg.PsTab[i].Psp[12] ) && \
                ( stPsTab->Psp[13] == itGlobalTabCfg.PsTab[i].Psp[13] ) && \
                ( stPsTab->Psp[14] == itGlobalTabCfg.PsTab[i].Psp[14] ) && \
                ( stPsTab->Psp[15] == itGlobalTabCfg.PsTab[i].Psp[15] ) )
            {
                CPDBGP("PsTabs have the same config\r\n");
                RETVALUE(RFAILED);
            }
    }

    RETVALUE(ROK);
}

PRIVATE S16 itVerifyRouteTab(ItCfgM3uaRouteTab* stRouteTab)
{
    U32 i = 0;

    if ( (ItCfgM3uaRouteTab*)NULLP == stRouteTab )
    {
        CPDBGP("stRouteTab is NULL\r\n");
        RETVALUE(RFAILED);
    }

    if ( 0 == itGlobalTabCfg.RouteTabNum)
    {
    	RETVALUE(ROK);
    }
	
    for ( i = 0; i < itGlobalTabCfg.RouteTabNum; i++ )
    {
        if ( ( stRouteTab->RouteType == itGlobalTabCfg.RouteTab[i].RouteType ) && \
                ( stRouteTab->PsID == itGlobalTabCfg.RouteTab[i].PsID ) && \
                ( stRouteTab->RouteType == itGlobalTabCfg.RouteTab[i].RouteType ) && \
                ( stRouteTab->NwkID == itGlobalTabCfg.RouteTab[i].NwkID ) && \
                ( stRouteTab->RouteMode == itGlobalTabCfg.RouteTab[i].RouteMode ) && \
                ( stRouteTab->DPCValue == itGlobalTabCfg.RouteTab[i].DPCValue ) && \
                ( stRouteTab->OPCValue == itGlobalTabCfg.RouteTab[i].OPCValue ) && \
                ( stRouteTab->SIO == itGlobalTabCfg.RouteTab[i].SIO ) && \
                ( stRouteTab->CICStart == itGlobalTabCfg.RouteTab[i].CICStart ) && \
                ( stRouteTab->CICEnd == itGlobalTabCfg.RouteTab[i].CICEnd ) && \
                ( stRouteTab->SSN == itGlobalTabCfg.RouteTab[i].SSN ) && \
                ( stRouteTab->TridStart == itGlobalTabCfg.RouteTab[i].TridStart ) && \
                ( stRouteTab->TridEnd == itGlobalTabCfg.RouteTab[i].TridEnd ) )
            {
                CPDBGP("RouteTabs have the same config\r\n");
                RETVALUE(RFAILED);
            }
    }

    RETVALUE(ROK);
}

S16 itRecvInitCfg(tb_record* prow)
{
    ItOamM3uaGenTab*            pGenTab;
    ItOamM3uaNodeTypeTab*    pNodeTab;
    ItOamM3uaPspTab*             pPspTab;
    ItOamM3uaPsTab*              pPsTab;
    ItOamM3uaRouteTab*         pRouteTab;
    
    CP_OAM_SS7_NETWORK_TAB*  pNetworkTab;
    CP_OAM_SS7_SPC_TAB*          pSpcTab;
    CP_OAM_SS7_UP_TAB*             pUpTab;
    CP_OAM_COM_IP_TAB*             pIpTab;
    
    S16  n = 0;
    U32 i = 0;
    U32* pTemp = NULLP;
    U32   uTemp = 0;
    
    TRC2(itRecvInitCfg);
    
    while(prow)
    {
        switch(prow->tableid)
        {
            case APP_TABLE_ID_SS7_NWK:
            {
                pNetworkTab = (CP_OAM_SS7_NETWORK_TAB*) prow->panytbrow;

                if ( ROK != CpSs7SetOneNwkTab(EN_CP_OPR_ADD,  pNetworkTab) )
                {
                    CPDBGP("itRecvInitCfg(CpSs7SetOneNwkTab is RFAILED)\r\n");
                    RETVALUE(RFAILED);
                }
                break;
            }
            case APP_TABLE_ID_SS7_SPC:
            {
                pSpcTab = (CP_OAM_SS7_SPC_TAB*)prow->panytbrow;

                if ( ROK !=  CpSs7SetOneSpcTab(EN_CP_OPR_ADD,  pSpcTab) )
                {
                    CPDBGP("itRecvInitCfg(CpSs7SetOneSpcTab is RFAILED)\r\n");
                    RETVALUE(RFAILED);
                }
                break;
            }

            case APP_TABLE_ID_SS7_UP:
            {
                pUpTab = (CP_OAM_SS7_UP_TAB*)prow->panytbrow;

                if ( ROK !=  CpSs7SetOneUpTab(EN_CP_OPR_ADD,  pUpTab) )
                {
                    CPDBGP( "itRecvInitCfg(CpSs7SetOneUpTab is RFAILED)\r\n");
                    RETVALUE(RFAILED);
                }
                break;
            }

            case APP_TABLE_ID_COM_IP:
            {
                pIpTab = (CP_OAM_COM_IP_TAB*)prow->panytbrow;

                if ( ROK !=  CpComSetOneIpTab(EN_CP_OPR_ADD,  pIpTab) )
                {
                    CPDBGP("itRecvInitCfg(CpComSetOneIpTab is RFAILED)\r\n");
                    RETVALUE(RFAILED);
                }
                break;
            }
            
            case APP_TABLE_ID_SS7_M3UA_GEN:
            {
                pGenTab = (ItOamM3uaGenTab *) prow->panytbrow;

                n = itGlobalTabCfg.GenTabNum;
                
                itGlobalTabCfg.GenTab[0].DrkmSupp = pGenTab->DrkmSupp;
                itGlobalTabCfg.GenTab[0].DrstSupp = pGenTab->DrstSupp;
                itGlobalTabCfg.GenTab[0].HeartbeatTimer = pGenTab->HeartbeatTimer;
                itGlobalTabCfg.GenTab[0].MaxLpsNum = pGenTab->MaxLpsNum;
                itGlobalTabCfg.GenTab[0].MaxNumMsg = pGenTab->MaxNumMsg;
                itGlobalTabCfg.GenTab[0].MaxNumRndRbnls = pGenTab->MaxNumRndRbnls;
                itGlobalTabCfg.GenTab[0].MaxNumSls = pGenTab->MaxNumSls;
                itGlobalTabCfg.GenTab[0].MaxNumSlsls = pGenTab->MaxNumSlsls;
                itGlobalTabCfg.GenTab[0].MaxPsNum = pGenTab->MaxPsNum;
                itGlobalTabCfg.GenTab[0].MaxPspNum = pGenTab->MaxPspNum;
                
                itGlobalTabCfg.GenTabNum++;
                break;
            }
            case APP_TABLE_ID_SS7_M3UA_NODE:
            {
                pNodeTab = (ItOamM3uaNodeTypeTab *) prow->panytbrow;

                n = itGlobalTabCfg.NodeTabNum;

                itGlobalTabCfg.NodeTab[0].M3uaPort = pNodeTab->M3uaPort;
                itGlobalTabCfg.NodeTab[0].NodeType = pNodeTab->NodeType;

                itGlobalTabCfg.NodeTabNum++;
                break;
            }
            case APP_TABLE_ID_SS7_M3UA_PSP:
            {
                pPspTab = (ItOamM3uaPspTab*) prow->panytbrow;

                n = itGlobalTabCfg.PspTabNum;
                
                if ( ROK != CpComGetDesIpAddr(pPspTab->DestAddr1Index, &uTemp) )
                {
                    CPDBGP("itRecvInitCfg(CpComGetDesIpAddr is RFAILED)\r\n");
                    RETVALUE(RFAILED);
                }
                itGlobalTabCfg.PspTab[n].DestAddr1 = uTemp;

                if ( ROK != CpComGetDesIpAddr(pPspTab->DestAddr2Index, &uTemp) )
                {
                    CPDBGP("itRecvInitCfg(CpComGetDesIpAddr is RFAILED)\r\n");
                    RETVALUE(RFAILED);
                }
                itGlobalTabCfg.PspTab[n].DestAddr2 = uTemp;

                if ( ROK != CpComGetDesIpAddr(pPspTab->DestAddr3Index, &uTemp) )
                {
                    CPDBGP("itRecvInitCfg(CpComGetDesIpAddr is RFAILED)\r\n");
                    RETVALUE(RFAILED);
                }
                itGlobalTabCfg.PspTab[n].DestAddr3 = uTemp;

                if ( ROK != CpComGetDesIpAddr(pPspTab->DestAddr4Index, &uTemp) )
                {
                    CPDBGP("itRecvInitCfg(CpComGetDesIpAddr is RFAILED)\r\n");
                    RETVALUE(RFAILED);
                }
                itGlobalTabCfg.PspTab[n].DestAddr4 = uTemp;
                
                itGlobalTabCfg.PspTab[n].DestPort = pPspTab->DestPort;
                itGlobalTabCfg.PspTab[n].DfltLshareMode = pPspTab->DfltLshareMode;
                itGlobalTabCfg.PspTab[n].IpspType = pPspTab->IpspType;
                itGlobalTabCfg.PspTab[n].NwkAppIncl = pPspTab->NwkAppIncl;
                itGlobalTabCfg.PspTab[n].NwkID = (pPspTab->NwkID);
                itGlobalTabCfg.PspTab[n].OutStreamNum = pPspTab->OutStreamNum;

                if ( ROK != CpComGetDesIpAddr(pPspTab->PriDestAddrIndex, &uTemp) )
                {
                    CPDBGP("itRecvInitCfg(CpComGetDesIpAddr is CpComGetDesIpAddr)\r\n");
                    RETVALUE(RFAILED);
                }
                itGlobalTabCfg.PspTab[n].PriDestAddr = uTemp;
                
                itGlobalTabCfg.PspTab[n].PspID = pPspTab->PspID;
                itGlobalTabCfg.PspTab[n].PspType = pPspTab->PspType;

                if ( ROK !=  itVerifyPspTab(&(itGlobalTabCfg.PspTab[n])) )
                {
                    CPDBGP("itRecvInitCfg(itVerifyPspTab is RFAILED)\r\n");
                    RETVALUE(RFAILED);
                }
                itGlobalTabCfg.PspTabNum++;
                break;
            }
            case APP_TABLE_ID_SS7_M3UA_PS:
            {
                pPsTab = (ItOamM3uaPsTab*)prow->panytbrow;

                n = itGlobalTabCfg.PsTabNum;

                itGlobalTabCfg.PsTab[n].ActivePspRequired = pPsTab->ActivePspRequired;
                itGlobalTabCfg.PsTab[n].RoutCtx = pPsTab->RoutCtx;
                itGlobalTabCfg.PsTab[n].LoadShareMode = pPsTab->LoadShareMode;
                itGlobalTabCfg.PsTab[n].LocalFlag = pPsTab->LocalFlag;
                itGlobalTabCfg.PsTab[n].NwkID = (pPsTab->NwkID);
                itGlobalTabCfg.PsTab[n].PsID = (pPsTab->PsID);
                itGlobalTabCfg.PsTab[n].PspNum = pPsTab->PspNum;
                pTemp = &(pPsTab->Psp1);
                for ( i = 0; i < IT_CFG_MAX_PSP_IN_PS; i++ )
                {
                    itGlobalTabCfg.PsTab[n].Psp[i] = *(pTemp+i);
                    
                }
                itGlobalTabCfg.PsTab[n].PsWorkMode = pPsTab->PsWorkMode;
                if ( ROK !=  itVerifyPsTab(&(itGlobalTabCfg.PsTab[n])) )
                {
                    CPDBGP("itRecvInitCfg(itVerifyPsTab is RFAILED)\r\n");
                    RETVALUE(RFAILED);
                }
                
                itGlobalTabCfg.PsTabNum++;
                break;
            }
            case APP_TABLE_ID_SS7_M3UA_ROUTE:
            {
                pRouteTab = (ItOamM3uaRouteTab*)prow->panytbrow;

                n = itGlobalTabCfg.RouteTabNum;

                itGlobalTabCfg.RouteTab[n].CICEnd = pRouteTab->CICEnd;
                itGlobalTabCfg.RouteTab[n].CICStart = pRouteTab->CICStart;

                itGlobalTabCfg.RouteTab[n].PsID = (pRouteTab->PsID);
                itGlobalTabCfg.RouteTab[n].RouteID = pRouteTab->RouteID;
                itGlobalTabCfg.RouteTab[n].RouteMode = pRouteTab->RouteMode;
                itGlobalTabCfg.RouteTab[n].RouteType = pRouteTab->RouteType;
                itGlobalTabCfg.RouteTab[n].TridEnd = pRouteTab->TridEnd;
                itGlobalTabCfg.RouteTab[n].TridStart = pRouteTab->TridStart;
                itGlobalTabCfg.RouteTab[n].NwkID = (pRouteTab->NwkID);

                itGlobalTabCfg.RouteTab[n].DPCValue = 0;
                itGlobalTabCfg.RouteTab[n].OPCValue = 0;
                itGlobalTabCfg.RouteTab[n].SIO = 0;
                itGlobalTabCfg.RouteTab[n].SSN = 0;
                
                if ( EN_RT_DPC_SIO_SSN == pRouteTab->RouteMode || EN_RT_DPC_OPC_SIO_SSN == pRouteTab->RouteMode )
                {
                    if ( SS_SCCPMNGT ==  pRouteTab->SSN || SS_ISUP ==  pRouteTab->SSN \
                        || SS_OMAP ==  pRouteTab->SSN || SS_MAP ==  pRouteTab->SSN \
                        || SS_HLR ==  pRouteTab->SSN || SS_VLR ==  pRouteTab->SSN \
                        || SS_MSC ==  pRouteTab->SSN || SS_EIR ==  pRouteTab->SSN \
                        || SS_AC ==  pRouteTab->SSN || SS_INAP ==  pRouteTab->SSN )
                    {
                         itGlobalTabCfg.RouteTab[n].SSN = pRouteTab->SSN;
                    }
                    else
                    {
                        CPDBGP("itRecvInitCfg(itVerifyRouteTab SSN Value Error)\r\n");
                        RETVALUE(RFAILED);
                    }     
                }
                
                if ( EN_RT_DPC_SIO == pRouteTab->RouteMode \
                    || EN_RT_DPC_OPC_SIO == pRouteTab->RouteMode \
                    || EN_RT_DPC_SIO_CIC == pRouteTab->RouteMode \
                    || EN_RT_DPC_OPC_SIO_CIC == pRouteTab->RouteMode \
                    || EN_RT_DPC_SIO_SSN == pRouteTab->RouteMode \
                    || EN_RT_DPC_OPC_SIO_SSN == pRouteTab->RouteMode \
                    || EN_RT_OPC_SIO == pRouteTab->RouteMode \
                    || EN_RT_OPC_SIO_CIC == pRouteTab->RouteMode \
                    || EN_RT_DPC_SIO_TRID == pRouteTab->RouteMode \
                    || EN_RT_DPC_OPC_SIO_TRID == pRouteTab->RouteMode \
                    || EN_RT_OPC_SIO_TRID == pRouteTab->RouteMode )
                {
                    if ( SI_SCCP == pRouteTab->SIO  || SI_ISUP == pRouteTab->SIO )
                    {
                        itGlobalTabCfg.RouteTab[n].SIO = pRouteTab->SIO;
                    }
                    else
                    {
                        CPDBGP("itRecvInitCfg(itVerifyRouteTab SIO Value Error)\r\n");
                        RETVALUE(RFAILED);
                    }
                }
                
                if ( EN_RT_DPC ==  pRouteTab->RouteMode \
                     || EN_RT_DPC_SIO == pRouteTab->RouteMode \
                     || EN_RT_DPC_OPC_SIO == pRouteTab->RouteMode \
                     || EN_RT_DPC_SIO_CIC == pRouteTab->RouteMode \
                     || EN_RT_DPC_OPC_SIO_CIC == pRouteTab->RouteMode \
                     || EN_RT_DPC_SIO_SSN == pRouteTab->RouteMode \
                     || EN_RT_DPC_OPC_SIO_SSN == pRouteTab->RouteMode \
                     || EN_RT_DPC_OPC == pRouteTab->RouteMode \
                     || EN_RT_DPC_SIO_TRID == pRouteTab->RouteMode \
                     || EN_RT_DPC_OPC_SIO_TRID == pRouteTab->RouteMode )
                {
                    if ( ROK != CpSs7GetSPC(pRouteTab->DPCValueIndex, &uTemp) )
                    {
                        CPDBGP("itRecvInitCfg(itVerifyRouteTab is DPC CpSs7GetSPC )\r\n");
                        RETVALUE(RFAILED);
                    }
                    itGlobalTabCfg.RouteTab[n].DPCValue = uTemp;
                }

                if ( EN_RT_OPC ==  pRouteTab->RouteMode \
                     || EN_RT_OPC_SIO == pRouteTab->RouteMode \
                     || EN_RT_DPC_OPC_SIO == pRouteTab->RouteMode \
                     || EN_RT_OPC_SIO_CIC == pRouteTab->RouteMode \
                     || EN_RT_DPC_OPC_SIO_CIC == pRouteTab->RouteMode \
                     || EN_RT_DPC_OPC_SIO_SSN == pRouteTab->RouteMode \
                     || EN_RT_DPC_OPC == pRouteTab->RouteMode \
                     || EN_RT_DPC_OPC_SIO_TRID == pRouteTab->RouteMode \
                     || EN_RT_OPC_SIO_TRID == pRouteTab->RouteMode )
                {
                    if ( ROK != CpSs7GetSPC(pRouteTab->OPCValueIndex, &uTemp) )
                    {
                        CPDBGP("itRecvInitCfg(itVerifyRouteTab is OPC CpSs7GetSPC )\r\n");
                        RETVALUE(RFAILED);
                    }
                    itGlobalTabCfg.RouteTab[n].OPCValue = uTemp;
                }

                
                if ( ROK !=  itVerifyRouteTab(&(itGlobalTabCfg.RouteTab[n])) )
                {
                    CPDBGP("itRecvInitCfg(itVerifyRouteTab is RFAILED)\r\n");
                    RETVALUE(RFAILED);
                }
                itGlobalTabCfg.RouteTabNum++;
                break;
            }
            default:
            {
                /*����prowΪȫ�ֵı�ID�����Ի���ܵ���������ID*/
                break;
            }
        }

        prow = prow->next;
    }

    RETVALUE(ROK);
}

S16 itRecvDynCfg(U32 msgtype, tb_record* prow)
{
    ItCfgM3uaPspTab*       pPspTab = (ItCfgM3uaPspTab*)NULLP;
    ItCfgM3uaPsTab*         pPsTab = (ItCfgM3uaPsTab*)NULLP;
    ItCfgM3uaRouteTab*    pRouteTab = (ItCfgM3uaRouteTab*)NULLP;
        
    while(prow)
    {
        switch(prow->tableid)
        {
            case APP_TABLE_ID_SS7_M3UA_PSP:
            {
                pPspTab = (ItCfgM3uaPspTab*) prow->panytbrow;

                switch ( msgtype )
                {
                    case SA_INSERT_MSG:
                    {
                        break;
                    }
                    case SA_DELETE_MSG:
                    {
                        break;
                    }
                    case SA_UPDATE_MSG:
                    {
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                break;
            }

            case APP_TABLE_ID_SS7_M3UA_PS:
            {
                pPspTab = (ItCfgM3uaPspTab*) prow->panytbrow;

                switch ( msgtype )
                {
                    case SA_INSERT_MSG:
                    {
                        break;
                    }
                    case SA_DELETE_MSG:
                    {
                        break;
                    }
                    case SA_UPDATE_MSG:
                    {
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                break;
            }

            case APP_TABLE_ID_SS7_M3UA_ROUTE:
            {
                pPspTab = (ItCfgM3uaPspTab*) prow->panytbrow;

                switch ( msgtype )
                {
                    case SA_INSERT_MSG:
                    {
                        break;
                    }
                    case SA_DELETE_MSG:
                    {
                        break;
                    }
                    case SA_UPDATE_MSG:
                    {
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                break;
            }
            default:
            {
                break;
            }
    			
    	}

       prow = prow->next;
    }

    RETVALUE(ROK);
}

S16 itDynCfgMsg(tb_record *prow)
{
    ItCfgM3uaPspTab*       pPspTab = (ItCfgM3uaPspTab*)NULLP;
    ItCfgM3uaPsTab*         pPsTab = (ItCfgM3uaPsTab*)NULLP;
    ItCfgM3uaRouteTab*    pRouteTab = (ItCfgM3uaRouteTab*)NULLP;
    U32  i;
    S16 ret = ROK;


    if( gSmCb[ENTSP].smStatus == SM_DYN_STATE)
    {
        for( i = 0; i < itGlobalTabCfg.PspTabNum; i++)
        {
            switch(itGlobalTabCfg.PspTab[i].OprType)
            {
                case EN_CP_OPR_ADD:
                {
                    /*ret = itDynAddPspCfg(i);*/
                    if( ROK != ret)
                    {
                        RETVALUE(ret);
                    }    
                    break;
                }
                
                case(EN_CP_OPR_DEL):
                {
                    /*ret = itDynDelPspCfg(i);*/
                    if( ROK != ret)
                    {
                        RETVALUE(ret);
                    }            
                    break;
                }
                
                case(EN_CP_OPR_MOD):
                {
                    /*ret = itDynModPspCfg(i, prow);*/
                    if( ROK != ret)
                    {
                        RETVALUE(ret);
                    }            
                    break;
                }
                
                default:
                {
                    break;
                }
            }
        }

        for( i = 0; i < itGlobalTabCfg.PsTabNum; i++)
        {
            switch(itGlobalTabCfg.PsTab[i].OprType)
            {
                case EN_CP_OPR_ADD:
                {
                    /*ret = itDynAddPsCfg(i);*/
                    if( ROK != ret)
                    {
                        RETVALUE(ret);
                    }    
                    break;
                }
                
                case(EN_CP_OPR_DEL):
                {
                    /*ret = itDynDelPsCfg(i);*/
                    if( ROK != ret)
                    {
                        RETVALUE(ret);
                    }            
                    break;
                }
                
                case(EN_CP_OPR_MOD):
                {
                    /*ret = itDynModPsCfg(i, prow);*/
                    if( ROK != ret)
                    {
                        RETVALUE(ret);
                    }            
                    break;
                }
                
                default:
                {
                    break;
                }
            }
        }

        for( i = 0; i < itGlobalTabCfg.RouteTabNum; i++)
        {
            switch(itGlobalTabCfg.RouteTab[i].OprType)
            {
                case EN_CP_OPR_ADD:
                {
                    /*ret = itDynAddRouteCfg(i);*/
                    if( ROK != ret)
                    {
                        RETVALUE(ret);
                    }    
                    break;
                }
                
                case(EN_CP_OPR_DEL):
                {
                    /*ret = itDynDelRouteCfg(i);*/
                    if( ROK != ret)
                    {
                        RETVALUE(ret);
                    }            
                    break;
                }
                
                case(EN_CP_OPR_MOD):
                {
                    /*ret = itDynModRouteCfg(i, prow);*/
                    if( ROK != ret)
                    {
                        RETVALUE(ret);
                    }            
                    break;
                }
                
                default:
                {
                    break;
                }
            }
        }
    }
    RETVALUE(ROK);
}

S16 itCfgMsg(VOID)
{
    S16 ret = ROK;
    U32 i;

    TRC2(itCfgMsg);
    
    /* static config data only be done in config start phase, and it would not change after system started*/
    if( gSmCb[ENTIT].smStatus == SM_INIT_CFG_STATE)
    {
        ret  =  itTabM3uaGenCfg();
        if( ROK != ret)
        {
            CPDBGP("itCfgMsg(itTabM3uaGenCfg is RFAILED)\r\n");
            RETVALUE(ret);
        }

        ret  =  itTabM3uaLSapCfg();
        if( ROK != ret)
        {
            CPDBGP("itCfgMsg(itTabM3uaLSapCfg is RFAILED)\r\n");
            RETVALUE(ret);
        }

        for ( i=0; i<gstCpSs7Global.NwkTabNum; i++ )
        {
            ret  =  itTabSs7NwkCfg(i);
            if( ROK != ret)
            {
                CPDBGP("itCfgMsg(itTabSs7NwkCfg is RFAILED )\r\n");
                RETVALUE(ret);
            }
        }
        

        for ( i=0; i< gstCpSs7Global.UPTabNum; i++ )
        {
            ret  =  itTabM3uaNSapCfg(i);
            if( ROK != ret)
            {
                CPDBGP("itCfgMsg(itTabM3uaNSapCfg is RFAILED)\r\n");
                RETVALUE(ret);
            }
        }

        for ( i=0; i< itGlobalTabCfg.PspTabNum; i++ )
        {
            ret  =  itTabM3uaPspCfg(i);
            if( ROK != ret)
            {
                CPDBGP("itCfgMsg(itTabM3uaPspCfg is RFAILED)\r\n");
                RETVALUE(ret);
            }
        }

        for ( i=0; i< itGlobalTabCfg.PsTabNum; i++ )
        {
            ret  =  itTabM3uaPsCfg(i);
            if( ROK != ret)
            {
                CPDBGP("itCfgMsg(itTabM3uaPsCfg is RFAILED)\r\n");
                RETVALUE(ret);
            }
        }

        for ( i=0; i< itGlobalTabCfg.RouteTabNum; i++ )
        {
            ret  =  itTabM3uaRteCfg(i);
            if( ROK != ret)
            {
                CPDBGP("itCfgMsg(itTabM3uaRteCfg is RFAILED)\r\n");
                RETVALUE(ret);
            }
        }
    }

    RETVALUE(ROK);
}
