/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**

     Name:     smitptmi.c - M3UA portable management interface

     Type:     C source file

     Desc:     C source code for the M3UA layer management
               service user primitives used in loosely coupled
               systems.

     File:     smitptmi.c

     Sid:      smitptmi.c@@/main/6 - Thu Apr  1 03:49:26 2004

     Prg:      jdb

*********************************************************************21*/

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_ss7.h"        /* common SS7 */
#include "cm_tpt.h"        /* common transport defines */
#include "lit.h"           /* layer management M3UA  */
#include "sct.h"           /* SCT interface */
#include "snt.h"           /* SNT interface */
#ifdef NF_FTHA             
#include "sht.h"           /* SHT Interface header file */
#else
#ifdef IT_FTHA             
#include "sht.h"           /* SHT Interface header file */
#endif /* IT_FTHA */
#endif /* NF_FTHA */
#include "it.h"            /* M3UA internal defines */
#include "it_err.h"        /* M3UA error */
#include "smit_err.h"        /* M3UA Stack Manager error */
#ifdef ZV
#include "cm_ftha.h"       /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.h"       /* The common LDF defines */
#include "cmzvdvlb.h"       /* The common LDF defines */
#endif
#include "mrs.h"           /* Message Router common define */
#include "lzv.h"           /* common PSF */
#include "zv.h"            /* common PSF */
#endif
#ifdef IT_ACC
#include "it_acc.h"        /* acceptance test */
#endif
#ifdef SIG_INT
#include "sig_int.h"
#endif


/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* common SS7 */
#include "cm_tpt.x"        /* common transport */
#include "sct.x"           /* SCT interface */
#ifdef NF_FTHA             
#include "sht.x"           /* SHT Interface header file */
#else
#ifdef IT_FTHA             
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#endif /* NF_FTHA */
#include "lit.x"           /* layer management M3UA */
#include "snt.x"           /* SNT interface */
#include "it.x"            /* M3UA internal typedefs */
#ifdef ZV
#include "cm_ftha.x"          /* common PSF */
#include "cm_psfft.x"          /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.x"       /* The LDF common data structs */
#include "cmzvdvlb.x"       /* The LDF common data structs */
#endif
#include "mrs.x"       /* The LDF common data structs */
#include "lzv.x"           /* common PSF */
#include "zv.x"            /* common PSF */
#endif
#ifdef IT_ACC
#include "it_acc.x"        /* acceptance test */
#endif
#ifdef SIG_INT
#include "sig_int.x"
#endif



/* local defines */
#define MAXITMI                2

#ifdef LCSMITMILIT
#ifdef SM
#define LIT_NO_PORT
#endif /* SU */
#ifndef IT
#undef LIT_NO_PORT
#endif /* IT */
#endif /* LCSBUISCT */

/* forward references */
#ifndef LIT_NO_PORT
PRIVATE S16 PtMiLitCfgReq   ARGS((Pst *pst, ItMgmt *cfg ));
PRIVATE S16 PtMiLitStaReq   ARGS((Pst *pst, ItMgmt *sta ));
PRIVATE S16 PtMiLitStsReq   ARGS((Pst *pst, Action action, ItMgmt *sts ));
PRIVATE S16 PtMiLitCntrlReq ARGS((Pst *pst, ItMgmt *cntrl ));
#endif /* LIT_NO_PORT */


/*
The following matrices define the mapping between the primitives
called by the layer management interface of MPC8260 driver and the corresponding
primitives in the driver.

The parameter MAXITMI defines the maximum number of layer manager entities
on top of the driver. There is an array of functions per primitive invoked by
the driver. Every array is MAXITMI long (i.e. there are as many functions as the
number of service users).

The dispatching is performed by the configurable variable: selector.
The selector is configured during general configuration.

The selectors are:

   0 - loosely coupled interface (#define LCSMITMILIT)
   1 - Lit (#define IT)

*/

/* Configuration request primitive */

PRIVATE LitCfgReq SmMiLitCfgReqMt[MAXITMI] =
{
#ifdef LCSMITMILIT
   cmPkLitCfgReq,        /* 0 - loosely coupled  */
#else
   PtMiLitCfgReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItMiLitCfgReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLitCfgReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Statistics request primitive */

PRIVATE LitStsReq SmMiLitStsReqMt[MAXITMI] =
{
#ifdef LCSMITMILIT
   cmPkLitStsReq,        /* 0 - loosely coupled  */
#else
   PtMiLitStsReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItMiLitStsReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLitStsReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Status request primitive */

PRIVATE LitStaReq SmMiLitStaReqMt[MAXITMI] =
{
#ifdef LCSMITMILIT
   cmPkLitStaReq,        /* 0 - loosely coupled - bc */
#else
   PtMiLitStaReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItMiLitStaReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLitStaReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Control request primitive */

PRIVATE LitCntrlReq SmMiLitCntrlReqMt[MAXITMI] =
{
#ifdef LCSMITMILIT
   cmPkLitCntrlReq,        /* 0 - loosely coupled - bc */
#else
   PtMiLitCntrlReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef IT
   ItMiLitCntrlReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLitCntrlReq,          /* 1 - tightly coupled, portable */
#endif
};

/*
*     layer management interface functions
*/

/*
*
*       Fun:   Configuration request
*
*       Desc:  This function is used to configure MPC8260 driver
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smvoptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 SmMiLitCfgReq
(
Pst *pst,                 /* post structure */
ItMgmt *cfg              /* configure */
)
#else
PUBLIC S16 SmMiLitCfgReq(pst, cfg)
Pst *pst;                 /* post structure */
ItMgmt *cfg;             /* configure */
#endif
{
   TRC3(SmMiLitCfgReq)
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*SmMiLitCfgReqMt[pst->selector])(pst, cfg));
} /* end of SmMiLitCfgReq */

/*
*
*       Fun:   Status request
*
*       Desc:  This function is used to send a status request to MPC8260 driver
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smvoptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 SmMiLitStaReq
(
Pst *pst,                 /* post structure */
ItMgmt *sta              /* status */
)
#else
PUBLIC S16 SmMiLitStaReq(pst, sta)
Pst *pst;                 /* post structure */
ItMgmt *sta;             /* status */
#endif
{
   TRC3(SmMiLitStaReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLitStaReqMt[pst->selector])(pst, sta);
   RETVALUE(ROK);
} /* end of SmMiLitStaReq */

/*
*
*       Fun:   Statistics request
*
*       Desc:  This function is used to request statistics from MPC8260 driver
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smvoptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 SmMiLitStsReq
(
Pst *pst,                 /* post structure */
Action action,
ItMgmt *sts              /* statistics */
)
#else
PUBLIC S16 SmMiLitStsReq(pst, action, sts)
Pst *pst;                 /* post structure */
Action action;
ItMgmt *sts;             /* statistics */
#endif
{
   TRC3(SmMiLitStsReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLitStsReqMt[pst->selector])(pst, action, sts);
   RETVALUE(ROK);
} /* end of SmMiLitStsReq */

/*
*
*       Fun:   Control request
*
*       Desc:  This function is used to send control request to MPC8260 driver
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smvoptmi.c
*
*/

#ifdef ANSI
PUBLIC S16 SmMiLitCntrlReq
(
Pst *pst,                 /* post structure */
ItMgmt *cntrl            /* control */
)
#else
PUBLIC S16 SmMiLitCntrlReq(pst, cntrl)
Pst *pst;                 /* post structure */
ItMgmt *cntrl;           /* control */
#endif
{
   TRC3(SmMiLitCntrlReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLitCntrlReqMt[pst->selector])(pst, cntrl);
   RETVALUE(ROK);
} /* end of SmMiLitCntrlReq */



#ifndef LIT_NO_PORT
/*
*
*       Fun:   Portable configure Request MPC8260 driver
*
*       Desc:
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smvoptmi.c
*
*/

#ifdef ANSI
PRIVATE S16 PtMiLitCfgReq
(
Pst *pst,                   /* post structure */
ItMgmt *cfg                /* configure */
)
#else
PRIVATE S16 PtMiLitCfgReq(pst, cfg)
Pst *pst;                   /* post structure */
ItMgmt *cfg;               /* configure */
#endif
{
   TRC3(PtMiLitCfgReq);
#if (ERRCLASS & ERRCLS_DEBUG)
   /* it019.106 */
#ifdef IT_ACC
   ACCLOGERROR(ERRCLS_DEBUG, ESM019, (ErrVal) ERRZERO, "PtMiLitCfgReq");
#else
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG, (ErrCode)ESM019,
             (ErrVal)ERRZERO, "PtMiLitCfgReq");
#endif
#endif
   UNUSED(pst);
   UNUSED(cfg);
   RETVALUE(ROK);
} /* end of PtMiLitCfgReq */


/*
*
*       Fun:   Portable status Request MPC8260 driver
*
*       Desc:
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smvoptmi.c
*
*/

#ifdef ANSI
PRIVATE S16 PtMiLitStaReq
(
Pst *pst,                   /* post structure */
ItMgmt *sta                /* status */
)
#else
PRIVATE S16 PtMiLitStaReq(pst, sta)
Pst *pst;                   /* post structure */
ItMgmt *sta;               /* status */
#endif
{
   TRC3(PtMiLitStaReq);
#if (ERRCLASS & ERRCLS_DEBUG)
   /* it019.106 */
#ifdef IT_ACC
   ACCLOGERROR(ERRCLS_DEBUG, ESM020, (ErrVal) ERRZERO, "PtMiLitStaReq");
#else
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG, (ErrCode)ESM020,
             (ErrVal)ERRZERO, "PtMiLitStaReq");
#endif
#endif
   UNUSED(pst);
   UNUSED(sta);
   RETVALUE(ROK);
} /* end of PtMiLitStaReq */


/*
*
*       Fun:   Portable statistics Request MPC8260 driver
*
*       Desc:
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smvoptmi.c
*
*/

#ifdef ANSI
PRIVATE S16 PtMiLitStsReq
(
Pst *pst,                   /* post structure */
Action action,
ItMgmt *sts                /* statistics */
)
#else
PRIVATE S16 PtMiLitStsReq(pst, action, sts)
Pst *pst;                   /* post structure */
Action action;
ItMgmt *sts;               /* statistics */
#endif
{
   TRC3(PtMiLitStsReq);
#if (ERRCLASS & ERRCLS_DEBUG)
   /* it019.106 */
#ifdef IT_ACC
   ACCLOGERROR(ERRCLS_DEBUG, ESM021, (ErrVal) ERRZERO, "PtMiLitStsReq");
#else
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG, (ErrCode)ESM021,
             (ErrVal)ERRZERO, "PtMiLitStsReq");
#endif
#endif
   UNUSED(pst);
   UNUSED(action);
   UNUSED(sts);
   RETVALUE(ROK);
} /* end of PtMiLitStsReq */


/*
*
*       Fun:   Portable control Request MPC8260 driver
*
*       Desc:
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smvoptmi.c
*
*/

#ifdef ANSI
PRIVATE S16 PtMiLitCntrlReq
(
Pst *pst,                   /* post structure */
ItMgmt *cntrl              /* control */
)
#else
PRIVATE S16 PtMiLitCntrlReq(pst, cntrl)
Pst *pst;                   /* post structure */
ItMgmt *cntrl;             /* control */
#endif
{
   TRC3(PtMiLitCntrlReq);
#if (ERRCLASS & ERRCLS_DEBUG)
   /* it019.106 */
#ifdef IT_ACC
   ACCLOGERROR(ERRCLS_DEBUG, ESM022, (ErrVal) ERRZERO, "PtMiLitCntrlReq");
#else
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG, (ErrCode)ESM022,
             (ErrVal)ERRZERO, "PtMiLitCntrlReq");
#endif
#endif
   UNUSED(pst);
   UNUSED(cntrl);
   RETVALUE(ROK);
} /* end of PtMiLitCntrlReq */
#endif /* LIT_NO_PORT */


/********************************************************************30**

         End of file:     smitptmi.c@@/main/6 - Thu Apr  1 03:49:26 2004

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/3      ---      mrw  1. Initial version
/main/3      ---      as   1. Updates to Release 1.2
/main/4      ---      sg   1. Updates to Release 1.3
/main/5      ---      nt   1. Update to Release 1.5
/main/6      ---      rs   1. Update to Release 1.6.
/main/6     it019.106 sg   1. Added compilation flag IT_ACC before call to
                              ACCLOGERROR. If IT_ACC not defined, used
                              SLogError.
*********************************************************************91*/
