/*************************************************
  Copyright (C), 1995-2006, XinWei Tech. Co., Ltd.
  
  File name:    it_nms.h
  
  Subsystem   : sm
  
  Description: ����M3UAЭ���OAM�ӿ�,�������ܻ��ļ����
  �����ݱ��浽ȫ�ֱ�����
  
  Others:         

  History: 
  Programmer  Date         Rev    Description
  --------------- ---------- -------- ------------------------------
  chenning   5/18/2006    1.0        created 
*************************************************/ 

#ifndef _IT_NMS_H_
#define _IT_NMS_H_

#include "oam_interface.h"

#ifdef __cplusplus
extern "C" {
#endif
/*--------------------------------------------------------*/

/*--------------------------------------------------------*/
EXTERN unsigned char itInitCfgCallback(U16 msgtype, U32 sepuense, U8 pack_end, tb_record* prow);
EXTERN VOID itInitCfgData(VOID);
EXTERN VOID itResetCfgData(VOID);
EXTERN unsigned char itDynCfgCallback(unsigned int tableid, unsigned short msgtype, unsigned int sequence, unsigned char pack_end, tb_record *prow);
#ifdef __cplusplus
}
#endif



#endif
