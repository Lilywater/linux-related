/*************************************************
  Copyright (C), 1995-2006, XinWei Tech. Co., Ltd.
  
  File name:    it_cfg.h
  
  Subsystem   : sm
  
  Description: ����M3UAЭ���OAM�ӿ�
  ����õ��������γ����÷��͸�SM���Э��ջ����
  
  Others:         

  History: 
  Programmer  Date         Rev    Description
  --------------- ---------- -------- ------------------------------
  chenning   5/18/2006    1.0        created 
*************************************************/ 

#ifndef __IT_CFG_H__
#define __IT_CFG_H__

#include "envopt.h" 
#include "envdep.h"
#include "envind.h"
#include "gen.h"
#include "ssi.h" 
#include "cm_hash.h"
#include "cm5.h"
#include "cm_ss7.h"
#include "cm_llist.h"
#include "cm_tpt.h" 
#include "lit.h" 
#include "sct.h"
#include "snt.h"

#include "gen.x"
#include "ssi.x"          
#include "cm_ss7.x" 
#include "cm_hash.x"
#include "cm5.x"
#include "cm_lib.x"
#include "cm_tpt.x" 
#include "cm_llist.x"
#include "sct.x" 
#include "lit.x"

#include "cm_llist.x"

#ifdef __cplusplus
extern "C" {
#endif
/********************* macro *******************************/

#define SM_M3UA_TAB_NUM                     9


#define IT_CFG_MAX_GENTAB                   1
#define IT_CFG_MAX_NWKTAB                  CP_SS7_MAX_NWKTAB
#define IT_CFG_MAX_OPCTAB                   CP_SS7_MAX_UPTAB
#define IT_CFG_MAX_NODETAB                 1
#define IT_CFG_MAX_PSPTAB                   16
#define IT_CFG_MAX_PSTAB                     32
#define IT_CFG_MAX_ROUTETAB              256

#define IT_M3UA_QSIZE                           2000
#define IT_M3UA_CONG_LEVEL1                500
#define IT_M3UA_CONG_LEVEL2                1000
#define IT_M3UA_CONG_LEVEL3                1500
#define IT_TMR_RES                                  10
#define IT_DFT_TMR_RES                          1

#define IT_CFG_TIGHT                                1
#define IT_CFG_LOOSE                                0
/* selector definition added by xingzhou.xu --06/15/2006 */
/* Upper SAP */
#define IT_SEL_LC			                    0
#define IT_SEL_TC			                    1
#define IT_SEL_SP			                    IT_SEL_TC
#define IT_SEL_SI			                    2
#define IT_SEL_TP			                    3
#define IT_SEL_BI			                    4
#define IT_SEL_AL			                    5
#define IT_SEL_MG			                    6
#define IT_SEL_BICC			                    7
#define IT_SEL_ATT                                      8
/* Lower SAP */
#define IT_SEL_SN			                    IT_SEL_TC

#define IT_RTE_SIO_MASK		            0x0F
#define IT_RTE_SLS_MASK		            0x0F

#define IT_DPC_14_MASK		                    0x3FFF
#define IT_DPC_16_MASK		                    0xFFFF
#define IT_DPC_24_MASK		                    0xFFFFFF

#define IT_NWK_BEAR_M3UA                        0
#define IT_NWK_BEAR_MTP3                        1

#define IT_CFG_MAX_PSP_IN_PS                16

#define IT_CFG_ASPDN_TIMER                      2
#define IT_CFG_ASPPD_TIMER                      4
#define IT_CFG_ASPM_TIMER                       2
#define IT_CFG_ASPUP1_TIMER                     2
#define IT_CFG_ASPUP2_TIMER                     4
#define IT_CFG_DAUD_TIMER                        5
#define IT_CFG_DRKM_TIMER                       5
#define IT_CFG_DUNA_TIMER                       5
#define IT_CFG_RESTART_TIMER                60
#define IT_CFG_MTP3STA_TIMER                10
#define IT_CFG_SEQCNTRL_TIMER               1
#define IT_CFG_DPCLRN_FLAG                  FALSE

#define IT_CFG_NWK_NMB                          10
#define IT_CFG_RTE_NMB                              256
#define IT_CFG_DPC_NMB                              128
#define IT_CFG_NSAP_NMB                         10
#define IT_CFG_SCTSAP_NMB                       1
#define IT_CFG_ASPUP1_NMB                       3
#define IT_CFG_RKTRY_NMB                        3

#define IT_CFG_REGION                               0
#define IT_CFG_POOL                                   0
#define IT_CFG_SM_INST                             0
#define IT_CFG_IT_INST                              0
#define IT_CFG_SB_INST                              0
#define IT_CFG_TMR_PRIM                         10
#define IT_CFG_TMR_STA                           10


#define IT_CFG_NWK_24_SPC_LEG            24
#define IT_CFG_NWK_14_SPC_LEG            14
#define IT_CFG_NWK_16_SPC_LEG            16
#define IT_CFG_NWK_APP                          1
#define IT_CFG_NWK_SLS_LEG                  4
#define IT_CFG_DYNREGRK                         FALSE
#define IT_CFG_RXTX                                 FALSE

#define IT_CFG_REQAVAIL                         FALSE
#define IT_CFG_ROUTECTX                          0

#define ITCFGLAYERNAME                          "M3UA_CFG_LAYER"

#define ITCFGDBGP(_msgClass, _arg)                                               \
        DBGP(&(itGlobalTabCfg.CfgInit), ITCFGLAYERNAME, _msgClass, _arg)
        

/********************  enum ***************************/

typedef enum _IT_CONFIG_QUEUE_ID
{
    EN_IT_CFG_GEN_Q = 0,
    EN_IT_CFG_LSAP_Q,
    EN_IT_CFG_NETWORK_Q,
    EN_IT_CFG_NSAP_Q,
    EN_IT_CFG_PSP_Q,
    EN_IT_CFG_PS_Q,
    EN_IT_CFG_ROUTE_Q,
    EN_IT_CFG_Q_MAX_NUM,
}IT_CONFIG_QUEUE_ID;

typedef enum _IT_ROUTE_MODE
{
    EN_RT_DPC,                           /*(Route message by DPC)*/
    EN_RT_OPC,                           /*(Route message by OPC)*/
    EN_RT_DPC_SIO,                    /*(Route message by OPC+SIO)*/
    EN_RT_DPC_OPC_SIO,            /*(Route message by DPC+OPC+SIO)*/
    EN_RT_DPC_SIO_CIC,             /* (Route message by DPC+SIO+CIC Range)*/
    EN_RT_DPC_OPC_SIO_CIC,     /*(Route message by DPC+OPC+SIO+CIC Range)*/
    EN_RT_DPC_SIO_SSN,             /*(Route message by DPC+SIO+SSN)*/
    EN_RT_DPC_OPC_SIO_SSN,     /*(Route message by DPC+OPC+SIO+SSN)*/ 
    EN_RT_DPC_OPC,                     /*(Route message by OPC+OPC)*/
    EN_RT_OPC_SIO,                      /*(Route message by OPC+SIO)*/
    EN_RT_OPC_SIO_CIC,               /*(Route message by OPC+SIO+CIC Range)*/
    EN_RT_DPC_SIO_TRID,             /*(Route message by DPC+SIO+TRID Range)*/
    EN_RT_DPC_OPC_SIO_TRID,     /*(Route message by DPC+OPC+SIO+TRID Range)*/
    EN_RT_OPC_SIO_TRID                     /*(Route message by OPC+SIO+TRID Range)*/
}EN_IT_ROUTE_MODE;


/************** struct ************************/
typedef struct _ItCfgM3uaGenTab
{
    U32     MaxPsNum;
    U32     MaxPspNum;
    U32     MaxLpsNum;
    U32     MaxNumMsg;
    U32     MaxNumRndRbnls;
    U32     MaxNumSlsls;
    U32     MaxNumSls;
    U32     DrkmSupp;
    U32     DrstSupp;
    U32     HeartbeatTimer;
} ItCfgM3uaGenTab;

typedef struct _ItCfgM3uaNodeTypeTab
{
    U32     NodeType;
    U32     M3uaPort;
} ItCfgM3uaNodeTypeTab;

typedef struct _ItCfgM3uaPspTab
{
    U32     OprType;
    U32     PspID;
    U32     PspType;
    U32     IpspType;
    U32     DfltLshareMode;
    U32     NwkAppIncl;
    U32     NwkID;
    U32     DestAddr1;
    U32     DestAddr2;
    U32     DestAddr3;
    U32     DestAddr4;
    U32     PriDestAddr;
    U32     DestPort;
    U32     OutStreamNum;
} ItCfgM3uaPspTab;

typedef struct _ItCfgM3uaPsTab
{
    U32     OprType;
    U32     PsID;
    U32     NwkID;
    U32     PsWorkMode;
    U32     RoutCtx;
    U32     LoadShareMode;
    U32     LocalFlag;
    U32     ActivePspRequired;
    U32     PspNum;
    U32     Psp[IT_CFG_MAX_PSP_IN_PS];
}ItCfgM3uaPsTab;

typedef struct _ItCfgM3uaRouteTab
{
    U32     OprType;
    U32     RouteID;
    U32     RouteType;
    U32     PsID;
    U32     NwkID;
    U32     RouteMode;
    U32     DPCValue;
    U32     OPCValue;
    U32     SIO;
    U32     CICStart;
    U32     CICEnd;
    U32     SSN;
    U32     TridStart;
    U32     TridEnd;
} ItCfgM3uaRouteTab;

typedef struct _ItCfgGlobal
{
    TskInit                         CfgInit;
    U16                             GenTabNum;
    ItCfgM3uaGenTab         GenTab[IT_CFG_MAX_GENTAB];
    U16                             NodeTabNum;
    ItCfgM3uaNodeTypeTab NodeTab[IT_CFG_MAX_NODETAB];
    U16                             PspTabNum;
    ItCfgM3uaPspTab         PspTab[IT_CFG_MAX_PSPTAB];
    U16                             PsTabNum;
    ItCfgM3uaPsTab          PsTab[IT_CFG_MAX_PSTAB];
    U16                             RouteTabNum;
    ItCfgM3uaRouteTab       RouteTab[IT_CFG_MAX_ROUTETAB];
} ItCfgGlobal;

/********************** extern *******************************/
EXTERN U32 itCfgTbl[];
EXTERN CmLListCp itGlobalSmQ[];
EXTERN ItCfgGlobal itGlobalTabCfg;

EXTERN S16 smItSendReqQ(CmLList *node);

EXTERN S16  itTabSs7NwkCfg(U32 NwkIndex);
EXTERN S16  itTabM3uaGenCfg(VOID);
EXTERN S16  itTabM3uaPspCfg(U32 PspIndex);
EXTERN S16  itTabM3uaPsCfg(U32 PsIndex);
EXTERN S16  itTabM3uaRteCfg(U32 RteIndex);
EXTERN S16  itTabM3uaLSapCfg(VOID);
EXTERN S16  itTabM3uaNSapCfg(U32 OpcIndex);

#ifdef __cplusplus
}
#endif

#endif
