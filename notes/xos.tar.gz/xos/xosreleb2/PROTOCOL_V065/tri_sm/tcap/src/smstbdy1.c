/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     stack manager TCAP body 1
  
     Type:     C source file
  
     Desc:     Prototype C source code for the Layer Management
               service provider primitives that usually are supplied
               by the customer.
               This is the version used for the TCAP sample code test.
               This file was created out of lm_ptsp.c

     File:     smstbdy1.c
  
     Sid:      smstbdy1.c@@/main/9 - Fri Nov 17 10:33:43 2000
  
     Prg:      ak
  
*********************************************************************21*/
  
  
/*
  
Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.

The following functions are provided in this file for the
layer management service user:
  
     SmMiLstCfgCfm      Configuration Confirm
     SmMiLstCntrlCfm    Control Confirm
     SmMiLstStaCfm      Status Confirm
     SmMiLstStsCfm      Statistics Confirm
     SmMiLstStaInd      Status Indication
     SmMiLstTrcInd      Trace Indication
  

It is assumed that the following functions are provided in the
stack management file smstptmi.c.
  
     SmMiLstCfgReq      Configure Request
     SmMiLstUcfgReq     Unconfigure Request
     SmMiLstCntrlReq    Control Request
     SmMiLstStaReq      Status Request
     SmMiLstStsReq      Statistics Request
  
*/
  
  
/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "cm5.h"           /* common Timer */
#include "lst.h"           /* layer management, TCAP */
#include "smst_err.h"      /* Stack Manager - TCAP interface - error */
#ifdef STTST
#include "st_acc.h"        /* TCAP acceptance test */
 /* st005.301 - Added - Rolling Upgrade feature */
#ifdef ST_RUG
#include "gen.h"
#include "stu.h"
#include "spt.h"
#endif /* ST_RUG */
#endif /* STTST */
#ifdef ST_FTHA
/* st007.301 -Modify -sht.h included if ST_FTHA is defined,
 *            Deleted - ST_RUG flag */
#include "sht.h"
#endif /* ST_FTHA */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */
#include "cm5.x"           /* common Timer */
#include "lst.x"           /* layer management, TCAP */
/* st007.301 -Modify -sht.x included if ST_FTHA is defined,
 *            Deleted - ST_RUG flag */
#ifdef ST_FTHA
#include "sht.x"
#endif /* ST_FTHA */
/* st005.301 - Added- Rolling Upgrade Feature */
#ifdef STTST
/* st007.301 -Modify- stAccFlushQ is needed for TC-User Dist
 * Feature */
#if (defined(ST_RUG) || defined(ST_TC_USER_DIST))
EXTERN  S16   stAccFlushQ       ARGS((Void));
#endif /* ST_RUG or ST_TC_USER_DIST */
#endif /* STTST */

  
/* local defines */

#define PRNTBUF_SIZE  128  /* Print Buffer size */
#define LM_PERIOD      60
  
#ifdef STTST
#define LM_GETMSG(p, m, e) {                                          \
    S16   ret;                                                        \
                                                                      \
    ret = SGetMsg((p)->region, (p)->pool, &(m));                      \
    if (ret != ROK)                                                   \
    {                                                                 \
        SLogError(0, 0, 0,  __FILE__, __LINE__, ERRCLS_DEBUG, e, 0,   \
                      "SGetMsg failed");                              \
        RETVALUE(ret);                                                \
    }                                                                 \
  }
#endif /* STTST */
  
/* local typedefs */
  
/* local externs */
/* bind confirm status */
PRIVATE Txt *cfmStatus[] = {"OK","NOT_OK"};
/* bind confirm reason */
PRIVATE Txt *cfmReason[] = {"NOT_APPL","INVALID_ENT", "INVALID_INST", "INVALID_MSGTYPE",
							"MEM_NOT_AVAIL", "INVALID_ELMNT", "RECFG_FAIL", "REGTMR_FAIL",
							"GENCFG_NOT_DONE", "INVALID_ACT", "INVALID_SUBACT", "INVALID_STATE",
							"INVALID_SAP", "INVALID_PARAM", "UNKOWN", "QINIT_FAIL", "NEG_CFM",
							"UPDTMR_EXP", "MISC_FAIL", "EXCEED_CFG_VAL", "HASHING_FAIL", 
							"PEERCFG_NOT_DONE", "PRT_LYRCFG_NOT_DONE", "INV_RSET", 
							"INV_REST_RANGE", "INV_RSET_TYPE", "INV_RSET_QUAL", "INV_IF", 
							"INV_DIST_TYPE", "INV_DIST_QUAL", "NAK_RCVD", "TIMEOUT", "PURE_FTHA",
							"DIST_FTHA", "INV_KEY", "SW_INCOMP", "VER_MISMATCH", "SWVER_INV"};

/* forward references */
PUBLIC  S16  smStActvTmr      ARGS((Void));


#ifdef STTST
EXTERN  Queue   *stAccLmRxQ;     /* Acceptance Test LM message receive queue */
/* st005.301 - Added- Rolling Upgrade feature */
EXTERN  Bool    stAccChk; /* Flag for test is passed */

/* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG
EXTERN Bool stAccAlarmChk; /* Flag for  alarm is ok */
#endif /* ST_RUG */

/* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
EXTERN Bool stAccTcUserDistAlarmChk; /* Flag for  alarm is ok */
#endif /* ST_TC_USER_DIST */
/* st007.301 - Modify - stAccFlshQ kept under STTST flag */
EXTERN Bool stAccFlshQ; /* Flag to indicate Queue 
                           will be flushed before 
                           inserting in it */

#endif /* STTST */

/* public variable declarations */

/* private variable declarations */

  
/*
*     interface functions to layer management service user
*/

    
/*
*
*       Fun:   Status Indication
*
*       Desc:  This function is used by the TCAP to present
*              unsolicited status information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smstbdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLstStaInd
(
Pst       *pst,          /* post structure */
StMngmt   *usta          /* unsolicited status */
)
#else
PUBLIC S16 SmMiLstStaInd(pst, usta)
Pst       *pst;          /* post structure */
StMngmt   *usta;         /* unsolicited status */

#endif
{
   Txt      prntBuf[PRNTBUF_SIZE];

   TRC2(SmMiLstStaInd)
 
   UNUSED(pst);

#ifdef SMST_LMINT3
   sprintf(prntBuf,"SM:Alarm from TCAP with category %d, event %d, cause %d\n",
                       usta->t.usta.alarm.category, usta->t.usta.alarm.event,
                       usta->t.usta.alarm.cause);
#else
   sprintf(prntBuf,"SM:Alarm from TCAP with event %d\n", usta->t.usta.evnt);
#endif /* SMST_LMINT3 */
   SPrint(prntBuf);

/* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG
#ifdef STTST
  if (stAccAlarmChk)
  {
      if (pst->intfVer != LSTIFVER - 1)
      {
        stAccChk = FALSE;
        sprintf(prntBuf,"Invalid Interface version no. in alarms");
        RETVALUE(RFAILED);
      }
      stAccChk = TRUE;
  } /* stAccAlarmChk */
#endif /* STTST */
#endif /* ST_RUG */

  
/* st007.301 - Added - TC-User Distribution Feature */  
#ifdef STTST
#ifdef ST_TC_USER_DIST

  if (stAccTcUserDistAlarmChk)
  {
     if ((usta->t.usta.alarm.category != LCM_CATEGORY_INTERNAL) && 
         ((usta->t.usta.alarm.cause != LST_CAUSE_TUSAP_ASSOC_FAIL) ||
          (usta->t.usta.alarm.cause != LST_CAUSE_SPSAP_ASSOC_FAIL)))
     {
        sprintf(prntBuf,"Improper Alarm generated");
        stAccChk = FALSE;     
     }        
     stAccChk = TRUE;
  }        
#endif /* ST_TC_USER_DIST */
#endif /* STTST */
   RETVALUE(ROK);
} /* end of SmMiLstStaInd */

  
/*
*
*       Fun:   Trace Indication
*
*       Desc:  This function is used by TCAP to present trace
*              information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smstbdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLstTrcInd
(
Pst       *pst,          /* post structure */
StMngmt   *trc           /* trace */
)
#else
PUBLIC S16 SmMiLstTrcInd(pst, trc)
Pst       *pst;          /* post structure */
StMngmt   *trc;          /* trace */
#endif
{
   Txt      prntBuf[PRNTBUF_SIZE];
   Buffer  *mBuf;

   TRC2(SmMiLstTrcInd)

   if (trc->t.trc.evnt == LST_MSG_RECVD)
   {
      sprintf(prntBuf, "\nMessage Trace: Event = MSG_RX'd\n");
   }
   else if (trc->t.trc.evnt == LST_MSG_TXED)
   {
      sprintf(prntBuf, "\nMessage Trace: Event = MSG_TX'd\n");
   }
   else
   {
      sprintf(prntBuf, "\nMessage Trace: Event = Illegal Event\n");
      SPrint(prntBuf);
      RETVALUE(RFAILED);
   }
   SPrint(prntBuf);
 
   SGetMsg(pst->region, pst->pool, &mBuf);
   SAddPstMsgMult(trc->t.trc.evntParm, trc->t.trc.len, mBuf);
   SPrntMsg(mBuf, 0, 0);
   SPutMsg(mBuf);

   RETVALUE(ROK);
} /* end of SmMiLstTrcInd */

    
/*
*
*       Fun:   Statistics Confirm
*
*       Desc:  This function is used by the TCAP to present
*              solicited statistics information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smstbdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLstStsCfm
(
Pst        *pst,         /* post structure */
StMngmt    *sts          /* confirmed statistics */
)
#else
PUBLIC S16 SmMiLstStsCfm(pst, sts)
Pst        *pst;         /* post structure */
StMngmt    *sts;         /* confirmed statistics */
#endif
{
   SpId      spId;       /* Sap Id */
   StSapSts *s;
   Txt       prntBuf[PRNTBUF_SIZE];    /* print buffer */
   Bool      ituFlag;

   TRC2(SmMiLstStsCfm)

   UNUSED(pst);

   /* Get the Sap Id */
   spId = sts->hdr.elmId.elmntInst1;

   s    = &sts->t.sts.sapSts;
   
   /* Set the protocol flag */
   switch(s->swtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:

#if (SS7_ETSI)
      case LST_SW_ETS96:
#endif
         ituFlag = TRUE;
         break;

      default:
         ituFlag = FALSE;
         break;
   }

   sprintf(prntBuf, "\nStatistics for SAP: %u\n\n", spId);
   SPrint(prntBuf);
   sprintf(prntBuf, "%-32s   %-10s%s\r\n", "Type", "Rx", "Tx");
   SPrint(prntBuf);
   sprintf(prntBuf, "------------------------------------------------\n");
   SPrint(prntBuf);
   sprintf(prntBuf, "%-32s : %-10lu%lu\r\n", "Total Messages", s->msgRx, s->msgTx);
   SPrint(prntBuf);
   sprintf(prntBuf, "%-32s : %-10lu%lu\r\n", "Uni Msgs", s->uniRx, s->uniTx);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu%lu\r\n", "Abort Msgs", s->abtRx, s->abtTx);
   SPrint(prntBuf);

   if (ituFlag)
   {
      sprintf(prntBuf, "%-32s : %-10lu%lu\r\n", "Begin Msgs", s->bgnRx, s->bgnTx);
      SPrint(prntBuf);
      sprintf(prntBuf, "%-32s : %-10lu%lu\r\n", "Cont Msgs", s->cntRx, s->cntTx);
      SPrint(prntBuf);
      sprintf(prntBuf, "%-32s : %-10lu%lu\r\n", "End Msgs", s->endRx, s->endTx);
      SPrint(prntBuf);
   }

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   else
   {
      sprintf(prntBuf, "%-32s : %-10lu%lu\r\n", "Query With Permission", s->qwpRx, s->qwpTx);
      SPrint(prntBuf);
      sprintf(prntBuf, "%-32s : %-10lu%lu\r\n", "Query Without Permission", s->qnpRx, s->qnpTx);
      SPrint(prntBuf);
      sprintf(prntBuf, "%-32s : %-10lu%lu\r\n", "Conversation With Permission", s->cwpRx, s->cwpTx);
      SPrint(prntBuf);
      sprintf(prntBuf, "%-32s : %-10lu%lu\r\n", "Conversation Without Permission", s->cnpRx, s->cnpTx);
      SPrint(prntBuf);
      sprintf(prntBuf, "%-32s : %-10lu%lu\r\n", "Response", s->rspRx, s->rspTx);
      SPrint(prntBuf);
   }
#endif

   sprintf(prntBuf, "%-32s : %-10lu%lu\r\n", "Total Components", s->cmpRx, s->cmpTx);
   SPrint(prntBuf);
   sprintf(prntBuf, "%-32s : %-10lu%lu\r\n", "Invoke", s->invRx, s->invTx);
   SPrint(prntBuf);
   sprintf(prntBuf, "%-32s : %-10lu%lu\r\n", "Return-Result", s->resRx, s->resTx);
   SPrint(prntBuf);
   sprintf(prntBuf, "%-32s : %-10lu%lu\r\n", "Return-Error", s->errRx, s->errTx);
   SPrint(prntBuf);
   sprintf(prntBuf, "%-32s : %-10lu%lu\r\n\n", "Reject", s->rejRx, s->rejTx);
   SPrint(prntBuf);

   sprintf(prntBuf, "%-32s : %-10lu\r\n", "Total Active Transactions", s->actTrns);
   SPrint(prntBuf);
   sprintf(prntBuf, "%-32s : %-10lu\r\n", "Total Active Invokes", s->actInv);
   SPrint(prntBuf);
   sprintf(prntBuf, "%-32s : %-10lu\r\n", "Total Used Transaction Ids", s->trnsId);
   SPrint(prntBuf);

   sprintf(prntBuf, "%-32s : %-10lu\r\n", "Total Rx Msgs Droppeds", s->drop);
   SPrint(prntBuf);

   sprintf(prntBuf, "\nAbort Cause/Problem codes received in the P-Abort/Reject:\n\n");
   SPrint(prntBuf);
   sprintf(prntBuf, "%-30s   %-7s\r\n", "Error Type", "Count");
   SPrint(prntBuf);
   sprintf(prntBuf, "------------------------------------------------\n");
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Unrecognized Msgs", s->urMsgRx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Incorrect Transaction Portion", s->inTrnRx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Badly Structured Trns Prtn", s->bdTrnRx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Unrecognized Transaction Id", s->urTidRx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Resource Limitation", s->rsrcLRx.cnt);
   SPrint(prntBuf);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   if (!ituFlag)
   {
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Permission to Release Problem", s->prRlsRx.cnt);
      SPrint(prntBuf);
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Unrecognized Dlg Prtn Id", s->urDlgRx.cnt);
      SPrint(prntBuf);
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Badly Structured Dlg Prtn", s->bdDlgRx.cnt);
      SPrint(prntBuf);
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Missing Dlg Prtn", s->msDlgRx.cnt);
      SPrint(prntBuf);
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Inconsistent Dlg Prtn", s->inDlgRx.cnt);
      SPrint(prntBuf);
   }
#endif

   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "General - Unrecognized Component", s->urCmpRx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "General - Incorrect Component", s->inCmpRx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "General - Badly Structured Comp", s->bdCmpRx.cnt);
   SPrint(prntBuf);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   if (!ituFlag)
   {
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "General - Inc Comp Encoding", s->inEncRx.cnt);
      SPrint(prntBuf);
   }
#endif

   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Unrecognized Linked Id", s->urLidRx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Result - Unrecognized Invoke Id", s->urIidRRRx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Result - Unexpected Ret-Result", s->uxResRx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Error - Unrecognized Invoke Id", s->urIidRERx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Error - Unexpected Ret-Error", s->uxErrRx.cnt);
   SPrint(prntBuf);

   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Duplicate Invoke Id", s->dupIdRx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Unrecognized OpCode", s->urOprRx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Incorrect Parameters", s->inPrmINRx.cnt);
   SPrint(prntBuf);

   if (ituFlag)
   {
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Resource Limitation", s->rsrcInvRx.cnt);
      SPrint(prntBuf);
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Initiating Release", s->rlsInvRx.cnt);
      SPrint(prntBuf);
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Unexpected Linked Rsp", s->uxLrspRx.cnt);
      SPrint(prntBuf);
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Unexpected Linked Opr", s->uxLoprRx.cnt);
      SPrint(prntBuf);
   }

   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Result - Incorrect Parameters", s->inPrmRRRx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Error - Unrecognized Error Code", s->urErrRx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Error - Unexpected Error Code", s->uxEcdRx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Error - Incorrect Parameters", s->inPrmRERx.cnt);
   SPrint(prntBuf);

   sprintf(prntBuf, "\nError detected in the received Messages/components:\n\n");
   SPrint(prntBuf);
   sprintf(prntBuf, "%-30s   %-7s\r\n", "Error Type", "Count");
   SPrint(prntBuf);
   sprintf(prntBuf, "------------------------------------------------\n");
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Unrecognized Msgs", s->urMsgTx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Incorrect Transaction Portion", s->inTrnTx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Badly Structured Trns Prtn", s->bdTrnTx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Unrecognized Transaction Id", s->urTidTx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Resource Limitation", s->rsrcLTx.cnt);
   SPrint(prntBuf);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   if (!ituFlag)
   {
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Permission to Release Problem", s->prRlsTx.cnt);
      SPrint(prntBuf);
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Unrecognized Dlg Prtn Id", s->urDlgTx.cnt);
      SPrint(prntBuf);
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Badly Structured Dlg Prtn", s->bdDlgTx.cnt);
      SPrint(prntBuf);
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Missing Dlg Prtn", s->msDlgTx.cnt);
      SPrint(prntBuf);
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Inconsistent Dlg Prtn", s->inDlgTx.cnt);
      SPrint(prntBuf);
   }
#endif

   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "General - Unrecognized Component", s->urCmpTx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "General - Incorrect Component", s->inCmpTx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "General - Badly Structured Comp", s->bdCmpTx.cnt);
   SPrint(prntBuf);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   if (!ituFlag)
   {
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "General - Inc Comp Encoding", s->inEncTx.cnt);
      SPrint(prntBuf);
   }
#endif

   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Unrecognized Linked Id", s->urLidTx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Result - Unrecognized Invoke Id", s->urIidRRTx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Result - Unexpected Ret-Result", s->uxResTx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Error - Unrecognized Invoke Id", s->urIidRETx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Error - Unexpected Ret-Error", s->uxErrTx.cnt);
   SPrint(prntBuf);

   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Duplicate Invoke Id", s->dupIdTx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Unrecognized OpCode", s->urOprTx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Incorrect Parameters", s->inPrmINTx.cnt);
   SPrint(prntBuf);

   if (ituFlag)
   {
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Resource Limitation", s->rsrcInvTx.cnt);
      SPrint(prntBuf);
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Initiating Release", s->rlsInvTx.cnt);
      SPrint(prntBuf);
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Unexpected Linked Rsp", s->uxLrspTx.cnt);
      SPrint(prntBuf);
	  sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Invoke - Unexpected Linked Opr", s->uxLoprTx.cnt);
      SPrint(prntBuf);
   }

   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Result - Incorrect Parameters", s->inPrmRRTx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Error - Unrecognized Error Code", s->urErrTx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Error - Unexpected Error Code", s->uxEcdTx.cnt);
   SPrint(prntBuf);
   sprintf(prntBuf,  "%-32s : %-10lu\r\n", "Error - Incorrect Parameters", s->inPrmRETx.cnt);
   SPrint(prntBuf);

   RETVALUE(ROK);
} /* end of SmMiLstStsCfm */

    
/*
*
*       Fun:   Status Confirm
*
*       Desc:  This function is used by the TCAP to present
*              solicited status information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smstbdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLstStaCfm
(
Pst       *pst,          /* post structure */
StMngmt   *sta           /* confirmed statistics */
)
#else
PUBLIC S16 SmMiLstStaCfm(pst, sta)
Pst       *pst;          /* post structure */
StMngmt   *sta;          /* confirmed statistics */
#endif
{

   LnkNmb     lnkNmb;                 /* link number */
   Txt        prntBuf[PRNTBUF_SIZE];  /* print buffer */
   SystemId  *sid;                    /* System Id */
#ifdef STTST
   /*st011.301 - Added for posting message*/
   Buffer    *mBuf;                   /* Message Buffer */
#endif

   TRC2(SmMiLstStaCfm)

   UNUSED(pst);

/* st011.301-Addition- posting message in LM Deque */
#ifndef LCSMSTMILST
   pst->event = EVTLSTSTACFM;
#endif /* LCSMSTMILST */

#ifdef STTST
   LM_GETMSG(pst, mBuf, ESMSTXXX);

   /* now pack */
   CMCHKPKLOG(cmPkCmStatus, &sta->cfm, mBuf, ESMSTXXX, pst);
   CMCHKPKLOG(cmPkHeader,   &sta->hdr, mBuf, ESMSTXXX, pst);
   CMCHKPKLOG(cmPkPst,      pst,       mBuf, ESMSTXXX, pst);

   /* now queue the message */
   SQueueLast(mBuf, stAccLmRxQ);
#endif
/* End of st011.301 */

   /* in the acceptance test, this needs to update the link info */
   lnkNmb = sta->hdr.elmId.elmntInst1;

   switch (sta->hdr.elmId.elmnt)
   {
      /* status for TCAP Upper Sap */
      case STTCUSAP:
         sprintf(prntBuf, "\nStatus for Upper Sap id: %d\n", lnkNmb);
         SPrint(prntBuf);
         sprintf(prntBuf, "High Level State: %d\n", sta->t.ssta.s.sapSta.hlSt);
         SPrint(prntBuf);
         sprintf(prntBuf, "Switch type : %d\n", sta->t.ssta.s.sapSta.swtch);
         SPrint(prntBuf);

/* st005.301 - Added- Rolling Upgrade feature */
#ifdef ST_RUG
#ifdef STTST
         sprintf(prntBuf, "Self Interface Version : %d\n", 
                       sta->t.ssta.s.sapSta.selfIntfVer);
         SPrint(prntBuf);
         sprintf(prntBuf, "Remote Interface Version : %d\n", 
                       sta->t.ssta.s.sapSta.remIntfVer);
         SPrint(prntBuf);
         if (( sta->t.ssta.s.sapSta.selfIntfVer == STUIFVER ) && 
             (sta->t.ssta.s.sapSta.remIntfVer == STUIFVER))
           stAccChk = TRUE;
         else
           stAccChk = FALSE;

#endif /* STTST */
#endif /* ST_RUG */
         break;

      /* status for TCAP Lower Sap */
      case STSPSAP:
         sprintf(prntBuf, "\nStatus for Lower Sap id: %d\n", lnkNmb);
         SPrint(prntBuf);
         sprintf(prntBuf, "High Level State: %d\n", sta->t.ssta.s.sapSta.hlSt);
         SPrint(prntBuf);
         sprintf(prntBuf, "Switch type : %d\n", sta->t.ssta.s.sapSta.swtch);
         SPrint(prntBuf);
         break;

      /* system id */
      case STSID: 
         sid = &sta->t.ssta.s.sysId;
         sprintf(prntBuf, "\nTCAP System Id = %d:%d:%d:%d - %s\n", sid->mVer,
         sid->mRev, sid->bVer, sid->bRev, sid->ptNmb);
         SPrint(prntBuf);
         break;
   }

   RETVALUE(ROK);
} /* end of SmMiLstStaCfm */

#ifdef SMST_LMINT3

/*
*
*       Fun:   Configuration Confirm
*
*       Desc:  This function is used by the TCAP to present
*              configuration confirmation information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smstbdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SmMiLstCfgCfm
(
Pst      *pst,
StMngmt  *cfm          /* confirm */
)
#else
PUBLIC S16 SmMiLstCfgCfm(pst, cfm)
Pst      *pst;
StMngmt  *cfm;         /* confirm */
#endif
{
#ifdef STTST
   Buffer    *mBuf;
#else
   Txt        prntBuf[PRNTBUF_SIZE];  /* print buffer */
#endif /* STTST */

   TRC2(SmMiLstCfgCfm)

#ifndef LCSMSTMILST
   pst->event = EVTLSTCFGCFM;
#endif /* LCSMSTMILST */

#ifdef STTST
   LM_GETMSG(pst, mBuf, ESMST001);

   /* now pack */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ESMST002, pst);
   CMCHKPKLOG(cmPkHeader,   &cfm->hdr, mBuf, ESMST003, pst);
   CMCHKPKLOG(cmPkPst,      pst,       mBuf, ESMST004, pst);

   /* now queue the message */
   SQueueLast(mBuf, stAccLmRxQ);
#else
   sprintf(prntBuf,"SM:Config Cfm from TCAP Proc %x with status %s, reason %s\n",
                       pst->srcProcId, cfmStatus[cfm->cfm.status],
                       cfmReason[cfm->cfm.reason]);
   SPrint(prntBuf);
#endif

   RETVALUE(ROK);
} /* end of SmMiLstCfgCfm */


/*
*
*       Fun:   control Confirm
*
*       Desc:  This function is used by the TCAP to present
*              control confirmation information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smstbdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SmMiLstCntrlCfm
(
Pst      *pst,
StMngmt  *cfm          /* confirm */
)
#else
PUBLIC S16 SmMiLstCntrlCfm(pst, cfm)
Pst      *pst;
StMngmt  *cfm;         /* confirm */
#endif
{
#ifdef STTST
   Buffer    *mBuf;
#else
   Txt        prntBuf[PRNTBUF_SIZE];  /* print buffer */
#endif /* STTST */

   TRC2(SmMiLstCprntBuf)

#ifndef LCSMSTMILST
   pst->event = EVTLSTCNTRLCFM;
#endif /* LCSMSTMILST */

#ifdef STTST
   LM_GETMSG(pst, mBuf, ESMST005);

   /* now pack */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ESMST006, pst);
   CMCHKPKLOG(cmPkHeader,   &cfm->hdr, mBuf, ESMST007, pst);
   CMCHKPKLOG(cmPkPst,      pst,       mBuf, ESMST008, pst);

   /* st005.301 - Added- Rolling Upgrade feature */
   /* st007.301 -Modify- Flush the queue for RUG and TC User Dist. feature  */
   /* now flush the queue */
#if (defined(ST_RUG) || defined(ST_TC_USER_DIST))
   if (stAccFlshQ)
     stAccFlushQ(); 
#endif /* ST_RUG or ST_TC_USER_DIST */
  /* now queue the message */
   SQueueLast(mBuf, stAccLmRxQ);
#else
   sprintf(prntBuf,
      "SM:Control Cfm from TCAP Proc %x with status %s, reason %s\n",
                    pst->srcProcId, cfmStatus[cfm->cfm.status], 
                    cfmReason[cfm->cfm.reason]);
   SPrint(prntBuf);
#endif

   RETVALUE(ROK);
} /* end of SmMiLstCntrlCfm */
#endif /* SMST_LMINT3 */


/*
*
*       Fun:   Activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smstbdy1.c
*
*/
  
#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 smStActvInit
(
ProcId proc,           /* Proc Id * */
Ent         ent,         /* entity */
Inst        inst,        /* instance */
Region      region,      /* region */
Reason      reason,       /* reason */
void **xxCb            /* protocol control block */
)
#else
PUBLIC S16 smStActvInit(proc,ent, inst, region, reason)
ProcId proc;           /* Proc Id */
Ent         ent;         /* entity */
Inst        inst;        /* instance */
Region      region;      /* region */
Reason      reason;      /* reason */
void     **xxCb;            /* protocol control block */
#endif
#else 
#ifdef ANSI
PUBLIC S16 smStActvInit
(
Ent         ent,         /* entity */
Inst        inst,        /* instance */
Region      region,      /* region */
Reason      reason       /* reason */
)
#else
PUBLIC S16 smStActvInit(ent, inst, region, reason)
Ent         ent;         /* entity */
Inst        inst;        /* instance */
Region      region;      /* region */
Reason      reason;      /* reason */
#endif
#endif
{
   TRC3(smStActvInit)
 
   UNUSED(region);
   UNUSED(reason);
/*--- Commentted by xingzhou.xu for it making dead lock 2006/03/27 -----
#ifndef SS7_TST
   /* register timer: ask for one resolution (LM_PERIOD) * /
#ifdef SS_MULTIPLE_PROCS
   (Void)SRegTmr(proc,ent, inst, LM_PERIOD, smStActvTmr);
#else 
   (Void)SRegTmr(ent, inst, LM_PERIOD, smStActvTmr);
#endif
#endif /* SS7_TST * /
*-------------------------------------------------------------------*/
   RETVALUE(ROK);
} /* end of smStActvInit */

/*
*
*       Fun:    smStActvTmr
*
*       Desc:   Processes Layer Manager Timer ticks
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   smstbdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smStActvTmr
(
Void
)
#else
PUBLIC S16 smStActvTmr()
#endif
{
   TRC2(smStActvTmr)
 
   RETVALUE(ROK);
} /* end of smStActvTmr */

#ifdef TDS_CORE2
#ifdef ST_FTHA
/*
 *
 *      Fun  : Control Request Confirmation
 *
 *      Desc : This function is used to indicate the status of a previous
 *             control request via the system agent interface.
 *:
 *      Ret  : ROK      - ok
 *
 *      Notes: None
 *
 *      File :  smstbdy1.c
 *
 */
#ifdef ANSI
PUBLIC S16 ShMiShtCntrlCfm
(
Pst     *pst,                                   /* post structure       */
ShtCntrlCfmEvnt *cfmInfo                         /* control confirm      */
)
#else
PUBLIC S16 ShMiShtCntrlCfm(pst, cfmInfo)
Pst     *pst;                                   /* post structure       */
ShtCntrlCfmEvnt *cfmInfo;                        /* control confirm      */
#endif
{
  S16 ret1;
  Buffer *mBuf;

   TRC3(ShMiShtCntrlCfm)

/* st005.301 - Added- Rolling Upgrade Feature */   
   if ((cfmInfo->transId != 0 ) ||
       (cfmInfo->status.status != LCM_PRIM_OK))
   {
#if (ERRCLS & ERRCLS_INT_PAR)
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, \
             __LINE__, (ErrCls) ERRCLS_INT_PAR, (ErrVal)ESMSAXXX,
             (ErrVal)0, "SmMiLstCntrlCfm() Failed");
#endif
   }

    ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
    if (ret1 != ROK)
    {
       LSTLOGERROR(ERRCLS_ADD_RES, ESMXXX, (ErrVal) ret1,"SGetMsg failed");
       RETVALUE(ret1);
    }
/* st005.301 - Added- Rolling Upgrade Feature */    
#ifdef ST_RUG
   switch (cfmInfo->reqType)
    {
      case  SHT_REQTYPE_GETVER:
      case  SHT_REQTYPE_SETVER: 
           CMCHKPKLOG(SPkU16, cfmInfo->t.gvCfm.pif.intfVer, 
                 mBuf,ESMST006, pst);
           CMCHKPKLOG(SPkU16, cfmInfo->t.gvCfm.pif.intfId, 
                 mBuf,ESMST006, pst);                             
           CMCHKPKLOG(SPkU16, cfmInfo->t.gvCfm.lifList[0].intfVer, 
                 mBuf,ESMST006, pst);
           CMCHKPKLOG(SPkU16, cfmInfo->t.gvCfm.lifList[0].intfId, 
                 mBuf,ESMST006, pst);
           CMCHKPKLOG(SPkU16,cfmInfo->t.gvCfm.numLif,
                 mBuf,ESMST006, pst);
           CMCHKPKLOG(SPkU16, cfmInfo->t.gvCfm.uifList[0].intfVer, 
                 mBuf,ESMST006, pst);
           CMCHKPKLOG(SPkU16, cfmInfo->t.gvCfm.uifList[0].intfId, 
                 mBuf,ESMST006, pst);
           CMCHKPKLOG(SPkU16,cfmInfo->t.gvCfm.numUif,mBuf,ESMST006, pst);
           CMCHKPKLOG(SPkU8, cfmInfo->reqType, mBuf,ESMST006, pst);
           CMCHKPKLOG(cmPkCmStatus, &cfmInfo->status, mBuf,ESMST006, pst);
           CMCHKPKLOG(cmPkTranId, cfmInfo->transId, mBuf,ESMST006, pst);
           CMCHKPKLOG(cmPkPst, pst, mBuf,ESMST006, pst);
  

/* st007.301 -Modify- Access to stAccLmRxQ,stAccFlushQ  should be under STTST flag */
#ifdef STTST           
           /* now flush the queue */
           if (stAccFlshQ)
              stAccFlushQ(); 
          /* Now Queue the last message */  
           SQueueLast(mBuf, stAccLmRxQ);
#endif /* STTST */           
           break;
     default:
          break; 
     }
#endif /* ST_RUG */      

   RETVALUE(ROK);
} /* end of ShMiShtCntrlCfm */

#endif /* ST_FTHA */
#endif /* TDS_CORE2 */




/********************************************************************30**
  
         End of file:     smstbdy1.c@@/main/9 - Fri Nov 17 10:33:43 2000

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  ak    1. initial release

1.2          ---  ak    1. change call to SRegTmr

1.3          ---  ak    1. smStActvTmr now seeks stats for 8 links for
                           ANSI 92, 4 for ANSI 88
             ---  ak    2. StsCfm prints statistics a bit more intelligently
                           using swtch field in the sts structure.
             ---  ak    3. StaInd prints out unsolicited status information.
             ---  ak    4. initialize all StMngmt fields before transmission

1.4          ---  fmg   1. replaced strncpy with cmCopy
             ---  fmg   2. changed extern to EXTERN
             ---  fmg   3. changed smStActvTmr from PRIVATE to PUBLIC
             ---  fmg   4. changed #ifdef SS7_XXXX usage to #if SS7_XXXX

1.5          ---  aa    1. miscellaneous changes


*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.6          ---      aa   1. Moved cm_ss7.[hx] above lst.[hx] 

1.7          ---      nj   1. Rewrote the file.
1.8          ---      nj   1. Config confirm and control confirm primitives
                              added for SMST_LMINT3.
             ---      nj   2. Added support for ITU-96.
/main/9      ---      as   1. DFT/HA release
3.1+      st005.301   zr   1. Rolling Upgrade Feature
                           - Modified SmMiShtCntrlCfm routine to check
                             for status
                           - Added logic for checking alarm version
3.1+      st007.301   zr   1. Alarm check for TC-User Distribution feature
                              Modification of some flag defines to make
                              the stuffs  available for TC-User Distribution 
                              feature
3.1+      st011.301   akp  1. Added few lines of packing functions for posting
                              of the message in layer manager demand queue. 
3.1+      st035.301   mkm  1. Addition for SS_MULTIPLE_PROCS flag.
*********************************************************************91*/
