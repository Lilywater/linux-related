/**********************************************************************

        Name:   st_cfg.c - Configuration for the TCAP

        Type:   C source file

        Desc:   C code for the TCAP layer Configuration

        File:   st_cfg.c

        Sid:    st_cfg.c - 10/08/2001

        Created by:     shu.bu

**********************************************************************/
#ifdef CP_OAM_SUPPORT
/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_llist.h"
#include "cm5.h"           /* Common timer */
#include "cm_ss7.h"        /* SS7 Specific */
#include "cm_hash.h"       /* common hash */
#include "cm_err.h"        /* common error */
#include "cm_asn.h"        /* common ASN.1 Encoder/Decoder */
#include "stu.h"           /* Tcap Upper Interface */
#include "spt.h"           /* Tcap Lwer Interface */
#include "lst.h"           /* TCAP layer management Interface */
#if 1
#include "st.h"            /* Tcap */
#include "st_mf.h"         /* Tcap Message functions */
#include "st_db.h"         /* Tcap ASN.1 Database */
#include "st_err.h"        /* Tcap error */
#endif


/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_llist.x"
#include "cm5.x"           /* Common Timer */
#include "cm_ss7.x"        /* common SS7 Specific */
#include "cm_hash.x"       /* common hash */
#include "cm_asn.x"        /* common ASN.1 Encoder/Decoder */
#include "stu.x"           /* Tcap Upper Interface  */
#include "spt.x"           /* Tcap Lower interface */
#include "lst.x"           /* TCAP layer management Interface */
#include "st_mf.x"         /* Tcap Message functions */

#include "st.x"            /* Tcap */

#include "oam_tab_def.h"
#include "xosshell.h"
#include "st_oam.x"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"
#include "cp_tab_def.h"
#include "oam_interface.h"
#include "sm.h"
#include "st_cfg.h"
#include "st_nms.h"
#include "sm.x"
#include "st_bind.h"


extern SmCb gSmCb[ENTLAST + 1];
extern Bool get_stRegisterFlag(void);
#ifdef ZT
extern S16 ztCfg();
#endif

#ifndef SS_MULTIPLE_PROCS
EXTERN  StCb   stCb;       /* TCAP layer control block */
#endif /* SS_MULTIPLE_PROCS */

VOID stDynCfgCallback(unsigned int tableid, unsigned short msgtype, unsigned int sequence, unsigned char pack_end, tb_record *prow)
{
#ifdef CP_OAM_DATA_SHOW
	StCb *lStCb = &stCb;
	U32 i, j;
    CP_SS7_SSN_TAB	*ssn		= NULLP;
    CP_SS7_UP_TAB	*usrPart	= NULLP;
	StTUSap			*sap		= NULLP;
#endif

   if(NULL == prow)
   {
      STLOGERROR(ERRCLS_DEBUG, ESTXXX, 0, "stDynCfgCallback tcap recv null pointer.");
		RETVOID;
   }

   if(gSmCb[ENTST].smStatus != SM_STATUS_TOTAL_NUM)
   {
      STLOGERROR(ERRCLS_DEBUG, ESTXXX, 0, "stDynCfgCallback tcap init configuration do not complete.");
		RETVOID;
   }
   else
   {
      gSmCb[ENTST].smStatus = SM_DYN_STATE;
   }

    if (TRUE == pack_end)
    {
		if (ROK != stRecvDynCfg(SA_UPDATE_MSG, prow))
		{
			RETVOID;         
		}
		/* create sm req msg from subagent data and store it into prority queue*/
		if( RFAILED == stCfgMsg())
		{
			RETVOID;         
		}
		
		/* configure TCAP Psf */
#ifdef ZT
		if( RFAILED == ztCfg())
		{
			RETVOID;                 
		}
#endif
		
		/* send out a config req message to sm*/
		if( ROK != smSendCfgReq(ENTST, SM_DYN_STATE))
		{
			RETVOID;                         
		}
		
		/* wait initial cofiguration finished*/
		ssWaitSema(&gSmCb[ENTST].sema);
		
		/* send response to subagent*/
		if(SM_SUCCESS_STATE ==  gSmCb[ENTST].smStatus)
		{
			/* All the initialization configuration data is processed successfully */
          	prow->head.col_index = OAM_ERRCOL_OK;
          	prow->head.err_no = OAM_RESPONSE_OK;
			opt_response_batch(sequence, OAM_RESPONSE_OK);
		}
		else 
		{
			prow->head.col_index = OAM_ERRCOL_UNKNOWN;
			prow->head.err_no = OAM_RESPONSE_UPDATE_ERROR;
			opt_response_batch(sequence, OAM_RESPONSE_SYNC_ERROR);
		}

		smReset(ENTST);
	}

#ifdef CP_OAM_DATA_SHOW
	/* Print SAP info */
	for (i=0; i<gstCpSs7Global.SSNTabNum; i++)
	{
		if( i >= gstCpSs7Global.SSNTabNum)
	    {
	        continue;
	    }
	    ssn = &gstCpSs7Global.SSNTab[i];
	    if(ssn->SsnUsr != EN_CP_SSNUSR_MAP)
		{
		    printf("TCAP add ssn error, the user of ssn index(%d) is not MAP. Returning...\r\n",ssn->Ssn);
	        continue;		
		}


	    /* find out network table item*/
	    for( j = 0; j < gstCpSs7Global.UPTabNum; j++)
	    {
	        if( gstCpSs7Global.UPTab[j].UpIndex== ssn->UpIndex)
	            break;
	    }
	    
	    if( j == gstCpSs7Global.UPTabNum)
	    {
	        continue;
	    }
	    usrPart = &gstCpSs7Global.UPTab[j];

	    /* find out network table item*/
	    for( j = 0; j< gstCpSs7Global.NwkTabNum; j++)
	    {
	        if( gstCpSs7Global.NwkTab[j].NwId == usrPart->NwId)
	            break;
	    }
	    if( j == gstCpSs7Global.NwkTabNum)
	    {
	        continue;
	    }

		if(ssn->SsnIndex < stCb.genCfg.nmbSaps)
		{
			sap = stCb.tuSapLst[ssn->SsnIndex];
		}
		if (sap == NULLP)
		{
			printf("[TCAP]TUSap: id(%d) > cfgNmb(%d) , or sap is NULLP!\r\n", 
					ssn->SsnIndex, stCb.genCfg.nmbSaps);
			continue;
		}
		printf("\n-------------- TCAP RECONFIGURATION BEGIN ---------------\n\n");
 		printf("[TCAP]TUSapCfg: sap %d\r\n", ssn->SsnIndex);
        if(prow->head.mask[0] & 0x01)
			printf("[TCAP]TUSapCfg: Invoke timer     = %d\r\n", sap->cfg.t1.val);
        if(prow->head.mask[0] & 0x02)
			printf("[TCAP]TUSapCfg: Rejection timer  = %d\r\n", sap->cfg.t2.val);
		printf("\n--------------- TCAP RECONFIGURATION END ----------------\n\n");

	}
#endif /* CP_OAM_DATA_SHOW */

    RETVOID;    
}

unsigned char stInitCfgCallback(U16 msgtype, U32 sequence, U8 pack_end, tb_record* prow)
{
#ifdef CP_OAM_DATA_SHOW
	StCb *lStCb = &stCb;
	U32 i = 0, j = 0;
  CP_SS7_SSN_TAB	*ssn 		= NULLP;
  CP_SS7_UP_TAB	*usrPart	= NULLP;
	StTUSap			*sap		= NULLP;
#endif

  if (TRUE == pack_end)
  {
		if (ROK != stRecvInitCfg(prow))
		{
			opt_response_batch(sequence, OAM_RESPONSE_SYNC_ERROR);
			RETVALUE(RFAILED);         
		}
		/* create sm req msg from subagent data and store it into prority queue*/
		if( RFAILED == stCfgMsg())
		{
			opt_response_batch(sequence, OAM_RESPONSE_SYNC_ERROR);
			RETVALUE(RFAILED);         
		}
		
		/* configure TCAP Psf */
#ifdef ZT
		if( RFAILED == ztCfg())
		{
			opt_response_batch(sequence, OAM_RESPONSE_SYNC_ERROR);
			RETVALUE(RFAILED);                 
		}
#endif
		
		/* send out a config req message to sm*/
		if( ROK != smSendCfgReq(ENTST, SM_INIT_CFG_STATE))
		{
			opt_response_batch(sequence, OAM_RESPONSE_SYNC_ERROR);
			RETVALUE(RFAILED);                         
		}
		
		/* wait initial cofiguration finished*/
		ssWaitSema(&gSmCb[ENTST].sema);
		
		/* send response to subagent*/
		if(SM_SUCCESS_STATE ==  gSmCb[ENTST].smStatus)
		{
			/* All the initialization configuration data is processed successfully */
#ifndef STTST			
			stBndSpReq();             /* TCAP BND SCCP */
#endif
			opt_response_batch(sequence, OAM_RESPONSE_OK);
		}
		else 
		{
			opt_response_batch(sequence, OAM_RESPONSE_SYNC_ERROR);
		}

		smReset(ENTST);
	}

#ifdef CP_OAM_DATA_SHOW
	/* Print SAP info */
	for (i=0; i<gstCpSs7Global.SSNTabNum; i++)
	{
		if( i >= gstCpSs7Global.SSNTabNum)
	    {
	        continue;
	    }
	    ssn = &gstCpSs7Global.SSNTab[i];
	    if(ssn->SsnUsr != EN_CP_SSNUSR_MAP)
		{
		    printf("TCAP add ssn error, the user of ssn index(%d) is not MAP. Returning...\r\n",ssn->Ssn);
	        continue;		
		}


	    /* find out network table item*/
	    for( j = 0; j < gstCpSs7Global.UPTabNum; j++)
	    {
	        if( gstCpSs7Global.UPTab[j].UpIndex== ssn->UpIndex)
	            break;
	    }
	    
	    if( j == gstCpSs7Global.UPTabNum)
	    {
	        continue;
	    }
	    usrPart = &gstCpSs7Global.UPTab[j];

	    /* find out network table item*/
	    for( j = 0; j< gstCpSs7Global.NwkTabNum; j++)
	    {
	        if( gstCpSs7Global.NwkTab[j].NwId == usrPart->NwId)
	            break;
	    }
	    if( j == gstCpSs7Global.NwkTabNum)
	    {
	        continue;
	    }

		if(ssn->SsnIndex < stCb.genCfg.nmbSaps)
		{
			sap = stCb.tuSapLst[ssn->SsnIndex];
		}
		if (sap == NULLP)
		{
			printf("[TCAP]TUSap: id(%d) > cfgNmb(%d) , or sap is NULLP!\r\n", 
					ssn->SsnIndex, stCb.genCfg.nmbSaps);
			continue;
		}
		printf("\n-------------- TCAP CONFIGURATION BEGIN ---------------\n\n");
 		printf("[TCAP]TUSapCfg: sap %d\r\n", ssn->SsnIndex);
 		printf("[TCAP]TUSapCfg: Invoke timer     = %d\r\n", sap->cfg.t1.val);
		printf("[TCAP]TUSapCfg: Rejection timer  = %d\r\n", sap->cfg.t2.val);
		printf("\n--------------- TCAP CONFIGURATION END ----------------\n\n");

	}
#endif /* CP_OAM_DATA_SHOW */

    RETVALUE(ROK);    
}

S16 stRecvDynCfg(U32 msgtype, tb_record* prow)
{
	StGenCfgTab*         pStGenCfg = NULLP;
	
#if 1 /* general config is set here */    
	gStCfgData.TcapGen.OprType = EN_CP_OPR_MOD;
#endif /* general config */
    
    while(prow)    
    {
		switch(prow->tableid)
		{
		case APP_TABLE_ID_SS7_TCAP_GEN:
			{
				pStGenCfg = (StGenCfgTab *) prow->panytbrow;
                if(prow->head.mask[0] & 0x01)
					gStCfgData.TcapGen.T1 = pStGenCfg->invTmr;
                if(prow->head.mask[0] & 0x02)
					gStCfgData.TcapGen.T2 = pStGenCfg->rejTmr;
			}
			break;

		default:
			break;
		}

		prow = prow->next;
	}
	
	RETVALUE(ROK);                                         
}

S16 stRecvInitCfg(tb_record* prow)
{
	CP_OAM_SS7_NETWORK_TAB*	pNetworkTab	= NULLP; /* network table */
	CP_OAM_SS7_UP_TAB*		pUpTab		= NULLP; /* user part table */
	CP_OAM_SS7_SSN_TAB*		pSsnTab		= NULLP; /* ssn table */
	StGenCfgTab*			pStGenCfg	= NULLP; /* general config table */
	S16 ret = ROK;    
	
#if 1 /* general config is set here */    
	gStCfgData.TcapGenNum = 1;
	gStCfgData.TcapGen.NmbSaps = ST_NMB_SAPS;
	gStCfgData.TcapGen.NmbInvs = ST_NMB_INVS;
	gStCfgData.TcapGen.spTmr = ST_LOW_SAP_TMR;
	gStCfgData.TcapGen.TIntTmr = ST_TMR_BND_CFM;
	gStCfgData.TcapGen.ErrCntrlFlg = FALSE;
	gStCfgData.TcapGen.OprType = EN_CP_OPR_MOD;
#endif /* general config */
    
    while(prow)    
    {
		switch(prow->tableid)
		{
		case APP_TABLE_ID_SS7_TCAP_GEN:
			{
				pStGenCfg = (StGenCfgTab *) prow->panytbrow;
				gStCfgData.TcapGen.T1 = pStGenCfg->invTmr;   /* invoke timer set as global var, and not from nms */
				gStCfgData.TcapGen.T2 = pStGenCfg->rejTmr;
			}
			break;
				
			/* get opc config */
		case APP_TABLE_ID_SS7_UP:
			{
				pUpTab	= (CP_OAM_SS7_UP_TAB*) prow->panytbrow;
				ret		= (S16)CpSs7SetOneUpTab(EN_CP_OPR_ADD, pUpTab);
			}
			break;
			
			/* get network config */
		case APP_TABLE_ID_SS7_NWK:
			{
				pNetworkTab	= (CP_OAM_SS7_NETWORK_TAB*)prow->panytbrow;
				ret			= (S16)CpSs7SetOneNwkTab(EN_CP_OPR_ADD, pNetworkTab);
			}
			break;
			
			/* get local ssn config */
		case APP_TABLE_ID_SS7_SSN:
			{
				pSsnTab	= (CP_OAM_SS7_SSN_TAB*)prow->panytbrow;
				ret		= (S16)CpSs7SetOneSsnTab(EN_CP_OPR_ADD, pSsnTab);
			}
			break;
			
		default:
			break;
		}

		prow = prow->next;
	}
	
	RETVALUE(ret);                                         
}


#ifdef ST_OAM_TST
/*
* Fun: OamTestTsk
*
* Desc: Test OAM net management
*
* Ret:   ROK
*
* Notes: none
*
* File: st_nms.c
*
*/
PUBLIC S16 OamTestTsk(Void)
{
	S32 threadId;
	tb_record * prow = NULL;

	threadId = GetCurrentThread();
	printf("OAM thread test, task is %x\n",threadId);

	for(;;)
	{
		if(TRUE == get_stRegisterFlag())
		{
			stInitCfgCallback(APP_SYNC_MSG, 1, 1, prow);
			break;
		}
		else
		{
			Sleep(500);
			continue;
		}
	}

	RETVALUE(ROK);
}/* end of OamTestTsk */


/*
*
*       Fun:    Net Manangement activate task
*
*       Desc:   Processes received event from management Layer
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   st_nms.c
*
*/
#ifdef ANSI
PUBLIC S16 nmsTstActvTsk
(
Pst       *pst,             /* post */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 nmsTstActvTsk(pst, mBuf)
Pst       *pst;             /* post */
Buffer    *mBuf;            /* message buffer */
#endif
{
	RETVALUE(OamTestTsk());
} /* end of nmsActvTsk */

#endif /* ST_OAM_TST */

#endif /* CP_OAM_SUPPORT */
/********************************************************************30**

         End of file: st_cfg.c 1.1  -  10/08/2001

*********************************************************************31*/

/********************************************************************90*

     ver       pat                     description
------------ --------  ----------------------------------------------*/


