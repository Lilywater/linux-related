/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     stack manager - portable tcap interface files.
  
     Type:     C source file
  
     Desc:     C source code for the tcap layer management
               service user primitives used in loosely coupled
               systems.

     File:     smstptmi.c
  
     Sid:      smstptmi.c@@/main/12 - Fri Nov 17 10:33:48 2000
   
     Prg:      ak
  
*********************************************************************21*/
  


/*
   Layer management provides the necessary functions to control and
   monitor the condition of each protocol layer.

   The following functions are provided in this file:

     SmMiLstCfgReq      Configure Request
     SmMiLstCntrlReq    Control Request
     SmMiLstUcfgReq     Unconfigure Request
     SmMiLstStaReq      Status Request
     SmMiLstStsReq      Statistics Request
   
   It is assumed that the following functions are provided in the stack
   management body files:

     SmMiLstCfgCfm      Configuration Confirm
     SmMiLstCntrlCfm    Control Confirm
     SmMiLstStaCfm      Status Confirm
     SmMiLstStsCfm      Statistics Confirm
     SmMiLstStaInd      Status Indication
     SmMiLstTrcInd      Trace Indication
   
*/   

/*
*     This software may be used with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000031     SS7 - TCAP
*
*/



/* header include files (.h) */
  
#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "cm_ss7.h"        /* ss7 layer */
#include "ssi.h"           /* system services */
#include "lst.h"           /* stack management, tcap */
#include "smst_err.h"      /* Stack Manager - TCAP interface - error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"       /* common functions */
#include "lst.x"           /* stack management, tcap */


/* local defines */
 
#define SMSTLOGERROR(errCls, errCode, errVal, errDesc)              \
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,             \
             __FILE__,  __LINE__,                                   \
             (ErrCls)errCls, (ErrVal)errCode, (ErrVal)errVal,       \
             errDesc) 

/* local typedefs */
  
/* local externs */
  
/* forward references */
/* st031.301 - Add - Condition Added to avoid warnings */
/* st033.301 - Modify - Modify condition to avoid compilation errors */
#if (!defined(LCSMSTMILST) || !defined(ST))
PRIVATE S16 PtMiLstCfgReq   ARGS((Pst *pst, StMngmt *cfg ));
PRIVATE S16 PtMiLstCntrlReq ARGS((Pst *pst, StMngmt *cntrl ));
PRIVATE S16 PtMiLstUcfgReq  ARGS((Pst *pst, StMngmt *uCfg ));
PRIVATE S16 PtMiLstStaReq   ARGS((Pst *pst, StMngmt *sta ));
PRIVATE S16 PtMiLstStsReq   ARGS((Pst *pst, Action action, StMngmt *sts ));
#endif

/* public variable declarations */
 
/* private variable declarations */

/*
   The following matrices define the mapping between the primitives called
   by the layer management interface of TCAP and the corresponding primitives
   in TCAP.
 
   The parameter MAXSTMI defines the maximum number of layer manager entities
   on top of TCAP. There is an array of functions per primitive invoked by TCAP.
   Every array is MAXSTMI long (i.e. there are as many functions as the number
   of service users).
 
   The dispatching is performed by the configurable variable: selector.
   The selector is configured during general configuration.
 
   The selectors are:
 
   0 - Loosely coupled - (#define LCSMSTMILST)
   1 - Tightly coupled - (#define ST)
 
*/


/* Configuration request primitive */
 
PRIVATE LstCfgReq SmMiLstCfgReqMt[MAXSTMI] =
{
#ifdef LCSMSTMILST
   cmPkLstCfgReq,        /* 0 - loosely coupled  */
#else
   PtMiLstCfgReq,        /* 0 - tightly coupled, portable */
#endif

#ifdef ST
   StMiLstCfgReq,        /* 1 - tightly coupled, layer management */
#else
   PtMiLstCfgReq,        /* 1 - tightly coupled, portable */
#endif
};


/* UnConfiguration request primitive */
 
PRIVATE LstUcfgReq SmMiLstUcfgReqMt[MAXSTMI] =
{
#ifdef LCSMSTMILST
   cmPkLstUcfgReq,       /* 0 - loosely coupled  */
#else
   PtMiLstUcfgReq,       /* 0 - tightly coupled, portable */
#endif

#ifdef ST
   StMiLstUcfgReq,       /* 1 - tightly coupled, layer management */
#else
   PtMiLstUcfgReq,       /* 1 - tightly coupled, portable */
#endif
};


/* Statistics request primitive */
 
PRIVATE LstStsReq SmMiLstStsReqMt[MAXSTMI] =
{
#ifdef LCSMSTMILST
   cmPkLstStsReq,        /* 0 - loosely coupled */
#else
   PtMiLstStsReq,        /* 0 - tightly coupled, portable */
#endif

#ifdef ST
   StMiLstStsReq,        /* 1 - tightly coupled, layer management */
#else
   PtMiLstStsReq,        /* 1 - tightly coupled, portable */
#endif
};


/* Status request primitive */
 
PRIVATE LstStaReq SmMiLstStaReqMt[MAXSTMI] =
{
#ifdef LCSMSTMILST
   cmPkLstStaReq,        /* 0 - loosely coupled */
#else
   PtMiLstStaReq,        /* 0 - tightly coupled, portable */
#endif

#ifdef ST
   StMiLstStaReq,        /* 1 - tightly coupled, layer management */
#else
   PtMiLstStaReq,        /* 1 - tightly coupled, portable */
#endif
};


/* Control request primitive */
 
PRIVATE LstCntrlReq SmMiLstCntrlReqMt[MAXSTMI] =
{
#ifdef LCSMSTMILST
   cmPkLstCntrlReq,      /* 0 - loosely coupled */
#else
   PtMiLstCntrlReq,      /* 0 - tightly coupled, portable */
#endif

#ifdef ST
   StMiLstCntrlReq,      /* 1 - tightly coupled, layer management */
#else
   PtMiLstCntrlReq,      /* 1 - tightly coupled, portable */
#endif
};


/*
*     layer management interface functions 
*/
 
/*
*
*       Fun:   Configuration request
*
*       Desc:  This function is used to configure TCAP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smstptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLstCfgReq
(
Pst       *pst,           /* post structure */
StMngmt   *cfg            /* configure */
)
#else
PUBLIC S16 SmMiLstCfgReq(pst, cfg)
Pst       *pst;           /* post structure */   
StMngmt   *cfg;           /* configure */
#endif
{
   TRC3(SmMiLstCfgReq)

   /* jump to specific primitive depending on configured selector */

   (*SmMiLstCfgReqMt[pst->selector])(pst, cfg); 

   RETVALUE(ROK);
} /* end of SmMiLstCfgReq */


/*
*
*       Fun:   Unconfiguration request
*
*       Desc:  This function is used to Unconfigure TCAP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smstptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLstUcfgReq
(
Pst       *pst,           /* post structure */
StMngmt   *uCfg           /* unconfigure */
)
#else
PUBLIC S16 SmMiLstUcfgReq(pst, uCfg)
Pst       *pst;           /* post structure */   
StMngmt   *uCfg;          /* unconfigure */
#endif
{
   TRC3(SmMiLstUcfgReq)

   /* jump to specific primitive depending on configured selector */

   (*SmMiLstUcfgReqMt[pst->selector])(pst, uCfg); 

   RETVALUE(ROK);
} /* end of SmMiLstUcfgReq */


/*
*
*       Fun:   Status request
*
*       Desc:  This function is used to send a status request to TCAP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smstptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLstStaReq
(
Pst       *pst,           /* post structure */
StMngmt   *sta            /* status */
)
#else
PUBLIC S16 SmMiLstStaReq(pst, sta)
Pst       *pst;           /* post structure */   
StMngmt   *sta;           /* status */
#endif
{
   TRC3(SmMiLstStaReq)

   /* jump to specific primitive depending on configured selector */

   (*SmMiLstStaReqMt[pst->selector])(pst, sta); 

   RETVALUE(ROK);
} /* end of SmMiLstStaReq */


/*
*
*       Fun:   Statistics request
*
*       Desc:  This function is used to request statistics from TCAP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smstptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLstStsReq
(
Pst       *pst,           /* post structure */
Action     action,
StMngmt   *sts            /* statistics */
)
#else
PUBLIC S16 SmMiLstStsReq(pst, action, sts)
Pst       *pst;           /* post structure */   
Action     action;
StMngmt   *sts;           /* statistics */
#endif
{
   TRC3(SmMiLstStsReq)

   /* jump to specific primitive depending on configured selector */

   (*SmMiLstStsReqMt[pst->selector])(pst, action, sts); 

   RETVALUE(ROK);
} /* end of SmMiLstStsReq */


/*
*
*       Fun:   Control request
*
*       Desc:  This function is used to send control request to TCAP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smstptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 SmMiLstCntrlReq
(
Pst       *pst,           /* post structure */
StMngmt   *cntrl          /* control */
)
#else
PUBLIC S16 SmMiLstCntrlReq(pst, cntrl)
Pst       *pst;           /* post structure */   
StMngmt   *cntrl;         /* control */
#endif
{
   TRC3(SmMiLstCntrlReq)

   /* jump to specific primitive depending on configured selector */

   (*SmMiLstCntrlReqMt[pst->selector])(pst, cntrl); 

   RETVALUE(ROK);
} /* end of SmMiLstCntrlReq */


/* st031.301 - Add - Condition Added to avoid warnings */
/* st033.301 - Modify - Modify condition to avoid compilation errors */
#if (!defined(LCSMSTMILST) || !defined(ST))
/*
*
*       Fun:   Portable configure Request TCAP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smstptmi.c
*
*/
#ifdef ANSI
PRIVATE S16 PtMiLstCfgReq
(
Pst       *pst,             /* post structure */
StMngmt   *cfg              /* configure */
)
#else
PRIVATE S16 PtMiLstCfgReq(pst, cfg)
Pst       *pst;             /* post structure */
StMngmt   *cfg;             /* configure */
#endif
{
  TRC3(PtMiLstCfgReq);

  UNUSED(cfg);

#if (ERRCLASS & ERRCLS_DEBUG)
   SMSTLOGERROR(ERRCLS_DEBUG, ESMST010, ERRZERO, "PtMiLstCfgReq: Failed"); 
#else
   UNUSED(pst);
#endif

  RETVALUE(ROK);
} /* end of PtMiLstCfgReq */


/*
*
*       Fun:   Portable unconfigure Request TCAP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smstptmi.c
*
*/
#ifdef ANSI
PRIVATE S16 PtMiLstUcfgReq
(
Pst       *pst,             /* post structure */
StMngmt   *uCfg             /* configure */
)
#else
PRIVATE S16 PtMiLstUcfgReq(pst, uCfg)
Pst       *pst;             /* post structure */
StMngmt   *uCfg;            /* configure */
#endif
{
  TRC3(PtMiLstUcfgReq);

  UNUSED(uCfg);
#if (ERRCLASS & ERRCLS_DEBUG)
   SMSTLOGERROR(ERRCLS_DEBUG, ESMST011, ERRZERO, "PtMiLstUcfgReq: Failed"); 
#else
   UNUSED(pst);
#endif

  RETVALUE(ROK);
} /* end of PtMiLstUcfgReq */

/*
*
*       Fun:   Portable status Request TCAP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smstptmi.c
*
*/
#ifdef ANSI
PRIVATE S16 PtMiLstStaReq
(
Pst       *pst,             /* post structure */
StMngmt   *sta              /* status */
)
#else
PRIVATE S16 PtMiLstStaReq(pst, sta)
Pst       *pst;             /* post structure */
StMngmt   *sta;             /* status */
#endif
{
  TRC3(PtMiLstStaReq);

  UNUSED(sta);
#if (ERRCLASS & ERRCLS_DEBUG)
   SMSTLOGERROR(ERRCLS_DEBUG, ESMST012, ERRZERO, "PtMiLstStaReq: Failed"); 
#else
   UNUSED(pst);
#endif

  RETVALUE(ROK);
} /* end of PtMiLstStaReq */

/*
*
*       Fun:   Portable statistics Request TCAP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smstptmi.c
*
*/
#ifdef ANSI
PRIVATE S16 PtMiLstStsReq
(
Pst       *pst,             /* post structure */
Action     action,
StMngmt   *sts              /* statistics */
)
#else
PRIVATE S16 PtMiLstStsReq(pst, action, sts)
Pst       *pst;             /* post structure */
Action     action;
StMngmt   *sts;             /* statistics */
#endif
{
  TRC3(PtMiLstStsReq);

  UNUSED(sts);
  UNUSED(action);
#if (ERRCLASS & ERRCLS_DEBUG)
   SMSTLOGERROR(ERRCLS_DEBUG, ESMST013, ERRZERO, "PtMiLstStsReq: Failed"); 
#else
   UNUSED(pst);
#endif

  RETVALUE(ROK);
} /* end of PtMiLstStsReq */

/*
*
*       Fun:   Portable control Request TCAP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smstptmi.c
*
*/
#ifdef ANSI
PRIVATE S16 PtMiLstCntrlReq
(
Pst       *pst,             /* post structure */
StMngmt   *cntrl            /* control */
)
#else
PRIVATE S16 PtMiLstCntrlReq(pst, cntrl)
Pst       *pst;             /* post structure */
StMngmt   *cntrl;           /* control */
#endif
{
  TRC3(PtMiLstCntrlReq);

  UNUSED(cntrl);
#if (ERRCLASS & ERRCLS_DEBUG)
   SMSTLOGERROR(ERRCLS_DEBUG, ESMST014, ERRZERO, "PtMiLstCntrlReq: Failed"); 
#else
   UNUSED(pst);
#endif

  RETVALUE(ROK);
} /* end of PtMiLstCntrlReq */
#endif /* if ((!LCSTMILST) & (!SM)) */

/********************************************************************30**

         End of file:     smstptmi.c@@/main/12 - Fri Nov 17 10:33:48 2000

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  ak    1. initial release
 
1.2          ---  ak    1. fix non-ANSI compile bugs.
 
1.3          ---  ak    1. StsReq and StaReq pack only Header Information.
 
1.4          ---  ak    1. add class packing
 
1.5          ---  fmg   1. removed packing of class
 
1.6          ---  aa    1. replaced cm2.x with cm_ss7.x
 
1.7          ---  fmg   1. removed redundant declarations
 
1.8          ---  aa    1. Changes to remove sError calls 
             ---  aa    2. moved cm_ss7.x before stu.x

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.9          ---      aa   3. Include cm_ss7.h

1.10         ---      nj   1. Reworte the file.

1.11         ---      nj   1. Moved the packing functions from this file to the
                              newly created lst.c file.
/main/12     ---      as   1. DFT/HA release

3.1+      st031.301   yk   1. Condition added to avoid warnings.
3.1+      st033.301   yk   1. Condition modified to avoid compilation error
*********************************************************************91*/
