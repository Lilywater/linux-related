/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     stack manager TCAP extended mos
  
     Type:     C source file
  
     Desc:     Activation point for TCAP Stack Manager and unpacking
               functions.

     File:     smstexms.c
  
     Sid:      smstexms.c@@/main/12 - Fri Nov 17 10:33:46 2000
  
     Prg:      aa
  
*********************************************************************21*/
  
  

/*
  
Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.

*/
  
  

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#ifdef ST_FTHA
#include "sht.h"           /* SHT interface, TCAP */
#endif /* ST_FTHA */
#include "lst.h"           /* stack management, TCAP */
#include "smst_err.h"      /* stack management - TCAP interface - error */  

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */
#include "lst.x"           /* stack management, TCAP */

/* st005.301 - Added - Rolling Upgrade Feature */
#ifdef ST_RUG
#include "sht.x"
#endif /* ST_RUG */

/* local defines */

/* local typedefs */
  
/* local externs */
  
/* forward references */
  
/* functions in other modules */
#ifdef __cplusplus
EXTERN "C" {
#endif

#ifdef ZT
EXTERN S16 smZtActvTsk     ARGS((Pst *pst, Buffer *mBuf));
#endif /* ZT */
  
#ifdef __cplusplus
}
#endif

/* public variable declarations */
  
/* private variable declarations */

  

/*
*     support functions
*/


/*
*
*       Fun:    activate task
*
*       Desc:   Processes received event from TCAP
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   smstexms.c
*
*/
#ifdef ANSI
PUBLIC S16 smStActvTsk
(
Pst      *pst,              /* post structure */
Buffer   *mBuf              /* message buffer */
)
#else
PUBLIC S16 smStActvTsk(pst, mBuf)
Pst      *pst;              /* post structure */
Buffer   *mBuf;             /* message buffer */
#endif
{
   TRC2(smStActvTsk)

   switch(pst->event)
   {

#ifdef LCSMSTMILST

      case EVTLSTSTACFM:             /* Status Confirm */
         cmUnpkLstStaCfm(SmMiLstStaCfm, pst, mBuf);
         break;

      case EVTLSTSTSCFM:             /* Statistics Confirm */
         cmUnpkLstStsCfm(SmMiLstStsCfm, pst, mBuf);
         break;

      case EVTLSTSTAIND:             /* Status Indication */
         cmUnpkLstStaInd(SmMiLstStaInd, pst, mBuf);
         break;

      case EVTLSTTRCIND:             /* Trace Indication */
         cmUnpkLstTrcInd(SmMiLstTrcInd, pst, mBuf);
         break;

#ifdef SMST_LMINT3 
      case EVTLSTCFGCFM:             /* config Confirm */
         cmUnpkLstCfgCfm(SmMiLstCfgCfm, pst, mBuf);
         break;

      case EVTLSTCNTRLCFM:           /* control Confirm */
         cmUnpkLstCntrlCfm(SmMiLstCntrlCfm, pst, mBuf);
         break;

#endif /* SMST_LMINT3 */
#endif /* LCSMSTMILST */

       /* st011.301 -Delete- ifdef ZT section, SHT Control Confirm message
        * can come for conventional TCAP when ST_FTHA is enabled and PSF is
        * absent
        */
#ifdef ST_FTHA
 
      case EVTSHTCNTRLCFM:           /* control Confirm */
/* st005.301 -Added - Rolling Upgrade Feature */
#ifdef ST_RUG
          cmUnpkMiShtCntrlCfm(ShMiShtCntrlCfm, pst, mBuf);
#endif /* ST_RUG */
       break;

#endif /* ST_FTHA */
/* st011.301 -Add- ifdef ZT section */
#ifdef ZT       
      default:
         smZtActvTsk(pst, mBuf);
         break;
#else
      default:

#if (ERRCLASS & ERRCLS_DEBUG)
        SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,                  \
                  __FILE__, __LINE__,                                         \
                  (ErrCls)ERRCLS_DEBUG, (ErrVal)ESMST009, (ErrVal)pst->event, \
                  "smStActvTsk: Failed"); 
#endif
         break;
#endif /* ZT */
   }

   SExitTsk();

   RETVALUE(ROK);
} /* end of smStActvTsk */

  

/********************************************************************30**
  
         End of file:     smstexms.c@@/main/12 - Fri Nov 17 10:33:46 2000

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  ak    1. initial release
 
1.2          ---  ak    1. fix non-ANSI compile bugs.
 
1.3          ---  ak    1. unpack new unsolicited Status structure in
                           UnpkStaInd primitive.
                        2. Unpack Sts fields conditionally based on swtch 
                           value.
 
1.4          ---  aa    1. miscellaneous changes
 
1.5          ---  aa    1. surrounded the ANSI88 intances with ANSI92 as well.
             ---  aa    2. replaced cm2.x with cm_ss7.x
 
1.6          ---  fmg   1. wrapped stUnpkStEvCnt use with #if (ANS..)
 
1.7          ---  aa    1. changed LST_SW_CCITTxx to LST_SW_ITUxx and
                           LST_SW_ANSIxx to LST_SW_ANSxx
1.8          ---  aa    1. Changes to remove sError calls 

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.9          ---      aa   1. Moved cm_ss7.[hx] above lst.[hx]

1.10         ---      nj   1. Rewrote the file.

1.11         ---      nj   1. Added unpacking for new primitives for LMINT3.
                           2. Added changes for STSWFT.
                           3. Added support for ITU-96.

             ---      nj   4. Moved the unpacking functions from this file 
                              to the new file lst.c
/main/12     ---      as   1. DFT/HA release
3.1+      st005.301   zr   1. Case added to call Unpacking routine 
                              for Sht Control Confirm
3.1+      st011.301   akp  1. In smStActTsk routine, the SHT control confirm
                              case is no longer kept under ZT flag 
*********************************************************************91*/
