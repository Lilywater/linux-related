/**********************************************************************

        Name:   st_cfg.c - Configuration for the TCAP

        Type:   C source file

        Desc:   C code for the TCAP layer Configuration

        File:   st_cfg.c

        Sid:    st_cfg.c - 10/08/2001

        Created by:     shu.bu

**********************************************************************/
#ifdef CP_OAM_SUPPORT

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timer */
#include "cm_inet.h"	/* common sockets */

#include "ss_err.h"        /* errors */
#include "ss_dep.h"        /* implementation-specific */
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */
#include "cm_llist.h"
#include "cm_ss7.h"
#include "st.h"
#include "lst.h"

#include "sm.h"


/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* common timer */
#include "cm_lib.x"
#include "cm_inet.x"	/* common sockets */

#include "ss_dep.x"        /* implementation-specific */
#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */
#include "cm_lib.x"       

#include "cm_llist.x"

#include "cm_ss7.x"
#include "sm.x"
#include "lst.x"

#include "xosshell.h"
#include "oam_tab_def.h"
#include "cp_tab_def.h"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"
#include "st_cfg.h"

/* ------------ Extern Function daclarations ---------------*/
EXTERN Void stHdrInit ARGS((Header *hdr));
EXTERN Void smStPstInit ARGS((Pst *smStPst));

/* --------------Public variable declarations----------------------- */


/*---------------Forward Declarations -------------------------------*/

CP_TCAP_CONFIG_DATA    gStCfgData;
CmLListCp gStSmQ[CP_TCAP_CONFIG_Q_TOTAL_NUM];
U32 stCfgTbl[] = {APP_TABLE_ID_SS7_NWK, 
	APP_TABLE_ID_SS7_UP, APP_TABLE_ID_SS7_SSN, APP_TABLE_ID_SS7_TCAP_GEN};

#ifdef ZT
extern S16 ztCfg();
#endif


/*-------------- Local variable declarations ------------------------*/
 
/* Local Declarations */
#ifdef DEBUGP
PRIVATE void stCntrlTsk(Void *par);
#endif /* DEBUGP */
PRIVATE void stStaReqTsk(Void *par);
PRIVATE void stStsReqTsk(Void *par);

U8 stGetSwType( U8 swType)
{
    U8 stSwType;
    
    switch( swType)
    {
        case EN_CP_SW_ANSI88:
            stSwType = LST_SW_ANS88;
            break;
        case EN_CP_SW_ANSI92:
            stSwType = LST_SW_ANS92;
            break;
        case EN_CP_SW_ANSI96:
            stSwType = LST_SW_ANS96;
            break;
       case EN_CP_SW_CHINA:
            stSwType = LST_SW_ITU96;
            break;
       case EN_CP_SW_ITU88:
            stSwType = LST_SW_ITU88;
            break;
       case EN_CP_SW_ITU92:
            stSwType = LST_SW_ITU92;
            break;
 #ifdef SS7_ITU96
      case EN_CP_SW_ITU96:
            stSwType = LST_SW_ITU96;
            break;
#endif            
      default:
            stSwType = LST_SW_ITU96;                   
    }
    return stSwType;
}

/* 
 * Function name: stGenCfg
 * Des:		      General Configure for TCAP
 * Return Value : ROK or RFAILED
 */
S16 stGenCfg(Void)
{
    CmLList *node;
    CP_TCAP_GEN_TAB *tcapGen;
    StMngmt *stMngmt;
        
    TRC2(stGenCfg);        

    
    /* if the general config data haven't received, return failure*/
    if( gStCfgData.TcapGenNum != 1)
    {
        RETVALUE(RFAILED);
    }

    
    /* get all data for config*/
    tcapGen = &gStCfgData.TcapGen;

    /* alloc a node for saving sm msg info */
    if( ROK != smGetQNode(&node, sizeof(StMngmt)))
    {
        RETVALUE(RFAILED);
    }

    stMngmt = (StMngmt *)cmLListNode(node) ;
    stMngmt->hdr.msgLen = sizeof( StMngmt);
    
    /* if the general config data type is not modified, return failure*/
    if( tcapGen->OprType != EN_CP_OPR_MOD)
    {
        smPutQNode(node, sizeof(StMngmt));
        RETVALUE(RFAILED);
    }

    stHdrInit(&stMngmt->hdr);
	
    stMngmt->hdr.msgType = TCFG;                 /* configuration */
    stMngmt->hdr.elmId.elmnt = STGEN;            /* general */

#ifdef LCSTMILST
    stMngmt->t.cfg.s.genCfg.smPst.selector = ST_SEL_LC;
#else
    stMngmt->t.cfg.s.genCfg.smPst.selector = ST_SEL_TC;
#endif

    stMngmt->t.cfg.s.genCfg.smPst.region = ST_REG;       /* region */
    stMngmt->t.cfg.s.genCfg.smPst.pool = ST_POOL;           /* pool */
    stMngmt->t.cfg.s.genCfg.smPst.prior = PRIOR1;                  /* priority */
    stMngmt->t.cfg.s.genCfg.smPst.route = RTESPEC;                  /* route */
    stMngmt->t.cfg.s.genCfg.smPst.dstProcId = SFndProcId();   /* destination processor id */
    stMngmt->t.cfg.s.genCfg.smPst.dstEnt = ENTSM;             /* dst entity   (always ENTST) */
    stMngmt->t.cfg.s.genCfg.smPst.dstInst = SM_INST;         /* dst instance (unused) */
    stMngmt->t.cfg.s.genCfg.smPst.srcProcId = SFndProcId();   /* source processor id */
    stMngmt->t.cfg.s.genCfg.smPst.srcEnt = ENTST;            /* source entity */
    stMngmt->t.cfg.s.genCfg.smPst.srcInst = ST_INST_0;         /* src instance (unused) */

    /* to support set initial value instead of arg:gen or the structure of
    gen difference of cfg.t.cfg.s.genCfg, set value one by one */

    /* configure general configuration */
    stMngmt->t.cfg.s.genCfg.nmbSaps = tcapGen->NmbSaps;		/* number of saps */    
    stMngmt->t.cfg.s.genCfg.nmbDlgs = ST_NMB_DLGS;		/* number of dlg - sys wide */
    stMngmt->t.cfg.s.genCfg.nmbInvs = ST_NMB_INVS;		/* number of opr - sys wide */
    stMngmt->t.cfg.s.genCfg.timeRes = ST_TIME_RES;		/* timer resolution */
    stMngmt->t.cfg.s.genCfg.sapTimeRes = ST_SAP_TIME_RES;	/* timer resolution */
    stMngmt->t.cfg.s.genCfg.nmbBins = ST_NMB_BINS;		/* no. of bins - sys wide */
    stMngmt->t.cfg.s.genCfg.loDlgId = ST_LO_DLG_ID;
    stMngmt->t.cfg.s.genCfg.hiDlgId = ST_HI_DLG_ID;
    stMngmt->t.cfg.s.genCfg.bitMapFlg = ST_BIT_MAP_FLAG;
    stMngmt->t.cfg.s.genCfg.errCntrlFlg = tcapGen->ErrCntrlFlg;

    cmLListAdd2Tail(&gStSmQ[CP_TCAP_GEN_Q], node);

    RETVALUE(ROK);
}

/* 
 * Function name: stTUSapDynCfg
 * Des:		      TCAP USER SAP Configure for TCAP layer
 * Return Value : ROK or RFAILED
 */
S16 stTUSapDynCfg(U16 nRec)
{
    CmLList			*node 		= NULLP;		/* node */
    StMngmt			*stMngmt 	= NULLP;		/* management */
    StTUSapCfg		*tuSapCfg 	= NULLP;		/* tu sap config */
    CP_SS7_SSN_TAB	*ssn 		= NULLP;		/* ssn */
    CP_SS7_UP_TAB	*usrPart 	= NULLP;		/* user part table */
    CP_SS7_NETWORK_TAB	*network 	= NULLP;	/* network table */
    CP_TCAP_GEN_TAB		*tcapGen 	= NULLP;	/* general config struct */
    U16 i = 0;
    
    TRC2(stTUSapDynCfg);        
    
    /* get all data for config*/
    if( nRec >= gstCpSs7Global.SSNTabNum)
    {
        RETVALUE(LST_REASON_INVALID_NMBSAPS);
    }
    ssn = &gstCpSs7Global.SSNTab[nRec];
    if(ssn->SsnUsr != EN_CP_SSNUSR_MAP)
	{
	    printf("TCAP add ssn error, the user of ssn index(%d) is not MAP. Returning...\r\n",ssn->Ssn);
        RETVALUE(ROK);		
	}


    /* find out network table item*/
    for( i = 0; i < gstCpSs7Global.UPTabNum; i++)
    {
        if( gstCpSs7Global.UPTab[i].UpIndex== ssn->UpIndex)
            break;
    }
    
    if( i == gstCpSs7Global.UPTabNum)
    {
        RETVALUE(LST_REASON_INVALID_NMBSAPS);
    }
    usrPart = &gstCpSs7Global.UPTab[i];

    /* find out network table item*/
    for( i = 0; i < gstCpSs7Global.NwkTabNum; i++)
    {
        if( gstCpSs7Global.NwkTab[i].NwId == usrPart->NwId)
            break;
    }
    if( i == gstCpSs7Global.NwkTabNum)
    {
        RETVALUE(RFAILED);
    }
    network = &gstCpSs7Global.NwkTab[i];
    tcapGen = &gStCfgData.TcapGen;
    
    /* alloc a node for save sm msg info */
    if( ROK != smGetQNode(&node, sizeof(StMngmt)))
    {
        RETVALUE(LCM_REASON_MEM_NOAVAIL);
    }

    stMngmt = (StMngmt *)cmLListNode(node) ;
    stMngmt->hdr.msgLen = sizeof( StMngmt);

    stHdrInit(&stMngmt->hdr);
    stMngmt->hdr.msgType = TCFG;                 /* configuration */
    stMngmt->hdr.elmId.elmnt = STTCUSAP;			/* TU user sap */
    stMngmt->hdr.elmId.elmntInst1 = ssn->SsnIndex;	
    tuSapCfg = &stMngmt->t.cfg.s.tuSapCfg;

    tuSapCfg->t1.enb = tcapGen->T1?TRUE:FALSE;
    tuSapCfg->t1.val = tcapGen->T1;
    tuSapCfg->t2.enb = tcapGen->T2?TRUE:FALSE;
    tuSapCfg->t2.val = tcapGen->T2;

    cmLListAdd2Tail(&gStSmQ[CP_TCAP_SAP_Q], node);

    RETVALUE(ROK);
}


S16 stAddSsn(U16 nRec)
{
    CmLList			*node 		= NULLP;		/* node */
    StMngmt			*stMngmt 	= NULLP;		/* management */
    StSPSapCfg		*spSapCfg 	= NULLP;		/* sp sap config */
    StTUSapCfg		*tuSapCfg 	= NULLP;		/* tu sap config */
    CP_SS7_SSN_TAB	*ssn 		= NULLP;		/* ssn */
    CP_SS7_UP_TAB	*usrPart 	= NULLP;		/* user part table */
    CP_SS7_NETWORK_TAB	*network 	= NULLP;	/* network table */
    CP_TCAP_GEN_TAB		*tcapGen 	= NULLP;	/* general config struct */
    U16 i = 0;
    
    TRC2(stAddSsn);        
    
    /* get all data for config*/
    if( nRec >= gstCpSs7Global.SSNTabNum)
    {
        RETVALUE(LST_REASON_INVALID_NMBSAPS);
    }
    ssn = &gstCpSs7Global.SSNTab[nRec];
    if(ssn->SsnUsr != EN_CP_SSNUSR_MAP)
	{
	    printf("TCAP add ssn error, the user of ssn index(%d) is not MAP. Returning...\r\n",ssn->Ssn);
#if 0 /* xingzhou.xu: deletion for the others may use it --2006/06/14 */
        RETVALUE(LMA_REASON_EXC_SSN_NUM);
#endif
        RETVALUE(ROK);		
	}


    /* find out network table item*/
    for( i = 0; i < gstCpSs7Global.UPTabNum; i++)
    {
        if( gstCpSs7Global.UPTab[i].UpIndex== ssn->UpIndex)
            break;
    }
    
    if( i == gstCpSs7Global.UPTabNum)
    {
        RETVALUE(LST_REASON_INVALID_NMBSAPS);
    }
    usrPart = &gstCpSs7Global.UPTab[i];

    /* find out network table item*/
    for( i = 0; i < gstCpSs7Global.NwkTabNum; i++)
    {
        if( gstCpSs7Global.NwkTab[i].NwId == usrPart->NwId)
            break;
    }
    if( i == gstCpSs7Global.NwkTabNum)
    {
        RETVALUE(RFAILED);
    }
    network = &gstCpSs7Global.NwkTab[i];
    tcapGen = &gStCfgData.TcapGen;

    /* alloc a node for save sm msg info */
    if( ROK != smGetQNode(&node, sizeof(StMngmt)))
    {
        RETVALUE(LCM_REASON_MEM_NOAVAIL);
    }

    stMngmt = (StMngmt *)cmLListNode(node) ;
    stMngmt->hdr.msgLen = sizeof( StMngmt);

    stHdrInit(&stMngmt->hdr);
	
    stMngmt->hdr.msgType = TCFG;                 /* configuration */
    stMngmt->hdr.elmId.elmnt = STSPSAP;			/* lower sap */
    stMngmt->hdr.elmId.elmntInst1 = ssn->SsnIndex;	
    spSapCfg = &stMngmt->t.cfg.s.spSapCfg;

    spSapCfg->swtch = stGetSwType(network->SwType);

    /* update the lower interface parameters */
    /* for TCAP user like MAP, CAP, tight coupling always used */
#ifdef LCSTLISPT	
    spSapCfg->spSel = ST_SEL_LC;	/* loosely coupled */
#elif (defined(SP))
    spSapCfg->spSel = ST_SEL_SP;	/* tightly coupled */
#elif (defined(SU))
    spSapCfg->spSel = ST_SEL_SU;	/* tightly coupled */
#endif

    spSapCfg->spMemId.region = ST_REG;	/* defualt region */
    spSapCfg->spMemId.pool = ST_POOL;	/* defualt pool */
    spSapCfg->spPrior = PRIOR2;			/* defualt priority */

/* Arthur Yin chaged it April 26th, 2004
  * for TCAP, it will not use the SCCP ULDF for the current moment
  * so we use the route is RET_PROTO. this may be deliberated later
  */
#if defined( FTHA)
    spSapCfg->spRoute = RTE_PROTO;
#elif defined(DFTHA)
    spSapCfg->spRoute = RTE_PROTO;
#else
    spSapCfg->spRoute = RTE_PROTO;
#endif    
    spSapCfg->spProcId = SFndProcId();
    spSapCfg->spEnt = ENTSP;
    spSapCfg->spInst = SP_INST_0;		             
    spSapCfg->spId = ssn->SsnIndex;			/* lower sap Id */
    spSapCfg->spTmr = tcapGen->spTmr;	       /* TCAP Timer */
    spSapCfg->ssn = (U8)ssn->Ssn; 	/* mdf by leon.teng on 2003-12-9 */
 
#ifdef SPT2
    spSapCfg->tIntTmr.enb = tcapGen->TIntTmr?TRUE:FALSE;	/* Bind Confirm Timer */
    spSapCfg->tIntTmr.val = tcapGen->TIntTmr;
#endif /* SPT2 */

    cmLListAdd2Tail(&gStSmQ[CP_TCAP_SAP_Q], node);

    /* alloc a node for save sm msg info */
    if( ROK != smGetQNode(&node, sizeof(StMngmt)))
    {
        RETVALUE(LCM_REASON_MEM_NOAVAIL);
    }

    stMngmt = (StMngmt *)cmLListNode(node) ;
    stMngmt->hdr.msgLen = sizeof( StMngmt);

    stHdrInit(&stMngmt->hdr);
    stMngmt->hdr.msgType = TCFG;                 /* configuration */
    stMngmt->hdr.elmId.elmnt = STTCUSAP;			/* TU user sap */
    stMngmt->hdr.elmId.elmntInst1 = ssn->SsnIndex;	
    tuSapCfg = &stMngmt->t.cfg.s.tuSapCfg;

   /* update the upper interface parameters */
#ifdef LCSTUISTU   
   tuSapCfg->tuSel = ST_SEL_LC;	/* loosely coupled */
#elif (defined(TU))
   tuSapCfg->tuSel = ST_SEL_TU;	/* tightly coupled */
#elif (defined(MA))
   tuSapCfg->tuSel = ST_SEL_MA;	/* tightly coupled */
#elif (defined(IA))
   tuSapCfg->tuSel = ST_SEL_IA;	/* tightly coupled */
#elif (defined(IE))
   tuSapCfg->tuSel = ST_SEL_IE;	/* tightly coupled */
#elif (defined(QC))
   tuSapCfg->tuSel = ST_SEL_QC;	/* tightly coupled */
#elif (defined(DSTU))
   tuSapCfg->tuSel = ST_SEL_DSTU;	/* tightly coupled */
#elif (defined(DSDT))
   tuSapCfg->tuSel = ST_SEL_DSDT;	/* tightly coupled */
#endif

    tuSapCfg->tuMemId.region = ST_REG;	/* defualt region */
    tuSapCfg->tuMemId.pool = ST_POOL;	/* defualt pool */
    tuSapCfg->tuPrior = PRIOR2;			/* defualt priority */
    tuSapCfg->tuRoute = RTESPEC;			/* default route */

    tuSapCfg->swtch = stGetSwType(network->SwType);
    tuSapCfg->t1.enb = tcapGen->T1?TRUE:FALSE;
    tuSapCfg->t1.val = tcapGen->T1*ST_TIME_RES/ST_TIME_RES;
    tuSapCfg->t2.enb = tcapGen->T2?TRUE:FALSE;
    tuSapCfg->t2.val = tcapGen->T2*ST_TIME_RES/ST_TIME_RES;
    tuSapCfg->loDlgId = ST_LO_DLG_ID;
    tuSapCfg->hiDlgId = ST_HI_DLG_ID;
    tuSapCfg->nmbDlgs = ST_SAP_DLGS;
    tuSapCfg->nmbInvs = ST_SAP_INVS;
    tuSapCfg->nmbBins = ST_NMB_BINS;

    cmLListAdd2Tail(&gStSmQ[CP_TCAP_SAP_Q], node);

    RETVALUE(ROK);
}/* end of stAddSsn */

S16 stDelSsn(U16 nRec)
{
	RETVALUE(RFAILED);
}

S16 stModSsn(U16 nRec)
{
	RETVALUE(RFAILED);
}

/* 
 * Function name: stGenCfg
 * Des:		      General Configure for TCAP
 * Return Value : ROK or RFAILED
 */
S16 stGenStsReq(U16 nRec)
{
    CmLList *node;
    CP_TCAP_GEN_STS_TAB *tcapGenSts;
    StMngmt *stMngmt;
        
    TRC2(stGenStsReq);        

    UNUSED(nRec);
    
    /* if the sccp general config data do not receive, return failure*/
    if( gStCfgData.TcapGenStsNum != 1)
    {
        RETVALUE(RFAILED);
    }

    
    /* get all data for config*/
    tcapGenSts = &gStCfgData.TcapGenSts[nRec];

    /* alloc a node for save sm msg info */
    if( ROK != smGetQNode(&node, sizeof(StMngmt)))
    {
        RETVALUE(LCM_REASON_MEM_NOAVAIL);
    }

    stMngmt = (StMngmt *)cmLListNode(node) ;
    stMngmt->hdr.msgLen = sizeof( StMngmt);
    
    /* if the tcap general config data type is not modify, return failure*/
    if( tcapGenSts->OprType != EN_CP_OPR_GET)
    {
        smPutQNode(node, sizeof(StMngmt));
        RETVALUE(RFAILED);
    }

    stHdrInit(&stMngmt->hdr);
	
    stMngmt->hdr.msgType = TSTS;                 /* configuration */
    stMngmt->hdr.elmId.elmnt = STGEN;            /* general */
    stMngmt->hdr.elmId.elmntInst1 = CP_TCAP_STS_GEN;		     /* meaningless */

    cmLListAdd2Tail(&gStSmQ[CP_TCAP_STS_Q], node);

    RETVALUE(ROK);
}

S16 stAbtStsReq(U16 nRec)
{
    CmLList *node;
    CP_TCAP_ABORT_STS_TAB *tcapAbtSts;
    StMngmt *stMngmt;
        
    TRC2(stAbtStsReq);        

    UNUSED(nRec);
    
    /* if the sccp general config data do not receive, return failure*/
    if( gStCfgData.TcapAbortStsNum != 1)
    {
        RETVALUE(RFAILED);
    }

    
    /* get all data for config*/
    tcapAbtSts = &gStCfgData.TcapAbortSts[nRec];

    /* alloc a node for save sm msg info */
    if( ROK != smGetQNode(&node, sizeof(StMngmt)))
    {
        RETVALUE(LCM_REASON_MEM_NOAVAIL);
    }

    stMngmt = (StMngmt *)cmLListNode(node) ;
    stMngmt->hdr.msgLen = sizeof( StMngmt);
    
    /* if the sccp general config data type is not modify, return failure*/
    if( tcapAbtSts->OprType != EN_CP_OPR_GET)
    {
        smPutQNode(node, sizeof(StMngmt));
        RETVALUE(RFAILED);
    }

    stHdrInit(&stMngmt->hdr);
	
    stMngmt->hdr.msgType = TSTS;                 /* configuration */
    stMngmt->hdr.elmId.elmnt = STGEN;            /* general */
    stMngmt->hdr.elmId.elmntInst1 = CP_TCAP_STS_ABT;		     /* meaningless */

    cmLListAdd2Tail(&gStSmQ[CP_TCAP_STS_Q], node);

    RETVALUE(ROK);
}

S16 stRejStsReq(U16 nRec)
{
    CmLList *node;
    CP_TCAP_REJ_STS_TAB *tcapRejSts;
    StMngmt *stMngmt;
        
    TRC2(stRejStsReq);        

    UNUSED(nRec);
    
    /* if the sccp general config data do not receive, return failure*/
    if( gStCfgData.TcapRejStsNum != 1)
    {
        RETVALUE(RFAILED);
    }

    
    /* get all data for config*/
    tcapRejSts = &gStCfgData.TcapRejSts[nRec];

    /* alloc a node for save sm msg info */
    if( ROK != smGetQNode(&node, sizeof(StMngmt)))
    {
        RETVALUE(LCM_REASON_MEM_NOAVAIL);
    }

    stMngmt = (StMngmt *)cmLListNode(node) ;
    stMngmt->hdr.msgLen = sizeof( StMngmt);
    
    /* if the sccp general config data type is not modify, return failure*/
    if( tcapRejSts->OprType != EN_CP_OPR_GET)
    {
        smPutQNode(node, sizeof(StMngmt));
        RETVALUE(RFAILED);
    }

    stHdrInit(&stMngmt->hdr);
	
    stMngmt->hdr.msgType = TSTS;                 /* configuration */
    stMngmt->hdr.elmId.elmnt = STGEN;            /* general */
    stMngmt->hdr.elmId.elmntInst1 = CP_TCAP_STS_REJ;		     /* meaningless */

    cmLListAdd2Tail(&gStSmQ[CP_TCAP_STS_Q], node);

    RETVALUE(ROK);
}

Void stSmFillGenSts(CP_TCAP_GEN_STS_TAB *outSts, StSapSts *srcSts)
{
   
	/* Copy the resource usage information */
	outSts->actTrns = srcSts->actTrns;
	outSts->actInv  = srcSts->actInv;
	outSts->usedTrns = srcSts->usedTrns;
	outSts->usedInv  = srcSts->usedInv;

	outSts->uniTx = srcSts->uniTx;
	outSts->abtTx = srcSts->abtTx;

	/* The following three counters are maintained for ITU only */
	outSts->bgnTx = srcSts->bgnTx;
	outSts->cntTx = srcSts->cntTx;
	outSts->endTx = srcSts->endTx;

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
	/* The following five counters are maintained for ANSI only */
	outSts->qwpTx = srcSts->qwpTx;
	outSts->qnpTx = srcSts->qnpTx;
	outSts->cwpTx = srcSts->cwpTx;
	outSts->cnpTx = srcSts->cnpTx;
	outSts->rspTx = srcSts->rspTx;
#else
	outSts->qwpTx = outSts->qnpTx = 0;
	outSts->cwpTx = outSts->cnpTx = 0;
	outSts->rspTx = 0;
#endif

	/* Message Rx Statistics */

	/* The following three counters are maintained for both ITU and ANSI */
	outSts->uniRx = srcSts->uniRx;
	outSts->abtRx = srcSts->abtRx;

	/* The following three counters are maintained for ITU only */
	outSts->bgnRx = srcSts->bgnRx;
	outSts->cntRx = srcSts->cntRx;
	outSts->endRx = srcSts->endRx;

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
	/* The following five counters are maintained for ANSI only */
	outSts->qwpRx = srcSts->qwpRx;
	outSts->qnpRx = srcSts->qnpRx;
	outSts->cwpRx = srcSts->cwpRx;
	outSts->cnpRx = srcSts->cnpRx;
	outSts->rspRx = srcSts->rspRx;
#else
	outSts->qwpRx = outSts->qnpRx = 0;
	outSts->cwpRx = outSts->cnpRx = 0;
	outSts->rspRx = 0;
#endif

	/* Component Tx Statistics */

	/* The following five counters are maintained for both ITU and ANSI */
	outSts->invTx = srcSts->invTx;
	outSts->resTx = srcSts->resTx;
	outSts->errTx = srcSts->errTx;
	outSts->rejTx = srcSts->rejTx;

	/* Component Rx Statistics */

	/* The following five counters are maintained for both ITU and ANSI */

	outSts->invRx = srcSts->invRx;
	outSts->resRx = srcSts->resRx;
	outSts->errRx = srcSts->errRx;
	outSts->rejRx = srcSts->rejRx;

			
}

Void stSmFillAbtSts(CP_TCAP_ABORT_STS_TAB *outSts, StSapSts *srcSts)
{
   outSts->abtRx = srcSts->abtRx;
   outSts->abtTx = srcSts->abtTx;

/* Protocol error detected in Transaction portion - with P-abort cause */
/* The following five counters are maintained for both ITU and ANSI */
   outSts->urMsgRx = srcSts->urMsgRx.cnt;
   outSts->inTrnRx = srcSts->inTrnRx.cnt;
   outSts->bdTrnRx = srcSts->bdTrnRx.cnt;
   outSts->urTidRx = srcSts->urTidRx.cnt;
   outSts->rsrcLRx = srcSts->rsrcLRx.cnt;


/* The following five counters are maintained for both ITU and ANSI */
   outSts->urMsgTx = srcSts->urMsgTx.cnt;
   outSts->inTrnTx = srcSts->inTrnTx.cnt;
   outSts->bdTrnTx = srcSts->bdTrnTx.cnt;
   outSts->urTidTx = srcSts->urTidTx.cnt;
   outSts->rsrcLTx = srcSts->rsrcLTx.cnt;

}

Void stSmFillRejSts(CP_TCAP_REJ_STS_TAB *outSts, StSapSts *srcSts)
{
   
   outSts->rejRx = srcSts->rejRx;
   outSts->rejTx = srcSts->rejTx;

/* Protocol error detected in conponent portion - with problem code */

/* ALL The following counters are maintained for both ITU and ANSI */
   outSts->urCmpRx = srcSts->urCmpRx.cnt;
   outSts->inCmpRx = srcSts->inCmpRx.cnt;
   outSts->bdCmpRx = srcSts->bdCmpRx.cnt;
   outSts->urLidRx = srcSts->urLidRx.cnt;
   outSts->urIidRRRx = srcSts->urIidRRRx.cnt;
   outSts->uxResRx = srcSts->uxResRx.cnt;
   outSts->urIidRERx = srcSts->urIidRERx.cnt;
   outSts->uxErrRx = srcSts->uxErrRx.cnt;


/* TC User generated problems */

   outSts->dupIdRx = srcSts->dupIdRx.cnt;
   outSts->urOprRx = srcSts->urOprRx.cnt;
   outSts->inPrmINRx = srcSts->inPrmINRx.cnt;
   outSts->rsrcInvRx = srcSts->rsrcInvRx.cnt;
   outSts->rlsInvRx = srcSts->rlsInvRx.cnt;
   outSts->uxLrspRx = srcSts->uxLrspRx.cnt;
   outSts->uxLoprRx = srcSts->uxLoprRx.cnt;
   outSts->inPrmRRRx = srcSts->inPrmRRRx.cnt;
   outSts->urErrRx = srcSts->urErrRx.cnt;
   outSts->uxEcdRx = srcSts->uxEcdRx.cnt;
   outSts->inPrmRERx = srcSts->inPrmRERx.cnt;

/* Protocol error detected in Transaction portion - with P-abort cause */

/* Protocol error detected in conponent portion - with problem code */

/* ALL The following counters are maintained for both ITU and ANSI */
   outSts->urCmpTx = srcSts->urCmpTx.cnt;
   outSts->inCmpTx = srcSts->inCmpTx.cnt;
   outSts->bdCmpTx = srcSts->bdCmpTx.cnt;
   outSts->urLidTx = srcSts->urLidTx.cnt;
   outSts->urIidRRTx = srcSts->urIidRRTx.cnt;
   outSts->uxResTx = srcSts->uxResTx.cnt;
   outSts->urIidRETx = srcSts->urIidRETx.cnt;
   outSts->uxErrTx = srcSts->uxErrTx.cnt;

/* TC User generated problems */

   outSts->dupIdTx = srcSts->dupIdTx.cnt;
   outSts->urOprTx = srcSts->urOprTx.cnt;
   outSts->inPrmINTx = srcSts->inPrmINTx.cnt;
   outSts->rsrcInvTx = srcSts->rsrcInvTx.cnt;
   outSts->rlsInvTx = srcSts->rlsInvTx.cnt;
   outSts->uxLrspTx = srcSts->uxLrspTx.cnt;
   outSts->uxLoprTx = srcSts->uxLoprTx.cnt;
   outSts->inPrmRRTx = srcSts->inPrmRRTx.cnt;
   outSts->urErrTx = srcSts->urErrTx.cnt;
   outSts->uxEcdTx = srcSts->uxEcdTx.cnt;
   outSts->inPrmRETx = srcSts->inPrmRETx.cnt;

}

void  smStStsCfm(Pst *pst, StMngmt *sts)
{
   U16 itemNum=0;

   TRC2(smStStsCfm);

   if(sts->hdr.elmId.elmnt == STGEN)
   {
   		switch(sts->hdr.elmId.elmntInst1)
   		{
			case CP_TCAP_STS_GEN:
				stSmFillGenSts(&gStCfgData.TcapGenSts[itemNum], &sts->t.sts.sapSts);
				break;
			case CP_TCAP_STS_ABT:
				stSmFillAbtSts(&gStCfgData.TcapAbortSts[itemNum], &sts->t.sts.sapSts);
				break;
			case CP_TCAP_STS_REJ:
				stSmFillRejSts(&gStCfgData.TcapRejSts[itemNum], &sts->t.sts.sapSts);
				break;

   		}
   }
}

/********************************************************************************************************
  Function: cpTcapCfgMsg() 
  Description: sccp cfg task entry
  Calls:
  Called By: 
  Input:    
               
  Output:  

  
  Return:   ROK:success; 
                RFAILED: failure
  Others:
 ********************************************************************************************************/
S16 stCfgMsg(void)
{
    S16 ret = ROK;
    U16 i;

    TRC2(stCfgMsg);

    /* static config data only be done in config start phase, and it would not change after system started*/
    if( gSmCb[ENTST].smStatus == SM_INIT_CFG_STATE)
    {
        ret = stGenCfg();
        if( ROK != ret)
        {
            RETVALUE(ret);
        }
        /* create tsap config msg */
        for( i = 0; i < gstCpSs7Global.SSNTabNum; i++)
        {
            ret = stAddSsn(i);
            if( ROK != ret)
            {
                RETVALUE(ret);
            }            
        }
    }
	else if( gSmCb[ENTST].smStatus == SM_DYN_STATE) /* Dynamic config */
	{
		/* dynamic config */
        /* create tsap config msg */
        for( i = 0; i < gstCpSs7Global.SSNTabNum; i++)
        {
            ret = stTUSapDynCfg(i);
            if( ROK != ret)
            {
                RETVALUE(ret);
            }            
        }
		
	}
	else
	{
		/* statistics request */
	    for( i = 0; i < gStCfgData.TcapGenStsNum; i++)
	    {
            ret = stGenStsReq(i);
	        if( ROK != ret)
	        {
		     /* better print something */
	            continue;
	        }
	    }
	    for( i = 0; i < gStCfgData.TcapAbortStsNum; i++)
	    {
            ret = stAbtStsReq(i);
	        if( ROK != ret)
	        {
		     /* better print something */
	            continue;
	        }
	    }
	    for( i = 0; i < gStCfgData.TcapRejStsNum; i++)
	    {
            ret = stRejStsReq(i);
	        if( ROK != ret)
	        {
		     /* better print something */
	            continue;
	        }
	    }
	}
    RETVALUE(ROK); 
}

void stInitCfgData(void)
{

    TRC2(stInitCfgData);

    cmMemset((U8 *)&gStCfgData, 0, sizeof(CP_TCAP_CONFIG_DATA));
	
    gStCfgData.TcapGenNum = 0;
    gStCfgData.TcapGenStsNum = 0;
    gStCfgData.TcapAbortStsNum = 0;
    gStCfgData.TcapRejStsNum = 0;
	gSmCb[ENTST].smStatus = SM_INIT_CFG_STATE;
   
}

void stResetCfgData(void)
{
    U16 i;
    
    TRC2(stResetCfgData);      
    
    for( i = 0; i < gStCfgData.TcapGenNum; i++)
    {
        gStCfgData.TcapGen.OprType = EN_CP_OPR_INVALID;
    }
	
    for( i = 0; i < gStCfgData.TcapGenStsNum; i++)
    {
        gStCfgData.TcapGenSts[i].OprType = EN_CP_OPR_INVALID;
    }
	
    for( i = 0; i < gStCfgData.TcapAbortStsNum; i++)
    {
        gStCfgData.TcapAbortSts[i].OprType = EN_CP_OPR_INVALID;
    }
	
    for( i = 0; i < gStCfgData.TcapRejStsNum; i++)
    {
        gStCfgData.TcapRejSts[i].OprType = EN_CP_OPR_INVALID;
    }
	
    gStCfgData.TcapGenStsNum = 0;
    gStCfgData.TcapAbortStsNum = 0;
    gStCfgData.TcapRejStsNum = 0;    
}


/********************************************************************************************************
  Function: stCfgTsk() 
  Description: tcap cfg task entry
  Calls:
  Called By: 
  Input:    
               
  Output:  

  
  Return:   ROK:success; 
                RFAILED: failure
  Others:
 ********************************************************************************************************/
#if 0
S16 stCfgTsk()
{

     mml_node_t *current;
   
     TRC2(stCfgTsk);      
	 
    current = xClTtyReg(NULL, "TCAP", NULL);
    xClTtyReg(current,(char *)"setStTrc", stTraceSet);
    xClTtyReg(current,(char *)"stGetsta", stGetSta);
    xClTtyReg(current,(char *)"stGetsts", stGetSts);
    xClTtyReg(current,(char *)"stCntrl", stCtrl);
#ifdef DEBUGP
    xClTtyReg(current,(char *)"setStDbg", stSetDbgp);
#endif
#ifndef CP_NMS
/* added by Bruce for Resource Bulk Release 2004/12/22 begin*/
    xClTtyReg(current,(char *)"stDlgShow", stDlgShow);
#endif
    xClTtyReg(current,(char *)"stGetSapStat", stGetSapStat);


     stInitCfgData();
     if( ROK != cpSmRegCb((Ent)ENTST,  gStSmQ, sizeof(gStSmQ)/sizeof(CmLListCp), 
            smStSendReqQ, smStGetMsgAttr, stResetCfgData))
     {
        cpLog(ENTST, CPLOGCLSERRLOG, 0, CPLOGLEVELERROR, "TCAP init error");
        RETVALUE(RIGNORE); 
        
     }
	 
#ifdef CP_SUB_AGENT                     
     if( ROK != cpSubAgRegCb((Ent)ENTST,  "stSmTsk", stSmTsk, gTcapEnum, gTcapEnumSize/sizeof(CP_SA_ENUM_TAB)))
     {
        cpLog(ENTST, CPLOGCLSERRLOG, 0, CPLOGLEVELERROR, "TCAP init error");
        RETVALUE(RIGNORE); 
        
     }
#endif     
     RETVALUE(ROK);
}	
#endif


/********************************************************************************************************
  Function: smStSendReqQ() 
  Description: sccp get msg buffer from sm queue, and send it out
  Calls:
  Called By: 
  Input:   smMsg: msg buffer get from sm queue 
               
  Output:  send LSP message to SP ENTITY

  
  Return:   ROK:success; 
                RFAILED: failure
  Others:
 ********************************************************************************************************/
S16 smStSendReqQ(CmLList *node)
{
    Pst smStPst;
#ifdef ZT
    Pst smZtPst;
#endif
    Header *msgHeader;
    S16 ret=ROK;
   
    TRC2(smStSendReqQ);      


    msgHeader = (Header *)cmLListNode(node);

    smStPstInit(&smStPst);

    switch(msgHeader->msgType)
    {
        case TCFG:
            ret = SmMiLstCfgReq(&smStPst, (StMngmt *)cmLListNode(node));
            break;
        case TCNTRL:
            ret = SmMiLstCntrlReq(&smStPst, (StMngmt *)cmLListNode(node));
            break;
        case TSTS:
            ret = SmMiLstStsReq(&smStPst, 0, (StMngmt *)cmLListNode(node));
            break;
        case TSSTA:
            ret = SmMiLstStaReq(&smStPst, (StMngmt *)cmLListNode(node));
            break;
        default:
            RETVALUE(RFAILED);
    }

    RETVALUE(ret);
}


/* 
 * Function name: stStsReq
 * Des:		      Send statistic Req to st
 * Return Value : ROK or RFAILED
 */
S16 stStsReq(SuId suId, Elmnt elmnt, U8 action)
{
	StMngmt   sts;            /* statistics */
	Pst	smStPst;

	TRC2(stStsReq);

	smStPstInit(&smStPst);
	memset(&sts, 0, sizeof(StMngmt));
	stHdrInit(&sts.hdr);
	
	sts.hdr.msgType       = TSTS;        /* Control */
	sts.hdr.entId.ent       = ENTST;         /* entity */
	sts.hdr.entId.inst       = ST_INST_0;     /* instance */
	sts.hdr.elmId.elmnt     = elmnt;         /* TC User sap */
	sts.hdr.elmId.elmntInst1 = suId;          /* sap id */

	/* give Control request to layer */
	(Void) SmMiLstStsReq(&smStPst, action, &sts);

	RETVALUE(ROK);
} /* end of stStsReq */


/* 
 * Function name: stStaReq
 * Des:		      send status Req to st
 * Return Value : ROK or RFAILED
 */
S16 stStaReq(SuId suId, Elmnt elmnt)
{
	StMngmt    sta;         /* Status */
	Pst	smStPst;
	
	TRC2(stStaReq)

	smStPstInit(&smStPst);
	memset(&sta, 0, sizeof(StMngmt));
	stHdrInit(&sta.hdr);
	
	sta.hdr.msgType        = TSSTA;      	/* Status */
	sta.hdr.entId.ent        = ENTST;         	/* entity */
	sta.hdr.entId.inst        = ST_INST_0;     	/* instance */
	sta.hdr.elmId.elmnt      = elmnt;         	/* TC User sap */
	sta.hdr.elmId.elmntInst1  = suId;          	/* sap id */

   /* give Status request to layer */
   (Void) SmMiLstStaReq(&smStPst, &sta);

   RETVALUE(ROK);
} /* end of stStaReq */

PRIVATE void stCntrlTsk(Void *par)
{
	StCntrlPar 		*cntrlPar;

	if ( (cntrlPar = (StCntrlPar *)par) == (StCntrlPar *)NULLP)
	{
		RETVOID;
	}

	
	stCntrlReq(cntrlPar->suId, cntrlPar->elmnt, cntrlPar->action, 
			cntrlPar->subAction, cntrlPar->par);
	SPutSBuf(DFLT_REGION, DFLT_POOL, (Data *)cntrlPar, sizeof(StCntrlPar));
	
	RETVOID;
}


/* 
 * Function name: stCntrlReq
 * Des:		      Send Control Req to TCAP
 * Return Value : ROK or RFAILED
 */
S16 stCntrlReq(SuId suId, Elmnt elmnt, U8 action, U8 subAction,
                  U32 par)
{
	StMngmt    cntrl;       /* Control */
	Pst	smStPst;

	TRC2(stCntrlReq);

	smStPstInit(&smStPst);
	memset(&cntrl, 0, sizeof(StMngmt));
	stHdrInit(&cntrl.hdr);
	
	cntrl.hdr.msgType          = TCNTRL;        /* Control */
	cntrl.hdr.entId.ent        = ENTST;         /* entity */
	cntrl.hdr.entId.inst       = ST_INST_0;     /* instance */
	cntrl.hdr.elmId.elmnt      = elmnt;         /* TC User sap */
	cntrl.hdr.elmId.elmntInst1 = suId;          /* sap id */
	cntrl.t.cntrl.action    = action;
	cntrl.t.cntrl.subAction = subAction;

	if ((elmnt == STGRTCUSAP) || (elmnt == STGRSPSAP) || (elmnt == STALLSAP))
	{
		cntrl.t.cntrl.par.dstProcId = par;
	}
#ifdef DEBUGP
	if(subAction == SADBG)
		cntrl.t.cntrl.dbg.dbgMask = par;
#else
	UNUSED(par);
#endif /* DEBUGP */

	/* give Control request to layer */
	(Void) SmMiLstCntrlReq(&smStPst, &cntrl);

	RETVALUE(ROK);
} /* end of stCntrlReq */


PRIVATE void stStaReqTsk(Void *par)
{
	StCntrlPar 		*cntrlPar;

	if ( (cntrlPar = (StCntrlPar *)par) == (StCntrlPar *)NULLP)
	{
		RETVOID;
	}

	
	stStaReq(cntrlPar->suId, cntrlPar->elmnt);
	SPutSBuf(DFLT_REGION, DFLT_POOL, (Data *)cntrlPar, sizeof(StCntrlPar));
	
	RETVOID;
}

PRIVATE void stStsReqTsk(Void *par)
{
	StCntrlPar 		*cntrlPar;

	if ( (cntrlPar = (StCntrlPar *)par) == (StCntrlPar *)NULLP)
	{
		RETVOID;
	}

	
	stStsReq(cntrlPar->suId, cntrlPar->elmnt, cntrlPar->action);
	SPutSBuf(DFLT_REGION, DFLT_POOL, (Data *)cntrlPar, sizeof(StCntrlPar));
	
	RETVOID;
}

#endif /* CP_OAM_SUPPORT */

/********************************************************************30**

         End of file: st_cfg.c 1.1  -  10/08/2001

*********************************************************************31*/

/********************************************************************90*

     ver       pat                     description
------------ --------  ----------------------------------------------*/


