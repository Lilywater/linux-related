/**********************************************************************

    Name:   st_cfg.h - Configuration for the TCAP

    Type:   C include file

    Desc:   #define and macros for the TCAP layer Configuration

    File:   st_cfg.h

    Sid:    st_cfg.h - SEP/23/2003

    Created by: avery.sun

**********************************************************************/
#ifndef _ST_CFG_H_
#define _ST_CFG_H_

#ifdef CP_OAM_SUPPORT

/*---------------------------macro define----------------------------*/
/* system task priority */
#define SS_TCAP_TSK_PRI	75

/* Local Define */
/*#define ST_INST_0	0	 map instance 0 */
#define ST_REG		0	/* memory region id */
#define ST_POOL		0	/* pool value */

/* Sap Ids */
#define ST_SAP_0	0	/* sap 0 */
#define ST_SAP_1	1	/* sap 1 */

/* Resources configuration in the MAP layer */
#define ST_SAP_DLGS				10000		/* Max. number of dialogues on a Sap */
#define ST_SAP_INVS				10000		/* Max. number of invokes on a Sap */
#define ST_SAP_BINS				10000			/* Max. number of Hash List Bins on a Sap */
/* 30000->10000, mdf by leon.teng */

/* Timer define */
#define ST_TMR_INV				100			/* Invoke Timer */
#define ST_TMR_REJ				5			/* Reject Timer */
#define ST_TMR_BND_CFM			10			/* Bind confirm timer value */
#define ST_LOW_SAP_TMR			10			/* Lower Sap timer */
/* add by shu.bu 2003/08/07 for resource audit */
#define ST_PERIOD0				1			/* TCAP Timer resolution */
#define ST_PERIOD1				1			/* PSF Timer resolution */

/*---------------------TCAP initializing configure----------------------------*/ 

/* Macro define for tcap general configure */
#define ST_NMB_SAPS		6							/* Max Number of TCAP Saps (Upper and Lower) , Must <7*/
#define ST_NMB_DLGS		(ST_NMB_SAPS * ST_SAP_DLGS)	/* Max Number of dialogs; system-wide */
#define ST_NMB_INVS			(ST_NMB_SAPS * ST_SAP_INVS)	/* Max Number of invokes; system-wide */
#define ST_NMB_BINS			(ST_NMB_SAPS * ST_SAP_BINS)	/* Max Number of Hash List Bins; system-wide */
#define ST_TIME_RES		       10					/* Timer Resolution as no of Ticks , now it is one second*/
#define ST_SAP_TIME_RES	10					/* Timer Resolution as no of Ticks , now it is one second*/
#define ST_LO_DLG_ID	1							/* lower limit on dlg id */
#define ST_HI_DLG_ID	        65535				/* higher limit on dlg id */
#define ST_BIT_MAP_FLAG        FALSE
/* Macro define for tcap sap configure */

#define MAX_TCAP_GEN_STS_NUM	  1	
#define MAX_TCAP_ABT_STS_NUM	  1	
#define MAX_TCAP_REJ_STS_NUM	  1	
#define MAX_INAP_SAP_STS_NUM	  4	

#define MAX_SS7_NETWORK_NUM             10
#define MAX_SS7_OPC_NUM                      10
#define MAX_SS7_DPC_NUM                      100
#define MAX_SS7_SSN_NUM                      16


/*-------------TCAP configure part ---------*/

typedef struct _CP_TCAP_GEN_TAB
{
    U32      OprType;
    U32      NmbSaps;
    U32      NmbInvs;
    U32      ErrCntrlFlg;
    U32      T1;
    U32      T2;
    U32      spTmr;
    U32      TIntTmr;
    
}CP_TCAP_GEN_TAB;

/*-------------TCAP statistcs part ---------*/
typedef struct _CP_TCAP_GEN_STS_TAB
{
	U32 OprType;
	U32 GroupId;

   U32        uniTx;          /* unidirectional messages transmitted */
   U32        abtTx;          /* abort messages transmitted */

   /* The following three counters are maintained for ITU only */
   U32        bgnTx;          /* begin messages transmitted */
   U32        cntTx;          /* continue messages transmitted */
   U32        endTx;          /* end messages transmitted */

   /* The following five counters are maintained for ANSI only */
   U32        qwpTx;          /* query with permission transmitted */
   U32        qnpTx;          /* query without permission transmitted */
   U32        cwpTx;          /* conversation with permission transmitted */
   U32        cnpTx;          /* conversation without permission transmitted */
   U32        rspTx;          /* response transmitted */

   /* Message Rx Statistics */

   U32        uniRx;          /* unidirectional messages received */
   U32        abtRx;          /* abort messages received */

   /* The following three counters are maintained for ITU only */
   U32        bgnRx;          /* begin messages received */
   U32        cntRx;          /* continue messages received */
   U32        endRx;          /* end messages received */

   /* The following five counters are maintained for ANSI only */
   U32        qwpRx;          /* query with permission transmitted */
   U32        qnpRx;          /* query without permission transmitted */
   U32        cwpRx;          /* conversation with permission transmitted */
   U32        cnpRx;          /* conversation without permission transmitted */
   U32        rspRx;          /* response transmitted */

   /* Component Tx Statistics */

   /* The following five counters are maintained for both ITU and ANSI */

   U32        invTx;          /* Invoke components transmitted */
   U32        resTx;          /* Return result components transmitted */
   U32        errTx;          /* Return error components transmitted */
   U32        rejTx;          /* Reject components transmitted */

   /* Component Rx Statistics */

   /* The following five counters are maintained for both ITU and ANSI */

   U32        invRx;          /* invoke components received */
   U32        resRx;          /* return result components received */
   U32        errRx;          /* return error components received */
   U32        rejRx;          /* reject components received */    

   U32        actInv;			/* actived invokes */
   U32        usedInv;			/* used invokes */
   U32        actTrns;		/* actived transactions */
   U32        usedTrns;		/* used transaction */
   
}CP_TCAP_GEN_STS_TAB;

typedef struct _CP_TCAP_ABORT_STS_TAB
{
	U32 OprType;
	U32 GroupId;
	U32        abtTx;          /* abort messages transmitted */
	U32        abtRx;          /* abort messages received */

	/* The following five counters are maintained for both ITU and ANSI */
	U32     urMsgRx;        /* unrecognized message type */
	U32     inTrnRx;        /* incorrect transaction portion */
	U32     bdTrnRx;        /* badly formatted transaction portion */
	U32     urTidRx;        /* unrecognized transaction ID */
	U32     rsrcLRx;        /* resource limitation */

	/* The following five counters are maintained for both ITU and ANSI */
	U32     urMsgTx;        /* unrecognized message type */
	U32     inTrnTx;        /* incorrect transaction portion */
	U32     bdTrnTx;        /* badly formatted transaction portion */
	U32     urTidTx;        /* unrecognized transaction ID */
	U32     rsrcLTx;        /* resource limitation */
	
}CP_TCAP_ABORT_STS_TAB;

typedef struct _CP_TCAP_REJ_STS_TAB
{
	U32 OprType;
	U32 GroupId;

	U32        rejRx;          /* reject components received */    
	U32        rejTx;          /* Reject components transmitted */

	/* ALL The following counters are maintained for both ITU and ANSI */
	U32     urCmpRx;        /* general - unrecognized component */
	U32     inCmpRx;        /* general - incorrect component portion */
	U32     bdCmpRx;        /* general - badly structured component prtn */
	U32     urLidRx;        /* invoke - unrecognized linked Id */
	U32     urIidRRRx;      /* return result - unrecognized invoke Id */
	U32     uxResRx;        /* return result - unexpected return result */
	U32     urIidRERx;      /* return error - unrecognized invoke Id */
	U32     uxErrRx;        /* return error - unexpected return error */

	U32     dupIdRx;        /* invoke - duplicate Invoke Id */
	U32     urOprRx;        /* invoke - unrecognized operation code */
	U32     inPrmINRx;      /* invoke - incorrect parameters */
	U32     rsrcInvRx;      /* invoke - resource limitation */
	U32     rlsInvRx;       /* invoke - initiating release */
	U32     uxLrspRx;       /* invoke - unexpected linked response */
	U32     uxLoprRx;       /* invoke - unexpected linked operation */
	U32     inPrmRRRx;      /* return result - incorrect parameters */
	U32     urErrRx;        /* return error - unrecognized error code */
	U32     uxEcdRx;        /* return error - unexpected error code */
	U32     inPrmRERx;      /* return error - incorrect parameters */

	/* TC User generated problems */
	U32     dupIdTx;        /* invoke - duplicate Invoke Id */
	U32     urOprTx;        /* invoke - unrecognized operation code */
	U32     inPrmINTx;      /* invoke - incorrect parameters */
	U32     rsrcInvTx;      /* invoke - resource limitation */
	U32     rlsInvTx;       /* invoke - initiating release */
	U32     uxLrspTx;       /* invoke - unexpected linked response */
	U32     uxLoprTx;       /* invoke - unexpected linked operation */
	U32     inPrmRRTx;      /* return result - incorrect parameters */
	U32     urErrTx;        /* return error - unrecognized error code */
	U32     uxEcdTx;        /* return error - unexpected error code */
	U32     inPrmRETx;      /* return error - incorrect parameters */

	/* ALL The following counters are maintained for both ITU and ANSI */
	U32     urCmpTx;        /* general - unrecognized component */
	U32     inCmpTx;        /* general - incorrect component portion */
	U32     bdCmpTx;        /* general - badly structured component prtn */
	U32     urLidTx;        /* invoke - unrecognized linked Id */
	U32     urIidRRTx;      /* return result - unrecognized invoke Id */
	U32     uxResTx;        /* return result - unexpected return result */
	U32     urIidRETx;      /* return error - unrecognized invoke Id */
	U32     uxErrTx;        /* return error - unexpected return error */

}CP_TCAP_REJ_STS_TAB;

/*---------------------------type define----------------------------*/
/*	initialization tcap global configure */

typedef struct CP_TCAP_CONFIG_DATA
{
    U16                          TcapGenNum;
    CP_TCAP_GEN_TAB              TcapGen;
    
    /* statistics */
    U16                          TcapGenStsNum;
	  CP_TCAP_GEN_STS_TAB          TcapGenSts[MAX_TCAP_GEN_STS_NUM];
    U16                          TcapAbortStsNum;
	  CP_TCAP_ABORT_STS_TAB		     TcapAbortSts[MAX_TCAP_ABT_STS_NUM];
    U16                          TcapRejStsNum;
	  CP_TCAP_REJ_STS_TAB		       TcapRejSts[MAX_TCAP_REJ_STS_NUM];
	
}CP_TCAP_CONFIG_DATA;

typedef struct CP_DT_CONFIG_DATA
{
    U16                          Ss7NetworkNum;
    CP_SS7_NETWORK_TAB           Ss7Network[MAX_SS7_NETWORK_NUM];
    U16                          Ss7UpNum;
    CP_SS7_UP_TAB               Ss7Up[MAX_SS7_OPC_NUM];
    U16                          Ss7SsnNum;
    CP_SS7_SSN_TAB               Ss7Ssn[MAX_SS7_SSN_NUM];
    
}CP_DT_CONFIG_DATA;

enum CP_TCAP_CONFIG_QUEUE_ID
{
    CP_TCAP_GEN_Q,
    CP_TCAP_SAP_Q,
#ifdef ZT    
    CP_TCAPPSF_GEN_Q,
#endif
#ifdef ZT_DFTHA
    CP_TCAPPSF_DIST_Q,
    CP_TCAPPSF_RSET_Q,
#endif
    CP_TCAP_STS_Q,
    CP_TCAP_CONFIG_Q_TOTAL_NUM,
};

/* tcap control structure parameter */
typedef struct _stCntrlPar
{
	SuId   suId;               /* Sap Id */
	U8     elmnt;              /* Element */
	U8     action;             /* Enable/disable */
	U8     subAction;          /* Trace/alarm */
	U32    par;            /* debug mask */
} StCntrlPar;

/* TCAP table ID */
typedef enum _stTableID
{
	SM_STGENCFG_TBL = 1,        /* General config */
	SM_STOPCCFG_TBL,            /* OPC config */
	SM_STSS7CFG_TBL,             /* Network config */
	SM_STSSNCFG_TBL,            /* SSN config */
	
}StTblId;


#define ST_CTRL_TSK_STACK_SIZE 409600
#define ST_CTRL_TSK_PRI	100

extern CP_TCAP_CONFIG_DATA    gStCfgData;
extern CmLListCp gStSmQ[CP_TCAP_CONFIG_Q_TOTAL_NUM];
extern U32 stCfgTbl[4];

/*--------Extern Functions------------------------*/
#ifdef __cplusplus
extern "C" {
#endif

extern Bool smIsSameSTsk(Ent entId1, Inst instId1, Ent entId2, Inst instId2);
extern S16 stGenCfg(Void);
extern S16 stAddSsn(U16 nRec);
extern S16 stDelSsn(U16 nRec);
extern S16 stModSsn(U16 nRec);
extern S16 stCfgMsg(void);
extern void stInitCfgData(void);
extern void stResetCfgData(void);
extern S16 smStSendReqQ(CmLList *node);
extern U8 stGetSwType( U8 swType);

extern S16 stStsReq(SuId suId, Elmnt elmnt, U8 action);
extern S16 stStaReq(SuId suId, Elmnt elmnt);
/*----------------------------------------------------------------*/
extern S16 stCntrlReq(SuId suId, Elmnt elmnt, U8 action, U8 subAction,
                  U32 par);


#ifdef __cplusplus
}
#endif

#endif /* CP_OAM_SUPPORT */

#endif /* _ST_CFG_H_ */
