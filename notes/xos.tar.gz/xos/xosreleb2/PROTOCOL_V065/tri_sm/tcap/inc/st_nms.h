/**********************************************************************

    Name:   st_cfg.h - Configuration for the TCAP

    Type:   C include file

    Desc:   #define and macros for the TCAP layer Configuration

    File:   st_cfg.h

    Sid:    st_cfg.h - SEP/23/2003

    Created by: avery.sun

**********************************************************************/
#ifndef _ST_NMS_H_
#define _ST_NMS_H_

#ifdef CP_OAM_SUPPORT

#ifdef __cplusplus
extern "C"{
#endif
EXTERN S16 smStCfgTsk(void);
EXTERN S16 stRecvInitCfg(tb_record* prow);
EXTERN S16 stRecvDynCfg(U32 msgtype, tb_record* prow);
EXTERN unsigned char stInitCfgCallback(U16 msgtype, U32 sequense, U8 pack_end, tb_record * prow);
EXTERN VOID stDynCfgCallback(unsigned int tableid, unsigned short msgtype, unsigned int sequence,
									unsigned char pack_end, tb_record *prow);

#ifdef ST_OAM_TST
EXTERN PUBLIC S16 OamTestTsk(Void);
EXTERN PUBLIC S16 nmsTstActvTsk(Pst * pst, Buffer * mBuf);
#endif /* ST_OAM_TST */

#ifdef __cplusplus
}
#endif

#endif /* CP_OAM_SUPPORT */

#endif /* _ST_CFG_H_ */
