/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

  
/********************************************************************20**
  
     Name:     stack manager - interface with MTP Level 3

     Type:     C source file
  
     Desc:     Sample C source code for the stack manager.
               - MTP Level 3 interface primitives.
               - Functions required for unpacking layer management
                 service provider primitives in loosely coupled systems.

     File:     smsnexms.c
  
     Sid:      smsnexms.c@@/main/11 - Mon Apr  9 13:43:57 2001
  
     Prg:      mc
  
*********************************************************************21*/
  
  
/*
*     The functions provided in this file correspond to the functions
*     provided in the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*
*/

/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000028     SS7 - MTP Level 3
*
*/
  
  
/* header include files (.h) */
  
#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "cm_ss7.h"
#include "cm_hash.h"       /* common functions */
#include "ssi.h"           /* system services */
#include "lsn.h"           /* mtp3 layer management */
#include "smsn_err.h"      /* stack management (q.saal)errors */
#ifdef ZN
#include "cm_ftha.h"
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common FT/HA  */
#endif
#include "cm_psfft.h"      /* common FT/HA  */
#ifdef ZN_DFTHA
#include "cmzndn.h"
#include "cmzndnlb.h"
#endif
#include "mrs.h"
#include "lzn.h"
#endif /* ZN */
#ifdef FTHA
#include "sht.h"
#endif
  
/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"           /* general */
#include "cm_hash.x"           /* common functions */
#include "lsn.x"           /* mtp3 layer management */
#ifdef ZN
#include "cm_ftha.x"
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common FT/HA  */
#endif
#include "cm_psfft.x"      /* common FT/HA  */
#ifdef ZN_DFTHA
#include "cmzndn.x"
#include "cmzndnlb.x"
#endif
#include "mrs.x"
#include "lzn.x"           /* layer mgmt: mtp level 3 PSF */
#endif /* ZN */
#ifdef FTHA
#include "sht.x"
#endif

  
/* local defines */
  
/* local typedefs */
  
/* local externs */
  
/* forward references */


/* functions in other modules */

/* public variable declarations */
  
/* private variable declarations */


/*
*
*       Fun:    activate task
*
*       Desc:   Processes received event from MTP 3
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   smsnexms.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smSnActvTsk
(
Pst *lmgPst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 smSnActvTsk(lmgPst, mBuf)
Pst *lmgPst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   S16 ret1;

   TRC3(smSnActvTsk)

   ret1 = ROK;

   switch(lmgPst->event)
   {
#ifdef LCSMSNMILSN
      case EVTLSNSTACFM:             /* Status Confirm */
         cmUnpkLsnStaCfm(SmMiLsnStaCfm, lmgPst, mBuf);
         break;
      case EVTLSNSTSCFM:             /* Statistics Confirm */
         cmUnpkLsnStsCfm(SmMiLsnStsCfm, lmgPst, mBuf);
         break;
      case EVTLSNSTAIND:             /* Status Indication */
         cmUnpkLsnStaInd(SmMiLsnStaInd, lmgPst, mBuf);
         break;
      case EVTLSNTRCIND:             /* Trace Indication */
         cmUnpkLsnTrcInd(SmMiLsnTrcInd, lmgPst, mBuf);
         break;
#ifdef SMSN_LMINT3 
      case EVTLSNCFGCFM:             /* config Confirm */
         cmUnpkLsnCfgCfm(SmMiLsnCfgCfm, lmgPst, mBuf);
         break;
      case EVTLSNCNTRLCFM:           /* control Confirm */
         cmUnpkLsnCntrlCfm(SmMiLsnCntrlCfm, lmgPst, mBuf);
         break;
#endif /* SMSN_LMINT3 */
#endif /* LCSMSNMILSN */

      default:
#ifdef ZN
         /* it may be an event for the PSF */
         smZnActvTsk(lmgPst, mBuf);
#else /* ZN */
#if (ERRCLASS & ERRCLS_DEBUG)
         SLogError(lmgPst->dstEnt, lmgPst->dstInst, lmgPst->dstProcId, __FILE__, \
                   __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal)ESMSN003, 
                   (ErrVal)lmgPst->event, "smSnActvTsk invalid event"); 
#endif
         (Void) SPutMsg(mBuf);
         ret1 = RFAILED;
#endif /* ZN */
   }
   SExitTsk();
   RETVALUE(ret1);

} /* end of smSnActvTsk */

  
/********************************************************************30**
  
         End of file:     smsnexms.c@@/main/11 - Mon Apr  9 13:43:57 2001
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mc    1. initial release.

1.2          ---  mc    1. modified smUnpkMiLsnStaCfm.

2.1          ---  mc    1. added txRestrictRx statistic in smUnpkMiLsnStsCfm.
             ---  mc    2. removed ret from smSnActvTsk.

2.2          ---  fmg   1. included cm_gen.?
             ---  mc    2. unpack U32 instead of S32 for duration statistics in
                           smUnpkMiLsnStsCfm.

2.3          ---  mc    1. added packing function of dpc in STROUT case in 
                           LsnStaCfm and LsnStsCfm.

2.4          ---  mc    1. added LsnTrcInd.
             ---  mc    2. replaced all unpacking functions with macro CMCHKUNPKLOG.
             ---  mc    3. unpakced remBlkd in smUnpkMiLsnStaCfm.

2.5          ---  pm    1. unpacked tQSize and rtQSize as U32 in smUnpkMiLsnStaCfm.
             ---  pm    2. include cm_gen.h, cm_ss7.h and cm_ss7.x files.

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
2.6          ---      pm   1. added SS7_ANS96 preprocessor.
             ---      pm   2. unpacked UpSwtch while unpacking SnMiLsnStaCfm and
                              SnMiLsnStsCfm.
             ---      pm   3. unpacked lnkErrPduRx while unpacking SnMiLsnStsCfm
                              for link error counters.
             ---      pm   4. SPutMsg in SActvTsk should be called unconditionally and
                              not not under ERROR CLASS. 

2.7          ---      pm   1. added SmMiLsnCfgCfm and SmMiLsnCntrlCfm
                              primitives.
             ---      pm   2. added SmMiLznCfgCfm, SmMiLznCntrlCfm,
                              SmMiLznStaCfm and SmMiLznStaInd primitives.
             ---      pm   3. added support for LMINT3.
             ---      pm   4. unpacked bndState for DLSAP in SnMiLsnStaCfm.
             ---      pm   5. removed SmMiLznCfgCfm, SmMiLznCntrlCfm,
                              SmMiLznStaCfm and SmMiLznStaInd primitives.
             ---      sr   6. unpacking functions replaced by common 
                              unpacking functions.
             ---      sr   7. unpacking functions replaced by common 
                              unpacking functions.
             ---      pm   8. unpack function names corrected.
             ---      pm   9. removed cm_gen.[hx] files.
/main/10     ---      sr   1. Modified copyright header and other changes
                              for release 3.1
/main/11     ---      nb   1. Modified error codes
*********************************************************************91*/

