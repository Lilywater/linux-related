/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

  
/********************************************************************20**
  
     Name:     stack manager - portable mtp level 3
  
     Type:     C source file
  
     Desc:     C source code for the mtp level 3 layer management
               service user primitives used in loosely coupled
               systems.
 
     File:     smsnptmi.c
  
     Sid:      smsnptmi.c@@/main/12 - Mon Apr  9 13:44:04 2001
   
     Prg:      mc
  
*********************************************************************21*/
 

/*
  
Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.
 
The following functions are provided in this file:
 
     SmMiLsnCfgReq      Configure Request
     SmMiLsnStaReq      Status Request
     SmMiLsnStsReq      Statistics Request
     SmMiLsnCntrlReq    Control Request

It is assumed that the following functions are provided in the
layer managment service provider file:
 
     SmMiLsnStaInd      Status Indication
     SmMiLsnStaCfm      Status Confirm
     SmMiLsnStsCfm      Statistics Confirm
     SmMiLsnTrcInd      Trace Indication

*/   
  

/*
*     This software may be used with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000028     SS7 - MTP level 3
*
*/


/* header include files (.h) */
  
#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
 
#include "gen.h"           /* general layer */
#include "cm_ss7.h"
#include "ssi.h"           /* system services */
#include "lsn.h"           /* layer management, mtp level 3 */
#include "smsn_err.h"      /* stack manager error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"           /* general */
#include "lsn.x"           /* layer management, mtp level 3 */


/* local defines */
 
#define MAXSNMI         3

/* local typedefs */
  
/* local externs */
  
/* forward references */
#ifndef LCSMSNMILSN
#define DEFPTSMSNMILSN
#endif
#ifndef SM 
#define DEFPTSMSNMILSN
#endif
#ifdef DEFPTSMSNMILSN
PRIVATE S16 PtMiLsnCfgReq   ARGS((Pst *lmpst, SnMngmt *cfg ));
PRIVATE S16 PtMiLsnStaReq   ARGS((Pst *lmpst, SnMngmt *sta ));
PRIVATE S16 PtMiLsnStsReq   ARGS((Pst *lmpst, Action action, SnMngmt *sts ));
PRIVATE S16 PtMiLsnCntrlReq ARGS((Pst *lmpst, SnMngmt *cntrl ));
#endif

/* functions in other modules */
  
/* public variable declarations */
  
/* private variable declarations */

/*
the following matrices define the mapping between the primitives
called by the layer management interface of MTP-3 and the corresponding
primitives in MTP-3.
 
The parameter MAXSNMI defines the maximum number of layer manager entities
on top of MTP-3. There is an array of functions per primitive
invoked by MTP-3. Every array is MAXSNMI long (i.e. there
are as many functions as the number of service users).
 
The dispatching is performed by the configurable variable: selector.
The selector is configured during general configuration.
 
The selectors are:
 
   0 - loosely coupled - old interface, backward cabability (#define LCSMSNMILSN)
   1 - loosely coupled - new interface, forawrd cabability (#define LCSMSNMILSN)
   2 - Lsn (#define SN)
 
*/

/* Configuration request primitive */
 
PRIVATE LsnCfgReq SmMiLsnCfgReqMt[MAXSNMI] =
{
#ifdef LCSMSNMILSN
   cmPkLsnCfgReq,        /* 0 - loosely coupled - bc */
#else
   PtMiLsnCfgReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef LCSMSNMILSN
   cmPkLsnCfgReq,        /* 1 - loosely coupled - fc */
#else
   PtMiLsnCfgReq,          /* 1 - tightly coupled, portable */
#endif
#ifdef SN
   SnMiLsnCfgReq,          /* 2 - tightly coupled, layer management */
#else
   PtMiLsnCfgReq,          /* 2 - tightly coupled, portable */
#endif
};

/* Statistics request primitive */
 
PRIVATE LsnStsReq SmMiLsnStsReqMt[MAXSNMI] =
{
#ifdef LCSMSNMILSN
   cmPkLsnStsReq,        /* 0 - loosely coupled - bc */
#else
   PtMiLsnStsReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef LCSMSNMILSN
   cmPkLsnStsReq,        /* 1 - loosely coupled - fc */
#else
   PtMiLsnStsReq,          /* 1 - tightly coupled, portable */
#endif
#ifdef SN
   SnMiLsnStsReq,          /* 2 - tightly coupled, layer management */
#else
   PtMiLsnStsReq,          /* 2 - tightly coupled, portable */
#endif
};

/* Status request primitive */
 
PRIVATE LsnStaReq SmMiLsnStaReqMt[MAXSNMI] =
{
#ifdef LCSMSNMILSN
   cmPkLsnStaReq,        /* 0 - loosely coupled - bc */
#else
   PtMiLsnStaReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef LCSMSNMILSN
   cmPkLsnStaReq,        /* 1 - loosely coupled - fc */
#else
   PtMiLsnStaReq,          /* 1 - tightly coupled, portable */
#endif
#ifdef SN
   SnMiLsnStaReq,          /* 2 - tightly coupled, layer management */
#else
   PtMiLsnStaReq,          /* 2 - tightly coupled, portable */
#endif
};

/* Control request primitive */
 
PRIVATE LsnCntrlReq SmMiLsnCntrlReqMt[MAXSNMI] =
{
#ifdef LCSMSNMILSN
   cmPkLsnCntrlReq,        /* 0 - loosely coupled - bc */
#else
   PtMiLsnCntrlReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef LCSMSNMILSN
   cmPkLsnCntrlReq,        /* 1 - loosely coupled - fc */
#else
   PtMiLsnCntrlReq,          /* 1 - tightly coupled, portable */
#endif
#ifdef SN
   SnMiLsnCntrlReq,          /* 2 - tightly coupled, layer management */
#else
   PtMiLsnCntrlReq,          /* 2 - tightly coupled, portable */
#endif
};

/*
*     layer management interface functions 
*/
 
/*
*
*       Fun:   Configuration request
*
*       Desc:  This function is used to configure MTP-3
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsnptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsnCfgReq
(
Pst *lmpst,                 /* post structure */
SnMngmt *cfg              /* configure */
)
#else
PUBLIC S16 SmMiLsnCfgReq(lmpst, cfg)
Pst *lmpst;                 /* post structure */   
SnMngmt *cfg;             /* configure */
#endif
{
   TRC3(SmMiLsnCfgReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLsnCfgReqMt[lmpst->selector])(lmpst, cfg); 
   RETVALUE(ROK);
} /* end of SmMiLsnCfgReq */

/*
*
*       Fun:   Status request
*
*       Desc:  This function is used to send a status request to MTP-3
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsnptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsnStaReq
(
Pst *lmpst,                 /* post structure */
SnMngmt *sta              /* status */
)
#else
PUBLIC S16 SmMiLsnStaReq(lmpst, sta)
Pst *lmpst;                 /* post structure */   
SnMngmt *sta;             /* status */
#endif
{
   TRC3(SmMiLsnStaReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLsnStaReqMt[lmpst->selector])(lmpst, sta); 
   RETVALUE(ROK);
} /* end of SmMiLsnStaReq */

/*
*
*       Fun:   Statistics request
*
*       Desc:  This function is used to request statistics from MTP-3
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsnptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsnStsReq
(
Pst *lmpst,                 /* post structure */
Action action,
SnMngmt *sts              /* statistics */
)
#else
PUBLIC S16 SmMiLsnStsReq(lmpst, action, sts)
Pst *lmpst;                 /* post structure */   
Action action;
SnMngmt *sts;             /* statistics */
#endif
{
   TRC3(SmMiLsnStsReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLsnStsReqMt[lmpst->selector])(lmpst, action, sts); 
   RETVALUE(ROK);
} /* end of SmMiLsnStsReq */

/*
*
*       Fun:   Control request
*
*       Desc:  This function is used to send control request to MTP-3
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsnptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsnCntrlReq
(
Pst *lmpst,                 /* post structure */
SnMngmt *cntrl            /* control */
)
#else
PUBLIC S16 SmMiLsnCntrlReq(lmpst, cntrl)
Pst *lmpst;                 /* post structure */   
SnMngmt *cntrl;           /* control */
#endif
{
   TRC3(SmMiLsnCntrlReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLsnCntrlReqMt[lmpst->selector])(lmpst, cntrl); 
   RETVALUE(ROK);
} /* end of SmMiLsnCntrlReq */


#ifdef DEFPTSMSNMILSN

/*
*
*       Fun:   Portable configure Request MTP-3
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsnptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLsnCfgReq
(
Pst *lmpst,                   /* post structure */
SnMngmt *cfg                /* configure */
)
#else
PRIVATE S16 PtMiLsnCfgReq(lmpst, cfg)
Pst *lmpst;                   /* post structure */
SnMngmt *cfg;               /* configure */
#endif
{
  TRC3(PtMiLsnCfgReq);
#if (ERRCLASS & ERRCLS_DEBUG)
   SLogError(lmpst->srcEnt, lmpst->srcInst, lmpst->srcProcId, __FILE__, \
             __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal)ESMSN004, 
             (ErrVal)0, "PtMiLsnCfgReq () Failed"); 
#else
   UNUSED(lmpst);
#endif
   UNUSED(cfg);
  RETVALUE(ROK);
} /* end of PtMiLsnCfgReq */


/*
*
*       Fun:   Portable status Request MTP-3
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsnptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLsnStaReq
(
Pst *lmpst,                   /* post structure */
SnMngmt *sta                /* status */
)
#else
PRIVATE S16 PtMiLsnStaReq(lmpst, sta)
Pst *lmpst;                   /* post structure */
SnMngmt *sta;               /* status */
#endif
{
  TRC3(PtMiLsnStaReq);
#if (ERRCLASS & ERRCLS_DEBUG)
   SLogError(lmpst->srcEnt, lmpst->srcInst, lmpst->srcProcId, __FILE__, \
             __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal)ESMSN005, 
             (ErrVal)0, "PtMiLsnStaReq () Failed"); 
#else
   UNUSED(lmpst);
#endif
   UNUSED(sta);
  RETVALUE(ROK);
} /* end of PtMiLsnStaReq */


/*
*
*       Fun:   Portable statistics Request MTP-3
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsnptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLsnStsReq
(
Pst *lmpst,                   /* post structure */
Action action,
SnMngmt *sts                /* statistics */
)
#else
PRIVATE S16 PtMiLsnStsReq(lmpst, action, sts)
Pst *lmpst;                   /* post structure */
Action action;
SnMngmt *sts;               /* statistics */
#endif
{
  TRC3(PtMiLsnStsReq);
#if (ERRCLASS & ERRCLS_DEBUG)
   SLogError(lmpst->srcEnt, lmpst->srcInst, lmpst->srcProcId, __FILE__, \
             __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal)ESMSN006, 
             (ErrVal)0, "PtMiLsnStaReq () Failed"); 
#else
   UNUSED(lmpst);
#endif
   UNUSED(action);
   UNUSED(sts);
  RETVALUE(ROK);
} /* end of PtMiLsnStsReq */


/*
*
*       Fun:   Portable control Request MTP-3
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsnptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLsnCntrlReq
(
Pst *lmpst,                   /* post structure */
SnMngmt *cntrl              /* control */
)
#else
PRIVATE S16 PtMiLsnCntrlReq(lmpst, cntrl)
Pst *lmpst;                   /* post structure */
SnMngmt *cntrl;             /* control */
#endif
{
  TRC3(PtMiLsnCntrlReq);
#if (ERRCLASS & ERRCLS_DEBUG)
   SLogError(lmpst->srcEnt, lmpst->srcInst, lmpst->srcProcId, __FILE__, \
             __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal)ESMSN007, 
             (ErrVal)0, "PtMiLsnCntrlReq () Failed"); 
#else
   UNUSED(lmpst);
#endif
   UNUSED(cntrl);
  RETVALUE(ROK);
} /* end of PtMiLsnCntrlReq */
#endif /* DEFPTSMSNMILSN */

/********************************************************************30**

         End of file:     smsnptmi.c@@/main/12 - Mon Apr  9 13:44:04 2001

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mc    1. initial release

1.2          ---  ak    1. fix non-ANSI compile bugs.

1.3          ---  lc    1. change rstFlg to spRst

1.4          ---  mc    1. add packing function for Simple Router in 
                           smPkMiLsnCfgReq.

2.1          ---  mc    1. pack ssf in the STROUT case in smPkMiLsnCfgReq.

2.2          ---  fmg   1. included cm_gen.?
             ---  mc    2. pack U32 instead of S32 for duration statistics in
                           smPkMiLsnStsReq.
             ---  mc    3. pack ssfValid in smPkMiLsnCfgReq.

2.3          ---  mc    1. correct typo (PUBLIC -> PRIVATE for all packing 
                           functions)
             ---  mc    2. it's not necessary to pack in StaReq and StsReq.
             ---  mc    3. pack U32 for maxCredit instead of U8 in smPkMiLsnCfgReq.

2.4          ---  mc    1. text change.
             ---  mc    2. pack brdcastFlg and opc to smPkMiLsnCfgReq.

2.5          ---  pm    1. removed SSINT1 interface.
             ---  pm    2. packed p*QLen as U32 in smPkMiLsnCfgReq.
             ---  pm    3. packed dpc in smPkMiLsnCfgReq.
             ---  pm    4. packed tmr t11 in snPkMiLsnCfgReq 
             ---  pm    5. packed upSwtch field of  SnNSapCfg struct.
             ---  pm    6. packed upSwtch field of  SnDLSapCfg struct.
             ---  pm    7. include cm_gen.h, cm_ss7.h and cm_ss7.x files.

2.6          ---  pm    1. packed clstMemCmbLnkSetId,rteToClstMember and
                           clstMemNumber fields in SnRoutCfg struct.
             ---  pm    2. removed masks from snGenCb.

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------

2.7          ---      pm   1. Added STDLSAPDIS and STDLSAPACT as new elmnt
                              while sending the configuration request.
             ---      pm   2. packed timer t18 in route timer block.
             ---      pm   3. packed timer t35, t36 and t37 in link control block.
             ---      pm   4. added SS7_ANS96 preprocessor.
             ---      pm   5. packed l2Type in DLSAP cfg. 
             ---      pm   6. packed upSwtch in route config.
             ---      pm   7. renamed minNmbActLnk as nmbActLnkReqd in lnkSetCb.
             ---      pm   8. added upSwtchwhile packing SmMiLsnStaReq,
                              SmMiLsnStsReq and SmMiLsnCntrlReq.
             ---      pm   9. removed packing of rteToCluster, clstMemCmbLnkSetId,
                              rteToClstMember and clstMemNumber fields in SnRoutCfg
                              struct.
             ---      pm  10. packed ssf field in the NSAP config.

2.8          ---      pm   1. added SmMiLznCfgReq, SmMiLznCntrlReq
                              and SmMiLznStaReq primitives.
                           2. unpacked dstPrcoId in cntrl packing structure.
             ---      pm   3. removed cm_gen.[hx] files.
             ---      pm   4. removed SmMiLznCfgReq, SmMiLznCntrlReq
                              and SmMiLznStaReq primitives.
             ---      sr   5. packing functions moved to common file.
             ---      pm   6. pack function names corrected.
             ---      pm   7. packed tFlc and tBnd fields in the DLSAP
                              configuration request.
/main/12     ---      nb   8. Added new error codes.
*********************************************************************91*/
