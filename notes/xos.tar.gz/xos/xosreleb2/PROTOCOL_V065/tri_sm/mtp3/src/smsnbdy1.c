/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

  
/********************************************************************20**
  
     Name:     stack manager - body 1
  
     Type:     C source file
  
     Desc:     Prototype C source code for the Layer Management
               service provider. This file is needed for the 
               MTP Level 3 software test sample.

     File:     smsnbdy1.c
  
     Sid:      smsnbdy1.c@@/main/11 - Mon Apr  9 13:43:50 2001
  
     Prg:      mc
  
*********************************************************************21*/
  

/*
  
Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.

The following functions are provided in this file for the
layer management service user:
  
     SmMiLsnStaInd      Status Indication
     SmMiLsnStsCfm      Statistics Confirm
     SmMiLsnStaCfm      Status Confirm
     SmMiLsnTrcInd      Trace Indication

     For LSNINT3

     SmMiLsnCfgCfm      Configuration Confirm  
     SmMiLsnCntrlCfm    Control Confirm

It should be noted that not all of these functions may be required
by a particular layer management service user.

It is assumed that the following functions are provided in the
layer managment service user file:
  
     SmMiLsnCfgReq      Configure Request
     SmMiLsnStaReq      Status Request
     SmMiLsnStsReq      Statistics Request
     SmMiLsnCntrlReq    Control Request
  
*/
  

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "cm_ss7.h"
#include "ssi.h"           /* system services */
#include "lsn.h"           /* layer management, mtp 3 */
#include "smsn_err.h"      /* mtp 3 - error code */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"           /* general */
#include "lsn.x"           /* layer management, mtp 3 */

/* local defines */
#define SMSNDPC(usta) \
         ((U32) (usta.evntParm[3]   |   \
         (usta.evntParm[2] << 8)    |   \
         (usta.evntParm[1] << 16)   |   \
         (usta.evntParm[0] << 24)))

#ifdef SN_LMINT3
#define SMSNSAPID(usta) \
         ((U32) (usta.evntParm[1]   |   \
         (usta.evntParm[0] << 8))) 
#endif /* SN_LMINT3 */
 
/* local typedefs */
  
/* local externs */
#ifdef SN_ACCEPT_TEST
EXTERN Bool snLmQReqd;
EXTERN Queue mLyrRxQ;
#endif
/* forward references */
  
/* functions in other modules */

/* public variable declarations */

/* private variable declarations */


/*
*     support functions
*/


/*
*     interface functions to layer management service user
*/

/*
*
*       Fun:   Status Indication
*
*       Desc:  This function is used by the MTP 3 to present
*              unsolicited status information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smsnbdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsnStaInd
(
Pst *lmpst,              /* post structure */
SnMngmt *sta           /* unsolicited status */
)
#else
PUBLIC S16 SmMiLsnStaInd(lmpst, sta)
Pst *lmpst;              /* post structure */
SnMngmt *sta;          /* unsolicited status */
#endif
{
   Txt     pBuf[100];
   S16 ret1;
   Header *hdr;
   Buffer *mBuf;
   Pst *pst;

   TRC2(SmMiLsnStaInd)
 
   pst = lmpst;
#ifdef SMSN_FM
#if (SN_LMINT3 || SMSN_LMINT3)
   if((sta->t.usta.alarm.event == LSN_EVENT_PROT_ST_UP) ||
      (sta->t.usta.alarm.event == LSN_EVENT_PROT_ST_DN))
   {
      EXTERN Void fmHandleSnStaInd ARGS((U16 lnkNmb, U16 state));
 
      fmHandleSnStaInd(sta->hdr.elmId.elmntInst1, sta->t.usta.alarm.event);
   }
#else /* LMINT3 */
   if((sta->t.usta.evnt == PROT_ST_UP) || (sta->t.usta.evnt == PROT_ST_DN))
   {
      EXTERN Void fmHandleSnStaInd ARGS((U16 lnkNmb, U16 state));
 
      fmHandleSnStaInd(sta->hdr.elmId.elmntInst1, sta->t.usta.evnt);
   }
#endif /* LMINT3 */
#endif /* FM */

#ifdef SN_ACCEPT_TEST
   if (snLmQReqd)
   {
      ret1 = SGetMsg(lmpst->region, lmpst->pool, &mBuf);
      if (ret1 != ROK)
      {
         LSNLOGERROR(ERRCLS_ADD_RES, ESMXXX, (ErrVal) ret1,"SGetMsg failed");
         RETVALUE(ret1);
      }
#if (SN_LMINT3 || SMSN_LMINT3)
      CMCHKPKLOG(cmPkCmAlarm, &sta->t.usta.alarm, mBuf, ESMSN001, lmpst);
#else /* SN_LMINT3 || SMSN_LMINT3 */
      CMCHKPKLOG( SPkU16, sta->t.usta.evnt, mBuf, ESMSN002, lmpst);
#endif /* SN_LMINT3 || SMSN_LMINT3 */
      cmPkPst(lmpst, mBuf);
      SQueueLast(mBuf, &mLyrRxQ);
      RETVALUE(ROK);
   }
#endif

#ifdef SN_PERF
   RETVALUE(ROK);
#endif

   hdr = &sta->hdr;
   sprintf(pBuf, "[SMSN] SmMiLsnStaInd \n");
 
   switch(hdr->elmId.elmnt)
   {
      case STGEN:
         sprintf(pBuf, "[SMSN] STGEN\n");
         SPrint(pBuf);
         break;
 
      case STDLSAP:
         sprintf(pBuf, "[SMSN] STDLSAP Link = %d ",
                                          hdr->elmId.elmntInst1);
         SPrint(pBuf);
         break;
 
      case STROUT:
         sprintf(pBuf, "[SMSN] STROUT");
         SPrint(pBuf);
         break;
 
      default:
         sprintf(pBuf, "[SMSN] [UNKNOWN 0x%x] ",
                                              sta->hdr.elmId.elmnt);
         SPrint(pBuf);
         break;
 
  }
#if (SN_LMINT3 || SMSN_LMINT3)
  switch(sta->t.usta.alarm.event)
#else /* LMINT3 */
  switch(sta->t.usta.evnt)
#endif /* LMINT3 */
  {
      case LCM_EVENT_BND_OK:
          sprintf(pBuf, "LCM_EVENT_BND_OK : Bind OK\n");
          break;

      case LSN_EVENT_PROT_ST_UP:
          sprintf(pBuf, "LSN_PROT_ST_UP : Link Up\n");
          break;
 
      case LSN_EVENT_PROT_ST_DN:
          sprintf(pBuf, "LSN_PROT_ST_DN : Link Down\n");
          break;
 
      case LSN_EVENT_INH_DEN:
          sprintf(pBuf, "LSN_INH_DEN : Link Inhibit Denied\n");
          break;

      case LSN_EVENT_LOC_INH_ACK:
          sprintf(pBuf, "LSN_EVENT_LOC_INH_ACK: link inhibited locally\n");
          break;
     
      case LSN_EVENT_REM_INH_ACK:
          sprintf(pBuf, "LSN_EVENT_REM_INH_ACK: link inhibited remotely\n");
          break;
 
      case LSN_EVENT_LOC_UNINHED:
          sprintf(pBuf, "LSN_EVENT_LOC_UNINHED : link un-inhibited locally\n");
          break;
     
      case LSN_EVENT_REM_UNINHED:
          sprintf(pBuf, "LSN_EVENT_REM_UNINHED : link un-inhibited remotely\n");
          break;
 
      case LSN_EVENT_UNINH_DEN:
          sprintf(pBuf, "LSN_UNINH_DEN : Link Uninhibit Denied\n");
          break;
 
      case LSN_EVENT_RMT_BLKD:
          sprintf(pBuf, "LSN_UNINH_BLKD : Link Remotely Blocked\n"); 
          break;
 
      case LSN_EVENT_RMT_UNBLKD:
          sprintf(pBuf, "LSN_RMT_UNBLKED : Link Remotely Unblocked\n"); 
          break;
 
      case LSN_EVENT_PAUSE:
          sprintf(pBuf, "LSN_PAUSE : Concerned Dpc Pause 0x%lx\n",
                  SMSNDPC(sta->t.usta));
          break;
 
      case LSN_EVENT_RESUME:
          sprintf(pBuf, "LSN_RESUME : Concerned Dpc Resume 0x%lx\n", 
                       SMSNDPC(sta->t.usta));
          break;
 
      case LSN_EVENT_CONG:
         if (hdr->elmId.elmnt == STDLSAP)
            sprintf(pBuf, "LSN_CONG : link current congestion priority=%d\n",
                             sta->t.usta.evntParm[0]);
         else 
          sprintf(pBuf, "LSN_CONG : Concerned Dpc Network Congested\n");
          break;
 
      case LSN_EVENT_RMTUSRUNAV:
          sprintf(pBuf, "LSN_RMTUSRUNAV : Concerned Dpc Remote User Unavailable\n");
          break;
 
      case LSN_EVENT_STPCONG:
          sprintf(pBuf, "LSN_SPTCONG : Concerned Dpc Stop Network Congestion\n");
          break;
 
      case LSN_EVENT_SNT_INV:
          sprintf(pBuf, "LSN_SNT_INV : Invalid Event at SNT Interface\n"); 
          break;
 
      case LSN_EVENT_SDT_INV:
          sprintf(pBuf, "LSN_SDT_INV : Invalid Event at SDT Interface\n"); 
          break;
 
      case LSN_EVENT_SDT_INV_DATA_DRP:
          sprintf(pBuf, "LSN_SDT_INV_DAT_DRP : Invalid Data Dropped at SDT Interface\n");
          break;
 
      case LSN_EVENT_LOC_BLKD:
          sprintf(pBuf, "LSN_LOC_BLKD : Link Locally Blocked\n");
          break;
 
      case LSN_EVENT_LOC_UNBLKD:
          sprintf(pBuf, "LSN_LOC_UNBLKD : Link Locally Unblocked\n"); 
          break;
 
      case LSN_EVENT_LSNCFGREQ_OK:
          sprintf(pBuf, "LSN_LSNCFGREQ_OK : Configuration Success\n"); 
          break;
 
      case LSN_EVENT_LSNCFGREQ_NOK:
          sprintf(pBuf, "LSN_LSNCFGREQ_NOK : Configuration Failed \n");
          break;
 
      case LSN_EVENT_LSNSTAREQ_NOK:
          sprintf(pBuf, "LSN_LSNSTAREQ_NOK : Status Request Failed\n"); 
          break;
 
      case LSN_EVENT_LSNSTSREQ_NOK:
          sprintf(pBuf, "LSN_LSNSTSREQ_NOK : Statistics Request Failed\n"); 
          break;
 
      case LSN_EVENT_LSNCNTRLREQ_NOK:
          sprintf(pBuf, "LSN_LSNCNTRLREQ_NOK : Control Request Failed\n"); 
          break;
#if (SS7_TTC || SS7_NTT)
      case LSN_EVENT_SRTEST:
          if (sta->t.usta.evntParm[0] == LSN_SRT_PASSED)
          {
             sprintf(pBuf, "LSN_EVENT_SRTEST: Test Passed\n"); 
             SPrint(pBuf);
          }
          else 
          {
             sprintf(pBuf, "LSN_EVENT_SRTEST: Test Failed\n"); 
             SPrint(pBuf);
             sprintf(pBuf, "Failure reason : %d \n", sta->t.usta.evntParm[1]); 
             SPrint(pBuf);
          }
          if (hdr->elmId.elmnt == STDLSAP)
          {
             sprintf(pBuf, "[SMSN] STDLSAP Link = %d \n",
                                          hdr->elmId.elmntInst1);
             SPrint(pBuf);
          }
          else if (hdr->elmId.elmnt == STROUT)
          {
             Dpc dpc;
             U16 word1;
             U16 word2;
             sprintf(pBuf, "[SMSN] STROUT Linkset = %d \n",
                                          hdr->elmId.elmntInst1);

             SPrint(pBuf);
             word1 = (U16) PutHiByte(word1, sta->t.usta.evntParm[2]);
             word1 = (U16) PutLoByte(word1, sta->t.usta.evntParm[3]);
             word2 = (U16) PutHiByte(word2, sta->t.usta.evntParm[4]);
             word2 = (U16) PutLoByte(word2, sta->t.usta.evntParm[5]);
             dpc = (U32) PutLoWord(dpc, word2);
             dpc = (U32) PutHiWord(dpc, word1);
             sprintf(pBuf, "[SMSN] STROUT Dpc = 0x%lx \n", dpc);
             SPrint(pBuf);
          }
          break;
         
 
#endif 

      case LSN_EVENT_INV_SLC_OTHER_END:
          sprintf(pBuf, "LSN_INV_SLC_OTHER_END : Invalid SLC received.\n"); 
          break;

      case LSN_EVENT_INV_OPC_OTHER_END:
          sprintf(pBuf, "LSN_EVENT_INV_OPC_OTHER_END : Invalid OPC received.\n"); 
          break;

      case LSN_EVENT_CRE_HMAP_FLR:
          if (hdr->elmId.elmnt == STROUT)
          {
              sprintf(pBuf, "[SMSN] LSN_EVENT_CRE_HMAP_FLR: Concerned Dpc Pause 0x%lx\n",
                           SMSNDPC(sta->t.usta));
             SPrint(pBuf);
#ifdef SMSN_LMINT3
             sprintf(pBuf, "Alarm cause = %d \n", sta->t.usta.alarm.cause);
#endif
          }
          break;
      default:
#ifdef SMSN_LMINT3
          sprintf(pBuf, "[UNKNOWN EVENT = 0x%x]\n", sta->t.usta.alarm.event);
#else
          sprintf(pBuf, "[UNKNOWN EVENT = 0x%x]\n", sta->t.usta.evnt);
#endif
          break;
   }
   SPrint(pBuf);

   UNUSED(lmpst);
   UNUSED(sta); 
   RETVALUE(ROK);
} /* end of SmMiLsnStaInd */

    
/*
*
*       Fun:   Statistics Confirm
*
*       Desc:  This function is used by the MTP 3 to present
*              solicited statistics information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smsnbdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsnStsCfm
(
Pst *lmpst,              /* post structure */
Action action,         /* action */
SnMngmt *sts           /* confirmed statistics */
)
#else
PUBLIC S16 SmMiLsnStsCfm(lmpst, action, sts)
Pst *lmpst;              /* post structure */
Action action;         /* action */
SnMngmt *sts;          /* confirmed statistics */
#endif
{
   TRC2(SmMiLsnStsCfm)
   UNUSED(lmpst);
   UNUSED(action);
   UNUSED(sts);
   RETVALUE(ROK);
} /* end of SmMiLsnStsCfm */

    
/*
*
*       Fun:   Status Confirm
*
*       Desc:  This function is used by the MTP 3 to present
*              solicited status information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smsnbdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsnStaCfm
(
Pst *lmpst,              /* post structure */
SnMngmt *sta           /* confirmed statistics */
)
#else
PUBLIC S16 SmMiLsnStaCfm(lmpst, sta)
Pst *lmpst;              /* post structure */
SnMngmt *sta;          /* confirmed statistics */
#endif
{
   TRC2(SmMiLsnStaCfm)
   UNUSED(lmpst);
   UNUSED(sta);
   RETVALUE(ROK);
} /* end of SmMiLsnStaCfm */

  
/*
*
*       Fun:   Trace Indication
*
*       Desc:  This function is used by the MTP 3 to present trace
*              information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smsnbdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLsnTrcInd
(
Pst *lmpst,              /* post structure */
SnMngmt *trc           /* trace */
)
#else
PUBLIC S16 SmMiLsnTrcInd(lmpst, trc)
Pst *lmpst;              /* post structure */
SnMngmt *trc;          /* trace */
#endif
{
   char xdmbuf[256];
   int i;
 
   TRC2(SmMiLsnTrcInd)

   UNUSED(lmpst);
 
   if (trc->t.trc.evnt == LSN_MSG_RX)
   {
      sprintf(xdmbuf, "RECEIVED<%1d> : ", trc->hdr.elmId.elmntInst1);
   }
   else
   {
       sprintf(xdmbuf,"TRANSMIT<%1d> : ", trc->hdr.elmId.elmntInst1);
   }
 
   for (i=0; i< 15; i++)
   {
      sprintf(xdmbuf+14+i*3, "%2x ", trc->t.trc.evntParm[i]);
   }
 
   SPrint(xdmbuf);
   RETVALUE(ROK);
} /* end of SmMiLsnTrcInd */

  
/*
*
*       Fun:   Activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smsnbdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smSnActvInit
(
Ent ent,                      /* entity */
Inst inst,                    /* instance */
Region region,                /* region */
Reason reason                 /* reason */
)
#else
PUBLIC S16 smSnActvInit(ent, inst, region, reason)
Ent ent;                      /* entity */
Inst inst;                    /* instance */
Region region;                /* region */
Reason reason;                /* reason */
#endif
{
   TRC3(smSnActvInit)

   UNUSED(ent);
   UNUSED(inst);
   UNUSED(region);
   UNUSED(reason);

   RETVALUE(ROK);
} /* end of smSnActvInit */

#ifdef SMSN_LMINT3
/*
*
*       Fun:   Configuration Confirm
*
*       Desc:  This function is used by the MTP3 to present
*              configuration confirmation information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smsnbdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SmMiLsnCfgCfm
(
Pst *lmpst,
SnMngmt *cfm          /* confirm */
)
#else
PUBLIC S16 SmMiLsnCfgCfm(lmpst, cfm)
Pst *lmpst;
SnMngmt *cfm;         /* confirm */
#endif
{

   TRC2(SmMiLsnCfgCfm)
   UNUSED(lmpst);
   UNUSED(cfm);

   RETVALUE(ROK);
} /* end of SmMiLsnCfgCfm */


/*
*
*       Fun:   control Confirm
*
*       Desc:  This function is used by the MTP3 to present
*              control confirmation information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smsnbdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SmMiLsnCntrlCfm
(
Pst *lmpst,
SnMngmt *cfm          /* confirm */
)
#else
PUBLIC S16 SmMiLsnCntrlCfm(lmpst, cfm)
Pst *lmpst;
SnMngmt *cfm;         /* confirm */
#endif
{

   TRC2(SmMiLsnCntrlCfm)
   UNUSED(lmpst);
   UNUSED(cfm);

   RETVALUE(ROK);
} /* end of SmMiLsnCntrlCfm */
#endif /* SMSN_LMINT3 */


/********************************************************************30**
  
         End of file:     smsnbdy1.c@@/main/11 - Mon Apr  9 13:43:50 2001

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

 
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mc   1. initial release

1.2          ---  mc   1. text changes

1.3          ---  fmg  1. added ISS7_TST logic

1.4          ---  mc   1. print out all alarms in LsnStaInd.

1.5          ---  pm   1. added cm_gen.h, cm_ss7.h and cm_ss7.x in include files.

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------

1.6          ---      pm   1. added SMSNDPC macro and changed the printing
                              style of alarms.
             ---      pm   2. In SnMiLsnStaInd function, event is initialised
                              instead being compared.
             ---      pm   3. added SmMiLsnTrcInd function.
 
1.7          ---      pm   1. added SmMiLsnCfgCfm and SmMiLsnCntrlCfm
                              primitives for LMINT3.
             ---      pm   2. added SmMiLznCfgCfm, SmMiLznCntrlCfm,
                              SmMiLznStaCfm and SmMiLznStaInd primitives.
             ---      pm   3. removed cm_gen.[hx] files.
             ---      pm   4. removed SmMiLznCfgCfm, SmMiLznCntrlCfm,
                              SmMiLznStaCfm and SmMiLznStaInd primitives.
1.8          ---      sr   1. ifdef ISS7_TST removed.
1.9          ---      sr   1. cases for local/remote inhibit/uninhibit added.
/main/10     ---      sr   1. Handling for link congestion alarm provided
             ---      sr   1. Modifications for SRT related alarms
             ---      vk   1. Added alarms for LSN_INV_SLC_OTHER_END and
                              LSN_EVENT_INV_OPC_OTHER_END.
             ---      vk   1. Updated 'SmMiLsnStaInd' to take care of modified
                              'usta' structure for LMINT3 interface.
/main/11     ---      nb   1. Added primitive queing
                           2. New error codes
*********************************************************************91*/
