/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     stack manager - interface with MTP level 3 - error
  
     Type:     C include file
  
     Desc:     Error defines required by the stack manager.
   
     File:     smsn_err.h
  
     Sid:      smsn_err.h@@/main/5 - Mon Apr  9 13:43:45 2001
  
     Prg:      mc 
  
*********************************************************************21*/

#ifndef __SMSNERRH_
#define __SMSNERRH_


/* defines */
  
/* management interface - MTP level 3 error codes */

#define  ESMSNBASE   (ERRSMSN   + 0)   /* reserved */

#define  ESMSNXXX    (ESMSNBASE + 0)   /* reserved */

#define   ESMSN001      (ERRSMSN +    1)    /*   smsnbdy1.c: 240 */
#define   ESMSN002      (ERRSMSN +    2)    /*   smsnbdy1.c: 242 */

#define   ESMSN003      (ERRSMSN +    3)    /*   smsnexms.c: 243 */

#define   ESMSN004      (ERRSMSN +    4)    /*   smsnptmi.c: 434 */
#define   ESMSN005      (ERRSMSN +    5)    /*   smsnptmi.c: 473 */
#define   ESMSN006      (ERRSMSN +    6)    /*   smsnptmi.c: 514 */
#define   ESMSN007      (ERRSMSN +    7)    /*   smsnptmi.c: 554 */

#endif /* __SMSNERRH__*/


/********************************************************************30**

         End of file:     smsn_err.h@@/main/5 - Mon Apr  9 13:43:45 2001

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mc    1. initial release.

1.2          ---  mc    1. text change

1.3          ---  mc    1. miscellaneous changes

*********************************************************************81*/
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.4          ---      pm   1. regenerated the error codes.
/main/5      ---      nb   1. regenerated the error codes.  
*********************************************************************91*/

