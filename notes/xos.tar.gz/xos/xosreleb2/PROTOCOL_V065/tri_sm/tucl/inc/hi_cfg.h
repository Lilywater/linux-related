/* ***************************************************************************
 *        (c) COPYRIGHT 1995-2006 by Xinwei, Inc.
 *                   All rights reserved.
 *
 * hi_cfg.h:  
 *          this head file include all about use of tucl.
 *           
 * Author:
 *          zhouguishuang
 * Date:
 *          2006-5-8
 * Last Modified:
 *
 ****************************************************************************/
#ifndef  __HI_CFGH__
#define  __HI_CFGH__


#define  DEL_ENT                        0
#define  SEL_TC                         1
#define  SEL_LC                         0
#define  SB_PRNTBUF_SIZE                255
#define  SAP_1                          1
#define  SA3REGION                      DFLT_REGION      /* memory region id */
#define  SA3POOL                        DFLT_POOL        /* memory pool id */


#define SUID_0                  0
#define SUID_1                  1
#define SUID_2                  2
#define SUID_3                  3
#define SUID_4                  4

#define SPID_0                  0
#define SPID_1                  1
#define SPID_2                  2
#define SPID_3                  3
#define SPID_4                  4

/* defines for TUCL general configuration */
#define SO_TUCL_MAX_TSAP      5
#define SO_TUCL_MAX_CON       5000
#define SO_TUCL_FDS           1000
#define SO_TUCL_FDBINS        1000
#define SO_TUCL_STP_THRESH    5
#define SO_TUCL_DRP_THRESH    2
#define SO_TUCL_STRT_THRESH   4

/* defines for TUCL upper SAP configuration */
#define SO_TUCL_CONG_STRT     15000
#define SO_TUCL_CONG_DRP      20000
#define SO_TUCL_CONG_STP      10000
#define SO_TUCL_NMB_HLBINS    2


#define TUCL_PRINT_CONFIG_INFO    0x0001
#define TUCL_PRINT_LAYER_INFO     0x0002
#define TUCL_PRINT_SAP_INFO       0x0004
#define TUCL_PRINT_ALL_INFO       0x0008


#define SM_TUCLGENCFG_TBL           5

typedef struct  _hiCfgGenWG
{
   U32         numSaps;   /* max no. SAPS */
   U32         numCons;   /* max no. connections number */
}HiCfgGenWG;


typedef enum TUCL_CONFIG_QUEUE_ID
{
    TUCL_GEN_Q,
    TUCL_SAP_Q,
    TUCL_ROUTE_Q,
    TUCL_NID_DPC_Q,
    TUCL_STA_Q,
    TUCL_CTRL_Q,
    TUCL_STS_Q,    
    TUCL_CONFIG_Q_TOTAL_NUM
}TUCL_CONFIG_QUEUE_ID;


extern HiCfgGenWG  hiCfgGenWG;

extern U32 hiCfgTbl;



PUBLIC S16 hiSapCfg(void);
PUBLIC S16 hiGenCfg(void);

#ifdef CP_OAM_SUPPORT

extern CmLListCp   hiCmListSQ[];

S16  tucl_oam_config_gen(void);
S16 tucl_oam_config_saps(void);
S16 smHiSendReqQ(CmLList *node);
#endif

#endif /* __HI_CFGH__ */