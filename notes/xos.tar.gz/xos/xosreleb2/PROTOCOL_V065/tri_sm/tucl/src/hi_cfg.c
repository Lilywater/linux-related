
/* ***************************************************************************
 *        (c) COPYRIGHT 1995-2006 by Xinwei, Inc.
 *                   All rights reserved.
 *
 * sb_sample.c:  
 *          This file include the sample usage of sctp protocol.
 *           
 * Author:
 *          zhouguishuang
 * Date:
 *          2006-4-21
 * Last Modified:
 *
 ****************************************************************************/
 

#include "hi_common.h"
#include "hi_cfg.h"

#ifdef CP_OAM_SUPPORT
#include "xosshell.h"
#include "cp_tab_def.h"

#include "hi_oam.x"
#endif

HiCfgGenWG  hiCfgGenWG;
CmLListCp   hiCmListSQ[7]; /*[TUCL_CONFIG_Q_TOTAL_NUM];*/
#ifdef CP_OAM_SUPPORT
U32         hiCfgTbl= APP_TABLE_ID_VOIP_TUCL_GEN;
#endif

PUBLIC Void hiFillPst
(
Pst   *pst
)
  
{
   TRC2(hiFillPst)
   /*---------- Fill default values in Pst structure ----------*/
   pst->dstProcId = SFndProcId();
   pst->srcProcId = SFndProcId();
   pst->prior     = PRIOR0;
   pst->route     = RTESPEC;
   pst->event     = EVTNONE;
   pst->region    = DFLT_REGION; 
   pst->pool      = DFLT_POOL; 
   pst->selector  = SEL_LC;

   RETVOID;
}


void hiInitCfgData(void)
  
{
   TRC2(hiInitCfgData)

   hiCfgGenWG.numSaps = SO_TUCL_MAX_TSAP;
   hiCfgGenWG.numCons = SO_TUCL_MAX_CON;

   RETVOID;
}





/***************************************************************************
*
*       Fun:   hiGenCfgReq
*
*       Desc:  This function is used to do the Configuration of
*              the real TUCL layer
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  hi_cfg.c
*
*/

PUBLIC S16 hiGenCfgReq
(
TranId           transId          /* transaction ID */
)
{
   HiMngmt  cfg;         /* management structure */
   HiGenCfg *genCfg;
   Pst      pst;

   TRC2(hiGenCfgReq)

   /* clear the config structure first */
   cmMemset((U8 *)&cfg, 0, sizeof(HiMngmt));

   genCfg = &cfg.t.cfg.s.hiGen;

   /* prepare header */
   cfg.hdr.entId.ent   = ENTHI;       /* entity */
   cfg.hdr.entId.inst  = DEL_ENT;   /* instance */
   cfg.hdr.elmId.elmnt = STGEN;       /* general */
   cfg.hdr.transId     = transId;     /* transaction identifier */
#ifdef LCHIMILHI
   cfg.hdr.response.selector = SEL_LC; /* transaction identifier */
#else 
   cfg.hdr.response.selector = SEL_TC; /* transaction identifier */
#endif


   /* prepare the rest */
   genCfg->numSaps      = SO_TUCL_MAX_TSAP;
   genCfg->numCons      = SO_TUCL_MAX_CON;
   genCfg->numFdsPerSet = SO_TUCL_FDS;
   genCfg->numFdBins    = SO_TUCL_FDBINS;
   genCfg->permTsk      = TRUE;

   /* schdTmrVal is irrelevant since permTsk = TRUE */
   genCfg->schdTmrVal   = 0;
   genCfg->poolStrtThr  = SO_TUCL_STRT_THRESH;
   genCfg->poolDropThr  = SO_TUCL_DRP_THRESH;
   genCfg->poolStopThr  = SO_TUCL_STP_THRESH;

   /* timer resolution unused */
   genCfg->timeRes          = 0;

#ifdef HI006_12
   genCfg->selTimeout        = 10;
   genCfg->numRawMsgsToRead  = 240;
   genCfg->numUdpMsgsToRead  = 240;
   genCfg->numClToAccept     = 5;
#endif

   /*Post Structure*/
   genCfg->lmPst.dstProcId = SFndProcId();
   genCfg->lmPst.srcProcId = SFndProcId(); 
   genCfg->lmPst.dstEnt    = ENTSM;
   genCfg->lmPst.dstInst   = DEL_ENT;
   genCfg->lmPst.srcEnt    = ENTHI;
   genCfg->lmPst.srcInst   = DEL_ENT;
   genCfg->lmPst.prior     = PRIOR0;
   genCfg->lmPst.route     = RTESPEC;
   genCfg->lmPst.event     = EVTNONE;
   genCfg->lmPst.region    = DFLT_REGION; 
   genCfg->lmPst.pool      = DFLT_POOL; 
#ifdef LCHIMILHI
   genCfg->lmPst.selector  = SEL_LC;
#else 
   genCfg->lmPst.selector  = SEL_TC;
#endif

   hiFillPst(&pst);
   pst.srcEnt   = ENTSM;
   pst.srcInst  = DEL_ENT;
   pst.dstEnt   = ENTHI;
   pst.dstInst  = DEL_ENT;

   SmMiLhiCfgReq(&pst, &cfg);

   RETVALUE(ROK);
}/* hiGenCfgReq */

/***************************************************************************
*
*       Fun:   hiSapCfgReq
*
*       Desc:  This function is used to configure a TUCL layer
*              transport SAP
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  hi_cfg.c
*
*/

PUBLIC S16 hiSapCfgReq
(
TranId           transId,
SpId             spId,
U8               selector
)
{
   /* local variables */
   HiMngmt    cfg;          /* TUCL management structure */
   HiSapCfg   *sapCfg;
   Pst        pst;   

   TRC2(hiSapCfgReq)

   /* clear the config structure first */
   cmMemset((U8 *)&cfg, 0, sizeof(HiMngmt));

   /* prepare header */
   cfg.hdr.entId.ent   = ENTHI;            /* entity */
   cfg.hdr.entId.inst  = DEL_ENT;        /* instance */
   cfg.hdr.elmId.elmnt = STTSAP;           /* transport SAP */
#ifdef LCHIMILHI
   cfg.hdr.response.selector = SEL_LC; /* transaction identifier */
#else 
   cfg.hdr.response.selector = SEL_TC; /* transaction identifier */
#endif

   sapCfg = &cfg.t.cfg.s.hiSap;

   /* set the rest of the parameters */
   sapCfg->flcEnb          = FALSE;
   sapCfg->txqCongStrtLim  = SO_TUCL_CONG_STRT;
   sapCfg->txqCongDropLim  = SO_TUCL_CONG_DRP;
   sapCfg->txqCongStopLim  = SO_TUCL_CONG_STP;
   sapCfg->numBins         = SO_TUCL_NMB_HLBINS;
#ifdef LCHIUIHIT
   sapCfg->uiSel           = SEL_LC;
#else
   sapCfg->uiSel           = selector;
#endif
   sapCfg->uiMemId.region  = DFLT_REGION;   /* region */
   sapCfg->uiMemId.pool    = DFLT_POOL;     /* pool */
   sapCfg->uiPrior         = PRIOR0;        /* default priority */
   sapCfg->uiRoute         = RTESPEC;       /* default route */


   /* profile_1 : srvcType value = 3  */
   sapCfg->hdrInf[0].hdrLen = 20;
   sapCfg->hdrInf[0].offLen = 2;
   sapCfg->hdrInf[0].lenLen = 2;
   sapCfg->hdrInf[0].flag   = 0;

   /* profile_2 : srvcType value = 4  */
   sapCfg->hdrInf[1].hdrLen = 10;
   sapCfg->hdrInf[1].offLen = 2;
   sapCfg->hdrInf[1].lenLen = 2;
   sapCfg->hdrInf[1].flag   = 0;

   /* these parameters are dependant on the TSAP being configured */
   cfg.hdr.transId    = transId;
   sapCfg->spId       = spId;

     hiFillPst(&pst);
     pst.srcEnt   = ENTSM;
     pst.srcInst  = DEL_ENT;
     pst.dstEnt   = ENTHI;
     pst.dstInst  = DEL_ENT;

   SmMiLhiCfgReq(&pst, &cfg);

   RETVALUE(ROK);

}/* hiSapCfgReq()*/



/***************************************************************************
*
*       Fun:   hiSapCfg
*
*       Desc:  This function is use to config sap of tucl for user.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  hi_cfg.c
*
*/

PUBLIC S16 hiSapCfg(void)
{
   U16    id=0;
   U8     i=0;

   id=10011;
#if 0   
   hiSapCfgReq (10011, 0, SEL_LC);  
   
   hiSapCfgReq (10011, 1, SEL_LC);  
#endif
  
   for(i=0;i<SO_TUCL_MAX_TSAP;i++)
   {
     id += 200;
     hiSapCfgReq(id,
	 			 i, 
#ifdef LCHIUIHIT
	 			 SEL_LC
#else
                 6
#endif
				);
   }

   RETVALUE(ROK); 

}/* hiSapCfg */






/*
*
*       Fun:   hiSapCfg
*
*       Desc:  This function is use to config general config of tucl for user.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  hi_cfg.c
*
*/
PUBLIC S16 hiGenCfg(void)
{

   hiGenCfgReq (10017);
   RETVALUE(ROK);

}/* hiGenCfg()*/

#ifdef CP_OAM_SUPPORT
/************************************************************************
*
*       Fun:   tucl_oam_config_gen
*
*       Desc:  OAM ����TUCL������
*
*       Ret:   ROK      �ɹ�
*              RFAILED  ʧ��
*
*       Notes: None
*
*       File:  hi_cfg.c
*
*/
S16  tucl_oam_config_gen(void)
{
    HiMngmt      *hiMgmt;
    CmLList      *node;
    HiGenCfg     *genCfg;
    S16            ret = 0;

    TRC2(tucl_oam_config_saps);  
    
    SPrint("CONFIG GEN TUCL!\n");
    /* alloc a node for save sm msg info */
    if(ROK != (ret = smGetQNode(&node, sizeof(HiMngmt))))
    {
        RETVALUE(RFAILED);
    }
    hiMgmt = (HiMngmt *)cmLListNode(node) ;
    hiMgmt->hdr.msgLen = sizeof( HiMngmt);


    hiMgmt->hdr.msgType = TCFG; 
    hiMgmt->hdr.transId = 0;


   genCfg = &hiMgmt->t.cfg.s.hiGen;

   /* prepare header */
   hiMgmt->hdr.entId.ent   = ENTHI;       /* entity */
   hiMgmt->hdr.entId.inst  = DEL_ENT;   /* instance */
   hiMgmt->hdr.elmId.elmnt = STGEN;       /* general */
#ifdef LCHIMILHI
   hiMgmt->hdr.response.selector = SEL_LC; /* transaction identifier */
#else 
   hiMgmt->hdr.response.selector = SEL_TC; /* transaction identifier */
#endif


   /* prepare the rest */
   genCfg->numSaps      = hiCfgGenWG.numSaps;
   genCfg->numCons      = hiCfgGenWG.numCons;
   genCfg->numFdsPerSet = SO_TUCL_FDS;
   genCfg->numFdBins    = SO_TUCL_FDBINS;
   genCfg->permTsk      = TRUE;

   /* schdTmrVal is irrelevant since permTsk = TRUE */
   genCfg->schdTmrVal   = 0;
   genCfg->poolStrtThr  = SO_TUCL_STRT_THRESH;
   genCfg->poolDropThr  = SO_TUCL_DRP_THRESH;
   genCfg->poolStopThr  = SO_TUCL_STP_THRESH;

   /* timer resolution unused */
   genCfg->timeRes          = 0;

#ifdef HI006_12
   genCfg->selTimeout        = 10; 
   genCfg->numRawMsgsToRead  = 240;
   genCfg->numUdpMsgsToRead  = 240;
   genCfg->numClToAccept     = 5;
#endif

   /*Post Structure*/
   genCfg->lmPst.dstProcId = SFndProcId();
   genCfg->lmPst.srcProcId = SFndProcId(); 
   genCfg->lmPst.dstEnt    = ENTSM;
   genCfg->lmPst.dstInst   = DEL_ENT;
   genCfg->lmPst.srcEnt    = ENTHI;
   genCfg->lmPst.srcInst   = DEL_ENT;
   genCfg->lmPst.prior     = PRIOR0;
   genCfg->lmPst.route     = RTESPEC;
   genCfg->lmPst.event     = EVTNONE;
   genCfg->lmPst.region    = DFLT_REGION; 
   genCfg->lmPst.pool      = DFLT_POOL; 
#ifdef LCHIMILHI
   genCfg->lmPst.selector  = SEL_LC;
#else 
   genCfg->lmPst.selector  = SEL_TC;
#endif
   
    cmLListAdd2Tail(&hiCmListSQ[TUCL_GEN_Q], node);

    RETVALUE(ROK);
}


/************************************************************************
*
*       Fun:   tucl_oam_config_saps
*
*       Desc:  OAM ����TUCL SAP�㺯����
*
*       Ret:   ROK      �ɹ�
*              RFAILED  ʧ��
*
*       Notes: None
*
*       File:  hi_cfg.c
*
*/
S16 tucl_oam_config_saps(void)
{
    HiMngmt     *hiMgmt;
    CmLList     *node;
    HiSapCfg    *sapCfg; 
    S16            ret = 0;
    U8      i=0;
	
    TRC2(tucl_oam_config_saps);     
    printf("TUCL CONFIG SAP!\n");
   
   
   for(i=1;i<= hiCfgGenWG.numSaps ;i++)
   {
        /* alloc a node for save sm msg info */
        if(ROK !=( ret = smGetQNode(&node, sizeof(HiMngmt))))
        {
            RETVALUE(RFAILED);
        }        
        hiMgmt = (HiMngmt *)cmLListNode(node) ;
        hiMgmt->hdr.msgLen = sizeof(HiMngmt);
        
        hiMgmt->hdr.msgType = TCFG; 
        hiMgmt->hdr.transId=0;

	   hiMgmt->hdr.entId.ent   = ENTHI;            /* entity */
	   hiMgmt->hdr.entId.inst  = DEL_ENT;        /* instance */
	   hiMgmt->hdr.elmId.elmnt = STTSAP;           /* transport SAP */
	#ifdef LCHIMILHI
	   hiMgmt->hdr.response.selector = SEL_LC; /* transaction identifier */
	#else 
	   hiMgmt->hdr.response.selector = SEL_TC; /* transaction identifier */
	#endif

	   sapCfg = &hiMgmt->t.cfg.s.hiSap;

	   /* set the rest of the parameters */
	   sapCfg->flcEnb          = FALSE;
	   sapCfg->txqCongStrtLim  = SO_TUCL_CONG_STRT;
	   sapCfg->txqCongDropLim  = SO_TUCL_CONG_DRP;
	   sapCfg->txqCongStopLim  = SO_TUCL_CONG_STP;
	   sapCfg->numBins         = SO_TUCL_NMB_HLBINS;
	#ifdef LCHIUIHIT
	   sapCfg->uiSel           = SEL_LC;
	#else
	   sapCfg->uiSel           = 6;
	#endif
	   sapCfg->uiMemId.region  = DFLT_REGION;   /* region */
	   sapCfg->uiMemId.pool    = DFLT_POOL;     /* pool */
	   sapCfg->uiPrior         = PRIOR0;        /* default priority */
	   sapCfg->uiRoute         = RTESPEC;       /* default route */


	   /* profile_1 : srvcType value = 3  */
	   sapCfg->hdrInf[0].hdrLen = 20;
	   sapCfg->hdrInf[0].offLen = 2;
	   sapCfg->hdrInf[0].lenLen = 2;
	   sapCfg->hdrInf[0].flag   = 0;

	   /* profile_2 : srvcType value = 4  */
	   sapCfg->hdrInf[1].hdrLen = 10;
	   sapCfg->hdrInf[1].offLen = 2;
	   sapCfg->hdrInf[1].lenLen = 2;
	   sapCfg->hdrInf[1].flag   = 0;

	   /* these parameters are dependant on the TSAP being configured */

	   sapCfg->spId       = i-1;

       cmLListAdd2Tail(&hiCmListSQ[TUCL_SAP_Q], node);
   }
   

    RETVALUE(ROK);
}


PUBLIC  Void  hiSetSmPstV
(
Pst *smPst
)
{
#ifdef LCHIMILHI
   smPst->selector  = SEL_LC;
#else
   smPst->selector  = SEL_TC;
#endif

   smPst->dstProcId = SFndProcId();
   smPst->srcProcId = SFndProcId();
   smPst->dstEnt    = ENTHI;
   smPst->dstInst   = DEF_ENT;
   smPst->srcEnt    = ENTSM;
   smPst->srcInst   = DEF_ENT;
   smPst->prior     = PRIOR0;
   smPst->route     = RTESPEC;
   smPst->region    = DFLT_REGION;
   smPst->pool      = DFLT_POOL;
}  


/************************************************************************
*
*       Fun:   smHiSendReqQ
*
*       Desc:  ����������������
*
*       Ret:   ROK      �ɹ�
*              RFAILED  ʧ��
*
*       Notes: None
*
*       File:  hi_cfg.c
*
*/
S16 smHiSendReqQ(CmLList *node)
{
    Pst smHiPst;
    Header *msgHeader;
    S16 ret = ROK;
 
	

    TRC2(smHiSendReqQ);      
    msgHeader = (Header *)cmLListNode(node);


    hiSetSmPstV(&smHiPst);
    switch(msgHeader->msgType)
    {
        case TCFG:
            ret = SmMiLhiCfgReq(&smHiPst, (HiMngmt *)cmLListNode(node));
            break;

        default:
            break;
    }

    RETVALUE(ret);
}
#endif /*CP_OAM_SUPPORT*/

/********************************************************************30**

         End of file:     hi_cfg.c@@/main/2 - 2006-05-11

*********************************************************************31*/