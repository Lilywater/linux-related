/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     TCP UDP Convegence Layer Sample Stack Manager
  
     Type:     C source file
  
     Desc:     Sample code for Management Interface primitives supplied 
               by TRILLIUM
              
     File:     smhibdy1.c
  
     Sid:      smhibdy1.c@@/main/3 - Thu Jun 28 13:28:28 2001

     Prg:      asa
  
*********************************************************************21*/

/*
Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.

The following functions are provided in this file for the
layer management service user:
  
     SmMiLhiStaInd      Status Indication
     SmMiLhiStsCfm      Statistics Confirm
     SmMiLhiStaCfm      Status Confirm
     SmMiLhiAcntInd     Accounting Indication
     SmMiLhiTrcInd      Trace Indication

It should be noted that not all of these functions may be required
by a particular layer management service user.

It is assumed that the following functions are provided in the
layer managment service user file:
  
     SmMiLhiCfgReq      Configure Request
     SmMiLhiStaReq      Status Request
     SmMiLhiStsReq      Statistics Request
     SmMiLhiCntrlReq    Control Request
  
*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_inet.h"       /* common sockets */
#include "cm_hash.h"       /* common hashing */
#include "cm_err.h"        /* common error */
#include "cm5.h"           /* common timer */
#include "cm_tpt.h"        /* common transport defines */
#include "lhi.h"           /* layer management, HI Layer */

#ifdef HI_ACC
#include "hi_acc.h"        /* acceptance */
#else 
#ifdef HC_ACC
/* hi002.104 - deleted H.323 include files */
#include "hc_acc.h"
#else
#ifdef HG_ACC
#include "cm_tkns.h"       /* common tokens */
#include "cm_llist.h"      /* llist mgmt*/
#include "cm_mblk.h"       /* common memory alloc */
#include "cm32x.h"         /* encoding/decoding */
#include "cm_pasn.h"
#include "cm_dns.h"
#include "lhgt.h"
#include "hgt.h"
#include "lhg.h"
#include "hg_acc.h"        /* acceptance */
#else
#ifdef SO_ACC
#include "cm_tkns.h"       /* common tokens */
#include "cm_sdp.h"        /* common SDP */
#include "cm_mblk.h"       /* common memory allocation */
#include "sot.h"           /* SOT interface */
#include "lso.h"           /* layer management, SIP  */
/*#include "so_acc.h"*/    /* defines for SIP test layer */
#endif /* SO_ACC */
#endif /* HG_ACC */
#endif /* HC_ACC */
#endif /* HI_ACC */

#include "smhi_err.h"      /* Stack Manager - error */

/* common header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_inet.x"       /* common sockets */
#include "cm_hash.x"       /* common hashing */
#include "cm5.x"           /* common timer */
#include "cm_tpt.x"        /* common transport typedefs */
#include "lhi.x"           /* layer management, HI layer */

#ifdef HI_ACC
#include "hi_acc.x"        /* acceptance */
#else
#ifdef HC_ACC
/* hi002.104 - deleted H.323 include files */
#include "hc_acc.x"        /* H.323 acceptance test */
#else
#ifdef HG_ACC
#include "cm_tkns.x"       /* common tokens */
#include "cm_llist.x"      /* llist mngmt */
#include "cm_lib.x"        /* commmon Library */
#include "cm_mblk.x"       /* common memory alloc */
#include "cm32x.x"         /* encoding/decoding */
#include "cm_pasn.x"
#include "cm_xtree.x"
#include "cm_dns.x"
#include "lhgt.x"
#include "hgt.x"
#include "lhg.x"
#include "hg_acc.x"
#else
#ifdef SO_ACC
#include "cm_lib.x"        /* common library */
#include "cm_tkns.x"       /* common tokens */
#include "cm_sdp.x"        /* common SDP */
#include "cm_mblk.x"       /* common memory allocation */
#include "sot.x"           /* SOT interface */
#include "lso.x"           /* layer management, SIP  */
/*#include "so_acc.x"*/    /* typedefs for SIP test layer */
#endif /* SO_ACC */

#endif /* HG_ACC */ 
#endif /* HC_ACC */
#endif /* HI_ACC */


/* local typedefs */
  
/* private variable declarations */ 


/*
*     interface functions to layer management service user
*/
/*
*
*       Fun:   Configuration Confirm
*
*       Desc:  This function is used by to present configuration confirm
*              information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smhibdy1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 SmMiLhiCfgCfm
(
Pst     *pst,          /* post structure */
HiMngmt *cfm           /* configuration */
)
#else
PUBLIC S16 SmMiLhiCfgCfm(pst, cfm)
Pst     *pst;          /* post structure */
HiMngmt *cfm;          /* configuration */
#endif
{
   TRC2(SmMiLhiCfgCfm)

#ifdef HI_ACC 
   (Void)hiAccProcCfgCfm(pst, cfm);
#else
#ifdef HC_ACC
   (Void)hcAccProcLhiCfgCfm(pst, cfm);
#else
#ifdef HG_ACC
   (Void)hgAccHndlLhiCfgCfm(cfm);
#else
#ifdef SO_ACC
   (Void) soAccProcLhiCfgCfm(pst, cfm);
#endif
#endif
#endif
#endif

   RETVALUE(ROK);
} /* end of SmMiLhiCfgCfm */


/*
*
*       Fun:   Control Confirm
*
*       Desc:  This function is used by to present control confirm
*              information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smhibdy1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 SmMiLhiCntrlCfm
(
Pst     *pst,          /* post structure */
HiMngmt *cfm           /* control */
)
#else
PUBLIC S16 SmMiLhiCntrlCfm(pst, cfm)
Pst     *pst;          /* post structure */
HiMngmt *cfm;          /* control */
#endif
{
 
   TRC2(SmMiLhiCntrlCfm)
 
#ifdef HI_ACC 
   (Void)hiAccProcCntrlCfm(pst, cfm);
#else
#ifdef HC_ACC
   (Void)hcAccProcLhiCntrlCfm(pst, cfm);
#else
#ifdef HG_ACC
   (Void)hgAccHndlCntrlCfm((HgMngmt *) cfm);
#else
#ifdef SO_ACC
   (Void)soAccProcLhiCntrlCfm(pst, cfm);
#endif
#endif
#endif
#endif

   RETVALUE(ROK);
} /* end of SmMiLhiCntrlCfm */

    
/*
*
*       Fun:   Status Indication
*
*       Desc:  This function is used by to present  unsolicited status 
*              information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smhibdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLhiStaInd
(
Pst     *pst,           /* post structure */
HiMngmt *usta           /* unsolicited status */
)
#else
PUBLIC S16 SmMiLhiStaInd(pst, usta)
Pst     *pst;           /* post structure */
HiMngmt *usta;          /* unsolicited status */
#endif
{

   TRC2(SmMiLhiStaInd)

#ifdef HI_ACC 
   (Void)hiAccProcStaInd(pst, usta);
#else
#ifdef HC_ACC
   (Void)hcAccProcLhiStaInd(pst, usta);
#else
#ifdef HG_ACC
   (Void)hgAccHndlLhiStaInd((HiMngmt *) usta);
#else
#ifdef SO_ACC
   (Void)soAccProcLhiStaInd(pst, usta);
#endif
#endif
#endif
#endif

   RETVALUE(ROK);
} /* end of SmMiLhiStaInd */


  
/*
*
*       Fun:   Trace Indication
*
*       Desc:  This function is used to present trace
*              information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smhibdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLhiTrcInd
(
Pst *pst,               /* post structure */
HiMngmt *trc,           /* trace */
Buffer *mBuf            /* message buffer */
)
#else
PUBLIC S16 SmMiLhiTrcInd(pst, trc, mBuf)
Pst *pst;               /* post structure */
HiMngmt *trc;           /* trace */
Buffer *mBuf;           /* message buffer */
#endif
{
   TRC2(SmMiLhiTrcInd)

#ifdef HI_ACC 
   (Void)hiAccProcTrcInd(pst, trc, mBuf);
#else
#ifdef HC_ACC
   (Void)hcAccProcLhiTrcInd(pst, trc, mBuf);
#else
#ifdef HG_ACC
   (Void)hgAccHndlLhiTrcInd((HiMngmt *) trc, mBuf);
#else
#ifdef SO_ACC
   (Void)soAccProcLhiTrcInd(pst, (HiMngmt *) trc, mBuf);
#endif
#endif 
#endif
#endif

   RETVALUE(ROK);
} /* end of SmMiLhiTrcInd */

    
/*
*
*       Fun:   Statistics Confirm
*
*       Desc:  This function is used to present solicited statistics 
*              information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smhibdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLhiStsCfm
(
Pst       *pst,         /* post structure */
HiMngmt   *sts          /* confirmed statistics */
)
#else
PUBLIC S16 SmMiLhiStsCfm(pst, sts)
Pst       *pst;         /* post structure */
HiMngmt   *sts;         /* confirmed statistics */
#endif
{
   TRC2(SmMiLhiStsCfm)

#ifdef HI_ACC 
   (Void)hiAccProcStsCfm(pst, sts);
#else
#ifdef HC_ACC
   (Void)hcAccProcLhiStsCfm(pst, sts);
#else
#ifdef HG_ACC
   (Void)hgAccHndlLhiStsCfm((HiMngmt *) sts);
#else
#ifdef SO_ACC
   (Void)soAccProcLhiStsCfm(pst, (HiMngmt *) sts);
#endif
#endif
#endif
#endif
 
   RETVALUE(ROK);
} /* end of SmMiLhiStsCfm */

    
/*
*
*       Fun:   Status Confirm
*
*       Desc:  This function is used to present solicited status 
*              information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smhibdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLhiStaCfm
(
Pst     *pst,           /* post structure */
HiMngmt *sta             /* confirmed status */
)
#else
PUBLIC S16 SmMiLhiStaCfm(pst, sta)
Pst     *pst;           /* post structure */
HiMngmt *sta;            /* confirmed status */
#endif
{
   TRC2(SmMiLhiStaCfm)

#ifdef HI_ACC 
   (Void)hiAccProcStaCfm(pst, sta);
#else
#ifdef HC_ACC
   (Void)hcAccProcLhiStaCfm(pst, sta);
#else
#ifdef HG_ACC
   (Void)hgAccHndlLhiStaCfm((HiMngmt *) sta);
#else
#ifdef SO_ACC
   (Void)soAccProcLhiStaCfm(pst, (HiMngmt *) sta);
#endif
#endif
#endif
#endif

   RETVALUE(ROK);
} /* end of SmMiLhiStaCfm */

  
/*
*
*       Fun:   Activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smhibdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smHiActvInit
(
Ent ent,                      /* entity */
Inst inst,                    /* instance */
Region region,                /* region */
Reason reason                 /* reason */
)
#else
PUBLIC S16 smHiActvInit(ent, inst, region, reason)
Ent ent;                      /* entity */
Inst inst;                    /* instance */
Region region;                /* region */
Reason reason;                /* reason */
#endif
{
   TRC3(smHiActvInit);

   UNUSED(region);
   UNUSED(reason);
   UNUSED(ent);
   UNUSED(inst);

   RETVALUE(ROK);
} /* end of smHiActvInit */


/********************************************************************30**
 
         End of file:     smhibdy1.c@@/main/3 - Thu Jun 28 13:28:28 2001

*********************************************************************31*/
 
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      asa  1. initial release.
/main/2       ---      cvp  1. changed HC to HC_ACC.
                          2. changed the copyright header. 
/main/2+    hi002.13 cvp  1. Annex G related changes.
/main/2+    hi006.13 asa  1. SIP related additions.
/main/3      ---      cvp 1. Release with multi-threaded TUCL.
/main/3+    hi002.104 an  1. Removed H.323 core header file 
*********************************************************************91*/
