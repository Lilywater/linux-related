/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     stack manager - portable MAP interface files.
  
     Type:     C source file
  
     Desc:     C source code for the MAP layer management
               service user primitives used in loosely coupled
               systems.

     File:     smmaptmi.c
  
     Sid:      smmaptmi.c@@/main/9 - Fri Sep 16 02:41:12 2005
   
     Prg:      ssk
  
*********************************************************************21*/
  

/*
  
Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.

The following functions are provided in this file:

     SmMiLmaCfgReq      Configure Request
     SmMiLmaStaReq      Status Request
     SmMiLmaStsReq      Statistics Request
     SmMiLmaCntrlReq    Control Request
   
It is assumed that the following functions are provided in the
stack management body files:

     SmMiLmaCfgCfm      Configuration Confirm
     SmMiLmaCntrlCfm    Control Confirm
     SmMiLmaStaCfm      Status Confirm
     SmMiLmaStsCfm      Statistics Confirm
     SmMiLmaStaInd      Status Indication
     SmMiLmaTrcInd      Trace Indication
   
*/   

/*
*     This software may be used with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000093     SS7 - MAP
*
*/



/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "cm5.h"           /* common timer */
#include "ssi.h"           /* system services */
#include "lma.h"           /* inap layer management */
#include "cm_err.h"        /* common error */
#include "smma_err.h"      /* inap error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* common timer */
#include "cm_ss7.x"        /* SS7 Common */
#include "lma.x"           /* inap layer management */
  

/* local defines */
#ifndef LCSMMAMILMA
#define PTSMMAMILMA   1      /* portable MA LM interface */
#else
#ifndef MA
#define PTSMMAMILMA   1      /* portable MA LM interface */
#endif
#endif

 
/* local typedefs */
  
/* local externs */
  
/* forward references */

#ifdef PTSMMAMILMA
PRIVATE S16 PtMiLmaCfgReq   ARGS((Pst *pst, MaMngmt *cfg));
PRIVATE S16 PtMiLmaStaReq   ARGS((Pst *pst, MaMngmt *sta));
PRIVATE S16 PtMiLmaStsReq   ARGS((Pst *pst, Action action, MaMngmt *sts));
PRIVATE S16 PtMiLmaCntrlReq ARGS((Pst *pst, MaMngmt *cntrl));
#endif

/* public variable declarations */
 
/* private variable declarations */

/*
the following matrices define the mapping between the primitives
called by the layer management interface of MAP and the corresponding
primitives in MAP.
 
The parameter MAXMAMI defines the maximum number of layer manager entities
on top of MAP. There is an array of functions per primitive invoked by 
MAP. Every array is MAXMAMI long (i.e. there are as many functions as the
number of service users).
 
The dispatching is performed by the configurable variable: selector.
The selector is configured during general configuration.
 
The selectors are:
 
   0 - loosely coupled (#define LCSMMAMILMA)
   2 - Lma (#define MA)
 
*/

/* Configuration request primitive */
 
PRIVATE LmaCfgReq SmMiLmaCfgReqMt[MAXMAMI] =
{
#ifdef LCSMMAMILMA
   cmPkLmaCfgReq,        /* 0 - loosely coupled  */
#else
   PtMiLmaCfgReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef MA
   MaMiLmaCfgReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLmaCfgReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Statistics request primitive */
 
PRIVATE LmaStsReq SmMiLmaStsReqMt[MAXMAMI] =
{
#ifdef LCSMMAMILMA
   cmPkLmaStsReq,        /* 0 - loosely coupled  */
#else
   PtMiLmaStsReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef MA
   MaMiLmaStsReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLmaStsReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Status request primitive */
 
PRIVATE LmaStaReq SmMiLmaStaReqMt[MAXMAMI] =
{
#ifdef LCSMMAMILMA
   cmPkLmaStaReq,        /* 0 - loosely coupled  */
#else
   PtMiLmaStaReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef MA
   MaMiLmaStaReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLmaStaReq,          /* 1 - tightly coupled, portable */
#endif
};

/* Control request primitive */
 
PRIVATE LmaCntrlReq SmMiLmaCntrlReqMt[MAXMAMI] =
{
#ifdef LCSMMAMILMA
   cmPkLmaCntrlReq,        /* 0 - loosely coupled  */
#else
   PtMiLmaCntrlReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef MA
   MaMiLmaCntrlReq,          /* 1 - tightly coupled, layer management */
#else
   PtMiLmaCntrlReq,          /* 1 - tightly coupled, portable */
#endif
};

/*
*     layer management interface functions 
*/
 
/*
*
*       Fun:   Configuration request
*
*       Desc:  This function is used to configure MAP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smmaptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLmaCfgReq
(
Pst *pst,                 /* post structure */
MaMngmt *cfg              /* configure */
)
#else
PUBLIC S16 SmMiLmaCfgReq(pst, cfg)
Pst *pst;                 /* post structure */   
MaMngmt *cfg;             /* configure */
#endif
{
   TRC3(SmMiLmaCfgReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLmaCfgReqMt[pst->selector])(pst, cfg); 
   RETVALUE(ROK);
} /* end of SmMiLmaCfgReq */

/*
*
*       Fun:   Status request
*
*       Desc:  This function is used to send a status request to MAP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smmaptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLmaStaReq
(
Pst *pst,                 /* post structure */
MaMngmt *sta              /* status */
)
#else
PUBLIC S16 SmMiLmaStaReq(pst, sta)
Pst *pst;                 /* post structure */   
MaMngmt *sta;             /* status */
#endif
{
   TRC3(SmMiLmaStaReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLmaStaReqMt[pst->selector])(pst, sta); 
   RETVALUE(ROK);
} /* end of SmMiLmaStaReq */

/*
*
*       Fun:   Statistics request
*
*       Desc:  This function is used to request statistics from MAP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smmaptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLmaStsReq
(
Pst *pst,                 /* post structure */
Action action,
MaMngmt *sts              /* statistics */
)
#else
PUBLIC S16 SmMiLmaStsReq(pst, action, sts)
Pst *pst;                 /* post structure */   
Action action;
MaMngmt *sts;             /* statistics */
#endif
{
   TRC3(SmMiLmaStsReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLmaStsReqMt[pst->selector])(pst, action, sts); 
   RETVALUE(ROK);
} /* end of SmMiLmaStsReq */

/*
*
*       Fun:   Control request
*
*       Desc:  This function is used to send control request to MAP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smmaptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLmaCntrlReq
(
Pst *pst,                 /* post structure */
MaMngmt *cntrl            /* control */
)
#else
PUBLIC S16 SmMiLmaCntrlReq(pst, cntrl)
Pst *pst;                 /* post structure */   
MaMngmt *cntrl;           /* control */
#endif
{
   TRC3(SmMiLmaCntrlReq)
   /* jump to specific primitive depending on configured selector */
   (*SmMiLmaCntrlReqMt[pst->selector])(pst, cntrl); 
   RETVALUE(ROK);
} /* end of SmMiLmaCntrlReq */


#ifdef PTSMMAMILMA

/*
*
*       Fun:   Portable configure Request MAP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smmaptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLmaCfgReq
(
Pst *pst,                   /* post structure */
MaMngmt *cfg                /* configure */
)
#else
PRIVATE S16 PtMiLmaCfgReq(pst, cfg)
Pst *pst;                   /* post structure */
MaMngmt *cfg;               /* configure */
#endif
{
  TRC3(PtMiLmaCfgReq);

  UNUSED(cfg);

#if (ERRCLASS & ERRCLS_DEBUG)
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, \
             __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal)ESMMA014, 
             (ErrVal)0, "PtMiLmaCfgReq () Failed"); 
#endif

  RETVALUE(ROK);
} /* end of PtMiLmaCfgReq */


/*
*
*       Fun:   Portable status Request MAP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smmaptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLmaStaReq
(
Pst *pst,                   /* post structure */
MaMngmt *sta                /* status */
)
#else
PRIVATE S16 PtMiLmaStaReq(pst, sta)
Pst *pst;                   /* post structure */
MaMngmt *sta;               /* status */
#endif
{
  TRC3(PtMiLmaStaReq);

  UNUSED(sta);

#if (ERRCLASS & ERRCLS_DEBUG)
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, \
             __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal)ESMMA015, 
             (ErrVal)0, "PtMiLmaStaReq () Failed"); 
#endif

  RETVALUE(ROK);
} /* end of PtMiLmaStaReq */


/*
*
*       Fun:   Portable statistics Request MAP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smmaptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLmaStsReq
(
Pst *pst,                   /* post structure */
Action action,
MaMngmt *sts                /* statistics */
)
#else
PRIVATE S16 PtMiLmaStsReq(pst, action, sts)
Pst *pst;                   /* post structure */
Action action;
MaMngmt *sts;               /* statistics */
#endif
{
  TRC3(PtMiLmaStsReq);

  UNUSED(sts);

#if (ERRCLASS & ERRCLS_DEBUG)
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, \
             __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal)ESMMA016, 
             (ErrVal)0, "PtMiLmaStsReq () Failed"); 
#endif

  RETVALUE(ROK);
} /* end of PtMiLmaStsReq */


/*
*
*       Fun:   Portable control Request MAP
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smmaptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLmaCntrlReq
(
Pst *pst,                   /* post structure */
MaMngmt *cntrl              /* control */
)
#else
PRIVATE S16 PtMiLmaCntrlReq(pst, cntrl)
Pst *pst;                   /* post structure */
MaMngmt *cntrl;             /* control */
#endif
{
  TRC3(PtMiLmaCntrlReq);

  UNUSED(cntrl);

#if (ERRCLASS & ERRCLS_DEBUG)
   SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, \
             __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal)ESMMA017, 
             (ErrVal)0, "PtMiLmaCntrlReq () Failed"); 
#endif

  RETVALUE(ROK);
} /* end of PtMiLmaCntrlReq */

#endif /* PTSMMAMILMA */


/********************************************************************30**

         End of file:     smmaptmi.c@@/main/9 - Fri Sep 16 02:41:12 2005

*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa    1. initial release
1.2          ---  aa    1. Changed the packing function for ApnCfg strcuture

*********************************************************************81*/
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.3          ---      aa   1. Removed cm1.[hx] and cm5.[hx] from the include list
                              as it is not required.
1.4          ---      ssk  1. Changes for adding the MAP Phase 2+ variant
                              and for adding LMINT3.

/main/5      ---      ssk  1. update for MAP 1.5 release.

/main/6      ---      ssk  1. update for MAP 1.6 release.

/main/7      ---      jie  1. update for MAP 1.7 release.

/main/8      ---      cp   1. update for MAP 2.1 release.
/main/9      ---      st   1. Updated copyright Info.
*********************************************************************91*/
 
