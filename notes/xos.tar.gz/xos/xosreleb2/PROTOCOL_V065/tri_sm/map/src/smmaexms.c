/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     stack manager MAP extended mos
  
     Type:     C source file
  
     Desc:     Activation point for MAP Stack Manager and unpacking
               functions.

     File:     smmaexms.c
  
     Sid:      smmaexms.c@@/main/10 - Fri Sep 16 02:40:58 2005
  
     Prg:      sg
  
*********************************************************************21*/
  
  
/*
Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.
*/
  
  
/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"
#include "cm_ss7.h"
#include "cm_err.h"        /* common error */
#include "stu.h"           /* tcap upper interface */
#include "mat.h"           /* inap upper interface */
#ifdef MA_FTHA
#include "sht.h"
#endif /* MA_FTHA */
#include "lma.h"           /* layer management interface */
#ifdef MATST
#include "ma_acc.h"        /* acceptance test defines */
#endif /*MATST*/
#include "ma.h"
#include "ma_err.h"        /* error defines */
#include "smma_err.h"      /* error defines */
#include "ma_mf.h"
#ifdef ZJ
#include "cm_ftha.h"       /* Common FTHA */
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#include "cm_tupsf.h"      /* Common TCAP user PSF */
#include "zj_acc.h"        /* PSF acceptance test */
#endif /* ZJ */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"
#include "cm_ss7.x"        /* Common */
#include "cm_lib.x"        /* Common library headers */
#include "stu.x"           /* tcap upper interface */
#include "lma.x"           /* layer management interface */
#include "mat.x"           /* inap upper interface */
#ifdef MA_FTHA
#include "sht.x"
#endif /* MA_FTHA */
#ifdef ZJ
#include "cm_ftha.x"       /* Common FTHA */
#include "cm_pftha.x"      /* Common PSF defines */
#include "cm_psfft.x"
#include "cm_tupsf.x"      /* Common TCAP user PSF */
#include "lzj.x"           /* PSF MAP */
#endif
#include "ma.x"
#ifdef MATST
#include "ma_acc.x"        /* acceptance test defines */
#endif /*MATST*/

  
/* local defines */

/* local typedefs */
  
/* local externs */
  
/* forward references */
  

/*
*
*       Fun:    activate task
*
*       Desc:   Processes received event from MAP
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   smmaexms.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smMaActvTsk
(
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 smMaActvTsk(pst, mBuf)
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   S16           ret = ROK; /* return value from the function */

   switch(pst->event)
   {
#ifdef LCSMMAMILMA
      case MA_EVTLMASTACFM:             /* Status Confirm */
         if ((ret = cmUnpkLmaStaCfm(SmMiLmaStaCfm, pst, mBuf)) != ROK)
         {
            RETVALUE(ret);
         }
         break;

      case MA_EVTLMASTSCFM:             /* Statistics Confirm */
         if ((ret = cmUnpkLmaStsCfm(SmMiLmaStsCfm, pst, mBuf)) != ROK)
         {
            RETVALUE(ret);
         }
         break;

      case MA_EVTLMASTAIND:             /* Status Indication */
         if ((ret = cmUnpkLmaStaInd(SmMiLmaStaInd, pst, mBuf)) != ROK)
         {
            RETVALUE(ret);
         }
         break;

      case MA_EVTLMATRCIND:             /* Trace Indication */
         if ((ret = cmUnpkLmaTrcInd(SmMiLmaTrcInd, pst, mBuf)) != ROK)
         {
            RETVALUE(ret);
         }
         break;

      case MA_EVTLMACFGCFM:             /* Configuration Confirm */
         cmUnpkLmaCfgCfm(SmMiLmaCfgCfm, pst, mBuf);
         break;
 
      case MA_EVTLMACNTRLCFM:           /* Control Confirm */
         cmUnpkLmaCntrlCfm(SmMiLmaCntrlCfm, pst, mBuf);
         break;
#endif /* LCSMMAMILMA */

      default:
#ifdef ZJ
         smZjActvTsk(pst, mBuf);
#else /* ZJ */
         UNUSED(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
         SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, \
                   __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal)ESMMA013, 
                   (ErrVal)pst->event, "smMaActvTsk () Failed"); 
#endif
#endif /* ZJ */
         break;
   }

   SExitTsk();

   RETVALUE(ret);

} /* end of smMaActvTsk */

  
/********************************************************************30**
  
         End of file:     smmaexms.c@@/main/10 - Fri Sep 16 02:40:58 2005

*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa    1. initial release

1.2          --   aa    1. Changed from #ifdef MAP_XXX to #if MAP_XXX

*********************************************************************81*/
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.3          ---      aa   1. Changed the unpacking order in StaInd function to
                               make it consistent with other unpacking routines.
             ---      aa   2. Change the flag from LCSMSTMILST to LCSMMAMILMA

1.4          ---      ssk  1. Changes for adding the MAP Phase 2+ variant
                              and for adding LMINT3

/main/5      ---      ssk  1. update for MAP 1.5 release.
 
             ---      jie  1. Rolling Upgrade compliance.

             ---      yz   1. Use flag MATST to not include ma_acc
                              header file in non-acceptance test.

/main/6      ---      ssk  1. update for MAP 1.6 release.

/main/7      ---      jie  1. update for MAP 1.6 release.

/main/9      ---      cp   1. update for MAP 2.2 release.
/main/10     ---      st   1. Updated Copyright Info.
*********************************************************************91*/
