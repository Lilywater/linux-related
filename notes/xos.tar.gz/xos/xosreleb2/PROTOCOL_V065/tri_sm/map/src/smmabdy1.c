/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     stack manager MAP body 1
  
     Type:     C source file
  
     Desc:     Prototype C source code for the Layer Management
               service provider primitives that usually are supplied
               by the customer.
               This is the version used for the MAP sample code test.

     File:     smmabdy1.c
  
     Sid:      smmabdy1.c@@/main/9 - Fri Sep 16 02:40:43 2005
  
     Prg:      hrg
  
*********************************************************************21*/
  
  
/*
  
Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.

The following functions are provided in this file for the
layer management service user:
  
     SmMiLmaCfgCfm      Configuration Confirm
     SmMiLmaCntrlCfm    Control Confirm
     SmMiLmaStaCfm      Status Confirm
     SmMiLmaStsCfm      Statistics Confirm
     SmMiLmaStaInd      Status Indication
     SmMiLmaTrcInd      Trace Indication
  

It is assumed that the following functions are provided in the
stack management file smmaptmi.c.
  
     SmMiLmaCfgReq      Configure Request
     SmMiLmaStaReq      Status Request
     SmMiLmaStsReq      Statistics Request
     SmMiLmaCntrlReq    Control Request
  
*/
  
  
/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_err.h"        /* common error */
#include "cm_ss7.h"        /* common ss7 */
#include "stu.h"           /* tcap layer */
#include "mat.h"           /* mat interface layer */
#ifdef MA_FTHA
#include "sht.h"
#endif /* MA_FTHA */
#include "cm5.h"           /* common timer */
#include "lma.h"           /* layer management */
#include "ma.h"            /* inap layer */
#ifdef MATST
#include "ma_acc.h"        /* acceptance */
#endif /*MATST*/
#include "smma_err.h"      /* Stack Manager - MAP interface - error */
#ifdef ZJ
#include "cm_ftha.h"       /* Common FTHA */
#include "cm_pftha.h"      /* Common PSF defines */
#include "cm_psfft.h"
#include "cm_tupsf.h"      /* Common TCAP user PSF */
#include "zj_acc.h"        /* PSF acceptance test */
#endif /* ZJ */

/* common header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common */
#include "stu.x"           /* tcap layer */
#include "lma.x"           /* layer management */
#include "mat.x"           /* mat interface layer */
#ifdef MA_FTHA
#include "sht.x"
#endif /* MA_FTHA */
#include "cm5.x"           /* common timer */
#ifdef ZJ
#include "cm_ftha.x"       /* Common FTHA */
#include "cm_pftha.x"      /* Common PSF defines */
#include "cm_psfft.x"
#include "cm_tupsf.x"      /* Common TCAP user PSF */
#endif
#include "ma.x"            /* inap layer */
#ifdef MATST
#include "ma_acc.x"        /* acceptance */
#endif /*MATST*/

/* local typedefs */
  
/* local externs */
EXTERN S16 smMaActvInit ARGS((Ent ent,Inst inst,Region region,Reason reason));
#ifdef MATST
EXTERN MaAccCb   maAccCb;     /* MAP Acceptance test CB */
#endif /* MATST */

/* private variable declarations */
PRIVATE Void smMaPrntSBuf ARGS((Data *buffer, U16 len));

/* Macro to print date and time */
#define SMMAPRNTDT(_dt)                                                     \
{                                                                           \
   SPrint("DateTime =");                                                    \
   sprintf(prntBuf, "%d:%d:%d::%d   %d/%d/%d\n", _dt->hour, _dt->min,       \
                 _dt->sec, _dt->tenths, _dt->month, _dt->day, _dt->year);   \
   SPrint(prntBuf);                                                         \
}

#define SMMAPRNTDURATION(_du)                                               \
{                                                                           \
   SPrint("Duration =");                                                    \
   sprintf(prntBuf, "Days %d, Hours %d, Mins %d, Secs %d, Tenths %d\n",     \
              _du->days, _du->hours,_du->mins, _du->secs, _du->tenths);     \
   SPrint(prntBuf);                                                         \
}

#define MAX_MA_STRING   (255)

#ifdef MATST
#define LM_GETMSG(p, m, e) {                                          \
    S16   ret;                                                        \
                                                                      \
    ret = SGetMsg((p)->region, (p)->pool, &(m));                      \
    if (ret != ROK)                                                   \
    {                                                                 \
        SLogError(0, 0, 0,  __FILE__, __LINE__, ERRCLS_DEBUG, e, 0,   \
                      "SGetMsg failed");                              \
        RETVALUE(ret);                                                \
    }                                                                 \
  }
#endif /* MATST */
  
/* functions in other modules */
#ifdef MATST
EXTERN  Queue   *maAccLmRxQ;     /* Acceptance Test LM message receive queue */
#endif /* MATST */

#define PrntCntr(x) \
   if(s->x > 0)\
   {\
   sprintf(prntBuf, "%s \t %7lu\n", #x,s->x);\
   SPrint(prntBuf);\
   }


/* 
* support functions
*/

/*
*
*       Fun:   smMaPrntSBuf 
*
*       Desc:  This routines prints the static buffer
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  smmabdy1.c
*
*/
  
#ifdef ANSI
PRIVATE Void smMaPrntSBuf 
(
Data  *str,  /* static string */
U16   len    /* length */
)
#else
PRIVATE Void smMaPrntSBuf (str, len)
Data  *str;  /* static string */
U16   len;   /* length */
#endif
{
   Txt  prntBuf[MAX_MA_STRING];   /* Buffer to print */
   U16  i;                   /* counter */
   U16  j;                   /* counter */
   U8   data;                /* data */
   U16  tCount;              /* temporary counter */
   Data *msg;                /* message pointer */
 
   TRC2(smMaPrntSBuf)

   if (str == NULLP)
   {
      RETVOID;
   }

   tCount = len;
   msg    = str;
 
   SPrint("\n");
   sprintf(prntBuf, "   message size: %4d\n", len);
 
   if (len == 0)
   {
      return;
   }
 
   SPrint(prntBuf);
   SPrint("\n   ");

   j = 0;
   i = 0;
 
   while (1)
   {
      if (tCount > 0)
      {
         data = msg[i];
 
         if (j < 16)
         {
            /* print the hex values first */
            sprintf(prntBuf, "%02x ", data);
            SPrint(prntBuf);
         }
         else
         {
            j = 0;
 
            /* for the next line, print three preceeding spaces */
            SPrint("\n   ");
 
            continue;
         }
 
      }
      else
      {
         break;
      }
 
      i++;
      j++;
 
      tCount--;
 
   } /* end while */
 
   SPrint("\n");
   SPrint("\n");
 
} /* smMaPrntSBuf */

  
/*
*     interface functions to layer management service user
*/

    
/*
*
*       Fun:   Status Indication
*
*       Desc:  This function is used by to present  unsolicited status 
*              information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smmabdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLmaStaInd
(
Pst     *pst,            /* post structure */
MaMngmt *usta            /* unsolicited status */
)
#else
PUBLIC S16 SmMiLmaStaInd(pst, usta)
Pst     *pst;            /* post structure */
MaMngmt *usta;           /* unsolicited status */
#endif
{
   #ifdef MATST
   EXTERN MaAccCb     maAccCb;   /* MAP Acceptance Test control block */
   #endif
   Txt          prntBuf[MAX_MA_STRING];   /* Buffer to print */
   DateTime     *dt;                      /* date and time when alarm rxd */

   CmAlarm      *alm;                     /* alarm */
   MaUsta       *info;                    /* status information */

   TRC2(SmMiLmaStaInd)

   UNUSED(pst);

   SPrint("Unsolicited Status Indication Received \n");
   alm  = &usta->t.usta.alarm;

   /* print the date and time */
   dt   = &alm->dt;
   SMMAPRNTDT(dt);
  
   sprintf(prntBuf, "Category = %d, Event = %d, Cause = %d\n",              \
                                     alm->category, alm->event, alm->cause);
#ifdef MATST
{
   CmAlarm *alarmtmp = &maAccCb.alarm;
   cmCopy ((U8 *)alm, (U8 *)alarmtmp, sizeof (CmAlarm));
}
#endif /* MATST */
   SPrint(prntBuf);
#ifdef MA_RUG
   sprintf(prntBuf, "Layer manager interface version = %d\n", pst->intfVer);
   SPrint(prntBuf);
#endif

   /* print the unsolicited status */
   info = &usta->t.usta.info;
   SPrint("----- Unsolicited Status Information -----\n");
   sprintf(prntBuf, "sapId     = %d\n", info->sapId);
   SPrint(prntBuf);
   sprintf(prntBuf, "dlgId     = %ld\n", info->dlgId);
   SPrint(prntBuf);
   sprintf(prntBuf, "invokeId  = %d\n", info->invokeId);
   SPrint(prntBuf);
   sprintf(prntBuf, "state     = %d\n", info->state);
   SPrint(prntBuf);
   sprintf(prntBuf, "oprCode   = %d\n", info->oprCode);
   SPrint(prntBuf);
   sprintf(prntBuf, "param     = %ld\n", info->param);
   SPrint(prntBuf);
   sprintf(prntBuf, "Memory Region   = %d\n", info->mem.region);
   SPrint(prntBuf);
   sprintf(prntBuf, "Memory Pool     = %d\n", info->mem.pool);
   SPrint(prntBuf);

#if (MAP_SEC && LMAV2)
   if (info->secUsta.plmnId.mcc.pres == TRUE)
   {
      sprintf(prntBuf, "plmnId(mcc)  = %d\n", info->secUsta.plmnId.mcc.val);
      SPrint(prntBuf);
   }
   if (info->secUsta.plmnId.mnc.pres == TRUE)
   {
      sprintf(prntBuf, "plmnId(mnc)  = %d\n", info->secUsta.plmnId.mnc.val);
      SPrint(prntBuf);
   }
   sprintf(prntBuf, "secSpi          = %ld\n",info->secUsta.secSpi);
   SPrint(prntBuf);
   sprintf(prntBuf, "cmpType         = %d\n",info->secUsta.cmpId.cmpType);
   SPrint(prntBuf);
   sprintf(prntBuf, "cmpVal          = %d\n",info->secUsta.cmpId.cmpVal.oprCode);
   SPrint(prntBuf);
   sprintf(prntBuf, "acName          = %d\n",info->secUsta.acName);
   SPrint(prntBuf);
   sprintf(prntBuf, "acVer           = %d\n",info->secUsta.acVer);
   SPrint(prntBuf);
#endif
   SPrint("----- Unsolicited Status Information -----\n");

   RETVALUE(ROK);
} /* end of SmMiLmaStaInd */


  
/*
*
*       Fun:   Trace Indication
*
*       Desc:  This function is used by MAP to present trace
*              information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smmabdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLmaTrcInd
(
Pst *pst,                /* post structure */
MaMngmt *trc             /* trace */
)
#else
PUBLIC S16 SmMiLmaTrcInd(pst, trc)
Pst *pst;                /* post structure */
MaMngmt *trc;            /* trace */
#endif
{
   Txt         prntBuf[MAX_MA_STRING];  /* buffer to print */
   DateTime    *dt;                     /* date and time */

   TRC2(SmMiLmaTrcInd)

   UNUSED(pst);

   dt  = &trc->t.trc.dt;
   SMMAPRNTDT(dt);

   SPrint("----- Trace Indication -----\n");
   sprintf(prntBuf, "Trace Indication: Event = %d\n",trc->t.trc.evnt);
   SPrint(prntBuf);
   /* print the static buffer received */
   smMaPrntSBuf(trc->t.trc.evntParm, trc->t.trc.len);
   SPrint("----- Trace Indication -----\n");

   RETVALUE(ROK);
} /* end of SmMiLmaTrcInd */

    
/*
*
*       Fun:   Statistics Confirm
*
*       Desc:  This function is used by the MAP to present
*              solicited statistics information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smmabdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLmaStsCfm
(
Pst       *pst,          /* post structure */
Action    action,        /* Action - zero the statistics */
MaMngmt   *sts           /* confirmed statistics */
)
#else
PUBLIC S16 SmMiLmaStsCfm(pst, action, sts)
Pst       *pst;          /* post structure */
Action    action;        /* Action - zero the statistics */
MaMngmt   *sts;          /* confirmed statistics */
#endif
{
   Txt        prntBuf[PRNTSZE];      /* print buffer */
   DateTime   *dt;                   /* date and time when status is rxd */
   Duration   *dura;                 /* duration */
   MaMAUSts   *s;                  /* sap statistics */
#ifdef MATST
   Buffer    *mBuf;
#endif

   TRC2(SmMiLmaStsCfm)
   
   UNUSED(pst);

   if (sts->cfm.status == LCM_PRIM_OK)
   {
      dt   = &sts->t.sts.dt;
      SMMAPRNTDT(dt);
     
      dura = &sts->t.sts.dura;
   
      s = &sts->t.sts.maMAUSts;
   
      SMMAPRNTDURATION(dura);
   
      sprintf(prntBuf, "Type        \t   Rx      \t   Tx \n");
      SPrint(prntBuf);
      sprintf(prntBuf, "----------- \t -------   \t ------- \n");
      SPrint(prntBuf);
      sprintf(prntBuf, "OPEN REQ \t %7lu   \t %7lu\n",
      s->openReqRx, s->openReqTx);
      SPrint(prntBuf);
      sprintf(prntBuf, "CLOSE REQ \t %7lu   \t %7lu\n",
      s->closeRx, s->closeTx);
      SPrint(prntBuf);
      sprintf(prntBuf, "OPEN RSP \t %7lu   \t %7lu\n",
      s->openRspRx, s->openRspTx);
      SPrint(prntBuf);
      sprintf(prntBuf, "ABRT REQ \t %7lu   \t %7lu\n",
      s->abrtRx, s->abrtRx);
      SPrint(prntBuf);


#if (MAP_MSC || MAP_VLR || MAP_HLR)
      PrntCntr(regSSReqTx);     /* Register SS request transmitted */
      PrntCntr(regSSReqRx);     /* Register SS request Received */
      PrntCntr(regSSRspTx);     /* Register SS response transmitted */
      PrntCntr(regSSRspRx);     /* Register SS response Received */
      PrntCntr(regSSReTx);      /* Register SS ret.error transmitted */
      PrntCntr(regSSReRx);      /* Register SS ret.error Received */
   
      PrntCntr(eraseSSReqTx);    /* Erase SS request transmitted */
      PrntCntr(eraseSSReqRx);    /* Erase SS request Received */
      PrntCntr(eraseSSRspTx);    /* Erase SS response transmitted */
      PrntCntr(eraseSSRspRx);    /* Erase SS response Received */
      PrntCntr(eraseSSReTx);     /* Erase SS ret.error transmitted */
      PrntCntr(eraseSSReRx);     /* Erase SS ret.error Received */
   
      PrntCntr(actvSSReqTx);     /* Activate SS request transmitted */
      PrntCntr(actvSSReqRx);     /* Activate SS request Received */
      PrntCntr(actvSSRspTx);     /* Activate SS response transmitted */
      PrntCntr(actvSSRspRx);     /* Activate SS response Received */
      PrntCntr(actvSSReTx);      /* Activate SS ret.error transmitted */
      PrntCntr(actvSSReRx);      /* Activate SS ret.error Received */
   
      PrntCntr(dactvSSReqTx);     /* Deactivate SS request transmitted */
      PrntCntr(dactvSSReqRx);     /* Deactivate SS request Received */
      PrntCntr(dactvSSRspTx);     /* Deactivate SS response transmitted */
      PrntCntr(dactvSSRspRx);     /* Deactivate SS response Received */
      PrntCntr(dactvSSReTx);      /* Deactivate SS ret.error transmitted */
      PrntCntr(dactvSSReRx);      /* Deactivate SS ret.error Received */
   
      PrntCntr(interSSReqTx);     /* Interogate SS request transmitted */
      PrntCntr(interSSReqRx);     /* Interogate SS request Received */
      PrntCntr(interSSRspTx);     /* Interogate SS response transmitted */
      PrntCntr(interSSRspRx);     /* Interogate SS response Received */
      PrntCntr(interSSReTx);      /* Interrogate SS ret.error transmitted */
      PrntCntr(interSSReRx);      /* Interrogate SS ret.error Received */
   
      PrntCntr(regPasswdReqTx);    /* Register Password request transmitted */
      PrntCntr(regPasswdReqRx);    /* Register Password request Received */
      PrntCntr(regPasswdRspTx);    /* Register Password response transmitted */
      PrntCntr(regPasswdRspRx);    /* Register Password response Received */
      PrntCntr(regPasswdReTx);     /* Register Password ret.error transmitted */
      PrntCntr(regPasswdReRx);     /* Register Password ret.error Received */
   
      PrntCntr(getPasswdReqTx);    /* Get Password request transmitted */
      PrntCntr(getPasswdReqRx);    /* Get Password request Received */
      PrntCntr(getPasswdRspTx);    /* Get Password response transmitted */
      PrntCntr(getPasswdRspRx);    /* Get Password response Received */
      PrntCntr(getPasswdReTx);     /* Get Password ret.error transmitted */
      PrntCntr(getPasswdReRx);     /* Get Password ret.error Received */
   
      PrntCntr(procUSSDatReqTx);   /* Process USS  request transmitted */
      PrntCntr(procUSSDatReqRx);   /* Process USS request Received */
      PrntCntr(procUSSDatRspTx);   /* Process USS response transmitted */
      PrntCntr(procUSSDatRspRx);   /* Process USS response Received */
      PrntCntr(procUSSDatReTx);    /* Process USS ret.error transmitted */
      PrntCntr(procUSSDatReRx);    /* Process USS ret.error Received */
   
      PrntCntr(procUSSReqTx);      /* Process USS  Data request transmitted */
      PrntCntr(procUSSReqRx);      /* Process USS Data request Received */
      PrntCntr(procUSSRspTx);      /* Process USS Data response transmitted */
      PrntCntr(procUSSRspRx);      /* Process USS Data response Received */
      PrntCntr(procUSSReTx);      /* Process USS Data ret.error transmitted */
      PrntCntr(procUSSReRx);     /* Process USS Data ret.error Received */
   
      PrntCntr(ussReqTx);          /* USS  request transmitted */
      PrntCntr(ussReqRx);          /* USS request Received */
      PrntCntr(ussRspTx);          /* USS response transmitted */
      PrntCntr(ussRspRx);          /* USS response Received */
      PrntCntr(ussReTx);         /* USS ret.error transmitted */
      PrntCntr(ussReRx);           /* USS ret.error Received */
   
      PrntCntr(ussNotReqTx);       /* USS Notify request transmitted */
      PrntCntr(ussNotReqRx);       /* USS Notify request Received */
      PrntCntr(ussNotRspTx);       /* USS Notify response transmitted */
      PrntCntr(ussNotRspRx);       /* USS Notify response Received */
      PrntCntr(ussNotReTx);        /* USS Notify Ret.Err transmitted */
      PrntCntr(ussNotReRx);        /* USS Notify Ret.Err Received */
   
      PrntCntr(fwdChkSSIndReqTx);     /* Forward Chk SS Ind. request transmitted */
      PrntCntr(fwdChkSSIndReqRx);     /* Forward Chk SS Ind. request Received */
   
      PrntCntr(regCcEntReqTx);     /*reg Cc Ent req Tx */
      PrntCntr(regCcEntReqRx);     /*reg Cc Ent req Rx */
      PrntCntr(regCcEntRspTx);     /*reg Cc Ent rsp Tx */
      PrntCntr(regCcEntRspRx);     /*reg Cc Ent rsp Rx */
      PrntCntr(regCcEntReTx);      /*reg Cc Ent re Tx */
      PrntCntr(regCcEntReRx);      /*reg Cc Ent re Rx */
   
      PrntCntr(eraseCcEntReqTx);     /*erase Cc Ent req Tx */
      PrntCntr(eraseCcEntReqRx);     /*erase Cc Ent req Rx */
      PrntCntr(eraseCcEntRspTx);     /*erase Cc Ent rsp Tx */
      PrntCntr(eraseCcEntRspRx);     /*erase Cc Ent rsp Rx */
      PrntCntr(eraseCcEntReTx);      /*erase Cc Ent re Tx */
      PrntCntr(eraseCcEntReRx);      /*erase Cc Ent re Rx */
   
#endif /* MSC || VLR || HLR */
   
#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
      PrntCntr(smRdyReqTx);       /* SM Ready request transmitted */
      PrntCntr(smRdyReqRx);       /* SM Ready request Received */
      PrntCntr(smRdyRspTx);       /* SM Ready response transmitted */
      PrntCntr(smRdyRspRx);       /* SM Ready response Received */
      PrntCntr(smRdyReTx);       /* SM Ready re. transmitted */
      PrntCntr(smRdyReRx);       /* SM Ready re. Received */
#endif /* (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN) */


#if (MAP_MSC || MAP_VLR)
      PrntCntr(detIMSIReqTx);         /* Detach IMSI request transmitted */
      PrntCntr(detIMSIReqRx);         /* Detach IMSI request Received */
   
   
      PrntCntr(trSubReqTx);           /* Trace Sub Activity request transmitted */
      PrntCntr(trSubReqRx);           /* Trace Sub Activity request Received */

#endif /* MAP_MSC || MAP_VLR */

#if (MAP_MSC || MAP_VLR || MAP_GSN)
      PrntCntr(chkIMEIReqTx);         /* Check IMEI request transmitted */
      PrntCntr(chkIMEIReqRx);         /* Check IMEI request Received */
      PrntCntr(chkIMEIRspTx);         /* Check IMEI response transmitted */
      PrntCntr(chkIMEIRspRx);         /* Check IMEI response Received */
      PrntCntr(chkIMEIReTx);          /* Check IMEI ret.err Tx */
      PrntCntr(chkIMEIReRx);          /* Check IMEI ret.err Rx */
   
#endif /* (MAP_MSC || MAP_VLR || MAP_GSN) */

#if (MAP_MSC || MAP_HLR)
      PrntCntr(routInfoReqTx);        /* Send Rout Info request transmitted */
      PrntCntr(routInfoReqRx);        /* Send Rout Info request Received */
      PrntCntr(routInfoRspTx);        /* Send Rout Info response transmitted */
      PrntCntr(routInfoRspRx);        /* Send Rout Info response Received */
      PrntCntr(routInfoReTx);         /* Send Rout Info ret.error transmitted */
      PrntCntr(routInfoReRx);         /* Send Rout Info ret.error Received */
   
      PrntCntr(routInfoSMReqTx);      /* Send Rout Info for SM request transmitted */
      PrntCntr(routInfoSMReqRx);      /* Send Rout Info for SM request Received */
      PrntCntr(routInfoSMRspTx);      /* Send Rout Info for SM response transmitted */
      PrntCntr(routInfoSMRspRx);      /* Send Rout Info for SM response Received */
      PrntCntr(routInfoSMReTx);        /* Send Rout Info  ret.error transmitted */
      PrntCntr(routInfoSMReRx);        /* Send Rout Info  ret.error Received */
   
      PrntCntr(smDelReqTx);           /* SM Delivery request transmitted */
      PrntCntr(smDelReqRx);           /* SM Delivery request Received */
      PrntCntr(smDelRspTx);           /* SM Delivery response transmitted */
      PrntCntr(smDelRspRx);           /* SM Delivery response Received */
      PrntCntr(smDelReTx);            /* SM Delivery  ret.error transmitted */
      PrntCntr(smDelReRx);            /* SM Delivery  ret.error Received */
   
      PrntCntr(alrtSCReqTx);           /* Alert Service Center request transmitted */
      PrntCntr(alrtSCReqRx);           /* Alert Service Center request Received */
      PrntCntr(alrtSCRspTx);           /* Alert Service Center response transmitted */
      PrntCntr(alrtSCRspRx);           /* Alert Service Center response Received */
      PrntCntr(alrtSCReTx);            /* Alert Service Center re transmitted */
      PrntCntr(alrtSCReRx);            /* Alert Service Center re Received */
      PrntCntr(alrtSCWRsltReqTx);      /* Alert SC Without Result request tx */
      PrntCntr(alrtSCWRsltReqRx);      /* Alert SC Without Result request Received */
   
      PrntCntr(infSCReqTx);           /* Inform Service Center request transmitted */
      PrntCntr(infSCReqRx);           /* Inform Service Center request Received */

#endif

#if (MAP_VLR || MAP_HLR || MAP_GSN )
      PrntCntr(canLocReqTx);        /* Cancel Location request transmitted */
      PrntCntr(canLocReqRx);        /* Cancel Location request Received */
      PrntCntr(canLocRspTx);        /* Cancel Location request transmitted */
      PrntCntr(canLocRspRx);        /* Cancel Location request Received */
      PrntCntr(canLocReTx);        /* Cancel Location re. transmitted */
      PrntCntr(canLocReRx);        /* Cancel Location re. Received */
   
      PrntCntr(purgMsReqTx);        /* Purge Ms request transmitted */
      PrntCntr(purgMsReqRx);        /* Purge Ms request Received */
      PrntCntr(purgMsRspTx);        /* Purge Ms response transmitted */
      PrntCntr(purgMsRspRx);        /* Purge Ms response Received */
      PrntCntr(purgMsReTx);        /* Purge Ms re. transmitted */
      PrntCntr(purgMsReRx);        /* Purge Ms re. Received */
   
      PrntCntr(authInfReqTx);       /* Authintication Info request transmitted */
      PrntCntr(authInfReqRx);       /* Authintication Info request Received */
      PrntCntr(authInfRspTx);       /* Authintication Info response transmitted */
      PrntCntr(authInfRspRx);       /* Authintication Info response Received */
      PrntCntr(authInfReTx);        /* Authentication Info ret.error transmitte*/
      PrntCntr(authInfReRx);        /* Authentication Info ret.error Received */
   
      PrntCntr(insSubReqTx);        /* Insert Subscriber Data request transmitted */
      PrntCntr(insSubReqRx);        /* Insert Subscriber Data request Received */
      PrntCntr(insSubRspTx);        /* Insert Subscriber Data response transmitted */
      PrntCntr(insSubRspRx);        /* Insert Subscriber Data response Received */
      PrntCntr(insSubReTx);      /* Insert Subscriber Data ret.error tx */
      PrntCntr(insSubReRx);      /* Insert Subscriber Data ret.error Received */
   
      PrntCntr(delSubReqTx);        /* Delete Subscriber Data request transmitted */
      PrntCntr(delSubReqRx);        /* Delete Subscriber Data request Received */
      PrntCntr(delSubRspTx);        /* Delete Subscriber Data response transmitted */
      PrntCntr(delSubRspRx);        /* Delete Subscriber Data response Received */
      PrntCntr(delSubReTx);         /* Delete Subscriber Data ret err transmitted */
      PrntCntr(delSubReRx);         /* Delete Subscriber Data ret err Received*/
   
      PrntCntr(resetReqTx);         /* Reset request transmitted */
      PrntCntr(resetReqRx);         /* Reset request Received */
   
      PrntCntr(actvTrReqTx);         /* Activate trace request transmitted */
      PrntCntr(actvTrReqRx);         /* Activate trace request Received */
      PrntCntr(actvTrRspTx);         /* Activate trace Response transmitted */
      PrntCntr(actvTrRspRx);         /* Activate trace response Received */
      PrntCntr(actvTrReTx);         /* Activate trace re. transmitted */
      PrntCntr(actvTrReRx);         /* Activate trace re. Received */
   
      PrntCntr(dactvTrReqTx);         /* Deactivate trace request transmitted */
      PrntCntr(dactvTrReqRx);         /* Deactivate trace request Received */
      PrntCntr(dactvTrRspTx);         /* Deactivate trace response transmitted */
      PrntCntr(dactvTrRspRx);         /* Deactivate trace response Received */
      PrntCntr(dactvTrReTx);         /* Deactivate trace re. transmitted */
      PrntCntr(dactvTrReRx);         /* Deactivate trace re. Received */

#if MAP_REL99

      /* Auth Failure Report */
      PrntCntr(authFailRptReqTx);    /* Inv. Tx */
      PrntCntr(authFailRptReqRx);    /* Inv. Rx */
      PrntCntr(authFailRptRspTx);   /* RR Tx */
      PrntCntr(authFailRptRspRx);   /* RR Rx */
      PrntCntr(authFailRptReTx);     /* RE Tx */
      PrntCntr(authFailRptReRx);     /* RE Rx */ 

#endif /* MAP_REL99 */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */
#if (MAP_VLR || MAP_HLR)
      PrntCntr(upLocReqTx);         /* Update Location request transmitted */
      PrntCntr(upLocReqRx);         /* Update Location request Received */
      PrntCntr(upLocRspTx);         /* Update Location response transmitted */
      PrntCntr(upLocRspRx);         /* Update Location response Received */
      PrntCntr(upLocReTx);          /* Update Location ret.error transmitted */
      PrntCntr(upLocReRx);          /* Update Location ret.error Received */
   
      PrntCntr(sndParamReqTx);      /* Send Parameter request transmitted */
      PrntCntr(sndParamReqRx);      /* Send Parameter request Received */
      PrntCntr(sndParamRspTx);      /* Send Parameter response transmitted */
      PrntCntr(sndParamRspRx);      /* Send Parameter response Received */
      PrntCntr(sndParamReTx);       /* Send Parameter response transmitted */
      PrntCntr(sndParamReRx);       /* Send Parameter response Received */
   
      PrntCntr(restoreReqTx);         /* Restore request transmitted */
      PrntCntr(restoreReqRx);         /* Restore request Received */
      PrntCntr(restoreRspTx);         /* Restore response transmitted */
      PrntCntr(restoreRspRx);         /* Restore response Received */
      PrntCntr(restoreReTx);          /* Restore ret.error transmitted */
      PrntCntr(restoreReRx);          /* Restore SS ret.error Received */
   
      PrntCntr(sndIMSIReqTx);         /* Send IMSI request transmitted */
      PrntCntr(sndIMSIReqRx);         /* Send IMSI request Received */
      PrntCntr(sndIMSIRspTx);         /* Send IMSI response transmitted */
      PrntCntr(sndIMSIRspRx);         /* Send IMSI response Received */
      PrntCntr(sndIMSIReTx);          /* Send IMSI ret.error transmitted */
      PrntCntr(sndIMSIReRx);          /* Send IMSI ret.error Received */
   
      PrntCntr(provRoamNmbReqTx); /* Provide Roaming Number request transmitted */
      PrntCntr(provRoamNmbReqRx); /* Provide Roaming Number request Received */
      PrntCntr(provRoamNmbRspTx); /* Provide Roaming Number response transmitted */
      PrntCntr(provRoamNmbRspRx); /* Provide Roaming Number response Received */
      PrntCntr(provRoamNmbReTx);  /* Prov. Roaming Nmb. ret.error transmitted */
      PrntCntr(provRoamNmbReRx);  /* Prov. Roaming Nmb. ret.error Received */
   
      PrntCntr(bgnSubActvReqTx);  /* Begin Subs. Activity  request transmitted */
      PrntCntr(bgnSubActvReqRx);  /* Begin Subs. Activity  request Received */
      PrntCntr(notSubPresReqTx);  /* Note Subscriber Present request transmitted */
      PrntCntr(notSubPresReqRx);  /* Note Subscriber Present request Received */
   
   
      PrntCntr(setRptStateReqTx);     /* req Tx */
      PrntCntr(setRptStateReqRx);     /* req Rx */
      PrntCntr(setRptStateRspTx);     /* rsp Tx */
      PrntCntr(setRptStateRspRx);     /* rsp Rx */
      PrntCntr(setRptStateReTx);      /* set rpt state ret.error transmitted */
      PrntCntr(setRptStateReRx);      /* set rpt state ret.error Received */
   
      PrntCntr(rmtUsrFreeReqTx);     /* req Tx */
      PrntCntr(rmtUsrFreeReqRx);     /* req Rx */
      PrntCntr(rmtUsrFreeRspTx);     /* rsp Tx */
      PrntCntr(rmtUsrFreeRspRx);     /* rsp Rx */
      PrntCntr(rmtUsrFreeReTx);      /*rmt usr free ret.error transmitted */
      PrntCntr(rmtUsrFreeReRx);      /* rmt usr free ret.error Received */
   
      PrntCntr(staRptReqTx);         /*   req Tx */
      PrntCntr(staRptReqRx);         /*   req Rx */
      PrntCntr(staRptRspTx);         /*   rsp Tx */
      PrntCntr(staRptRspRx);         /*   rsp Rx */
      PrntCntr(staRptReTx);          /*   re Tx */
      PrntCntr(staRptReRx);          /*   re Rx */

#if MAP_REL99

      /* Note MM Event  */
      PrntCntr(notMmEvReqTx);          /* Inv. Tx */
      PrntCntr(notMmEvReqRx);          /* Inv. Rx */
      PrntCntr(notMmEvRspTx);          /* rsp Tx */
      PrntCntr(notMmEvRspRx);          /* rsp Rx */
      PrntCntr(notMmEvReTx);           /* re Tx */
      PrntCntr(notMmEvReRx);           /* re Rx */
   
#endif /* MAP_REL99 */

#endif

#if MAP_VLR
      PrntCntr(sndIdReqTx);         /* Send Identification request transmitted */
      PrntCntr(sndIdReqRx);         /* Send Identification request Received */
      PrntCntr(sndIdRspTx);         /* Send Identification response transmitted */
      PrntCntr(sndIdRspRx);         /* Send Identification response Received */
      PrntCntr(sndIdReTx);          /* Send Identification ret.error transmitted */
      PrntCntr(sndIdReRx);          /* Send Identification ret.error Received */
   
#endif

#if MAP_MSC
      PrntCntr(preHoReqTx);         /* Prepare Handover request transmitted */
      PrntCntr(preHoReqRx);         /* Prepare Handover request Received */
      PrntCntr(preHoRspTx);         /* Prepare Handover response transmitted */
      PrntCntr(preHoRspRx);         /* Prepare Handover response Received */
      PrntCntr(preHoReTx);          /* Prepare Handover ret.error transmitted */
      PrntCntr(preHoReRx);          /* Prepare Handover ret.error Received */
   
      PrntCntr(preSubHoReqTx);      /* Prepare Subsequest Handover request tx */
      PrntCntr(preSubHoReqRx);      /* Prepare Subsequent Handover request Received */
      PrntCntr(preSubHoRspTx);      /* Prepare Subsequent Handover response tx */
      PrntCntr(preSubHoRspRx);      /* Prepare Subsequent Handover response Received */
      PrntCntr(preSubHoReTx);       /* Prepare Subsequent ret.error transmitted */
      PrntCntr(preSubHoReRx);       /* Prepare Subsequent ret.error Received */
   
      PrntCntr(perHoReqTx);         /* Perform Handover request transmitted */
      PrntCntr(perHoReqRx);         /* Perform Handover request Received */
      PrntCntr(perHoRspTx);         /* Perform Handover response transmitted */
      PrntCntr(perHoRspRx);         /* Perform Handover response Received */
      PrntCntr(perHoReTx);          /* Perform Handover ret.error transmitted */
      PrntCntr(perHoReRx);          /* Perform Handover ret.error Received */
   
      PrntCntr(perSubHoReqTx);      /* Perform Subsequest Handover request tx */
      PrntCntr(perSubHoReqRx);      /* Perform Subsequent Handover request Received */
      PrntCntr(perSubHoRspTx);      /* Perform Subsequent Handover response tx */
      PrntCntr(perSubHoRspRx);      /* Perform Subsequent Handover response Received */
      PrntCntr(perSubHoReTx);      /* Perform Subsequent Handover re tx */
      PrntCntr(perSubHoReRx);      /* Perform Subsequent Handover re Received */
   
      PrntCntr(sndEndSigReqTx);      /* Send End Signal request tx */
      PrntCntr(sndEndSigReqRx);      /* Send End Signal request Received */
      PrntCntr(sndEndSigRspTx);      /* Send End Signal request tx */
      PrntCntr(sndEndSigRspRx);      /* Send End Signal request Received */
   
      PrntCntr(procAccSigReqTx);     /* Process Access Signalling request tx */
      PrntCntr(procAccSigReqRx);     /* Process Access Signalling request Received */
   
      PrntCntr(fwdAccSigReqTx);      /* Forward Access Signalling request tx */
      PrntCntr(fwdAccSigReqRx);      /* Forward Access Signalling request Received */
   
      PrntCntr(notInterHoReqTx);     /* Note Internal Handover request tx */
      PrntCntr(notInterHoReqRx);     /* Note Internal Handover request Received */
   
      PrntCntr(resCallHandlReqTx);     /* Resume Call Handling  req Tx */
      PrntCntr(resCallHandlReqRx);     /* Resume Call Handling  req Rx */
      PrntCntr(resCallHandlRspTx);     /* resume Call Handling response tx*/
      PrntCntr(resCallHandlRspRx);     /* resume Call Handling response Rx*/
      PrntCntr(resCallHandlReTx);      /* Res. Call Handl ret.error transmitted */
      PrntCntr(resCallHandlReRx);      /* Res. Call Handl ret.error Received */
   
      PrntCntr(prepGrpCallReqTx);     /*  Prepare Grp call req Tx */
      PrntCntr(prepGrpCallReqRx);     /* Prepare Grp call req Rx */
      PrntCntr(prepGrpCallRspTx);     /* Prepare Grp call rsp Tx */
      PrntCntr(prepGrpCallRspRx);     /*  Prepare Grp call rsp Rx */
      PrntCntr(prepGrpCallReTx);     /* Prep Grp Call ret.error transmitted */
      PrntCntr(prepGrpCallReRx);     /* Prep Grp Call ret.error Received */
   
      PrntCntr(proGrpCallSigReqTx);     /* Pro Grp Call Sig  req Tx */
      PrntCntr(proGrpCallSigReqRx);     /* Pro Grp Call Sig  req Rx */
      PrntCntr(proGrpCallRspTx);        /* Process Group Call response tx*/
      PrntCntr(proGrpCallRspRx);        /* Process Group Call  response Rx*/
      PrntCntr(proGrpCallReTx);         /* Process Group Call ret.error transmitted*/
      PrntCntr(proGrpCallReRx);         /* Process Group Call ret.error Received*/
   
      PrntCntr(fwdGrpCallSigReqTx);     /* Fwd Grp Call Sig req Tx */
      PrntCntr(fwdGrpCallSigReqRx);     /* Fwd Grp Call Sig req Rx */
   
      PrntCntr(sndGrpCallEndSigReqTx);     /* Snd Grp Call End Sig req Tx */
      PrntCntr(sndGrpCallEndSigReqRx);     /* Snd Grp Call End Sig req Rx */
      PrntCntr(sndGrpCallEndSigRspTx);     /* snd. Grp. Call End Sig response tx*/
      PrntCntr(sndGrpCallEndSigRspRx);     /* snd. Grp. Call End Sig response Rx*/
      PrntCntr(sndGrpCallEndSigReTx);      /* snd. Grp. Call End Sig ret.error tx */
      PrntCntr(sndGrpCallEndSigReRx);      /* snd. Grp. Call End Sig ret.error Rx */
   
      PrntCntr(provSiwfsNmbReqTx);     /* prov Siwfs Nmb req Tx */
      PrntCntr(provSiwfsNmbReqRx);     /* prov Siwfs Nmb req Rx */
      PrntCntr(provSiwfsNmbRspTx);     /* prov Siwfs Nmb rsp Tx */
      PrntCntr(provSiwfsNmbRspRx);     /* prov Siwfs Nmb rsp Rx */
      PrntCntr(provSiwfsNmbReTx);      /* Provide Siwfs Number ret.error tx */
      PrntCntr(provSiwfsNmbReRx);      /* Prov.Siwfs.Nmb ret.error Received */
   
      PrntCntr(siwfsSigModReqTx);     /*  siwfs Sig Mod req Tx */
      PrntCntr(siwfsSigModReqRx);     /*  siwfs Sig Mod req Rx */
      PrntCntr(siwfsSigModRspTx);     /*  siwfs Sig Mod rsp Tx */
      PrntCntr(siwfsSigModRspRx);     /*  siwfs Sig Mod rsp Rx */
      PrntCntr(siwfsSigModReTx);      /*  Siwfs Sig Mod ret.error tx */
      PrntCntr(siwfsSigModReRx);      /*  Siwfs.Sig Mod ret.error Received */
   
#endif
   
#if (MAP_MSC || MAP_GSN)
      PrntCntr(fwdSMReqTx);          /* Forward SM request tx */
      PrntCntr(fwdSMReqRx);          /* Forward SM request Received */
      PrntCntr(fwdSMRspTx);          /* Forward SM Response tx*/
      PrntCntr(fwdSMRspRx);          /* Forward SM Response Rx*/
      PrntCntr(fwdSMReTx);           /* Forward SM ret.error transmitted */
      PrntCntr(fwdSMReRx);           /* Forward SM ret.error Received */
   
      PrntCntr(mtFwdSMReqTx);          /* mo Forward SM request tx */
      PrntCntr(mtFwdSMReqRx);          /* mo Forward SM request Received */
      PrntCntr(mtFwdSMRspTx);          /* mo Forward SM rsp tx */
      PrntCntr(mtFwdSMRspRx);          /* mo Forward SM rsp Received */
      PrntCntr(mtFwdSMReTx);           /* mo Forward SM ret.error transmitted */
      PrntCntr(mtFwdSMReRx);           /* mo Forward SM ret.error Received */
   
#endif /* MAP_MSC || MAP_GSN */
#if MAP_HLR
      PrntCntr(anyInterReqTx);     /* any Inter req Tx */
      PrntCntr(anyInterReqRx);     /* any Inter req Rx */
      PrntCntr(anyInterRspTx);     /* any Inter rsp Tx */
      PrntCntr(anyInterRspRx);     /* any Inter rsp Rx */
      PrntCntr(anyInterReTx);     /* any Inter re Tx */
      PrntCntr(anyInterReRx);     /* any Inter re Rx */

#endif
#if (MAP_MSC || MAP_HLR)
      PrntCntr(ssInvNotReqTx);     /*  ss Inv Not req Tx */
      PrntCntr(ssInvNotReqRx);     /*  ss Inv Not req Rx */
      PrntCntr(ssInvNotRspTx);     /*  ss Inv Not rsp Tx */
      PrntCntr(ssInvNotRspRx);     /*  ss Inv Not rsp Rx */
      PrntCntr(ssInvNotReTx);      /*  ss Inv Not re Tx  */
      PrntCntr(ssInvNotReRx);      /*  ss Inv Not re Rx  */
   
#if MAP_REL99

      /* IST Alert  */
      PrntCntr(istAlrtReqTx);        /* Inv. Tx */
      PrntCntr(istAlrtReqRx);        /* Inv. Rx */
      PrntCntr(istAlrtRspTx);        /* RR Tx */
      PrntCntr(istAlrtRspRx);        /* RR Rx */
      PrntCntr(istAlrtReTx);         /* RE Tx  */
      PrntCntr(istAlrtReRx);         /* RE Rx  */
   
      /* IST Command  */
      PrntCntr(istCmdReqTx);        /* Inv. Tx */
      PrntCntr(istCmdReqRx);        /* Inv. Rx */
      PrntCntr(istCmdRspTx);        /* RR Tx */
      PrntCntr(istCmdRspRx);        /* RR Rx */
      PrntCntr(istCmdReTx);         /* RE Tx  */
      PrntCntr(istCmdReRx);         /* RE Rx  */
   
#endif /* MAP_REL99 */
   
#endif 

#if MAP_MSC
#if MAP_REL99
#if MAP_REL6

      /* Release Resources  */
      PrntCntr(relResReqTx);        /* Inv. Tx */
      PrntCntr(relResReqRx);        /* Inv. Rx */
      PrntCntr(relResRspTx);        /* RR Tx */
      PrntCntr(relResRspRx);        /* RR Rx */
      PrntCntr(relResReTx);         /* RE Tx  */
      PrntCntr(relResReRx);         /* RE Rx  */
   
#endif /* MAP_REL6 */
#endif /* MAP_REL99 */
#endif /* MAP_MSC */
   
#if (MAP_VLR || MAP_HLR || MAP_GSN)
      PrntCntr(provSubsInfoReqTx);     /* prov Subs Info req Tx */
      PrntCntr(provSubsInfoReqRx);     /* prov Subs Info req Rx */
      PrntCntr(provSubsInfoRspTx);     /* prov Subs Info rsp Tx */
      PrntCntr(provSubsInfoRspRx);     /* prov Subs Info rsp Rx */
      PrntCntr(provSubsInfoReTx);      /* prov.Subs Info ret.error transmitte*/
      PrntCntr(provSubsInfoReRx);      /* prov.Subs Info ret.error Received */
   
#endif

#if (MAP_HLR || MAP_GSN)
      PrntCntr(gprsUpLocReqTx);     /* Gprs Up. Loc req Tx */
      PrntCntr(gprsUpLocReqRx);     /* Gprs Up. Loc req Rx */
      PrntCntr(gprsUpLocRspTx);     /* Gprs Up. Loc rsp Tx */
      PrntCntr(gprsUpLocRspRx);     /* Gprs Up. Loc rsp Rx */
      PrntCntr(gprsUpLocReTx);     /* Update Gprs Location ret.error Tx*/
      PrntCntr(gprsUpLocReRx);     /* Update Gprs Location  ret.error Rx */
   
      PrntCntr(gprsRoutInfoReqTx);  /* Gprs Rout Info req Tx */
      PrntCntr(gprsRoutInfoReqRx);  /* Gprs Rout Info req Rx */
      PrntCntr(gprsRoutInfoRspTx);  /* Gprs Rout Info rsp Tx */
      PrntCntr(gprsRoutInfoRspRx);  /* Gprs Rout Info rsp Rx */
      PrntCntr(gprsRoutInfoReTx);  /* Gprs Rout Info  ret.error transmitted */
      PrntCntr(gprsRoutInfoReRx);  /* Gprs Rout Info  ret.error Received */
   
      PrntCntr(failRptReqTx);     /* Fail Rpt  req Tx */
      PrntCntr(failRptReqRx);     /* Fail Rpt  req Rx */
      PrntCntr(failRptRspTx);     /* Fail Rpt  rsp Tx */
      PrntCntr(failRptRspRx);     /* Fail Rpt  rsp Rx */
      PrntCntr(failRptReTx);     /* Fail Rpt  re Tx */
      PrntCntr(failRptReRx);     /* Fail Rpt  re Rx */
   
      PrntCntr(gprsNoteMsPresReqTx);     /* Gprs Note Ms Pres  req Tx */
      PrntCntr(gprsNoteMsPresReqRx);     /* Gprs Note Ms Pres  req Rx */
      PrntCntr(gprsNoteMsPresRspTx);     /* Gprs Note Ms Pres  rsp Tx */
      PrntCntr(gprsNoteMsPresRspRx);     /* Gprs Note Ms Pres  rsp Rx */
      PrntCntr(gprsNoteMsPresReTx);     /* Gprs Note Ms Pres  re Tx */
      PrntCntr(gprsNoteMsPresReRx);     /* Gprs Note Ms Pres  re Rx */
   
#endif /* MAP_HLR || MAP_GSN */

#if MAP_REL99

#if MAP_HLR
      /* anytime Subscriber Interrogation */
      PrntCntr(anySubsInterReqTx);    /* Inv. tx*/
      PrntCntr(anySubsInterReqRx);    /* Inv. Rx*/
      PrntCntr(anySubsInterRspTx);    /* RR tx*/
      PrntCntr(anySubsInterRspRx);    /* RR Rx*/
      PrntCntr(anySubsInterReTx);     /* RE Tx */
      PrntCntr(anySubsInterReRx);     /* RE Rx */
   
      /* anytime Modification */
      PrntCntr(anyModReqTx);    /* Inv. tx*/
      PrntCntr(anyModReqRx);    /* Inv. Rx*/
      PrntCntr(anyModRspTx);    /* RR tx*/
      PrntCntr(anyModRspRx);    /* RR Rx*/
      PrntCntr(anyModReTx);     /* RE Tx */
      PrntCntr(anyModReRx);     /* RE Rx */
      
      /* Note Subscriber Modification */
      PrntCntr(notSubsModReqTx);    /* Inv. tx*/
      PrntCntr(notSubsModReqRx);    /* Inv. Rx*/
      PrntCntr(notSubsModRspTx);    /* RR tx*/
      PrntCntr(notSubsModRspRx);    /* RR Rx*/
      PrntCntr(notSubsModReTx);     /* RE Tx */
      PrntCntr(notSubsModReRx);     /* RE Rx */
#endif /* MAP_HLR */
   
#endif /* MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)
#if (MAP_MSC || MAP_MLC)
      /* provide subscriber location */
      PrntCntr(provSubsLocReqTx);    /* Inv. tx*/
      PrntCntr(provSubsLocReqRx);    /* Inv. Rx*/
      PrntCntr(provSubsLocRspTx);    /* RR tx*/
      PrntCntr(provSubsLocRspRx);    /* RR Rx*/
      PrntCntr(provSubsLocReTx);     /* RE Tx */
      PrntCntr(provSubsLocReRx);     /* RE Rx */
   
      /* subscriber Location */
      PrntCntr(subsLocReqTx);    /* Inv. tx*/
      PrntCntr(subsLocReqRx);    /* Inv. Rx*/
      PrntCntr(subsLocRspTx);    /* RR tx*/
      PrntCntr(subsLocRspRx);    /* RR Rx*/
      PrntCntr(subsLocReTx);     /* RE Tx */
      PrntCntr(subsLocReRx);     /* RE Rx */
#endif /* MAP_MSC || MAP_MLC */
#endif /* MAP_REL98 || MAP_REL99 */
   
#if (MAP_HLR || MAP_MLC)
      PrntCntr(anyTimeInterReqTx);  /* Any Time Interrogation request tx*/
      PrntCntr(anyTimeInterReqRx);  /* Any Time Interrogation request Rx*/
      PrntCntr(anyTimeInterRspTx);  /* Any Time Interrogation response tx*/
      PrntCntr(anyTimeInterRspRx);  /* Any Time Interrogation response Rx*/
      PrntCntr(anyTimeInterReTx);   /* Any Time Interrogation ret.err Tx */
      PrntCntr(anyTimeInterReRx);   /* Any Time Interrogation ret.err Rx */

#if (MAP_REL98 || MAP_REL99)
      /* send routing info for LCS */
      PrntCntr(lcsSndRoutInfoReqTx);    /* Inv. tx*/
      PrntCntr(lcsSndRoutInfoReqRx);    /* Inv. Rx*/
      PrntCntr(lcsSndRoutInfoRspTx);    /* RR tx*/
      PrntCntr(lcsSndRoutInfoRspRx);    /* RR Rx*/
      PrntCntr(lcsSndRoutInfoReTx);     /* RE Tx */
      PrntCntr(lcsSndRoutInfoReRx);     /* RE Rx */
#endif /* MAP_REL98 || MAP_REL99 */

#endif /* MAP_HLR || MAP_MLC */
   }
   else
   {
      SPrint("SAP statistics request failed\n");
   }   
   SPrint("----- SAP statistics -----\n");
     
#ifndef LCSMMAMILMA
   pst->event = MA_EVTLMASTSCFM;
#endif /* LCSMMAMILMA */

#ifdef MATST
   LM_GETMSG(pst, mBuf, ESMMA001);

   /* now pack */
   CMCHKPKLOG(cmPkCmStatus, &sts->cfm, mBuf, ESMMA002, pst);
   CMCHKPKLOG(cmPkHeader,   &sts->hdr, mBuf, ESMMA003, pst);
   CMCHKPKLOG(cmPkPst,      pst,       mBuf, ESMMA004, pst);

   /* now queue the message */
   SQueueLast(mBuf, maAccLmRxQ);
#endif
   RETVALUE(ROK);
} /* end of SmMiLmaStsCfm */

    
/*
*
*       Fun:   Status Confirm
*
*       Desc:  This function is used by the MAP to present
*              solicited status information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smmabdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SmMiLmaStaCfm
(
Pst     *pst,            /* post structure */
MaMngmt *sta             /* confirmed status */
)
#else
PUBLIC S16 SmMiLmaStaCfm(pst, sta)
Pst     *pst;            /* post structure */
MaMngmt *sta;            /* confirmed status */
#endif
{
   Txt        prntBuf[32];   /* Buffer to print */
   DateTime   *dt;           /* date and time when status is rxd */

   TRC2(SmMiLmaStaCfm)

   UNUSED(pst);

   if (sta->cfm.status == LCM_PRIM_OK)
   {
      dt = &sta->t.ssta.dt;
      SMMAPRNTDT(dt);
      switch (sta->hdr.elmId.elmnt)
      {
         case STSID:
         {
            SystemId *n = &sta->t.ssta.s.sysId;
 
            SPrint("SYSTEM ID Status\n");
            sprintf(prntBuf, "mVer %d\n", n->mVer);
            SPrint(prntBuf);
            sprintf(prntBuf, "mRev %d\n", n->mRev);
            SPrint(prntBuf);
            sprintf(prntBuf, "bVer %d\n", n->bVer);
            SPrint(prntBuf);
            sprintf(prntBuf, "bRev %d\n", n->bRev);
            SPrint(prntBuf);
            sprintf(prntBuf, "ptNmb %s\n", n->ptNmb);
            SPrint(prntBuf);
            break;
         }
         case STMATSAP:
         {
            MaMAUSta *n = &sta->t.ssta.s.maUSta;
 
            SPrint("USAP Status\n");
            sprintf(prntBuf, "swtch %d\n", n->swtch);
            SPrint(prntBuf);
            sprintf(prntBuf, "hlSt %d\n", n->maState);
            SPrint(prntBuf);
#ifdef MA_RUG
            sprintf(prntBuf, "MAT remIntfValid %d\n", n->maVerStaMU.remIntfValid);
            SPrint(prntBuf);
            sprintf(prntBuf, "MAT selfIntfVer %d\n", n->maVerStaMU.selfIntfVer);
            SPrint(prntBuf);
            sprintf(prntBuf, "MAT remIntfVer %d\n", n->maVerStaMU.remIntfVer);
            SPrint(prntBuf);
            sprintf(prntBuf, "STU remIntfValid %d\n", n->maVerStaTC.remIntfValid);
            SPrint(prntBuf);
            sprintf(prntBuf, "STU selfIntfVer %d\n", n->maVerStaTC.selfIntfVer);
            SPrint(prntBuf);
            sprintf(prntBuf, "STU remIntfVer %d\n", n->maVerStaTC.remIntfVer);
            SPrint(prntBuf);
#endif /* MA_RUG */
            break;
         }
      }
   }

   RETVALUE(ROK);
} /* end of SmMiLmaStaCfm */


/*
*
*       Fun:   Configuration Confirm
*
*       Desc:  This function is used by the MAP to present
*              configuration confirmation information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smmabdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SmMiLmaCfgCfm
(
Pst      *pst,
MaMngmt  *cfm          /* confirm */
)
#else
PUBLIC S16 SmMiLmaCfgCfm(pst, cfm)
Pst      *pst;
MaMngmt  *cfm;         /* confirm */
#endif
{
#ifdef MATST
   Buffer    *mBuf;
#else
   Txt        prntBuf[MA_PRNTBUF_SIZE];  /* print buffer */
#endif /* MATST */

   TRC2(SmMiLmaCfgCfm)

#ifndef LCSMMAMILMA
   pst->event = MA_EVTLMACFGCFM;
#endif /* LCSMMAMILMA */

#ifdef MATST
   LM_GETMSG(pst, mBuf, ESMMA005);

   /* now pack */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ESMMA006, pst);
   CMCHKPKLOG(cmPkHeader,   &cfm->hdr, mBuf, ESMMA007, pst);
   CMCHKPKLOG(cmPkPst,      pst,       mBuf, ESMMA008, pst);

   /* now queue the message */
   SQueueLast(mBuf, maAccLmRxQ);
#else
   sprintf(prntBuf,"SM:Config Cfm from MAP Proc %x with status %d, reason %d\n",
                       pst->srcProcId, cfm->cfm.status, cfm->cfm.reason);
   SPrint(prntBuf);
#endif

   RETVALUE(ROK);
} /* end of SmMiLmaCfgCfm */


/*
*
*       Fun:   control Confirm
*
*       Desc:  This function is used by the MAP to present
*              control confirmation information to Layer Management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  smmabdy1.c
*
*/

#ifdef ANSI
PUBLIC S16 SmMiLmaCntrlCfm
(
Pst      *pst,
MaMngmt  *cfm          /* confirm */
)
#else
PUBLIC S16 SmMiLmaCntrlCfm(pst, cfm)
Pst      *pst;
MaMngmt  *cfm;         /* confirm */
#endif
{
#ifdef MATST
   Buffer    *mBuf;
#else
   Txt        prntBuf[MA_PRNTBUF_SIZE];  /* print buffer */
#endif /* MATST */

   TRC2(SmMiLmaCprntBuf)

#ifndef LCSMMAMILMA
   pst->event = MA_EVTLMACNTRLCFM;
#endif /* LCSMMAMILMA */

#ifdef MATST
   LM_GETMSG(pst, mBuf, ESMMA009);

   /* now pack */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ESMMA010, pst);
   CMCHKPKLOG(cmPkHeader,   &cfm->hdr, mBuf, ESMMA011, pst);
   CMCHKPKLOG(cmPkPst,      pst,       mBuf, ESMMA012, pst);

   /* now queue the message */
   SQueueLast(mBuf, maAccLmRxQ);
#else
   sprintf(prntBuf,"SM:Control Cfm from MAP Proc %x with status %d, reason %d\n",
                    pst->srcProcId, cfm->cfm.status, cfm->cfm.reason);
   SPrint(prntBuf);
#endif

   RETVALUE(ROK);
} /* end of SmMiLmaCntrlCfm */


  
/*
*
*       Fun:   Activate Task - initialize
*
*       Desc:  Invoked by system services to initialize a task.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  smmabdy1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smMaActvInit
(
Ent ent,                      /* entity */
Inst inst,                    /* instance */
Region region,                /* region */
Reason reason                 /* reason */
)
#else
PUBLIC S16 smMaActvInit(ent, inst, region, reason)
Ent ent;                      /* entity */
Inst inst;                    /* instance */
Region region;                /* region */
Reason reason;                /* reason */
#endif
{
   TRC3(smMaActvInit);

   UNUSED(region);
   UNUSED(reason);
   UNUSED(ent);
   UNUSED(inst);

   RETVALUE(ROK);
} /* end of smMaActvInit */


  
/********************************************************************30**
  
         End of file:     smmabdy1.c@@/main/9 - Fri Sep 16 02:40:43 2005

*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa    1. initial release

*********************************************************************81*/
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.2          ---      aa   1. moved cm_ss7.x and cm_gen.x before lma.x

1.3          ---      ssk  1. Changes for adding the MAP Phase 2+ variant
                              and for adding LMINT3.

/main/4      ---      ssk  1. update for MAP 1.5 release.
 
             ---      jie  1. Rolling Upgrade compliance.

             ---      yz   2. Remove REL99 flag for sndEndSigRspRx/Tx.

             ---      yz   3. Use flag MATST to not include ma_acc
                              header file in non-acceptance test.

/main/5      ---      ssk  1. update for MAP 1.6 release.

/main/6      ---      jie  1. update for MAP 1.7 release.

/main/8      ---      cp   1. update for MAP release 2.2
/main/9      ---     rbabu 1. update for MAP release 2.3
/main/9    ma002.203  dv   1. Removed compiler warnings
*********************************************************************91*/
