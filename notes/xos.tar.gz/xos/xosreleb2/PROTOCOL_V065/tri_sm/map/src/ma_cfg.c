#ifdef CP_OAM_SUPPORT
/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "ss_err.h"        /* errors */
#include "ss_dep.h"        /* implementation-specific */
#include "ss_queue.h"      /* queues */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */

#include "lma.h"           /* layer management, MAP */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* tcap layer */
#include "mat.h"           /* map layer */
#ifdef MA_FTHA
#include "sht.h"
#endif /* MA_FTHA */
#include "cm5.h"
#include "ma.h"            /* map */
#include "ma_mf.h"         /* map */
#include "ma_err.h"        /* map error */
#include "cm_ss7.h"
#include "cm_llist.h"

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "ss_dep.x"        /* implementation-specific */
#include "ss_queue.x"      /* queues */
#include "ss_queue.x"      /* queues */
#include "ss_task.x"
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */

#include "cm5.x"
#include "cm_ss7.x"           /* common */
#include "stu.x"           /* tcap layer */
#include "lma.x"           /* layer management, TCAP */
#include "mat.x"           /* map  layer */
#ifdef MA_FTHA
#include "sht.x"
#endif /* MA_FTHA */
#include "ma.x"            /* map */
#include "cm_lib.x"        /* Common Portable Library */
#include "cm_llist.x"

/*application .h file*/
#include "xosshell.h"
#include "cp_tab_def.h"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"
#include "sm.h"
#include "sm.x"
#include "ma_oam.x"
#include "ma_cfg.h"

EXTERN SsOs osCp;

CmLListCp gMaSmQ[CP_MA_CONFIG_Q_TOTAL_NUM];
MaCfgData gMaCfgData;
U32   gMaTransId = 0;
U32 maCfgTbl[SM_MAP_TAB_NUM]={APP_TABLE_ID_SS7_NWK, APP_TABLE_ID_SS7_UP, APP_TABLE_ID_SS7_SSN, APP_TABLE_ID_SS7_MAP_GEN, APP_TABLE_ID_SS7_MAP_SAP, APP_TABLE_ID_SS7_MAP_ACN};/**/

U32 maGetTransId()
{
    return gMaTransId++;
}

Bool smIsSameSTsk(Ent ent1, Inst inst1, Ent ent2, Inst inst2 )
{
	SsIdx idx1, idx2;	
#ifdef SS_MULTIPLE_PROCS
	U16 procIdIdx = SFndProcId();
#endif /* SS_MULTIPLE_PROCS */

#ifdef SS_MULTIPLE_PROCS
	idx1 = osCp.tTskIds[procIdIdx][ent1][inst1];
	idx2 = osCp.tTskIds[procIdIdx][ent2][inst2];
#else /* SS_MULTIPLE_PROCS */
	idx1 = osCp.tTskIds[ent1][inst1];
	idx2 = osCp.tTskIds[ent2][inst2];
#endif /* SS_MULTIPLE_PROCS */

	if(osCp.tTskTbl[idx1].sTsk == osCp.tTskTbl[idx2].sTsk)
	{
		RETVALUE(TRUE);
	}
	else
	{
		RETVALUE(FALSE);
	}
}

/* 
 * Function name: maHdrInit
 * Des:  		  Init Hdr 
 * Return Value : ROK or RFAILED
 */
S16 maHdrInit(Header *hdr)
{
	TRC2(maHdrInit)
 
       hdr->msgLen         = sizeof(MaMngmt);
       hdr->msgType          = 0;
	hdr->entId.ent        = ENTMA;
	hdr->entId.inst       = MA_INST;
	hdr->elmId.elmnt      = 0;
	hdr->elmId.elmntInst1 = 0;
	hdr->elmId.elmntInst2 = 0;
	hdr->elmId.elmntInst3 = 0;
	hdr->seqNmb           = 0;
	hdr->version          = 0;
 
#ifdef LMA_LMINT3
	hdr->response.prior      = PRIOR1;
	hdr->response.route      = RTESPEC;
	hdr->response.mem.region = MA_REG;
	hdr->response.mem.pool   = MA_POOL;
	hdr->transId             = maGetTransId();
#ifdef LCSMMAMILMA
	hdr->response.selector   = MA_SEL_LC;
#else
	hdr->response.selector   = MA_SEL_TC;
#endif /* LCSMMAMILMA */
#endif /* LMA_LMINT3 */
 
	RETVALUE(ROK);
} /* End of maHdrInit */

/* 
 * Function name: smMaPstInit
 * Des:		      Init the Pst from sm to Ma 
 * Return Value : ROK or RFAILED
 */
S16 smMaPstInit(Pst *smMaPst)
{
	memset((U8 *)smMaPst, 0, sizeof(Pst));

#ifdef LCSMMAMILMA
   smMaPst->selector  = MA_SEL_LC;
#else
	smMaPst->selector  = MA_SEL_TC;
#endif
	smMaPst->event     = 0;
	smMaPst->region    = SM_REG;
	smMaPst->pool      = SM_POOL;
	smMaPst->prior     = PRIOR1;
	smMaPst->route     = RTESPEC;
	smMaPst->dstProcId = SFndProcId();
	smMaPst->dstEnt    = ENTMA;
	smMaPst->dstInst   = MA_INST;
	smMaPst->srcProcId = SFndProcId();
	smMaPst->srcEnt    = ENTSM;
	smMaPst->srcInst   = SM_INST;
	
	RETVALUE(ROK);
}

U8 maGetSwType( U8 swType)
{
    U8 maSwType;
    
    switch( swType)
    {
        case SW_ANSI88:
        case SW_ANSI92:
        case SW_CHINA:
        case SW_ITU:
        default:
            maSwType = LMA_SW_GSM_0902;
            break;
    }
    return maSwType;
}


/* 
 * Function name: maFillAcn
 * Des:		      Fill ACN for according operation 
 * Return Value : ROK or RFAILED
 */
S16 maFillAcn(U8 opCode, MaApConName *acn, MaApConName *altAcn, U8 *oprClass, U8 *maVer, U8 maSwtch)
{

   U8 cntxt;     
   U8 ver;     
   U8 altCntxt;     
   U8 altVer;     

   cntxt = ver = altCntxt = altVer = 0;
   acn->pres = TRUE;
   acn->len = 8;
   acn->val[0] = 0;
   acn->val[1] = 4;
   acn->val[2] = 0;
   acn->val[3] = 0;
   acn->val[4] = 1;
   acn->val[5] = 0;

   altAcn->pres = FALSE;
   altAcn->len = 0;
   altAcn->val[0] = 0;
   altAcn->val[1] = 4;
   altAcn->val[2] = 0;
   altAcn->val[3] = 0;
   altAcn->val[4] = 1;
   altAcn->val[5] = 0;

   switch(opCode)

   {
#ifdef XWEXT
	case MA_PAGING_DETECT:
	{
      cntxt = MA_PAGING_DETECT_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
	}
	break;
#endif

#if (MAP_MSC || MAP_VLR)  /*  B Interface */
   case MA_DET_IMSI:         /* MaDetIMSI */
   {
      *maVer   = LMA_VER1;
      *oprClass = MA_OPRCLASS4;
      RETVALUE(RFAILED);
   }

   case MA_TRACESUBSACTV:    /* MaTrSubsActv */
   {
      cntxt = MA_HO_CONTROL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER1;
      *oprClass = MA_OPRCLASS4;
      break;
   }
#endif

#if MAP_VLR                   /*  G Interface */
   case MA_SNDID:             /* MaSendId */
   {
      cntxt = MA_INTVLRINFO_RET_AC;

#ifdef MAP_VER_V2   /* added by adam for SM v2/v3 2003-10-13 */
      ver   = 2; 
      *maVer   = LMA_VER2;
#else
      ver   =maSwtch;
#if 0 /* added by adam 2003-10-08 */
      *maVer   = LMA_VER1;
#else
      *maVer   = LMA_VER_ALL;
#endif
#endif

      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif


#if MAP_MSC
   case MA_NOTEINTERHO:      /* MaNotInterHo */
   {
      cntxt = MA_HO_CONTROL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER1;
      *oprClass = MA_OPRCLASS4;
      break;
   }
   case MA_PER_HO:           /* MaPerHo */
   case MA_PER_SUBSHO:       /* MaPerSubHo */
   {
      cntxt = MA_HO_CONTROL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER1;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_SNDENDSIG:        /* MaSndEndSig */
   {
      cntxt = MA_HO_CONTROL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
/* modified by Bruce for MAPE 2003/6/19 */	  
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_PRE_HO:           /* MaPreHo */
   case MA_PRE_SUBSHO:       /* MaPreSubHo */
   {
      cntxt = MA_HO_CONTROL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2AND2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_PROCACCSIG:       /* MaProcAccSig */
   case MA_FWDACCSIG:        /* MaFwdAccSig */
   {
      cntxt = MA_HO_CONTROL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS4;
      break;
   }
   case MA_RESCALLHANDL:     /* MaResCallHandl */
   {
      cntxt = MA_CALL_CNTRL_TRANS_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_SND_GRPCALLENDSIG: /* MaSndGrpCallEndSig */
   {
      cntxt = MA_GRP_CALL_CNTRL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS3;
      break;
   }
   case MA_PREP_GRPCALL:     /* MaPrepGrpCall */
   {
      cntxt = MA_GRP_CALL_CNTRL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_PRO_GRPCALLSIG:   /* MaProGrpCallSig */
   case MA_FWD_GRPCALLSIG:   /* MaFwdGrpCallSig */
   {
      cntxt = MA_GRP_CALL_CNTRL_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS4;
      break;
   }
   case MA_PROV_SIWFS_NMB:   /* MaProvSiwfsNmb */
   case MA_SIWFS_SIGMOD:     /* MaSiwfsSigMod */
   {
      cntxt = MA_SIWFS_ALLOC_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif 

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
   case MA_SMRDY:            /* MaRdySM */
   {
      cntxt = MA_MWD_MNGMT_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2AND2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_PROVROAMNMB:      /* MaRoamNmb  */
   {
      cntxt = MA_ROAM_NMB_ENQUIRY_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#if 0
/* added by Bruce for smart call in 12/2/2004 begin 3G00007112*/
   case MA_PRVROAMNMB_FORWYCF:      /* MaRoamNmb  */
   {
      cntxt = MA_ROAM_NMB_ENQUIRY_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
/* added by Bruce for smart call in 12/2/2004 end 3G00007112*/
#endif   
#endif /* MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_MSC || MAP_VLR || MAP_HLR)  /* D Interface */
   case MA_REGSS:            /* MaRegSS */
   case MA_ERASESS:          /* MaEraseSS */
   case MA_ACTVSS:           /* MaActvSS */
   case MA_DACTVSS:          /* MaDactvSS */
   case MA_INTERSS:          /* MaInterSS */
   case MA_REGPASSWD:        /* MaRegPasswd */
   case MA_GETPASSWD:        /* MaGetPasswd */
   {
      cntxt = MA_NETFUNC_SS_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_PROCUSSREQ:       /* MaProcUSSReq */
   case MA_USSREQ:           /* MaUSSReq */
   case MA_USSNOTIFY:        /* MaUSSNotify */
   {
      cntxt = MA_NETWORK_USS_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2AND2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_PROCUSSDATA:      /* MaProcUSSDat */
   {
      cntxt = MA_NETFUNC_SS_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif /* MAP_MSC || MAP_VLR || MAP_HLR */

#if ( MAP_VLR || MAP_HLR)  /* D Interface */
   case MA_UPLOC:            /* MaUpLoc */
   {
      cntxt = MA_NETWORK_LOCUP_AC;
	  
#ifdef MAP_VER_V2   /* added by adam for v2/v3 2003-10-13 */
      ver   = 2; 
      *maVer   = LMA_VER2;
#else
       ver   = maSwtch;
	*maVer   = LMA_VER_ALL;
#endif
	  
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif 

#if ( MAP_VLR || MAP_HLR)  /* D Interface */
   case MA_SNDPARAM:         /* MaSndParam */
   {
      cntxt = MA_NETFUNC_SS_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_RESTOREDATA:      /* MaRestDat */
   {
      cntxt = MA_NETWORK_LOCUP_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER1AND2AND2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif

#if (MAP_MSC || MAP_VLR || MAP_HLR)
   case MA_FWDCHKSSIND:      /* NULL    */
   {
      cntxt = MA_NETWORK_LOCUP_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS4;
      break;
   }
#endif

#if (MAP_VLR || MAP_HLR)
   case MA_SNDIMSI:          /* MaSndIMSI */
   {
      cntxt = MA_IMSI_RET_AC;
      ver   =maSwtch;
      /* modified by shu.bu 2002/06/13 according to HLR request */
      #if 0
      *maVer   = LMA_VER2AND2P;
      #else
      *maVer   =  LMA_VER_ALL;
      #endif
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_BEGIN_SUBS_ACTV:  /* MaBgnSubActv */
   {
      cntxt = MA_NETFUNC_SS_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS4;
      break;
   }
   case MA_NOTSUBPRES:       /* MaNotSubPres */
   {
      cntxt = MA_MWD_MNGMT_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER1;
      *oprClass = MA_OPRCLASS4;
      break;
   }
   case MA_SETRPTSTATE:      /* MaSetRptState */
   case MA_STARPT:              /* MaStaRpt */
   case MA_RMTUSRFREE:       /* MaRmtUsrFree */
   {
      cntxt = MA_REPORTING_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif

#if (MAP_MSC || MAP_VLR || MAP_HLR)
   case MA_REGCCENT:         /* MaRegCcEnt */
   case MA_ERASECCENT:       /* MaEraseCcEnt */
   {
      cntxt = MA_CALL_COMP_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif  /* MSC || (VLR) || (HLR) */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MA_CANCELLOC:        /* MaCancelLoc */
   {
      cntxt = MA_CANCEL_LOC_AC;

#ifdef MAP_VER_V2   /* added by adam for v2/v3 2003-10-13 */
      ver   = 2; 
      *maVer   = LMA_VER2;
#else
       ver   = maSwtch;
	*maVer   = LMA_VER_ALL;
#endif
	  
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_RESET:            /* MaReset */
   {
      cntxt = MA_RESET_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS4;
      break;
   }
   case MA_PURGE:            /* MaPurgeMs */
   {
      cntxt = MA_MS_PURGING_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_INSSUBSDATA:      /* MaInsSubsDat */
   {
      cntxt = MA_NETWORK_LOCUP_AC;
      ver   =maSwtch;

      altCntxt = MA_GPRS_UPLOC_AC;
      altVer   = LMA_VER2P;

      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_DELSUBSDATA:      /* MaDelSubsDat */
   {
      cntxt = MA_SUBS_DATA_MNGMT_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_AUTHINFO:            /* MaAuthInfo */
   {
      cntxt = MA_INFO_RET_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_AUTHFAILRPT:            /* MaAuthFailRpt */
   {
      cntxt = MA_AUTH_FAILRPT_AC ;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   
#endif
#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MA_ACTVTRACE:        /* MaActvTr */
   {
      cntxt = MA_NETWORK_LOCUP_AC;
      ver   =maSwtch;

  
      altCntxt = MA_GPRS_UPLOC_AC;
      altVer = LMA_VER2P;
  
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_DACTVTRACE:       /* MaDactvTr */
   {
      cntxt = MA_TRACING_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   case MA_PROVSUBSINFO:     /* MaProvSubsInfo */
   {
      cntxt = MA_SUBS_INFO_ENQ_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif
/* added by Bruce for LCS 2003/7/3*/
#if (MAP_HLR || MAP_MLC)
    case MA_SENDROUTINFOFORLCS:          /* RoutInfo For LCS */
        {
           cntxt = MA_LOC_SVC_GATEWAY;
           ver   = maSwtch;
           *maVer   = LMA_VER2AND2P;
           *oprClass = MA_OPRCLASS1;
           break;
        }
#endif
#if (MAP_REL98 || MAP_REL99)
#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL4 && MAP_GSN))
    case MA_PROVSUBSLOC:          /* Provide Subscriber Location */
        {
           cntxt = MA_LOC_SVC_ENQUIRY;
           ver   = maSwtch;
           *maVer   = LMA_VER2AND2P;
           *oprClass = MA_OPRCLASS1;
           break;
        }
   case MA_SUBSLOCRPT:          /* Subscriber Location Report */
        {
           cntxt = MA_LOC_SVC_ENQUIRY;
           ver   = maSwtch;
           *maVer   = LMA_VER2AND2P;
           *oprClass = MA_OPRCLASS1;
           break;
        }
#endif
#endif
#endif

#if (MAP_MSC || MAP_HLR)     /* C Interface */
   case MA_ROUTINFO:         /* MaSndRoutInfo */
   {

      cntxt = MA_LOCINFO_RET_AC;
      ver   =maSwtch;

      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_ROUTINFOSM:       /* MaRoutInfoSM */
   {
      cntxt = MA_SM_GATEWAY_AC;
	  
#ifdef MAP_VER_V2   /* added by adam for SM v2/v3 2003-09-23 */
      ver   = 2; 
      *maVer   = LMA_VER2;
#else
       ver   = maSwtch;
	*maVer   = LMA_VER_ALL;
#endif

      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_SMDEL:            /* MaRepSMDel */
   {
      cntxt = MA_SM_GATEWAY_AC;
       ver   = maSwtch;
	*maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }

   case MA_INFSC:            /* MaInformSC */
   {
      cntxt = MA_SM_GATEWAY_AC;
	  
#ifdef MAP_VER_V2   /* added by adam for SM v2/v3 2003-10-14 */
      ver   = 2; 
      *maVer   = LMA_VER2;
#else
       ver   = maSwtch;
	*maVer   = LMA_VER2AND2P;
#endif

      *oprClass = MA_OPRCLASS4;
      break;
   }
   case MA_ALRTSC:           /* MaAlrtSC */
   {
      cntxt = MA_SM_ALERT_AC;
#if 0 /* added by adam 2003-11-27 */
      ver   =maSwtch;
      *maVer   = LMA_VER2AND2P;
#else
      ver   = 2; 
      *maVer   = LMA_VER2;
#endif
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_ALRTSCWRSLT:      /* MaAlrtSCWRslt */
   {
      cntxt = MA_SM_ALERT_AC;
#if 0 /* added by adam 2003-11-27 */
      ver   =maSwtch;
      *maVer   = LMA_VER1;
#else
      ver   = 2; 
      *maVer   = LMA_VER2;
#endif
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif

#if (MAP_MSC || MAP_HLR)
   case MA_SSINV_NOTIFY:     /* MaSSInvNot */
   {
      cntxt = MA_SSINV_NOTIFY_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }

#endif

#if (MAP_HLR || MAP_GSN)        /* Gr Interface */
   case MA_GPRS_UPLOC:        /*   MaGprsUpLoc */
   {
      cntxt = MA_GPRS_UPLOC_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_GPRS_ROUTINFO:     /* MaGprsRoutInfo */
   {
      cntxt = MA_GPRS_LOCINFO_RET_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_FAILRPT:           /*  MaFailRpt */
   {
      cntxt = MA_FAILRPT_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
   case MA_GPRS_NOTEMSPRES:   /* MaGprsNoteMsPres */
   {
      cntxt = MA_GPRS_NOTIFY_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif 

#if (MAP_MSC || MAP_GSN)     /* Gd Interface */

   case MA_FWDSM:            /* MaFwdSM */
   {
      cntxt = MA_SM_MO_RELAY_AC;
	  
#ifdef MAP_VER_V2   /* added by adam for SM v2/v3 2003-11-19 */
      ver   = 2; 
      *maVer   = LMA_VER2;
#else
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
#endif

      *oprClass = MA_OPRCLASS1;
      break;
   }

   case MA_MT_FWDSM:          /* MaMoFwdSM */
   {
      cntxt = MA_SM_MT_RELAY_AC;
	  
#ifdef MAP_VER_V2   /* added by adam for SM v2/v3 2003-09-23 */
      ver   = 2; 
      *maVer   = LMA_VER2;
#else
       ver   = maSwtch;
	*maVer   = LMA_VER_ALL;
#endif

      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif  

#if (MAP_MSC || MAP_VLR || MAP_GSN)
   case MA_CHKIMEI:          /* MaChkIMEI */
   {
      cntxt = MA_EQP_MNGMT_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER_ALL;
      *oprClass = MA_OPRCLASS1;
      break;
   }
#endif


#if MAP_HLR
   case MA_ANY_INTER:           /* MaAnyInter */
   {
      cntxt = MA_ANY_TIME_ENQUIRY_AC;
      ver   =maSwtch;
      *maVer   = LMA_VER2P;
      *oprClass = MA_OPRCLASS1;
      break;
   }
    
    #ifdef MAP_29_002 /* Added by Felix for CAMEL */   
    case MA_ANYSUBSINTER:            /* maAnySubsInter */   
    {   
       cntxt = MA_ANY_INFO_HNDL_AC ;   
       ver   =maSwtch;   
       *maVer   = LMA_VER2P;   
       *oprClass = MA_OPRCLASS1;   
       break;   
    }   
    #endif 

#endif /* MAP_HLR */

#ifdef MAP_3G_R4   
    case MA_ANY_MOD:            /* maAnySubsInter */   
    {   
       cntxt = MA_ANY_INFO_HNDL_AC ;   
       ver   =maSwtch;   
       *maVer   = LMA_VER2P;   
       *oprClass = MA_OPRCLASS1;   
       break;   
    }
	
    case MA_NOTE_SUBSDATA_MOD:            /* maAnySubsInter */   
    {   
       cntxt =  MA_SUBS_DATA_MODI_NOT;   
       ver   =maSwtch;   
       *maVer   = LMA_VER2P;   
       *oprClass = MA_OPRCLASS1;   
       break;   
    }   
	
#endif 

   default: 
   {
      RETVALUE(RFAILED);
   }
   }

   acn->val[6] = cntxt;
   acn->val[7] = ver;

   RETVALUE(ROK);
} /* maAccFillAcn */



/* 
 * Function name: maFillAcnCfg
 * Des:		      Fill ACN for all Operation for Map layer 
 * Return Value : ROK or RFAILED
 */
S16 maFillAcnCfg(MaApnCfg *apnCfg, U8 swtch)
{
   U8 i=0;
   U16 j=0;
   U16 k=0;
   MaApConName apn;
   MaApConName altApn;
   
   for (i=0; i < MA_MAX_OPR; i++)
   {
      cmZero((PTR)&apnCfg[i],sizeof(MaApnCfg));
   }

   for(i = 0;i<MA_MAX_OPR;i++)
   {
#if MA_LMINT3
      if(maFillAcn(i,&apn,&altApn,&apnCfg[j].oprClass, &apnCfg[j].maVer, swtch) 
                     == RFAILED)
#else /* MA_LMINT3 */
      if(maFillAcn(i,&apn,&altApn,&apnCfg[j].class, &apnCfg[j].maVer, swtch) 
                     == RFAILED)
#endif /* MA_LMINT3 */
      {
         continue;
      }

      apnCfg[j].pres = TRUE;
      apnCfg[j].oprCode = i;
      apnCfg[j].oprTmr.enb = TRUE;
#if 0 /* added by adam 2003-04-10 */      
      apnCfg[j].oprTmr.val = 100; /* 50 */
#else
      switch (i)
      {
            /* Timer m */
            default: 
                  apnCfg[j].oprTmr.val = 200; /* 20 seconds */
            break;

            /* Timer s */
            case MA_SNDID: 
            case MA_SMDEL:
            case MA_ALRTSC:
                  apnCfg[j].oprTmr.val = 70; /* 7 seconds */
            break;
     
            /* Timer ml */
            case MA_RMTUSRFREE: 
            case MA_USSREQ:
            case MA_USSNOTIFY:
            case MA_REGPASSWD:
            case MA_MO_FWDSM:
            case MA_MT_FWDSM:
                  apnCfg[j].oprTmr.val = 3000; /* 5 minutes */
            break;

            /* 10 minutes */
            case MA_PROCUSSDATA: 
                  apnCfg[j].oprTmr.val = 6000; /* 10 minutes */
            break;
            
            /* Timer l */
            case MA_PROCACCSIG:
            case MA_FWDACCSIG:
            case MA_SNDENDSIG: 
                  apnCfg[j].oprTmr.val = 65535; /* 30 hours */
            break;

#ifdef XWEXT 
			case MA_PAGING_DETECT:
				apnCfg[j].oprTmr.val = 300;  /* 30 seconds */
			break;
#endif
       }
#endif /* #if 0  added by adam 2003-04-10  */

      cmZero((PTR)&apnCfg[j].altApn,sizeof(MaApnStr));
      cmZero((PTR)&apnCfg[j].apn,sizeof(MaApnStr));
      apnCfg[j].apn.string[7] = swtch;
      apnCfg[j].altApn.string[7]= swtch;

      if(apn.pres == TRUE)
      {
         apnCfg[j].apn.len  = apn.len;
         for (k=0; k<apn.len; k++)
         {
            apnCfg[j].apn.string[k]=apn.val[k];
         }
      }

      j++;
   }
   RETVALUE(ROK);
}


/* 
 * Function name: maGenCfg
 * Des:		      General configure for Map layer 
 * Return Value : ROK or RFAILED
 */

S16 maGenCfg(U16 nRec)
{
    CmLList                 *node;
    MaGenCfgTab *maGen;
    MaMngmt              *maMngmt;
        
    TRC2(maGenCfg);        

    UNUSED(nRec);
    
    /* if the map general config data do not receive, return failure*/
    if( gMaCfgData.maGenCfgNum!= 1)
    {
        printf("MAP General configuration error, Gen config data item num error");
        RETVALUE(LMA_REASON_INV_GEN_PARA);
    }

    
    /* get all data for config*/
    maGen = &gMaCfgData.maGenCfg;

    /* alloc a node for save sm msg info */
    if( ROK != smGetQNode(&node, sizeof(MaMngmt)))
    {
        printf("MAP General configuration error, alloc msg failure");
        RETVALUE(LCM_REASON_MEM_NOAVAIL);
    }

    maMngmt = (MaMngmt *)cmLListNode(node) ;
    maMngmt->hdr.msgLen = sizeof( MaMngmt);
    
    maHdrInit(&maMngmt->hdr);
	
    maMngmt->hdr.msgType = TCFG;                 /* configuration */
    maMngmt->hdr.entId.ent = ENTMA;					/* entity */
    maMngmt->hdr.entId.inst = MA_INST;				/* instance */    
    maMngmt->hdr.elmId.elmnt = STMATGEN;            /* general */

#ifdef LCMAMILMA
    maMngmt->t.cfg.s.maGen.smPst.selector  = MA_SEL_LC;
#else
    maMngmt->t.cfg.s.maGen.smPst.selector  = MA_SEL_TC;
#endif
    maMngmt->t.cfg.s.maGen.smPst.region    = MA_REG;
    maMngmt->t.cfg.s.maGen.smPst.pool      = MA_POOL;
    maMngmt->t.cfg.s.maGen.smPst.prior     = PRIOR1;
    maMngmt->t.cfg.s.maGen.smPst.route     = RTESPEC;
    maMngmt->t.cfg.s.maGen.smPst.dstProcId = SFndProcId();
    maMngmt->t.cfg.s.maGen.smPst.dstEnt    = ENTSM;
    maMngmt->t.cfg.s.maGen.smPst.dstInst   = SM_INST;
    maMngmt->t.cfg.s.maGen.smPst.srcProcId = SFndProcId();
    maMngmt->t.cfg.s.maGen.smPst.srcEnt    = ENTMA;
    maMngmt->t.cfg.s.maGen.smPst.srcInst   = MA_INST;

    /* to support set initial value instead of arg:gen or the structure of
    gen difference of cfg.t.cfg.s.genCfg, set value one by one */

   /* configure general configuration */
   maMngmt->t.cfg.s.maGen.nmbMAUSaps = MA_MAX_SAPS;	/* number of saps */    
   maMngmt->t.cfg.s.maGen.nmbDlgs = MA_MAX_DLGS;		/* number of dlg - sys wide */
   maMngmt->t.cfg.s.maGen.nmbOpr  = MA_MAX_OPRS;			/* number of opr - sys wide */
   maMngmt->t.cfg.s.maGen.timeRes = MA_TIME_RES;		/* timer resolution */
   maMngmt->t.cfg.s.maGen.range = MA_DLG_ID_RANGE*3; /* Dialogue range   */
	#ifdef MA_SEG
	maMngmt->t.cfg.s.maGen.sigFrameSz = maGen->sigFrameSz;    /* signalling frame size for MAP-segmentation */
	#endif
	
	cmLListAdd2Tail(&gMaSmQ[CP_MA_GEN_Q], node);

    RETVALUE(ROK);
}



/* 
 * Function name: maSapCfg
 * Des:		      Sap configure for Map layer 
 * Return Value : ROK or RFAILED
 */

S16 maSapCfg(U16 nRec)
{
    CmLList				*node		= NULLP;
    MaMngmt				*maMngmt	= NULLP;
    MaMAUCfg			*maMAUCfg	= NULLP;    
    CP_SS7_SSN_TAB		*ssn		= NULLP;
	CP_SS7_UP_TAB		*usrPart	= NULLP;
	CP_SS7_NETWORK_TAB	*network	= NULLP;
    MaMAUCfgTab			*maMAUCfgTab = NULLP;
    MaACNCfgTab			*maAcnCfg	= NULLP;
    U8 i = 0;
	
    TRC2(maSapCfg);        
    
    /* if the map general config data do not receive, return failure*/
    if( gMaCfgData.maGenCfgNum!= 1)
    {
        printf("MAP General configuration error, Gen config data item num error");
        RETVALUE(LMA_REASON_INV_GEN_PARA);
    }
/*
    if( gMaCfgData.maSapCfgNum != 1)
    {
        printf("MAP SAP configuration error, SAP config data item num error");
        RETVALUE(LMA_REASON_INV_GEN_PARA);
    }
*/
    
	maMAUCfgTab = &gMaCfgData.maSapCfg;
	maAcnCfg = &gMaCfgData.maAcnCfg; 
	
    /* get all data for config*/

    if((nRec+1) > gstCpSs7Global.SSNTabNum)
    {
        printf("MAP Sap Cfg error, SAP num(%d) exceed SSN TabNum(%d)\r\n",nRec, gstCpSs7Global.SSNTabNum);
        RETVALUE(LMA_REASON_EXC_SSN_NUM);
    }
/*
    for( i = 0; i < gstCpSs7Global.SSNTabNum; i++)
    {
        if( gstCpSs7Global.SSNTab[i].SsnIndex == maSapC->sapId)
            break;
    }
    if( i == gstCpSs7Global.SSNTabNum)
    {
        printf("MAP SAP Cfg error, SSN can not find, SsnIndex = %d\r\n",maSapC->sapId);
        RETVALUE(LMA_REASON_INV_USAP_CFG);
    }
*/
   ssn = &gstCpSs7Global.SSNTab[nRec];
   if(ssn->SsnUsr != EN_CP_SSNUSR_MAP)
   {
       printf("the user of ssn index(%d) is not MAP\r\n",ssn->SsnIndex);
       RETVALUE(LMA_REASON_EXC_SSN_NUM);
   }
 	 
    /* find out network table item*/
    for( i = 0; i < gstCpSs7Global.UPTabNum; i++)
    {
        if( gstCpSs7Global.UPTab[i].UpIndex == ssn->UpIndex)
            break;
    }
    if( i == gstCpSs7Global.UPTabNum)
    {
        printf("MAP SAP Cfg error, can not find user part, UpIndex = %d\r\n",ssn->UpIndex);
        RETVALUE(LMA_REASON_INV_USAP_CFG);
    }
    usrPart = &gstCpSs7Global.UPTab[i];

    /* find out network table item*/
    for( i = 0; i < gstCpSs7Global.NwkTabNum; i++)
    {
        if( gstCpSs7Global.NwkTab[i].NwId == usrPart->NwId)
            break;
    }
    if( i == gstCpSs7Global.NwkTabNum)
    {
        printf("MAP SAP Cfg error, Network can not find, Nwid = %d ",usrPart->NwId);
        RETVALUE(LMA_REASON_INV_NW_CFG);
    }
    network = &gstCpSs7Global.NwkTab[i];

    /* alloc a node for save sm msg info */
    if( ROK != smGetQNode(&node, sizeof(MaMngmt)))
    {
        printf("MAP SAP Cfg error configuration error, alloc Queu node failure\r\n");
	    RETVALUE(LCM_REASON_MEM_NOAVAIL);
    }

    maMngmt = (MaMngmt *)cmLListNode(node) ;
    maMngmt->hdr.msgLen = sizeof( MaMngmt);

    maHdrInit(&maMngmt->hdr);
	
    maMngmt->hdr.msgType = TCFG;                 /* configuration */
    maMngmt->hdr.elmId.elmnt = STMATSAP;			/* lower sap */
    maMngmt->hdr.elmId.elmntInst1 = ssn->SsnIndex;	      /* lower sapId */

/* configuare for upper sap */ 
    maMAUCfg = &maMngmt->t.cfg.s.maMAU;
    maMAUCfg->swtch = maAcnCfg->maVer;/*maGetSwType(network->SwType);*/
#ifdef LCMAUIMAT /* xingzhou.xu: addition for coupling selector --06/14/2006 */
#ifdef CP_UA_IF_TYPE_SS
    maMAUCfg->selectorMU = 3;	/* loosely coupled for SS*/
#else/*CP_UA_IF_TYPE_SS*/
    #ifdef CP_UA_IF_TYPE_HLR
    maMAUCfg->selectorMU = 4;	/* loosely coupled for HLR*/
    #else/*CP_UA_IF_TYPE_HLR*/
    maMAUCfg->selectorMU = MA_SEL_LC;	/* loosely coupled */
    #endif
#endif

#else/*LCMAUIMAT*/
    maMAUCfg->selectorMU = MA_SEL_TC;	/* tightly coupled */
#endif

	#if 0
    if(smIsSameSTsk(ENTMA, MA_INST, ENTAU, AU_INST) == TRUE)
        maMAUSapCfg->selectorMU = MA_SEL_TC;	/* tightly coupled */
	#endif

/* added for FSA, provide timer values for map sap configure, by mike.xiao 2005-05-27 */
#ifdef MAP_AGENT
    maMAUCfg->selectorMU = 2;
#endif

/* added for FSA, provide loosely coupled for test, by mike.xiao 2005-05-27 */
#ifdef MAP_AGENT_TST
    maMAUCfg->selectorMU = MA_SEL_LC;
#endif

    maMAUCfg->memMU.region = MA_REG;	/* defualt priority */
    maMAUCfg->memMU.pool = MA_POOL;		/* defualt priority */
    maMAUCfg->priorMU = PRIOR2;          /* defualt priority */
    maMAUCfg->routeMU = RTESPEC;     /* default route */
    maMAUCfg->ssn = ssn->Ssn;            /* configure ssn ssn->Ssn*/
    maMAUCfg->maPrior = MA_PRIO;   /* MAP priority */
    maMAUCfg->maGrdTmr.enb = TRUE;  /* MAP Gaurd Timer */
    maMAUCfg->maGrdTmr.val = maMAUCfgTab->maGrdTmr*SS_TICKS_SEC/MA_TIME_RES; /* MAP Gaurd Timer */
    maMAUCfg->maxDlg = MA_MAX_DLGS;              /* Maximum dialogues */
    maFillAcnCfg(&maMAUCfg->apnCfg[0], maAcnCfg->maVer);
    
    /* configuare for lower sap */
#ifdef LCMALISTU
    maMAUCfg->selectorTC = MA_SEL_LC;        /* loosely coupled */
#else
    maMAUCfg->selectorTC = MA_SEL_TC;        /* tightly coupled */
#endif

    if(smIsSameSTsk(ENTMA, MA_INST, ENTST, ST_INST) == TRUE)
        maMAUCfg->selectorTC = MA_SEL_TC;        /* tightly coupled */

    maMAUCfg->memTC.region = MA_REG;     /* Memory region 0 */
    maMAUCfg->memTC.pool = MA_POOL;          /* Memory pool 1 */
    maMAUCfg->procIdTC = SFndProcId();       /* provider processorId */
    maMAUCfg->entTC = ENTST;             /* provider entity */
    maMAUCfg->instTC = ST_INST;            /* provider inst */
    maMAUCfg->routeTC = RTESPEC;         /* provider route */
    maMAUCfg->priorTC = PRIOR2;              /* provider priority */

    maMAUCfg->spIdTC = ssn->SsnIndex;           /* tcap sap id ssn->SsnIndex*/ 

    maMAUCfg->stDlgId = MA_START_DLG_ID;     /* start dialog id */
    maMAUCfg->range   = MA_DLG_ID_RANGE; /* dialog id range */
#ifdef STU2
    maMAUCfg->tIntTmr.enb = TRUE;     /* Timer values for retrying primitives */
    maMAUCfg->tIntTmr.val = MA_TINT_TMR_VAL*SS_TICKS_SEC/MA_TIME_RES;
#endif /* STU2 */

/* added for FSA, provide timer values for map sap configure, by mike.xiao 2005-05-27 */
#ifdef MAP_AGENT
    /*  set the spid and suid for external application usage(FSA) */ 
    if((ssn->SsnUsr == CP_SSN_USR_DEF && 
        (ssn->Ssn == SS_MAP || ssn->Ssn == SS_HLR || ssn->Ssn == SS_VLR || ssn->Ssn == SS_MSC
         ||ssn->Ssn == SS_SIWF ||ssn->Ssn == SS_SGSN || ssn->Ssn == SS_GGSN || ssn->Ssn == SS_GMLC 
         || ssn->Ssn == SS_EIR || ssn->Ssn == SS_GSMSCF))
         || ssn->SsnUsr == CP_SSN_USR_MAP )
    {
        auSuId = auSpId = ssn->SsnId;
        auSapFlag = TRUE;
    }
#endif /* MAP_AGENT */

#ifdef MA_RETOPT_CHANGE
    maMAUCfg->retOpt = LMA_REC_ROE;           /* return option not requested */
    maMAUCfg->pClass = PCLASS0;           /* Sequencing Requested */
#endif    
    cmLListAdd2Tail(&gMaSmQ[CP_MA_SAP_Q], node);

    RETVALUE(ROK);
}


/**/
#ifdef ANSI
PUBLIC  S16 maCntrlReq
(
SuId   suId,               /* Sap Id */
U8     elmnt,              /* Element */
U8     action,             /* Enable/disable */
U8     subAction,          /* Trace/alarm */
U32    dbgMask,            /* debug mask */
TranId transId             /* Transaction Id */
)
#else
PUBLIC  S16 maCntrlReq(suId, elmnt, action, subAction, dbgMask, transId)
SuId   suId;               /* Sap Id */
U8     elmnt;              /* Element */
U8     action;             /* Enable/disable */
U8     subAction;          /* Trace/alarm */
U32    dbgMask;            /* debug mask */
TranId transId;            /* Transaction Id */
#endif 
{
   MaMngmt   *cntrl;       /* Control */
   Header    *hdr;         /* pointer to header */
   S16       ret;
   Data        *tmp;                /* temporary memory pointer */
   Pst post;

   TRC2(maCntrlReq)

   printf("maCntrlReq: suId=%d, elmnt=%d, action=%d, subAction=%d\n", 
            suId, elmnt, action, subAction);

   ret = SGetSBuf(maCb.maInit.region, maCb.maInit.pool, &tmp, sizeof(MaMngmt));
   if (ret!= ROK)
   {
      printf("maCntrlReq: memory allocation failed, suId=%d, elmnt=%d, action=%d, subAction=%d\n", 
      suId, elmnt, action, subAction);
      RETVALUE(RFAILED);
   }

   cntrl = (MaMngmt *)tmp;

   smMaPstInit(&post);
   
   hdr = &cntrl->hdr;
   maHdrInit(hdr);
   hdr->msgType          = TCNTRL;        /* Control */
   hdr->entId.ent        = ENTMA;         /* entity */
   hdr->entId.inst       = MA_INST;     /* instance */
   hdr->elmId.elmnt      = elmnt;         /* TC User sap */
   hdr->elmId.elmntInst1 = suId;          /* sap id */

   cntrl->t.cntrl.action    = action;
   cntrl->t.cntrl.subAction = subAction;

#ifdef DEBUGP
   cntrl->t.cntrl.s.dbg.dbgMask = dbgMask;
#else
   UNUSED(dbgMask);
#endif 
#ifdef SS_MULTIPLE_PROCS
   cntrl->t.cntrl.par.dstProcId = 0;
#else
   cntrl->t.cntrl.par.dstProcId = SFndProcId();  /* dst proc id */
#endif

   /* give Control request to layer */
   (Void) SmMiLmaCntrlReq(&post, cntrl);

   SPutSBuf(maCb.maInit.region, maCb.maInit.pool, (Data *)tmp, sizeof(MaMngmt));

   RETVALUE(ROK);
} /* end of maAccCntrlReq */

/********************************************************************************************************
  Function: smMaSendReqQ() 
  Description: sccp get msg buffer from sm queue, and send it out
  Calls:
  Called By: 
  Input:   smMsg: msg buffer get from sm queue 
               
  Output:  send LSP message to SP ENTITY

  
  Return:   ROK:success; 
                RFAILED: failure
  Others:
 ********************************************************************************************************/
S16 smMaSendReqQ(CmLList *node)
{
    Pst smMaPst;
    Header *msgHeader;
    S16 ret = ROK;
   
    TRC2(smMaSendReqQ);      
    msgHeader = (Header *)cmLListNode(node);


    smMaPstInit(&smMaPst);
    switch(msgHeader->msgType)
    {
        case TCFG:
            ret = SmMiLmaCfgReq(&smMaPst, (MaMngmt *)cmLListNode(node));
            break;
        case TCNTRL:
            ret = SmMiLmaCntrlReq(&smMaPst, (MaMngmt *)cmLListNode(node));
            break;
        case TSTS:
            ret = SmMiLmaStsReq(&smMaPst, NOZEROSTS, (MaMngmt *)cmLListNode(node));
            break;
        case TSSTA:
            ret = SmMiLmaStaReq(&smMaPst, (MaMngmt *)cmLListNode(node));
            break;
        default:
            RETVALUE(RFAILED);
    }

    RETVALUE(ret);
}


#endif /*CP_OAM_SUPPORT*/

