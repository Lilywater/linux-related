/**********************************************************************

    Name:   ma_cfg.h - Configuration for the MAP

    Type:   C include file

    Desc:   #define and macros for the MAP layer Configuration

    File:   ma_cfg.h

    Sid:    ma_cfg.h - 11/20/2001

**********************************************************************/
#ifndef _MA_CFG_H_
#define _MA_CFG_H_

/*---------------------------macro define----------------------------*/
/* system task priority */
#define SS_MAP_TSK_PRI	76

/* Local Define */
/*#define MA_INST_0	0	 map instance 0 */
#define MA_REG		0	/* memory region id */
#define MA_POOL		0	/* pool value */
#define MA_SEL_LC	0	/* selector 0 (loosely-coupled) */
#define MA_SEL_TC	1	/* selector 1 (tightly-coupled) */

/* Sap Ids */
#define MA_SAP_0	0	/* sap 0 */
#define MA_SAP_1	1	/* sap 1 */

/* Resources configuration in the MAP layer */
#define MA_MAX_SAPS				MA_MAX_USAPS			/* Maximum number of Saps */
#define MA_MAX_DLGS				20000		/* Maximum number of dialogues for per SAP 
											   and for the genCfg */
#define MA_MAX_OPRS				1000		/* for genCfg, but for the memory allocate reason,
											   it is no more use */
/* Timer define */
#define MA_GRD_TMR				100			/* 50 Guard  Timer */

/* Dialog Id Control */
#define MA_START_DLG_ID			1			/* start dialog id */
#define MA_DLG_ID_RANGE			20000		/* range of dialog id for bit map */

#ifndef MA_PERIOD
#define MA_PERIOD          1				/* timer resolution */
#endif

#define SM_INST 0
#define ST_INST 0
#define MA_INST 0
#define AU_INST 0
/*---------------------MAP initializing configure----------------------------*/ 

#define MA_TIME_RES				10

#define MA_TINT_TMR_VAL			10		/* */

/* return option not requested */
#define MA_REC_NSO          0x00      /* No Special Options */
#define MA_REC_ROE          0x08      /* Return on Error */

#define SM_MAP_TAB_NUM 6

/*xqc for SM*/
#define LMA_REASON_INV_GEN_PARA 0x9d /*Invalid general cfg parameters*/
#define LMA_REASON_INV_USAP_CFG 0x9e
#define LMA_REASON_EXC_SSN_NUM 0x9f
#define LMA_REASON_INV_NW_CFG 0xa0

#define cmCpy(s, d, c)	cmMemcpy((U8 *)d, (CONSTANT U8 *)s, c)
#define cmZero(s, c)	cmMemset((U8 *)s, 0, c)

typedef struct CP_MA_ALARM_DATA
{
    U32  	groupId;
    SuId	suId;
    U32 	cause;
    S32 	severity;
}CP_MA_ALARM_DATA;

typedef enum CP_MA_CONFIG_QUEUE_ID
{
    CP_MA_GEN_Q,
    CP_MA_SAP_Q,
#ifdef ZMP
    CP_ZM_GEN_Q,
    CP_ZM_RSET_Q,
#endif
    CP_MA_CONFIG_Q_TOTAL_NUM    
}CP_MA_CONFIG_QUEUE_ID;

#if 0 
extern maCfgData    gMaCfgData;
extern CmLListCp     gMaSmQ[CP_MA_CONFIG_Q_TOTAL_NUM];
#endif
/*----Jacken Add for SubAgent 2003/9/23 -----*/

/*---------------------------type define----------------------------*/

typedef struct _maInitCfg
{
	MaGenCfgTab	maGen;		/* MAP General Config */
	U8				sapNum;		/* map sap number */
	MaMAUCfgTab 	mAU[MA_MAX_SAPS];		/* MAP SAP Config */
} MaInitCfgTab;

/* MAP control parameter structure */
typedef struct _maCntrlPar
{
	int			par1;
	int			par2;
	int			par3;
} MaCntrlPar;

typedef struct CP_MA_CONFIG_DATA
{
	U16         maGenCfgNum;
	MaGenCfgTab maGenCfg;

	U16 maSapCfgNum;
	MaMAUCfgTab maSapCfg;/*[MA_MAX_SAPS];*/

   U16 maAcnCfgNum;
   MaACNCfgTab maAcnCfg;
}MaCfgData;


extern SmCb gSmCb[];
extern MaCfgData    gMaCfgData;
extern CmLListCp     gMaSmQ[CP_MA_CONFIG_Q_TOTAL_NUM];
extern U32 maCfgTbl[];

/*-------------------------Extern Declare ----------------------------*/
#ifdef __cplusplus
extern "C" {
#endif
EXTERN S16 maSapCfg(U16 nRec);
EXTERN S16 maGenCfg(U16 nRec);
EXTERN S16 smMaSendReqQ(CmLList *node);


#ifdef __cplusplus
}
#endif

#endif /* _MA_CFG_H_ */


