/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     stack manager - interface with INAP - error
  
     Type:     C include file
  
     Desc:     Error defines required by the stack manager.
   
     File:     smma_err.h
  
     Sid:      smma_err.h@@/main/8 - Fri Sep 16 02:40:27 2005
  
     Prg:      ssk 
  
*********************************************************************21*/

#ifndef __SMMAERRH_
#define __SMMAERRH_

/* error codes */

#define   ESMMA001      (ERRSMMA +    1)    /*   smmabdy1.c:1140 */
#define   ESMMA002      (ERRSMMA +    2)    /*   smmabdy1.c:1143 */
#define   ESMMA003      (ERRSMMA +    3)    /*   smmabdy1.c:1144 */
#define   ESMMA004      (ERRSMMA +    4)    /*   smmabdy1.c:1145 */
#define   ESMMA005      (ERRSMMA +    5)    /*   smmabdy1.c:1283 */
#define   ESMMA006      (ERRSMMA +    6)    /*   smmabdy1.c:1286 */
#define   ESMMA007      (ERRSMMA +    7)    /*   smmabdy1.c:1287 */
#define   ESMMA008      (ERRSMMA +    8)    /*   smmabdy1.c:1288 */
#define   ESMMA009      (ERRSMMA +    9)    /*   smmabdy1.c:1342 */
#define   ESMMA010      (ERRSMMA +   10)    /*   smmabdy1.c:1345 */
#define   ESMMA011      (ERRSMMA +   11)    /*   smmabdy1.c:1346 */
#define   ESMMA012      (ERRSMMA +   12)    /*   smmabdy1.c:1347 */

#define   ESMMA013      (ERRSMMA +   13)    /*   smmaexms.c: 239 */

#define   ESMMA014      (ERRSMMA +   14)    /*   smmaptmi.c: 429 */
#define   ESMMA015      (ERRSMMA +   15)    /*   smmaptmi.c: 469 */
#define   ESMMA016      (ERRSMMA +   16)    /*   smmaptmi.c: 511 */
#define   ESMMA017      (ERRSMMA +   17)    /*   smmaptmi.c: 551 */


#endif /* __SMMAERRH_*/

#ifndef MATST
#define MA_PRNTBUF_SIZE 128
#endif /*MATST*/

/********************************************************************30**

         End of file:     smma_err.h@@/main/8 - Fri Sep 16 02:40:27 2005

*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      aa   1. initial release.

1.2          ---      aa   1. Added error codes for packing additional parameter 
                              in ApnCfg (file smmaptmi.c)

1.3          ---      ssk  1. Changes for adding the MAP Phase 2+ variant
                              and for adding LMINT3

/main/4      ---      jie  1. update for MAP 1.5 release.
 
             ---      yz   1. Adding define MA_PRNTBUF_SIZE for non TST.
/main/5      ---      ssk  1. update for MAP 1.6 release.

/main/6      ---      jie  1. update for MAP 1.7 release.

/main/7      ---      cp   1. update for MAP 2.1 release.
/main/8      ---      st   1. Updated Copyright Information
*********************************************************************91*/
