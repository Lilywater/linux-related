
#ifndef __HI_INITH__
#define __HI_INITH__

PUBLIC S16 hi_init_fun(SSTskId hiTskId);


#endif  /*__HI_INITH__*/