/* ***************************************************************************
 *        (c) COPYRIGHT 1995-2006 by Xinwei, Inc.
 *                   All rights reserved.
 *
 * tucl_api.h:  
 *          this head file include all about use of tucl.
 *           
 * Author:
 *          zhouguishuang
 * Date:
 *          2006-5-8
 * Last Modified:
 *
 ****************************************************************************/
 
#ifndef  __TUCL_APIH__
#define  __TUCL_APIH__


#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_inet.h"       /* common sockets */
#include "cm_tpt.h"        /* common transport defines */
#ifdef FTHA
#include "sht.h"           /* SHT Interface header files */
#endif /* FTHA */
#include "lhi.h"           /* layer management, TUCL  */
#include "hit.h"           /* HIT interface */
#include "hi.h"            /* TUCL internal defines */
#include "hi_err.h"        /* TUCL error */
#ifdef H323_PERF
#include "hc_prf.h"        /* Performance measurement data structs */
#endif /* H323_PERF */
 
/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_inet.x"       /* common sockets */
#include "cm_tpt.x"        /* common transport typedefs */
#ifdef FTHA
#include "sht.x"           /* SHT Interface header file */
#endif /* FTHA */
#include "lhi.x"           /* layer management TUCL */
#include "hit.x"           /* HIT interface */
#include "hi.x"            /* TUCL internal typedefs */
#ifdef H323_PERF
#include "hc_prf.x"        /* Performance measurement data structs */
#endif /* H323_PERF */




#define  DEL_ENT                        0
#define  DEF_ENT                        0
#define  SEL_TC                         1
#define  SEL_LC                         0
#define  SB_PRNTBUF_SIZE                255
#define  SAP_1                          1
#define  SA3REGION                      DFLT_REGION      /* memory region id */
#define  SA3POOL                        DFLT_POOL        /* memory pool id */


#define SUID_0                  0
#define SUID_1                  1
#define SUID_2                  2
#define SUID_3                  3
#define SUID_4                  4

#define SPID_0                  0
#define SPID_1                  1
#define SPID_2                  2
#define SPID_3                  3
#define SPID_4                  4

/* defines for TUCL general configuration */
#define SO_TUCL_MAX_TSAP      5
#define SO_TUCL_MAX_CON       5000
#define SO_TUCL_FDS           1000
#define SO_TUCL_FDBINS        1000
#define SO_TUCL_STP_THRESH    5
#define SO_TUCL_DRP_THRESH    2
#define SO_TUCL_STRT_THRESH   4

/* defines for TUCL upper SAP configuration */
#define SO_TUCL_CONG_STRT     15000
#define SO_TUCL_CONG_DRP      20000
#define SO_TUCL_CONG_STP      10000
#define SO_TUCL_NMB_HLBINS    2


#define TUCL_PRINT_CONFIG_INFO    0x0001
#define TUCL_PRINT_LAYER_INFO     0x0002
#define TUCL_PRINT_SAP_INFO       0x0004
#define TUCL_PRINT_ALL_INFO       0x0008





/* Public variable declarations */
/* hi025.104 : Addition - Support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
extern PUBLIC HiCb hiCbLst[HI_MAX_INSTANCES];     /* TUCL control block */
extern PUBLIC HiCb *hiCbPtr;
#else /*  SS_MULTIPLE_PROCS */ 
extern PUBLIC HiCb  hiCb;         /* TUCL control block */
#endif /*  SS_MULTIPLE_PROCS */ 

#endif /* __TUCL_APIH__ */