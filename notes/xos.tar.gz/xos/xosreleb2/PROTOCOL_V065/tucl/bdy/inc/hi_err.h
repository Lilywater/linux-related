/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     TCP UDP Convergence Layer error file.
  
     Type:     C include file
  
     Desc:     Error Hash Defines required by HI layer
  
     File:     hi_err.h
  
     Sid:      hi_err.h@@/main/4 - Thu Jun 28 13:29:59 2001

     Prg:      asa
  
*********************************************************************21*/
  
#ifndef __HIERRH__
#define __HIERRH__



#if (ERRCLASS & ERRCLS_DEBUG)
#define HILOGERROR_DEBUG(errCode, errVal, inst, errDesc)                \
        SLogError(hiCb.hiInit.ent, inst, hiCb.hiInit.procId,            \
                  __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,             \
                  (ErrCode)errCode, (ErrVal)errVal, errDesc)
#else
#define HILOGERROR_DEBUG(errCode, errVal, inst, errDesc)        
#endif /* ERRCLS_DEBUG */

#if (ERRCLASS & ERRCLS_INT_PAR)
#define HILOGERROR_INT_PAR(errCode, errVal, inst, errDesc)              \
        SLogError(hiCb.hiInit.ent, inst, hiCb.hiInit.procId,            \
                  __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,           \
                  (ErrCode)errCode, (ErrVal)errVal, errDesc)
#else
#define HILOGERROR_INT_PAR(errCode, errVal, inst, errDesc)      
#endif /* ERRCLS_INT_PAR */

#if (ERRCLASS & ERRCLS_ADD_RES)
#define HILOGERROR_ADD_RES(errCode, errVal, inst, errDesc)              \
        SLogError(hiCb.hiInit.ent, inst, hiCb.hiInit.procId,            \
                  __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,           \
                  (ErrCode)errCode, (ErrVal)errVal, errDesc)
#else
#define HILOGERROR_ADD_RES(errCode, errVal, errDesc, inst)
#endif /* ERRCLS_ADD_RES */

#define   EHIBASE     0
#define   EHIXXX      (EHIBASE   +0)    /* reserved */
#define   ERRHI       (EHIBASE   +0)    /* reserved */
 
#define   EHI001      (ERRHI +    1)    /*    hi_bdy1.c: 379 */
#define   EHI002      (ERRHI +    2)    /*    hi_bdy1.c: 482 */
#define   EHI003      (ERRHI +    3)    /*    hi_bdy1.c: 510 */
#define   EHI004      (ERRHI +    4)    /*    hi_bdy1.c: 522 */
#define   EHI005      (ERRHI +    5)    /*    hi_bdy1.c: 544 */
#define   EHI006      (ERRHI +    6)    /*    hi_bdy1.c: 636 */
#define   EHI007      (ERRHI +    7)    /*    hi_bdy1.c: 886 */
#define   EHI008      (ERRHI +    8)    /*    hi_bdy1.c: 899 */
#define   EHI009      (ERRHI +    9)    /*    hi_bdy1.c: 916 */
#define   EHI010      (ERRHI +   10)    /*    hi_bdy1.c: 993 */
#define   EHI011      (ERRHI +   11)    /*    hi_bdy1.c:1090 */
#define   EHI012      (ERRHI +   12)    /*    hi_bdy1.c:1237 */
#define   EHI013      (ERRHI +   13)    /*    hi_bdy1.c:1247 */
#define   EHI014      (ERRHI +   14)    /*    hi_bdy1.c:1265 */
#define   EHI015      (ERRHI +   15)    /*    hi_bdy1.c:1341 */
#define   EHI016      (ERRHI +   16)    /*    hi_bdy1.c:1366 */
#define   EHI017      (ERRHI +   17)    /*    hi_bdy1.c:1385 */
#define   EHI018      (ERRHI +   18)    /*    hi_bdy1.c:1426 */
#define   EHI019      (ERRHI +   19)    /*    hi_bdy1.c:1436 */
#define   EHI020      (ERRHI +   20)    /*    hi_bdy1.c:1441 */
#define   EHI021      (ERRHI +   21)    /*    hi_bdy1.c:1507 */
#define   EHI022      (ERRHI +   22)    /*    hi_bdy1.c:1517 */
#define   EHI023      (ERRHI +   23)    /*    hi_bdy1.c:1543 */
#define   EHI024      (ERRHI +   24)    /*    hi_bdy1.c:1588 */
#define   EHI025      (ERRHI +   25)    /*    hi_bdy1.c:1598 */
#define   EHI026      (ERRHI +   26)    /*    hi_bdy1.c:1605 */
#define   EHI027      (ERRHI +   27)    /*    hi_bdy1.c:1626 */
#define   EHI028      (ERRHI +   28)    /*    hi_bdy1.c:1661 */
#define   EHI029      (ERRHI +   29)    /*    hi_bdy1.c:1842 */
#define   EHI030      (ERRHI +   30)    /*    hi_bdy1.c:1883 */
#define   EHI031      (ERRHI +   31)    /*    hi_bdy1.c:1920 */
#define   EHI032      (ERRHI +   32)    /*    hi_bdy1.c:1958 */
#define   EHI033      (ERRHI +   33)    /*    hi_bdy1.c:2140 */
#define   EHI034      (ERRHI +   34)    /*    hi_bdy1.c:2150 */
#define   EHI035      (ERRHI +   35)    /*    hi_bdy1.c:2158 */
#define   EHI036      (ERRHI +   36)    /*    hi_bdy1.c:2199 */
#define   EHI037      (ERRHI +   37)    /*    hi_bdy1.c:2221 */
#define   EHI038      (ERRHI +   38)    /*    hi_bdy1.c:2264 */
#define   EHI039      (ERRHI +   39)    /*    hi_bdy1.c:2274 */
#define   EHI040      (ERRHI +   40)    /*    hi_bdy1.c:2279 */
#define   EHI041      (ERRHI +   41)    /*    hi_bdy1.c:2350 */
#define   EHI042      (ERRHI +   42)    /*    hi_bdy1.c:2360 */
#define   EHI043      (ERRHI +   43)    /*    hi_bdy1.c:2377 */
#define   EHI044      (ERRHI +   44)    /*    hi_bdy1.c:2403 */
#define   EHI045      (ERRHI +   45)    /*    hi_bdy1.c:2413 */
#define   EHI046      (ERRHI +   46)    /*    hi_bdy1.c:2458 */
#define   EHI047      (ERRHI +   47)    /*    hi_bdy1.c:2468 */
#define   EHI048      (ERRHI +   48)    /*    hi_bdy1.c:2554 */
#define   EHI049      (ERRHI +   49)    /*    hi_bdy1.c:2627 */
#define   EHI050      (ERRHI +   50)    /*    hi_bdy1.c:2666 */
#define   EHI051      (ERRHI +   51)    /*    hi_bdy1.c:2696 */
#define   EHI052      (ERRHI +   52)    /*    hi_bdy1.c:2736 */
#define   EHI053      (ERRHI +   53)    /*    hi_bdy1.c:2832 */
#define   EHI054      (ERRHI +   54)    /*    hi_bdy1.c:2843 */
#define   EHI055      (ERRHI +   55)    /*    hi_bdy1.c:2951 */
#define   EHI056      (ERRHI +   56)    /*    hi_bdy1.c:2961 */
#define   EHI057      (ERRHI +   57)    /*    hi_bdy1.c:2996 */
#define   EHI058      (ERRHI +   58)    /*    hi_bdy1.c:3040 */
#define   EHI059      (ERRHI +   59)    /*    hi_bdy1.c:3060 */
#define   EHI060      (ERRHI +   60)    /*    hi_bdy1.c:3176 */
#define   EHI061      (ERRHI +   61)    /*    hi_bdy1.c:3187 */
#define   EHI062      (ERRHI +   62)    /*    hi_bdy1.c:3202 */
#define   EHI063      (ERRHI +   63)    /*    hi_bdy1.c:3218 */
#define   EHI064      (ERRHI +   64)    /*    hi_bdy1.c:3491 */
#define   EHI065      (ERRHI +   65)    /*    hi_bdy1.c:3497 */
#define   EHI066      (ERRHI +   66)    /*    hi_bdy1.c:3524 */
#define   EHI067      (ERRHI +   67)    /*    hi_bdy1.c:3530 */
#define   EHI068      (ERRHI +   68)    /*    hi_bdy1.c:3719 */
#define   EHI069      (ERRHI +   69)    /*    hi_bdy1.c:3735 */
#define   EHI070      (ERRHI +   70)    /*    hi_bdy1.c:3747 */
#define   EHI071      (ERRHI +   71)    /*    hi_bdy1.c:3762 */
#define   EHI072      (ERRHI +   72)    /*    hi_bdy1.c:3775 */
#define   EHI073      (ERRHI +   73)    /*    hi_bdy1.c:3848 */
#define   EHI074      (ERRHI +   74)    /*    hi_bdy1.c:3894 */
#define   EHI075      (ERRHI +   75)    /*    hi_bdy1.c:3942 */
#define   EHI076      (ERRHI +   76)    /*    hi_bdy1.c:4160 */
#define   EHI077      (ERRHI +   77)    /*    hi_bdy1.c:4170 */
#define   EHI078      (ERRHI +   78)    /*    hi_bdy1.c:4322 */
#define   EHI079      (ERRHI +   79)    /*    hi_bdy1.c:4332 */
#define   EHI080      (ERRHI +   80)    /*    hi_bdy1.c:4348 */
#define   EHI081      (ERRHI +   81)    /*    hi_bdy1.c:4491 */
#define   EHI082      (ERRHI +   82)    /*    hi_bdy1.c:4679 */
#define   EHI083      (ERRHI +   83)    /*    hi_bdy1.c:4699 */
#define   EHI084      (ERRHI +   84)    /*    hi_bdy1.c:4709 */
#define   EHI085      (ERRHI +   85)    /*    hi_bdy1.c:4713 */
#define   EHI086      (ERRHI +   86)    /*    hi_bdy1.c:4724 */
#define   EHI087      (ERRHI +   87)    /*    hi_bdy1.c:4951 */
#define   EHI088      (ERRHI +   88)    /*    hi_bdy1.c:5019 */
#define   EHI089      (ERRHI +   89)    /*    hi_bdy1.c:5085 */

#define   EHI090      (ERRHI +   90)    /*    hi_bdy2.c: 165 */
#define   EHI091      (ERRHI +   91)    /*    hi_bdy2.c: 171 */
#define   EHI092      (ERRHI +   92)    /*    hi_bdy2.c: 390 */
#define   EHI093      (ERRHI +   93)    /*    hi_bdy2.c: 622 */
#define   EHI094      (ERRHI +   94)    /*    hi_bdy2.c: 655 */
#define   EHI095      (ERRHI +   95)    /*    hi_bdy2.c: 661 */
#define   EHI096      (ERRHI +   96)    /*    hi_bdy2.c: 671 */
#define   EHI097      (ERRHI +   97)    /*    hi_bdy2.c: 685 */
#define   EHI098      (ERRHI +   98)    /*    hi_bdy2.c: 690 */
#define   EHI099      (ERRHI +   99)    /*    hi_bdy2.c: 744 */
#define   EHI100      (ERRHI +  100)    /*    hi_bdy2.c: 755 */
#define   EHI101      (ERRHI +  101)    /*    hi_bdy2.c: 762 */
#define   EHI102      (ERRHI +  102)    /*    hi_bdy2.c: 771 */
#define   EHI103      (ERRHI +  103)    /*    hi_bdy2.c: 900 */
#define   EHI104      (ERRHI +  104)    /*    hi_bdy2.c: 910 */
#define   EHI105      (ERRHI +  105)    /*    hi_bdy2.c:1382 */
#define   EHI106      (ERRHI +  106)    /*    hi_bdy2.c:1974 */
#define   EHI107      (ERRHI +  107)    /*    hi_bdy2.c:1983 */
#define   EHI108      (ERRHI +  108)    /*    hi_bdy2.c:2246 */
#define   EHI109      (ERRHI +  109)    /*    hi_bdy2.c:2284 */
#define   EHI110      (ERRHI +  110)    /*    hi_bdy2.c:2356 */
#define   EHI111      (ERRHI +  111)    /*    hi_bdy2.c:2371 */
#define   EHI112      (ERRHI +  112)    /*    hi_bdy2.c:2385 */
#define   EHI113      (ERRHI +  113)    /*    hi_bdy2.c:2500 */
#define   EHI114      (ERRHI +  114)    /*    hi_bdy2.c:2564 */
#define   EHI115      (ERRHI +  115)    /*    hi_bdy2.c:2608 */
#define   EHI116      (ERRHI +  116)    /*    hi_bdy2.c:2702 */
#define   EHI117      (ERRHI +  117)    /*    hi_bdy2.c:2955 */
#define   EHI118      (ERRHI +  118)    /*    hi_bdy2.c:2966 */
#define   EHI119      (ERRHI +  119)    /*    hi_bdy2.c:3193 */
#define   EHI120      (ERRHI +  120)    /*    hi_bdy2.c:3199 */
#define   EHI121      (ERRHI +  121)    /*    hi_bdy2.c:3200 */
#define   EHI122      (ERRHI +  122)    /*    hi_bdy2.c:3241 */
#define   EHI123      (ERRHI +  123)    /*    hi_bdy2.c:3242 */
#define   EHI124      (ERRHI +  124)    /*    hi_bdy2.c:3305 */
#define   EHI125      (ERRHI +  125)    /*    hi_bdy2.c:3316 */
#define   EHI126      (ERRHI +  126)    /*    hi_bdy2.c:3327 */
#define   EHI127      (ERRHI +  127)    /*    hi_bdy2.c:3345 */
#define   EHI128      (ERRHI +  128)    /*    hi_bdy2.c:3366 */
#define   EHI129      (ERRHI +  129)    /*    hi_bdy2.c:3458 */
#define   EHI130      (ERRHI +  130)    /*    hi_bdy2.c:3469 */
#define   EHI131      (ERRHI +  131)    /*    hi_bdy2.c:3474 */
#define   EHI132      (ERRHI +  132)    /*    hi_bdy2.c:3527 */
#define   EHI133      (ERRHI +  133)    /*    hi_bdy2.c:3636 */
#define   EHI134      (ERRHI +  134)    /*    hi_bdy2.c:3752 */
#define   EHI135      (ERRHI +  135)    /*    hi_bdy2.c:3855 */
#define   EHI136      (ERRHI +  136)    /*    hi_bdy2.c:4133 */
#define   EHI137      (ERRHI +  137)    /*    hi_bdy2.c:4590 */
#define   EHI138      (ERRHI +  138)    /*    hi_bdy2.c:4634 */
#define   EHI139      (ERRHI +  139)    /*    hi_bdy2.c:4654 */
#define   EHI140      (ERRHI +  140)    /*    hi_bdy2.c:4745 */
#define   EHI141      (ERRHI +  141)    /*    hi_bdy2.c:4825 */
#define   EHI142      (ERRHI +  142)    /*    hi_bdy2.c:4927 */
#define   EHI143      (ERRHI +  143)    /*    hi_bdy2.c:4934 */
#define   EHI144      (ERRHI +  144)    /*    hi_bdy2.c:5021 */
#define   EHI145      (ERRHI +  145)    /*    hi_bdy2.c:5044 */
#define   EHI146      (ERRHI +  146)    /*    hi_bdy2.c:5062 */
#define   EHI147      (ERRHI +  147)    /*    hi_bdy2.c:5123 */
#define   EHI148      (ERRHI +  148)    /*    hi_bdy2.c:5137 */
#define   EHI149      (ERRHI +  149)    /*    hi_bdy2.c:5202 */
#define   EHI150      (ERRHI +  150)    /*    hi_bdy2.c:5251 */
#define   EHI151      (ERRHI +  151)    /*    hi_bdy2.c:5259 */
#define   EHI152      (ERRHI +  152)    /*    hi_bdy2.c:5313 */
#define   EHI153      (ERRHI +  153)    /*    hi_bdy2.c:5327 */
#define   EHI154      (ERRHI +  154)    /*    hi_bdy2.c:5361 */
#define   EHI155      (ERRHI +  155)    /*    hi_bdy2.c:5381 */
#define   EHI156      (ERRHI +  156)    /*    hi_bdy2.c:5455 */
#define   EHI157      (ERRHI +  157)    /*    hi_bdy2.c:5485 */
#define   EHI158      (ERRHI +  158)    /*    hi_bdy2.c:5521 */
#define   EHI159      (ERRHI +  159)    /*    hi_bdy2.c:5568 */
#define   EHI160      (ERRHI +  160)    /*    hi_bdy2.c:5640 */
#define   EHI161      (ERRHI +  161)    /*    hi_bdy2.c:5652 */
#define   EHI162      (ERRHI +  162)    /*    hi_bdy2.c:5666 */
#define   EHI163      (ERRHI +  163)    /*    hi_bdy2.c:5715 */
#define   EHI164      (ERRHI +  164)    /*    hi_bdy2.c:5726 */
#define   EHI165      (ERRHI +  165)    /*    hi_bdy2.c:5787 */
#define   EHI166      (ERRHI +  166)    /*    hi_bdy2.c:5793 */
#define   EHI167      (ERRHI +  167)    /*    hi_bdy2.c:5794 */
#define   EHI168      (ERRHI +  168)    /*    hi_bdy2.c:5795 */
#define   EHI169      (ERRHI +  169)    /*    hi_bdy2.c:5796 */
#define   EHI170      (ERRHI +  170)    /*    hi_bdy2.c:5840 */
#define   EHI171      (ERRHI +  171)    /*    hi_bdy2.c:5841 */
#define   EHI172      (ERRHI +  172)    /*    hi_bdy2.c:5842 */
#define   EHI173      (ERRHI +  173)    /*    hi_bdy2.c:5843 */
#define   EHI174      (ERRHI +  174)    /*    hi_bdy2.c:5900 */
#define   EHI175      (ERRHI +  175)    /*    hi_bdy2.c:5906 */
#define   EHI176      (ERRHI +  176)    /*    hi_bdy2.c:5907 */
#define   EHI177      (ERRHI +  177)    /*    hi_bdy2.c:5946 */
#define   EHI178      (ERRHI +  178)    /*    hi_bdy2.c:5947 */
#define   EHI179      (ERRHI +  179)    /*    hi_bdy2.c:6000 */
#define   EHI180      (ERRHI +  180)    /*    hi_bdy2.c:6006 */
#define   EHI181      (ERRHI +  181)    /*    hi_bdy2.c:6044 */
#define   EHI182      (ERRHI +  182)    /*    hi_bdy2.c:6106 */
#define   EHI183      (ERRHI +  183)    /*    hi_bdy2.c:6199 */
#define   EHI184      (ERRHI +  184)    /*    hi_bdy2.c:6205 */
#define   EHI185      (ERRHI +  185)    /*    hi_bdy2.c:6246 */
#define   EHI186      (ERRHI +  186)    /*    hi_bdy2.c:6305 */
#define   EHI187      (ERRHI +  187)    /*    hi_bdy2.c:6311 */
#define   EHI188      (ERRHI +  188)    /*    hi_bdy2.c:6352 */
#define   EHI189      (ERRHI +  189)    /*    hi_bdy2.c:6648 */
#define   EHI190      (ERRHI +  190)    /*    hi_bdy2.c:6670 */
#define   EHI191      (ERRHI +  191)    /*    hi_bdy2.c:6794 */
#define   EHI192      (ERRHI +  192)    /*    hi_bdy2.c:6833 */
#define   EHI193      (ERRHI +  193)    /*    hi_bdy2.c:6938 */

#define   EHI194      (ERRHI +  194)    /*    hi_bdy3.c: 188 */
#define   EHI195      (ERRHI +  195)    /*    hi_bdy3.c: 198 */
#define   EHI196      (ERRHI +  196)    /*    hi_bdy3.c: 202 */
#define   EHI197      (ERRHI +  197)    /*    hi_bdy3.c: 217 */
#define   EHI198      (ERRHI +  198)    /*    hi_bdy3.c: 227 */
#define   EHI199      (ERRHI +  199)    /*    hi_bdy3.c: 231 */
#define   EHI200      (ERRHI +  200)    /*    hi_bdy3.c: 505 */
#define   EHI201      (ERRHI +  201)    /*    hi_bdy3.c: 564 */
#define   EHI202      (ERRHI +  202)    /*    hi_bdy3.c: 584 */
#define   EHI203      (ERRHI +  203)    /*    hi_bdy3.c: 756 */
#define   EHI204      (ERRHI +  204)    /*    hi_bdy3.c: 765 */
#define   EHI205      (ERRHI +  205)    /*    hi_bdy3.c: 783 */
#define   EHI206      (ERRHI +  206)    /*    hi_bdy3.c: 792 */
#define   EHI207      (ERRHI +  207)    /*    hi_bdy3.c:1059 */
#define   EHI208      (ERRHI +  208)    /*    hi_bdy3.c:1363 */
#define   EHI209      (ERRHI +  209)    /*    hi_bdy3.c:1375 */
#define   EHI210      (ERRHI +  210)    /*    hi_bdy3.c:1529 */
#define   EHI211      (ERRHI +  211)    /*    hi_bdy3.c:1543 */
#define   EHI212      (ERRHI +  212)    /*    hi_bdy3.c:1638 */
#define   EHI213      (ERRHI +  213)    /*    hi_bdy3.c:1702 */
#define   EHI214      (ERRHI +  214)    /*    hi_bdy3.c:2085 */
#define   EHI215      (ERRHI +  215)    /*    hi_bdy3.c:2226 */
#define   EHI216      (ERRHI +  216)    /*    hi_bdy3.c:2259 */
#define   EHI217      (ERRHI +  217)    /*    hi_bdy3.c:2264 */
#define   EHI218      (ERRHI +  218)    /*    hi_bdy3.c:2269 */
#define   EHI219      (ERRHI +  219)    /*    hi_bdy3.c:2278 */
#define   EHI220      (ERRHI +  220)    /*    hi_bdy3.c:2313 */
#define   EHI221      (ERRHI +  221)    /*    hi_bdy3.c:2335 */
#define   EHI222      (ERRHI +  222)    /*    hi_bdy3.c:2376 */
#define   EHI223      (ERRHI +  223)    /*    hi_bdy3.c:2450 */
#define   EHI224      (ERRHI +  224)    /*    hi_bdy3.c:2469 */
#define   EHI225      (ERRHI +  225)    /*    hi_bdy3.c:2544 */
#define   EHI226      (ERRHI +  226)    /*    hi_bdy3.c:2644 */
#define   EHI227      (ERRHI +  227)    /*    hi_bdy3.c:2758 */
#define   EHI228      (ERRHI +  228)    /*    hi_bdy3.c:2789 */
#define   EHI229      (ERRHI +  229)    /*    hi_bdy3.c:2885 */
#define   EHI230      (ERRHI +  230)    /*    hi_bdy3.c:2923 */
#define   EHI231      (ERRHI +  231)    /*    hi_bdy3.c:3158 */
#define   EHI232      (ERRHI +  232)    /*    hi_bdy3.c:3366 */
#define   EHI233      (ERRHI +  233)    /*    hi_bdy3.c:3375 */
#define   EHI234      (ERRHI +  234)    /*    hi_bdy3.c:3395 */
#define   EHI235      (ERRHI +  235)    /*    hi_bdy3.c:3404 */
#define   EHI236      (ERRHI +  236)    /*    hi_bdy3.c:3418 */
#define   EHI237      (ERRHI +  237)    /*    hi_bdy3.c:3442 */
#define   EHI238      (ERRHI +  238)    /*    hi_bdy3.c:3460 */
#define   EHI239      (ERRHI +  239)    /*    hi_bdy3.c:3503 */
#define   EHI240      (ERRHI +  240)    /*    hi_bdy3.c:3596 */
#define   EHI241      (ERRHI +  241)    /*    hi_bdy3.c:3689 */
#define   EHI242      (ERRHI +  242)    /*    hi_bdy3.c:3697 */
#define   EHI243      (ERRHI +  243)    /*    hi_bdy3.c:3717 */
#define   EHI244      (ERRHI +  244)    /*    hi_bdy3.c:3726 */
#define   EHI245      (ERRHI +  245)    /*    hi_bdy3.c:3740 */
#define   EHI246      (ERRHI +  246)    /*    hi_bdy3.c:3763 */
#define   EHI247      (ERRHI +  247)    /*    hi_bdy3.c:3794 */
#define   EHI248      (ERRHI +  248)    /*    hi_bdy3.c:3871 */
#define   EHI249      (ERRHI +  249)    /*    hi_bdy3.c:3926 */
#define   EHI250      (ERRHI +  250)    /*    hi_bdy3.c:3934 */
#define   EHI251      (ERRHI +  251)    /*    hi_bdy3.c:4030 */
#define   EHI252      (ERRHI +  252)    /*    hi_bdy3.c:4037 */
#define   EHI253      (ERRHI +  253)    /*    hi_bdy3.c:4047 */

#define   EHI254      (ERRHI +  254)    /*   hi_ex_ms.c: 229 */
#define   EHI255      (ERRHI +  255)    /*   hi_ex_ms.c: 303 */
#define   EHI256      (ERRHI +  256)    /*   hi_ex_ms.c: 327 */
#define   EHI257      (ERRHI +  257)    /*   hi_ex_ms.c: 368 */
#define   EHI258      (ERRHI +  258)    /*   hi_ex_ms.c: 378 */

#define   EHI259      (ERRHI +  259)    /*    hi_ptui.c:1169 */
#define   EHI260      (ERRHI +  260)    /*    hi_ptui.c:1210 */
#define   EHI261      (ERRHI +  261)    /*    hi_ptui.c:1249 */
#define   EHI262      (ERRHI +  262)    /*    hi_ptui.c:1291 */
#define   EHI263      (ERRHI +  263)    /*    hi_ptui.c:1349 */
#define   EHI264      (ERRHI +  264)    /*    hi_ptui.c:1391 */
#define   EHI265      (ERRHI +  265)    /*    hi_ptui.c:1432 */
#define   EHI266      (ERRHI +  266)    /*    hi_ptui.c:1481 */
/* Patch hi025.104 Error code for Multiple Procs */
#define   EHI267      (ERRHI +  267)    /*    hi_bdy1.c: 428 */
#define   EHI268      (ERRHI +  268)    /*    hi_init.c: 36 */
#endif /* __HIERRH__ */
 


/********************************************************************30**
 
         End of file:     hi_err.h@@/main/4 - Thu Jun 28 13:29:59 2001

*********************************************************************31*/
 

/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 

/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      asa  1. initial release.
/main/4      ---      cvp   1. updated error codes.
                           2. changed the copyright header.
/main/4      ---      cvp  1. updated error codes.
                           2. changed the copyright header.
/main/4+   hi025.104  pr   1. Error code for multiple procs added.
*********************************************************************91*/
