/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**

     Name:    TCP UDP Convergence Layer (TUCL)
  
     Type:    C source file
  
     Desc:    product id file  
              
     File:    hi_id.c
  
     Sid:      hi_id.c@@/main/4 - Thu Jun 28 13:30:18 2001
  
     Prg:     asa
  
*********************************************************************21*/

/* header include files (.h) */
  
#include "envopt.h"           /* environment options */
#include "envdep.h"           /* environment dependent */
#include "envind.h"           /* environment independent */
  
#include "gen.h"              /* general layer */
#include "ssi.h"              /* system services */
#include "cm_inet.h"          /* common sockets */
#include "lhi.h"              /* layer management */
  
/* header/extern include files (.x) */
  
#include "gen.x"              /* general layer */
#include "ssi.x"              /* system services */
  
/* defines */
  
#define HISWMV 1            /* TUCL - main version */
#define HISWMR 4            /* TUCL - main revision */
#define HISWBV 0            /* TUCL - branch version */

/* hi001.104 - Changed the revision number */
/* hi002.104 - Changed the revision number */
/* hi003.104 - Changed the revision number */
/* hi004.104 - Changed the revision number */
/* hi005.104 - Changed the revision number */
/* hi006.104 - Changed the revision number */
/* hi007.104 - Changed the revision number */
/* hi008.104 - Changed the revision number */
/* hi009.104 - Changed the revision number */
/* hi010.104 - Changed the revision number */
/* hi011.104 - Changed the revision number */
/* hi012.104 - Changed the revision number */
/* hi013.104 - Changed the revision number */
/* hi014.104 - Changed the revision number */
/* hi015.104 - Changed the revision number */
/* hi016.104 - Changed the revision number */
/* hi017.104 - Changed the revision number */
/* hi018.104 - Changed the revision number */
/* hi019.104 - Changed the revision number */
/* hi020.104 - Changed the revision number */
/* hi021.104 - Changed the revision number */
/* hi022.104 - Changed the revision number */
/* hi026.104 - Changed the revision number */
/* hi027.104 - Changed the revision number */
#define HISWBR 29            /* TUCL - branch revision */


#define HISWPN "1000158"    /* TUCL - part number */
  
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* forward references */

PUBLIC S16 hiGetSid ARGS((SystemId *sid));

/* public variable declarations */
  
/* copyright banner */
  
CONSTANT PUBLIC Txt hiBan1[] ={"(c) COPYRIGHT 1989-2000, Trillium Digital Systems, Inc."};
CONSTANT PUBLIC Txt hiBan2[] ={"                 All rights reserved."};
  
/* system id */
  
PRIVATE CONSTANT SystemId sId ={
   HISWMV,                    /* main version */
   HISWMR,                    /* main revision */
   HISWBV,                    /* branch version */
   HISWBR,                    /* branch revision */
   HISWPN,                    /* part number */
};

  
/*
*     support functions
*/

  
/*
*
*       Fun:   hiGetSid
*
*       Desc:  Get system id consisting of part number, main version and
*              revision and branch version and branch.
*
*       Ret:   TRUE      - ok
*
*       Notes: None
*
*       File:  hi_id.c
*
*/
#ifdef ANSI
PUBLIC S16 hiGetSid
(
SystemId *s                 /* system id */
)
#else
PUBLIC S16 hiGetSid(s)
SystemId *s;                /* system id */
#endif
{
   TRC2(hiGetSid)

   s->mVer = sId.mVer;
   s->mRev = sId.mRev;
   s->bVer = sId.bVer;
   s->bRev = sId.bRev;
   s->ptNmb = sId.ptNmb;

   RETVALUE(TRUE);

} /* hiGetSid */

#ifdef __cplusplus
}
#endif /* __cplusplus */

  

/********************************************************************30**

         End of file:     hi_id.c@@/main/4 - Thu Jun 28 13:30:18 2001

*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      asa  1. initial release.
/main/2       ---      cvp  1. changed main revision.
                          2. changed the copyright header.
             /main/4                cvp  1. changed the main revision.
/main/4+     ---      cvp  1. changed the revision number.
/main/4+     hi002.13 cvp  1. changed the revision number.
/main/4+     hi004.13 cvp  1. changed the revision number.
/main/4+     hi005.13 cvp  1. changed the revision number.
/main/4+     hi007.13 cvp  1. changed the revision number.
/main/4      ---      cvp  1. Changed the main revision.
                           2. Changed the copyright header.
/main/4+     hi001.104 mmh  1. changed the revision number.
/main/4+     hi002.104 mmh  1. changed the revision number.
/main/4+     hi003.104 ml  1. changed the revision number.
/main/4+     hi004.104 rs  1. changed the revision number.
/main/4+     hi005.104 bdu 1. Changed the revision number.
/main/4+     hi006.104 mmh 1. Changed the revision number.
/main/4+     hi007.104 mmh 1. Changed the revision number.
/main/4+     hi008.104 mmh 1. Changed the revision number.
/main/4+     hi009.104 mmh 1. Changed the revision number.
/main/4+     hi010.104 bdu 1. Changed the revision number.
/main/4+     hi011.104 bdu 1. Changed the revision number.
/main/4+     hi012.104 bdu 1. Changed the revision number.
/main/4+     hi013.104 bdu 1. Changed the revision number.
/main/4+     hi014.104 bdu 1. Changed the revision number.
/main/4+     hi015.104 zmc 1. Changed the revision number.
/main/4+     hi016.104 zmc 1. Changed the revision number.
/main/4+     hi017.104 zmc 1. Changed the revision number.
/main/4+     hi018.104 rs  1. Changed the revision number.
/main/4+     hi019.104 zmc 1. Changed the revision number.
/main/4+     hi020.104 rs  1. Changed the revision number.
/main/4+     hi021.104 rs  1. Changed the revision number.
/main/4+     hi022.104 rs  1. Changed the revision number.
/main/4+     hi023.104 jc  1. Changed the revision number.
/main/4+     hi024.104 jc  1. Changed the revision number.
/main/4+     hi025.104 pr  1. Changed the revision number.
/main/4+     hi026.104 jc  1. Changed the revision number.
/main/4+     hi027.104 jc  1. Changed the revision number.
/main/4+     hi028.104 jc  1. Changed the revision number.
/main/4+     hi029.104 jc  1. Changed the revision number.
*********************************************************************91*/
