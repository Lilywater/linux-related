/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**

     Name:    TCP UDP Convergence Layer - external - mos
              (TUCL)
  
     Type:    C source file
  
     Desc:    Functions required for scheduling and initialization.
  
              
     File:    hi_ex_ms.c
  
     Sid:      hi_ex_ms.c@@/main/sip_rel_1.2_dev/1 - Thu Apr 11 10:14:43 2002

     Prg:     asa
  
*********************************************************************21*/

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_inet.h"       /* common sockets */
#ifdef FTHA
#include "sht.h"           /* SHT Interface header file */
#endif /* FTHA */
#include "lhi.h"           /* layer management, HI */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm_err.h"        /* common error */
#include "cm5.h"           /* common timer */
#include "cm_tpt.h"        /* common transport defines */
#include "hit.h"           /* hit interface */
#include "hi.h"            /* HI layer */
#include "hi_err.h"        /* HI error */
#ifdef H323_PERF
#include "hc_prf.h"      /* Performance measurement data structs */
#endif /* H323_PERF */

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_inet.x"       /* common sockets */
#ifdef FTHA
#include "sht.x"           /* SHT Interface header file */
#endif /* FTHA */
#include "lhi.x"           /* layer management, HI */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm5.x"           /* common timer */
#include "cm_lib.x"        /* common library */
#include "cm_tpt.x"        /* common transport typedefs */
#include "hit.x"           /* hit interface */
#include "hi.x"            /* HI layer */
#ifdef H323_PERF
#include "hc_prf.x"      /* Performance measurement data structs */
#endif /* H323_PERF */

  
/* local defines */

/* local typedefs */
  
/* local externs */
  
/* functions in other modules */

/* public variable declarations */

/* private variable declarations */
  
  
/*
*     support functions
*/

/* ------------------------------------------------------------ */


/*
*
*       Fun:    initialize external
*
*       Desc:   Initializes variables used to interface with Upper/Lower
*               Layer  
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   hi_ex_ms.c
*
*/
#ifdef ANSI
PUBLIC S16 hiInitExt
(
void
)
#else
PUBLIC S16 hiInitExt()
#endif
{

   TRC2(hiInitExt)

   RETVALUE(ROK);
} /* end of hiInitExt */


/*
*
*       Fun:    activation task
*
*       Desc:   Processes received event from Upper/Lower Layer
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   hi_ex_ms.c
*
*/
#ifdef ANSI
PUBLIC S16 hiActvTsk
(
Pst    *pst,                /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 hiActvTsk(pst, mBuf)
Pst    *pst;                /* post */
Buffer *mBuf;               /* message buffer */
#endif
{

   /* hi021.104 - Initializing ret */
   S16 ret = ROK;
   /* hi009.104 - declare memInfo to be passed down */
#ifdef IPV6_OPTS_SUPPORTED    
   Mem memInfo;             /* mem info passed when calling cmUnpkHitUDatReq */
#endif

/* hi009.104 - added to generate alarm */
#ifdef HI_RUG
   HiAlarmInfo info;
#endif /* HI_RUG */
   
   TRC3(hiActvTsk)

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId, pst->dstEnt, pst->dstInst,
                          (Void **)&hiCbPtr)) != ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "hiActvTsk() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }
   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */

   /* hi009.104 - fill up alarm information */      
#ifdef HI_RUG
   /* init the alarm info structure */   
   info.spId = -1; /* set to this value to indiacte error */
   info.type = LHI_ALARMINFO_TYPE_INFVER;
#endif /* HI_RUG */

   switch(pst->srcEnt)
   {
#ifdef LCHIMILHI
      case ENTSM:
      {
         switch(pst->event)
         {
            case EVTLHICFGREQ:       /* Configuration Request */
               ret = cmUnpkLhiCfgReq(HiMiLhiCfgReq, pst, mBuf);
               break;
            case EVTLHISTSREQ:       /* Statistics Request */
               ret = cmUnpkLhiStsReq(HiMiLhiStsReq, pst, mBuf);
               break;
            case EVTLHICNTRLREQ:     /* Control Request */
               ret = cmUnpkLhiCntrlReq(HiMiLhiCntrlReq, pst, mBuf);
               break;
            case EVTLHISTAREQ:       /* Status Request */
               ret = cmUnpkLhiStaReq(HiMiLhiStaReq, pst, mBuf);
               break;
            default:
               HILOGERROR_DEBUG( EHI254, (ErrVal)pst->event, pst->dstInst,
                          "hiActvTsk(): Invalid Event from layer manager");
               (Void)SPutMsg(mBuf);
               ret = RFAILED;
               break;
         }/* end of switch */
         break;
      }
#endif /* LCHIMILHI */

#ifdef LCHIUIHIT
      case ENTHC:
      case ENTHR:
      case ENTGT:
      case ENTMG:
      case ENTHG:
      case ENTSB:
      case ENTLN:
#ifdef DM
      case ENTDM:
#endif /* DM */
#ifdef SO
      case ENTSO:
#endif /* SO */
/* hi020.104: Adding Sip Application as another user */
#ifdef SV
      case ENTSV:
#endif /* SV */
      {
         switch(pst->event)
         {
            case  EVTHITBNDREQ:
               ret = cmUnpkHitBndReq(HiUiHitBndReq, pst, mBuf);
               break;

            case  EVTHITUBNDREQ:
               ret = cmUnpkHitUbndReq(HiUiHitUbndReq, pst, mBuf);
               break;

            case  EVTHITSRVOPENREQ:
               ret = cmUnpkHitServOpenReq(HiUiHitServOpenReq, pst, mBuf);
               break;

            case  EVTHITCONREQ:
#ifdef H323_PERF
               TAKE_TIMESTAMP("L ConReq HC->HI, in HI");
#endif /* H323_PERF */

               ret = cmUnpkHitConReq(HiUiHitConReq, pst, mBuf);
               break;

            case  EVTHITCONRSP:
               ret = cmUnpkHitConRsp(HiUiHitConRsp, pst, mBuf);
               break;

            case  EVTHITDATREQ:
#ifdef H323_PERF
               TAKE_TIMESTAMP("L DatReq HC->HI, in HI");
#endif /* H323_PERF */

               ret = cmUnpkHitDatReq(HiUiHitDatReq, pst, mBuf);
               break;

            case  EVTHITUDATREQ:
#ifdef H323_PERF
               TAKE_TIMESTAMP("L UDatReq HC->HI, in HI");
#endif /* H323_PERF */

                /* hi009.104 - pass memory info down */
#ifdef IPV6_OPTS_SUPPORTED              
               memInfo.region = hiCb.hiInit.region;
               memInfo.pool = hiCb.hiInit.pool;
               ret = cmUnpkHitUDatReq(HiUiHitUDatReq, pst, mBuf, &memInfo);
#else
               ret = cmUnpkHitUDatReq(HiUiHitUDatReq, pst, mBuf);
#endif /* IPV6_OPTS_SUPPORTED */              
               break;

            case  EVTHITDISCREQ:
               ret = cmUnpkHitDiscReq(HiUiHitDiscReq, pst, mBuf);
               break;

            default:
               HILOGERROR_DEBUG( EHI255, (ErrVal)pst->event, pst->dstInst,
                          "hiActvTsk(): Invalid Event from service user" );
               (Void)SPutMsg(mBuf);
               ret = RFAILED;
               break;
         }/* end switch */
         break;
      }
#endif /* LCHIUIHIT */

      /* The system agent is always loosely coupled */
      case ENTSH:
         /* check the event */
         switch(pst->event)
         {
#ifdef FTHA
            case EVTSHTCNTRLREQ:    /* system agent control request */
               /* call unpakcing function */
               cmUnpkMiShtCntrlReq(HiMiShtCntrlReq, pst, mBuf);
               break;
#endif /* FTHA */

            default:
               SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                         __FILE__, __LINE__, ERRCLS_INT_PAR, EHI256, 
                         (ErrVal) pst->event, "Invalid event from ENTSH");
               SPutMsg(mBuf);
               break;
         }

         /* hi009.104 - added mising break. It seems this path was not test 
          *             properly before */
         break;

#ifdef HI_MULTI_THREADED     
      case ENTHI:
         /* Check the event */
         switch(pst->event)
         {
            case EVTINTDISCIND:
               hiRecvIntDiscInd(pst, mBuf);
               break;

            case EVTINTCONGOFF:
               hiRecvIntCongOff(pst, mBuf);
               break;

            case EVTINTSAPCONCBDEL:
               hiRecvIntSapConCbDel(pst, mBuf);
               break;

            case EVTINTRECVTHRCLOSED:
               hiRecvIntRecvThrClosed(pst, mBuf);
               break;
            
            case EVTINTZEROSTS:
               hiRecvIntZeroStsReq(pst, mBuf);
               break;

            case EVTINTSAPDISREQ:
               hiRecvIntSapDisReq(pst, mBuf);
               break;

            case EVTINTSAPDISCFM:
               hiRecvIntSapDisCfm(pst, mBuf);
               break;

            default:
               SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                         __FILE__, __LINE__, ERRCLS_INT_PAR, EHI257, 
                         (ErrVal) pst->event, "Invalid event from ENTHI");
               SPutMsg(mBuf);
               ret = RFAILED;
               break;
         }
         break;
#endif /* HI_MULTI_THREADED      */

      default:
         HILOGERROR_DEBUG( EHI258, (ErrVal)pst->event, pst->dstInst,
                    "hiActvTsk(): Invalid source entity" );
         (Void)SPutMsg(mBuf);
         ret = RFAILED;
         break;
   }/* end of switch */

/* hi009.104 - generate alarm */
#ifdef HI_RUG
   /* check return value */
   if ((ret == RINVIFVER) && (hiCb.hiInit.cfgDone == TRUE))
   {
      /* generate alarm when primitive recvd has invalid interface version no */
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LCM_EVENT_INV_EVT,
                  LCM_CAUSE_DECODE_ERR, &info);
   }
#endif /* HI_RUG */

   SExitTsk();

   RETVALUE(ret);
}/* end of hiActvTsk */


/********************************************************************30**
 
         End of file:     hi_ex_ms.c@@/main/sip_rel_1.2_dev/1 - Thu Apr 11 10:14:43 2002

*********************************************************************31*/
 
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      asa  1. initial release.
1.1+         hi002.11 asa  1. changes for GTP.
1.1+         hi004.11 cvp  1. changes for MGCP.
1.1+         hi005.11 cvp  1. included MGCP loose coupling flag.
/main/2       ---      cvp  1. changes for Annex G.
                          2. changed the copyright header.
             /main/4                sb   1. changes for SCTP.
                     cvp  2. changes for MPLS.
/main/4+     hi003.13 cvp  1. changes for dummy layer.
/main/4+     hi006.13 bsr  1. changes for SIP layer.
/main/4      ---     cvp  1. changes for multi-threaded TUCL.
                           2. changed the copyright header.
/main/4+   hi009.104 mmh  1. passing memInfo needed to allocate memory
                             for ip hdr parameters in cmUnpkHitUDatReq. 
                          2. Rolling upgrade changes, under compile flag
                             HI_RUG as per tcr0020.txt:
                          -  Added new variable for alarm info
                          -  Fill up the alarm info structure properly
                          -  Check on return value of unpacking primitive is
                             added for alarm indication to LM in case primitive
                             is received with invalid interface version number.
                          -  added missing break in case ENTSH
/main/4+   hi020.104  rs  1. Added ENTSV as one of the users.
/main/4+   hi021.104  rs  1. Warning Removed.
/main/4+   hi025.104  pr  1. SS_MULTIPLE_PROCS flag added.
*********************************************************************91*/
