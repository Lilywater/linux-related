/* ***************************************************************************
 *        (c) COPYRIGHT 1995-2006 by Xinwei, Inc.
 *                   All rights reserved.
 *
 * sb_sample.c:  
 *          This file include the sample usage of sctp protocol.
 *           
 * Author:
 *          zhouguishuang
 * Date:
 *          2006-4-21
 * Last Modified:
 *
 ****************************************************************************/

#include "hi_common.h"

#ifdef SSI_WITH_CLI_ENABLED
#include "xosshell.h"
#include "clishell.h"


extern PUBLIC S16 hiGenCfg(void);
extern PUBLIC S16 hiSapCfg(void);
void hi_print_state_info(CLI_ENV* pCliEnv,U16 print_action);
extern PUBLIC S16 hiGetGenSts
(
HiGenSts    *genStsToFill     /* pointer to general statistics to be returned */
);

XVOID  hiCfgProtocol(CLI_ENV* pCliEnv,XS32  siArgc,XCHAR **ppArgv);
XVOID  hiStateDbgPrint(CLI_ENV* pCliEnv,XS32  siArgc,XCHAR **ppArgv);
XVOID  hiDbgSwitch(CLI_ENV* pCliEnv,XS32  siArgc,XCHAR **ppArgv);


/*
*
*       ����:   hiCfgProtocol
*
*       ����:   ����SCTPЭ�麯��������GEN��SAP��
*
*       ����ֵ: ��
*
*       �ļ�:  sb_dbg.c
*
*/
XVOID  hiCfgProtocol(CLI_ENV* pCliEnv,XS32  siArgc,XCHAR **ppArgv)
{
    if(siArgc != 2)
    {
        XOS_CliExtPrintf(pCliEnv,"\r\nParameter Input Error!\r\n");
        return;        
    }
    if((XOS_StrCmp(ppArgv[0],"config")!=0))
    {
        XOS_CliExtPrintf(pCliEnv,"\r\nParameter Input Error!\r\n");
        return;
    }	

    if((XOS_StrCmp(ppArgv[1],"gen")==0)||(XOS_StrCmp(ppArgv[1],"all")==0))
    	{
    	hiGenCfg();
    	}

    if((XOS_StrCmp(ppArgv[1],"sap")==0)||(XOS_StrCmp(ppArgv[1],"all")==0))
    	{
    	hiSapCfg();
    	}
	return;
}



/*****************************************************************************
*
*       ����:   hiStateDbgPrint
*
*       ����:   ��ӡSCTP״̬��Ϣ�Ĵ�����������������״̬��Ϣ
*                                                 Э���ʼ����Ϣ
*                                                 SAP���ƿ���Ϣ
*
*       ����ֵ:   ʧ��:           RFAILED
*                 �ɹ�:           ROK
*       �ļ�:  sb_dbg.c
*
*/


XVOID  hiStateDbgPrint(CLI_ENV* pCliEnv,XS32  siArgc,XCHAR **ppArgv)
{

    U16  action=0;
    if( siArgc != 2 ) 
    {
        
        XOS_CliExtPrintf(pCliEnv,"\r\n[SCTP]Input Parameter no. != 2.\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nUsage:\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nshow <all |config| layer| sap>\r\n");
        return;
    }      
    if((XOS_StrCmp(ppArgv[0],"show")!=0))
    {
        XOS_CliExtPrintf(pCliEnv,"\r\nParameter Input command Error!\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nUsage:\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nshow <all |config| layer| sap>\r\n");        
        return;
    }
    if((XOS_StrCmp(ppArgv[1],"config")==0))
    {
        action |= TUCL_PRINT_CONFIG_INFO; 
    }    
    
    if((XOS_StrCmp(ppArgv[1],"stat")==0))
    {
        action |= TUCL_PRINT_LAYER_INFO; 
    }
    if((XOS_StrCmp(ppArgv[1],"sap")==0))
    {
        action |= TUCL_PRINT_SAP_INFO; 
    }
    if((XOS_StrCmp(ppArgv[1],"all")==0))
    {
        action |= TUCL_PRINT_ALL_INFO; 
    }
    if(action)
    {
       hi_print_state_info(pCliEnv,action);
    }
    else
    {
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL] parameter input error.\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nUsage:\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\nshow <all |config| layer| sap>\r\n");
    }
    return;
}

/*
*
*       ����:   hi_print_state_info
*
*       ����:   ��ӡSCTP״̬��Ϣ�Ĵ�����������������״̬��Ϣ
*                                                 Э���ʼ����Ϣ
*                                                 SAP���ƿ���Ϣ
*
*       ����ֵ:   ʧ��:           RFAILED
*                 �ɹ�:           ROK
*       �ļ�:  sb_dbg.c
*
*/
void hi_print_state_info(CLI_ENV* pCliEnv,U16 print_action)
{
         
    U8              i=0;
    HiSap           *sap;
    HiGenSts        genSts;
    if(!hiCb.cfgDone)
    {
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL]ERROR:GEN CFG NOT DONE.\r\n");
        return;
    }
    
    
    if((print_action&TUCL_PRINT_CONFIG_INFO)||(print_action&TUCL_PRINT_ALL_INFO))
    {
        XOS_CliExtPrintf(pCliEnv,"\r\n------------------- TUCL GEN CFG INFO ---------------------\r\n");
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL CFG]number of SAPs in TUCL = %d\r\n",hiCb.cfg.numSaps);
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL CFG]maximum number of connections = %d\r\n",hiCb.cfg.numCons);
#ifdef HI006_12
#ifdef HI_REL_1_3        
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL CFG]number of raw messages to read = %d\r\n",hiCb.cfg.numRawMsgsToRead);
#endif /* HI_REL_1_3 */
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL CFG]number of udp messages to read = %d\r\n",hiCb.cfg.numUdpMsgsToRead);
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL CFG]number of clients to accept simultaneously = %d\r\n",hiCb.cfg.numClToAccept);
#endif /* HI006_12 */
        if(hiCb.cfg.permTsk == 1)   
            XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL CFG]schedule as permanent task .\r\n");
        else
        {
            XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL CFG]schedule through a timer .\r\n");
            XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL CFG]value of the scheduling timer = %d\r\n",hiCb.cfg.schdTmrVal);
        }
        
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL CFG]start threshold of the memory pool = %d\r\n",hiCb.cfg.poolStrtThr);
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL CFG]drop threshold of the memory pool = %d\r\n",hiCb.cfg.poolDropThr);
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL CFG]stop threshold of the memory pool = %d\r\n",hiCb.cfg.poolStopThr);
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL CFG]start threshold of the memory pool = %d\r\n",hiCb.cfg.poolStrtThr);
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL CFG]drop threshold of the memory pool = %d\r\n",hiCb.cfg.poolDropThr);
        
    }         

    if((print_action&TUCL_PRINT_LAYER_INFO)||(print_action&TUCL_PRINT_ALL_INFO))
    {
        XOS_CliExtPrintf(pCliEnv,"\r\n------------------- TUCL STA RUN INFO ---------------------\r\n");
        hiGetGenSts(&genSts);
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]total number of connections = %d\r\n",genSts.numCons);
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]socket transmit error  = %d\r\n",genSts.sockTxErr);
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]socket receive  error  = %d\r\n",genSts.sockRxErr);
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]socket open  error = %d\r\n",genSts.sockOpenErr);
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]socket bind  error = %d\r\n",genSts.sockBindErr);
        
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]socket connect  error  = %d\r\n",genSts.sockCnctErr);
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]socket listen   error  = %d\r\n",genSts.sockLstnErr);
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]socket set-option error = %d\r\n",genSts.sockSOptErr);
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]socket close error    = %d\r\n",genSts.sockClosErr);
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]socket shutdown error = %d\r\n",genSts.sockShutErr);        
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]version number  error = %d\r\n",genSts.rxMsgVerErr);        
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]number of flow control indications = %d\r\n",genSts.numFlcInd);        
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]number of transmitted TCP messages = %d\r\n",genSts.numTxTcpMsg);        
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]number of received TCP messages    = %d\r\n",genSts.numRxTcpMsg);        
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]number of transmitted UDP messages = %d\r\n",genSts.numTxUdpMsg);        
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]number of received UDP messages    = %d\r\n",genSts.numRxUdpMsg);        
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]number of bytes transmitted  = %d\r\n",genSts.numTxbytes);        
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]number of bytes received     = %d\r\n",genSts.numRxbytes);        
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]Number of transmitted Raw messages = %d\r\n",genSts.numTxRawMsg);        
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL STAT]Number of received Raw messages    = %d\r\n",genSts.numRxRawMsg);        
        
    } 
    if((print_action&TUCL_PRINT_SAP_INFO)||(print_action&TUCL_PRINT_ALL_INFO))
    {
                
         XOS_CliExtPrintf(pCliEnv,"\n------------------- TUCL SAP RUN INFO ---------------------\n");
         for (i = 0; i < hiCb.cfg.numSaps; i++)
         {
            sap = hiCb.sapLstPtr[i];

            if (sap == (HiSap *) NULLP)
               continue;
               
            XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL SAP]suId = %d\r\n",sap->suId);            
            XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL SAP]spId = %d\r\n",sap->spId);
            XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL SAP]state = ");
            switch(sap->state)
            {
                case HI_ST_UBND:
                    XOS_CliExtPrintf(pCliEnv,"UNBOUND.\n\n");
                    break;
                case HI_ST_BND:
                    XOS_CliExtPrintf(pCliEnv,"BOUND.\n\n");
                    break;
                default:
                    XOS_CliExtPrintf(pCliEnv,"ERROR.\n\n");
                    break;
                                                
            }
         }        
    } 

    return;
}

/*
*
*       ����:   hiDbgSwitch
*
*       ����:   ����̨��������Ϣ��
*
*       ����ֵ:   ��
*
*       �ļ�:  sb_dbg.c
*
*/
XVOID  hiDbgSwitch(CLI_ENV* pCliEnv,XS32  siArgc,XCHAR **ppArgv)
{

#ifdef DEBUGP
    if( siArgc != 2 ) 
    {
        
        XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL]Input Parameter no. != 2.\r\n");

        return;
    }      
    if((XOS_StrCmp(ppArgv[0],"debug")!=0))
    {
        XOS_CliExtPrintf(pCliEnv,"\r\nParameter Input command Error!\r\n");
        return;
    }
    if((XOS_StrCmp(ppArgv[1],"on")==0))
    {
        hiCb.hiInit.dbgMask = 0xffffffff;
    } 
    if((XOS_StrCmp(ppArgv[1],"off")==0))
    {
        hiCb.hiInit.dbgMask = 0;
    }
#else
    XOS_CliExtPrintf(pCliEnv,"\r\n[TUCL]NOT COMPILE WITH: DEBUGP.\r\n");
#endif
}

Bool XOS_CLIRegCommand_HI(Void)
{
	XS32 ret = 0;
	XS32 cmdIndex=0,tuclcmdIndex=0;
    cmdIndex =     XOS_RegistCmdPrompt( SYSTEM_MODE, "prtl", "Э��ģʽ", "�޲���" );
	tuclcmdIndex=     XOS_RegistCmdPrompt( cmdIndex, "tucl", "tucl Э��", "�޲���" );
#if 0
	XOS_RegistCommand(tuclcmdIndex,
		              hiCfgProtocol,
					  "config",
					  "�ֹ�����TUCL",
					  "gen\r\nsap\r\nall\r\n");
#endif

	XOS_RegistCommand(tuclcmdIndex,
		              hiStateDbgPrint,
					  "show",
					  "��ʾTUCL ��Ϣ",
					  "all\r\nconfig\r\nlayer\r\nsap\r\n");

	XOS_RegistCommand(tuclcmdIndex,
		              hiDbgSwitch,
					  "debug",
					  "��/�رո�����Ϣ",
					  "on\r\noff\r\n");

		
	return XTRUE;
}

#endif /* SSI_WITH_CLI_ENABLED */


/*
*
*       ����:   hi_print_state_cb_info
*
*       ����:   ��ӡSCTP״̬��Ϣ�Ĵ�����������������״̬��Ϣ
*                                                 Э���ʼ����Ϣ
*                                                 SAP���ƿ���Ϣ
*
*       ����ֵ:   ʧ��:           RFAILED
*                 �ɹ�:           ROK
*       �ļ�:  sb_dbg.c
*
*/
void hi_print_state_cb_info(U16 print_action)
{
         
	U8              i=0;
#if 0	
    HiSap           *sap;
    HiGenSts        genSts;
#endif	
    if(!hiCb.cfgDone)
    {
        printf("\r\n[TUCL]ERROR:GEN CFG NOT DONE.\r\n");
        return;
    }
    
    
    if((print_action&TUCL_PRINT_CONFIG_INFO)||(print_action&TUCL_PRINT_ALL_INFO))
    {
        printf("\r\n------------------- TUCL GEN CFG BEGIN ---------------------\r\n");
        printf("\r\n[TUCL CFG]number of SAPs in TUCL = %d\n",hiCb.cfg.numSaps);
        printf("\r\n[TUCL CFG]maximum number of connections = %d\n",hiCb.cfg.numCons);
		printf("\r\n------------------- TUCL GEN CFG END ---------------------\r\n");
#if 0
#ifdef HI006_12
#ifdef HI_REL_1_3        
        printf("[TUCL CFG]number of raw messages to read = %d\n",hiCb.cfg.numRawMsgsToRead);
#endif /* HI_REL_1_3 */
        printf("[TUCL CFG]number of udp messages to read = %d\n",hiCb.cfg.numUdpMsgsToRead);
        printf("[TUCL CFG]number of clients to accept simultaneously = %d\n",hiCb.cfg.numClToAccept);
#endif /* HI006_12 */
        if(hiCb.cfg.permTsk == 1)   
            printf("[TUCL CFG]schedule as permanent task .\n");
        else
        {
            printf("[TUCL CFG]schedule through a timer .\n");
            printf("[TUCL CFG]value of the scheduling timer = %d\n",hiCb.cfg.schdTmrVal);
        }
        
        printf("[TUCL CFG]start threshold of the memory pool = %d\n",hiCb.cfg.poolStrtThr);
        printf("[TUCL CFG]drop threshold of the memory pool = %d\n",hiCb.cfg.poolDropThr);
        printf("[TUCL CFG]stop threshold of the memory pool = %d\n",hiCb.cfg.poolStopThr);
        printf("[TUCL CFG]start threshold of the memory pool = %d\n",hiCb.cfg.poolStrtThr);
        printf("[TUCL CFG]drop threshold of the memory pool = %d\n",hiCb.cfg.poolDropThr);
#endif        
    }         
#if 0
    if((print_action&TUCL_PRINT_LAYER_INFO)||(print_action&TUCL_PRINT_ALL_INFO))
    {
        printf("\n------------------- TUCL STA RUN INFO ---------------------\n\n");
        hiGetGenSts(&genSts);
        printf("[TUCL STAT]total number of connections = %d\n",genSts.numCons);
        printf("[TUCL STAT]socket transmit error  = %d\n",genSts.sockTxErr);
        printf("[TUCL STAT]socket receive  error  = %d\n",genSts.sockRxErr);
        printf("[TUCL STAT]socket open  error = %d\n",genSts.sockOpenErr);
        printf("[TUCL STAT]socket bind  error = %d\n",genSts.sockBindErr);
        
        printf("[TUCL STAT]socket connect  error  = %d\n",genSts.sockCnctErr);
        printf("[TUCL STAT]socket listen   error  = %d\n",genSts.sockLstnErr);
        printf("[TUCL STAT]socket set-option error = %d\n",genSts.sockSOptErr);
        printf("[TUCL STAT]socket close error    = %d\n",genSts.sockClosErr);
        printf("[TUCL STAT]socket shutdown error = %d\n",genSts.sockShutErr);        
        printf("[TUCL STAT]version number  error = %d\n",genSts.rxMsgVerErr);        
        printf("[TUCL STAT]number of flow control indications = %d\n",genSts.numFlcInd);        
        printf("[TUCL STAT]number of transmitted TCP messages = %d\n",genSts.numTxTcpMsg);        
        printf("[TUCL STAT]number of received TCP messages    = %d\n",genSts.numRxTcpMsg);        
        printf("[TUCL STAT]number of transmitted UDP messages = %d\n",genSts.numTxUdpMsg);        
        printf("[TUCL STAT]number of received UDP messages    = %d\n",genSts.numRxUdpMsg);        
        printf("[TUCL STAT]number of bytes transmitted  = %d\n",genSts.numTxbytes);        
        printf("[TUCL STAT]number of bytes received     = %d\n",genSts.numRxbytes);        
        printf("[TUCL STAT]Number of transmitted Raw messages = %d\n",genSts.numTxRawMsg);        
        printf("[TUCL STAT]Number of received Raw messages    = %d\n",genSts.numRxRawMsg);        
        
    } 
    if((print_action&TUCL_PRINT_SAP_INFO)||(print_action&TUCL_PRINT_ALL_INFO))
    {
                
         printf("\n------------------- TUCL SAP RUN INFO ---------------------\n");
         for (i = 0; i < hiCb.cfg.numSaps; i++)
         {
            sap = hiCb.sapLstPtr[i];

            if (sap == (HiSap *) NULLP)
               continue;
               
            printf("[TUCL SAP]suId = %d\n",sap->suId);            
            printf("[TUCL SAP]spId = %d\n",sap->spId);
            printf("[TUCL SAP]state = ");
            switch(sap->state)
            {
                case HI_ST_UBND:
                    printf("UNBOUND.\n\n");
                    break;
                case HI_ST_BND:
                    printf("BOUND.\n\n");
                    break;
                default:
                    printf("ERROR.\n\n");
                    break;
                                                
            }
         }        
    } 
#endif
    return;
}


/*added by wanglijun for set dbgmask from shell*/
#ifdef HI_DEBUGP
U32 g_hiDbgMask = DBGMASK_LI|DBGMASK_UI|DBGMASK_MI;
#else
U32 g_hiDbgMask = 0;
#endif

Void hiSetDbgMaskFromShell(U32 dbgMask)
{
  g_hiDbgMask = dbgMask;
#ifdef DEBUGP
  hiCb.hiInit.dbgMask = g_hiDbgMask;
#endif
  RETVOID;
}


/********************************************************************30**

         End of file:     hi_dbg.c@@/main/2 - 2006-05-11

*********************************************************************31*/
