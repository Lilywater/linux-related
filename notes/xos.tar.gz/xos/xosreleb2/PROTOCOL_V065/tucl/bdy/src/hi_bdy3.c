/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
     Name:     TCP UDP Convergence Layer
                 - code related to socket management
  
     Type:     C source file
  
     Desc:     Functions that make use of socket library calls.  
              
     File:     hi_bdy3.c
  
     Sid:      hi_bdy3.c@@/main/4 - Thu Jun 28 13:29:52 2001

     Prg:      asa
   
*********************************************************************21*/

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_inet.h"       /* common sockets */
#include "cm_tpt.h"        /* common transport defines */
#ifdef FTHA
#include "sht.h"           /* SHT Interface header files */
#endif /* FTHA */
#include "lhi.h"           /* layer management, TUCL  */
#include "hit.h"           /* HIT interface */
#include "hi.h"            /* TUCL internal defines */
#include "hi_err.h"        /* TUCL error */
#ifdef H323_PERF
#include "hc_prf.h"        /* Performance measurement data structs */
#endif /* H323_PERF */
  
/* header/extern include files (.x) */
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_inet.x"       /* common sockets */
#include "cm_tpt.x"        /* common transport typedefs */
#ifdef FTHA
#include "sht.x"           /* SHT Interface header file */
#endif /* FTHA */
#include "lhi.x"           /* layer management TUCL */
#include "hit.x"           /* HIT interface */
#include "hi.x"            /* TUCL internal typedefs */
#ifdef H323_PERF
#include "hc_prf.x"        /* Performance measurement data structs */
#endif /* H323_PERF */
 

/* Public variable declarations */
/* function prototypes */
/* functions */


/*
*
*       Fun:   hiSockInit 
*
*       Desc:  This function is called in general configuration
*              for initializing the socket library and for creating 
*              a common UDP socket for all service users.
*
*       Ret:   LCM_REASON_NOT_APPL
*
*       Notes: None 
*
*       File:  hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16 hiSockInit 
(
Void
)
#else
PUBLIC S16 hiSockInit()
#endif
{

   S16       ret;
#ifdef HI_MULTI_THREADED
   HiAlarmInfo alInfo;
#endif /* HI_MULTI_THREADED */

   /* hi009.104 - added to bind the generic socket */
#ifdef HI_SPECIFY_GENSOCK_ADDR   
   CmTptAddr genSockBindAddr;   /* for IPv4 generic socket */
#ifdef IPV6_SUPPORTED
   CmTptAddr genSock6BindAddr;   /* for IPv6 generic socket */
#endif /* IPV6_SUPPORTED */
#endif /* HI_SPECIFY_GENSOCK_ADDR */
   
   TRC2(hiSockInit)

   /* initialize the socket library */
   ret = cmInetInit();
   if(ret != ROK)
   {
      RETVALUE(LHI_REASON_SOCKLIB_INIT_FAIL);
   }

   /* hi009.104 - added to bind the generic socket */
#ifdef HI_SPECIFY_GENSOCK_ADDR     
   /* fill up only for IPv4 */
   genSockBindAddr.type    = CM_NETADDR_IPV4;
   genSockBindAddr.u.ipv4TptAddr.address = hiCb.cfg.ipv4GenSockAddr.address;
   genSockBindAddr.u.ipv4TptAddr.port    = hiCb.cfg.ipv4GenSockAddr.port;
#ifdef IPV6_SUPPORTED 
   /* now fill up for IPv6 socket */
   genSock6BindAddr.type    = CM_NETADDR_IPV6;
   genSock6BindAddr.u.ipv6Addr.address = hiCb.cfg.ipv6GenSockAddr.address;
   genSock6BindAddr.u.ipv6Addr.port    = hiCb.cfg.ipv6GenSockAddr.port;
#endif /* IPV6_SUPPORTED */
#endif /* HI_SPECIFY_GENSOCK_ADDR */
   
   /* open a common socket for UDP users */
#ifdef HI_REL_1_3  
#ifdef IPV6_SUPPORTED
   ret = cmInetSocket(CM_INET_DGRAM, &hiCb.resvConFd, 0, 
                      CM_INET_IPV4_DOMAIN);
#else
   ret = cmInetSocket(CM_INET_DGRAM, &hiCb.resvConFd, 0);
#endif /* IPV6_SUPPORTED */
#else 
   ret = cmInetSocket(CM_INET_DGRAM, &hiCb.resvConFd);
#endif /* HI_REL_1_3 */ 
   if (ret != ROK)
   {
#ifdef HI_MULTI_THREADED
      alInfo.spId = -1;
      alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
      HI_LOCK(&hiCb.errStsLock, alInfo, ret); 
      if (ret != ROK)
         HILOGERROR_DEBUG(EHI194, (ErrVal) 0, 0, 
            "hiSockInit () : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */
      
      /* increment the statistics counter */
      hiCb.errSts.sockOpenErr++;

#ifdef HI_MULTI_THREADED
      HI_UNLOCK(&hiCb.errStsLock, alInfo, ret);
      if (ret != ROK)
         HILOGERROR_DEBUG(EHI195, (ErrVal) 0, 0, 
            "hisockInit () : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */

      HILOGERROR_ADD_RES(EHI196, (ErrVal) ret, 0,
                 "hiSockInit(): failed to open common socket");
      RETVALUE(LHI_REASON_SOCK_FAIL);
   }

   /* hi009.104 - added to bind the generic IPv4 socket to the address assigned
    *             during general configuration */
#ifdef HI_SPECIFY_GENSOCK_ADDR
#ifdef IPV6_SUPPORTED
      ret = cmInetBind(&hiCb.resvConFd, (CmInetAddr *)&genSockBindAddr);
#else
      ret = cmInetBind(&hiCb.resvConFd, &(genSockBindAddr.u.ipv4TptAddr));
#endif /* IPV6_SUPPORTED */

      if (ret != ROK)
      {
         SPrint("hiSockInit(): binding of IPv4 generic socket failed\n");
         cmInetClose(&hiCb.resvConFd);
         RETVALUE(RFAILED);
      }
#endif /* HI_SPECIFY_GENSOCK_ADDR */

#ifdef IPV6_SUPPORTED
   ret = cmInetSocket(CM_INET_DGRAM, &hiCb.resv6ConFd, 0, 
                      CM_INET_IPV6_DOMAIN);
   if (ret != ROK)
   {
#ifdef HI_MULTI_THREADED
      alInfo.spId = -1;
      alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
      HI_LOCK(&hiCb.errStsLock, alInfo, ret); 
      if (ret != ROK)
         HILOGERROR_DEBUG(EHI197, (ErrVal) 0, 0, 
            "hiSockInit () : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */
      
      /* increment the statistics counter */
      hiCb.errSts.sockOpenErr++;

#ifdef HI_MULTI_THREADED
      HI_UNLOCK(&hiCb.errStsLock, alInfo, ret);
      if (ret != ROK)
         HILOGERROR_DEBUG(EHI198, (ErrVal) 0, 0, 
            "hisockInit () : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */

      HILOGERROR_ADD_RES(EHI199, (ErrVal) ret, 0,
                 "hiSockInit(): failed to open common ICMPV6 socket");
      RETVALUE(LHI_REASON_SOCK_FAIL);
   }

   /* hi009.104 - added to bind the generic IPv4 socket to the address assigned
    *             during general configuration */
#ifdef HI_SPECIFY_GENSOCK_ADDR
      ret = cmInetBind(&hiCb.resv6ConFd, (CmInetAddr *)&genSock6BindAddr);

      if (ret != ROK)
      {
         SPrint("hiSockInit(): binding of IPv6 generic socket failed\n");
         cmInetClose(&hiCb.resv6ConFd);
         RETVALUE(RFAILED);
      }
#endif /* HI_SPECIFY_GENSOCK_ADDR */
#endif /* IPV6_SUPPORTED */

   RETVALUE(LCM_REASON_NOT_APPL);
} /* end of hiSockInit */


/*
*
*       Fun:   hiHndlTcpData
*
*       Desc:  This function processes the TCP octet stream received 
*              the other side. It takes care of the cases when a TPKT
*              is received in multiple fragments or when multiple TPKTs
*              are received in a single fragment.
*              When the full packet is received, Data Indication is 
*              issued to the user.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <none>
*
*       File:  hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16  hiHndlTcpData
(
HiConCb *conCb,         /* pointer to the connection block */
Buffer *mBuf,           /* buffer returned from cmInetRecv call */
U32 len                 /* actual length of the data received */
)
#else
PUBLIC S16  hiHndlTcpData(conCb, mBuf, len)
HiConCb *conCb;         /* pointer to the connection block */
Buffer *mBuf;           /* buffer returned from cmInetRecv call */
U32 len;                /* actual length of the data received */
#endif
{

   Queue       rxQ;
   QLen        qLen;
   Buffer      *tmpBuf;
   Mem         mem;
   HiAlarmInfo info;
   U16         tmpLen;
   Bool        flag;
   S16         ret;

   TRC2(hiHndlTcpData)  
   
   /* Variable initializations */
   flag    = TRUE;
   tmpLen  = len;
   mem.region = conCb->sap->uiPst.region;
   mem.pool   = conCb->sap->uiPst.pool;
   ret     = ROK;

   /* Initialize alarm info structure */
   info.spId = conCb->sap->spId;
   info.type = LHI_ALARMINFO_TYPE_NTPRSNT;
   
   ret = SInitQueue(&rxQ);
   if(ret != ROK)
   {
      /* Deallocate the received buffer */
      SPutMsg(mBuf);
      conCb->reason = HI_INTERNAL_ERR;
      RETVALUE(RFAILED);
   }

   /* If there is some previously received data on this connection */
   if(conCb->rxBuf != NULLP)
   {
      /* Catenate the previously received buffer */
      ret = SCatMsg(mBuf, conCb->rxBuf, M2M1);
      if (ret != ROK)
      {
         /* Discard the received data */
         (Void)SPutMsg(mBuf);

         HI_FILL_ALARMINFO_MEM_ID(info, mem.region, mem.pool)
         /* Raise an alarm to the Layer Manager */
         hiSendAlarm(LCM_CATEGORY_RESOURCE,
                     LCM_EVENT_DMEM_ALLOC_FAIL,
                     LCM_CAUSE_UNKNOWN, &info); 

         conCb->reason = HI_OUTOF_RES;
         RETVALUE(RFAILED);
      }

      (Void)SPutMsg(conCb->rxBuf);
      conCb->rxBuf = NULLP;
   }
   /* Set await header flag true */
   else
      conCb->awaitHdr = TRUE;

   while(flag)
   {
      /* initialize the received length parameter */
      conCb->rxLen += tmpLen;

      /* Set the pending length here */
      /* Process header only if awaiting header */
      if (conCb->awaitHdr)
         if(hiProcRxHdr(conCb, mBuf) != ROK)
         {
            conCb->reason = HI_OUTOF_RES;
            /* mBuf is deallocated in hiProcRxHdr */
            ret = RFAILED;
            break;
         }

      /* If the full header or message is not come queue the 
       * data */
      if((conCb->awaitHdr) || (conCb->pendLen > conCb->rxLen))
      {
         /* Full header is not received. Wait for the header */
         conCb->rxBuf = mBuf;
         break;
      }
      
      /* Case of receiving one full packet */
      if(conCb->pendLen == conCb->rxLen)
      {
         /* Initialize rxLen and pendLen */
         conCb->rxLen = conCb->pendLen = 0;

         (Void)SQueueLast(mBuf, &rxQ);

         break;
      }/* end if */
      else if(conCb->rxLen > conCb->pendLen)
      {
         /* here received length is greater than the pending length */
         HIDBGP(DBGMASK_SI, (hiCb.hiInit.prntBuf,
                "SSegMsg(mBuf1(%p), idx(%ld), mBuf2(%p))\n", 
                mBuf, conCb->pendLen, &tmpBuf));

         /* Segment the message */
         ret = SSegMsg(mBuf, (U16)conCb->pendLen, &tmpBuf);
         if(ret !=ROK)
         {
            /* Raise an alarm to the Layer Manager */
            HI_FILL_ALARMINFO_MEM_ID(info, mem.region, mem.pool);
            hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                        LCM_CAUSE_UNKNOWN, &info); 
            ret = ROUTRES;
            conCb->reason = HI_OUTOF_RES;
            (Void)SPutMsg(mBuf);
            break;
         }

         /* Queue up the complete TPKT */
         (Void)SQueueLast(mBuf, &rxQ);

         /* Initialize variables for next iteration */
         tmpLen = conCb->rxLen - conCb->pendLen;
         conCb->rxLen = conCb->pendLen = 0;           
         
         /* Set awaitHdr flag */
         conCb->awaitHdr = TRUE;

         /* Put the next part of the packet in the mBuf */
         mBuf = tmpBuf;
          
         if(!tmpLen)
            flag = FALSE;
      }/* end else */
   }/* end while */

   (Void)SFndLenQueue(&rxQ, &qLen);
   while(qLen)
   {
      (Void)SDequeueFirst(&tmpBuf, &rxQ);

      qLen--;

      if(!(conCb->toBeDel))
      {
         /* Issue a Data Indication to the Upper Layer */
#ifdef HI_MULTI_THREADED
         HiUiHitDatInd(&conCb->sap->uiDatIndPst, conCb->sap->suId, 
                       conCb->suConId, tmpBuf);               
#else
         HiUiHitDatInd(&conCb->sap->uiPst, conCb->sap->suId, 
                       conCb->suConId, tmpBuf); 
#endif /* HI_MULTI_THREADED */
      }
      else
         (Void)SPutMsg(tmpBuf);
   }/* end while */

   (Void)SFlushQueue(&rxQ);

   RETVALUE(ret);
}/* end of hiHndlTcpData () */


/*
*
*       Fun:   hiAcceptTcpCon 
*
*       Desc:  This function is used to accept a connection from
*              a new TCP client.
*
*       Ret:   Void
*
*       Notes: None 
*
*       File:  hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC Void hiAcceptTcpCon
(
HiConCb *conCb
)
#else
PUBLIC Void hiAcceptTcpCon(conCb)
HiConCb *conCb;
#endif
{

   CmInetFd       newConFd;
   CmTptAddr      peerAddr;
   HiConCb        *newConCb;
   HiSap          *sap;
   HiAlarmInfo    info;
   S16            ret;
   U8             maxCons;

   TRC2(hiAcceptTcpCon)
   
   sap = conCb->sap; 

   /* Initialize info */
   info.spId  = sap->spId;
   info.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   /* Number of connections to accept is now a user defined
    * parameter */
#ifdef HI006_12
   maxCons = hiCb.cfg.numClToAccept;
#else
   maxCons = HI_MAX_CONS_TO_ACCEPT;
#endif /* HI006_12 */

   /* hi009.104 - init all local variables to 0.
    * NOTE: This MUST be followed for all Local structures dclared at all
    * files. Otherwise it will cause some hard to find errors. */
   
   HI_ZERO((U8*)&newConFd, sizeof(CmInetFd));
   HI_ZERO((U8*)&peerAddr, sizeof(CmTptAddr));
   HI_ZERO((U8*)&info, sizeof(HiAlarmInfo));

   /* Accept multiple connections in one go */
   while (maxCons)
   {
      maxCons -= 1;
   
      /* accept the connection on this socket */
#ifdef IPV6_SUPPORTED
      ret = cmInetAccept(&conCb->conFd, (CmInetAddr *)&peerAddr, &newConFd); 
#else
      ret = cmInetAccept(&conCb->conFd, &(peerAddr.u.ipv4TptAddr), &newConFd); 
#endif /* IPV6_SUPPORTED */
      if (ret != ROK)
      {
         /* RFAILED and ROKDNA cases */
      
         /* break if ROKDNA */
         if (ret == ROKDNA)
            RETVOID;

         /* failure to accept new connection on the server */
         /* no HitDiscInd is issued, the new connection is dumped and 
          * an alarm is issued to the Layer Manager */

         HILOGERROR_DEBUG(EHI200, (ErrVal) ret, sap->uiPst.srcInst,
                     "hiAcceptTcpCon: failed to accept connection");

         hiSendAlarm(LCM_CATEGORY_INTERNAL, LHI_EVENT_INET_ERR,
                     LHI_CAUSE_SOCK_ACPT_ERR, &info);
         RETVOID;
      }

      /* obtain a new connection block */
      HI_ALLOC(sizeof(HiConCb), newConCb)
      if (!newConCb)
      {  
         /* close the new socket */
         HI_CLOSE_SOCKET(&newConFd);

         /* fill up the alarm information */
         HI_FILL_ALARMINFO_MEM_ID(info, hiCb.hiInit.region, hiCb.hiInit.pool)
         hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_SMEM_ALLOC_FAIL,
                     LCM_CAUSE_UNKNOWN, &info);
         RETVOID;
      }
   
      /* fill up the new connection  block obtained */
      newConCb->conState  =  HI_ST_AW_CON_RSP;

      /* the suConId is obtained in HiUiHitConRsp */
      newConCb->sap      =  sap;
      newConCb->flag     =  conCb->flag;
      newConCb->srvcType =  conCb->srvcType;

      /* hi023.104 - Set The TOS for the new socket */
      if((conCb->flag & HI_FL_TCP)&& (conCb->ipTos != 0xFF))
      {
	      U32 optVal = conCb->ipTos;

	      ret = cmInetSetOpt(&newConFd,CM_INET_LEVEL_IP, CM_INET_OPT_TOS, (Void*)&optVal);
	      if ( ret != ROK )
	      {  
		      HILOGERROR_DEBUG(EHI201, (ErrVal)ret, sap->uiPst.srcInst,
				      "hiAcceptTcpCon : Setsockopt Failed ");
		      /* close the new socket */
		      HI_CLOSE_SOCKET(&newConFd);

		      /* deallocate the connection block */
		      HI_FREE(sizeof(HiConCb), newConCb);

		      /* fill up the alarm information */
		      hiSendAlarm(LCM_CATEGORY_INTERNAL,LCM_EVENT_INV_EVT,
				      LHI_CAUSE_SOCK_ACPT_ERR, &info);
		      RETVOID;
	      }
      }

      ret = hiGetConId(sap, newConCb);
      if(ret != ROK)
      {
         /* close the socket */
         HI_CLOSE_SOCKET(&newConFd);

         /* deallocate the connection block */
         HI_FREE(sizeof(HiConCb), newConCb);

         hiSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_INV_EVT, 
                     LHI_CAUSE_CONID_NOT_AVAIL, &info);
         RETVOID;
      }


      /* hi006.104 - if IPV6_SUPPORTED is defined, then this type field will
       * be filled in cmInetAccept function. For IPv4, we have to fill here */
       
#ifndef IPV6_SUPPORTED
      /* initialize the address type in peerAddr */
      peerAddr.type = CM_TPTADDR_IPV4;
#endif /* IPV6_SUPPORTED */
      
      cmMemcpy((U8*)&newConCb->peerAddr, (U8*)&peerAddr, 
               sizeof(CmTptAddr)); 
      cmMemcpy((U8 *)&(newConCb->conFd), (U8 *)&newConFd,
               sizeof(CmInetFd));

      /* initialize the transmit queues */
      SInitQueue(&newConCb->txQ);

#ifdef HI_MULTI_THREADED
      ret = SInitLock(&newConCb->txQLockId, SS_LOCK_MUTEX);
      if (ret != ROK)
      {
         HILOGERROR_DEBUG(EHI201, (ErrVal)ret, sap->uiPst.srcInst,
                  "hiAcceptTcpCon : Failed to initialise ");

         HI_CLOSE_SOCKET(&newConFd);

         hiRmvFrmSpConIdHl(conCb);

         SDestroyLock(&conCb->txQLockId);

         /* deallocate the connection block */
         HI_FREE(sizeof(HiConCb), newConCb);
      
         RETVOID;
      }
#else
      /* insert the new connection block in the hash list */
      ret = cmHashListInsert(&sap->sapHlCp, (PTR)newConCb,
                             (U8 *)&newConCb->spConId, sizeof(UConnId));
      if (ret != ROK)
      {
         HILOGERROR_DEBUG(EHI202, (ErrVal) ret, 0,
                    "hiAcceptTcpCon() :failed to insert in hash list");
         
         hiSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_INV_EVT, 
                     LCM_CAUSE_HASH_FAIL, &info);
         /* close the new socket and release the connection block */
         HI_CLOSE_SOCKET(&newConFd);
         
         HI_FREE(sizeof(HiConCb), newConCb);

         RETVOID;
      }
#endif /* HI_MULTI_THREADED */

      /* increment the statistics counters */
      sap->genTxSts.numCons++;
      sap->txSts.numCons++;

      /* issue a Connect Indication to the user */
      /* here suConId is that of the listener socket */
#ifdef HI_MULTI_THREADED
      HiUiHitConInd(&sap->uiConIndPst, sap->suId, conCb->suConId, 
                    newConCb->spConId, &peerAddr);
#else
      HiUiHitConInd(&sap->uiPst, sap->suId, conCb->suConId, 
                    newConCb->spConId, &peerAddr);
#endif /* HI_MULTI_THREADED */
   } /* end while */

   RETVOID;
}/* end of hiAcceptTcpCon() */


/*
*
*       Fun:   hiRecvMsg
*
*       Desc:  This function is used to receive the TCP octet stream
*              and UDP datagrams
*            
*       Ret:   ROK
*              RFAILED
*              ROUTRES
*              ROKDNA
*              The conCb->reason field is filled with the appropriate
*              reason to be used to send disconnect indications to be used
*              to send a disconnect indication to the upper user.
*
*       Notes: None
*
*       File:  hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16  hiRecvMsg
(
HiConCb *conCb
)
#else
PUBLIC S16  hiRecvMsg(conCb)
HiConCb *conCb;
#endif
{

   MsgLen            len;     /* length to read */
   Buffer            *mBuf;   /* message buffer */
   CmTptAddr         srcAddr; /* source address */
   CmInetMemInfo     info;    /* region and pool */
   HiAlarmInfo       alInfo;  /* alarm information */
   HiSap             *sap;    /* sap pointer */
   S16               ret;     /* return value from the function */
#ifdef HI_REL_1_3  
   CmTptAddr         destAddr;/* destination address */
   CmIpHdrParm       ipHdrParm;     /* IP Header parameters */
   U8                tmpSrvcType;   /* temporary service type */
#endif /* HI_REL_1_3 */ 
   /* Change for priority processing */
   U8                numMsg;   /* number of messages to read */
   /* hi002.104 - Removed locTptAddr definition */
   HiFdGrpInfo       *grpInfoPtr;

   /* hi009.104 - added new local variables */
#ifdef LOCAL_INTF
   CmTptLocalInf    localIf; /* local interface on which pkt was recvd */
#endif /* LOCAL_INTF */
   
   TRC2(hiRecvMsg)

   sap = conCb->sap;
   len = 0;

   /* hi009.104 - fillup with all 0's */
   HI_ZERO((U8*)&srcAddr, sizeof(CmTptAddr));
   HI_ZERO((U8*)&info, sizeof(CmInetMemInfo));
   HI_ZERO((U8*)&alInfo, sizeof(HiAlarmInfo));
   
#ifdef HI_REL_1_3
   tmpSrvcType = 0;
   tmpSrvcType = conCb->srvcType & 0xf0;

   /* hi009.104 - fillup with all 0's */
   HI_ZERO((U8*)&destAddr, sizeof(CmTptAddr));
   HI_ZERO(&ipHdrParm, sizeof(CmIpHdrParm));
#ifdef LOCAL_INTF   
   HI_ZERO(&localIf, sizeof(CmTptLocalInf));
#endif /* LOCAL_INTF */   
#endif /* HI_REL_1_3 */

   /* Initialise number of messages to read */
   /* Number of messages to read is now a general configuration 
    * parameter. For TCP sockets read is called only once */
   if (conCb->flag & HI_FL_PRIOR)
#ifdef HI_REL_1_3
#ifdef HI006_12
   {
      if (conCb->srvcType == HI_SRVC_RAW_SCTP)
         numMsg = hiCb.cfg.numRawMsgsToRead;
      else
         numMsg = hiCb.cfg.numUdpMsgsToRead;
   }
#else      
   {
      if (conCb->srvcType == HI_SRVC_RAW_SCTP)
         numMsg = HI_NUM_RAW_MSGS_TOREAD;
      else
         numMsg = HI_NUM_UDP_MSGS_TOREAD;
   }
#endif /* HI006_12 */
#else
#ifdef HI006_12
      numMsg = hiCb.cfg.numUdpMsgsToRead;
#else
      numMsg = HI_NUM_UDP_MSGS_TOREAD;
#endif /* HI006_12 */
#endif /* HI_REL_1_3 */
   else
      numMsg = 1;

   ret = ROK;

   grpInfoPtr = hiCb.hiFdGrpInfoLstPtr[conCb->fdBlkIdx];

   /* Initialize alarm info structure */
   alInfo.spId  = sap->spId;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   info.region = hiCb.hiInit.region;
   info.pool   = hiCb.hiInit.pool;

   /* Read multiple messages for priority sockets */
   while ((ret != ROKDNA) && (numMsg))
   {
      /* read the available data on this socket */
      len = CM_INET_READ_ANY;

      numMsg -= 1;

#ifdef H323_PERF
      TAKE_TIMESTAMP("Before hiRecvMsg()/cmInetRecvMsg(), in HI");
#endif /* H323_PERF */

      /* hi009.104 - added new arguments ipHdrParm and localIf */
      /* read the available data */
#ifdef IPV6_SUPPORTED
      if ((conCb->locTptAddr.type == CM_TPTADDR_IPV6) &&
          (conCb->conFd.type != CM_INET_STREAM))
      {
         ret = cmInetRecvMsg(&conCb->conFd, (CmInetAddr *)&srcAddr, 
                             &info, &mBuf, &len,
#ifdef IPV6_OPTS_SUPPORTED                             
                             (CmInetIpHdrParm *)&ipHdrParm, 
#endif
#ifdef LOCAL_INTF                             
                             (CmInetLocalInf *)&localIf,
#endif                             
                             CM_INET_NO_FLAG);
      }
      else
      { 
         /* hi009.104 - added new arguments ipHdrParm and localIf */
         ret = cmInetRecvMsg(&conCb->conFd, (CmInetAddr *)&srcAddr, 
                             &info, &mBuf, &len, 
#ifdef IPV6_OPTS_SUPPORTED                              
                             NULLP, 
#endif
#ifdef LOCAL_INTF                             
                             (CmInetLocalInf *)&localIf,
#endif                             
                             CM_INET_NO_FLAG);
      }   
#else  
      /* hi009.104 - added new argument localIf */
      ret = cmInetRecvMsg(&conCb->conFd, &(srcAddr.u.ipv4TptAddr), &info, 
                          &mBuf, &len, 
#ifdef LOCAL_INTF                           
                          (CmInetLocalInf *)&localIf,
#endif                          
                          CM_INET_NO_FLAG);  
#endif /* IPV6_SUPPORTED */

#ifdef H323_PERF
      TAKE_TIMESTAMP("L/T After hiRecvMsg()/cmInetRecvMsg(), in HI");
#endif /* H323_PERF */
      if (ret != ROK)
      {
         /* RCLOSED or RFAILED may be returned by cmInetRecvMsg */
         if(ret == RCLOSED)
         {
            conCb->reason = HI_CON_CLOSED_BY_PEER;
            /* NOT an error case, this value is returned when the peer
             * closes his side of the TCP connection */
            RETVALUE(RCLOSED);
         }
         else if(ret == ROKDNA)
            RETVALUE(ROKDNA); 
         else if(ret == ROUTRES)
         {
#ifdef HI_MULTI_THREADED
            HI_LOCK(&hiCb.errStsLock, alInfo, ret);
            if (ret != ROK)
               HILOGERROR_DEBUG(EHI203, (ErrVal) 0, conCb->sap->uiPst.srcInst, 
                  "hiRecvMsg () : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */

            hiCb.errSts.sockRxErr++; 
        
#ifdef HI_MULTI_THREADED
            HI_UNLOCK(&hiCb.errStsLock, alInfo, ret);
            if (ret != ROK)
               HILOGERROR_DEBUG(EHI204, (ErrVal) 0, conCb->sap->uiPst.srcInst, 
                  "hiRecvMsg () : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */

            alInfo.type = LHI_ALARMINFO_MEM_ID;

            /* fill up the alarm information */
            HI_FILL_ALARMINFO_MEM_ID(alInfo, info.region, info.pool);
            hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                        LHI_CAUSE_SOCK_RECV_ERR, &alInfo);
           /* hi001.104 - don't close the socket */
            RETVALUE(ROKDNA);
         }
         else
         {
#ifdef HI_MULTI_THREADED
            HI_LOCK(&hiCb.errStsLock, alInfo, ret);
            if (ret != ROK)
               HILOGERROR_DEBUG(EHI205, (ErrVal) 0, conCb->sap->uiPst.srcInst, 
                  "hiRecvMsg () : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */

            hiCb.errSts.sockRxErr++; 

#ifdef HI_MULTI_THREADED
            HI_UNLOCK(&hiCb.errStsLock, alInfo, ret);
            if (ret != ROK)
               HILOGERROR_DEBUG(EHI206, (ErrVal) 0, conCb->sap->uiPst.srcInst, 
                  "hiRecvMsg () : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */
            conCb->reason = HI_SOCK_RECV_ERR;

            hiSendAlarm(LCM_CATEGORY_INTERNAL, LHI_EVENT_INET_ERR,
                        LHI_CAUSE_SOCK_RECV_ERR, &alInfo);
            RETVALUE(RFAILED);
         }
      }

      /* increment the statistics counters */
      grpInfoPtr->grpCb.genRxSts.numRxbytes += len; 
      grpInfoPtr->grpCb.rxStsArr[conCb->sap->spId].numRxbytes += len; 

      /* update the peer address in the connection block */
#ifndef IPV6_SUPPORTED 
      srcAddr.type = CM_TPTADDR_IPV4;
#endif /* IPV6_SUPPORTED */
      cmMemcpy((U8*)&conCb->peerAddr, (U8*)&srcAddr, sizeof(CmTptAddr));

#ifdef HI_REL_1_3  
      if(conCb->flag & HI_FL_RAW)
      {
         /* statistics counter for RAW packets */
         grpInfoPtr->grpCb.rxStsArr[conCb->sap->spId].numRxRawMsg++;
         grpInfoPtr->grpCb.genRxSts.numRxRawMsg++;
    
         /* trace the data received */
         if(sap->trc)
            hiTrcBuf(sap, LHI_RAW_RXED, mBuf);

         /* UDatInd will be send from this function itself */
         /* Ignore the value of this function */
         /* hi009.104 - added new argument localIf */
#ifdef IPV6_SUPPORTED 
         if (conCb->flag & HI_FL_RAW_IPV6)
         {   
#ifdef LOCAL_INTF            
            hiHndlIpv6RawMsg(conCb, mBuf, len, &localIf, &ipHdrParm); 
#else
            hiHndlIpv6RawMsg(conCb, mBuf, len, &ipHdrParm);
#endif /* LOCAL_INTF */         
         }   
         else
#endif /* IPV6_SUPPORTED */
           
            /* hi009.104 - added new argument localIf */
#ifdef LOCAL_INTF            
            hiHndlRawMsg(conCb, mBuf, &localIf, len); 
#else
            hiHndlRawMsg(conCb, mBuf, len);
#endif /* LOCAL_INTF */ 
            
         /* Return value is not checked here */

         continue;
      }
#endif /* HI_REL_1_3 */ 

      if(conCb->flag & HI_FL_UDP)
      {
         /* UDP data received */

         /* increment the statistics counters */
         /* hi005.104: correct the spId index */
         grpInfoPtr->grpCb.rxStsArr[conCb->sap->spId].numRxUdpMsg++;
         grpInfoPtr->grpCb.genRxSts.numRxUdpMsg++;
         
         /* trace the data received */
         if(sap->trc)
            hiTrcBuf(sap, LHI_UDP_RXED, mBuf);

#ifdef H323_PERF
         TAKE_TIMESTAMP("L/T UDatInd Rcvd HI->HC, in HI");
#endif /* H323_PERF */

#ifndef HI_REL_1_3  
         /* send a unit data indication to the service user */
         HiUiHitUDatInd(&sap->uiPst, sap->suId, conCb->suConId, 
                        &srcAddr, mBuf);
#else
         if ((conCb->srvcType != HI_SRVC_UDP_TPKT_HDR) &&
            (!tmpSrvcType))
         {
            destAddr.type = CM_TPTADDR_NOTPRSNT;
      
            /* Send a Unit Data Indication to the service user */
#ifdef HI_MULTI_THREADED       
            /* hi009.104 - added new argument localIf */
            HiUiHitUDatInd(&sap->uiUDatIndPst, sap->suId, conCb->suConId, 
                           &srcAddr, &destAddr, &ipHdrParm, 
#ifdef LOCAL_INTF                           
                           &localIf,
#endif /* LOCAL_INTF */                           
                           mBuf);
#else
            /* hi009.104 - added new argument localIf */
            HiUiHitUDatInd(&sap->uiPst, sap->suId, conCb->suConId, 
                           &srcAddr, &destAddr, &ipHdrParm, 
#ifdef LOCAL_INTF                           
                           &localIf, 
#endif /* LOCAL_INTF */                           
                           mBuf);

#endif /* HI_MULTI_THREADED */
         }
         else
         {
            destAddr.type = CM_TPTADDR_NOTPRSNT;
            /* hi009.104 - added new argument localIf */
            /* process the UDP stream received */
            hiHndlUdpData(conCb, mBuf, &destAddr, &ipHdrParm, &srcAddr, 
#ifdef LOCAL_INTF                           
                          &localIf, 
#endif                          
                          len);
         }
#endif /* HI_REL_1_3 */         
      }
      else
      {
         /* TCP data received */
         
         /* If the connection is in progress mark the block as 
          * connected */
         if (conCb->conState == HI_ST_CLT_CONNECTING)
         {
            /* Mark the connection as completed */
            conCb->conState = HI_ST_CONNECTED;
            
            /* hi002.104 - local transport address already set in the 
             * calling function */

            /* Issue a connection confirm to the upper layer */
#ifdef HI_MULTI_THREADED
            HiUiHitConCfm(&sap->uiConCfmPst, sap->suId, conCb->suConId,
                          conCb->spConId, &conCb->locTptAddr);
#else
            HiUiHitConCfm(&sap->uiPst, sap->suId, conCb->suConId,
                          conCb->spConId, &conCb->locTptAddr);
#endif /* HI_MULTI_THREADED */
         }

         /* increment the statistics counters */
         grpInfoPtr->grpCb.genRxSts.numRxTcpMsg++;
         /* hi005.104: correct the spId index */
         grpInfoPtr->grpCb.rxStsArr[conCb->sap->spId].numRxTcpMsg++;
         
         /* trace the data received */
         if(sap->trc)
            hiTrcBuf(sap, LHI_TCP_RXED, mBuf);
#ifdef HI_REL_1_3
         if ((conCb->srvcType == HI_SRVC_TCP_TPKT_HDR) ||
            (tmpSrvcType))
#else
         if(conCb->srvcType >=  HI_SRVC_TCP_TPKT_HDR)
#endif /* HI_REL_1_3 */
         {
            /* process the TCP stream received */
            ret = hiHndlTcpData(conCb, mBuf, len);

            if (ret != ROK)
               RETVALUE(ret);
         }
         else
            /* send a data indication to the service user */
                     
#ifdef HI_MULTI_THREADED
            HiUiHitDatInd(&sap->uiDatIndPst, sap->suId, conCb->suConId, mBuf);
#else
            HiUiHitDatInd(&sap->uiPst, sap->suId, conCb->suConId, mBuf);
#endif /* HI_MULTI_THREADED */
      }/* end else */
   }/* end while */

   RETVALUE(ROK);
}/* end of hiRecvMsg() */


/*
*
*       Fun:   TUCL receive/send function 
*
*       Desc:  This function is called from either a permanent task function,
*              the activation function or from a timer function. This function 
*              will call cmInetSelect with the appropriate timeout values. 
*
*              If blockingSelect parameter is true, cmInetSelect will block 
*              till one of the sockets is ready. In this case the function 
*              will not return control to the caller.
*
*              For multi-threaded cases -
*
*              When one of the main threads sends a request to close this 
*              thread then the function will return control to the caller.
*           
*              For non multi-threaded cases -
*
*              If blockingSelect is false then this function will return
*              control to the caller after one call to select.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16  hiSendRecvFn
(
HiFdGrpInfo    *grpInfoPtr,
Bool           blockingSelect 
)
#else
PUBLIC S16  hiSendRecvFn(grpInfoPtr, blockingSelect) 
HiFdGrpInfo    *grpInfoPtr;
Bool           blockingSelect;
#endif
{

   U32            timeout;    /* timeout for select call */
   S16            ret;        /* return value */
   CmInetFdSet    readMask;   /* read file descriptor mask */
   CmInetFdSet    writeMask;  /* write file descriptor mask */
   HiAlarmInfo    alInfo;     /* TUCL alarm information */
   S16            numFds;

   /* hi018.104: sending disconnect indication for select call failure */
   HiSap           *sap;       /* pointer to the sap contrl block */
   HiConCb         *conCb;     /* pointer to the connection block */
   HiConCb         *prevConCb; /* pointer to the connection block */
   U32             i;

   /* Initialisations */
   alInfo.spId = -1;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
   ret = ROK;
   numFds = 0;

   TRC2(hiSendRecvFn);

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (grpInfoPtr == NULLP)
      RETVALUE(RFAILED);
#endif /* ERRCLS_INT_PAR */

   /* Set timeout value to use for select */
   if (!blockingSelect)
   {
#ifdef HI006_12
      timeout = hiCb.cfg.selTimeout;
#else
      timeout = 0;
#endif /* HI006_12 */
   }

   do
   {
      /* Copy the read fd_set in a temporary variable */
      cmMemcpy((U8 *) &readMask, 
               (U8 *) &grpInfoPtr->grpCb.readFdSet, 
               sizeof(CmInetFdSet));
   
      /* Copy the write fd_set in a temporary variable */
      if (grpInfoPtr->grpCb.numWrFds)
      {
         cmMemcpy((U8 *) &writeMask, 
                  (U8 *) &grpInfoPtr->grpCb.writeFdSet, 
                  sizeof(CmInetFdSet));
      } 

      if (blockingSelect)
      {
         if (grpInfoPtr->grpCb.numWrFds)
            ret = cmInetSelect(&readMask, &writeMask, NULLP, &numFds);
         else
            ret = cmInetSelect(&readMask, NULLP, NULLP, &numFds);
      }
      else
      {
         if (grpInfoPtr->grpCb.numWrFds)
            ret = cmInetSelect(&readMask, &writeMask, &timeout, &numFds);
         else
            ret = cmInetSelect(&readMask, NULLP, &timeout, &numFds);
      }

      if (ret == RFAILED)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         HILOGERROR_DEBUG(EHI207, (ErrVal)ret, 0,
                    "hiSendRecvFn : select call failure ");

         hiSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_INV_EVT,
                     LHI_CAUSE_SOCK_SLCT_ERR, &alInfo);

#endif /* ERRCLS_INT_PAR */
      
         /* hi018.104: Sedning disconect indication in case of *
          * select call failure. The fix is for SCTP only now
	  */
         for (i = 0; i < hiCb.cfg.numSaps; i++)
         {
            sap = hiCb.sapLstPtr[i];
            if (sap != (HiSap *) NULLP)
            {
               if (sap->uiPst.dstEnt == ENTSB)
               {
                  conCb = prevConCb = NULLP;
                  while((ret = cmHashListGetNext(&sap->sapHlCp, (PTR)prevConCb,
                                         (PTR *)&conCb)) == ROK)
                  {
                     prevConCb = conCb;
                     hiDiscSockHandle(TRUE, HI_SELECT_ERR, conCb);
                     conCb = NULLP;
                  }
	       }
	    }
         }
         RETVALUE(RFAILED);
      }
      if (numFds)
      {
         /* If there are some sockets set call hiPollSockets */
         if (grpInfoPtr->grpCb.numWrFds)
            ret = hiPollSockets(grpInfoPtr, &readMask, &writeMask, numFds); 
         else
            ret = hiPollSockets(grpInfoPtr, &readMask, NULLP, numFds); 
         if (ret == RCLOSED)
         {
            /* This means that some data was posted by the main thread.
             * This thread will give back control to the SSI and will
             * later be killed
             */
            RETVALUE(RCLOSED);
         }
      }
   } while(blockingSelect); /* end of while loop */

   RETVALUE(ROK);
} /* end of hiSendRecvFn */


/*
*
*       Fun:      hiPollSockets
*
*       Desc:     This function is used to go through the hash list associated
*                 with the current fd set block.
*                 New TCP connections are accepted and the received
*                 TCP/UDP/RAW data is sent to the user. 
*                 New connections are checked for completion.
*
*       Ret:      ROK
*                 RFAILED
*
*       Notes:    None
*
*       File:     hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16 hiPollSockets
(
HiFdGrpInfo       *grpInfoPtr,   /* read file descriptor group info ptr */
CmInetFdSet       *readMaskPtr,  /* read mask returned from select */
CmInetFdSet       *writeMaskPtr, /* write mask returned from select */
S16               numFds         /* number of descriptors set */
)
#else
PUBLIC S16 hiPollSockets(grpInfoPtr, readMaskPtr, writeMaskPtr, numFds)
HiFdGrpInfo       *grpInfoPtr;   /* read file descriptor group info ptr */
CmInetFdSet       *readMaskPtr;  /* read mask returned from select */
CmInetFdSet       *writeMaskPtr; /* write mask returned from select */
S16               numFds;        /* number of descriptors set */
#endif
{

   HiConCb        *prevConCb;   /* previous connection in the hash list */
   HiConCb        *conCb;       /* next connection in the hash list */
   CmInetMemInfo  info;         /* region and pool */
   S16            ret;          /* return value from function */
   CmHashListCp   *crntBlkHlCp; /* current fd blocks hash list
                                 * control point */
#ifdef HI_FAST_FIND
   CmInetFdType   tempSock;
#else  /* HI_FAST_FIND */
   CmInetFd       *sockPtr;     /* socket descriptor */
#endif /* HI_FAST_FIND */
   CmTptAddr      locTptAddr;
   HiAlarmInfo    alInfo;        /* Alarm Information */

   TRC2(hiPollSockets)

   /* Variable initializations */
   info.region = hiCb.hiInit.region;
   info.pool   = hiCb.hiInit.pool;
   prevConCb   = conCb = NULLP;
   
   alInfo.spId = -1;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

#ifdef HI_MULTI_THREADED     
   /* See if a message has come on the reserved UDP server */
   if (CM_INET_FD_ISSET(&grpInfoPtr->grpCb.servFd, readMaskPtr))
   {
      ret = hiProcResvServMsg(grpInfoPtr, readMaskPtr, writeMaskPtr, 
                              &numFds);
      /* RCLOSED is returned when the UDP server gets some data */
      if (ret == RCLOSED)
         RETVALUE(RCLOSED);
   }
#endif /* HI_MULTI_THREADED */

#ifdef HI_REL_1_3 
   /* If this file descriptor block is processing the ICMP socket then process
    * the ICMP socket first */
   if (grpInfoPtr->procIcmp)
   {
      /* Check if the icmpConFd is set in the read file descriptor set */
      if (CM_INET_FD_ISSET(&hiCb.icmpConFd, readMaskPtr))
      {
         numFds --;
         CM_INET_FD_CLR(&hiCb.icmpConFd, readMaskPtr);
         /* If something goes wrong while receiving messages from the 
          * ICMP socket then incase of multi-threaded case a message is 
          * sent to all the appropriate saps */
         ret = hiRecvIcmpMsg();
         if (ret == RFAILED)
         {
#ifdef HI_MULTI_THREADED
            grpInfoPtr->procIcmp = FALSE;
            CM_INET_FD_CLR(&grpInfoPtr->icmpConFd, 
                           &grpInfoPtr->grpCb.readFdSet);
#else
            grpInfoPtr->procIcmp = FALSE;
            HI_CLOSE_SOCKET(&hiCb.icmpConFd);
            CM_INET_FD_CLR(&hiCb.icmpConFd, &grpInfoPtr->grpCb.readFdSet);
#endif /* HI_MULTI_THREADED */
         }
      }
   }

#ifdef IPV6_SUPPORTED
   if (grpInfoPtr->procIcmp6)
   {
      /* Check if the ipv6 icmpConFd is set in the read file descriptor set */
      if (CM_INET_FD_ISSET(&hiCb.icmp6ConFd, readMaskPtr))
      {
         numFds --;
         CM_INET_FD_CLR(&hiCb.icmp6ConFd, readMaskPtr);
         ret = hiRecvIcmp6Msg();
         if (ret == RFAILED)
         {
#ifdef HI_MULTI_THREADED
            grpInfoPtr->procIcmp6 = FALSE;
            CM_INET_FD_CLR(&grpInfoPtr->icmp6ConFd, 
                           &grpInfoPtr->grpCb.readFdSet);
#else
            grpInfoPtr->procIcmp6 = FALSE;
            HI_CLOSE_SOCKET(&hiCb.icmp6ConFd);
            CM_INET_FD_CLR(&hiCb.icmp6ConFd, &grpInfoPtr->grpCb.readFdSet);
#endif /* HI_MULTI_THREADED */
         }
      }
   }
#endif /* IPV6_SUPPORTED */
#endif /* HI_REL_1_3 */

   /* First go through the write file descriptor set */
   crntBlkHlCp = &grpInfoPtr->grpCb.wrFdHlCp;
   conCb = prevConCb = NULLP;
   
   /* The write mask pointer may be null here */
   if (writeMaskPtr)
   {
      while(((ret = cmHashListGetNext(crntBlkHlCp, (PTR) prevConCb,
                                      (PTR *) &conCb)) == ROK) && (numFds))
      {
         /* check if this socket is ready to write */
         if (CM_INET_FD_ISSET(&conCb->conFd, writeMaskPtr))
         {
            numFds --;
            /* Check if a connection was pending */
            if(conCb->conState == HI_ST_CLT_CONNECTING)
            {
               /* hi002.104 - Get the local transport address here */
#ifdef IPV6_SUPPORTED
               (Void)cmInetGetSockName(&conCb->conFd, 
                                       (CmInetAddr *)&locTptAddr);
#else
               locTptAddr.type = CM_TPTADDR_IPV4;
               (Void)cmInetGetSockName(&conCb->conFd, 
                                       &(locTptAddr.u.ipv4TptAddr));
#endif /* IPV6_SUPPORTED */

               /* Copy the local transport address in the conCb */
               cmMemcpy((U8*)&conCb->locTptAddr, (U8*)&locTptAddr, 
                         (U32) sizeof(CmTptAddr));

               if (CM_INET_FD_ISSET(&conCb->conFd, readMaskPtr))
               {
                  numFds --;
                  CM_INET_FD_CLR(&conCb->conFd, readMaskPtr);
                  /* Two possibilities here */
                  /* 1 - Connection has completed and data has arrived */
                  /* In this case a conCfm is issued followed by a DatInd */
                  /* 2 - There was an error connecting */
                  /* In this case a disconnect indication is issued to the 
                   * upper user */
                  ret = hiRecvMsg(conCb);
                  if ((ret != ROK) && (ret != ROKDNA))
                  {
                     /* A disconnect indication is sent from within the
                      * function */
#ifdef HI_MULTI_THREADED
                     /* Clear the file descriptors here */
                     hiDelFrmFdGrp(grpInfoPtr, conCb, HI_FDGRP_BOTH_LIST);
#ifndef HI_LPBK                     
                     /* hi002.104 - Clearing the file-descriptor */
                     HI_DEL_FRM_FDSET(grpInfoPtr, conCb, HI_FDGRP_BOTH_LIST);
#endif /* HI_LPBK */                     
                     hiSendIntDiscInd(conCb->sap, HI_PROVIDER_CON_ID, 
                                      conCb->spConId, conCb->reason,
                                      grpInfoPtr->thisInst);
#else
                     /* hi029.104 Clear the file descriptors here */
                     hiDelFrmFdGrp(grpInfoPtr, conCb, HI_FDGRP_BOTH_LIST);

                     /* hi029.104: Remove from Fdset */
                     HI_DEL_FRM_FDSET(grpInfoPtr, conCb, HI_FDGRP_BOTH_LIST);

                     /* hi018.104: Send disconnect idnication to 
		      *	the upper layer 
		      */ 
                     /* hi022.104: Send disconnect only for raw sockets */
	             if((conCb->srvcType == HI_SRVC_RAW_SCTP)||(conCb->srvcType == HI_SRVC_RAW_SCTP_PRIOR))
                     {
                        hiDiscSockHandle(FALSE, HI_SOCK_RECV_ERR, conCb);
                     }
#endif /* HI_MULTI_THREADED */
                     continue; 
                  }
               }
               else
               {
                  /* Mark the connection as completed */
                  conCb->conState = HI_ST_CONNECTED;

                  /* hi002.104 - Removing the setting of local tpt address 
                   * here. This is done previously */
   
                  /* Issue a connection confirm to the upper layer */
#ifdef HI_MULTI_THREADED
                  HiUiHitConCfm(&conCb->sap->uiConCfmPst, conCb->sap->suId, 
                                conCb->suConId, conCb->spConId, &locTptAddr);
#else
                  HiUiHitConCfm(&conCb->sap->uiPst, conCb->sap->suId, 
                                conCb->suConId, conCb->spConId, &locTptAddr);
#endif /* HI_MULTI_THREADED */
               }
               /* The conCb can be deleted from the write list. There is no
                * danger of the conCb being in the transmit Q list
                */
               hiDelFrmFdGrp(grpInfoPtr, conCb, HI_FDGRP_WRITE_LIST);
#ifndef HI_LPBK               
               /* hi002.104 - Remove file descriptor from fd_set */               
               HI_DEL_FRM_FDSET(grpInfoPtr, conCb, HI_FDGRP_WRITE_LIST);
#endif /* HI_LPBK */               
               continue;
            }
            else
            {
               /* Check if there is data in the conCb->queue to be sent out */
               ret = hiChkTxQ(conCb);
               if (ret != ROK)    
               {
                  if (ret != RWOULDBLOCK)
                  {
                     /* Check if this fd is set in the read file descriptor 
                      * list. If it is clear it and decrement numFds */
                     if (CM_INET_FD_ISSET(&conCb->conFd, readMaskPtr))
                     {
                        CM_INET_FD_CLR(&conCb->conFd, readMaskPtr);
                        numFds --;
                     }
#ifdef HI_MULTI_THREADED
                     /* Remove the conCb from both the lists */
                     hiDelFrmFdGrp(grpInfoPtr, conCb, HI_FDGRP_BOTH_LIST);
#ifndef HI_LPBK                     
                     /* hi002.104 - Remove file descriptor from fd_set */                    
                     HI_DEL_FRM_FDSET(grpInfoPtr, conCb, HI_FDGRP_BOTH_LIST);
#endif /* HI_LPBK */
                     hiSendIntDiscInd(conCb->sap, HI_PROVIDER_CON_ID, 
                                      conCb->spConId, conCb->reason, 
                                      grpInfoPtr->thisInst);
#else
                     HI_DISCIND(conCb->sap, HI_PROVIDER_CON_ID, conCb->spConId, 
                                conCb->reason);
                     hiFreeConCb(conCb);
#endif /* HI_MULTI_THREADED */
                  }
               }
               else 
               {
                  /* return value was OK */
#ifdef HI_MULTI_THREADED
                  /* Issue an internal primitive to the TUCL instance informing
                   * it that all mBufs are sent out */
                  hiSendIntCongOff(conCb->sap, conCb->spConId, 
                                   grpInfoPtr->thisInst);
#else
                  conCb->mBufInQ = FALSE;
#endif /* HI_MULTI_THREADED */
                  hiDelFrmFdGrp(grpInfoPtr, conCb, HI_FDGRP_WRITE_LIST);
#ifndef HI_LPBK                  
                  /* hi002.104 - Remove file descriptor from fd_set */
                  HI_DEL_FRM_FDSET(grpInfoPtr, conCb, HI_FDGRP_WRITE_LIST);
#endif /* HI_LPBK */                  
                  continue;
               }
            }
         }
         prevConCb = conCb;
      } /* end of while loop */
   } /* end of if statement */

   /* go through the connection block hash list to get any socket ready
    * to be read.
    */
   crntBlkHlCp = &grpInfoPtr->grpCb.rdFdHlCp;
   /* hi002.104 - Initialise prevConCb and conCb to NULL */
   prevConCb = conCb = NULLP;

#ifdef HI_FAST_FIND
   while (numFds)
#else
   while(((ret = cmHashListGetNext(crntBlkHlCp, (PTR) prevConCb,
         (PTR *) &conCb)) == ROK) && (numFds))
#endif /* HI_FAST_FIND */
   {
#ifdef HI_FAST_FIND 
      /* Get the next file descriptor set */
      ret = cmInetGetFd(grpInfoPtr->grpCb.rdFdSetInfo, readMaskPtr,
                        &tempSock);
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         HILOGERROR_DEBUG(EHI208, (ErrVal) ret, 0,
                    "hiPollSockets(): cmInetGetFd call failed \n");
         RETVALUE(RFAILED);
      }
#endif /* ERRCLS_DEBUG */

      /* Search for the file descriptor */
      ret = cmHashListFind(crntBlkHlCp, (U8 *)&tempSock, sizeof(CmInetFdType), 
                           0, (PTR *) &conCb);
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         HILOGERROR_DEBUG(EHI209, (ErrVal) ret, 0,
                    "hiPollSockets(): Socket not found in hash list \n");
         RETVALUE(RFAILED);
      }
#endif /* ERRCLS_DEBUG */

#else  /* HI_FAST_FIND */
      sockPtr = &conCb->conFd;

      /* check if this socket is ready to read */
      if (CM_INET_FD_ISSET(sockPtr, readMaskPtr))
#endif /* HI_FAST_FIND */ 
      {
         numFds --;

         /* the only valid states here are CONNECTED
          * SRV_LISTEN or CONNECTED_NOWR */
         if(!((conCb->conState == HI_ST_CONNECTED) ||
              (conCb->conState == HI_ST_SRV_LISTEN) ||
              (conCb->conState == HI_ST_CONNECTED_NOWR)))
         {
            continue;
         }/* end if */
  
         /* If this is a TCP server accept the connections */
         if (conCb->conState == HI_ST_SRV_LISTEN)
         {
            /* hi005.104: if TSAP is under resource congestion
             * ignore the incoming connection */
            if (conCb->sap->resCongStrt)
            {
               continue;
            }
            else
            {
               hiAcceptTcpCon(conCb);
            }            
         }
         else
         {
            ret = hiChkRes(conCb->sap);
            if(ret != ROK)
            {
               /* severe resource congestion, data is not read from
                * the socket */
               continue;
            }
            else
            {
               /* receive the TCP data or UDP datagram */
               ret = hiRecvMsg(conCb);
			   
			   if ((ret != ROK) && (ret != ROKDNA))
               {
               		if(conCb->srvcType != HI_SRVC_UDP)/* zhouguis modified this 2006-8-2 */
               		{
#ifdef HI_MULTI_THREADED
		                hiDelFrmFdGrp(grpInfoPtr, conCb, HI_FDGRP_BOTH_LIST);
#ifndef HI_LPBK                  
		                  /* hi002.104 - Remove file descriptor from fd_set */
		                HI_DEL_FRM_FDSET(grpInfoPtr, conCb, HI_FDGRP_BOTH_LIST);
#endif /* HI_LPBK */                  
		                hiSendIntDiscInd(conCb->sap, HI_PROVIDER_CON_ID, 
		                                   conCb->spConId, conCb->reason,
		                                   grpInfoPtr->thisInst);
#else
		                HI_DISCIND(conCb->sap, HI_USER_CON_ID, conCb->suConId, 
		                             conCb->reason);
		                hiFreeConCb(conCb);
#endif /* HI_MULTI_THREADED */
		                continue;               			
               		}
					else /*conCb->srvcType == HI_SRVC_UDP zhouguis modified this 2006-8-2  */
					{
						SPrint("\nUDP receiced error information.\n");
					}
               }
            }/* end if */
         } 
      }
#ifndef HI_FAST_FIND
      prevConCb = conCb;
#endif /* HI_FAST_FIND */
   }
#ifdef HI_FAST_FIND
   CM_INET_FDSETINFO_RESET(grpInfoPtr->grpCb.rdFdSetInfo);
#endif /* HI_FAST_FIND */

   RETVALUE(ROK);
} /* end of hiPollSockets */

#ifdef HI_MULTI_THREADED

/*
*
*       Fun:      hiProcResvServMsg
*
*       Desc:     This function is used to process the message received on 
*                 the reserved UDP server. 
*                 
*                 While deleting conCbs if the file descriptor is set in 
*                 the readMask or the writeMask fd_sets they will be cleared.
*                 The numFds will be decremented when a fd is cleared.
*
*       Ret:      ROK
*                 RCLOSED
*                 RFAILED
*
*       Notes:    None
*
*       File:     hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16 hiProcResvServMsg
(
HiFdGrpInfo       *grpInfoPtr,   /* fd group information pointer */
CmInetFdSet       *readMaskPtr,  /* read mask returned from select */
CmInetFdSet       *writeMaskPtr, /* write mask returned from select */
S16               *numFds        /* number of descriptors set */
)
#else
PUBLIC S16 hiProcResvServMsg(grpInfoPtr, readMaskPtr, writeMaskPtr, numFds)
HiFdGrpInfo       *grpInfoPtr;   /* fd group information pointer */
CmInetFdSet       *readMaskPtr;  /* read mask returned from select */
CmInetFdSet       *writeMaskPtr; /* write mask returned from select */
S16               *numFds;       /* number of descriptors set */
#endif
{
   S16            ret;     /* return value from functions */
   HiAlarmInfo    alInfo;  /* TUCL alarm information */
   CmInetMemInfo  info;    /* region and pool */
   CmTptAddr      srcAddr; /* source address */
   Buffer         *mBuf;   /* Message buffer */
   MsgLen         len;     /* length to read */
   CmLListCp      *lCp;    /* linked list control point */
   CmLList        *listEnt;
   HiConCb        *conCb;  /* TUCL connection control block */
   HiSap          *sap;
   Bool           toBeClosed;
   HiSendThrMsg   msg;
   U16            i;
   /* hi015.104: reset the counter */
   StsCntr        numCons;

   TRC2(hiProcResvServMsg);

   /* Initialisations */
   alInfo.spId = -1;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   info.region = hiCb.hiInit.region;
   info.pool   = hiCb.hiInit.pool;
   toBeClosed = FALSE;

   /* read the available data on this socket */
   len = CM_INET_READ_ANY;
   ret = ROK;

   CM_INET_FD_CLR(&grpInfoPtr->grpCb.servFd, readMaskPtr);
   (*numFds) -= 1;

   /* No data is expected on the UDP server. */
   /* hi009.104 - added 2 new arguments */
#ifdef IPV6_SUPPORTED                 
   ret = cmInetRecvMsg(&grpInfoPtr->grpCb.servFd,  (CmInetAddr *)&srcAddr,
                       &info, &mBuf, &len, 
#ifdef IPV6_OPTS_SUPPORTED                       
                       NULLP, 
#endif
#ifdef LOCAL_INTF                       
                       NULLP,
#endif                       
                       CM_INET_NO_FLAG);
#else
   /* hi009.104 - added new argument */
   ret = cmInetRecvMsg(&grpInfoPtr->grpCb.servFd,  &(srcAddr.u.ipv4TptAddr), 
                       &info, &mBuf, &len,
#ifdef LOCAL_INTF                       
                       NULLP,
#endif                       
                       CM_INET_NO_FLAG);
#endif /* IPV6_SUPPORTED */
   if (ret == RFAILED)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      HILOGERROR_DEBUG(EHI210, (ErrVal)ret, grpInfoPtr->thisInst,
                 "hiProcResvServMsg : Error receiving data reserved server!");

      hiSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_INV_EVT,
                  LCM_CAUSE_UNKNOWN, &alInfo);

#endif /* ERRCLS_DEBUG */
      RETVALUE(RFAILED);
   }

   /* Unpack the message type */
   ret = SUnpkU8(&msg.msgType, mBuf);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI211, 0, grpInfoPtr->thisInst,
                 "hiProcResvServMsg : Could not unpack message type ");
      /* Deallocate the mBuf received on the server */
      SPutMsg(mBuf);
      RETVALUE(RFAILED);
   }

   switch(msg.msgType)
   {
      case HI_EMPTY_MSG:
         break;

      case HI_DELSAP_MSG:
      case HI_UBNDSAP_MSG:
         ret = SUnpkS16(&msg.inf.spId, mBuf);
         if (ret != ROK)
            RETVALUE(ROK);
         SPutMsg(mBuf);
         /* remove all conCbs assocaited with the sap */
         hiRmvSapConCbs(msg.inf.spId, grpInfoPtr, readMaskPtr, 
                        writeMaskPtr, numFds);
         if (msg.msgType == HI_DELSAP_MSG)
         {
            sap = hiCb.sapLstPtr[msg.inf.spId];
            hiSendIntSapConCbDel(sap, grpInfoPtr->thisInst);
         }
         RETVALUE(ROK);
         break;

      case HI_ZERO_SAPSTS:
         ret = SUnpkS16(&msg.inf.spId, mBuf);
         if (ret != ROK)
            RETVALUE(ROK);
         /* hi015.104: reset the counter */
         numCons = grpInfoPtr->grpCb.rxStsArr[msg.inf.spId].numCons;
         HI_ZERO(&grpInfoPtr->grpCb.rxStsArr[msg.inf.spId], sizeof(HiRxSts));
         grpInfoPtr->grpCb.rxStsArr[msg.inf.spId].numCons = numCons;
         SPutMsg(mBuf);
         RETVALUE(ROK);
         break;

      case HI_ZERO_GENSTS:
         /* hi015.104: reset the counter */
         numCons = grpInfoPtr->grpCb.genRxSts.numCons;
         HI_ZERO(&grpInfoPtr->grpCb.genRxSts, sizeof(HiRxSts));
         grpInfoPtr->grpCb.genRxSts.numCons = numCons;
         SPutMsg(mBuf);
         RETVALUE(ROK);
         break;

      case HI_ENDTSK_MSG:
         for (i = 0; i < hiCb.cfg.numSaps; i++)
            hiRmvSapConCbs(i, grpInfoPtr, readMaskPtr, 
                           writeMaskPtr, numFds);
         SPutMsg(mBuf);
         RETVALUE(RCLOSED);
         break;
      
      case HI_ADDICMP_SOCK:
         hiAddIcmpConFd(grpInfoPtr, CM_INET_IPV4ADDR_TYPE);
         SPutMsg(mBuf);
         RETVALUE(ROK);
         break;

      case HI_DELICMP_SOCK:
         hiDelIcmpConFd(grpInfoPtr, CM_INET_IPV4ADDR_TYPE);
         SPutMsg(mBuf);
         RETVALUE(ROK);
         break;

#ifdef IPV6_SUPPORTED
      case HI_ADDICMP6_SOCK:
         hiAddIcmpConFd(grpInfoPtr, CM_INET_IPV6ADDR_TYPE);
         SPutMsg(mBuf);
         RETVALUE(ROK);
         break;

      case HI_DELICMP6_SOCK:
         hiDelIcmpConFd(grpInfoPtr, CM_INET_IPV6ADDR_TYPE);
         SPutMsg(mBuf);
         RETVALUE(ROK);
         break;

      case HI_UPDICMP6_FILTER:
         hiUpdIcmp6Filter();
         SPutMsg(mBuf);
         RETVALUE(ROK);
         break;
#endif /* IPV6_SUPPORTED */

      default:
         break;
   }

   /* Deallocate the mBuf received on the server */
   SPutMsg(mBuf);

   /* Acquire lock to access the linked lists */
   HI_LOCK(&grpInfoPtr->cmInfoLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI212, (ErrVal)ret, grpInfoPtr->thisInst,
                 "hiProcResvServMsg : Could not acquire common info lock ");

      RETVALUE(RFAILED);
   }

   /* Go through the linked list and check to see if there are any conCbs to
    * be added */
   lCp =  (CmLListCp *)&grpInfoPtr->cmGrpCb.newConCbLst;
   
   /* Run through the new connection linked list */
   for (conCb = (HiConCb *)CM_LLIST_FIRST_NODE(lCp, listEnt);
        conCb != NULLP;
        conCb = (HiConCb *)CM_LLIST_NEXT_NODE(lCp, listEnt))
   {
      /* delete this conCb from the linked list */
      cmLListDelFrm(lCp, (CmLList *)&conCb->llEnt);

      conCb->isInList &= ~(HI_CONCB_IN_TOADD_LIST);

      /* All additions to the fd_set and hashlist are done in this 
       * function. Any disconnect indication is given from within this
       * function.
       */
      hiProcAddConCb(conCb, grpInfoPtr);
   } /* end of concbs to be added in the linked list */

   /* Go through the linked list and check to see if there are any conCbs to
    * on which there is data to be sent */
   lCp =  (CmLListCp *)&grpInfoPtr->cmGrpCb.txQCongLst;

   for (conCb = (HiConCb *)CM_LLIST_FIRST_NODE(lCp, listEnt);
        conCb != NULLP;
        conCb = (HiConCb *)CM_LLIST_NEXT_NODE(lCp, listEnt))
   {
      /* delete this conCb from the linked list */
      cmLListDelFrm(lCp, (CmLList *)&conCb->llEnt);

      conCb->isInList &= ~(HI_CONCB_IN_CONG_LIST);

      hiProcTxQConCb(conCb, grpInfoPtr);
   } /* end of transmit queue list */

   /* Go through the linked list and check to see if there are any conCbs to
    * be deleted */
   lCp =  (CmLListCp *)&grpInfoPtr->cmGrpCb.toBeDelLst;
   for (conCb = (HiConCb *)CM_LLIST_FIRST_NODE(lCp, listEnt);
        conCb != NULLP;
        conCb = (HiConCb *)CM_LLIST_NEXT_NODE(lCp, listEnt))
   {
      sap = conCb->sap;

      /* delete this conCb from the linked list */
      cmLListDelFrm(lCp, (CmLList *)&conCb->llEnt);
      conCb->isInList &= ~(HI_CONCB_IN_TODEL_LIST);
  
      hiProcDelConCb(conCb, grpInfoPtr, readMaskPtr, writeMaskPtr,
                     numFds);
   } /* End of to be deleted list processing */

   /* Unlock the common information structure and continue */
   HI_UNLOCK(&grpInfoPtr->cmInfoLock, alInfo, ret)
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI213, (ErrVal)ret, grpInfoPtr->thisInst,
                 "hiProcResvServMsg : Could not unlock common info lock");

      RETVALUE(RFAILED);
   }

   if (toBeClosed)
      RETVALUE(RCLOSED);

   RETVALUE(ret);
   
} /* end of hiProcResvServMsg */
#endif /* HI_MULTI_THREADED */

#ifndef HI_MULTI_THREADED

/*
*
*       Fun:   hiScanConLst
*
*       Desc:  This function is used to scan the linked list of
*              connection blocks marked for deletion. TUCL does not free
*              connection blocks on getting a XxYyHitDiscReq from the
*              service user or if any error is encountered. It removes
*              the corresponding desriptor from the global read and
*              write lists and inserts that connection block in to a
*              global linked list. 
*
*       Ret:   Void
*
*       Notes: None
*
*       File:  hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC Void hiScanConLst
(
Void
)
#else
PUBLIC Void hiScanConLst()
#endif
{

   CmLListCp    *lCp;
   U16          idx;
   CmLList      *listEnt;
   HiConCb      *conCb;
   HiSap        *sap;
   UConnId      conId;
   U8           choice;
   Action       action;
   HiAlarmInfo  alInfo;
/* hi022.104: Send disconnect only for raw socket */
   U8           srvcType;
#ifndef HI_REL_1_3
   U32          prevQsiz;
#endif /* HI_REL_1_3 */
   /* hi018.104: add a local variable */
   Bool         discInd;
   Reason       rea;
   
   TRC2(hiScanConLst)
 
   /* hi018.104: init discInd */	   
   discInd = FALSE;	   
   rea     = HI_INTERNAL_ERR;
   /* Variable initializations */
   lCp       =  (CmLListCp *)&hiCb.llstCp;
  
   /* run through the linked list */
   for (conCb = (HiConCb *)CM_LLIST_FIRST_NODE(lCp, listEnt); 
        conCb != NULLP;
        conCb = (HiConCb *)CM_LLIST_NEXT_NODE(lCp, listEnt))
   {
      sap     = conCb->sap;
     
      /* Initialise the alarm parameters */ 
      alInfo.spId = sap->spId;
      alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
   
      /* check to see if this block is to be deleted */
      if (conCb->toBeDel)
      {
         /* remove this node from the connection control block */
         cmLListDelFrm(lCp, (CmLList *)&conCb->llEnt);

         action  = conCb->action;
         sap     = conCb->sap;
         /* hi018.104: save discInd flag */
	 discInd = conCb->discInd;
	 rea = conCb->reason;
         /* hi022.104: Send disconnect only for raw socket */
         srvcType = conCb->srvcType;
#ifndef HI_LPBK
         /* delete this block from the fd block hash list */

         /* get the index in the fd block array */
         idx = conCb->fdBlkIdx;
         hiDelFrmFdGrp(hiCb.hiFdGrpInfoLstPtr[idx], conCb, 
                          HI_FDGRP_BOTH_LIST);
#else
         UNUSED(idx);
#endif /* HI_LPBK */

#ifdef HI_REL_1_3  
         /* If this connection block was listening to ICMP messages then we have
          * to deallocate the filter structure if any & decrement the number of 
          * current ICMP listeners  */

         if (conCb->icmpMask)  
         {
            conCb->icmpMask = 0;
            HI_FREE((conCb->numFilters*sizeof(CmIcmpError)), conCb->icmpError);
            conCb->numFilters = 0;
        
            /* If the number of current icmpUsers is Zero then we have to close 
             * the socket & reset the Fdset from Block index. */
            if(!(--hiCb.icmpUsers))
            {
               CM_INET_FD_CLR(&(hiCb.icmpConFd),
               &(hiCb.hiFdGrpInfoLstPtr[0]->grpCb.readFdSet));

               hiCb.hiFdGrpInfoLstPtr[0]->numFds -= 1;
               
               /* close the socket */
               HI_CLOSE_SOCKET(&hiCb.icmpConFd); 
               
               /* zero out the icmp conFd structure */
               HI_ZERO(&hiCb.icmpConFd, sizeof(CmInetFd)); 
            }
         
            (Void)cmHashListDelete(&hiCb.icmpHlCp, (PTR) conCb);
         }
#endif  /* HI_REL_1_3 */ 

         conId = ((conCb->flag & HI_FL_UDP)?
                  (choice = HI_USER_CON_ID, conCb->suConId):
                  (choice = HI_PROVIDER_CON_ID, conCb->spConId));

         /* delete from sap hash list */
         (Void)cmHashListDelete(&sap->sapHlCp, (PTR)conCb);

#ifndef HI_REL_1_3 
         /* check the SAP transmit queue sizes */
         prevQsiz = sap->currTxQSiz;

         /* decrement the currTxQSiz in the corresponding sap */
         sap->currTxQSiz -= conCb->txQSiz;
#endif /* HI_REL_1_3 */

         /* zero the structure and free it */
         HI_FREE(sizeof(HiConCb), conCb)

         /* decrement statistics counters */
         sap->genTxSts.numCons--;
         sap->txSts.numCons--;

#ifndef HI_REL_1_3
         /* issue a Flow Control Indication to the user if the
          * total queue size falls below txqCongStopLim
          */
         if (prevQsiz >= sap->cfg.txqCongStrtLim)
         {
            /* indicate to the LM that transmit queue congestion limit
             * has subsided and all further data requests should
             * go through */
            hiSendAlarm(LCM_CATEGORY_RESOURCE, LHI_EVENT_TXQ_CONG_OFF,
                        LCM_CAUSE_UNKNOWN, &alInfo);

            if(sap->currTxQSiz <= sap->cfg.txqCongStopLim)
            {
               /* issue a Flow Control Indication to the user if the
                * total queue size falls below txqCongStopLim */
               if(sap->cfg.flcEnb)
               {
                  /* increment the statistics counters */
                  hiCb.errSts.numFlcInd++;

                  /* remove the TSAP from flow control */
                  sap->flc = FALSE;

                  HiUiHitFlcInd(&sap->uiPst, sap->suId, HI_FLC_STOP);
                }/* end if */
            }/* end if */
         }/* end if */
#endif /* HI_REL_1_3 */

         if (action)
	 {
            HiUiHitDiscCfm(&sap->uiPst, sap->suId, choice, conId, action);
	 }
	 /* hi018.104: send Disc Ind */
         /* hi022.104: Send disconnect only for raw socket */
	 else if(((srvcType == HI_SRVC_RAW_SCTP)||(srvcType == HI_SRVC_RAW_SCTP_PRIOR)) &&
                 (discInd == TRUE))
	 {
            HI_DISCIND(sap, choice, conId, rea);
	 }
      }/* end if */
   }/* end for */
}/* end of hiScanConLst() */
#endif /* HI_MULTI_THREADED */


/*
*
*       Fun:   TUCL receive thread spawn task (hiRecvTsk) 
*
*       Desc:  This function is executed as a permanent task or as a timer
*              function. The mode of operation depends on the general  
*              configuration. This function polls all the sockets for any 
*              data received from the other end. Each time this function
*              calls select on different file descriptor sets.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16 hiRecvTsk
(
Pst       *tpst,        /* post */
Buffer    *mBuf         /* message buffer */
)
#else
PUBLIC S16 hiRecvTsk(tpst, mBuf) 
Pst       *tpst;        /* post */
Buffer    *mBuf;        /* message buffer */
#endif
{
   
   S16      ret;
#ifndef HI_MULTI_THREADED     
   U16      blkNum;
   U16      numGrps;
#else  /* HI_MULTI_THREADED      */
   Inst     thisInst;
#endif /* HI_MULTI_THREADED      */

   /* Initialization */
   ret = ROK;

   /* hi021.104: UNUSED tpst if Multithreaded is not used */
#ifndef HI_MULTI_THREADED  
   UNUSED(tpst);
#endif /* HI_MULTI_THREADED */

   /* Check if general configuration is done */
   if (!hiCb.cfgDone)
      RETVALUE(ROK);

   if (mBuf)
      SPutMsg(mBuf);

#ifdef HI_MULTI_THREADED     

   /* Each receive thread will cater to one file descriptor group 
    * This group depends on the instance number of this thread.
    */
   HI_GET_THISINST(tpst, thisInst);

   /* This function is not expected to return control. The only time
    * this function should return control is at the time of shutdown.
    * In all other cases this will go on forever.
    */
   ret = hiSendRecvFn(hiCb.hiFdGrpInfoLstPtr[thisInst], TRUE);
   if (ret != ROK)
   {
      /* This point should be reached only when the main thread sends a
       * message on the UDP servers to close the receive thread. */
      /* Send an internal primitive to TUCL instance 0 telling it that this 
       * receive thread is no longer polling for data */
      hiSendIntRecvThrClosed(tpst->dstInst);
      
      RETVALUE(ROK);
   } /* end of while */
#else /* HI_MULTI_THREADED      */

   /* Call scan con list to clean up any old connections */
   hiScanConLst();

   blkNum = hiCb.nextFdGrp;

   ret = hiSendRecvFn(hiCb.hiFdGrpInfoLstPtr[blkNum], FALSE);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   /* Go through the file descriptor groups to check for next group to 
    * poll. This group will be polled in the next scheduling */
   for (numGrps = 0; numGrps < hiCb.numFdGrps; numGrps++)
   {
      blkNum++;

      if (blkNum >= hiCb.numFdGrps)
         blkNum = 0;

      /* see if some sockets have been set in this block */
      if (hiCb.hiFdGrpInfoLstPtr[blkNum]->numFds > 1)
      {
         hiCb.nextFdGrp = blkNum;
         break;
      }
   }

#endif /* HI_MULTI_THREADED      */

   RETVALUE(ROK);
} /* end of hiRecvTsk */


/*
*
*       Fun:   TUCL Permamnent Task (hiScanPermTsk) 
*
*       Desc:  This is kept for backward compatibility. In a multi 
*              threaded mode there is no permanent task. Hence this 
*              function name is not appropriate for that. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16  hiScanPermTsk
(
Pst       *tpst,        /* post */
Buffer    *mBuf         /* message buffer */
)
#else
PUBLIC S16  hiScanPermTsk(tpst, mBuf) 
Pst       *tpst;        /* post */
Buffer    *mBuf;        /* message buffer */
#endif
{
   hiRecvTsk(tpst, mBuf);

   RETVALUE(ROK);
} /* end of hiScanPermTsk */

#ifdef HI_REL_1_3  

/*
*
*       Fun:   hiProcessIcmpReq 
*
*       Desc:  This function is executed 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy3.c
*
*/
 
#ifdef ANSI
PUBLIC S16  hiProcessIcmpReq
(
HiConCb *conCb,
CmIcmpFilter *icmpFilter 
)
#else
PUBLIC S16  hiProcessIcmpReq(conCb, icmpFilter) 
HiConCb *conCb;
CmIcmpFilter *icmpFilter;
#endif
{

   /* Variable declaration */
   U16            num;    
   S16            ret;
   HiAlarmInfo    alInfo;
   U8             type;
#ifdef HI_MULTI_THREADED
/*   HiFdGrpInfo    *grpInfoPtr; */
#endif /* HI_MULTI_THREADED */
   CmIcmpv4Filter *icmpv4Filter;
#ifdef IPV6_SUPPORTED
   CmIcmpv6Filter *icmpv6Filter;
#endif /* IPV6_SUPPORTED */

   alInfo.spId = conCb->sap->spId;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
   type = 0;
   num = 0;
   conCb->icmpError = NULLP;

#if (ERRCLASS & ERRCLS_DEBUG)
#ifdef IPV6_SUPPORTED
   if ((icmpFilter->u.icmpv4Filter.icmpMsgFlag == FALSE) &&
       (icmpFilter->u.icmpv6Filter.icmpMsgFlag == FALSE)) 
#else
   if (icmpFilter->u.icmpv4Filter.icmpMsgFlag == FALSE)
#endif /* IPV6_SUPPORTED */
   { 
      /* Indicate proper error */
      HILOGERROR_DEBUG(EHI214, 0, 0, 
                  "hiProcessIcmpReq: Flag is false  ");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */

   if (icmpFilter->type == CM_ICMPVER4_FILTER)
   {
      type = CM_NETADDR_IPV4;           
      icmpv4Filter = (CmIcmpv4Filter *)&icmpFilter->u.icmpv4Filter;
      if(icmpv4Filter->allMsg == TRUE)
      {
         if(icmpv4Filter->protocol == CM_PROTOCOL_RAW)
            conCb->icmpMask |= ALL_ICMP_MSG;
         else 
         {
            conCb->filterProtocol = icmpv4Filter->protocol;
            conCb->icmpMask |= ALL_PROTO_SPEC_MSG;
         }
      }
      else 
      {
         if(icmpv4Filter->protocol == CM_PROTOCOL_RAW)
         {
            conCb->icmpMask |= ALL_FLTRD_ICMP_MSG;
            num = icmpv4Filter->num;
            conCb->numFilters = icmpv4Filter->num;
            HI_ALLOC((num * sizeof(CmIcmpError)), (conCb->icmpError));
            if (!conCb->icmpError)
               RETVALUE(RFAILED);
            /* hi010.104 - remove the "&" before conCb->icmpError */
            cmMemcpy((U8*)(conCb->icmpError),(U8*)icmpv4Filter->icmpError,
                     (num * sizeof(CmIcmpError)));
         }
         else 
         {
            conCb->filterProtocol = icmpv4Filter->protocol;
            conCb->icmpMask |= FLTRD_PROTO_SPEC_MSG;
            conCb->numFilters = icmpv4Filter->num;
            num = icmpv4Filter->num;
            HI_ALLOC((num * sizeof(CmIcmpError)), (conCb->icmpError));
            if (!conCb->icmpError)
               RETVALUE(RFAILED);
            /* hi010.104 - remove the "&" before conCb->icmpError */
            cmMemcpy((U8*)(conCb->icmpError),(U8*)icmpv4Filter->icmpError,
                     (num * sizeof(CmIcmpError)));
         }
      }
   }
#ifdef IPV6_SUPPORTED
   else
   {
      type = CM_NETADDR_IPV6;       
      icmpv6Filter = (CmIcmpv6Filter *)&icmpFilter->u.icmpv6Filter;
      if(icmpv6Filter->allMsg == TRUE)
         conCb->icmp6Mask |= ALL_ICMP_MSG;
      else 
      {
         conCb->numFilters = icmpv6Filter->num;
         conCb->icmp6Mask |= ALL_FLTRD_ICMP_MSG;
         num = icmpv6Filter->num;
         HI_ALLOC((num * sizeof(CmIcmpError)), (conCb->icmpError));
         if (!conCb->icmpError)
            RETVALUE(RFAILED);
         cmMemcpy((U8*)(conCb->icmpError),(U8*)icmpv6Filter->icmpError,
                  (num * sizeof(CmIcmpError)));
      }
   }
#endif /* IPV6_SUPPORTED */

   /* Open an ICMP socket if necessary and also add the conCb in the icmp
    * hashlist */
   ret = hiOpenIcmpSock(conCb, type);
   if (ret != ROK)
   {
      if (conCb->icmpError)
         HI_FREE((num * sizeof(CmIcmpError)), conCb->icmpError);

      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of hiProcessIcmpReq */


/*
*
*       Fun:   hiOpenIcmpSock
*
*       Desc:  This function is used to open a Icmp socket if the number
*              of users is zero. This function also adds the conCb in the 
*              icmp hashlist.
*              
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiOpenIcmpSock 
(
HiConCb  *conCb,
U8       type
)
#else
PUBLIC S16 hiOpenIcmpSock(conCb, type)
HiConCb  *conCb;
U8       type;
#endif
{
   S16               ret;
   HiAlarmInfo       alInfo;
#ifdef HI_MULTI_THREADED     
   HiSendThrMsg      msg;
   SLockId           *hlLockId;
#endif /* HI_MULTI_THREADED */
   Bool              openSock;
#ifdef IPV6_SUPPORTED 
   U8                numIcmp6Filt;
   U8                icmpFltIdx;
   Bool              sendUpdFiltMsg;
#endif /* IPV6_FILTER */

   /* hi021.104: UNUSED type if IPV6 is not used */
#ifndef IPV6_SUPPORTED
   UNUSED(type);
#endif /* IPV6_SUPPORTED */

   /* Initialization */
   alInfo.spId = conCb->sap->spId;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
   openSock = FALSE;
   
   /* hi009.104 - INSURE fix */
#ifdef IPV6_SUPPORTED
   sendUpdFiltMsg = FALSE;
#endif /* IPV6_SUPPORTED */
          
#ifdef HI_MULTI_THREADED     
#ifdef IPV6_SUPPORTED
   if (type == CM_NETADDR_IPV6)         
      hlLockId = &hiCb.icmp6HlLock;
   else
#endif /* IPV6_SUPPORTED */
      hlLockId = &hiCb.icmpHlLock;

   /* Lock the hash list */
   HI_LOCK(hlLockId, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI215, (ErrVal) ret, conCb->sap->uiPst.srcInst,
                    "hiOpenIcmpSock () : Unable to lock icmp user lock \n");
      RETVALUE(RFAILED);
   }
#endif /* HI_MULTI_THREADED */

#ifdef IPV6_SUPPORTED
   if (type == CM_NETADDR_IPV6)
   {
      if (hiCb.icmp6Users == 0)
         openSock = TRUE;
   }
   else
#endif /* IPV6_SUPPORTED */
   {
      if (hiCb.icmpUsers == 0)
         openSock = TRUE;
   }

   if (openSock == TRUE)
   {
#ifdef IPV6_SUPPORTED
      if (type == CM_NETADDR_IPV6)
         ret = cmInetSocket(CM_INET_RAW, &hiCb.icmp6ConFd, CM_PROTOCOL_ICMPV6,
                            CM_INET_IPV6_DOMAIN);
      else
         ret = cmInetSocket(CM_INET_RAW, &hiCb.icmpConFd, CM_PROTOCOL_ICMP,
                            CM_INET_IPV4_DOMAIN);
#else
      ret = cmInetSocket(CM_INET_RAW, &hiCb.icmpConFd, CM_PROTOCOL_ICMP);
#endif /* IPV6_SUPPORTED */
      if (ret != ROK)
      {
         HILOGERROR_DEBUG(EHI216, (ErrVal)ret, conCb->sap->uiPst.srcInst,
               "hiOpenIcmpReq() : Failed to open an icmp socket ");
#ifdef HI_MULTI_THREADED 
         HI_UNLOCK(hlLockId, alInfo, ret);
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI217, (ErrVal) ret, conCb->sap->uiPst.srcInst,
               "hiOpenIcmpSock : Unable to unlock the icmp users lock \n");

         HI_LOCK(&hiCb.errStsLock, alInfo, ret); 
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI218, (ErrVal) 0, conCb->sap->uiPst.srcInst, 
                  "hiOpenIcmpReq () : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */

         hiCb.errSts.sockOpenErr ++;

#ifdef HI_MULTI_THREADED 
         HI_UNLOCK(&hiCb.errStsLock, alInfo, ret);
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI219, (ErrVal) 0, conCb->sap->uiPst.srcInst, 
                  "hiOpenIcmpReq () : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */
         RETVALUE(RFAILED);
      }
   }
   
   if(conCb->protocol == CM_PROTOCOL_ICMP)
   {
#ifdef IPV6_SUPPORTED 
      if (type == CM_NETADDR_IPV6)
         cmMemcpy((U8 *)&(conCb->conFd), (U8 *)&hiCb.icmp6ConFd,
                  (U32) sizeof(CmInetFd));
      else
#endif /* IPV6_SUPPORTED */
         cmMemcpy((U8 *)&(conCb->conFd), (U8 *)&hiCb.icmpConFd,
                  (U32) sizeof(CmInetFd));
   }
  
   /* Insert the conCbs in the respective hashlist */
#ifdef IPV6_SUPPORTED  
   if (type == CM_NETADDR_IPV6)
   {
      /* Add the conCb in the icmpHashList */
      ret = cmHashListInsert(&hiCb.icmp6HlCp, (PTR)conCb, 
                             (U8 *)&conCb->spConId, sizeof(UConnId));
      if (ret != ROK)
      {
         if (openSock)
            HI_CLOSE_SOCKET(&hiCb.icmp6ConFd);
         hiSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_INV_EVT, 
                     LCM_CAUSE_HASH_FAIL, &alInfo);
#ifdef HI_MULTI_THREADED
         HI_UNLOCK(hlLockId, alInfo, ret);
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI220, (ErrVal) ret, conCb->sap->uiPst.srcInst,
                 "hiOpenIcmpSock : Unable to unlock icmp users lock \n");
#endif /* HI_MULTI_THREADED */
         RETVALUE(RFAILED);
      }
      conCb->isInList |= HI_CONCB_IN_ICMP6_LIST;
   }
   else
#endif /* IPV6_SUPPORTED */
   {
      /* Add the conCb in the icmpHashList */
      ret = cmHashListInsert(&hiCb.icmpHlCp, (PTR)conCb, 
                             (U8 *)&conCb->spConId, sizeof(UConnId));
      if (ret != ROK)
      {
         if (openSock)
            HI_CLOSE_SOCKET(&hiCb.icmpConFd);
         hiSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_INV_EVT, 
                     LCM_CAUSE_HASH_FAIL, &alInfo);
#ifdef HI_MULTI_THREADED 
         HI_UNLOCK(hlLockId, alInfo, ret);
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI221, (ErrVal) ret, conCb->sap->uiPst.srcInst,
                 "hiOpenIcmpSock : Unable to unlock icmp users lock \n");
#endif /* HI_MULTI_THREADED */
         RETVALUE(RFAILED);
      }
      conCb->isInList |= HI_CONCB_IN_ICMP_LIST;
   }
   
   /* If the icmp socket is just opened then set the icmp conFd in the 
    * readFdSet */
   
   /* Send a message to the receive thread to add the icmp conFd to its 
    * file descriptor set for processing */
   if (openSock)
   {
#ifdef HI_MULTI_THREADED
#ifdef IPV6_SUPPORTED    
      if (type == CM_NETADDR_IPV6)
         msg.msgType = HI_ADDICMP6_SOCK;
      else
#endif /* IPV6_SUPPORTED */
         msg.msgType = HI_ADDICMP_SOCK;
      ret = hiSendRecvThrMsg(0, &msg);
      if (ret != ROK)
      {
#ifdef IPV6_SUPPORTED  
         if (type == CM_NETADDR_IPV6)
         {
            HI_CLOSE_SOCKET(&hiCb.icmp6ConFd);
            cmHashListDelete(&hiCb.icmp6HlCp, (PTR) conCb);
            conCb->isInList &= ~(HI_CONCB_IN_ICMP6_LIST);
         }
         else
#endif /* IPV6_SUPPORTED */
         {
            HI_CLOSE_SOCKET(&hiCb.icmpConFd);
            cmHashListDelete(&hiCb.icmpHlCp, (PTR) conCb);
            conCb->isInList &= ~(HI_CONCB_IN_ICMP_LIST);
         }
         HI_UNLOCK(hlLockId, alInfo, ret);
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI222, (ErrVal) ret, conCb->sap->uiPst.srcInst,
                 "hiOpenIcmpSock : Unable to unlock the icmp users lock \n");
         RETVALUE(RFAILED);
      }
#else
#ifdef IPV6_SUPPORTED
      if (type == CM_NETADDR_IPV6)
      {
         CM_INET_FD_SET(&(hiCb.icmp6ConFd),
                        &(hiCb.hiFdGrpInfoLstPtr[0]->grpCb.readFdSet));
         hiCb.hiFdGrpInfoLstPtr[0]->procIcmp6 = TRUE;
      }
      else
#endif /* IPV6_SUPPORTED */
      {
         /* Add the icmp File descriptor to the file descriptor group */
         CM_INET_FD_SET(&(hiCb.icmpConFd),
                     &(hiCb.hiFdGrpInfoLstPtr[0]->grpCb.readFdSet));
         hiCb.hiFdGrpInfoLstPtr[0]->procIcmp = TRUE;
      }
#endif /* HI_MULTI_THREADED */
   }
   
#ifdef IPV6_SUPPORTED 
   /* Update the ICMPv6 filter if necessary */
   if (conCb->icmp6Mask & (ALL_ICMP_MSG))
   {
      CM_INET_ICMP6_FILTER_SETPASSALL(hiCb.icmp6Filter);
      for(icmpFltIdx = 0; icmpFltIdx < CM_MAX_ICMP_ERROR; icmpFltIdx++)
      {
         if (hiCb.icmp6FiltArr[icmpFltIdx] == 0)
            sendUpdFiltMsg = TRUE;
         hiCb.icmp6FiltArr[icmpFltIdx] += 1;
      }
   }
   else
   {
      /* Update the filter users if necessary */
      for (numIcmp6Filt = 0; numIcmp6Filt < conCb->numFilters; numIcmp6Filt ++)
      {
         icmpFltIdx = conCb->icmpError[numIcmp6Filt].errType;
         if (hiCb.icmp6FiltArr[icmpFltIdx] == 0)
         {
            sendUpdFiltMsg = TRUE;
            CM_INET_ICMP6_FILTER_SETPASS(icmpFltIdx, hiCb.icmp6Filter);
         }
         hiCb.icmp6FiltArr[icmpFltIdx] += 1;
      }
   }

   if (sendUpdFiltMsg)
   {
#ifdef HI_MULTI_THREADED
      msg.msgType = HI_UPDICMP6_FILTER;
      ret = hiSendRecvThrMsg(0, &msg);
      if (ret != ROK)
      {
         if (type == CM_NETADDR_IPV6)
         {
            if (openSock)
               HI_CLOSE_SOCKET(&hiCb.icmp6ConFd);
            cmHashListDelete(&hiCb.icmp6HlCp, (PTR) conCb);
            conCb->isInList &= ~(HI_CONCB_IN_ICMP6_LIST);
         }
         else
         {
            if (openSock)
               HI_CLOSE_SOCKET(&hiCb.icmpConFd);
            cmHashListDelete(&hiCb.icmpHlCp, (PTR) conCb);
            conCb->isInList &= ~(HI_CONCB_IN_ICMP_LIST);
         }

         HI_UNLOCK(hlLockId, alInfo, ret);
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI223, (ErrVal) ret, conCb->sap->uiPst.srcInst,
                 "hiOpenIcmpSock : Unable to unlock the icmp users lock \n");
         RETVALUE(RFAILED);
      }
#else
      hiUpdIcmp6Filter();
#endif /* HI_MULTI_THREADED */
   }

   if (type == CM_NETADDR_IPV6)
      hiCb.icmp6Users += 1;
   else
#endif /* IPV6_SUPPORTED */
      hiCb.icmpUsers += 1;

#ifdef HI_MULTI_THREADED
   HI_UNLOCK(hlLockId, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI224, (ErrVal) ret, conCb->sap->uiPst.srcInst,
         "hiOpenIcmpSock : Unable to unlock the icmp users lock \n");
      RETVALUE(RFAILED);
   }
#endif /* HI_MULTI_THREADED */

   RETVALUE(ROK);
} /* end of hiOpenIcmpSock */


/*
*
*       Fun:   hiCloseIcmpSock
*
*       Desc:  This function is used to close the Icmp socket if 
*              the number of users is zero. 
*              
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiCloseIcmpSock 
(
HiConCb *conCb,
U8  type
)
#else
PUBLIC S16 hiCloseIcmpSock(conCb, type)
HiConCb *conCb;
U8  type;
#endif
{
#ifdef HI_MULTI_THREADED     
   HiAlarmInfo       alInfo;
   S16               ret;
   HiSendThrMsg      msg;
   SLockId           *hlLockId;
#endif /* HI_MULTI_THREADED */
#ifdef IPV6_SUPPORTED
   Bool              sendUpdFiltMsg;
   U8                numIcmp6Filt;
   U8                icmpFltIdx;
#endif /* IPV6_SUPPORTED */
   U8                *icmpUsers;

   /* hi021.104: UNUSED type if IPV6 is not used */
#ifndef IPV6_SUPPORTED
   UNUSED(type);
#endif /* IPV6_SUPPORTED */

   /* Initialization */
#ifdef HI_MULTI_THREADED     
   alInfo.spId = -1;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
#endif /* HI_MULTI_THREADED */

#ifdef IPV6_SUPPORTED 
   if (type == CM_NETADDR_IPV6)
      icmpUsers = &hiCb.icmp6Users;
   else
#endif /* IPV6_SUPPORTED */
      icmpUsers = &hiCb.icmpUsers;

#ifdef HI_MULTI_THREADED     
   /* Lock the hash list */
#ifdef IPV6_SUPPORTED 
   if (type == CM_NETADDR_IPV6)
      hlLockId = &hiCb.icmp6HlLock;
   else
#endif /* IPV6_SUPPORTED */
      hlLockId = &hiCb.icmpHlLock;

   HI_LOCK(hlLockId, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI225, (ErrVal) ret, 0,
                    "hiCloseIcmpSock () : Unable to lock icmp user lock \n");
      RETVALUE(RFAILED);
   }
#endif /* HI_MULTI_THREADED */  

   if (*icmpUsers != 0)
      *icmpUsers -= 1;

#ifdef IPV6_SUPPORTED 
   sendUpdFiltMsg = FALSE;
   if (type == CM_NETADDR_IPV6)
   {
      cmHashListDelete(&hiCb.icmp6HlCp, (PTR) conCb);
      conCb->isInList &= ~(HI_CONCB_IN_ICMP6_LIST);

      /* Update the ICMPv6 filter if necessary */
      if (conCb->icmp6Mask & (ALL_ICMP_MSG))
      {
         for (numIcmp6Filt = 0; numIcmp6Filt < CM_MAX_ICMP_ERROR; 
              numIcmp6Filt++)
         {
            hiCb.icmp6FiltArr[numIcmp6Filt] -= 1;
            if (hiCb.icmp6FiltArr[numIcmp6Filt] == 0)
            {
               icmpFltIdx = numIcmp6Filt;
               CM_INET_ICMP6_FILTER_SETBLOCK(icmpFltIdx, hiCb.icmp6Filter);
               sendUpdFiltMsg = TRUE;
            }
         }
      }
      else
      {
         for (numIcmp6Filt = 0; numIcmp6Filt < conCb->numFilters; 
              numIcmp6Filt++)
         {
            icmpFltIdx = conCb->icmpError[numIcmp6Filt].errType;
            hiCb.icmp6FiltArr[icmpFltIdx] -= 1;
            if (hiCb.icmp6FiltArr[icmpFltIdx] == 0)
            {
               CM_INET_ICMP6_FILTER_SETBLOCK(icmpFltIdx, hiCb.icmp6Filter);
               sendUpdFiltMsg = TRUE;
            }
         }
      }
   }
   else
#endif /* IPV6_SUPPORTED */
   {
      cmHashListDelete(&hiCb.icmpHlCp, (PTR) conCb);
      conCb->isInList &= ~(HI_CONCB_IN_ICMP_LIST);
   }

#ifdef IPV6_SUPPORTED
   if (sendUpdFiltMsg)
   {
#ifdef HI_MULTI_THREADED
      msg.msgType = HI_UPDICMP6_FILTER;
      ret = hiSendRecvThrMsg(0, &msg); 
#else
      hiUpdIcmp6Filter();
#endif /* HI_MULTI_THREADED */
   }
#endif /* IPV6_SUPPORTED */

   if (*icmpUsers == 0)
   {
      /* Clear the icmp socket from the file descriptor set */
#ifdef HI_MULTI_THREADED
#ifdef IPV6_SUPPORTED
      if (type == CM_NETADDR_IPV6)
         msg.msgType = HI_DELICMP6_SOCK;
      else
#endif /* IPV6_SUPPORTED */
         msg.msgType = HI_DELICMP_SOCK;
      hiSendRecvThrMsg(0, &msg);
#else
#ifdef IPV6_SUPPORTED
      if (type == CM_NETADDR_IPV6)
      {
         /* Add the icmp File descriptor to the file descriptor group */
         CM_INET_FD_CLR(&(hiCb.icmp6ConFd),
                  &(hiCb.hiFdGrpInfoLstPtr[0]->grpCb.readFdSet));
         hiCb.hiFdGrpInfoLstPtr[0]->procIcmp6 = FALSE;
         HI_CLOSE_SOCKET(&hiCb.icmp6ConFd);
      }
      else
#endif /* IPV6_SUPPORTED */
      {  
         CM_INET_FD_CLR(&(hiCb.icmpConFd),
                  &(hiCb.hiFdGrpInfoLstPtr[0]->grpCb.readFdSet));
         hiCb.hiFdGrpInfoLstPtr[0]->procIcmp = FALSE;
         HI_CLOSE_SOCKET(&hiCb.icmpConFd);
      }
#endif /* HI_MULTI_THREADED */
   }

#ifdef HI_MULTI_THREADED
   HI_UNLOCK(hlLockId, alInfo, ret);
   if (ret != ROK)
      HILOGERROR_DEBUG(EHI226, (ErrVal) ret, 0,
         "hiCloseIcmpSock : Unable to unlock the icmp users lock \n");
#endif /* HI_MULTI_THREADED */
   
   RETVALUE(ROK);
} /* end of hiCloseIcmpSock */

#ifdef HI_MULTI_THREADED

/*
*
*       Fun:   hiChkAndCloseIcmpSock
*
*       Desc:  This function is used to close an Icmp socket if the number
*              of users is zero. 
*              
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void hiChkAndCloseIcmpSock 
(
HiConCb  *conCb
)
#else
PUBLIC Void hiChkAndCloseIcmpSock(conCb)
HiConCb  *conCb;
#endif
{

#ifdef IPV6_SUPPORTED
   if ((conCb->icmpMask) || (conCb->protocol == CM_PROTOCOL_ICMP) ||
       (conCb->icmp6Mask))
#else
   if ((conCb->icmpMask) || (conCb->protocol == CM_PROTOCOL_ICMP))
#endif /* IPV6_SUPPORTED */
   {
#ifdef IPV6_SUPPORTED
      if (conCb->icmp6Mask)
         hiCloseIcmpSock(conCb, CM_NETADDR_IPV6);
      else
         hiCloseIcmpSock(conCb, CM_NETADDR_IPV4);          
      conCb->icmpMask = 0;
      conCb->icmp6Mask = 0;
#else
      hiCloseIcmpSock(conCb, CM_NETADDR_IPV4);           
      conCb->icmpMask = 0;
#endif /* IPV6_SUPPORTED */
      
      if (conCb->numFilters)
         HI_FREE((conCb->numFilters * sizeof(CmIcmpError)), conCb->icmpError);
   }

   RETVOID;

} /* end of hiChkAndCloseIcmp */


/*
*
*       Fun:   hiAddIcmpConFd
*
*       Desc:  This function is used to add a icmp conFd to the readFdSet. 
*              This is invoked in the context of a receive thread.
*              
*       Ret:   Void 
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void hiAddIcmpConFd
(
HiFdGrpInfo *grpInfoPtr,
U8          type
)
#else
PUBLIC Void hiAddIcmpConFd(grpInfoPtr, type)
HiFdGrpInfo *grpInfoPtr;
U8          type;
#endif
{
   S16         ret;
   HiAlarmInfo alInfo;
   SLockId     *hlLockId;
   U8          *icmpUsers;

   alInfo.spId = -1;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
  
#ifdef IPV6_SUPPORTED 
   if (type == CM_INET_IPV6ADDR_TYPE)
   {
      hlLockId = &hiCb.icmp6HlLock;
      icmpUsers = &hiCb.icmp6Users;
   }
   else
#endif /* IPV6_SUPPORTED */
   {
      hlLockId = &hiCb.icmpHlLock;
      icmpUsers = &hiCb.icmpUsers;
   }

   /* Lock the icmp user lock */
   HI_LOCK(hlLockId, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI227, (ErrVal) ret, 0,
                    "hiAddIcmpConFd () : Unable to lock icmp user lock \n");
      RETVOID;
   }

   /* The icmp users should be non zero and the icmpFdBlk and thisInst 
    * should match */
   if (*icmpUsers != 0) 
   {
#ifdef IPV6_SUPPORTED 
      if (type == CM_INET_IPV6ADDR_TYPE)
      {
         CM_INET_FD_SET(&hiCb.icmp6ConFd, &grpInfoPtr->grpCb.readFdSet);
         cmMemcpy((U8 *)&grpInfoPtr->icmp6ConFd, (U8 *)&hiCb.icmp6ConFd, 
                   sizeof(CmInetFd));
         grpInfoPtr->procIcmp6 = TRUE;
      }
      else
#endif /* IPV6_SUPPORTED */
      {
         CM_INET_FD_SET(&hiCb.icmpConFd, &grpInfoPtr->grpCb.readFdSet);
         cmMemcpy((U8 *)&grpInfoPtr->icmpConFd, (U8 *)&hiCb.icmpConFd, 
                   sizeof(CmInetFd));
         grpInfoPtr->procIcmp = TRUE;
      }
   }

   /* Unlock the icmp user lock */
   HI_UNLOCK(hlLockId, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI228, (ErrVal) ret, 0,
         "hiOpenIcmpSock : Unable to unlock the icmp users lock \n");
      RETVOID;
   }
   
   RETVOID;

} /* end of hiAddIcmpConFd */


/*
*
*       Fun:   hiDelIcmpConFd
*
*       Desc:  This function is used to delete a icmp conFd. 
*              
*       Ret:   Void 
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void hiDelIcmpConFd
(
HiFdGrpInfo *grpInfoPtr,
U8          type
)
#else
PUBLIC Void hiDelIcmpConFd(grpInfoPtr, type)
HiFdGrpInfo *grpInfoPtr;
U8          type;
#endif
{
#ifdef IPV6_SUPPORTED 
   if (type == CM_INET_IPV6ADDR_TYPE)
   {
      if (grpInfoPtr->procIcmp6)
         CM_INET_FD_CLR(&grpInfoPtr->icmp6ConFd, &grpInfoPtr->grpCb.readFdSet);
      HI_CLOSE_SOCKET(&grpInfoPtr->icmp6ConFd);
      grpInfoPtr->procIcmp6 = FALSE;
   }
   else 
#endif /* IPV6_SUPPORTED */
   {
      if (grpInfoPtr->procIcmp)
         CM_INET_FD_CLR(&grpInfoPtr->icmpConFd, &grpInfoPtr->grpCb.readFdSet);
      HI_CLOSE_SOCKET(&grpInfoPtr->icmpConFd);
      grpInfoPtr->procIcmp = FALSE;
   }

   RETVOID;

} /* end if hiDelIcmpConFd */
#endif /* HI_MULTI_THREADED */

#ifdef IPV6_SUPPORTED

/*
*
*       Fun:   hiUpdIcmp6Filter
*
*       Desc:  This function is used to update the icmp filter. 
*              
*       Ret:   Void 
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiUpdIcmp6Filter
(
Void
)
#else
PUBLIC S16 hiUpdIcmp6Filter()
#endif
{
   HiAlarmInfo alInfo;
   S16         ret, retVal;
   HiConCb     *conCb, *prevConCb;
   HiSap       *sap;

   /* Initialisations */
   alInfo.spId = -1; /* the ICMP conFd is not associated with any 
                      * particular SAP */
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
   retVal = ROK;

#ifdef HI_MULTI_THREADED
   HI_LOCK(&hiCb.icmp6HlLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI229, (ErrVal) ret, 0,
                 "hiUpdIcmp6Filter() : Unable to lock icmp user lock \n");
      RETVALUE(RFAILED);
   }

   ret = cmInetSetOpt(&hiCb.icmp6ConFd,
                      CM_INET_PROTO_ICMPV6, CM_INET_OPT_ICMP6_FILTER, 
                      &hiCb.icmp6Filter);
#else 
   /* hi012.104 - change to hiCb.icmp6ConFd */
   ret = cmInetSetOpt(&hiCb.icmp6ConFd,
                      CM_INET_PROTO_ICMPV6, CM_INET_OPT_ICMP6_FILTER, 
                      &hiCb.icmp6Filter);
#endif /* HI_MULTI_THREADED */

   if (ret != ROK)
   {
      conCb = prevConCb = NULLP;
      while ((ret = cmHashListGetNext(&hiCb.icmp6HlCp,
                                     (PTR) prevConCb, (PTR *)&conCb)) == ROK)
      {
         sap = conCb->sap;
#ifdef HI_MULTI_THREADED
         conCb->reason = HI_SOCK_ICMP_RECV_ERR;
         hiSendIntDiscInd(sap, HI_PROVIDER_CON_ID, conCb->spConId, 
                          HI_SOCK_ICMP_RECV_ERR, 0);
#else
         HI_DISCIND(sap, HI_USER_CON_ID, conCb->suConId, 
                    HI_SOCK_ICMP_RECV_ERR);
         hiFreeConCb(conCb);
#endif /* HI_MULTI_THREADED */
         prevConCb = conCb;
      }
      retVal = RFAILED;
   }

#ifdef HI_MULTI_THREADED
   HI_UNLOCK(&hiCb.icmp6HlLock, alInfo, ret);
   if (ret != ROK)
      HILOGERROR_DEBUG( EHI230, (ErrVal) ret, 0,
                       "hiRecvIcmpMsg() : Unable to unlock icmp user lock \n");
#endif /* HI_MULTI_THREADED */

   RETVALUE(retVal);

} /* end if hiUpdIcmp6Filter */
#endif /* IPV6_SUPPORTED */


/*
*
*       Fun:   hiHndlUdpData
*
*       Desc:  This function processes the UDP datagram received from
*              the other side. It takes care of the cases when a single TPKT
*              packet is received or when multiple TPKTs are received in a 
*              single datagram. A TPKT packet cannot arrive in more than
*              one datagram. Each TPKT packet is given as a UDP data
*              indication to the upper layer. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC Void hiHndlUdpData
(
HiConCb *conCb,          /* pointer to the connection block */
Buffer *mBuf,            /* buffer returned from cmInetRecv call */
CmTptAddr *destAddr,     /* pointer to destination address */
CmIpHdrParm *ipHdrParm,  /* pointer to IP header parameter */
CmTptAddr *srcAddr,      /* pointer to source address */
/* hi009.104 - added new argument localIf */
#ifdef LOCAL_INTF
CmTptLocalInf *localIf,  /* local intf on which pkt arrived */
#endif
MsgLen    len            /* length of the message read */
)
#else /* ANSI */
/* hi009.104 - added new argument localIf */
#ifdef LOCAL_INTF
PUBLIC Void hiHndlUdpData(conCb, mBuf, destAddr, ipHdrParm,
                          srcAddr, localIf, len)
HiConCb *conCb;          /* pointer to the connection block */
Buffer *mBuf;            /* buffer returned from cmInetRecv call */
CmTptAddr *destAddr;     /* pointer to destination address */
CmIpHdrParm *ipHdrParm;  /* pointer to IP header parameter */
CmTptAddr *srcAddr;      /* pointer to source address */
CmTptLocalInf *localIf;  /* local intf on which pkt arrived */
MsgLen    len;           /* length of the message read */
#else
PUBLIC Void hiHndlUdpData(conCb, mBuf, destAddr, ipHdrParm, srcAddr, len)
HiConCb *conCb;          /* pointer to the connection block */
Buffer *mBuf;            /* buffer returned from cmInetRecv call */
CmTptAddr *destAddr;     /* pointer to destination address */
CmIpHdrParm *ipHdrParm;  /* pointer to IP header parameter */
CmTptAddr *srcAddr;      /* pointer to source address */
MsgLen    len;           /* length of the message read */
#endif
#endif /* ANSI */
{

   Queue       rxQ;
   QLen        qLen;
   Buffer      *tmpBuf;
   Mem         mem;
   HiAlarmInfo info;
   Bool        flag;
   S16         ret;

   TRC2(hiHndlUdpData) 
   
   /* Variable initializations */
   flag    = TRUE;
   mem.region = conCb->sap->uiPst.region;
   mem.pool   = conCb->sap->uiPst.pool;

   /* Initialize alarm info structure */
   info.spId = conCb->sap->spId;
   info.type = LHI_ALARMINFO_TYPE_NTPRSNT;
   
   ret = SInitQueue(&rxQ);
   if(ret != ROK)
   {
      /* deallocate the received buffer */
      SPutMsg(mBuf);

      RETVOID;
   }

   while(flag)
   {
      conCb->rxLen = len;

      /* initialize the received length parameter */
      if(hiProcRxHdr(conCb, mBuf) != ROK)
      {
         /* Message is deallocated in function */
         break;
      }

      /* case of receiving ONE FULL TPKT */
      if(conCb->pendLen == conCb->rxLen)
      {
         /* Initialize rxLen and pendLen */
         conCb->pendLen = conCb->rxLen = 0;
         (Void)SQueueLast(mBuf, &rxQ);
         break;
      }
      else if ((conCb->awaitHdr) ||
               (conCb->pendLen > conCb->rxLen))
      {
         /* deallocate the received buffer */
         SPutMsg(mBuf);
         
         /* Full header or full message not come. */

         /* Incase of UDP this is an error */
         hiSendAlarm(LCM_CATEGORY_PROTOCOL, LCM_EVENT_PI_INV_EVT,
                     LCM_CAUSE_DECODE_ERR, &info); 
         /* This is treated as a decode error. */
         break;
      }
      else
      {
         /* more than one packets have come */
         HIDBGP(DBGMASK_SI, (hiCb.hiInit.prntBuf,
                "SSegMsg(mBuf1(%p), idx(%ld), mBuf2(%p))\n", 
                 mBuf, conCb->pendLen, &tmpBuf));

         /* Segment the message */
         ret = SSegMsg(mBuf, (U16)conCb->pendLen, &tmpBuf);
         if(ret !=ROK)
         {
            /* deallocate the received buffer */
            SPutMsg(mBuf);

            /* raise an alarm to the Layer Manager */
            HI_FILL_ALARMINFO_MEM_ID(info, mem.region, mem.pool);
            hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                        LCM_CAUSE_UNKNOWN, &info); 
            break;
         }

         /* queue up the complete TPKT */
         (Void)SQueueLast(mBuf, &rxQ);

         /* initialize variables for next iteration */
         len = len - conCb->pendLen;
         conCb->pendLen = 0;           

         /* put the next TPKT in mBuf */
         mBuf = tmpBuf;
          
         if(!len)
            flag = FALSE;
      }/* end else */
   }/* end while */

   (Void)SFndLenQueue(&rxQ, &qLen);
   while(qLen)
   {
      (Void)SDequeueFirst(&tmpBuf, &rxQ);

      qLen--;

      if(!conCb->toBeDel)
      {
#ifdef H323_PERF
         TAKE_TIMESTAMP("L/T Rcvd TCP Pkt on UDP, in HI");
#endif /* H323_PERF */
        /* issue a data indication to the upper layer*/
        /* hi009.104 - added new argument localIf */
#ifdef HI_MULTI_THREADED        
        HiUiHitUDatInd(&conCb->sap->uiUDatIndPst, conCb->sap->suId, 
                       conCb->suConId, srcAddr, destAddr, ipHdrParm, 
#ifdef LOCAL_INTF                       
                       localIf, 
#endif /* LOCAL_INTF */                       
                       tmpBuf); 
#else
        /* hi009.104 - added new argument localIf */
        HiUiHitUDatInd(&conCb->sap->uiPst, conCb->sap->suId, 
                       conCb->suConId, srcAddr, destAddr, ipHdrParm,
#ifdef LOCAL_INTF                       
                       localIf, 
#endif /* LOCAL_INTF */                        
                       tmpBuf);
 
#endif /* HI_MULTI_THREADED */
      }
      else
         (Void)SPutMsg(tmpBuf);
   }/* end while */

   (Void)SFlushQueue(&rxQ);

   RETVOID; 
}/* end of hiHndlUdpData () */


/*
*
*       Fun:   hiHndlRawMsg
*
*       Desc:  This function is executed when raw ipv4 data received 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy3.c
*
*/
 
#ifdef ANSI
PUBLIC S16  hiHndlRawMsg
(
HiConCb *conCb,         /* pointer to the connection block */
Buffer *mBuf,           /* buffer returned from cmInetRecv call */
/* hi009.104 - added new argument localIf */
#ifdef LOCAL_INTF 
CmTptLocalInf *localIf, /* local intf on which pkt arrived */
#endif /* LOCAL_INTF */
U32 len                 /* actual length of the data received */
)
#else
#ifdef LOCAL_INTF
PUBLIC S16  hiHndlRawMsg(conCb, mBuf, localIf, len) 
HiConCb *conCb;         /* pointer to the connection block */
Buffer *mBuf;           /* buffer returned from cmInetRecv call */
/* hi009.104 - added new argument localIf */
CmTptLocalInf *localIf; /* local intf on which pkt arrived */
U32 len;                /* actual length of the data received */
#else
PUBLIC S16  hiHndlRawMsg(conCb, mBuf, len) 
HiConCb *conCb;         /* pointer to the connection block */
Buffer *mBuf;           /* buffer returned from cmInetRecv call */
U32 len;                /* actual length of the data received */
#endif /* LOCAL_INTF */
#endif
{
  
   HiSap        *sap;
   S16          ret;
   CmIpv4Hdr    ipHdr;
   CmIpHdrParm  ipHdrParm;
   CmTptAddr    srcAddr;   
   CmTptAddr    destAddr;  
   UConnId      suConId; 

   TRC2(hiHndlRawMsg)  
   
   /* Variable initializations */
   sap     = conCb->sap;
   suConId = conCb->suConId;

   /* hi028.104 - make len unused */
   UNUSED(len);

   cmMemset((U8 *)&ipHdrParm, 0, sizeof(CmIpHdrParm));
   cmMemset((U8 *)&ipHdr, 0, sizeof(CmIpv4Hdr));

   /* hi009.104 - changed for ipv4 options */
   /* If this is a Raw packet then this must contain IP header */
#ifdef IPV4_OPTS_SUPPORTED   
   ret = hiUnpkIpv4Hdr(&ipHdr, mBuf, &ipHdrParm);
#else
   ret = hiUnpkIpv4Hdr(&ipHdr, mBuf);
#endif   

#if (ERRCLASS & ERRCLS_DEBUG)
   if(ret != ROK)
   {
      /* Discard the received data */
      (Void)SPutMsg(mBuf);

      HILOGERROR_DEBUG(EHI231, (ErrVal)ret, 0,
                 "hiHndlRawMsg(): Error in Extracting  IP Header");

      RETVALUE(RFAILED);

   }
#endif /* ERRCLS_DEBUG */
   
   ipHdrParm.type = CM_HDRPARM_IPV4;

   ipHdrParm.u.hdrParmIpv4.proto.pres = TRUE;
   ipHdrParm.u.hdrParmIpv4.proto.val  = ipHdr.proto;
   
   if(ipHdr.off & CM_DF_MASK)
   {
      ipHdrParm.u.hdrParmIpv4.dfBit.pres = TRUE;
      ipHdrParm.u.hdrParmIpv4.dfBit.val = 1;
   }
   else 
      ipHdrParm.u.hdrParmIpv4.dfBit.pres = FALSE;

   ipHdrParm.u.hdrParmIpv4.tos.pres   = TRUE;
   ipHdrParm.u.hdrParmIpv4.tos.val    = ipHdr.tos;

   ipHdrParm.u.hdrParmIpv4.ttl.pres   = TRUE; 
   ipHdrParm.u.hdrParmIpv4.ttl.val    = ipHdr.ttl;

   srcAddr.type =  CM_TPTADDR_IPV4;
   destAddr.type =  CM_TPTADDR_IPV4;

   /* Ports are not relevant in RAW socket */
   srcAddr.u.ipv4TptAddr.port  = 0;  
   destAddr.u.ipv4TptAddr.port = 0; 

   srcAddr.u.ipv4TptAddr.address  = ipHdr.srcAddr;
   destAddr.u.ipv4TptAddr.address = ipHdr.destAddr;
   
   /* hi009.104 - added new argument localIf */
   /* Send a Unit Data Indication to the service user */
#ifdef HI_MULTI_THREADED
   HiUiHitUDatInd(&sap->uiUDatIndPst, sap->suId, suConId, 
                  &srcAddr, &destAddr, &ipHdrParm, 
#ifdef LOCAL_INTF                  
                  localIf, 
#endif                  
                  mBuf);
  
#else
   /* hi009.104 - added new argument localIf */
   HiUiHitUDatInd(&sap->uiPst, sap->suId, suConId, 
                  &srcAddr, &destAddr, &ipHdrParm, 
#ifdef LOCAL_INTF                  
                  localIf, 
#endif                  
                  mBuf);  
#endif /* HI_MULTI_THREADED */

   RETVALUE(ROK);

} /* hiHndlRawMsg */

#ifdef IPV6_SUPPORTED
/*
*
*       Fun:   hiHndlIpv6RawMsg
*
*       Desc:  This function is executed to receive an IPV6 raw message.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy3.c
*
*/
 
#ifdef ANSI
PUBLIC S16  hiHndlIpv6RawMsg
(
HiConCb *conCb,         /* pointer to the connection block */
Buffer *mBuf,           /* buffer returned from cmInetRecv call */
U32 len,                /* actual length of the data received */
/* hi009.104 - added new argument localIf */
#ifdef LOCAL_INTF
CmTptLocalInf *localIf, /* local intf on which pkt arrived */
#endif /* LOCAL_INTF */
CmIpHdrParm  *ipHdrParm /* IPv6 Header Parameters */
)
#else
#ifdef LOCAL_INTF
PUBLIC S16  hiHndlIpv6RawMsg(conCb, mBuf, len, localIf, ipHdrParm) 
HiConCb *conCb;         /* pointer to the connection block */
Buffer *mBuf;           /* buffer returned from cmInetRecv call */
U32 len;                /* actual length of the data received */
/* hi009.104 - added new argument localIf */
CmTptLocalInf *localIf;/* local intf on which pkt arrived */
CmIpHdrParm  *ipHdrParm;/* IPv6 Header Parameters */
#else
PUBLIC S16  hiHndlIpv6RawMsg(conCb, mBuf, len, ipHdrParm) 
HiConCb *conCb;         /* pointer to the connection block */
Buffer *mBuf;           /* buffer returned from cmInetRecv call */
U32 len;                /* actual length of the data received */
CmIpHdrParm  *ipHdrParm;/* IPv6 Header Parameters */
#endif /* LOCAL_INTF */
#endif
{

   HiSap        *sap;
   CmTptAddr    srcAddr;   
   CmTptAddr    destAddr;  
   UConnId      suConId; 



   TRC2(hiHndlRawMsg)  
   
   /* hi021.104 - make len unused */
   UNUSED(len);
   /* Variable initializations */
   sap     = conCb->sap;
   suConId = conCb->suConId;
   
   srcAddr.type =  CM_TPTADDR_IPV6;
   destAddr.type =  CM_TPTADDR_IPV6;

   /* Send a Unit Data Indication to the service user. ipHdrParm will have 
    * values received inside cmInetRecvMsg func by recvmsg system call */
   /* hi009.104 - added new argument localIf */
#ifdef HI_MULTI_THREADED
   HiUiHitUDatInd(&sap->uiUDatIndPst, sap->suId, suConId, 
                &conCb->peerAddr, &conCb->locTptAddr, ipHdrParm, 
#ifdef LOCAL_INTF                
                localIf, 
#endif                
                mBuf);
#else
   /* hi009.104 - added new argument localIf */
   HiUiHitUDatInd(&sap->uiPst, sap->suId, suConId, 
                &conCb->peerAddr, &conCb->locTptAddr, ipHdrParm, 
#ifdef LOCAL_INTF                
                localIf, 
#endif                
                mBuf);
#endif /* HI_MULTI_THREADED */
   
   RETVALUE(ROK);
} /* end of hiHndlIpv6RawMsg */
#endif /* IPV6_SUPPORTED */


/*
*
*       Fun:   hiRecvIcmpMsg
*
*       Desc:  This function is called to receive ICMP messages. 
*
*       Ret:   ROK:        OK
*              ROUTRES:    Failed, Out of resources
*              RIGNORE:    Failed, Ignore
*              RFAILED:    Failed
*
*       Notes: None 
*
*       File:  hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16  hiRecvIcmpMsg
(
)
#else
PUBLIC S16  hiRecvIcmpMsg() 
#endif
{
   MsgLen            len;       /* length to read */
   Buffer            *mBuf;     /* message buffer */
   Buffer            *sndmBuf;  /* message buffer */
   CmTptAddr         srcAddr;   /* source address */
   CmInetMemInfo     info;      /* region and pool */
   HiAlarmInfo       alInfo;    /* alarm information */
   HiSap             *sap;      /* sap pointer */
   Reason            reason;    /* reason */
   S16               ret;       /* return value from the function */
   CmTptAddr         destAddr;  /* destination transport Address */
   CmIpHdrParm       ipHdrParm; /* Header parameter Buffer */
   CmIcmpv4Hdr       icmpHdr;   /* Icmp header pointer */
   CmIpv4Hdr         ipv4Hdr;   /* IP header pointer */
   U8                msgType;   /* Type of ICMP message */
   U8                msgCode;   /* Code of ICMP message */
   U8                protocol;  /* Protocol value */
   U16               idx;       /* Index */
   MsgLen            count;
   HiConCb           *conCb,*prevConCb; 
                               /* pointer to the connection block */
   Bool              sendflag;  /* Boolean flag for sending messages */
   Mem               mem;

   /* hi009.104 - added new local varible */
#ifdef LOCAL_INTF
   CmTptLocalInf    localIf; /* local interface on which pkt was recvd */
#endif /* LOCAL_INTF */

   TRC2(hiRecvIcmpMsg)

   len = 0;
   
   /* Initialize alarm info structure */
   alInfo.spId = -1; /* the ICMP conFd is not associated with any 
                      * particular SAP */
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   info.region = hiCb.hiInit.region;
   info.pool   = hiCb.hiInit.pool;

   prevConCb = conCb = NULLP;

   /* hi009.104 - fill with all 0's */
#ifdef LOCAL_INTF
   HI_ZERO(&localIf, sizeof(CmTptLocalInf)); 
#endif /* LOCAL_INTF */
   
   /* read the available data on this socket */
   len = CM_INET_READ_ANY;

   /* read the available data */ /* mmh: intf ; pass last arg NULLP for icmp */
#ifndef HI_MULTI_THREADED
#ifdef IPV6_SUPPORTED
   /* hi009.104 - added 2 new arguments */
   ret = cmInetRecvMsg(&hiCb.icmpConFd, 
                       (CmInetAddr *)&srcAddr, &info, &mBuf, &len, 
#ifdef IPV6_OPTS_SUPPORTED                       
                       NULLP, 
#endif
#ifdef LOCAL_INTF                       
                       NULLP,
#endif                       
                       CM_INET_NO_FLAG);
#else
   /* hi009.104 - added new argument */
   ret = cmInetRecvMsg(&hiCb.icmpConFd, 
                       &(srcAddr.u.ipv4TptAddr), &info, 
                       &mBuf, &len, 
#ifdef LOCAL_INTF                       
                       NULLP,
#endif                       
                       CM_INET_NO_FLAG);
#endif /* IPV6_SUPPORTED */
   
#else
   
#ifdef IPV6_SUPPORTED
   /* hi009.104 - added 2 new arguments */
   ret = cmInetRecvMsg(&hiCb.hiFdGrpInfoLstPtr[0]->icmpConFd, 
                       (CmInetAddr *)&srcAddr, &info, &mBuf, &len, 
#ifdef IPV6_OPTS_SUPPORTED                       
                       NULLP, 
#endif
#ifdef LOCAL_INTF                       
                       NULLP,
#endif                       
                       CM_INET_NO_FLAG);
#else
   /* hi009.104 - added new argument */
   ret = cmInetRecvMsg(&hiCb.hiFdGrpInfoLstPtr[0]->icmpConFd, 
                       &(srcAddr.u.ipv4TptAddr), &info, 
                       &mBuf, &len,
#ifdef LOCAL_INTF                       
                       NULLP,
#endif                       
                       CM_INET_NO_FLAG);
#endif /* IPV6_SUPPORTED */
#endif /* HI_MULTI_THREADED */

   if (ret != ROK)
   {
      if(ret == ROUTRES)
      {
#ifdef HI_MULTI_THREADED 
         HI_LOCK(&hiCb.errStsLock, alInfo, ret); 
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI232, (ErrVal) 0, 0, 
                  "hiRecvIcmpMsg() : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */

         hiCb.errSts.sockRxErr++; 
        
#ifdef HI_MULTI_THREADED 
         HI_UNLOCK(&hiCb.errStsLock, alInfo, ret); 
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI233, (ErrVal) 0, 0, 
                  "hiRecvIcmpMsg() : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */

         reason = HI_OUTOF_RES;

         alInfo.type = LHI_ALARMINFO_MEM_ID;

         /* fill up the alarm information */
         HI_FILL_ALARMINFO_MEM_ID(alInfo, info.region, info.pool);
         hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                     LHI_CAUSE_SOCK_RECV_ERR, &alInfo);

         reason = HI_OUTOF_RES; 
      }
      else
      {
#ifdef HI_MULTI_THREADED 
         HI_LOCK(&hiCb.errStsLock, alInfo, ret); 
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI234, (ErrVal) 0, 0, 
                  "hiRecvIcmpMsg() : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */

         hiCb.errSts.sockRxErr++; 

#ifdef HI_MULTI_THREADED 
         HI_UNLOCK(&hiCb.errStsLock, alInfo, ret); 
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI235, (ErrVal) 0, 0, 
                  "hiRecvIcmpMsg() : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */

         reason = HI_SOCK_ICMP_RECV_ERR;
         hiSendAlarm(LCM_CATEGORY_INTERNAL, LHI_EVENT_INET_ERR,
                     LHI_CAUSE_SOCK_RECV_ERR, &alInfo);
      }

#ifdef HI_MULTI_THREADED
      /* Lock the ICMP hashlist */
      HI_LOCK(&hiCb.icmpHlLock, alInfo, ret);
      if (ret != ROK)
      {
         HILOGERROR_DEBUG( EHI236, (ErrVal) ret, 0,
                    "hiRecvIcmpMsg() : Unable to lock icmp user lock \n");
         RETVALUE(RFAILED);
      }
#endif /* HI_MULTI_THREADED */

      /* hi014.104: using NULLP in cmHashListGetNext */
      while((ret = cmHashListGetNext(&hiCb.icmpHlCp, 
                           (PTR) NULLP, (PTR *) &conCb)) == ROK)
      {
         sap = conCb->sap;
#ifdef HI_MULTI_THREADED
         conCb->reason = reason;
         hiSendIntDiscInd(sap, HI_PROVIDER_CON_ID, conCb->spConId, 
                          HI_SOCK_ICMP_RECV_ERR, 0);
#else
         HI_DISCIND(sap, HI_USER_CON_ID, conCb->suConId, reason);
         hiFreeConCb(conCb);
#endif /* HI_MULTI_THREADED */
      }

#ifdef HI_MULTI_THREADED
      HI_UNLOCK(&hiCb.icmpHlLock, alInfo, ret);
      if (ret != ROK)
         HILOGERROR_DEBUG( EHI237, (ErrVal) ret, 0,
                    "hiRecvIcmpMsg() : Unable to unlock icmp user lock \n");
#endif /* HI_MULTI_THREADED */

      RETVALUE(RFAILED);
   }

   /* Increment the statistics counters */
   hiCb.hiFdGrpInfoLstPtr[0]->grpCb.genRxSts.numRxbytes += len;
  
   srcAddr.type = CM_TPTADDR_IPV4;
   
   /* hi009.104 - changed for ipv4 options */ 
#ifdef IPV4_OPTS_SUPPORTED   
   ret = hiUnpkIpv4Hdr(&ipv4Hdr, mBuf, &ipHdrParm);
#else
   ret = hiUnpkIpv4Hdr(&ipv4Hdr, mBuf);
#endif   

#if (ERRCLASS & ERRCLS_DEBUG)
   if(ret != ROK)
   {
      /* Discard the received data */
      (Void)SPutMsg(mBuf);
      HILOGERROR_DEBUG(EHI238, (ErrVal) ret, 0,
                 "hiRecvIcmpMsg(): Error in Extracting  IP Header");

      RETVALUE(RIGNORE);
   }
#endif /* ERRCLS_DEBUG */

   ipHdrParm.type = CM_HDRPARM_IPV4;
   
   ipHdrParm.u.hdrParmIpv4.proto.pres = TRUE;
   ipHdrParm.u.hdrParmIpv4.proto.val  = ipv4Hdr.proto;

   if(ipv4Hdr.off & CM_DF_MASK)
      ipHdrParm.u.hdrParmIpv4.dfBit.pres = TRUE;
   else 
      ipHdrParm.u.hdrParmIpv4.dfBit.pres = FALSE;

   ipHdrParm.u.hdrParmIpv4.tos.pres   = TRUE;
   ipHdrParm.u.hdrParmIpv4.tos.val    = ipv4Hdr.tos;
   ipHdrParm.u.hdrParmIpv4.ttl.pres   = TRUE; 
   ipHdrParm.u.hdrParmIpv4.ttl.val    = ipv4Hdr.ttl;
  
   (Void)SCpyMsgFix(mBuf, 0, sizeof(CmIcmpv4Hdr), (Data *)&icmpHdr, 
                    &count);

   msgType = icmpHdr.icmpType;
   msgCode = icmpHdr.icmpCode;
   protocol = icmpHdr.u3.icmpIpHdr.proto;
   
   srcAddr.type =  CM_TPTADDR_IPV4;
   destAddr.type =  CM_TPTADDR_IPV4;

   srcAddr.u.ipv4TptAddr.port = 0;  /* Port is not relevant in RAW socket */
   destAddr.u.ipv4TptAddr.port = 0; /* Port is not relevant in RAW socket */

   srcAddr.u.ipv4TptAddr.address = ipv4Hdr.srcAddr;
   destAddr.u.ipv4TptAddr.address = ipv4Hdr.destAddr;

#ifdef HI_MULTI_THREADED
   /* Lock the ICMP hashlist */
   HI_LOCK(&hiCb.icmpHlLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI239, (ErrVal) ret, 0,
                 "hiRecvIcmpMsg() : Unable to lock icmp user lock \n");
      (Void)SPutMsg(mBuf);
      RETVALUE(RFAILED);
   }
#endif /* HI_MULTI_THREADED */

   while((ret = cmHashListGetNext(&hiCb.icmpHlCp, 
           (PTR) prevConCb, (PTR *) &conCb) == ROK))
   {
      sendflag = FALSE;
      prevConCb = conCb;
      sap = conCb->sap;

      /* If connnection is not intrested in listening to ICMP message 
       * then just skip */
      if (conCb->icmpMask == 0)
      {
         continue;
      }
   
#ifdef HI_MULTI_THREADED 
      if (conCb->sendConCfm)
         continue;
#endif /* HI_MULTI_THREADED */

      /* Connections wants to listen to ICMP messages */
      if(conCb->conState != HI_ST_CONNECTED)
         continue;

      if(conCb->icmpMask & ALL_ICMP_MSG)
         sendflag = TRUE;
      else if (conCb->icmpMask & ALL_PROTO_SPEC_MSG)
      {
         if (protocol == conCb->filterProtocol)
            sendflag = TRUE;
      }
      else if (conCb->icmpMask & ALL_FLTRD_ICMP_MSG)
      {
         for (idx=0; idx < conCb->numFilters; idx++)
         { 
            if (conCb->icmpError[idx].errType != msgType)
               continue;

            if (conCb->icmpError[idx].errCodeMask & (1 << msgCode))
               sendflag = TRUE;

            break;
         } 
      }
      else if (conCb->icmpMask & FLTRD_PROTO_SPEC_MSG)
      {
         if (protocol == conCb->filterProtocol)
         {
            for (idx=0; idx < conCb->numFilters; idx++)
            {
               if (conCb->icmpError[idx].errType != msgType)
                  continue;
      
               if (conCb->icmpError[idx].errCodeMask & (1 << msgCode))
                  sendflag = TRUE;
               break;
            } 
         }
      }

      if(sendflag == TRUE)
      {
         mem.region = conCb->sap->uiPst.region;
         mem.pool   = conCb->sap->uiPst.pool;

         ret = SAddMsgRef(mBuf, mem.region, mem.pool, &sndmBuf);
         if(ret != ROK)
         { 
            /* we can just skip this */
            continue;
         }
          
         /* Send a Unit Data Indication to the service user */
         /* hi009.104- pass NULLP for localIf in case of icmp */
#ifdef HI_MULTI_THREADED
         HiUiHitUDatInd(&sap->uiUDatIndPst, sap->suId, conCb->suConId, 
                            &srcAddr, &destAddr, &ipHdrParm, 
#ifdef LOCAL_INTF                            
                            &localIf, 
#endif                            
                            sndmBuf);
#else
         HiUiHitUDatInd(&sap->uiPst, sap->suId, conCb->suConId, 
                            &srcAddr, &destAddr, &ipHdrParm, 
#ifdef LOCAL_INTF                            
                            &localIf, 
#endif                            
                            sndmBuf);
#endif /* HI_MULTI_THREADED */
      }  /* end of if sendflag */
   } /* end while loop */

#ifdef HI_MULTI_THREADED
   HI_UNLOCK(&hiCb.icmpHlLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI240, (ErrVal) ret, 0,
         "hiRecvIcmpMsg() : Unable to unlock icmp user lock \n");
      (Void)SPutMsg(mBuf);
      RETVALUE(RFAILED);
   }
#endif /* HI_MULTI_THREADED */

   (Void)SPutMsg(mBuf);

   RETVALUE(ROK);
} /* end of hiRecvIcmpMsg */

#ifdef IPV6_SUPPORTED 

/*
*
*       Fun:   hiRecvIcmp6Msg
*
*       Desc:  This function is called to receive ICMP messages. 
*
*       Ret:   ROK:        OK
*              ROUTRES:    Failed, Out of resources
*              RIGNORE:    Failed, Ignore
*              RFAILED:    Failed
*
*       Notes: None 
*
*       File:  hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16  hiRecvIcmp6Msg
(
)
#else
PUBLIC S16  hiRecvIcmp6Msg() 
#endif
{
   MsgLen            len;       /* length to read */
   Buffer            *mBuf;     /* message buffer */
   Buffer            *sndmBuf;  /* message buffer */
   CmTptAddr         srcAddr;   /* source address */
   CmInetMemInfo     info;      /* region and pool */
   HiAlarmInfo       alInfo;    /* alarm information */
   HiSap             *sap;      /* sap pointer */
   Reason            reason;    /* reason */
   S16               ret;       /* return value from the function */
   CmTptAddr         destAddr;  /* destination transport Address */
   CmIpHdrParm       ipHdrParm; /* Header parameter Buffer */
   CmIcmpv6Hdr       icmp6Hdr;  /* Icmp V6 header pointer */
   U8                msgType;   /* Type of ICMP message */
   U8                msgCode;   /* Code of ICMP message */
   U16               idx;       /* Index */
   MsgLen            count;
   HiConCb           *conCb,*prevConCb; 
                                /* pointer to the connection block */
   Bool              sendflag;  /* Boolean flag for sending messages */
   Mem               mem;

   /* hi009.104 - added new local variable */
#ifdef LOCAL_INTF
   CmTptLocalInf    localIf;    /* local interface on which pkt was recvd */
#endif /* LOCAL_INTF */

   TRC2(hiRecvIcmp6Msg)

   len = 0;
   
   /* Initialize alarm info structure */
   alInfo.spId = -1; /* the ICMP conFd is not associated with any 
                      * particular SAP */
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   info.region = hiCb.hiInit.region;
   info.pool   = hiCb.hiInit.pool;

   prevConCb = conCb = NULLP;

   /* hi009.104 - fill up with all 0's */
#ifdef LOCAL_INTF   
   HI_ZERO(&localIf, sizeof(CmTptLocalInf)); 
#endif /* LOCAL_INTF */   
   
   /* read the available data on this socket */
   len = CM_INET_READ_ANY;

   /* read the available data */

#ifndef HI_MULTI_THREADED
   /* hi009.104 - added 2 new arguments */
   ret = cmInetRecvMsg(&hiCb.icmp6ConFd, 
                       (CmInetAddr *)&srcAddr, &info, &mBuf, &len,
#ifdef IPV6_OPTS_SUPPORTED                       
                       NULLP, 
#endif                       
#ifdef LOCAL_INTF                       
                       NULLP,
#endif                       
                       CM_INET_NO_FLAG);
#else
   /* hi009.104 - added 2 new arguments */
   ret = cmInetRecvMsg(&hiCb.hiFdGrpInfoLstPtr[0]->icmp6ConFd, 
                       (CmInetAddr *)&srcAddr, &info, 
                       &mBuf, &len, 
#ifdef IPV6_OPTS_SUPPORTED                        
                       NULLP, 
#endif
#ifdef LOCAL_INTF                       
                       NULLP,
#endif                       
                       CM_INET_NO_FLAG);
#endif /* HI_MULTI_THREADED */
   if (ret != ROK)
   {
      if(ret == ROUTRES)
      {
#ifdef HI_MULTI_THREADED
         HI_LOCK(&hiCb.errStsLock, alInfo, ret); 
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI241, (ErrVal) 0, 0, 
                  "hiRecvIcm6Msg () : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */
         hiCb.errSts.sockRxErr++;

#ifdef HI_MULTI_THREADED
         HI_UNLOCK(&hiCb.errStsLock, alInfo, ret);
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI242, (ErrVal) 0, 0, 
                  "HiUiHitServOpenReq() : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */
        
         reason = HI_OUTOF_RES;

         alInfo.type = LHI_ALARMINFO_MEM_ID;

         /* fill up the alarm information */
         HI_FILL_ALARMINFO_MEM_ID(alInfo, info.region, info.pool);
         hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                     LHI_CAUSE_SOCK_RECV_ERR, &alInfo);

         reason = HI_OUTOF_RES; 
      }
      else
      {
#ifdef HI_MULTI_THREADED
         HI_LOCK(&hiCb.errStsLock, alInfo, ret); 
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI243, (ErrVal) 0, 0, 
                  "hiRecvIcm6Msg () : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */
         
         hiCb.errSts.sockRxErr++; 

#ifdef HI_MULTI_THREADED
         HI_UNLOCK(&hiCb.errStsLock, alInfo, ret);
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI244, (ErrVal) 0, 0, 
                  "HiUiHitServOpenReq() : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */
        
         reason = HI_SOCK_ICMP_RECV_ERR;
         hiSendAlarm(LCM_CATEGORY_INTERNAL, LHI_EVENT_INET_ERR,
                     LHI_CAUSE_SOCK_RECV_ERR, &alInfo);
      }

#ifdef HI_MULTI_THREADED
      /* Lock the ICMP hashlist */
      HI_LOCK(&hiCb.icmp6HlLock, alInfo, ret);
      if (ret != ROK)
      {
         HILOGERROR_DEBUG( EHI245, (ErrVal) ret, 0,
                    "hiRecvIcmp6Msg() : Unable to lock icmp user lock \n");
         RETVALUE(RFAILED);
      }
#endif /* HI_MULTI_THREADED */

      while((ret = cmHashListGetNext(&hiCb.icmp6HlCp, 
                           NULLP, (PTR *) &conCb)) == ROK)
      {
         sap = conCb->sap;
#ifdef HI_MULTI_THREADED
         conCb->reason = reason;
         hiSendIntDiscInd(sap, HI_PROVIDER_CON_ID, conCb->spConId, 
                          HI_SOCK_ICMP_RECV_ERR, 0);
#else
         HI_DISCIND(sap, HI_USER_CON_ID, conCb->suConId, reason);
         hiFreeConCb(conCb);
#endif /* HI_MULTI_THREADED */
      }

#ifdef HI_MULTI_THREADED
      HI_UNLOCK(&hiCb.icmp6HlLock, alInfo, ret);
      if (ret != ROK)
         HILOGERROR_DEBUG( EHI246, (ErrVal) ret, 0,
                    "hiRecvIcmp6Msg() : Unable to unlock icmp user lock \n");
#endif /* HI_MULTI_THREADED */

      RETVALUE(RFAILED);
   }

   /* Increment the statistics counters */
   hiCb.hiFdGrpInfoLstPtr[0]->grpCb.genRxSts.numRxbytes += len;

   srcAddr.type = CM_TPTADDR_IPV6;

   /* hi012.104 - change the type from NOTPRSNT to CM_HDRPARM_ICMP6 */
   ipHdrParm.type = CM_HDRPARM_ICMP6;

   (Void)SCpyMsgFix(mBuf, 0, sizeof(CmIcmpv6Hdr), (Data *)&icmp6Hdr, 
                    &count);

   msgType = icmp6Hdr.icmp6_type;
   msgCode = icmp6Hdr.icmp6_code;
   
   srcAddr.type =  CM_TPTADDR_IPV6;
   destAddr.type =  CM_TPTADDR_IPV6;

   srcAddr.u.ipv6TptAddr.port = 0;  /* Port is not relevant in RAW socket */
   destAddr.u.ipv6TptAddr.port = 0; /* Port is not relevant in RAW socket */

#ifdef HI_MULTI_THREADED
   /* Lock the ICMP hashlist */
   HI_LOCK(&hiCb.icmp6HlLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI247, (ErrVal) ret, 0,
                 "hiRecvIcmpMsg() : Unable to lock icmp user lock \n");
      RETVALUE(RFAILED);
   }
#endif /* HI_MULTI_THREADED */

   while((ret = cmHashListGetNext(&hiCb.icmp6HlCp, 
           (PTR) prevConCb, (PTR *) &conCb) == ROK))
   {
      sendflag = FALSE;
      prevConCb = conCb;
      sap = conCb->sap;

      /* If connnection is not intrested in listening to ICMP message 
       * then just skip */
      if (conCb->icmp6Mask == 0)
      {
         continue;
      }
   
#ifdef HI_MULTI_THREADED 
      if (conCb->sendConCfm)
         continue;
#endif /* HI_MULTI_THREADED */

      /* Connections wants to listen to ICMP messages */
      if(conCb->conState != HI_ST_CONNECTED)
         continue;

      if(conCb->icmp6Mask & ALL_ICMP_MSG)
         sendflag = TRUE;
      else if (conCb->icmp6Mask & ALL_FLTRD_ICMP_MSG)
      {
         for (idx=0; idx < conCb->numFilters; idx++)
         { 
            if (conCb->icmpError[idx].errType != msgType)
               continue;

            if (conCb->icmpError[idx].errCodeMask & (1 << msgCode))
               sendflag = TRUE;
            break;
         } 
      }

      if(sendflag == TRUE)
      {
         mem.region = conCb->sap->uiPst.region;
         mem.pool   = conCb->sap->uiPst.pool;

         ret = SAddMsgRef(mBuf, mem.region, mem.pool, &sndmBuf);
         if(ret != ROK)
         { 
            /* we can just skip this */
            continue;
         }
          
         /* Send a Unit Data Indication to the service user */
         /* hi009.104 - pass NULLP for localIf when icmp */
#ifdef HI_MULTI_THREADED
         HiUiHitUDatInd(&sap->uiUDatIndPst, sap->suId, conCb->suConId, 
                            &srcAddr, &destAddr, &ipHdrParm, 
#ifdef LOCAL_INTF                            
                            &localIf, 
#endif                            
                            sndmBuf);
#else
         HiUiHitUDatInd(&sap->uiPst, sap->suId, conCb->suConId, 
                            &srcAddr, &destAddr, &ipHdrParm, 
#ifdef LOCAL_INTF                            
                            &localIf, 
#endif                            
                            sndmBuf);
#endif /* HI_MULTI_THREADED */
      }  /* end of if sendflag */
      else
      {
         /* If no conCbs are interested in this type of error message then the 
          * filter will be updated */
         CM_INET_ICMP6_FILTER_SETBLOCK(msgType, hiCb.icmp6Filter);
      }
   } /* end while loop */

#ifdef HI_MULTI_THREADED
   HI_UNLOCK(&hiCb.icmp6HlLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI248, (ErrVal) ret, 0,
         "hiRecvIcmp6Msg() : Unable to unlock icmp user lock \n");
      RETVALUE(RFAILED);
   }
#endif /* HI_MULTI_THREADED */

   (Void)SPutMsg(mBuf);

   RETVALUE(ROK);
} /* end of hiRecvIcmp6Msg */
#endif /* IPV6_SUPPORTED */


/*
*
*       Fun:   hiPkIpv4Hdr
*
*       Desc:  This function is called to pack the IPv4 header. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16  hiPkIpv4Hdr
(
CmIpv4Hdr *ipv4Hdr,     /* pointer to Ipv4 Header Structure */
Buffer *mBuf           /* Message buffer  */
)
#else
PUBLIC S16  hiPkIpv4Hdr(ipv4Hdr, mBuf) 
CmIpv4Hdr *ipv4Hdr;     /* pointer to Ipv4 Header Structure */
Buffer *mBuf;           /* Message buffer  */
#endif
{

   Data   revPkArray[CM_IPV4_HDRLEN]; 
   Data   pkArray[CM_IPV4_HDRLEN];
   S16    cnt;
   S16    idx;
   S16    ret;

   /* Initialise variables */
   cnt = 0;

   cmMemset(revPkArray, 0, CM_IPV4_HDRLEN);
   cmMemset(pkArray, 0, CM_IPV4_HDRLEN);
 
  ret = ROK;

#if (ERRCLASS & ERRCLS_DEBUG)
   if( mBuf == NULL)
   {
      ret = RFAILED;
      HILOGERROR_DEBUG(EHI249, (ErrVal) ret, 0,
                 "hiPkIpv4Hdr(): Message buffer pointer invalid ");
      RETVALUE(RFAILED);
   }

   if( ipv4Hdr == NULL)
   {
      ret = RFAILED;
      HILOGERROR_DEBUG(EHI250, (ErrVal) ret, 0,
                 "hiPkIpv4Hdr(): IpHdr pointer invalid ");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* Pack hdrVersion */
   pkArray[cnt++] = ipv4Hdr->hdrVer;
   /* Pack Tos */
   pkArray[cnt++] = ipv4Hdr->tos;

   /* hi010.104 - On some BSD similiar core, the ip_len and ip_off field 
    * is in host byte order when passed into kernel, we need to reverse
    * the order in a little endian processor in such case. If your OS is 
    * behaving like this way, you need to enable BSD_SIM_CORE flag */
#ifndef BSD_SIM_CORE
   pkArray[cnt++] = (Data) GetHiByte(ipv4Hdr->length);
   pkArray[cnt++] = (Data) GetLoByte(ipv4Hdr->length);
#else
   pkArray[cnt++] = 
      (Data) GetHiByte(CM_INET_HTON_U16((U16)ipv4Hdr->length));
   pkArray[cnt++] = 
      (Data) GetLoByte(CM_INET_HTON_U16((U16)ipv4Hdr->length));
#endif /* BSD_SIM_CORE */   
   
   /* Pack Id */
   pkArray[cnt++] = (Data) GetHiByte(ipv4Hdr->id);
   pkArray[cnt++] = (Data) GetLoByte(ipv4Hdr->id);
      
   /* Pack Offset*/ 
   /* hi010.104 - make the change on some BSD similiar core */
#ifndef BSD_SIM_CORE
   pkArray[cnt++] = (Data) GetHiByte(ipv4Hdr->off);
   pkArray[cnt++] = (Data) GetLoByte(ipv4Hdr->off);
#else
   pkArray[cnt++] = 
      (Data) GetHiByte(CM_INET_HTON_U16((U16)ipv4Hdr->off));
   pkArray[cnt++] = 
      (Data) GetLoByte(CM_INET_HTON_U16((U16)ipv4Hdr->off));
#endif /* BSD_SIM_CORE */
      
   /* Pack TTl */
   pkArray[cnt++] = ipv4Hdr->ttl;
      
   /* Pack Protocol */
   pkArray[cnt++] = ipv4Hdr->proto;
      
   /* Pack Checksum */
   pkArray[cnt++] = (Data) GetHiByte(ipv4Hdr->chkSum);
   pkArray[cnt++] = (Data) GetLoByte(ipv4Hdr->chkSum);

   /*Pack Source Address */
   pkArray[cnt++] = (Data) GetHiByte(GetHiWord(ipv4Hdr->srcAddr));
   pkArray[cnt++] = (Data) GetLoByte(GetHiWord(ipv4Hdr->srcAddr));
   pkArray[cnt++] = (Data) GetHiByte(GetLoWord(ipv4Hdr->srcAddr));
   pkArray[cnt++] = (Data) GetLoByte(GetLoWord(ipv4Hdr->srcAddr));
   
   /* Pack Destination Address */
   pkArray[cnt++] = (Data) GetHiByte(GetHiWord(ipv4Hdr->destAddr));
   pkArray[cnt++] = (Data) GetLoByte(GetHiWord(ipv4Hdr->destAddr));
   pkArray[cnt++] = (Data) GetHiByte(GetLoWord(ipv4Hdr->destAddr));
   pkArray[cnt++] = (Data) GetLoByte(GetLoWord(ipv4Hdr->destAddr));

   
   for (idx = 0; idx < CM_IPV4_HDRLEN; idx++)
   {
      revPkArray[idx] = pkArray[CM_IPV4_HDRLEN -idx -1];
   }
  
   /* This function automatically reverses revPkArray. */
   SAddPreMsgMult(revPkArray, (MsgLen)cnt, mBuf); 
                        
   RETVALUE(ROK);
} /* end of hiPkIpv4Hdr */

/*
*
*       Fun:   hiUnpkIpv4Hdr
*
*       Desc:  This function is called to unpack the Ipv4 header. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy3.c
*
*/
#ifdef ANSI

#ifdef IPV4_OPTS_SUPPORTED
PUBLIC S16  hiUnpkIpv4Hdr
(
CmIpv4Hdr *ipv4Hdr,     /* pointer to Ipv4 Header Structure */
Buffer *mBuf,           /* Message buffer  */
/* hi009.104 - added new argument */
CmIpHdrParm *hdrParm    /* Structure that has the option values */
)
#else
PUBLIC S16  hiUnpkIpv4Hdr
(
CmIpv4Hdr *ipv4Hdr,     /* pointer to Ipv4 Header Structure */
Buffer *mBuf            /* Message buffer  */
)
#endif
#else
#ifdef IPV4_OPTS_SUPPORTED
PUBLIC S16  hiUnpkIpv4Hdr(ipv4Hdr, mBuf, hdrParm) 
CmIpv4Hdr *ipv4Hdr;     /* pointer to Ipv4 Header Structure */
Buffer *mBuf;           /* Message buffer  */
/* hi009.104 - added new argument */
CmIpHdrParm *hdrParm;   /* Structure that has the option values */
#else
PUBLIC S16  hiUnpkIpv4Hdr(ipv4Hdr, mBuf) 
CmIpv4Hdr *ipv4Hdr;     /* pointer to Ipv4 Header Structure */
Buffer *mBuf;           /* Message buffer  */
#endif
#endif
{
   /* hi009.104 - added new variables */
#ifdef IPV4_OPTS_SUPPORTED
   Data   unPkArray[CM_IPV4_HDRLEN + CM_IPV4_OPTS_MAXLEN];
   S8     extraBytes;  /* extra bytes after 20 bytes IP hdr & data in IP hdr */
#else
   Data   unPkArray[CM_IPV4_HDRLEN];
#endif /* IPV4_OPTS_SUPPORTED */

   U8     cnt;
   S16    ret;
   S16    temp;

   /* Initialise variables */
   cnt = 0;
  
   /* hi009.104 - fill up with all 0's */
#ifdef IPV4_OPTS_SUPPORTED
   cmMemset(unPkArray, 0, CM_IPV4_HDRLEN + CM_IPV4_OPTS_MAXLEN);
#else
   cmMemset(unPkArray, 0, CM_IPV4_HDRLEN);
#endif /* #ifdef IPV4_OPTS_SUPPORTED */

   temp = 0;

#if (ERRCLASS & ERRCLS_DEBUG)
   if( mBuf == NULL)
   {
      ret = RFAILED;
      HILOGERROR_DEBUG(EHI251, (ErrVal) ret, 0,
                 "hiUnpkIpv4Hdr(): Message buffer pointer invalid ");
      RETVALUE(RFAILED);
   }
   if( ipv4Hdr == NULL)
   {
      ret = RFAILED;
      HILOGERROR_DEBUG( EHI252, (ErrVal) ret, 0,
                "hiUnpkIpv4Hdr(): IpHdr pointer invalid ");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */
     
   ret = SRemPreMsgMult((Data *)unPkArray, CM_IPV4_HDRLEN, mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
   if(ret != ROK)
   {
      HILOGERROR_DEBUG( EHI253, (ErrVal) ret, 0,
                "hiUnpkIpv4Hdr(): Error in SRemPreMsgMult ");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* Unpack hdrVersion */
   ipv4Hdr->hdrVer = unPkArray[cnt++];

   /* Unpack Tos */
   ipv4Hdr->tos = unPkArray[cnt++];
     
   /* UnPack Length */
   ipv4Hdr->length = PutHiByte(ipv4Hdr->length, unPkArray[cnt++]);
   ipv4Hdr->length = PutLoByte(ipv4Hdr->length, unPkArray[cnt++]);
      
      
   /* UnPack id */
   ipv4Hdr->id = PutHiByte(ipv4Hdr->id, unPkArray[cnt++]);
   ipv4Hdr->id = PutLoByte(ipv4Hdr->id, unPkArray[cnt++]);
   
   /* UnPack off */
   ipv4Hdr->off = PutHiByte(ipv4Hdr->off, unPkArray[cnt++]);
   ipv4Hdr->off = PutLoByte(ipv4Hdr->off, unPkArray[cnt++]);

   /* Unpack Ttl */
   ipv4Hdr->ttl = unPkArray[cnt++];
      
   /* Unpack proto */
   ipv4Hdr->proto= unPkArray[cnt++];
     
   /* UnPack chkSum */
   ipv4Hdr->chkSum = PutHiByte(ipv4Hdr->chkSum, unPkArray[cnt++]);
   ipv4Hdr->chkSum = PutLoByte(ipv4Hdr->chkSum, unPkArray[cnt++]);

   /* UnPack Source Address */
   temp =  PutHiByte(temp, unPkArray[cnt++]);
   temp =  PutLoByte(temp, unPkArray[cnt++]);
     
   ipv4Hdr->srcAddr = PutHiWord(ipv4Hdr->srcAddr, temp);

   temp =  PutHiByte(temp, unPkArray[cnt++]);
   temp =  PutLoByte(temp, unPkArray[cnt++]);
     
   ipv4Hdr->srcAddr = PutLoWord(ipv4Hdr->srcAddr, temp);

   /* UnPack Destination Address */
   temp =  PutHiByte(temp, unPkArray[cnt++]);
   temp =  PutLoByte(temp, unPkArray[cnt++]);
     
   ipv4Hdr->destAddr = PutHiWord(ipv4Hdr->destAddr, temp);

   temp =  PutHiByte(temp, unPkArray[cnt++]);
   temp =  PutLoByte(temp, unPkArray[cnt++]);
     
   ipv4Hdr->destAddr = PutLoWord(ipv4Hdr->destAddr, temp);

   /* hi009.104 - extract all IPv4 options if they are present in IP header */
#ifdef IPV4_OPTS_SUPPORTED
   extraBytes =((ipv4Hdr->hdrVer & 0x0f)- 0x05) * 4;

   if(extraBytes > 0)
   {   
      /* IP Options present in the IPv4 header */
      hdrParm->u.hdrParmIpv4.ipv4HdrOpt.pres = TRUE;
      hdrParm->u.hdrParmIpv4.ipv4HdrOpt.len = extraBytes;
      
      /* copy the IP optiosn from the IPv4 header */ 
      SRemPreMsgMult((Data *)hdrParm->u.hdrParmIpv4.ipv4HdrOpt.val, 
                     extraBytes, mBuf);
   }   
#endif /* IPV4_OPTS_SUPPORTED */
   
   RETVALUE(ROK);
} /* end of hiUnpkIpv4Hdr */
#endif /* HI_REL_1_3 */ 


/********************************************************************30**
 
         End of file:     hi_bdy3.c@@/main/4 - Thu Jun 28 13:29:52 2001
 
*********************************************************************31*/
 
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      asa  1. initial release.
1.1+         hi002.11 asa  1. changed TCP clients reconnection method.
                          2. added processing for TCP application 
                             specific header.
                          3. miscellaneous bug fixes.
/main/2       ---      cvp  1. changed the hiScanConLst and hiScanPermTsk
                             functions to support multiple file 
                             descriptor sets.
                          2. removed write file descriptor set from 
                             select function parameters.
                          3. added check for ROUTRES return value from 
                             cmInetRecvMsg functions.
                          4. changed the copyright header.
/main/4      ---      sb   1. changes for receiving Raw messages, 
                              distributing Raw ICMP messages.
                          2. changes for packing/unpacking of IP header.
                          3. added backward compatibility flag.
                     cvp  4. changed the hiHndlTcpData function.
                          5. added hiHndlUdpData function.
/main/4+    hi001.13 cvp  1. Check received TPKT header only once. 
                          2. Miscellaneous bug fixes.
/main/4+    hi003.13 cvp  1. Added a UDP priority service type.
                          2. Accept multiple messages for the server.
                          3. Removed call to SAddMsgRef function in 
                             hiHndlTcpData.
/main/4+    hi005.13 cvp  1. Changes for peeking into the file descriptor
                             set.
                          2. Checking for RCLOSED from cmInetConnect. 
                             This error may be returned if the connection 
                             was actively refused or if the server is 
                             dead.
                          3. Added a change to set the timeout value for
                             select depending on the general 
                             configuration option.
                          4. Number of UDP messages to be read is now a 
                             general configuration option.
                          5. Number of RAW messages to be read is now a 
                             general configuration option.
                          6. Number of clients to accept for a TCP server 
                             is now a configuration option.
/main/4      ---      cvp  1. Multi-threaded related changes.
                          2. IPV6 related changes.
                          3. changed the copyright header.
/main/4+    hi001.104 mmh  1. In function hiRecvMsg(): Prevent closing of 
                              socket when cmInetRecvMsg returns ROUTRES.
/main/4+    hi002.104 mmh 1. In function hiPollSockets(): Removing conCb
                             from write hashlist after pending connection is
                             completed.
                          2. In function hiPollSockets(): Using a new macro
                             to clear file descriptors from fd_sets.
/main/4+    hi005.104 mmh 1. Correctly calculated numRxUdpMsg and
                             numRxTcpMsg in each sap in hiRecvMsg function.
                          2. Fix the problem of memory congestion handling.
/main/4+    hi006.104 mmh 1. peerAddr.type = CM_TPTADDR_IPV4 will be assigned
                             only when IPV6_SUPPORTED is not defined.
/main/4+    hi009.104 mmh 1. added new argument localIf in functions - 
                             hiHndlUdpData, hiHndlIpv6RawMsg, HiUiHitUDatInd.
                          2. initialize new structures & vars to all 0's.
                          3. pass 2 new arguments ipHdrParam & localIf
                             in cmInetRecvMsg and ipHdrParm in cmInetSendMsg.
                          4. added new arg CmIpHdrParm in func hiUnpkIpv4Hdr.
                          5. extract IPv4 IP OPTIONS in function hiUnpkIpv4Hdr
                          6. added Rolling Upgrade Support
                              - init all local struc var to all zeros in the
                                function hiAcceptTcpCon and hiRecvMsg
                          7. init structures for binding gen sockets in func
                             hiSockInit() and call cmInetBind under the flag
                             HI_SPECIFY_GENSOCK_ADDR.
/main/4+    hi010.104 bdu 1. Fix the problem of packing Ipv4 header on some 
                             BSD similiar core. On those core, the ip_len 
                             field and ip_off field is in host byte order
                             when passed into kernel.
                          2. Miscellous fix.
/main/4+    hi012.104 bdu 1. Change the ipHdrParm.type from NOTPRSNT to
                             CM_HDRPARM_ICMP6 in hiRecvIcmp6Msg function.
                          2. Miscellous fix.
/main/4+    hi014.104 bdu 1. fix some problem in hiRecvIcmpMsg function.
/main/4+    hi015.104 zmc 1. reset the counter
/main/4+    hi018.104 rs  1. Sending disconnect Indication in case of
                             select call failure.
/main/4+    hi021.104 rs  1. Warnings Removed.
/main/4+    hi022.104 rs  1. Send disconnect indication only for raw socket.
/main/4+    hi023.104 jc  1. Set IP TOS for accepted connection
/main/4+    hi028.104 jc  1. Removed compiler warnings
/main/4+    hi029.104 jc  1. Remove Fds from Fdset in case of error
*********************************************************************91*/
