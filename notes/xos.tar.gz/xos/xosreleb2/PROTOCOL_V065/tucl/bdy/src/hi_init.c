/* ***************************************************************************
 *        (c) COPYRIGHT 1995-2006 by Xinwei, Inc.
 *                   All rights reserved.
 *
 * hi_init.c:  
 *          tucl protocol initialize function.
 *           
 * Author:
 *          zhouguishuang
 * Date:
 *          2006-5-8
 * Last Modified:
 *
 ****************************************************************************/
 
#include"hi_common.h"

#ifdef CP_OAM_SUPPORT
#include "xosshell.h"
#include "cp_tab_def.h"
#include "sm.x"
#include "hi_cfg.h"

#include "hi_oam.x"
#include "oam_interface.h"
#include "oam_tab_def.h"

extern S16 smHiSendReqQ(CmLList *node);
extern unsigned char hiNmInitCallback(unsigned short msgtype, unsigned int sepuense, unsigned char pack_end, tb_record* prow);
extern VOID hiResetCfgData(void);
#endif /* CP_OAM_SUPPORT */

#ifdef TUCL_OAM_DISABLED
extern PUBLIC S16 hiSapCfg(void);
extern PUBLIC S16 hiGenCfg(void);
#endif /* TUCL_OAM_DISABLED */





Bool g_tucltaskRegComp;

/*****************************************************************************
*
*       ����:   hi_init_fun
*
*       ����:   TUCLģ���ʼ��������
*
*       ����ֵ:   ʧ��:           RFAILED
*                 �ɹ�:           ROK
*       �ļ�:   hi_init.c
*
*/
PUBLIC S16 hi_init_fun(SSTskId hiTskId)
{
    char prntBuf[255];
    

   if(hiTskId == 0)
   {
	   /* ����TUCLϵͳ���� */
	   if (SCreateSTsk((SSTskPrior)PRIOR0, &(hiTskId)) != ROK)
	   {
	      RETVALUE(RFAILED);
	   }
   	}

   /* ע�� TUCL TAPA ���� */
   if (SRegTTsk((Ent)ENTHI, (Inst)0, (Ttype)TTNORM, (Prior)PRIOR0,
                hiActvInit, hiActvTsk) != ROK)
   {
      HILOGERROR_DEBUG(EHI268, 0, 0,  "hi_init_fun:SRegTTsk() for TUCL failed.\n");
      RETVALUE(RFAILED);
   }

   /* ƥ�� TUCL TAPA ���� */
   if (SAttachTTsk((Ent)ENTHI, (Inst)0, hiTskId)!= ROK)
   {
      HILOGERROR_DEBUG(EHI268, 0, 0, "hi_init_fun:SAttachTTsk() for TUCL failed.\n");
      RETVALUE(RFAILED);
   }

   
   /* TUCL scan socket - perm task */
#ifndef HI_MULTI_THREADED
#ifdef SS_MULTIPLE_PROCS
   if (SRegTTsk (200, ENTHI,(Inst)1, TTPERM, PRIOR0, NULLP, hiScanPermTsk) 
                 != ROK)
#else /* SS_MULTIPLE_PROCS */
   if (SRegTTsk (ENTHI, (Inst)1, TTPERM, PRIOR0, NULLP, hiScanPermTsk) 
                 != ROK)
#endif /* SS_MULTIPLE_PROCS */
   {
      HILOGERROR_DEBUG(EHI268, 0, 0, 
         "hi_init_fun: SRegTTsk failed.\n");
      RETVALUE(RFAILED);
   }
   if (SAttachTTsk((Ent)ENTHI, (Inst)1, hiTskId)!= ROK)
   {
      HILOGERROR_DEBUG(EHI268, 0, 0, "hi_init_fun:SAttachTTsk() for hiScanPermTsk.\n");
      RETVALUE(RFAILED);
   }

#endif /* HI_MULTI_THREADED */

#ifdef  CP_OAM_SUPPORT
    g_tucltaskRegComp = TRUE;
#endif


#ifdef CP_OAM_SUPPORT
   /* ��ʼ�������������� */
#ifndef TUCL_OAM_DISABLED
   
   if( ROK != smRegCb((Ent)ENTHI, hiCmListSQ, 7,smHiSendReqQ,hiResetCfgData))
   {
      RETVALUE(RFAILED);
   }

	if( OAM_CALL_SUCC != register_msg_proc(CP_MODULE_ID_VOIP_TUCL,  APP_SYNC_MSG, hiNmInitCallback, NULL))
	{
      RETVALUE(RFAILED);
   } 	
   
   (unsigned char)get_resource(xwCpTuclGenCfg, sizeof(HiCfgGenWG), xwCpTuclGenCfg_ROW_NUM);
   
   if( OAM_CALL_SUCC != app_register(CP_MODULE_ID_VOIP_TUCL, &hiCfgTbl, 1))
   {
      RETVALUE(RFAILED);
   }
#endif /* TUCL_OAM_DISABLED */  
#endif /*CP_OAM_SUPPORT*/
  
#ifdef TUCL_OAM_DISABLED
   
   hiGenCfg();

   hiSapCfg();
  
#endif /* TUCL_OAM_DISABLED */   
   RETVALUE(ROK);
}
 

Bool get_tucltaskRegComp(void)
{ 
       return(g_tucltaskRegComp);
}

/********************************************************************30**

         End of file:     hi_init.c@@/main/2 - 2006-05-11

*********************************************************************31*/
