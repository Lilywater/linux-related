/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:    TCP UDP Convergence Layer (TUCL)
  
     Type:    C source file
  
     Desc:    Code for Upper Interface and Management Interface 
              primitives supplied by TRILLIUM
              
     File:    hi_bdy1.c
  
     Sid:      hi_bdy1.c@@/main/4 - Thu Jun 28 13:29:37 2001

     Prg:     asa
  
*********************************************************************21*/

/* 
Upper Layer functions interface to the HI Layer user.
 
The following functions are provided in this file:
 
Upper layer functions
 
    HiUiHitBndReq        Bind Request
    HiUiHitUbndReq       Unbind Request
    HiUiHitServOpenReq   Server Open Request
    HiUiHitConReq        Connect Request
    HiUiHitConRsp        Connect Response
    HiUiHitDatReq        Data Request(TCP)
    HiUiHitUDatReq       Unit Data Request(UDP)
    HiUiHitDiscReq       Disconnect Request

Lower layer functions

    socket calls to common socket library. 
 
Layer Management functions
 
    HiMiLhiCfgReq       Configuration Request
    HiMiLhiStsReq       Statistics Request
    HiMiLhiCntrlReq     Control Request
    HiMiLhiStaReq       Solicited Status Request
 
System Services
 
    hiActvInit          Activate task - initialize
 
The following function are expected from the interface providers
  
Upper Interface (hi_ptui.c)
    HiUiHitConInd      Connect Indication
    HiUiHitConCfm      Connect Confirm 
    HiUiHitBndCfm      Bind Confirm
    HiUiHitDatInd      Data Indication
    HiUiHitUDatInd     Unit Data Indication
    HiUiHitDiscInd     Disconnect Indication
    HiUiHitDiscCfm     Disconnect Confirm
    HiUiHitFlcInd      Flow Control Indication 

Upper Interface (Internal primitive). These primitives are posted by the
receive thread to the TUCL instance threads.
   
    HiUiIntDiscInd      Internal disconnect indication 
    HiUiIntCongOff      Internal congestion off indication
    HiUiIntRecvThrClosed Internal receive thread indication
    HiUiIntZeroStsReq   Internal zero stats request
    HiUiIntSapDisReq    Internal Sap Disable request
    HiUiIntSapConCbDel  Internal primitive indicating last conCb on a sap is 
                        deleted
    HiUiIntSapDisCfm    Internal Sap Disable confirm

Lower Interface (hi_ptli.c)
    dummy file
 
Layer Management (hi_ptmi.c)
    HiMiLhiCfgCfm       Configuration Confirm
    HiMiLhiStsCfm       Statistics Confirm 
    HiMiLhiCntrlCfm     Control Confirm
    HiMiLhiStaCfm       Status Confirm 
    HiMiLhiTrcind       Trace Indication
 
System Services

    SRegTmr        Register timer activation function 
    SDeregTTsk     Deregister tapa task
    SDetachTTsk    Detach tapa task 

    SInitQueue     Initialize Queue
    SQueueFirst    Queue to First Place
    SQueueLast     Queue to Last Place
    SDequeueFirst  Dequeue from First Place
    SFndLenQueue   Find Length of Queue
  
    SPutMsg        Put Message
    SFndLenMsg     Find Length of Message
  
    SAddPreMsg     Add Pre Message
    SAddPstMsg     Add Post Message
    SRemPreMsg     Remove Pre Message
    SRemPstMsg     Remove Post Message

    SAddPreMsgMult Add multiple bytes to head of the Message
    SAddPstMsgMult Add multiple bytes from tail of the Message
    SRemPreMsgMult Remove multiple bytes to head of the Message
    SRemPstMsgMult Remove multiple bytes from tail of the Message

    SGetSBuf       Get Static Buffer
    SPutSBuf       Put Static Buffer
    SCatMsg        Concatenate two messages
    SSegMsg        Segments a message buffer
    SInitMsg       Initialize a message buffer pointer
  
    SChkRes        Check Resources
    SGetDateTime   Get Date and Time
    SGetSysTime    Get System Time

NOTE: For a complete list, please refer to TUCL Service Definition Document
  
*/


/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_inet.h"       /* common sockets */
#include "cm_tpt.h"        /* common transport defines */
#ifdef FTHA
#include "sht.h"           /* SHT Interface header files */
#endif /* FTHA */
#include "lhi.h"           /* layer management, TUCL  */
#include "hit.h"           /* HIT interface */
#include "hi.h"            /* TUCL internal defines */
#include "hi_err.h"        /* TUCL error */
#ifdef H323_PERF
#include "hc_prf.h"        /* Performance measurement data structs */
#endif /* H323_PERF */
 
/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_inet.x"       /* common sockets */
#include "cm_tpt.x"        /* common transport typedefs */
#ifdef FTHA
#include "sht.x"           /* SHT Interface header file */
#endif /* FTHA */
#include "lhi.x"           /* layer management TUCL */
#include "hit.x"           /* HIT interface */
#include "hi.x"            /* TUCL internal typedefs */
#ifdef H323_PERF
#include "hc_prf.x"        /* Performance measurement data structs */
#endif /* H323_PERF */



#ifdef SSI_WITH_CLI_ENABLED
extern Bool XOS_CLIRegCommand_HI(Void);
#endif

extern void hiInitCfgData(void);
/* Public variable declarations */
/* hi025.104 : Addition - Support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
PUBLIC HiCb hiCbLst[HI_MAX_INSTANCES];     /* TUCL control block */
PUBLIC HiCb *hiCbPtr;
#else /*  SS_MULTIPLE_PROCS */ 
PUBLIC HiCb  hiCb;         /* TUCL control block */
#endif /*  SS_MULTIPLE_PROCS */ 

EXTERN U32 g_hiDbgMask;

/* function prototypes */

/* functions */

/* ------------------------------------------------------------------*/
/* Interface Functions to System Services                            */


/*
*
*      Fun:   Activate Task - initialize
* 
*      Desc:  Invoked by system services to initialize a task.
* 
*      Ret:   ROK
* 
*      Notes: None
* 
*      File:  hi_bdy1.c
* 
*/
#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 hiActvInit
(
ProcId procId,         /* procId */
Ent entity,            /* entity */
Inst inst,             /* instance */
Region region,         /* region */
Reason reason,         /* reason */
Void **xxCb           /* Protocol Control Block */
)
#else
PUBLIC S16 hiActvInit(procId,entity, inst, region, reason, xxCb)
ProcId procId;         /* procId */
Ent entity;            /* entity */
Inst inst;             /* instance */
Region region;         /* region */
Reason reason;         /* reason */
Void **xxCb;           /* Protocol Control Block */
#endif
#else /* SS_MULTIPLE_PROCS */
#ifdef ANSI
PUBLIC S16 hiActvInit
(
Ent entity,            /* entity */
Inst inst,             /* instance */
Region region,         /* region */
Reason reason          /* reason */
)
#else
PUBLIC S16 hiActvInit(entity, inst, region, reason)
Ent entity;            /* entity */
Inst inst;             /* instance */
Region region;         /* region */
Reason reason;         /* reason */
#endif
#endif /* SS_MULTIPLE_PROCS */
{
#ifdef SS_MULTIPLE_PROCS
   PRIVATE U16 i = 0;
   PRIVATE U16 hiNumCallsToInit = 0;
#endif /* SS_MULTIPLE_PROCS */

   TRC2(hiActvInit)

/* hi025.104 : Addition - Support for multiple instances */
#ifdef SS_MULTIPLE_PROCS
if(reason != SHUTDOWN)
{
   if(!hiNumCallsToInit)
   {
      for(i = 0; i < HI_MAX_INSTANCES; i++)
         HI_ZERO(&hiCbLst[i],sizeof(HiCb));
   }   
   if(hiNumCallsToInit >= HI_MAX_INSTANCES)
      RETVALUE(FALSE);
   hiCbLst[hiNumCallsToInit].used = TRUE;
   hiCbPtr = &hiCbLst[hiNumCallsToInit];
   *xxCb = (Void *)&hiCbLst[hiNumCallsToInit];
   hiNumCallsToInit++;
}   
#endif /* SS_MULTIPLE_PROCS */
#ifdef SS_MULTIPLE_PROCS
   HIDBGP(DBGMASK_SI, (hiCb.hiInit.prntBuf,
          "hiActvInit(ProcId(%d), Ent(%d), Inst(%d), Region(%d), Reason(%d))\n",
           procId, entity, inst, region, reason));
#else /* SS_MULTIPLE_PROCS */ 
   HIDBGP(DBGMASK_SI, (hiCb.hiInit.prntBuf,
          "hiActvInit(Ent(%d), Inst(%d), Region(%d), Reason(%d))\n",
           entity, inst, region, reason));
#endif /* SS_MULTIPLE_PROCS */
 
   /* Initialize the TUCL control block. Note that TUCL instance 0 must
    * be the first TUCL instance registerd */
#ifdef HI_MULTI_THREADED    
   if (inst == 0)
#endif /* HI_MULTI_THREADED */
      HI_ZERO(&hiCb, sizeof(HiCb));

#ifdef HI_MULTI_THREADED    
   /* Store greatest instance used */
   if (inst > hiCb.lastInstUsed)
      hiCb.lastInstUsed = inst;
   
   /* The init structure contains info for inst 0 only */
   if (inst != 0)
      RETVALUE(ROK);
   else
      hiCb.zeroInstReg = TRUE;
#endif /* HI_MULTI_THREADED */
  
   hiCb.hiInit.ent = entity;
   hiCb.hiInit.inst = inst;
   hiCb.hiInit.region = region;
   hiCb.hiInit.reason = reason;
   hiCb.hiInit.cfgDone = FALSE;
   /* Pool Id is obtained after SGetSMem in general configuration */
   hiCb.hiInit.pool = 0;
#ifdef SS_MULTIPLE_PROCS
   hiCb.hiInit.procId = procId;
#else /* SS_MULTIPLE_PROCS */
   hiCb.hiInit.procId = SFndProcId();
#endif /* SS_MULTIPLE_PROCS */
   hiCb.hiInit.acnt = FALSE;
   hiCb.hiInit.usta = TRUE;
   hiCb.hiInit.trc = FALSE;

#ifdef HI_DEBUGP
   hiCb.hiInit.dbgMask = g_hiDbgMask;
#endif /* DEBUGP */


   hiInitCfgData();


   


#ifdef SSI_WITH_CLI_ENABLED
   XOS_CLIRegCommand_HI();
#endif


   /* hiInit.lmPst is initialised in general configuration */
   /* perform external initialization, if needed */
   hiInitExt();  
 
   RETVALUE(ROK);
}/* end of hiActvInit */

/* --------------------------------------------------------------- */
/* Layer Management interface LHI primitives                       */


/*
*
*       Fun:   HiMiLhiCfgReq
*
*       Desc:  This function is used by the Layer Management to
*              configure the layer. The TUC layer responds with a
*              Configuration Confirm to the layer manager.
*
*       Ret:   ROK
*
*       Notes: Configuration must be performed in the following 
*              sequence:
*              1) general configuration (STGEN);
*              2) transport sap configuration (STTSAP).
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiMiLhiCfgReq
(
Pst     *pst,                /* post structure */
HiMngmt *cfg                 /* configuration structure */
)
#else
PUBLIC S16 HiMiLhiCfgReq(pst, cfg)
Pst     *pst;                /* post structure */
HiMngmt *cfg;                /* configuration structure */
#endif
{

   Header      *hdr;         /* Header structure */
   HiMngmt     cfmMsg;       /* configuration confirm */
   S16         ret;          /* return code */
 
   TRC3(HiMiLhiCfgReq)

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "HiMiLhiCfgReq() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
          "HiMiLhiCfgReq(pst, elmnt(%d))\n",
           cfg->hdr.elmId.elmnt));
 
   /* obtain the header structure from the configuration */
   hdr = &(cfg->hdr);

   /* zero out the confirm structure */
   HI_ZERO(&cfmMsg, sizeof(HiMngmt));

#ifdef HI_MULTI_THREADED
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst->dstInst != 0)
   {
      HILOGERROR_INT_PAR(EHI001, (ErrVal) pst->dstInst, pst->dstInst, 
               "HiMiLhiCfgReq(): Configuration request to wrong instance \n");
      hiSendLmCfm(pst, TCFG, hdr, LCM_PRIM_NOK, LHI_REASON_WRONG_INST, 
                  &cfmMsg);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */
#endif /* HI_MULTI_THREADED */

   /* hi009.104 - added : fill intfVer in lmPst, Layer manager is not 
         required to provide backward compatibility at LM interface. LM always 
         fills self LM interface version number in pst. Initialize interface 
         version in lmPst with the version number filled by LM in the pst 
         structure */ 
#ifdef HI_RUG
   if (hiCb.hiInit.cfgDone == FALSE)
      hiCb.hiInit.lmPst.intfVer = pst->intfVer;
#endif /* HI_RUG */   
   
   switch (hdr->elmId.elmnt)
   {
      case STGEN:            /* general configuration */
         ret = hiCfgGen(&cfg->t.cfg.s.hiGen);
         break;
 
      case STTSAP:           /* sap configuration */
         ret = hiCfgSap(&cfg->t.cfg.s.hiSap);
         break;

      default:               /* invalid */
 
         ret = LCM_REASON_INVALID_ELMNT; /* error code returned */
         break;
 
   }/* end of switch statement */

   /* in normal cases, LCM_REASON_NOT_APPL is returned, in all error
    * cases appropriate reason is returned by the above functions */

   if (ret != LCM_REASON_NOT_APPL)
   {
      hiSendLmCfm(pst, TCFG, hdr, LCM_PRIM_NOK, ret, 
                  &cfmMsg);
      RETVALUE(RFAILED);
   }

   hiSendLmCfm(pst, TCFG, hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 
               &cfmMsg);
   RETVALUE(ROK);
} /* end of HiMiLhiCfgReq() */


/*
*
*       Fun:   Statistics Request Primitive 
*
*       Desc:  This primitive is used by the Layer Manager to solicit 
*              statistics information. The statistics values are 
*              returned by HiMiLhiStsCfm primitive.The statistics 
*              counters can be initialized to NULL using the "action" 
*              parameter. The possible values for "action" are:
*
*              ZEROSTS:  zero statistics counters
*              NOZEROSTS:do not zero statistics counters 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiMiLhiStsReq
(
Pst     *pst,                /* post structure */
Action  action,              /* action to be done */
HiMngmt *sts                 /* statistics structure */
)
#else
PUBLIC S16 HiMiLhiStsReq(pst, action, sts)
Pst     *pst;                /* post structure */
Action  action;              /* action to be done */
HiMngmt *sts;                /* statistics structure */
#endif
{

   Header      *hdr;         /* Header structure */
   HiMngmt     cfmMsg;       /* configuration confirm */
   
   TRC3(HiMiLhiStsReq)

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "HiMiLhiStsReq() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
          "HiMiLhiStsReq(pst, action(%d), elmnt(%d))\n",
           action, sts->hdr.elmId.elmnt));

   /* obtain the header structure from the configuration */
   hdr = &(sts->hdr);

   /* zero out the confirm structure */
   HI_ZERO(&cfmMsg, sizeof(HiMngmt));

   HIDBGP(DBGMASK_SI, (hiCb.hiInit.prntBuf,
          "SGetDateTime(DateTime(%p))\n", &cfmMsg.t.sts.dt));
           
   /* get the date and time */
   SGetDateTime(&cfmMsg.t.sts.dt);

#ifdef HI_MULTI_THREADED
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst->dstInst != 0)
   {
      HILOGERROR_INT_PAR(EHI002, (ErrVal) pst->dstInst, pst->dstInst, "HiMiLhiStsReq(): Statistics request to wrong instance \n");
      hiSendLmCfm(pst, TSTS, hdr, LCM_PRIM_NOK, LHI_REASON_WRONG_INST, 
                  &cfmMsg);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */
#endif /* HI_MULTI_THREADED */

   switch (hdr->elmId.elmnt)
   {
      case STGEN:            /* general statistics */
         /* copy the general statistics from the control block */
         hiGetGenSts(&cfmMsg.t.sts.s.genSts);
         if (action == ZEROSTS)
            /* zero out the stored statistics in the sap structure */
            hiZeroGenSts();
         break;
 
      case STTSAP:           /* sap statistics */
      {
         HiSap        *sap;  /* transport SAP */
         SpId         spId;  /* spId */

         spId = sts->t.sts.s.sapSts.sapId;

#if (ERRCLASS & ERRCLS_INT_PAR)
         if ((spId >= (SpId) hiCb.cfg.numSaps) || (spId < 0))
         {
            HILOGERROR_INT_PAR(EHI003, (ErrVal) spId, pst->dstInst, "HiMiLhiStsReq(): sapId out of range \n");
            hiSendLmCfm(pst, TSTS, hdr, LCM_PRIM_NOK, 
                        LHI_REASON_INV_SPID, &cfmMsg);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */

         sap = hiCb.sapLstPtr[spId];

#if (ERRCLASS & ERRCLS_INT_PAR)
         if (!sap)
         {
            HILOGERROR_INT_PAR(EHI004,
                       (ErrVal) sts->t.sts.s.sapSts.sapId, pst->dstInst,
                       "HiMiLhiStsReq(): SAP not configured");
            hiSendLmCfm(pst, TSTS, hdr, LCM_PRIM_NOK, 
                        LCM_REASON_INVALID_SAP, &cfmMsg);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
       
         /* copy the statistics from the sap to the management structure */
         hiGetSapSts(&cfmMsg.t.sts.s.sapSts, spId);

         if (action == ZEROSTS)
         {
            /* zero out the stored statistics in the sap structure */
            hiZeroSapSts(spId);
         }
         break;
      }/* end case */

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         HILOGERROR_INT_PAR(EHI005, (ErrVal) hdr->elmId.elmnt, pst->dstInst,
                    "HiMiLhiStsReq(): Bad Element in statistics request");
         hiSendLmCfm(pst, TSTS, hdr, LCM_PRIM_NOK, 
                     LCM_REASON_INVALID_ELMNT, &cfmMsg);
#endif /* ERRCLS_INT_PAR */
         RETVALUE(RFAILED);
   } /* end of switch statement */
   
   /* Issue a statistics confirm */
   hiSendLmCfm(pst, TSTS, hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL,
               &cfmMsg);
       
   RETVALUE(ROK);
}/* end of HiMiLhiStsReq() */


/*
*
*       Fun:   Control Request Primitive 
*
*       Desc:  This primitive is used to control the specified element.
*              It can be used to enable or disable trace and alarm 
*              (unsolicited status) generation. It can also be used 
*              to delete or disable a SAP or a group of SAPs. The 
*              control request is also used for debug printing control.
*
*       Ret:   ROK
*
*       Notes: None 
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiMiLhiCntrlReq
(
Pst  *pst,                   /* post structure */              
HiMngmt *ctl                 /* pointer to control structure */
)
#else
PUBLIC S16 HiMiLhiCntrlReq(pst, ctl)
Pst  *pst;                   /* post structure */              
HiMngmt *ctl;                /* pointer to control structure */
#endif
{

   Header      *hdr;         /* Header structure */
   HiMngmt     cfmMsg;       /* configuration confirm */
   S16         ret;          /* return code */

   TRC3(HiMiLhiCntrlReq)

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "HiMiLhiCntrlReq() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   
    
   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
          "HiMiLhiCntrlReq(pst, elmnt(%d))\n", ctl->hdr.elmId.elmnt));

   /* obtain the header structure from the configuration */
   hdr = &(ctl->hdr);

   /* zero out the confirm structure */
   HI_ZERO(&cfmMsg, sizeof(HiMngmt));

   HIDBGP(DBGMASK_SI, (hiCb.hiInit.prntBuf,
          "SGetDateTime(DateTime(%p))\n", &ctl->t.cntrl.dt));
  
   SGetDateTime(&(ctl->t.cntrl.dt));

#ifdef HI_MULTI_THREADED
   if (pst->dstInst != 0)
   {
      hiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK, LHI_REASON_WRONG_INST, 
                  &cfmMsg);
      RETVALUE(RFAILED);
   }
#endif /* HI_MULTI_THREADED */

   /* check element */
   switch(hdr->elmId.elmnt)
   {
      case STGEN:
         ret = hiCntrlGen(pst, ctl, hdr);
         break;

      case STTSAP: 
         ret = hiCntrlSap(pst, ctl, hdr);
         break;
 
      case STGRTSAP:
         ret = hiCntrlSapGrp(pst, ctl, hdr);
         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         HILOGERROR_INT_PAR(EHI006, (ErrVal) hdr->elmId.elmnt, 0,
                    "HiMiLhiCntrlReq(): Bad Element in control request");
#endif /* ERRCLS_INT_PAR */

         ret = LCM_REASON_INVALID_ELMNT; /* error code returned */
         break;
   } /* end switch */

#ifdef HI_MULTI_THREADED
   if (ret == LHI_REASON_OPINPROG)
   {
      hiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_OK_NDONE, 
                  LCM_REASON_NOT_APPL, &cfmMsg);
      RETVALUE(ROK);
   }
#endif /* HI_MULTI_THREADED */

   if (ret != LCM_REASON_NOT_APPL)
   {
      hiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_NOK, ret, &cfmMsg);
      RETVALUE(RFAILED);
   }

   /* Send a Control Confirm to the Layer Manager */
   hiSendLmCfm(pst, TCNTRL, hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 
               &cfmMsg);
   RETVALUE(ROK); 
}/* end of HiMiLhiCntrlReq() */

#ifdef FTHA

/*
 *
 *       Fun  :  System agent control Request 
 *
 *       Desc :  Processes system agent control request primitive
 *
 *       Ret  :  ROK  - ok
 *
 *       Notes:  None
 *
 *       File :  hi_bdy1.c
 *
 */
#ifdef ANSI
PUBLIC S16 HiMiShtCntrlReq
(
Pst *pst,                        /* post structure          */
ShtCntrlReqEvnt *reqInfo         /* system agent control request event */
)
#else
PUBLIC S16 HiMiShtCntrlReq(pst, reqInfo)
Pst *pst;                      /* post structure          */
ShtCntrlReqEvnt *reqInfo;      /* system agent control request event */
#endif
{
   Pst             repPst;   /* reply post structure */
   ShtCntrlCfmEvnt cfmInfo;  /* system agent control confirm event */
   U16             i;
   Bool            found;
   HiSap           *sap;
   S16             ret;  
#ifdef HI_MULTI_THREADED
   HiSendThrMsg   msg;
#endif /* HI_MULTI_THREADED */

#ifdef HI_RUG
   S32 j;                    /* loop counter */
#endif /* HI_RUG */   

   TRC3 (HiMiShtCntrlReq);

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "HiMiShtCntrlReq() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

   /* Variable initialisation */
   found = FALSE;
   ret = ROK;

   /* hi009.104 - add missing initialization of local struc to 0's */
#ifdef HI_RUG
   HI_ZERO((U8*)&repPst, sizeof(Pst));
   HI_ZERO((U8*)&cfmInfo, sizeof(ShtCntrlCfmEvnt));
#ifdef HI_MULTI_THREADED   
   HI_ZERO((U8*)&msg, sizeof(HiSendThrMsg));
#endif /* HI_MULTI_THREADED */   
#endif /* HI_RUG */   
   
   /* fill reply pst structure */
   repPst.dstProcId = pst->srcProcId;
   repPst.dstEnt    = pst->srcEnt;
   repPst.dstInst   = pst->srcInst;
   repPst.prior     = reqInfo->hdr.response.prior;
   repPst.route     = reqInfo->hdr.response.route;
   repPst.selector  = reqInfo->hdr.response.selector;
   
   /* hi009.104 - was previously mising */
   repPst.region    = reqInfo->hdr.response.mem.region;
   repPst.pool      = reqInfo->hdr.response.mem.pool;
   
   repPst.event     = EVTSHTCNTRLCFM;
   repPst.srcProcId = pst->dstProcId;
   repPst.srcEnt    = ENTHI;
   repPst.srcInst   = pst->dstInst;

   /* fill reply transaction Id */
   cfmInfo.transId = reqInfo->hdr.transId;

   /* hi009.104 - fill request type */
#ifdef HI_RUG
   cfmInfo.reqType = reqInfo->reqType;
#endif /* HI_RUG */
   
   /* check if general configuration done */
   if (hiCb.cfgDone == FALSE)
   {
      cfmInfo.status.status = LCM_PRIM_NOK;
      cfmInfo.status.reason = LCM_REASON_GENCFG_NOT_DONE;
      
      HiMiShtCntrlCfm(&repPst, &cfmInfo);
      RETVALUE(ROK);
   }

   /* fill status value */
   cfmInfo.status.reason = LCM_REASON_NOT_APPL;
    
   switch (reqInfo->reqType)
   {
      case SHT_REQTYPE_BND_ENA:   /* system agent control bind enable */
         /* TUCL does not have bind enable */
         cfmInfo.status.reason = LCM_REASON_LYR_SPECIFIC;
         break;

      case SHT_REQTYPE_UBND_DIS:  /* system agent control unbind disable */
         for (i = 0; i < hiCb.cfg.numSaps; i++)
         {
            sap = hiCb.sapLstPtr[i];
            if (!sap)
               continue;
            
            switch (reqInfo->s.ubndDis.grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if ((sap->uiPst.dstProcId == reqInfo->s.ubndDis.dstProcId) && 
                      (sap->uiPst.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) &&
                      (sap->uiPst.dstInst == reqInfo->s.ubndDis.dstEnt.inst) &&
                      (sap->contEnt != ENTSM))
                     found = TRUE;
                  break;

               case SHT_GRPTYPE_ENT:
                  if ((sap->uiPst.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) &&
                      (sap->uiPst.dstInst == reqInfo->s.ubndDis.dstEnt.inst) &&
                      (sap->contEnt != ENTSM))
                     found = TRUE;
                  break;

               default:
                  cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
                  break;
            }

            if(found)
            {
               found = FALSE;

#ifdef HI_MULTI_THREADED
               if((sap->pendOp.flag != TRUE) && (hiCb.pendOp.flag != TRUE))
               {
                  /* Cleanup all conCbs on this sap */
                  if (sap->uiPst.srcInst == 0) 
                     hiCleanupSapConCbs(sap, HI_UBNDSAP_MSG);
                  else
                     hiSendIntSapDisReq(sap->spId);
               }
#else
               if (sap->state == HI_ST_BND)
               {
                  /* Release all connections */
                  HI_RELEASE_SAP_CON_LIST(sap, TRUE);
                  sap->state = HI_ST_UBND;
               }
#endif /* HI_MULTI_THREADED */
               /* hi009.104 - recommended */
#ifdef HI_RUG
               if (sap->verContEnt != ENTSM)
                  sap->remIntfValid = FALSE;
#endif /* HI_RUG */                  
            }
         } /* for */

         /* hi009.104 - deletion of stored version info */
#ifdef HI_RUG
         /* delete of stored version info */
         for (j = (S32)(hiCb.numIntfInfo - 1); j >= 0; j--)
         {
            if ((hiCb.intfInfo[j].grpType == reqInfo->s.ubndDis.grpType) &&
                (hiCb.intfInfo[j].dstProcId ==
                                              reqInfo->s.ubndDis.dstProcId) &&
                (hiCb.intfInfo[j].dstEnt.ent ==
                                              reqInfo->s.ubndDis.dstEnt.ent) &&
                (hiCb.intfInfo[j].dstEnt.inst ==
                                              reqInfo->s.ubndDis.dstEnt.inst))
            {
               /* delete verson info by copying the last version info
                  into current location */
               cmMemcpy((U8 *)&hiCb.intfInfo[j], 
                        (U8 *)&hiCb.intfInfo[hiCb.numIntfInfo - 1],
                        sizeof(ShtVerInfo));
               hiCb.numIntfInfo--;
            }
         }   
#endif /* HI_RUG */     
         break;
         
      /* hi009.104 - handling of getver and setver request types */
#ifdef HI_RUG
      case SHT_REQTYPE_GETVER:  /* system agent control get interface version */
         ret = hiGetVer(&cfmInfo.t.gvCfm);
         break;
      case SHT_REQTYPE_SETVER:  /* system agent control set interface version */
         hiSetVer(&reqInfo->s.svReq, &cfmInfo.status);
         break;
#endif /* HI_RUG */          
         
      default:
         cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
         break;
   }

   /* response is sent without waiting for bind or unbind to complete */
   if (cfmInfo.status.reason != LCM_REASON_NOT_APPL)
      cfmInfo.status.status = LCM_PRIM_NOK;
   else
      cfmInfo.status.status = LCM_PRIM_OK;
   
   /* send the response */
   HiMiShtCntrlCfm(&repPst, &cfmInfo);
       
   RETVALUE(ROK);
} /* end HiMiShtCntrlReq */
#endif /* FTHA */


/*
*
*       Fun:   Status Request Primitive 
*
*       Desc:  This primitive is used by the Layer Manager to solicit
*              status information. The information is returned via the
*              HiMiLhiStaCfm primitive.
*
*       Ret:   ROK      - ok
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiMiLhiStaReq
(
Pst  *pst,                   /* post structure */              
HiMngmt *sta                 /* status structure */
)
#else
PUBLIC S16 HiMiLhiStaReq(pst, sta)
Pst  *pst;                   /* post structure */              
HiMngmt *sta;                /* status structure */
#endif
{

   Header      *hdr;         /* Header structure */
   HiMngmt     cfmMsg;       /* configuration confirm */
 
   TRC3(HiMiLhiStaReq)

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "HiMiLhiStaReq() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf, "HiMiLhiStaReq(pst, elmnt(%d))\n",
           sta->hdr.elmId.elmnt));

   /* obtain the header structure from the configuration */
   hdr = &(sta->hdr);

   /* zero out the confirm structure */
   HI_ZERO(&cfmMsg, sizeof(HiMngmt));

#ifdef HI_MULTI_THREADED
   if (pst->dstInst != 0)
   {
      hiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK, LHI_REASON_WRONG_INST, 
                  &cfmMsg);
      RETVALUE(RFAILED);
   }
#endif /* HI_MULTI_THREADED */

   switch (hdr->elmId.elmnt)
   {
      case STSID:
         /* get the system id information */
         (Void) hiGetSid(&cfmMsg.t.ssta.s.sysId);
         break;

      case STTSAP:
      {
         HiSap           *sap;  /* SAP pointer */
         SpId            spId;  /* spId */

         spId = sta->t.ssta.s.sapSta.spId;

         /* validate the sapId */
#if (ERRCLASS & ERRCLS_INT_PAR)
         if ((spId >= (SpId) hiCb.cfg.numSaps) || (spId < 0))
         {
            HILOGERROR_INT_PAR(EHI007, (ErrVal) spId, 0,
                       "HiMiLhiStaReq(): spId out of range");
            hiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK, 
                        LHI_REASON_INV_SPID, &cfmMsg);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */
 
         sap = hiCb.sapLstPtr[spId];
#if (ERRCLASS & ERRCLS_INT_PAR)
         /* check to see if the sap exists */
         if (!sap)
         {
            HILOGERROR_INT_PAR(EHI008, (ErrVal) spId, 0,
                       "HiMiLhiStaReq(): Sap not configured");
            hiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK, 
                        LCM_REASON_INVALID_SAP, &cfmMsg);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLS_INT_PAR */

/* hi009.104 - fill self and remote interface version info in status struct */
#ifdef HI_RUG
         /* fill up interface version information */
         cfmMsg.t.ssta.s.sapSta.remIntfValid = sap->remIntfValid;
         cfmMsg.t.ssta.s.sapSta.selfIfVer = HITIFVER;
         cfmMsg.t.ssta.s.sapSta.remIfVer = sap->uiPst.intfVer;
#endif /* HI_RUG */
         
         /* get the status of the transport sap */
         cfmMsg.t.ssta.s.sapSta.spId     = sap->spId;
         cfmMsg.t.ssta.s.sapSta.state    = sap->state;
         break;

      }/* end case */

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         HILOGERROR_INT_PAR(EHI009, (ErrVal) hdr->elmId.elmnt, 0,
                    "HiMiLhiStaReq(): Invalid Element in Status request");
         hiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_NOK, 
                     LCM_REASON_INVALID_ELMNT, &cfmMsg);
#endif /* ERRCLS_DEBUG */
         RETVALUE(RFAILED);
 
   } /* end switch */
 
   SGetDateTime(&cfmMsg.t.ssta.dt);          /* fill the date and time */
 
   /* issue a status confirm to the Layer Manager */
   hiSendLmCfm(pst, TSSTA, hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 
               &cfmMsg);
 
   RETVALUE(ROK);
}/* end of HiMiLhiStaReq() */

/* --------------------------------------------------------------- */
/* Upper interface HIT primitives                                  */


/*
*
*       Fun:   Bind Request Primitive 
*
*       Desc:  This function binds a User to the TCP UDP Convergence
*              Layer.
*              The  TCP UDP Convergence Layer allocates a service 
*              access point for this bind and records the identity 
*              of the service user.
*              It also issues a HiUiHitBndCfm to the service user
*              after completing a successful bind.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiHitBndReq
(
Pst *pst,                    /* Post structure */
SuId suId,                   /* service user id */
SpId spId                    /* service provider id */
)
#else
PUBLIC S16 HiUiHitBndReq(pst, suId, spId)
Pst *pst;                    /* Post Structure */
SuId suId;                   /* service user id */
SpId spId;                   /* service provider id */
#endif
{

   HiSap      *sap;          /* pointer to current SAP */
   HiAlarmInfo info;
   S16         ret;
   /* hi009.104 - added for rolling upgrade */
#ifdef HI_RUG
      U16  i;
      Bool found;
#endif /* HI_RUG */

   TRC3(HiUiHitBndReq)

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "HiUiHitBndReq() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

   ret = ROK;
 
   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
          "HiUiHitBndReq(pst, suId(%d), spId(%d))\n", suId, spId));
 
   /* Initialize alarmInfo */
   info.spId = spId;   
   /* hi009.104 - added for rolling upgrade */
#ifdef HI_RUG
   info.type = LHI_ALARMINFO_PAR_TYPE;
#else
   info.type = LHI_ALARMINFO_TYPE_NTPRSNT;
#endif /* HI_RUG */

   /* Validation of Input parameters */
#if (ERRCLASS & ERRCLS_INT_PAR)
   HI_CHK_SPID(spId, LHI_EVENT_BNDREQ, ret, info);
   if(ret != ROK)
   {
      HILOGERROR_INT_PAR(EHI010, (ErrVal)spId, pst->dstInst,
                 "HiUiHitBndReq(): Invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   sap = hiCb.sapLstPtr[spId];

   /* Check if the SAP is already bound */
   if (sap->state != HI_ST_BND)
   {
      /* copy bind configuration parameters in sap */
      sap->suId            = suId;
      sap->uiPst.dstProcId = pst->srcProcId;
      sap->uiPst.dstEnt    = pst->srcEnt;
      sap->uiPst.dstInst   = pst->srcInst;
      sap->uiPst.srcProcId = pst->dstProcId;
      sap->uiPst.srcInst   = pst->dstInst;

#ifdef HI_MULTI_THREADED
      HI_DUPLICATE_SAP_PST(sap, sap->uiPst);
#endif /* HI_MULTI_THREADED */


      /* Update the date and time for statistics */
      SGetDateTime(&sap->dt);
      
      /* hi009.104 - find interface version from stored info */
#ifdef HI_RUG
      found = FALSE;
            
      if(sap->remIntfValid == FALSE)
      {
         for(i = 0; i < hiCb.numIntfInfo && found == FALSE; i++)
         {
            if(hiCb.intfInfo[i].intf.intfId == HITIF)
            {
               switch(hiCb.intfInfo[i].grpType)
               {
                  case SHT_GRPTYPE_ALL:
                     if((hiCb.intfInfo[i].dstProcId == pst->srcProcId) &&
                        (hiCb.intfInfo[i].dstEnt.ent ==pst->srcEnt) &&
                        (hiCb.intfInfo[i].dstEnt.inst == pst->srcInst))
                        found = TRUE;
                        break;
                                
                  case SHT_GRPTYPE_ENT:
                     if((hiCb.intfInfo[i].dstEnt.ent ==pst->srcEnt) &&
                        (hiCb.intfInfo[i].dstEnt.inst == pst->srcInst))
                        found = TRUE;
                        break;
                        
                  default:
                     break;
               } /* switch */
            } /* if */
         } /* for */
         
         if(found == TRUE)
         {
            sap->uiPst.intfVer = hiCb.intfInfo[i-1].intf.intfVer;
            sap->remIntfValid = TRUE;          
         } 
         else
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            HILOGERROR_INT_PAR(EHIXXX, (ErrVal)spId, pst->dstInst,
                 "HiUiHitBndReq(): remIntfver not available");
#endif /* ERRCLS_INT_PAR */            
            /* generate alarm to layer manager */
            hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_BNDREQ,
                        LCM_CAUSE_SWVER_NAVAIL, &info);

            /* send NOK to service user layer */
            (Void) HiUiHitBndCfm(&sap->uiPst, suId, CM_BND_NOK);

            RETVALUE(RFAILED);
         } 
      }
#endif /* HI_RUG */
   }/* end if */

   /* hi009.104 - now mark the sap state to bound */
   /* state bound and enabled */
   sap->state = HI_ST_BND;

   /* if the sap is already bound, a Bind confirm is given to
    * the user and no state change is made */

   /* send an acknowledgement back to the user */
   (Void) HiUiHitBndCfm(&sap->uiPst, suId, CM_BND_OK);

   RETVALUE(ROK);
} /* end of HiUiHitBndReq() */


/*
*
*       Fun:   Primitive to unbind a service user.
*
*       Desc:  This function "un-binds" a User to the TCP UDP
*              Convergence Layer.
*              The service access point for this bind is de-allocated,
*              all associated TCP and UDP sockets are closed, and 
*              their corresponding connection blocks are released.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiHitUbndReq
(
Pst *pst,              /* Post structure */
SpId spId,             /* Service provider Id */
Reason reason          /* cause for unbind operation */
)
#else
PUBLIC S16 HiUiHitUbndReq(pst, spId, reason)
Pst *pst;              /* Post structure */
SpId spId;             /* Service provider Id */
Reason reason;         /* cause for unbind operation */
#endif
{
 
   HiSap       *sap;           /* pointer to current SAP */
   HiAlarmInfo info;           /* alarm information */
   S16         ret;            /* return value */

   TRC3(HiUiHitUbndReq)

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "HiUiHitUBndReq() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */
   UNUSED(reason);

   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
          "HiUiHitUbndReq(pst, spId(%d), reason(%d))\n", spId, reason));
 
   /* initializations */
   info.spId = spId;
   info.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   ret = ROK;

   /* validation of Input parameters */
#if (ERRCLASS & ERRCLS_INT_PAR)
   HI_CHK_SPID(spId, LHI_EVENT_UBNDREQ, ret, info);
   if(ret != ROK)
   {
      HILOGERROR_INT_PAR(EHI011, (ErrVal)spId, pst->dstInst, 
                 "HiUiHitUbndReq(): Invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */
 
   sap = hiCb.sapLstPtr[spId];

   /* return if SAP has not been bound */
   if(sap->state == HI_ST_UBND)
      RETVALUE(ROK);

#ifdef HI_MULTI_THREADED
   /* Cleanup all conCbs from the sap */
   hiCleanupSapConCbs(sap, HI_UBNDSAP_MSG);

#else
   /* traverse the connection block hash list. Close all associated 
    * TCP and UDP sockets.Release the connection blocks.
    */
   HI_RELEASE_SAP_CON_LIST(sap, FALSE);
#endif /* HI_MULTI_THREADED */

#ifndef HI_REL_1_3
   sap->currTxQSiz = 0;
#endif /* HI_REL_1_3 */

   /* revert the SAP state to configured but not bound */
   sap->state = HI_ST_UBND;

   RETVALUE(ROK);
}/* end of HiUiHitUbndReq() */


/*
*
*       Fun:   Primitive to Open a new TCP or UDP server 
*
*       Desc:  This primitive  is used by the service user to 
*              open a TCP server or a UDP server on the server 
*              address provided. TCP UDP Convergence Layer 
*              creates a new socket. This socket is non-blocking
*              by default. Any other socket options as specified
*              in "tPar" are set on the socket.
*              TCP UDP Convergence Layer issues a HiUiHitConCfm
*              to the service user after processing the primitive.    
*
*              "tPar" :  may specify any additional socket 
*                        options required.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: TUCL will send a HiUiHitDiscInd to the user in 
*              case of any socket/memory or any other errors and 
*              it will close the socket and relinquish resources (if 
*              allocated). 
* 
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiHitServOpenReq 
(
Pst *pst,                  /* post stucture */
SpId spId,                 /* service provider Id */
UConnId servConId,         /* service user's server connection Id */
CmTptAddr *servTAddr,      /* transport address of the server */ 
CmTptParam *tPar,          /* transport options */
#ifdef HI_REL_1_3 
CmIcmpFilter *icmpFilter,  /* Filter parameters */
#endif /* HI_REL_1_3 */
U8  srvcType               /* service type */
)
#else
#ifdef HI_REL_1_3  
PUBLIC S16 HiUiHitServOpenReq(pst, spId, servConId, servTAddr, tPar,
                              icmpFilter, srvcType) 
Pst *pst;                  /* post stucture */
SpId spId;                 /* service provider Id */
UConnId servConId;         /* service user's server connection Id */
CmTptAddr  *servTAddr;     /* transport address of the server */ 
CmTptParam *tPar;          /* transport options */
CmIcmpFilter *icmpFilter;  /* Filter parameters */
U8  srvcType;              /* service type */
#else 
PUBLIC S16 HiUiHitServOpenReq(pst, spId, servConId, servTAddr, tPar,
                              srvcType) 
Pst *pst;                   /* post stucture */
SpId spId;                  /* service provider Id */
UConnId servConId;          /* service user's server connection Id */
CmTptAddr  *servTAddr;      /* transport address of the server */ 
CmTptParam *tPar;           /* transport options */
U8  srvcType;               /* service type */
#endif /* HI_REL_1_3 */ 
#endif /* ANSI */
{

   HiSap          *sap;      /* HI SAP address */
   HiConCb        *conCb;    /* HI connection block */
   CmInetFd       sockd;     /* socket descriptor */
   HiAlarmInfo    info;      /* alarm information */
   CmTptAddr      locTptAddr;/* local transport address */
   U8             type;      /* type of socket */
   S16            backLog;   /* backlog */
   U32            protType;  /* protocol type */
   S16            ret;       /* return value */
   
   /* hi023.104 - Store the IP TOS*/
   U8             i;         /* loop counter */
#ifdef HI_REL_1_3  
   U8             protocol;      /* Protocol value */
   S16            notSupported;  /* Flag for not supporting IP_HDRINCLD opt*/
   U8             tmpSrvcType;   /* temporary service type */
#endif /* HI_REL_1_3 */ 

#ifdef FTHA
   HiConCb        *prevConCb;
#endif /* FTHA */

   TRC3(HiUiHitServOpenReq)

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "HiUiHitServOpenReq() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */

#ifdef HI_LPBK
   UNUSED(backLog); 
#endif /* HI_LPBK */

   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
          "HiUiHitServOpenReq(pst, spId(%d), servConId(%ld), \
          servTAddr(%p), tPar(%p), srvcType(%d))\n", spId, servConId, 
          servTAddr, tPar, srvcType));
  
   /* Initialize spId in alarmInfo */
   info.spId = spId;
   info.type = LHI_ALARMINFO_TYPE_NTPRSNT;

#ifdef HI_REL_1_3  
   /* Initialise protocol */
   protocol = 0; 
   notSupported = FALSE;
   tmpSrvcType = 0;
#endif /* HI_REL_1_3 */ 

   /* hi026.104 - Initializtion */
   if(tPar->type == CM_TPTPARAM_NOTPRSNT )
      tPar->u.sockParam.numOpts=0;

   /* validation of input parameters */
#if (ERRCLASS & ERRCLS_INT_PAR)
   HI_CHK_SPID(spId, LHI_EVENT_SERVOPENREQ, ret, info);
   if (ret != ROK)
   {
      HILOGERROR_INT_PAR(EHI012, (ErrVal)spId, pst->dstInst, 
                 "HiUiHitServOpenReq(): Invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   sap = hiCb.sapLstPtr[spId];
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sap->state != HI_ST_BND)
   {
      HILOGERROR_INT_PAR(EHI013, (ErrVal) sap->state, pst->dstInst,
                 "HiUiHitServOpenReq(): Sap not Bound");

      HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_INV_SAP_STATE);

      HI_FILL_ALARMINFO_SAP_STATE(info, sap->state);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_SERVOPENREQ,
                  LCM_CAUSE_INV_STATE, &info);
      RETVALUE(RFAILED);
   }

#ifdef IPV6_SUPPORTED
   if ((!servTAddr) || ((servTAddr->type != CM_TPTADDR_IPV4) &&
                        (servTAddr->type != CM_TPTADDR_IPV6)))
#else
   if ((!servTAddr) || (servTAddr->type != CM_TPTADDR_IPV4))
#endif /* IPV6_SUPPORTED */
   {
      HILOGERROR_INT_PAR(EHI014, (ErrVal) servTAddr->type, pst->dstInst,
                 "HiUiHitServOpenReq(): servTAddr not present");

      HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_INV_PAR_VAL);

      HI_FILL_ALARMINFO_PAR_TYPE(info, LHI_INV_TPT_ADDR);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_SERVOPENREQ,
                  LCM_CAUSE_INV_PAR_VAL, &info);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

#ifdef HI_REL_1_3  
   /* service type consists of two parts. The lower 4 bits are used
    * to identify one of the predefined service types. The higher
    * bits are used for user defined profile types.
    */
   tmpSrvcType = srvcType & 0x0f;

   switch(tmpSrvcType) 
   {
      case HI_SRVC_UDP: 
      case HI_SRVC_UDP_TPKT_HDR: 
      case HI_SRVC_UDP_PRIOR:
         protType = HI_FL_UDP;
         type = CM_INET_DGRAM;
         break;

      case HI_SRVC_RAW_RAW: 
         protType = HI_FL_RAW;
         protocol = CM_PROTOCOL_RAW;
         type = CM_INET_RAW;
         break;

      case HI_SRVC_RAW_ICMP:  
         protType = HI_FL_RAW;
         protocol = CM_PROTOCOL_ICMP;
         type = CM_INET_RAW;
         break;
       
      /* hi009.104 - added new service type */     
#ifdef HI_RSVP_SUPPORT
      case HI_SRVC_RAW_RSVP:
         protType = HI_FL_RAW;
         protocol = CM_PROTOCOL_RSVP;
         type = CM_INET_RAW;
         break;
#endif /* HI_RSVP_SUPPORT */

      case HI_SRVC_RAW_SCTP: 
      case HI_SRVC_RAW_SCTP_PRIOR:
         protType = HI_FL_RAW;
         protocol = CM_PROTOCOL_SCTP;
         type = CM_INET_RAW;
         break;
         
      case HI_SRVC_TCP_TPKT_HDR: 
      case HI_SRVC_TCP_NO_HDR:
      default:
         protType = HI_FL_TCP;
         type = CM_INET_STREAM;
         break;
   }

#else /* HI_REL_1_3 */
   if((srvcType == HI_SRVC_UDP) || (srvcType == HI_SRVC_UDP_PRIOR))
   {
      protType = HI_FL_UDP;
      type = CM_INET_DGRAM;
   }
   else
   {
      protType = HI_FL_TCP;
      type = CM_INET_STREAM;
   }
#endif /* HI_REL_1_3 */ 

#ifdef HI_REL_1_3  
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* If protocol type is TCP or UDP, & filter parameter are set then 
    * indicate an error */
   if (((protType == HI_FL_UDP) || (protType == HI_FL_TCP)) && 
       (icmpFilter->type != CM_ICMP_NO_FILTER))
   {        

      HILOGERROR_INT_PAR(EHI015, (ErrVal) srvcType, pst->dstInst,
                 "HiUiHitServOpenReq():Invalid Type filter combination ");

      HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_INV_PAR_VAL);

      HI_FILL_ALARMINFO_PAR_TYPE(info, LHI_INV_FILTER_TYPE_COMB);

      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_SERVOPENREQ,
                  LCM_CAUSE_INV_PAR_VAL, &info);

      RETVALUE(RFAILED);
   }

#ifndef IPV6_SUPPORTED
   if ((protocol == CM_PROTOCOL_ICMP) && 
       ((icmpFilter->type != CM_ICMPVER4_FILTER) ||
        (icmpFilter->u.icmpv4Filter.icmpMsgFlag != TRUE)))
#else
   if ((protocol == CM_PROTOCOL_ICMP) && 
       (((icmpFilter->type == CM_ICMPVER4_FILTER) &&
         (icmpFilter->u.icmpv4Filter.icmpMsgFlag != TRUE)) ||
       (((icmpFilter->type == CM_ICMPVER6_FILTER) &&
         (icmpFilter->u.icmpv6Filter.icmpMsgFlag != TRUE)))))
#endif /* IPV6_SUPPORTED */
   {
      HILOGERROR_INT_PAR(EHI016, (ErrVal)tPar->type, pst->dstInst,
                 "HiUiHitServOpenReq(): Invalid filter parameter");

      HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_INV_PAR_VAL);

      HI_FILL_ALARMINFO_PAR_TYPE(info, LHI_INV_FILTER_TYPE_COMB);

      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_SERVOPENREQ,
                  LCM_CAUSE_INV_PAR_VAL, &info);

      RETVALUE(RFAILED);
   } 
#endif /* ERRCLS_INT_PAR */
#endif /* HI_REL_1_3 */ 

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check for tPar in TCP case */
   if ((type == CM_INET_STREAM) && (tPar->type != CM_TPTPARAM_SOCK))
   {
      HILOGERROR_INT_PAR(EHI017, (ErrVal)tPar->type, pst->dstInst,
                 "HiUiHitServOpenReq(): Invalid tPar parameter");

      HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_INV_PAR_VAL);

      HI_FILL_ALARMINFO_PAR_TYPE(info, LHI_INV_TPT_PARAM);

      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_SERVOPENREQ,
                  LCM_CAUSE_INV_PAR_VAL, &info);

      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */
  
   /* hi017.104: needs to first check the resource 
    * before checking the flag */
   hiChkRes(sap);
   /* Check for resource availability */
   if (sap->resCongStrt)
   {
      HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_OUTOF_RES);
      RETVALUE(RFAILED);
   }

#ifndef HI_LPBK
#ifdef HI_REL_1_3  
   /* Incase of an ICMP server request we will decide later if a socket
    * is needed. Only one socket is opened to receive ICMP messages. */
   if(protocol != CM_PROTOCOL_ICMP)
   {
      /* Open a new socket */
#ifdef IPV6_SUPPORTED
      if (servTAddr->type == CM_TPTADDR_IPV6)
         ret = cmInetSocket(type, &sockd, protocol, CM_INET_IPV6_DOMAIN);
      else
         ret = cmInetSocket(type, &sockd, protocol, CM_INET_IPV4_DOMAIN);
#else
      ret = cmInetSocket(type, &sockd, protocol);
#endif /* IPV6_SUPPORTED */

      if (ret != ROK)
      {
#ifdef HI_MULTI_THREADED
         HI_LOCK(&hiCb.errStsLock, info, ret); 
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI018, (ErrVal) 0, pst->dstInst, 
                  "HiUiHitServOpenReq() : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */

         /* Increment the statistics counter */
         hiCb.errSts.sockOpenErr++;

#ifdef HI_MULTI_THREADED
         HI_UNLOCK(&hiCb.errStsLock, info, ret);
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI019, (ErrVal) 0, pst->dstInst, 
                  "HiUiHitServOpenReq() : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */

#if (ERRCLASS & ERRCLS_ADD_RES)
         HILOGERROR_ADD_RES(EHI020, (ErrVal) ret, pst->dstInst,
                    "HiUiHitServOpenReq: failed to open socket");
#endif /* ERRCLS_ADD_RES */

         /* Issue an indication to the upper layer */
         HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_SOCK_OPEN_ERR);
         RETVALUE(RFAILED);
      }

      /* Apply the CM_SOCKOPT_OPT_REUSEADDR option */
      HI_SET_SOCKOPT_REUSEADDR(&sockd);

      /* Bind the socket to server's address */
#ifdef IPV6_SUPPORTED
      ret = cmInetBind(&sockd, (CmInetAddr *)servTAddr);
#else
      ret = cmInetBind(&sockd, &(servTAddr->u.ipv4TptAddr));
#endif /* IPV6_SUPPORTED */
      if (ret != ROK)
      {
#ifdef FTHA
         /* There may be a duplicate serv open req on the same source address
          * as a previous server open request. This may happen in case
          * of fault tolerant upper layers. Beware if the upper layer has 
          * an implementation error the duplicate ServOpenReq will go through!!!
          */

         /* Go through the sap hash list and check the locTptAddr with the
          * address got in this request. */
         conCb = prevConCb = NULLP;

         while((ret = cmHashListGetNext(&(sap->sapHlCp), (PTR)prevConCb,
                                        (PTR *)&(conCb))) == ROK)           
         {
#ifdef IPV6_SUPPORTED
            if ((cmMemcmp((U8 *) servTAddr, 
                          (U8 *) &conCb->locTptAddr,
                          sizeof(conCb->locTptAddr))) == 0);
#else
            if ((cmMemcmp((U8 *) &servTAddr->u.ipv4TptAddr, 
                          (U8 *) &conCb->locTptAddr.u.ipv4TptAddr,
                          sizeof(CmIpv4TptAddr))) == 0);
#endif /* IPV6_SUPPORTED */
            {
               /* Check if this is a server */
               if ((conCb->flag & HI_FL_SRV) &&
                   (conCb->srvcType == srvcType) &&
                   (conCb->protocol == protocol))
               { 
                  /* Store the new suConId in the conCb */
                  conCb->suConId = servConId;

                  /* Issue a Connect confirm to the Upper Layer */
                  HiUiHitConCfm(&sap->uiPst, sap->suId, 
                                servConId, conCb->spConId, &conCb->locTptAddr);
                  RETVALUE(ROK);
               }
            }
            /* Get the next conCb */
            prevConCb = conCb;
         }
#endif /* FTHA */

#ifdef HI_MULTI_THREADED
         HI_LOCK(&hiCb.errStsLock, info, ret); 
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI021, (ErrVal) 0, pst->dstInst, 
                  "HiUiHitServOpenReq() : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */

         /* Increment the statistics counters */
         hiCb.errSts.sockBindErr++;
         
#ifdef HI_MULTI_THREADED
         HI_UNLOCK(&hiCb.errStsLock, info, ret);
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI022, (ErrVal) 0, pst->dstInst, 
                  "HiUiHitServOpenReq() : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */

         /* Close the socket */
         HI_CLOSE_SOCKET(&sockd);
         
         /* Issue an indication to the upper layer */
         HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_SOCK_BIND_ERR);
         
         RETVALUE(RFAILED);
      }
      /*printf("hi open socket ok!\n\n");*/

      /* Apply the CM_SOCKOPT_OPT_TCP_NODELAY option */
      if (type == CM_INET_STREAM)
         HI_SET_SOCKOPT_TCP_NODELAY(&sockd);

      ret = hiSetSockOpt(&sockd, tPar);
      if (ret != ROK)
      {
         if (ret == RNA)
         { 
            notSupported = TRUE;   
         }
         else 
         {
            HILOGERROR_DEBUG(EHI023, (ErrVal) ret, pst->dstInst,
                        "HiUiHitServOpenReq: failed to set socket options");

            /* Close the socket */
            HI_CLOSE_SOCKET(&sockd);

            /* Issue an indication to the upper layer */
            HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_SOCK_SOPT_ERR);
            RETVALUE(RFAILED);
         }
      }

      /* Initialize the local address type filed */
#ifndef IPV6_SUPPORTED
      locTptAddr.type = CM_TPTADDR_IPV4;
#endif /* IPV6_SUPPORTED */

      /* Get the local address associated with the socket */
#ifdef IPV6_SUPPORTED
      ret = cmInetGetSockName(&sockd, (CmInetAddr *)&locTptAddr);
#else
      ret = cmInetGetSockName(&sockd, &(locTptAddr.u.ipv4TptAddr));
#endif /* IPV6_SUPPORTED */
      if (ret != ROK)
      {
         /* Close the socket */
         HI_CLOSE_SOCKET(&sockd);

         /* Issue an indication to the upper layer */
         HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_SOCK_NAME_ERR);

         RETVALUE(RFAILED);
      }

      if (type == CM_INET_STREAM) 
      {
         /* listen for all incoming connections */
         backLog = (S16)tPar->u.sockParam.listenQSize;

         ret = cmInetListen(&sockd, backLog);
         if (ret != ROK)
         {   
#ifdef HI_MULTI_THREADED
            HI_LOCK(&hiCb.errStsLock, info, ret); 
            if (ret != ROK)
               HILOGERROR_DEBUG(EHI024, (ErrVal) 0, pst->dstInst, 
                     "HiUiHitServOpenReq() : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */
            
            /* Increment the statistics counters */
            hiCb.errSts.sockLstnErr++;

#ifdef HI_MULTI_THREADED
            HI_UNLOCK(&hiCb.errStsLock, info, ret);
            if (ret != ROK)
               HILOGERROR_DEBUG(EHI025, (ErrVal) 0, pst->dstInst, 
                     "HiUiHitServOpenReq() : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */

            /* close the socket */
            HI_CLOSE_SOCKET(&sockd);
            
            HILOGERROR_DEBUG(EHI026, (ErrVal) ret, pst->dstInst,
                        "HiUiHitServOpenReq: listen failed on server socket");

            /* Issue an indication to the upper layer */
            HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_SOCK_LSTN_ERR);
               
            RETVALUE(RFAILED);
         }/* end if */
      }/* end if */
   } /* end if protocol != ICMP */

#else /* HI_REL_1_3 */
   
   /* Open a new socket */
   ret = cmInetSocket(type, &sockd);
   
   if (ret != ROK)
   {
      /* Increment the statistics counter */
      hiCb.errSts.sockOpenErr++;

#if (ERRCLASS & ERRCLS_ADD_RES)
      HILOGERROR_ADD_RES(EHI027, (ErrVal) ret, pst->dstInst,
                 "HiUiHitServOpenReq: failed to open socket");
#endif /* ERRCLS_ADD_RES */

      /* Issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_SOCK_OPEN_ERR);
      RETVALUE(RFAILED);
   }

   HI_SET_SOCKOPT_REUSEADDR(&sockd);

   /* Bind the socket to server's address */
   ret = cmInetBind(&sockd, &(servTAddr->u.ipv4TptAddr));
   if (ret != ROK)
   {
      /* Increment the statistics counters */
      hiCb.errSts.sockBindErr++;
                     
      /* Close the socket */
      HI_CLOSE_SOCKET(&sockd);

      /* Issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_SOCK_BIND_ERR);

      RETVALUE(RFAILED);
   }

   /* Apply the CM_SOCKOPT_OPT_TCP_NODELAY option */
   if (type == CM_INET_STREAM)
      HI_SET_SOCKOPT_TCP_NODELAY(&sockd);

   /* Set the specified socket options */
   ret = hiSetSockOpt(&sockd, tPar);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI028, ret, pst->dstInst,
                 "HiUiHitServOpenReq: failed to set socket options");

      /* Close the socket */
      HI_CLOSE_SOCKET(&sockd);

      /* Issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_SOCK_SOPT_ERR);
      RETVALUE(RFAILED);
   }

   /* Initialize the local address type filed */
#ifndef IPV6_SUPPORTED
   locTptAddr.type = CM_TPTADDR_IPV4;
#endif /* IPV6_SUPPORTED */

   /* Get the local address associated with the socket */
   ret = cmInetGetSockName(&sockd, &(locTptAddr.u.ipv4TptAddr));
   if (ret != ROK)
   {
      /* Close the socket */
      HI_CLOSE_SOCKET(&sockd);

      /* Issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_SOCK_NAME_ERR);

      RETVALUE(RFAILED);
   }

   if (type == CM_INET_STREAM) 
   {
      /* Listen for all incoming connections */
      backLog = (S16)tPar->u.sockParam.listenQSize;

      ret = cmInetListen(&sockd, backLog);
      if (ret != ROK)
      {
         /* Increment the statistics counters */
         hiCb.errSts.sockLstnErr++;
                         
         /* Close the socket */
         HI_CLOSE_SOCKET(&sockd);

         /* Issue an indication to the upper layer */
         HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_SOCK_LSTN_ERR);
         RETVALUE(RFAILED);
      }/* end if */
   }/* end if */
#endif  /* HI_REL_1_3 */ 
#endif /* HI_LPBK */

   /* Obtain a new connection block */
   HI_ALLOC(sizeof(HiConCb), conCb)
   if (!conCb)
   {
#ifdef HI_REL_1_3
      if (protocol != CM_PROTOCOL_ICMP)
      {
         HI_CLOSE_SOCKET(&sockd); /* close the socket */
      }
#else  
      /* Close the socket */
      HI_CLOSE_SOCKET(&sockd);
#endif /* HI_REL_1_3 */ 

      /* Issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_SMEM_ALLOC_ERR);

      /* Fill up the alarm information */
      HI_FILL_ALARMINFO_MEM_ID(info, hiCb.hiInit.region, hiCb.hiInit.pool);
      hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_SMEM_ALLOC_FAIL,
                  LCM_CAUSE_UNKNOWN, &info);

      RETVALUE(RFAILED);
   }

   /* Fill up the new connection block obtained */
   conCb->suConId  =  servConId;
   conCb->sap      =  sap;
#ifdef HI_REL_1_3
   /* hi004.104 - TOS parameter initialized to zero */ 
   conCb->ipTos    = 0;
#endif /* HI_REL_1_3 */
   conCb->flag     |=  (protType | HI_FL_SRV);

   /* Set the priority profile flag if necessary */
   if (srvcType == HI_SRVC_UDP_PRIOR)
   {  
      conCb->flag    |= HI_FL_PRIOR;
      conCb->srvcType = HI_SRVC_UDP;
   }
#ifdef HI_REL_1_3
   else if (srvcType == HI_SRVC_RAW_SCTP_PRIOR)
   {
      conCb->flag    |= HI_FL_PRIOR;
      conCb->srvcType = HI_SRVC_RAW_SCTP;
   }
#endif /* HI_REL_1_3 */
   else
   {
      conCb->srvcType = srvcType;
   }
   /* hi023.104 - Store the IP TOS*/
   conCb->ipTos= 0xff;
   for (i = 0; i < tPar->u.sockParam.numOpts; i++)
   {
	   CmSockOpts *sOpts = &(tPar->u.sockParam.sockOpts[i]);
	   if (sOpts->option == CM_SOCKOPT_OPT_TOS )
	   {
		   conCb->ipTos= (U8)sOpts->optVal.value;
		   break;
	   }
   }

#ifdef IPV6_SUPPORTED 
   if (servTAddr->type == CM_INET_IPV6ADDR_TYPE)
      if (conCb->flag & HI_FL_RAW)
         conCb->flag |= HI_FL_RAW_IPV6;
#endif /* IPV6_SUPPORTED */

#ifdef HI_REL_1_3  
   /* The conFd is valid only if protocol is not ICMP */
   if (protocol != CM_PROTOCOL_ICMP)
   {
      cmMemcpy((U8 *)&(conCb->conFd), (U8 *)&sockd,
               (U32) sizeof(CmInetFd));
   }
#else 
   cmMemcpy((U8 *)&(conCb->conFd), (U8 *)&sockd,
            (U32) sizeof(CmInetFd));
#endif /* HI_REL_1_3 */  

   conCb->isInList =  HI_CONCB_IN_NOLIST;

#ifdef HI_REL_1_3  
   conCb->hdrIncldFlag = 0;      
   conCb->protocol = protocol;

   if(notSupported)
   {
      conCb->hdrIncldFlag |= HI_HDRINCLD_NT_SUPPORTED; 
   }
   else
   {
      /*  Set ipHdrIncld flag for Raw socket if header include option is 
       *  present in tPar */ 
      if (conCb->flag & HI_FL_RAW)
      {
         for (i = 0; i < tPar->u.sockParam.numOpts; i++)
         {
            CmSockOpts *sOpts = &(tPar->u.sockParam.sockOpts[i]);
            if (sOpts->option == CM_SOCKOPT_OPT_HDRINCLD)
            {
               conCb->hdrIncldFlag |= HI_INCLUDE_HDR;
               break;
            }
         }
      }
   }

   /* hi009.104 - set this flag to TRUE  */ 
   /* mark that IPV6 extension headers are expected in the received IP packet */
#ifdef IPV6_OPTS_SUPPORTED
   if (protocol == CM_PROTOCOL_RSVP && servTAddr->type == CM_TPTADDR_IPV6)
      conCb->ipv6OptsReq = TRUE;
#endif /* IPV6_OPTS_SUPPORTED */  

#endif /* HI_REL_1_3 */    

   if (type == CM_INET_STREAM) /* case of TCP server */
   {
      conCb->conState = HI_ST_SRV_LISTEN;
   }
   else
   {
      conCb->conState = HI_ST_CONNECTED;
   }

   /* Obtain a new connection id */
   ret = hiGetConId(sap, conCb);
   if (ret != ROK)
   {  
#ifdef HI_REL_1_3
      if (protocol != CM_PROTOCOL_ICMP)
      {
         HI_CLOSE_SOCKET(&sockd); /* close the socket */
      }
#else   
      HI_CLOSE_SOCKET(&sockd);
#endif /* HI_REL_1_3 */ 
      HI_FREE(sizeof(HiConCb), conCb);
      HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_CONID_NOT_AVAIL);
      hiSendAlarm(LCM_CATEGORY_INTERNAL, LHI_EVENT_SERVOPENREQ,   
                  LHI_CAUSE_CONID_NOT_AVAIL, &info);
      RETVALUE(RFAILED);
   }

   /* Insert the new connection block in the sap hash list */
   ret = cmHashListInsert(&sap->sapHlCp, (PTR)conCb, (U8 *)&conCb->spConId, 
                          sizeof(UConnId));
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI029, (ErrVal) ret, pst->dstInst,
                 "HiUiHitServOpenReq() :failed to insert in sap hash list");
#ifdef HI_REL_1_3
      if (protocol != CM_PROTOCOL_ICMP)
      {
         HI_CLOSE_SOCKET(&conCb->conFd); /* close the socket */
      }
#else  
      HI_CLOSE_SOCKET(&conCb->conFd); /* close the socket */
#endif /* HI_REL_1_3 */ 

#ifdef HI_MULTI_THREADED
      hiRmvFrmSpConIdHl(conCb);
#endif /* HI_MULTI_THREADED */
      HI_FREE(sizeof(HiConCb), conCb); 
      HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_INTERNAL_ERR);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */

#ifdef HI_LPBK
   HI_LPBK_INIT_TPTADDR(servTAddr);
   ret = hiLpBkInsServInLst(conCb, servTAddr, tPar);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }
   cmMemcpy((U8*)&locTptAddr, (U8*)servTAddr, (U32) sizeof(CmTptAddr));
#else 

#ifdef HI_REL_1_3  
   if (protocol != CM_PROTOCOL_ICMP)
   {
      ret = hiGetFdBlkIdx(conCb, &conCb->fdBlkIdx);
   }
#else  
   ret = hiGetFdBlkIdx(conCb, &conCb->fdBlkIdx);
#endif /* HI_REL_1_3 */ 
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI030, (ErrVal)ret, pst->dstInst,
                 "HiUiHitServOpenReq() : failed to get fdBlkIdx \n");
      cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
#ifdef HI_REL_1_3
      if (protocol != CM_PROTOCOL_ICMP)
      {
         HI_CLOSE_SOCKET(&sockd); /* close the socket */
      }
#else   
      HI_CLOSE_SOCKET(&sockd);
#endif /* HI_REL_1_3 */ 

#ifdef HI_MULTI_THREADED
      hiRmvFrmSpConIdHl(conCb);
#endif /* HI_MULTI_THREADED */

      /* Deallocate the connection block */
      HI_FREE(sizeof(HiConCb), conCb);

      /* Issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_INTERNAL_ERR);

      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */

#ifdef HI_REL_1_3  
#ifdef IPV6_SUPPORTED 
   if ((icmpFilter->type == CM_ICMPVER4_FILTER) ||
       (icmpFilter->type == CM_ICMPVER6_FILTER))
#else
   if (icmpFilter->type == CM_ICMPVER4_FILTER)
#endif /* IPV6_SUPPORTED */
   {
      ret = hiProcessIcmpReq(conCb, icmpFilter);
      if(ret != ROK)
      {
         HILOGERROR_DEBUG(EHI031, (ErrVal)ret, pst->dstInst,
           "HiUiHitServOpenReq() : failed returned from hiProcessIcmpReq");

         if (protocol != CM_PROTOCOL_ICMP)
            HI_CLOSE_SOCKET(&sockd); /* close the socket */

         cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
         hiDecNumFds(conCb, conCb->fdBlkIdx);
#ifdef HI_MULTI_THREADED
         hiRmvFrmSpConIdHl(conCb);
#endif /* HI_MULTI_THREADED */
         HI_FREE(sizeof(HiConCb), conCb);
         HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_INTERNAL_ERR);
         RETVALUE(RFAILED);
      }
   }
#endif /* HI_REL_1_3 */

   /* Copy the local transport address in the conCb */
   cmMemcpy((U8*)&conCb->locTptAddr, (U8*)&locTptAddr, 
            (U32) sizeof(CmTptAddr));

   /* Add this socket to enable polling for new TCP connections for TCP 
    * servers and for UDP datagrams for UDP servers */
#ifdef HI_REL_1_3  
   if (protocol != CM_PROTOCOL_ICMP)
   {
#ifdef HI_MULTI_THREADED
      conCb->sendConCfm = TRUE;
#endif /* HI_MULTI_THREADED */
      ret = hiFdSet(conCb);
   }
#else  
   ret = hiFdSet(conCb);
#endif /* HI_REL_1_3 */ 
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI032, (ErrVal)ret, pst->dstInst,
                 "HiUiHitServOpenReq() :failed to insert socket in fd_set");
      
      /* Delete the conCb from the sap hash list */
      cmHashListDelete(&sap->sapHlCp, (PTR) conCb);

#ifdef HI_REL_1_3
      if (protocol != CM_PROTOCOL_ICMP)
      {
         HI_CLOSE_SOCKET(&sockd); /* close the socket */
      }

#ifdef IPV6_SUPPORTED
      if (conCb->icmp6Mask)
         hiCloseIcmpSock(conCb, CM_NETADDR_IPV6);
      else if (conCb->icmpMask)
         hiCloseIcmpSock(conCb, CM_NETADDR_IPV4);
#else
      if (conCb->icmpMask)
         hiCloseIcmpSock(conCb, CM_NETADDR_IPV4);
#endif /* IPV6_SUPPORTED */

#ifdef HI_MULTI_THREADED
      hiRmvFrmSpConIdHl(conCb);
#endif /* HI_MULTI_THREADED */

#else   
      /* Close the socket */
      HI_CLOSE_SOCKET(&sockd);
#endif /* HI_REL_1_3 */ 
      
      hiDecNumFds(conCb, conCb->fdBlkIdx);

      /* Deallocate the connection block */
      HI_FREE(sizeof(HiConCb), conCb);

      /* Issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, servConId, HI_INTERNAL_ERR);

      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */
#endif /* HI_LPBK */
  
   /* Increment the statistics counters */
   sap->genTxSts.numCons++;
   sap->txSts.numCons++;

#ifndef HI_MULTI_THREADED
    /* Issue a Connect confirm to the Upper Layer */
   HiUiHitConCfm(&sap->uiPst, sap->suId, servConId, conCb->spConId, 
                 &locTptAddr);
#endif /* HI_MULTI_THREADED */

   RETVALUE(ROK);

} /* end of HiUiHitServOpenReq */

/*
*
*       Fun:   Primitive to Open a new TCP or UDP client
*
*       Desc:  This primitive is used by the service user to open 
*              a new TCP client connection.
*
*              The socket is bound to the "localAddr" specified 
*              ( if any). The TCP client socket is then connected 
*              to the "remAddr". 
*
*              "remAddr" specifies the server's well known address and
*              port.
*
*              "localAddr" specifies the local address to which the 
*              client may bind.
*
*              In case RINPROGRESS is returned from the connect call
*              the connection state is changed to HI_ST_CLT_CONNECTING.
*              Once the connection is completed a connection confirm is
*              given to the upper user. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: By default, the socket is non blocking. The TUCL layer 
*              does not validate the local/remote addresses specified
*              by the user.
*              TUCL will send a HiUiHitDiscInd to the user in 
*              case of any socket /memory/ or any other errors and it
*              will close the socket and relinquish resources (if 
*              allocated). 
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiHitConReq
(
Pst *pst,                  /* post structure */ 
SpId spId,                 /* service provider id */ 
UConnId suConId,           /* service user's connection id */ 
CmTptAddr *remAddr,        /* address of the server */ 
CmTptAddr *localAddr,      /* local address */
CmTptParam *tPar,          /* transport parameters */
U8  srvcType               /* service type */
)
#else
PUBLIC S16 HiUiHitConReq(pst, spId, suConId, remAddr, localAddr, tPar, 
                         srvcType) 
Pst *pst;                  /* post structure */ 
SpId spId;                 /* service provider id */ 
UConnId suConId;           /* service user's connection id */ 
CmTptAddr  *remAddr;       /* address of the server */ 
CmTptAddr  *localAddr;     /* local address */
CmTptParam *tPar;          /* transport parameters */
U8  srvcType;              /* service type */
#endif
{

   HiSap          *sap;
   HiConCb        *conCb;
   HiAlarmInfo    info;
   CmInetFd       sockd;
   CmTptAddr      locTptAddr;
   U32            protType;
   U8             type;
#ifdef HI_LPBK
   HiConCb        *srvConCb;
   HiConCb        *newConCb;
   U8             idx;
   Bool           found;
   CmTptAddr      anyAddr;
#endif /* HI_LPBK */
   S16            retCon;
   S16            ret;
   Bool           isUdpClt;
#ifdef HI_REL_1_3
   U8             tmpSrvcType;
#endif /* HI_REL_1_3*/

#ifdef FTHA
   HiConCb        *prevConCb;
#endif /* FTHA */

   TRC3(HiUiHitConReq)

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "HiUiHitConReq() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

#ifndef SS_MULTIPLE_PROCS   
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */

#ifdef H323_PERF
   TAKE_TIMESTAMP("L/T ConReq HC->HI, in HI");
#endif /* H323_PERF */

   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
          "HiUiHitConReq(pst, spId(%d), suConId(%ld), remAddr(%p), \
           localAddr(%p), tPar(%p), srvcType(%d))\n", spId, suConId,
           remAddr, localAddr, tPar, srvcType));

   retCon = ROK;
   isUdpClt = FALSE;
   
#ifdef HI_LPBK
   idx   = 0;
   found = FALSE;
   /* initialize both local and remote transport addresses */
   HI_LPBK_INIT_TPTADDR(remAddr);
   HI_LPBK_INIT_TPTADDR(localAddr);
#endif /* HI_LPBK */

   /* Initialize info */
   info.spId = spId;
   info.type = LHI_ALARMINFO_TYPE_NTPRSNT;

#ifdef HI_REL_1_3 
   tmpSrvcType = 0;
   tmpSrvcType = srvcType & 0x0f;
#endif /* HI_REL_1_3 */

   /* hi026.104 - Initializtion */
   if(tPar->type == CM_TPTPARAM_NOTPRSNT )
      tPar->u.sockParam.numOpts=0;

   /* Validation of input parameters */
#if (ERRCLASS & ERRCLS_INT_PAR)
   HI_CHK_SPID(spId, LHI_EVENT_CONREQ, ret, info);
   if(ret != ROK)
   {
      HILOGERROR_INT_PAR(EHI033, (ErrVal)spId, pst->dstInst,
                 "HiUiHitConReq(): invalid spId");
      RETVALUE(RFAILED);
   }

#ifdef HI_REL_1_3
   if ((tmpSrvcType != HI_SRVC_UDP) && (tmpSrvcType != HI_SRVC_UDP_TPKT_HDR)
       && (tmpSrvcType != HI_SRVC_TCP_TPKT_HDR) && 
       (tmpSrvcType != HI_SRVC_TCP_NO_HDR))
   {
      HILOGERROR_INT_PAR(EHI034, (ErrVal)srvcType, pst->dstInst,
                 "HiUiHitConReq(): invalid service type");
      RETVALUE(RFAILED);
   } 
#else 
   if ((srvcType != HI_SRVC_UDP) && (srvcType != HI_SRVC_TCP)
                                    && (srvcType != HI_SRVC_TCP_TPKT_HDR))
   {
      HILOGERROR_INT_PAR(EHI035, (ErrVal)srvcType, pst->dstInst,
                 "HiUiHitConReq(): invalid service type");
      RETVALUE(RFAILED);
   } 
#endif /* HI_REL_1_3 */
#endif /* ERRCLS_INT_PAR */

#ifdef HI_REL_1_3
   switch(tmpSrvcType)
   {
      case HI_SRVC_UDP: 
      case HI_SRVC_UDP_TPKT_HDR:
      case HI_SRVC_UDP_PRIOR:
         protType = HI_FL_UDP;
         type = CM_INET_DGRAM;
         break;

      case HI_SRVC_TCP_TPKT_HDR: 
      case HI_SRVC_TCP_NO_HDR:
      default:
         protType = HI_FL_TCP;
         type = CM_INET_STREAM;
         break;
   }
#else
   if ((srvcType == HI_SRVC_UDP) || (srvcType == HI_SRVC_UDP_PRIOR))
   {
      protType = HI_FL_UDP;
      type = CM_INET_DGRAM;
   }
   else
   {
      protType = HI_FL_TCP;
      type = CM_INET_STREAM;
   }
#endif /* HI_REL_1_3 */
   
   sap = hiCb.sapLstPtr[spId];
#if (ERRCLASS & ERRCLS_INT_PAR)
   if(sap->state != HI_ST_BND)
   {
      HILOGERROR_INT_PAR(EHI036, (ErrVal) sap->state, pst->dstInst,
                 "HiUiHitConReq(): Sap not Bound");

      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_INV_SAP_STATE);

      HI_FILL_ALARMINFO_SAP_STATE(info, sap->state);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_CONREQ,
                  LCM_CAUSE_INV_STATE, &info);
      RETVALUE(RFAILED);
   }

   /* Added a check for TCP clients only
    * for UDP remAddr is insignificant */
#ifdef IPV6_SUPPORTED
   if((type == CM_INET_STREAM) && ((!remAddr) ||
                 ((remAddr->type != CM_TPTADDR_IPV4) &&
                  (remAddr->type != CM_TPTADDR_IPV6))))
#else
   if((type == CM_INET_STREAM) && ((!remAddr) || 
                 (remAddr->type != CM_TPTADDR_IPV4)))
#endif /* IPV6_SUPPORTED */
   {
      HILOGERROR_INT_PAR(EHI037, (ErrVal) remAddr->type, pst->dstInst,
                 "HiUiHitConReq(): Invalid remote address");

      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_INV_PAR_VAL);

      HI_FILL_ALARMINFO_PAR_TYPE(info, LHI_INV_TPT_ADDR);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_CONREQ,
                       LCM_CAUSE_INV_PAR_VAL, &info);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* hi016.104: needs to first check the resource 
    * before checking the flag */
   hiChkRes(sap);
   /* check for resource availability */
   if(sap->resCongStrt)
   {
      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_OUTOF_RES);
      RETVALUE(RFAILED);
   }

#ifdef H323_PERF
   TAKE_TIMESTAMP("L/T cmInet-calls strt, in HI");
#endif /* H323_PERF */

#ifndef HI_LPBK 

   /* open a new socket */
#ifdef HI_REL_1_3  
#ifdef IPV6_SUPPORTED
   if (remAddr->type == CM_TPTADDR_IPV6)
      ret = cmInetSocket(type, &sockd, 0, CM_INET_IPV6_DOMAIN);
   else
      ret = cmInetSocket(type, &sockd, 0, CM_INET_IPV4_DOMAIN);
#else
   ret = cmInetSocket(type, &sockd, 0);
#endif /* IPV6_SUPPORTED */
#else   
   ret = cmInetSocket(type, &sockd);
#endif /* HI_REL_1_3 */ 
   if (ret != ROK)
   {
#ifdef HI_MULTI_THREADED
      HI_LOCK(&hiCb.errStsLock, info, ret); 
      if (ret != ROK)
         HILOGERROR_DEBUG(EHI038, (ErrVal) 0, pst->dstInst, 
               "HiUiHitConReq () : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */

      /* increment the statistics counter */
      hiCb.errSts.sockOpenErr++;

#ifdef HI_MULTI_THREADED
      HI_UNLOCK(&hiCb.errStsLock, info, ret);
      if (ret != ROK)
         HILOGERROR_DEBUG(EHI039, (ErrVal) 0, pst->dstInst, 
            "HiUiHitConReq () : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */

#if (ERRCLASS & ERRCLS_ADD_RES)
      HILOGERROR_ADD_RES( EHI040, (ErrVal) ret, pst->dstInst,
                "HiUiHitConReq: failed to open socket");
#endif /* ERRCLS_ADD_RES */

      /* issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_SOCK_OPEN_ERR);
      RETVALUE(RFAILED);
   }

#ifdef IPV6_SUPPORTED
   if ((localAddr) && ((localAddr->type == CM_TPTADDR_IPV4) ||
                       (localAddr->type == CM_TPTADDR_IPV6)))
#else
   if ((localAddr) && (localAddr->type == CM_TPTADDR_IPV4))
#endif /* IPV6_SUPPORTED */
   {
      HI_SET_SOCKOPT_REUSEADDR(&sockd);

      /* bind the TCP socket to the local address */
#ifdef IPV6_SUPPORTED
      ret = cmInetBind(&sockd, (CmInetAddr *)localAddr);
#else
      ret = cmInetBind(&sockd, &(localAddr->u.ipv4TptAddr));
#endif /* IPV6_SUPPORTED */
      if (ret != ROK)
      {
#ifdef FTHA
         /* There may be a duplicate serv open req on the same source address
          * as a previous server open request. This may happen in case
          * of fault tolerant upper layers. Beware if the upper layer has 
          * an implementation error the duplicate ServOpenReq will go through!!!
          */

         /* Go through the sap hash list and check the locTptAddr with the
          * address got in this request. */
         conCb = prevConCb = NULLP;

         while((ret = cmHashListGetNext(&(sap->sapHlCp), (PTR )prevConCb,
                                        (PTR *)&(conCb))) == ROK)           
         {
#ifdef IPV6_SUPPORTED
            if ((cmMemcmp((U8 *)localAddr, 
                          (U8 *) &conCb->locTptAddr,
                         sizeof(conCb->locTptAddr))) == 0)
#else
            if ((cmMemcmp((U8 *) &localAddr->u.ipv4TptAddr,
                          (U8 *) &conCb->locTptAddr.u.ipv4TptAddr,
                         sizeof(localAddr->u.ipv4TptAddr))) == 0)
#endif /* IPV6_SUPPORTED */
            {
               /* Check if this is a server */
               if ((conCb->flag & HI_FL_CLT) &&
                   (conCb->srvcType == srvcType))  
               { 
                  /* Store the new suConId in the conCb */
                  conCb->suConId = suConId;

                  /* Issue a Connect confirm to the Upper Layer */
                  HiUiHitConCfm(&sap->uiPst, sap->suId, 
                                suConId, conCb->spConId, &conCb->locTptAddr);
                  RETVALUE(ROK);
               }
            }
            /* Get the next conCb */
            prevConCb = conCb;
         }
#endif /* FTHA */

#ifdef HI_MULTI_THREADED
         HI_LOCK(&hiCb.errStsLock, info, ret); 
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI041, (ErrVal) 0, pst->dstInst, 
                  "HiUiHitConReq () : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */

         /* increment the statistics counters */
         hiCb.errSts.sockBindErr++;

#ifdef HI_MULTI_THREADED
         HI_UNLOCK(&hiCb.errStsLock, info, ret);
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI042, (ErrVal) 0, pst->dstInst, 
               "HiUiHitConReq () : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */
                        
         /* close the socket */
         HI_CLOSE_SOCKET(&sockd);

         /* issue an indication to the upper layer */
         HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_SOCK_BIND_ERR);
         RETVALUE(RFAILED);
      }
   }/* end if */

   /* set the specified socket options */
   ret = hiSetSockOpt(&sockd, tPar);
   if(ret != ROK)
   {
      HILOGERROR_DEBUG( EHI043, ret, pst->dstInst,
                 "HiUiHitConReq: Failed to set socket options");
      /* close the socket */
      HI_CLOSE_SOCKET(&sockd);

      /* issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_SOCK_SOPT_ERR);
      RETVALUE(RFAILED);
   }/* end if tPar->type */

   if(type == CM_INET_STREAM)
   {
      /* apply the CM_SOCKOPT_OPT_TCP_NODELAY option */
      HI_SET_SOCKOPT_TCP_NODELAY(&sockd);

      /* connect the TCP client's socket to the server's address */
#ifdef IPV6_SUPPORTED
      retCon = cmInetConnect(&sockd, (CmInetAddr *)remAddr);
#else
      retCon = cmInetConnect(&sockd, &(remAddr->u.ipv4TptAddr));
#endif /* IPV6_SUPPORTED */
      if(retCon == RFAILED)
      {
#ifdef HI_MULTI_THREADED
         HI_LOCK(&hiCb.errStsLock, info, ret); 
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI044, (ErrVal) 0, pst->dstInst, 
                  "HiUiHitConReq () : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */

         /* increment the statistics counters */
         hiCb.errSts.sockCnctErr++;

#ifdef HI_MULTI_THREADED
         HI_UNLOCK(&hiCb.errStsLock, info, ret);
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI045, (ErrVal) 0, pst->dstInst, 
               "HiUiHitConReq () : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */    

         /* close the socket */
         HI_CLOSE_SOCKET(&sockd);

         /* issue an indication to the upper layer */
         HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_SOCK_CONN_ERR);
         RETVALUE(RFAILED);
      }
      /* Check for Connection refused errors */
      else if (retCon == RCLOSED)
      {
         /* close the socket */
         HI_CLOSE_SOCKET(&sockd);

         /* issue an indication to the upper layer */
         HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_CON_CLOSED_BY_PEER);
         RETVALUE(RFAILED);
      }
   }

   else if (type == CM_INET_DGRAM) /* for UDP clients */
   {
      /* Call connect if a valid address is present */
#ifdef IPV6_SUPPORTED
      if ((remAddr) && ((remAddr->type == CM_TPTADDR_IPV4) ||
                        (remAddr->type == CM_TPTADDR_IPV6)))
#else
      if ((remAddr) && (remAddr->type == CM_TPTADDR_IPV4))
#endif /* IPV6_SUPPORTED */
      {
         /* If a valid address is present go ahead and connect */
#ifdef IPV6_SUPPORTED
         retCon = cmInetConnect(&sockd, (CmInetAddr *)remAddr);
#else
         retCon = cmInetConnect(&sockd, &(remAddr->u.ipv4TptAddr));
#endif /* IPV6_SUPPORTED */
         /* The UDP socket connect should not block */
         if(retCon != ROK)
         {
#ifdef HI_MULTI_THREADED
            HI_LOCK(&hiCb.errStsLock, info, ret); 
            if (ret != ROK)
               HILOGERROR_DEBUG(EHI046, (ErrVal) 0, pst->dstInst, 
                     "HiUiHitConReq () : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */

            /* increment the statistics counters */
            hiCb.errSts.sockCnctErr++;

#ifdef HI_MULTI_THREADED
            HI_UNLOCK(&hiCb.errStsLock, info, ret);
            if (ret != ROK)
               HILOGERROR_DEBUG(EHI047, (ErrVal) 0, pst->dstInst, 
                    "HiUiHitConReq () : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */    

            /* close the socket */
            HI_CLOSE_SOCKET(&sockd);

            /* issue an indication to the upper layer */
            HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_SOCK_CONN_ERR);
            RETVALUE(RFAILED);
         }
         /* This is a true UDP client */
         isUdpClt = TRUE;
      }
   }

   /* get the local address associated with the socket */
   if(retCon == ROK)
   {
      /* initialize the local address type filed */
#ifndef IPV6_SUPPORTED
      locTptAddr.type = CM_TPTADDR_IPV4;
#endif /* IPV6_SUPPORTED */

#ifdef IPV6_SUPPORTED
      ret = cmInetGetSockName(&sockd, (CmInetAddr *)&locTptAddr);
#else
      ret = cmInetGetSockName(&sockd, &(locTptAddr.u.ipv4TptAddr));
#endif /* IPV6_SUPPORTED */
      if (ret != ROK)
      {
         HI_CLOSE_SOCKET(&sockd);
         HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_SOCK_NAME_ERR);
         RETVALUE(RFAILED);
      }
   }
#endif /* HI_LPBK */

#ifdef H323_PERF
   TAKE_TIMESTAMP("L/T cmInet-calls end, in HI");
#endif /* H323_PERF */

   /* Obtain a new connection block */
   HI_ALLOC(sizeof(HiConCb), conCb)
   if(!conCb)
   {
      /* close the socket */
      HI_CLOSE_SOCKET(&sockd);

      /* issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_SMEM_ALLOC_ERR);

      /* fill up the alarm information */
      HI_FILL_ALARMINFO_MEM_ID(info, hiCb.hiInit.region, hiCb.hiInit.pool);
      hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_SMEM_ALLOC_FAIL,
                  LCM_CAUSE_UNKNOWN, &info);
      RETVALUE(RFAILED);
   }

   conCb->isInList = HI_CONCB_IN_NOLIST;

   /* fill up the new connection  block obtained */
   if ((retCon == RINPROGRESS) || (retCon == ROKDNA) || 
       (retCon == RWOULDBLOCK))
   {
       /* The connection could not be completed, so the state is
        * changed to connecting. This connection control block is 
        * inserted in the write and read file descriptor set later. 
        * When the connection is complete a connection confirm primitive
        * will be sent to the upper user.
        */
       conCb->conState = HI_ST_CLT_CONNECTING;
   }
   else
   {
       /* ROK or RISCONN */
       conCb->conState = HI_ST_CONNECTED;
   }

#ifdef HI_MULTI_THREADED
   if (protType == HI_FL_TCP)
   {
      /* Initialise the conCb transmit Q lock */
      ret = SInitLock(&conCb->txQLockId, SS_LOCK_MUTEX);
      if (ret != ROK)
      {
         HILOGERROR_DEBUG(EHI048, (ErrVal)ret, pst->dstInst,
               "HiUiHitConReq - Failed to initialise tx Q lock \n");

         HI_CLOSE_SOCKET(&sockd);
      
         /* deallocate the connection block */
         HI_FREE(sizeof(HiConCb), conCb);

         /* issue an indication to the upper layer */
         HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_INTERNAL_ERR);
      
         hiSendAlarm(LCM_CATEGORY_INTERNAL, LHI_EVENT_CONREQ,      
                     LHI_CAUSE_INITLOCK_ERR, &info);
         RETVALUE(RFAILED);
      }
   }
#endif /* HI_MULTI_THREADED */

   conCb->suConId  =  suConId;
   conCb->sap      =  sap;
   /* hi004.104 - TOS parameter initialized to zero */
#ifdef HI_REL_1_3
   conCb->ipTos    = 0;
#endif /* HI_REL_1_3 */
   
   if (isUdpClt)
      conCb->flag  |= (protType | HI_FL_UDP_CLT);
   else
      conCb->flag  |= (protType | HI_FL_CLT);

   /* Set the priority flag */
   if (srvcType == HI_SRVC_UDP_PRIOR)
   {
      conCb->flag    |= HI_FL_PRIOR;
      conCb->srvcType = HI_SRVC_UDP;
   }
   else
      conCb->srvcType = srvcType;

   cmMemcpy((U8 *)&(conCb->conFd), (U8 *)&sockd,
            (U32) sizeof(CmInetFd));

   /* store the server's address: needed in hiScanPermTsk
    * when trying for re-connection 
    */
   cmMemcpy((U8*)&(conCb->peerAddr), (U8*)remAddr, sizeof(CmTptAddr));

   /* obtain a new connection id */
   ret = hiGetConId(sap, conCb);
   if(ret != ROK)
   {
      /* close the socket */
      HI_CLOSE_SOCKET(&sockd);

#ifdef HI_MULTI_THREADED
      SDestroyLock(&conCb->txQLockId);
#endif /* HI_MULTI_THREADED */

      /* deallocate the connection block */
      HI_FREE(sizeof(HiConCb), conCb);

      /* issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_CONID_NOT_AVAIL);

      /* fill up the alarm information */
      HI_FILL_ALARMINFO_MEM_ID(info, hiCb.hiInit.region, hiCb.hiInit.pool);

      hiSendAlarm(LCM_CATEGORY_INTERNAL, LHI_EVENT_CONREQ, 
                  LHI_CAUSE_CONID_NOT_AVAIL, &info);
      RETVALUE(RFAILED);   
   }

   /* insert the new connection block in the hash list */
   ret = cmHashListInsert(&sap->sapHlCp, (PTR)conCb, (U8 *)&conCb->spConId, 
                          sizeof(UConnId));
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI049, (ErrVal) ret, pst->dstInst,
                 "HiUiHitConReq() :failed to insert in hash list");

      /* de-allocate the connection block allocated */
      /* close the socket */
      HI_CLOSE_SOCKET(&sockd);
     
#ifdef HI_MULTI_THREADED
      SDestroyLock(&conCb->txQLockId);
      hiRmvFrmSpConIdHl(conCb);
#endif /* HI_MULTI_THREADED */

      /* deallocate the connection block */
      HI_FREE(sizeof(HiConCb), conCb);

      /* issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_INTERNAL_ERR);

      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */

   /* increment the statistics counters */
   sap->genTxSts.numCons++;
   sap->txSts.numCons++;

   /* only TCP clients can receive data 
    * or have pending data to write */
   if(type == CM_INET_STREAM)
      /* Initialize the transmit queue */
      SInitQueue(&conCb->txQ);

#ifndef HI_LPBK

   /* Get a file descriptor block index */
   ret = hiGetFdBlkIdx(conCb, &conCb->fdBlkIdx);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI050, (ErrVal)ret, pst->dstInst,
                 "HiUIHitConReq() : failed to get fdBlkIdx ");
      /* close the socket */
      HI_CLOSE_SOCKET(&sockd);
      cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
#ifdef HI_MULTI_THREADED
      hiRmvFrmSpConIdHl(conCb);
      SDestroyLock(&conCb->txQLockId);
#endif /* HI_MULTI_THREADED */
      /* deallocate the connection block */
      HI_FREE(sizeof(HiConCb), conCb);
      /* Issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_INTERNAL_ERR);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */

   if (retCon == ROK)
      /* Copy the local transport address in the conCb */
      cmMemcpy((U8*)&conCb->locTptAddr, (U8*)&locTptAddr, 
               (U32) sizeof(CmTptAddr));

#ifdef HI_MULTI_THREADED
   conCb->sendConCfm = TRUE;
#endif /* HI_MULTI_THREADED */

   /* set this socket in a file descriptor set */
   ret = hiFdSet(conCb);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI051, (ErrVal)ret, pst->dstInst,
                 "HiUIHitConReq() :failed to insert socket in fd_set ");

      /* close the socket */
      HI_CLOSE_SOCKET(&sockd);
      cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
#ifdef HI_MULTI_THREADED
      hiRmvFrmSpConIdHl(conCb);
      SDestroyLock(&conCb->txQLockId);
#endif /* HI_MULTI_THREADED */
      hiDecNumFds(conCb, conCb->fdBlkIdx);
      /* deallocate the connection block */
      HI_FREE(sizeof(HiConCb), conCb);
      /* Issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_INTERNAL_ERR);
      RETVALUE(RFAILED);
   }

#else
   
   /* loopback mode processing */

   /* local address is required both for TCP and UDP clients
    * in LPBK mode
    */
   if(!localAddr->type)
      localAddr->type = CM_TPTADDR_IPV4;

   cmMemcpy((U8*)&(conCb->locAddr), (U8*)localAddr, 
            (U32) sizeof(CmTptAddr));
   cmMemcpy((U8*)&locTptAddr, (U8*)localAddr, 
            (U32) sizeof(CmTptAddr));
   HI_ZERO(&(conCb->conFd), (U32) sizeof(CmInetFd));

   /* insert the client block in the address hash list */
   ret = cmHashListInsert(&hiCb.locAddrHlCp, (PTR)conCb, 
                          (U8*)&(conCb->locAddr.u.ipv4TptAddr),
                          sizeof(CmIpv4TptAddr));
   if(ret != ROK)
   {
      HILOGERROR_DEBUG( EHI052, (ErrVal) ret, pst->dstInst,
                 "HiUiHitConReq() :failed to insert in address hash list");
      hiFreeConCb(conCb);
      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_INTERNAL_ERR);
      RETVALUE(RFAILED);
   }

   if(type == CM_INET_STREAM) /* for TCP clients only */
   {
      /* find the connection block of the TCP server */
      while((ret = cmHashListFind(&hiCb.locAddrHlCp, 
                                  (U8 *)&(remAddr->u.ipv4TptAddr), 
                                  sizeof(CmIpv4TptAddr), idx++, 
                                  (PTR *)&srvConCb)) == ROK)
      {
         if(srvConCb->conState == HI_ST_SRV_LISTEN)
         {
            found = TRUE;
            break;
         }
      }

      /* check if a server is opened listening on address CM_INADDR_ANY */
      if (!found)
      {
         HI_ZERO(&anyAddr, sizeof(CmTptAddr));

         cmMemcpy((U8*)&anyAddr, (U8*)remAddr, sizeof(CmTptAddr));

         idx = 0;

         anyAddr.u.ipv4TptAddr.address = CM_INADDR_ANY;
      
         while((ret = cmHashListFind(&hiCb.locAddrHlCp, 
                                    (U8 *)&(anyAddr.u.ipv4TptAddr), 
                                    sizeof(CmIpv4TptAddr), idx++, 
                                    (PTR *)&srvConCb)) == ROK)
         {
            if(srvConCb->conState == HI_ST_SRV_LISTEN)
            {
               found = TRUE;
               break;
            }
         }
      }

      if(found)
      {
         sap = srvConCb->sap;

         /* allocate a new block for the accepted connection */
         HI_ALLOC(sizeof(HiConCb), newConCb)
         if(!newConCb)
         {
            /* issue an indication to the upper layer */
            HI_DISCIND(sap, HI_USER_CON_ID, srvConCb->suConId, 
                       HI_SMEM_ALLOC_ERR);

            /* fill up the alarm information */
            HI_FILL_ALARMINFO_MEM_ID(info, hiCb.hiInit.region, 
                                     hiCb.hiInit.pool);
            hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_SMEM_ALLOC_FAIL,
                        LCM_CAUSE_UNKNOWN, &info);
            RETVALUE(RFAILED);
         }

         /* fill up the new connection  block obtained */
         newConCb->conState  =  HI_ST_AW_CON_RSP;

         /* the suConId is obtained in HiUiHitConRsp */
         newConCb->sap      =  srvConCb->sap;
         newConCb->flag     =  srvConCb->flag;
         newConCb->srvcType =  srvConCb->srvcType;
         newConCb->isInList =  HI_CONCB_IN_NOLIST;
 
         ret = hiGetConId(sap, newConCb);
         if(ret != ROK)
         {
            /* Deallocate the connection block */
            HI_FREE(sizeof(HiConCb), newConCb);

            hiSendAlarm(LCM_CATEGORY_INTERNAL, LHI_EVENT_CONREQ, 
                        LHI_CAUSE_CONID_NOT_AVAIL, &info);
            RETVALUE(RFAILED);
         }

         cmMemcpy((U8*)&newConCb->peerAddr, (U8*)localAddr, 
                  sizeof(CmTptAddr));
         cmMemcpy((U8*)&newConCb->locAddr,  (U8*)remAddr, 
                  sizeof(CmTptAddr));

         /* insert the new connection block in the hash lists */
         ret = cmHashListInsert(&sap->sapHlCp, (PTR)newConCb,
                                (U8 *)&newConCb->spConId, sizeof(UConnId));
         if(ret != ROK)
         {
            HILOGERROR_DEBUG( EHI053, (ErrVal) ret, pst->dstInst,
                    "HiUiHitServOpenReq():failed to insert in hash list");
            hiFreeConCb(newConCb);
            RETVALUE(RFAILED);
         }

         ret = cmHashListInsert(&hiCb.locAddrHlCp, (PTR)newConCb, 
                                (U8 *)&(newConCb->locAddr.u.ipv4TptAddr), 
                                sizeof(CmIpv4TptAddr));
         if(ret != ROK)
         {
            HILOGERROR_DEBUG( EHI054, (ErrVal) ret, pst->dstInst,
                    "HiUiHitServOpenReq():failed to insert in addr hash list");
            hiFreeConCb(newConCb);
            RETVALUE(RFAILED);
         }

         /* increment the statistics counters */
         sap->txSts.numCons++;
         sap->genTxSts.numCons++;

         /* localAddr should be specified in loopback cases */
         HiUiHitConInd(&newConCb->sap->uiPst, newConCb->sap->suId, 
                       srvConCb->suConId, newConCb->spConId,
                       &newConCb->peerAddr);
      }/* end if found */
      else
      {
         /* server connection block not found => invalid remAddr */
         hiFreeConCb(conCb);
         HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_SOCK_CONN_ERR);
         hiSendAlarm(LCM_CATEGORY_INTERNAL, LHI_EVENT_INET_ERR,
                     LHI_CAUSE_SOCK_CONN_ERR, &info);
         RETVALUE(RFAILED);
      }
   } /* end of if CM_INET_STREAM */
#endif /* HI_LPBK */

   /* In case of multi threaded cases the receive thread will give the 
    * connection confirm */
#ifndef HI_MULTI_THREADED
   if(conCb->conState == HI_ST_CONNECTED)
   {
      /* issue a Connect confirm to the Upper Layer */
      HiUiHitConCfm(&sap->uiPst, sap->suId, suConId, conCb->spConId, 
                    &locTptAddr);
   }
#endif /* HI_MULTI_THREADED */
   RETVALUE(ROK);
}/* end of HiUiHitConReq() */


/*
*
*       Fun:   Primitive to respond to a Connection Indication
*
*       Desc:  This primitive is used by the service user to accept 
*              the new TCP client connection as indicated by the 
*              connection indication (XxYyHitconInd) primitive.
*              The state of the connection is changed to "connected"
*              and the "suConId" is stored in the connection block.
*              Data may now be tranferred over this connection.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: If TUCL is not able to find the connection block
*              corresponding to "spConId", it silently returns. This may 
*              happen in case TUCL has already issued a XxYyHitDiscInd
*              for that connection and has released the connection
*              block.
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiHitConRsp
(
Pst *pst,                /* post structure */ 
SpId spId,               /* service provider id */ 
UConnId suConId,         /* service user's connection id */ 
UConnId spConId          /* service provider's connection id */
)
#else
PUBLIC S16 HiUiHitConRsp(pst, spId, suConId, spConId)
Pst *pst;                /* post structure */ 
SpId spId;               /* service provider id */ 
UConnId suConId;         /* service user's connection id */ 
UConnId spConId;         /* service provider's connection id */
#endif
{

   HiSap         *sap;
   HiConCb       *conCb; 
   HiAlarmInfo   info;
   S16           ret;
   
   TRC3(HiUiHitConRsp)

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "HiUiHitConRsp() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */

#ifdef H323_PERF
   TAKE_TIMESTAMP("L/T ConRsp HC->HI, in HI");
#endif /* H323_PERF */

   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
           "HiUiHitConRsp(pst, spId(%d), suConId(%ld), spConId(%ld))\n",
           spId, suConId, spConId));

   /* initialize alarm information */
   info.spId = spId;
   info.type = LHI_ALARMINFO_TYPE_NTPRSNT;

  /* validation of input parameters */
#if (ERRCLASS & ERRCLS_INT_PAR)
   HI_CHK_SPID(spId, LHI_EVENT_CONRSP, ret, info);
   if(ret != ROK)
   {
      HILOGERROR_INT_PAR( EHI055, (ErrVal)spId, pst->dstInst,
                 "HiUiHitConRsp(): invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   sap = hiCb.sapLstPtr[spId];
#if (ERRCLASS & ERRCLS_INT_PAR)
   if(sap->state != HI_ST_BND)
   {
      HILOGERROR_INT_PAR( EHI056, (ErrVal)sap->state, pst->dstInst,
                 "HiUiHitConRsp(): Sap not Bound");

      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_INV_SAP_STATE);

      HI_FILL_ALARMINFO_SAP_STATE(info, sap->state);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_CONRSP,
                  LCM_CAUSE_INV_STATE, &info);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* find the connection block */
#ifndef HI_MULTI_THREADED     
   ret = cmHashListFind (&sap->sapHlCp, (U8 *)&spConId, sizeof(UConnId), 
                         0, (PTR *)&conCb);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }
#else
   ret = hiFindConCbBySpConId(sap, &conCb, spConId);
   if (ret != ROK)
   {
      /* Issue a disconnect indication to the upper user */
      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_INV_PAR_VAL);

      RETVALUE(RFAILED);
   }

   /* Add the conCb in the sap hash list */
   ret = cmHashListInsert(&sap->sapHlCp, (PTR)conCb, (U8 *)&conCb->spConId, 
                          sizeof(UConnId));
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI057, (ErrVal) ret, sap->uiPst.srcInst,
                 "HiUiHitConRsp() : failed to insert in sap hash list");

      /* Remove conCb from the spConId hash list */
      hiRmvFrmSpConIdHl(conCb);
      
      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_INV_CON_STATE);

      RETVALUE(RFAILED);
   }
#endif /* HI_MULTI_THREADED      */

   /* check the connection state */
   if (conCb->conState != HI_ST_AW_CON_RSP)
   {
      cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
#ifdef HI_MULTI_THREADED
      hiRmvFrmSpConIdHl(conCb);
#else  /* HI_MULTI_THREADED */
      hiFreeConCb(conCb);
#endif /* HI_MULTI_THREADED */
      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_INV_CON_STATE);

      HI_FILL_ALARMINFO_CON_STATE(info, conCb->conState);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_CONRSP,
                  LHI_CAUSE_INV_CON_STATE, &info);
      RETVALUE(RFAILED);
   }

   /* store the suconId for the connection */
   conCb->suConId  = suConId;

   /* change the connection state to connected */
   conCb->conState = HI_ST_CONNECTED;

#ifndef HI_LPBK

#ifdef HI_MULTI_THREADED
   conCb->sendConCfm = FALSE;
#endif /* HI_MULTI_THREADED */

   ret = hiGetFdBlkIdx(conCb, &conCb->fdBlkIdx);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI058, (ErrVal)ret, pst->dstInst,
                 "HiUiHitConRsp() :failed to get fd blk idx ");

#ifdef HI_MULTI_THREADED
      cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
      hiRmvFrmSpConIdHl(conCb);
#else  /* HI_MULTI_THREADED */
      hiFreeConCb(conCb);
#endif /* HI_MULTI_THREADED */

      /* issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_INTERNAL_ERR);

      RETVALUE(RFAILED);
   }
   
   /* set the socket in a file descriptor set */
   ret = hiFdSet(conCb);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI059, (ErrVal)ret, pst->dstInst,
                 "HiUiHitConRsp() :failed to insert socket in fd_set");
#ifdef HI_MULTI_THREADED
      cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
      hiDecNumFds(conCb, conCb->fdBlkIdx);
      hiRmvFrmSpConIdHl(conCb);
#else  /* HI_MULTI_THREADED */
      hiFreeConCb(conCb);
#endif /* HI_MULTI_THREADED */

      /* issue an indication to the upper layer */
      HI_DISCIND(sap, HI_USER_CON_ID, suConId, HI_INTERNAL_ERR);

      RETVALUE(RFAILED);
   }

#endif /* HI_LPBK */

   /* Data transfer is now possible on this socket */
   
   RETVALUE(ROK);
}/* end of HiUiHitConRsp() */


/*
*
*       Fun:   Primitive to send TCP data on a connection.   
*
*       Desc:  This primitive is used by the service user to transmit
*              data on a TCP socket. If the TSAP is under flow control,
*              the primitive is dropped.
*              If TSAP is not under flow control, TUCL marks the message 
*              boundaries (in accordance with RFC1006), if it was requested
*              in HiUiHitServOpenReq or HiUiHitConReq. TUCL tries to send 
*              any pending data on the connection. It then tries to send 
*              the data in this primitive.  In case it is not able to send 
*              the full message, it queues up the un-transmitted data.
*              In case the size of un-transmitted data exceeds the upper
*              threshold( as specified in sap configuration), a Flow
*              control Indication is conveyed to the TUCL user and the
*              data is dropped.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: In case the connection id is not valid, or if the user 
*              has specified an invalid spConId, the data is dropped 
*              without informing the user.
*              In other error cases, a HiUiHitDiscInd is sent to the
*              user and the socket is closed.
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiHitDatReq
(
Pst *pst,                /* post structure */ 
SpId spId,               /* service provider id */ 
UConnId spConId,         /* service provider's connection id */
Buffer *mBuf             /* message buffer */
)
#else
PUBLIC S16 HiUiHitDatReq(pst, spId, spConId, mBuf)
Pst *pst;                /* post structure */ 
SpId spId;               /* service provider id */ 
UConnId spConId;         /* service provider's connection id */
Buffer *mBuf;            /* message buffer */
#endif
{

   HiSap               *sap;
   HiConCb             *conCb;
   CmInetMemInfo       memInfo;
   MsgLen              txLen;
   MsgLen              mLen;
   MsgLen              len;
   Buffer              *qBuf;
   HiAlarmInfo         info;
   S16                 ret;
   S16                 retVal;
   S16                 ret1;

   TRC3(HiUiHitDatReq)

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "HiUiHitDatReq() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */

#ifdef HI_LPBK
   UNUSED(ret1);
   UNUSED(len);
   UNUSED(retVal);
#endif /* HI_LPBK */

#ifdef H323_PERF
   TAKE_TIMESTAMP("L/T DatReq HC->HI, in HI");
#endif /* H323_PERF */

   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
           "HiUiHitDatReq(pst, spId(%d), spConId(%ld), mBuf(%p)))\n", 
           spId, spConId, mBuf));

   txLen = 0;
   qBuf = NULLP;

   /* initialize alarm information */
   info.spId = spId;
   info.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   memInfo.region = hiCb.hiInit.region;
   memInfo.pool   = hiCb.hiInit.pool;

  /* validation of input parameters */
#if (ERRCLASS & ERRCLS_INT_PAR)
   HI_CHK_SPID(spId, LHI_EVENT_DATREQ, ret, info);
   if(ret != ROK)
   {
      HILOGERROR_INT_PAR(EHI060, (ErrVal)spId, pst->dstInst,
                 "HiUiHitDatReq(): Invalid spId");

      /* hi001.104 - Added check for mBuf */
      if (mBuf)
         (Void)SPutMsg(mBuf);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   sap = hiCb.sapLstPtr[spId];
#if(ERRCLASS & ERRCLS_INT_PAR)
   if(sap->state != HI_ST_BND)
   {
      HILOGERROR_INT_PAR(EHI061, (ErrVal) sap->state, pst->dstInst,
                 "HiUiHitDatReq(): Sap not Bound");

      /* Deallocate the received message buffer */
      /* hi001.104 - Added check for mBuf */
      if (mBuf)
         (Void)SPutMsg(mBuf);

      HI_FILL_ALARMINFO_SAP_STATE(info, sap->state);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_DATREQ,
                  LCM_CAUSE_INV_STATE, &info);
      RETVALUE(RFAILED);
   }

   /* Check if there is some data to send or not */
   if(!mBuf)
   {
      HILOGERROR_INT_PAR( EHI062, (ErrVal) spId, pst->dstInst,
                 "HiUiHitDatReq(): Invalid Buffer");

      HI_FILL_ALARMINFO_PAR_TYPE(info, LHI_INV_MBUF);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_DATREQ,
                  LCM_CAUSE_INV_PAR_VAL, &info);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* Check the length of data payload in mBuf */

   (Void)SFndLenMsg(mBuf, &mLen);
#if(ERRCLASS & ERRCLS_INT_PAR)
   if(!mLen)
   {
      HILOGERROR_INT_PAR( EHI063, (ErrVal) spId, pst->dstInst, 
                 "HiUiHitDatReq(): Invalid Buffer");

      HI_FILL_ALARMINFO_PAR_TYPE(info, LHI_INV_MBUF);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_DATREQ,
                  LCM_CAUSE_INV_PAR_VAL, &info);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* Check for resource congestion and flow control */
#ifndef HI_REL_1_3 
   /* hi017.104: needs to first check the resource 
    * before checking the flag */
   hiChkRes(sap);
   if((sap->resCongDrop) || (sap->flc))
   {
      /* No indication is issued to the user here.
       * In case of resource congestion, an alarm would already have
       * been issued to the LM with event as LHI_EVENT_TXQ_CONG_DATA_DROP 
       * when poolDropThr was hit.
       * In case of flow control, a flow control indication with reason
       * as HI_FLC_DROP would already have been issued to the service 
       * user earlier */

      (Void)SPutMsg(mBuf);
      RETVALUE(RFAILED);
   }
#endif /* HI_REL_1_3 */

   /* Find the connection block */
   ret = cmHashListFind (&sap->sapHlCp, (U8 *)&spConId, sizeof(UConnId), 0,
                         (PTR *)&conCb);
   if (ret != ROK)
   {
      /* Deallocate the received message buffer */
      (Void)SPutMsg(mBuf);
      /* Issue a disconnect indication here */
      HI_DISCIND(sap, HI_PROVIDER_CON_ID, spConId, HI_DATREQ_INVALID_CONID);
      RETVALUE(RFAILED);
   }

#ifdef HI_REL_1_3 
   /* hi017.104: needs to first check the resource 
    * before checking the flag */
   hiChkRes(sap);
   if((sap->resCongDrop) || (conCb->flc))
   {
      /* No indication is issued to the user here.
       * In case of resource congestion, an alarm would already have
       * been issued to the LM with event as LHI_EVENT_TXQ_CONG_DATA_DROP 
       * when poolDropThr was hit.
       * In case of flow control, a flow control indication with reason
       * as HI_FLC_DROP would already have been issued to the service 
       * user earlier */
      
      (Void)SPutMsg(mBuf);
      RETVALUE(RFAILED);
   }
#endif /* HI_REL_1_3 */

   /* check the connection state */
   /* data transfer is possible only in connected states */

   if (!((conCb->conState == HI_ST_CONNECTED) || 
                (conCb->conState == HI_ST_CONNECTED_NORD)))
   {
      /* Deallocate the message buffer */
      (Void)SPutMsg(mBuf);
      HI_FILL_ALARMINFO_CON_STATE(info, conCb->conState);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_DATREQ,
                  LHI_CAUSE_INV_CON_STATE, &info);
      RETVALUE(RFAILED);
   }

   /* check the protocol in the connection block */
   if (conCb->flag & HI_FL_UDP)
   {
      /* Deallocate the message buffer */
      (Void)SPutMsg(mBuf);

      HI_FILL_ALARMINFO_PAR_TYPE(info, LHI_INV_SRVC_TYPE);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_DATREQ,
                 LCM_CAUSE_INV_PAR_VAL, &info);
      RETVALUE(RFAILED);
   }

#ifdef HI_LPBK
   hiLpBkSendTcpData(conCb, mBuf);
   (Void)SPutMsg(mBuf);
   RETVALUE(ROK);
#else

   /* append TPKT header on tcp data to be sent */
   if(conCb->srvcType ==  HI_SRVC_TCP_TPKT_HDR)
   {
      if(hiAppendHdr(mBuf) != ROK)
      {
         (Void)SPutMsg(mBuf);
#ifndef HI_MULTI_THREADED
         HI_DISCIND(sap, HI_USER_CON_ID, conCb->suConId, HI_OUTOF_RES);
         hiFreeConCb(conCb);
#else
         /* Ask the receive thread to send a disconnect indication */
         conCb->toBeDel |= HI_DEL_SEND_DISCIND;
   
         /* Decrement the number of file descriptors */
         hiDecNumFds(conCb, conCb->fdBlkIdx);

         /* Clear this conCb from the receive thread */
         hiFdClr(conCb, CM_INET_SHTDWN_BOTH);

         /* delete this conCb from the sap hashlist */
         cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
#endif /* HI_MULTI_THREADED */
         hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                     LCM_CAUSE_UNKNOWN, &info);
         RETVALUE(RFAILED);
      }
      /* Update message length after appending the header */
      mLen += HI_TPKT_HDR_LEN;
   }
   
   /* Check if there is any data pending to be transmitted 
    * in the transmit queue. Try to send it first */

   /* Check if there is some mBufs already queued */
   /* Incase of multithreaded case this variable is safe to read because the
    * main thread is the only one that changes this. The receive thread will
    * post an internal primitive when all the mBufs have been sent.
    */
   if (conCb->mBufInQ)
   {
      /* Add the new mBuf into the queue */
      ret = hiAddmBufToConCbQ(conCb, mBuf);
      if (ret != ROK)
      {
         SPutMsg(mBuf);
#ifndef HI_MULTI_THREADED
         HI_DISCIND(sap, HI_USER_CON_ID, conCb->suConId, conCb->reason);
         hiFreeConCb(conCb);
#else
         /* Ask the receive thread to send a disconnect indication */
         conCb->toBeDel |= HI_DEL_SEND_DISCIND;
   
         /* Decrement the number of file descriptors */
         hiDecNumFds(conCb, conCb->fdBlkIdx);

         /* Clear this conCb from the receive thread */
         hiFdClr(conCb, CM_INET_SHTDWN_BOTH);

         /* delete this conCb from the sap hashlist */
         cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
#endif /* HI_MULTI_THREADED */
         HI_FILL_ALARMINFO_MEM_ID(info, sap->uiPst.region, 
                                  sap->uiPst.pool);
         hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                     LCM_CAUSE_UNKNOWN, &info);
         RETVALUE(RFAILED);
      }
      /* Check if flow control indication needs to be issued */
#ifdef HI_REL_1_3
      hiChkFlwCntrl(conCb, mLen, 0);
#else
      hiChkFlwCntrl(sap, mLen, 0);
      sap->currTxQSiz += mLen;
#endif /* HI_REL_1_3 */
      /* All the mBufs will be transferred from the receive thread or the
       * permanent task */
      RETVALUE(ROK);
   } /* end if */

#ifdef H323_PERF
   TAKE_TIMESTAMP("L/T Before DatReq/cmInetSendMsg(), in HI");
#endif /* H323_PERF */

   /* hi009.104 - pass NULLP for new argument */ 
#ifdef IPV6_SUPPORTED  
   retVal = cmInetSendMsg(&conCb->conFd, (CmInetAddr *)&(conCb->peerAddr), 
                          &memInfo, mBuf, &txLen, 
#ifdef IPV6_OPTS_SUPPORTED                          
                          NULLP,
#endif /* IPV6_OPTS_SUPPORTED */                          
                          CM_INET_NO_FLAG);   
#else
   retVal = cmInetSendMsg(&conCb->conFd, &(conCb->peerAddr.u.ipv4TptAddr), 
                          &memInfo, mBuf, &txLen, CM_INET_NO_FLAG);
#endif /* IPV6_SUPPORTED */

#ifdef H323_PERF
   TAKE_TIMESTAMP("L/T After DatReq/cmInetSendMsg(), in HI");
#endif /* H323_PERF */

   /* Increment the statistics counters */
   sap->genTxSts.numTxbytes += txLen;
   sap->txSts.numTxbytes += txLen;

   if (retVal == RWOULDBLOCK)
   {
      /* The length of the untransmitted data is */
      len = mLen - txLen;

      /* Check if some data was transmitted */
      if(txLen) 
      {
         sap->genTxSts.numTxTcpMsg++;
         sap->txSts.numTxTcpMsg++;

         HIDBGP(DBGMASK_SI, (hiCb.hiInit.prntBuf,
               "SSegMsg(mBuf1(%p), idx(%d), mBuf2(%p))\n", 
                mBuf,txLen,&qBuf));

         /* get the un-transmittted message */
         ret1 = SSegMsg(mBuf, txLen, &qBuf);
         if (ret1 != ROK)
         {
            (Void)SPutMsg(mBuf);
#ifndef HI_MULTI_THREADED
            HI_DISCIND(sap, HI_USER_CON_ID, conCb->suConId, HI_OUTOF_RES);
            hiFreeConCb(conCb);
#else
            conCb->reason = HI_OUTOF_RES;
            conCb->toBeDel |= HI_DEL_SEND_DISCIND;
            hiDecNumFds(conCb, conCb->fdBlkIdx);
            hiFdClr(conCb, CM_INET_SHTDWN_BOTH);
            cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
#endif /* HI_MULTI_THREADED */
            HI_FILL_ALARMINFO_MEM_ID(info, sap->uiPst.region, 
                                     sap->uiPst.pool);
            hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                        LCM_CAUSE_UNKNOWN, &info);
            /* hi014.104: remove extra SPutMsg */
            RETVALUE(RFAILED);
         }

         /* Trace the transmitted buffer */
         if(sap->trc)
            hiTrcBuf(sap, LHI_TCP_TXED, mBuf);

         /* Deallocate the sent part of the message */
         SPutMsg(mBuf);

         /* Set the mBuf pointer to point to the untransmitted part */
         mBuf = qBuf;

      }/* end if txLen */

      /* Add the mBuf to the transmit queue */
      ret = hiAddmBufToConCbQ(conCb, mBuf);
      if (ret != ROK)
      {
         SPutMsg(mBuf);
#ifndef HI_MULTI_THREADED
         /* conCb->reason is set in the function */
         HI_DISCIND(sap, HI_USER_CON_ID, conCb->suConId, conCb->reason);
         hiFreeConCb(conCb);
#else
         conCb->toBeDel |= HI_DEL_SEND_DISCIND;
         hiDecNumFds(conCb, conCb->fdBlkIdx);
         hiFdClr(conCb, CM_INET_SHTDWN_BOTH);
         cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
#endif /* HI_MULTI_THREADED */
         RETVALUE(RFAILED);
      }

      /* Check if flow control indication needs to be issued */
#ifdef HI_REL_1_3
      hiChkFlwCntrl(conCb, len, 0);
#else
      hiChkFlwCntrl(sap, len, 0);
      sap->currTxQSiz += len;
#endif /* HI_REL_1_3 */
      RETVALUE(ROK);
   }/* end RWOULDBLOCK || RNA */
   else if(retVal == RFAILED) 
   {
#ifdef HI_MULTI_THREADED
      conCb->reason = HI_SOCK_SEND_ERR;
      conCb->toBeDel |= HI_DEL_SEND_DISCIND;
      hiDecNumFds(conCb, conCb->fdBlkIdx);
      hiFdClr(conCb, CM_INET_SHTDWN_BOTH);
      cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
      HI_LOCK(&hiCb.errStsLock, info, ret); 
      if (ret != ROK)
         HILOGERROR_DEBUG(EHI064, (ErrVal) 0, pst->dstInst, 
               "HiUiHitDatReq () : Unable to lock error sts \n");
      /* Increment the statistics counter */
      hiCb.errSts.sockTxErr++;
      HI_UNLOCK(&hiCb.errStsLock, info, ret);
      if (ret != ROK)
         HILOGERROR_DEBUG(EHI065, (ErrVal) 0, pst->dstInst, 
            "HiUiHitConReq () : Unable to unlock error sts \n");
#else
      HI_DISCIND(sap, HI_USER_CON_ID, conCb->suConId, HI_SOCK_SEND_ERR);
      /* Increment the statistics counter */
      hiCb.errSts.sockTxErr++;
      hiFreeConCb(conCb);
#endif /* HI_MULTI_THREADED */

      /* Deallocate the received message buffer */
      (Void)SPutMsg(mBuf);

      hiSendAlarm(LCM_CATEGORY_INTERNAL, LHI_EVENT_INET_ERR,
                  LHI_CAUSE_SOCK_SEND_ERR, &info);

      RETVALUE(RFAILED);
   }
   else if(retVal == ROUTRES)
   {
#ifdef HI_MULTI_THREADED
      conCb->reason = HI_OUTOF_RES;
      conCb->toBeDel |= HI_DEL_SEND_DISCIND;
      hiDecNumFds(conCb, conCb->fdBlkIdx);
      hiFdClr(conCb, CM_INET_SHTDWN_BOTH);
      cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
      HI_LOCK(&hiCb.errStsLock, info, ret); 
      if (ret != ROK)
         HILOGERROR_DEBUG(EHI066, (ErrVal) 0, pst->dstInst, 
               "HiUiHitDatReq () : Unable to lock error sts \n");
      /* Increment the statistics counter */
      hiCb.errSts.sockTxErr++;
      HI_UNLOCK(&hiCb.errStsLock, info, ret);
      if (ret != ROK)
         HILOGERROR_DEBUG(EHI067, (ErrVal) 0, pst->dstInst, 
            "HiUiHitDatReq () : Unable to unlock error sts \n");
#else
      HI_DISCIND(sap,  HI_USER_CON_ID, conCb->suConId, HI_OUTOF_RES);
      /* Increment the statistics counter */
      hiCb.errSts.sockTxErr++;
      hiFreeConCb(conCb);
#endif /* HI_MULTI_THREADED */

      /* Deallocate the received message buffer */
      (Void)SPutMsg(mBuf);

      /* Fill up the alarm information */
      HI_FILL_ALARMINFO_MEM_ID(info, memInfo.region, memInfo.pool);

      hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                  LHI_CAUSE_SOCK_SEND_ERR, &info);

      RETVALUE(RFAILED);
   }/* end ROUTRES */
   /* Check for connection closed be peer */
   else if(retVal == RCLOSED)
   {
#ifndef HI_MULTI_THREADED
      HI_DISCIND(sap, HI_USER_CON_ID, conCb->suConId, HI_CON_CLOSED_BY_PEER);
      hiFreeConCb(conCb);
#else
      conCb->reason = HI_CON_CLOSED_BY_PEER;
      conCb->toBeDel |= HI_DEL_SEND_DISCIND;
      hiDecNumFds(conCb, conCb->fdBlkIdx);
      hiFdClr(conCb, CM_INET_SHTDWN_BOTH);
      cmHashListDelete(&sap->sapHlCp, (PTR) conCb);      
#endif /* HI_MULTI_THREADED */

      /* Deallocate the received message buffer */
      (Void)SPutMsg(mBuf);

      RETVALUE(RFAILED);
   }
   else /* ROK */
   {
      if(sap->trc)
         hiTrcBuf(sap, LHI_TCP_TXED, mBuf);
      sap->genTxSts.numTxTcpMsg++;
      sap->txSts.numTxTcpMsg++;
   }

   /* Deallocate the sent message buffer */
   if (mBuf != NULLP)
      (Void)SPutMsg(mBuf);

#ifdef H323_PERF
   TAKE_TIMESTAMP("L/T DatReq - End of HiUiHitDatReq, in HI");
#endif /* H323_PERF */

   RETVALUE(ROK);
#endif /* HI_LPBK */
}/* end of HiUiHitDatReq() */


/*
*
*       Fun:   Primitive to send UDP datagrams
*
*       Desc:  This primitive is used by the service user to transmit
*              data on a UDP socket.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: In case of error to send data, no indication is given to
*              the service user. An alrm is however raised to the Layer
*              Manager.
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiHitUDatReq
(
Pst *pst,                /* post structure */ 
SpId spId,               /* service provider id */ 
UConnId  spConId,        /* service provider connection id */
CmTptAddr *remAddr,      /* remote address */
#ifdef HI_REL_1_3  
CmTptAddr *srcAddr,      /* Source Address */
CmIpHdrParm *hdrParm,    /* Header Parameters */
#ifdef HI_REL_1_4
CmTptParam *tPar,        /* transport parameters */
#endif  /* HI_REL_1_4 */ 
#endif  /* HI_REL_1_3 */ 
Buffer *mBuf             /* message buffer to be sent */
)
#else
#ifdef HI_REL_1_3  
#ifdef HI_REL_1_4
PUBLIC S16 HiUiHitUDatReq(pst, spId, spConId, remAddr, srcAddr, 
                          hdrParm, tPar, mBuf)
Pst *pst;                /* post structure */ 
SpId spId;               /* service provider id */ 
UConnId  spConId;        /* service provider connection id */
CmTptAddr *remAddr;      /* remote address */
CmTptAddr *srcAddr;      /* Source Address */
CmIpHdrParm *hdrParm;    /* Header Parameters */
CmTptParam *tPar;        /* transport parameters */
Buffer *mBuf;            /* message buffer to be sent */
#else
PUBLIC S16 HiUiHitUDatReq(pst, spId, spConId, remAddr, srcAddr, 
                          hdrParm, mBuf)
Pst *pst;                /* post structure */ 
SpId spId;               /* service provider id */ 
UConnId  spConId;        /* service provider connection id */
CmTptAddr *remAddr;      /* remote address */
CmTptAddr *srcAddr;      /* Source Address */
CmIpHdrParm *hdrParm;    /* Header Parameters */
Buffer *mBuf;            /* message buffer to be sent */
#endif /* HI_REL_1_4 */
#else /* HI_REL_1_3 */ 
PUBLIC S16 HiUiHitUDatReq(pst, spId, spConId, remAddr, mBuf)
Pst *pst;                /* post structure */ 
SpId spId;               /* service provider id */ 
UConnId  spConId;        /* service provider connection id */
CmTptAddr *remAddr;      /* remote address */
Buffer *mBuf;            /* message buffer to be sent */
#endif /* HI_REL_1_3 */ 
#endif /* ANSI */ 
{

   HiSap               *sap;
   CmInetMemInfo       memInfo;
   HiAlarmInfo         info;
   MsgLen              txLen;
   CmInetFd            *sendFd;
   HiConCb             *conCb;
   S16                 ret;
   Bool                isUdpClt;
#ifdef HI_REL_1_3   
   CmIpv4Hdr           ipv4Hdr;
   MsgLen              mLen; 
   CmTptParam          lclTPar;
#ifdef HI_REL_1_4  
   Bool                found;
   Bool                resetTtl;
#endif /* HI_REL_1_4 */ 
#endif  /* HI_REL_1_3 */ 
   /* hi009.104 - added new local variables */ 
#ifdef IPV4_OPTS_SUPPORTED   
   Bool                 appendHdrOpts;  /* when TRUE: Router Alert socket
                                           option failed & Router Alert will
                                           be inserted in ipv4 hdr manually */
   MsgLen               msgLen;         /* message length */ 
#endif /* IPV4_OPTS_SUPPORTED */

   /* hi009.104 - added new local variables */ 
#ifdef IPV6_OPTS_SUPPORTED   
   CmInetIpv6HdrParm   *ipv6HdrParm;
#endif /* IPV6_OPTS_SUPPORTED */ 
   Bool                isRsvpSocket;
   
   TRC3(HiUiHitUDatReq)
#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Entered HiUiHitUDatReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "HiUiHitUDatReq() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */

#ifdef HI_LPBK
   UNUSED(txLen);
   UNUSED(memInfo);
   /* removed compiler warnings in LPBK mode */
#ifdef HI_REL_1_3
   UNUSED(lclTPar);
   UNUSED(mLen);
   UNUSED(ipv4Hdr);
#ifdef HI_REL_1_4
   UNUSED(resetTtl);
   UNUSED(found);
#endif /* HI_REL_1_4 */
#endif /* HI_REL_1_3 */
#endif /* HI_LPBK */

#ifdef H323_PERF
   TAKE_TIMESTAMP("L/T UDatReq HC->HI, in HI");
#endif /* H323_PERF */

   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
           "HiUiHitUDatReq(pst, spId(%d), remAddr(%p), mBuf(%p))\n",
           spId, remAddr, mBuf));

   /* Initialize spId in alarmInfo */
   info.spId = spId;
   info.type = LHI_ALARMINFO_TYPE_NTPRSNT;
   sendFd    = NULLP;
   conCb     = NULLP;
   isUdpClt  = FALSE;
#ifdef HI_REL_1_4  
   found = FALSE;
   resetTtl = FALSE;
#endif /* HI_REL_1_4 */ 

   /* hi009.104 - set to FALSE */ 
   isRsvpSocket = FALSE;
   
   /* hi026.104 - Initializtion */
   /* hi027.104 - Put under HI_REL_1_4 */
#ifdef HI_REL_1_4
   if(tPar->type == CM_TPTPARAM_NOTPRSNT )
      tPar->u.sockParam.numOpts=0;
#endif

   /* validation of input parameters */
#if (ERRCLASS & ERRCLS_INT_PAR)
   HI_CHK_SPID(spId, LHI_EVENT_UDATREQ, ret, info);
   if(ret != ROK)
   {
      HILOGERROR_INT_PAR( EHI068, (ErrVal)spId, pst->dstInst, 
                 "HiUiHitUDatReq(): Invalid spId");
      /* hi001.104: the old code here is if(!mBuf) which is wrong */
      if(mBuf)
         SPutMsg(mBuf);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   sap = hiCb.sapLstPtr[spId];
#if (ERRCLASS & ERRCLS_INT_PAR)
   if(sap->state != HI_ST_BND)
   {
      /* deallocate the received message buffer */
      /* hi001.104: the old code here is if(!mBuf) which is wrong */
      if(mBuf)
         SPutMsg(mBuf);

      HILOGERROR_INT_PAR( EHI069, (ErrVal) sap->state, pst->dstInst, 
                 "HiUiHitUDatReq(): Sap not Bound");

      HI_FILL_ALARMINFO_SAP_STATE(info, sap->state);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_UDATREQ,
                  LCM_CAUSE_INV_STATE, &info);

      RETVALUE(RFAILED);
   }

   if(!mBuf)
   {
      HILOGERROR_INT_PAR( EHI070, (ErrVal)mBuf, pst->dstInst, 
                 "HiUiHitUDatReq(): Null Message buffer");

      HI_FILL_ALARMINFO_PAR_TYPE(info, LHI_INV_MBUF);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_UDATREQ,
                  LCM_CAUSE_INV_PAR_VAL, &info);
      RETVALUE(RFAILED);      
   }
#endif /* ERRCLS_INT_PAR */

#ifdef HI_REL_1_3  
#if (ERRCLASS & ERRCLS_INT_PAR)
#ifndef IPV6_SUPPORTED
   if(srcAddr->type == CM_TPTADDR_IPV6)
   {
      HILOGERROR_INT_PAR(EHI071, (ErrVal) remAddr->type, pst->dstInst, 
                 "HiUiHitUDatReq(): Invalid source address");

      (Void)SPutMsg(mBuf);

      HI_FILL_ALARMINFO_PAR_TYPE(info, LHI_INV_TPT_ADDR);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_UDATREQ,
                  LCM_CAUSE_INV_PAR_VAL, &info);
      RETVALUE(RFAILED);
   }

   if(hdrParm->type == CM_HDRPARM_IPV6)
   {
      HILOGERROR_INT_PAR( EHI072, (ErrVal) hdrParm->type, pst->dstInst, 
                 "HiUiHitUDatReq(): Invalid protocol Type ");

      (Void)SPutMsg(mBuf);

      HI_FILL_ALARMINFO_PAR_TYPE(info, LHI_INV_TPT_ADDR);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_UDATREQ,
                  LCM_CAUSE_INV_PAR_VAL, &info);
      RETVALUE(RFAILED);
   }

   /* hi009.104 - added check for new argument */ 
   if(hdrParm->type != CM_HDRPARM_NOTPRSNT) 
   {
#ifdef IPV4_OPTS_SUPPORTED
      if((hdrParm->u.hdrParmIpv4.ipv4HdrOpt.pres) &&
         (hdrParm->u.hdrParmIpv4.ipv4HdrOpt.len > CM_IPV4_OPTS_MAXLEN))
      {
         HILOGERROR_INT_PAR(EHIXXX,
                            (ErrVal) hdrParm->u.hdrParmIpv4.ipv4HdrOpt.len, 
                            pst->dstInst,
                            "HiUiHitUDatReq(): Invalid IPv4 Options length ");

         (Void)SPutMsg(mBuf);

         HI_FILL_ALARMINFO_PAR_TYPE(info, LHI_INV_HDR_PARAM);
         hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_UDATREQ,
                     LCM_CAUSE_INV_PAR_VAL, &info);
         RETVALUE(RFAILED);
      }
#endif /* IPV4_OPTS_SUPPORTED */
   }

#endif /* IPV6_SUPPORTED */
#endif /* ERRCLS_INT_PAR */
#endif /* HI_REL_1_3 */ 

   /* check if resource congestion was hit */
   /* hi017.104: needs to first check the resource 
    * before checking the flag */
   hiChkRes(sap);
   if(sap->resCongDrop)
   {
      (Void)SPutMsg(mBuf);
      RETVALUE(RFAILED);
   }

   /* spConId = ZERO : use generic socket to transmit data
    * spConId = valid_value find the server/client socket to send data
    */
   if(spConId)
   {
      /* Find the connection block */
      if(cmHashListFind (&sap->sapHlCp, (U8 *)&spConId, sizeof(UConnId), 0,
                            (PTR *)&conCb) == ROK)
      {
         sendFd = &conCb->conFd;
    /* hi018.104: if socket not available return failure */
    if(conCb->toBeDel)
    {
       (Void)SPutMsg(mBuf);
       RETVALUE(RFAILED);
    }
         if (conCb->flag & HI_FL_UDP_CLT)

            isUdpClt = TRUE;
#ifdef HI_REL_1_4  
         found = TRUE;
#endif /* HI_REL_1_4 */ 
         /* hi009.104 - set the value of new local variable */ 
#ifdef HI_REL_1_3         
#ifdef HI_RSVP_SUPPORT
         /* Check if the socket is of type RSVP */
         if (conCb->srvcType == HI_SRVC_RAW_RSVP)
         {
            isRsvpSocket = TRUE;
         }  
#endif /* HI_RSVP_SUPPORT */
#endif /* HI_REL_1_3 */         
      }
      else
      {
         /* hi019.104: free teh mBuf */
         if(mBuf)
            SPutMsg(mBuf);
         /* Issue a disconnect indication here */
         hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_UDATREQ,
                  LCM_CAUSE_INV_PAR_VAL, &info);
         RETVALUE(RFAILED);
      }
   }
   else
   {
      /* Use the common socket opened during configuration */
#ifdef IPV6_SUPPORTED
      if (remAddr->type == CM_INET_IPV6ADDR_TYPE)
      {
         if (hiCb.resv6ConFd.fd != CM_INET_INV_SOCKFD)
            sendFd = &hiCb.resv6ConFd;
      }
      else
#endif /* IPV6_SUPPORTED */
         if(hiCb.resvConFd.fd != CM_INET_INV_SOCKFD)
            sendFd = &hiCb.resvConFd;
   }

#ifdef HI_REL_1_3  
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check if conCb can be NULL here */
   /* Indicate an error if protocol is not valid */
#ifdef IPV6_SUPPORTED
   /* hi009.104 -  change the checking condition by replacing 
    * !(conCb->flag & HI_FL_RAW) with (conCb->flag & HI_FL_TCP) */
   if(((hdrParm->type == CM_HDRPARM_IPV4) || (hdrParm->type == CM_HDRPARM_IPV6))
       && (conCb->flag & HI_FL_TCP)) 
#else
   if((hdrParm->type == CM_HDRPARM_IPV4) && !(conCb->flag & HI_FL_RAW)) 
#endif /* IPV6_SUPPORTED */
   {
      HILOGERROR_INT_PAR( EHI073, (ErrVal) hdrParm->type, pst->dstInst, 
                 "HiUiHitUDatReq(): Invalid type protocol combination");

      (Void)SPutMsg(mBuf);

      HI_FILL_ALARMINFO_PAR_TYPE(info, LHI_INV_TPT_ADDR);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_UDATREQ,
                  LCM_CAUSE_INV_PAR_VAL, &info);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */
#endif /* HI_REL_1_3 */

#ifdef HI_LPBK
   hiLpBkSendUdpData(sap, ((conCb)? &conCb->locAddr:NULLP), remAddr, mBuf);
#else

   if(sendFd)
   {
      /* Send data */
      memInfo.region = hiCb.hiInit.region;
      memInfo.pool   = hiCb.hiInit.pool;

#ifdef HI_REL_1_3  
      /* For UDP_TPKT_HDR srvcType append the header. */
      if ((conCb) && (conCb->srvcType == HI_SRVC_UDP_TPKT_HDR))
         if(hiAppendHdr(mBuf) != ROK)
         {
            (Void)SPutMsg(mBuf);
            hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                        LCM_CAUSE_UNKNOWN, &info);
            RETVALUE(RFAILED);
         }

      if ((conCb) && (hdrParm->type == CM_HDRPARM_IPV4))
      {
         if((conCb) && (conCb->hdrIncldFlag & HI_INCLUDE_HDR))
         {
            /* hi009.104 -  added to set/reset IPv4 IP_OPTIONS */
#ifdef IPV4_OPTS_SUPPORTED
            appendHdrOpts = FALSE;
            /* Reset IP_OPTIONS if that is already set!! */
            if(hdrParm->u.hdrParmIpv4.ipv4HdrOpt.pres == FALSE) 
            {
               /* Reset ONLY if it was set before. Else ignore. */
               if (conCb->ipv4OptionSet == TRUE)
               {
                  hdrParm->u.hdrParmIpv4.ipv4HdrOpt.pres = TRUE;  
                  hdrParm->u.hdrParmIpv4.ipv4HdrOpt.len = 0;
                  ret = cmInetSetOpt(&conCb->conFd, CM_SOCKOPT_LEVEL_IP,
                                     CM_INET_OPT_IP_OPTIONS,
                                     &hdrParm->u.hdrParmIpv4.ipv4HdrOpt);
                  /* hi018.104: Socket option set error */
                  if(ret != ROK)
                  {
                     hiDiscSockHandle(FALSE, HI_SOCK_SEND_ERR, conCb);
                     RETVALUE(RFAILED); 
                  }
                  else
                  {
                     hdrParm->u.hdrParmIpv4.ipv4HdrOpt.pres = FALSE; 
                     conCb->ipv4OptionSet = FALSE;
                  }
               }
            }
            else
            { 
               if (conCb->ipv4OptionSet == FALSE)
               {
                  ret = cmInetSetOpt(&conCb->conFd, CM_SOCKOPT_LEVEL_IP,
                                     CM_INET_OPT_IP_OPTIONS,
                                     &hdrParm->u.hdrParmIpv4.ipv4HdrOpt);               
                 /* setting router alert socket option failed. So Router
                  * Alert needs to be inserted in IPV4 hdr by us */
                  if (ret == RNA)
                     appendHdrOpts = TRUE;
                  /* hi018.104: Socket option set error */
                  else if(ret != ROK)
                  {
                     hiDiscSockHandle(FALSE, HI_SOCK_SEND_ERR, conCb);
                     RETVALUE(RFAILED); 
                  }
                  else
                     conCb->ipv4OptionSet = TRUE; 
               }
            }   
#endif /* IPV4_OPTS_SUPPORTED */ 

            cmMemset((U8*)&ipv4Hdr, 0, sizeof(CmIpv4Hdr));
            /* If header type is IPv4 then set the header parameter in the 
             * Ip header buffer */
            (Void)SFndLenMsg(mBuf, &mLen);
#if(ERRCLASS & ERRCLS_INT_PAR)
            if(!mLen)
            {
               HILOGERROR_INT_PAR(EHI074, (ErrVal) spId, pst->dstInst, 
                          "HiUiHitUDatReq(): Invalid Buffer");

               RETVALUE(RFAILED);
            }
#endif /* ERRCLS_INT_PAR */

            ipv4Hdr.length = CM_IPV4_HDRLEN + mLen;
            ipv4Hdr.hdrVer = 0x45;

            /* hi009.104 - update the header length and total length */
            /* when ip header option is present */
#ifdef IPV4_OPTS_SUPPORTED
            if ((appendHdrOpts == TRUE) && 
                hdrParm->u.hdrParmIpv4.ipv4HdrOpt.pres)
            {
               ipv4Hdr.length += hdrParm->u.hdrParmIpv4.ipv4HdrOpt.len; 
               ipv4Hdr.hdrVer = 0x40 + 
                                (5 + hdrParm->u.hdrParmIpv4.ipv4HdrOpt.len/4);
            }
#endif /* IPV4_OPTS_SUPPORTED */

            if(hdrParm->u.hdrParmIpv4.proto.pres)
            {
               ipv4Hdr.proto = hdrParm->u.hdrParmIpv4.proto.val;
            }
            else
            {
               ipv4Hdr.proto = conCb->protocol;
            }
            
            if(hdrParm->u.hdrParmIpv4.dfBit.pres)
            {
               ipv4Hdr.off |= CM_DF_MASK;
            }

            if(hdrParm->u.hdrParmIpv4.tos.pres)
            {
               ipv4Hdr.tos = hdrParm->u.hdrParmIpv4.tos.val;
            }

            if(hdrParm->u.hdrParmIpv4.ttl.pres)
            {
               ipv4Hdr.ttl = hdrParm->u.hdrParmIpv4.ttl.val;
            }
     
            /* Insert source address in IP buffer if specified by the User */
            if(srcAddr->type  == CM_TPTADDR_IPV4)
            {
               ipv4Hdr.srcAddr = srcAddr->u.ipv4TptAddr.address;
            }
     
            /* Insert destination address in IP buffer */
            ipv4Hdr.destAddr = remAddr->u.ipv4TptAddr.address;

            /* This funtion will prepend IP header in the message */  
            ret = hiPkIpv4Hdr(&ipv4Hdr, mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
            if(ret != ROK)
            {
               HILOGERROR_DEBUG(EHI075, (ErrVal)0 , pst->dstInst, 
                        "HiUiHitUDatReq(): IP-HEADER prepending Error ");

               (Void)SPutMsg(mBuf);

               RETVALUE(ROK); /* As this is a Raw packet case so return 
                               * success */
            }
#endif /* ERRCLS_DEBUG */            

            /* hi009.104 - Insert Router Alert manually to the end of the 
             * mBuf (Copy the 4 bytes) */
#ifdef IPV4_OPTS_SUPPORTED            
            if ((appendHdrOpts == TRUE) && 
                hdrParm->u.hdrParmIpv4.ipv4HdrOpt.pres)
            {
               /* Insert 4 bytes of Router Alert at index 20 of mBuf just 
                * at the end of IPV4 Hdr */
               ret = SCpyFixMsg((Data *)&hdrParm->u.hdrParmIpv4.ipv4HdrOpt.val, 
                                mBuf, CM_IPV4_HDRLEN, 
                                hdrParm->u.hdrParmIpv4.ipv4HdrOpt.len, 
                                &msgLen);
               if ((ret != ROK) || 
                   (msgLen !=  hdrParm->u.hdrParmIpv4.ipv4HdrOpt.len))
               {
                  /* cleanup as appending of router alert failed */
                  (Void)SPutMsg(mBuf);
                  RETVALUE(RFAILED);
               }
            }
#endif /* IPV4_OPTS_SUPPORTED */            
         }
         else 
         {
            /* If the IP header include option is not supported */ 
            if((conCb) && (conCb->hdrIncldFlag & HI_HDRINCLD_NT_SUPPORTED))
            {
               lclTPar.type = CM_TPTPARAM_SOCK;
               lclTPar.u.sockParam.numOpts = 0;

               if(hdrParm->u.hdrParmIpv4.dfBit.pres)
               {
                  if(!(conCb->ipParamMask & HI_DF_MASK))
                  {
                     lclTPar.u.sockParam.sockOpts[lclTPar.u.sockParam.numOpts].
                                 option = CM_SOCKOPT_OPT_DONTFRAGMENT;
                     lclTPar.u.sockParam.sockOpts[lclTPar.u.sockParam.numOpts].
                                 level  = CM_SOCKOPT_LEVEL_IP;
                     lclTPar.u.sockParam.sockOpts[lclTPar.u.sockParam.numOpts].
                                 optVal.value = CM_SOCKOPT_ENABLE;
                     lclTPar.u.sockParam.numOpts++;
                     conCb->ipParamMask |= HI_DF_MASK;
                  }
               }
               else 
               {
                  if(conCb->ipParamMask & HI_DF_MASK)
                  {
                     lclTPar.u.sockParam.sockOpts[lclTPar.u.sockParam.numOpts].
                           option = CM_SOCKOPT_OPT_DONTFRAGMENT;
                     lclTPar.u.sockParam.sockOpts[lclTPar.u.sockParam.numOpts].
                                 level = CM_SOCKOPT_LEVEL_IP;
                     lclTPar.u.sockParam.sockOpts[lclTPar.u.sockParam.numOpts].
                                 optVal.value = CM_SOCKOPT_DISABLE;
                     lclTPar.u.sockParam.numOpts++;
                     conCb->ipParamMask &= ~HI_DF_MASK;
                  }
               }

               /* hi004.104 - TOS value assigned in the setsock option */
               if(hdrParm->u.hdrParmIpv4.tos.pres)
               {
                  if(conCb->ipTos !=  hdrParm->u.hdrParmIpv4.tos.val)
                  {
                     lclTPar.u.sockParam.sockOpts[lclTPar.u.sockParam.numOpts].
                        option = CM_SOCKOPT_OPT_TOS;
                     lclTPar.u.sockParam.sockOpts[lclTPar.u.sockParam.numOpts].level =
                                                         CM_SOCKOPT_LEVEL_IP;
                     lclTPar.u.sockParam.sockOpts[lclTPar.u.sockParam.numOpts].optVal.
                                       value = hdrParm->u.hdrParmIpv4.tos.val;
                     lclTPar.u.sockParam.numOpts++;
                     conCb->ipTos = hdrParm->u.hdrParmIpv4.tos.val;  
                  }
               } 

               if(hdrParm->u.hdrParmIpv4.ttl.pres)
               {
                  if(conCb->ipTtl !=  hdrParm->u.hdrParmIpv4.ttl.val)
                  {
                     lclTPar.u.sockParam.sockOpts[lclTPar.u.sockParam.numOpts].
                                                   option = CM_SOCKOPT_OPT_TTL;
                     lclTPar.u.sockParam.sockOpts[lclTPar.u.sockParam.numOpts].
                                                   level  = CM_SOCKOPT_LEVEL_IP;
                     lclTPar.u.sockParam.sockOpts[lclTPar.u.sockParam.numOpts].
                                 optVal.value = hdrParm->u.hdrParmIpv4.ttl.val;
                     lclTPar.u.sockParam.numOpts++;
                     conCb->ipTtl=hdrParm->u.hdrParmIpv4.ttl.val;
                  }
               }

               if (lclTPar.u.sockParam.numOpts)
               {
                  ret = hiSetSockOpt(&conCb->conFd, &lclTPar);
                  /* hi018.104: Socket option set error */
                  if(ret != ROK)
                  {
                     hiDiscSockHandle(FALSE, HI_SOCK_SEND_ERR, conCb);
                     RETVALUE(RFAILED); 
                  }
               }

               /* hi009.104 -  try to set IP_OPTIONS for IPv4 Router Alert */
#if (defined(IPV4_OPTS_SUPPORTED) && (!defined(SS_LINUX) || !defined(SS_VW)))
               if(hdrParm->u.hdrParmIpv4.ipv4HdrOpt.pres == FALSE) 
               {
                  /* Reset ONLY if it was set before. Else ignore. */
                  if (conCb->ipv4OptionSet == TRUE)
                  {
                     hdrParm->u.hdrParmIpv4.ipv4HdrOpt.pres = TRUE;  
                     hdrParm->u.hdrParmIpv4.ipv4HdrOpt.len = 0;
                     ret = cmInetSetOpt(&conCb->conFd, CM_SOCKOPT_LEVEL_IP,
                                        CM_INET_OPT_IP_OPTIONS,
                                        &hdrParm->u.hdrParmIpv4.ipv4HdrOpt);
                     /* hi018.104: Socket option set error */
                     if(ret != ROK)
                     {
                        hiDiscSockHandle(FALSE, HI_SOCK_SEND_ERR, conCb);
                        RETVALUE(RFAILED); 
                     }
                     hdrParm->u.hdrParmIpv4.ipv4HdrOpt.pres = FALSE; 
                     conCb->ipv4OptionSet = FALSE;
                  }
               }                        
               else if(hdrParm->u.hdrParmIpv4.ipv4HdrOpt.pres == TRUE) 
               {         
                  if (conCb->ipv4OptionSet == FALSE)
                  {
                     ret = cmInetSetOpt(&conCb->conFd, CM_SOCKOPT_LEVEL_IP,
                                        CM_INET_OPT_IP_OPTIONS,
                                        &hdrParm->u.hdrParmIpv4.ipv4HdrOpt);
                     /* hi018.104: Socket option set error */
                     if(ret == RNA || ret == RFAILED)
                     {
                        hiDiscSockHandle(FALSE, HI_SOCK_SEND_ERR, conCb);
                        RETVALUE(RFAILED); 
                     }
                     else
                        conCb->ipv4OptionSet = TRUE;
                  }
               }   
#endif /* IPV4_OPTS_SUPPORTED */     
            }
         } /* else */
      }
#ifdef IPV6_SUPPORTED 
      else if ((conCb) && (hdrParm->type == CM_HDRPARM_IPV6))
      {
         lclTPar.type = CM_TPTPARAM_SOCK;
         lclTPar.u.sockParam.numOpts = 0;

         /* mmh -  do we need this check */
#ifndef CMINETFLATBUF
         if(hdrParm->u.hdrParmIpv6.ttl.pres)
         {
            if (conCb->ipTtl != hdrParm->u.hdrParmIpv6.ttl.val)
            {
               lclTPar.u.sockParam.numOpts = 1;
               lclTPar.u.sockParam.sockOpts[0].option = CM_SOCKOPT_OPT_IPV6_TTL;
               lclTPar.u.sockParam.sockOpts[0].level  = CM_SOCKOPT_LEVEL_IPV6;
               lclTPar.u.sockParam.sockOpts[0].optVal.value = 
                                               hdrParm->u.hdrParmIpv6.ttl.val;
               ret = hiSetSockOpt(&conCb->conFd, &lclTPar);
               /* hi018.104: Socket option set error */
               if(ret == RNA || ret == RFAILED)
               {
                  hiDiscSockHandle(FALSE, HI_SOCK_SEND_ERR, conCb);
                  RETVALUE(RFAILED); 
               }
               conCb->ipTtl = hdrParm->u.hdrParmIpv6.ttl.val;
            }
         }
#endif /* CMINETFLATBUF */         
      }
#endif /* IPV6_SUPPORTED */
#endif /* HI_REL_1_3 */ 

#ifdef HI_REL_1_4  
#ifdef IPV6_SUPPORTED
      /* If the socket option is not to set the TTL then ignore. 
       * Currently the 
       * upper user is not expected to set any other
       * option other than TTL. 
       * There is no problem if the upper user
       * sets more than one option. 
       * However in this case TUCL will not check 
       * the old value of TTL set
       * on the socket and will always 
       * set all the options */
      if ((tPar->type == CM_TPTPARAM_SOCK) && 
          (tPar->u.sockParam.numOpts > 0) &&
          ((tPar->u.sockParam.sockOpts[0].option ==
          CM_SOCKOPT_OPT_MCAST_TTL) || 
          (tPar->u.sockParam.sockOpts[0].option == 
          CM_SOCKOPT_OPT_MCAST6_HOPS)))
#else
      if ((tPar->type == CM_TPTPARAM_SOCK) && 
          (tPar->u.sockParam.numOpts > 0) &&
          (tPar->u.sockParam.sockOpts[0].option == 
          CM_SOCKOPT_OPT_MCAST_TTL))
#endif /* IPV6_SUPPORTED */
      {
         if (found == TRUE)
         {
            if (conCb->mCastTtl != 
                tPar->u.sockParam.sockOpts[0].optVal.value)
            {
               ret = hiSetSockOpt(&conCb->conFd, tPar);
               /* hi018.104: Socket option set error */
               if(ret == RNA || ret == RFAILED)
               {
                  hiDiscSockHandle(FALSE, HI_SOCK_SEND_ERR, conCb);
                  RETVALUE(RFAILED); 
               }
               conCb->mCastTtl = 
               tPar->u.sockParam.sockOpts[0].optVal.value;
            }
         }
         else
         {
            resetTtl = TRUE;
            lclTPar.u.sockParam.numOpts = 1;
            lclTPar.u.sockParam.sockOpts[0].option = 
                      tPar->u.sockParam.sockOpts[0].option;
            lclTPar.u.sockParam.sockOpts[0].level  = 
                                 tPar->u.sockParam.sockOpts[0].level;
            lclTPar.u.sockParam.sockOpts[0].optVal.value = 1;
            ret = hiSetSockOpt(sendFd, tPar);
            /* hi018.104: Socket option set error */
            if(ret == RNA || ret == RFAILED)
            {
               hiDiscSockHandle(FALSE, HI_SOCK_SEND_ERR, conCb);
               RETVALUE(RFAILED); 
            }
         }
      }
#endif /* HI_REL_1_4 */ 
      
#ifdef H323_PERF
      TAKE_TIMESTAMP("Before UDatReq/cmInetSendMsg(), in HI");
#endif /* H323_PERF */

      /* If the UDP socket is already connected then pass the remote 
       * address as NULLP.
       */
#ifdef IPV6_SUPPORTED
#ifdef IPV6_OPTS_SUPPORTED                                
      /* copy the src addr to hdrParm struc so that it can be available inside
       * cmInetSendMsg() to set as the src addr on outgoind IPv6 pkt */
      if(srcAddr != NULLP && srcAddr->type != CM_TPTADDR_NOTPRSNT)
      {
         hdrParm->u.hdrParmIpv6.srcAddr6.type = srcAddr->type; 
         cmMemcpy((U8 *)&hdrParm->u.hdrParmIpv6.srcAddr6.u.ipv6NetAddr, 
                  (U8 *)&srcAddr->u.ipv6TptAddr.ipv6NetAddr, (U32)16);
      }
#endif /* IPV6_OPTS_SUPPORTED */                                

      /* hi009.104 - added new argument */
      if(isUdpClt)
         ret = cmInetSendMsg(sendFd, NULLP, &memInfo, mBuf, 
                           &txLen,
#ifdef IPV6_OPTS_SUPPORTED                           
                           NULLP,
#endif /* IPV6_OPTS_SUPPORTED */                           
                           CM_INET_NO_FLAG);
      else
      {
         /* hi013.104 - specify the local interface
          * in outgoing packet */
         ret = cmInetSendMsg(sendFd, (CmInetAddr *)remAddr, &memInfo, 
                             mBuf, &txLen, 
#ifdef IPV6_OPTS_SUPPORTED                                
                             (CmInetIpHdrParm *)hdrParm,
#endif /* IPV6_OPTS_SUPPORTED */                                
                             CM_INET_NO_FLAG);
#ifdef IPV6_OPTS_SUPPORTED            
         /* call deallocation macro only when hdr param type is IPV6 */
         if (hdrParm->type == CM_HDRPARM_IPV6)
         {
            ipv6HdrParm = (CmInetIpv6HdrParm *)&hdrParm->u.hdrParmIpv6;
            CM_INET_FREE_IPV6_HDRPARM(hiCb.hiInit.region, 
                                    hiCb.hiInit.pool, 
                                    ipv6HdrParm); 
         }
#endif /* IPV6_OPTS_SUPPORTED */            
      }
#else                  
      if(isUdpClt)
         ret = cmInetSendMsg(sendFd, NULLP, &memInfo, mBuf, 
                             &txLen, CM_INET_NO_FLAG);
      else
         ret = cmInetSendMsg(sendFd, &(remAddr->u.ipv4TptAddr), &memInfo, 
                             mBuf, &txLen, CM_INET_NO_FLAG);
#endif /* IPV6_SUPPORTED  */

#ifdef H323_PERF
      TAKE_TIMESTAMP("After UDatReq/cmInetSendMsg(), in HI");
#endif /* H323_PERF */
      if (ret != ROK)
      {
   
         /* No HitDiscInd is issued, the user should assume as if the
          * data has been lost in the network */

         /* Deallocate the received message buffer */
         (Void)SPutMsg(mBuf);

         /* hi018.104: Dont send disconnect indication if failure is due *
          * to ROUTRES or RWOULDBLOCK                                    */
           
         if((ret == ROUTRES)||(ret == RWOULDBLOCK))
         {
            /* Fill up the alarm information */
            HI_FILL_ALARMINFO_MEM_ID(info, memInfo.region, memInfo.pool);

            hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                        LHI_CAUSE_SOCK_SEND_ERR, &info);

            RETVALUE(RFAILED);
         }
         /* hi001.104: added check for return value from cmInetSendMsg() */
         else if(ret == RCLOSED)  
         {   
            /* RCLOSED is returned when an ICMP message is received on a UDP
             * socket. This will happen only in the case of connected UDP
             * sockets. Hence the spConId in these cases will be valid. 
             */
            if (isUdpClt)
            {
#ifndef HI_MULTI_THREADED
               /* send DiscInd to upper user & do the required cleaning */
               /* hi018.104: Send disconnect idnication to the upper layer */ 
               hiDiscSockHandle(FALSE, HI_SOCK_SEND_ERR, conCb);
#else
               conCb->reason = HI_CON_CLOSED_BY_PEER;
               conCb->toBeDel |= HI_DEL_SEND_DISCIND;
               hiDecNumFds(conCb, conCb->fdBlkIdx);
               hiFdClr(conCb, CM_INET_SHTDWN_BOTH);
               cmHashListDelete(&sap->sapHlCp, (PTR) conCb);   
#endif /* HI_MULTI_THREADED */
               RETVALUE(RFAILED);
            }
	    else
            {
               /* hi018.104: Send disconnect idnication to the upper layer */ 
               hiDiscSockHandle(FALSE, HI_SOCK_SEND_ERR, conCb);
               RETVALUE(RFAILED); 
            }
         }

         /* hi018.104: Consider all the other errors */ 
         else
         { 
            hiSendAlarm(LCM_CATEGORY_INTERNAL, LHI_EVENT_INET_ERR,
                        LHI_CAUSE_SOCK_SEND_ERR, &info);

/* hi029.104 - Error Statistics should be incremented in all cases */	    
#ifdef HI_MULTI_THREADED
	    HI_LOCK(&hiCb.errStsLock, info, ret); 
	    if (ret != ROK)
	       HILOGERROR_DEBUG(EHI076, (ErrVal) 0, pst->dstInst, 
		     "HiUiHitUDatReq () : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */

	    /* Increment the statistics counter */
	    hiCb.errSts.sockTxErr++;

#ifdef HI_MULTI_THREADED
	    HI_UNLOCK(&hiCb.errStsLock, info, ret);
	    if (ret != ROK)
	       HILOGERROR_DEBUG(EHI077, (ErrVal) 0, pst->dstInst, 
		     "HiUiHitUDatReq () : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */

            if ((conCb->srvcType == HI_SRVC_RAW_SCTP)||
                (conCb->srvcType == HI_SRVC_RAW_SCTP_PRIOR))
            /* hi018.104: Send disconnect idnication to the upper layer */ 
            /* hi022.104: ONLY if its a RAW socket */ 
            {
               hiDiscSockHandle(FALSE, HI_SOCK_SEND_ERR, conCb);
            }
	    /* hi029.104 - Return Failure in all cases */
	    RETVALUE(RFAILED);
         }
      }
      
      /* increment the statistics counters */
      sap->genTxSts.numTxbytes += txLen;
      sap->txSts.numTxbytes += txLen;

#ifdef HI_REL_1_3  
      /* Here check the condition of protocol type then properly increment 
       * the number of message for UDP, RAW, or ICMP */
      if((!conCb) || (conCb->flag & HI_FL_UDP) || (isUdpClt))
      {
         sap->genTxSts.numTxUdpMsg++;
         sap->txSts.numTxUdpMsg++;
         /* trace the transmitted data */
         if(sap->trc)
            hiTrcBuf(sap, LHI_UDP_TXED, mBuf);
      }
      else
      {
         sap->genTxSts.numTxRawMsg++;
         sap->txSts.numTxRawMsg++;
         /* trace the transmitted data */
         if(sap->trc)
            hiTrcBuf(sap, LHI_RAW_TXED, mBuf);
      }
#ifdef HI_REL_1_4
      /* Reset IP Multicast TTL if necessary */
      if (resetTtl)
         hiSetSockOpt(sendFd, &lclTPar);
#endif /* HI_REL_1_4 */ 
#else   
      sap->txSts.numTxUdpMsg++;
      sap->genTxSts.numTxUdpMsg++;
      /* trace the transmitted data */
      if(sap->trc)
         hiTrcBuf(sap, LHI_UDP_TXED, mBuf);
#endif /* HI_REL_1_3 */ 
      
      /* deallocate the message buffer */
      (Void)SPutMsg(mBuf);

#ifdef H323_PERF
      TAKE_TIMESTAMP("L/T DatReq - End of HiUiHitUDatReq, in HC");
#endif /* H323_PERF */

      RETVALUE(ROK);
   } /* end if */
#endif /* HI_LPBK */

   /* Deallocate the received message buffer */
   (Void)SPutMsg(mBuf);

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Leaving HiUiHitUDatReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif

   RETVALUE(RFAILED);
}/* end of HiUiHitUDatReq() */


/*
*
*       Fun:   Primitive to disconnect a TCP (server/client) connection
*              or a UDP server.
*
*       Desc:  This primitive is used by the service user to either
*              shutdown or close the socket associated with "conId".
*              "conId" may have eithe service user's or provider's 
*              connection id, depending upon the value of "choice"
*              parameter.
*              The TCP UDP Convergence Layer responds with a 
*              HiUiHitDiscCfm to the user in case the  request was 
*              successful.
*              In addition this primitive may also be used to leave the
*              membership of a multicast group for UDP sockets.
*
*              "action" specifies the whether the socket has to be
*              closed or it has to be shutdown or it is a request to
*              leave a multicast group.
*
*              The possible values of action are :
*              "action":
*                    HI_SHTDWN_RECV :shutdown the read half of the socket
*                    HI_SHTDWN_SEND :shutdown the write half of the socket
*                    HI_SHTDWN_BOTH :shutdown both the read and write halves
*                                    of the socket
*                    HI_CLOSE       :close the socket
*                    HI_LEAVE_MCAST_GROUP: leave the specified multicast 
*                                          group for a UDP socket.
*              "tPar" :
*                    Pointer to Transport Parameters.  This parameter is 
*                    used to specify the address of the multicast group 
*                    for a UDP multicast case. In all other cases, it 
*                    should be initialized to CM_TPTPARAM_NOTPRSNT
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: The connection block is released only if the "action"
*              is specified as HI_CLOSE
*              If connection block can not be found in the hash list,
*              TUCL silently returns back. This may happen in a case
*              when TUCL has already given a XxYyHitDiscInd to the
*              service user and has released the connection block.
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiHitDiscReq
(
Pst *pst,                /* post structure */ 
SpId spId,               /* service provider id */ 
U8 choice,               /* choice of user or provider connection id */
UConnId conId,           /* connection id */
Action action,           /* action to be performed */
CmTptParam *tPar         /* transport parameters */ 
)
#else
PUBLIC S16 HiUiHitDiscReq(pst, spId, choice, conId, action, tPar)
Pst *pst;                /* post structure */ 
SpId spId;               /* service provider id */ 
U8 choice;               /* choice of user or provider connection id */
UConnId conId;           /* connection id */
Action action;           /* action to be performed */
CmTptParam *tPar;        /* transport parameters */ 
#endif
{

   HiSap               *sap;
   HiConCb             *conCb;
   HiConCb             *prevConCb;
   HiAlarmInfo         info;
   S16                 ret;
  
   TRC3(HiUiHitDiscReq)

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "HiUiHitDiscReq() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

#ifndef SS_MULTIPLE_PROCS
   UNUSED(pst);
#endif  /* SS_MULTIPLE_PROCS */

   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
          "HiUiHitDiscReq(pst, spId(%d), choice(%d), conId(%ld), \
          action(%d))\n", spId, choice, conId, action));

   /* initialize spId in alarmInfo */
   info.spId = spId;
   info.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   /* validation of input parameters */
#if (ERRCLASS & ERRCLS_INT_PAR)
   HI_CHK_SPID(spId, LHI_EVENT_DISCREQ, ret, info);
   if (ret != ROK)
   {
      HILOGERROR_INT_PAR(EHI078, (ErrVal)spId, pst->dstInst, 
                 "HiUiHitDiscReq(): invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   sap = hiCb.sapLstPtr[spId];
#if (ERRCLASS & ERRCLS_INT_PAR)
   if(sap->state != HI_ST_BND)
   {
      HILOGERROR_INT_PAR( EHI079, (ErrVal) sap->state, pst->dstInst, 
                 "HiUiHitDiscReq(): Sap not Bound");
      HI_FILL_ALARMINFO_SAP_STATE(info, sap->state);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_DISCREQ,
                  LCM_CAUSE_INV_STATE, &info);
      RETVALUE(RFAILED);
   }

#ifdef IPV6_SUPPORTED
   if((action == HI_LEAVE_MCAST_GROUP) && ((tPar->type != CM_TPTPARAM_SOCK) ||
      ((tPar->u.sockParam.sockOpts[0].option != CM_SOCKOPT_OPT_DRP_MCAST_MBR) &&
       (tPar->u.sockParam.sockOpts[0].option != CM_SOCKOPT_OPT_DRP_MCAST6_MBR))))
#else
   if((action == HI_LEAVE_MCAST_GROUP) && ((tPar->type != CM_TPTPARAM_SOCK) ||
     (tPar->u.sockParam.sockOpts[0].option != CM_SOCKOPT_OPT_DRP_MCAST_MBR)))
#endif /* IPV6_SUPPORTED */
   {
      HILOGERROR_INT_PAR( EHI080, (ErrVal) sap->state, pst->dstInst, 
                 "HiUiHitDiscReq(): invalid transport parameters");
#ifdef HI_MULTI_THREADED
      HiUiHitDiscCfm(&sap->uiDiscCfmPst, sap->suId, choice, conId, action);   
#else      
      HiUiHitDiscCfm(&sap->uiPst, sap->suId, choice, conId, action);   
#endif /* HI_MULTI_THREADED */
      HI_FILL_ALARMINFO_PAR_TYPE(info, LHI_INV_TPT_PARAM);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_DISCREQ,
                  LCM_CAUSE_INV_PAR_VAL, &info);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* find the connection block */
   if (choice == HI_PROVIDER_CON_ID)
   {
      ret = cmHashListFind (&sap->sapHlCp, (U8 *)&conId, sizeof(UConnId), 
                            0, (PTR *)&conCb);
      if (ret !=ROK)
      {
#ifdef HI_MULTI_THREADED
         HiUiHitDiscCfm(&sap->uiDiscCfmPst, sap->suId, choice, conId, action);
#else      
         HiUiHitDiscCfm(&sap->uiPst, sap->suId, choice, conId, action);   
#endif /* HI_MULTI_THREADED */
         RETVALUE(RFAILED);
      }
   }
   else /* the user has specified suConId  */
   {
       conCb = prevConCb = NULLP;
       while((ret = cmHashListGetNext(&sap->sapHlCp, (PTR)prevConCb, 
                                      (PTR *)&conCb)) == ROK)
       {
          if (conCb->suConId == conId)
             break;

          prevConCb = conCb;
          conCb = NULLP;
       }
       if ( conCb == NULLP )
       {
#ifdef HI_MULTI_THREADED
         HiUiHitDiscCfm(&sap->uiDiscCfmPst, sap->suId, choice, conId, action); 
#else      
         HiUiHitDiscCfm(&sap->uiPst, sap->suId, choice, conId, action);
#endif /* HI_MULTI_THREADED */
         RETVALUE(RFAILED);
       }
   }/* end else */

   /* store the action field in conCb */
   conCb->action = action;

   switch(action)
   {
      case HI_SHTDWN_RECV:
         conCb->conState = HI_ST_CONNECTED_NORD;
#ifdef HI_MULTI_THREADED     
         conCb->toBeDel |= HI_DEL_SEND_DISCCFM;
         hiAddConCbToCmList(conCb, HI_CM_TOBEDEL_LIST);        
#else
         HI_SHUT_SOCKET(conCb, CM_INET_SHTDWN_RECV);
         /* issue a Disconnect Confirm to the user */
         HiUiHitDiscCfm(&sap->uiPst, sap->suId, choice, conId, action);
#endif /* HI_MULTI_THREADED      */
         break;

      case HI_SHTDWN_SEND:
         conCb->conState = HI_ST_CONNECTED_NOWR;
#ifdef HI_MULTI_THREADED     
         conCb->toBeDel |= HI_DEL_SEND_DISCCFM;
         hiAddConCbToCmList(conCb, HI_CM_TOBEDEL_LIST);        
#else
         HI_SHUT_SOCKET(conCb, CM_INET_SHTDWN_SEND);

         /* issue a Disconnect Confirm to the user */
         HiUiHitDiscCfm(&sap->uiPst, sap->suId, choice, conId, action);
#endif /* HI_MULTI_THREADED      */
         break;

      case HI_SHTDWN_BOTH:
         conCb->conState = HI_ST_CONNECTED_NORDWR;
#ifdef HI_MULTI_THREADED     
         conCb->toBeDel |= HI_DEL_SEND_DISCCFM;
         hiAddConCbToCmList(conCb, HI_CM_TOBEDEL_LIST);        
#else
         HI_SHUT_SOCKET(conCb, CM_INET_SHTDWN_BOTH);

         /* issue a Disconnect Confirm to the user */
         HiUiHitDiscCfm(&sap->uiPst, sap->suId, choice, conId, action);
#endif /* HI_MULTI_THREADED      */
         break;

      case HI_CLOSE:
#ifdef HI_MULTI_THREADED 
         /* Delete this conCb from the sap hash list */
         cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
         conCb->toBeDel |= HI_DEL_SEND_DISCCFM;
         hiDecNumFds(conCb, conCb->fdBlkIdx);
         /* Close the Icmp socket if necessary */
         hiChkAndCloseIcmpSock(conCb);
         hiAddConCbToCmList(conCb, HI_CM_TOBEDEL_LIST);
#else
         /* de-allocate the connection block allocated */
         /* close the socket */
         hiFreeConCb(conCb);
#endif /* HI_MULTI_THREADED      */
         break;

      case HI_LEAVE_MCAST_GROUP:
#ifdef HI_LPBK
         if(conCb->flag & HI_FL_MCAST_CONCB)
            ret = hiLpBkProcMCastGrp(conCb, tPar);
#else
         ret = hiSetSockOpt(&conCb->conFd, tPar);
#endif /* HI_LPBK */
         if(ret != ROK)
         {
#ifdef HI_MULTI_THREADED     
            /* Delete this conCb from the sap hash list */
            cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
            conCb->toBeDel |= HI_DEL_SEND_DISCCFM;
            conCb->reason = HI_INTERNAL_ERR;
            hiDecNumFds(conCb, conCb->fdBlkIdx);
            hiAddConCbToCmList(conCb, HI_CM_TOBEDEL_LIST);
#else
            hiFreeConCb(conCb);
#endif /* HI_MULTI_THREADED      */
            RETVALUE(RFAILED);
         }

         /* issue a Disconnect Confirm to the user */
#ifdef HI_MULTI_THREADED     
         HiUiHitDiscCfm(&sap->uiDiscCfmPst, sap->suId, choice, conId, action);
#else
         HiUiHitDiscCfm(&sap->uiPst, sap->suId, choice, conId, action);
#endif /* HI_MULTI_THREADED      */
         break;
         
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         HILOGERROR_INT_PAR( EHI081, (ErrVal) spId, pst->dstInst,
                    "HiUiHitDiscReq(): Invalid action");

         HI_FILL_ALARMINFO_PAR_TYPE(info, LHI_INV_ACTION);
         hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_DISCREQ,
                     LCM_CAUSE_INV_PAR_VAL, &info);

#endif /* ERRCLS_INT_PAR */
         RETVALUE(RFAILED);
   }/* end switch */

   RETVALUE(ROK);
}/* end of HiUiHitDiscReq() */

#ifdef HI_MULTI_THREADED     

/*
*
*       Fun:   HiUiIntDiscInd 
*       
*       Desc:  Internal primitive invoked by one of the receive threads 
*              to inform this instance that a connection is closed. 
*
*              This function is used by the TUCL receive threads to inform
*              the TUCL instances that a disconnect indication has come in
*              on a TCP client or a socket is being closed because of some
*              error. 
*           
*              If the connection control block for this conCb is found in 
*              the sap hash list a Disconnect indication is given to the 
*              upper user. This function will also close the socket and 
*              deallocate memory of the conCb.
*              
*              If the conCb is not found in the sap hash list the receive 
*              thread will give a disconnect indication.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: This is an internal primitive and should not be used by other
*              layers.
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiIntDiscInd 
(
Pst *pst,                /* post structure */ 
SpId spId,               /* service provider id */ 
U8 choice,               /* choice of user or provider connection id */
UConnId conId,           /* connection id */
Reason reason            /* reason */
)
#else
PUBLIC S16 HiUiIntDiscInd(pst, spId, choice, conId, reason)
Pst *pst;                /* post structure */ 
SpId spId;               /* service provider id */ 
U8 choice;               /* choice of user or provider connection id */
UConnId conId;           /* connection id */
Reason reason;           /* reason */
#endif
{
   S16      ret;           /* return value */
   HiSap    *sap;          /* sap pointer */
   HiConCb  *conCb;        /* connection control block */
   HiAlarmInfo alInfo;     /* alarm information */

   TRC3(HiUiIntDiscInd)

   /* Initialize alarmInfo */
   alInfo.spId = spId;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
 
   /* The sap can be null if after deleting a sap there are still some
    * pending internal primitives left over */
   sap = hiCb.sapLstPtr[spId];
   if (!sap)
      RETVALUE(ROK);

   /* Check the sap hashlist for a connection control block */
   ret = cmHashListFind (&sap->sapHlCp, (U8 *) &conId, sizeof(UConnId),
                         0, (PTR *)&conCb);
   if (ret != ROK)
   {
      /* This may be due to a race condition here. The TUCL instance has
       * received DiscReq just before it got a DiscInd internally. In this
       * case the conCb will not be found in the sap hashlist. The conCb
       * will be in the toBeDel list of the common information structure
       */
      RETVALUE(ROK);
   }

   /* The following actions are taken once the conCb is found */

   /* Close the Icmp socket if necessary */
   hiChkAndCloseIcmpSock(conCb);

   /* Delete the conCb from the sap hashlist */
   cmHashListDelete(&sap->sapHlCp, (PTR) conCb);

   /* Decrement the number of file descriptors */
   hiDecNumFds(conCb, conCb->fdBlkIdx);

   /* If there was an ICMP receive error then inform the appropriate 
    * receive thread to send a disconnect indication */
   if (reason == HI_SOCK_ICMP_RECV_ERR)
   {
      conCb->toBeDel |= HI_DEL_SEND_DISCIND;
      hiAddConCbToCmList(conCb, HI_CM_TOBEDEL_LIST);        
      RETVALUE(ROK);
   }

   if (conCb->protocol != CM_PROTOCOL_ICMP)
      HI_CLOSE_SOCKET(&conCb->conFd);

   HI_DISCIND(sap, HI_USER_CON_ID, conCb->suConId, reason);

   /* Delete the conCb from the spConIdHlCp */
   hiRmvFrmSpConIdHl(conCb);

   /* If this is a streams socket deallocate the transmit queue lock */
   if (conCb->flag & HI_FL_TCP)
   {
      if (conCb->rxBuf)
         SPutMsg(conCb->rxBuf);

      SFlushQueue(&conCb->txQ);
      SDestroyLock(&conCb->txQLockId);
   }

   /* Free the memory associated with the conCb */
   HI_FREE(sizeof(HiConCb), conCb);

   RETVALUE(ROK);
} /* end of HiUiIntDiscInd */


/*
*
*       Fun:   HiUiIntCongOff
*              
*
*       Desc:  Internal primitive invoked by one of the receive threads 
*              to inform this instance that all buffers in the transmit
*              queue are sent.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: This is an internal primitive and should not be used by other
*              layers.
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiIntCongOff 
(
Pst *pst,                /* post structure */ 
SpId spId,               /* service provider id */ 
UConnId conId           /* connection id */
)
#else
PUBLIC S16 HiUiIntCongOff(pst, spId, conId)
Pst *pst;                /* post structure */ 
SpId spId;               /* service provider id */ 
UConnId conId;           /* connection id */
#endif
{
   S16      ret;           /* return value */
   S16      retVal;        /* return value */
   HiSap    *sap;          /* sap pointer */
   HiConCb  *conCb;        /* connection control block */
   HiAlarmInfo alInfo;     /* alarm information */
   QLen        qLen;

   TRC3(HiUiIntCongOff)

   /* Initialize alarmInfo */
   alInfo.spId = spId;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
   
   /* validation of sap id */
#if (ERRCLASS & ERRCLS_INT_PAR)
   HI_CHK_INT_SPID(spId, ret);
   if (ret != ROK)
   {
      HILOGERROR_INT_PAR(EHI082, (ErrVal)spId, pst->dstInst, 
                 "HiUiIntCongOff () : Invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   sap = hiCb.sapLstPtr[spId];

   /* Check the sap hashlist for a connection control block */
   ret = cmHashListFind (&sap->sapHlCp, (U8 *) &conId, sizeof(UConnId),
                         0, (PTR *)&conCb);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   /* Lock the transmit queue congestion list */
   HI_LOCK(&conCb->txQLockId, alInfo, ret); 
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI083, (ErrVal) 0, pst->dstInst, 
            "HiUiIntCongOff () : Unable to obtain transmit queue lock \n");
      RETVALUE(RFAILED);
   }

   /* Check the length of the transmit queue. It it is zero set the txQSiz
    * to zero */
   ret = SFndLenQueue(&conCb->txQ, &qLen);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI084, (ErrVal)ret, 0,
                 "hiChkTxQ() failed: SFndLenQueue failed");
      HI_UNLOCK(&conCb->txQLockId, alInfo, retVal);
      if (retVal != ROK)
         HILOGERROR_DEBUG(EHI085, (ErrVal)retVal, sap->uiPst.srcInst,
               "hiChkTxQ - Failed to unlock transmit queue");
      RETVALUE(RFAILED);
   }

   if (!qLen)
      conCb->mBufInQ = FALSE;

   HI_UNLOCK(&conCb->txQLockId, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI086, (ErrVal)ret, sap->uiPst.srcInst,
               "hiChkTxQ - Failed to unlock transmit queue");
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* end of HiUiIntCongOff */


/*
*
*       Fun:   HiUiIntRecvThrClosed
*
*       Desc:  Internal primitive invoked by one of the receive threads 
*              to inform the zeroeth instance that the receive thread is
*              closed.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: This is an internal primitive and should not be used by other
*              layers.
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiIntRecvThrClosed
(
Pst *pst                 /* post structure */ 
)
#else
PUBLIC S16 HiUiIntRecvThrClosed(pst)
Pst *pst;                /* post structure */ 
#endif
{
   HiAlarmInfo    alInfo;
   HiSendThrMsg   msg;
   S16            i;
   U16            fdGrpNum;
   HiFdGrpInfo    *grpInfoPtr;
   HiMngmt        cfmMsg;             
   Header         hdr;                

   TRC3(HiUiIntRecvThrClosed);

   /* Initialisation */
   alInfo.spId = -1;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
   
   /* Increase the number of threads closed */
   hiCb.numThrClosed += 1;

   /* Get this file descriptor group number */
   fdGrpNum = pst->srcInst - hiCb.lastInstUsed;
   fdGrpNum -= 1;

   /* Destroy the receive thread */
#ifdef SS_MULTIPLE_PROCS 
   SDeregTTsk(pst->srcProcId, ENTHI, pst->srcInst);
#else /* SS_MULTIPLE_PROCS */
   SDeregTTsk(ENTHI, pst->srcInst);
#endif /* SS_MULTIPLE_PROCS */
   SDestroySTsk(hiCb.tskIdArray[fdGrpNum]);      

   /* Check if a pending shutdown operation is present */
   if (!hiCb.pendOp.flag)
   {
      /* A receive thread unexpectedly closed. TUCL cannot function 
       * in this scenario. All receive threads are closed and a 
       * status indication given to the system manager */
      for (i = 0; i < hiCb.numFdGrps; i++)
      {
         msg.msgType = HI_ENDTSK_MSG;
         hiSendRecvThrMsg(i, &msg); 
      }

      /* Send an alarm to the layer manager */
      hiSendAlarm(LCM_CATEGORY_INTERNAL, 
                  LHI_EVENT_RECVTHR_CLOSED,
                  LCM_CAUSE_UNKNOWN, &alInfo);

      RETVALUE(ROK);
   }

   grpInfoPtr = hiCb.hiFdGrpInfoLstPtr[fdGrpNum];
   
   /* De-init the file descriptor group */
   hiDeInitFdGrp(grpInfoPtr);  

   if (hiCb.numThrClosed == hiCb.numFdGrps)
   {
      /* All receive threads are closed */
      HI_FREE((hiCb.cfg.numSaps*sizeof(PTR)), hiCb.sapLstPtr);

      HI_ZERO(&(hiCb.hiInit.lmPst), sizeof(Pst));
     
      HI_SOCK_DEINIT();

      /* Deallocate the file descriptor groups */
      for (i = 0; i < hiCb.numFdGrps; i++)
      {
         if (hiCb.hiFdGrpInfoLstPtr[i])
         {
            HI_FREE(sizeof(HiFdGrpInfo), hiCb.hiFdGrpInfoLstPtr[i]);
            hiCb.hiFdGrpInfoLstPtr[i] = NULLP;
         }
      }

      HI_FREE((hiCb.numFdGrps * sizeof(PTR)), hiCb.hiFdGrpInfoLstPtr);
      HI_FREE((hiCb.numFdGrps * sizeof(SSTskId)), hiCb.tskIdArray);

      /* Destroy the locks */
      SDestroyLock(&hiCb.grpLock);
      SDestroyLock(&hiCb.errStsLock);

      SDestroyLock(&hiCb.icmpHlLock);
#ifdef IPV6_SUPPORTED
      SDestroyLock(&hiCb.icmp6HlLock);
#endif /* IPV6_SUPPORTED */

      /* hi001.104 - Deallocate ICMP hashlist */
      HI_ZERO(&hiCb.icmpConFd, sizeof(CmInetFd));
      cmHashListDeinit(&hiCb.icmpHlCp);
#ifdef IPV6_SUPPORTED 
      HI_ZERO(&hiCb.icmp6ConFd, sizeof(CmInetFd));
      cmHashListDeinit(&hiCb.icmp6HlCp);
#endif /* IPV6_SUPPORTED */  

      /* Send a control confirm to the layer manager */

      /* Copy the header into a local variable */
      cmMemcpy((U8 *)&hdr, (U8 *)&hiCb.pendOp.hdr, 
               (U32) sizeof(Header));

      /* Copy the overwrite the post structure */
      cmMemcpy((U8 *)pst, (U8 *)&hiCb.pendOp.lmPst, 
               (U32) sizeof(Pst));

      /* Send a confirm message */
      hiSendLmCfm(pst, TCNTRL, &hdr, LCM_PRIM_OK,
                  LCM_REASON_NOT_APPL, &cfmMsg);
     
      /* hi001.104 - Zero out only the cfg structure and not the entire 
       * structure. Also set the cfgDone to FALSE.
       */
      (Void) SPutSMem(hiCb.hiInit.region, hiCb.hiInit.pool);
      hiCb.cfgDone = FALSE;
      hiCb.lastGrpUsed = 0;
      hiCb.numThrClosed = 0;
      hiCb.numFdGrps = 0;
      hiCb.numSapsToBeDel = 0;
       
      HI_ZERO(&(hiCb.pendOp), sizeof(HiPendOp));
      HI_ZERO(&(hiCb.cfg), sizeof(HiGenCfg));
   }
    
   RETVALUE(ROK);
} /* end of HiUiIntRecvThrClosed */


/*
*
*       Fun:   HiUiIntZeroStsReq 
*
*       Desc:  primitive invoked by one of the receive threads 
*              or TUCL instance 0 to request the zeroing of statistics.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: 
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiIntZeroStsReq
(
Pst *pst,                /* post structure */ 
U8  type,                /* type of statistics to zero out */
SpId spId                /* service provider id */ 
)
#else
PUBLIC S16 HiUiIntZeroStsReq(pst, type, spId)
Pst *pst;                /* post structure */ 
U8  type;                /* type of statistics to zero out */
SpId spId;               /* service provider id */ 
#endif
{
   HiSap       *sap;
   /* hi015.104: reset the counter */
   StsCntr     numCons;
   
   sap = hiCb.sapLstPtr[spId];

   if (sap == NULLP)
      RETVALUE(RFAILED);

   if (type == HI_ZERO_GENSTS)
   {
      /* hi016.104: reset the counter */
      numCons = sap->genTxSts.numCons;
      HI_ZERO(&sap->genTxSts, sizeof(HiTxSts));
      sap->genTxSts.numCons = numCons;
   }
   else
   {
      /* hi015.104: reset the counter */
      numCons = sap->txSts.numCons;
      HI_ZERO(&sap->txSts, sizeof(HiTxSts));
      sap->txSts.numCons = numCons;
   }
   
   RETVALUE(ROK);

} /* end of HiUiIntZeroStsReq */


/*
*
*       Fun:   HiUiIntSapDisReq
*              
*       Desc:  Internal primitive invoked by TUCL instance 0 to disable 
*              a sap.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: This is an internal primitive and should not be used by other
*              layers.
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiIntSapDisReq
(
Pst *pst,                /* post structure */ 
SpId spId                /* service provider id */ 
)
#else
PUBLIC S16 HiUiIntSapDisReq(pst, spId)
Pst *pst;                /* post structure */ 
SpId spId;               /* service provider id */ 
#endif
{
   HiSap          *sap;
   S16            ret;

   /* Initialisations */
   ret = ROK;

#if (ERRCLASS & ERRCLS_DEBUG)
   HI_CHK_INT_SPID(spId, ret); 
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI087, (ErrVal)spId, pst->dstInst, 
                 "HiUiIntSapDisReq(): Invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */

   sap = hiCb.sapLstPtr[spId];

   if (sap->state != HI_ST_UBND)
   {
      /* Clean up all connections on this sap */
      hiCleanupSapConCbs(sap, HI_DELSAP_MSG);
   
      sap->state = HI_ST_UBND;

      /* Send a CntrlCfm immediately if there are no pending connections */
      if (sap->numRecvThrCfmsExptd == 0)
         hiSendIntSapDisCfm(spId);
   }
   else
      hiSendIntSapDisCfm(spId);

   RETVALUE(ROK);

} /* end of HiUiIntSapDisReq */


/*
*
*       Fun:   HiUiIntSapConCbDel
*              
*       Desc:  Internal primitive invoked by all the receive threads 
*              to inform this instance that all conCbs related to the sap
*              have been deleted from the file descriptor list hash lists. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: This is an internal primitive and should not be used by other
*              layers.
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiIntSapConCbDel
(
Pst *pst,                /* post structure */ 
SpId spId                /* service provider id */ 
)
#else
PUBLIC S16 HiUiIntSapConCbDel(pst, spId)
Pst *pst;                /* post structure */ 
SpId spId;               /* service provider id */ 
#endif
{
   HiSap       *sap;    /* Sap */
   S16         ret;

   TRC3(HiUiIntSapConCbDel)

   /* Initialisations */
   ret = ROK;

#if (ERRCLASS & ERRCLS_DEBUG)
   HI_CHK_INT_SPID(spId, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI088, (ErrVal)spId, pst->dstInst, 
                 "HiUiIntLastConCbDel(): Invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */

   sap =  hiCb.sapLstPtr[spId];
   sap->numRecvThrCfmsExptd --;

   if (sap->numRecvThrCfmsExptd == 0)
   {
      if (sap->uiPst.srcInst == 0)
         HiUiIntSapDisCfm(pst, spId);
      else
         hiSendIntSapDisCfm(spId);
   }

   RETVALUE(ROK);
} /* end of HiUiIntSapConCbDel */


/*
*
*       Fun:   HiUiIntSapDisCfm
*              
*       Desc:  Internal primitive invoked to inform the instance 0 that
*              the sap has been disabled.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: This is an internal primitive and should not be used by other
*              layers.
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiIntSapDisCfm
(
Pst *pst,                /* post structure */ 
SpId spId                /* service provider id */ 
)
#else
PUBLIC S16 HiUiIntSapDisCfm(pst, spId)
Pst *pst;                /* post structure */ 
SpId spId;               /* service provider id */ 
#endif
{
   S16            ret;
   HiSap          *sap;
   Bool           sendCfm;
   Bool           freeSap;
   HiMngmt        cfmMsg;
   Header         hdr;
   HiSendThrMsg   msg;
   U16            i;

   /* Initialisations */
   ret = ROK;

   /* validation of input parameters */
#if (ERRCLASS & ERRCLS_DEBUG)
   HI_CHK_INT_SPID(spId, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI089, (ErrVal)spId, pst->dstInst, 
                 "HiUiIntSapDisCfm(): Invalid spId");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */
   
   /* Initialisations */
   sendCfm = FALSE;
   freeSap = FALSE;
   
   sap = hiCb.sapLstPtr[spId];

   /* Check if the sap has a pending operation is present */
   if (sap->pendOp.flag == TRUE)
   {
      if (sap->pendOp.elmnt == STGRTSAP)
      {
         if (sap->pendOp.action == ADEL)
            freeSap = TRUE;

         hiCb.numGrpSapsToBeDel --;
            
         if (hiCb.numGrpSapsToBeDel == 0)
            sendCfm = TRUE;
         else
            sap->pendOp.flag = FALSE;
      }
      else
      {
         /* Send a sap control confirm */
         if (sap->pendOp.action == ADEL)
            freeSap = TRUE;

         sendCfm = TRUE;
      }
   
      if (sendCfm == TRUE)
      {
         /* Send a sap control confirm */
         cmMemcpy((U8 *)&hdr, (U8 *)&sap->pendOp.hdr, 
            (U32) sizeof(Header));

         /* Overwrite the incoming post structure */
         cmMemcpy((U8 *)pst, (U8 *)&sap->pendOp.lmPst, 
                  (U32) sizeof(Pst));

         if (sap->pendOp.action == AUBND_DIS)
         {
            sap->contEnt = ENTSM;

            sap->state = HI_ST_UBND;
         }

         hiSendLmCfm(pst, TCNTRL, &hdr, LCM_PRIM_OK, 
                     LCM_REASON_NOT_APPL, &cfmMsg);
      }

      if (freeSap)
         /* Free the sap resources */
         HI_FREE_SAP_RES(sap);
   }

   
   if (hiCb.pendOp.flag == TRUE)
   {
      hiCb.numSapsToBeDel --;

      /* Free the sap resources */
      if (!freeSap)
         HI_FREE_SAP_RES(sap);

      if (hiCb.numSapsToBeDel == 0)
      {
         if (hiCb.numThrClosed == 0)
         {
            msg.msgType = HI_ENDTSK_MSG;
            for (i = 0; i < hiCb.numFdGrps; i++)
               hiSendRecvThrMsg(i, &msg);
         }
      }
   }

   RETVALUE(ROK);
} /* end of HiUiIntSapDisCfm */

#endif /* HI_MULTI_THREADED */ 


/********************************************************************30**
 
         End of file:     hi_bdy1.c@@/main/4 - Thu Jun 28 13:29:37 2001

*********************************************************************31*/
 
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      asa  1. initial release.
1.1+         hi002.11 asa  1. changes for loopback mode.
                          2. added spConId in HitUDatReq.
                          3. added HitConReq procedure for UDP clients.
                          4. added processing for TCP application 
                             specific header.
                          5. miscellaneous bug fixes.
1.1+         hi003.11 asa  1. removed an error check from HitBndReq
                          2. initialized "type" in HitConReq
1.1+         hi005.11 cvp  1. corrected confirm type in the LhiStaReq 
                             primitive.
/main/2       ---      cvp  1. added support for multiple file descriptor 
                             sets.
                          2. added support for CM_INADDR_ANY server for 
                             loopback mode.
                          3. added check for ROUTRES return value from 
                             cmInetRecvMsg and cmInetSendMsg functions.
                          4. changed the copyright header.
/main/4      ---      sb   1. Changes for Raw Socket Support in TUCL.
                          2. Application also listen to Raw ICMP messages 
                             depending on the filtering parameter provided 
                             in ServOpenReq primitive.
                          3. Ip header parameters like tos, ttl, dfBit can
                             be modified for any Raw outgoing packet. 
/main/4     hi002.13  cvp 1. Check for RCLOSED from cmInetSendMsg.
/main/4     hi003.13  cvp 1. Added support for new service type.
                          2. Incrementing queues sizes if message was not 
                             sent fully.
/main/4     hi005.13  cvp 1.  Added a check for RCLOSED from 
                             cmInetConnect function to check for 
                             connection refused errors.
                          2. Removed compiler warnings in LPBK mode.
/main/4     hi007.13  zmc 1. Fix the compilation failure due to hi005.13 
                             patch.
                          2. Add the checking for the common UDP socket.
                      cvp 3. Removing the host to network conversion of
                             the source address. This is done in the
                             hiPkIpv4Hdr function.
/main/4      ---      cvp 1. Multi-threaded related changes.
                          2. Changes to support IPV6.
                          3. changed the copyright header.
/main/4     hi001.104  mmh 1. Fixed a bug (!mBuf) to (mBuf) in HiUiHitUDatReq() 
                             and HiUiHitDatReq(). 
                          2. Added check for return value from cmInetSendMsg()
                             in function HiUiHitUDatReq(). The value RCLOSED
                             will be returned when an ICMP message is 
                             received on connected UDP socket.
                      cvp 3. Zeroing out only the cfg structure and not the 
                             whole hiCb in shutdown.
            hi004.104 mmh 1. TOS value initialized.
            hi009.104 mmh 1. added new service type in HiUiHitServOpenReq()
                          2. call cmInetSendMsg & cmInetRecvMsg with different
                             new arguments.
                          3. added check for invalid IPv4 options length.
                          4. added to set/reset IPv4 IP_OPTIONS
                          5. update the header length and total length
                             when IP_OPTIONS are inserted manually.
                          6. insert IP_OPTION router alert by socket option
                             or manually if not supported.
                          7. rolling upgrade changes, under the compile flag
                              HI_RUG, as per tcr0020.txt:
                           -  during general configuration, memory allocation
                              for storing interface version information and 
                              configuration and re-configuration of LM 
                              interface version number within lmPst. 
                           -  lmPst made reconfigurable.
                           -  reconfigure version info in already configured
                              snap or copy version info to new sap.
                           -  during shutdown free memory allocated for version
                              information.
                           -  fill up self and remote interface version info 
                              in status struct in function HiMiLhiStaReq
                           -  in the system agent control request, handling for 
                              request type SHT_REQTYPE_GETVER and
                              SHT_REQTYPE_SETVER.
                           -  in HiMiShtCntrlReq() added the missing assignment
/main/4     hi013.104 bdu 1. setting the interface in the outgoing packet in 
                             UDatReq if IPV6_OPTS_SUPPORTED is enabled. 
/main/4     hi014.104 bdu 1. Fix one problem in HiUiHitDatReq.
/main/4     hi015.104 zmc 1. reset the counter
/main/4     hi017.104 zmc 1. Needs to first check the resource 
                             before checking the flag
/main/4     hi018.104 zmc 1. If socket not available free mBuf and 
                             return failure
/main/4     hi019.104 zmc 1. Fix the memory leak when spConnId is not
                             present in HiUiHitUDatReq.
/main/4     hi022.104 rs  1. Fix for sending disconnect indication.
/main/4     hi023.104 jc  1. Fix for setting IP TOS for accepted connections
/main/4+    hi025.104 pr  1. SS_MULTIPLE_PROCS flag added.
/main/4+    hi026.104 jc  1. Fix for initializing tPar->u.sockParam.numOpts
/main/4+    hi027.104 jc  1. Put hi026 changes under HI_REL_1_4 Flag
/main/4+    hi029.104 jc  1. Put hi026 changes under HI_REL_1_4 Flag
*********************************************************************91*/
