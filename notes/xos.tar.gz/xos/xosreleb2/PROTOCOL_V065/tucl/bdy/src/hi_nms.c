/* ***************************************************************************
 *        (c) COPYRIGHT 1995-2006 by Xinwei, Inc.
 *                   All rights reserved.
 *
 * hi_nms.c:  
 *          tucl protocol oam config function.
 *           
 * Author:
 *          zhouguishuang
 * Date:
 *          2006-5-23
 * Last Modified:
 *
 ****************************************************************************/
#ifdef CP_OAM_SUPPORT
#include "hi_common.h"
#include "xosshell.h"
#include "cp_tab_def.h"
#include "sm.x"
#include "hi_cfg.h"

#include "hi_oam.x"
#include "oam_interface.h"
#ifdef CP_OAM_DATA_SHOW
EXTERN void hi_print_state_cb_info(U16 print_action);
#endif



VOID hiResetCfgData(void)
{
  return;
}



/*****************************************************************************
*
*       ����:   hiRecvInitCfg
*
*       ����:   ͨ�����ܻ�ȡTUCL���á�
*
*       ����ֵ:   ʧ��:           RFAILED
*                 �ɹ�:           ROK
*       �ļ�:   hi_nms.c
*
*/
S16 hiRecvInitCfg(unsigned short msgtype, tb_record* prow)
{
   HiCfgGenWG  * tmphiCfgGen=NULLP;

    
  while(prow)
  {
    switch(prow->tableid)
    {
      case APP_TABLE_ID_VOIP_TUCL_GEN:
        
        tmphiCfgGen =(HiCfgGenWG *) prow->panytbrow;

        if((tmphiCfgGen->numSaps >= 1)&&(tmphiCfgGen->numSaps <=5))
        {
                          hiCfgGenWG.numSaps    = tmphiCfgGen->numSaps;
        }
                else
                {
                            SPrint("\nTUCL:numSaps cfg value error.range:[1-5].\n");
              return RFAILED;
                }

        if((tmphiCfgGen->numCons >= 10)&&(tmphiCfgGen->numCons <=100000))
        {
                          hiCfgGenWG.numCons      = tmphiCfgGen->numCons;
        }                
                else
                {
                            SPrint("\nTUCL:numCons cfg value error.range:[10-100000].\n");
              return RFAILED;
                }

        break;

      default:
        break;
    }

    prow = prow->next;
  }
    return 0;                                         
}

/*****************************************************************************
*
*       ����:   hiSendCfgMsg
*
*       ����:   ��д�������ݿ鵽SM���С�
*
*       ����ֵ:   ʧ��:           RFAILED
*                 �ɹ�:           ROK
*       �ļ�:   hi_nms.c
*
*/
S16 hiSendCfgMsg(viod)
{
    S16 ret = ROK;

    if( gSmCb[ENTHI].smStatus == SM_INIT_CFG_STATE)
    {
        ret = tucl_oam_config_gen();
      if(ret == RFAILED)
    {
        return ret;
    }
        ret = tucl_oam_config_saps();
      if(ret == RFAILED)
    {
        return ret;
    }   
    }

  RETVALUE(ROK);
}






/*****************************************************************************
*
*       ����:   hiNmSyncCallback
*
*       ����:   ���ûص�����
*
*       ����ֵ:   ʧ��:           RFAILED
*                 �ɹ�:           ROK
*       �ļ�:   hi_nms.c
*
*/
unsigned char hiNmInitCallback(unsigned short msgtype, unsigned int sepuense, unsigned char pack_end, tb_record* prow)
{
    /* 1.ȡ��������  */
  if(ROK != hiRecvInitCfg(msgtype,prow))
  {
      opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
      RETVALUE(RFAILED);
  }   
    
  if(TRUE == pack_end)
  {
     /* 2.����������д������*/
    if(ROK != hiSendCfgMsg())
    {
      opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
      SPrint("TUCL cfg ERROR!\n");
        RETVALUE(RFAILED);
    }   

    /* send out a config req message to sm*/
    /*3.����һ����ʾ��Ϣ������SM���Կ�ʼ������������*/
    if( ROK != smSendCfgReq(ENTHI, SM_INIT_CFG_STATE))
    {
      opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
      SPrint("TUCL cfg ERROR!\n");
        RETVALUE(RFAILED);                  
    }

    /* wait initial cofiguration finished*/
    ssWaitSema(&gSmCb[ENTHI].sema);

    /* send response to subagent*/
    if(SM_SUCCESS_STATE ==  gSmCb[ENTHI].smStatus)
    {
      /* All the initialization configuration data is processed successfully */
      opt_response_batch(sepuense, OAM_RESPONSE_OK);      
    }
    else 
    {
      opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
    }
  
  
  }

  printf("\nTUCL cfg finished.\n");
#ifdef CP_OAM_DATA_SHOW 
  hi_print_state_cb_info(0x0008);
#endif  
  RETVALUE(ROK);
}

#endif /* CP_OAM_SUPPORT */



