/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
    
     Name:     TCP UDP Convergence Layer
  
     Type:     C source file
  
     Desc:     C source code for HI layer portable Upper Interface
  
     File:     hi_ptui.c
  
     Sid:      hi_ptui.c@@/main/4 - Thu Jun 28 13:30:46 2001
  
     Prg:      asa
  
*********************************************************************21*/


/* header include files (.h) */

/* header/extern include files (.x) */
  
  

/*
  
The following functions are provided in this file:
  
     HiUiHitConInd    upper interface - Connect Indication
     HiUiHitConCfm    upper interface - Connect Confirm 
     HiUiHitBndCfm    upper interface - Bind Confirm
     HiUiHitDatInd    upper interface - Data Indication
     HiUiHitUDatInd   upper interface - Unit Data Indication
     HiUiHitDiscInd   upper interface - Disconnect Indication
     HiUiHitDiscCfm   upper interface - Disconnect Confirm
     HiUiHitFlcInd    upper interface - Flow Control Indication
  
It should be noted that not all of these functions may be required
by a particular network layer service user.
  
  
*/

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_inet.h"       /* common sockets */
#ifdef FTHA
#include "sht.h"           /* SHT Interface header file */
#endif /* FTHA */
#include "lhi.h"           /* layer management HI */
#include "cm_hash.h"       /* common hash list */
#include "cm_llist.h"      /* common linked list */
#include "cm_err.h"        /* common error */
#include "cm5.h"           /* common timer */
#include "cm_tpt.h"        /* common transport defines */
#include "hit.h"           /* hit interface */
#include "hi.h"            /* HI layer */
#include "hi_err.h"        /* HI error */
#ifdef H323_PERF
#include "hc_prf.h"      /* Performance measurement data structs */
#endif /* H323_PERF */
 
/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_inet.x"       /* common sockets */
#ifdef FTHA
#include "sht.x"           /* SHT Interface header file */
#endif /* FTHA */
#include "lhi.x"           /* layer management HI */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm5.x"           /* common timer */
#include "cm_lib.x"        /* common library */
#include "cm_tpt.x"        /* common transport typedefs */
#include "hit.x"           /* hit interface */
#include "hi.x"            /* HI layer */
#ifdef H323_PERF
#include "hc_prf.x"      /* Performance measurement data structs */
#endif /* H323_PERF */

 

/* local defines */
/* hi020.104: Adding Sip Application as another user */
#define MAXHIUI   11       /* max HI Layer upper users */

/* Always define PTHIUIHIT because HR and SB dont have the 
 * corresponding ConInd, DatInd and FlcInd primitives  at their lower
 * interface. Hence PTHIUIHIT is needed if they are defined and if
 * they are not defined, i.e., always */
#define PTHIUIHIT

/* local typedefs */
 
/* local externs */
  
#ifdef PTHIUIHIT

/* declaration of portable functions */
PRIVATE S16 PtUiHitConInd  ARGS((Pst *pst, SuId suId, UConnId servconId, 
                                 UConnId spConId, CmTptAddr *peerAddr));
PRIVATE S16 PtUiHitConCfm  ARGS((Pst *pst, SuId suId, UConnId suConId, 
                                 UConnId spConId, CmTptAddr *localAddr));
PRIVATE S16 PtUiHitBndCfm  ARGS((Pst *pst, SuId suId, U8 status));

#ifdef HI_REL_1_3
/* hi009.104 - added new declaration */
#ifdef LOCAL_INTF
PRIVATE S16 PtUiHitUDatInd ARGS((Pst *pst, SuId suId, UConnId suConId, 
                                 CmTptAddr *srcAddr, CmTptAddr *remAddr,
                                 CmIpHdrParm *ipHdrParm, 
                                 CmTptLocalInf *localIf, Buffer *mBuf));
#else
PRIVATE S16 PtUiHitUDatInd ARGS((Pst *pst, SuId suId, UConnId suConId, 
                                 CmTptAddr *srcAddr, CmTptAddr *remAddr,
                                 CmIpHdrParm *ipHdrParm, 
                                 Buffer *mBuf));
#endif /* LOCAL_INTF */
#else
PRIVATE S16 PtUiHitUDatInd ARGS((Pst *pst, SuId suId, UConnId suConId, 
                                 CmTptAddr *srcAddr, Buffer *mBuf));
#endif /* HI_REL_1_3 */

PRIVATE S16 PtUiHitDatInd  ARGS((Pst *pst, SuId suId, UConnId suConId, 
                                 Buffer *mBuf));

PRIVATE S16 PtUiHitDiscInd ARGS((Pst *pst, SuId suId, U8 choice, 
                                 UConnId conId, Reason reason));
PRIVATE S16 PtUiHitDiscCfm ARGS((Pst *pst, SuId suId, U8 choice, 
                                 UConnId conId, Action action));
#ifdef HI_REL_1_3
PRIVATE S16 PtUiHitFlcInd  ARGS((Pst *pst, SuId suId, 
                                 UConnId suConId, Reason reason));
#else
PRIVATE S16 PtUiHitFlcInd  ARGS((Pst *pst, SuId suId, Reason reason));
#endif /* HI_REL_1_3 */
#endif /* PTHIUIHIT */


/*
  The following matrices define the mapping between the primitives
  called by the upper interface of TCP UDP Convergence Layer 
  and the corresponding primitives of the TCP UDP Convergence Layer 
  service user(s).
  
  The parameter MAXHIUI defines the maximum number of service users on
  top of TCP UDP Convergence Layer. There is an array of functions
  per primitive invoked by TCP UDP Convergence Layer. Every array is
  MAXHIUI long(i.e.there are as many functions as the number of service
  users).
  
  The dispatching is performed by the configurable variable: selector.
  The selector is configured on a per SAP basis.
  
  The selectors are:
  
  0 - loosely coupled (#define LCHIUIHIT)
  1 - H.323 Control   (#define HC)
  2 - RTP/RTCP        (#define HR)
  3 - GTP             (#define GT)
  4 - MGCP            (#define MG)
  5 - Annex G         (#define HG)
  6 - SCTP            (#define SB)
  7 - MPLS            (#define LN)
  8 - Dummy Layer     (#define DM)
  9 - SIP             (#define SO)
 10 - SIP User        (#define SV)
*/


/* Connect Indication primitive */

PRIVATE HitConInd HiUiHitConIndMt[MAXHIUI] =
{
#ifdef LCHIUIHIT
   cmPkHitConInd,         /* 0 - loosely coupled */
#else
   PtUiHitConInd,         /* 0 - loosely coupled, portable */
#endif
#ifdef HC
   HcLiHitConInd,         /* 1 - tightly coupled, H.323 Control */
#else
   PtUiHitConInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef HR
   PtUiHitConInd,         /* 2 - tightly coupled, RTP/RTCP */
#else
   PtUiHitConInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef GT
   GtLiHitConInd,         /* 3 - tightly coupled, GTP */
#else
   PtUiHitConInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef MG 
   MgLiHitConInd,         /* 4 - tightly coupled, MGCP */   
#else
   PtUiHitConInd,         /* 4 - tightly coupled, portable */
#endif
#ifdef HG 
   HgLiHitConInd,         /* 5 - tightly coupled, ANNEX G */
#else
   PtUiHitConInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef SB
   PtUiHitConInd,         /* 6 - tightly coupled, SCTP */
#else
   PtUiHitConInd,         /* 6 - tightly coupled, portable */
#endif 
#ifdef LN
   LnLiHitConInd,         /* 7 - tightly coupled, MPLS */
#else
   PtUiHitConInd,         /* 7 - tightly coupled, portable */
#endif 
#ifdef DM
   DmLiHitConInd,         /* 8 - tightly coupled, Dummy Layer */
#else
   PtUiHitConInd,         /* 8 - tightly coupled, portable */
#endif 
#ifdef SO
   SoLiHitConInd,         /* 9 - tightly coupled, SIP */
#else
   PtUiHitConInd,         /* 9 - tightly coupled, portable */
#endif
/* hi020.104: Adding Sip Application as another user */
#ifdef SV
   SvLiHitConInd,         /* 10 - tightly coupled, SIP User */
#else
   PtUiHitConInd          /* 10 - tightly coupled, portable */
#endif
};


/* Connect Confirm primitive */

PRIVATE HitConCfm HiUiHitConCfmMt[MAXHIUI] =
{
#ifdef LCHIUIHIT
   cmPkHitConCfm,         /* 0 - loosely coupled */
#else
   PtUiHitConCfm,         /* 0 - loosely coupled, portable */
#endif
#ifdef HC
   HcLiHitConCfm,         /* 1 - tightly coupled, H.323 Control */
#else
   PtUiHitConCfm,         /* 1 - tightly coupled, portable */
#endif
#ifdef HR
   HrLiHitConCfm,         /* 2 - tightly coupled, RTP/RTCP */
#else
   PtUiHitConCfm,         /* 2 - tightly coupled, portable */
#endif
#ifdef GT
   GtLiHitConCfm,         /* 3 - tightly coupled, GTP */
#else
   PtUiHitConCfm,         /* 3 - tightly coupled, portable */
#endif
#ifdef MG 
   MgLiHitConCfm,         /* 4 - tightly coupled, MGCP */   
#else
   PtUiHitConCfm,         /* 4 - tightly coupled, portable */
#endif
#ifdef HG 
   HgLiHitConCfm,         /* 5 - tightly coupled, ANNEX G */
#else
   PtUiHitConCfm,         /* 5 - tightly coupled, portable */
#endif
#ifdef SB 
   SbLiHitConCfm,         /* 6 - tightly coupled, SCTP */
#else
   PtUiHitConCfm,         /* 6 - tightly coupled, portable */
#endif
#ifdef LN 
   LnLiHitConCfm,         /* 7 - tightly coupled, MPLS */
#else
   PtUiHitConCfm,         /* 7 - tightly coupled, portable */
#endif
#ifdef DM
   DmLiHitConCfm,         /* 8 - tightly coupled, Dummy Layer */
#else
   PtUiHitConCfm,         /* 8 - tightly coupled, portable */
#endif
#ifdef SO
   SoLiHitConCfm,         /* 9 - tightly coupled, SIP */
#else
   PtUiHitConCfm,         /* 9 - tightly coupled, portable */
#endif
/* hi020.104: Adding Sip Application as another user */
#ifdef SV
   SvLiHitConCfm,         /* 10 - tightly coupled, SIP User */
#else
   PtUiHitConCfm          /* 10 - tightly coupled, portable User */
#endif
};


/* Bind Confirm primitive */

PRIVATE HitBndCfm HiUiHitBndCfmMt[MAXHIUI] =
{
#ifdef LCHIUIHIT
   cmPkHitBndCfm,         /* 0 - loosely coupled */
#else
   PtUiHitBndCfm,         /* 0 - loosely coupled, portable */
#endif
#ifdef HC
   HcLiHitBndCfm,         /* 1 - tightly coupled, H.323 Control */
#else
   PtUiHitBndCfm,         /* 1 - tightly coupled, portable */
#endif
#ifdef HR
   HrLiHitBndCfm,         /* 2 - tightly coupled, RTP/RTCP */
#else
   PtUiHitBndCfm,         /* 2 - tightly coupled, portable */
#endif
#ifdef GT
   GtLiHitBndCfm,         /* 3 - tightly coupled, GTP */
#else
   PtUiHitBndCfm,         /* 3 - tightly coupled, portable */
#endif
#ifdef MG
   MgLiHitBndCfm,         /* 4 - tightly coupled, MGCP */   
#else
   PtUiHitBndCfm,         /* 4 - tightly coupled, portable */
#endif
#ifdef HG
   HgLiHitBndCfm,         /* 5 - tightly coupled, ANNEX G */
#else
   PtUiHitBndCfm,         /* 5 - tightly coupled, portable */
#endif
#ifdef SB 
   SbLiHitBndCfm,         /* 6 - tightly coupled, SCTP */
#else
   PtUiHitBndCfm,         /* 6 - tightly coupled, portable */
#endif
#ifdef LN 
   LnLiHitBndCfm,         /* 7 - tightly coupled, MPLS */
#else
   PtUiHitBndCfm,         /* 7 - tightly coupled, portable */
#endif
#ifdef DM 
   DmLiHitBndCfm,         /* 8 - tightly coupled, Dummy Layer */
#else
   PtUiHitBndCfm,         /* 8 - tightly coupled, portable */
#endif
#ifdef SO
   SoLiHitBndCfm,         /* 9 - tightly coupled, SIP */
#else
   PtUiHitBndCfm,         /* 9 - tightly coupled, portable */
#endif
/* hi020.104: Adding Sip Application as another user */
#ifdef SV
   SvLiHitBndCfm,         /* 10 - tightly coupled, SIP User */
#else
   PtUiHitBndCfm          /* 10 - tightly coupled, portable */
#endif
};


/* Data Indication primitive */

PRIVATE HitDatInd HiUiHitDatIndMt[MAXHIUI] =
{
#ifdef LCHIUIHIT
   cmPkHitDatInd,         /* 0 - loosely coupled */
#else
   PtUiHitDatInd,         /* 0 - loosely coupled, portable */
#endif
#ifdef HC
   HcLiHitDatInd,         /* 1 - tightly coupled, H.323 Control */
#else
   PtUiHitDatInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef HR
   PtUiHitDatInd,         /* 2 - tightly coupled, RTP/RTCP */
#else
   PtUiHitDatInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef GT
   GtLiHitDatInd,         /* 3 - tightly coupled, GTP */
#else
   PtUiHitDatInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef MG 
   MgLiHitDatInd,         /* 4 - tightly coupled, MGCP */   
#else
   PtUiHitDatInd,         /* 4 - tightly coupled, portable */
#endif
#ifdef HG 
   HgLiHitDatInd,         /* 5 - tightly coupled, ANNEX G */
#else
   PtUiHitDatInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef SB 
   PtUiHitDatInd,         /* 6 - tightly coupled, SCTP */
#else
   PtUiHitDatInd,         /* 6 - tightly coupled, portable */
#endif
#ifdef LN 
   LnLiHitDatInd,         /* 7 - tightly coupled, MPLS */
#else
   PtUiHitDatInd,         /* 7 - tightly coupled, portable */
#endif
#ifdef DM 
   DmLiHitDatInd,         /* 8 - tightly coupled, Dummy Layer */
#else
   PtUiHitDatInd,         /* 8 - tightly coupled, portable */
#endif
#ifdef SO
   SoLiHitDatInd,         /* 9 - tightly coupled, SIP */
#else
   PtUiHitDatInd,         /* 9 - tightly coupled, portable */
#endif
/* hi020.104: Adding Sip Application as another user */
#ifdef SV
   SvLiHitDatInd,         /* 10 - tightly coupled, SIP User */
#else
   PtUiHitDatInd          /* 10 - tightly coupled, portable */
#endif
};


/* Unit Data Indication primitive */
PRIVATE HitUDatInd HiUiHitUDatIndMt[MAXHIUI] =
{
#ifdef LCHIUIHIT
   cmPkHitUDatInd,         /* 0 - loosely coupled */
#else
   PtUiHitUDatInd,         /* 0 - loosely coupled, portable */
#endif
#ifdef HC
   HcLiHitUDatInd,         /* 1 - tightly coupled, H.323 Control */
#else
   PtUiHitUDatInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef HR
   HrLiHitUDatInd,         /* 2 - tightly coupled, RTP/RTCP */
#else
   PtUiHitUDatInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef GT
   GtLiHitUDatInd,         /* 3 - tightly coupled, GTP */
#else
   PtUiHitUDatInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef MG 
   MgLiHitUDatInd,         /* 4 - tightly coupled, MGCP */   
#else
   PtUiHitUDatInd,         /* 4 - tightly coupled, portable */
#endif
#ifdef HG 
   HgLiHitUDatInd,         /* 5 - tightly coupled, ANNEX G */
#else
   PtUiHitUDatInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef SB 
   SbLiHitUDatInd,         /* 6 - tightly coupled, SCTP */
#else
   PtUiHitUDatInd,         /* 6 - tightly coupled, portable */
#endif
#ifdef LN 
   LnLiHitUDatInd,         /* 7 - tightly coupled, MPLS */
#else
   PtUiHitUDatInd,         /* 7 - tightly coupled, portable */
#endif
#ifdef DM 
   DmLiHitUDatInd,         /* 8 - tightly coupled, Dummy Layer */
#else
   PtUiHitUDatInd,         /* 8 - tightly coupled, portable */
#endif
#ifdef SO
   SoLiHitUDatInd,         /* 9 - tightly coupled, SIP */
#else
   PtUiHitUDatInd,         /* 9 - tightly coupled, portable */
#endif
/* hi020.104: Adding Sip Application as another user */
#ifdef SV
   SvLiHitUDatInd,         /* 10 - tightly coupled, SIP User */
#else
   PtUiHitUDatInd          /* 10 - tightly coupled, portable */
#endif
};


/* Disconnect Indication primitive */

PRIVATE HitDiscInd HiUiHitDiscIndMt[MAXHIUI] =
{
#ifdef LCHIUIHIT
   cmPkHitDiscInd,         /* 0 - loosely coupled */
#else
   PtUiHitDiscInd,         /* 0 - loosely coupled, portable */
#endif
#ifdef HC
   HcLiHitDiscInd,         /* 1 - tightly coupled, H.323 Control */
#else
   PtUiHitDiscInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef HR
   HrLiHitDiscInd,         /* 2 - tightly coupled, RTP/RTCP */
#else
   PtUiHitDiscInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef GT
   GtLiHitDiscInd,         /* 3 - tightly coupled, GTP */
#else
   PtUiHitDiscInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef MG 
   MgLiHitDiscInd,         /* 4 - tightly coupled, MGCP */   
#else
   PtUiHitDiscInd,         /* 4 - tightly coupled, portable */
#endif
#ifdef HG 
   HgLiHitDiscInd,         /* 5 - tightly coupled, ANNEX G */
#else
   PtUiHitDiscInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef SB 
   SbLiHitDiscInd,         /* 6 - tightly coupled, SCTP */
#else
   PtUiHitDiscInd,         /* 6 - tightly coupled, portable */
#endif
#ifdef LN 
   LnLiHitDiscInd,         /* 7 - tightly coupled, MPLS */
#else
   PtUiHitDiscInd,         /* 7 - tightly coupled, portable */
#endif
#ifdef DM 
   DmLiHitDiscInd,         /* 8 - tightly coupled, Dummy Layer */
#else
   PtUiHitDiscInd,         /* 8 - tightly coupled, portable */
#endif
#ifdef SO
   SoLiHitDiscInd,         /* 9 - tightly coupled, SIP */
#else
   PtUiHitDiscInd,         /* 9 - tightly coupled, portable */
#endif
/* hi020.104: Adding Sip Application as another user */
#ifdef SV
   SvLiHitDiscInd,         /* 10 - tightly coupled, SIP User */
#else
   PtUiHitDiscInd          /* 10 - tightly coupled, portable */
#endif
};


/* Disconnect Confirm primitive */

PRIVATE HitDiscCfm HiUiHitDiscCfmMt[MAXHIUI] =
{
#ifdef LCHIUIHIT
   cmPkHitDiscCfm,         /* 0 - loosely coupled */
#else
   PtUiHitDiscCfm,         /* 0 - loosely coupled, portable */
#endif
#ifdef HC
   HcLiHitDiscCfm,         /* 1 - tightly coupled, H.323 Control */
#else
   PtUiHitDiscCfm,         /* 1 - tightly coupled, portable */
#endif
#ifdef HR
   HrLiHitDiscCfm,         /* 2 - tightly coupled, RTP/RTCP */
#else
   PtUiHitDiscCfm,         /* 2 - tightly coupled, portable */
#endif
#ifdef GT
   GtLiHitDiscCfm,         /* 3 - tightly coupled, GTP */
#else
   PtUiHitDiscCfm,         /* 3 - tightly coupled, portable */
#endif
#ifdef MG 
   MgLiHitDiscCfm,         /* 4 - tightly coupled, MGCP */   
#else
   PtUiHitDiscCfm,         /* 4 - tightly coupled, portable */
#endif
#ifdef HG 
   HgLiHitDiscCfm,         /* 5 - tightly coupled, ANNEX G */
#else
   PtUiHitDiscCfm,         /* 5 - tightly coupled, portable */
#endif
#ifdef SB 
   SbLiHitDiscCfm,         /* 6 - tightly coupled, SCTP */
#else
   PtUiHitDiscCfm,         /* 6 - tightly coupled, portable */
#endif
#ifdef LN 
   LnLiHitDiscCfm,         /* 7 - tightly coupled, MPLS */
#else
   PtUiHitDiscCfm,         /* 7 - tightly coupled, portable */
#endif
#ifdef DM 
   DmLiHitDiscCfm,         /* 8 - tightly coupled, Dummy Layer */
#else
   PtUiHitDiscCfm,         /* 8 - tightly coupled, portable */
#endif
#ifdef SO
   SoLiHitDiscCfm,         /* 9 - tightly coupled, SIP */
#else
   PtUiHitDiscCfm,         /* 9 - tightly coupled, portable */
#endif
/* hi020.104: Adding Sip Application as another user */
#ifdef SV
   SvLiHitDiscCfm,         /* 10 - tightly coupled, SIP User */
#else
   PtUiHitDiscCfm          /* 10 - tightly coupled, portable */
#endif
};


/* Flow Control Indication primitive */

PRIVATE HitFlcInd HiUiHitFlcIndMt[MAXHIUI] =
{
#ifdef LCHIUIHIT
   cmPkHitFlcInd,         /* 0 - loosely coupled */
#else
   PtUiHitFlcInd,         /* 0 - loosely coupled, portable */
#endif
#ifdef HC
   HcLiHitFlcInd,         /* 1 - tightly coupled, H.323 Control */
#else
   PtUiHitFlcInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef HR
   PtUiHitFlcInd,         /* 2 - tightly coupled, RTP/RTCP */
#else
   PtUiHitFlcInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef GT
   GtLiHitFlcInd,         /* 3 - tightly coupled, GTP */
#else
   PtUiHitFlcInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef MG 
   MgLiHitFlcInd,         /* 4 - tightly coupled, MGCP */   
#else
   PtUiHitFlcInd,         /* 4 - tightly coupled, portable */
#endif
#ifdef HG 
   HgLiHitFlcInd,         /* 5 - tightly coupled, ANNEX G */
#else
   PtUiHitFlcInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef SB 
   PtUiHitFlcInd,         /* 6 - tightly coupled, SCTP */
#else
   PtUiHitFlcInd,         /* 6 - tightly coupled, portable */
#endif
#ifdef LN 
   LnLiHitFlcInd,         /* 7 - tightly coupled, MPLS */
#else
   PtUiHitFlcInd,         /* 7 - tightly coupled, portable */
#endif
#ifdef DM 
   DmLiHitFlcInd,         /* 8 - tightly coupled, Dummy Layer */
#else
   PtUiHitFlcInd,         /* 8 - tightly coupled, portable */
#endif
#ifdef SO
   SoLiHitFlcInd,         /* 9 - tightly coupled, SIP */
#else
   PtUiHitFlcInd,         /* 9 - tightly coupled, portable */
#endif
/* hi020.104: Adding Sip Application as another user */
#ifdef SV
   SvLiHitFlcInd,         /* 10 - tightly coupled, SIP User */
#else
   PtUiHitFlcInd          /* 10 - tightly coupled, portable */
#endif
};

/* 
 *  upper interface functions
 */


/*
*
*       Fun:   Connect Indication
*
*       Desc:  This function indicates the service user of a new
*              TCP client connection.
*              
*              "peerAddr" - has the address of the remote entity
*                           which has initiated the client connection.
*
*       Ret:   ROK   - ok
*
*       Notes: Service user will be issued a Connect Indication only 
*              when it has initiated a TCP server using 
*              HiUiHitServOpenReq() primitive.
*
*       File:  hi_ptui.c
*
*/
  
#ifdef ANSI
PUBLIC S16 HiUiHitConInd
(
Pst *pst,                 /* post stucture */
SpId suId,                /* service user Id */
UConnId servConId,        /* server's connection id */
UConnId spConId,          /* service provider's connection Id */
CmTptAddr *peerAddr       /* peer address */
)
#else
PUBLIC S16 HiUiHitConInd(pst, suId, servConId, spConId, peerAddr)
Pst *pst;                 /* post stucture */
SpId suId;                /* service user Id */
UConnId servConId;        /* server's connection id */
UConnId spConId;          /* service provider's connection Id */
CmTptAddr *peerAddr;      /* peer address */
#endif
{
   TRC3(HiUiHitConInd)
   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
          "HiUiHitConInd(pst, suId(%d), servConId(%ld)), spConId(%ld), \
           peerAddr(%p)\n", suId, servConId, spConId, peerAddr));
 
#ifdef H323_PERF
   TAKE_TIMESTAMP("L/T ConInd sent HI->HC, in HI");
#endif /* H323_PERF */
   
   /* hi008.104 - Added code for directing primitives to GCP-LDF */
   switch(pst->dstEnt)
   {
#ifdef DG
      case ENTMG:
         if(pst->route ==  RTE_PROTO)
            (*(HiUiHitConIndMt[pst->selector]))
               (pst, suId, servConId, spConId, peerAddr);
         else
            DgLiHitConInd(pst, suId, servConId, spConId, peerAddr);
         break;
#endif /* DG */
         
      default:
          /* jump to specific primitive depending on configured selector */
          (*(HiUiHitConIndMt[pst->selector]))
              (pst, suId, servConId, spConId, peerAddr);
          break;
   }

   
   RETVALUE(ROK);
} /* end of HiUiHitConInd */


/*
*
*       Fun:   Connect Confirmation
*
*       Desc:  This primitive is used by the TUCL software to 
*              indicate to the service user  that the socket 
*              (as requested by HiUiHitServOpenReq or by HiUiHitConReq) 
*              has been opened, and the UDP data transfer may take 
*              place or new TCP client connections may be accepted.
*              
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  hi_ptui.c
*
*/
  
#ifdef ANSI
PUBLIC S16 HiUiHitConCfm
(
Pst  *pst,                /* post structure */
SuId  suId,               /* Service User Id */
UConnId  suConId,         /* service user's connection Id */
UConnId  spConId,         /* service provider's connection Id */
CmTptAddr *localAddr      /* local transport address */
)
#else
PUBLIC S16 HiUiHitConCfm(pst, suId, suConId, spConId, localAddr)
Pst  *pst;                /* post structure */
SuId  suId;               /* Service User Id */
UConnId  suConId;         /* service user's connection Id */
UConnId  spConId;         /* service provider's connection Id */
CmTptAddr *localAddr;     /* local transport address */
#endif
{
   TRC3(HiUiHitConCfm)

   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
    "HiUiHitConCfm(pst, suId(%d), suConId(%ld)), spConId(%ld), \
     localAddr(%p)\n", suId, suConId, spConId, localAddr));
 
   /* hi008.104 - Added code for directing primitives to GCP-LDF */
   switch(pst->dstEnt)
   {
#ifdef DG
      case ENTMG:
         if(pst->route ==  RTE_PROTO)
         (*HiUiHitConCfmMt[pst->selector])(pst, suId, 
            suConId, spConId, localAddr);
         else
            DgLiHitConCfm(pst, suId, suConId, spConId, localAddr);
         break;
#endif /* DG */
      default:
         (*HiUiHitConCfmMt[pst->selector])(pst, suId, 
            suConId, spConId, localAddr);
         break;
   }

   RETVALUE(ROK);
} /* end of HiUiHitConCfm */


/*
*
*       Fun:   Bind Confirmation
*
*       Desc:  This function indicates to the service user whether the 
*              bind operation has been successful or not.
*              
*       Ret:   ROK
*
*       Notes: None
*
*       File:  hi_ptui.c
*
*/
  
#ifdef ANSI
PUBLIC S16 HiUiHitBndCfm
(
Pst         *pst,         /* post structure */
SuId        suId,         /* Service User Id */
U8          status        /* status */
)
#else
PUBLIC S16 HiUiHitBndCfm(pst, suId, status)
Pst         *pst;         /* post structure */
SuId        suId;         /* Service User Id */
U8          status;       /* status */ 
#endif
{
   TRC3(HiUiHitBndCfm)

   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
          "HiUiHitBndCfm(pst, suId(%d), status(%d)\n", suId, status));
 
   /* hi008.104 - Added code for directing primitives to GCP-LDF */
   switch(pst->dstEnt)
   {
#ifdef DG
      case ENTMG:
         if(pst->route ==  RTE_PROTO)
            (*HiUiHitBndCfmMt[pst->selector])(pst, suId, status);
         else
             DgLiHitBndCfm(pst, suId, status);
         break;
#endif /* DG */
      default:
         (*HiUiHitBndCfmMt[pst->selector])(pst, suId, status);
         break;
   }

   RETVALUE(ROK);
} /* end of HiUiHitBndCfm */


/*
*
*       Fun:   Data Indication
*
*       Desc:  This function provides for indicating incoming 
*              TCP data on the socket.
*
*       Ret:   ROK   - ok
*
*       Notes: HI layer strips off the TPKT header and delievers
*              the data in a message buffer.
*
*       File:  hi_ptui.c
*
*/
  
#ifdef ANSI
PUBLIC S16 HiUiHitDatInd
(
Pst         *pst,         /* post structure */
SuId        suId,         /* service User Id */
UConnId     suConId,      /* service provider's connection id */
Buffer      *mBuf         /* message buffer */
)
#else
PUBLIC S16 HiUiHitDatInd(pst, suId, suConId, mBuf)
Pst         *pst;         /* post structure */
SuId        suId;         /* service User Id */
UConnId     suConId;      /* service provider's connection id */ 
Buffer      *mBuf;        /* message buffer */
#endif
{
   TRC3(HiUiHitDatInd)

   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
          "HiUiHitDatInd(pst, suId(%d), suConId(%ld), mBuf(%p))\n",
          suId, suConId, mBuf));
 
   /* hi008.104 - Added code for directing primitives to GCP-LDF */
   switch(pst->dstEnt)
   {
#ifdef DG
      case ENTMG:
         if(pst->route ==  RTE_PROTO)
            (*HiUiHitDatIndMt[pst->selector])(pst, suId, suConId, mBuf);
         else
            DgLiHitDatInd(pst, suId, suConId, mBuf);
         break;
#endif /* DG */
      default:
         (*HiUiHitDatIndMt[pst->selector])(pst, suId, suConId, mBuf);
         break;
   }

   RETVALUE(ROK);
} /* end of HiUiHitDatInd */


/*
*
*       Fun:   Unit Data Indication
*
*       Desc:  This function provides for indicating incoming 
*              UDP datagrams to the service user.
*
*              "srcAddr" - indicates the address from where the 
*                          data was received.
*       Ret:   ROK
*
*       Notes: None
*
*       File:  hi_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiHitUDatInd
(
Pst *pst,                 /* post stucture */
SpId suId,                /* service user Id */
UConnId suConId,          /* service user's connection Id */
CmTptAddr *srcAddr,       /* source transport address */
#ifdef HI_REL_1_3  
CmTptAddr *remAddr,       /* Remote Address */
CmIpHdrParm *hdrParm,     /* Header Parameters */
/* hi009.104 - added new argument localIf */
#ifdef LOCAL_INTF
CmTptLocalInf *localIf,   /* local intf on which pkt arrived */
#endif /* LOCAL_INTF */
#endif /* HI_REL_1_3 */ 
Buffer *mBuf              /* message buffer */
)
#else
#ifdef HI_REL_1_3
#ifdef LOCAL_INTF
PUBLIC S16 HiUiHitUDatInd(pst, suId, suConId, srcAddr, remAddr, hdrParm, 
                          localIf, mBuf)
Pst *pst;                 /* post stucture */
SpId suId;                /* service user Id */
UConnId suConId;          /* service user's connection Id */
CmTptAddr *srcAddr;       /* source transport address */
CmTptAddr *remAddr;       /* Remote Address */
CmIpHdrParm *hdrParm;     /* Header Parameters */
/* hi009.104 - added new argument localIf */
CmTptLocalInf *localIf;   /* local intf on which pkt arrived */
Buffer *mBuf;             /* message buffer */
#else 
PUBLIC S16 HiUiHitUDatInd(pst, suId, suConId, srcAddr, remAddr, hdrParm, mBuf)
Pst *pst;                 /* post stucture */
SpId suId;                /* service user Id */
UConnId suConId;          /* service user's connection Id */
CmTptAddr *srcAddr;       /* source transport address */
CmTptAddr *remAddr;       /* Remote Address */
CmIpHdrParm *hdrParm;     /* Header Parameters */
Buffer *mBuf;             /* message buffer */
#endif /* LOCAL_INTF */ 
#else
PUBLIC S16 HiUiHitUDatInd(pst, suId, suConId, srcAddr, mBuf)
Pst *pst;                 /* post stucture */
SpId suId;                /* service user Id */
UConnId suConId;          /* service user's connection Id */
CmTptAddr *srcAddr;       /* source transport address */
Buffer *mBuf;             /* message buffer */
#endif /* HI_REL_1_3 */ 
#endif /* ANSI */
{
   TRC3(HiUiHitUDatInd)

   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
         "HiUiHitUDatInd(pst, suId(%d), suConId(%ld), srcAddr(%p), \
          mBuf(%p))\n", suId, suConId, srcAddr, mBuf));
 
   /* hi008.104 - Added code for directing primitives to GCP-LDF */
   switch(pst->dstEnt)
   {
#ifdef DG
      case ENTMG:
         if(pst->route ==  RTE_PROTO)
         {
#ifdef HI_REL_1_3
   /* hi009.104 - added new argument localIf */      
#ifdef LOCAL_INTF         
   /* jump to specific primitive depending on configured selector */
   (*HiUiHitUDatIndMt[pst->selector])(pst, suId, suConId, srcAddr,
                                      remAddr, hdrParm, localIf, mBuf);
#else
   /* jump to specific primitive depending on configured selector */
   (*HiUiHitUDatIndMt[pst->selector])(pst, suId, suConId, srcAddr,
                                      remAddr, hdrParm, mBuf);
#endif /* LOCAL_INTF */                
#else 
            /* jump to specific primitive depending on configured selector */
            (*HiUiHitUDatIndMt[pst->selector])(pst, suId, suConId, 
                                               srcAddr, mBuf);
#endif /* HI_REL_1_3 */ 
         }
         else
            DgLiHitUDatInd(pst, suId, suConId, srcAddr, remAddr, hdrParm,
               mBuf);
         break;
#endif /* DG */
      default:
      {
#ifdef HI_REL_1_3  
   /* hi009.104 - added new argument localIf */      
#ifdef LOCAL_INTF         
   /* jump to specific primitive depending on configured selector */
   (*HiUiHitUDatIndMt[pst->selector])(pst, suId, suConId, srcAddr,
                                      remAddr, hdrParm, localIf, mBuf);
#else
   /* jump to specific primitive depending on configured selector */
   (*HiUiHitUDatIndMt[pst->selector])(pst, suId, suConId, srcAddr,
                                      remAddr, hdrParm, mBuf);
#endif /* LOCAL_INTF */
#else 
         /* jump to specific primitive depending on configured selector */
         (*HiUiHitUDatIndMt[pst->selector])(pst, suId, suConId, 
                                            srcAddr, mBuf);
#endif /* HI_REL_1_3 */ 
         break;
      }
   }
   
   RETVALUE(ROK);   
} /* end of HiUiHitUDatInd */


/*
*
*       Fun:   Disconnect Indication
*
*       Desc:  This primitive is used by the TCP UDP Convergence Layer
*              to inform the service user that the socket 
*              is being closed by TCP UDP Convergence Layer and 
*              the associated connection information is being released. 
*              This may be issued in error cases  (e.g. socket related 
*              errors  like error in opening, binding, connecting to a 
*              socket, or miscellaneous errors like errors encountered 
*              in hash list operations or error in allocating static 
*              memory.) . 
*
*              "reason" - indicates the reason for closure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  hi_ptui.c
*
*/
  
#ifdef ANSI
PUBLIC S16 HiUiHitDiscInd
(
Pst *pst,                 /* post stucture */
SpId suId,                /* service user Id */
U8  choice,               /* choice parameter */
UConnId conId,            /* connection Id */
Reason reason             /* reason */
)
#else
PUBLIC S16 HiUiHitDiscInd(pst, suId, choice, conId, reason)
Pst *pst;                 /* post stucture */
SpId suId;                /* service user Id */
U8  choice;               /* choice parameter */
UConnId conId;            /* connection Id */
Reason reason;            /* reason */
#endif
{
   TRC3(HiUiHitDiscInd)

   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
          "HiUiHitDiscInd(pst, suId(%d), choice(%d), conId(%ld),\
           reason(%d))\n", suId, choice, conId, reason));
 
   /* hi008.104 - Added code for directing primitives to GCP-LDF */
   switch(pst->dstEnt)
   {
#ifdef DG
      case ENTMG:
         if(pst->route ==  RTE_PROTO)
            /* jump to specific primitive depending on configured selector */
            (*HiUiHitDiscIndMt[pst->selector])(pst, suId, choice, conId, 
                                             reason);
         else
            DgLiHitDiscInd(pst, suId, choice, conId, reason);
         break;
#endif /* DG */
      default:
         /* jump to specific primitive depending on configured selector */
         (*HiUiHitDiscIndMt[pst->selector])(pst, suId, choice, conId, 
                                          reason);
         break;
   }

   RETVALUE(ROK);
} /* end of HiUiHitDiscInd */


/*
*
*       Fun:   Disconnect Confirmation
*
*       Desc:  This primitive is used by the  TCP UDP Convergence 
*              Layer to indicate to the service user that 
*              Disconnect Request issued by  the service user 
*              for the action was successful.
*
*       Ret:   ROK
*
*       Notes: Please note that DiscCfm does not necessarily imply 
*              that the connection has  been closed or the connection 
*              information has been released by the HI layer ( as the 
*              socket may have been put into a shutdown state )
* 
*       File:  hi_ptui.c
*
*/
  
#ifdef ANSI
PUBLIC S16 HiUiHitDiscCfm
(
Pst *pst,                 /* post stucture */
SpId suId,                /* service user Id */
U8  choice,               /* choice parameter */
UConnId conId,             /* connection Id */
Action action             /* action type */
)
#else
PUBLIC S16 HiUiHitDiscCfm(pst, suId, choice, conId, action)       
Pst *pst;                 /* post stucture */
SpId suId;                /* service user Id */
U8  choice;               /* choice parameter */
UConnId conId;             /* connection Id */
Action action;            /* action type */
#endif
{
   TRC3(HiUiHitDiscCfm)

   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
          "HiUiHitDiscCfm(pst, suId(%d), choice(%d), conId(%ld), \
          action(%d))\n", suId, choice, conId, action));
 
   /* hi008.104 - Added code for directing primitives to GCP-LDF */
   switch(pst->dstEnt)
   {
#ifdef DG
      case ENTMG:
         if(pst->route ==  RTE_PROTO)
            /* jump to specific primitive depending on configured selector */
            (*HiUiHitDiscCfmMt[pst->selector])(pst, suId, choice, 
                                               conId, action);
         else
            DgLiHitDiscCfm(pst, suId, choice, conId, action);
         break;
#endif /* DG */
      default:
         /* jump to specific primitive depending on configured selector */
         (*HiUiHitDiscCfmMt[pst->selector])(pst, suId, choice, 
                                            conId, action);
         break;
   }

   RETVALUE(ROK);
} /* end of HiUiHitDiscCfm */


/*
*
*       Fun:   Flow Control Indication 
*
*       Desc:  This primitive is used to indicate a shortage of
*              kernel buffers to the HI layer users. The service users
*              are expected not to give any Data Requests to the HI
*              layer while flow control in ON.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  hi_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 HiUiHitFlcInd 
(
Pst         *pst,         /* post structure */
SuId        suId,         /* service user Id */
#ifdef HI_REL_1_3
UConnId     suConId,      /* service user connection id */
#endif /* HI_REL_1_3 */
Reason      reason        /* reason for flow control */
)
#else
#ifdef HI_REL_1_3
PUBLIC S16 HiUiHitFlcInd(pst, suId, suConId, reason)
Pst         *pst;         /* post structure */
SuId        suId;         /* service user Id */
UConnId     suConId;      /* service user connection Id */
Reason      reason;       /* reason for flow control */
#else
PUBLIC S16 HiUiHitFlcInd(pst, suId, reason)
Pst         *pst;         /* post structure */
SuId        suId;         /* service user Id */
Reason      reason;       /* reason for flow control */
#endif /* HI_REL_1_3 */
#endif /* ANSI */
{
   TRC3(HiUiHitFlcInd)

   HIDBGP(DBGMASK_UI, (hiCb.hiInit.prntBuf,
          "HiUiHitFlcInd(pst, suId(%d), reason(%d))\n",
          suId, reason));
 
   /* hi008.104 - Added code for directing primitives to GCP-LDF */
   switch(pst->dstEnt)
   {
#ifdef DG
      case ENTMG:
         if(pst->route ==  RTE_PROTO)
         {
            /* jump to specific primitive depending on configured selector */
#ifdef HI_REL_1_3
            (*HiUiHitFlcIndMt[pst->selector])(pst, suId, suConId, reason);
#else
            (*HiUiHitFlcIndMt[pst->selector])(pst, suId, reason);
#endif /* HI_REL_1_3 */
         }
         else
            DgLiHitFlcInd(pst, suId, suConId, reason); 
         break;
#endif /* DG */
      default:
         /* jump to specific primitive depending on configured selector */
#ifdef HI_REL_1_3
         (*HiUiHitFlcIndMt[pst->selector])(pst, suId, suConId, reason);
#else
         (*HiUiHitFlcIndMt[pst->selector])(pst, suId, reason);
#endif /* HI_REL_1_3 */
         break;
   }

   RETVALUE(ROK);
} /* end of HiUiHitFlcInd */


/*
*     upper interface portable functions
*/


#ifdef PTHIUIHIT
/*
*
*       Fun:   Portable - Connect Indication
*
*       Desc:  This function indicates the service user of a new
*              TCP client connection.
*              
*              "peerAddr" - has the address of the remote entity
*                           which has initiated the client connection.
*
*       Ret:   ROK   - ok
*
*       Notes: Service user will be issued a Connect Indication only 
*              when it has initiated a TCP server using 
*              HiUiHitServOpenReq() primitive.
*
*       File:  hi_ptui.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtUiHitConInd
(
Pst *pst,                 /* post stucture */
SpId suId,                /* service user Id */
UConnId servConId,        /* server's connection id */
UConnId spConId,          /* service provider's connection Id */
CmTptAddr *peerAddr   /* peer address */
)
#else
PRIVATE S16 PtUiHitConInd(pst, suId, servConId, spConId, peerAddr)
Pst *pst;                 /* post stucture */
SpId suId;                /* service user Id */
UConnId servConId;        /* server's connection id */
UConnId spConId;          /* service provider's connection Id */
CmTptAddr *peerAddr;  /* peer address */
#endif
{
   TRC3(PtUiHitConInd)
#if (ERRCLASS & ERRCLS_DEBUG)
   HILOGERROR_DEBUG(EHI259, (ErrVal)ERRZERO, pst->dstInst,
         "PtUiHitConInd");
#endif /* ERRCLASS */
   /* hi021.104: Removing warnings */
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(servConId);
   UNUSED(spConId);
   UNUSED(peerAddr);
   
   RETVALUE(ROK);
} /* end of PtUiHitConInd */


/*
*
*       Fun:   Portable - Connect Confirmation
*
*       Desc:  
*              
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  hi_ptui.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtUiHitConCfm
(
Pst  *pst,                /* post structure */
SuId  suId,               /* Service User Id */
UConnId  suConId,         /* service user's connection Id */
UConnId  spConId,         /* service provider's connection Id */
CmTptAddr *localAddr      /* local transport address */
)
#else
PRIVATE S16 PtUiHitConCfm(pst, suId, suConId, spConId, localAddr)
Pst  *pst;                /* post structure */
SuId  suId;               /* Service User Id */
UConnId  suConId;         /* service user's connection Id */
UConnId  spConId;         /* service provider's connection Id */
CmTptAddr *localAddr;     /* local transport address */
#endif
{
   TRC3(PtUiHitConCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
   HILOGERROR_DEBUG(EHI260, (ErrVal)ERRZERO, pst->dstInst,
         "PtUiHitConCfm");
#endif /* ERRCLASS */
   /* hi021.104: Removing warnings */
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConId);
   UNUSED(spConId);
   UNUSED(localAddr);

   RETVALUE(ROK);
} /* end of PtUiHitConCfm */


/*
*
*       Fun:   Portable - Bind Confirmation
*
*       Desc:  This function indicates to the service user whether the 
*              bind operation has been successful.
*              
*       Ret:   ROK
*
*       Notes: None
*
*       File:  hi_ptui.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtUiHitBndCfm
(
Pst         *pst,         /* post structure */
SuId        suId,         /* Service User Id */
U8          status        /* status of bind */
)
#else
PRIVATE S16 PtUiHitBndCfm(pst, suId, status)
Pst         *pst;         /* post structure */
SuId        suId;         /* Service User Id */
U8          status;       /* status of bind */
#endif
{
   TRC3(PtUiHitBndCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
   HILOGERROR_DEBUG( EHI261, (ErrVal)ERRZERO, pst->dstInst,
         "PtUiHitBndCfm");
#endif /* ERRCLASS */
   /* hi021.104: Removing warnings */
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(status);

   RETVALUE(ROK);
} /* end of PtUiHitBndCfm */


/*
*
*       Fun:   Portable - Data Indication
*
*       Desc:  This function provides for indicating incoming 
*              TCP data on the socket.
*
*       Ret:   ROK
*
*       Notes: TCP UDP Convergence Layer strips off the TPKT 
*              header and delievers the data in a message buffer.
*
*       File:  hi_ptui.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtUiHitDatInd
(
Pst         *pst,         /* post structure */
SuId        suId,         /* service User Id */
UConnId      suConId,     /* service provider's connection id */
Buffer      *mBuf         /* message buffer */
)
#else
PRIVATE S16 PtUiHitDatInd(pst, suId, suConId, mBuf)
Pst         *pst;         /* post structure */
SuId        suId;         /* service User Id */
UConnId     suConId;      /* service provider's connection id */ 
Buffer      *mBuf;        /* message buffer */
#endif
{
   TRC3(PtUiHitDatInd)
#if (ERRCLASS & ERRCLS_DEBUG)
   HILOGERROR_DEBUG(EHI262, (ErrVal)ERRZERO, pst->dstInst,
         "PtUiHitDatInd");
#endif /* ERRCLASS */
   /* hi021.104: Removing warnings */
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConId);
   UNUSED(mBuf);

   RETVALUE(ROK);
} /* end of PtUiHitDatInd */


/*
*
*       Fun:   Portable - Unit Data Indication
*
*       Desc:  Portable - Unit Data Indication
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  hi_ptui.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtUiHitUDatInd
(
Pst *pst,                 /* post stucture */
SpId suId,                /* service user Id */
UConnId suConId,          /* service user's connection Id */
CmTptAddr *srcAddr,       /* source transport address */
#ifdef HI_REL_1_3  
CmTptAddr *remAddr,       /* Remote Address */
CmIpHdrParm *ipHdrParm,   /* IP header Parameters */
/* hi009.104 - added new argument localIf */
#ifdef LOCAL_INTF
CmTptLocalInf *localIf,   /* local intf on which pkt arrived */
#endif /* LOCAL_INTF */
#endif /* HI_REL_1_3 */
Buffer *mBuf              /* message buffer */
)
#else
#ifdef HI_REL_1_3
#ifdef LOCAL_INTF
PRIVATE S16 PtUiHitUDatInd(pst, suId, suConId, srcAddr , remAddr, 
                          ipHdrParm, localIf, mBuf)
Pst *pst;                 /* post stucture */
SuId suId;                /* service user Id */
UConnId suConId;          /* service user's connection Id */
CmTptAddr *srcAddr;       /* source transport address */
CmTptAddr *remAddr;       /* Remote Address */
CmIpHdrParm *ipHdrParm;   /* IP header Parameters */
/* hi009.104 - added new argument localIf */
CmTptLocalInf *localIf;  /* local intf on which pkt arrived */
Buffer *mBuf;             /* message buffer */
#else
PRIVATE S16 PtUiHitUDatInd(pst, suId, suConId, srcAddr , remAddr, 
                          ipHdrParm, mBuf)
Pst *pst;                 /* post stucture */
SuId suId;                /* service user Id */
UConnId suConId;          /* service user's connection Id */
CmTptAddr *srcAddr;       /* source transport address */
CmTptAddr *remAddr;       /* Remote Address */
CmIpHdrParm *ipHdrParm;   /* IP header Parameters */
Buffer *mBuf;             /* message buffer */
#endif /* LOCAL_INTF */ 
#else
PRIVATE S16 PtUiHitUDatInd(pst, suId, suConId, srcAddr, mBuf)
Pst *pst;                 /* post stucture */
SpId suId;                /* service user Id */
UConnId suConId;          /* service user's connection Id */
CmTptAddr *srcAddr;       /* source transport address */
Buffer *mBuf;             /* message buffer */
#endif /* HI_REL_1_3 */
#endif /* ANSI */
{
   TRC3(PtUiHitUDatInd)
#if (ERRCLASS & ERRCLS_DEBUG)
   HILOGERROR_DEBUG( EHI263, (ErrVal)ERRZERO, pst->dstInst,
         "PtUiHitUDatInd");
#endif /* ERRCLASS */
   /* hi021.104: Removing warnings */
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConId);
   UNUSED(srcAddr);
#ifdef HI_REL_1_3  
   UNUSED(remAddr);
   UNUSED(ipHdrParm);
#ifdef LOCAL_INTF
   UNUSED(localIf);
#endif /* LOCAL_INTF */
#endif /* HI_REL_1_3 */
   UNUSED(mBuf);

   RETVALUE(ROK);
} /* end of PtUiHitUDatInd */


/*
*
*       Fun:   Portable - Disconnect Indication
*
*       Desc:  Portable - Disconnect Indication
*             
*       Ret:   ROK
*
*       Notes: None
*
*       File:  hi_ptui.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtUiHitDiscInd
(
Pst *pst,                 /* post stucture */
SpId suId,                /* service user Id */
U8  choice,               /* choice parameter */
UConnId conId,            /* connection Id */
Reason reason             /* reason */
)
#else
PRIVATE S16 PtUiHitDiscInd(pst, suId, choice, conId, reason)
Pst *pst;                 /* post stucture */
SpId suId;                /* service user Id */
U8  choice;               /* choice parameter */
UConnId conId;            /* connection Id */
Reason reason;            /* reason */
#endif
{
   TRC3(PtUiHitDiscInd)
#if (ERRCLASS & ERRCLS_DEBUG)
   HILOGERROR_DEBUG( EHI264, (ErrVal)ERRZERO,pst->dstInst,
         "PtUiHitDiscInd");
#endif /* ERRCLASS */
   /* hi021.104: Removing warnings */
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(choice);
   UNUSED(conId);
   UNUSED(reason);
   RETVALUE(ROK);
} /* end of PtUiHitDiscInd */


/*
*
*       Fun:   Portable - Disconnect Confirmation
*
*       Desc:  Portable - Disconnect Confirmation 
*
*       Ret:   ROK
*
*       Notes: None 
* 
*       File:  hi_ptui.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtUiHitDiscCfm
(
Pst *pst,                 /* post stucture */
SpId suId,                /* service user Id */
U8  choice,               /* choice parameter */
UConnId conId,             /* connection Id */
Action action             /* action type */
)
#else
PRIVATE S16 PtUiHitDiscCfm(pst, suId, choice, conId, action)       
Pst *pst;                 /* post stucture */
SpId suId;                /* service user Id */
U8  choice;               /* choice parameter */
UConnId conId;             /* connection Id */
Action action;            /* action type */
#endif
{
   TRC3(PtUiHitDiscCfm)
#if (ERRCLASS & ERRCLS_DEBUG)
   HILOGERROR_DEBUG( EHI265, (ErrVal)ERRZERO, pst->dstInst,
         "PtUiHitDiscCfm");
#endif /* ERRCLASS */
   /* hi021.104: Removing warnings */
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(choice);
   UNUSED(conId);
   UNUSED(action);

   RETVALUE(ROK);
} /* end of PtUiHitDiscCfm */


/*
*
*       Fun:   Portable - Flow Control Indication 
*
*       Desc:  Portable - Flow Control Indication   
*
*       Ret:   ROK
*
*       Notes: None 
*
*       File:  hi_ptui.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtUiHitFlcInd 
(
Pst         *pst,         /* post structure */
SuId        suId,         /* Service User Id */
#ifdef HI_REL_1_3
UConnId     suConId,      /* Service User Connection Id */
#endif /* HI_REL_1_3 */
Reason      reason        /* reason for flow control */
)
#else
#ifdef HI_REL_1_3
PRIVATE S16 PtUiHitFlcInd(pst, suId, suConId, reason)
Pst         *pst;         /* post structure */
SuId        suId;         /* Service User Id */
UConnId     suConId;      /* Service User Connection Id */
Reason      reason;       /* reason for flow control */
#else
PRIVATE S16 PtUiHitFlcInd(pst, suId, reason)
Pst         *pst;         /* post structure */
SuId        suId;         /* Service User Id */
Reason      reason;       /* reason for flow control */
#endif /* HI_REL_1_3 */
#endif /* ANSI */
{
   TRC3(PtUiHitFlcInd)
#if (ERRCLASS & ERRCLS_DEBUG)
   HILOGERROR_DEBUG( EHI266, (ErrVal)ERRZERO, pst->dstInst,
         "PtUiHitFlcInd");
#endif /* ERRCLASS */
   /* hi021.104: Removing warnings */
   UNUSED(pst);
   UNUSED(suId);
#ifdef HI_REL_1_3
   UNUSED(suConId);
#endif /* HI_REL_1_3 */
   UNUSED(reason);

   RETVALUE(ROK);
} /* end of PtUiHitFlcInd */

#endif /* PTHIUIHIT */




/********************************************************************30**
 
         End of file:     hi_ptui.c@@/main/4 - Thu Jun 28 13:30:46 2001
 
*********************************************************************31*/
 

/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 

/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
 1.1           ---    asa   1. initial release.
 1.1+       hi002.11  asa   1. changes for RTP, removed HrLiHitFlcInd,
                               HrLiHitConInd and HrLiHitDatInd
                            2. added a new user GTP.
 1.1+       hi004.11  cvp   1. added a new user MGCP. 
/main/2       ---      cvp   1. added a new user Annex G.
                            2. changed the copyright header.
             /main/4                 sb    1. changes for Raw Socket interface in 
                               primitives HiUiHitUDatInd.
                            2. added a new user SCTP.
                      cvp   3. added a new user MPLS.
                            4. changes for sht interface.
/main/4+    hi001.13  cvp   1. changes for SB, removed SbLiHitFlcInd,
                               SbLiHitConInd and SbLiHitDatInd
/main/4+    hi003.13  cvp   1. added a new user - Dummy layer.
/main/4+    hi006.13  asa   1. added a new user - SIP layer.
/main/4      ---       cvp   1. changed the copyright header.
/main/4+    hi008.104  mmh  1. Added code required for distribution
                               of primitives from TUCL towards GCP
                               through LDF-GCP. The extern definition
                               for the LDF-GCP functions will be added
                               in hit.x to be released with GCP 1.3
/main/4+    hi009.104  mmh  1. added a new argument localIf in functions
                               PtUiHitUDatInd, HiUiHitDatInd when LOCAL_INTF
                               flag is defined during compile time.
/main/4+    hi020.104   rs  1. Added SV as another user.
/main/4+    hi021.104   rs  1. Removing Warnings.
*********************************************************************91*/
