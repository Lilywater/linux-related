/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
    
     Name:     TCP UDP Convergence Layer  
  
     Type:     C source file
  
     Desc:     C source code for TCP UDP Convergence Layer 
               portable Management Interface
  
     File:     hi_ptmi.c
  
     Sid:      hi_ptmi.c@@/main/4 - Thu Jun 28 13:30:40 2001
  
     Prg:      asa
  
*********************************************************************21*/


/* header include files (.h) */
 
/* header/extern include files (.x) */
  
  

/*
  
The following functions are provided in this file:
     HiMiLhiCfgCfm      Configuration Confirm
     HiMiLhiCntrlCfm    Control Confirm
     HiMiLhiStsCfm      Statistics Confirm
     HiMiLhiStaInd      Status Indication
     HiMiLhiStaCfm      Status Confirm
     HiMiLhiTrcInd      Trace Indication
   
It should be noted that not all of these functions may be required
by a particular layer management service user.

It is assumed that the following functions are provided in TUCL

     HiMiLhiCfgReq      Configure Request
     HiMiLhiCntrlReq    Control Request
     HiMiLhiStsReq      Statistics Request
     HiMiLhiStaReq      Status Request
   
*/

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_inet.h"       /* common sockets */
#ifdef FTHA
#include "sht.h"           /* SHT Interface header file */
#endif /* FTHA */
#include "lhi.h"           /* layer management HI */
#include "cm_hash.h"       /* common hashing */
#include "cm_llist.h"      /* common linked list */
#include "cm_err.h"        /* common error */
#include "cm5.h"           /* common timer */
#include "cm_tpt.h"        /* common transport defines */
#include "hit.h"           /* hit interface */
#include "hi.h"            /* TUCL defines */
#include "hi_err.h"        /* HI error */
 
/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_inet.x"       /* common sockets */
#ifdef FTHA
#include "sht.x"           /* SHT Interface header file */
#endif /* FTHA */
#include "lhi.x"           /* layer management TUCL */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm5.x"           /* common timer */
#include "cm_lib.x"        /* common library */
#include "cm_tpt.x"        /* common transport typedefs */
#include "hit.x"           /* hit interface */
#include "hi.x"            /* TUCL typedefs */

/* local externs */
  

#define MAXHIMI  2

#ifndef LCHIMILHI
#define PTHIMILHI
#else
#ifndef SM
#define PTHIMILHI
#endif
#endif


#ifdef PTHIMILHI

/* declaration of portable functions */
PRIVATE S16 PtMiLhiCfgCfm     ARGS((Pst *pst, HiMngmt  *cfg));
PRIVATE S16 PtMiLhiCntrlCfm   ARGS((Pst *pst, HiMngmt *cntrl));
PRIVATE S16 PtMiLhiStaCfm     ARGS((Pst *pst, HiMngmt *sta));
PRIVATE S16 PtMiLhiStaInd     ARGS((Pst *pst, HiMngmt *usta));
PRIVATE S16 PtMiLhiStsCfm     ARGS((Pst *pst, HiMngmt *sts));
PRIVATE S16 PtMiLhiTrcInd     ARGS((Pst *pst, HiMngmt *trc, Buffer *mBuf));

#endif /* PTHIMILHI */

#ifdef FTHA
#ifndef SH
EXTERN S16 PtHiMiShtCntrlCfm ARGS((Pst *pst, ShtCntrlCfmEvnt *cfmInfo));
#endif /* SH */
#endif /* FTHA */


/*
  The following matrices define the mapping between the primitives
  called by the upper interface of TCP UDP Convergence Layer 
  and the corresponding primitives of the TCP UDP Convergence Layer 
  service user(s).
  
  The parameter MAXHIMI defines the maximum number of service users on
  top of TCP UDP Convergence Layer. There is an array of functions
  per primitive invoked by TCP UDP Convergence Layer. Every array is
  MAXHIMI long(i.e.there are as many functions as the number of service
  users).
  
  The dispatching is performed by the configurable variable: selector.
  The selector is configured on a per SAP basis.
  
  The selectors are:
  
   0 - loosely coupled (#define LCHIMILHI)
   1 - Lhi (#define SM)
  
*/



/* Configuration Confirm primitive */
 
PRIVATE LhiCfgCfm HiMiLhiCfgCfmMt[MAXHIMI] =
{
#ifdef LCHIMILHI
   cmPkLhiCfgCfm,          /* 0 - loosely coupled  */
#else
   PtMiLhiCfgCfm,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLhiCfgCfm,          /* 1 - tightly coupled, layer management */
#else
   PtMiLhiCfgCfm,          /* 1 - tightly coupled, portable */
#endif
};

/* Control Confirm primitive */
 
PRIVATE LhiCntrlCfm HiMiLhiCntrlCfmMt[MAXHIMI] =
{
#ifdef LCHIMILHI
   cmPkLhiCntrlCfm,          /* 0 - loosely coupled  */
#else
   PtMiLhiCntrlCfm,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLhiCntrlCfm,          /* 1 - tightly coupled, layer management */
#else
   PtMiLhiCntrlCfm,          /* 1 - tightly coupled, portable */
#endif
};

/* Statistics Confirm primitive */
 
PRIVATE LhiStsCfm HiMiLhiStsCfmMt[MAXHIMI] =
{
#ifdef LCHIMILHI
   cmPkLhiStsCfm,          /* 0 - loosely coupled  */
#else
   PtMiLhiStsCfm,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLhiStsCfm,          /* 1 - tightly coupled, layer management */
#else
   PtMiLhiStsCfm,          /* 1 - tightly coupled, portable */
#endif
};

/* Status Indication primitive */
 
PRIVATE LhiStaInd HiMiLhiStaIndMt[MAXHIMI] =
{
#ifdef LCHIMILHI
   cmPkLhiStaInd,          /* 0 - loosely coupled  */
#else
   PtMiLhiStaInd,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLhiStaInd,          /* 1 - tightly coupled, layer management */
#else
   PtMiLhiStaInd,          /* 1 - tightly coupled, portable */
#endif
};

/* Status Confirm primitive */
 
PRIVATE LhiStaCfm HiMiLhiStaCfmMt[MAXHIMI] =
{
#ifdef LCHIMILHI
   cmPkLhiStaCfm,          /* 0 - loosely coupled  */
#else
   PtMiLhiStaCfm,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLhiStaCfm,          /* 1 - tightly coupled, layer management */
#else
   PtMiLhiStaCfm,          /* 1 - tightly coupled, portable */
#endif
};

/* Trace Indication primitive */
 
PRIVATE LhiTrcInd HiMiLhiTrcIndMt[MAXHIMI] =
{
#ifdef LCHIMILHI
   cmPkLhiTrcInd,          /* 0 - loosely coupled  */
#else
   PtMiLhiTrcInd,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLhiTrcInd,          /* 1 - tightly coupled, layer management */
#else
   PtMiLhiTrcInd,          /* 1 - tightly coupled, portable */
#endif
};

#ifdef FTHA
/* System agent control Confirm primitive */
PRIVATE ShtCntrlCfm HiMiShtCntrlCfmMt[MAXHIMI] =
{
   cmPkMiShtCntrlCfm,      /* 0 - loosely coupled */
   #ifdef SH
   ShMiShtCntrlCfm,        /* 1 - tightly coupled system agent */
   #else
   PtHiMiShtCntrlCfm,      /* 1 - tightly coupled, portable */
   #endif
};


/*
*
*       Fun:   System agent control Confirm
*
*       Desc:  This function is used to send the system agent control confirm 
*              primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  hi_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 HiMiShtCntrlCfm
(
Pst *pst,                /* post structure */
ShtCntrlCfmEvnt *cfmInfo     /* system agent control confirm event */
)
#else
PUBLIC S16 HiMiShtCntrlCfm(pst, cfmInfo)
Pst *pst;                /* post structure */
ShtCntrlCfmEvnt *cfmInfo;    /* system agent control confirm event */
#endif
{

   TRC3(HiMiShtCntrlCfm)

   /* jump to specific primitive depending on configured selector */
   (*HiMiShtCntrlCfmMt[pst->selector])(pst, cfmInfo); 

   RETVALUE(ROK);

} /* end of HiMiShtCntrlCfm */

#ifndef SH

/*
*
*       Fun:   Portable system agent control Confirm
*
*       Desc:  This function is used to send the system agent control confirm 
*              primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  hi_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 PtHiMiShtCntrlCfm
(
Pst *pst,                /* post structure */
ShtCntrlCfmEvnt *cfmInfo     /* system agent control confirm event */
)
#else
PUBLIC S16 PtHiMiShtCntrlCfm(pst, cfmInfo)
Pst *pst;                /* post structure */
ShtCntrlCfmEvnt *cfmInfo;    /* system agent control confirm event */
#endif
{

   TRC3(PtHiMiShtCntrlCfm)

   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
         "HiMiLhiCfgCfm(pst, cfg (0x%p))\n", cfmInfo));

   RETVALUE(ROK);

} /* end of PtHiMiShtCntrlCfm */
#endif /* SH */
#endif /* FTHA */


/*
*     Layer Management Interface Functions 
*/


/*
*
*       Fun:   Configuration confirm
*
*       Desc:  This function is used to send a configuration confirm
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  hi_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 HiMiLhiCfgCfm
(
Pst     *pst,            /* post structure */
HiMngmt *cfg             /* configuration */
)
#else
PUBLIC S16 HiMiLhiCfgCfm(pst, cfg)
Pst     *pst;            /* post structure */   
HiMngmt *cfg;            /* configuration */
#endif
{
   TRC3(HiMiLhiCfgCfm)
 
   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
         "HiMiLhiCfgCfm(pst, cfg (0x%p))\n", cfg));
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*HiMiLhiCfgCfmMt[pst->selector])(pst, cfg)); 
} /* end of HiMiLhiCfgCfm */


/*
*
*       Fun:   Control confirm
*
*       Desc:  This function is used to send a control confirm
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  hi_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 HiMiLhiCntrlCfm
(
Pst     *pst,            /* post structure */
HiMngmt *cntrl           /* control */
)
#else
PUBLIC S16 HiMiLhiCntrlCfm(pst, cntrl)
Pst     *pst;            /* post structure */   
HiMngmt *cntrl;          /* control */
#endif
{
   TRC3(HiMiLhiCntrlCfm)
 
   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
         "HiMiLhiCntrlCfm(pst, cntrl (0x%p))\n", cntrl));
 
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*HiMiLhiCntrlCfmMt[pst->selector])(pst, cntrl)); 
} /* end of HiMiLhiCntrlCfm */


/*
*
*       Fun:   Status Indication
*
*       Desc:  This function is used to indicate the status
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  hi_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 HiMiLhiStaInd
(
Pst     *pst,            /* post structure */
HiMngmt *usta             /* unsolicited status */
)
#else
PUBLIC S16 HiMiLhiStaInd(pst, usta)
Pst     *pst;            /* post structure */   
HiMngmt *usta;            /* unsolicited status */
#endif
{
   TRC3(HiMiLhiStaInd)

   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
          "HiMiLhiStaInd(pst, usta (0x%p))\n", usta));
 
   /* jump to specific primitive depending on configured selector */
   RETVALUE((*HiMiLhiStaIndMt[pst->selector])(pst, usta)); 
} /* end of HiMiLhiStaInd */


/*
*
*       Fun:   Status Confirm
*
*       Desc:  This function is used to return the status 
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  hi_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 HiMiLhiStaCfm
(
Pst     *pst,            /* post structure */     
HiMngmt *sta              /* solicited status */
)
#else
PUBLIC S16 HiMiLhiStaCfm(pst, sta)
Pst     *pst;            /* post structure */     
HiMngmt *sta;             /* solicited status */
#endif
{
   TRC3(HiMiLhiStaCfm)

   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
          "HiMiLhiStaCfm(pst, sta (0x%p))\n",  sta));

   /* jump to specific primitive depending on configured selector */
   RETVALUE((*HiMiLhiStaCfmMt[pst->selector])(pst, sta)); 
} /* end of HiMiLhiStaCfm */

/*
*
*       Fun:   Statistics Confirm
*
*       Desc:  This function is used to return the statistics 
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  hi_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 HiMiLhiStsCfm
(
Pst     *pst,                /* post structure */    
HiMngmt *sts                 /* statistics */
)
#else
PUBLIC S16 HiMiLhiStsCfm(pst, sts)
Pst     *pst;                /* post structure */    
HiMngmt *sts;                /* statistics */
#endif
{
   TRC3(HiMiLhiStsCfm)

   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
         "HiMiLhiStsCfm(pst, sts (0x%p))\n", sts));

   /* jump to specific primitive depending on configured selector */
   RETVALUE((*HiMiLhiStsCfmMt[pst->selector])(pst, sts)); 
} /* end of HiMiLhiStsCfm */


/*
*
*       Fun:   Trace Indication
*
*       Desc:  This function is used to indicate the trace 
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  hi_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 HiMiLhiTrcInd
(
Pst     *pst,            /* post structure */
HiMngmt *trc,             /* unsolicited status */
Buffer  *mBuf              /* message buffer */ 
)
#else
PUBLIC S16 HiMiLhiTrcInd(pst, trc, mBuf)
Pst     *pst;            /* post structure */   
HiMngmt *trc;             /* unsolicited status */
Buffer  *mBuf;             /* message buffer */ 
#endif
{
   TRC3(HiMiLhiTrcInd)

   HIDBGP(DBGMASK_MI, (hiCb.hiInit.prntBuf,
         "HiMiLhiTrcInd(pst, trc (0x%p))\n", trc));

   /* jump to specific primitive depending on configured selector */
   RETVALUE((*HiMiLhiTrcIndMt[pst->selector])(pst, trc, mBuf)); 
} /* end of HiMiLhiTrcInd */ 

#ifdef PTHIMILHI

/*
*
*       Fun:   Portable Configuration confirm
*
*       Desc:  
*
*       Ret:   None
*
*       Notes: None
*
*       File:  hi_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLhiCfgCfm
(
Pst     *pst,              /* post structure */
HiMngmt *cfg               /* configuration */
)
#else
PRIVATE S16 PtMiLhiCfgCfm(pst, cfg)
Pst     *pst;              /* post structure */
HiMngmt *cfg;              /* configuration */
#endif
{
   TRC3(PtMiLhiCfgCfm)
 
   UNUSED(pst);
   UNUSED(cfg);
 
#if (ERRCLASS & ERRCLS_DEBUG)
   HILOGERROR_DEBUG(EHI070, (ErrVal)0, pst->dstInst, 
         "PtMiLhiCfgCfm () Failed");
#endif
   RETVALUE(ROK);
} /* end of PtMiLhiCfgCfm */


/*
*
*       Fun:   Portable Control confirm
*
*       Desc:
*
*       Ret:   None
*
*       Notes: None
*
*       File:  hi_ptmi.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtMiLhiCntrlCfm
(
Pst     *pst,              /* post structure */
HiMngmt *cntrl             /* control */
)
#else
PRIVATE S16 PtMiLhiCntrlCfm(pst, cntrl)
Pst     *pst;              /* post structure */
HiMngmt *cntrl;            /* control */
#endif
{
  TRC3(PtMiLhiCntrlCfm)
 
  UNUSED(pst);
  UNUSED(cntrl);
 
#if (ERRCLASS & ERRCLS_DEBUG)
  HILOGERROR_DEBUG(EHI071, (ErrVal)0, pst->dstInst,
        "PtMiLhiCntrlCfm () Failed");
#endif
  RETVALUE(ROK);
} /* end of PtMiLhiCntrlCfm */

/*
*
*       Fun:   Portable Status Confirm
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  hi_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLhiStaCfm
(
Pst     *pst,              /* post structure */
HiMngmt *sta                /* solicited status */
)
#else
PRIVATE S16 PtMiLhiStaCfm(pst, sta)
Pst     *pst;              /* post structure */
HiMngmt *sta;               /* solicited status */
#endif
{
  TRC3(PtMiLhiStaCfm);

  UNUSED(pst);
  UNUSED(sta);

#if (ERRCLASS & ERRCLS_DEBUG)
  HILOGERROR_DEBUG(EHI072, (ErrVal)0, pst->dstInst,
        "PtMiLhiStaCfm () Failed");
#endif
  RETVALUE(ROK);
} /* end of PtMiLhiStaCfm */


/*
*
*       Fun:   Portable Status Indication
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  hi_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLhiStaInd
(
Pst     *pst,               /* post structure */
HiMngmt *usta                /* unsolicited status */
)
#else
PRIVATE S16 PtMiLhiStaInd(pst, usta)
Pst     *pst;               /* post structure */
HiMngmt *usta;               /* unsolicited status */
#endif
{
  TRC3(PtMiLhiStaInd);

  UNUSED(pst);
  UNUSED(usta);

#if (ERRCLASS & ERRCLS_DEBUG)
  HILOGERROR_DEBUG(EHI073, (ErrVal)0, pst->dstInst,
        "PtMiLhiStaInd () Failed");
#endif
  RETVALUE(ROK);
} /* end of PtMiLhiStaInd */


/*
*
*       Fun:   Portable Statistics Confirm
*
*       Desc:  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  hi_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLhiStsCfm
(
Pst     *pst,              /* post structure */
HiMngmt *sts               /* statistics */
)
#else
PRIVATE S16 PtMiLhiStsCfm(pst, sts)
Pst     *pst;              /* post structure */
HiMngmt *sts;              /* statistics */
#endif
{
  TRC3(PtMiLhiStsCfm);

  UNUSED(pst);
  UNUSED(sts);

#if (ERRCLASS & ERRCLS_DEBUG)
  HILOGERROR_DEBUG(EHI074, (ErrVal)0, pst->dstInst,
        "PtMiLhiStsCfm () Failed");
#endif
  RETVALUE(ROK);
} /* end of PtMiLhiStsCfm */


/*
*
*       Fun:   Portable Trace Indication
*
*       Desc:  
*
*       Ret:   None
*
*       Notes: None
*
*       File:  hi_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLhiTrcInd
(
Pst     *pst,              /* post structure */
HiMngmt *trc,              /* trace */
Buffer  *mBuf              /* message buffer */ 
)
#else
PRIVATE S16 PtMiLhiTrcInd(pst, trc, mBuf)
Pst     *pst;              /* post structure */
HiMngmt *trc;               /* trace */
Buffer  *mBuf;             /* message buffer */ 
#endif
{
  TRC3(PtMiLhiTrcInd);

  UNUSED(pst);
  UNUSED(trc);

#if (ERRCLASS & ERRCLS_DEBUG)
  HILOGERROR_DEBUG( EHI075, (ErrVal)0, pst->dstInst,
        "PtMiLhiTrcInd () Failed");
#endif
  RETVALUE(ROK);
} /* end of PtMiLhiTrcInd */

#endif /* PTHIMILHI */


/********************************************************************30**
 
         End of file:     hi_ptmi.c@@/main/4 - Thu Jun 28 13:30:40 2001

*********************************************************************31*/
 
/********************************************************************40**
 
        notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        revision history:
 
*********************************************************************61*/
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      asa  1. initial release.
/main/2       ---      cvp  1. changed the copyright header.
             /main/4                cvp  1. changes for sht interface. 
/main/4      ---     cvp   1. changed the copyright header.
*********************************************************************91*/
