/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:    TCP UDP Convergence Layer (TUCL)
  
     Type:    C source file
  
     Desc:    Support/Utility functions 
              
     File:    hi_bdy2.c
  
     Sid:      hi_bdy2.c@@/main/4 - Thu Jun 28 13:29:45 2001

     Prg:     asa
  
*********************************************************************21*/

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hash list */
#include "cm_llist.h"      /* common linked list */
#include "cm5.h"           /* common timer */
#include "cm_inet.h"       /* common sockets */
#include "cm_tpt.h"        /* common transport defines */
#ifdef FTHA
#include "sht.h"           /* SHT Interface header files */
#endif /* FTHA */
#include "lhi.h"           /* layer management, TUCL  */
#include "hit.h"           /* HIT interface */
#include "hi.h"            /* TUCL internal defines */
#include "hi_err.h"        /* TUCL error */
 
/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hashing */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common library */
#include "cm5.x"           /* common timer */
#include "cm_inet.x"       /* common sockets */
#include "cm_tpt.x"        /* common transport typedefs */
#ifdef FTHA
#include "sht.x"           /* SHT Interface header file */
#endif /* FTHA */
#include "lhi.x"           /* layer management TUCL */
#include "hit.x"           /* HIT interface */
#include "hi.x"            /* TUCL internal typedefs */
 
/* Public variable declarations */
/* function prototypes */

/* functions */

/* ------------------------------------------------------------------*/
/* Timer related functions
 */
 
#ifndef HI_LPBK
#ifndef HI_MULTI_THREADED

/*
*
*       Fun:   hiTmrEvnt  
*
*       Desc:  This function is used to process the expiry of TUCL
*              timer events.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiTmrEvnt 
(
PTR  cb,                  /* control block */
S16 evnt                  /* timer number */
)
#else
PUBLIC S16 hiTmrEvnt(cb, evnt) 
PTR  cb;                  /* control block */
S16 evnt;                 /* timer number */
#endif
{

   TRC2(hiTmrEvnt)

#if (ERRCLASS & ERRCLS_DEBUG)
   if(!cb)
   {
      HILOGERROR_DEBUG(EHI090, (ErrVal) evnt, 0,
                "hiTmrEvnt(): invalid control block");
      RETVALUE(RFAILED);
   }
   if(evnt != HI_TMR_SCHD)
   {
      HILOGERROR_DEBUG(EHI091, (ErrVal) evnt, 0,
                 "hiTmrEvnt(): invalid timer event value");
      RETVALUE(RFAILED);
   }
#endif /* ERRRCLS_DEBUG */

   hiRecvTsk(NULLP, NULLP);

   /* restart the scheduling timer */
   /* the timer is started with one layer tick */
   HI_START_TMR(HI_TMR_SCHD, 1);

   RETVALUE(ROK);
}/* end of  hiTmrEvnt() */


/*
*
*       Fun:   Activate Task - timer
*
*       Desc:  Invoked by system services to activate a task with
*              a timer tick.
*
*       Ret:   ROK      - ok
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 hiActvTmr
(
ProcId procId,    /* proc id */
Ent ent,          /* Entity */
Inst inst         /* Instance */
)
#else
PUBLIC S16 hiActvTmr(procId,ent,inst)
ProcId procId;    /* proc id */
Ent ent;          /* Entity */
Inst inst;         /* Instance */
#endif
#else /* SS_MULTIPLE_PROCS */
#ifdef ANSI
PUBLIC S16 hiActvTmr
(
Void
)
#else
PUBLIC S16 hiActvTmr()
#endif
#endif /* SS_MULTIPLE_PROCS */
{

   TRC2(hiActvTmr)

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(procId,ent,inst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,inst,
            "hiActvTmr() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_SI, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      procId,ent,inst));
#endif  /* SS_MULTIPLE_PROCS */   

   cmPrcTmr(&hiCb.hiTqCp, hiCb.hiTq, (PFV)hiTmrEvnt);

   RETVALUE(ROK);
}
#endif /* HI_MULTI_THREADED */
#endif /* HI_LPBK */

/* ------------------------------------------------------------------*/
/*  General Utility Functions
 */

#ifndef HI_MULTI_THREADED 

/*
*
*       Fun:   hiFreeConCb
*
*       Desc:  This function is used to clean up and then free a
*              connection block.
*
*       Ret:   ROK 
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void hiFreeConCb
(
HiConCb  *conCb               /* connection block */ 
)
#else
PUBLIC Void hiFreeConCb(conCb)
HiConCb  *conCb;              /* connection block */ 
#endif
{

   HiSap       *sap;/* sap pointer */
   S16         ret; /* return value */
#ifdef HI_LPBK
   U8          action;
   UConnId     conId;
   U8          choice;
   HiConCb     *pConCb;
   HiConCb     *prevConCb;
   HiConCb     *nextConCb;
   U8          i;
#endif /* HI_LPBK */

   TRC2(hiFreeConCb)

   ret = ROK;

   sap = conCb->sap;

#ifdef HI_LPBK

   i = 0;
   action = conCb->action;
   conId = ((conCb->flag & HI_FL_UDP)? 
            (choice = HI_USER_CON_ID, conCb->suConId):
            (choice = HI_PROVIDER_CON_ID, conCb->spConId));
   
   if(!(conCb->flag & HI_FL_UDP) && (conCb->conState == HI_ST_CONNECTED))
   {
      /* issue a HitDiscInd for the peer side of the connection */
      while((ret=cmHashListFind(&hiCb.locAddrHlCp, 
                                (U8 *)&(conCb->peerAddr.u.ipv4TptAddr), 
                                sizeof(CmIpv4TptAddr), i++, 
                                (PTR *)&pConCb)) == ROK)
      {
         if((!(pConCb->flag & HI_FL_UDP)) && 
                        (!(pConCb->conState == HI_ST_SRV_LISTEN)))
         {
            /* free the peer connection block */
            (Void)cmHashListDelete(&pConCb->sap->sapHlCp, (PTR)pConCb);
            (Void)cmHashListDelete(&hiCb.locAddrHlCp,  (PTR)pConCb);

            /* Zero the structure  and free it */
            HI_FREE(sizeof(HiConCb), pConCb);
            
            /* Decrement the statistics counters */
            pConCb->sap->genTxSts.numCons--;
            pConCb->sap->txSts.numCons--;
            HI_DISCIND(pConCb->sap, HI_PROVIDER_CON_ID, pConCb->spConId, 
                       HI_CON_CLOSED_BY_PEER);
            break;
         }
      }/* end while loop */
   }

   (Void)cmHashListDelete(&sap->sapHlCp, (PTR)conCb);
   (Void)cmHashListDelete(&hiCb.locAddrHlCp, (PTR)conCb);

   /* for a UDP server with multicast group memberships, leave
    * all group memberships */
   if(conCb->flag & HI_FL_MCAST_CONCB)
   {
      /* erase all concbs with matching suConId */
      prevConCb = nextConCb = NULLP;
      while((ret = cmHashListGetNext(&hiCb.locAddrHlCp, (PTR)prevConCb,
                                     (PTR*)&nextConCb)) != ROKDNA)
      {
         if(ret == RFAILED)
            break;
         if(conCb->suConId == nextConCb->suConId)
         {
            (Void)cmHashListDelete(&hiCb.locAddrHlCp, (PTR)nextConCb);
            HI_FREE(sizeof(HiConCb), nextConCb);
         }
         else
         {
            prevConCb = nextConCb;
         }
      }/* end while */
   }/* end if */

   /* zero the structure  and free it */
   HI_FREE(sizeof(HiConCb), conCb)
   
   /* decrement the statistics counters */
   sap->txSts.numCons--;
   sap->genTxSts.numCons--;
   if(action)
      HiUiHitDiscCfm(&sap->uiPst, sap->suId, choice, conId, action);
#else /* HI_LPBK */

   if (!(conCb->toBeDel))
   {
      if (!sap)
         RETVOID;

      /* mark the connection block for deletion */
      conCb->toBeDel = TRUE;

      /* Decrement the number of file descriptors from the file descriptor
       * group */
      hiDecNumFds(conCb, conCb->fdBlkIdx);

      /* remove the socket from the fdset */ 
      hiFdClr(conCb, CM_INET_SHTDWN_BOTH);
 
#ifdef HI_REL_1_3  
      /* If this connection block was listening to ICMP messages then we have 
       * to deallocate the filter structure if any & decrement the number of 
       * current ICMP listeners  */
      if(conCb->icmpMask)
      {
         /* If there are no other icmpUsers close this socket */
         hiCloseIcmpSock(conCb, CM_NETADDR_IPV4);

         conCb->icmpMask = 0;
         if(conCb->icmpError)
            HI_FREE((conCb->numFilters*sizeof(CmIcmpError)), conCb->icmpError);
         conCb->numFilters = 0;
      }
#ifdef IPV6_SUPPORTED 
      else if (conCb->icmp6Mask)
      {
         /* If there are no other icmpUsers close this socket */
         hiCloseIcmpSock(conCb, CM_NETADDR_IPV6);

         conCb->icmp6Mask = 0;
         if(conCb->icmpError)
            HI_FREE((conCb->numFilters*sizeof(CmIcmpError)), conCb->icmpError);
         conCb->numFilters = 0;
      }
#endif /* IPV6_SUPPORTED */
#endif  /* HI_REL_1_3 */ 

      /* flush the transmit queue in the connection block */
      ret = SFlushQueue(&conCb->txQ);
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         HILOGERROR_DEBUG(EHI092, (ErrVal) ret, 0,
                    "hiFreeConCb() :SFlushQueue failure.");
         RETVOID;
      }
#endif /* ERRCLS_DEBUG */

#ifdef HI_REL_1_3  
      if(conCb->protocol != CM_PROTOCOL_ICMP)
      {
         HI_CLOSE_SOCKET(&conCb->conFd); /* close the socket */
      }
#else  
      /* close the socket */
      HI_CLOSE_SOCKET(&conCb->conFd);
#endif /* HI_REL_1_3 */ 

      /* free any partially received mBufs */
      if (conCb->rxBuf != NULLP)
         SPutMsg(conCb->rxBuf);

      /* disable conCb for any further read or write operations */
      conCb->conState = HI_ST_CONNECTED_NORDWR;
      
      /* insert in the to be deleted list */
      if (!(conCb->isInList & HI_CONCB_IN_SCANCON_LIST))
      {
         conCb->llEnt.node = (PTR)conCb;
         cmLListAdd2Tail(&hiCb.llstCp, (CmLList *)&conCb->llEnt);
         conCb->isInList |= HI_CONCB_IN_SCANCON_LIST;
      }
   }
#endif /* HI_LPBK */
   RETVOID;
}/* end of hiFreeConCb() */
#endif /* HI_MULTI_THREADED */

/* hi018.104: add a new utility for doing close socket cleanup */

/*
*
*       Fun:   hiDiscSockHandle
*
*       Desc:  This function is used to clean up and then free a
*              connection block.
*
*       Ret:   ROK 
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void hiDiscSockHandle
(
Bool     delImmed,
Reason   reason,
HiConCb  *conCb               /* connection block */ 
)
#else
PUBLIC Void hiDiscSockHandle(delImmed, reason, conCb)
Bool     delImmed; 
Reason   reason;
HiConCb  *conCb;              /* connection block */ 
#endif
{
#ifdef HI_MULTI_THREADED
   HiFdGrpInfo *grpInfoPtr;
   HiSap       *sap;
   S16         ret;
   S16         numFds;
   HiAlarmInfo alInfo;
#endif
	   
   TRC2(hiDiscSockHandle)

   if (conCb == NULLP)
      RETVOID;

   /* hi028 - Removed compiler warning */
#ifndef HI_MULTI_THREADED
   UNUSED(delImmed);
#endif
      
   conCb->reason = reason;
#ifdef HI_MULTI_THREADED
   sap = conCb->sap;
   numFds = 1;
   conCb->action = HI_CLOSE;
   conCb->toBeDel |= HI_DEL_SEND_DISCIND;
   if(delImmed == FALSE)
   {
      cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
      conCb->toBeDel |= HI_DEL_SEND_DISCCFM;
      hiDecNumFds(conCb, conCb->fdBlkIdx);
      /* Close the Icmp socket if necessary */
      hiChkAndCloseIcmpSock(conCb);
      hiAddConCbToCmList(conCb, HI_CM_TOBEDEL_LIST);
   }
   else
   {
      if (conCb->fdBlkIdx >= hiCb.numFdGrps)
         RETVOID;
      grpInfoPtr = hiCb.hiFdGrpInfoLstPtr[conCb->fdBlkIdx];

      if (!grpInfoPtr)
         RETVOID;

      HI_LOCK(&grpInfoPtr->cmInfoLock, alInfo, ret);
      if (ret != ROK)
      {
         HILOGERROR_DEBUG(EHI212, (ErrVal)ret, grpInfoPtr->thisInst,
                 "hiDiscSockHandle: Could not acquire common info lock ");
         RETVOID;
      }
      
      hiProcDelConCb(conCb, grpInfoPtr, NULLP, NULLP,
                     &numFds);
      HI_UNLOCK(&grpInfoPtr->cmInfoLock, alInfo, ret)
      if (ret != ROK)
      {
         HILOGERROR_DEBUG(EHI213, (ErrVal)ret, grpInfoPtr->thisInst,
              "hiDiscSockHandle: Could not unlock common info lock");
	 RETVOID;
      }
   }
#else
   conCb->action = 0;
   conCb->discInd = TRUE;
   hiFreeConCb(conCb);   
#endif /* HI_MULTI_THREADED */
   RETVOID;
}


/*
*
*       Fun:   hiAllocSap
*
*       Desc:  Allocate a SAP
*            
*       Ret:   Failure:    LCM_REASON_MEM_NOAVAIL
*              Success:    LCM_REASON_NOT_APPL
*              
*       Notes: None
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC  S16 hiAllocSap
(
HiSapCfg         *cfg        /* pointer to SAP configuration */
)
#else
PUBLIC  S16 hiAllocSap(cfg)
HiSapCfg         *cfg;        /* pointer to SAP configuration */
#endif
{
   
   HiSap         *sap;       /* transport SAP */
   S16            ret;       /* function return value */

   TRC2(hiAllocSap)

   /* allocate memory for the sap */
   HI_ALLOC(sizeof(HiSap), sap)
   if(!sap)
      RETVALUE(LCM_REASON_MEM_NOAVAIL);
 
   /* initialize new sap */
   sap->spId        = cfg->spId;        /* spId */

   /* Set the controlling entity information here */
#ifdef HI_DIS_SAP
   sap->contEnt = ENTSM;   /* stack manager controlling entity */
#else
   sap->contEnt = ENTNC;   /* unknown controlling entity */
#endif /* HI_DIS_SAP */

   /* sap->suId is initialized on getting a bind 
      request from the user */

   /* hi009.104 - copy interface version info (configure) to this new sap!! */
#ifdef HI_RUG
   /* reconfigure interface version info */ 
   if (cfg->remIntfValid == TRUE)
   {
      /* validate interface version number */
      if (cfg->remIntfVer > HITIFVER)
      {
         /* free the memory allocated for this new sap control block */
         HI_FREE(sizeof(HiSap), sap);
      
         /* send NOK to LM with reason version mismatch */            
         RETVALUE(LCM_REASON_VERSION_MISMATCH);
      }
      else
      {
         /* reconfigure interface version number in pst of SAP */
         sap->uiPst.intfVer = cfg->remIntfVer;

         /* mark the validity of remote interface version number */
         sap->remIntfValid = TRUE;

         /* mark version controlling entity as layer manager */
         sap->verContEnt = ENTSM;
      }
   }
   else
   {
         /* mark the validity of remote interface version as FALSE */
         sap->remIntfValid = FALSE;

         /* mark version controlling entity as unknown */
         sap->verContEnt = ENTNC;  /* version controller unknown */
   }
#endif /* HI_RUG */
   
   /* update the HI user pst */
   sap->uiPst.selector  = cfg->uiSel;
   sap->uiPst.prior     = cfg->uiPrior;
   sap->uiPst.route     = cfg->uiRoute;
   sap->uiPst.region    = cfg->uiMemId.region;
   sap->uiPst.pool      = cfg->uiMemId.pool;
 
   /* dstProcId, dstEnt, and dstInst are assigned 
    * during bind request */
   sap->uiPst.dstProcId = PROCIDNC;
   sap->uiPst.dstEnt    = ENTNC;
   sap->uiPst.dstInst   = INSTNC;
   
   /* srcProcId, srcEnt and srcInst are assigned
    * during bind request */
   sap->uiPst.srcProcId = PROCIDNC; 
   sap->uiPst.srcEnt    = hiCb.hiInit.ent; 
   sap->uiPst.srcInst   = INSTNC;
   sap->uiPst.event     = EVTNONE;

   /* update the configuration */
   cmMemcpy((U8*)&sap->cfg, (U8*)cfg, sizeof(HiSapCfg));
 
   /* update the pointer to the sap in the table of saps */
   hiCb.sapLstPtr[sap->spId]   = sap;
 
   /* change the state as configured but unbound */
   sap->state           = HI_ST_UBND;
   
   /* initialise the connection block hash list  */
   /* hi022.104: Changing keytype from DEF to U32 */
   ret = cmHashListInit(&sap->sapHlCp,          /* connections */
                        cfg->numBins,           /* HL bins for the server */
                        HI_GET_OFFSET(HiConCb, sapHlEnt),
                        HI_HLDUP_FLAG,          /* Allow dup. keys ? */
                        CM_HASH_KEYTYPE_U32MOD, /* HL key type */
                        hiCb.hiInit.region,     /* Mem region for HL */
                        hiCb.hiInit.pool);      /* Mem pool for HL */

   if(ret != ROK)
   {
      hiCb.sapLstPtr[sap->spId] = NULLP;

      /* Free the memory associated with this SAP */
      HI_FREE(sizeof(HiSap), sap);

      RETVALUE(LCM_REASON_MEM_NOAVAIL);
   }

#ifdef HI_MULTI_THREADED     
   ret = SInitLock(&sap->spConIdLock, SS_LOCK_MUTEX);
   if (ret != ROK)
   {
      hiCb.sapLstPtr[sap->spId] = NULLP;

      cmHashListDeinit(&sap->sapHlCp);
   
      /* Free the memory associated with this SAP */
      HI_FREE(sizeof(HiSap), sap);

      RETVALUE(LHI_REASON_LOCK_INIT_FAILED);
   }

   /* initialise the connection block hash list  */
   /* hi022.104: Changing keytype from DEF to U32 */
   ret = cmHashListInit(&sap->spConIdHlCp,      /* spConId hashlist */
                        cfg->numBins,           /* HL bins for the server */
                        HI_GET_OFFSET(HiConCb, spConIdHlEnt), /* Get Offset */
                        HI_HLDUP_FLAG,          /* Allow dup. keys ? */
                        CM_HASH_KEYTYPE_U32MOD, /* HL key type */
                        hiCb.hiInit.region,     /* Mem region for HL */
                        hiCb.hiInit.pool);      /* Mem pool for HL */
   if(ret != ROK)
   {
      hiCb.sapLstPtr[sap->spId] = NULLP;

      cmHashListDeinit(&sap->sapHlCp);
 
      /* Destroy the lock */
      SDestroyLock(&sap->spConIdLock);

      /* Free the memory associated with this SAP */
      HI_FREE(sizeof(HiSap), sap);

      RETVALUE(LCM_REASON_MEM_NOAVAIL);
   }
#endif /* HI_MULTI_THREADED */

   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of hiAllocSap() */

  
/*
*
*       Fun:    hiGetConId
*
*       Desc:   Allocates a new spConId.
*               In the multiple receive thread case the conCb will also be
*               added in the spConIdHl.
*
*       Ret:    ROK 
*               RFAILED
*
*       Notes:  None 
*
*       File:   hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiGetConId
(
HiSap *sap,               /* SAP pointer */
HiConCb *conCb
)
#else
PUBLIC S16 hiGetConId(sap, conCb) 
HiSap *sap;               /* SAP pointer */
HiConCb *conCb;
#endif
{

   UConnId      id;
   HiConCb      *tempConCb;
   U32          maxNmbCons;
   CmHashListCp *listHlCp;
   HiAlarmInfo  alInfo;
#ifdef HI_MULTI_THREADED
   S16          ret;
#endif /* HI_MULTI_THREADED */

   TRC2(hiGetConId)
 
   /* Variable initializations */
   maxNmbCons = hiCb.cfg.numCons;

   alInfo.spId = sap->spId;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   /* This assignment need not be protected in the multiple receive 
    * thread case. This is because the hash list find is locked.
    */
   id = ++sap->lstSpConId;

#ifdef HI_MULTI_THREADED     
   /* Lock the hash list */
   HI_LOCK(&sap->spConIdLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI093, (ErrVal) ret, sap->uiPst.srcInst,
                    "hiGetConId () : Unable to lock sap spConId hash list \n.");
      RETVALUE(RFAILED);
   }

   /* Search for a conId from the spConIdHl */
   listHlCp = &sap->spConIdHlCp;
#else
   /* Search for a conId from the sap hashlist */
   listHlCp = &sap->sapHlCp;
#endif /* HI_MULTI_THREADED */

   while(maxNmbCons)
   {
      /* wrap around connection id */
      if (id > hiCb.cfg.numCons)
         id = 1;

      /* check that conId is not already in use */
      if ((cmHashListFind (listHlCp, (U8 *)&id, sizeof(UConnId), 0,
                                (PTR *)&tempConCb)) == RFAILED)
      {
         sap->lstSpConId = id;

         /* fill up the id in conId */
         conCb->spConId = id;

#ifdef HI_MULTI_THREADED     
         /* Insert the connection control block in the spConId hash list */
         ret = cmHashListInsert(listHlCp, (PTR)conCb, (U8 *)&conCb->spConId,
                                sizeof(UConnId));
         if (ret != ROK)
         {
            HILOGERROR_DEBUG( EHI094, (ErrVal)ret, 0,
               "hiGetConId () : Unable to insert conCb in spConId hashlist");
            hiSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_INV_EVT, 
                        LCM_CAUSE_HASH_FAIL, &alInfo);
            HI_UNLOCK(&sap->spConIdLock, alInfo, ret);
            if (ret != ROK)
               HILOGERROR_DEBUG(EHI095, (ErrVal)ret, sap->uiPst.srcInst,
                  "hiGetConId - Failed to unlock spconid lock \n");
            RETVALUE(RFAILED);
         }

         conCb->isInList |= HI_CONCB_IN_SPCONID_LIST;

         HI_UNLOCK(&sap->spConIdLock, alInfo, ret);
         if (ret != ROK)
         {
            HILOGERROR_DEBUG( EHI096, (ErrVal) ret, 0,
                       "hiGetConId () : Unable to unlock sap spConId list \n.");
            RETVALUE(RFAILED);
         }
#endif /* HI_MULTI_THREADED      */
         RETVALUE(ROK);
      }
      id++;
      maxNmbCons--;
   }/* end while */

#ifdef HI_MULTI_THREADED     
   HI_UNLOCK(&sap->spConIdLock, alInfo, ret);
   if (ret != ROK)
      HILOGERROR_DEBUG( EHI097, (ErrVal) ret, 0,
                    "hiGetConId () : Unable to unlock sap spConId list \n.");
#endif /* HI_MULTI_THREADED      */

#if (ERRCLASS & ERRCLS_DEBUG)
   HILOGERROR_DEBUG( EHI098, (ErrVal)id, sap->uiPst.srcInst,
              "hiGetConId(): Failed to obtain connection id");
#endif /* ERRCLS_DEBUG */

   RETVALUE(RFAILED);
}/* end of hiGetConId() */

#ifdef HI_MULTI_THREADED     
  
/*
*
*       Fun:    hiFindConCbBySpConId
*
*       Desc:   Checks if a conCb with the given spConId exists in the 
*               spConId hash list associated with the SAP. The usual 
*               circumstance for this is when one of the receive threads
*               accepts a connection, allocates a spConId and the upper user 
*               responds with a conRsp. The main TUCL thread will call 
*               this function to check if a conCb for this connection exists.
*
*       Ret:    ROK, The conCb pointer points to conCb with spConId == conId
*               RFAILED, No conCb with spConId - conId is found.
*
*       Notes:  None 
*
*       File:   hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiFindConCbBySpConId
(
HiSap *sap,               /* SAP pointer */
HiConCb **conCb,          /* Connection Control Block */
UConnId conId             /* spConId of the block to find */
)
#else
PUBLIC S16 hiFindConCbBySpConId(sap, conCb, conId) 
HiSap *sap;               /* SAP pointer */
HiConCb **conCb;          /* Connection Control Block */
UConnId conId;            /* spConId of the block to find */
#endif
{
   S16          ret;
   HiAlarmInfo  alInfo;

   TRC2(hiFindConCbBySpConId)
   
   alInfo.spId = sap->spId;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   /* Lock the sap spConId hashlist */
   HI_LOCK(&sap->spConIdLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI099, (ErrVal)ret, sap->uiPst.srcInst,
           "hiFindConCbBySpConId(): unable to lock the spConId hash list \n");
      conCb = NULLP;
      RETVALUE(RFAILED);
   }

   /* Find the connection control block in the spConId hashlist */
   ret = cmHashListFind(&sap->spConIdHlCp, (U8 *) &conId, sizeof(UConnId),
                        0, (PTR *) conCb);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI100, (ErrVal)ret, 0,
           "hiFindConCbBySpConId(): hash list find operation failed \n");

      conCb = NULLP;

      HI_UNLOCK(&sap->spConIdLock, alInfo, ret);
      if (ret != ROK)
         HILOGERROR_DEBUG( EHI101, (ErrVal)ret, sap->uiPst.srcInst,
                    "hiFincConCbBySpConId(): Unable to unlock hashlist \n");

      RETVALUE(RFAILED);
   }

   HI_UNLOCK(&sap->spConIdLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG( EHI102, (ErrVal)ret, 0,
                 "hiFincConCbBySpConId(): Unable to unlock hashlist \n");
      conCb = NULLP;
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}/* end of hiGetConCbBySpConId() */
#endif /* HI_MULTI_THREADED */

#ifndef HI_LPBK

/*
*
*       Fun:   hiSetSockOpt 
*
*       Desc:  This function is used to apply socket options
*              as specified in transport parameters 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiSetSockOpt 
(
CmInetFd *sockPtr,         /* socket descriptor */
CmTptParam *tPar           /* transport options */
)
#else
PUBLIC S16 hiSetSockOpt(sockPtr, tPar)
CmInetFd *sockPtr;         /* socket descriptor */
CmTptParam *tPar;          /* transport options */
#endif
{

   Ptr            value;
   U8             i;
   CmInetMCastInf mCastInf;
   S16            ret;
   CmInetIpAddr   lclAddr;

#ifdef HI_REL_1_3  
#ifdef HI_MULTI_THREADED
   HiAlarmInfo    alInfo;
#endif /* HI_MULTI_THREADED */
   Bool           noHdrIncld;
#endif /* HI_REL_1_3 */ 

   TRC2(hiSetSockOpt)

   /* initialisation */
#ifdef HI_REL_1_3  
#ifdef HI_MULTI_THREADED
   alInfo.spId = -1;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
#endif /* HI_MULTI_THREADED */
   noHdrIncld = FALSE;
#endif /* HI_REL_1_3 */ 

   if(tPar->type == CM_TPTPARAM_SOCK)
   {
      /* apply the indicated socket options */
      for (i = 0; i < tPar->u.sockParam.numOpts; i++)
      {
         CmSockOpts *sOpts = &(tPar->u.sockParam.sockOpts[i]);

         /* check if it is a IP multicast option */
         if((sOpts->option == CM_SOCKOPT_OPT_ADD_MCAST_MBR) || 
                   (sOpts->option == CM_SOCKOPT_OPT_DRP_MCAST_MBR))
         {
            /* Get the multicast information required */
#ifdef HI_REL_1_3
            mCastInf.mCastAddr = 
                           sOpts->optVal.mCastInfo.mCastAddr.u.ipv4NetAddr;

            mCastInf.localAddr = 
                           sOpts->optVal.mCastInfo.localAddr.u.ipv4NetAddr;
#else
            mCastInf.mCastAddr = 
                           sOpts->optVal.mCastAddr.u.ipv4NetAddr;

            mCastInf.localAddr = CM_INADDR_ANY;
#endif /* HI_REL_1_3 */
 
            value = (Ptr)&mCastInf;
         }
         else if (sOpts->option == CM_SOCKOPT_OPT_MCAST_IF)
         {
            /* Specifies the local interface for outgoing multicast
             * datagrams 
             */
            lclAddr = sOpts->optVal.lclAddr.u.ipv4NetAddr;
            value = (Ptr)&lclAddr;
         }
#ifdef IPV6_SUPPORTED
         else if((sOpts->option == CM_SOCKOPT_OPT_ADD_MCAST6_MBR) || 
                 (sOpts->option == CM_SOCKOPT_OPT_DRP_MCAST6_MBR))
         {
            value = (Ptr)&sOpts->optVal.mCastInfo6;
         }
         else if (sOpts->option == CM_SOCKOPT_OPT_MCAST6_IF)
         {
            /* hi011.104 - change for MCAST6_IF option */
            value = (Ptr)&sOpts->optVal.infId;
         }
#endif /* IPV6_SUPPORTED */
         else
         {
            value = (Ptr)&sOpts->optVal.value;
         }

         ret = cmInetSetOpt(sockPtr, sOpts->level, sOpts->option, value);
#ifdef HI_REL_1_3  
         if(ret == RNA)
         {
            /* IP header include option not supported */
            noHdrIncld = TRUE;
         }
         else
         {
            if (ret != ROK)
            {
#ifdef HI_MULTI_THREADED
               HI_LOCK(&hiCb.errStsLock, alInfo, ret); 
               if (ret != ROK)
                  HILOGERROR_DEBUG(EHI103, (ErrVal) 0, 0, 
                        "hiSetSockOpt() : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */

               /* increment the statistics counters */
               hiCb.errSts.sockSOptErr++;

#ifdef HI_MULTI_THREADED
               HI_UNLOCK(&hiCb.errStsLock, alInfo, ret);
               if (ret != ROK)
                  HILOGERROR_DEBUG(EHI104, (ErrVal) 0, 0, 
                     "hiSetSockOpt() : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */
               RETVALUE(RFAILED);
            }
         }
#else /* HI_REL_1_3 */ 
         if (ret != ROK)
         {
            /* increment the statistics counters */
            hiCb.errSts.sockSOptErr++;
            RETVALUE(RFAILED);
         }
#endif /* HI_REL_1_3 */ 
      }/* end for loop */
   }/* end if tPar->type */

#ifdef HI_REL_1_3  
   if (noHdrIncld)
      RETVALUE(RNA);
   else
      RETVALUE(ROK);
#else 
      RETVALUE(ROK);
#endif /* HI_REL_1_3 */ 

}/* end of hiSetSockOpt() */
#endif /* HI_LPBK */


/*
*
*       Fun:   hiChkRes
*
*       Desc:  This function is used to check for resource thresholds.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiChkRes
(
HiSap *sap
)
#else
PUBLIC S16 hiChkRes(sap)
HiSap *sap;
#endif
{

   Status      status;
   HiAlarmInfo info;

   /* Initialize alarm info structure */
   info.spId  = sap->spId;
   info.type  = LHI_ALARMINFO_TYPE_NTPRSNT;

   TRC2(hiChkRes)

   /*
      < RED  ><    YELLOW   ><        GREEN            >  
      --------i--------------i-------------i------------
      0    poolDropThr    poolStrtThr   poolStopThr    9

    */
   /* Flags used
    * resCongStrt: This flag is SET once poolStrtThr is hit and is
    *              RESET on poolStopThr
    * resCongDrop: This flag is SET once poolDropThr is hit and is
    *              RESET on poolStopThr
    */

   /* Check for availablity of system resources */
   SChkRes(sap->uiPst.region, sap->uiPst.pool, &status);

   /* SAP was not under resource congestion */
   if(!sap->resCongStrt) /* inside GREEN zone */
   {
      /* hi019.104: relogic the hiChkRes */
      if(status >= hiCb.cfg.poolStrtThr)
         /* Remains inside GREEN zone */
         RETVALUE(ROK);

      /* hi019.104: relogic the hiChkRes */
      else if(status >= hiCb.cfg.poolDropThr)  
      {
         /* Entering YELLOW from GREEN zone */

         /* SET the congestion start flag */
         sap->resCongStrt = TRUE;

         /* Inform the Layer Manager of resource crunch */
         HI_FILL_ALARMINFO_MEM_ID(info, sap->uiPst.region, 
                                  sap->uiPst.pool)
         hiSendAlarm(LCM_CATEGORY_RESOURCE, 
                     LHI_EVENT_RES_CONG_STRT,
                     LCM_CAUSE_UNKNOWN, &info);
         RETVALUE(ROK);
      }
      else
      {
         /* Entering RED from GREEN zone */

         /* SET the congestion flags */
         sap->resCongStrt = TRUE;
         sap->resCongDrop = TRUE;

         /* Inform the Layer Manager of resource crunch */
         HI_FILL_ALARMINFO_MEM_ID(info, sap->uiPst.region, 
                                  sap->uiPst.pool)
         hiSendAlarm(LCM_CATEGORY_RESOURCE, 
                     LHI_EVENT_RES_CONG_DROP,
                     LCM_CAUSE_UNKNOWN, &info);
         RETVALUE(RFAILED);
      }
   }
   else /* SAP already under resource congestion */
   {  
      /* inside YELLOW or RED zone */

      if(!sap->resCongDrop) /* inside YELLOW zone */
      {
         /* hi019.104: relogic the hiChkRes */
         if(status < hiCb.cfg.poolDropThr)
         {
            /* Entering RED from YELLOW zone */

            /* SET the congestion drop flag */
            sap->resCongDrop = TRUE;

            /* Inform the Layer Manager of resource crunch */
            HI_FILL_ALARMINFO_MEM_ID(info, sap->uiPst.region, 
                                     sap->uiPst.pool)
            hiSendAlarm(LCM_CATEGORY_RESOURCE, 
                        LHI_EVENT_RES_CONG_DROP,
                        LCM_CAUSE_UNKNOWN, &info);
            RETVALUE(RFAILED);
         }
         else if(status >= hiCb.cfg.poolStopThr)
         {
            /* Entering GREEN from YELLOW zone */

            /* RESET the congestion flags */
            sap->resCongStrt = FALSE;

            /* Inform the Layer Manager of resource crunch */
            HI_FILL_ALARMINFO_MEM_ID(info, sap->uiPst.region, 
                                     sap->uiPst.pool)
            hiSendAlarm(LCM_CATEGORY_RESOURCE, 
                        LHI_EVENT_RES_CONG_STOP,
                        LCM_CAUSE_UNKNOWN, &info);
            RETVALUE(ROK);
         }
         else /* remains in YELLOW zone */
            RETVALUE(ROK);
      }
      else /* inside RED ZONE */
      {
         if(status >= hiCb.cfg.poolStopThr)
         {
            /* Entering GREEN from RED zone */

            /* RESET the congestion flags */
            sap->resCongStrt = FALSE;
            sap->resCongDrop = FALSE;

            /* Inform the Layer Manager of resource crunch */
            HI_FILL_ALARMINFO_MEM_ID(info, sap->uiPst.region, 
                                     sap->uiPst.pool)
            hiSendAlarm(LCM_CATEGORY_RESOURCE, 
                        LHI_EVENT_RES_CONG_STOP,
                        LCM_CAUSE_UNKNOWN, &info);
            RETVALUE(ROK);
         }
         else
            /* either inside RED or YELLOW zone */
            RETVALUE(RFAILED);
      }
   }
}/* end of hiChkRes() */


/*
*
*       Fun:   hiChkFlwCntrl
*
*       Desc:  This function is used to check the transmit queue size
*              and issue a flow control indication and an alarm if
*              required.
*              "posLen" specifies the number of bytes to be added to
*                       queue size like number of untransmitted bytes
*                       in HiUiHitDatReq
*               "negLen" specifies the number of bytes to be subtracted
*                        from the queue size like the number of bytes
*                        transmitted while checking the pending queues
*                        in hiChkTxQ() function.
*
*       Ret:   Void 
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void hiChkFlwCntrl
(
#ifdef HI_REL_1_3 
HiConCb *conCb,
#else
HiSap *sap,
#endif /* HI_REL_1_3 */
U32   posLen,
U32   negLen
)
#else
#ifdef HI_REL_1_3
PUBLIC Void hiChkFlwCntrl(conCb, posLen, negLen)
HiConCb *conCb;
U32   posLen;
U32   negLen;
#else
PUBLIC Void hiChkFlwCntrl(sap, posLen, negLen)
HiSap *sap;
U32   posLen;
U32   negLen;
#endif /* HI_REL_1_3 */
#endif /* ANSI */
{

   U32 prevQsiz;
   U32 newQsiz;
   HiAlarmInfo info;
   U8  flc;
#ifdef HI_REL_1_3
   HiSap *sap;
#endif /* HI_REL_1_3 */

   TRC2(hiChkFlwCntrl)

#ifdef HI_REL_1_3
   sap = conCb->sap;
   prevQsiz = conCb->txQSiz;
   flc = conCb->flcIssued;
#else
   prevQsiz = sap->currTxQSiz;
   flc = sap->flcIssued;
#endif /* HI_REL_1_3 */

   newQsiz = prevQsiz + posLen - negLen;

   info.spId = sap->spId;
   info.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   /* Changed the logic of generating flow control indications */
   if(newQsiz > sap->cfg.txqCongStrtLim)
   {
      if (newQsiz > sap->cfg.txqCongDropLim)
      {
         if (!(flc & HI_SENT_FLC_DROP))
         {
            /* if drop indication is not sent send it now */
            flc |= HI_SENT_FLC_DROP;
#ifdef HI_REL_1_3
            conCb->flcIssued = flc;
            HI_FLW_CNTRL(conCb, HI_FLC_DROP, LHI_EVENT_TXQ_CONG_DATA_DROP, 
                         &info);
#else
            sap->flcIssued = flc;
            HI_FLW_CNTRL(sap, HI_FLC_DROP, LHI_EVENT_TXQ_CONG_DATA_DROP, 
                         &info);
#endif /* HI_REL_1_3 */
         }
      }
      else 
      {
         /* queue size is between start and drop limits */
         if (!(flc & HI_SENT_FLC_STRT))
         {
            flc |= HI_SENT_FLC_STRT;
#ifdef HI_REL_1_3
            HI_FLW_CNTRL(conCb, HI_FLC_STRT, LHI_EVENT_TXQ_CONG_ON, 
                         &info);
            conCb->flcIssued = flc;
#else
            HI_FLW_CNTRL(sap, HI_FLC_STRT, LHI_EVENT_TXQ_CONG_ON, 
                         &info);
            sap->flcIssued = flc;
#endif /* HI_REL_1_3 */
         }
      }
   }/* end if */
   else if (newQsiz < sap->cfg.txqCongStopLim)
   {
      if ((flc & HI_SENT_FLC_STRT) || (flc & HI_SENT_FLC_DROP))
      {
#ifdef HI_REL_1_3
         HI_FLW_CNTRL(conCb, HI_FLC_STOP, LHI_EVENT_TXQ_CONG_OFF, 
                      &info);
         conCb->flcIssued = 0;
#else
         HI_FLW_CNTRL(sap, HI_FLC_STOP, LHI_EVENT_TXQ_CONG_OFF, 
                      &info);
         sap->flcIssued = 0;
#endif /* HI_REL_1_3 */
      }
   }

   RETVOID;
}/* end of hiChkFlwCntrl() */


/* ------------------------------------------------------------------*/
/* Management Interface Support Functions
 */


/*
*
*       Fun:   hiSendAlarm 
*
*       Desc:  This function is used to send unsolicited Status
*              Indications to the Layer Manager
*
*       Ret:   Void
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void hiSendAlarm
(
U16             cgy,            /* alarm category */
U16             evnt,           /* event */
U16             cause,          /* cause for alarm */
HiAlarmInfo     *info           /* alarm information */
)
#else
PUBLIC Void hiSendAlarm(cgy, evnt, cause, info)
U16             cgy;            /* alarm category */
U16             evnt;           /* event */
U16             cause;          /* cause for alarm */
HiAlarmInfo     *info;          /* alarm information */ 
#endif
{

   HiMngmt  sm;   /* Management structure */
   
   TRC2(hiSendAlarm)

   /* hi009.104 - added check for rolling upgrade. Return VOID when 
    * the general config is NOT done */
   if (hiCb.hiInit.cfgDone == FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      HILOGERROR_DEBUG(EHIXXX, (ErrVal) 0, 0,
                    "hiSendAlarm() : General Config not done");
#endif /* ERRCLS_DEBUG */      
      RETVOID;
   }

   /* hi009.104 - added check */
   if(hiCb.hiInit.usta)
   {
      /* zero out the management structure */
      HI_ZERO(&sm, sizeof(HiMngmt));
 
      /* copy the entire header structure */
      sm.hdr.elmId.elmnt        = TUSTA;
      sm.hdr.elmId.elmntInst1   = HI_UNUSED;
      sm.hdr.elmId.elmntInst2   = HI_UNUSED;
      sm.hdr.elmId.elmntInst3   = HI_UNUSED;
 
      /* fill in the event and category */
      sm.t.usta.alarm.category  = cgy;
      sm.t.usta.alarm.event     = evnt;
      sm.t.usta.alarm.cause     = cause;
 
      /* fill in the alarm specific information */
      cmMemcpy((U8*)&sm.t.usta.info, (U8*)info, sizeof(HiAlarmInfo)); 
 
      /* update the date and time */
      (Void) SGetDateTime(&sm.t.usta.alarm.dt);

      HiMiLhiStaInd(&(hiCb.hiInit.lmPst), &sm);
   }
   RETVOID;
}/* end of hiSendAlarm() */


/*
*
*      Fun:   hiSendLmCfm
*
*      Desc:  This function sends configuration, control, statistics,
*             and status confirms to layer management
*
*      Ret:   Void 
*
*      Notes: None
*
*      File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void hiSendLmCfm
(
Pst     *pst,                   /* post */
U8      cfmType,                /* confirm type */
Header  *hdr,                   /* header */
U16     status,                 /* confirm status */
U16     reason,                 /* failure reason */
HiMngmt *cfm                    /* management structure */
)
#else
PUBLIC Void hiSendLmCfm(pst, cfmType, hdr, status, reason, cfm)
Pst     *pst;                   /* post */
U8      cfmType;                /* confirm type */
Header  *hdr;                   /* header */
U16     status;                 /* confirm status */
U16     reason;                 /* failure reason */
HiMngmt *cfm;                   /* management structure */
#endif
{

   Pst   cfmPst;                /* Post structure for confimation */

   TRC2(hiSendLmCfm)

   /* hi009.104 - Insure fix */
   HI_ZERO(&cfmPst, sizeof(Pst));
   
   /* Fill up the header in the confirm structure */
   cfm->hdr.elmId.elmnt = hdr->elmId.elmnt;
   cfm->hdr.transId     = hdr->transId;

   cfm->cfm.status = status;
   cfm->cfm.reason = reason;

    /* Fill up the post struct for comfirm */
   cfmPst.srcEnt        = hiCb.hiInit.ent;
#ifdef HI_MULTI_THREADED
   cfmPst.srcInst       = 0;
#else
   cfmPst.srcInst       = hiCb.hiInit.inst;
#endif /* HI_MULTI_THREADED */
   cfmPst.srcProcId     = hiCb.hiInit.procId;
   cfmPst.dstEnt        = pst->srcEnt;
   cfmPst.dstInst       = pst->srcInst;
   cfmPst.dstProcId     = pst->srcProcId;
   cfmPst.selector      = hdr->response.selector;
   cfmPst.prior         = hdr->response.prior;
   cfmPst.route         = hdr->response.route;
   cfmPst.region        = hdr->response.mem.region;
   cfmPst.pool          = hdr->response.mem.pool;

   /* hi009.104 - added to fill remote interface version */
#ifdef HI_RUG
   /* fill up the remote interface version */
   cfmPst.intfVer = pst->intfVer;
#endif
 
   switch(cfmType)
   {
      case TCFG:
         /* send configuration confirm */
         HiMiLhiCfgCfm(&cfmPst, cfm);
         break;

      case TSTS:
         /* send Statistics confirm */
         HiMiLhiStsCfm(&cfmPst, cfm);
         break;

      case TCNTRL:
         /* send control confirm */
         HiMiLhiCntrlCfm(&cfmPst, cfm);
         break;
 
      case TSSTA:
         /* send solicited status confirm */
         HiMiLhiStaCfm(&cfmPst, cfm);
         break;
 
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         HILOGERROR_DEBUG(EHI105, (ErrVal)cfmType, 0,
                    "hiSendLmCfm(): unknown parameter cfmType passed");
#endif /* ERRCLS_DEBUG */        
         RETVOID;
   } /* end of switch statement */

   RETVOID;
}/* end of hiSendLmCfm() */


/*
*
*       Fun:   hiCfgGen
*
*       Desc:  This function is used for the general configuration 
*              of the TCP UDP Convergence Layer. 
*              General configuration must be done before any other 
*              configuration or no operation can be done in TCP UDP 
*              Convergence Layer, and after TCP UDP Convergence Layer 
*              has been initialized (using hiActvInit). It configures 
*              the maximums in TCP UDP Convergence Layer, using which 
*              TUCL makes a reservation of static memory (using SGetSMem). 
*              TUCL also allocates any memory needed immediately, such 
*              as SAP lists (using SGetSBuf). This configuration also 
*              provides the period for timer activations.TUCL  may be 
*              tightly or loosely coupled with layer Manager. Common 
*              Socket Library is initialized and a common UDP socket 
*              is opened.
*
*              In non-multithreaded casese a permanent task must 
*              be registered with system services. If the user wants he can
*              configure TUCL to poll for data using a timer function.
*
*              In case multi-threaded TUCL multiple receive threads are 
*              spawned here.
*
*       Ret:   Failure:           LCM_REASON_RECONFIG_FAIL
*                                 LCM_REASON_MEM_NOAVAIL
*                                 LCM_REASON_REGTMR_FAIL
*                                 LHI_REASON_SOCKLIB_INIT_FAIL
*                                 LHI_REASON_SOCK_FAIL
*
*                                 For multithreaded related errors -
*
*                                 LHI_REASON_LOCK_INIT_FAIL 
*                                 LHI_REASON_INST0_NTREG
*
*              Success:           LCM_REASON_NOT_APPL
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiCfgGen
(
HiGenCfg    *hiGen      /* pointer to general configuration */
)
#else
PUBLIC S16 hiCfgGen(hiGen)
HiGenCfg    *hiGen;     /* pointer to general configuration */
#endif
{

   U16       i;
   Size      sMemSize;
   S32       sockLibMemSize;
   S16       ret;
   Size      fdBlkSize;
   Bool      fdGrpInitDone;

   TRC2(hiCfgGen);

   sockLibMemSize = 0;
   fdBlkSize = 0;
   fdGrpInitDone = FALSE;

   /* TUCL instance 0 has to be registered */
#ifdef HI_MULTI_THREADED
   if (!hiCb.zeroInstReg)
      RETVALUE(LHI_REASON_INST0_NTREG);
#endif /* HI_MULTI_THREADED */

   /* hi009.104 - added validation of interface version number in lmPst */
#ifdef HI_RUG
   if (hiGen->lmPst.intfVer > LHIIFVER)
   {
      RETVALUE(LCM_REASON_VERSION_MISMATCH);
   }
#endif /* HI_RUG */            
   
   /* check if general configuration was done */ 
   if(hiCb.cfgDone == TRUE)
   {
      /* general reconfiguration not permitted */
      RETVALUE(LCM_REASON_RECONFIG_FAIL);
   }

   cmMemset((U8 *)&hiCb.cfg, 0, sizeof(HiGenCfg));

   /* copy the general configuration */
   cmMemcpy((U8 *) &hiCb.cfg, (U8 *) hiGen, sizeof(HiGenCfg));

#ifdef HI_REL_1_2 /* Flag to ensure backward compatability */
   hiCb.numFdsPerSet = hiGen->numFdsPerSet;
   hiCb.numFdBins    = hiGen->numFdBins; 
#else
   /* For release 1.1 set these parameters to default values */
   hiCb.numFdsPerSet = LHI_NUM_FDS_PER_SET;
   hiCb.numFdBins    = LHI_NUM_FD_BINS;
#endif /* HI_REL_1_2 */

   hiCb.numFdGrps = (hiCb.cfg.numCons/hiCb.numFdsPerSet);
   
   if (hiCb.cfg.numCons % hiCb.numFdsPerSet)
      hiCb.numFdGrps += 1; 

   /* compute memory necessary to run */
   sMemSize = ((hiCb.cfg.numSaps * (sizeof(HiSap) + sizeof(PTR))) + 
              (hiCb.cfg.numCons * (sizeof(HiConCb))));
 
   /* calculate the worst case memory required for hash list bins */

   /* There is one sap hashlist in the sap */
   sMemSize += (hiCb.cfg.numCons * CM_HASH_BINSIZE);
   
#ifdef HI_LPBK

   /* memory required for hash list on local transport address and for
    * the multicast group membership connection blocks. For each
    * membership a connection block is required.
    */
   sMemSize += (HI_LPBK_NUM_ADDRLST_BINS * CM_HASH_BINSIZE) +
               (sizeof(HiConCb) * HI_LPBK_NUM_MCAST_MBR);
#else
   /* add memory requirement for ICMP hash list */
   sMemSize += hiCb.cfg.numCons * CM_HASH_BINSIZE;

#ifdef IPV6_SUPPORTED 
   /* add memory requirement for ICMP V6 hash list */
   sMemSize += hiCb.cfg.numCons * CM_HASH_BINSIZE;
#endif /* IPV6_SUPPORTED */

   /* calculate the memory required by the socket library */
   (Void) cmInetGetMemSize(&sockLibMemSize);
   sMemSize += sockLibMemSize;
#endif /* HI_LPBK */

   /* memory required by the file descriptor blocks. For each file 
    * descriptor block there will be 2 hash lists with number of bins
    * equal to that specified in hiCb.numFdBins. 
    */
   fdBlkSize += (hiCb.numFdGrps * (sizeof(HiFdGrpInfo) + sizeof(PTR)));

   sMemSize  += fdBlkSize;

   /* Memory for read fd hash list */
   sMemSize  += (hiCb.numFdGrps * (hiCb.numFdsPerSet * CM_HASH_BINSIZE)); 

   /* Memory for write fd hash list */
   sMemSize  += (hiCb.numFdGrps * (hiCb.numFdsPerSet * CM_HASH_BINSIZE)); 

#ifdef HI_FAST_FIND
   /* Add memory needed for fdSetInfo. There is one per fd group */
   sMemSize += (hiCb.numFdGrps * sizeof(CmInetFdSetInfo));
#endif /* HI_FAST_FIND */

#ifdef HI_MULTI_THREADED     
   /* There is a spConId hash list maintained incase of multithreaded
    * case */
   sMemSize += (hiCb.cfg.numCons * CM_HASH_BINSIZE);
#endif /* HI_MULTI_THREADED      */

   /* hi009.104 - added to include memory required for version info */
#ifdef HI_RUG
   sMemSize += hiCb.cfg.numSaps * sizeof(ShtVerInfo);
#endif /* HI_RUG */
   
   HIDBGP(DBGMASK_SI, (hiCb.hiInit.prntBuf,
          "SGetSMem(region(%d), size(%ld), &pool(%p))\n",
           hiCb.hiInit.region, sMemSize, &hiCb.hiInit.pool));

   /* reserve the memory */
   ret = SGetSMem(hiCb.hiInit.region, (Size) sMemSize,
                  &hiCb.hiInit.pool);
   if(ret != ROK)
      RETVALUE(LCM_REASON_MEM_NOAVAIL);

#ifdef HI_RUG
   /* hi009.104 - addition - allocate Memory to Interface version info list */
   hiCb.numIntfInfo = 0;
   HI_ALLOC((hiCb.cfg.numSaps * sizeof(ShtVerInfo)), hiCb.intfInfo);
   if(!hiCb.intfInfo)
   {
      HI_FREE((hiCb.cfg.numSaps * sizeof(ShtVerInfo)), hiCb.intfInfo);
      (Void) SPutSMem(hiCb.hiInit.region, hiCb.hiInit.pool);
      RETVALUE(LCM_REASON_MEM_NOAVAIL);
   }         
#endif /* HI_RUG */
            
   /* allocate the SAP list */
 
   HI_ALLOC((hiGen->numSaps * sizeof(PTR)), hiCb.sapLstPtr)
   if(!hiCb.sapLstPtr)
   {
      (Void) SPutSMem(hiCb.hiInit.region, hiCb.hiInit.pool);
      RETVALUE(LCM_REASON_MEM_NOAVAIL);
   }
 
   /* initialize SAP list */
   for (i = 0; i < (U32) hiCb.cfg.numSaps; i++)
     *(hiCb.sapLstPtr + i) = NULLP;
 
   /* initialize layer manager post structure */
   cmMemcpy((U8 *)&hiCb.hiInit.lmPst, (U8 *) &hiGen->lmPst, sizeof(Pst));
 
   /* update the source processor id, entity and instance */
   hiCb.hiInit.lmPst.srcProcId = hiCb.hiInit.procId;
   hiCb.hiInit.lmPst.srcEnt    = hiCb.hiInit.ent;
   hiCb.hiInit.lmPst.srcInst   = hiCb.hiInit.inst;
   hiCb.hiInit.lmPst.event     = EVTNONE;

   /* hi009.104 - initialize LM interface version number in lmPst */
#ifdef HI_RUG         
   hiCb.hiInit.lmPst.intfVer = hiGen->lmPst.intfVer;
#endif /* HI_RUG */            
   
   /* Initialize the socket library and open the common UDP socket */
   /* Moved the socket library initialisation here */
   ret = hiSockInit();
   if(ret != LCM_REASON_NOT_APPL)
   {
      HI_FREE((hiGen->numSaps * sizeof(PTR)), hiCb.sapLstPtr)
      (Void) SPutSMem(hiCb.hiInit.region,  hiCb.hiInit.pool);
      RETVALUE(ret);
   }

#ifdef HI_LPBK

   /* initialise the connection block tpt addr hash list  */
   /* hi024.104: Reverting keytype to DEF */
#ifdef HI_REL_1_3  
   ret = cmHashListInit(&hiCb.locAddrHlCp,      /* connections */
                        HI_LPBK_NUM_ADDRLST_BINS,/* bins */
                        (sizeof(CmLList) +
                         sizeof(CmHashListEnt) +
                         sizeof(CmHashListEnt) +
                         sizeof(CmHashListEnt)),/* offset of HL Entry */
                        TRUE,                   /* Allow dup. keys ? */
                        CM_HASH_KEYTYPE_DEF, /* HL key type */
                        hiCb.hiInit.region,     /* Mem region for HL */
                        hiCb.hiInit.pool);      /* Mem pool for HL */

#else /* HI_REL_1_3 */ 
   ret = cmHashListInit(&hiCb.locAddrHlCp,      /* connections */
                        HI_LPBK_NUM_ADDRLST_BINS,/* bins */
                        (sizeof(CmLList) +
                         sizeof(CmHashListEnt) +
                         sizeof(CmHashListEnt)),/* offset of HL Entry */
                        TRUE,                   /* Allow dup. keys ? */
                        CM_HASH_KEYTYPE_DEF, /* HL key type */
                        hiCb.hiInit.region,     /* Mem region for HL */
                        hiCb.hiInit.pool);      /* Mem pool for HL */
#endif /* HI_REL_1_3 */ 

   if(ret != ROK)
   {
      HI_SOCK_DEINIT();
      (Void) SPutSMem(hiCb.hiInit.region, hiCb.hiInit.pool);
      RETVALUE(LCM_REASON_MEM_NOAVAIL);
   }

   /* Deregister the permanent task registered in tst() */
#ifndef HI_CMPTBL_FLAG 
#ifdef SS_MULTIPLE_PROCS       
   SDeregTTsk ((ProcId)hiCb.hiInit.procId, (Ent)hiCb.hiInit.ent, (Inst)(hiCb.hiInit.inst + 1));
   SDetachTTsk((ProcId)hiCb.hiInit.procId, (Ent)hiCb.hiInit.ent, (Inst)(hiCb.hiInit.inst + 1));
#else /* SS_MULTIPLE_PROCS */      
   SDeregTTsk ((Ent)hiCb.hiInit.ent, (Inst)(hiCb.hiInit.inst + 1));
   SDetachTTsk((Ent)hiCb.hiInit.ent, (Inst)(hiCb.hiInit.inst + 1));
#endif /* SS_MULTIPLE_PROCS */      
#endif /* HI_CMPTBL_FLAG */

   /* set the general configuration done flag */
   hiCb.cfgDone = TRUE;
#else  /* HI_LPBK */

   /* Allocate memory for fd group pointers */ 
   HI_ALLOC((hiCb.numFdGrps * sizeof(PTR)), hiCb.hiFdGrpInfoLstPtr)
   if(!hiCb.hiFdGrpInfoLstPtr)
   {
      /* Free the SAP list */
      HI_SOCK_DEINIT();
      HI_FREE((hiGen->numSaps * sizeof(PTR)), hiCb.sapLstPtr);
      (Void) SPutSMem(hiCb.hiInit.region, hiCb.hiInit.pool);
      RETVALUE(LCM_REASON_MEM_NOAVAIL);
   }

   for (i = 0; i < hiCb.numFdGrps; i++)
      *(hiCb.hiFdGrpInfoLstPtr + i) = NULLP;

#ifdef HI_MULTI_THREADED
   /* Initialise all locks here. The locks used are -
    * a) The group lock, 
    * b) The ICMP V4 lock and 
    * c) The ICMP v6 lock
    */
   ret = SInitLock(&hiCb.grpLock, SS_LOCK_MUTEX);
   if (ret != ROK)
   {
      HI_SOCK_DEINIT();
      HI_FREE((hiGen->numSaps * sizeof(PTR)), hiCb.sapLstPtr);
      HI_FREE((hiCb.numFdGrps * sizeof(PTR)), hiCb.hiFdGrpInfoLstPtr);
      (Void) SPutSMem(hiCb.hiInit.region, hiCb.hiInit.pool);
      RETVALUE(LHI_REASON_LOCK_INIT_FAILED);
   }

   ret = SInitLock(&hiCb.icmpHlLock, SS_LOCK_MUTEX);
   if (ret != ROK)
   {
      HI_SOCK_DEINIT();
      SDestroyLock(&hiCb.grpLock);
      HI_FREE((hiGen->numSaps * sizeof(PTR)), hiCb.sapLstPtr);
      HI_FREE((hiCb.numFdGrps * sizeof(PTR)), hiCb.hiFdGrpInfoLstPtr);
      (Void) SPutSMem(hiCb.hiInit.region, hiCb.hiInit.pool);
      RETVALUE(LHI_REASON_LOCK_INIT_FAILED);
   }

   ret = SInitLock(&hiCb.errStsLock, SS_LOCK_MUTEX);
   if (ret != ROK)
   {
      HI_SOCK_DEINIT();
      SDestroyLock(&hiCb.grpLock);
      SDestroyLock(&hiCb.icmpHlLock);
      HI_FREE((hiGen->numSaps * sizeof(PTR)), hiCb.sapLstPtr);
      HI_FREE((hiCb.numFdGrps * sizeof(PTR)), hiCb.hiFdGrpInfoLstPtr);
      (Void) SPutSMem(hiCb.hiInit.region, hiCb.hiInit.pool);
      RETVALUE(LHI_REASON_LOCK_INIT_FAILED);
   }

#ifdef IPV6_SUPPORTED 
   ret = SInitLock(&hiCb.icmp6HlLock, SS_LOCK_MUTEX);
   if (ret != ROK)
   {
      HI_SOCK_DEINIT();
      SDestroyLock(&hiCb.grpLock);
      SDestroyLock(&hiCb.icmpHlLock);
      SDestroyLock(&hiCb.errStsLock);
      HI_FREE((hiGen->numSaps * sizeof(PTR)), hiCb.sapLstPtr);
      HI_FREE((hiCb.numFdGrps * sizeof(PTR)), hiCb.hiFdGrpInfoLstPtr);
      (Void) SPutSMem(hiCb.hiInit.region, hiCb.hiInit.pool);
      RETVALUE(LHI_REASON_LOCK_INIT_FAILED);
   }
#endif /* IPV6_SUPPORTED */
#endif /* HI_MULTI_THREADED */

   fdGrpInitDone = TRUE;

   /* Allocate memory for each file descriptor pointer and initialise the
    * fd group array */
   for (i = 0; i < hiCb.numFdGrps; i++)
   {
      HI_ALLOC(sizeof(HiFdGrpInfo), (hiCb.hiFdGrpInfoLstPtr[i]))
      if (!hiCb.hiFdGrpInfoLstPtr[i])
      {
         fdGrpInitDone = FALSE;
         ret = LCM_REASON_MEM_NOAVAIL;
         break;
      }

      /* Initilise the file descriptor group */
      ret = hiInitFdGrp(hiCb.hiFdGrpInfoLstPtr[i], i);
      if (ret != ROK)
      {
         HI_FREE(sizeof(HiFdGrpInfo), hiCb.hiFdGrpInfoLstPtr[i]);
         fdGrpInitDone = FALSE;
         ret = LCM_REASON_MEM_NOAVAIL;
         break;
      }
   }

   /* Check if all fd Grps have been initialised */
   if (!fdGrpInitDone)
   {
      if (i)
         i --;

      /* Go from i to 0 and deallocate all the fdGrps */
      for (; i > 0; i--)
      {
         hiDeInitFdGrp(hiCb.hiFdGrpInfoLstPtr[i]);
         HI_FREE(sizeof(HiFdGrpInfo), hiCb.hiFdGrpInfoLstPtr[i]);
      }

      hiDeInitFdGrp(hiCb.hiFdGrpInfoLstPtr[0]);
      HI_FREE(sizeof(HiFdGrpInfo), hiCb.hiFdGrpInfoLstPtr[0]);

#ifdef HI_MULTI_THREADED 
      SDestroyLock(&hiCb.grpLock);
      SDestroyLock(&hiCb.icmpHlLock);
      SDestroyLock(&hiCb.errStsLock);
#ifdef IPV6_SUPPORTED
      SDestroyLock(&hiCb.icmp6HlLock);
#endif /* IPV6_SUPPORTED */
#endif /* HI_MULTI_THREADED */

      /* Free the SAP list */
      HI_FREE((hiGen->numSaps * sizeof(PTR)), hiCb.sapLstPtr);
      HI_FREE((hiCb.numFdGrps * sizeof(PTR)), hiCb.hiFdGrpInfoLstPtr);
      HI_SOCK_DEINIT();
      (Void) SPutSMem(hiCb.hiInit.region, hiCb.hiInit.pool);
      RETVALUE(ret);
   }

   /* set the general configuration done flag */
   hiCb.cfgDone = TRUE;

   /* Check if the layer should be scheduled through a timer or through
    * a permanent task */
   /* There is no timer mode when multiple receive threads are used.
    * This general configuration parameter is ignored. This is kept for
    * backward compatibility purposes.
    */
#ifndef HI_MULTI_THREADED      
   /* Initialize the timing queue */
   hiCb.hiTqCp.tmrLen = HIQNUMENT;

   if(hiCb.cfg.permTsk == FALSE)
   {
#ifdef SS_MULTIPLE_PROCS
      HIDBGP(DBGMASK_SI, (hiCb.hiInit.prntBuf,
             "SRegTmr(procid(%d), entity(%d), inst(%d), period(%d), tmrFunc(%p))\n",
              hiCb.hiInit.procId, hiCb.hiInit.ent, hiCb.hiInit.inst, hiCb.cfg.schdTmrVal, 
              hiActvTmr));
      /* Register the timer function */
      ret = SRegTmr(hiCb.hiInit.procId, hiCb.hiInit.ent, hiCb.hiInit.inst, 
                    hiCb.cfg.schdTmrVal, hiActvTmr);
#else /* SS_MULTIPLE_PROCS */      
      HIDBGP(DBGMASK_SI, (hiCb.hiInit.prntBuf,
             "SRegTmr(entity(%d), inst(%d), period(%d), tmrFunc(%p))\n",
              hiCb.hiInit.ent, hiCb.hiInit.inst, hiCb.cfg.schdTmrVal, 
              hiActvTmr));
      /* Register the timer function */
      ret = SRegTmr(hiCb.hiInit.ent, hiCb.hiInit.inst, 
                    hiCb.cfg.schdTmrVal, hiActvTmr);
#endif /* SS_MULTIPLE_PROCS */      
      if (ret != ROK)
      {
#ifdef HI_RUG         
         /* hi009.104 - deallocate static buffer allocated for version info */  
         HI_FREE((hiCb.cfg.numSaps * sizeof(ShtVerInfo)), hiCb.intfInfo);
#endif /* HI_RUG */
         
         /* Free the SAP list */
         HI_FREE((hiGen->numSaps * sizeof(PTR)), hiCb.sapLstPtr)
         for(i = 0; i < hiCb.numFdGrps; i++)
         {
            hiDeInitFdGrp(hiCb.hiFdGrpInfoLstPtr[i]);
            HI_FREE(sizeof(HiFdGrpInfo), hiCb.hiFdGrpInfoLstPtr[i]);
         }
         HI_FREE((hiGen->numSaps * sizeof(PTR)), hiCb.sapLstPtr);
         HI_FREE((hiCb.numFdGrps * sizeof(PTR)), hiCb.hiFdGrpInfoLstPtr);
         HI_SOCK_DEINIT();
         (Void) SPutSMem(hiCb.hiInit.region,  hiCb.hiInit.pool);
         RETVALUE(LCM_REASON_REGTMR_FAIL);
      }

      /* Initialize the timer structure in the control block */
      cmInitTimers(hiCb.timers, 1);

      HI_START_TMR(HI_TMR_SCHD, 1);

#ifndef HI_CMPTBL_FLAG 
#ifdef SS_MULTIPLE_PROCS       
      /* Deregister the permanent task registered in tst() */
      SDeregTTsk ((ProcId)hiCb.hiInit.procId, (Ent)hiCb.hiInit.ent, (Inst)(hiCb.hiInit.inst + 1));
      SDetachTTsk((ProcId)hiCb.hiInit.procId, (Ent)hiCb.hiInit.ent, (Inst)(hiCb.hiInit.inst + 1));
#else /* SS_MULTIPLE_PROCS */      
      SDeregTTsk ((Ent)hiCb.hiInit.ent, (Inst)(hiCb.hiInit.inst + 1));
      SDetachTTsk((Ent)hiCb.hiInit.ent, (Inst)(hiCb.hiInit.inst + 1));
#endif /* SS_MULTIPLE_PROCS */      
#endif /* HI_CMPTBL_FLAG */
   }

#ifdef HI_CMPTBL_FLAG 
   /* Compatability flag for older service user implementations */
   /* Old service users are those that still use MOS!! or those that
    * do not register the permanent task. */
   else
   {
      /* Register the permanent task for TUCL */
      SRegActvTsk((Ent)(hiCb.hiInit.ent), 
                  (Inst)(hiCb.hiInit.inst + 1), (Ttype)TTPERM, 
                  (Prior)PRIOR0, (ActvTsk)hiScanPermTsk);
   }/* end else */
#endif /* HI_CMPTBL_FLAG */
#endif /* HI_MULTI_THREADED      */

#endif /* HI_LPBK */

#ifdef HI_REL_1_3  
   
   /* initialise the connection block tpt addr hash list  */
   /* hi022.104: Changing keytype from DEF to U32 */
   ret = cmHashListInit(&hiCb.icmpHlCp,      /* connections */
                        hiCb.numFdBins,      /* bins */
                        HI_GET_OFFSET(HiConCb, icmpHlEnt),
                        TRUE,                   /* Allow dup. keys ? */
                        CM_HASH_KEYTYPE_U32MOD, /* HL key type */
                        hiCb.hiInit.region,     /* Mem region for HL */
                        hiCb.hiInit.pool);      /* Mem pool for HL */
   if(ret != ROK)
   {
      /* Free the SAP list */
      HI_FREE((hiGen->numSaps * sizeof(PTR)), hiCb.sapLstPtr)
#ifndef HI_LPBK
      for(i = 0; i < hiCb.numFdGrps; i++)
      {
         hiDeInitFdGrp(hiCb.hiFdGrpInfoLstPtr[i]);
         HI_FREE(sizeof(HiFdGrpInfo), hiCb.hiFdGrpInfoLstPtr[i]);
      }
#ifdef HI_MULTI_THREADED 
      SDestroyLock(&hiCb.grpLock);
      SDestroyLock(&hiCb.icmpHlLock);
      SDestroyLock(&hiCb.errStsLock);
#ifdef IPV6_SUPPORTED
      SDestroyLock(&hiCb.icmp6HlLock);
#endif /* IPV6_SUPPORTED */
#endif /* HI_MULTI_THREADED */
      HI_FREE((hiGen->numSaps * sizeof(PTR)), hiCb.sapLstPtr);
      HI_FREE((hiCb.numFdGrps * sizeof(PTR)), hiCb.hiFdGrpInfoLstPtr);
#endif /* HI_LPBK */
      HI_SOCK_DEINIT();
      (Void) SPutSMem(hiCb.hiInit.region, hiCb.hiInit.pool);
      RETVALUE(LCM_REASON_MEM_NOAVAIL);
   }
   hiCb.icmpUsers = 0;

#ifdef IPV6_SUPPORTED
   /* initialise the connection block tpt addr hash list  */
   /* hi022.104: Changing keytype from DEF to U32 */
   ret = cmHashListInit(&hiCb.icmp6HlCp,      /* connections */
                        hiCb.numFdBins,      /* bins */
                        HI_GET_OFFSET(HiConCb, icmpHlEnt),
                        TRUE,                   /* Allow dup. keys ? */
                        CM_HASH_KEYTYPE_U32MOD, /* HL key type */
                        hiCb.hiInit.region,     /* Mem region for HL */
                        hiCb.hiInit.pool);      /* Mem pool for HL */
   if(ret != ROK)
   {
      /* Free the SAP list */
      HI_FREE((hiGen->numSaps * sizeof(PTR)), hiCb.sapLstPtr)
#ifndef HI_LPBK
      for(i = 0; i < hiCb.numFdGrps; i++)
      {
         hiDeInitFdGrp(hiCb.hiFdGrpInfoLstPtr[i]);
         HI_FREE(sizeof(HiFdGrpInfo), hiCb.hiFdGrpInfoLstPtr[i]);
      }
#ifdef HI_MULTI_THREADED 
      SDestroyLock(&hiCb.grpLock);
      SDestroyLock(&hiCb.icmpHlLock);
      SDestroyLock(&hiCb.errStsLock);
      SDestroyLock(&hiCb.icmp6HlLock);
#endif /* HI_MULTI_THREADED */
      cmHashListDeinit(&hiCb.icmpHlCp);
      HI_FREE((hiGen->numSaps * sizeof(PTR)), hiCb.sapLstPtr);
      HI_FREE((hiCb.numFdGrps * sizeof(PTR)), hiCb.hiFdGrpInfoLstPtr);
#endif /* HI_LPBK */
      HI_SOCK_DEINIT();
      (Void) SPutSMem(hiCb.hiInit.region, hiCb.hiInit.pool);
      RETVALUE(LCM_REASON_MEM_NOAVAIL);
   }
   hiCb.icmp6Users = 0;
#endif /* IPV6_SUPPORTED */
#endif /* HI_REL_1_3 */ 

#ifdef HI_MULTI_THREADED     
   /* Register all TAPA tasks, create new system threads and attach
    * TAPA tasks to the respective system threads and finally send a 
    * message to all the threads 
    */
   if (hiSpawnRecvTasks() != ROK)
   {
      for (i = 0; i < hiCb.numFdGrps; i++)
      {
         hiDeInitFdGrp(hiCb.hiFdGrpInfoLstPtr[i]);
         HI_FREE(sizeof(HiFdGrpInfo), hiCb.hiFdGrpInfoLstPtr[i]);
      }
      cmHashListDeinit(&hiCb.icmpHlCp);
      /* Free the SAP list */
      HI_SOCK_DEINIT();
      SDestroyLock(&hiCb.grpLock);
      SDestroyLock(&hiCb.icmpHlLock);
      SDestroyLock(&hiCb.errStsLock);
#ifdef IPV6_SUPPORTED
      SDestroyLock(&hiCb.icmp6HlLock);
      cmHashListDeinit(&hiCb.icmp6HlCp);
#endif /* IPV6_SUPPORTED */
      HI_FREE((hiGen->numSaps * sizeof(PTR)), hiCb.sapLstPtr);
      HI_FREE((hiCb.numFdGrps * sizeof(PTR)), hiCb.hiFdGrpInfoLstPtr);
      (Void) SPutSMem(hiCb.hiInit.region, hiCb.hiInit.pool);
      RETVALUE(LHI_REASON_CREATE_RECVTSKS_FAILED);
   }
#endif /* HI_MULTI_THREADED      */

   /* hi009.104 - added */
   hiCb.hiInit.cfgDone = TRUE;
      
   RETVALUE(LCM_REASON_NOT_APPL);
}/* end of hiCfgGen() */


/*
*
*       Fun:    hiCfgSap 
*
*       Desc:   This function is used for TUCL SAP configuration.
*               SAP configuration can be used to allocate and configure 
*               a new SAP, or to reconfigure an existing SAP. SAPs can 
*               be configured at any time after general configuration. 
*
*       Ret:    Failure:         LCM_REASON_GENCFG_NOT_DONE 
*                                LCM_REASON_INVALID_SAP
*                                LCM_REASON_RECONFIG_FAIL
*
*               Success:         LCM_REASON_NOT_APPL
*
*       Notes:  None 
*
*       File:   hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16   hiCfgSap
(
HiSapCfg *cfg           /* pointer to sap configuration structure */
)
#else
PUBLIC S16   hiCfgSap(cfg) 
HiSapCfg *cfg;          /* pointer to sap configuration structure */
#endif
{

   HiSap  *sap;

   TRC2(hiCfgSap)
 
   /* sanity checks */
#if (ERRCLASS & ERRCLS_DEBUG)
   if(hiCb.cfgDone != TRUE)
   {
      HILOGERROR_INT_PAR( EHI106, (ErrVal) 0, 0,
                 "hiCfgSap(): SAP configuration before General configuration");
      RETVALUE(LCM_REASON_GENCFG_NOT_DONE);
   }
#endif /* ERRCLS_DEBUG */
 
#if (ERRCLASS & ERRCLS_INT_PAR)
   if((cfg->spId >= hiCb.cfg.numSaps) ||(cfg->spId <0))
   {
      HILOGERROR_INT_PAR( EHI107, (ErrVal)cfg->spId, 0,
                 "hiCfgSap(): spId out of range");
      RETVALUE(LHI_REASON_INV_SPID);
   }
#endif /* ERRCLS_INT_PAR */
 
   /* get the sap control block */
   sap = hiCb.sapLstPtr[cfg->spId];
   if (sap == NULLP)
   {
      /* new configuration request, allocate a transport sap. also configure 
       * the interface version info in the control sturcture of this sap */
      RETVALUE(hiAllocSap(cfg));
   }
   else
   {  
      /* sap->flc if SET is not reset */
      sap->cfg.flcEnb = cfg->flcEnb;
      /* Copy the header information */
      cmMemcpy((U8*)sap->cfg.hdrInf, (U8*)cfg->hdrInf, 
               (LHI_MAX_HDR_TYPE * sizeof(HiHdrInfo)));
      
      /* hi009.104 - reconfiguration interface version info in this sap */ 
#ifdef HI_RUG
     /* reconfigure interface version info */ 
      if (cfg->remIntfValid == TRUE)
      {
         /* validate interface version number */
         if (cfg->remIntfVer > HITIFVER)
         {
            /* send NOK to LM with reason version mismatch */            
            RETVALUE(LCM_REASON_VERSION_MISMATCH);
         }
         else
         {
            /* reconfigure interface version number in pst of SAP */
            sap->uiPst.intfVer = cfg->remIntfVer;

            /* mark the validity of remote interface version number */
            sap->remIntfValid = TRUE;

            /* mark version controlling entity as layer manager */
            sap->verContEnt = ENTSM;
         }
      } 
#endif /* HI_RUG */
   }

   RETVALUE(LCM_REASON_NOT_APPL);
}/* end of hiCfgSap() */


/*
*
*       Fun:   hiShutdown
*
*       Desc:  This function is called to bring down the TUCL. It
*              reverses the actions in general configuration.
*
*       Ret:   Void 
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void hiShutdown
(
Void
)
#else
PUBLIC Void hiShutdown()
#endif
{

   U16   i;
   S16   ret;

#ifdef HI_MULTI_THREADED
   HiSendThrMsg   msg;
   U32            spIds;
   HiSap          *sap;
   HiAlarmInfo    alInfo;
#else
   HiSap *sap;
#endif /* HI_MULTI_THREADED */

   /* hi009.104 - added fields for inetrface version info */
#ifdef HI_RUG
   U16 hiMaxNumIntfInfo;        /* max num of intf ver info */
   Size hiMaxIntfInfoSize;      /* max size to store intf ver info */
#endif /* HI_RUG */   

   TRC2(hiShutdown)

#ifdef HI_MULTI_THREADED
   /* Send a message to all saps to delete the saps */
   for (spIds = 0; spIds < hiCb.cfg.numSaps; spIds++)
   {
      sap = hiCb.sapLstPtr[spIds];
      if (!sap)
         continue;
      else 
      {
         if (sap->uiPst.srcInst == 0)
         {
            /* Cleanup all conCbs from the sap */
            hiCleanupSapConCbs(sap, HI_DELSAP_MSG);

            /* If no receive threads have any conCbs go ahead with the
             * request */
            if (sap->numRecvThrCfmsExptd == 0)
            {
               HI_FREE_SAP_RES(sap);
               continue;
            }
         }
         else if (sap->uiPst.srcInst == INSTNC)
         {
            HI_FREE_SAP_RES(sap);
            continue;
         }
         else 
         {
            /* Sap is not on instance 0. If there is a pending operation
             * then there is no need to send a request other wise send 
             * a request to disable the sap */
            if (sap->pendOp.flag != TRUE)
            {
               ret = hiSendIntSapDisReq(sap->spId);
               if (ret != ROK)
               { 
                  /* Raise an alarm here */
                  alInfo.spId = sap->spId;
                  alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

                  hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_SHTDWNREQ,
                              LHI_CAUSE_INTPRIM_ERR, &alInfo);
               }
            }
         }
         hiCb.numSapsToBeDel += 1;
      }
   }

   /* If all saps have already shutdown then close all the threads */
   if (hiCb.numSapsToBeDel == 0)
   {
      msg.msgType = HI_ENDTSK_MSG;
      for (i = 0; i < hiCb.numFdGrps; i++)
         hiSendRecvThrMsg(i, &msg);
   }
#else  /* HI_MULTI_THREADED */
   
   /* Delete all TSAPs */
   for (i=0; i< hiCb.cfg.numSaps; i++)
   {
      sap = hiCb.sapLstPtr[i];
      if(!sap)
         continue;

      HI_RELEASE_SAP_CON_LIST(sap, TRUE);
      cmHashListDeinit(&sap->sapHlCp);

      hiCb.sapLstPtr[sap->spId] = NULLP;
      HI_FREE(sizeof(HiSap), sap);
   }
   HI_FREE((hiCb.cfg.numSaps*sizeof(PTR)), hiCb.sapLstPtr);
   HI_ZERO(&(hiCb.hiInit.lmPst), sizeof(Pst));
#ifdef  HI_LPBK
   (Void)cmHashListDeinit(&hiCb.locAddrHlCp);
#else
   HI_SOCK_DEINIT();
   if(hiCb.cfg.permTsk == FALSE)
   {
      /* Stop and deregister the permamnent task timer */
      HI_STOP_TMR();
#ifdef SS_MULTIPLE_PROCS
      SDeregTmr(hiCb.hiInit.procId, hiCb.hiInit.ent, hiCb.hiInit.inst, 
                 hiCb.cfg.schdTmrVal, hiActvTmr);
#else /* SS_MULTIPLE_PROCS */      
      SDeregTmr(hiCb.hiInit.ent, hiCb.hiInit.inst, 
                 hiCb.cfg.schdTmrVal, hiActvTmr);
# endif /* SS_MULTIPLE_PROCS */      
   }
   else
   {
      /* If user registers the permanent task then the user should 
       * deregister it */
#ifdef HI_CMPTBL_FLAG 
      /* Deregister the permanent task */
      SDeregInitTskTmr((Ent)hiCb.hiInit.ent, (Inst)(hiCb.hiInit.inst+1));
#endif /* HI_CMPTBL_FLAG */
   }

   /* deallocate the hash list. All conCbs would have been deleted when 
    * the sap memory was released. */
   for (i = 0; i < hiCb.numFdGrps; i++)
   {
      hiDeInitFdGrp(hiCb.hiFdGrpInfoLstPtr[i]);
      HI_FREE(sizeof(HiFdGrpInfo), hiCb.hiFdGrpInfoLstPtr[i]);
   }
      
   HI_FREE((sizeof(PTR) * hiCb.numFdGrps), hiCb.hiFdGrpInfoLstPtr);
#endif /* HI_LPBK */

   /* deinitialise the ICMP conCb hash list */
#ifdef HI_REL_1_3 
   HI_ZERO(&hiCb.icmpConFd, sizeof(CmInetFd));
   cmHashListDeinit(&hiCb.icmpHlCp);
#ifdef IPV6_SUPPORTED 
   HI_ZERO(&hiCb.icmp6ConFd, sizeof(CmInetFd));
   cmHashListDeinit(&hiCb.icmp6HlCp);
#endif /* IPV6_SUPPORTED */  
#endif /* HI_REL_1_3 */

   /* Deallocate the static memory reserved */
   SPutSMem(hiCb.hiInit.region, hiCb.hiInit.pool);
   /* hi009.104 - add for RUG */
#ifdef HI_RUG
   /* calculate maximum number of interface informations */
   hiMaxNumIntfInfo = (Size)hiCb.cfg.numSaps;
#endif /* HI_RUG */
   /* remove general config information from the Control Block */
   HI_ZERO(&(hiCb.cfg), sizeof(HiGenCfg));

   hiCb.cfgDone = FALSE;
#endif /* HI_MULTI_THREADED */

   /* hi009.104 - free the memory allocated for interface info */
#ifdef HI_RUG
   if (hiCb.intfInfo != NULLP)
   {
#ifdef HI_MULTI_THREADED
      /* calculate maximum number of interface informations */
      hiMaxNumIntfInfo = (Size)hiCb.cfg.numSaps;
#endif /* HI_MULTI_THREADED */
      /* calculate memory allocated to store interface version info */
      hiMaxIntfInfoSize = (Size)hiMaxNumIntfInfo * (Size)sizeof(ShtVerInfo);

      SPutSBuf(hiCb.hiInit.region, hiCb.hiInit.pool, (Data *)hiCb.intfInfo,
               hiMaxIntfInfoSize);
   }
#endif /* HI_RUG */
   

   RETVOID;
} /* end of hiShutdown() */


/*
*
*       Fun:   hiCntrlGen 
*
*       Desc:  This function is called on getting a Control Request with 
*              with elmnt as STGEN. It is used to enable or disable
*              alarms and unsolicited status indications. It is also
*              used to control debug information printing.
*
*       Ret:   LCM_REASON_NOT_APPL 
*              LCM_REASON_INVALID_ACTION
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiCntrlGen 
(
Pst      *pst,    /* post structure */
HiMngmt  *cntrl,  /* pointer to control structure */
Header   *hdr     /* Header */
)
#else
PUBLIC S16 hiCntrlGen(pst, cntrl, hdr) 
Pst      *pst;    /* post structure */
HiMngmt  *cntrl;  /* pointer to control structure */
Header   *hdr;    /* Header */
#endif
{

   U8      action;
   U8      subAction;

#ifdef HI_MULTI_THREADED
   S16     ret;
#endif /* HI_MULTI_THREADED */

   TRC2(hiCntrlGen)

   /* hi021.104: UNUSED hdr and pst if Multithreaded is not used */
#ifndef HI_MULTI_THREADED  
   UNUSED(pst);
   UNUSED(hdr);
#endif /* HI_MULTI_THREADED */

   action = cntrl->t.cntrl.action;
   subAction = cntrl->t.cntrl.subAction;

   if(action == ASHUTDOWN)
   {
#ifdef HI_MULTI_THREADED
      ret = hiChkCntrlOp(STGEN);
      if (ret != LCM_REASON_NOT_APPL)
         RETVALUE(ret);

      /* Save the post structure and header for later use */
      hiCb.pendOp.flag = TRUE;
      cmMemcpy((U8 *)&(hiCb.pendOp.lmPst), (U8 *)pst,
               (U32) sizeof(Pst));
      cmMemcpy((U8 *)&(hiCb.pendOp.hdr), (U8 *)hdr,
               (U32) sizeof(Header));

      hiShutdown();
      RETVALUE(LHI_REASON_OPINPROG);
#else
      hiShutdown();
      RETVALUE(LCM_REASON_NOT_APPL);
#endif /* HI_MULTI_THREADED */
   }

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check the subAction value received */
   if((subAction != SAUSTA) && (subAction != SADBG))
   {
      HILOGERROR_INT_PAR( EHI108, (ErrVal)subAction, 0,
                 "hiCntrlGen(): invalid subAction specified");
      RETVALUE(LCM_REASON_INVALID_SUBACTION);
   }
#endif /* ERRCLS_INT_PAR */

   switch(action)
   {
      case AENA:
          /* Enable unsolicited status or debug  */
         if (subAction == SAUSTA)
         {
            hiCb.hiInit.usta = TRUE;
         }
#ifdef DEBUGP
         else if (subAction == SADBG)
         {
            hiCb.hiInit.dbgMask |= cntrl->t.cntrl.ctlType.hiDbg.dbgMask;
         }
#endif /* DEBUGP */
         break;
 
      case ADISIMM:
         /* Disable unsolicited status or debug */
         if (subAction == SAUSTA)
         {
            hiCb.hiInit.usta = FALSE;
         }
#ifdef DEBUGP
         else if (subAction == SADBG)
         {
            hiCb.hiInit.dbgMask &= ~(cntrl->t.cntrl.ctlType.hiDbg.dbgMask);
         }
#endif /* DEBUGP */
         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         HILOGERROR_INT_PAR( EHI109, (ErrVal) action, 0,
                   "hiCntrlGen(): Unknown or unsupported action");
#endif /* ERRCLS_INT_PAR */

         RETVALUE(LCM_REASON_INVALID_ACTION);
   } /* end switch */
 
   RETVALUE(LCM_REASON_NOT_APPL); 
}/* end of hiCntrlGen */


/*
*
*       Fun:   hiCntrlSap   
*
*       Desc:  This function is called on getting a Control Request 
*              with elmnt as STTSAP. It is used to disable or delete 
*              a TUCL SAP.
*
*       Ret:   LCM_REASON_NOT_APPL
*              LCM_REASON_INVALID_ACTION
*              LCM_REASON_INVALID_SUBACTION
*              LCM_REASON_INVALID_SAP
*
*              LHI_REASON_DIFFOPINPROG - Different control operation in 
*                                        progress.
*
*              LHI_REASON_OPINPROG - Operation in progress 
*              LCM_REASON_INT_ERROR - Incase of a failure 
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiCntrlSap
(
Pst      *pst,    /* post structure */
HiMngmt  *cntrl,  /* pointer to control structure */
Header   *hdr     /* Header */
)
#else
PUBLIC S16 hiCntrlSap(pst, cntrl, hdr)
Pst      *pst;    /* post structure */
HiMngmt  *cntrl;  /* pointer to control structure */
Header   *hdr;    /* Header */
#endif
{

   S16            sapId;
   HiSap          *sap;
   U8             action;
   U8             subAction;
   S16            ret; 

   TRC2(hiCntrlSap)

   /* Initialisations */
   ret = ROK;

   /* hi021.104: UNUSED hdr and pst if Multithreaded is not used */
#ifndef HI_MULTI_THREADED  
   UNUSED(pst);
   UNUSED(hdr);
#endif /* HI_MULTI_THREADED */
   /* Get the header */
   action    = cntrl->t.cntrl.action;
   subAction = cntrl->t.cntrl.subAction;
 
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check the subAction value received */
   if((subAction != SAELMNT) && (subAction != SATRC))
   {
      HILOGERROR_INT_PAR( EHI110, (ErrVal)subAction, 0,
                 "hiCntrlSap(): invalid subAction specified");
      RETVALUE(LCM_REASON_INVALID_SUBACTION);
   }
#endif /* ERRCLS_INT_PAR */

   if(subAction == SAELMNT)
      sapId = cntrl->t.cntrl.ctlType.sapId;
   else
      sapId = cntrl->t.cntrl.ctlType.trcDat.sapId;

   /* check the sapId range */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if((sapId >= hiCb.cfg.numSaps) ||(sapId <0))
   {
      HILOGERROR_INT_PAR( EHI111, (ErrVal)sapId, 0,
                 "hiCntrlSap(): spId out of range");
      RETVALUE(LHI_REASON_INV_SPID);
   }
#endif /* ERRCLS_INT_PAR */

   sap = hiCb.sapLstPtr[sapId];

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* A SAP should be disabled only after it has been bound */
   if ((sap == NULLP) ||
       ((action == AUBND_DIS) && (subAction == SAELMNT) && 
        (sap->state == HI_ST_UBND)))
   {
      HILOGERROR_INT_PAR( EHI112, (ErrVal) action, 0,
                    "hiCntrlSap(): invalid sapId specified");
      RETVALUE(LCM_REASON_INVALID_SAP);
   }
#endif /* ERRCLS_INT_PAR */
         
   switch(action)
   {
      case AUBND_DIS:
       /* hi009.104 - move up here from case ADEL */
#ifdef HI_RUG
       /* unbind disable for upper sap */
       if(sap->contEnt == ENTNC)
          sap->remIntfValid = FALSE;
#endif /* HI_RUG */                  
               
         if(subAction == SATRC)
         {
            sap->trc = FALSE;
            break;
         }
         /* Case FALL THRU */
        
      case ADEL:
#ifndef HI_MULTI_THREADED
         if(subAction == SAELMNT)
         {
            /* Disconnect all connections for this sap */
            HI_RELEASE_SAP_CON_LIST(sap, TRUE);

            if(action == ADEL)
            {
               /* Free the memory associated with this SAP */
               HI_FREE(sizeof(HiSap), sap);
               hiCb.sapLstPtr[sapId] = NULLP;
            }
            else /* action == AUBND_DIS */
            {
               sap->contEnt = ENTSM;
               /* revert the SAP state to configured but not bound */
               sap->state = HI_ST_UBND;
            }
         }/* end if subAction */
#else
         /* Check if there is another pending operation */
         ret = hiChkCntrlOp(STTSAP);
         if (ret != LCM_REASON_NOT_APPL)
            RETVALUE(ret);

	 /* hi029.104 - SAP Delete will always be processed by Instance
	    0 - so no need for internal primitive */
	 /* Cleanup all conCbs from the sap */
	 hiCleanupSapConCbs(sap, HI_DELSAP_MSG);

	 /* If no receive threads have any conCbs go ahead with the
	  * request */
	 if (sap->numRecvThrCfmsExptd == 0)
	 {
	    /* No receive threads have conCbs. Proceed with the 
	     * control request */
	    if(action == ADEL)
	    {
	       HI_FREE_SAP_RES(sap);
	    }
	    else
	    {
	       sap->contEnt = ENTSM;

	       /* revert the SAP state to configured but not bound */
	       sap->state = HI_ST_UBND;
	    }
	    /* Come out of the case statement */
	    break;
	 }
         
         RETVALUE(LHI_REASON_OPINPROG);
#endif /* HI_MULTI_THREADED */
         break;
 
      case AENA:
         if(subAction == SATRC)
         {
            /* Enable Trace Indications */
            sap->trc = TRUE;

            /* set the trace length */
            sap->trcLen = cntrl->t.cntrl.ctlType.trcDat.trcLen;
         }
         break;
          
      default:
 
#if (ERRCLASS & ERRCLS_INT_PAR)
         HILOGERROR_INT_PAR(EHI113, (ErrVal) action, 0,
                    "hiCntrlSap(). Unknown or unsupported action");
#endif /* ERRCLS_INT_PAR */
         
         RETVALUE(LCM_REASON_INVALID_ACTION);
   } /* end switch */
 
   RETVALUE(LCM_REASON_NOT_APPL);

}/* end of hiCntrlSap */


/*
*
*       Fun:   hiCntrlSapGrp 
*       Desc:  This function is called on getting a Control Request with 
*              with elmnt as STGRSAP. It is used to disable or delete a 
*              group of TCP UDP Convergence Layer SAPs.
*
*       Ret:   LCM_REASON_NOT_APPL
*              LCM_REASON_INVALID_SAP
*              LHI_REASON_NO_SAP_FOUND
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiCntrlSapGrp
(
Pst      *pst,     /* post structure */
HiMngmt  *cntrl,   /* pointer to control structure */
Header   *hdr      /* header */
)
#else
PUBLIC S16 hiCntrlSapGrp(pst, cntrl, hdr)
Pst      *pst;     /* post structure */
HiMngmt  *cntrl;   /* pointer to control structure */
Header   *hdr;     /* header */
#endif
{

   HiSap      *sap;
   U16        i;
   Bool       found; 
   Bool       anySap;
   U8         action;
   S16        ret;

#ifdef HI_MULTI_THREADED
   HiAlarmInfo    alInfo;
#endif /* HI_MULTI_THREADED */

   TRC2(hiCntrlSapGrp)
   
   /* hi021.104: UNUSED hdr and pst if Multithreaded is not used */
#ifndef HI_MULTI_THREADED  
   UNUSED(pst);
   UNUSED(hdr);
#endif /* HI_MULTI_THREADED */
   anySap = FALSE;
   action = cntrl->t.cntrl.action;
   ret = LCM_REASON_NOT_APPL;

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* sanity checks */
   if((action != ADEL) && (action != AUBND_DIS))
   {
      HILOGERROR_INT_PAR( EHI114, (ErrVal) action, 0,
                 "hiCntrlSap(): Unknown or unsupported action");
      RETVALUE(LCM_REASON_INVALID_ACTION);
   }
#endif /* ERRCLS_INT_PAR */

#ifdef HI_MULTI_THREADED
   /* Check if another operation is going on */
   ret = hiChkCntrlOp(STGRTSAP);
   if (ret != LCM_REASON_NOT_APPL)
   {
      RETVALUE(LHI_REASON_DIFF_OPINPROG);
   }
#endif /* HI_MULTI_THREADED */

   for (i=0; i< hiCb.cfg.numSaps; i++)
   {
      sap = hiCb.sapLstPtr[i];
      if (!sap)
         continue;

      found = FALSE;
      switch (cntrl->t.cntrl.subAction)
      {
         case SAGR_DSTPROCID:
            if(sap->uiPst.dstProcId == 
                    cntrl->t.cntrl.ctlType.dstProcId)
            found = TRUE;
            break;

         case SAGR_ROUTE:
            if(sap->uiPst.route == 
                    cntrl->t.cntrl.ctlType.route)
            found = TRUE;
            break;

         case SAGR_PRIORITY:
            if(sap->uiPst.prior == 
                    cntrl->t.cntrl.ctlType.priority)
            found = TRUE;
            break;

         default:
#if (ERRCLASS & ERRCLS_INT_PAR)
            HILOGERROR_INT_PAR( EHI115, (ErrVal) cntrl->t.cntrl.subAction, 0,
                       "hiCntrlSap(): Unknown or unsupported sub-action");
#endif /* ERRCLS_INT_PAR */
            RETVALUE(LCM_REASON_INVALID_SUBACTION);
      }/* end switch */
              
      if (found) /* found a SAP with matching criterion */
      {
         /* A SAP may be disabled only after it has been bound */
         if((action == ADEL) ||
             ((action == AUBND_DIS) && (sap->state == HI_ST_BND)))
         {
            /* Set the anySap flag to indicate a SAP was found */
            anySap = TRUE;

#ifndef HI_MULTI_THREADED
            /* Release SAP connections */
            HI_RELEASE_SAP_CON_LIST(sap, TRUE);
            if (action == ADEL)
            {
               hiCb.sapLstPtr[sap->spId] = NULLP;
               HI_FREE(sizeof(HiSap), sap);
            }
            else
            {
               sap->state = HI_ST_UBND;
               sap->contEnt = ENTSM;
            }
#else
            if (sap->uiPst.srcInst == 0)
            { 
               /* Cleanup all conCbs from the sap */
               hiCleanupSapConCbs(sap, HI_DELSAP_MSG);

               /* If no receive threads have any conCbs go ahead with the
                * request */
               if (sap->numRecvThrCfmsExptd == 0)
               {
                  /* No receive threads have conCbs. Proceed with the 
                   * control request */
                  if(action == ADEL)
                  {
                     HI_FREE_SAP_RES(sap);
                  }
                  else
                  {
                     sap->contEnt = ENTSM;

                     /* revert the SAP state to configured but not bound */
                     sap->state = HI_ST_UBND;
                  }
               }
            }
            else
            {
               /* Save the header and other information for later use */
               sap->pendOp.flag = TRUE;
               sap->pendOp.action = action;
               sap->pendOp.elmnt = STGRTSAP;

               cmMemcpy((U8 *)&(sap->pendOp.lmPst), (U8 *)pst,
                        (U32) sizeof(Pst));
               cmMemcpy((U8 *)&(sap->pendOp.hdr), (U8 *)hdr,
                        (U32) sizeof(Header));

               /* Send an internal primitive to the appropriate sap instance.
               * The control confirm will be given later.
               */
               ret = hiSendIntSapDisReq(sap->spId);
               if (ret != ROK)
               { 
                  /* Raise an alarm here */
                  alInfo.spId = sap->spId;
                  alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

                  hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_GRPCNTRLREQ,
                     LHI_CAUSE_INTPRIM_ERR, &alInfo);
                  RETVALUE(LHI_REASON_INT_ERROR);
               }
               ret = LHI_REASON_OPINPROG;
               hiCb.numGrpSapsToBeDel += 1;
            }
#endif /* HI_MULTI_THREADED */
         }/* end if */
         else
            continue;
      }/* end if found */
   }/* end for loop */

   if (anySap == FALSE)
   {

#if (ERRCLASS & ERRCLS_DEBUG)

      HILOGERROR_DEBUG( EHI116, (ErrVal) action, 0,
                 "hiCntrlSapGrp(): NO SAP found for specified criterion");

#endif /* ERRCLS_DEBUG */

      RETVALUE(LHI_REASON_NO_SAP_FOUND);
   }/* end if */

  RETVALUE(ret);

}/* end of hiCntrlSapGrp */


/*
*
*       Fun:   hiTrcBuf 
*
*       Desc:  This function is used to trace the messages received
*              or transmitted by TCP UDP Convergence Layer.
*              "mBuf" parameter is not modified by this function.
*
*       Ret:   Void 
*
*       Notes: None
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void  hiTrcBuf 
(
HiSap *sap, 
U16    evnt,
Buffer *mBuf
)
#else
PUBLIC Void  hiTrcBuf(sap, evnt, mBuf)
HiSap  *sap; 
U16    evnt;
Buffer *mBuf;
#endif
{

   HiMngmt     mgt;
   MsgLen      mLen;
   Buffer      *trcBuf;
   Buffer      *tmpBuf;
   HiAlarmInfo info;
   S16         ret;
   S16         trcLen;

   TRC2(hiTrcBuf)

   info.spId = sap->spId;
   info.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   /* zero out the management structure */
   HI_ZERO(&mgt, sizeof(HiMngmt));

   /* update the date and time */
   (Void) SGetDateTime(&mgt.t.trc.dt);

   SFndLenMsg(mBuf, &mLen);

   trcLen = sap->trcLen;

   /* Full message to be traced */
   if((trcLen == -1) || (trcLen >= mLen))
   {
      /* Copy the entire buffer */
      ret = SAddMsgRef(mBuf, hiCb.hiInit.lmPst.region, 
                       hiCb.hiInit.lmPst.pool, &trcBuf);
      if(ret != ROK)
      {
         HI_FILL_ALARMINFO_MEM_ID(info, hiCb.hiInit.lmPst.region, 
                                  hiCb.hiInit.lmPst.pool);
         hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                     LCM_CAUSE_UNKNOWN, &info);
         RETVOID;
      }
   }
   else if(trcLen > 0)
   {
      /* Copy the entire buffer */
      ret = SAddMsgRef(mBuf, hiCb.hiInit.lmPst.region, 
                       hiCb.hiInit.lmPst.pool, &trcBuf);
      if(ret != ROK)
      {
         HI_FILL_ALARMINFO_MEM_ID(info, hiCb.hiInit.lmPst.region, 
                                  hiCb.hiInit.lmPst.pool)
         hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                     LCM_CAUSE_UNKNOWN, &info);
         RETVOID;
      }

      /* copy only first "trcLen" bytes to the trace buffer */
      ret = SSegMsg(trcBuf, trcLen, &tmpBuf);
      if(ret != ROK)
      {
         HI_FILL_ALARMINFO_MEM_ID(info, hiCb.hiInit.lmPst.region, 
                                  hiCb.hiInit.lmPst.pool)
         hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                           LCM_CAUSE_UNKNOWN, &info);
         RETVOID;
      }
      if(tmpBuf)
         (Void)SPutMsg(tmpBuf);
   }
   else
   {
      /* pass the trace buffer as NULL */
      trcBuf = NULLP;
   }

     
   /* fill in the event */
   mgt.t.trc.evnt = evnt;

#ifdef HI_RUG   
   /* hi009.104 - added check for RUG */
   if (hiCb.hiInit.cfgDone == FALSE)
      RETVOID;
#endif /* HI_RUG */

   /* hi023.104 Sap Id in Trace Information */
#ifdef HI_ENB_SAP_TRC
  mgt.t.trc.sap =   sap->spId;
#endif
   
   HiMiLhiTrcInd(&(hiCb.hiInit.lmPst), &mgt, trcBuf);
   
   RETVOID;
}/* end of hiTrcBuf() */


/*
*
*       Fun:   hiGetGenSts
*
*       Desc:  This function is used fill the general statistics.
*
*       Ret:   ROK, Ok.
*              RFAILED, Not OK.
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiGetGenSts
(
HiGenSts    *genStsToFill     /* pointer to general statistics to be returned */
)
#else
PUBLIC S16 hiGetGenSts(genStsToFill)
HiGenSts    *genStsToFill;    /* pointer to general statistics to be returned */
#endif
{
#ifndef HI_LPBK
   U16         fdGrpInfoNum;
   SpId        sapId;
   HiSap       *sap;
   HiFdGrpInfo *grpInfoPtr;
#endif /* HI_LPBK */

   if (genStsToFill == NULLP)
      RETVALUE(RFAILED);
   
   HI_ZERO(genStsToFill, sizeof(HiGenSts));

#ifndef HI_LPBK
   /* Go through the file descriptor groups and add all the counters */
   for (fdGrpInfoNum = 0; fdGrpInfoNum < hiCb.numFdGrps; fdGrpInfoNum++)
   {
      grpInfoPtr = hiCb.hiFdGrpInfoLstPtr[fdGrpInfoNum];
      
      genStsToFill->numCons += grpInfoPtr->grpCb.genRxSts.numCons;
      genStsToFill->numRxTcpMsg += grpInfoPtr->grpCb.genRxSts.numRxTcpMsg;
      genStsToFill->numRxUdpMsg += grpInfoPtr->grpCb.genRxSts.numRxUdpMsg;
      genStsToFill->numRxbytes += grpInfoPtr->grpCb.genRxSts.numRxbytes;
#ifdef HI_REL_1_3
      genStsToFill->numRxRawMsg += grpInfoPtr->grpCb.genRxSts.numRxRawMsg;
#endif /* HI_REL_1_3 */
   }
   
   for (sapId = 0; sapId < hiCb.cfg.numSaps; sapId++)
   {
      sap = hiCb.sapLstPtr[sapId];

      if (sap == NULLP)
         continue;

      genStsToFill->numCons += sap->genTxSts.numCons;        
      genStsToFill->numTxTcpMsg += sap->genTxSts.numTxTcpMsg;
      genStsToFill->numTxUdpMsg += sap->genTxSts.numTxUdpMsg;
      genStsToFill->numTxbytes += sap->genTxSts.numTxbytes;
#ifdef HI_REL_1_3
      genStsToFill->numTxRawMsg += sap->genTxSts.numTxRawMsg;
#endif /* HI_REL_1_3 */
   }

   /* The general statistics are not locked while reading */
   genStsToFill->sockTxErr = hiCb.errSts.sockTxErr;
   genStsToFill->sockRxErr = hiCb.errSts.sockRxErr;
   genStsToFill->sockOpenErr = hiCb.errSts.sockOpenErr;
   genStsToFill->sockBindErr = hiCb.errSts.sockBindErr;
   genStsToFill->sockCnctErr = hiCb.errSts.sockCnctErr;
   genStsToFill->sockLstnErr = hiCb.errSts.sockLstnErr;
   genStsToFill->sockSOptErr = hiCb.errSts.sockSOptErr;
   genStsToFill->sockClosErr = hiCb.errSts.sockClosErr;
   genStsToFill->sockShutErr = hiCb.errSts.sockShutErr;
   genStsToFill->rxMsgVerErr = hiCb.errSts.rxMsgVerErr;
   genStsToFill->numFlcInd = hiCb.errSts.numFlcInd;
#endif /* HI_LPBK */

   RETVALUE(ROK);

} /* end of hiGetGenSts */


/*
*
*       Fun:   hiZeroGenSts
*
*       Desc:  This function is used
*
*       Ret:   
*              
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiZeroGenSts
(
Void
)
#else
PUBLIC S16 hiZeroGenSts()
#endif
{
#ifndef HI_LPBK
   U16         fdGrpInfoNum;
   SpId        sapId;
   HiSap       *sap;
#ifndef HI_MULTI_THREADED
   HiFdGrpInfo *grpInfoPtr;
#else
   HiAlarmInfo   alInfo;
   HiSendThrMsg  msg;
   S16           ret;
#endif /* HI_MULTI_THREADED */
#endif /* HI_LPBK */
   /* hi015.104: add local variable for saving numCons */
   StsCntr       numCons;
   
#ifndef HI_LPBK
#ifdef HI_MULTI_THREADED
   alInfo.spId = -1;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   HI_LOCK(&hiCb.errStsLock, alInfo, ret); 
   if (ret != ROK)
      HILOGERROR_DEBUG(EHI117, (ErrVal) 0, 0, 
         "hiZeroGenSts () : Unable to lock error sts \n");
#endif /* HI_MULTI_THREADED */

   /* Zero the error statistics. These statistics are not protected in case
    * of multi-threaded implementation */
   HI_ZERO(&hiCb.errSts, sizeof(HiErrSts));

#ifdef HI_MULTI_THREADED
   HI_UNLOCK(&hiCb.errStsLock, alInfo, ret);
   if (ret != ROK)
      HILOGERROR_DEBUG(EHI118, (ErrVal) 0, 0, 
         "hiZeroGenSts () : Unable to unlock error sts \n");
#endif /* HI_MULTI_THREADED */
   
   for (fdGrpInfoNum = 0; fdGrpInfoNum < hiCb.numFdGrps; fdGrpInfoNum ++)
   {
#ifdef HI_MULTI_THREADED
      msg.msgType = HI_ZERO_GENSTS;
      hiSendRecvThrMsg(fdGrpInfoNum, &msg);
#else
      grpInfoPtr = hiCb.hiFdGrpInfoLstPtr[fdGrpInfoNum];
      /* hi015.104: reset the sts counter */
      numCons = grpInfoPtr->grpCb.genRxSts.numCons;
      HI_ZERO(&grpInfoPtr->grpCb.genRxSts, sizeof(HiRxSts));
      grpInfoPtr->grpCb.genRxSts.numCons = numCons;
#endif /* HI_MULTI_THREADED */
   }   

   for (sapId = 0; sapId < hiCb.cfg.numSaps; sapId++)
   {
      sap = hiCb.sapLstPtr[sapId];
      
      if (!sap)
         continue;

#ifdef HI_MULTI_THREADED
      if (sap->uiPst.srcInst != 0)
      {
         /* Invoke an internal primitive to send the zero statistics 
          * request */
         hiSendIntZeroStsReq(HI_ZERO_GENSTS, 0, sap->uiPst.srcInst);
      }
      else
#endif /* HI_MULTI_THREADED */
      {
         /* hi015.104: reset teh counter */
         numCons = sap->genTxSts.numCons;
         HI_ZERO(&sap->genTxSts, sizeof(HiTxSts));
         sap->genTxSts.numCons = numCons;
      }
   }
#endif /* HI_LPBK */

   RETVALUE(ROK);
} /* end of hiZeroGenSts */


/*
*
*       Fun:   hiGetSapSts
*
*       Desc:  This function is used fill the sap statistics.
*
*       Ret:   ROK, Ok.
*              RFAILED, Not OK.
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiGetSapSts
(
HiSapSts    *sapStsToFill,    /* pointer to sap statistics to be returned */
SpId        sapId             /* SAP Id */
)
#else
PUBLIC S16 hiGetSapSts(sapStsToFill, sapId)
HiSapSts    *sapStsToFill;    /* pointer to sap statistics to be returned */
SpId        sapId;            /* SAP Id */
#endif
{
#ifndef HI_LPBK
   U16         fdGrpInfoNum;
   HiSap       *sap;
   HiFdGrpInfo *grpInfoPtr;

   sap = hiCb.sapLstPtr[sapId];

#if (ERRCLASS & ERRCLS_DEBUG) 
   if ((sapStsToFill == NULLP) || (sap == NULLP))
      RETVALUE(RFAILED);
#endif /* ERRCLS_DEBUG */

   HI_ZERO(sapStsToFill, sizeof(HiSapSts));

   /* Go through the file descriptor groups and add all the counters */
   for (fdGrpInfoNum = 0; fdGrpInfoNum < hiCb.numFdGrps; fdGrpInfoNum++)
   {
      grpInfoPtr = hiCb.hiFdGrpInfoLstPtr[fdGrpInfoNum];
       
      sapStsToFill->numCons += grpInfoPtr->grpCb.rxStsArr[sapId].numCons;
      sapStsToFill->numRxTcpMsg += 
                           grpInfoPtr->grpCb.rxStsArr[sapId].numRxTcpMsg;
      sapStsToFill->numRxUdpMsg += 
                           grpInfoPtr->grpCb.rxStsArr[sapId].numRxUdpMsg;
      sapStsToFill->numRxbytes += grpInfoPtr->grpCb.rxStsArr[sapId].numRxbytes;
#ifdef HI_REL_1_3
      sapStsToFill->numRxRawMsg += 
                                 grpInfoPtr->grpCb.rxStsArr[sapId].numRxRawMsg;
#endif /* HI_REL_1_3 */
   }
  
   sapStsToFill->numTxTcpMsg = sap->txSts.numTxTcpMsg;
   sapStsToFill->numTxUdpMsg = sap->txSts.numTxUdpMsg;
   sapStsToFill->numTxbytes = sap->txSts.numTxbytes;
#ifdef HI_REL_1_3
   sapStsToFill->numTxRawMsg = sap->txSts.numTxRawMsg;
#endif /* HI_REL_1_3 */
   /* hi005.104: set the sapId */
   sapStsToFill->sapId = sapId;
#endif /* HI_LPBK */   

   RETVALUE(ROK);

} /* end of hiGetSapSts */


/*
*
*       Fun:   hiZeroSapSts
*
*       Desc:  This function is used to zero out the sap statistics.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiZeroSapSts
(
SpId  sapId
)
#else
PUBLIC S16 hiZeroSapSts(sapId)
SpId  sapId;
#endif
{
#ifndef HI_LPBK
   HiSap       *sap;
   U16         fdGrpInfoNum;

#ifdef HI_MULTI_THREADED
   HiSendThrMsg   msg;
#else
   HiFdGrpInfo *grpInfoPtr;
#endif /* HI_MULTI_THREADED */
   /* hi015.104: reset the counter */
   StsCntr numCons;
   
   sap = hiCb.sapLstPtr[sapId];

#if (ERRCLASS & ERRCLS_DEBUG) 
   if (!sap)
      RETVALUE(RFAILED);
#endif /* ERRCLS_DEBUG */

#ifdef HI_MULTI_THREADED
   if (sap->uiPst.srcInst != 0)
      hiSendIntZeroStsReq(HI_ZERO_SAPSTS, sapId, sap->uiPst.srcInst);
   else
#endif /* HI_MULTI_THREADED */
   {
      /* hi015.104: reset teh counter */
      numCons = sap->txSts.numCons;
      HI_ZERO(&sap->txSts, sizeof(HiTxSts));
      sap->txSts.numCons = numCons;
   }
   for (fdGrpInfoNum = 0; fdGrpInfoNum < hiCb.numFdGrps; fdGrpInfoNum ++)
   {
#ifdef HI_MULTI_THREADED
      msg.msgType = HI_ZERO_SAPSTS;
      msg.inf.spId = sapId;
      hiSendRecvThrMsg(fdGrpInfoNum, &msg);
#else
      grpInfoPtr = hiCb.hiFdGrpInfoLstPtr[fdGrpInfoNum];
      /* hi015.104: reset the couter */
      numCons = grpInfoPtr->grpCb.rxStsArr[sapId].numCons;
      HI_ZERO(&grpInfoPtr->grpCb.rxStsArr[sapId], sizeof(HiRxSts));
      grpInfoPtr->grpCb.rxStsArr[sapId].numCons = numCons;
#endif /* HI_MULTI_THREADED */
   }
#endif /* HI_LPBK */

   RETVALUE(ROK);

} /* end of hiZeroSapSts */

#ifdef HI_MULTI_THREADED

/*
*
*       Fun:   hiSendIntZeroStsReq
*
*       Desc:  This function is used to invoke the internal 
*              zero statistics request. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiSendIntZeroStsReq
(
U8       type,       /* Type of statistics to zero out */ 
SpId     sapId,      /* sapId */
Inst     inst        /* Instance */
)
#else
PUBLIC S16 hiSendIntZeroStsReq(type, sapId, inst) 
U8       type;       /* Type of statistics to zero out */ 
SpId     sapId;      /* sapId */
Inst     inst;       /* Instance */
#endif
{
   
   Pst      selfPst;
   Pst      *pst;
   Buffer   *mBuf;
   S16      retVal;
   HiSap    *sap;
   
   TRC2(hiSendIntZeroStsReq);
   
   pst = &selfPst;
   
   sap = hiCb.sapLstPtr[sapId];

   /* Fill in the post structure */
   HI_FILLIN_SELFPST(selfPst, sap, inst, EVTINTZEROSTS);

   /* Get a mBuf */
   retVal = SGetMsg(selfPst.region, selfPst.pool, &mBuf);
   if (retVal != ROK)
   {
      HILOGERROR_ADD_RES(EHI119, (ErrVal) retVal, inst, 
         "hiSendIntCongOff : Failed to allocate mBuf \n");

      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(SPkU8, type, mBuf, EHI120, pst);
   CMCHKPKLOG(cmPkSpId, sapId, mBuf, EHI121, pst);

   RETVALUE(ROK);

} /* hiSendIntZeroStsReq */


/*
*
*       Fun:   hiRecvIntZeroStsReq
*
*       Desc:  This function is used to invoke the internal primitve 
*              to zero the statistics. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiRecvIntZeroStsReq
(
Pst    *pst,
Buffer *mBuf
)
#else
PUBLIC S16 hiRecvIntZeroStsReq(pst, mBuf) 
Pst    *pst;
Buffer *mBuf;
#endif
{

   SpId     sapId;
   U8       type;

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "hiRecvIntZeroStsReq() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_LYR, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

   TRC2(hiRecvIntZeroStsReq);

   /* Unpack the parameters */
   CMCHKUNPKLOG(cmUnpkSpId,   &sapId, mBuf, EHI122, pst);
   CMCHKUNPKLOG(SUnpkU8,      &type,  mBuf, EHI123, pst);

   SPutMsg(mBuf);
   
   /* Directly invoke the primitive */
   HiUiIntZeroStsReq(pst, type, sapId);

   RETVALUE(ROK);

} /* end of hiRecvIntZeroStsReq */
#endif /* HI_MULTI_THREADED */


/* ------------------------------------------------------------------*/
/* Miscellaneous Support functions
 */


/*
*
*       Fun:   hiAddmBufToConCbQ
*
*       Desc:  This function adds the mBuf to the conCb->txQ.
*
*       Ret:   ROK 
*              RFAILED
*              The conCb->reason is filled with the appropriate reason to send
*              to the upper user. The caller should send a disconnect
*              indication to the upper user. There is no deletion of file
*              descriptors from any set here.
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16   hiAddmBufToConCbQ
(
HiConCb    *conCb,      /* connection control block */
Buffer     *mBuf        /* mBuf to be queued */
)
#else
PUBLIC S16  hiAddmBufToConCbQ(conCb, mBuf)
HiConCb    *conCb;      /* connection control block */
Buffer     *mBuf;       /* mBuf to be queued */
#endif
{
   S16               ret;
   MsgLen            mLen;
   HiAlarmInfo       alInfo;
#ifndef HI_MULTI_THREADED
   HiFdGrpInfo       *grpInfoPtr;
#endif /* HI_MULTI_THREADED */

   /* Initialisation */
   alInfo.spId = conCb->sap->spId;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
  
   TRC2(hiAddmBufToConCbQ);

#ifdef HI_MULTI_THREADED
   HI_LOCK(&conCb->txQLockId, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI124, (ErrVal)ret, conCb->sap->uiPst.srcInst,
            "hiAddmBufToConCbQ - Failed to insert mBuf into transmit queue \n");
      conCb->reason = HI_INTERNAL_ERR;
      RETVALUE(RFAILED);
   }
#endif /* HI_MULTI_THREADED */

   ret = SFndLenMsg(mBuf, &mLen);
#if(ERRCLASS & ERRCLS_INT_PAR)
   if(!mLen)
   {
      HILOGERROR_INT_PAR(EHI125, (ErrVal) ret, conCb->sap->uiPst.srcInst, 
                 "hiAddmBufToConCbQ (): Invalid Buffer");

      HI_FILL_ALARMINFO_PAR_TYPE(alInfo, LHI_INV_MBUF);
      hiSendAlarm(LCM_CATEGORY_INTERFACE, LHI_EVENT_DATREQ,
                  LCM_CAUSE_INV_PAR_VAL, &alInfo);

      alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
#ifdef HI_MULTI_THREADED
      HI_UNLOCK(&conCb->txQLockId, alInfo, ret);
      if (ret != ROK)
         HILOGERROR_DEBUG(EHI126, (ErrVal)ret, conCb->sap->uiPst.srcInst,
               "hiAddmBufToConCbQ () : Cannot unlock transmit queue lock ");
#endif /* HI_MULTI_THREADED */

      conCb->reason = HI_INTERNAL_ERR;
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* Enqueue the untransmitted message */
   SQueueLast(mBuf, &conCb->txQ);
   conCb->txQSiz += mLen;
   conCb->mBufInQ = TRUE;

#ifdef HI_MULTI_THREADED
   HI_UNLOCK(&conCb->txQLockId, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI127, (ErrVal)ret, conCb->sap->uiPst.srcInst,
            "hiAddmBufToConCbQ - Failed to insert mBuf into transmit queue \n");
      conCb->reason = HI_INTERNAL_ERR;

      RETVALUE(RFAILED);
   }

   ret = hiAddConCbToCmList(conCb, HI_CM_TXQCONG_LIST);
   if (ret != ROK)
   {
      conCb->reason = HI_INTERNAL_ERR;
      RETVALUE(RFAILED);
   }
#else
   /* Set this file descriptor in the write file descriptor set */
   if (!(conCb->isInList & HI_CONCB_IN_WRITE_LIST))
   {
      grpInfoPtr = hiCb.hiFdGrpInfoLstPtr[conCb->fdBlkIdx];

      if (!grpInfoPtr)
      {
         HILOGERROR_DEBUG(EHI128, (ErrVal)0, conCb->sap->uiPst.srcInst,
               "hiAddmBufToConCbQ - invalid grp information pointer \n");

         conCb->reason = HI_INTERNAL_ERR;
            
         RETVALUE(RFAILED);
      }

      ret =  cmHashListInsert(&grpInfoPtr->grpCb.wrFdHlCp,
                             (PTR)conCb, (U8 *)&(conCb->conFd.fd),
                             sizeof(CmInetFdType));
      if (ret != ROK)
      {
         conCb->reason = HI_INTERNAL_ERR;

         hiSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_INV_EVT, 
                     LCM_CAUSE_HASH_FAIL, &alInfo);

         RETVALUE(RFAILED);
      }
      CM_INET_FD_SET(&(conCb->conFd), 
                 &(grpInfoPtr->grpCb.writeFdSet));
      conCb->isInList |= HI_CONCB_IN_WRITE_LIST;
      grpInfoPtr->grpCb.numWrFds += 1;
   }
#endif /* HI_MULTI_THREADED */

   RETVALUE(ROK);
} /* end of hiAddmBufToConCbQ */


/*
*
*       Fun:   hiChkTxQ 
*
*       Desc:  This function checks the txQ in the connection block
*              for any pending messages. If any messages are pending,
*              it tries to send them.
*
*       Ret:   ROK 
*              RFAILED
*              ROKDNA 
*              RCLOSED
*              The conCb->reason is filled with the appropriate reason to send
*              to the upper user. The caller should send a disconnect
*              indication to the upper user. There is no deletion of file
*              descriptors from any set here.
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16   hiChkTxQ
(
HiConCb    *conCb
)
#else
PUBLIC S16  hiChkTxQ(conCb)
HiConCb    *conCb;
#endif
{

   QLen          qLen;
   QLen          i;
   Buffer        *mBuf;
   Buffer        *qBuf;
   HiSap         *sap;
   CmInetMemInfo memInfo;
   HiAlarmInfo   info;
   MsgLen        txLen;
   S16           ret;
   S16           ret2;
#ifdef HI_MULTI_THREADED
   S16           retVal;
#endif /* HI_MULTI_THREADED */

   TRC2(hiChkTxQ)
    
   /* Initializations */
   sap = conCb->sap;

   info.spId  = sap->spId;
   info.type  = LHI_ALARMINFO_TYPE_NTPRSNT;
   
   memInfo.region = hiCb.hiInit.region;
   memInfo.pool   = hiCb.hiInit.pool;

#ifdef HI_MULTI_THREADED
   HI_LOCK(&conCb->txQLockId, info, ret);
   if (ret != ROK)
   {
      conCb->reason = HI_INTERNAL_ERR;
      HILOGERROR_DEBUG(EHI129, (ErrVal)ret, sap->uiPst.srcInst,
            "hiChkTxQ - Failed to obtain transmit queue lock \n");
      RETVALUE(RFAILED);
   }
#endif /* HI_MULTI_THREADED */

   ret = SFndLenQueue(&conCb->txQ, &qLen);
#if (ERRCLASS & ERRCLS_DEBUG) 
   if (ret != ROK)
   {
      conCb->reason = HI_INTERNAL_ERR;
      HILOGERROR_DEBUG( EHI130, (ErrVal)ret, 0,
                 "hiChkTxQ() failed: SFndLenQueue failed");
#ifdef HI_MULTI_THREADED
       HI_UNLOCK(&conCb->txQLockId, info, ret);
       if (ret != ROK)
          HILOGERROR_DEBUG(EHI131, (ErrVal)ret, sap->uiPst.srcInst,
                "hiChkTxQ - Failed to unlock transmit queue");
#endif /* HI_MULTI_THREADED */
      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */
   
   /* Scan the transmit queue */
   for(i = 0; i < qLen; i++)
   {
      /* Obtain the first queued up message */ 
      (Void) SDequeueFirst(&mBuf, &conCb->txQ);

      ret2 = RNA;

      while (ret2 == RNA)
      {
      /* hi009.104 - added new argument */   
      /* Send the message */
#ifdef IPV6_SUPPORTED
         ret2 = cmInetSendMsg(&conCb->conFd, (CmInetAddr *)&(conCb->peerAddr), 
                              &memInfo, mBuf, &txLen, 
#ifdef IPV6_OPTS_SUPPORTED                              
                              NULLP,
#endif /* IPV6_OPTS_SUPPORTED */                               
                              CM_INET_NO_FLAG);        
#else
         ret2 = cmInetSendMsg(&conCb->conFd, &(conCb->peerAddr.u.ipv4TptAddr), 
                              &memInfo, mBuf, &txLen, CM_INET_NO_FLAG);
#endif /* IPV6_SUPPORTED */

         if((ret2 == RWOULDBLOCK) || (ret2 == RNA))
         {
            /* Check if some data could be transmitted */
            if(txLen)
            {
               /* Here txLen < len(mBuf) as RWOULDBLOCK
                * was returened back */

               /* Increment the statistics counters */
               sap->genTxSts.numTxbytes += txLen;
               sap->txSts.numTxbytes += txLen;

               HIDBGP(DBGMASK_SI, (hiCb.hiInit.prntBuf,
                      "SSegMsg(mBuf1(%p), idx(%d), mBuf2(%p))\n", 
                      mBuf, txLen, &qBuf));

               /* Get the un transmitted part of the message */
               ret = SSegMsg(mBuf, txLen, &qBuf);
               if (ret != ROK)
               {
                  /* deallocate buffer */
                  (Void)SPutMsg(mBuf);
                  /* Flush the queue */
                  SFlushQueue(&conCb->txQ);
#ifdef HI_MULTI_THREADED
                  HI_UNLOCK(&conCb->txQLockId, info, ret);
                  if (ret != ROK)
                     HILOGERROR_DEBUG(EHI132, (ErrVal)ret, sap->uiPst.srcInst,
                           "hiChkTxQ - Unable to unlock the transmit Q lock");
#endif /* HI_MULTI_THREADED */
                  conCb->reason = HI_OUTOF_RES;
                  hiSendAlarm(LCM_CATEGORY_RESOURCE, 
                              LCM_EVENT_DMEM_ALLOC_FAIL,
                              LCM_CAUSE_UNKNOWN, &info);
                  RETVALUE(RFAILED);
               }

               SPutMsg(mBuf);
               conCb->txQSiz   -= txLen;
#ifndef HI_REL_1_3
               sap->currTxQSiz -= txLen;
#endif /* HI_REL_1_3 */
            
               if (ret2 != RNA)
               {
                  /* Queue up the un-transmitted buffer */
                  (Void)SQueueFirst(qBuf, &conCb->txQ);

                  /* Check if a flow control indication needs to be 
                  * issued to the service user */
#ifdef HI_REL_1_3
                  hiChkFlwCntrl(conCb, 0, txLen);
#else
                  hiChkFlwCntrl(sap, 0, txLen);
#endif /* HI_REL_1_3 */
   
                  /* Deallocate mBuf here */
                  ret = RWOULDBLOCK;
                  break;
               }
               else
               {
                  mBuf = qBuf;
               }
            }/* end if txLen */
            else /* No data could be sent */
            {
               /* queue up the dequeued buffer and return */
               (Void)SQueueFirst(mBuf, &conCb->txQ);
               ret = RWOULDBLOCK;
               break;
            }
         }/* end if  */
         else if (ret2 == RFAILED)
         {
            /* increment the statistics counter */
            hiCb.errSts.sockTxErr++;

            /* deallocate the dequeued buffer */
            (Void)SPutMsg(mBuf);

            /* RFAILED or RWOULDBLOCK with txLen = 0 */
            hiSendAlarm(LCM_CATEGORY_INTERNAL, LHI_EVENT_INET_ERR,
                        LHI_CAUSE_SOCK_SEND_ERR, &info);
            break;
         }
         else if (ret2 == ROUTRES)
         {
            /* increment the statistics counter */
            hiCb.errSts.sockTxErr++;
   
            info.type = LHI_ALARMINFO_MEM_ID;
            
            conCb->reason = HI_OUTOF_RES;

            /* fill up the alarm information */
            HI_FILL_ALARMINFO_MEM_ID(info, memInfo.region, memInfo.pool);
            hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                        LHI_CAUSE_SOCK_SEND_ERR, &info);
            break;
         }
         /* Added check for RCLOSED */
         else if (ret2 == RCLOSED)
         {
            conCb->reason = HI_CON_CLOSED_BY_PEER;
            /* deallocate the buffer */
            (Void)SPutMsg(mBuf);
            break;
         }
         else if (ret2 == ROK)
         {
            /* Check if a flow control indication needs to be 
             * issued to the service user */
#ifdef HI_REL_1_3
            hiChkFlwCntrl(conCb, 0, txLen);
#else
            hiChkFlwCntrl(sap, 0, txLen);
            sap->currTxQSiz -= txLen;
#endif /* HI_REL_1_3 */  
            conCb->txQSiz   -= txLen;
         } 

         /* Deallocate the message buffer sent */
         /* Here it may be full buffer dequeued or may be the segmented
          * buffer transmitted 
          */
         if (ret2 != RNA)
            (Void)SPutMsg(mBuf);
      }
   } /* end of for loop */

#ifdef HI_MULTI_THREADED
   HI_UNLOCK(&conCb->txQLockId, info, retVal);
   if (retVal != ROK)
   {
      conCb->reason = HI_INTERNAL_ERR;
      HILOGERROR_DEBUG(EHI133, (ErrVal)retVal, sap->uiPst.srcInst,
         "hiChkTxQ - Failed to unlock transmit queue lock \n");
      RETVALUE(RFAILED);
   }
#endif /* HI_MULTI_THREADED */

   RETVALUE(ret);
} /* end of hiChkTxQ() */


/*
*
*       Fun:   hiAppendHdr   
*
*       Desc:  This function is used to mark the boundaries of
*              data in TCP octet stream.
*
*       Ret:   ROK
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16  hiAppendHdr
(
Buffer *buf              /* message buffer */
)
#else
PUBLIC S16  hiAppendHdr(buf)
Buffer *buf;              /* message buffer */
#endif
{

   U8           hdr[HI_TPKT_HDR_LEN];
   MsgLen       len;
   U16          nLen;
   S16          ret;

   TRC2(hiAppendHdr)

   /* calculate the TPDU length */
   SFndLenMsg(buf, &len);

   /* increment the length by the lenght of the header */
   len += HI_TPKT_HDR_LEN;

   nLen = len;
   /* encode the length */
   hdr[0] = GetLoByte(nLen);
   hdr[1] = GetHiByte(nLen);  
   hdr[2] = HI_TPKT_HDR_RESERVED;
   hdr[3] = HI_TPKT_HDR_VERSION;

   /* Append the header */
   ret = SAddPreMsgMult(hdr, HI_TPKT_HDR_LEN, buf);
   if(ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}/* end of hiAppendHdr() */

#ifdef HI_LPBK

/* Functions (hiLpBk*) specific to loopback mode */

/*
*
*       Fun:   hiLpBkInsServInLst
*
*       Desc:  This function is used to insert the server connection
*              block in the hash list on local transport address.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  hi_bdy2.c 
*
*/
#ifdef ANSI
PUBLIC S16 hiLpBkInsServInLst
(
HiConCb *conCb,
CmTptAddr *servTAddr,
CmTptParam *tPar
)
#else
PUBLIC S16 hiLpBkInsServInLst(conCb, servTAddr, tPar)
HiConCb *conCb;
CmTptAddr *servTAddr;
CmTptParam *tPar;
#endif
{

   HiSap   *sap;
   S16     ret;

   TRC2(hiLpBkInsServInLst)

   sap = conCb->sap;

   cmMemcpy((U8*)&(conCb->locAddr), (U8*)servTAddr, (U32) sizeof(CmTptAddr));

   HI_ZERO(&(conCb->conFd), (U32) sizeof(CmInetFd));

   /* hash the connection block on the local address */
   ret = cmHashListInsert(&hiCb.locAddrHlCp, (PTR)conCb, 
                          (U8 *)&(conCb->locAddr.u.ipv4TptAddr),
                          sizeof(CmIpv4TptAddr));
   if(ret != ROK)
   {
      HILOGERROR_DEBUG( EHI134, (ErrVal) ret, 0,
                 "hiLpBkInsServInLst(): failed to insert in addr hash list");

      /* de-allocate the connection block allocated */
      hiFreeConCb(conCb);
      HI_DISCIND(sap, HI_USER_CON_ID, conCb->suConId, HI_INTERNAL_ERR);
      RETVALUE(RFAILED);
   }

   /* Also hash the UDP connection block on ALL the mcast addresses */
   if(conCb->flag & HI_FL_UDP)
   {
      ret = hiLpBkProcMCastGrp(conCb, tPar);
      if(ret !=ROK)
      {
         hiFreeConCb(conCb);
         HI_DISCIND(sap, HI_USER_CON_ID, conCb->suConId, HI_INTERNAL_ERR);
         RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
}/* end of hiLpBkInsServInLst() */


/*
*
*       Fun:   hiLpBkSendTcpData   
*
*       Desc:  This function is used to send TCP data to the service
*              user.
*
*       Ret:   Void 
*
*       Notes: None
*
*       File:  hi_bdy2.c 
*
*/
#ifdef ANSI
PUBLIC Void hiLpBkSendTcpData
(
HiConCb *conCb,
Buffer  *mBuf
)
#else
PUBLIC Void hiLpBkSendTcpData(conCb, mBuf)
HiConCb *conCb;
Buffer  *mBuf;
#endif
{

   HiConCb     *pConCb;
   Buffer      *buf;
   U8          i;
   Bool        found;
   HiAlarmInfo info;
   S16         ret;
   
   TRC2(hiLpBkSendTcpData)

   i = 0;
   found = FALSE;
   info.spId  = conCb->sap->spId;
   info.type  = LHI_ALARMINFO_TYPE_NTPRSNT;

   /* Find out the other end's conCb */
   /* search for the pconCb using conCb.peerAddr */
   while((ret = cmHashListFind(&hiCb.locAddrHlCp, 
                              (U8 *)&(conCb->peerAddr.u.ipv4TptAddr), 
                              sizeof(CmIpv4TptAddr), i++, 
                              (PTR *)&pConCb)) == ROK)
   {
      if((!(pConCb->flag & HI_FL_UDP)) && 
            (pConCb->conState == HI_ST_CONNECTED) &&
            (!cmMemcmp((U8*)&conCb->locAddr.u.ipv4TptAddr, 
                       (U8*)&pConCb->peerAddr.u.ipv4TptAddr, 
                       sizeof(CmIpv4TptAddr))))
      {
         found = TRUE;
         break;
      }
   }

   if(found)
   {
      ret = SAddMsgRef(mBuf, conCb->sap->uiPst.region, 
                       conCb->sap->uiPst.pool, &buf);
      if(ret != ROK)
      {
         HI_FILL_ALARMINFO_MEM_ID(info, conCb->sap->uiPst.region,
                                  conCb->sap->uiPst.pool);
         hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                     LCM_CAUSE_UNKNOWN, &info);
         RETVOID;
      }

      /* issue a HitDatInd to the other end */
      HiUiHitDatInd(&pConCb->sap->uiPst, pConCb->sap->suId, 
                    pConCb->suConId, buf);
   }
   else
   {
      /* error case */
      HILOGERROR_DEBUG(EHI135, (ErrVal)0, 0,
                 "hiLpBkSendData() : Peer end not found");
      hiFreeConCb(conCb);
      HI_DISCIND(conCb->sap, HI_USER_CON_ID, conCb->suConId, HI_SOCK_SEND_ERR);
   }

   RETVOID;
}/* end of hiLpBkSendTcpData() */


/*
*
*       Fun:   hiLpBkSendUdpData
*
*       Desc:  This function is used to send UDP datain loopback mode
*
*       Ret:   Void 
*
*       Notes: None
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void hiLpBkSendUdpData
(
HiSap   *sap,
CmTptAddr *srcAddr,
CmTptAddr *remAddr,
Buffer *mBuf
)
#else
PUBLIC Void hiLpBkSendUdpData(sap, srcAddr, remAddr, mBuf)
HiSap   *sap;
CmTptAddr *srcAddr;
CmTptAddr *remAddr;
Buffer *mBuf;
#endif
{

   HiConCb     *srvConCb;
   U8          i;
   Buffer      *buf;
   HiAlarmInfo info;
   CmTptAddr   nullAddr;
   S16         ret;
   Bool        found;
   CmTptAddr   anyAddr;
#ifdef HI_REL_1_3  
   CmIpHdrParm  nullHdr;
#endif  /* HI_REL_1_3 */ 

   /* hi009.104 - added new local variable */
#ifdef LOCAL_INTF   
   CmTptLocalInf *localIf;  /* local intf on which pkt arrived */
#endif /* LOCAL_INTF */

   TRC2(hiLpBkSendUdpData)

   i = 0;
   found = FALSE;

   info.spId  = sap->spId;
   info.type  = LHI_ALARMINFO_TYPE_NTPRSNT;

   HI_LPBK_INIT_TPTADDR(remAddr);

   while(cmHashListFind(&hiCb.locAddrHlCp, 
                        (U8*)&(remAddr->u.ipv4TptAddr),
                        sizeof(CmIpv4TptAddr), i++, (PTR*)&srvConCb) == ROK)
   {
      found = TRUE;
      if((srvConCb->flag & HI_FL_UDP) && (srvConCb->flag & HI_FL_SRV))
      {
         ret = SAddMsgRef(mBuf, sap->uiPst.region, sap->uiPst.pool, &buf);
         if(ret != ROK)
         {
            HI_FILL_ALARMINFO_MEM_ID(info, sap->uiPst.region,
                                     sap->uiPst.pool);
            hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                        LCM_CAUSE_UNKNOWN, &info);
            RETVOID;
         }

         if(srcAddr)
         {

#ifdef HI_REL_1_3  
            HI_ZERO(&nullAddr, sizeof(CmTptAddr));
            nullAddr.type = CM_TPTADDR_NOTPRSNT;
            
            HI_ZERO(&nullHdr, sizeof(CmIpHdrParm));
            nullHdr.type = CM_HDRPARM_NOTPRSNT;

            /* hi009.104 - added new argument */
            HiUiHitUDatInd(&srvConCb->sap->uiPst, srvConCb->sap->suId, 
                           srvConCb->suConId, srcAddr, &nullAddr, &nullHdr, 
#ifdef LOCAL_INTF                           
                           localIf, 
#endif /* LOCAL_INTF */                           
                           buf);
#else   /* HI_REL_1_3 */ 
            HiUiHitUDatInd(&srvConCb->sap->uiPst, srvConCb->sap->suId, 
                           srvConCb->suConId, srcAddr, buf);

#endif  /* HI_REL_1_3 */ 
         }
         else
         {
            HI_ZERO(&nullAddr, sizeof(CmTptAddr));
            nullAddr.type = CM_TPTADDR_NOTPRSNT;
#ifdef HI_REL_1_3  
            HI_ZERO(&nullHdr, sizeof(CmIpHdrParm));
            nullHdr.type = CM_HDRPARM_NOTPRSNT;

            /* hi009.104 - added new argument */
            HiUiHitUDatInd(&srvConCb->sap->uiPst, srvConCb->sap->suId, 
                           srvConCb->suConId, &nullAddr, &nullAddr, &nullHdr, 
#ifdef LOCAL_INTF                           
                           localIf, 
#endif /* LOCAL_INTF */                           
                           buf);
#else   /* HI_REL_1_3 */ 
            HiUiHitUDatInd(&srvConCb->sap->uiPst, srvConCb->sap->suId, 
                           srvConCb->suConId, &nullAddr, buf);
#endif  /* HI_REL_1_3 */ 
         }
      }
   }/* end while */

   if (found == FALSE)
   {
      /* Check if we have a server listening to CM_INADDR_ANY and on the 
       * same port number as this */
      HI_ZERO(&anyAddr, sizeof(CmTptAddr));

      cmMemcpy((U8*)&anyAddr, (U8*)remAddr, sizeof(CmTptAddr));

      i = 0;

      /* Overwrite the address */
      anyAddr.u.ipv4TptAddr.address = CM_INADDR_ANY;
      
      ret = cmHashListFind(&hiCb.locAddrHlCp, 
                           (U8*)&(anyAddr.u.ipv4TptAddr),
                           sizeof(CmIpv4TptAddr), i++, (PTR*)&srvConCb);
      if (ret == ROK)
      {
         ret = SAddMsgRef(mBuf, sap->uiPst.region, sap->uiPst.pool, &buf);
         if(ret != ROK)
         {
            HI_FILL_ALARMINFO_MEM_ID(info, sap->uiPst.region,
                                     sap->uiPst.pool);
            hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_DMEM_ALLOC_FAIL,
                        LCM_CAUSE_UNKNOWN, &info);
            RETVOID;
         }

         if(srcAddr)
         {

#ifdef HI_REL_1_3  
            HI_ZERO(&nullAddr, sizeof(CmTptAddr));
            nullAddr.type = CM_TPTADDR_NOTPRSNT;

            HI_ZERO(&nullHdr, sizeof(CmIpHdrParm));
            nullHdr.type = CM_HDRPARM_NOTPRSNT;

            /* hi009.104 - added new argument */
            HiUiHitUDatInd(&srvConCb->sap->uiPst, srvConCb->sap->suId, 
                           srvConCb->suConId, srcAddr, &nullAddr, &nullHdr, 
#ifdef LOCAL_INTF                           
                           localIf, 
#endif /* LOCAL_INTF */                            
                           buf);
#else /* HI_REL_1_3 */ 
            HiUiHitUDatInd(&srvConCb->sap->uiPst, srvConCb->sap->suId, 
                           srvConCb->suConId, srcAddr, buf);
#endif /* HI_REL_1_3 */ 
         }
         else
         {
#ifdef HI_REL_1_3  
            HI_ZERO(&nullAddr, sizeof(CmTptAddr));
            nullAddr.type = CM_TPTADDR_NOTPRSNT;

            HI_ZERO(&nullHdr, sizeof(CmIpHdrParm));
            nullHdr.type = CM_HDRPARM_NOTPRSNT;

            /* hi009.104 - added new argument */
            HiUiHitUDatInd(&srvConCb->sap->uiPst, srvConCb->sap->suId, 
                           srvConCb->suConId, &nullAddr, &nullAddr, &nullHdr, 
#ifdef LOCAL_INTF                             
                           localIf, 
#endif /* LOCAL_INTF */                            
                           buf);
#else   /* HI_REL_1_3 */ 

            HI_ZERO(&nullAddr, sizeof(CmTptAddr));
            nullAddr.type = CM_TPTADDR_NOTPRSNT;
            HiUiHitUDatInd(&srvConCb->sap->uiPst, srvConCb->sap->suId, 
                           srvConCb->suConId, &nullAddr, buf);
#endif /* HI_REL_1_3 */ 
         }
      }
   }

   RETVOID;
}/* end of hiLpBkSendUdpData() */


/*
*
*       Fun:   hiLpBkProcMCastGrp
*
*       Desc:  This function is used to process join / leave to 
*              a IP multicast group.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c 
*
*/
#ifdef ANSI
PUBLIC S16 hiLpBkProcMCastGrp
(
HiConCb *conCb,
CmTptParam *tPar
)
#else
PUBLIC S16 hiLpBkProcMCastGrp(conCb, tPar)
HiConCb *conCb;
CmTptParam *tPar;
#endif
{

   CmTptAddr    mCastAddr;
   HiConCb      *mCastConCb;
   HiAlarmInfo  info;
   S16          ret;
   U8           i;
   U8           seqNum;

   TRC2(hiLpBkProcMCastGrp)

   seqNum = 0;
   mCastConCb = NULLP;
   info.spId = conCb->sap->spId;
   info.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   if (tPar->type == CM_TPTPARAM_NOTPRSNT)
      RETVALUE(ROK);

   /* Initialize the address */
   HI_ZERO(&mCastAddr, sizeof(CmTptAddr));

   for (i=0; i<tPar->u.sockParam.numOpts; i++)
   {
      CmSockOpts *sOpts = &(tPar->u.sockParam.sockOpts[i]);

      if(sOpts->option == CM_SOCKOPT_OPT_ADD_MCAST_MBR)
      {
         conCb->flag |= HI_FL_MCAST_CONCB;
         HI_ALLOC(sizeof(HiConCb), mCastConCb);
         if(!mCastConCb)
         {
            /* Fill up the alarm information */
            HI_FILL_ALARMINFO_MEM_ID(info, hiCb.hiInit.region, 
                                     hiCb.hiInit.pool);
            hiSendAlarm(LCM_CATEGORY_RESOURCE, LCM_EVENT_SMEM_ALLOC_FAIL,
                        LCM_CAUSE_UNKNOWN, &info);
            RETVALUE(RFAILED);
         }
         cmMemcpy((U8*)mCastConCb, (U8*)conCb, sizeof(HiConCb));

         /* Initialize the local address as the mcast address */
         mCastConCb->locAddr.type = CM_TPTADDR_IPV4;
#ifdef HI_REL_1_3
         cmMemcpy((U8*)&(mCastConCb->locAddr.u.ipv4TptAddr.address), 
                  (U8*)&(sOpts->optVal.mCastInfo.mCastAddr.u.ipv4NetAddr),
                  sizeof(CmInetIpAddr));
#else
         cmMemcpy((U8*)&(mCastConCb->locAddr.u.ipv4TptAddr.address), 
                  (U8*)&(sOpts->optVal.mCastAddr.u.ipv4NetAddr),
                  sizeof(CmInetIpAddr));
#endif /* HI_REL_1_3 */

         mCastConCb->locAddr.u.ipv4TptAddr.port = 
                                  conCb->locAddr.u.ipv4TptAddr.port; 

         /* insert the new connection block in the hash list */
         ret = cmHashListInsert(&hiCb.locAddrHlCp, (PTR)mCastConCb, 
                         (U8 *)&(mCastConCb->locAddr.u.ipv4TptAddr),
                         sizeof(CmIpv4TptAddr));
         if(ret != ROK)
         {
            HILOGERROR_DEBUG( EHI136, (ErrVal) ret, 0,
                   "hiLpBkProcMCastGrp():failed to insert in addr hash list");
            HI_FREE(sizeof(HiConCb), mCastConCb);
            RETVALUE(RFAILED);
         }
      }
      else if(sOpts->option == CM_SOCKOPT_OPT_DRP_MCAST_MBR)
      {
         mCastAddr.type = CM_TPTADDR_IPV4;
#ifdef HI_REL_1_3
         mCastAddr.u.ipv4TptAddr.address = 
                       sOpts->optVal.mCastInfo.mCastAddr.u.ipv4NetAddr;
#else
         mCastAddr.u.ipv4TptAddr.address = 
                       sOpts->optVal.mCastAddr.u.ipv4NetAddr;
#endif /* HI_REL_1_3 */
         mCastAddr.u.ipv4TptAddr.port =
                       conCb->locAddr.u.ipv4TptAddr.port;

         while((ret = cmHashListFind(&hiCb.locAddrHlCp, 
                                    (U8*)&(mCastAddr.u.ipv4TptAddr),
                                    sizeof(CmIpv4TptAddr), seqNum++,
                                    (PTR*)&mCastConCb)) == ROK)
         {
            if(mCastConCb->suConId == conCb->suConId)
            {
               (Void)cmHashListDelete(&hiCb.locAddrHlCp, (PTR)mCastConCb);
               HI_FREE(sizeof(HiConCb), mCastConCb);
            }
         }
      }/* end if */
   }/* end for loop */

   RETVALUE(ROK);

}/* end of hiLpBkProcMCastGrp() */

#endif /* HI_LPBK */


/*
*
*       Fun:   hiProcRxHdr
*
*       Desc:  This function is used to process the received application
*              header in the received TCP data.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c 
*
*/
#ifdef ANSI
PUBLIC S16 hiProcRxHdr
(
HiConCb *conCb,
Buffer *mBuf
)
#else
PUBLIC S16 hiProcRxHdr(conCb, mBuf)
HiConCb *conCb;
Buffer *mBuf;
#endif
{

   U8          arr[HI_MAX_HDR_LEN];
   HiHdrInfo   *hdr;
   HiAlarmInfo info;
   U16         len1;
   U32         len;
   U16         i;
   MsgLen      msgLen;

   TRC2(hiProcRxHdr)

   /* Variable initializations */
   len     = 0;
   len1    = 0;

   /* initialize alarm info structure */
   info.spId = conCb->sap->spId;
   info.type = LHI_ALARMINFO_TYPE_NTPRSNT;
  
   if(SFndLenMsg(mBuf, &msgLen) != ROK)
   {
      /* Increment the statistics counter */
      hiCb.errSts.rxMsgVerErr++;

      HI_FILL_ALARMINFO_MEM_ID(info, conCb->sap->uiPst.region,
                               conCb->sap->uiPst.pool);

      hiSendAlarm(LCM_CATEGORY_PROTOCOL, LCM_EVENT_PI_INV_EVT,
                  LCM_CAUSE_DECODE_ERR, &info); 
      
      /* Discard the received data */
      (Void)SPutMsg(mBuf);
      
      RETVALUE(RFAILED);
   }

#ifdef HI_REL_1_3
   if((conCb->srvcType == HI_SRVC_TCP_TPKT_HDR) ||
      (conCb->srvcType == HI_SRVC_UDP_TPKT_HDR))
#else
   if(conCb->srvcType == HI_SRVC_TCP_TPKT_HDR)
#endif /* HI_REL_1_3 */
   {
      /* If the message header has not come */
      if (msgLen < HI_TPKT_HDR_LEN)
      {
         /* less than header length is received */
         conCb->awaitHdr = TRUE;
         conCb->pendLen = 0;
         RETVALUE(ROK);
      }
      else
         conCb->awaitHdr = FALSE;

      /* extract the header */
      SRemPreMsgMult(arr, HI_TPKT_HDR_LEN, mBuf);

      if(arr[0] != HI_TPKT_HDR_VERSION)
      {
         /* increment the statistics counter */
         hiCb.errSts.rxMsgVerErr++;

         /* discard the received data */
         (Void)SPutMsg(mBuf);
            
         /* raise an alarm to the layer manager */
         hiSendAlarm(LCM_CATEGORY_PROTOCOL, LCM_EVENT_PI_INV_EVT,
                     LCM_CAUSE_DECODE_ERR, &info); 

         RETVALUE(RFAILED);
      }

      /* obtain the packet length from the header */
      len1 = PutHiByte(len1, arr[2]);
      len1 = PutLoByte(len1, arr[3]);

      /* initialize the length variables in conCb */
      conCb->pendLen = len1 - HI_TPKT_HDR_LEN;
      conCb->rxLen  -= HI_TPKT_HDR_LEN;
   }
   else /* other TCP header types */
   {
#ifdef HI_REL_1_3  
      hdr = &conCb->sap->cfg.hdrInf[(conCb->srvcType >> HI_SRVCTYPE_MASK) - 1];
#else   
      hdr = &conCb->sap->cfg.hdrInf[conCb->srvcType - 3];
#endif /* HI_REL_1_3 */ 

      if ((U32)msgLen < hdr->hdrLen)
      {
         conCb->awaitHdr = TRUE;
         conCb->pendLen = 0;
         RETVALUE(ROK);
      }
      else
         conCb->awaitHdr = FALSE;

      /* extract the header */
      SRemPreMsgMult(arr, (S16)hdr->hdrLen, mBuf);

      /* obtain the packet length from the header */
      if(hdr->lenLen == 1)
      {
         len = arr[hdr->offLen];
         conCb->pendLen = len;
      }
      else if(hdr->lenLen == 2)
      {
         len1 = PutHiByte(len1, arr[hdr->offLen]);
         len1 = PutLoByte(len1, arr[hdr->offLen+1]);
         conCb->pendLen = len1;
      }
      else 
      {
         len1 = PutHiByte(len1, arr[hdr->offLen]);
         len1 = PutLoByte(len1, arr[hdr->offLen+1]);
         len  = PutHiWord(len, len1);
         len1 = PutHiByte(len1, arr[hdr->offLen+2]);
         len1 = PutLoByte(len1, arr[hdr->offLen+3]);
         len  = PutLoWord(len, len1);

         if(hdr->lenLen == 3)
            len >>= 8;

         conCb->pendLen = len;
      }

      if(!(hdr->flag & LHI_LEN_INCL_HDR))
         conCb->pendLen += hdr->hdrLen;
       
      /* append back the header */
      for(i = hdr->hdrLen; i>0; i--)
         if(SAddPreMsg(arr[i-1], mBuf) != ROK)
         {
            /* discard the received data */
            (Void)SPutMsg(mBuf);

            HI_FILL_ALARMINFO_MEM_ID(info, conCb->sap->uiPst.region,
                              conCb->sap->uiPst.pool);
            hiSendAlarm(LCM_CATEGORY_PROTOCOL, LCM_EVENT_PI_INV_EVT,
                        LCM_CAUSE_DECODE_ERR, &info); 
            RETVALUE(RFAILED);
         }
   }
   RETVALUE(ROK);
}/* end of hiProcRxHdr() */


#ifndef HI_LPBK

/*
*  
*       Fun:   hiFdSet 
* 
*       Desc:  This function is used to set the socket in the  
*              appropriate file descriptor block.
*
*              In the multi-threaded case, TUCL will send a message to the 
*              receive threads to add the conCb to its file descriptor set.
* 
*       Ret:   ROK
*              RFAILED
* 
*       Notes: None 
* 
*       File:  hi_bdy2.c 
* 
*/
#ifdef ANSI
PUBLIC S16 hiFdSet
(
HiConCb *conCb
)
#else
PUBLIC S16 hiFdSet(conCb)
HiConCb *conCb;
#endif
{

   S16         ret;
   HiAlarmInfo alInfo;
#ifndef HI_MULTI_THREADED
   HiFdGrpInfo *grpInfoPtr;
#endif /* HI_MULTI_THREADED */

   TRC2(hiFdSet);

   alInfo.spId = conCb->sap->spId;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

#ifdef HI_MULTI_THREADED
   /* Add the conCb in the to be added linked list */
   ret = hiAddConCbToCmList(conCb, HI_CM_TOBEADD_LIST);
   if (ret != ROK)
      RETVALUE(RFAILED);
#else

   grpInfoPtr = hiCb.hiFdGrpInfoLstPtr[conCb->fdBlkIdx];

   /* insert this connection control block in the file descriptor
    * block hash list */
   ret = cmHashListInsert(&(grpInfoPtr->grpCb.rdFdHlCp), (PTR)conCb, 
                          (U8 *)&(conCb->conFd.fd), sizeof(CmInetFdType));
   if (ret != ROK) 
   {
      hiSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_INV_EVT,
                  LCM_CAUSE_HASH_FAIL, &alInfo);
      RETVALUE(RFAILED);
   }

   /* Set the file descriptor group in the read file descriptor set 
    */
   CM_INET_FD_SET(&(conCb->conFd), &(grpInfoPtr->grpCb.readFdSet));
   conCb->isInList |= HI_CONCB_IN_READ_LIST;
         
   if (conCb->conState == HI_ST_CLT_CONNECTING)
   {
      /* Set the file descriptor group in the 
       * write file descriptor set */
      CM_INET_FD_SET(&(conCb->conFd), &(grpInfoPtr->grpCb.writeFdSet));
      /* Insert this connection control block in the write
       * file descriptor block hash list */
      ret = cmHashListInsert(&(grpInfoPtr->grpCb.wrFdHlCp),
                             (PTR)conCb, (U8 *)&(conCb->conFd.fd), 
                              sizeof(CmInetFdType));
      if (ret != ROK) 
      {
         hiSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_INV_EVT,
                     LCM_CAUSE_HASH_FAIL, &alInfo);
         hiDelFrmFdGrp(grpInfoPtr, conCb, HI_FDGRP_READ_LIST);
         /* hi002.104 - Using new macro to clear fd from fd_set */
         HI_DEL_FRM_FDSET(grpInfoPtr, conCb, HI_FDGRP_BOTH_LIST);
         RETVALUE(RFAILED);
      }
      grpInfoPtr->grpCb.numWrFds += 1;
      conCb->isInList |= HI_CONCB_IN_WRITE_LIST;
   }
#endif /* HI_MULTI_THREADED */

   RETVALUE(ROK);
} /* end of hiFdSet() */


/*
* 
*       Fun:   hiFdClr
* 
*       Desc:  This function is used to clear the socket from the
*              appropriate file descriptor block.
*
*              Incase of multi-threaded case a message is sent to the 
*              appropriate receive thread.
* 
*       Ret:   ROK
*              RFAILED
* 
*       Notes: None
* 
*       File:  hi_bdy2.c
* 
*/
#ifdef ANSI
PUBLIC S16 hiFdClr
(
HiConCb *conCb,              /* connection block */
S32     flag                 /* type of fd to be cleared */
)
#else
PUBLIC S16 hiFdClr(conCb, flag)
HiConCb *conCb;              /* connection block */
S32     flag;                /* type of fd to be cleared */
#endif
{

#ifndef HI_REL_1_3
   HiSap      *sap;
#endif /* HI_REL_1_3 */
#ifdef HI_MULTI_THREADED
   S16         ret;
#else
   U16        i;
   HiFdGrpInfo *grpInfoPtr;
   CmLListCp  *lCp;
#endif /* HI_MULTI_THREADED */

   TRC2(hiFdClr)

   /* check the type of clear requested */
#ifdef HI_MULTI_THREADED
   /* Add the connection control block in the to be deleted list. */
   ret = hiAddConCbToCmList(conCb, HI_CM_TOBEDEL_LIST);
   if (ret != ROK)
      RETVALUE(ret);
#else
   /* Variable initializations */
   i = conCb->fdBlkIdx;
   lCp = &hiCb.llstCp;
   grpInfoPtr = hiCb.hiFdGrpInfoLstPtr[i];

   /* Clear the file descriptors as needed */
   if (flag == CM_INET_SHTDWN_RECV)
      /* clear this socket descriptor in the read fd set */
      /* hi002.104 - Remove fd from fd_set */
      HI_DEL_FRM_FDSET(grpInfoPtr, conCb, HI_FDGRP_READ_LIST)
   else if (flag == CM_INET_SHTDWN_SEND)
      /* clear this socket descriptor from the write fd set */
      /* hi002.104 - Remove fd from fd_set */
      HI_DEL_FRM_FDSET(grpInfoPtr, conCb, HI_FDGRP_WRITE_LIST)
   else
      /* clear the socket descrptor from both the read and write list */
      /* hi002.104 - Remove fd from fd_set */
      HI_DEL_FRM_FDSET(grpInfoPtr, conCb, HI_FDGRP_BOTH_LIST)

#ifndef HI_REL_1_3
   sap = conCb->sap;
#endif /* HI_REL_1_3 */
   if ((flag == CM_INET_SHTDWN_BOTH) || (flag == CM_INET_SHTDWN_SEND))
   {
      /* check if there is any data to be transmitted */
      if (conCb->txQSiz)
      {
         /* flush the transmit queue */
         SFlushQueue(&conCb->txQ);
 
         conCb->txQSiz = 0;
#ifndef HI_REL_1_3
         sap->currTxQSiz -= conCb->txQSiz;
#endif /* HI_REL_1_3 */
         /* delete the control block if it is not marked for deletion */ 
         if (conCb->isInList &= HI_CONCB_IN_SCANCON_LIST)
         {
            if (!conCb->toBeDel)
            {
               cmLListDelFrm(lCp, (CmLList *)&conCb->llEnt);
               conCb->isInList &= ~(HI_CONCB_IN_SCANCON_LIST);
            }/* end if */
         }
      }/* end if */
   }/* end if */
#endif /* HI_MULTI_THREADED */

   RETVALUE(ROK);
} /* end of hiFdClr() */

#endif /* HI_LPBK */


/*
*
*       Fun:   hiInitFdGrp
*
*       Desc:  This function initialises the file descriptor group
*
*       Ret:   ROK 
*              RFAILED 
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16  hiInitFdGrp
(
HiFdGrpInfo    *grpInfoPtr,      /* File descriptor information */
U16            fdGrpNum          /* This number */
)
#else
PUBLIC S16  hiInitFdGrp(grpInfoPtr, fdGrpNum) 
HiFdGrpInfo    *grpInfoPtr;      /* File descriptor information */
U16            fdGrpNum;         /* This number */
#endif
{
   HiFdGrpCb      *grpCb;
   S16            ret;

#ifdef HI_MULTI_THREADED     
   CmInetAddr     udpServAddr;
#endif /* HI_MULTI_THREADED      */

   TRC2(hiInitFdGrp)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (grpInfoPtr == NULLP)
   {
      HILOGERROR_DEBUG(EHI137, 0, 0,
            "hiInitFdGrp - Null pointer passed \n");

      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */

   grpInfoPtr->numFds = 0;

   grpCb = &grpInfoPtr->grpCb;

   HI_ALLOC((hiCb.cfg.numSaps * sizeof(HiRxSts)), grpCb->rxStsArr);
   if (!grpCb->rxStsArr)
      RETVALUE(RFAILED);

#ifdef HI_FAST_FIND 
   /* Allocate memory for file descriptor information */
   HI_ALLOC(sizeof(CmInetFdSetInfo), grpCb->rdFdSetInfo);
   if (!grpCb->rdFdSetInfo)
   {
      HI_FREE((hiCb.cfg.numSaps * sizeof(HiRxSts)), grpCb->rxStsArr);
      RETVALUE(RFAILED);
   }

   ret = cmInetFdSetInfoInit(grpInfoPtr->grpCb.rdFdSetInfo);
   if (ret != ROK)
   {
      HI_FREE((hiCb.cfg.numSaps * sizeof(HiRxSts)),      grpCb->rxStsArr);
      HI_FREE(sizeof(CmInetFdSetInfo), grpInfoPtr->grpCb.rdFdSetInfo); 
      RETVALUE(ret);
   }
#endif /* HI_FAST_FIND */

   /* Initialize read file descriptor hashlist */
   /* hi024.104: Reverting keytype to DEF */
   ret = cmHashListInit(&(grpCb->rdFdHlCp),
                           hiCb.numFdBins,         /* bins */
                           HI_GET_OFFSET(HiConCb, rdFdHlEnt), /* Offset of HL 
                                                                 Entry */
                           TRUE,                   /* Allow dup. keys T? */  
                           CM_HASH_KEYTYPE_DEF, /* HL Key type */
                           hiCb.hiInit.region,     /* Mem region for HL */
                           hiCb.hiInit.pool);      /* Mem pool for HL */
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI138, (ErrVal)ret, 0,
      "hiInitFdGrp : Failed to initialise read fd hashlist \n");
      HI_FREE((hiCb.cfg.numSaps * sizeof(HiRxSts)),      grpCb->rxStsArr);
#ifdef HI_FAST_FIND 
      HI_FREE(sizeof(CmInetFdSetInfo), grpInfoPtr->grpCb.rdFdSetInfo); 
#endif  /* HI_FAST_FIND  */
      RETVALUE(RFAILED);
   }

   /* Initialize the write file descriptor hashlist */
   /* hi024.104: Reverting keytype to DEF */
   ret = cmHashListInit(&(grpCb->wrFdHlCp),
                           hiCb.numFdBins,         /* bins */
                           HI_GET_OFFSET(HiConCb, wrFdHlEnt), /* Offset of HL 
                                                                 Entry */
                           TRUE,                   /* Allow dup. keys T? */  
                           CM_HASH_KEYTYPE_DEF, /* HL Key type */
                           hiCb.hiInit.region,     /* Mem region for HL */
                           hiCb.hiInit.pool);      /* Mem pool for HL */
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI139, (ErrVal)ret, 0,
      "hiInitFdGrp : Failed to initialise write fd hashlist \n");
      HI_FREE((hiCb.cfg.numSaps * sizeof(HiRxSts)),      grpCb->rxStsArr);
#ifdef HI_FAST_FIND 
      HI_FREE(sizeof(CmInetFdSetInfo), grpInfoPtr->grpCb.rdFdSetInfo); 
#endif  /* HI_FAST_FIND  */
      cmHashListDeinit(&grpCb->rdFdHlCp);
      RETVALUE(RFAILED);
   }

   /* Clear the read and write file descriptor sets */
   CM_INET_FD_ZERO(&grpCb->readFdSet);
   CM_INET_FD_ZERO(&grpCb->writeFdSet);
   grpCb->numWrFds = 0;

#ifdef HI_MULTI_THREADED      
   /* Open a UDP server on a IP loopack address with a generic port 
    * number. Store the generic port number and address in the fd grp
    * info structure.
    */
#ifdef IPV6_SUPPORTED
   ret = cmInetSocket(CM_INET_DGRAM, &grpCb->servFd, 0, CM_INET_IPV4_DOMAIN); 
#else
   ret = cmInetSocket(CM_INET_DGRAM, &grpCb->servFd, 0); 
#endif /* IPV6_SUPPORTED */
   if (ret != ROK)
   {
      HI_FREE((hiCb.cfg.numSaps * sizeof(HiRxSts)),      grpCb->rxStsArr);
#ifdef HI_FAST_FIND 
      HI_FREE(sizeof(CmInetFdSetInfo), grpInfoPtr->grpCb.rdFdSetInfo); 
#endif  /* HI_FAST_FIND  */
      cmHashListDeinit(&grpCb->rdFdHlCp);
      cmHashListDeinit(&grpCb->wrFdHlCp);
      RETVALUE(RFAILED);
   }
 
   HI_ZERO(&udpServAddr, sizeof(udpServAddr));

   /* Initialise the servers listening address */
#ifdef IPV6_SUPPORTED 
   udpServAddr.type = CM_INET_IPV4ADDR_TYPE;
   udpServAddr.u.ipv4Addr.port = HI_UDP_RESV_PORT;
   udpServAddr.u.ipv4Addr.address = HI_UDP_RESV_ADDR;
#else
   udpServAddr.port = HI_UDP_RESV_PORT;
   udpServAddr.address = HI_UDP_RESV_ADDR;
#endif /* IPV6_SUPPORTED */

   /* Bind the socket to an address */
   ret = cmInetBind(&grpCb->servFd, (CmInetAddr *)&(udpServAddr));
   if (ret != ROK)
   {
      HI_CLOSE_SOCKET(&grpCb->servFd);
      HI_FREE((hiCb.cfg.numSaps * sizeof(HiRxSts)),      grpCb->rxStsArr);
#ifdef HI_FAST_FIND 
      HI_FREE(sizeof(CmInetFdSetInfo), grpInfoPtr->grpCb.rdFdSetInfo); 
#endif  /* HI_FAST_FIND  */
      cmHashListDeinit(&grpCb->rdFdHlCp);
      cmHashListDeinit(&grpCb->wrFdHlCp);
      RETVALUE(RFAILED);
   }

   /* Get the address the socket is bound to and store it */
   ret = cmInetGetSockName(&grpCb->servFd, &(grpInfoPtr->servAddr));
   if (ret != ROK)
   {
      HI_CLOSE_SOCKET(&grpCb->servFd);
      HI_FREE((hiCb.cfg.numSaps * sizeof(HiRxSts)),      grpCb->rxStsArr);
#ifdef HI_FAST_FIND 
      HI_FREE(sizeof(CmInetFdSetInfo), grpInfoPtr->grpCb.rdFdSetInfo); 
#endif  /* HI_FAST_FIND  */
      cmHashListDeinit(&grpCb->rdFdHlCp);
      cmHashListDeinit(&grpCb->wrFdHlCp);
      RETVALUE(RFAILED);
   }

   /* Initialise the common information part */

   /* Initialise the new connection control block list */
   cmLListInit(&grpInfoPtr->cmGrpCb.newConCbLst);

   /* Initialise the new connection control block list */
   cmLListInit(&grpInfoPtr->cmGrpCb.toBeDelLst);

   /* Initialise the new connection control block list */
   cmLListInit(&grpInfoPtr->cmGrpCb.txQCongLst);

   /* Initialise the lock to access the common information */
   ret = SInitLock(&grpInfoPtr->cmInfoLock, SS_LOCK_MUTEX);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI140, (ErrVal)ret, 0,
      "hiInitFdGrp : Failed to initialise common lock \n");
      HI_FREE((hiCb.cfg.numSaps * sizeof(HiRxSts)),      grpCb->rxStsArr);
#ifdef HI_FAST_FIND 
      HI_FREE(sizeof(CmInetFdSetInfo), grpInfoPtr->grpCb.rdFdSetInfo); 
#endif  /* HI_FAST_FIND  */
      HI_CLOSE_SOCKET(&grpCb->servFd);
      cmHashListDeinit(&grpCb->rdFdHlCp);
      cmHashListDeinit(&grpCb->wrFdHlCp);
      RETVALUE(RFAILED);
   }

   /* Set the reserved file descriptor in the read fd_set */
   CM_INET_FD_SET(&(grpInfoPtr->grpCb.servFd), 
                  &(grpInfoPtr->grpCb.readFdSet));

   grpInfoPtr->thisInst = hiCb.lastInstUsed + fdGrpNum;
   grpInfoPtr->thisInst += 1;

   /* The number of descriptors set now is 1 */
   grpInfoPtr->numFds += 1;

#endif /* HI_MULTI_THREADED */

#ifdef HI_REL_1_3
   grpInfoPtr->procIcmp = FALSE;
   /* Group 0 will have the ICMP file descriptor by default. Incase
    * if IPV6 support is present the IPV6 socket will also be handled */ 
   if (fdGrpNum == 0)
#ifdef IPV6_SUPPORTED
   {
      grpInfoPtr->numFds += 2;
      grpInfoPtr->procIcmp6 = FALSE;
   }
#else
      grpInfoPtr->numFds += 1;
#endif /* IPV6_SUPPORTED */
#endif /* HI_REL_1_3 */   

   RETVALUE(ROK);
} /* end of hiInitFdGrp */


/*
*
*       Fun:   hiDeInitFdGrp
*
*       Desc:  This function walks through the read and write hash list.
*              This function will give a disconnect indication to the 
*              upper user.
*
*       Ret:   ROK 
*              RFAILED 
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16  hiDeInitFdGrp
(
HiFdGrpInfo       *grpInfoPtr
)
#else
PUBLIC S16  hiDeInitFdGrp(grpInfoPtr) 
HiFdGrpInfo       *grpInfoPtr;
#endif
{
   HiConCb        *conCb;
   S16            ret;
   S16            retLock;
   CmHashListCp   *crntRdBlkHlCp;
   CmHashListCp   *crntWrBlkHlCp;

   TRC2(hiDeInitFdGrp);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (grpInfoPtr == NULLP)
   {
      HILOGERROR_DEBUG(EHI141, 0, 0, 
         "hiDeInitFdGrp : Passing NULL pointer \n");

      RETVALUE(RFAILED);
   }
#endif /* ERRCLS_DEBUG */

   HI_FREE((hiCb.cfg.numSaps * sizeof(HiRxSts)), grpInfoPtr->grpCb.rxStsArr);

#ifdef HI_FAST_FIND 
   /* De allocate memory for read fd set info */
   HI_FREE(sizeof(CmInetFdSetInfo), grpInfoPtr->grpCb.rdFdSetInfo);
#endif /* HI_FAST_FIND */

#ifdef HI_MULTI_THREADED     
   /* Remove the UDP server from the hashlist */
   CM_INET_FD_CLR(&grpInfoPtr->grpCb.servFd, 
                  &grpInfoPtr->grpCb.readFdSet);

   /* Close the UDP server */
   cmInetClose(&grpInfoPtr->grpCb.servFd);

   /* Zero the server address */
   HI_ZERO(&grpInfoPtr->servAddr, sizeof(grpInfoPtr->servAddr));
   
   /* Destroy the common lock */
   SDestroyLock(&grpInfoPtr->cmInfoLock);
#endif /* HI_MULTI_THREADED */
   
   crntRdBlkHlCp = &grpInfoPtr->grpCb.rdFdHlCp;
   crntWrBlkHlCp = &grpInfoPtr->grpCb.wrFdHlCp;

   conCb = NULLP;
   ret = retLock = RFAILED;

   CM_INET_FD_ZERO(&grpInfoPtr->grpCb.readFdSet);
   CM_INET_FD_ZERO(&grpInfoPtr->grpCb.writeFdSet);

   /* Delete all connection control blocks from write hash list */
   while ((ret = cmHashListGetNext(crntWrBlkHlCp, NULLP,
                  (PTR *) &conCb)) == ROK)
   {
      cmHashListDelete(crntWrBlkHlCp, (PTR) conCb);
   }

   grpInfoPtr->grpCb.numWrFds = 0;

   /* Deinitialise the write file descriptor hash list */
   (Void) cmHashListDeinit(&grpInfoPtr->grpCb.wrFdHlCp);

   conCb = NULLP;
   
   while ((ret = cmHashListGetNext(crntRdBlkHlCp, NULLP,
                  (PTR *) &conCb)) == ROK)
   {
      cmHashListDelete(crntRdBlkHlCp, (PTR) conCb);

   } /* end of read hlCp walk */ 
   
   /* Deinitialise the write file descriptor hash list */
   (Void) cmHashListDeinit(&grpInfoPtr->grpCb.rdFdHlCp);

   RETVALUE(ROK);

} /* end of hiDeInitFdGrp */


/*
*  
*       Fun:   hiDelFrmFdGrp
* 
*       Desc:  This function will delete the conCb 
*              from the appropriate file descriptor sets
*
*       Ret:   ROK
*              RFAILED
* 
*       Notes:
*
*       File:  hi_bdy2.c 
* 
*/
#ifdef ANSI
PUBLIC Void hiDelFrmFdGrp
(
HiFdGrpInfo    *grpInfoPtr,    /* group information */
HiConCb        *conCb,         /* connection control block */
U8             conList         /* list the conCb should be deleted from */
)
#else
/* hi008.104 - change list to conList */
PUBLIC Void hiDelFrmFdGrp(grpInfoPtr, conCb, conList)
HiFdGrpInfo    *grpInfoPtr;    /* group information */
HiConCb        *conCb;         /* connection control block */
U8             conList;        /* list the conCb should be deleted from */
#endif
{

   TRC2(hiDelFrmFdGrp);

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (!grpInfoPtr)
   {
      HILOGERROR_INT_PAR(EHI142, 0, 0,
                 "hiDelFrmFdGrp - Null group information pointer \n");
      RETVOID;
   }

   if (!conCb)
   {
      HILOGERROR_INT_PAR(EHI143, 0, 0,
                 "hiDelFrmFdGrp - Invalid connection control block \n");
      RETVOID;
   }
#endif /* ERRCLS_INT_PAR */

   /* hi007.104 - change list to conList */
   if (conList & HI_FDGRP_READ_LIST)                          
   {                                                        
      if (conCb->isInList & HI_CONCB_IN_READ_LIST)         
      {  
         /* Delete the conCb from the read hash list and 
          * from the read file descriptor set */
         cmHashListDelete(&grpInfoPtr->grpCb.rdFdHlCp,     
                         (PTR)conCb);                      
         /* hi002.104 - file-descriptor no longer cleared in this function */
         conCb->isInList &= ~(HI_CONCB_IN_READ_LIST);   
      }                                                
   }
   
   /* hi007.104 - change list to conList */
   if (conList & HI_FDGRP_WRITE_LIST)                 
   {                                                        
      if (conCb->isInList & HI_CONCB_IN_WRITE_LIST)        
      {                                                     
         /* Delete the conCb from the write hash list and 
          * from the write file descriptor set */
         cmHashListDelete(&grpInfoPtr->grpCb.wrFdHlCp,     
                          (PTR)conCb);                     
         /* hi002.104 - file-descriptor no longer cleared in this function */
         grpInfoPtr->grpCb.numWrFds -= 1;                   
         conCb->isInList &= ~(HI_CONCB_IN_WRITE_LIST);        
      }                                                     
   }

   RETVOID;
} /* end of hiDelFrmFdGrp */


/*
*  
*       Fun:   hiGetFdBlkIdx
* 
*       Desc:  This function is used to get the next file descriptor block 
*              index.
* 
*       Ret:   ROK
*              RFAILED
* 
*       Notes: None 
* 
*       File:  hi_bdy2.c 
* 
*/
#ifdef ANSI
PUBLIC S16 hiGetFdBlkIdx
(
HiConCb  *conCb,           /* file descriptor block index */
U16      *fdBlkIdx         /* service provider connection id */ 
)
#else
PUBLIC S16 hiGetFdBlkIdx(conCb, fdBlkIdx)
HiConCb  *conCb;           /* file descriptor block index */
U16      *fdBlkIdx;        /* service provider connection id */ 
#endif
{
   U16         i;
   U16         strtIdx;
   HiAlarmInfo alInfo;
#ifdef HI_MULTI_THREADED     
   S16         ret;
#endif /* HI_MULTI_THREADED */

   TRC2(hiGetFdBlkIdx);

   /* Variable initializations */
   alInfo.spId = conCb->sap->spId;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

#ifdef HI_MULTI_THREADED     
   HI_LOCK(&hiCb.grpLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI144, (ErrVal) ret, conCb->sap->uiPst.srcInst,
                "hiFdSet(): cannot obtain group lock \n");
      RETVALUE(RFAILED);
   }

   strtIdx = hiCb.lastGrpUsed + 1;
#else
   strtIdx = 0;
#endif /* HI_MULTI_THREADED */
   
   /* search for a fdset to set the socket in */
   for(i = 0; i < hiCb.numFdGrps; i++)
   {
      if (strtIdx >= hiCb.numFdGrps)
         strtIdx = 0;

#ifdef HI_MULTI_THREADED      
      /* There should be no holes in the InfoLst */
      if (!hiCb.hiFdGrpInfoLstPtr[strtIdx])
      {
         /* Unlock the group lock structure */
         HI_UNLOCK(&hiCb.grpLock, alInfo, ret) 
         if (ret != ROK)
            HILOGERROR_DEBUG(EHI145, (ErrVal)ret, conCb->sap->uiPst.srcInst,
                  "hiGetFdBlkIdx - Could not unlock group lock \n");
         RETVALUE(RFAILED);
      }
#endif /* HI_MULTI_THREADED */
      
      if(hiCb.hiFdGrpInfoLstPtr[strtIdx]->numFds < hiCb.numFdsPerSet)
      {
         hiCb.hiFdGrpInfoLstPtr[strtIdx]->numFds += 1;
         *fdBlkIdx = strtIdx;

#ifdef HI_MULTI_THREADED      
         hiCb.lastGrpUsed = strtIdx;

         /* Unlock the group lock */
         HI_UNLOCK(&hiCb.grpLock, alInfo, ret)
         if (ret != ROK)
         {
            HILOGERROR_DEBUG(EHI146, (ErrVal)ret, conCb->sap->uiPst.srcInst,
                  "hiGetFdBlkIdx : Could not unlock group lock \n");
            RETVALUE(RFAILED);
         }
#endif /* HI_MULTI_THREADED */

         RETVALUE(ROK);
      } 
      strtIdx += 1;
   }

   /* If we come out of the for loop then it means all file descriptors
    * are full */
   RETVALUE(RFAILED);

} /* end of hiGetFdBlkIdx */


/*
*  
*       Fun:   hiDecNumFds
* 
*       Desc:  This function is used to decrement the number of file 
*              file descriptors from the appropriate file descriptor 
*              block 
* 
*       Ret:   RETVOID 
* 
*       Notes: None 
* 
*       File:  hi_bdy2.c 
* 
*/
#ifdef ANSI
PUBLIC Void hiDecNumFds
(
HiConCb  *conCb,           /* connection control block */ 
U16      fdBlkIdx          /* file descriptor block index */
)
#else
PUBLIC Void hiDecNumFds(conCb, fdBlkIdx)
HiConCb  *conCb;           /* connection control block */ 
U16      fdBlkIdx;         /* file descriptor block index */
#endif
{

#ifdef HI_MULTI_THREADED
   S16         ret;
   HiAlarmInfo alInfo;
#endif /* HI_MULTI_THREADED */

   TRC2(hiDecNumFds);

   /* hi010.104 - in the case of TCP server throw up ConInd, if the
    * the upper layer reponse with DisReq but not ConRsp, we should
    * not decrement the Fds */
   if (conCb->conState == HI_ST_AW_CON_RSP)
      RETVOID;

#ifdef HI_MULTI_THREADED     
   /* Variable initializations */
   alInfo.spId = conCb->sap->spId;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   HI_LOCK(&hiCb.grpLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI147, (ErrVal) ret, conCb->sap->uiPst.srcInst,
                "hiDecNumFds(): cannot obtain group lock \n");
      RETVOID;
   }
#endif /* HI_MULTI_THREADED */
  
   if (hiCb.hiFdGrpInfoLstPtr[fdBlkIdx])
      hiCb.hiFdGrpInfoLstPtr[fdBlkIdx]->numFds -= 1;

#ifdef HI_MULTI_THREADED      
   /* Unlock the group lock */
   HI_UNLOCK(&hiCb.grpLock, alInfo, ret)
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI148, (ErrVal)ret, conCb->sap->uiPst.srcInst,
                "hiGetFdBlkIdx : Could not unlock group lock \n");
      RETVOID;
   }
#endif /* HI_MULTI_THREADED */

   RETVOID;
} /* end of hiDecNumFds */

  
/* hi009.104 - addition - functions hiGetVer and hiSetVer */
#ifdef HI_RUG
/*
*
*       Fun  :  Get Interface Version handling
*
*       Desc :  Processes system agent control request 
*               primitive to get interface version for all
*               intefaces implemented by the protocol
*
*       Ret  :  ROK  - ok
*
*       Notes:  None
*
*       File :  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiGetVer
(
ShtGetVerCfm *getVerCfmInfo   /* to return intf ver info */
)
#else
PUBLIC S16 hiGetVer(getVerCfmInfo)
ShtGetVerCfm *getVerCfmInfo;  /* to return intrf ver info */
#endif
{
   TRC2(hiGetVer)
              
   /* Fill TUCL upper interface ID and its version number.TCR doent's say this.
    * What a document! */
   getVerCfmInfo->numUif = 1;
   getVerCfmInfo->uifList[0].intfId  = HITIF;
   getVerCfmInfo->uifList[0].intfVer = HITIFVER;

   /* TUCL doesn't have these!! So fill lower interface version informations 
    * with negative value to bypass erroneous checking with wrong values 
    * TCR doent's say this. What a document! */
   getVerCfmInfo->numLif = 0;
   getVerCfmInfo->lifList[0].intfId = 0;
   getVerCfmInfo->lifList[0].intfVer = 0;

   /* TUCL doesn't have these!! So assign all zeros. */
   getVerCfmInfo->pif.intfId = 0;
   getVerCfmInfo->pif.intfVer = 0;

   RETVALUE(ROK);
} /* hiGetVer */

/*
*
*       Fun  :  Set Interface Version handling
*
*       Desc :  Processes system agent cntrl req primitive to 
*               set interface version.
*
*       Ret  :  ROK  - ok
*
*       Notes:  None
*
*       File :  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void hiSetVer
(
ShtVerInfo *setVerInfo,   /* to return intf ver information */
CmStatus   *status
)
#else
PUBLIC Void hiSetVer(setVerInfo, status)
ShtVerInfo *setVerInfo;   /* to return intf ver information */
CmStatus   *status;
#endif
{
   Bool       found;
   U16        i;
   ShtVerInfo *intfInf;
   HiSap       *sap;
              
   TRC3(hiSetVer)
              
   found = FALSE;

   /* Validate Set Version Information         */
   switch(setVerInfo->intf.intfId)
   {
      case HITIF:
         if(setVerInfo->intf.intfVer > HITIFVER)
            status->reason = LCM_REASON_VERSION_MISMATCH;
         break;
      default:
         status->reason = LCM_REASON_VERSION_MISMATCH;
         break;
   }
                    
   if(status->reason != LCM_REASON_NOT_APPL )
      RETVOID;
                            
   /* See if stored information already exists */
   for(i = 0; i < hiCb.numIntfInfo && found == FALSE; i++)
   {
      intfInf = &hiCb.intfInfo[i];  

      if(intfInf->intf.intfId == setVerInfo->intf.intfId)
      {
         if(intfInf->grpType == setVerInfo->grpType)
         {
            /* Stored information found. Replace the   *
             * information with new version information*
             * specified in this set version request   */
              
            switch(setVerInfo->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if((intfInf->dstProcId  == setVerInfo->dstProcId) &&
                    (intfInf->dstEnt.ent  == setVerInfo->dstEnt.ent) &&
                    (intfInf->dstEnt.inst == setVerInfo->dstEnt.inst))
                  {
                     intfInf->intf.intfVer = setVerInfo->intf.intfVer;
                     found = TRUE;
                  }
                  break;
                                
               case SHT_GRPTYPE_ENT:
                 if((intfInf->dstEnt.ent  == setVerInfo->dstEnt.ent) &&
                    (intfInf->dstEnt.inst == setVerInfo->dstEnt.inst))
                  {
                     intfInf->intf.intfVer = setVerInfo->intf.intfVer;
                     found = TRUE;
                  }
                  break;
            }
         }
      }
   } /* for */

   /* In the worst case we should be required to store one * 
   * version info. for every configured sap in the layer. */
   if(found == FALSE)
   {
      /* check if version info can be appended to the list */
      if(hiCb.numIntfInfo < hiCb.cfg.numSaps)
      {
         /* store version info at the end of the list */
         cmMemcpy((U8 *)&hiCb.intfInfo[hiCb.numIntfInfo], (U8 *)setVerInfo,
                  sizeof(ShtVerInfo));
         hiCb.numIntfInfo++;
      }
      else
      {
         status->reason = LCM_REASON_EXCEED_CONF_VAL;
         RETVOID;
      }
   }
                      
   /* Information in set version stored. Now update the SAPs */
   switch(setVerInfo->intf.intfId)
   {
      case HITIF: 
         /* repeat for all SAPs on the HIT interface */
         for(i = 0; i < hiCb.cfg.numSaps; i++)
         {
            /* If it is an unbound SAP then the remote entity, *
             * instance and proc ID would not be available and *
             * hence we should wait for bind to happen to set  *
             * the remote interface ver                        */
              
            /* get the saps one by one */
            sap = hiCb.sapLstPtr[i];
            if(!sap)
               continue;
            
            /* update interface version in pst only if SAP is bound */
            if(sap->state == HI_ST_BND)
            {
               switch(setVerInfo->grpType)
               {
                  case SHT_GRPTYPE_ALL:
                     if((setVerInfo->dstProcId   == sap->uiPst.dstProcId) &&
                        (setVerInfo->dstEnt.ent  == sap->uiPst.dstEnt) &&
                        (setVerInfo->dstEnt.inst == sap->uiPst.dstInst))
                     {
                        sap->uiPst.intfVer = setVerInfo->intf.intfVer;
                        sap->remIntfValid = TRUE;
                     }
                     break;
                  case SHT_GRPTYPE_ENT:
                     if((setVerInfo->dstEnt.ent  == sap->uiPst.dstEnt) &&
                        (setVerInfo->dstEnt.inst == sap->uiPst.dstInst))
                     {
                        sap->uiPst.intfVer = setVerInfo->intf.intfVer;
                        sap->remIntfValid = TRUE;
                     }
                     break;
               } /* switch */
            } /* SP_BND) */
         } /* for */
   } /* switch */ 

   RETVOID;
} /* hiSetVer */
#endif /* HI_RUG */

#ifdef HI_MULTI_THREADED     

/*
*  
*       Fun:   hiAddConCbToCmList
* 
*       Desc:  This function will add the conCb to the appropriate list in the
*              common structure.
*
*       Ret:   ROK
*              RFAILED
* 
*       Notes:
*
*       File:  hi_bdy2.c 
* 
*/
#ifdef ANSI
PUBLIC S16 hiAddConCbToCmList
(
HiConCb *conCb,      /* conCb to be put in the toBeDelList */ 
U16     listType     /* list the conCb should be inserted in */
)
#else
PUBLIC S16 hiAddConCbToCmList(conCb, listType)
HiConCb *conCb;      /* conCb to be put in the toBeDelList */ 
U16     listType;    /* list the conCb should be inserted in */
#endif
{
   HiFdGrpInfo    *grpInfoPtr;
   HiAlarmInfo    alInfo;
   CmLListCp      *lListCp;
   HiSendThrMsg   msg;

   S16            ret;

   TRC2(hiAddConCbToCmList);

   if (conCb == NULLP)
      RETVALUE(RFAILED);

   if (conCb->fdBlkIdx >= hiCb.numFdGrps)
      RETVALUE(RFAILED);

   alInfo.spId = conCb->sap->spId;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   grpInfoPtr = hiCb.hiFdGrpInfoLstPtr[conCb->fdBlkIdx];

   if (!grpInfoPtr)
      RETVALUE(RFAILED);

   /* Acquire the common information lock */
   HI_LOCK(&grpInfoPtr->cmInfoLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI149, (ErrVal)ret, grpInfoPtr->thisInst,
                 "hiAddConCbToCmList : Could not acquire lock");
      RETVALUE(RFAILED);
   }
   
   conCb->llEnt.node = (PTR) conCb;

   switch(listType)
   {
      case HI_CM_TOBEADD_LIST:
         lListCp = &grpInfoPtr->cmGrpCb.newConCbLst;
         cmLListAdd2Tail(lListCp, (CmLList *)&conCb->llEnt);
         conCb->isInList |= HI_CONCB_IN_TOADD_LIST;
         break;

      case HI_CM_TOBEDEL_LIST:
         if (conCb->isInList != HI_CONCB_IN_NOLIST)
         {
            /* If the conCb was put in toBeAdded list remove it */
            if (conCb->isInList & HI_CONCB_IN_TOADD_LIST)
            {
               lListCp = &grpInfoPtr->cmGrpCb.newConCbLst;
               cmLListDelFrm(lListCp, (CmLList *)&conCb->llEnt);
               conCb->isInList &= ~(HI_CONCB_IN_TOADD_LIST);
            }
            /* If the conCb is in transmit Q congestion list remove it */
            else if (conCb->isInList & HI_CONCB_IN_CONG_LIST)
            {
               lListCp = &grpInfoPtr->cmGrpCb.txQCongLst;
               cmLListDelFrm(lListCp, (CmLList *)&conCb->llEnt);
               conCb->isInList &= ~(HI_CONCB_IN_CONG_LIST);
            }
         }
         lListCp = &grpInfoPtr->cmGrpCb.toBeDelLst;
         cmLListAdd2Tail(lListCp, (CmLList *)&conCb->llEnt);
         conCb->isInList |= HI_CONCB_IN_TODEL_LIST;
         break;

      case HI_CM_TXQCONG_LIST:
         if (!(conCb->isInList & HI_CONCB_IN_CONG_LIST))
         {
            lListCp = &grpInfoPtr->cmGrpCb.txQCongLst;
            cmLListAdd2Tail(lListCp, (CmLList *)&conCb->llEnt);
            conCb->isInList |= HI_CONCB_IN_CONG_LIST;
         }
         break;

      default:
         ret = RFAILED;
         HILOGERROR_DEBUG(EHI150, (ErrVal)listType, grpInfoPtr->thisInst,
               "hiAddConCbToCmList : Wrong list type \n");
         break;
   }

   HI_UNLOCK(&grpInfoPtr->cmInfoLock, alInfo, ret); 
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI151, (ErrVal)ret, grpInfoPtr->thisInst,
                 "hiAddConCbToCmList : Could not release common lock");

      RETVALUE(RFAILED);
   }

   msg.msgType = HI_EMPTY_MSG;
   hiSendRecvThrMsg(conCb->fdBlkIdx, &msg);

   RETVALUE(ret);

} /* end of hiAddConCbToCmList */


/*
*  
*       Fun:   hiSendRecvThrMsg
* 
*       Desc:  This function will send the receive thread a message.
*
*       Ret:   ROK
*              RFAILED
* 
*       Notes: 
*
*       File:  hi_bdy2.c 
* 
*/
#ifdef ANSI
PUBLIC S16 hiSendRecvThrMsg
(
U16          recvThrNum,  /* receive thread number */ 
HiSendThrMsg *msg         /* message to send to the receive task */
)
#else
PUBLIC S16 hiSendRecvThrMsg(recvThrNum, msg)
U16          recvThrNum;  /* receive thread number */ 
HiSendThrMsg *msg;        /* message to send to the receive task */
#endif
{
   Buffer         *mBuf;
   CmInetMemInfo  memInfo;
   S16            ret;
   MsgLen         txLen;
   HiFdGrpInfo    *grpInfoPtr;
   
   /* Initialisations */
   memInfo.region = hiCb.hiInit.region;
   memInfo.pool   = hiCb.hiInit.pool;

   TRC2(hiSendRecvThrMsg);

   if (msg == NULLP)
   {
      HILOGERROR_INT_PAR(EHI152, 0, 0,
                "hiSendRecvThrMsg(): Null message \n");
      RETVALUE(RFAILED);
   }

   grpInfoPtr = hiCb.hiFdGrpInfoLstPtr[recvThrNum];

   if (grpInfoPtr == NULLP)
   {
      RETVALUE(RFAILED);
   }

   if (SGetMsg(hiCb.hiInit.region, hiCb.hiInit.pool, &mBuf) != ROK)
   {
      HILOGERROR_ADD_RES(EHI153, 0, 0,
                "hiSendRecvThrMsg(): mBuf allocation failed \n");
      RETVALUE(RFAILED);
   }

   switch(msg->msgType)
   {
      case HI_ENDTSK_MSG:
      case HI_EMPTY_MSG:
      case HI_ADDICMP_SOCK:
      case HI_DELICMP_SOCK:
      case HI_ZERO_GENSTS:
         break;

#ifdef IPV6_SUPPORTED
      case HI_ADDICMP6_SOCK:
      case HI_DELICMP6_SOCK:
         break;

      case HI_UPDICMP6_FILTER:
         break;
#endif /* IPV6_SUPPORTED */

      case HI_DELSAP_MSG:
      case HI_UBNDSAP_MSG:
      case HI_ZERO_SAPSTS:
         if (SPkS16(msg->inf.spId, mBuf) != ROK)
         {
            SPutMsg(mBuf);
            RETVALUE(RFAILED);
         }
         break;

      default:
         HILOGERROR_DEBUG(EHI154, 0, 0, 
            "hiSendRecvThrMsg(): Invalid message type \n");
         RETVALUE(RFAILED);
         break;
   }

   ret = SPkU8(msg->msgType, mBuf);
   if (ret != ROK)
   {
      SPutMsg(mBuf);
      RETVALUE(RFAILED);
   }

   /* hi009.104 - added new argument */
   /* Send the message to the appropriate server */
   ret = cmInetSendMsg(&grpInfoPtr->grpCb.servFd, 
                       &grpInfoPtr->servAddr, &memInfo, mBuf, &txLen, 
#ifdef IPV6_OPTS_SUPPORTED                       
                       NULLP,
#endif /* IPV6_OPTS_SUPPORTED */                       
                       CM_INET_NO_FLAG);    
   if (ret != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      HILOGERROR_ADD_RES(EHI155, (ErrVal) ret, 0,
               "hiSendRecvThrMsg(): Could not send msg \n");
      SPutMsg(mBuf);
      RETVALUE(RFAILED);
#endif /* ERRCLS_DEBUG */
   }

   /* Free the mBuf */
   SPutMsg(mBuf);
   RETVALUE(ROK);

} /* end of hiSendRecvThrMsg */


/*
*
*       Fun:   hiSpawnRecvTasks
*
*       Desc:  This function registers the receive tasks HI instances, 
*              calls SCreateSTsk, attaches the instances to the threads
*              and posts an empty message to all the newly registered 
*              tasks.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16  hiSpawnRecvTasks
(
)
#else
PUBLIC S16  hiSpawnRecvTasks()
#endif
{
   Inst        tempInst;            
   SSTskId     *tskIdArray;         
   U16         numTsks;
   Bool        deregTasks;
   S16         ret;
   Buffer      *mBuf;
   Pst         selfPst;

   TRC2(hiSpawnRecvTasks);
  
   /* Initialisations */
   deregTasks = FALSE;
   
   /* Allocate memory for the task id array */
   HI_ALLOC((hiCb.numFdGrps * sizeof(SSTskId)), tskIdArray);
   if (!tskIdArray)
      RETVALUE(RFAILED);
   
   /* Initialise the task id array */
   for (numTsks = 0; numTsks < hiCb.numFdGrps; numTsks++)
      tskIdArray[numTsks] = 0;

   /* Register the tasks with SSI. All receive tasks are registered 
    * as normal tasks */
   /* The starting instance number is set depending on the last instance
    * registered by the user. */
   tempInst = hiCb.lastInstUsed + 1;
   for (numTsks = 0; numTsks < hiCb.numFdGrps; numTsks++)
   {
      /* The receive tasks have no activation function */
#ifdef SS_MULTIPLE_PROCS       
      ret = SRegTTsk(hiCb.hiInit.procId, ENTHI, tempInst, HI_RECV_TASK_TYPE, HI_RECV_TASK_PRIOR, 
                     NULLP, hiRecvTsk);
#else /* SS_MULTIPLE_PROCS */      
      ret = SRegTTsk(ENTHI, tempInst, HI_RECV_TASK_TYPE, HI_RECV_TASK_PRIOR, 
                     NULLP, hiRecvTsk);
#endif /* SS_MULTIPLE_PROCS */      
      if (ret != ROK)
      {
#if (ERRCLS & ERRCLS_DEBUG)
         HILOGERROR_DEBUG( EHI156, (ErrVal)tempInst, 0,
             "hiSpawnRecvTasks : Registration of receive task failed \n");
#endif /* ERRCLS_DEBUG */
         deregTasks = TRUE;
         break;
      }
      tempInst += 1;
   }
  
   if (deregTasks)
   {
      /* Something went wrong during registering tasks. Cleanup */
      numTsks++;
      while(numTsks) 
      {
#ifdef SS_MULTIPLE_PROCS       
         SDeregTTsk(hiCb.hiInit.procId, ENTHI, tempInst);
#else /* SS_MULTIPLE_PROCS */      
         SDeregTTsk(ENTHI, tempInst);
#endif /* SS_MULTIPLE_PROCS */      
         tempInst --;
         numTsks--;
      }
      HI_FREE((hiCb.numFdGrps *sizeof(SSTskId)), tskIdArray);
      RETVALUE(RFAILED);
   }
   
   for (numTsks = 0; numTsks < hiCb.numFdGrps; numTsks++)
   {
      /* Create the systerm tasks (threads) */
      ret = SCreateSTsk (HI_RECV_TASK_PRIOR, &tskIdArray[numTsks]);
      if (ret != ROK)
      {
#if (ERRCLS & ERRCLS_DEBUG)
         HILOGERROR_DEBUG(EHI157, 0, 0,
         "hiSpawnRecvTasks : Creation of receive thread failed \n");
#endif /* ERRCLS_DEBUG */
         deregTasks = TRUE;
         break;
      }
   }
   
   if (deregTasks)
   {
      /* Deregister the tapa tasks registered */
      tempInst = hiCb.lastInstUsed + 1;
      for (numTsks = 0; numTsks < hiCb.numFdGrps; numTsks++)
      {
#ifdef SS_MULTIPLE_PROCS       
         SDeregTTsk(hiCb.hiInit.procId, ENTHI, tempInst);
#else /* SS_MULTIPLE_PROCS */      
         SDeregTTsk(ENTHI, tempInst);
#endif /* SS_MULTIPLE_PROCS */      
         tempInst ++;
      }
      /* Something went wrong during creating threads. Cleanup */
      /* Destroy the created system threads */
      while(numTsks)
      {
         numTsks --;
         SDestroySTsk(tskIdArray[numTsks]);
      }
      HI_FREE((hiCb.numFdGrps *sizeof(SSTskId)), tskIdArray);
      RETVALUE(RFAILED);
   }
   
   tempInst = hiCb.lastInstUsed + 1;
   /* Attach all the registered tasks with system tasks */
   for (numTsks = 0; numTsks < hiCb.numFdGrps; numTsks++)
   {
#ifdef SS_MULTIPLE_PROCS       
      ret = SAttachTTsk (hiCb.hiInit.procId, ENTHI, tempInst, tskIdArray[numTsks]);
#else /* SS_MULTIPLE_PROCS */      
      ret = SAttachTTsk (ENTHI, tempInst, tskIdArray[numTsks]);
#endif /* SS_MULTIPLE_PROCS */      
      if (ret != ROK)
      {
#if (ERRCLS & ERRCLS_DEBUG)
         HILOGERROR_DEBUG( EHI158, 0, 0,
         "hiSpawnRecvTasks : Failed to attach receive task to thread \n");
#endif /* ERRCLS_DEBUG */
         deregTasks = TRUE;
         break;
      }
      tempInst += 1;
   }

   if (deregTasks)
   {
      /* Not able to attach the tapa tasks to the system tasks */
      /* Remove all the system threads and deregister all tapa tasks 
       * registered earlier */
      tempInst = hiCb.lastInstUsed + 1;
      for (numTsks = 0; numTsks < hiCb.numFdGrps; numTsks++)
      {
         SDestroySTsk(tskIdArray[numTsks]);
#ifdef SS_MULTIPLE_PROCS       
         SDeregTTsk(hiCb.hiInit.procId, ENTHI, tempInst);
#else /* SS_MULTIPLE_PROCS */      
         SDeregTTsk(ENTHI, tempInst);
#endif /* SS_MULTIPLE_PROCS */      
         tempInst ++;
      }
      HI_FREE((hiCb.numFdGrps * sizeof(SSTskId)), tskIdArray);
      RETVALUE(RFAILED);
   }
  
   /* Receive threads are always loose coupled */
   selfPst.selector = HI_RECV_LC;
   selfPst.region = hiCb.hiInit.region;
   selfPst.pool = hiCb.hiInit.pool;
   selfPst.prior = PRIOR0;
   selfPst.route = RTESPEC;
   selfPst.dstEnt = ENTHI;
#ifdef SS_MULTIPLE_PROCS       
   selfPst.dstProcId = hiCb.hiInit.procId;
#else /* SS_MULTIPLE_PROCS */      
   selfPst.dstProcId = SFndProcId();
#endif /* SS_MULTIPLE_PROCS */      
   selfPst.srcEnt = ENTHI;
   selfPst.srcInst = 0;
#ifdef SS_MULTIPLE_PROCS       
   selfPst.srcProcId = hiCb.hiInit.procId;
#else /* SS_MULTIPLE_PROCS */      
   selfPst.srcProcId = SFndProcId();
#endif /* SS_MULTIPLE_PROCS */      
   selfPst.event = EVTINTGOACTV;

   tempInst = hiCb.lastInstUsed + 1;
  
   for (numTsks = 0; numTsks < hiCb.numFdGrps; numTsks++)
   {
      /* Send an empty mBuf to receive tasks to kick off things */
      ret = SGetMsg(hiCb.hiInit.region, hiCb.hiInit.pool, &mBuf);
      if (ret != ROK)
      {
#if (ERRCLS & ERRCLS_ADD_RES)
            HILOGERROR_DEBUG(EHI159, 0, 0, 
            "hiSpawnRecvTasks : Failed to allocate a mBuf \n");
#endif /* ERRCLS_DEBUG */
         deregTasks = TRUE;
         RETVALUE(RFAILED);
      }
  
      /* Change the destination instance */
      selfPst.dstInst = tempInst;

      SPstTsk(&selfPst, mBuf);
      tempInst ++;
   }
   
   if(deregTasks)
   {
      /* Couldnt allocate a message to be sent to the receive threads. 
       * Destroy all system threads and deregister all tapa tasks registered
       * earlier 
       */
      tempInst = hiCb.lastInstUsed + 1;
      for (numTsks = 0; numTsks < hiCb.numFdGrps; numTsks++)
      {
#ifdef SS_MULTIPLE_PROCS       
         SDeregTTsk(hiCb.hiInit.procId, ENTHI, tempInst);
#else /* SS_MULTIPLE_PROCS */      
         SDeregTTsk(ENTHI, tempInst);
#endif /* SS_MULTIPLE_PROCS */      
         SDestroySTsk(tskIdArray[numTsks]);
         tempInst ++;
      }
      HI_FREE((hiCb.numFdGrps *sizeof(SSTskId)), tskIdArray);
      RETVALUE(RFAILED);
   }

   /* Store the task id array for later use */
   hiCb.tskIdArray = tskIdArray;

   RETVALUE(ROK);
} /* end of hiSpawnRecvTasks */


/*
*
*       Fun:   hiRmvFrmSpConIdHl
*
*       Desc:  This function removed the conCb from the spConId hashlist.
*
*       Ret:   Void 
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void hiRmvFrmSpConIdHl
(
HiConCb  *conCb             /* connection control block */
)
#else
PUBLIC Void hiRmvFrmSpConIdHl(conCb)
HiConCb  *conCb;             /* connection control block */
#endif
{
   S16         ret;
   HiSap       *sap;
   HiAlarmInfo alInfo;

   TRC2(hiRmvFrmSpConIdHl);

   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (!conCb)
   {
      HILOGERROR_DEBUG(EHI160, 0, 0,
         "hiRmvFrmSpConIdHl - Invalid conCb \n");
      RETVOID;
   }
#endif /* ERRCLS_DEBUG */

   sap = conCb->sap;
   alInfo.spId = sap->spId;

   HI_LOCK(&sap->spConIdLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI161, (ErrVal) ret, 0,
      "hiRmvFrmSpConIdHl : failed to acquire spConId hashlist lock ");

      RETVOID;
   }

   if (conCb->isInList & HI_CONCB_IN_SPCONID_LIST)
      cmHashListDelete(&sap->spConIdHlCp, (PTR) conCb);

   conCb->isInList &= ~(HI_CONCB_IN_SPCONID_LIST);

   HI_UNLOCK(&sap->spConIdLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI162, (ErrVal) ret, 0,
         "hiRmvFrmSpConIdHl : failed to acquire spConId hashlist lock ");

      RETVOID;
   }

   RETVOID;
} /* end of hiRmvFrmSpConIdHl */


/*
*
*       Fun:      hiChkConCbsInSpConIdHl
*
*       Desc:     This function is used to check the number of conCbs in the 
*                 spConId hash list. 
*                 
*       Ret:      ROK
*                 RCLOSED
*                 RFAILED
*
*       Notes:    None
*
*       File:     hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16 hiChkConCbsInSpConIdHl
(
HiSap             *sap,          /* sap id */
U16               *numConCbs     /* number of conCbs */
)
#else
PUBLIC S16 hiChkConCbsInSpConIdHl(sap, numConCbs)
HiSap             *sap;          /* sap id */
U16               *numConCbs;    /* number of conCbs */
#endif
{
   HiAlarmInfo alInfo;
   S16         ret;

   TRC2(hiChkConCbsInSpConIdHl);

   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;
   alInfo.spId = sap->spId;
   
   HI_LOCK(&sap->spConIdLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI163, (ErrVal) ret, 0,
      "hiChkConCbsInSpConIdHl : failed to acquire spConId hashlist lock ");

      RETVALUE(RFAILED);
   }

   (*numConCbs) = HI_NUMCONCBS_IN_LIST(sap->spConIdHlCp);

   HI_UNLOCK(&sap->spConIdLock, alInfo, ret);
   if (ret != ROK)
   {
      HILOGERROR_DEBUG(EHI164, (ErrVal) ret, 0,
         "hiChkConCbsInSpConIdHl : failed to acquire spConId hashlist lock ");

      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* end of hiChkConCbsInSpConIdHl */


/*
*
*       Fun:   hiSendIntDiscInd
*
*       Desc:  This function is used to invoke the internal disconnect
*              indication primitive. 
*
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiSendIntDiscInd
(
HiSap    *sap,
U8       choice,
UConnId  id,
Reason   reason,
Inst     inst
)
#else
PUBLIC S16 hiSendIntDiscInd(sap, choice, id, reason, inst) 
HiSap    *sap;
U8       choice;
UConnId  id;
Reason   reason;
Inst     inst;
#endif
{
   Pst    selfPst;
   Buffer *mBuf;
   S16    retVal;
   Pst    *pst;
   
   TRC2(hiSendIntDiscInd);

   pst = &selfPst;

   /* Fill in the post structure */
   HI_FILLIN_SELFPST(selfPst, sap, inst, EVTINTDISCIND);
   
   /* Get a mBuf */
   retVal = SGetMsg(selfPst.region, selfPst.pool, &mBuf);
   if (retVal != ROK)
   {
      HILOGERROR_ADD_RES(EHI165, (ErrVal) retVal, inst, 
         "hiSendIntDiscInd : Failed to allocate mBuf \n");

      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkReason, reason, mBuf, EHI166, pst);
   CMCHKPKLOG(cmPkUConnId, id, mBuf, EHI167, pst);
   CMCHKPKLOG(SPkU8, choice, mBuf, EHI168, pst);
   CMCHKPKLOG(cmPkSpId, sap->spId, mBuf, EHI169, pst);

   RETVALUE(SPstTsk(pst, mBuf));

} /* end of hiSendIntDiscInd */


/*
*
*       Fun:   hiRecvIntDiscInd
*
*       Desc:  This function is used to invoke the internal disconnect
*              indication primitive. 
*
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiRecvIntDiscInd
(
Pst    *pst,
Buffer *mBuf
)
#else
PUBLIC S16 hiRecvIntDiscInd(pst, mBuf) 
Pst    *pst;
Buffer *mBuf;
#endif
{

   SpId     sapId;
   U8       choice;
   UConnId  conId;
   Reason   reason;

   TRC2(hiRecvIntDiscInd);

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "hiRecvIntDiscInd() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_LYR, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

   /* Unpack the parameters */
   CMCHKUNPKLOG(cmUnpkSpId,   &sapId,    mBuf, EHI170, pst);
   CMCHKUNPKLOG(SUnpkU8,      &choice,  mBuf, EHI171, pst);
   CMCHKUNPKLOG(cmUnpkUConnId, &conId,   mBuf, EHI172, pst);
   CMCHKUNPKLOG(cmUnpkReason, &reason,  mBuf, EHI173, pst);

   SPutMsg(mBuf);
   
   /* Directly invoke the primitive */
   HiUiIntDiscInd(pst, sapId, choice, conId, reason);

   RETVALUE(ROK);

} /* end of hiRecvIntDiscInd */


/*
*
*       Fun:   hiSendIntCongOff
*
*       Desc:  This function is used to invoke the internal 
*              congestion off primitive. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiSendIntCongOff
(
HiSap    *sap, 
UConnId  id,
Inst     inst
)
#else
PUBLIC S16 hiSendIntCongOff(sap, id, inst) 
HiSap    *sap;
UConnId  id;
Inst     inst;
#endif
{
   Pst    selfPst;
   Buffer *mBuf;
   S16    retVal;
   Pst    *pst;

   TRC2(hiSendIntCongOff);

   pst = &selfPst;

   /* Fill in the post structure */
   HI_FILLIN_SELFPST(selfPst, sap, inst, EVTINTCONGOFF);

   /* Get a mBuf */
   retVal = SGetMsg(selfPst.region, selfPst.pool, &mBuf);
   if (retVal != ROK)
   {
      HILOGERROR_ADD_RES(EHI174, (ErrVal) retVal, inst, 
         "hiSendIntCongOff : Failed to allocate mBuf \n");

      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkUConnId, id, mBuf, EHI175, pst);
   CMCHKPKLOG(cmPkSpId, sap->spId, mBuf, EHI176, pst);

   RETVALUE(SPstTsk(pst, mBuf));

} /* end of hiSendIntCongOff */


/*
*
*       Fun:   hiRecvIntCongOff
*
*       Desc:  This function is used to invoke the internal 
*              congestion off primitive. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiRecvIntCongOff
(
Pst    *pst,
Buffer *mBuf
)
#else
PUBLIC S16 hiRecvIntCongOff(pst, mBuf) 
Pst    *pst;
Buffer *mBuf;
#endif
{

   SpId     sapId;
   UConnId  conId;

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "hiRecvIntCongOff() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_LYR, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

   /* Unpack the parameters */
   CMCHKUNPKLOG(cmUnpkSpId,   &sapId,    mBuf, EHI177, pst);
   CMCHKUNPKLOG(cmUnpkUConnId, &conId,   mBuf, EHI178, pst);

   SPutMsg(mBuf);
   
   /* Directly invoke the primitive */
   HiUiIntCongOff(pst, sapId, conId);

   RETVALUE(ROK);

} /* end of hiRecvIntCongOff */


/*
*
*       Fun:   hiSendIntSapConCbDel
*
*       Desc:  This function is used to invoke the internal 
*              last concb del primitive. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiSendIntSapConCbDel
(
HiSap    *sap, 
Inst     inst
)
#else
PUBLIC S16 hiSendIntSapConCbDel(sap, inst) 
HiSap    *sap;
Inst     inst;
#endif
{
   Pst    selfPst;
   Buffer *mBuf;
   S16    retVal;
   Pst    *pst;

   pst = &selfPst;

   /* Fill in the post structure */
   HI_FILLIN_SELFPST(selfPst, sap, inst, EVTINTSAPCONCBDEL);

   /* Get a mBuf */
   retVal = SGetMsg(selfPst.region, selfPst.pool, &mBuf);
   if (retVal != ROK)
   {
      HILOGERROR_ADD_RES(EHI179, (ErrVal) retVal, inst, 
         "hiSendIntLastConCbDel : Failed to allocate mBuf \n");

      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkSpId, sap->spId, mBuf, EHI180, pst);

   RETVALUE(SPstTsk(pst, mBuf));

} /* end of hiSendIntSapConCbDel */


/*
*
*       Fun:   hiRecvIntSapConCbDel
*
*       Desc:  This function is used to invoke the internal 
*              sap concb del primitive. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiRecvIntSapConCbDel
(
Pst    *pst,
Buffer *mBuf
)
#else
PUBLIC S16 hiRecvIntSapConCbDel(pst, mBuf) 
Pst    *pst;
Buffer *mBuf;
#endif
{

   SpId     sapId;

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "hiRecvIntSapConCbDel() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_LYR, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

   /* Unpack the parameters */
   CMCHKUNPKLOG(cmUnpkSpId,   &sapId,    mBuf, EHI181, pst);

   SPutMsg(mBuf);
   
   /* Directly invoke the primitive */
   HiUiIntSapConCbDel(pst, sapId);

   RETVALUE(ROK);

} /* end of hiRecvIntSapConCbDel */


/*
*
*       Fun:   hiSendIntRecvThrClosed
*
*       Desc:  This function is used to invoke the internal 
*              recive thread closed primitive. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiSendIntRecvThrClosed
(
Inst  inst
)
#else
PUBLIC S16 hiSendIntRecvThrClosed(inst) 
Inst  inst;
#endif
{
   Pst    selfPst;
   Buffer *mBuf;
   S16    retVal;
   Pst    *pst;

   pst = &selfPst;

   /* Fill in the post structure */
   selfPst.selector = HI_RECV_LC;
   selfPst.prior = PRIOR0;
   selfPst.route = RTESPEC; 
   selfPst.region = hiCb.hiInit.region;
   selfPst.pool = hiCb.hiInit.pool;
   selfPst.dstProcId = hiCb.hiInit.procId; 
   selfPst.dstEnt = ENTHI;
   selfPst.dstInst = 0;
#ifdef SS_MULTIPLE_PROCS       
   selfPst.srcProcId = hiCb.hiInit.procId;
#else /* SS_MULTIPLE_PROCS */      
   selfPst.srcProcId = SFndProcId();
#endif /* SS_MULTIPLE_PROCS */      
   selfPst.srcEnt = ENTHI;
   selfPst.srcInst = inst;
   selfPst.event = EVTINTRECVTHRCLOSED;

   /* Get a mBuf */
   retVal = SGetMsg(selfPst.region, selfPst.pool, &mBuf);
   if (retVal != ROK)
   {
      HILOGERROR_ADD_RES(EHI182, (ErrVal) retVal, inst, 
         "hiSendIntRecvThrClosed : Failed to allocate mBuf \n");

      RETVALUE(RFAILED);
   }

   RETVALUE(SPstTsk(pst, mBuf));

} /* end of hiSendIntRecvThrClosed */


/*
*
*       Fun:   hiRecvIntRecvThrClosed
*
*       Desc:  This function is used to invoke the internal 
*              last concb del primitive. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiRecvIntRecvThrClosed
(
Pst    *pst,
Buffer *mBuf
)
#else
PUBLIC S16 hiRecvIntRecvThrClosed(pst, mBuf) 
Pst    *pst;
Buffer *mBuf;
#endif
{

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "hiRecvIntRecvThrClosed() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_LYR, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

   SPutMsg(mBuf);
   
   /* Directly invoke the primitive */
   HiUiIntRecvThrClosed(pst);

   RETVALUE(ROK);

} /* end of hiRecvIntRecvThrClosed */



/*
*
*       Fun:   hiSendIntSapDisReq
*              
*       Desc:  Send a sap disable request.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: 
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 hiSendIntSapDisReq 
(
SpId spId                /* service provider id */ 
)
#else
PUBLIC S16  hiSendIntSapDisReq(spId)
SpId spId;               /* service provider id */ 
#endif
{
   
   Pst    selfPst;
   Buffer *mBuf;
   S16    retVal;
   Pst    *pst;
   HiSap  *sap;

   TRC2(hiSendIntSapDisReq);

   pst = &selfPst;

   sap = hiCb.sapLstPtr[spId];

   /* Fill in the post structure */
   HI_FILLIN_SELFPST(selfPst, sap, 0, EVTINTSAPDISREQ);
   
   /* Get a mBuf */
   retVal = SGetMsg(selfPst.region, selfPst.pool, &mBuf);
   if (retVal != ROK)
   {
      HILOGERROR_ADD_RES(EHI183, (ErrVal) retVal, 0, 
         "hiSendIntSapDisReq: Failed to allocate mBuf \n");

      RETVALUE(RFAILED);
   }
   
   CMCHKPKLOG(cmPkSpId, sap->spId, mBuf, EHI184, pst);

   RETVALUE(SPstTsk(pst, mBuf));

} /* end of hiSendIntSapDisReq */
   

/*
*
*       Fun:   hiRecvIntSapDisReq
*
*       Desc:  This function is used to invoke the internal 
*              sap disable confirm primitive. 
*
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiRecvIntSapDisReq
(
Pst    *pst,
Buffer *mBuf
)
#else
PUBLIC S16 hiRecvIntSapDisReq(pst, mBuf) 
Pst    *pst;
Buffer *mBuf;
#endif
{

   SpId     sapId;

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "hiRecvIntSapDisReq() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_LYR, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

   TRC2(hiRecvIntSapDisReq);

   /* Unpack the parameters */
   CMCHKUNPKLOG(cmUnpkSpId,   &sapId,    mBuf, EHI185, pst);

   SPutMsg(mBuf);
   
   /* Directly invoke the primitive */
   HiUiIntSapDisReq(pst, sapId);

   RETVALUE(ROK);

} /* end of hiRecvIntSapDisReq */



/*
*
*       Fun:   hiSendIntSapDisCfm
*              
*       Desc:  Send a sap disable confirm.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: 
*
*       File:  hi_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 hiSendIntSapDisCfm 
(
SpId spId                /* service provider id */ 
)
#else
PUBLIC S16  hiSendIntSapDisCfm(spId)
SpId spId;               /* service provider id */ 
#endif
{
   
   Pst    selfPst;
   Buffer *mBuf;
   S16    retVal;
   Pst    *pst;
   HiSap  *sap;

   TRC2(hiSendIntSapDisCfm);

   pst = &selfPst;

   sap = hiCb.sapLstPtr[spId];

   /* Fill in the post structure */
   HI_FILLIN_SELFPST(selfPst, sap, sap->uiPst.srcInst, EVTINTSAPDISCFM);
   selfPst.dstInst = 0;

   
   /* Get a mBuf */
   retVal = SGetMsg(selfPst.region, selfPst.pool, &mBuf);
   if (retVal != ROK)
   {
      HILOGERROR_ADD_RES(EHI186, (ErrVal) retVal, sap->uiPst.srcInst, 
         "hiSendIntSapDisCfm: Failed to allocate mBuf \n");

      RETVALUE(RFAILED);
   }
   
   CMCHKPKLOG(cmPkSpId, sap->spId, mBuf, EHI187, pst);

   RETVALUE(SPstTsk(pst, mBuf));

} /* end of hiSendIntSapDisCfm */
   

/*
*
*       Fun:   hiRecvIntSapDisCfm
*
*       Desc:  This function is used to invoke the internal 
*              sap disable confirm primitive. 
*
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  hi_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 hiRecvIntSapDisCfm
(
Pst    *pst,
Buffer *mBuf
)
#else
PUBLIC S16 hiRecvIntSapDisCfm(pst, mBuf) 
Pst    *pst;
Buffer *mBuf;
#endif
{

   SpId     sapId;

#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst,(Void **)&hiCbPtr)) !=
      ROK)
   {
      HILOGERROR_DEBUG(EHI267,(ErrVal)0,pst->dstInst,
            "hiRecvIntSapDiscCfm() failed, cannot derive hiCb");
      RETVALUE(FALSE);
   }   
   HIDBGP(DBGMASK_LYR, (hiCb.hiInit.prntBuf,
      "---------TUCL------(proc(%d),entt(%d),inst(%d))--------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif  /* SS_MULTIPLE_PROCS */   

   TRC2(hiRecvIntSapDisCfm);

   /* Unpack the parameters */
   CMCHKUNPKLOG(cmUnpkSpId,   &sapId,    mBuf, EHI188, pst);

   SPutMsg(mBuf);
   
   /* Directly invoke the primitive */
   HiUiIntSapDisCfm(pst, sapId);

   RETVALUE(ROK);

} /* end of hiRecvIntSapDisReq */



/*
*  
*       Fun:   hiChkCntrlOp
* 
*       Desc:  This function will check if there is a pending operation on 
*              any of the saps. If there is a pending operating then it
*              returns LHI_REASON_DIFF_OPINPROG otherwise it returns 
*              LCM_REASON_NOT_APPL.
* 
*       Ret:   LCM_REASON_NOT_APPL - No other control operation is pending.
*              LHI_REASON_DIFF_OPINPROG - A control operation is pending on 
*                                      some or all the saps.
*              RFAILED
* 
*       Notes:
*
*       File:  hi_bdy2.c 
* 
*/
#ifdef ANSI
PUBLIC S16 hiChkCntrlOp
(
Elmnt    elmnt          /* Element */
)
#else
PUBLIC S16  hiChkCntrlOp(elmnt)
Elmnt    elmnt;         /* Element */
#endif
{
   SpId     sapId;
   HiSap    *sap;

   if (elmnt == STGEN)
   {
      /* For general control request */
      if (hiCb.pendOp.flag == TRUE)
         RETVALUE(LHI_REASON_DIFF_OPINPROG);
   }
   else
   {
      for (sapId = 0; sapId < hiCb.cfg.numSaps; sapId++)
      {
         sap = hiCb.sapLstPtr[sapId];

         if (sap == NULLP)
            continue;

         if (sap->pendOp.flag == TRUE)
            RETVALUE(LHI_REASON_DIFF_OPINPROG);
      }
   }

   RETVALUE(LCM_REASON_NOT_APPL);

} /* hiChkCntrlOp */


/*
*  
*       Fun:   hiCleanupSapConCbs
* 
*       Desc:  This function will delete all connection control blocks
*              from the sap hash list. 
*           
*              This function also sends a message to all receive threads 
*              to clear any connections they may have associated with this
*              sap.
*
*              This function will be called at the time of sap disable 
*              and shutdown.
* 
*       Ret:   ROK
*              RFAILED
* 
*       Notes:
*
*       File:  hi_bdy2.c 
* 
*/
#ifdef ANSI
PUBLIC S16 hiCleanupSapConCbs
(
HiSap *sap,      /* sap to cleanup */
U8    msgType    /* message type */
)
#else
PUBLIC S16  hiCleanupSapConCbs(sap, msgType)
HiSap *sap;      /* sap to cleanup */
U8    msgType;   /* message type */
#endif
{
   S16         ret; 
   HiConCb     *conCb;
   HiSendThrMsg   msg;
   U16            i;

   TRC2(hiCleanupSapConCbs);

   conCb = NULLP;

   /* Check if any conCbs are left in the spConId hashlist. */
   if (hiChkConCbsInSpConIdHl(sap, &i) == ROK);
   {
      if (i == 0)
      {
         /* No connections exist on this sap */

         /* set the expected number of primitives equal to ZERO */
         sap->numRecvThrCfmsExptd = 0;

         RETVALUE(ROK);
      }
   }

   while ((ret = cmHashListGetNext(&sap->sapHlCp, NULLP, 
                                   (PTR *) &conCb) == ROK))
   {
      cmHashListDelete(&sap->sapHlCp, (PTR) conCb);
      conCb->toBeDel = 0;
      hiDecNumFds(conCb, conCb->fdBlkIdx);
      hiChkAndCloseIcmpSock(conCb);
      hiAddConCbToCmList(conCb, HI_CM_TOBEDEL_LIST);
   }

   /* Send a message to all the receive threads */

   /* Fill the message to send to the receive thread */
   msg.msgType = msgType;
   msg.inf.spId = sap->spId;
   
   for (i = 0; i < hiCb.numFdGrps; i++)
      hiSendRecvThrMsg(i, &msg);

   /* set the expected number of primitives equal to number of 
    * threads */
   if (msgType == HI_UBNDSAP_MSG)
      sap->numRecvThrCfmsExptd = 0;
   else
      sap->numRecvThrCfmsExptd = hiCb.numFdGrps;

   RETVALUE(ROK);
} /* end of hiCleanupSapConCbs */


/*
*
*       Fun:      hiRmvSapConCbs
*
*       Desc:     This function is used to delete all conCbs related to a sap.
*                 This function is called only from the receive threads.
*                                  
*       Ret:      ROK
*                 RFAILED
*
*       Notes:    None
*
*       File:     hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16 hiRmvSapConCbs
(
SpId              spId,          /* sap Id */
HiFdGrpInfo       *grpInfoPtr,   /* group information pointer */
CmInetFdSet       *readMaskPtr,  /* read mask returned from select */
CmInetFdSet       *writeMaskPtr, /* write mask returned from select */
S16               *numFds        /* number of file descriptors */
)
#else
PUBLIC S16 hiRmvSapConCbs(spId, grpInfoPtr, readMaskPtr, writeMaskPtr, numFds)
SpId              spId;          /* sap Id */
HiFdGrpInfo       *grpInfoPtr;   /* group information pointer */
CmInetFdSet       *readMaskPtr;  /* read mask returned from select */
CmInetFdSet       *writeMaskPtr; /* write mask returned from select */
S16               *numFds;       /* number of file descriptors */
#endif
{
   CmHashListCp   *crntBlkHlCp;
   HiConCb        *conCb, *prevConCb;
   S16            ret;

   /* Initialisations */
   conCb = prevConCb = NULLP;

   /* Go through the write hash list and delete all conCbs from this list
    * belonging to the sap id */
   crntBlkHlCp = &grpInfoPtr->grpCb.wrFdHlCp;
  
   while((ret = cmHashListGetNext(crntBlkHlCp, (PTR) prevConCb,
                                  (PTR *) &conCb)) == ROK)
   {
      if (conCb->sap->spId == spId)
      {
         hiProcDelConCb(conCb, grpInfoPtr, readMaskPtr, writeMaskPtr,
                        numFds);
         continue;
      }
      prevConCb = conCb;
   }

   /* Go through the read hash list and delete all conCbs from this list
    * belonging to the sap id */
   crntBlkHlCp = &grpInfoPtr->grpCb.rdFdHlCp;
   conCb = prevConCb = NULLP;

   while((ret = cmHashListGetNext(crntBlkHlCp, (PTR) prevConCb,
         (PTR *) &conCb)) == ROK)
   {
      if (conCb->sap->spId == spId)
      {
         hiProcDelConCb(conCb, grpInfoPtr, readMaskPtr, writeMaskPtr,
                        numFds);
         continue;
      }
      prevConCb = conCb;
   } 

   RETVALUE(ROK);
} /* end of hiRmvSapConCbs */


/*
*
*       Fun:      hiProcAddConCb
*
*       Desc:     This function is used to process the connection control
*                 blocks in the to be added list.
*                 
*       Ret:      ROK
*                 RFAILED
*
*       Notes:    None
*
*       File:     hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16 hiProcAddConCb
(
HiConCb           *conCb,        /* connection control block to be added */
HiFdGrpInfo       *grpInfoPtr    /* group information pointer */
)
#else
PUBLIC S16 hiProcAddConCb(conCb, grpInfoPtr)
HiConCb           *conCb;        /* connection control block to be added */
HiFdGrpInfo       *grpInfoPtr;   /* group information pointer */
#endif
{
   S16            ret;
   HiAlarmInfo    alInfo;

   TRC2(hiProcAddConCb);

   /* Initialisations */
   alInfo.spId = conCb->sap->spId;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

#ifdef IPV6_SUPPORTED
   if ((conCb->icmpMask) || (conCb->icmp6Mask))
#else
   if (conCb->icmpMask)
#endif /* IPV6_SUPPORTED */
   {
      if (conCb->protocol == CM_PROTOCOL_ICMP)
      {
         if (conCb->sendConCfm)
         {
            /* Send a connection confirm back to the upper user */
            HiUiHitConCfm(&conCb->sap->uiConCfmPst, conCb->sap->suId, 
                           conCb->suConId, conCb->spConId, &conCb->locTptAddr);
            conCb->sendConCfm = FALSE;
         }
         RETVALUE(ROK);
      }
   }
   /* Add this connection control block to the fd hash list */
   /* insert this connection control block in the file descriptor
    * block hash list */
   ret = cmHashListInsert(&grpInfoPtr->grpCb.rdFdHlCp,
                          (PTR)conCb, (U8 *)&(conCb->conFd.fd), 
                         sizeof(CmInetFdType));
   if (ret != ROK) 
   {
      HILOGERROR_DEBUG( EHI189, (ErrVal)ret, 0,
                 "hiProcAddConCb : Could not insert conCb into hashlist");
      hiSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_INV_EVT,
                  LCM_CAUSE_HASH_FAIL, &alInfo);
      conCb->toBeDel |= HI_DEL_SEND_DISCIND;
      hiSendIntDiscInd(conCb->sap, HI_PROVIDER_CON_ID, conCb->spConId, 
                       grpInfoPtr->thisInst, HI_INTERNAL_ERR);
   }
   
   /* Set the file descriptor in the read file descriptor set */
   CM_INET_FD_SET(&(conCb->conFd), 
                    &(grpInfoPtr->grpCb.readFdSet));

   conCb->isInList |= HI_CONCB_IN_READ_LIST;
   
   if (conCb->conState == HI_ST_CLT_CONNECTING)
   {
      ret = cmHashListInsert(&grpInfoPtr->grpCb.wrFdHlCp,
                             (PTR)conCb, (U8 *)&(conCb->conFd.fd), 
                             sizeof(CmInetFdType));
      if (ret != ROK) 
      {
         HILOGERROR_DEBUG( EHI190, (ErrVal)ret, 0,
                  "hiProcAddConCb : Could not insert conCb into hashlist");
         hiSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_INV_EVT,
                     LCM_CAUSE_HASH_FAIL, &alInfo);
         hiDelFrmFdGrp(grpInfoPtr, conCb, HI_FDGRP_READ_LIST);
         /* hi002.104 - Clear fd from fd_set */
         HI_DEL_FRM_FDSET(grpInfoPtr, conCb, HI_FDGRP_READ_LIST);

         conCb->toBeDel |= HI_DEL_SEND_DISCIND;
         /* Issue an indication to the main TUCL instance. The main TUCL 
         * instance will issue a disconnect indication to the upper user
         */
         hiSendIntDiscInd(conCb->sap, HI_PROVIDER_CON_ID, conCb->spConId,  
                          grpInfoPtr->thisInst, HI_INTERNAL_ERR);
      }

      /* Set the file descriptor in the read file descriptor set */
      CM_INET_FD_SET(&(conCb->conFd), 
                     &(grpInfoPtr->grpCb.writeFdSet));

      conCb->isInList |= HI_CONCB_IN_WRITE_LIST;
      
      grpInfoPtr->grpCb.numWrFds += 1;
      RETVALUE(ROK);
   }

   if (conCb->sendConCfm)
   {
      /* Send a connection confirm back to the upper user */
      HiUiHitConCfm(&conCb->sap->uiConCfmPst, conCb->sap->suId, 
                    conCb->suConId, conCb->spConId, &conCb->locTptAddr);
      conCb->sendConCfm = FALSE;
   }

   RETVALUE(ROK);

} /* end of hiProcAddConCb() */


/*
*
*       Fun:      hiProcDelConCb
*
*       Desc:     This function is used to process the connection control
*                 blocks in the to be deleted list.
*                 
*       Ret:      ROK
*                 RFAILED
*
*       Notes:    None
*
*       File:     hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16 hiProcDelConCb
(
HiConCb           *conCb,        /* connection control block to be added */
HiFdGrpInfo       *grpInfoPtr,   /* group information pointer */
CmInetFdSet       *readMaskPtr,  /* read mask returned from select */
CmInetFdSet       *writeMaskPtr, /* write mask returned from select */
S16               *numFds        /* number of file descriptors */
)
#else
PUBLIC S16 hiProcDelConCb(conCb, grpInfoPtr, readMaskPtr, writeMaskPtr,
                              numFds)
HiConCb           *conCb;        /* connection control block to be added */
HiFdGrpInfo       *grpInfoPtr;   /* group information pointer */
CmInetFdSet       *readMaskPtr;  /* read mask returned from select */
CmInetFdSet       *writeMaskPtr; /* write mask returned from select */
S16               *numFds;       /* number of file descriptors */
#endif
{

   S16      ret;
   HiConCb  *tempConCb;

   TRC2(hiProcDelConCb);

   /* Search the file descriptor list to see if conCb exists */
   ret = cmHashListFind(&grpInfoPtr->grpCb.rdFdHlCp, 
                        (U8 *)&conCb->conFd.fd, 
                        sizeof(CmInetFdType), 0, (PTR *) &tempConCb);
   if (ret == ROK)
   {
      if (conCb->action == HI_SHTDWN_RECV)
      {
         /* Clear the conFd if it set in the readMaskPtr */
         if (CM_INET_FD_ISSET(&conCb->conFd, readMaskPtr))
         {
            CM_INET_FD_CLR(&conCb->conFd, readMaskPtr);
            (*numFds) --;
          }

         /* clear the read file descriptor set from the grCb
          * read file descriptor list */
         
         /* hi002.104 - Clear fd from fd_set */
         HI_DEL_FRM_FDSET(grpInfoPtr, conCb, HI_FDGRP_READ_LIST);
         
         HI_SHUT_SOCKET(conCb, CM_INET_SHTDWN_RECV);

         if (conCb->rxBuf)
         {
            SPutMsg(conCb->rxBuf);
            conCb->rxBuf = NULLP;
         }
         RETVALUE(ROK);
      }
      else if (conCb->action == HI_SHTDWN_SEND)
      {
         if (writeMaskPtr)
         {
            /* Remove the file descriptor from the write file descriptor
             * set */
            if (CM_INET_FD_ISSET(&conCb->conFd, writeMaskPtr))
            {
               CM_INET_FD_CLR(&conCb->conFd, writeMaskPtr);
               (*numFds) --;
            }
         }

         /* Flush the  transmit queue */
         if (conCb->flag & HI_FL_TCP)
         {
            /* Flush the transmit queue */
            if (SFlushQueue(&conCb->txQ) != ROK)
               HILOGERROR_DEBUG(EHI191, 0, conCb->sap->uiPst.srcInst,
                  "hiProcDelConCb : Error flusing the transmit queue");
         }

         hiDelFrmFdGrp(grpInfoPtr, conCb, HI_FDGRP_WRITE_LIST);
         /* hi002.104 - Clear fd from fd_set */
         HI_DEL_FRM_FDSET(grpInfoPtr, conCb, HI_FDGRP_WRITE_LIST);
 
         HI_SHUT_SOCKET(conCb, CM_INET_SHTDWN_SEND);

         RETVALUE(ROK);
      }
      else 
      {
         /* The two actions HI_SHTDWN_BOTH and HI_CLOSE are not 
          * distinguished from each other. */
	 /* hi018.104: check NULLP */     
         if (readMaskPtr != NULLP && CM_INET_FD_ISSET(&conCb->conFd, readMaskPtr))
         {
            CM_INET_FD_CLR(&conCb->conFd, readMaskPtr);
            (*numFds) --;
         }

         if (writeMaskPtr)
         {
            if (CM_INET_FD_ISSET(&conCb->conFd, writeMaskPtr))
            {
               CM_INET_FD_CLR(&conCb->conFd, writeMaskPtr);
               (*numFds) --;
            }
         }
      }
         
      /* Delete the conCb from both the read and write file 
       * descriptor sets and lists */
      hiDelFrmFdGrp(grpInfoPtr, conCb, HI_FDGRP_BOTH_LIST);
      /* hi002.104 - Clear fd from fd_set */
      HI_DEL_FRM_FDSET(grpInfoPtr, conCb, HI_FDGRP_BOTH_LIST);

      /* Flush the  transmit queue */
      if (conCb->flag & HI_FL_TCP)
      {
         /* Flush the transmit queue */
         if (SFlushQueue(&conCb->txQ) != ROK)
            HILOGERROR_DEBUG(EHI192, 0, conCb->sap->uiPst.srcInst,
               "hiProcDelConCb  : Error flusing the transmit queue");
      }

      if (conCb->rxBuf)
      {
         SPutMsg(conCb->rxBuf);
         conCb->rxBuf = NULLP;
      }

      /* Close the socket */
      if (conCb->protocol != CM_PROTOCOL_ICMP)
         HI_CLOSE_SOCKET(&conCb->conFd);
   }
   else
   {
         /*
          * If the search failed then the conCb was not in the file descriptor 
          * hash list. This can happen if the peer had disconnected this conCb 
          * before the DiscReq came into the main TUCL instance.
          */
         /* Close the socket */
         if (conCb->protocol != CM_PROTOCOL_ICMP)
            HI_CLOSE_SOCKET(&conCb->conFd);
   }
      
   /* 
    * 1. Send a disc Cfm to the upper user.
    * 2. Remove the block from the spConId hash list.
    * 3. Free the memory.
    */

   /* Send a disc Cfm to the upper user */
   if (conCb->toBeDel & HI_DEL_SEND_DISCCFM)
   {
      if (conCb->choice == HI_PROVIDER_CON_ID)
         HiUiHitDiscCfm(&conCb->sap->uiPst, conCb->sap->suId, conCb->choice, 
                        conCb->spConId, conCb->action);
      else
         HiUiHitDiscCfm(&conCb->sap->uiPst, conCb->sap->suId, conCb->choice, 
                        conCb->suConId, conCb->action);
   }
   else if (conCb->toBeDel & HI_DEL_SEND_DISCIND)
      /* Issue a disconnect indication to the upper user */
      HI_DISCIND(conCb->sap, HI_PROVIDER_CON_ID, conCb->spConId, 
                 conCb->reason);
      
   if (conCb->flag & HI_FL_TCP)
   {
      SDestroyLock(&conCb->txQLockId);
      SFlushQueue(&conCb->txQ);
   }

   /* Remove the conCb from the spConId hash list */
   hiRmvFrmSpConIdHl(conCb);

   HI_FREE(sizeof(HiConCb), conCb);

   RETVALUE(ROK);

} /* end of hiProcDelConCb */


/*
*
*       Fun:      hiProcTxQConCb
*
*       Desc:     This function is used to process the connection control
*                 blocks in the transmit Q list.
*                 
*       Ret:      ROK
*                 RFAILED
*
*       Notes:    None
*
*       File:     hi_bdy3.c
*
*/
#ifdef ANSI
PUBLIC S16 hiProcTxQConCb
(
HiConCb           *conCb,        /* Connection control block */
HiFdGrpInfo       *grpInfoPtr    /* File descriptor group information */
)
#else
PUBLIC S16 hiProcTxQConCb(conCb, grpInfoPtr)
HiConCb           *conCb;        /* Connection control block */
HiFdGrpInfo       *grpInfoPtr;   /* File descriptor group information */
#endif
{

   S16         ret;
   HiAlarmInfo alInfo;

   /* Initialisations */
   alInfo.spId = conCb->sap->spId;
   alInfo.type = LHI_ALARMINFO_TYPE_NTPRSNT;

   if(!(conCb->isInList & HI_CONCB_IN_WRITE_LIST))
   {  
      ret = cmHashListInsert(&grpInfoPtr->grpCb.wrFdHlCp,
                             (PTR)conCb, (U8 *)&(conCb->conFd.fd), 
                             sizeof(CmInetFdType));
      if (ret != ROK) 
      {
         HILOGERROR_DEBUG(EHI193, (ErrVal)ret, 0,
         "hiProcTxQConCb : Could not insert conCb into write hashlist");
         hiSendAlarm(LCM_CATEGORY_INTERNAL, LCM_EVENT_INV_EVT,
                     LCM_CAUSE_HASH_FAIL, &alInfo);
         hiDelFrmFdGrp(grpInfoPtr, conCb, HI_FDGRP_READ_LIST);

         /* hi002.104 - Using new function to clear fd from fd_set */
         HI_DEL_FRM_FDSET(grpInfoPtr, conCb, HI_FDGRP_READ_LIST);

         conCb->toBeDel |= HI_DEL_SEND_DISCIND;
         hiSendIntDiscInd(conCb->sap, HI_PROVIDER_CON_ID, conCb->spConId,  
                          grpInfoPtr->thisInst, HI_INTERNAL_ERR);
         RETVALUE(RFAILED);
      }

      /* Add this to the write fd_set */
      CM_INET_FD_SET(&(conCb->conFd), 
                     &(grpInfoPtr->grpCb.writeFdSet));
      
      conCb->isInList |= HI_CONCB_IN_WRITE_LIST;

      /* Increment the haveWriteFdSet */
      grpInfoPtr->grpCb.numWrFds += 1;
   }
   
   RETVALUE(ROK);

} /* end of hiProcTxQConCb */
#endif /* HI_MULTI_THREADED */


/********************************************************************30**
 
         End of file:     hi_bdy2.c@@/main/4 - Thu Jun 28 13:29:45 2001
 
*********************************************************************31*/
 
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      asa  1. initial release.
1.1+         hi002.11 asa  1. changes for loopback mode.
                          2. added processing for TCP application 
                             specific header.
                          3. fixed a bug in hiChkTxQ().
                          4. only suConId to be issued in HitDiscCfm.
                          5. miscellaneous bug fixes.
/main/2       ---      cvp  1. added support for multiple fd_set structures.
                          2. added function hiFdSet and hiFdClr.
                          3. added support for CM_INADDR_ANY UDP server in 
                             loopback mode.
                          4. added backward compatibility flag.
                          5. changed the copyright header.
/main/4      ---      sb   1. changed for header include options & hashlist
                             modifications.
                          2. added backward compatibility flag.
/main/4+     hi001.13 cvp 1. reserving memory for icmp hash list. 
                          2. freeing memory for fd hash list and array 
                             in hiShutdown function.
/main/4+     hi002.13 cvp 1. Deregister permanent task only if the user
                             has not registered it.
                          2. Check for RCLOSED in cmInetSendMsg 
                             function.
/main/4+     hi003.13 cvp 1. Freeing partially received mBufs in 
                             hiFreeConCb().
                          2. Changed the logic of generating flow 
                             control indications.
/main/4+     hi005.13 cvp 1. Allocating and freeing memory required 
                             by file descriptor information structures.
                          2. Connection control blocks are now inserted
                             with fd as the key.
/main/4                 cvp 1. Changes to support multithreaded TUCL.
                          2. Changes to support IPV6.
                          3. changed the copyright header.
/main/4+    hi002.104 cvp 1. File descriptors no longer cleared in 
                             hiDelFrmFdGrp function. This is now being done in 
                             a new macro.
/main/4+    hi005.104 bdu 1. fill in the sapId field into sapStsToFill
                             in hiGetSapSts function.
/main/4+    hi007.104 mmh 1. Change the name of the third argument of
                             hiDelFrmFdGrp to conList.
/main/4+    hi008.104 mmh 1. Correct last argument from list to conList in 
                             function hiDelFrmFdGrp's non-ANSI declaration.
/main/4+    hi009.104 mmh 1. added new argument in functions cmInetSendMsg and
                             HiUiHitUDatInd. 
                          2. init cfmPst to all zeros in hiSendLmCfm()
                          3. added rolling upgrade support under compile flag
                             HI_RUG as per tcr0020.txt:
                            - store version info when allocating a new sap
                            - reconfigure verion info in a sap
                            - free (by SPutSBuf) mem allocated for version info
                            - store version info into cfmPst in hiSendLmCfm()
                            - set sap->remIntfValid to FALSE when unbinding
                              and disabling a sap
                            - in function hiCfgGen() 
                               o  added validation of intf version num in lmPst
                               o  include the mem size of version info before
                                  allocating mem by SGetSMem()
                               o  call HI_ALLOC to allocate mem for ver info
                               o  initialize LM interface version num in lmPst
                               o  free mem allocated for version info if timer
                                  registration fails
                            - added 2 new functions hiGetVer and hiSetVer
/main/4+    hi010.104 bdu 1. In the case of TCP server throw up a ConInd,
                             if service user response with DisReq instead of
                             ConRsp, we should not decrement the number of 
                             fds. The change is in hiDecNumFds function.
/main/4+    hi011.104 bdu 1. Change for CM_SOCKOPT_OPT_MCAST6_IF option.
/main/4+    hi015.104 zmc 1. Reset the counter  
/main/4+    hi019.104 zmc 1. Relogic the hiChkRes
/main/4+    hi021.104 rs  1. Warnings Removed.
/main/4+    hi022.104 rs  1. Hash key changes to U32MOD.
/main/4+    hi023.104 jc  1. Add Sap Id in Trace 
/main/4+    hi024.104 jc  1. Reverted Hash key to DEF for locAddrHlCp
			     wrFdHlCp, rdFdHlCp
/main/4+    hi025.104 pr  1. SS_MULTIPLE_PROCS flag added.
/main/4+    hi028.104 jc  1. Removed compiler warning.
/main/4+    hi029.104 jc  1. Fixed SAP Delete problem.
*********************************************************************91*/
