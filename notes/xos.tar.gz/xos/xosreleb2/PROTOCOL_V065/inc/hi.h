/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     TCP UDP convergence Layer 
  
     Type:     C include file
  
     Desc:     Defines required by TUCL
  
     File:     hi.h
  
     Sid:      hi.h@@/main/4 - Thu Jun 28 13:29:24 2001
  
     Prg:      asa
  
*********************************************************************21*/
  
#ifndef __HIH__
#define __HIH__

/* Layer name */
#define HILAYERNAME     "TCP_UDP_CONVERGENCE_LAYER"

/* conCb.conState : connection states  */

/* NOTE: states specific to server only have HI_ST_SRV_
 * prefix and client specific states have HI_ST_CLT_
 * prefix, other states may be entered by both.
 */

#define HI_ST_SRV_LISTEN       0x0 /* Initial state of a TCP server before
                                    * accepting any connection */
#define HI_ST_AW_CON_RSP       0x1 /* State of a server or client awaiting
                                    * Connect Response from the upper Layer */
#define HI_ST_CLT_CONNECTING   0x2 /* State of a non blocking TCP client 
                                    * trying to connect to the server */
#define HI_ST_CONNECTED        0x3 /* data transfer state of a server or a 
                                    * client */

/* additional states */
#define HI_ST_CONNECTED_NORD   0x4  /* state after closing read half of 
                                     * the socket */
#define HI_ST_CONNECTED_NOWR   0x5  /* state after closing the write half 
                                     * of the socket */
#define HI_ST_CONNECTED_NORDWR 0x6  /* state after closing the both write 
                                     * and read halves of the socket */
 
/* conCb.flag : defines for flag in HiConCb */
#define HI_FL_TCP             0x00000001 /* TCP protocol */
#define HI_FL_UDP             0x00000002 /* UDP protocol */
#define HI_FL_SRV             0x00000004 /* Server connection block */
#define HI_FL_CLT             0x00000008 /* Client connection block */
#define HI_FL_UDP_CLT         0x00000010 /* UDP client */

#ifdef HI_REL_1_3  
#define HI_FL_RAW             0x00000020 /* Raw socket */
#ifdef IPV6_SUPPORTED 
#define HI_FL_RAW_IPV6        0x00000040 /* Raw IPV6 socket */
#endif /* IPV6_SUPPORTED */
#endif  /* HI_REL_1_3 */ 

#ifdef HI_LPBK
#define HI_FL_MCAST_CONCB     0x00000080 /* Multicast server block */
#endif /* HI_LPBK */

/* Added priority flag */
#define HI_FL_PRIOR           0x00000100  /* priority socket */

/* Max connections to accept */
#define HI_MAX_CONS_TO_ACCEPT 5  

/* hash defines for TPKT header required by HI layer */
#define HI_TPKT_HDR_LEN       4
#define HI_TPKT_HDR_VERSION   0x03
#define HI_TPKT_HDR_RESERVED  0x00

#define HI_MAX_HDR_LEN        100        /* Maximum length of the application
                                          * header over TCP
                                          */

#define  HI_SRVCTYPE_MASK     4

/* Miscellaneous loopback mode related defines */
#ifdef HI_LPBK

/* configuration related */
#define HI_LPBK_NUM_ADDRLST_BINS   4     /* Number of bins in the local 
                                          * transport address hash list */
#define HI_LPBK_NUM_MCAST_MBR      25    /* Total number of IP multicast 
                                          * group memberships for the system */
#endif /* HI_LPBK */

/* hi007.104 - Removed the defines of HI_MAX_FD_PER_FD_SET (64) and
 * HI_FD_BLK_NUM_BINS (4) since they are not in use */

/* Number of UDP messages to be read for priority UDP sockets */
#define HI_NUM_UDP_MSGS_TOREAD     20    /* Number of messages read per 
                                          * scheduling of the permanent task */

/* Number of RAW messages to be read for priority RAW sockets */
#ifdef HI_REL_1_3
#define HI_NUM_RAW_MSGS_TOREAD     20    /* Number of messages read per 
                                          * scheduling of the permanent task
                                          */
#endif /* HI_REL_1_3 */

/* Timer Tags used by  TUCL */
#define HI_TMR_SCHD                1     /* TUCL poll permanent task 
                                          * scheduling timer */
#define HIGENTMRS                  1     /* number of general timers */
#define HIQNUMENT                  1     /* size of the timing queue */
#define HIMAXSIMTMR                1     /* maximum nuber of simultaneous 
                                          * timers */

/* connection block hash list initialization fields */
#define  HI_HLDUP_FLAG       FALSE       /* Allow dup. keys  */

/* Miscellaneous defines */
#define HI_PRNTBUF_SIZE      128     /* size of print buffer */
#define HI_UNUSED           -1       /* for all unused fields */

#ifdef HI_REL_1_3
#define ALL_ICMP_MSG         0x0001  /* All ICMP messages */
#define ALL_PROTO_SPEC_MSG   0x0002  /* All protocol specific ICMP messages */
#define ALL_FLTRD_ICMP_MSG   0x0004  /* All Filtered ICMP messages */
#define FLTRD_PROTO_SPEC_MSG 0x0008  /* Filtered protocol specific messages */

/* Flags for IP_HEADER_INCLUDE & IP parameters */
#define HI_INCLUDE_HDR               0x0001
#define HI_HDRINCLD_NT_SUPPORTED     0x0002

#define HI_DF_MASK           0x0001
#define HI_TOS_MASK          0x001C
#endif /* HI_REL_1_3 */

/* Defines to identify the flow control indications given up */
#define HI_SENT_FLC_STRT            0x01  /* Start of congestion notified */
#define HI_SENT_FLC_DROP            0x02  /* Start of congestion notified */

/* Defines to identify the lists that the conCb may be in */
#define HI_CONCB_IN_NOLIST          0x0000  /* Not in any list */
#define HI_CONCB_IN_READ_LIST       0x0001  /* In read fd_set and list */
#define HI_CONCB_IN_WRITE_LIST      0x0002  /* In write fd_set and list */

#ifdef HI_REL_1_3
#define HI_CONCB_IN_ICMP_LIST       0x0004  /* In the common icmp list */
#define HI_CONCB_IN_ICMP6_LIST      0x0080  /* In the common icmp6 list */
#endif /* HI_REL_1_3 */

#ifdef HI_MULTI_THREADED
#define HI_CONCB_IN_TOADD_LIST      0x0008  /* In the common toadd list */
#define HI_CONCB_IN_TODEL_LIST      0x0010  /* In the common todel list */
#define HI_CONCB_IN_CONG_LIST       0x0020  /* In the common congestion list */
#define HI_CONCB_IN_SPCONID_LIST    0x0040  /* In the spConId hash list */

#define HI_ENDTSK_MSG               0x01 /* Message to kill the recv task */
#define HI_EMPTY_MSG                0x02 /* Message to unblock the recv task*/
#define HI_DELSAP_MSG               0x03 /* Message to tell the recv task to 
                                          * delete all conCbs associated with 
                                          * the sap */
#define HI_ADDICMP_SOCK             0x04 /* Message to tell the recv task to 
                                          * add the icmp con fd to its hash
                                          * list.
                                          */
#define HI_DELICMP_SOCK             0x05 /* Message to tell the recv task to 
                                          * delete the icmp con fd from its
                                          * hash list */
#ifdef IPV6_SUPPORTED 
#define HI_ADDICMP6_SOCK            0x06 /* Message to tell the recv task to 
                                          * add the icmp con fd to its hash
                                          * list.
                                          */
#define HI_DELICMP6_SOCK            0x07 /* Message to tell the recv task to 
                                          * delete the icmpv6 con fd from its
                                          * hash list */
#define HI_UPDICMP6_FILTER          0x08 /* Message to tell the recv task to 
                                          * set the icmpv6 filter */
#endif /* IPV6_SUPPORTED */

#define HI_ZERO_SAPSTS              0x09  /* Message to zero the sap statistics 
                                           */
#define HI_ZERO_GENSTS              0x0a  /* Message to zero the general
                                           * statistics */
#define HI_UBNDSAP_MSG              0x0b  /* Message sent when sap is unbound
                                           */

#define HI_RECV_TASK_TYPE          TTNORM /* Receive tasks are normal tasks
                                           * in multi-threaded mode */
#define HI_RECV_TASK_PRIOR         PRIOR0 /* Priority of receive tasks */

#define HI_RECV_LC                 0x0    /* Receive threads are always loose 
                                           * coupled */
#else 
#define HI_CONCB_IN_SCANCON_LIST    0x0040  /* In non multithreaded case this
                                             * this means it is in the list
                                             * accessed by the hiScanConLst
                                             * function */
#endif /* HI_MULTI_THREADED */

/* Defines to identify the actions to be taken when a conCb is in the 
 * toBeDel list */
#ifdef HI_MULTI_THREADED
#define HI_DEL_SEND_DISCCFM         0x01  /* Send a disconnect confirm to the
                                           * upper user */
#define HI_DEL_SEND_NODISCCFM       0x02  /* Do not send a disconnect confirm
                                           * to the upper user */
#define HI_DEL_SEND_DISCIND         0x04  /* Send a disconnect indication to 
                                           * the upper user */
#endif /* HI_MULTI_THREADED */

/* Defines for the common information structure lists */
#ifdef HI_MULTI_THREADED 
#define HI_CM_TOBEADD_LIST          0x8000 /* Common toAdd list */
#define HI_CM_TOBEDEL_LIST          0x4000 /* Common toDel list */
#define HI_CM_TXQCONG_LIST          0x2000 /* Common txQCong list */
#endif /* HI_MULTI_THREADED */

/* defines for common information list part */
#define HI_FDGRP_READ_LIST       0x0001  /* Read file descriptor group list */
#define HI_FDGRP_WRITE_LIST      0x0002  /* Write file descriptor group list */
#define HI_FDGRP_BOTH_LIST       (HI_FDGRP_WRITE_LIST | HI_FDGRP_READ_LIST)  

#define HI_UDP_RESV_ADDR         0x7f000001  /* Loopback address */
#define HI_UDP_RESV_PORT         0           /* Ephemeral port */

/* hi018.104: Maximum number of connections */
#define HI_MAX_NMBCONS_SUPP     100

/* hi025.104 : Addition - Support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
#ifndef HI_MAX_INSTANCES
#define HI_MAX_INSTANCES 1
#endif  /* HI_MAX_INSTANCES */

#define hiCb (*hiCbPtr)

#endif /* SS_MULTIPLE_PROCS */

/* TUCL Macros */

/* debug macro */
#define HIDBGP(_msgClass, _arg)                         \
   DBGP(&(hiCb.hiInit), HILAYERNAME, _msgClass, _arg)   \

/* start a timer */
#define HI_START_TMR(_timer, _wait)                     \
{                                                       \
   CmTmrArg   _arg;                                     \
   if (_wait != 0)                                      \
   {                                                    \
      _arg.tq     = hiCb.hiTq;                          \
      _arg.tqCp   = &(hiCb.hiTqCp);                     \
      _arg.timers = hiCb.timers;                        \
      _arg.cb     = (PTR)&hiCb;                         \
      _arg.evnt   = _timer;                             \
      _arg.wait   = _wait;                              \
      _arg.tNum   = 0;                                  \
      _arg.max    = 1;                                  \
      cmPlcCbTq(&_arg);                                 \
   }                                                    \
}

/* stop a timer */
#define HI_STOP_TMR()                                   \
{                                                       \
   CmTmrArg   _arg;                                     \
   _arg.tq     = hiCb.hiTq;                             \
   _arg.tqCp   = &(hiCb.hiTqCp);                        \
   _arg.timers = hiCb.timers;                           \
   _arg.cb     = (PTR)&hiCb;                            \
   _arg.evnt   = 0;                                     \
   _arg.wait   = 0;                                     \
   _arg.tNum   = 0;                                     \
   _arg.max    = 1;                                     \
   cmRmvCbTq(&_arg);                                    \
}

/* zero out a buffer */ 
#define HI_ZERO(_str,_len)                              \
   cmMemset((U8 *)_str, 0, _len);

/* allocate and zero out a static buffer */
#define HI_ALLOC(_size, _datPtr)                        \
{                                                       \
   ret = SGetSBuf(hiCb.hiInit.region,                   \
                  hiCb.hiInit.pool,                     \
                  (Data**)&_datPtr, _size);             \
    if(ret == ROK)                                      \
       cmMemset((U8*)_datPtr, 0, _size);                \
    else                                                \
       _datPtr = NULLP;                                 \
}

/* zero out and deallocate a static buffer */
#define HI_FREE(_size, _datPtr)                         \
{                                                       \
    (Void)SPutSBuf(hiCb.hiInit.region,                  \
                   hiCb.hiInit.pool,                    \
                   (Data*)_datPtr, _size);              \
}

/* Issue a disconnect indication to the service user */
#ifndef HI_MULTI_THREADED
#define HI_DISCIND(_sap, _choice, _id, _reason)         \
{                                                       \
   if (_sap->state == HI_ST_BND)                        \
   {                                                    \
      HiUiHitDiscInd(&_sap->uiPst, _sap->suId,          \
            (U8)_choice, (UConnId)_id,                  \
            (Reason)_reason);                           \
   }                                                    \
}
#else
#define HI_DISCIND(_sap, _choice, _id, _reason)         \
{                                                       \
   if (_sap->state == HI_ST_BND)                        \
   {                                                    \
      HiUiHitDiscInd(&_sap->uiDiscIndPst, _sap->suId,   \
            (U8)_choice, (UConnId)_id,                  \
            (Reason)_reason);                           \
   }                                                    \
}
#endif /* HI_MULTI_THREADED */

/* hi009.104 - calling cmInetDeInit after closing socket */
/* Deinitialise the socket library */
#ifdef IPV6_SUPPORTED 
#define HI_SOCK_DEINIT()                                \
{                                                       \
   (Void)cmInetClose(&hiCb.resvConFd);                  \
   (Void)cmInetClose(&hiCb.resv6ConFd);                 \
   cmInetDeInit();                                      \
}
#else
#define HI_SOCK_DEINIT()                                \
{                                                       \
   (Void)cmInetClose(&hiCb.resvConFd);                  \
   cmInetDeInit();                                      \
}
#endif /* IPV6_SUPPORTED */

#ifdef HI_MULTI_THREADED     
/* Fill in the self post structure */
#define HI_FILLIN_SELFPST(_selfPst, _sap, _inst, _event) \
{                                                       \
   _selfPst.selector = HI_RECV_LC;                      \
   _selfPst.prior = PRIOR0;                             \
   _selfPst.route = _sap->uiPst.route;                  \
   _selfPst.region = _sap->uiPst.region;                \
   _selfPst.pool = _sap->uiPst.pool;                    \
   _selfPst.dstProcId = _sap->uiPst.srcProcId;          \
   _selfPst.dstEnt = _sap->uiPst.srcEnt;                \
   _selfPst.dstInst =  _sap->uiPst.srcInst;             \
   _selfPst.srcProcId = _sap->uiPst.srcProcId;          \
   _selfPst.srcEnt = _sap->uiPst.srcEnt;                \
   _selfPst.srcInst = _inst;                            \
   _selfPst.event = _event;                             \
}

/* Duplicate the sap uiPst structure. Multiple threads may use these
 * structures */
#define HI_DUPLICATE_SAP_PST(_sap, _pst)                \
{                                                       \
   cmMemcpy((U8 *)&sap->uiConCfmPst, (U8 *)&sap->uiPst, \
           sizeof(Pst));                                \
                                                        \
   cmMemcpy((U8 *)&sap->uiConIndPst, (U8 *)&sap->uiPst, \
           sizeof(Pst));                                \
                                                        \
   cmMemcpy((U8 *)&sap->uiFlcIndPst, (U8 *)&sap->uiPst, \
           sizeof(Pst));                                \
                                                        \
   cmMemcpy((U8 *)&sap->uiDatIndPst, (U8 *)&sap->uiPst, \
           sizeof(Pst));                                \
                                                        \
   cmMemcpy((U8 *)&sap->uiUDatIndPst, (U8 *)&sap->uiPst,\
           sizeof(Pst));                                \
                                                        \
   cmMemcpy((U8 *)&sap->uiDiscIndPst, (U8 *)&sap->uiPst,\
           sizeof(Pst));                                \
                                                        \
   cmMemcpy((U8 *)&sap->uiDiscCfmPst, (U8 *)&sap->uiPst,\
           sizeof(Pst));                                \
                                                        \
}
#endif /* HI_MULTI_THREADED */

/* Check spId in an interface primitive */
#define HI_CHK_SPID(_spId, _event, _ret, _info)         \
{                                                       \
   _ret = ROK;                                          \
   if((_spId >= (SpId) hiCb.cfg.numSaps) || (_spId < 0))\
   {                                                    \
      hiSendAlarm((U16)LCM_CATEGORY_INTERFACE,          \
                  (U16)_event, (U16)LCM_CAUSE_INV_SPID, \
                  &_info);                              \
      _ret = RFAILED;                                   \
   }                                                    \
   if(!hiCb.sapLstPtr[_spId])                           \
   {                                                    \
      hiSendAlarm((U16)LCM_CATEGORY_INTERFACE,          \
                  (U16)_event,                          \
                  (U16)LCM_CAUSE_INV_SAP, &_info);      \
      _ret = RFAILED;                                   \
   }                                                    \
}

#ifdef HI_MULTI_THREADED
#define HI_CHK_INT_SPID(_spId, _ret)                    \
{                                                       \
   _ret = ROK;                                          \
   if((_spId >= (SpId) hiCb.cfg.numSaps) || (_spId < 0))\
      _ret = RFAILED;                                   \
                                                        \
   if(!hiCb.sapLstPtr[_spId])                           \
      _ret = RFAILED;                                   \
}
#endif /* HI_MULTI_THREADED */

/* Apply SO_REUSEADDR socket option */
#define HI_SET_SOCKOPT_REUSEADDR(_sockPtr)              \
{                                                       \
   U32 _optVal;                                         \
   _optVal = CM_SOCKOPT_ENABLE;                         \
   if(cmInetSetOpt(_sockPtr, CM_SOCKOPT_LEVEL_SOCKET,   \
                   CM_SOCKOPT_OPT_REUSEADDR,            \
                   (Ptr)&_optVal) != ROK)               \
      hiCb.errSts.sockSOptErr++;                           \
}

/* Apply TCP_NODELAY socket option */
#define HI_SET_SOCKOPT_TCP_NODELAY(_sockPtr)            \
{                                                       \
   U32 _optVal;                                         \
   _optVal = CM_SOCKOPT_ENABLE;                         \
   if(cmInetSetOpt(_sockPtr, CM_SOCKOPT_LEVEL_TCP,      \
                   CM_SOCKOPT_OPT_TCP_NODELAY,          \
                   (Ptr)&_optVal) != ROK)               \
      hiCb.errSts.sockSOptErr++;                        \
}

/* Issue a flow control indication and an alarm to the LM */
#ifdef HI_REL_1_3
#define HI_FLW_CNTRL(_conCb, _reason, _event, _infoPtr) \
{                                                       \
    if(_conCb->sap->cfg.flcEnb)                         \
    {                                                   \
       if(_reason == HI_FLC_DROP)                       \
          _conCb->flc = TRUE;                           \
       else if(_reason == HI_FLC_STOP)                  \
          _conCb->flc = FALSE;                          \
       hiCb.errSts.numFlcInd++;                         \
       HiUiHitFlcInd(&(_conCb->sap->uiPst),             \
                     _conCb->sap->suId, _conCb->suConId, \
                     _reason);                          \
    }                                                   \
    hiSendAlarm((U16)LCM_CATEGORY_RESOURCE,             \
                (U16)_event,                            \
                (U16)LCM_CAUSE_UNKNOWN, _infoPtr);      \
}
#else
#define HI_FLW_CNTRL(_sap, _reason, _event, _infoPtr)   \
{                                                       \
    if(_sap->cfg.flcEnb)                                \
    {                                                   \
       if(_reason == HI_FLC_DROP)                       \
          _sap->flc = TRUE;                             \
       else if(_reason == HI_FLC_STOP)                  \
          _sap->flc = FALSE;                            \
       hiCb.errSts.numFlcInd++;                         \
       HiUiHitFlcInd(&(_sap->uiPst), _sap->suId, _reason);  \
    }                                                   \
    hiSendAlarm((U16)LCM_CATEGORY_RESOURCE,             \
                (U16)_event,                            \
                (U16)LCM_CAUSE_UNKNOWN, _infoPtr);      \
}
#endif /* HI_REL_1_3 */
/* Alarm related macros */
#define HI_FILL_ALARMINFO_SAP_STATE(_info, _state)      \
{                                                       \
   _info.type = (U8)LHI_ALARMINFO_SAP_STATE;            \
   _info.inf.state = _state;                            \
}

#define HI_FILL_ALARMINFO_CON_STATE(_info, _conState)   \
{                                                       \
   _info.type = (U8)LHI_ALARMINFO_CON_STATE;            \
   _info.inf.conState = _conState;                      \
}

#define HI_FILL_ALARMINFO_MEM_ID(_info, _region, _pool) \
{                                                       \
   _info.type = (U8)LHI_ALARMINFO_MEM_ID;               \
   _info.inf.mem.region = _region;                      \
   _info.inf.mem.pool   = _pool;                        \
}

#define HI_FILL_ALARMINFO_PAR_TYPE(_info, _parType)     \
{                                                       \
   _info.type = (U8)LHI_ALARMINFO_MEM_ID;               \
   _info.inf.parType = _parType;                        \
}

#ifdef HI_LPBK

/* Initialize the transport address */
#define HI_LPBK_INIT_TPTADDR(_tptAddrPtr)               \
{                                                       \
   U8  _type = _tptAddrPtr->type;                       \
   U16 _port = _tptAddrPtr->u.ipv4TptAddr.port;         \
   U32 _address = _tptAddrPtr->u.ipv4TptAddr.address;   \
   cmMemset((U8 *)_tptAddrPtr, 0, sizeof(CmTptAddr));   \
   _tptAddrPtr->type = _type;                           \
   if(_type)                                            \
      _tptAddrPtr->u.ipv4TptAddr.address = _address;    \
   if((_type == 0) || (_port == 0))                     \
   {                                                    \
      if((hiCb.lstPortUsed == 0) ||                     \
          (hiCb.lstPortUsed == 65535))                  \
         hiCb.lstPortUsed = 2000;                       \
      _port = ++hiCb.lstPortUsed;                       \
   }                                                    \
   _tptAddrPtr->u.ipv4TptAddr.port = _port;             \
}

/* Close a socket */
#define HI_CLOSE_SOCKET(_ptr_fd)

/* Set a FD in the list */
#define HI_FD_SET(_sockd, _Fds)

/* Shutdown a socket */
#define HI_SHUT_SOCKET(_ptr_fd, _type)

/* hi007.104 - define HI_DEL_FRM_FDSET under HI_LPBK flag */
#define HI_DEL_FRM_FDSET(_grpInfoPtr, _conCb, _list)

/* Release all connnections in a TSAP */
#define HI_RELEASE_SAP_CON_LIST(_sap, _flag)            \
{                                                       \
   HiConCb *_conCb = NULLP;                             \
   while((ret = cmHashListGetNext(&(_sap->sapHlCp),     \
                                  NULLP,                \
                                 (PTR *)&(_conCb)))     \
                                  == ROK)               \
   {                                                    \
      hiFreeConCb(_conCb);                              \
   }                                                    \
   if(_flag)                                            \
      (Void)cmHashListDeinit(&_sap->sapHlCp);           \
}
#else /* HI_LPBK */

/* Close a socket */
#define HI_CLOSE_SOCKET(_ptr_fd)                        \
{                                                       \
   (Void)cmInetClose(_ptr_fd);                          \
}

/* Shutdown a socket */
#define HI_SHUT_SOCKET(_conCb, _type)                   \
{                                                       \
   S16 _ret;                                            \
                                                        \
   hiFdClr(_conCb, _type);                              \
                                                        \
   _ret = cmInetShutdown(&conCb->conFd, _type);         \
   if(_ret != ROK)                                      \
   {                                                    \
      hiCb.errSts.sockShutErr++;                        \
      RETVALUE(_ret);                                   \
   }                                                    \
}

/* Call hiScanConLst to cleanup properly */
/* Release all connnections in a TSAP */
#ifdef HI_MULTI_THREADED
#define HI_FREE_SAP_RES(_sap)                           \
{                                                       \
   cmHashListDeinit(&_sap->sapHlCp);                    \
   SDestroyLock(&_sap->spConIdLock);                    \
   cmHashListDeinit(&_sap->spConIdHlCp);                \
   hiCb.sapLstPtr[_sap->spId] = NULLP;                  \
   HI_FREE(sizeof(HiSap), _sap);                        \
}
#else
#define HI_RELEASE_SAP_CON_LIST(_sap, _flag)            \
{                                                       \
   HiConCb *_conCb = NULLP;                             \
   while((ret = cmHashListGetNext(&(_sap->sapHlCp),     \
                                  NULLP,                \
                                  (PTR *)&(_conCb)))    \
                                  == ROK)               \
   {                                                    \
      hiFreeConCb(_conCb);                              \
      _conCb->action = FALSE;                           \
      hiScanConLst();                                   \
   }                                                    \
   if(_flag)                                            \
      (Void)cmHashListDeinit(&_sap->sapHlCp);           \
}
#endif /* HI_MULTI_THREADED */


/* Get this instance from the post structure */
#define HI_GET_THISINST(_tpst, _thisInst)               \
{                                                       \
   _thisInst = _tpst->dstInst - hiCb.lastInstUsed;      \
   _thisInst -= 1;                                      \
}

/* hi002.104 - Removing HI_DEL_FRM_FDGRP macro */

/* hi002.104 - Added a new macro to clear file descriptors from
 * the file descriptor sets */
#define HI_DEL_FRM_FDSET(_grpInfoPtr, _conCb, _list)        \
{                                                           \
   if (_list & HI_FDGRP_READ_LIST)                          \
      CM_INET_FD_CLR(&_conCb->conFd,                        \
                     &_grpInfoPtr->grpCb.readFdSet);        \
   if (_list & HI_FDGRP_WRITE_LIST)                         \
     CM_INET_FD_CLR(&_conCb->conFd,                         \
                     &_grpInfoPtr->grpCb.writeFdSet);       \
}

#ifdef HI_MULTI_THREADED   
#define HI_LOCK(_lockPtr, _alInfo, _retVal)                 \
{                                                           \
   _retVal = SLock(_lockPtr);                               \
   if (_retVal != ROK)                                      \
   {                                                        \
      hiSendAlarm(LCM_CATEGORY_INTERNAL,                    \
                  LCM_EVENT_INV_EVT,                        \
                  LHI_CAUSE_LOCK_ERR, &_alInfo);            \
   }                                                        \
}

#define HI_UNLOCK(_lockPtr, _alInfo, _retVal)               \
{                                                           \
   _retVal = SUnlock(_lockPtr);                             \
   if (_retVal != ROK)                                      \
   {                                                        \
      hiSendAlarm(LCM_CATEGORY_INTERNAL,                    \
                  LCM_EVENT_INV_EVT,                        \
                  LHI_CAUSE_UNLOCK_ERR, &_alInfo);          \
   }                                                        \
}

#endif /* HI_MULTI_THREADED */

#define HI_NOMORE_CONCBS_IN_LIST(_hashListCp)               \
   (_hashListCp.nmbEnt == 0)

#define HI_NUMCONCBS_IN_LIST(_hashListCp)                   \
   (_hashListCp.nmbEnt)                                  

#endif /* HI_LPBK */

/* Get the offset of a field in a structure */
#define HI_GET_OFFSET(_type, _member)  ((U32)(&(((_type *) 0)->_member)))

/* hi009.104 - addition - following dependency checks to be moved to envopt
   file in next release */   
/* added for Rolling upgrade */
/**************** Define dependency checks (DO NOT CHANGE!!) *****************/

#ifdef TDS_ROLL_UPGRADE_SUPPORT
#ifndef TDS_CORE2
#error "Rolling upgrade feature available in CORE II only."
#endif
#endif

#ifdef HI_RUG
#ifndef TDS_ROLL_UPGRADE_SUPPORT
#error "HI_RUG cannot be defined without TDS_ROLL_UPGRADE_SUPPORT"
#endif
#endif /* HI_RUG */

#ifdef HI_RUG
#ifndef HIT2 
#error "HIT2 flag is mandatory for rolling upgrade. Please enable"
#endif
#endif /* HI_RUG */

#endif /* __HIH__ */
 

/********************************************************************30**
 
         End of file:     hi.h@@/main/4 - Thu Jun 28 13:29:24 2001

*********************************************************************31*/
 

/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 

/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      asa  1. initial release.
1.1+         hi002.11 asa  1. Changes for loopback mode
/main/2       ---      cvp   1. Added defines for HI_MAX_FD_PER_FD_SET 
                              and HI_FD_BLK_NUM_BINS
                           2. Changed the copyright header.
/main/4      ---      sb    1. changes for Raw socket support.
/main/4+     hi003.13 cvp  1. Added the define HI_NUM_UDP_MSGS_TO_READ
                           2. Added the define HI_FL_PRIOR 
                           3. Added the define HI_MAX_CONS_TO_ACCEPT
                           4. Added the define HI_NUM_RAW_MSGS_TOREAD     
/main/4+     hi004.13 cvp  1. Calling hiScanConLst() from the macro
                              HI_RELEASE_SAP_CON_LIST.
/main/4      ---           1. Multi-threaded related macros.
                           2. IPv6 related changes.
                           3. Changed the header.
/main/4+    hi002.104 mmh  1. Added a new macro HI_DEL_FRM_FDSET.
                           2. Deleted macro HI_DEL_FRM_FDGRP.
/main/4+    hi007.104 mmh  1. Removed the defines of
                              HI_MAX_FD_PER_FD_SET and
                              HI_FD_BLK_NUM_BINS.
                           2. define HI_DEL_FRM_FDSET under HI_LPBK.            
/main/4+    hi009.104 mmh  1. Rolling upgrade changes, under compile flag
                              HI_RUG as per tcr0020.txt:
                           -  DEPENDENCY CHECK for rolling upgrade feature is
                              added. This check list to be moved to envopt
                              file in next release.
                           2. calling cmInetDeInit after closing socket
/main/4+    hi018.104 rs   1. Maximum number of connections
/main/4+    hi025.104 pr   1. SS_MULTIPLE_PROCS flag added.
*********************************************************************91*/
