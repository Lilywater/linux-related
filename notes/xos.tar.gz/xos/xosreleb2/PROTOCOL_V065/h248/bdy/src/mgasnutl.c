/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                          All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     Mg asn mapping functions
  
     Type:     C Source file
  
     Desc:     C source code for Mg ans.1 mapping functions
  
     File:     mgasnutl.c
  
     Sid:      mgasnutl.c@@/main/mgcp_rel_1.5_dev/gcp_mgcov2_dev/14 - Mon Feb 14 10:44:14 2005
  
     Prg:      
  
*********************************************************************21*/


/************************************************************************
 

************************************************************************/
 
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#ifdef GCP_ASN

#include <ctype.h>
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tkns.h"       /* common token structures */
#include "cm_mblk.h"       /* common event memory management */
#include "cm_tpt.h"        /* TPT header file */
#include "cm_dns.h"        /* DNS header file */

#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */

#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#include "cm_abnf.h"       /* ABNF header file */
#include "cm_sdp.h"        /* SDP header file */
#include "mgt.h"           /* ABNF events header file */
#include "mg_asn.h"        /* ASN.1 header file */
#include "mgasndb1.h"       /* ASN.1 database */
#include "mgasnpdb.h"      /* ASN.1 package database */
#include "mgasndb2.h"      /* ASN.1 database tree */
#include "mgasnwrp.h"         /* encode/decode wrappers */
#ifdef MG_ASN_TEST
#include "mg_acc.h"        /* defines for MGCP acceptance tests */
#endif
#include "cm_hash.h"
#include "cm_llist.h"
#include "lmg.h"           /* layer management defines for MGCP */
#include "lhi.h"
#include "mg.h"
#include "mgasnutl.h"

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* general layer */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* common event memory management */
#include "cm_lib.x"        /* common structures */
#include "cm_tpt.x"        /* TPT structures */
#include "cm_dns.x"        /* DNS structures */

#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */

#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#include "cm_sdp.x"        /* SDP structures */
#include "cm_abnf.x"       /* ABNF structures */
#include "mg_asn.x"        /* ASN.1 structures */
#include "mg_db.x"
#include "mgco_db.x"       /* ABNF database */
#include "mgasnev.x"       /* ASN.1 events */
#include "mgasndb1.x"       /* ASN.1 database */
#include "mgasnpdb.x"      /* ASN.1 package database */
#include "mgt.x"           /* ABNF events */
#include "mgasnwrp.x"         /* encode/decode wrappers */
#include "cm_hash.x"
#include "cm_llist.x"
#ifdef GCP_PROV_MTP3
#include "cm_ss7.x"           /* layer management typedefs for MGCP */
#endif
#ifdef GCP_PROV_SCTP
#include "sct.h"           /* layer management typedefs for MGCP */
#include "sct.x"           /* layer management typedefs for MGCP */
#endif
#include "lmg.x"           /* layer management typedefs for MGCP */
#include "lhi.x"
#include "mg.x"
#include "mgasnutl.x"
                                                              

#define CM_ABNF_A2I(_str, _len, _val)                       \
{                                                           \
   U8 i;                                                    \
   U8 _base;                                                \
   U8 _start;                                               \
   _base = 10;                                              \
   _start = 0;                                              \
   (_val) = 0;                                              \
   if ((_str)[0] == '0')                                    \
   {                                                        \
      if ((_len) == 1)                                      \
         _base = 10;                                        \
      else if ((_str)[1] == 'x' || (_str)[1] == 'X')        \
      {                                                     \
         _base = 16;                                        \
         _start = 2;                                        \
      }                                                     \
      else                                                  \
      {                                                     \
         _base = 10; /* No support for octals */            \
         _start = 1;                                        \
      }                                                     \
   }                                                        \
   else                                                     \
   {                                                        \
      for (i = 0; i < (_len); i++)                          \
      {                                                     \
         if ( ((_str)[i] >= 'a' && (_str)[i] <= 'f') ||     \
              ((_str)[i] >= 'A' && (_str)[i] <= 'F')        \
            )                                               \
            {                                               \
               _base = 16;                                  \
            }                                               \
      }                                                     \
   }                                                        \
   if (_base == 10 || _base == 8)                           \
   {                                                        \
      for (i = _start; i < (_len); i++)                     \
      {                                                     \
         (_val) *= _base;                                   \
         (_val) += ((_str)[i] - '0');                       \
      }                                                     \
   }                                                        \
   else if (_base == 16)                                    \
   {                                                        \
      for (i = _start; i < (_len); i++)                     \
      {                                                     \
         (_val) *= _base;                                   \
         if ((_str)[i] >= '0' && (_str)[i] <= '9')          \
         {                                                  \
            (_val) += (_str)[i] - '0';                      \
         }                                                  \
         else if ((_str)[i] >= 'A' && (_str)[i] <= 'F')     \
         {                                                  \
            (_val) += (_str)[i] - 'A' + 10;                 \
         }                                                  \
         else if ((_str)[i] >= 'a' && (_str)[i] <= 'f')     \
         {                                                  \
            (_val) += (_str)[i] - 'a' + 10;                 \
         }                                                  \
         else                                               \
         {                                                  \
            break;                                          \
         }                                                  \
      }                                                     \
   }                                                        \
}                                                              

/* mg003.105: Add - Added new macro for H2A conversion */
#define CM_ABNF_H2A(_val, _str, _len)                       \
{                                                           \
   U8 _idx;                                                 \
   _idx = CM_ABNF_MAX_HEXUINTSZ - 1 - 2;                        \
   (_len) = 0;                                              \
   do                                                       \
   {                                                        \
      (_str)[(_idx)] = ((U8 )((_val) & 0xF));               \
      if ((_str)[(_idx)] > 9)                               \
      {                                                     \
         (_str)[(_idx)] += 'A' - 10;                        \
      }                                                     \
      else                                                  \
      {                                                     \
         (_str)[(_idx)] += '0';                             \
      }                                                     \
      _idx--;                                               \
      (_val) /= 16; /* Don't use >> 4 (signed/unsigned) */  \
      (_len)++;                                             \
   } while (_val);                                          \
}

/* mg003.105: Added element definitions for double encoding(wrap) of ServiceChangeReason element */
static MgAsnElmntDef gcMsgSCROctetString =
{
#ifdef MG_ASN_DBG
  "gcMsgSCROctetString",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 505,  /* idNum */
  TET_SEQ,         /* element type */
  MG_ASN_UOCTSTR,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  0,   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
static MgAsnElmntDef gcMsgSCRIA5String =
{
#ifdef MG_ASN_DBG
  "gcMsgSCRIA5String",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 506,  /* idNum */
  TET_STROSXL_MEM,         /* element type */
  MG_ASN_UIA5,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),            /* database definition size */
  sizeof(TknStrOSXL),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr         /* user function */
};
static MgAsnElmntDef *mgaValue_scr[] = { &gcMsgSCROctetString, &gcMsgSCRIA5String, &gcMsgTheTerminator, NULLP };


/*
*
*       Fun:   mgaFuncMessageEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMessageEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMessageEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncMessageEnc);

   /* When we enter here, eventStr is pointing to MgMgcoMsg.ver,
    * a required field (and it was just encoded as pres...hack
    */
   ++msgCp->elmntDef;

   /* version */
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   /* mid */
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   /* message body */
   if ((*(msgCp->elmntDef))->idNum != gcMsgTheTerminator.idNum) {
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
   
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMessageDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMessageDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMessageDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16          ret;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncMessageDec);
   /* Pres just set in version */
   ++msgCp->elmntDef;
   msgCp->evntStr->pres = NOTPRSNT;
   /* version */
   if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   /* mid */
   if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   /* message body */
   if ((*(msgCp->elmntDef))->idNum != gcMsgTheTerminator.idNum) {
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncCommandRequestEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncCommandRequestEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncCommandRequestEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoCommandReq* evPtr;
   

   /* Different order */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncCommandRequestEnc);
   evPtr = (MgMgcoCommandReq*)msgCp->evntStr;
   ++msgCp->elmntDef;

   /* Command */
   msgCp->evntStr = (TknU8*)&(evPtr->cmd);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* Optional */
   msgCp->evntStr = (TknU8*)&(evPtr->opt);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* WildcardReturn */
   msgCp->evntStr = (TknU8*)&(evPtr->wild);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncCommandRequestDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncCommandRequestDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncCommandRequestDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgAsnElmntDef* elmntDef;
   MgMgcoCommandReq* evPtr;
   

   /* Different order */
   TRC2(mgaFuncCommandRequestDec);
   elmntDef = *(msgCp->elmntDef);
   evPtr = (MgMgcoCommandReq*)msgCp->evntStr;
   if (elmntDef->idNum == gcMsgCommand.idNum) {
      /* mg003.105: Fix for CommandRequestDec */
      evPtr->pres.pres = PRSNT_NODEF;
      msgCp->evntStr = (TknU8*)&(evPtr->cmd);
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if (elmntDef->idNum == gcMsgOptionalO.idNum) {
      msgCp->evntStr = (TknU8*)&(evPtr->opt);
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if (elmntDef->idNum == gcMsgWildcardReturnO.idNum) {
      msgCp->evntStr = (TknU8*)&(evPtr->wild);
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
   }
   msgCp->evntStr = (TknU8*)evPtr;

   RETVALUE(ret);
}

/* mg008.105: New function added for AmmRequestEnc */

/*
*
*       Fun:   mgaFuncAmmRequestEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncAmmRequestEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncAmmRequestEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoAmmReq* evPtr;

   TRC2(mgaFuncAmmRequestEnc);
   evPtr = (MgMgcoAmmReq*)msgCp->evntStr;

   evPtr->dl.num.pres = PRSNT_NODEF;
   msgCp->evntStr = (TknU8*)evPtr;

   ret = mgAsnEncSetSeq(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncServiceChangeResParmEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncServiceChangeResParmEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncServiceChangeResParmEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoSvcChgResPar* evPtr;
   

   /* Different order */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncServiceChangeResParmEnc);

   ++msgCp->elmntDef;
   evPtr = (MgMgcoSvcChgResPar*)msgCp->evntStr;
   msgCp->evntStr = (TknU8*)&(evPtr->mgcId);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   msgCp->evntStr = (TknU8*)&(evPtr->addr);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   msgCp->evntStr = (TknU8*)&(evPtr->ver);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   msgCp->evntStr = (TknU8*)&(evPtr->prof);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   msgCp->evntStr = (TknU8*)&(evPtr->time);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncServiceChangeResParmDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncServiceChangeResParmDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncServiceChangeResParmDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgAsnElmntDef* elmntDef;
   

   /* Different order */
   TRC2(mgaFuncServiceChangeResParmDec);
   elmntDef = *(msgCp->elmntDef);
   if(elmntDef->idNum == gcMsgMIdO0.idNum) {
      msgCp->evntStr = (TknU8*) ((long)msgCp->evntStr 
                     + (long)sizeof(MgMgcoSvcChgAddr)
                     + (long)sizeof(TknU8)
                     + (long)sizeof(TknU8)
                     + (long)sizeof(MgMgcoSvcChgProf) );
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if(elmntDef->idNum == gcMsgServiceChangeAddressO.idNum) {
      msgCp->evntStr = (TknU8*) ((long)msgCp->evntStr
                     - (long) sizeof(MgMgcoMid)
                     - (long) sizeof(MgMgcoSvcChgProf)
                     - (long) sizeof(TknU8)
                     - (long) sizeof(MgMgcoSvcChgAddr) );
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if(elmntDef->idNum == gcMsgServiceChangeVersionO.idNum) {
      /* we're in position */
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if(elmntDef->idNum == gcMsgServiceChangeProfileO.idNum) {
      /* we're in position */
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if(elmntDef->idNum == gcMsgTimeNotationO4.idNum) {
      msgCp->evntStr = (TknU8*) ((long)msgCp->evntStr
                     + (long)sizeof(MgMgcoTimeStamp) );
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
   }

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMediaDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMediaDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMediaDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret = ROK;
   S16 j;
   S16 found;
   MgMgcoMediaDesc* evPtr;
   MgMgcoMediaPar* parPtr;
   MgMgcoMediaDesc* savePtr;

   /* Sequence of a choice mapped to a sequence */
   /* From the MgMgcoMediaPar list, we need to encode at
    * most one termination state descriptor and 
    * then call the Streams encoder to handle the oneStream
    * or multistream
    */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncMediaDescriptorEnc);

   ++msgCp->elmntDef;
   evPtr = (MgMgcoMediaDesc*)msgCp->evntStr;
   savePtr = evPtr; 

   /* Termination State */
   found = 0;
   for(j=0; j<evPtr->num.val; ++j) {
      parPtr = evPtr->parms[j];
      if (parPtr->type.val != MGT_MEDIAPAR_TERMST)
         continue;
      if (found)
      {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
      }
      msgCp->evntStr = (TknU8*)&(parPtr->u.tstate);
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      ++found;
   }
   if (!found) {
      mgAsnSkipElmnt(msgCp);
   }

   /* reset event ptr for Streams encoding */
   /* mg003.105: checking for streams is available or not */
   if(found < evPtr->num.val)
   {
      msgCp->evntStr = (TknU8*)savePtr;    
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMediaDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMediaDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMediaDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoMediaDesc* evPtr;
   MgMgcoMediaDesc* tmpPtr;
   MgMgcoMediaPar* newPar;
   MgMgcaStreams streams;
   MgAsnElmntDef*  elmntDef;
   U8 j;

   TRC2(mgaFuncMediaDescriptorDec);

   elmntDef = *msgCp->elmntDef;
   evPtr=(MgMgcoMediaDesc*) (msgCp->evntStr);
   if (elmntDef->idNum == gcMsgTerminationStateDescriptorO.idNum) {
      (void)cmMemset((U8*)evPtr, 0, sizeof(MgMgcoMediaDesc));
      /* Termination State Descriptor */
      if (mgAsnDecGetMem(msgCp, (Ptr*)&newPar, (sizeof(MgMgcoMediaPar))) != ROK) { RETVALUE(RFAILED); }
      (void)cmMemset((U8*)newPar, 0, sizeof(MgMgcoMediaPar));
      msgCp->evntStr = (TknU8*) &(newPar->u.tstate);
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) {RETVALUE(ret);}
      if(newPar->u.tstate.numComp.pres) {
         newPar->type.pres = PRSNT_NODEF;
         newPar->type.val = MGT_MEDIAPAR_TERMST;
         if ((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->parms), &(evPtr->num), (Ptr*)&newPar, 1)) != ROK) {
            RETVALUE(ret);
         }
      } else {
         if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newPar)) != ROK) { RETVALUE(ret); }
      }

   } else if (elmntDef->idNum == gcMsgStreamsO.idNum) {
      /* Streams */
      (void)cmMemset((U8*)&streams, 0, sizeof(MgMgcaStreams));
      msgCp->evntStr = (TknU8*) &streams;
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      if(streams.id.pres) {
         /* add to list */
         evPtr->num.pres = PRSNT_NODEF;
         /* mg002.105: Removed compilation warning */
		 /* mg003.105: Modify - fixes for the Media Descriptor */
         /* mg007.105: modified for the media descriptor */
         if(streams.id.val == 2)
         {
            if (mgAsnDecGetMoreMem(msgCp, (Ptr*)&(evPtr->parms), (MsgLen)((evPtr->num.val + streams.u.multiStream.num.val) * sizeof(MgMgcoMediaPar*)), (MsgLen)(evPtr->num.val * sizeof(MgMgcoMediaPar*))) != ROK) { RETVALUE(RFAILED); }
            /* mg007.105: modified for the local control descriptor */
            for (j=evPtr->num.val;j<(streams.u.multiStream.num.val+evPtr->num.val);j++)
            {
               if (mgAsnDecGetMoreMem(msgCp, (Ptr*)&(evPtr->parms[j]), (MsgLen)(sizeof(MgMgcoMediaPar)), (MsgLen)(evPtr->num.val * sizeof(MgMgcoMediaPar))) != ROK) { RETVALUE(RFAILED); }
               evPtr->parms[j]->type.pres = PRSNT_NODEF;
               evPtr->parms[j]->type.val = MGT_MEDIAPAR_STRPAR;
               cmMemcpy( (U8*)&(evPtr->parms[j]->u.stream), (U8*)streams.u.multiStream.multiStream[j - evPtr->num.val], sizeof(MgMgcoMediaPar) );
            }
            evPtr->num.val += streams.u.multiStream.num.val;
         }
         else if(streams.id.val == 1)
         {
            if(streams.u.oneStream.pres.pres == PRSNT_NODEF)
            {
               tmpPtr = (MgMgcoMediaDesc*)&(streams.u.oneStream);

               if (mgAsnDecGetMoreMem(msgCp, (Ptr*)&(evPtr->parms), (MsgLen)((evPtr->num.val + tmpPtr->num.val) * sizeof(MgMgcoMediaPar*)), (MsgLen)(evPtr->num.val * sizeof(MgMgcoMediaPar*))) != ROK) { RETVALUE(RFAILED); }
               for (j=evPtr->num.val;j<(tmpPtr->num.val+evPtr->num.val);j++)
               {
                  if (mgAsnDecGetMoreMem(msgCp, (Ptr*)&(evPtr->parms[j]), (MsgLen)(sizeof(MgMgcoMediaPar)), (MsgLen)(evPtr->num.val * sizeof(MgMgcoMediaPar))) != ROK) { RETVALUE(RFAILED); }
                  evPtr->parms[j]->type.pres = PRSNT_NODEF;
                  if(tmpPtr->parms[j - evPtr->num.val]->type.val == MGT_MEDIAPAR_LOCCTL)
                  {
                     evPtr->parms[j]->type.val = MGT_MEDIAPAR_LOCCTL;
                     cmMemcpy( (U8*)&(evPtr->parms[j]->u.locCtl), (U8*)&(tmpPtr->parms[j - evPtr->num.val]->u.locCtl), sizeof(MgMgcoMediaPar) );
                  }
                  else if(tmpPtr->parms[j - evPtr->num.val]->type.val == MGT_MEDIAPAR_LOCAL)
                  {
                     evPtr->parms[j]->type.val = MGT_MEDIAPAR_LOCAL;
                     cmMemcpy( (U8*)&(evPtr->parms[j]->u.local), (U8*)&(tmpPtr->parms[j - evPtr->num.val]->u.local), sizeof(MgMgcoMediaPar) );
                  }
                  else if(tmpPtr->parms[j - evPtr->num.val]->type.val == MGT_MEDIAPAR_REMOTE)
                  {
                     evPtr->parms[j]->type.val = MGT_MEDIAPAR_REMOTE;
                     cmMemcpy( (U8*)&(evPtr->parms[j]->u.remote), (U8*)&(tmpPtr->parms[j - evPtr->num.val]->u.remote), sizeof(MgMgcoMediaPar) );
                  }
               }
               evPtr->num.val += tmpPtr->num.val;
            }
         }
      }
   } else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
   }
   msgCp->evntStr = (TknU8*)evPtr;

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncStreamParmsSpecialEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncStreamParmsSpecialEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncStreamParmsSpecialEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoMediaDesc* evPtr;
   MgMgcoMediaPar* parPtr;
   MgMgcoMediaPar* locCtlPtr = NULLP;
   MgMgcoMediaPar* locPtr = NULLP;
   MgMgcoMediaPar* rmtPtr = NULLP;
   S16 j;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncStreamParmsSpecialEnc) 

   ++msgCp->elmntDef;
   evPtr = (MgMgcoMediaDesc*) ((long)msgCp->evntStr - (long)sizeof(TknU8));

   for(j=0; j<evPtr->num.val; ++j) {
      parPtr = evPtr->parms[j];
      if(parPtr->type.val == MGT_MEDIAPAR_LOCCTL) {
         locCtlPtr = parPtr;
      } else if(parPtr->type.val == MGT_MEDIAPAR_LOCAL) {
         locPtr = parPtr;
      } else if(parPtr->type.val == MGT_MEDIAPAR_REMOTE) {
         rmtPtr = parPtr;
      }
   }
   if(locCtlPtr == NULLP) {
      mgAsnSkipElmnt(msgCp); 
   } else {
      msgCp->evntStr = (TknU8*)&(locCtlPtr->u.locCtl);
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   if(locPtr == NULLP) {
      mgAsnSkipElmnt(msgCp); 
   } else {
      msgCp->evntStr = (TknU8*)&(locPtr->u.local);
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
   
   if(rmtPtr == NULLP) {
      mgAsnSkipElmnt(msgCp); 
   } else {
         msgCp->evntStr = (TknU8*)&(rmtPtr->u.remote);
         if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncStreamParmsSpecialDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncStreamParmsSpecialDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncStreamParmsSpecialDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   MgMgcoMediaPar* newPar;
   MgMgcoMediaDesc* evPtr;
   MsgLen               elmntLen;       /* element length */
   MsgLen               prevLen;        /* previous length */

   S16 ret;
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncStreamParmsSpecialDec);

   /* decode the values and construct a list of Media Pars */
   evPtr = (MgMgcoMediaDesc*) (msgCp->evntStr);
   (void)cmMemset((U8*)evPtr, 0, sizeof(MgMgcoMediaDesc));
   ++msgCp->elmntDef;

   elmntLen = msgCp->elmntLen;
   prevLen = mgAsnFindLen(msgCp);
   if (mgAsnDecGetMem(msgCp, (Ptr*)&newPar, sizeof(MgMgcoMediaPar)) != ROK) { RETVALUE(RFAILED); }

   (void)cmMemset((U8*)newPar, 0, sizeof(MgMgcoMediaPar));
   msgCp->evntStr = (TknU8*) &(newPar->u.locCtl);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) 
   {
      RETVALUE(ret);
   }
   
   if(newPar->u.locCtl.num.pres) {
      newPar->type.pres = PRSNT_NODEF;
      newPar->type.val = MGT_MEDIAPAR_LOCCTL;
      if ((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->parms), &(evPtr->num), (Ptr*)&newPar, 1)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newPar)) != ROK) { RETVALUE(ret); }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) { RETVALUE(mgAsnChkSeqMandMis(msgCp)); }

   /* mg003.105: Modify - Fix for Remote Descriptor    */
   prevLen = mgAsnFindLen(msgCp);
   if (mgAsnDecGetMem(msgCp, (Ptr*)&newPar, sizeof(MgMgcoMediaPar)) != ROK) { RETVALUE(RFAILED); }
   (void)cmMemset((U8*)newPar, 0, sizeof(MgMgcoMediaPar));
   msgCp->evntStr = (TknU8*) &(newPar->u.local);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK)
   {
      RETVALUE(ret);
   }
   if(newPar->u.local.pres.pres) {
      newPar->type.pres = PRSNT_NODEF;
      newPar->type.val = MGT_MEDIAPAR_LOCAL;
      if ((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->parms), &(evPtr->num), (Ptr*)&newPar, 1)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newPar)) != ROK) { RETVALUE(ret); }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) { RETVALUE(mgAsnChkSeqMandMis(msgCp)); }

   if (mgAsnDecGetMem(msgCp, (Ptr*)&newPar, sizeof(MgMgcoMediaPar)) != ROK) { RETVALUE(RFAILED); }
   (void)cmMemset((U8*)newPar, 0, sizeof(MgMgcoMediaPar));
   msgCp->evntStr = (TknU8*) &(newPar->u.remote);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK)
   {
      RETVALUE(ret);
   }
   if(newPar->u.remote.pres.pres) {
      newPar->type.pres = PRSNT_NODEF;
      newPar->type.val = MGT_MEDIAPAR_REMOTE;
      if ((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->parms), &(evPtr->num), (Ptr*)&newPar, 1)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newPar)) != ROK) { RETVALUE(ret); }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMultiStreamEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMultiStreamEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMultiStreamEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   
   TRC2(mgaFuncMultiStreamEnc);
   /* We're assuming the list of MediaPar's at evntStr only has 
    * MGT_MEDIAPAR_STRPAR vals
    */
   /* msgCp->evntStr = (TknU8*)((long)msgCp->evntStr - (long)sizeof(TknU8)); */
   if((ret = mgAsnEncUnconsSetSeqOf(msgCp)) != ROK) { RETVALUE(ret); }

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncStreamsEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncStreamsEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncStreamsEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret = ROK;
   MgMgcaStreams streams;
   MgMgcoMediaDesc* evPtr;
   MgMgcoMediaPar* parPtr;
   MgMgcoMediaPar** newParPtrList;
   MgMgcoMediaPar** curNewPtr;
   U8 saveSpare1;
   S16 j;
   S16 foundMulti = 0;
   S16 foundOneStr = 0;
   S16 foundLocCtl = 0;
   S16 foundLoc = 0;
   S16 foundRmt = 0;
   

   /* Streams is a choice between oneStream or MultiStream.
    * if oneStream, set id, construct a MgMgcoStreamParm and
    * encode it 
    * if multistream, set up id 
    */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncStreamsEnc);
   evPtr = (MgMgcoMediaDesc*) ((long) msgCp->evntStr);

   /* Choose if onestream or multi-stream */
   for(j=0; j<evPtr->num.val; ++j) {
      parPtr = evPtr->parms[j];
      if(parPtr->type.val == MGT_MEDIAPAR_STRPAR) {
         ++foundMulti;
      } else if (parPtr->type.val == MGT_MEDIAPAR_LOCCTL) {
         ++foundOneStr;
         ++foundLocCtl;
      } else if (parPtr->type.val == MGT_MEDIAPAR_LOCAL) {
         ++foundOneStr;
         ++foundLoc;
      } else if (parPtr->type.val == MGT_MEDIAPAR_REMOTE) {
        ++foundOneStr;
        ++foundRmt;
      }
   }
   
   if( (foundMulti > 0) && (foundOneStr > 0) ) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   } else if ( foundOneStr > 0 ) {
      /* Some err checking */
      if( (foundLoc > 1) || (foundLocCtl > 1) || (foundRmt > 1) ) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
      } 

      /* This will twist your melon - Need to hijack the spare1
       * var to fake a choice encoding
       */
      saveSpare1 = evPtr->num.spare1;
      evPtr->num.spare1 = 1;
      /* Following should call the "Special" stream parms */
      if((ret = mgAsnEncChoice(msgCp)) != ROK) { RETVALUE(ret); }
      evPtr->num.spare1 = saveSpare1;

   } else if (foundMulti > 0 ) {
      /* mg002.105: Removed compilation warning */
      if (mgAsnEncGetMem(msgCp, (Ptr*)&newParPtrList, (MsgLen)(foundMulti * sizeof(MgMgcoMediaPar*))) != ROK) { RETVALUE(RFAILED); }
      curNewPtr = newParPtrList;
      for(j=0; j<evPtr->num.val; ++j) {
         parPtr = evPtr->parms[j];
         if(parPtr->type.val == MGT_MEDIAPAR_STRPAR) {
            *curNewPtr = (MgMgcoMediaPar*)&parPtr->u.stream;
            curNewPtr++;
         }
      }

      /* Save, copy, restore */
      (void)cmMemset((U8*)&streams, 0, sizeof(streams));
      streams.id.pres = PRSNT_NODEF;
      streams.id.val = 2;
      streams.u.multiStream.num.pres = PRSNT_NODEF;
      streams.u.multiStream.num.val = foundMulti;
      streams.u.multiStream.multiStream = (MgMgcaStreamDescriptor**)newParPtrList;
      msgCp->evntStr = (TknU8*)&streams;
      if((ret = mgAsnEncChoice(msgCp)) != ROK) {
         /* mg002.105: Removed compilation warning */
         if (mgAsnEncPutMem(msgCp, (Ptr)newParPtrList, (MsgLen)(foundMulti * sizeof(MgMgcoMediaPar*))) != ROK) { RETVALUE(RFAILED); }
         RETVALUE(ret);
      }
      /* mg002.105: Removed compilation warning */
      if (mgAsnEncPutMem(msgCp, (Ptr)newParPtrList, (MsgLen)(foundMulti * sizeof(MgMgcoMediaPar*))) != ROK) { RETVALUE(RFAILED); }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);  
}


/*
*
*       Fun:   mgaFuncMuxDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMuxDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMuxDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret = ROK;
   MgMgcoMuxDesc* evPtr;
   

   /* Different order */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncMuxDescriptorEnc);

   ++msgCp->elmntDef;
   evPtr = (MgMgcoMuxDesc*)msgCp->evntStr;

   /* MuxType */
   msgCp->evntStr = (TknU8*)&(evPtr->type);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* TermList */
   msgCp->evntStr = (TknU8*)&(evPtr->tl);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* NonStandardData */
   if (evPtr->id.type.pres) {
      MgMgcoNonStdExtn tmpVal;

      cmMemset((U8 *)&tmpVal, 0, sizeof(tmpVal));
      msgCp->evntStr = (TknU8*)&tmpVal;
      tmpVal.pres.pres = PRSNT_NODEF;
      cmMemcpy((U8*)&tmpVal.id, (U8*)&(evPtr->id), sizeof(MgMgcoNonStdId));
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMuxDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMuxDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMuxDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgAsnElmntDef* elmntDef;
   

   /* Different order */
   TRC2(mgaFuncMuxDescriptorDec);
   elmntDef = *(msgCp->elmntDef);
   if(elmntDef->idNum == gcMsgMuxType.idNum) {
      msgCp->evntStr = (TknU8*)((long)msgCp->evntStr + (long)sizeof(TknPres));
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if(elmntDef->idNum == gcMsgTermList.idNum) {
      msgCp->evntStr = (TknU8*) ((long)msgCp->evntStr 
                     + (long) sizeof(MgMgcoNonStdId) );
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if(elmntDef->idNum == gcMsgNonStandardDataO2.idNum) {
      MgMgcoNonStdExtn tmpVal;
      MgMgcoNonStdId *evPtr;

      cmMemset((U8 *)&tmpVal, 0, sizeof(tmpVal));
      msgCp->evntStr = (TknU8*) ((long)msgCp->evntStr 
                     - (long) sizeof(MgMgcoTermIdLst) 
                     - (long) sizeof(MgMgcoNonStdId) );
      evPtr = (MgMgcoNonStdId*)msgCp->evntStr;
      msgCp->evntStr = (TknU8*)&tmpVal;
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      cmMemcpy((U8*)evPtr, (U8*)&(tmpVal.id), sizeof(MgMgcoNonStdId));
   } else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
   }

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncActionReplyEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncActionReplyEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncActionReplyEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16          ret;            /* return value */
   MgMgcoActnReply* evPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncActionReplyEnc);
   evPtr = (MgMgcoActnReply*)msgCp->evntStr;
   ++msgCp->elmntDef;
   /* mg003.105: Modify - point event structure to context id */
   msgCp->evntStr = (TknU8*)(&(evPtr->cxtId));  /* mg007.105: passing context id event structure */
   /* encode ContextId */
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
/* 
 * mg003.105: Bug Fixes 	  
 * Check for repErrSer.reply present token before calling 
 * Encoder function for repErrSer.reply
 */

#ifdef MGT_GCP_VER_1_4
   msgCp->evntStr = (TknU8*)(&(evPtr->repErrSet.err));
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   /*msgCp->evntStr = &(evPtr->repErrSet.reply);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }*/
   if (evPtr->repErrSet.reply.pres.pres) {
      /* encode CxtCmdReply */
      msgCp->evntStr = (TknU8*)(&(evPtr->repErrSet.reply.cxt));
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
   else
   {
      /* mg008.105: if command reply is absent skip contextrequest and
       * encode tag and length 00 */
      mgAsnSkipElmnt(msgCp);  /* skip contextrequest */
   }

   evPtr->repErrSet.reply.cl.num.pres = PRSNT_NODEF;
   msgCp->evntStr = (TknU8*)(&(evPtr->repErrSet.reply.cl));
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

#else
   /* encode error descriptor and/or reply */
   if (evPtr->type.val == MGT_ERRDESC) {
      msgCp->evntStr = (TknU8*)&(evPtr->u.err);
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
   else {
      MG_ASN_SKIP_TKNPRES(msgCp);
      mgAsnSkipElmnt(msgCp); /* skip ErrDesc */
      if (evPtr->u.reply.pres.pres) {
         /* encode CxtCmdReply */
         msgCp->evntStr = (TknU8*)(&(evPtr->u.reply.cxt));
         if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      }
      else
      {
         /* mg008.105: if command reply is absent skip contextrequest and
          * encode tag and length 00 */
         mgAsnSkipElmnt(msgCp); /* skip contextrequest */
      }

      evPtr->u.reply.cl.num.pres = PRSNT_NODEF;
      msgCp->evntStr = (TknU8*)(&(evPtr->u.reply.cl));
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
#endif

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncActionReplyDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncActionReplyDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncActionReplyDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16          ret;            /* return value */
   MgAsnElmntDef* elmntDef;

#ifdef MGT_GCP_VER_1_4
   PRIVATE MgMgcoActnReply *evPtr;
#else
   TknPres* presPtr;
   TknU8* typePtr;
#endif


   TRC2(mgaFuncActionReplyDec);

   /* get the pointer to the next element definition */
   elmntDef = *msgCp->elmntDef;

   if (elmntDef->idNum == gcMsgContextID.idNum) {
#ifdef MGT_GCP_VER_1_4
      /* 
       * mg003.105: Save the Starting of Action Reply to evPtr 
       * since msgCp->evntStr is a sliding pointer so make a copy of this pointer
       * into Static Variable Pointer
       */
      evPtr = (MgMgcoActnReply*)msgCp->evntStr;
      evPtr->pres.pres = PRSNT_NODEF;
#endif
      msgCp->evntStr = (TknU8*)((long)msgCp->evntStr + (long)sizeof(TknU8));
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
   else if (elmntDef->idNum == gcMsgErrorDescriptorO1.idNum) {
#ifdef MGT_GCP_VER_1_4
      evPtr->repErrSet.pres.pres = PRSNT_NODEF;
      msgCp->evntStr = (TknU8*)(&(evPtr->repErrSet.err));
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      evPtr->repErrSet.pres.pres = evPtr->repErrSet.err.pres.pres;
#else
      /* Type */
      typePtr = msgCp->evntStr;
      typePtr->pres = PRSNT_NODEF;
      typePtr->val = MGT_ERRDESC;
      msgCp->evntStr = (TknU8*)((long)msgCp->evntStr + (long)sizeof(TknU8));

      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
#endif
   }
   else if (elmntDef->idNum == gcMsgContextRequestO2.idNum) {
#ifdef MGT_GCP_VER_1_4	  
      /* mg003.105: Bug Fixes 
       * Fill the presnt token of reply.pres.pres
       * Increment the evntStr pointer to skip tknPres field
       */
      msgCp->evntStr = (TknU8*)(&(evPtr->repErrSet.reply));
      evPtr->repErrSet.reply.pres.pres = PRSNT_NODEF;
      /*typePtr = msgCp->evntStr;
      typePtr->pres = PRSNT_NODEF;
      typePtr->val = MGT_CXTCMDREPLY;*/
      msgCp->evntStr = (TknU8*)((long)msgCp->evntStr + (long)sizeof(TknPres));
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      if (! evPtr->repErrSet.pres.pres) {
         evPtr->repErrSet.pres.pres = evPtr->repErrSet.reply.pres.pres;
      }
#else
      /* Union, so backspace over Error descriptor */
      msgCp->evntStr = (TknU8*)((long)msgCp->evntStr - (long)sizeof(MgMgcoErrDesc));
      msgCp->evntStr = (TknU8*)((long)msgCp->evntStr - (long)sizeof(TknPres));
      typePtr = msgCp->evntStr;
      typePtr->pres = PRSNT_NODEF;
      typePtr->val = MGT_CXTCMDREPLY;
      msgCp->evntStr = (TknU8*)((long)msgCp->evntStr + (long)sizeof(TknPres));
      presPtr = (TknPres*)msgCp->evntStr;
      presPtr->pres = PRSNT_NODEF;
      /* Skip pres */
      msgCp->evntStr = (TknU8*)((long)msgCp->evntStr + (long)sizeof(TknPres));
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
#endif
   }
   else if (elmntDef->idNum == gcMsgCommandReplyList.idNum) {
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncObservedEventEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncObservedEventEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncObservedEventEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16          ret;            /* return value */
   MgMgcoObsEvt* evPtr;
   S16 foundOther = 0;
   S16 found = 0;
   S16 j;
   MgMgcoStreamId* streamId;
   MgMgcoEvtParLst newEvParLst;
   MgMgcoEvtPar* curPar;
   MgMgcoEvtPar* parPtr;
   MgMgcoEvtPar** curEvPar;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncObservedEventEnc);
   ++msgCp->elmntDef;
   evPtr = (MgMgcoObsEvt*)msgCp->evntStr;

   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      msgCp->secElmntDef = (MgAsnElmntDef**)mgaPkgObsEvts[evPtr->pkg.val - 1];
   } else if(evPtr->pkg.val == 0) {
      /* allow it, but it's not defined */
      msgCp->secElmntDef = NULLP;
   }

   /* pkgdName */
   msgCp->evntStr = (TknU8*)&(evPtr->pkg);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* Stream ID */
   found = 0;
   if ((evPtr->pl.num.pres) && (evPtr->pl.num.val != 0)) {
      if (evPtr->pl.parms == NULL)
      {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
      }
      for (j=0; j<(evPtr->pl.num.val); ++j) {
         curPar = evPtr->pl.parms[j];
         if (curPar->type.val == MGT_EVTPAR_STREAMID) {
            ++found;
            streamId = &(curPar->u.streamId);
         }
         if(evPtr->pl.parms[j]->type.val == MGT_EVTPAR_OTHER) {
            ++foundOther;
         }
      }
      if(found > 1) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
      } else if(found == 1) {
         msgCp->evntStr = (TknU8*)(streamId);
         if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      } else {
         mgAsnSkipElmnt(msgCp);
      }

      /* EventParList */
      if(foundOther < 1) {
#ifdef MG_ASN_TEST
         msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;
         MGAFUNCSKIP(msgCp);
         RETVALUE(ROK);
#else
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
#endif
      } else {
         /* mg002.105: Removed compilation warning */
         if (mgAsnEncGetMem(msgCp, (Ptr*)&(newEvParLst.parms), (MsgLen)(foundOther * sizeof(MgMgcoEvtParSec*))) != ROK) { RETVALUE(RFAILED); }
         curEvPar = newEvParLst.parms;
         for(j=0; j<evPtr->pl.num.val; ++j) {
            parPtr = evPtr->pl.parms[j];
            if(parPtr->type.val == MGT_EVTPAR_OTHER) {
               *(curEvPar) = parPtr;
               ++curEvPar;
            }
         }
         newEvParLst.num.val = foundOther;
         newEvParLst.num.pres = PRSNT_NODEF;
         msgCp->evntStr = (TknU8*) &(newEvParLst);
         if((ret = mgAsnEncElmnt(msgCp)) != ROK) {
            /* mg002.105: Removed compilation warning */
            if (mgAsnEncPutMem(msgCp, (Ptr)newEvParLst.parms, (MsgLen)(foundOther * sizeof(MgMgcoEvtParSec*))) != ROK) { RETVALUE(RFAILED); }
            RETVALUE(ret);
         }
         /* mg002.105: Removed compilation warning */
         if (mgAsnEncPutMem(msgCp, (Ptr)newEvParLst.parms, (MsgLen)(foundOther * sizeof(MgMgcoEvtParSec*))) != ROK) { RETVALUE(RFAILED); }
      }
   } else {
      mgAsnSkipElmnt(msgCp);
      /* mg003.105: Encode empty parameter list if it is absent in observed event */
      /* Encode empty list */
      newEvParLst.num.val = 0;
      newEvParLst.num.pres = PRSNT_NODEF;
      newEvParLst.parms = NULL;
      msgCp->evntStr = (TknU8*) &(newEvParLst);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) {
         RETVALUE(ret);
      }
   }

   /* TimeNotation */
   msgCp->evntStr = (TknU8*)&(evPtr->time);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncObservedEventDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncObservedEventDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncObservedEventDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16          ret;            /* return value */
   MgAsnElmntDef* elmntDef;
   MgMgcoEvtPar* newPar;
   MgMgcoStreamId streamIdVal;
   MgMgcoEvtParLst plVal;
   MgMgcoObsEvt* evPtr;
   TknU8* savePtr;
   MgaPkg* pkgName;

   /* Different Order */
   TRC2(mgaFuncObservedEventDec);
   evPtr = (MgMgcoObsEvt*) msgCp->evntStr;
   savePtr = msgCp->evntStr;
   elmntDef = *(msgCp->elmntDef);

   if (elmntDef->idNum == gcMsgPkgdName0.idNum) {
      msgCp->evntStr = (TknU8*) &(evPtr->pkg);
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      /* Error check the package id */
      if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
         /* validate the name */
         pkgName = mgaPkgObsEvts[evPtr->pkg.val - 1];
         if(pkgName != NULLP) {
            if( (evPtr->name.name.type.pres == PRSNT_NODEF) &&
               (evPtr->name.name.type.val == MGT_GEN_TYPE_KNOWN) &&
               (evPtr->name.name.u.val.val > 0) && 
               (evPtr->name.name.u.val.val <= pkgName->maxNumNames) )
            {
               if(pkgName->names[evPtr->name.name.u.val.val-1] != NULLP)
               {
                  msgCp->secElmntDef = (MgAsnElmntDef**)(pkgName->names[evPtr->name.name.u.val.val - 1]->value);
               } else {
#ifndef MG_ASN_TEST
                  MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
                  RETVALUE(RFAILED);
#endif
               }
            } else {
#ifndef MG_ASN_TEST
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(RFAILED);
#endif
            }
         }
      }
   } else if (elmntDef->idNum == gcMsgStreamIDO1.idNum) {
      /* This goes into our MgMgcoEvtParLst as a special case */
      (void)cmMemset((U8*)&streamIdVal, 0, sizeof(MgMgcoStreamId));
      msgCp->evntStr = (TknU8*) &streamIdVal;
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      if(streamIdVal.pres) {
         /* Add it to the list */
         if (mgAsnDecGetMem(msgCp, (Ptr*)&newPar, sizeof(MgMgcoEvtPar)) != ROK) { RETVALUE(RFAILED); }
         newPar->type.pres = PRSNT_NODEF;
         newPar->type.val = MGT_EVTPAR_STREAMID;
         cmMemcpy((U8*)&(newPar->u.streamId), (U8*)&streamIdVal, 
                   sizeof(MgMgcoStreamId));
         if ((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)&newPar, 1)) != ROK) {
            RETVALUE(ret);
         }
      }
   } else if(elmntDef->idNum == gcMsgEventParList.idNum) {
      (void) cmMemset((U8*)&plVal, 0, sizeof(MgMgcoEvtParLst));
      msgCp->evntStr = (TknU8*) &plVal;
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      /* Copy the new list to the existing list */
      if(plVal.num.pres && plVal.num.val > 0) {
         if ((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)plVal.parms, plVal.num.val)) != ROK) {
            RETVALUE(ret);
         }
      }
   } else if(elmntDef->idNum == gcMsgTimeNotationO3.idNum) {
      msgCp->evntStr = (TknU8*) &(evPtr->time);
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      /* Last item in seq, cleans up */
      msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;
   } else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
   }
   msgCp->evntStr = savePtr;
 
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncEventSpecEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncEventSpecEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncEventSpecEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16          ret;            /* return value */
   MgMgcoEvSpec* evPtr;
   S16 found;
   S16 foundOther;
   S16 j;
   MgMgcoStreamId* streamId;
   MgMgcoEvtPar* curPar;
   MgMgcoEvtParLst newEvParLst;
   MgMgcoEvtPar** curEvPar;
   MgMgcoEvtPar* parPtr;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncEventSpecEnc);
   evPtr = (MgMgcoEvSpec*)msgCp->evntStr;
   ++msgCp->elmntDef;

   /* PkgdName */
   msgCp->evntStr = (TknU8*)&(evPtr->pkg);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* see what we have */
   found = 0;
   foundOther = 0;
   if ((! evPtr->pl.num.pres) || (evPtr->pl.num.val == 0)) {
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }
   if (evPtr->pl.parms == NULL) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }
   curPar = *(evPtr->pl.parms);
   for (j=0; j<(evPtr->pl.num.val); ++j, ++curPar) {
      if (curPar->type.val == MGT_EVTPAR_STREAMID) {
         ++found;
         streamId = &(curPar->u.streamId);
      }
      if (curPar->type.val == MGT_EVTPAR_OTHER) {
         ++foundOther;
      }
   }

   /* Stream ID */
   if(found > 1) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   } else if (found == 1) {
      msgCp->evntStr = (TknU8*)(streamId);
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else {
      mgAsnSkipElmnt(msgCp);
   }
   if (foundOther) {
      /* mg002.105: Removed compilation warning */
      if (mgAsnEncGetMem(msgCp, (Ptr*)&(newEvParLst.parms), (MsgLen)(foundOther * sizeof(MgMgcoEvtParSec*))) != ROK) { RETVALUE(RFAILED); }
      curEvPar = newEvParLst.parms;
      for(j=0; j<evPtr->pl.num.val; ++j) {
         parPtr = evPtr->pl.parms[j];
         if(parPtr->type.val == MGT_EVTPAR_OTHER) {
            *(curEvPar) = parPtr;
            ++curEvPar;
         }
      }

      /* EventParList */
      newEvParLst.num.val = foundOther;
      newEvParLst.num.pres = PRSNT_NODEF;
      msgCp->evntStr = (TknU8*) &(newEvParLst);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) {
         /* mg002.105: Removed compilation warning */
         if (mgAsnEncPutMem(msgCp, (Ptr)newEvParLst.parms, (MsgLen)(foundOther * sizeof(MgMgcoEvtParSec*))) != ROK) { RETVALUE(RFAILED); }
         RETVALUE(ret);
      }
      /* mg002.105: Removed compilation warning */
      if (mgAsnEncPutMem(msgCp, (Ptr)newEvParLst.parms, (MsgLen)(foundOther * sizeof(MgMgcoEvtParSec*))) != ROK) { RETVALUE(RFAILED); }
   }
   else {
      /* mg003.105: Encode empty parameter list if it is absent in observed event */
      /* Encode empty list */
      newEvParLst.num.val = 0;
      newEvParLst.num.pres = PRSNT_NODEF;
      newEvParLst.parms = NULL;
      msgCp->evntStr = (TknU8*) &(newEvParLst);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) {
         RETVALUE(ret);
      }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncEventSpecDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncEventSpecDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncEventSpecDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16          ret;            /* return value */
   MgAsnElmntDef* elmntDef;
   MgMgcoEvtPar* newPar;
   MgMgcoStreamId streamIdVal;
   MgMgcoEvtParLst plVal;
   MgMgcoEvSpec* evPtr;
   TknU8* savePtr;

   TRC2(mgaFuncEventSpecDec);
   savePtr = msgCp->evntStr;
   evPtr = (MgMgcoEvSpec*)msgCp->evntStr;
   elmntDef = *(msgCp->elmntDef);
   if (elmntDef->idNum == gcMsgPkgdName0.idNum) {
      msgCp->evntStr = (TknU8*) &(evPtr->pkg);
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if ((elmntDef->idNum == gcMsgStreamID.idNum) ||
              (elmntDef->idNum == gcMsgStreamIDO1.idNum)) {
      (void)cmMemset((U8*)&streamIdVal, 0, sizeof(MgMgcoStreamId));
      msgCp->evntStr = (TknU8*) &streamIdVal;
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      if(streamIdVal.pres) {
         /* Add it to the list */
         /* mg002.105: Removed compilation warning */
         if (mgAsnDecGetMem(msgCp, (Ptr*)&newPar, sizeof(MgMgcoEvtPar)) != ROK) { RETVALUE(RFAILED); }
         newPar->type.pres = PRSNT_NODEF;
         newPar->type.val = MGT_EVTPAR_STREAMID;
         cmMemcpy((U8*)&(newPar->u.streamId), (U8*)&streamIdVal, 
                   sizeof(MgMgcoStreamId));
         if ((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)&newPar, 1)) != ROK) {
            RETVALUE(ret);
         }
      }
   } else if(elmntDef->idNum == gcMsgEventParList.idNum) {
      (void)cmMemset((U8*)&plVal, 0, sizeof(MgMgcoEvtParLst));
      msgCp->evntStr = (TknU8*) &plVal;
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      /* Copy the new list to the existing list */
      if(plVal.num.pres && plVal.num.val > 0) {
         evPtr->pl.num.pres = PRSNT_NODEF;
         if ((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)plVal.parms, plVal.num.val)) != ROK) {
            RETVALUE(ret);
         }
      }
   } else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
   }
 
   msgCp->evntStr = savePtr;
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncServiceChangeParmEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncServiceChangeParmEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncServiceChangeParmEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16          ret;            /* return value */
   MgMgcoSvcChgPar* evPtr;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncServiceChangeParmEnc);
   evPtr = (MgMgcoSvcChgPar*)msgCp->evntStr;
   ++msgCp->elmntDef;

   /* ServiceChangeMethod */
   msgCp->evntStr = (TknU8*)&(evPtr->meth);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* ServiceChangeAddress */
   msgCp->evntStr = (TknU8*)&(evPtr->addr);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* ServiceChangeVersion */
   msgCp->evntStr = (TknU8*)&(evPtr->ver);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* ServiceChangeProfile */
   msgCp->evntStr = (TknU8*)&(evPtr->prof);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* ServiceChangeReason */
   msgCp->evntStr = (TknU8*)&(evPtr->reason);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* ServiceChangeDelay */
   msgCp->evntStr = (TknU8*)&(evPtr->delay);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* MId */
   msgCp->evntStr = (TknU8*)&(evPtr->mgcId);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* TimeNotation */
   msgCp->evntStr = (TknU8*)&(evPtr->time);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* NonStandardData */
   msgCp->evntStr = (TknU8*)&(evPtr->extn);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* AuditDescriptor */
#ifdef MGT_MGCO_V2
   if(evPtr->auditItem.auditItem.pres == PRSNT_NODEF) {
      msgCp->evntStr = (TknU8*)&(evPtr->auditItem);
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
#endif

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncServiceChangeParmDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncServiceChangeParmDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncServiceChangeParmDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16          ret;            /* return value */
   MgAsnElmntDef*  elmntDef;

   TRC2(mgaFuncServiceChangeParmDec);

   /* Different Order */
   elmntDef = *(msgCp->elmntDef);
   if (elmntDef->idNum == gcMsgServiceChangeMethod.idNum) {
      msgCp->evntStr = (TknU8*)((long)msgCp->evntStr + (long)sizeof(MgMgcoNonStdExtn) + (long)sizeof(TknPres));
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if (elmntDef->idNum == gcMsgServiceChangeAddressO.idNum) {
      /* we're in position */
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if (elmntDef->idNum == gcMsgServiceChangeVersionO.idNum) {
      /* we're in position */
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if (elmntDef->idNum == gcMsgServiceChangeProfileO.idNum) {
      /* we're in position */
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if (elmntDef->idNum == gcMsgServiceChangeReason.idNum) {
      /* we're in position */
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if (elmntDef->idNum == gcMsgServiceChangeDelayO.idNum) {
      /* we're in position */
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if ((elmntDef->idNum == gcMsgMId.idNum) ||
              (elmntDef->idNum == gcMsgMIdO6.idNum)) {
      /* we're in position */
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if (elmntDef->idNum == gcMsgTimeNotationO7.idNum) {
      /* we're in position */
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if (elmntDef->idNum == gcMsgNonStandardDataO8.idNum) {
      msgCp->evntStr = (TknU8*) ((long) msgCp->evntStr
                      - (long) sizeof(MgMgcoTimeStamp)
                      - (long) sizeof(MgMgcoMid)
                      - (long) sizeof(TknU32)
                      - (long) sizeof(MgMgcoSvcChgReason)
                      - (long) sizeof(MgMgcoSvcChgProf)
                      - (long) sizeof(TknU8)
                      - (long) sizeof(MgMgcoSvcChgAddr)
                      - (long) sizeof(MgMgcoSvcChgMethod)
                      - (long) sizeof(MgMgcoNonStdExtn) );
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
#ifdef MGT_MGCO_V2
   } else if(elmntDef->idNum == gcMsgAuditDescriptorOV2.idNum) {
      /* We're in position*/
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
#endif
   }  else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
   }

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncServiceChangeAddressEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncServiceChangeAddressEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncServiceChangeAddressEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoSvcChgAddr* evPtr;
   MgMgcaServiceChangeAddress val;
   S16 asnCount, isUpPart, abnfCount;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncServiceChangeAddressEnc);

   evPtr = (MgMgcoSvcChgAddr*)(msgCp->evntStr);

   val.id.pres =  evPtr->type.pres;
   val.id.val =  evPtr->type.val;
   
   (void)cmMemset((U8*)val.u.mtpAddress.val, 0, evPtr->type.val );

   /*MAH_TODO */
   switch (val.id.val) {
   case MGT_MID_DEVICE:
      val.id.val = 5;   /* 5th element in the choice */
      val.u.deviceName.pres = evPtr->u.dev.pres.pres;

      if(val.u.deviceName.pres != PRSNT_NODEF) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
         RETVALUE(RFAILED);
      }
      if(evPtr->u.dev.lcl.pres == PRSNT_NODEF && 
         evPtr->u.dev.dom.pres == PRSNT_NODEF ) {
         val.u.deviceName.len = 
                 evPtr->u.dev.lcl.len + evPtr->u.dev.dom.len + 1;    
         if(val.u.deviceName.len > 64) {
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
            RETVALUE(RFAILED);
         }
         cmMemcpy( (U8*)val.u.deviceName.val, (U8*)evPtr->u.dev.lcl.val, 
                  evPtr->u.dev.lcl.len);
         cmMemcpy( (U8*)&(val.u.deviceName.val[evPtr->u.dev.lcl.len]), (U8*)"@", 1);
         cmMemcpy((U8*)&(val.u.deviceName.val[evPtr->u.dev.lcl.len + 1]), 
                 (U8*)evPtr->u.dev.dom.val, evPtr->u.dev.dom.len);
            
      } else if(evPtr->u.dev.lcl.pres == PRSNT_NODEF) {
         if(evPtr->u.dev.lcl.len > 64) {
            val.u.deviceName.len = 64;
         } else {
            /* mg002.105: Removed compilation warning */
            val.u.deviceName.len = (U8)evPtr->u.dev.lcl.len;
         }
         cmMemcpy( (U8*)val.u.deviceName.val, (U8*)evPtr->u.dev.lcl.val, 
               val.u.deviceName.len);
      } else if(evPtr->u.dev.dom.pres == PRSNT_NODEF) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
         RETVALUE(RFAILED);
      }
      break;
   case MGT_MID_DADDRPORT:
      if (evPtr->u.dAddrPort.type.val == MGT_IPV6) {
         val.id.val = 3;
         val.u.ip6Address.pres.pres = evPtr->u.dAddrPort.pres.pres;
         val.u.ip6Address.addressIp6.pres = PRSNT_NODEF;
         val.u.ip6Address.addressIp6.len = 4;
         if ((ret = cmInetAddr((S8*)evPtr->u.dAddrPort.u.ipv6.val, (CmInetIpAddr*)val.u.ip6Address.addressIp6.val)) != ROK) {
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
            RETVALUE(ret);
         }
         val.u.ip6Address.portNumber.pres =evPtr->u.dAddrPort.port.pres;
         val.u.ip6Address.portNumber.val = evPtr->u.dAddrPort.port.val;
      }
      else if(evPtr->u.dAddrPort.type.val == MGT_IPV4) {
         val.id.val = 2;
         val.u.ip4Address.pres.pres = evPtr->u.dAddrPort.pres.pres;
         val.u.ip4Address.addressIp4.pres = PRSNT_NODEF;
         val.u.ip4Address.addressIp4.len = 4;
         if ((ret = cmInetAddr((S8*)evPtr->u.dAddrPort.u.ipv4.val, (CmInetIpAddr*)val.u.ip4Address.addressIp4.val)) != ROK) {
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
            RETVALUE(ret);
         }
         val.u.ip4Address.portNumber.pres = evPtr->u.dAddrPort.port.pres;
         val.u.ip4Address.portNumber.val = evPtr->u.dAddrPort.port.val;
      } else {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
         RETVALUE(RFAILED);
      }
      break;
   case MGT_MID_DNAMEPORT:
      val.id.val = 4;
      val.u.domainName.domName.pres = evPtr->u.dNamePort.name.pres;
      val.u.domainName.domName.len = evPtr->u.dNamePort.name.len;
      val.u.domainName.domName.val = evPtr->u.dNamePort.name.val;
      val.u.domainName.portNumber.pres = evPtr->u.dNamePort.port.pres;
      val.u.domainName.portNumber.val = evPtr->u.dNamePort.port.val;
      break;
   case MGT_MID_MTPADDR:
      val.id.val = 6;
      /* Their TknStr8 contains between 4 - 8 hex "digits" that
       * get packed into 2-4 chars of our TknSTr4
       */
      val.u.mtpAddress.pres = evPtr->u.mtpAddr.pres;
      if(val.u.mtpAddress.pres != PRSNT_NODEF) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
         RETVALUE(RFAILED);
      } 
      if(evPtr->u.mtpAddr.len == 0) {
         val.u.mtpAddress.len = 4;   
      } else {
         asnCount = 0;
         isUpPart = 1;
         for(abnfCount = 0; abnfCount < evPtr->u.mtpAddr.len; abnfCount++) 
         {
            if(isxdigit(evPtr->u.mtpAddr.val[abnfCount])){
               switch(evPtr->u.mtpAddr.val[abnfCount]) {
               case '0':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 0; break; 
               case '1':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 1; break; 
               case '2':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 2; break; 
               case '3':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 3; break; 
               case '4':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 4; break; 
               case '5':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 5; break; 
               case '6':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 6; break; 
               case '7':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 7; break; 
               case '8':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 8; break; 
               case '9':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 9; break; 
               case 'A':
               case 'a':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 0xa; break; 
               case 'B':
               case 'b':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 0xb; break; 
               case 'C':
               case 'c':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 0xc; break; 
               case 'D':
               case 'd':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 0xd; break; 
               case 'E':
               case 'e':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 0xe; break; 
               case 'F':
               case 'f':  
                  val.u.mtpAddress.val[asnCount] = 
                        val.u.mtpAddress.val[asnCount] | 0xf; break; 
               default:
                  MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
                  RETVALUE(RFAILED);
               }
            }
                  if(isUpPart) {
                    val.u.mtpAddress.val[asnCount] = 
                              val.u.mtpAddress.val[asnCount] << 4;
                    isUpPart = 0;
                  } else {
                    ++asnCount;
                    isUpPart = 1;
                  }
         }/*for */
         if(isUpPart)
            /* mg002.105: Removed compilation warning */
            val.u.mtpAddress.len = (U8)asnCount;
         else
            val.u.mtpAddress.len = (U8)asnCount + 1;
      } 
      break;
   case MGT_MID_PORT:
      val.id.val = 1;
      val.u.portNumber.pres = evPtr->u.port.pres;
      val.u.portNumber.val = evPtr->u.port.val;
      break;
   default: 
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
      break;
   }

   /* Replace, encode, skip */
   msgCp->evntStr = (TknU8*)&(val);
   ret = mgAsnEncChoice(msgCp);
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncServiceChangeAddressDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncServiceChangeAddressDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncServiceChangeAddressDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoSvcChgAddr* evPtr;
   MgMgcaServiceChangeAddress val;
   S8 *delimChar;
   U16 domLen = 0;
   U16 lclLen = 0;
   CmInetIpAddr tmpVal;
   S8* tmpStr;
   S32 asnCount, hexVal;
   static S8 hexArr[] = {'0', '1', '2', '3', '4', '5', 
                 '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncServiceChangeAddressDec);
   evPtr = (MgMgcoSvcChgAddr*)(msgCp->evntStr);
   (void)cmMemset((U8*)&val, 0, sizeof(val) );

   /* decode */
   msgCp->evntStr = (TknU8*)&(val);
   if((ret = mgAsnDecChoice(msgCp)) != ROK){ RETVALUE(ret); }

   /* validate */
   evPtr->type.pres = val.id.pres;
   if(evPtr->type.pres == NOTPRSNT) {
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* copy over */
   switch (val.id.val) {
   case 1:
      evPtr->type.val = MGT_MID_PORT;
      evPtr->u.port.pres = val.u.portNumber.pres;
      evPtr->u.port.val = val.u.portNumber.val;
      break;
   case 2:
      evPtr->type.val = MGT_MID_DADDRPORT;
      evPtr->u.dAddrPort.pres.pres = val.u.ip4Address.pres.pres;
      evPtr->u.dAddrPort.type.val = MGT_IPV4;
      evPtr->u.dAddrPort.type.pres = PRSNT_NODEF;
      evPtr->u.dAddrPort.u.ipv4.pres =val.u.ip4Address.addressIp4.pres; 
      if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->u.dAddrPort.u.ipv4.val), CM_INET_IPV4_NUM_ADDR) != ROK) { RETVALUE(RFAILED); }
      (void)cmMemcpy((U8*)&tmpVal, (U8*)val.u.ip4Address.addressIp4.val, sizeof(tmpVal));
      if ((ret = cmInetNtoa(tmpVal, &tmpStr)) != ROK) { RETVALUE(ret); }
      (void)cmMemcpy((U8*)evPtr->u.dAddrPort.u.ipv4.val, (U8*)tmpStr, cmStrlen((U8*)tmpStr));
      evPtr->u.dAddrPort.u.ipv4.len = cmStrlen((U8*)evPtr->u.dAddrPort.u.ipv4.val);
      evPtr->u.dAddrPort.port.pres=val.u.ip4Address.portNumber.pres;
      evPtr->u.dAddrPort.port.val=val.u.ip4Address.portNumber.val;
      break;
   case 3:
      evPtr->type.val = MGT_MID_DADDRPORT;
      evPtr->u.dAddrPort.pres.pres = val.u.ip6Address.pres.pres;
      evPtr->u.dAddrPort.type.val = MGT_IPV6;
      evPtr->u.dAddrPort.u.ipv6.pres = PRSNT_NODEF;

      evPtr->u.dAddrPort.u.ipv6.pres =val.u.ip6Address.addressIp6.pres; 
      if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->u.dAddrPort.u.ipv6.val), CM_INET_IPV6ADDR_SIZE) != ROK) { RETVALUE(RFAILED); }
      (void)cmMemcpy((U8*)&tmpVal, (U8*)val.u.ip6Address.addressIp6.val, sizeof(tmpVal));
      if ((ret = cmInetNtoa(tmpVal, &tmpStr)) != ROK) { RETVALUE(ret); }
      (void)cmMemcpy((U8*)evPtr->u.dAddrPort.u.ipv6.val, (U8*)tmpStr, cmStrlen((U8*)tmpStr));
      evPtr->u.dAddrPort.u.ipv6.len = cmStrlen((U8*)evPtr->u.dAddrPort.u.ipv6.val);
      evPtr->u.dAddrPort.port.pres=val.u.ip6Address.portNumber.pres;
      evPtr->u.dAddrPort.port.val=val.u.ip6Address.portNumber.val;
      break;
   case 4: 
      evPtr->type.val = MGT_MID_DNAMEPORT;
      evPtr->u.dNamePort.name.pres = val.u.domainName.domName.pres;
      evPtr->u.dNamePort.name.len = val.u.domainName.domName.len;
      /* mg002.105: Removed compilation warning */
      if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->u.dNamePort.name.val), (MsgLen)(evPtr->u.dNamePort.name.len + 1)) != ROK) { RETVALUE(RFAILED); }
      cmMemcpy((U8*) evPtr->u.dNamePort.name.val, 
              (U8*) val.u.domainName.domName.val, 
               evPtr->u.dNamePort.name.len);
      evPtr->u.dNamePort.port.pres = val.u.domainName.portNumber.pres;
      evPtr->u.dNamePort.port.val = val.u.domainName.portNumber.val;
      break;
   case 5:
      evPtr->type.val = MGT_MID_DEVICE;
      evPtr->u.dev.pres.pres = val.u.deviceName.pres;
      if(evPtr->u.dev.pres.pres != PRSNT_NODEF) {
         MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
         RETVALUE(RFAILED);
      }
      if(val.u.deviceName.len > 0) {
         delimChar = strrchr((S8*)val.u.deviceName.val, '@');
         if(delimChar == NULL) {
            /* we only have a lcl */
            evPtr->u.dev.lcl.len = val.u.deviceName.len;
            /* mg002.105: Removed compilation warning */
            if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->u.dev.lcl.val), (MsgLen)(evPtr->u.dev.lcl.len + 1)) != ROK) { RETVALUE(RFAILED); }
            cmMemcpy((U8*)evPtr->u.dev.lcl.val, 
                 (U8*) val.u.deviceName.val, evPtr->u.dev.lcl.len);
         } else {
            lclLen = (U16) ((long)delimChar - (long)&val.u.deviceName.val);
            domLen = (U16) (((long)val.u.deviceName.val + val.u.deviceName.len) - (long)delimChar);
            evPtr->u.dev.lcl.len = lclLen;
            /* mg002.105: Removed compilation warning */
            if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->u.dev.lcl.val), (MsgLen)(evPtr->u.dev.lcl.len + 1)) != ROK) { RETVALUE(RFAILED); }
            cmMemcpy((U8*) evPtr->u.dev.lcl.val,
                 (U8*) val.u.deviceName.val, evPtr->u.dev.lcl.len);
            evPtr->u.dev.dom.len = domLen;
            /* mg002.105: Removed compilation warning */
            if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->u.dev.dom.val), (MsgLen)(evPtr->u.dev.dom.len + 1)) != ROK) { RETVALUE(RFAILED); }
            cmMemcpy((U8*) evPtr->u.dev.dom.val,
                    (U8*) (delimChar + 1), evPtr->u.dev.dom.len);
         }
      }
      break;
   case 6:
      evPtr->type.val = MGT_MID_MTPADDR;

      if(val.u.mtpAddress.pres != PRSNT_NODEF) {
         MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
         RETVALUE(RFAILED);
      }
      evPtr->u.mtpAddr.pres = PRSNT_NODEF;
      (void)cmMemset((U8*)evPtr->u.mtpAddr.val, '\0', 
                       sizeof(evPtr->u.mtpAddr.val));
      evPtr->u.mtpAddr.len = 0;

      for(asnCount = 0; asnCount < val.u.mtpAddress.len; asnCount++){
         hexVal = (val.u.mtpAddress.val[asnCount] >> 4) & 0xF;
         evPtr->u.mtpAddr.val[evPtr->u.mtpAddr.len++] = hexArr[hexVal];
         hexVal = val.u.mtpAddress.val[asnCount] & 0xF;
         evPtr->u.mtpAddr.val[evPtr->u.mtpAddr.len++] = hexArr[hexVal];
      }
      break;

   default:
      MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
      RETVALUE(RFAILED);
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncActionRequestEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncActionRequestEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncActionRequestEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoActionReq* evPtr;
   

   /* Different order */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncActionRequestEnc);

   ++msgCp->elmntDef;
   evPtr = (MgMgcoActionReq*)msgCp->evntStr;
   msgCp->evntStr = (TknU8*)&(evPtr->cxtId);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   if (evPtr->pres.pres) {
      /* Context properties */
      msgCp->evntStr = (TknU8*)&(evPtr->cxtProps);
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

      /* Context audit */
      msgCp->evntStr = (TknU8*)&(evPtr->cxtAud);
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

      /* Command request list */
      evPtr->cl.num.pres = PRSNT_NODEF;
      msgCp->evntStr = (TknU8*)&(evPtr->cl);
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncActionRequestDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncActionRequestDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncActionRequestDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgAsnElmntDef* elmntDef;
   /* mg003.105: fixes for the action request */
   MgMgcoActionReq *saveEvnt;
   

   /* Different order */
   TRC2(mgaFuncActionRequestDec);
   elmntDef = *(msgCp->elmntDef);
   saveEvnt = (MgMgcoActionReq*)msgCp->evntStr;
   if (elmntDef->idNum == gcMsgContextID.idNum) {
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if (elmntDef->idNum == gcMsgContextRequestO1.idNum) {
      msgCp->evntStr = (TknU8*)&(saveEvnt->cxtProps);
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      if (saveEvnt->cxtProps.pres.pres) saveEvnt->pres.pres = PRSNT_NODEF;
   } else if (elmntDef->idNum == gcMsgContextAttrAuditRequestO.idNum) {
      msgCp->evntStr = (TknU8*)&(saveEvnt->cxtAud);
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      if (saveEvnt->cxtAud.pres.pres) saveEvnt->pres.pres = PRSNT_NODEF;
   } else if (elmntDef->idNum == gcMsgCommandRequests.idNum) {
      msgCp->evntStr = (TknU8*)&(saveEvnt->cl);
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      if (saveEvnt->cl.num.pres) saveEvnt->pres.pres = PRSNT_NODEF;
   } else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
   }
   msgCp->evntStr = (TknU8*)saveEvnt;

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncTerminationIDEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncTerminationIDEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncTerminationIDEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoTermId* evPtr;
   MgMgcaTerminationID termID;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncTerminationIDEnc);
   evPtr = (MgMgcoTermId*)(msgCp->evntStr);
   (void)cmMemset((U8*)&termID, 0, sizeof(termID));

      /* mg003.105: Changes for 3GPP Termination Id */
   termID.wildcard.num.pres = PRSNT_NODEF;
   switch (evPtr->type.val) {
   case MGT_TERMID_ROOT:
   case MGT_TERMID_ALL: 
   case MGT_TERMID_CHOOSE: 
   case MGT_TERMID_OTHER: 
      /* mg003.105: Changes for 3GPP Termination Id */
      if(UserFuncEnc == NULLP) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
      }
      if ((ret = (*UserFuncEnc)(msgCp, &termID, evPtr)) != ROK) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
      }
      termID.wildcard.num.pres = PRSNT_NODEF;
      msgCp->evntStr = (TknU8*)&termID;
      ret = mgAsnEncSetSeq(msgCp);
      break;
   default:
      MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
      RETVALUE(RFAILED);
      break;
   }
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncTerminationIDDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncTerminationIDDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncTerminationIDDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoTermId* evPtr;
   MgMgcaTerminationID termID;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncTerminationIDDec);

   /* decode */
   (void)cmMemset((U8*)&termID, 0, sizeof(termID));
   evPtr = (MgMgcoTermId*)(msgCp->evntStr);
   msgCp->evntStr = (TknU8*)&termID;
   if ((ret = mgAsnDecSeq(msgCp)) == ROK) {
      /* Call user routine to properly map */
      if (UserFuncDec != NULLP) {
         if((ret = (*UserFuncDec)(msgCp, evPtr, &termID)) != ROK) {
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
            RETVALUE(RFAILED);
         }
      }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncAuditDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncAuditDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncAuditDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoAuditDesc* evPtr;
   MgMgcaAuditDescriptor auditDescriptor;
   MgMgcoAuditItem** arrPtr;
#ifdef MGT_MGCO_V2
   MgMgcoIndAudTermAudit  *indAud = NULLP;
#endif
   
   S16 j;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncAuditDescriptorEnc);
   (void)cmMemset((U8*)&auditDescriptor, 0, sizeof(auditDescriptor));
   evPtr = (MgMgcoAuditDesc*)(msgCp->evntStr);
   arrPtr = evPtr->al;

   /* Map it */
   auditDescriptor.pres.pres = evPtr->pres.pres;
/* mg007.105: Both audit token and auditproperty token are optional 
 * we have to support empty audit descriptor */ 
	if (evPtr->num.pres == PRSNT_NODEF)
	{
   	auditDescriptor.auditToken.pres = evPtr->pres.pres;
	   auditDescriptor.auditToken.len = 2;
	   for (j=0; j<evPtr->num.val; ++j) {
#ifdef MGT_MGCO_V2
	      if( (*arrPtr)->auditItem.pres == PRSNT_NODEF ) {
	         switch ((*arrPtr)->auditItem.val) {
#else
	      if( (*arrPtr)->pres == PRSNT_NODEF ) {
	         switch ((*arrPtr)->val) {
#endif
	         case MGT_MEDIADESC:
	            auditDescriptor.auditToken.val[0] |= 1<<5; break;
	         case MGT_MODEMDESC:
	            auditDescriptor.auditToken.val[0] |= 1<<6; break;
	         case MGT_MUXDESC:
	            auditDescriptor.auditToken.val[0] |= 1<<7; break;
	         case MGT_REQEVTDESC:
	            auditDescriptor.auditToken.val[0] |= 1<<4; break;
	         case MGT_EVBUFDESC:
	            auditDescriptor.auditToken.val[1] |= 1<<6; break;
	         case MGT_SIGNALSDESC:
	            auditDescriptor.auditToken.val[0] |= 1<<3; break;
	         case MGT_DIGMAPDESC:
	            auditDescriptor.auditToken.val[0] |= 1<<2; break;
	         case MGT_OBSEVTDESC:
	            auditDescriptor.auditToken.val[0] |= 1<<0; break;
	         case MGT_STATSDESC:
	            auditDescriptor.auditToken.val[0] |= 1<<1; break;
	         case MGT_PKGSDESC:
	            auditDescriptor.auditToken.val[1] |= 1<<7; break;
#ifdef MGT_MGCO_V2
	         case MGT_INDAUD_TERMAUDDESC: /* the termAudit below should be set */
	            break;
#endif
	         case MGT_AUDITDESC: /* Not defined */
	         case MGT_ERRDESC: /* Not defined */
	         default:
	            MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
	            RETVALUE(RFAILED);
	         }
	      } /* if */
#ifdef MGT_MGCO_V2
	      if( (*arrPtr)->termAudit.num.pres == PRSNT_NODEF) {
	         indAud = &( (*arrPtr)->termAudit );
	      }
#endif
	      ++arrPtr;
	   }

	   /* encode auditToken */
	   ++msgCp->elmntDef;
	   msgCp->evntStr = (TknU8*)&(auditDescriptor.auditToken);
	   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
	
#ifdef MGT_MGCO_V2
	   /* encode indAuditParameters */
	   if (indAud != NULLP) {
	      msgCp->evntStr = (TknU8*)indAud;
	      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
	   }
#endif
	}
	else
		ret = ROK;

   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncAuditDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncAuditDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncAuditDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgAsnElmntDef *elmntDef, *tmpelmntDef;
   MgMgcoAuditDesc* evPtr;
   MgMgcaAuditDescriptor auditDescriptor;
   MsgLen               elmntLen;       /* element length */
   MsgLen               prevLen;        /* previous length */
   MgMgcoAuditItem** arrPtr;
   S32 byteCnt;
   /* mg002.105: Removed compilation warning */
   U16 j;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncAuditDescriptorDec);
   elmntLen = msgCp->elmntLen;
   prevLen = mgAsnFindLen(msgCp);

   evPtr = (MgMgcoAuditDesc*)(msgCp->evntStr);
   /* mg007.105: Both audit token and auditproperty token are optional 
    * we have to support empty audit descriptor */ 
   if(elmntLen != 0)
   {
   	(void)cmMemset((U8*)&auditDescriptor, 0, sizeof(auditDescriptor));
   	elmntDef = *msgCp->elmntDef;

   	++msgCp->elmntDef;
   	/* mg007.105: saving the audit token element definition */
   	tmpelmntDef = *msgCp->elmntDef;
   	msgCp->evntStr = (TknU8*)&auditDescriptor.auditToken;
   	if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   	/* check length */
   	if ((auditDescriptor.auditToken.len != 1) &&
       	(auditDescriptor.auditToken.len != 2)) {
      	MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
      	RETVALUE(RFAILED);
   	}

   	/* set up num and pres*/
   	evPtr->pres.pres = PRSNT_NODEF;
   	evPtr->num.pres = PRSNT_NODEF;
   	evPtr->num.val = 0;
   	byteCnt = 0;
   	for (j=0; j<(tmpelmntDef->maxLen); ++j) {
      	if (j >= 8) byteCnt = 1;
      	if (auditDescriptor.auditToken.val[byteCnt] & (1<<(7-(j-(byteCnt*8))))) {
         	++(evPtr->num.val);
      	}
   	}
   	/* mg002.105: Removed compilation warning */
   	if (mgAsnDecGetMem(msgCp, (Ptr*)&(arrPtr), (MsgLen)(sizeof(MgMgcoAuditItem*)*(evPtr->num.val + 1))) != ROK) { RETVALUE(RFAILED); }
   	/* the +1 in the above is for IndAudTermAudits, if we need it */
   	evPtr->al = arrPtr;
   	byteCnt = 0;
   	for (j=0; j<tmpelmntDef->maxLen; ++j) {
      	if (j >= 8) {
         	byteCnt = 1;
         	if (auditDescriptor.auditToken.len == 1) break;
      	}
      	if (auditDescriptor.auditToken.val[byteCnt] & (1<<(7-(j-(byteCnt*8))))) {
         	if (mgAsnDecGetMem(msgCp, (Ptr*)arrPtr, sizeof(MgMgcoAuditItem)) != ROK) { RETVALUE(RFAILED); }

#ifdef MGT_MGCO_V2
      	{
         	(*arrPtr)->auditItem.pres = PRSNT_NODEF; 
         	switch (j) {
         	case 2:
            	(*arrPtr)->auditItem.val = MGT_MEDIADESC; break;
         	case 1:
            	(*arrPtr)->auditItem.val = MGT_MODEMDESC; break;
         	case 0:
            	(*arrPtr)->auditItem.val = MGT_MUXDESC; break;
         	case 3:
            	(*arrPtr)->auditItem.val = MGT_REQEVTDESC; break;
         	case 9:
            	(*arrPtr)->auditItem.val = MGT_EVBUFDESC; break;
         	case 4:
            	(*arrPtr)->auditItem.val = MGT_SIGNALSDESC; break;
         	case 5:
            	(*arrPtr)->auditItem.val = MGT_DIGMAPDESC; break;
         	case 7:
            	(*arrPtr)->auditItem.val = MGT_OBSEVTDESC; break;
         	case 6:
            	(*arrPtr)->auditItem.val = MGT_STATSDESC; break;
         	case 8:
            	(*arrPtr)->auditItem.val = MGT_PKGSDESC; break;
         	default:
            	MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
            	RETVALUE(RFAILED);
         	}
      	}
#	else
      	{
         	(*arrPtr)->pres = PRSNT_NODEF;
         	switch (j) {
         	case 2:
            	(*arrPtr)->val = MGT_MEDIADESC; break;
         	case 1:
            	(*arrPtr)->val = MGT_MODEMDESC; break;
         	case 0:
            	(*arrPtr)->val = MGT_MUXDESC; break;
         	case 3:
            	(*arrPtr)->val = MGT_REQEVTDESC; break;
         	case 9:
            	(*arrPtr)->val = MGT_EVBUFDESC; break;
         	case 4:
            	(*arrPtr)->val = MGT_SIGNALSDESC; break;
         	case 5:
            	(*arrPtr)->val = MGT_DIGMAPDESC; break;
         	case 7:
            	(*arrPtr)->val = MGT_OBSEVTDESC; break;
         	case 6:
            	(*arrPtr)->val = MGT_STATSDESC; break;
         	case 8:
            	(*arrPtr)->val = MGT_PKGSDESC; break;
         	default:
            	MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
            	RETVALUE(RFAILED);
         	}
       	}
#endif
         	++arrPtr;
      	}
   	}
   	elmntLen -= prevLen - mgAsnFindLen(msgCp);
   	if (elmntLen <= 0) { RETVALUE(mgAsnChkSeqMandMis(msgCp)); }

#ifdef MGT_MGCO_V2
   	/* decode indAuditParameters */
   	if (mgAsnDecGetMem(msgCp, (Ptr*)arrPtr, sizeof(MgMgcoAuditItem)) != ROK) { RETVALUE(RFAILED); }
   	msgCp->evntStr = (TknU8*)&((*arrPtr)->termAudit);
   	if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   	if( (*arrPtr)->termAudit.num.pres == PRSNT_NODEF) {
      	(*arrPtr)->auditItem.pres = PRSNT_NODEF;
      	(*arrPtr)->auditItem.val = MGT_INDAUD_TERMAUDDESC;
	      ++evPtr->num.val;
  	   }
#endif
   }
   else
   {		
	   ret = ROK;
   }

   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncPropGrpsEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncPropGrpsEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncPropGrpsEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
#ifdef CM_SDP_OPAQUE
   S8           tmpBuf[2048];
   MgMgcaPropGrps propGrps;
   MgAsnElmntDef  **startDef;
   MsgLen         totLen;
#endif


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncPropGrpsEnc);
#ifdef CM_SDP_OPAQUE
  /* Opaque init */
   msgCp->secEvntStr = msgCp->evntStr;
   if ((SFndLenMsg(((TknBuf*)(msgCp->secEvntStr))->val, &totLen) != ROK) ||
       (SCpyMsgFix(((TknBuf*)(msgCp->secEvntStr))->val, 0, ((totLen<sizeof(tmpBuf))?totLen:sizeof(tmpBuf)), (U8*)tmpBuf, &totLen) != ROK)) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }
   tmpBuf[((totLen<sizeof(tmpBuf))?totLen:(sizeof(tmpBuf)-1))] = '\000';

   /* loop */
   ++msgCp->elmntDef;
   cmMemset((U8*)&propGrps, 0, sizeof(propGrps));
   propGrps.num.pres = PRSNT_NODEF;
   propGrps.num.val = 1;
   startDef = msgCp->elmntDef;
   msgCp->secEvntStr = (TknU8*)tmpBuf;
   while (msgCp->secEvntStr) {
      /* encode it */
      msgCp->elmntDef = startDef;
      msgCp->evntStr = (TknU8*)&propGrps;
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
#else
   /* encode it */
   ret = mgAsnEncUnconsSetSeqOf(msgCp);
#endif
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncPropGrpsDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncPropGrpsDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncPropGrpsDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
#ifdef CM_SDP_OPAQUE
   MgAsnElmntDef **saveSecElmntDef;
#endif
   MGAFUNCSAVE(msgCp);

   TRC2(mgaFuncPropGrpsDec);
#ifdef CM_SDP_OPAQUE
   saveSecElmntDef = msgCp->secElmntDef;
#endif

   /* decode it */
   ret = mgAsnDecUnconsSetSeqOf(msgCp);
   MGAFUNCSKIP(msgCp);

   /* restore */
#ifdef CM_SDP_OPAQUE
   msgCp->secElmntDef = saveSecElmntDef;
#endif

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncLocalRemoteDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncLocalRemoteDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncLocalRemoteDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoLocalDesc* evPtr;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncLocalRemoteDescriptorEnc);
   evPtr = (MgMgcoLocalDesc*)(msgCp->evntStr);
   ++msgCp->elmntDef;

/*
#ifdef CM_SDP_OPAQUE
   msgCp->evntStr = (TknU8*)&(evPtr->sdpStr);
#else
   msgCp->evntStr = (TknU8*)&(evPtr->sdp);
#endif
*/
   /* mg004.105: Added Annex C support */
   msgCp->evntStr = (TknU8*)&(evPtr->annexCParmLst);
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncLocalRemoteDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncLocalRemoteDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncLocalRemoteDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoLocalDesc* evPtr;
   /* mg004.105: Added Annex C support */
   MgMgcaPropGrps propGrps;
#ifdef CM_SDP_OPAQUE
/*   MgMgcaPropGrps propGrps;*/
#endif


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncLocalRemoteDescriptorDec);
   /* mg004.105: Added Annex C support */
   (void)cmMemset((U8*)&propGrps, 0, sizeof(MgMgcaPropGrps));
#ifdef CM_SDP_OPAQUE
   /* decode */
   ++msgCp->elmntDef;
   evPtr = (MgMgcoLocalDesc*)(msgCp->evntStr);
/*   msgCp->secEvntStr = (TknU8*)&(evPtr->sdpStr);*/
   msgCp->secEvntStr = (TknU8*)&(evPtr);
   msgCp->evntStr = (TknU8*)&(propGrps);
   evPtr->pres.pres = PRSNT_NODEF;
   if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
#else
   /* decode */
   ++msgCp->elmntDef;
   evPtr = (MgMgcoLocalDesc*)(msgCp->evntStr);
 /*  msgCp->evntStr = (TknU8*)&(evPtr->sdp);*/
   evPtr->pres.pres = PRSNT_NODEF;
   msgCp->evntStr = (TknU8*)&(evPtr->annexCParmLst);
/*   msgCp->evntStr = (TknU8*)&(evPtr);*/
   if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
#endif
   /* mg003.105: Fix for the Local & Remote Descriptor */
/*   evPtr->pres.pres = PRSNT_NODEF;*/
/*   evPtr->annexCParm = (MgMgcoAnnexPropParmLst)(propGrps);*/
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMIdEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMIdEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMIdEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoMid* evPtr;
   MgMgcaMId     val;
   S32 abnfCount;
   S32 asnCount;
   S32 isUpPart = 1;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncMIdEnc);
   evPtr = (MgMgcoMid*)msgCp->evntStr;
   if (evPtr->type.pres) {
      /* Populate ASN.1 event */
      (void)cmMemset((U8*)&val, 0, sizeof(val));
      val.id.pres = PRSNT_NODEF;

      switch (evPtr->type.val) {
       case MGT_MID_DEVICE:
         val.id.val = 4;   /* 4th element in the choice */
         val.u.deviceName.pres = evPtr->u.dev.pres.pres;
         if(val.u.deviceName.pres != PRSNT_NODEF) {
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
            RETVALUE(RFAILED);
         }
         if(evPtr->u.dev.lcl.pres == PRSNT_NODEF && 
            evPtr->u.dev.dom.pres == PRSNT_NODEF ) {
            val.u.deviceName.len = 
                    evPtr->u.dev.lcl.len + evPtr->u.dev.dom.len + 1;    
            if(val.u.deviceName.len > 64) {
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(RFAILED);
            }
            cmMemcpy( (U8*)val.u.deviceName.val, (U8*)evPtr->u.dev.lcl.val, 
                     evPtr->u.dev.lcl.len);
            cmMemcpy( (U8*)&(val.u.deviceName.val[evPtr->u.dev.lcl.len]), (U8*)"@", 1);
            cmMemcpy((U8*)&(val.u.deviceName.val[evPtr->u.dev.lcl.len + 1]), 
                    (U8*)evPtr->u.dev.dom.val, evPtr->u.dev.dom.len);
            
         } else if(evPtr->u.dev.lcl.pres == PRSNT_NODEF) {
            if(evPtr->u.dev.lcl.len > 64) {
               val.u.deviceName.len = 64;
            } else {
               /* mg002.105: Removed compilation warning */
               val.u.deviceName.len = (U8)evPtr->u.dev.lcl.len;
            }
            cmMemcpy( (U8*)val.u.deviceName.val, (U8*)evPtr->u.dev.lcl.val, 
                     val.u.deviceName.len);
         } else if(evPtr->u.dev.dom.pres == PRSNT_NODEF) {
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
            RETVALUE(RFAILED);
         }
         break;
       case MGT_MID_DADDRPORT:
         if (evPtr->u.dAddrPort.type.val == MGT_IPV6) {
            val.id.val = 2;
            val.u.ip6Address.pres.pres = evPtr->u.dAddrPort.pres.pres;
            val.u.ip6Address.addressIp6.pres = PRSNT_NODEF;
            val.u.ip6Address.addressIp6.len = 4;
#ifdef IPV6_SUPPORTED
            if ((ret = cmInetPton6((CmInetIpAddr6*)val.u.ip6Address.addressIp6.val, (S8*)evPtr->u.dAddrPort.u.ipv6.val)) != ROK) {
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(ret);
            }
#else
            if ((ret = cmInetAddr((S8*)evPtr->u.dAddrPort.u.ipv6.val, (CmInetIpAddr*)val.u.ip6Address.addressIp6.val)) != ROK) {
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(ret);
            }
#endif
            val.u.ip6Address.portNumber.pres = evPtr->u.dAddrPort.port.pres;
            val.u.ip6Address.portNumber.val = evPtr->u.dAddrPort.port.val;
         } else if(evPtr->u.dAddrPort.type.val == MGT_IPV4) {
            val.id.val = 1;
            val.u.ip4Address.pres.pres = evPtr->u.dAddrPort.pres.pres;
            val.u.ip4Address.addressIp4.pres = PRSNT_NODEF;
            val.u.ip4Address.addressIp4.len = 4;
            if ((ret = cmInetAddr((S8*)evPtr->u.dAddrPort.u.ipv4.val, (CmInetIpAddr*)val.u.ip4Address.addressIp4.val)) != ROK) {
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(ret);
            }
            val.u.ip4Address.portNumber.pres = evPtr->u.dAddrPort.port.pres;
            val.u.ip4Address.portNumber.val = evPtr->u.dAddrPort.port.val;
         } else {
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
            RETVALUE(RFAILED);
         }
         break;
      case MGT_MID_DNAMEPORT:
         val.id.val = 3;
         val.u.domainName.pres.pres = evPtr->u.dNamePort.pres.pres;
         val.u.domainName.domName.pres = evPtr->u.dNamePort.name.pres;
         val.u.domainName.domName.len = evPtr->u.dNamePort.name.len;
         val.u.domainName.domName.val = evPtr->u.dNamePort.name.val;
         val.u.domainName.portNumber.pres = evPtr->u.dNamePort.port.pres;
         val.u.domainName.portNumber.val = evPtr->u.dNamePort.port.val;
         break;
      case MGT_MID_MTPADDR:
         val.id.val = 5;
         /* Their TknStr8 contains between 4 - 8 hex "digits" that
          * get packed into 2-4 chars of our TknSTr4
          */
         val.u.mtpAddress.pres = evPtr->u.mtpAddr.pres;
         if(val.u.mtpAddress.pres != PRSNT_NODEF) {
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
            RETVALUE(RFAILED);
         } 
         if(evPtr->u.mtpAddr.len == 0) {
            val.u.mtpAddress.len = 4;   
         } else {
            asnCount = 0;
            isUpPart = 1;
            for(abnfCount = 0; abnfCount < evPtr->u.mtpAddr.len; abnfCount++) 
            {
               if(isxdigit(evPtr->u.mtpAddr.val[abnfCount])){
                  switch(evPtr->u.mtpAddr.val[abnfCount]) {
                  case '0':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0x0; break; 
                  case '1':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0x1; break; 
                  case '2':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0x2; break; 
                  case '3':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0x3; break; 
                  case '4':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0x4; break; 
                  case '5':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0x5; break; 
                  case '6':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0x6; break; 
                  case '7':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0x7; break; 
                  case '8':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0x8; break; 
                  case '9':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0x9; break; 
                  case 'A':
                  case 'a':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0xa; break; 
                  case 'B':
                  case 'b':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0xb; break; 
                  case 'C':
                  case 'c':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0xc; break; 
                  case 'D':
                  case 'd':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0xd; break; 
                  case 'E':
                  case 'e':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0xe; break; 
                  case 'F':
                  case 'f':  
                     val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] | 0xf; break; 
                  default:
                     MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
                     RETVALUE(RFAILED);
                  }
               }
               if(isUpPart) {
                  val.u.mtpAddress.val[asnCount] = 
                           val.u.mtpAddress.val[asnCount] << 4;
                  isUpPart = 0;
               } else {
                  ++asnCount;
                  isUpPart = 1;
               }
            }
            if(isUpPart)
               val.u.mtpAddress.len = asnCount;
            else
               val.u.mtpAddress.len = asnCount + 1;
         } 
         break;
      default: 
         MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
         RETVALUE(RFAILED);
         break;
      }
   }

   /* Replace, encode, skip */
   msgCp->evntStr = (TknU8*)&val;
   ret = mgAsnEncChoice(msgCp);
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMIdDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMIdDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMIdDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoMid* evPtr;
   MgMgcaMId val;
   S8 *delimChar;
   U16 domLen = 0;
   U16 lclLen = 0;
   CmInetIpAddr tmpVal;
   S8* tmpStr;
   S32 asnCount;
   S32 hexVal;
   static S8 hexArr[] = {'0', '1', '2', '3', '4', '5', 
                 '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

   /* Save, replace, encode */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncMIdDec);

   evPtr = (MgMgcoMid*)(msgCp->evntStr);
   (void)cmMemset((U8*)&val, 0, sizeof(val) );
   msgCp->evntStr = (TknU8*)&(val);
   if ((ret = mgAsnDecChoice(msgCp)) != ROK) { RETVALUE(ret); }

   /* copy over */
   evPtr->type.pres = val.id.pres;
   if(evPtr->type.pres == NOTPRSNT) {
      MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
      RETVALUE(RFAILED);
   }

   switch (val.id.val) {
      case 1:
         evPtr->type.val = MGT_MID_DADDRPORT;
         evPtr->u.dAddrPort.pres.pres = val.u.ip4Address.pres.pres;
         evPtr->u.dAddrPort.type.val = MGT_IPV4;
         evPtr->u.dAddrPort.type.pres = PRSNT_NODEF;
         evPtr->u.dAddrPort.u.ipv4.pres = val.u.ip4Address.addressIp4.pres; 
         /* mg002.105: Removed compilation warning */
         if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->u.dAddrPort.u.ipv4.val), CM_INET_IPV4_NUM_ADDR) != ROK) { RETVALUE(RFAILED); }
         (void)cmMemcpy((U8*)&tmpVal, (U8*)val.u.ip4Address.addressIp4.val, sizeof(tmpVal));
         if ((ret = cmInetNtoa(tmpVal, &tmpStr)) != ROK) { RETVALUE(ret); }
         (void)cmMemcpy((U8*)evPtr->u.dAddrPort.u.ipv4.val, (U8*)tmpStr, cmStrlen((U8*)tmpStr));
         evPtr->u.dAddrPort.u.ipv4.len = cmStrlen((U8*)evPtr->u.dAddrPort.u.ipv4.val);
         evPtr->u.dAddrPort.port.pres=val.u.ip4Address.portNumber.pres;
         evPtr->u.dAddrPort.port.val=val.u.ip4Address.portNumber.val;
         break;
      case 2:
         evPtr->type.val = MGT_MID_DADDRPORT;
         evPtr->u.dAddrPort.pres.pres = val.u.ip6Address.pres.pres;
         evPtr->u.dAddrPort.type.val = MGT_IPV6;
         evPtr->u.dAddrPort.type.pres = PRSNT_NODEF;
         evPtr->u.dAddrPort.u.ipv6.pres = val.u.ip6Address.addressIp6.pres; 
         /* mg002.105: Removed compilation warning */
         if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->u.dAddrPort.u.ipv6.val), CM_INET_IPV6ADDR_SIZE) != ROK) { RETVALUE(RFAILED); }
         (void)cmMemcpy((U8*)&tmpVal, (U8*)val.u.ip6Address.addressIp6.val, sizeof(tmpVal));
         if ((ret = cmInetNtoa(tmpVal, &tmpStr)) != ROK) { RETVALUE(ret); }
         (void)cmMemcpy((U8*)evPtr->u.dAddrPort.u.ipv6.val, (U8*)tmpStr, cmStrlen((U8*)tmpStr));
         evPtr->u.dAddrPort.u.ipv6.len = cmStrlen((U8*)evPtr->u.dAddrPort.u.ipv6.val);
         evPtr->u.dAddrPort.port.pres=val.u.ip6Address.portNumber.pres;
         evPtr->u.dAddrPort.port.val=val.u.ip6Address.portNumber.val;
         break;
      case 3: 
         evPtr->type.val = MGT_MID_DNAMEPORT;
         evPtr->u.dNamePort.pres.pres = val.u.domainName.pres.pres;
         evPtr->u.dNamePort.name.pres = val.u.domainName.domName.pres;
         evPtr->u.dNamePort.name.len = val.u.domainName.domName.len;
         /* mg002.105: Removed compilation warning */
         if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->u.dNamePort.name.val), (MsgLen)(evPtr->u.dNamePort.name.len + 1)) != ROK) { RETVALUE(RFAILED); }
         cmMemcpy((U8*) evPtr->u.dNamePort.name.val, 
                 (U8*) val.u.domainName.domName.val, 
                  evPtr->u.dNamePort.name.len);
         evPtr->u.dNamePort.port.pres = val.u.domainName.portNumber.pres;
         evPtr->u.dNamePort.port.val = val.u.domainName.portNumber.val;
         break;
      case 4:
         evPtr->type.val = MGT_MID_DEVICE;
         evPtr->u.dev.pres.pres = val.u.deviceName.pres;
         if(evPtr->u.dev.pres.pres != PRSNT_NODEF) {
            MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
            RETVALUE(RFAILED);
         }
         if(val.u.deviceName.len > 0) {
            delimChar = strrchr((S8*)val.u.deviceName.val, '@');
            if(delimChar == NULL) {
               /* we only have a lcl */
               evPtr->u.dev.lcl.pres = PRSNT_NODEF;
               evPtr->u.dev.lcl.len = val.u.deviceName.len;
               /* mg002.105: Removed compilation warning */
               if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->u.dev.lcl.val), (MsgLen)(evPtr->u.dev.lcl.len + 1)) != ROK) { RETVALUE(RFAILED); }
               cmMemcpy((U8*)evPtr->u.dev.lcl.val, 
                       (U8*) val.u.deviceName.val,
                       evPtr->u.dev.lcl.len);
            } else {
               lclLen = (U16) ((long)delimChar - (long)&val.u.deviceName.val);
               domLen = (U16) (((long)val.u.deviceName.val + val.u.deviceName.len) - (long)delimChar);
               evPtr->u.dev.lcl.len = lclLen;
               /* mg002.105: Removed compilation warning */
               if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->u.dev.lcl.val), (MsgLen)(evPtr->u.dev.lcl.len + 1)) != ROK) { RETVALUE(RFAILED); }
               cmMemcpy((U8*) evPtr->u.dev.lcl.val,
                    (U8*) val.u.deviceName.val, evPtr->u.dev.lcl.len);
               evPtr->u.dev.dom.len = domLen;
               if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->u.dev.dom.val), (MsgLen)(evPtr->u.dev.dom.len + 1)) != ROK) { RETVALUE(RFAILED); }
               cmMemcpy((U8*) evPtr->u.dev.dom.val,
                       (U8*) (delimChar + 1), evPtr->u.dev.dom.len);
               evPtr->u.dev.lcl.pres = PRSNT_NODEF;
               evPtr->u.dev.dom.pres = PRSNT_NODEF;
            }
         } else {
            evPtr->u.dev.lcl.pres = NOTPRSNT;
            evPtr->u.dev.lcl.len = 0;
            evPtr->u.dev.dom.pres = NOTPRSNT;
            evPtr->u.dev.dom.len = 0;
         }
         break;
      case 5:
         if(val.u.mtpAddress.pres != PRSNT_NODEF) {
            MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
            RETVALUE(RFAILED);
         }
         evPtr->type.val = MGT_MID_MTPADDR;
         evPtr->u.mtpAddr.pres = PRSNT_NODEF;
         (void)cmMemset((U8*)evPtr->u.mtpAddr.val, '\0', 
                          sizeof(evPtr->u.mtpAddr.val));
         evPtr->u.mtpAddr.len = 0;

         for(asnCount = 0; asnCount < val.u.mtpAddress.len; asnCount++){
            hexVal = (val.u.mtpAddress.val[asnCount] >> 4) & 0xF;
            evPtr->u.mtpAddr.val[evPtr->u.mtpAddr.len++] = hexArr[hexVal];
            hexVal = val.u.mtpAddress.val[asnCount] & 0xF;
            evPtr->u.mtpAddr.val[evPtr->u.mtpAddr.len++] = hexArr[hexVal];
         }
         break;
      default:
         MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
         RETVALUE(RFAILED);
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncValue_SDPEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncValue_SDPEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncValue_SDPEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16           ret;
   Mem           memReg;
   CmAbnfErr     abnfErr;
   Data          nullChar;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncValue_SDPEnc);

   /* set up for abnf call */
   (void)cmMemset((U8*)&abnfErr, 0, sizeof(abnfErr));
   (void)cmMemset((U8*)&memReg, 0, sizeof(memReg));
   memReg.pool = msgCp->pool;
   memReg.region = msgCp->region;
                                                                                
   /* Make ABNF call */
   ++msgCp->elmntDef;
   if ((ret = cmAbnfEncPduMsg(CM_ABNF_PROT_MEGACO_H248, (U8*)msgCp->secEvntStr, msgCp->mBuf, (CmAbnfElmDef*)*(msgCp->elmntDef), &memReg, &abnfErr)) != ROK) {
      S8 errBuf[1024];
      mwrapErrPrint(&abnfErr, errBuf);
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT); /* ABNF->ASN mapping */
      RETVALUE(RFAILED);
   }

   /* make it null terminated */
   nullChar = (Data)0;
   if ((ret = mgAsnEncOut2Buf(msgCp, &nullChar, 1)) != ROK) { RETVALUE(ret); }
                                                                                
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncValue_SDPDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncValue_SDPDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncValue_SDPDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16           ret;
   Mem           memReg;
   CmAbnfErr     abnfErr;
   MsgLen        numDecBytes;
   CmAbnfDecOff  bufOff;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncValue_SDPDec);

   /* set up for abnf call */
   (void)cmMemset((U8*)&abnfErr, 0, sizeof(abnfErr));
   (void)cmMemset((U8*)&memReg, 0, sizeof(memReg));
   (void)cmMemset((U8*)&bufOff, 0, sizeof(bufOff));
   numDecBytes = 0;
   memReg.pool = msgCp->pool;
   memReg.region = msgCp->region;

   /* ABNF call */
   ++msgCp->elmntDef;
   if ((ret = cmAbnfDecPduMsg(CM_ABNF_PROT_MEGACO_H248, msgCp->memCp, (U8*)msgCp->secEvntStr, msgCp->mBuf, (CmAbnfElmDef *)*(msgCp->elmntDef), &numDecBytes, &bufOff, &abnfErr)) != ROK) {
      S8 errBuf[1024];
      mwrapErrPrint(&abnfErr, errBuf);
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG); /* ABNF->ASN mapping */
      RETVALUE(RFAILED);
   }

   /* skip the bytes */
   if ((ret = mgAsnDecIgnoreBytes(msgCp, numDecBytes)) != ROK) {
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(ret);
   }
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncValueSeqOfEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncValueSeqOfEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncValueSeqOfEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoValue* evPtr;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncValueSeqOfEnc);
   evPtr = (MgMgcoValue*)(msgCp->evntStr);

   /* ignores pres getting here, so we much check here */
   if (! (evPtr->type.pres)) {
      MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
      RETVALUE(RFAILED);
   }

   /* The ABNF event structure doesn't really support all of the types */
   /* mg005.105: Added prevention check for the type of the property */
   msgCp->elmntDef = msgCp->secElmntDef;
   switch (evPtr->type.val) {
   case MGT_VALTYPE_BOOL:
      if ((msgCp->elmntDef == NULLP ) || 
            ((msgCp->elmntDef != NULLP ) && 
             (*(msgCp->elmntDef))->tag == MG_ASN_UBOOL))
      {
      msgCp->elmntDef = mgaValue_Boolean;
      /* mg007.105: boolean field is added in MgMgcoValue union */
      msgCp->evntStr = (TknU8*)&(evPtr->u.boole);
      }
      else
      {
         MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
         RETVALUE(RFAILED);
      }
      break;

   case MGT_VALTYPE_ENUM:
      if ((msgCp->elmntDef == NULLP ) || 
            ((msgCp->elmntDef != NULLP ) && 
             (*(msgCp->elmntDef))->tag == MG_ASN_UENUM))
      {
      msgCp->elmntDef = mgaValue_Enumeration;
      msgCp->evntStr = (TknU8*)&(evPtr->u.enume);
      }
      else
      {
         MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
         RETVALUE(RFAILED);
      }
      break;
   case MGT_VALTYPE_UINT32:
   case MGT_VALTYPE_HEX_UINT32: /* not supported */
   case MGT_VALTYPE_SINT32: /* not supported */
   case MGT_VALTYPE_HEX_SINT32: /* not supported */
      if ((msgCp->elmntDef == NULLP ) || 
            ((msgCp->elmntDef != NULLP ) && 
             (*(msgCp->elmntDef))->tag == MG_ASN_UINT))
      {
         msgCp->elmntDef = mgaValue_TknU32;
         msgCp->evntStr = (TknU8*)&(evPtr->u.decInt);
      }
      else
      {
         MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
         RETVALUE(RFAILED);
      }
      break;
   case MGT_VALTYPE_OCTSTRXL:
      if ((msgCp->elmntDef == NULLP ) || 
            ((msgCp->elmntDef != NULLP ) && (((*(msgCp->elmntDef))->tag == MG_ASN_UOCTSTR) ||
            ((*(msgCp->elmntDef))->tag == MG_ASN_UIA5) )))
      {
         msgCp->elmntDef = mgaValue_TknStrOSXL;
         msgCp->evntStr = (TknU8*)&(evPtr->u.osxl);
      }
      else
      {
         MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
         RETVALUE(RFAILED);
      }
      break;
   case MGT_VALTYPE_TKNBUF:
   case MGT_VALTYPE_SIGNAME:
   case MGT_VALTYPE_SIGLST:
   case MGT_VALTYPE_TERMID:
   case MGT_VALTYPE_TERMIDLST:
#if ( defined(GCP_PKG_MGCO_ADVAUSRVRBASE) || \
      defined(GCP_PKG_MGCO_AASDIGCOLLECT) || \
      defined(GCP_PKG_MGCO_AASRECODING)   || \
      defined(GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT) )
   case MGT_VALTYPE_ADV_AUD_SEGLST:
   case MGT_VALTYPE_ADV_AUD_PROVSEGSPEC:
#endif
      {
         EXTERN CmAbnfElmDef mgMgcoGenericSigComplSigIdSigNameDef;
         EXTERN CmAbnfElmDef mgMgcoGenericSigComplSigIdSigLstDef;
         EXTERN CmAbnfElmDef mgMgcoTermIdDef;
         EXTERN CmAbnfElmDef mgMgcoTermIdLstDef;
#if ( defined(GCP_PKG_MGCO_ADVAUSRVRBASE) || \
      defined(GCP_PKG_MGCO_AASDIGCOLLECT) || \
      defined(GCP_PKG_MGCO_AASRECODING)   || \
      defined(GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT) )
         EXTERN CmAbnfElmDef mgMgcoAnncSpec;
         EXTERN CmAbnfElmDef mgMgcoProvSegSpec;
#endif

         TknStrOSXL      val;
         CmAbnfElmDef  *abnfElmDef;
         CmAbnfErr     abnfErr;
         CmAbnfDecOff  bufOff;
         Mem           memReg;
         Buffer        *mBuf;

         /* init */
         (void)cmMemset((U8*)&val, 0, sizeof(val));
         (void)cmMemset((U8*)&abnfErr, 0, sizeof(abnfErr));
         (void)cmMemset((U8*)&bufOff, 0, sizeof(bufOff));
         (void)cmMemset((U8*)&memReg, 0, sizeof(memReg));
         memReg.pool = msgCp->pool;
         memReg.region = msgCp->region;

         /* set specific info */
         switch (evPtr->type.val) {
         case MGT_VALTYPE_TKNBUF:
            msgCp->elmntDef = mgaValue_TknStrOSXL;
            msgCp->evntStr = (TknU8*)&(evPtr->u.mBuf);
            MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
            RETVALUE(RFAILED);
            break;
         case MGT_VALTYPE_SIGNAME:
            msgCp->elmntDef = mgaValue_TknStrOSXL;
            msgCp->evntStr = (TknU8*)&(evPtr->u.sigName);
            abnfElmDef = &mgMgcoGenericSigComplSigIdSigNameDef;
            break;
         case MGT_VALTYPE_SIGLST:
            msgCp->elmntDef = mgaValue_TknStrOSXL;
            msgCp->evntStr = (TknU8*)&(evPtr->u.sigLst);
            abnfElmDef = &mgMgcoGenericSigComplSigIdSigLstDef;
            break;
         case MGT_VALTYPE_TERMID:
            msgCp->elmntDef = mgaValue_TknStrOSXL;
            msgCp->evntStr = (TknU8*)&(evPtr->u.termId);
            abnfElmDef = &mgMgcoTermIdDef;
            break;
         case MGT_VALTYPE_TERMIDLST:
            msgCp->elmntDef = mgaValue_TknStrOSXL;
            msgCp->evntStr = (TknU8*)&(evPtr->u.termIdLst);
            abnfElmDef = &mgMgcoTermIdLstDef;
            break;
#if ( defined(GCP_PKG_MGCO_ADVAUSRVRBASE) || \
      defined(GCP_PKG_MGCO_AASDIGCOLLECT) || \
      defined(GCP_PKG_MGCO_AASRECODING)   || \
      defined(GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT) )
         case MGT_VALTYPE_ADV_AUD_SEGLST:
            msgCp->elmntDef = mgaValue_TknStrOSXL;
            msgCp->evntStr = (TknU8*)&(evPtr->u.anSpec);
            abnfElmDef = &mgMgcoAnncSpec;
            break;
         case MGT_VALTYPE_ADV_AUD_PROVSEGSPEC:
            msgCp->elmntDef = mgaValue_TknStrOSXL;
            msgCp->evntStr = (TknU8*)&(evPtr->u.prSpec);
            abnfElmDef = &mgMgcoProvSegSpec;
            break;
#endif
         }

         /* mg004.105: Add - support for the empty value */
/*         if (((TknU8*)(msgCp->evntStr))->pres != PRSNT_NODEF)
         {
            ((TknU8*)(msgCp->evntStr))->pres = PRSNT_NODEF;
            if ((ret = mgAsnEncTag(msgCp)) != ROK) 
            {
               if (ret == RSKIP) { RETVALUE(ROK); }
                  RETVALUE(ret);
            }
         }
         else*/
         {
            /* get message buffer */
            if ((ret = SGetMsg(msgCp->region, msgCp->pool, &mBuf)) != ROK) { RETVALUE(ret); }

            /* encode to string */
            if ((ret = cmAbnfEncPduMsg(CM_ABNF_PROT_MEGACO_H248, (U8*)msgCp->evntStr, mBuf, abnfElmDef, &memReg, &abnfErr)) != ROK) {
               S8 errBuf[1024];
               mwrapErrPrint(&abnfErr, errBuf);
               SPutMsg(mBuf);
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
               RETVALUE(RFAILED);
            }

            /* get string length */
            if ((ret = SFndLenMsg(mBuf, (MsgLen*)&(val.len))) != ROK) {
               SPutMsg(mBuf);
               MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
               RETVALUE(RFAILED);
            }

            /* get memory for val */
            if ((ret = SGetSBuf(msgCp->region, msgCp->pool, (Data**)&(val.val), (MsgLen)(val.len + 1))) != ROK) {
               SPutMsg(mBuf);
               MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
               RETVALUE(RFAILED);
            }
            cmMemset((U8 *)val.val, 0, (val.len+1));

            /* copy string */
            if ((ret = SRemPreMsgMult(val.val, (MsgLen)val.len, mBuf)) != ROK) {
               SPutMsg(mBuf);
               (Void)SPutSBuf(msgCp->region, msgCp->pool, (Data*)(val.val), (MsgLen)(val.len + 1));
               MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
               RETVALUE(RFAILED);
            }
            SPutMsg(mBuf);
            val.pres = PRSNT_NODEF;

            /* Set from secondary pointers if provided */
            if (msgCp->secElmntDef != NULLP){
                msgCp->elmntDef = msgCp->secElmntDef;
            }

            /* Double encode it */
            msgCp->evntStr = (TknU8*)&val;
            if ((ret = mgAsnEncElmnt(msgCp)) != ROK) {
               (Void)SPutSBuf(msgCp->region, msgCp->pool, (Data*)(val.val), (MsgLen)(val.len + 1));
               RETVALUE(ret);
            }

            /* return the data */
            if ((ret = SPutSBuf(msgCp->region, msgCp->pool, (Data*)(val.val), (MsgLen)(val.len + 1))) != ROK) { RETVALUE(ret); }

            MGAFUNCSKIP(msgCp);
            RETVALUE(ret);
         }
      }
      break;
   default:
      MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
      RETVALUE(RFAILED);
   }

   /* Set from secondary pointers if provided */
   if (msgCp->secElmntDef != NULLP){
      msgCp->elmntDef = msgCp->secElmntDef;
   }

   /* mg004.105: Add - support for the empty value */
/*   if (((TknU8*)(msgCp->evntStr))->pres != PRSNT_NODEF)
   {
      ((TknU8*)(msgCp->evntStr))->pres = PRSNT_NODEF;
      if ((ret = mgAsnEncTag(msgCp)) != ROK) 
      {
         if (ret == RSKIP) { RETVALUE(ROK); }
            RETVALUE(ret);
      }
   }
   else*/
   {
      /* Double encode it */
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncValueSeqOfDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncValueSeqOfDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncValueSeqOfDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoValue* evPtr;
   MsgLen               elmntLen;       /* element length */
   MsgLen               prevLen;        /* previous length */



   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncValueSeqOfDec);
   evPtr = (MgMgcoValue*)(msgCp->evntStr);

   /* Try each type */
   elmntLen = msgCp->elmntLen;
   prevLen = mgAsnFindLen(msgCp);
   if (msgCp->secElmntDef != NULLP) {
      /* get the tag and length */
      msgCp->elmntDef = msgCp->secElmntDef;
      if ((ret = mgAsnDecTagLen(msgCp)) != ROK) { RETVALUE(ret); }
   } else {
      /* get the tag and length */
      msgCp->elmntDef = mgaValue_TknStrOSXL;
      if ((ret = mgAsnDecTagLen(msgCp)) != ROK)
      {
         if (ret != RSKIP) { RETVALUE(ret); }
         msgCp->elmntDef = mgaValue_Enumeration;
         if ((ret = mgAsnDecTagLen(msgCp)) != ROK)
         {
            if (ret != RSKIP) { RETVALUE(ret); }
            msgCp->elmntDef = mgaValue_TknU32;
            if ((ret = mgAsnDecTagLen(msgCp)) != ROK)
            {
               if (ret != RSKIP) { RETVALUE(ret); }
               msgCp->elmntDef = mgaValue_Boolean;
               if ((ret = mgAsnDecTagLen(msgCp)) != ROK)
               {
                  RETVALUE(RFAILED);
               }
            }
         }
      }
   }

   /* Check length only gives 2 bytes for tag/length */
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   /* mg004.105: changed for empty sequence of parameter values */
   if (elmntLen <= 0) { 
/*   if (elmntLen < 0) {*/
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(RFAILED);
   }
/*   
   else if (elmntLen == 0)
   {
      evPtr->type.pres = PRSNT_NODEF;
      switch ((*(msgCp->elmntDef))->tag) 
      {
         case MG_ASN_UENUM:
         case MG_ASN_UBOOL:
            evPtr->type.val = MGT_VALTYPE_ENUM;
            break;
         case MG_ASN_UINT:
            evPtr->type.val = MGT_VALTYPE_UINT32;
            break;
         case MG_ASN_UOCTSTR:
         case MG_ASN_UIA5:
            evPtr->type.val = MGT_VALTYPE_OCTSTRXL;
            break;
         default:
            MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
            RETVALUE(RFAILED);
         }

      MGAFUNCSKIP(msgCp);
      RETVALUE(ret);
   }*/
   prevLen = mgAsnFindLen(msgCp);

   /* do the decode */
   evPtr->type.pres = PRSNT_NODEF;
   switch ((*(msgCp->elmntDef))->tag) {
   /* mg005.105: Added Bool type for the property */
   case MG_ASN_UBOOL:
      evPtr->type.val = MGT_VALTYPE_BOOL;
      /* mg007.105: boolean field is added in MgMgcoValue union */
      msgCp->evntStr = (TknU8*)&(evPtr->u.boole);
      break;
   case MG_ASN_UENUM:
      evPtr->type.val = MGT_VALTYPE_ENUM;
      msgCp->evntStr = (TknU8*)&(evPtr->u.enume);
      break;
   case MG_ASN_UINT:
      evPtr->type.val = MGT_VALTYPE_UINT32;
      msgCp->evntStr = (TknU8*)&(evPtr->u.decInt);
      break;
   case MG_ASN_UOCTSTR:
   /* mg004.105: Added IA5 type in the param value */
   case MG_ASN_UIA5:
      evPtr->type.val = MGT_VALTYPE_OCTSTRXL;
      msgCp->evntStr = (TknU8*)&(evPtr->u.osxl);
      break;
   default:
      MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
      RETVALUE(RFAILED);
   }

   /* Do double decode */
   if ((ret = ((*(msgCp->elmntDef))->funcDec)(msgCp)) != ROK) { RETVALUE(ret); }

   /* Make sure we got it and nothing more */
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen > 0) {
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(RFAILED);
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncContextRequestEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncContextRequestEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncContextRequestEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret = ROK;
   MgMgcoContextProps* evPtr;
#ifdef MGT_GCP_VER_1_4
   U8 saveVal;
   U8 savePres;
#endif

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncContextRequestEnc);
   evPtr = (MgMgcoContextProps*)msgCp->evntStr;

   /* encode, in order, priority, emergency, and topologyReq.
    * If Ver_1_4, then also encode emergOff into an automatic
    * and massage emerg accordingly
    */
#ifdef MGT_GCP_VER_1_4
   if (evPtr->emergOff.pres) {
      if(evPtr->emerg.val == 1 && evPtr->emergOff.val == 1) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
      } else if (evPtr->emergOff.val == 1) {
         saveVal = evPtr->emerg.val;
         savePres = evPtr->emerg.pres;
         evPtr->emerg.val = 0;
         evPtr->emerg.pres = PRSNT_NODEF;
      }
   }
#endif

   /* mg003.105: Fix for ContextRequestEnc */
   if ((evPtr->pri.pres) || (evPtr->emerg.pres) || (evPtr->tl.num.val > 0)) {
   if((ret = mgAsnEncSetSeq(msgCp)) != ROK) { RETVALUE(RFAILED); }
   }

#ifdef MGT_GCP_VER_1_4
   if(evPtr->emergOff.pres && evPtr->emergOff.val == 1) {
      evPtr->emerg.val = saveVal;
      evPtr->emerg.pres = savePres;
   }
#endif

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncContextRequestDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncContextRequestDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncContextRequestDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
#ifdef MGT_GCP_VER_1_4
   MgMgcoContextProps* evPtr;
#endif

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncContextRequestDec);

   if((ret = mgAsnDecSeq(msgCp)) != ROK) {
      RETVALUE(ret);
   }

#ifdef MGT_GCP_VER_1_4
   evPtr = (MgMgcoContextProps*) (msgCp->evntStr);
   if(evPtr->emerg.pres && evPtr->emerg.val == 0) {
      evPtr->emerg.pres = NOTPRSNT;
      evPtr->emergOff.pres = PRSNT_NODEF;
      evPtr->emergOff.val = 1;
   }
#endif

   MGAFUNCSKIP(msgCp);
 
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncPropertyParmEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncPropertyParmEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncPropertyParmEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoPropParm* evPtr;
   MgaPkg*          pkgProps;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncPropertyParmEnc);

   ++msgCp->elmntDef;
   evPtr = (MgMgcoPropParm*)msgCp->evntStr;
   /* Error check the package id */
   /* mg004.105: Added Annex C support */
   /* mg005.105: Change for prevention check of the property type */
   if(evPtr->pkg.val == 0) 
   {
      /* allow it, but it's not defined */
      msgCp->secElmntDef = (MgAsnElmntDef**)NULL;
      switch (AnnexCDefineMap[evPtr->name.name.u.val.val] >> 8) {
      case 0x10:
         msgCp->secElmntDef = (MgAsnElmntDef**)&MgaPkgAnnexC1Properties;
         break;
      case 0x20:
         msgCp->secElmntDef = (MgAsnElmntDef**)&MgaPkgAnnexC2Properties;
         break;
      case 0x30:
         msgCp->secElmntDef = (MgAsnElmntDef**)&MgaPkgAnnexC3Properties;
         break;
      case 0x40:
         msgCp->secElmntDef = (MgAsnElmntDef**)&MgaPkgAnnexC4Properties;
         break;
      case 0x50:
         msgCp->secElmntDef = (MgAsnElmntDef**)&MgaPkgAnnexC5Properties;
         break;
      case 0x60:
         msgCp->secElmntDef = (MgAsnElmntDef**)&MgaPkgAnnexC6Properties;
         break;
      case 0x70:
         msgCp->secElmntDef = (MgAsnElmntDef**)&MgaPkgAnnexC7Properties;
         break;
      case 0x80:
         msgCp->secElmntDef = (MgAsnElmntDef**)&MgaPkgAnnexC8Properties;
         break;
      case 0x90:
         msgCp->secElmntDef = (MgAsnElmntDef**)&MgaPkgAnnexC9Properties;
         break;
      case 0xa0:
         msgCp->secElmntDef = (MgAsnElmntDef**)&MgaPkgAnnexC10Properties;
         break;
      case 0xb0:
         msgCp->secElmntDef = (MgAsnElmntDef**)&MgaPkgAnnexC11Properties;
         break;
      case 0xc0:
         msgCp->secElmntDef = (MgAsnElmntDef**)&MgaPkgAnnexC12Properties;
         break;
      }
      if ((! evPtr->name.name.type.pres) ||
          (evPtr->name.name.type.val != MGT_GEN_TYPE_KNOWN)) {
         msgCp->secElmntDef = (MgAsnElmntDef**)NULL;
      }
   }
   /* mg007.105: 18 jan check before parm value encoding */
   else
   {
      pkgProps = mgaPkgProperties[evPtr->pkg.val - 1];
      if(pkgProps != NULLP) 
      {
         if( (evPtr->name.name.type.pres == PRSNT_NODEF) &&
               (evPtr->name.name.type.val == MGT_GEN_TYPE_KNOWN) &&
               (evPtr->name.name.u.val.val > 0) && 
               (evPtr->name.name.u.val.val <= pkgProps->maxNumNames) )
         {
            if(pkgProps->names[evPtr->name.name.u.val.val-1] != NULLP)
            {
               msgCp->secElmntDef = (MgAsnElmntDef**)pkgProps;
            } 
            else 
            {
                  MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
                  RETVALUE(RFAILED);
            }
         }
         else 
         {
            msgCp->secElmntDef = NULLP;
#ifndef MG_ASN_TEST
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
            RETVALUE(RFAILED);
#endif
         }
      }
   }
   /* encode PkgdName */
   msgCp->evntStr = (TknU8*) evPtr;
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* encode Prop Parm Value from evPtr->val */
   /* mg004.105: support for the empty parameter value */
   if( evPtr->val.type.pres == NOTPRSNT)
   {
      /* encode the tag into the array */
      evPtr->val.type.pres = PRSNT_NODEF;
      if ((ret = mgAsnEncTag(msgCp)) != ROK) {
         if (ret == RSKIP) { RETVALUE(ROK); }
         RETVALUE(ret);
      }
   }
   else
   {
      msgCp->evntStr = (TknU8*) &(evPtr->val);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

      /* extrainfo */
      if (evPtr->val.type.val != MGT_VALUE_EQUAL) {
         msgCp->evntStr = (TknU8*) &(evPtr->val);
         if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      }
   }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncPropertyParmDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncPropertyParmDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncPropertyParmDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16              ret;
   MgMgcoPropParm*  evPtr;
   MgMgcoLocalDesc   *localParm;
   MgMgcoValLst     vals;
   MsgLen           elmntLen;       /* element length */
   MsgLen           prevLen;        /* previous length */
   TknU8*           saveSecEvntStr;
   MgAsnElmntDef**  saveSecElmntDef;
   MgaPkg*          pkgProps;
   U16              tmpVal;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncPropertyParmDec);

   /* init */
   ++msgCp->elmntDef;
   evPtr = (MgMgcoPropParm*)(msgCp->evntStr);
   elmntLen = msgCp->elmntLen;

   localParm = ((MgMgcoLocalDesc*) (msgCp->secEvntStr));
   /* decode pkg/name */
   saveSecEvntStr = msgCp->secEvntStr;
   saveSecElmntDef = msgCp->secElmntDef;
   prevLen = mgAsnFindLen(msgCp);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   /* Error check the package id */
   if ((evPtr->pkg.val <= MGA_MAXPKGID))
      /*&& (evPtr->pkg.val >= 0) */
   {
      if (evPtr->pkg.val > 0) {
      /* validate the name */
/* mg003.105: Fixes for the property parm decoding */
/* mg004.105: Added Annex C support */
         pkgProps = mgaPkgProperties[evPtr->pkg.val - 1];
         if(pkgProps != NULLP) {
            if( (evPtr->name.name.type.pres == PRSNT_NODEF) &&
               (evPtr->name.name.type.val == MGT_GEN_TYPE_KNOWN) &&
               (evPtr->name.name.u.val.val > 0) && 
               (evPtr->name.name.u.val.val <= pkgProps->maxNumNames) )
            {
               if(pkgProps->names[evPtr->name.name.u.val.val-1] != NULLP)
               {
                  msgCp->secElmntDef = (MgAsnElmntDef**)(pkgProps->names[evPtr->name.name.u.val.val - 1]->value);
               } else {
                  MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
                  RETVALUE(RFAILED);
               }
            } else {
               msgCp->secElmntDef = NULLP;
#ifndef MG_ASN_TEST
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(RFAILED);
#endif
            }
         }
      } 
      else /* pkg.val == 0 */
      {
         
         tmpVal = AnnexCDefineMap[evPtr->name.name.u.val.val];

         msgCp->secElmntDef = (MgAsnElmntDef**)NULL;
         switch (tmpVal >> 8) {
         case 0x10:
            pkgProps = &MgaPkgAnnexC1Properties;
            tmpVal &= 0xFF;
            break;
         case 0x20:
            pkgProps = &MgaPkgAnnexC2Properties;
            tmpVal &= 0xFF;
            break;
         case 0x30:
            pkgProps = &MgaPkgAnnexC3Properties;
            tmpVal &= 0xFF;
            break;
         case 0x40:
            pkgProps = &MgaPkgAnnexC4Properties;
            tmpVal &= 0xFF;
            break;
         case 0x50:
            pkgProps = &MgaPkgAnnexC5Properties;
            tmpVal &= 0xFF;
            break;
         case 0x60:
            pkgProps = &MgaPkgAnnexC6Properties;
            tmpVal &= 0xFF;
            break;
         case 0x70:
            pkgProps = &MgaPkgAnnexC7Properties;
            tmpVal &= 0xFF;
            break;
         case 0x80:
            pkgProps = &MgaPkgAnnexC8Properties;
            tmpVal &= 0xFF;
            break;
         case 0x90:
            pkgProps = &MgaPkgAnnexC9Properties;
            tmpVal &= 0xFF;
            break;
         case 0xa0:
            pkgProps = &MgaPkgAnnexC10Properties;
            tmpVal &= 0xFF;
            break;
         case 0xb0:
            pkgProps = &MgaPkgAnnexC11Properties;
            tmpVal &= 0xFF;
            break;
         case 0xc0:
            pkgProps = &MgaPkgAnnexC12Properties;
            tmpVal &= 0xFF;
            break;
         }
         if ((! evPtr->name.name.type.pres) ||
             (evPtr->name.name.type.val != MGT_GEN_TYPE_KNOWN)) {
            pkgProps = (MgaPkg*)NULL;
         }

         if(pkgProps != NULLP) {
            if( (tmpVal > 0) && 
                (evPtr->name.name.type.pres == PRSNT_NODEF) &&
                (evPtr->name.name.type.val == MGT_GEN_TYPE_KNOWN))
            {
               if(pkgProps->names[tmpVal - 1] != NULLP)
               {
                  msgCp->secElmntDef = (MgAsnElmntDef**)(pkgProps->names[tmpVal - 1]->value);
               } else {
                  MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
                  RETVALUE(RFAILED);
               }
            } else {
                msgCp->secElmntDef = NULLP;
#ifndef MG_ASN_TEST
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(RFAILED);
#endif
            }
         }
      }   
   }

   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;
      msgCp->secEvntStr = saveSecEvntStr;
      if (mgAsnChkSeqMandMis(msgCp) != ROK) { RETVALUE(RFAILED); }
   }

   /* decode PropParmValue for value[s] */
   (void)cmMemset((U8*)&vals, 0, sizeof(MgMgcoValLst));
   msgCp->evntStr = (TknU8*) &vals;
   prevLen = mgAsnFindLen(msgCp);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);

   /* Validate and set defaults */
   /* mg004.105: Modified for the empty value */
   if(vals.num.val > 0)
   {
      /* len */
      if (elmntLen <= 0) {
         evPtr->val.type.pres = PRSNT_NODEF;
         evPtr->val.type.val = MGT_VALUE_EQUAL;
         msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;
         msgCp->secEvntStr = saveSecEvntStr;
         if (mgAsnChkSeqMandMis(msgCp) != ROK) { RETVALUE(RFAILED); }
      }
      else {
        /* decode ExtraInfo to partially populate evPtr->val;
         * The MgMgcoValLst will be used to complete evPtr->val
         */
        msgCp->evntStr = (TknU8*) &(evPtr->val);
        if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
        if(evPtr->val.type.pres == NOTPRSNT) {
           evPtr->val.type.pres = PRSNT_NODEF;
           evPtr->val.type.val = MGT_VALUE_EQUAL;
        }
      }

        /* merge */
        if((ret = mergeParmValue(&(evPtr->val), &vals)) != ROK) {
           MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
           RETVALUE(ret);
        }

         /* restore */
      /*  
      #ifdef CM_SDP_OPAQUE
         if (saveSecElmntDef == (MgAsnElmntDef**)&MgaPkgSDP) {
            msgCp->secElmntDef = saveSecElmntDef;
         } else {
            msgCp->secElmntDef = NULLP;
         }
      #else
         msgCp->secElmntDef = NULLP;
      #endif
      */
   }
   msgCp->secElmntDef = NULLP;
   msgCp->secEvntStr = saveSecEvntStr;
   
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncStatisticsParameterEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncStatisticsParameterEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncStatisticsParameterEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoStatsPar* evPtr;
   MgMgcoValLst    valLst;
   MgMgcoValue*    tmpValPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncStatisticsParameterEnc);

   ++msgCp->elmntDef;
   evPtr = (MgMgcoStatsPar*)msgCp->evntStr;
   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      msgCp->secElmntDef = (MgAsnElmntDef**)mgaPkgStatistics[evPtr->pkg.val - 1];
   } else if(evPtr->pkg.val == 0) {
      /* allow it, but it's not defined */
      msgCp->secElmntDef = NULLP;
   }
   /* encode PkgdName */
   msgCp->evntStr = (TknU8*) evPtr;
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* encode statsValue from evPtr->val */
   valLst.num.pres = evPtr->val.type.pres;
   valLst.num.val = 1;
   valLst.vals = &tmpValPtr;
   tmpValPtr = &(evPtr->val);
   msgCp->evntStr = (TknU8*) &(valLst);
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncStatisticsParameterDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncStatisticsParameterDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncStatisticsParameterDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16              ret;
   MgMgcoStatsPar*  evPtr;
   MgMgcoValLst     vals;
   MsgLen           elmntLen;       /* element length */
   MsgLen           prevLen;        /* previous length */
   MgaPkg* pkgName;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncStatisticsParameterDec);

   evPtr = (MgMgcoStatsPar*)msgCp->evntStr;
   elmntLen = msgCp->elmntLen;
   msgCp->evntStr = (TknU8*) evPtr;
   (void)cmMemset((U8*)evPtr, 0, sizeof(MgMgcoStatsPar));
   ++msgCp->elmntDef;

   /* decode pkg/name */
   prevLen = mgAsnFindLen(msgCp);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      /* validate the name */
      pkgName = mgaPkgStatistics[evPtr->pkg.val - 1];
      if(pkgName != NULLP) {
         if( (evPtr->name.name.type.pres == PRSNT_NODEF) &&
            (evPtr->name.name.type.val == MGT_GEN_TYPE_KNOWN) &&
            (evPtr->name.name.u.val.val > 0) && 
            (evPtr->name.name.u.val.val <= pkgName->maxNumNames) )
         {
            if(pkgName->names[evPtr->name.name.u.val.val-1] != NULLP)
            {
               msgCp->secElmntDef = (MgAsnElmntDef**)(pkgName->names[evPtr->name.name.u.val.val - 1]->value);
            } else {
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(RFAILED);
            }
         } else {
#ifndef MG_ASN_TEST
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
            RETVALUE(RFAILED);
#endif
         }
      }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) { RETVALUE(mgAsnChkSeqMandMis(msgCp)); }

   /* decode statValue for value[s] */
   (void)cmMemset((U8*)&vals, 0, sizeof(MgMgcoValLst));
   msgCp->evntStr = (TknU8*) &vals;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* Validate and set defaults */
   if (vals.num.pres && vals.num.val > 0) {
      (void)cmMemcpy((U8*)&(evPtr->val), (U8*)(vals.vals[0]), sizeof(MgMgcoValue));
      evPtr->val.type.pres = vals.num.pres;
   }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;
   
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncPropParmValueEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncPropParmValueEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncPropParmValueEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoParmValue* evPtr;
   MgMgcoValue* tmpPtr[2];
   MgMgcoValLst val; 

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncPropParmValueEnc);
   evPtr = (MgMgcoParmValue*) msgCp->evntStr;
   (void)cmMemset((U8*)&val, 0, sizeof(MgMgcoValLst));

   /* Depending on type, point to or construct the MgMgcoValLst */
   switch(evPtr->type.val) {
      case MGT_VALUE_EQUAL:
         val.num.pres = PRSNT_NODEF;
         val.num.val = 1;
         val.vals = tmpPtr; /* This will twist your melon */
         *(val.vals) = &(evPtr->u.eq);
         ((TknStrXL*)*(val.vals))->pres = PRSNT_NODEF; /* hack for mapping */
         msgCp->evntStr = (TknU8*) &val;
         break;
      case MGT_VALUE_GREATERTHAN:
         val.num.pres = PRSNT_NODEF;
         val.num.val = 1;
         val.vals = tmpPtr; /* This will twist your melon */
         *(val.vals) = &(evPtr->u.gt);
         ((TknStrXL*)*(val.vals))->pres = PRSNT_NODEF; /* hack for mapping */
         msgCp->evntStr = (TknU8*) &val;
         break;
      case MGT_VALUE_LESSTHAN:
         val.num.pres = PRSNT_NODEF;
         val.num.val = 1;
         val.vals = tmpPtr; /* This will twist your melon */
         *(val.vals) = &(evPtr->u.lt);
         ((TknStrXL*)*(val.vals))->pres = PRSNT_NODEF; /* hack for mapping */
         msgCp->evntStr = (TknU8*) &val;
         break;
      case MGT_VALUE_NOTEQUAL:
         val.num.pres = PRSNT_NODEF;
         val.num.val = 1;
         val.vals = tmpPtr; /* This will twist your melon */
         *(val.vals) = &(evPtr->u.ne);
         ((TknStrXL*)*(val.vals))->pres = PRSNT_NODEF; /* hack for mapping */
         msgCp->evntStr = (TknU8*) &val;
         break;
      case MGT_VALUE_AND:
         msgCp->evntStr = (TknU8*) &(evPtr->u.and);
         break;
      case MGT_VALUE_OR:
         msgCp->evntStr = (TknU8*) &(evPtr->u.or);
         break;
      case MGT_VALUE_RANGE:
         val.num.pres = PRSNT_NODEF;
         val.num.val = 2;
         val.vals = tmpPtr; /* This will twist your melon */
         *(val.vals) = &(evPtr->u.rng.low);
         ((TknStrXL*)*(val.vals))->pres = PRSNT_NODEF; /* hack for mapping */
         *(val.vals + 1) = &(evPtr->u.rng.up);
         ((TknStrXL*)*(val.vals + 1))->pres = PRSNT_NODEF;/* hack for mapping */
         msgCp->evntStr = (TknU8*) &(val);
         break;
   }

   ret = mgAsnEncUnconsSetSeqOf(msgCp);

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncExtraInfoEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncExtraInfoEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncExtraInfoEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoParmValue* evPtr;
   MgMgcaExtraInfo val;
   S32 encode = 0;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncExtraInfoEnc);

   evPtr = (MgMgcoParmValue*) msgCp->evntStr;
   (void)cmMemset((U8*)&val, 0, sizeof(MgMgcaExtraInfo));

   /* create it */
   switch (evPtr->type.val) {
      case MGT_VALUE_EQUAL:
         break;
      case MGT_VALUE_GREATERTHAN:
         val.id.val = 1;	/* assumming choice 1*/
         val.id.pres = PRSNT_NODEF;
         val.u.relation.pres = PRSNT_NODEF;
         val.u.relation.val = 0;
         ++encode;
         break;
      case MGT_VALUE_LESSTHAN:
         val.id.val = 1;	/* assumming choice 1*/
         val.id.pres = PRSNT_NODEF;
         val.u.relation.pres = PRSNT_NODEF;
         val.u.relation.val = 1;
         ++encode;
         break;
      case MGT_VALUE_NOTEQUAL:
         val.id.val = 1;	/* assumming choice 1*/
         val.id.pres = PRSNT_NODEF;
         val.u.relation.pres = PRSNT_NODEF;
         val.u.relation.val = 2;
         ++encode;
         break;
      case MGT_VALUE_AND:
         /* If the sublist field is selected, 
          * a seq with more than one element encodes the value
          * of a list-valued property (i.e. value1 AND value2 AND...)
          */
         val.id.pres = PRSNT_NODEF;
         val.id.val = 3;
         val.u.sublist.pres = PRSNT_NODEF;
         val.u.sublist.val = 1;
         ++encode;
         break;
      case MGT_VALUE_OR:
         /* If the sublist field is not selected , a longer
          * sequence means "choose one of the values" */
         val.id.pres = PRSNT_NODEF;
         val.id.val = 3;
         val.u.sublist.pres = PRSNT_NODEF;
         val.u.sublist.val = 0;
         ++encode;
         break;
      case MGT_VALUE_RANGE:
         val.id.val = 2;	/* assumming choice 1*/
         val.id.pres = PRSNT_NODEF;
         val.u.range.pres = PRSNT_NODEF;
         val.u.range.val = 1;
         ++encode;
         break;
      default:
         MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
         RETVALUE(RFAILED);
   }
   if(encode > 0) {
      msgCp->evntStr = (TknU8*) &(val);
      if ((ret = mgAsnEncChoice(msgCp)) != ROK) { RETVALUE(ret); }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ROK);
}


/*
*
*       Fun:   mgaFuncExtraInfoDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncExtraInfoDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncExtraInfoDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoParmValue* evPtr;
   MgMgcaExtraInfo val;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncExtraInfoDec);
   evPtr = (MgMgcoParmValue*) (msgCp->evntStr);
   (void) cmMemset((U8*)evPtr, 0, sizeof(MgMgcoParmValue));

   (void)cmMemset((U8*)&val, 0, sizeof(MgMgcaExtraInfo));
   msgCp->evntStr = (TknU8*) &val;
   if((ret = mgAsnDecChoice(msgCp)) != ROK) { RETVALUE(ret); }
   if (val.id.pres == NOTPRSNT) { RETVALUE(ROK); }

   if ( (val.id.val == 1) && (val.u.relation.val == 0) ) {
      evPtr->type.pres = PRSNT_NODEF;
      evPtr->type.val = MGT_VALUE_GREATERTHAN;
   } else if ( (val.id.val == 1) && (val.u.relation.val == 1) ) {
      evPtr->type.pres = PRSNT_NODEF;
      evPtr->type.val = MGT_VALUE_LESSTHAN;
   } else if ( (val.id.val == 1) && (val.u.relation.val == 2) ) {
      evPtr->type.pres = PRSNT_NODEF;
      evPtr->type.val = MGT_VALUE_NOTEQUAL;
   } else if( val.id.val == 2 ) {
      evPtr->type.pres = PRSNT_NODEF;
      evPtr->type.val = MGT_VALUE_RANGE;
   } else if( (val.id.val == 3) && (val.u.sublist.val == 1) ) {
      evPtr->type.pres = PRSNT_NODEF;
      evPtr->type.val = MGT_VALUE_AND;
   } else if( (val.id.val == 3) && (val.u.sublist.val == 0) ) {
      evPtr->type.pres = PRSNT_NODEF;
      evPtr->type.val = MGT_VALUE_OR;
   }
   else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
      RETVALUE(RFAILED);
   }
   
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncPkgdNameEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncPkgdNameEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncPkgdNameEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   U16 tmpVal;
   TknPkgId *evPtr;
   MgMgcoPkgdName *namePtr;
   MgMgcaPkgdName val;
   MgaPkg *pkgDefinition = NULLP;    /* for value error checking */

   /* First 2 octets are pkgid.  Next two octets
    * are found in PkgdName.  If type is wildcard,
    * then 2 octets are wildcard.  If type is KNOWN,
    * then val contains the id to be placed in the
    * 2 octets.  If type is UNKNOWN, then error is
    * thrown.
    */

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncPkgdNameEnc);
   ret = ROK;
   evPtr = (TknPkgId*) msgCp->evntStr;
   tmpVal = 0;
   namePtr = (MgMgcoPkgdName*)((long)msgCp->evntStr + (long)sizeof(TknPkgId));
   val.pres = evPtr->pres;
   val.len = 4;
   /* mg005.105: Support for Package id U16 */
#ifdef MGT_PROPR_PKG_SUPPORT
   tmpVal = evPtr->val;
   if(tmpVal > MGA_MAXPKGID)
   {
      if(tmpVal >= 0x8000 && tmpVal <=0xFFFF)
      {
         val.val[0] = tmpVal >> 8;
         val.val[1] = tmpVal & 0xFF;
      }
      else
      {
#if   (defined(MGT_UNKNOWN_PKG_REJ) && defined(GCP_ASN))
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
#else
         val.val[0] = tmpVal >> 8;
         val.val[1] = tmpVal & 0xFF;
#endif  /* MGT_UNKNOWN_PKG_REJ && GCP_ASN */
      }
   }
   else
   {
      val.val[0] = tmpVal >> 8;
      val.val[1] = tmpVal & 0xFF;
   }
#else
   if(evPtr->val > MGA_MAXPKGID)
   {
#if   (defined(MGT_UNKNOWN_PKG_REJ) && defined(GCP_ASN))
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
#endif  /* MGT_UNKNOWN_PKG_REJ && GCP_ASN */
   }
   val.val[0] = 0;
   val.val[1] = evPtr->val;
#endif /* MGT_PROPR_PKG_SUPPORT */

   tmpVal = 0;
   pkgDefinition = (MgaPkg*)msgCp->secElmntDef;
   if(namePtr->name.type.val == MGT_GEN_TYPE_ALL) {
      /* 2 octets contain wildcard */
      val.val[2] = 0xff;
      val.val[3] = 0xff;
      msgCp->secElmntDef = NULLP;
   } 
   else if(namePtr->name.type.val == MGT_GEN_TYPE_KNOWN ) 
   {
      /* error check */
      /* mg004.105: Added Annex C support */
      if (val.val[1] == 0)
      {
         tmpVal = AnnexCDefineMap[namePtr->name.u.val.val];
         switch(tmpVal >> 8)
         {
            case 0x10 : pkgDefinition = (MgaPkg*)&(MgaPkgAnnexC1Properties);    /* C.1   0x10  */
                        val.val[2] = 0x10;
                        break;
            case 0x20 : pkgDefinition = (MgaPkg*)&(MgaPkgAnnexC2Properties);    /* C.2   0x20  */
                        val.val[2] = 0x20;
                        break;
            case 0x30 : pkgDefinition = (MgaPkg*)&(MgaPkgAnnexC3Properties);    /* C.3   0x30  */
                        val.val[2] = 0x30;
                        break;
            case 0x40 : pkgDefinition = (MgaPkg*)&(MgaPkgAnnexC4Properties);    /* C.4   0x40  */
                        val.val[2] = 0x40;
                        break;
            case 0x50 : pkgDefinition = (MgaPkg*)&(MgaPkgAnnexC5Properties);    /* C.5   0x50  */
                        val.val[2] = 0x50;
                        break;
            case 0x60 : pkgDefinition = (MgaPkg*)&(MgaPkgAnnexC6Properties);    /* C.6   0x60  */
                        val.val[2] = 0x60;
                        break;
            case 0x70 : pkgDefinition = (MgaPkg*)&(MgaPkgAnnexC7Properties);    /* C.7   0x70  */
                        val.val[2] = 0x70;
                        break;
            case 0x80 : pkgDefinition = (MgaPkg*)&(MgaPkgAnnexC8Properties);    /* C.8   0x80  */
                        val.val[2] = 0x80;
                        break;
            case 0x90: pkgDefinition = (MgaPkg*)&(MgaPkgAnnexC9Properties);    /* C.9   0x90  */
                        val.val[2] = 0x90;
                        break;
            case 0xa0 : pkgDefinition = (MgaPkg*)&(MgaPkgAnnexC10Properties);    /* C.10  0xa0  */
                        val.val[2] = 0xa0;
                        break;
            case 0xb0: pkgDefinition = (MgaPkg*)&(MgaPkgAnnexC11Properties);    /* C.11  0xb0  */
                        val.val[2] = 0xb0;
                        break;
            case 0xc0 : pkgDefinition = (MgaPkg*)&(MgaPkgAnnexC12Properties);    /* C.12  0xc0  */
                        val.val[2] = 0xc0;
                        break;
         }
         tmpVal &= 0xFF;
      }
      else
      {
         tmpVal = namePtr->name.u.val.val;
         val.val[2] = 0;
      }
      if(pkgDefinition != NULLP) 
      {
            if(tmpVal < 1 || tmpVal > pkgDefinition->maxNumNames) {
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(RFAILED);
            }
            else {
               if  (pkgDefinition->names[tmpVal - 1] == NULLP) {
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(RFAILED);
            }
               msgCp->secElmntDef = (pkgDefinition->names[tmpVal - 1]->value); 
            }
      }
      val.val[3] = tmpVal;
#ifdef MG_ASN_TEST      
   } else if(namePtr->name.type.val == MGT_GEN_TYPE_UNKNOWN ) {
      val.val[2] = namePtr->name.u.val.val >> 8;
      val.val[3] = namePtr->name.u.val.val & 0xFF;
      msgCp->secElmntDef = NULLP;
#endif /* MG_ASN_TEST */
   } else {
      MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
      RETVALUE(RFAILED);
   }
 
   msgCp->evntStr = (TknU8*)&val;
   ret = mgAsnEncOctetStr(msgCp);

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncPkgdNameDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncPkgdNameDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncPkgdNameDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknPkgId* pkgPtr;
   MgMgcoPkgdName *namePtr;
   MgMgcaPkgdName val;
   U16    tmpVal;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncPkgdNameDec);
   (void)cmMemset((U8*)&val, 0, sizeof(val));
   pkgPtr = (TknPkgId* )msgCp->evntStr;
   namePtr = (MgMgcoPkgdName*)((long)msgCp->evntStr + sizeof(TknPkgId));
   msgCp->evntStr = (TknU8*) &(val);
   if ((ret = mgAsnDecOctetStr(msgCp)) == ROK) {
      /* copy over into both the "TknU8 pkg" (of which we are pointing)
       * and the "MgMgcoPkgdName name" vars*/

      pkgPtr->pres = val.pres;
      /* mg005.105: Support for Package id U16 */
#ifdef MGT_PROPR_PKG_SUPPORT
      tmpVal = 0;
      tmpVal = val.val[0];
      tmpVal = tmpVal << 8;
      tmpVal |= val.val[1];
      pkgPtr->val = tmpVal;
#else
      if(val.val[0] != 0)
         RETVALUE(RFAILED);
      pkgPtr->val = val.val[1];
#endif /* MGT_PROPR_PKG_SUPPORT */
      tmpVal = 0;
      /* mg004.105: Added Annex C support */
      /* if val[2] and val[3] has 0xff, then set MGT_GEN_TYPE_ALL */
      /* else set to MGT_GEN_TYPE_KNOWN */
      if( (val.val[2] == (U8)0xff) && (val.val[3] == (U8)0xff) ) 
      {
            namePtr->name.type.pres = PRSNT_NODEF;
            namePtr->name.type.val = MGT_GEN_TYPE_ALL;
      } 
      else 
      {
         if (pkgPtr->val == 0)
         {
            U8 i;
            tmpVal = val.val[2];
            tmpVal = tmpVal << 8;
            tmpVal |= val.val[3];
            
            for( i = 0; i < MGA_ANNEXC_MAXNUM; i++)
            {
               if(AnnexCDefineMap[i] == tmpVal)
                  break;
            }
            if( i == MGA_ANNEXC_MAXNUM )
            {
               /* ERROR type to be filled */
               RETVALUE(RFAILED);
            }
            namePtr->name.u.val.val = AnnexCValueMap[i];
            namePtr->name.type.pres = PRSNT_NODEF;
            namePtr->name.type.val = MGT_GEN_TYPE_KNOWN;
            namePtr->name.u.val.pres = PRSNT_NODEF;
         }
         else
         {
            namePtr->name.type.pres = PRSNT_NODEF;
            namePtr->name.u.val.pres = PRSNT_NODEF;
            namePtr->name.u.val.val = val.val[2] << 8;
            namePtr->name.u.val.val |= val.val[3];

            if(pkgPtr->val > MGA_MAXPKGID) 
            /* mg005.105: Support for Package id U16 */
            {
#ifdef MGT_PROPR_PKG_SUPPORT
               if(pkgPtr->val >= 0x8000 && pkgPtr->val <= 0xFFFF)
                  namePtr->name.type.val = MGT_GEN_TYPE_UNKNOWN;
               else
#endif /* MGT_PROPR_PKG_SUPPORT */                  
#if   (defined(MGT_UNKNOWN_PKG_REJ) && defined(GCP_ASN))
               {   
                  MG_ASN_ERR(msgCp, MGT_MGCO_RSP_CODE_PACKAGE_UNSUPP);
                  RETVALUE(RFAILED);
               }   
#else
                  namePtr->name.type.val = MGT_GEN_TYPE_UNKNOWN;
#endif /* MGT_UNKNOWN_PKG_REJ && GCP_ASN*/
            }
            else
               namePtr->name.type.val = MGT_GEN_TYPE_KNOWN;
         }
      }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncPkgdNameSpecialDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncPkgdNameSpecialDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncPkgdNameSpecialDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknPkgId* pkgPtr;
   MgMgcoPropParm*  evPtr;
   MgMgcoPkgdName *namePtr;
   MgMgcaPkgdName val;
   U16    tmpVal;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncPkgdNameSpecialDec);
   (void)cmMemset((U8*)&val, 0, sizeof(val));

   /* mg003.105: Fixes for the package name decoding */
   evPtr = (MgMgcoPropParm*)(msgCp->evntStr);
   pkgPtr = (TknPkgId*)&(evPtr->pkg);
/*   pkgPtr = msgCp->evntStr;
   namePtr = (MgMgcoPkgdName*)msgCp->evntStr;*/
   namePtr = (MgMgcoPkgdName*)&(evPtr->name);
   msgCp->evntStr = (TknU8*) &(val);

   if ((ret = mgAsnDecOctetStr(msgCp)) != ROK) { RETVALUE(ret); }

   /* copy over into both the "TknU8 pkg" (of which we are pointing)
    * and the "MgMgcoPkgdName name" vars*/

   pkgPtr->pres = val.pres;
   /* mg005.105: Support for Package id U16 */
#ifdef MGT_PROPR_PKG_SUPPORT
   tmpVal = 0;
   tmpVal = val.val[0];
   tmpVal = tmpVal << 8;
   tmpVal |= val.val[1];
   pkgPtr->val = tmpVal;
#else
   if(val.val[0] != 0)
      RETVALUE(RFAILED);
   pkgPtr->val = val.val[1];
#endif /* MGT_PROPR_PKG_SUPPORT */

   tmpVal = 0;
   /* if val[2] and val[3] has 0xff, then set MGT_GEN_TYPE_ALL */
   /* else set to MGT_GEN_TYPE_KNOWN */
   if( (val.val[2] == (U8)0xff) && (val.val[3] == (U8)0xff) ) {
      namePtr->name.type.pres = PRSNT_NODEF;
      namePtr->name.type.val = MGT_GEN_TYPE_ALL;
   }
   else
   {
      if (pkgPtr->val == 0)
      {
         U8 i;
         tmpVal = val.val[2];
         tmpVal = tmpVal << 8;
         tmpVal |= val.val[3];
         
         for( i = 0; i < MGA_ANNEXC_MAXNUM; i++)
         {
            if(AnnexCDefineMap[i] == tmpVal)
               break;
         }
         if( i == MGA_ANNEXC_MAXNUM )
         {
            /* ERROR type to be filled */
            RETVALUE(RFAILED);
         }
         namePtr->name.u.val.val = AnnexCValueMap[i];
         namePtr->name.type.pres = PRSNT_NODEF;
         namePtr->name.type.val = MGT_GEN_TYPE_KNOWN;
         namePtr->name.u.val.pres = PRSNT_NODEF;
      }
      else
      {
         namePtr->name.type.pres = PRSNT_NODEF;
         namePtr->name.u.val.pres = PRSNT_NODEF;
         namePtr->name.u.val.val = val.val[2] << 8;
         namePtr->name.u.val.val |= val.val[3];
         if(pkgPtr->val > MGA_MAXPKGID) 
         {
            /* mg005.105: Support for Package id U16 */
#ifdef MGT_PROPR_PKG_SUPPORT
            if(pkgPtr->val >= 0x8000 && pkgPtr->val <= 0xFFFF)
               namePtr->name.type.val = MGT_GEN_TYPE_UNKNOWN;
            else
#endif
#if   (defined(MGT_UNKNOWN_PKG_REJ) && defined(GCP_ASN))
            {   
               MG_ASN_ERR(msgCp, MGT_MGCO_RSP_CODE_PACKAGE_UNSUPP);
               RETVALUE(RFAILED);
            }   
#else
               namePtr->name.type.val = MGT_GEN_TYPE_UNKNOWN;
#endif /* MGT_UNKNOWN_PKG_REJ && GCP_ASN*/
         }
         else
            namePtr->name.type.val = MGT_GEN_TYPE_KNOWN;
      }
   }
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncNameSpecialEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncNameSpecialEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncNameSpecialEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoName* evPtr;
   MgMgcaName val;
   MgAsnElmntDef **validateDef;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncNameSpecialEnc);
   evPtr = (MgMgcoName*) msgCp->evntStr;
   (void) cmMemset((U8*)&val, 0, sizeof(val));

   /*
    * MgcoName is a choice and we need the MGT_GEN_TYPE_KNOWN
    * value to encode into our octet string.  Error checking happens.
    * The "Special" function is currently used for Name/Value 
    * scenarios in MgcaSigParameter and MgcaEventParameter
    */
#ifdef MG_ASN_TEST
   if(evPtr->type.pres && evPtr->type.val == MGT_GEN_TYPE_UNKNOWN) {
      evPtr->u.val.val = 0;
      if ((validateDef = msgCp->secElmntDef) != NULLP) {
         evPtr->u.val.val = (*validateDef)->minLen;
      }
   }
   else {
      if ((validateDef = msgCp->secElmntDef) != NULLP) {
         if (evPtr->u.val.val < (*validateDef)->minLen) {
            evPtr->u.val.val = (*validateDef)->minLen;
         }
      }
   }
#else
   if(evPtr->type.pres && evPtr->type.val == MGT_GEN_TYPE_UNKNOWN) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }
#endif

   /* Error check the name value by checking the secondary element
    * defintion.  Must then set secondary element def with the
    * correct item so that the future "value" encoding can be
    * error checked. */
   if ((validateDef = msgCp->secElmntDef) != NULLP) {
      if(    evPtr->u.val.val < (*validateDef)->minLen 
          || evPtr->u.val.val > (*validateDef)->maxLen ) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_PKG);
         RETVALUE(RFAILED);
      }
      msgCp->secElmntDef = &(validateDef[evPtr->u.val.val]);
      if(msgCp->secElmntDef == NULLP) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
      }
   } 

   val.pres = evPtr->type.pres;
   val.len = 2;
   val.val[0] = 0;
   val.val[1] = evPtr->u.val.val;
 
   msgCp->evntStr = (TknU8*)&val;
   ret = mgAsnEncOctetStr(msgCp);

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncNameSpecialDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncNameSpecialDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncNameSpecialDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoName* evPtr;
   MgAsnElmntDef **validateDef;
   MgMgcaName val;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncNameSpecialDec);
   evPtr = (MgMgcoName*) msgCp->evntStr;
   (void) cmMemset((U8*)&val, 0, sizeof(val));

   /* decode */
   msgCp->evntStr = (TknU8*)&val;
   if((ret = mgAsnDecOctetStr(msgCp)) != ROK) { RETVALUE(ret); }

   /* copy */
   evPtr->type.pres = val.pres;
   evPtr->type.val = MGT_GEN_TYPE_KNOWN;
   evPtr->u.val.pres = PRSNT_NODEF;
   evPtr->u.val.val = val.val[1];


   /* Error check the name value by checking the secondary element */
   if ((validateDef = msgCp->secElmntDef) != NULLP) {
      if(    evPtr->u.val.val < (*validateDef)->minLen 
          || evPtr->u.val.val > (*validateDef)->maxLen ) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_PKG);
         RETVALUE(RFAILED);
      }
      msgCp->secElmntDef = validateDef + evPtr->u.val.val;
      if(*(msgCp->secElmntDef) == NULLP) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
      }
   }
 
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncServiceChangeReasonEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncServiceChangeReasonEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncServiceChangeReasonEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknStrOSXL*   evPtr;
   /* mg003.105: Fixes for ServiceChangeReasonEnc */
   struct {
      TknPres pres;
      TknStrOSXL val;
   } tmpVal;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncServiceChangeReasonEnc);
   evPtr = (TknStrOSXL*)msgCp->evntStr;
/* mg003.105: Removing double quotes for service change reason in binary encoding */
   MGASERVICECHANGEREASONMODIFY(msgCp);

   /* double encode. */
   tmpVal.pres.pres = PRSNT_NODEF;
   (void)memcpy(&tmpVal.val, evPtr, sizeof(TknStrOSXL));
   msgCp->elmntDef = mgaValue_scr;
   msgCp->evntStr = (TknU8*)&tmpVal;
   if ((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncServiceChangeReasonDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncServiceChangeReasonDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncServiceChangeReasonDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknStrOSXL*   evPtr;
   /* mg003.105: Fixes for ServiceChangeReasonEnc */
   struct {
      TknPres pres;
      TknStrOSXL val;
   } tmpVal;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncServiceChangeReasonEnc);
   evPtr = (TknStrOSXL*)msgCp->evntStr;
   
   tmpVal.pres.pres = 0;
   tmpVal.pres.val = 0;
   tmpVal.pres.spare1 = 0;
   tmpVal.val.pres = 0;
   tmpVal.val.spare1 = 0;
   tmpVal.val.len = 0;
   tmpVal.val.val = NULLP;

   /* decode */
   msgCp->elmntDef = mgaValue_scr;
   msgCp->evntStr = (TknU8*)&tmpVal;
   if ((ret = (mgAsnDecElmnt(msgCp))) != ROK) { RETVALUE(ret); }
   (void)memcpy(evPtr, &tmpVal.val, sizeof(TknStrOSXL));

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}
                                                              
#ifdef MG_ASN_TEST
PUBLIC S16 usrTermIDSampleEnc ARGS(( MgAsnMsgCp *msgCp, MgMgcaTerminationID* asnTermId, MgMgcoTermId* abnfTermId));
PUBLIC S16 (*UserFuncEnc) ARGS(( MgAsnMsgCp *msgCp, MgMgcaTerminationID* asnTermId, MgMgcoTermId* abnfTermId)) = usrTermIDSampleEnc;
PUBLIC S16 usrTermIDSampleDec ARGS((MgAsnMsgCp *msgCp, MgMgcoTermId* abnfTermId, MgMgcaTerminationID* asnTermIdData));
PUBLIC S16 (*UserFuncDec) ARGS((MgAsnMsgCp *msgCp, MgMgcoTermId* abnfTermId, MgMgcaTerminationID* asnTermIdData)) = usrTermIDSampleDec;
#else
PUBLIC S16 (*UserFuncEnc) ARGS(( MgAsnMsgCp *msgCp, MgMgcaTerminationID* asnTermId, MgMgcoTermId* abnfTermId)) = NULLP;
PUBLIC S16 (*UserFuncDec) ARGS((MgAsnMsgCp *msgCp, MgMgcoTermId* abnfTermId, MgMgcaTerminationID* asnTermIdData)) = NULLP;
#endif


EXTERN    CmAbnfElmDef   mgMgcoAuthHdrMsgDef;



/*
*
*       Fun:   mergeParmValue
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mergeParmValue
(
MgMgcoParmValue* pVal,  /* ABNF parm value */
MgMgcoValLst* vList     /* ABNF val list */
)
#else
PUBLIC S16 mergeParmValue(pVal, vList)
MgMgcoParmValue* pVal;  /* ABNF parm value */
MgMgcoValLst* vList;    /* ABNF val list */
#endif
{
   /* use the values in vList to populate the pVal, according to
    * the type that pVal has set 
    */
   MgMgcoValue** curValue;

   TRC2(mergeParmValue);
   switch(pVal->type.val) {
      case MGT_VALUE_EQUAL:
         cmMemcpy((U8*)&(pVal->u.eq), (U8*)*(vList->vals), sizeof(MgMgcoValue));
         break;
      case MGT_VALUE_GREATERTHAN:
         cmMemcpy((U8*)&(pVal->u.gt), (U8*)*(vList->vals), sizeof(MgMgcoValue));
         break;
      case MGT_VALUE_LESSTHAN:
         cmMemcpy((U8*)&(pVal->u.lt), (U8*)*(vList->vals), sizeof(MgMgcoValue));
         break;
      case MGT_VALUE_NOTEQUAL:
         cmMemcpy((U8*)&(pVal->u.ne), (U8*)*(vList->vals), sizeof(MgMgcoValue));
         break;
      case MGT_VALUE_AND:
         cmMemcpy((U8*)&(pVal->u.and), (U8*)vList, sizeof(MgMgcoValLst));
         break;
      case MGT_VALUE_OR:
         cmMemcpy((U8*)&(pVal->u.or), (U8*)vList, sizeof(MgMgcoValLst));
         break;
      case MGT_VALUE_RANGE:
         if(vList->num.val < 2) {
            RETVALUE(RFAILED);
         } else {
            pVal->u.rng.pres.pres = PRSNT_NODEF;
            curValue = vList->vals;
            cmMemcpy((U8*)&(pVal->u.rng.low), (U8*)*(curValue), sizeof(MgMgcoValue)); 
            ++curValue;
            cmMemcpy((U8*)&(pVal->u.rng.up), (U8*)*(curValue), sizeof(MgMgcoValue));
         }
         break;
   }
   RETVALUE(ROK);
}

#ifdef MG_ASN_TEST

/*
*
*       Fun:   usrTermIDSampleEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 usrTermIDSampleEnc
(
MgAsnMsgCp   *msgCp,          /* message control point */
MgMgcaTerminationID* asnTermId,  /* Termination id ASN.1 */
MgMgcoTermId* abnfTermId      /* Termination id ABNF */
)
#else
PUBLIC S16 usrTermIDSampleEnc(msgCp, asnTermId, abnfTermId)
MgAsnMsgCp   *msgCp;          /* message control point */
MgMgcaTerminationID* asnTermId;  /* Termination id ASN.1 */
MgMgcoTermId* abnfTermId;     /* Termination id ABNF */
#endif
{
   S16       ret = ROK;
   S16       j;

   switch (abnfTermId->type.val) {
   case MGT_TERMID_OTHER:
      asnTermId->id.pres = PRSNT_NODEF;
/* mg003.105: Changes for 3GPP Termination Id Encoding */
#ifdef MGCO_3G_TERMINATION
      asnTermId->id.len = 4;

      /* mg003.105: Fix for the 3GPP Termination ID */
      if(abnfTermId->name.lcl.len == 8)
      {
         U32 tmpVal;
         U8  ptr[10];

         ptr[0] = '0';
         ptr[1] = 'x';
         for(j=2;j<10;j++)
            ptr[j] = abnfTermId->name.lcl.val[j-2];
         CM_ABNF_A2I(ptr,10,tmpVal);

         for(j=1;j<=4;j++)
         {
            asnTermId->id.val[j-1] = (U8)(tmpVal >> (32 - (8 * j)));
         }

      }
      else
         RETVALUE(RFAILED);
         
#else
       /* length */
     asnTermId->id.len = abnfTermId->name.lcl.len + abnfTermId->name.dom.len;
      if (((int)asnTermId->id.len == 0) || ((int)asnTermId->id.len > 256)) {
         RETVALUE(RFAILED);
      }

      /* copy it */
      asnTermId->id.pres = PRSNT_NODEF;
      (void)cmMemcpy((U8*)asnTermId->id.val, (U8*)abnfTermId->name.lcl.val, abnfTermId->name.lcl.len);
      if(abnfTermId->name.dom.pres == PRSNT_NODEF) {
         (void)strcat((S8*)asnTermId->id.val, "@");
         (void)strcat((S8*)asnTermId->id.val, (S8*)abnfTermId->name.dom.val);
         asnTermId->id.len = asnTermId->id.len + 1; /* mg007.105: 1 added for @ */
      }

#endif
      break;
   case MGT_TERMID_ROOT:
      asnTermId->id.pres = PRSNT_NODEF;
      asnTermId->id.len = 1;
      asnTermId->id.val[0] = 0x0F;
      asnTermId->pres.pres = PRSNT_NODEF;
      asnTermId->id.pres = PRSNT_NODEF;
/* mg003.105: Changes for 3GPP Termination Id Encoding */
#ifdef MGCO_3G_TERMINATION
      asnTermId->id.len = 4;/*gcMsgId.maxLen; */
#else
      asnTermId->id.len = 8;/*gcMsgId.maxLen; */
#endif
      for (j=0; j<asnTermId->id.len; ++j) {
         asnTermId->id.val[j] = (0xFF);
      }
      break;
   case MGT_TERMID_CHOOSE:
   case MGT_TERMID_ALL:
      asnTermId->id.pres = PRSNT_NODEF;
      /* mg004.105: Added Wildcard support for the Termination id */
      asnTermId->wildcard.num.pres = PRSNT_NODEF;
      
#ifdef MGCO_3G_TERMINATION
      asnTermId->id.len = 4;

      /* mg003.105: Fix for the 3GPP Termination ID */
      if(abnfTermId->name.lcl.len == 8)
      {
         U32 tmpVal;
         U8  ptr[10];

         ptr[0] = '0';
         ptr[1] = 'x';
         for(j=2;j<10;j++)
            ptr[j] = abnfTermId->name.lcl.val[j-2];
         CM_ABNF_A2I(ptr,10,tmpVal);

         for(j=1;j<=4;j++)
         {
            asnTermId->id.val[j-1] = (U8)(tmpVal >> (32 - (8 * j)));
         }

      }
      else
         RETVALUE(RFAILED);
         
#else
       /* length */
     asnTermId->id.len = abnfTermId->name.lcl.len + abnfTermId->name.dom.len;
      if (((int)asnTermId->id.len == 0) || ((int)asnTermId->id.len > 256)) {
         RETVALUE(RFAILED);
      }

      /* copy it */
      asnTermId->id.pres = PRSNT_NODEF;
      (void)cmMemcpy((U8*)asnTermId->id.val, (U8*)abnfTermId->name.lcl.val, abnfTermId->name.lcl.len);
      if(abnfTermId->name.dom.pres == PRSNT_NODEF) {
         (void)strcat((S8*)asnTermId->id.val, "@");
         (void)strcat((S8*)asnTermId->id.val, (S8*)abnfTermId->name.dom.val);
         asnTermId->id.len = asnTermId->id.len + 1; /* mg007.105: 1 added for @ */
      }

#endif
      /* mg007.105: Termination ID wildcard field filling */
      if (abnfTermId->wildcard.num.pres && abnfTermId->wildcard.num.val > 0) 
      { 
         if ((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(asnTermId->wildcard.wildcard), &(asnTermId->wildcard.num), (Ptr*)abnfTermId->wildcard.wildcard, (MsgLen)(abnfTermId->wildcard.num.val))) != ROK) {
            RETVALUE(ret);
         }
      }
      break;
   default:
      return(RFAILED);
   }

   return(ret);
}
  

/*
*
*       Fun:   usrTermIDSampleDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 usrTermIDSampleDec
(
MgAsnMsgCp   *msgCp,          /* message control point */
MgMgcoTermId* abnfTermId,        /* Termination id ABNF */
MgMgcaTerminationID* asnTermId   /* Termination id ASN.1 */
)
#else
PUBLIC S16 usrTermIDSampleDec(msgCp, abnfTermId, asnTermId)
MgAsnMsgCp   *msgCp;          /* message control point */
MgMgcoTermId* abnfTermId;         /* Termination id ABNF */
MgMgcaTerminationID* asnTermId;   /* Termination id ASN.1 */
#endif
{
   S16 ret = ROK;
/* mg003.105: Changes for 3GPP Termination Id Encoding */
#ifndef  MGCO_3G_TERMINATION
   S8 *ptr;
#else
   U8 ptr[10];
#endif

   if (asnTermId->id.pres && asnTermId->id.len > 0) {
      /****-mg003.105: BUG FIXES *****/
      /* Check for Lenth as 8 and with asnTermId.val together 
       * since if termination ID is not ROOT then also length can be
        8 so it won't hit the last else */
       
/* mg003.105: Changes for 3GPP Termination Id Encoding */
      if(
#ifdef MGCO_3G_TERMINATION
            (asnTermId->id.len == gcMsgId.maxLen) &&
#endif
          ((asnTermId->id.val[0] == 0xFF) && (asnTermId->id.val[1] == 0xFF)
           &&(asnTermId->id.val[2] == 0xFF) && (asnTermId->id.val[3] == 0xFF)
#ifndef MGCO_3G_TERMINATION
           &&(asnTermId->id.val[4] == 0xFF) && (asnTermId->id.val[5] == 0xFF)
           &&(asnTermId->id.val[6] == 0xFF) && (asnTermId->id.val[7] == 0xFF)
#endif
           ))
         {
            abnfTermId->type.pres = PRSNT_NODEF;
            abnfTermId->type.val = MGT_TERMID_ROOT;
            abnfTermId->name.pres.pres = NOTPRSNT;
            RETVALUE(ROK);
         }
      else {
/* mg003.105: Changes for 3GPP Termination Id Encoding */
#ifdef MGCO_3G_TERMINATION
         
         if (asnTermId->id.len != 4)  {
            RETVALUE(RFAILED);
         }
         else
         {
            abnfTermId->type.pres = PRSNT_NODEF;
            abnfTermId->type.val = MGT_TERMID_OTHER;
            abnfTermId->name.pres.pres = PRSNT_NODEF;

            /* map local name */
         abnfTermId->name.lcl.pres = PRSNT_NODEF;
         /* mg003.105: Fixes for the 3GPP Termination ID */
         {
            U32 tmpVal;
            U8 j;
            tmpVal = 0;
            for(j=0;j<4;j++)
            {
               tmpVal = (tmpVal<<8) | (U8)asnTermId->id.val[j];
            }
            CM_ABNF_H2A(tmpVal,ptr,abnfTermId->name.lcl.len);
            for(j=0;j<8-abnfTermId->name.lcl.len;j++)
               ptr[j] = '0';
            abnfTermId->name.lcl.len = 8;
            ptr[abnfTermId->name.lcl.len] = '\0';
         }
         if (mgAsnDecGetMem(msgCp, (Ptr*)&(abnfTermId->name.lcl.val), (MsgLen)(abnfTermId->name.lcl.len+1)) != ROK) { RETVALUE(RFAILED); }
         cmMemcpy(abnfTermId->name.lcl.val, (U8*)ptr, abnfTermId->name.lcl.len+1);
         abnfTermId->name.dom.pres = NOTPRSNT;
         }
#else
         abnfTermId->type.pres = PRSNT_NODEF;
         abnfTermId->type.val = MGT_TERMID_OTHER;
         abnfTermId->name.pres.pres = PRSNT_NODEF;
         if ((ptr = strchr((S8*)asnTermId->id.val, '@')) != NULL) {
            /* mg002.105: Removed compilation warning */
            abnfTermId->name.lcl.len = (U8)((long)ptr - (long)asnTermId->id.val);
            ++ptr;
            if (((long)asnTermId->id.len - (long)abnfTermId->name.lcl.len) < 0) {
               abnfTermId->name.dom.len = 0;
            } else {
               /* mg007.105: domain length correction */
               abnfTermId->name.dom.len = ((long)asnTermId->id.len - ((long)abnfTermId->name.lcl.len + 1));
            }

            /* allocate */
            if (mgAsnDecGetMem(msgCp, (Ptr*)&(abnfTermId->name.lcl.val), (MsgLen)(abnfTermId->name.lcl.len+1)) != ROK) { RETVALUE(RFAILED); }
            if (mgAsnDecGetMem(msgCp, (Ptr*)&(abnfTermId->name.dom.val), (MsgLen)(abnfTermId->name.dom.len+1)) != ROK) { RETVALUE(RFAILED); }

            (void)cmMemcpy((U8*)abnfTermId->name.lcl.val, (U8*)asnTermId->id.val, abnfTermId->name.lcl.len);
            abnfTermId->name.lcl.val[abnfTermId->name.lcl.len] = '\000';
            (void)cmMemcpy((U8*)abnfTermId->name.dom.val, (U8*)ptr, abnfTermId->name.dom.len);
            abnfTermId->name.dom.val[abnfTermId->name.dom.len] = '\000';
            /* mg007.105: filling the present field of name */
            abnfTermId->name.lcl.pres = PRSNT_NODEF;
            abnfTermId->name.dom.pres = PRSNT_NODEF;
         } else {
            abnfTermId->name.lcl.pres = PRSNT_NODEF;
            abnfTermId->name.lcl.len = asnTermId->id.len;
            if (mgAsnDecGetMem(msgCp, (Ptr*)&(abnfTermId->name.lcl.val), (MsgLen)(abnfTermId->name.lcl.len+1)) != ROK) { RETVALUE(RFAILED); }
            (void)cmMemcpy((U8*)abnfTermId->name.lcl.val, (U8*) asnTermId->id.val, asnTermId->id.len);
         }
         
#endif
      }
   } else {
      ret = RFAILED;
   }

   /* mg004.105: Termination ID wildcard field filling */
   if (asnTermId->wildcard.num.pres && asnTermId->wildcard.num.val > 0) 
   { 
      abnfTermId->type.val = MGT_TERMID_CHOOSE;
      if ((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(abnfTermId->wildcard.wildcard), &(abnfTermId->wildcard.num), (Ptr*)asnTermId->wildcard.wildcard, (MsgLen)(asnTermId->wildcard.num.val))) != ROK) {
         RETVALUE(ret);
      }
   }

   return(ret);
}
#endif


/*
*
*       Fun:   mgaFuncProfileNameEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncProfileNameEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncProfileNameEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoName* evPtr;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncProfileNameEnc);
   evPtr = (MgMgcoName*)(msgCp->evntStr);
   switch (evPtr->type.val) {
   case MGT_GEN_TYPE_UNKNOWN:
      break;
   case MGT_GEN_TYPE_KNOWN:
      break;
   case MGT_GEN_TYPE_ALL:
      break;
   default:
      break;
   }
   msgCp->evntStr = (TknU8*)&(evPtr->u.str);
   ret = mgAsnEncOctetStr(msgCp);
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncProfileNameDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncProfileNameDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncProfileNameDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoName* evPtr;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncProfileNameDec);
   evPtr = (MgMgcoName*)(msgCp->evntStr);
   msgCp->evntStr = (TknU8*)&(evPtr->u.str);
   if((ret = mgAsnDecOctetStr(msgCp)) != ROK){RETVALUE(ret);}
   MGAFUNCSKIP(msgCp);

   evPtr->type.pres = evPtr->u.str.pres;
   if (evPtr->type.pres) {
      evPtr->type.val = MGT_GEN_TYPE_UNKNOWN;
   }
   switch (evPtr->type.val) {
   case MGT_GEN_TYPE_UNKNOWN:
      break;
   case MGT_GEN_TYPE_KNOWN:
      break;
   case MGT_GEN_TYPE_ALL:
      break;
   default:
      break;
   }

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncCommandReplyEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncCommandReplyEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncCommandReplyEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoCmdReply* evPtr;
   U8 savePres;

   /* We need to skip pres and wild */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncCommandReplyEnc);
   evPtr = (MgMgcoCmdReply*)(msgCp->evntStr);
   savePres = evPtr->type.pres;
   evPtr->type.pres = evPtr->pres.pres;

   msgCp->evntStr = (TknU8*)&(evPtr->type);
   ret = mgAsnEncChoice(msgCp);
   evPtr->type.pres = savePres;

   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncCommandReplyDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncCommandReplyDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncCommandReplyDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoCmdReply* evPtr;


   /* We need to skip pres and wild */
   TRC2(mgaFuncCommandReplyDec);
   evPtr = (MgMgcoCmdReply*)(msgCp->evntStr);
   msgCp->evntStr = (TknU8*)&(evPtr->type);
   if((ret = mgAsnDecChoice(msgCp)) != ROK) { RETVALUE(ret); }
   evPtr->pres.pres = evPtr->type.pres;
   msgCp->evntStr = (TknU8*)((long)msgCp->evntStr - sizeof(TknPres) - sizeof(TknPres));

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncSignalsDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncSignalsDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncSignalsDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoSignalsDesc* evPtr;
   U8 savePres;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncSignalsDescriptorEnc);
   evPtr= (MgMgcoSignalsDesc*) (msgCp->evntStr);
   if (evPtr->num.val == 0) {
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* prep */
   savePres = evPtr->num.pres;
   evPtr->num.pres = PRSNT_NODEF;
   msgCp->evntStr = (TknU8*)&(evPtr->num);

   /* encode */
   ret = mgAsnEncUnconsSetSeqOf(msgCp);
   evPtr->num.pres = savePres;
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncSignalsDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncSignalsDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncSignalsDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret, i;
   MgMgcoSignalsDesc* evPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncSignalsDescriptorDec);
   evPtr= (MgMgcoSignalsDesc*)msgCp->evntStr;
   if (msgCp->elmntLen == 0) {
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }
   msgCp->evntStr=(TknU8*)((long)msgCp->evntStr + sizeof(TknPres));
   ret= mgAsnDecUnconsSetSeqOf(msgCp);
   evPtr->pres.pres = evPtr->num.pres;
   /* mg007.105: Changed the mapping of signal parameter from
    * mgaFuncSignalRequestDec */
   /* swap around the enums as above encoded */
   if(evPtr->num.pres)
   {
      for(i=0;i<evPtr->num.val;i++)
      {
         if(evPtr->parms[i]->type.val == 1)
            evPtr->parms[i]->type.val = MGT_SIGSPAR_REQ;
         else
            if(evPtr->parms[i]->type.val == 2)
               evPtr->parms[i]->type.val = MGT_SIGSPAR_LST;
      }
   }
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncContextIDEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncContextIDEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncContextIDEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoContextId* evPtr;
   U32 saveVal;
   U8 savePres;

   /*
    * -- Context   NULL Value: 0
    * -- Context CHOOSE Value: 4294967294 (0xFFFFFFFE)
    * -- Context    ALL Value: 4294967295 (0xFFFFFFFF)
    */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncContextIDEnc);
   evPtr = (MgMgcoContextId*)(msgCp->evntStr);
   saveVal = evPtr->val.val;
   savePres = evPtr->val.pres;
   evPtr->val.pres = PRSNT_NODEF; 
   switch (evPtr->type.val) {
   case MGT_CXTID_NULL:
      evPtr->val.val = 0;
      break;
   case MGT_CXTID_ALL:
      evPtr->val.val = (0xFFFFFFFF);
      break;
   case MGT_CXTID_CHOOSE:
      evPtr->val.val = (0xFFFFFFFE);
      break;
   case MGT_CXTID_OTHER:
   default:
      break;
   }
   /* Skip TknU8 which is type */
   msgCp->evntStr = (TknU8*)((long)msgCp->evntStr + sizeof(TknU8));
   ret = mgAsnEncInteger(msgCp);
   evPtr->val.pres = savePres;
   evPtr->val.val = saveVal;
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncContextIDDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncContextIDDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncContextIDDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoContextId* evPtr;


   /*
    * -- Context   NULL Value: 0
    * -- Context CHOOSE Value: 4294967294 (0xFFFFFFFE)
    * -- Context    ALL Value: 4294967295 (0xFFFFFFFF)
    */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncContextIDDec);
   evPtr = (MgMgcoContextId*)(msgCp->evntStr);
   /* Skip TknU8 which is type */
   msgCp->evntStr = (TknU8*)((long)msgCp->evntStr + sizeof(TknU8));
   if((ret = mgAsnDecInteger(msgCp)) != ROK) { RETVALUE(ret); }
   switch (evPtr->val.val) {
   case 0:
      evPtr->type.val = MGT_CXTID_NULL;
      break;
   case (0xFFFFFFFF):
      evPtr->type.val = MGT_CXTID_ALL;
      break;
   case (0xFFFFFFFE):
      evPtr->type.val = MGT_CXTID_CHOOSE;
      break;
   default:
      evPtr->type.val = MGT_CXTID_OTHER;
      break;
   }

   /* mg004.105: fix for the context id */
   evPtr->type.pres = PRSNT_NODEF;
   
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncVersionDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncVersionDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncVersionDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoVersion* evPtr;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncVersionDec);

   /* decode version */
   evPtr = (MgMgcoVersion*)(msgCp->evntStr);
   if((ret = mgAsnDecInteger(msgCp)) != ROK) { RETVALUE(ret); }

   /* set version */
   switch (evPtr->val) {
   case 1:
      msgCp->proType = MEGACO_V1;
      break;
   case 2:
      msgCp->proType = MEGACO_V2;
      break;
   default:
      break;
   }
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncRequestIDEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncRequestIDEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncRequestIDEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoRequestId* evPtr;
   U32 saveVal;
   U8 savePres;

   /* If ALL then value is 0xffffffff */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncRequestIDEnc);
   evPtr = (MgMgcoRequestId*)(msgCp->evntStr);
   saveVal = evPtr->id.val;
   savePres = evPtr->id.pres;
   evPtr->id.pres = evPtr->type.pres;  /* abnf looks at type.pres */
   if(evPtr->type.val == MGT_REQID_ALL) {
      evPtr->id.val = (0xFFFFFFFF);
   } /* else type is MGT_REQID_OTHER and id is set already */

   /* Skip TknU8 which is type */
   msgCp->evntStr = (TknU8*)((long)msgCp->evntStr + sizeof(TknU8));
   ret = mgAsnEncInteger(msgCp);
   evPtr->id.pres = savePres;
   evPtr->id.val = saveVal;
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncRequestIDDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncRequestIDDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncRequestIDDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoRequestId* evPtr;

/* mg003.105: Fix for the Request ID */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncRequestIDDec);
   evPtr = (MgMgcoRequestId*)(msgCp->evntStr);
   /* Skip TknU8 which is type */
   msgCp->evntStr = (TknU8*)((long)msgCp->evntStr + sizeof(TknU8));
   if((ret = mgAsnDecInteger(msgCp)) != ROK ){RETVALUE(ret);}
   if (evPtr->id.val == (0xFFFFFFFF) ) {
      evPtr->type.val = MGT_REQID_ALL;
   }
   else {
      evPtr->type.val = MGT_REQID_OTHER;
   }
   /* mg007.105: request id bug fix */
   evPtr->type.pres = PRSNT_NODEF;
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncServiceChangeMethodEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncServiceChangeMethodEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncServiceChangeMethodEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoSvcChgMethod* evPtr;
   TknU8 eval;

   /* map it */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncServiceChangeMethodEnc);
   evPtr = (MgMgcoSvcChgMethod*) (msgCp->evntStr);
   eval.pres = PRSNT_NODEF;
   switch (evPtr->type.val) {
   case MGT_SVCCHGMETH_FAILOVER:
      eval.val = 0; break;
   case MGT_SVCCHGMETH_FORCED:
      eval.val = 1; break;
   case MGT_SVCCHGMETH_GRACEFUL:
      eval.val = 2; break;
   case MGT_SVCCHGMETH_RESTART:
      eval.val = 3; break;
   case MGT_SVCCHGMETH_DISCON:
      eval.val = 4; break;
   case MGT_SVCCHGMETH_HANDOFF:
      eval.val = 5; break;
   case MGT_EXTNPARM:
      eval.val = 6; break;
   default:
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }

   /* encode */
   msgCp->evntStr = (TknU8*)&eval;
   ret = mgAsnEncOctetEnum(msgCp);

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncServiceChangeMethodDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncServiceChangeMethodDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncServiceChangeMethodDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoSvcChgMethod* evPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncServiceChangeMethodDec);
   evPtr = (MgMgcoSvcChgMethod*) msgCp->evntStr;
   msgCp->evntStr = (TknU8*) ((long)msgCp->evntStr+sizeof(TknPres));  
   if((ret = mgAsnDecOctetEnum(msgCp)) != ROK) {RETVALUE(ret);}
   evPtr->pres.pres = evPtr->type.pres;
   switch (evPtr->type.val) {
   case 0:
      evPtr->type.val = MGT_SVCCHGMETH_FAILOVER; break;
   case 1:
      evPtr->type.val = MGT_SVCCHGMETH_FORCED; break;
   case 2:
      evPtr->type.val = MGT_SVCCHGMETH_GRACEFUL; break;
   case 3:
      evPtr->type.val = MGT_SVCCHGMETH_RESTART; break;
   case 4:
      evPtr->type.val = MGT_SVCCHGMETH_DISCON; break;
   case 5:
      evPtr->type.val = MGT_SVCCHGMETH_HANDOFF; break;
   case 6:
      evPtr->type.val = MGT_EXTNPARM; break;
   default:
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
      RETVALUE(RFAILED);
   }
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}
 

/*
*
*       Fun:   mgaFuncU32Str4Enc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncU32Str4Enc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncU32Str4Enc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret = ROK;
   TknStr4 val;
   TknU32 *tknU32Ptr;
   S32 j;

   /* Copy data */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncU32Str4Enc);
   tknU32Ptr = (TknU32*)(msgCp->evntStr);
   (void)cmMemset((U8*)&val, 0, sizeof(val));
   val.len = 4;
   val.pres = tknU32Ptr->pres;
   for(j = 3; j >= 0; j-- ) {
      val.val[j] = tknU32Ptr->val & 0xFF;
      tknU32Ptr->val = tknU32Ptr->val >> 8;
   }

   /* Save, replace, encode */
   msgCp->evntStr = (TknU8*)&val;
   ret = mgAsnEncOctetStr(msgCp);
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncU32Str4Dec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncU32Str4Dec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncU32Str4Dec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret = ROK;
   TknStr4 val;
   TknU32 *tknU32Ptr;
   S32 j;

   /* Save and replace */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncU32Str4Dec);
   
   tknU32Ptr = (TknU32*)msgCp->evntStr;
   /* decode, restore, copy */
   (void)cmMemset((U8*)&val, 0, sizeof(val));
   msgCp->evntStr = (TknU8*)&val;
   if((ret = mgAsnDecOctetStr(msgCp)) != ROK) { RETVALUE(ret); }

   if( val.len > 0 ) {
      tknU32Ptr->pres = val.pres;
      tknU32Ptr->val = 0;
      tknU32Ptr->val = tknU32Ptr->val | val.val[0];
      for(j = 1; j < val.len; j++) {
         tknU32Ptr->val = tknU32Ptr->val << 8;
         tknU32Ptr->val = tknU32Ptr->val | val.val[j];
      }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncTransactionsSpecialEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncTransactionsSpecialEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncTransactionsSpecialEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16           ret;
   U16           saveNum;
   MgMgcoTxnLst  *evPtr;


   /* do only one transaction */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncTransactionsSpecialEnc);
   evPtr = (MgMgcoTxnLst*)(msgCp->evntStr);
   saveNum = evPtr->num.val;
   evPtr->num.val = 1;
   ret = mgAsnEncSetSeqOf(msgCp);
   evPtr->num.val = saveNum;
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncTransactionEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncTransactionEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncTransactionEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16           ret;
   U8            saveType;
   MgMgcoTxn     *evPtr;


   /* Different order */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncTransactionEnc);
   evPtr = (MgMgcoTxn*)(msgCp->evntStr);
   saveType = evPtr->type.val;
   if (saveType == 0) {
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }
   if (saveType == 2) evPtr->type.val = 3;
   if (saveType == 3) evPtr->type.val = 2;
   msgCp->evntStr = (TknU8*)&(evPtr->type);
   ret = mgAsnEncChoice(msgCp);
   evPtr->type.val = saveType;

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncTransactionDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncTransactionDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncTransactionDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoTxn     *evPtr;


   /* Different order */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncTransactionDec);
   evPtr = (MgMgcoTxn*)(msgCp->evntStr);
   msgCp->evntStr = (TknU8*)&(evPtr->type);
/* mg003.105: Changes for 3GPP Termination Id Encoding */
/*
   if (msgCp->elmntLen == 0) {
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }
*/
   if((ret = mgAsnDecChoice(msgCp)) != ROK) {RETVALUE(ret);}
   switch (evPtr->type.val) {
   case 2: evPtr->type.val = 3; break;
   case 3: evPtr->type.val = 2; break;
   }

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncTransaction0Dec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncTransaction0Dec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncTransaction0Dec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoTxn     ***evPtr;
   MgAsnElmntDef   *elmntDef;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncTransaction0Dec);
   evPtr = (MgMgcoTxn***)(msgCp->evntStr);
   elmntDef = *(msgCp->elmntDef);
   if (msgCp->elmntLen == 0) {
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* allocate some space */
   if (mgAsnDecGetMem(msgCp, (Ptr*)evPtr, (MsgLen)(sizeof(TknU8*)*(unsigned long)elmntDef->repCntr)) != ROK) {
      MGAFUNCSKIP(msgCp);
      RETVALUE(RFAILED);
   }
   if (mgAsnDecGetMem(msgCp, (Ptr*)*evPtr, (elmntDef->evSize)) != ROK) {
      MGAFUNCSKIP(msgCp);
      RETVALUE(RFAILED);
   }

   if((ret = mgaFuncTransactionDec(msgCp)) != ROK) {RETVALUE(ret);}
   (**evPtr)->type.pres = PRSNT_NODEF;
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMsgNameEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMsgNameEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMsgNameEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   /* See note in mgt.x.  ASN value is 2 char string
    * based on type being MGT_GEN_TYPE_UNKNOWN, 
    * MGT_GEN_TYPE_KNOWN, or MGT_GEN_TYPE_ALL
    * Cannot encode/decode when TYPE_UNKNOWN
    * MgMgcoName -> MgMgcaName
    */
   S16 ret;
   TknStr4 val;                /* ie. MgMgcaName */
   MgMgcoName* evPtr;

   /* Create data based on evntStr*/
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncMsgNameEnc);
   (void)cmMemset((U8*)&val, 0, sizeof(val));
   evPtr = (MgMgcoName*)((long)msgCp->evntStr);
   val.pres = evPtr->type.pres;		
   switch(evPtr->type.val) {
      case MGT_GEN_TYPE_UNKNOWN:
#ifdef MG_ASN_TEST
         val.val[0] = 0;
         val.val[1] = 0;
         val.len = 2;
#else
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
#endif
         break;
      case MGT_GEN_TYPE_KNOWN:
         val.val[0] = 0;
         val.val[1] = evPtr->u.val.val;
         val.len = 2;
         break;
      case MGT_GEN_TYPE_ALL:
         val.len = 2;
         val.val[0] = 0xFF;
         val.val[1] = 0xFF;
         break;
    }

   /* Save, replace, encode */
   msgCp->evntStr = (TknU8*)&val;
   ret = mgAsnEncOctetStr(msgCp);
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMsgNameDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMsgNameDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMsgNameDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknStr4 val;
   MgMgcoName* evPtr;

   /* Save and replace */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncMsgNameDec);
   (void)cmMemset((U8*)&val, 0, sizeof(val));
   msgCp->evntStr = (TknU8*)&val;

   /* decode, restore, copy */
   if((ret = mgAsnDecOctetStr(msgCp)) != ROK) {RETVALUE(ROK);}
   evPtr = (MgMgcoName*)msgCp->evntStr;
   evPtr->type.pres = val.pres;
   
   if( val.len == 2 ) {
      if (val.val[0] == '0') {
          evPtr->type.val = MGT_GEN_TYPE_KNOWN;
          evPtr->u.val.val = val.val[1];
      } else {
         evPtr->type.val = MGT_GEN_TYPE_ALL;
      }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncNotifyCompletionEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncNotifyCompletionEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncNotifyCompletionEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   /* 
    * ASN.1 encodes as a Bit Str, in TknStr12 whilst
    * abnf has it as the struct mgMgcoNtfyCmpl.
    * Map as: 
    *       onTimeOut(0), onInterruptByEvent(1),
    *       onInterruptByNewSignalDescr(2), otherReason(3)
    * Assuming that the bit string is represented 
    * by turning on the position with '\001'
   */
   S16 ret;
   MgMgcaNotifyCompletion val;
   MgMgcoNtfyCmpl *evPtr;
   TknU8* curReason;
   short j;

   /* Set up data */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncNotifyCompletionEnc);
   (void)cmMemset((U8*)&val, 0, sizeof(val));
   evPtr = (MgMgcoNtfyCmpl*)((long)msgCp->evntStr);
   val.pres = evPtr->num.pres; 
   j = 0;
   curReason = *(evPtr->reasons);
   while (j < evPtr->num.val) {
      switch(curReason->val) {
      case MGT_NTFYRES_TIMEOUT:
         val.val[0] |= 1<<7; break;
      case MGT_NTFYRES_IBYEVT:
         val.val[0] |= 1<<6; break;
      case MGT_NTFYRES_IBYNEWSIG: 
         val.val[0] |= 1<<5; break;
      case MGT_NTFYRES_OTHER:
         val.val[0] |= 1<<4; break;
      default:
         MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
         RETVALUE(RFAILED);
      }
      ++curReason;
      ++j;
   }
   val.len = 1;

   /* replace and encode */
   msgCp->evntStr = (TknU8*)&val;
   ret = mgAsnEncBitStr(msgCp);
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncNotifyCompletionDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncNotifyCompletionDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncNotifyCompletionDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgAsnElmntDef* elmntDef;
   MgMgcoNtfyCmpl *evPtr;
   MgMgcaNotifyCompletion val;
   TknU8** ptrReasons;
   /* mg002.105: Removed compilation warning */
   U16 j;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncNotifyCompletionDec);
   /* decode, restore, copy */
   evPtr = (MgMgcoNtfyCmpl*)msgCp->evntStr;
   (void)cmMemset((U8*)&val, 0, sizeof(val));
   msgCp->evntStr = (TknU8*)&val;
   elmntDef = *(msgCp->elmntDef);
   if ((ret = mgAsnDecBitStr(msgCp)) == ROK) {
      /* check length */
      if (val.len != 1) {
         MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
         RETVALUE(RFAILED);
      }

      /* set up num */
      evPtr->num.pres = val.pres;   
      evPtr->num.val = 0;
      for (j=0; j<(elmntDef->maxLen); ++j) {
         if (val.val[0] & ((1<<4)<<j)) {
            ++(evPtr->num.val);
         }
      }
      /* set up reasons */
      if (mgAsnDecGetMem(msgCp, (Ptr*)&(ptrReasons), (MsgLen)(sizeof(TknU8*)*(evPtr->num.val))) != ROK) { RETVALUE(RFAILED); }
      evPtr->reasons = ptrReasons;
      for (j=0; j<elmntDef->maxLen; ++j) {
         if( val.val[0] & (1<<(7-j))) {
            if (mgAsnDecGetMem(msgCp, (Ptr*)ptrReasons, (sizeof(TknU8))) != ROK) { RETVALUE(RFAILED); }
            /* set up a new reason */
            (*ptrReasons)->pres = PRSNT_NODEF;
            /* mg002.105: Removed compilation warning */
            (*ptrReasons)->val = (U8)j;    /* luckily, #defines line up */
            ++ptrReasons;
         }
      }
   }
 
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncServiceChangeProfileEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncServiceChangeProfileEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncServiceChangeProfileEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   /* MgMgcaServiceChangeProfile val; */
   MgMgcaServiceChangeProfile val;  
   MgMgcoSvcChgProf* evPtr;
   U16 len = 0;
   S8 tmpbuf[128];

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncServiceChangeProfileEnc);

   /* Format is name/ver */
   (void)cmMemset((U8*)&val, 0, sizeof(val));
   evPtr = (MgMgcoSvcChgProf*)((long)msgCp->evntStr);
   if(evPtr->name.type.val != MGT_GEN_TYPE_UNKNOWN) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }

   /* this is the one that has a string value */
   val.profileName.pres = evPtr->name.type.pres;
   len =  evPtr->name.u.str.len <= 64 ? evPtr->name.u.str.len : 64;
   cmMemcpy((U8*) val.profileName.val, (U8*) evPtr->name.u.str.val, len );
   val.profileName.val[len++] = '/';

   /* now put in the version */
   sprintf(tmpbuf, "%u", evPtr->ver.val);
   cmMemcpy( (U8*) &(val.profileName.val[len]), (U8*)tmpbuf, 2);
   if(cmStrlen((U8*)tmpbuf) < 2) {
      len += cmStrlen((U8*)tmpbuf);
   } else {
      len+=2;
   }
   /* mg002.105: Removed compilation warning */
   val.profileName.len = (U8)len;

   /* Replace, encode, skip */
   msgCp->evntStr = (TknU8*)&val;
   ret = mgAsnEncSetSeq(msgCp);
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncServiceChangeProfileDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncServiceChangeProfileDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncServiceChangeProfileDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcaServiceChangeProfile val;
   MgMgcoSvcChgProf* evPtr;
   S8 tmpBuf[257];
   S8* delim;
   U16 len;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncServiceChangeProfileDec);
   evPtr = (MgMgcoSvcChgProf*)msgCp->evntStr;

   /* decode */
   (void)cmMemset((U8*)&val, 0, sizeof(val));
   msgCp->evntStr = (TknU8*)&val;
   if ((ret = mgAsnDecSeq(msgCp)) != ROK) { RETVALUE(ret); }

   /* Set up the data */
   evPtr->pres = val.pres;
   /* String holds name/ver */
   evPtr->name.type.pres = val.profileName.pres;
   evPtr->name.type.val = MGT_GEN_TYPE_UNKNOWN;
   cmMemcpy((U8*)tmpBuf, (U8*) val.profileName.val, val.profileName.len);
   tmpBuf[val.profileName.len] = '\0';
   delim = strchr(tmpBuf, '/');
   if(delim == NULL) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
      RETVALUE(RFAILED);
   }

   /* parse */
   /* mg005.105: Fix for Service change profile */
   len = delim - tmpBuf;
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->name.u.str.val), (MsgLen)(len+1)) != ROK) { RETVALUE(RFAILED); }
   evPtr->name.u.str.pres = PRSNT_NODEF;
   cmMemcpy((U8*)(evPtr->name.u.str.val), (U8*)tmpBuf, len);
   evPtr->name.u.str.len = len;   
   if(cmStrlen((U8*)tmpBuf) > (len + 1) ) {
      /* we know there's version */
      evPtr->ver.pres = PRSNT_NODEF;
      CM_ABNF_A2I(delim + 1, cmStrlen((U8*) (delim + 1)), evPtr->ver.val);
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncAmmDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncAmmDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncAmmDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   U8 saveVal;
   MgMgcoAudRetParm* evPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncAmmDescriptorEnc);
   evPtr = (MgMgcoAudRetParm*)(msgCp->evntStr);
   saveVal = evPtr->type.val;

   /* map the union */
   switch (evPtr->type.val) {
   case MGT_MEDIADESC:
      evPtr->type.val = 1;
      /* mg008.105: evPtr->u.media.num.pres is set to present, because all
       * fields in media descriptor are optional */
      evPtr->u.media.num.pres = PRSNT_NODEF;
      break;
   case MGT_MODEMDESC:
      evPtr->type.val = 2; break;
   case MGT_MUXDESC:
      evPtr->type.val = 3; break;
   case MGT_REQEVTDESC:
      evPtr->type.val = 4; break;
   case MGT_EVBUFDESC:
      evPtr->type.val = 5; break;
   case MGT_SIGNALSDESC:
      evPtr->type.val = 6; break;
   case MGT_DIGMAPDESC:
      evPtr->type.val = 7; break;
   case MGT_AUDITDESC:
      evPtr->type.val = 8;
      /* mg008.105: evPtr->u.item is set to present, because all fields in audit
       * descriptor are optional */
#ifdef MGT_MGCO_V2
      evPtr->u.item.auditItem.pres = PRSNT_NODEF;
#else
      evPtr->u.item.pres = PRSNT_NODEF;
#endif /* MGT_MGCO_V2  */
         break;
   case MGT_ERRDESC:
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   case MGT_OBSEVTDESC:
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   case MGT_STATSDESC:
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   case MGT_PKGSDESC:
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   default:
      MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
      RETVALUE(RFAILED);
   }

   /* encode */
   ret = mgAsnEncChoice(msgCp);
   evPtr->type.val = saveVal;
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncAmmDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncAmmDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncAmmDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoAudRetParm* evPtr;

   /* Do the decode */
   TRC2(mgaFuncAmmDescriptorDec);
   evPtr = (MgMgcoAudRetParm*)(msgCp->evntStr);
   if((ret = mgAsnDecChoice(msgCp)) != ROK) { RETVALUE(ret); }

   /* swap around the enums as above encoded */
   switch (evPtr->type.val) {
   case 1:
      evPtr->type.val = MGT_MEDIADESC; break;
   case 2:
      evPtr->type.val = MGT_MODEMDESC; break;
   case 3:
      evPtr->type.val = MGT_MUXDESC; break;
   case 4:
      evPtr->type.val = MGT_REQEVTDESC; break;
   case 5:
      evPtr->type.val = MGT_EVBUFDESC; break;
   case 6:
      evPtr->type.val = MGT_SIGNALSDESC; break;
   case 7:
      evPtr->type.val = MGT_DIGMAPDESC; break;
   case 8:
      evPtr->type.val = MGT_AUDITDESC; break;
   default:
      MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
      RETVALUE(RFAILED);
   }

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncAuditReplyEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncAuditReplyEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncAuditReplyEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   U8 saveVal;
   MgMgcoAuditReply* evPtr;

   /* 
    * Hack: Change the val to index positionally
    * into the union for ease of encoding
   */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncAuditReplyEnc);
   evPtr = (MgMgcoAuditReply*)(msgCp->evntStr);
   saveVal = evPtr->type.val;

   if(evPtr->type.val == MGT_ERRDESC) {
      evPtr->type.val = 2;
   } else if(evPtr->type.val == MGT_CXTAUDIT) {
      evPtr->type.val = 1;
   } else if(evPtr->type.val == MGT_TERMAUDIT) {
      evPtr->type.val = 3;
      /* mg007.105: if TerminationAudit is empty send empty sequence */
      if(evPtr->u.other.audit.num.pres == NOTPRSNT)
         evPtr->u.other.audit.num.pres = PRSNT_NODEF;
   }

   ret = mgAsnEncChoice(msgCp);
   evPtr->type.val = saveVal;
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncAuditReplyDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncAuditReplyDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncAuditReplyDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoAuditReply* evPtr;

   TRC2(mgaFuncAuditReplyDec);
   if((ret = mgAsnDecChoice(msgCp)) != ROK) { RETVALUE(ret);}
   evPtr = (MgMgcoAuditReply*)(msgCp->evntStr);
   /* swap around the enums as above encoded */
   if(evPtr->type.val == 2) {
      evPtr->type.val = MGT_ERRDESC;
   } else if(evPtr->type.val == 1) {
      evPtr->type.val = MGT_CXTAUDIT;
   } else if(evPtr->type.val == 3) {
      evPtr->type.val = MGT_TERMAUDIT;
   }

   RETVALUE(ret);
}

/* mg008.105: New functions are added for priority encoding/decoding */

/*
*
*       Fun:   mgaFuncPriorityEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncPriorityEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncPriorityEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   U32           val;            /* pointer to the string */
   S16           ret;            /* return value */

   TRC2(mgaFuncPriorityEnc)
   val = ((TknU8*)(msgCp->evntStr))->val;
   if(val > 15)
   {
      ret = RFAILED;
   }
   else
   {
      ret = mgAsnEncInteger(msgCp);
   }
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncPriorityDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncPriorityDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncPriorityDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   U32           val;            /* pointer to the string */
   S16           ret;            /* return value */

   TRC2(mgaFuncPriorityDec)

   ret = mgAsnDecInteger(msgCp);
   if(ret != ROK)
   {
      ret = RFAILED;
   }
   else
   {
      val = ((TknU8*)(msgCp->evntStr))->val;
      if(val > 15)
      {
         ret = RFAILED;
      }
   }

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncObjectEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncObjectEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncObjectEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   /* Data in an OSXL needs to go over to a MgMgcaObject,
    * aka, TknOid
    */
   S16 ret;
   TknOid val;
   TknStrOSXL* evPtr;
   U16 i;

   /* Copy data */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncObjectEnc);
   (void)cmMemset((U8*)&val, 0, sizeof(val));
   evPtr = (TknStrOSXL*)((long)msgCp->evntStr);
   val.pres = evPtr->pres;
   val.len = evPtr->len <= sizeof(val.val) 
                 ? evPtr->len : sizeof(val.val);
   /* mg008.105: val is of TknOid and val.val is of type U32, but evPtr->val is
    * of type U8. So here cmMemcpy will not work */
/*   cmMemcpy((U8*) &(val.val[0]), (U8*)(evPtr->val), val.len);*/
   i = 0;
   do
   {
      val.val[i] = evPtr->val[i];
   }while(evPtr->val[i++]);

   /* Save, replace, encode */
   msgCp->evntStr = (TknU8*)&val;
   ret = mgAsnEncOid(msgCp);

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncObjectDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncObjectDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncObjectDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknOid val;
   TknStrOSXL* evPtr;
   U16 i;

   /* Save and replace */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncObjectDec);
   evPtr = (TknStrOSXL*)msgCp->evntStr;
   (void)cmMemset((U8*)&val, 0, sizeof(val));
   msgCp->evntStr = (TknU8*)&val;

   /* decode, restore, set up */
   if((ret = mgAsnDecOid(msgCp)) != ROK ) { RETVALUE(ret); }

   evPtr->pres = val.pres;
   evPtr->len = val.len;
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->val), (MsgLen)(val.len+1)) != ROK) { RETVALUE(RFAILED); }
   /* mg008.105: val is of TknOid and val.val is of type U32, but evPtr->val is
    * of type U8. So here cmMemcpy will not work */
/*   cmMemcpy((U8*)evPtr->val, (U8*) val.val, val.len);*/
   i = 0;
   do
   {
      evPtr->val[i] = val.val[i];
   }while(val.val[i++]);

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}

#if defined (GCP_VER_1_3) && defined (GCP_MGCO_PARSE_DIG_MAP)
/* Nada. Use default functions */
#else

/*
*
*       Fun:   mgaFuncDigitMapBodyEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncDigitMapBodyEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncDigitMapBodyEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknStrXL val;
   MgMgcoDigMap* evPtr;
   CmAbnfErr     abnfErr;
   CmAbnfDecOff  bufOff;
   Mem           memReg;
   Buffer        *mBuf;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncDigitMapBodyEnc);
   (void)cmMemset((U8*)&val, 0, sizeof(val));
   (void)cmMemset((U8*)&abnfErr, 0, sizeof(abnfErr));
   (void)cmMemset((U8*)&bufOff, 0, sizeof(bufOff));
   (void)cmMemset((U8*)&memReg, 0, sizeof(memReg));
   memReg.pool = msgCp->pool;
   memReg.region = msgCp->region;
   evPtr = (MgMgcoDigMap*)msgCp->evntStr;

   /* get message buffer */
   if ((ret = SGetMsg(msgCp->region, msgCp->pool, &mBuf)) != ROK) { RETVALUE(ret); }

   /* encode to string */
   if ((ret = cmAbnfEncPduMsg(CM_ABNF_PROT_MEGACO_H248, (U8*)evPtr, mBuf, &mgMgcoDigMapDef, &memReg, &abnfErr)) != ROK) {
      S8 errBuf[1024];
      mwrapErrPrint(&abnfErr, errBuf);
      SPutMsg(mBuf);
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
      RETVALUE(RFAILED);
   }

   /* get string length */
   if ((ret = SFndLenMsg(mBuf, (MsgLen*)&(val.len))) != ROK) {
      SPutMsg(mBuf);
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(RFAILED);
   }

   /* get memory for val */
   if ((ret = SGetSBuf(msgCp->region, msgCp->pool, (Data**)&(val.val), (MsgLen)(val.len + 1))) != ROK) {
      SPutMsg(mBuf);
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(RFAILED);
   }
   cmMemset((U8 *)val.val, 0, (val.len+1));

   /* copy string */
   if ((ret = SRemPreMsgMult(val.val, (MsgLen)val.len, mBuf)) != ROK) {
      SPutMsg(mBuf);
      (Void)SPutSBuf(msgCp->region, msgCp->pool, (Data*)(val.val), (MsgLen)(val.len + 1));
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(RFAILED);
   }
   SPutMsg(mBuf);
   val.pres = evPtr->num.pres;

   /* encode string */
   msgCp->evntStr = (TknU8*)&val;
   if ((ret = mgAsnEncOctetStr(msgCp)) != ROK) {
      (Void)SPutSBuf(msgCp->region, msgCp->pool, (Data*)(val.val), (MsgLen)(val.len + 1));
      RETVALUE(ret);
   }

   /* return the data */
   if ((ret = SPutSBuf(msgCp->region, msgCp->pool, (Data*)(val.val), (MsgLen)(val.len + 1))) != ROK) { RETVALUE(ret); }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncDigitMapBodyDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncDigitMapBodyDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncDigitMapBodyDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknStrXL val;
   MgMgcoDigMap* evPtr;
   CmAbnfErr     abnfErr;
   CmAbnfDecOff  bufOff;
   MsgLen        numDecBytes;
   Buffer        *mBuf;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncDigitMapBodyDec);
   (void)cmMemset((U8*)&val, 0, sizeof(val));
   (void)cmMemset((U8*)&abnfErr, 0, sizeof(abnfErr));
   (void)cmMemset((U8*)&bufOff, 0, sizeof(bufOff));
   evPtr = (MgMgcoDigMap*)msgCp->evntStr;

   /* decode */
   msgCp->evntStr = (TknU8*)&val;
   if ((ret = mgAsnDecOctetStr(msgCp)) != ROK) { RETVALUE(ret); }

   /* create a message */
   if ((ret = SGetMsg(msgCp->region, msgCp->pool, &mBuf)) != ROK) {
      if ((ret = SPutSBuf(msgCp->region, msgCp->pool, (Data*)(val.val), (MsgLen)val.len)) != ROK) { RETVALUE(ret); }
      RETVALUE(ret);
   }

   /* add the string */
   if ((ret = SAddPstMsgMult(val.val, val.len, mBuf)) != ROK) {
      SPutMsg(mBuf);
      if ((ret = SPutSBuf(msgCp->region, msgCp->pool, (Data*)(val.val), (MsgLen)val.len)) != ROK) { RETVALUE(ret); }
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }

   /* decode abnf into an event */
   if ((ret = cmAbnfDecPduMsg(CM_ABNF_PROT_MEGACO_H248, msgCp->memCp, (U8*)evPtr, mBuf, &mgMgcoMIDDef, &numDecBytes, &bufOff, &abnfErr)) != ROK) {
      S8 errBuf[1024];
      mwrapErrPrint(&abnfErr, errBuf);
      SPutMsg(mBuf);
      if ((ret = SPutSBuf(msgCp->region, msgCp->pool, (Data*)(val.val), (MsgLen)val.len)) != ROK) { RETVALUE(ret); }
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }
   SPutMsg(mBuf);

   /* return that memory */
   if ((ret = SPutSBuf(msgCp->region, msgCp->pool, (Data*)(val.val), (MsgLen)val.len)) != ROK) { RETVALUE(ret); }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}
#endif


/*
*
*       Fun:   mgaFuncLocalControlDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncLocalControlDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncLocalControlDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoLclCtlDesc* evPtr;
   S16 j;
   MgMgcoLocalParm* parPtr;
   S16 foundStreamMode = 0;
   S16 foundReserveVal = 0;
   S16 foundReserveGroup = 0;
   S16 foundPropertyParms = 0;
   MgMgcoLocalParm* modePtr;
   MgMgcoLocalParm* resValPtr;
   MgMgcoLocalParm* resGrpPtr;
   MgMgcoPropParmLst newPtrList;
   MgMgcoPropParm** curNewPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncLocalControlDescriptorEnc);
   evPtr = (MgMgcoLclCtlDesc*)msgCp->evntStr;
   ++msgCp->elmntDef;

   (void)cmMemset((U8*)&newPtrList, 0, sizeof(MgMgcoPropParmLst));
   /* Some sanity and error checking */
   for(j=0; j<evPtr->num.val; ++j) {
      parPtr = evPtr->parms[j];
      if(parPtr->type.val == MGT_LCLCTL_MODE) {
         ++foundStreamMode;
         modePtr = parPtr;
      } else if(parPtr->type.val == MGT_LCLCTL_RESVAL) {
         ++foundReserveVal;
         resValPtr = parPtr;
      } else if(parPtr->type.val == MGT_LCLCTL_RESGRP) {
         ++foundReserveGroup;
         resGrpPtr = parPtr;
      } else if(parPtr->type.val == MGT_LCLCTL_PROPPARM) {
         ++foundPropertyParms;
      }
   }
   if( (foundStreamMode > 1) || (foundReserveVal > 1) ||
       (foundReserveGroup > 1) ) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }

   /* encode, in order, stream mode (opt), reserve value (opt)
    * reserve group (opt), and property parms 
    */
   if( foundStreamMode == 0 ) {
      mgAsnSkipElmnt(msgCp);
   } else {
      msgCp->evntStr = (TknU8*) &(modePtr->u.mode);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   if( foundReserveVal == 0 ) {
      mgAsnSkipElmnt(msgCp);
   } else {
      msgCp->evntStr = (TknU8*) &(resValPtr->u.resVal);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   if( foundReserveGroup == 0 ) {
      mgAsnSkipElmnt(msgCp);
   } else {
      msgCp->evntStr = (TknU8*) &(resGrpPtr->u.resGrp);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   /* Property Parms */
   /* mg007.105: In localcontroldescriptor streammode, reserveval, and reservegroup
    * are optional and property parms is mandatory 
   
      if( (!foundStreamMode) && (!foundReserveVal) && (!foundReserveGroup) ) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
      }
      */
      /* mg004.105: Modified for empty property parms */
   if (foundPropertyParms == 0 ) {
      newPtrList.num.val = foundPropertyParms;
      newPtrList.num.pres = PRSNT_NODEF;
      msgCp->evntStr = (TknU8*) &(newPtrList);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      /* Create a list of just property parms for the child
       * element to encode.
       */
      if (mgAsnEncGetMem(msgCp, (Ptr*)&(newPtrList.parms), (MsgLen)(foundPropertyParms * sizeof(MgMgcoPropParm*))) != ROK) { RETVALUE(RFAILED); }
      curNewPtr = newPtrList.parms;
      for(j=0; j<evPtr->num.val; ++j) {
         parPtr = evPtr->parms[j];
         if(parPtr->type.val == MGT_LCLCTL_PROPPARM) { 
            *(curNewPtr) = &(parPtr->u.propParm);
            ++curNewPtr;
         }
      }
      /* swap in new, and encode */
      newPtrList.num.val = foundPropertyParms;
      newPtrList.num.pres = PRSNT_NODEF;
      msgCp->evntStr = (TknU8*)&(newPtrList);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) {
         if (mgAsnEncPutMem(msgCp, (Ptr)newPtrList.parms, (MsgLen)(foundPropertyParms * sizeof(MgMgcoPropParm*))) != ROK) { RETVALUE(RFAILED); }
         RETVALUE(ret);
      }
      if (mgAsnEncPutMem(msgCp, (Ptr)newPtrList.parms, (MsgLen)(foundPropertyParms * sizeof(MgMgcoPropParm*))) != ROK) { RETVALUE(RFAILED); }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncLocalControlDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncLocalControlDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncLocalControlDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   S16 j;
   MgMgcoLclCtlDesc* evPtr;
   MgMgcoLocalParm* newPar;
   MgMgcoPropParmLst propParmLst;
   MgMgcoPropParm* curPropPar;
   MgAsnElmntDef* elmntDef;
   MsgLen       msgLen;        /* message length */

   TRC2(mgaFuncLocalControlDescriptorDec);
   elmntDef = *(msgCp->elmntDef);
   evPtr = (MgMgcoLclCtlDesc*)msgCp->evntStr;
   if (elmntDef->idNum == gcMsgStreamModeO.idNum) {
      /* streamMode */
      (void)cmMemset((U8*)evPtr, 0, sizeof(MgMgcoLclCtlDesc));
      if (mgAsnDecGetMem(msgCp, (Ptr*)&(newPar), (sizeof(MgMgcoLocalParm))) != ROK) { RETVALUE(RFAILED); }
      (void)cmMemset((U8*)newPar, 0, sizeof(MgMgcoLocalParm));
      msgCp->evntStr = (TknU8*) &(newPar->u.mode);
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      if(newPar->u.mode.pres == PRSNT_NODEF) {
         newPar->type.pres = PRSNT_NODEF;
         newPar->type.val = MGT_LCLCTL_MODE;
         if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->parms), &(evPtr->num), (Ptr*)&(newPar), 1)) != ROK) {
            RETVALUE(ret);
         }
      } else {
         if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newPar)) != ROK) { RETVALUE(ret); }
      }
   } else if (elmntDef->idNum == gcMsgReserveValueO.idNum) {
      /* reservedValue */
      if (mgAsnDecGetMem(msgCp, (Ptr*)&(newPar), (sizeof(MgMgcoLocalParm))) != ROK) { RETVALUE(RFAILED); }
      (void)cmMemset((U8*)newPar, 0, sizeof(MgMgcoLocalParm));
      msgCp->evntStr = (TknU8*) &(newPar->u.resVal);
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      if(newPar->u.resVal.pres) {
         newPar->type.pres = PRSNT_NODEF;
         newPar->type.val = MGT_LCLCTL_RESVAL;
         if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->parms), &(evPtr->num), (Ptr*)&(newPar), 1)) != ROK) {
            RETVALUE(ret);
         }
      } else {
         if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newPar)) != ROK) { RETVALUE(ret); }
      }
   } else if (elmntDef->idNum == gcMsgReserveGroupO.idNum) {
      /* reservedGroup */
      if (mgAsnDecGetMem(msgCp, (Ptr*)&(newPar), (sizeof(MgMgcoLocalParm))) != ROK) { RETVALUE(RFAILED); }
      (void)cmMemset((U8*)newPar, 0, sizeof(MgMgcoLocalParm));
      msgCp->evntStr = (TknU8*) &(newPar->u.resGrp);
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      if(newPar->u.resGrp.pres) {
         newPar->type.pres = PRSNT_NODEF;
         newPar->type.val = MGT_LCLCTL_RESGRP;
         if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->parms), &(evPtr->num), (Ptr*)&(newPar), 1)) != ROK) {
            RETVALUE(ret);
         }
      } else {
         if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newPar)) != ROK) { RETVALUE(ret); }
      }
   } else if (elmntDef->idNum == gcMsgPropertyParms3.idNum) {
      msgLen = mgAsnFindLen(msgCp);
      /* PropertyParms */
      (void)cmMemset((U8*)&propParmLst, 0, sizeof(MgMgcoPropParmLst));
      msgCp->evntStr = (TknU8*) &(propParmLst);
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      if(propParmLst.num.pres && propParmLst.num.val >0) {
         /* increase the list */
        evPtr->num.pres = PRSNT_NODEF;
        /* mg002.105: Removed compilation warning */
        if (mgAsnDecGetMoreMem(msgCp, (Ptr*)&(evPtr->parms), (MsgLen)((evPtr->num.val + propParmLst.num.val) * sizeof(MgMgcoLocalParm*)), (MsgLen)((propParmLst.num.val) * sizeof(MgMgcoLocalParm*))) != ROK) { RETVALUE(RFAILED); }

         /* copy the list */
        for(j=0; j<propParmLst.num.val; ++j) {
           if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->parms[evPtr->num.val+j]), sizeof(MgMgcoLocalParm)) != ROK) { RETVALUE(RFAILED); }
           newPar = evPtr->parms[evPtr->num.val+j];
           newPar->type.pres = PRSNT_NODEF;
           newPar->type.val = MGT_LCLCTL_PROPPARM;
           curPropPar = propParmLst.parms[j];
           (void)cmMemcpy((U8*)&(newPar->u.propParm), (U8*)curPropPar, sizeof(MgMgcoPropParm));
           if (mgAsnDecPutMem(msgCp, curPropPar) != ROK) { RETVALUE(RFAILED); }
        }
        if (mgAsnDecPutMem(msgCp, propParmLst.parms) != ROK) { RETVALUE(RFAILED); }
        evPtr->num.val += propParmLst.num.val;
      }
      /* mg007.105: empty property param means choose so we have to fill the
       * present field in property parms */
      else
      {
        if( (msgLen - mgAsnFindLen(msgCp)) > 0)
           evPtr->num.pres = PRSNT_NODEF;
      }
   } else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
   }
   msgCp->evntStr = (TknU8*)evPtr;

   RETVALUE(ROK);
}
                                                                                

/*
*
*       Fun:   mgaFuncTerminationStateDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncTerminationStateDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncTerminationStateDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoTermStateDesc *evPtr;
   MgMgcoTermStateParm *parmPtr;
   S16 j;
   S16 foundPP = 0;
   S16 foundEBC = 0;
   S16 foundSS = 0;
   MgMgcoEvtBufCtl* ebcPtr;
   MgMgcoSvcState* ssPtr;
   MgMgcoPropParmLst newPtrList;
   MgMgcoPropParm** curNewPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncTerminationStateDescriptorEnc);
   ++msgCp->elmntDef;
   /* Set up counts and error checks */
   evPtr = (MgMgcoTermStateDesc*) ((long)msgCp->evntStr);
   for (j=0; j<evPtr->numComp.val; ++j) {
      parmPtr = evPtr->trmStPar[j];
      if (parmPtr->type.val == MGT_TERMST_PROPLST) {
         ++foundPP;
      } else if (parmPtr->type.val == MGT_TERMST_EVTBUFCTL) {
         ++foundEBC;
         ebcPtr = &(parmPtr->u.evtBufCtl);
      } else if (parmPtr->type.val == MGT_TERMST_SVCST) {
         ++foundSS;
         ssPtr = &(parmPtr->u.svcState);
      }
   }
   /* mg007.105: allowing empty property parms in termination state descriptor */
   if( (foundEBC > 1) || (foundSS > 1)) /* || (foundPP == 0) ) */
   {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }
   
   /* encode, in order, propertyParms, buffer control (opt TknU8),
    * and service state (opt TknU8) from MgMgcoTermStateDesc
    */

   /* for PropertyParms, create a list of just property parms
    * and have the default child encode */
   /* mg007.105: if foundPP is empty don't allocate memory */
   if(foundPP != 0)
   {
      if (mgAsnEncGetMem(msgCp, (Ptr*)&(newPtrList.parms), (MsgLen)(foundPP * sizeof(MgMgcoPropParm*))) != ROK) { RETVALUE(RFAILED); }
      curNewPtr = newPtrList.parms;
      for (j=0; j<evPtr->numComp.val; ++j) {
         parmPtr = evPtr->trmStPar[j];
         if(parmPtr->type.val == MGT_TERMST_PROPLST) {
            *(curNewPtr) = &(parmPtr->u.parm);
            ++curNewPtr;
         }
      }
   }

   /* PropertyParms */
   newPtrList.num.val = foundPP;
   newPtrList.num.pres = PRSNT_NODEF;
   msgCp->evntStr = (TknU8*) &(newPtrList);
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) {
      /* mg002.105: Removed compilation warning */
      if (mgAsnEncPutMem(msgCp, (Ptr)newPtrList.parms, (MsgLen)(foundPP * sizeof(MgMgcoPropParm*))) != ROK) { RETVALUE(RFAILED); }
      RETVALUE(ret);
   }
   /* mg002.105: Removed compilation warning */
   if(newPtrList.num.val != 0)
   {
      if (mgAsnEncPutMem(msgCp, (Ptr)newPtrList.parms, (MsgLen)(foundPP * sizeof(MgMgcoPropParm*))) != ROK) { RETVALUE(RFAILED); }
   }

   /* EventBufferControl */
   if(foundEBC == 0) {
      mgAsnSkipElmnt(msgCp);
   } else {
      msgCp->evntStr = (TknU8*)(ebcPtr);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   /* ServiceState */
   if (foundSS == 0) {
      mgAsnSkipElmnt(msgCp);
   } else {
      msgCp->evntStr = (TknU8*)(ssPtr);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ROK);
}



/*
*
*       Fun:   mgaFuncTerminationStateDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncTerminationStateDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncTerminationStateDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16                  ret;
   MgMgcoTermStateDesc* evPtr;
   MgMgcoTermStateParm* newPar;
   MgMgcoPropParmLst    ppList;
   MgMgcoPropParm*      curPropPar;
   MsgLen               elmntLen;       /* element length */
   MsgLen               prevLen;        /* previous length */
   S16 j;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncTerminationStateDescriptorDec);
   evPtr= (MgMgcoTermStateDesc*) msgCp->evntStr;
   (void) cmMemset((U8*)evPtr, 0, sizeof(MgMgcoTermStateDesc));
   elmntLen = msgCp->elmntLen;
   ++msgCp->elmntDef;

   /* Property Parms */
   prevLen = mgAsnFindLen(msgCp);
   (void)cmMemset((U8*)&ppList, 0, sizeof(MgMgcoPropParmLst));
   msgCp->evntStr = (TknU8*) &ppList;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(ppList.num.pres) {
      /* Copy over each prop parm into the TermStateDesc list */
      evPtr->numComp.pres = PRSNT_NODEF;
      if (mgAsnDecGetMoreMem(msgCp, (Ptr*)&(evPtr->trmStPar), (MsgLen)((evPtr->numComp.val + ppList.num.val) * sizeof(MgMgcoTermStateParm*)), (MsgLen)((ppList.num.val) * sizeof(MgMgcoTermStateParm*))) != ROK) { RETVALUE(RFAILED); }

      /* copy the list */
     for(j=0; j<ppList.num.val; ++j) {
        if (mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->trmStPar[evPtr->numComp.val+j]), sizeof(MgMgcoTermStateParm)) != ROK) { RETVALUE(RFAILED); }
        newPar = evPtr->trmStPar[evPtr->numComp.val+j];
        newPar->type.pres = PRSNT_NODEF;
        newPar->type.val = MGT_TERMST_PROPLST;
        curPropPar = ppList.parms[j];
        (void)cmMemcpy((U8*)&(newPar->u.parm), (U8*)curPropPar, sizeof(MgMgcoPropParm));
        if (mgAsnDecPutMem(msgCp, curPropPar) != ROK) { RETVALUE(RFAILED); }
     }
     if (mgAsnDecPutMem(msgCp, ppList.parms) != ROK) { RETVALUE(RFAILED); }
     evPtr->numComp.val += ppList.num.val;
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* Event Buffer Control */
   prevLen = mgAsnFindLen(msgCp);
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(newPar), (sizeof(MgMgcoTermStateParm))) != ROK) { RETVALUE(RFAILED); }
   (void)cmMemset((U8*)newPar, 0, sizeof(MgMgcoTermStateParm));
   msgCp->evntStr = (TknU8*) &(newPar->u.evtBufCtl);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(newPar->u.evtBufCtl.pres) {
      newPar->type.pres = PRSNT_NODEF;
      newPar->type.val = MGT_TERMST_EVTBUFCTL;
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->trmStPar), &(evPtr->numComp), (Ptr*)&(newPar), 1)) != ROK) {
         RETVALUE(ret);
      } 
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newPar)) != ROK) { RETVALUE(ret); }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* ServiceState */
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(newPar), (sizeof(MgMgcoTermStateParm))) != ROK) { RETVALUE(RFAILED); }
   (void)cmMemset((U8*)newPar, 0, sizeof(MgMgcoTermStateParm));
   msgCp->evntStr = (TknU8*) &(newPar->u.svcState);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(newPar->u.svcState.pres) {
      newPar->type.pres = PRSNT_NODEF;
      newPar->type.val = MGT_TERMST_SVCST;
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->trmStPar), &(evPtr->numComp), (Ptr*)&(newPar), 1)) != ROK) {
         RETVALUE(ret);
      } 
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newPar)) != ROK) { RETVALUE(ret); }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}

/* mg003.105: Add - encode function are adding for the events descriptor */

/*
*
*       Fun:   mgaFuncEventsDescriptorEnc
*
*       Desc:  This function encodes the EventsDescriptor  
*
*       Ret:   ROK (encoding successful) 
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgaFuncEventsDescriptorEnc 
(
MgAsnMsgCp   *msgCp     /* message control pointer */
)
#else
PUBLIC S16 mgaFuncEventsDescriptorEnc (msgCp)
MgAsnMsgCp   *msgCp;    /* message control pointer */
#endif
{
   S16          ret;            /* return value */
   U16          i;              /* counter */
   MgMgcoReqEvtDesc* evPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncEventsDescriptorEnc)

   evPtr = (MgMgcoReqEvtDesc*)msgCp->evntStr;
   i = 0;

   /* Increment the database pointer over seq start/set start defintion */
   ++msgCp->elmntDef;

   if (evPtr->el.num.pres == NOTPRSNT)
   {
      evPtr->el.num.pres = PRSNT_NODEF;
      evPtr->el.num.val = 0;
   }
      
   if (evPtr->reqId.type.pres == NOTPRSNT && evPtr->el.num.val >0)
   {
      MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
      RETVALUE(RFAILED);
   }
   /* assigning reqId elemnt */
   msgCp->evntStr = (TknU8*) &evPtr->reqId;
   /* encode all elements till end of sequence element is encountered */
   while ((*(msgCp->elmntDef))->type != TET_SETSEQ_TERM)
   {
      /* encode the element depending on the element type */
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK)
      {
         /* the error code would already be set, do not do it again */
         RETVALUE(ret);
      }
   } /* end while */

   /* Increment the database pointer over the seq/set end element */
   msgCp->elmntDef++;

   MGAFUNCSKIP(msgCp); 
   RETVALUE(ROK);

} /* end of mgaFuncEventsDescriptorEnc */

/* mg007.105: Add - decode function are adding for the events descriptor */

/*
*
*       Fun:   mgaFuncEventsDescriptorDec
*
*       Desc:  This function decodes the EventsDescriptor  
*
*       Ret:   ROK (encoding successful) 
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgaFuncEventsDescriptorDec 
(
MgAsnMsgCp   *msgCp     /* message control pointer */
)
#else
PUBLIC S16 mgaFuncEventsDescriptorDec (msgCp)
MgAsnMsgCp   *msgCp;    /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;      /* element definition */
   /* mg007.105: Add - temparory element for error reporting */
   MgAsnElmntDef   *tmpElmntDef;   
   S16          ret;            /* return value */
   TknU8        *evntStr;       /* pointer to event structure */
   MsgLen       prevLen;        /* msg length before decoding element */
   Buffer       *mBuf;          /* message buffer */
   MsgLen       elmntLen;       /* element length */
   MgMgcoReqEvtDesc* evPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgAsnDecSeq)

   evPtr = (MgMgcoReqEvtDesc*)msgCp->evntStr;
   evntStr  = (TknU8 *)msgCp->evntStr; /* get the event structure */
   elmntDef = *msgCp->elmntDef;        /* get the element definition */
   mBuf     = msgCp->mBuf;             /* get the message buffer */

   /* increment the data base pointer over the start of sequence element */
   ++msgCp->elmntDef;

   (void)cmMemset((U8*)evPtr, 0, sizeof(MgMgcoReqEvt));
   /* make the sequence present as true */
   evPtr->pres.pres = PRSNT_NODEF;

   /* assigning reqId  */
   msgCp->evntStr = (TknU8*) &evPtr->reqId;

   /* go through the loop and decode all the elements of the sequence */
   elmntLen = msgCp->elmntLen;
   while ((*(msgCp->elmntDef))->type != TET_SETSEQ_TERM)
   {
      if (elmntLen <= 0)
      {
         if (elmntLen < 0)
         {
            MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
            RETVALUE(RFAILED);
         }

         /* check for any mandatory element missing and return */
         if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK)
         {
            RETVALUE(ret);
         }
         RETVALUE(ROK);
      } /* end if */

      prevLen = mgAsnFindLen(msgCp);

      /* decode the element depending on the element type */
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK)
      {
         /* do not fill error as already filled in */ 
         RETVALUE(ret);
      }

      /* decrement the sequence length depending on the element size */
      elmntLen -= prevLen - mgAsnFindLen(msgCp);

   } /* end while */

   /* Increment the database pointer over end of sequence element */
   msgCp->elmntDef++;

   if ((evPtr->el.num.pres == NOTPRSNT) || (evPtr->reqId.type.pres == NOTPRSNT && evPtr->el.num.val >0))
   {
      tmpElmntDef = *msgCp->elmntDef;
      *msgCp->elmntDef = elmntDef;
      MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
      *msgCp->elmntDef = tmpElmntDef;
      RETVALUE(RFAILED);
   }

   MGAFUNCSKIP(msgCp); 
   RETVALUE(ROK);

} /* end of mgaFuncEventsDescriptorDec */


/*
*
*       Fun:   mgaFuncRequestedEventEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncRequestedEventEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncRequestedEventEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoReqEvt* evPtr;
   MgMgcoEvtPar* parPtr;

   S16 j;
   S16 foundStreamId = 0;
   MgMgcoStreamId* ptrStreamId;
   S16 foundReqAction = 0;
   S16 foundEmbedWithSig = 0;
   S16 foundEmbedNoSig = 0;
   S16 foundDigMap = 0;
   S16 foundKeepActive = 0;
   S16 foundOther = 0;
   MgMgcoEvtParLst newReqActLst;
   MgMgcoEvtPar** curReqAct;
   MgMgcoEvtParLst newEvParLst;
   MgMgcoEvtPar** curEvPar;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncRequestedEventEnc);
   evPtr = (MgMgcoReqEvt*)msgCp->evntStr;
   ++msgCp->elmntDef;

   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      msgCp->secElmntDef = (MgAsnElmntDef**)mgaPkgReqEvts[evPtr->pkg.val - 1];
   } else if(evPtr->pkg.val == 0) {
      /* allow it, but it's not defined */
      msgCp->secElmntDef = NULLP;
   }
   /* encode PkgdName, which takes first two events */
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* look at parameter list */
   /* mg003.105: If Event parameter list is not present encode with length of 00 */
   if(evPtr->pl.num.val > 0) {
      for(j=0; j<evPtr->pl.num.val; ++j) {
         parPtr = evPtr->pl.parms[j];
         if(parPtr->type.val == MGT_EVTPAR_OTHER) {
            ++foundOther;
         } else if (parPtr->type.val == MGT_EVTPAR_STREAMID) {
            ++foundStreamId;
            ptrStreamId = &(parPtr->u.streamId);
         } else if (parPtr->type.val == MGT_EVTPAR_EMBEDWITHSIG) {
            ++foundEmbedWithSig;
            ++foundReqAction;
         } else if (parPtr->type.val == MGT_EVTPAR_EMBEDNOSIG) {
            ++foundEmbedNoSig;
            ++foundReqAction;
         } else if (parPtr->type.val == MGT_EVTPAR_DIGMAP) {
            ++foundDigMap;
            ++foundReqAction;
         } else if (parPtr->type.val == MGT_EVTPAR_KEEPACTIVE) {
            ++foundKeepActive;
            ++foundReqAction;
         }
      }
   }

   /* encode, in order, streamId, requested actions, and EvParList */
   if(foundStreamId > 1) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   } else if (foundStreamId == 0) {
      mgAsnSkipElmnt(msgCp);
   } else {
      msgCp->evntStr = (TknU8*) ptrStreamId;
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
   
   /* Sanity check.  Then construct a MgMgcoEvtParLst with those 
    * elements that are used to encode Requested Action
    */
   if( (foundKeepActive > 1) || (foundDigMap > 1) || 
       (foundEmbedWithSig > 1) || (foundEmbedNoSig > 1) ) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }
   if(foundReqAction < 1) {
      mgAsnSkipElmnt(msgCp);
   } else {
      if (mgAsnEncGetMem(msgCp, (Ptr*)&(newReqActLst.parms), (MsgLen)(foundReqAction * sizeof(MgMgcoEvtPar*))) != ROK) { RETVALUE(RFAILED); }
      curReqAct = newReqActLst.parms;
      for(j=0; j<evPtr->pl.num.val; ++j) {
         parPtr = evPtr->pl.parms[j];
         if ( (parPtr->type.val == MGT_EVTPAR_EMBEDWITHSIG) ||
            (parPtr->type.val == MGT_EVTPAR_EMBEDNOSIG) ||
            (parPtr->type.val == MGT_EVTPAR_DIGMAP)  ||
            (parPtr->type.val == MGT_EVTPAR_KEEPACTIVE) ) {
            *(curReqAct) = parPtr;
            ++curReqAct;
         }
      }
      newReqActLst.num.val = foundReqAction;
      newReqActLst.num.pres = PRSNT_NODEF;
      msgCp->evntStr = (TknU8*) &(newReqActLst);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) {
         if (mgAsnEncPutMem(msgCp, (Ptr)newReqActLst.parms, (MsgLen)(foundReqAction * sizeof(MgMgcoEvtPar*))) != ROK) { RETVALUE(RFAILED); }
         RETVALUE(ret);
      }
      if (mgAsnEncPutMem(msgCp, (Ptr)newReqActLst.parms, (MsgLen)(foundReqAction * sizeof(MgMgcoEvtPar*))) != ROK) { RETVALUE(RFAILED); }
   }

   /* encode evparlist */
   /* mg003.105: Initialize event parameter to 0 */
   (void)cmMemset((U8*)&newEvParLst, 0, sizeof(MgMgcoEvtParLst));
   if (foundOther) {
      if (mgAsnEncGetMem(msgCp, (Ptr*)&(newEvParLst.parms), (MsgLen)(foundOther * sizeof(MgMgcoEvtPar*))) != ROK) { RETVALUE(RFAILED); }
      curEvPar = newEvParLst.parms;
      for(j=0; j<evPtr->pl.num.val; ++j) {
         parPtr = evPtr->pl.parms[j];
         if(parPtr->type.val == MGT_EVTPAR_OTHER) {
            *(curEvPar) = parPtr;
            ++curEvPar;
         }
      }
   }

/* mg003.105: Changes for RequestEventEnc */
   /* Encode empty list if necessary */
   newEvParLst.num.val = foundOther;
      newEvParLst.num.pres = PRSNT_NODEF;
   msgCp->evntStr = (TknU8*) &(newEvParLst);
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) {
      if (foundOther) {
         if (mgAsnEncPutMem(msgCp, (Ptr)newEvParLst.parms, (MsgLen)(foundOther * sizeof(MgMgcoEvtPar*))) != ROK) { RETVALUE(RFAILED); }
      }
      RETVALUE(ret);
   }
   if (foundOther) {
      if (mgAsnEncPutMem(msgCp, (Ptr)newEvParLst.parms, (MsgLen)(foundOther * sizeof(MgMgcoEvtPar*))) != ROK) { RETVALUE(RFAILED); }
   }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret); 
}


/*
*
*       Fun:   mgaFuncRequestedEventDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncRequestedEventDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncRequestedEventDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16                  ret;
   MgMgcoReqEvt*        evPtr;
   MgMgcoEvtPar*        newEvPar;
   MgMgcoEvtParLst      others;
   MgMgcoEvtParLst      reqActions;
   MsgLen               elmntLen;       /* element length */
   MsgLen               prevLen;        /* previous length */
   MgaPkg* pkgName;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncRequestedEventDec);
   evPtr = (MgMgcoReqEvt*)msgCp->evntStr;
   elmntLen = msgCp->elmntLen;
   ++msgCp->elmntDef;

   /* decode pkg and name */
   prevLen = mgAsnFindLen(msgCp);
   (void)cmMemset((U8*)evPtr, 0, sizeof(MgMgcoReqEvt));
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      /* validate the name */
      pkgName = mgaPkgReqEvts[evPtr->pkg.val - 1];
      if(pkgName != NULLP) {
         if( (evPtr->name.name.type.pres == PRSNT_NODEF) &&
            (evPtr->name.name.type.val == MGT_GEN_TYPE_KNOWN) &&
            (evPtr->name.name.u.val.val > 0) && 
            (evPtr->name.name.u.val.val <= pkgName->maxNumNames) )
         {
            if(pkgName->names[evPtr->name.name.u.val.val-1] != NULLP)
            {
               msgCp->secElmntDef = (MgAsnElmntDef**)(pkgName->names[evPtr->name.name.u.val.val - 1]->value);
            } else {
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(RFAILED);
            }
         } else {
#ifndef MG_ASN_TEST
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
            RETVALUE(RFAILED);
#endif
         }
      }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }
   
   /* stream id*/
   prevLen = mgAsnFindLen(msgCp);
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(newEvPar), (sizeof(MgMgcoEvtPar))) != ROK) { RETVALUE(RFAILED); }
   msgCp->evntStr = (TknU8*) &(newEvPar->u.streamId);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(newEvPar->u.streamId.pres) {
      newEvPar->type.pres = PRSNT_NODEF;
      newEvPar->type.val = MGT_EVTPAR_STREAMID;
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)&newEvPar, 1)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newEvPar)) != ROK) { RETVALUE(ret); }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }
   
   /* Requested actions types EMBEDWITHSIG, EMBEDNOSIG, DIGMAP, KEEPACTIVE */
   prevLen = mgAsnFindLen(msgCp);
   (void) cmMemset((U8*)&reqActions, 0, sizeof(MgMgcoEvtParLst));
   msgCp->evntStr = (TknU8*) &reqActions;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(reqActions.num.pres) {
      evPtr->pl.num.pres = PRSNT_NODEF;
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)reqActions.parms, reqActions.num.val)) != ROK) {
         RETVALUE(ret);
      }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* EvParList is all "others" */
   (void)cmMemset((U8*)&others, 0, sizeof(MgMgcoEvtParLst));
   msgCp->evntStr = (TknU8*) &others;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(others.num.pres) {
      evPtr->pl.num.pres = PRSNT_NODEF;
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)others.parms, others.num.val)) != ROK) {
         RETVALUE(ret);
      }
   }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;
   
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncRequestedActionsEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncRequestedActionsEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncRequestedActionsEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   /* Go through the MgMgcoEvtParList searching for, and encoding,
    * in order: keepActive, eventDm, SecondEvent, and Signals Desc
    * (all are optional)
    */
   S16 ret;
   S16 j;
   MgMgcoEvtParLst* evPtr;
   MgMgcoEvtPar* parPtr;
   MgMgcoEmbWithSig* embWithSigPtr = NULL;
   MgMgcoEmbNoSig* embNoSigPtr = NULL;
   MgMgcoEvtDM* dmPtr = NULL;
   S16 foundKeepActive = 0;
   TknBool kaVal;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncRequestedActionsEnc);
   ++msgCp->elmntDef;
   evPtr = (MgMgcoEvtParLst*)msgCp->evntStr;
   for(j=0; j<evPtr->num.val; ++j) {
      parPtr = evPtr->parms[j];
      if(parPtr->type.val == MGT_EVTPAR_KEEPACTIVE) {
         ++foundKeepActive;
      } else if(parPtr->type.val == MGT_EVTPAR_EMBEDWITHSIG) {
         embWithSigPtr = &(parPtr->u.embWithSig);
      } else if(parPtr->type.val == MGT_EVTPAR_EMBEDNOSIG) {
         embNoSigPtr = &(parPtr->u.embNoSig);
      } else if(parPtr->type.val == MGT_EVTPAR_DIGMAP) {
         dmPtr = &(parPtr->u.dm);
      }
   }

   if(foundKeepActive == 0) {
      mgAsnSkipElmnt(msgCp);
   } else {
      kaVal.pres = PRSNT_NODEF;
      kaVal.val = 1;
      msgCp->evntStr = (TknU8*) &kaVal;
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) {RETVALUE(ret); }
      msgCp->evntStr = (TknU8*)evPtr;
   }

   if(dmPtr == NULL) {
      mgAsnSkipElmnt(msgCp);
   } else {
      msgCp->evntStr = (TknU8*) dmPtr;
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   if(embWithSigPtr != NULL) {
      /* encode SecondEventsDescriptor and SignalsDescriptor */
      msgCp->evntStr = (TknU8*) &(embWithSigPtr->emb);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

      msgCp->evntStr = (TknU8*) &(embWithSigPtr->sig);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if (embNoSigPtr != NULL) {
      /* encode SecondEventsDescriptor and skip SignalsDescriptor */
      msgCp->evntStr = (TknU8*) (embNoSigPtr);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      mgAsnSkipElmnt(msgCp);
   } else {
      /* Skip both SecondEventsDescriptor and SignalsDescriptor */
      mgAsnSkipElmnt(msgCp);
      mgAsnSkipElmnt(msgCp);
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncRequestedActionsDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncRequestedActionsDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncRequestedActionsDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoEvtParLst* evPtr;
   MgMgcoEvtPar* newEvPar;
   MgMgcoEmbedFirst val;
   MgMgcoSignalsDesc sigVal;
   MsgLen               elmntLen;       /* element length */
   MsgLen               prevLen;        /* previous length */

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncRequestedActionsDec);
   evPtr = (MgMgcoEvtParLst*)msgCp->evntStr;
   elmntLen = msgCp->elmntLen;
   ++msgCp->elmntDef;

   /* Keep Active */
   prevLen = mgAsnFindLen(msgCp);
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(newEvPar), (sizeof(MgMgcoEvtPar))) != ROK) { RETVALUE(RFAILED); }
   (void)cmMemset((U8*)newEvPar, 0, sizeof(MgMgcoEvtPar));
   msgCp->evntStr = (TknU8*) (newEvPar);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) {RETVALUE(ret); }
   if(newEvPar->type.pres) {
      newEvPar->type.val = MGT_EVTPAR_KEEPACTIVE;
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->parms), &(evPtr->num), (Ptr*)&(newEvPar), 1)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newEvPar)) != ROK) { RETVALUE(ret); }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }
   
   /* eventDM */
   prevLen = mgAsnFindLen(msgCp);
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(newEvPar), (sizeof(MgMgcoEvtPar))) != ROK) { RETVALUE(RFAILED); }
   (void)cmMemset((U8*)newEvPar, 0, sizeof(MgMgcoEvtPar));
   msgCp->evntStr = (TknU8*) &(newEvPar->u.dm);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) {RETVALUE(ret); }
   if(newEvPar->u.dm.type.pres) {
      newEvPar->type.pres = PRSNT_NODEF;
      newEvPar->type.val = MGT_EVTPAR_DIGMAP;
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->parms), &(evPtr->num), (Ptr*)&(newEvPar), 1)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newEvPar)) != ROK) { RETVALUE(ret); }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }
 
   /* second events will come back with an embedfirst/embedNoSig 
    * or nada,
    * if the next decode has a signal, manually construct the
    * embWithSig, else construct the embNoSig
    */
   (void)cmMemset((U8*)&val, 0, sizeof(MgMgcoEmbedFirst));
   msgCp->evntStr = (TknU8*) &(val);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) {RETVALUE(ret); }
   if(val.pres.pres) {
      /* See if there is anything else */
      (void)cmMemset((U8*)&sigVal, 0, sizeof(MgMgcoSignalsDesc));
      elmntLen -= prevLen - mgAsnFindLen(msgCp);
      if (elmntLen > 0) {
         /* SignalsDescriptor */
         msgCp->evntStr = (TknU8*) &sigVal;
         if((ret = mgAsnDecElmnt(msgCp)) != ROK) {RETVALUE(ret); }
      }

      /* prepare the MgMgcoEvtPar */
      if (mgAsnDecGetMem(msgCp, (Ptr*)&(newEvPar), (sizeof(MgMgcoEvtPar))) != ROK) { RETVALUE(RFAILED); }
      (void)cmMemset((U8*)newEvPar, 0, sizeof(MgMgcoEvtPar));
      newEvPar->type.pres = PRSNT_NODEF;

      if(sigVal.pres.pres) {
         /* construct EvtPar with type of EMBEDWITHSIG */
         newEvPar->type.val = MGT_EVTPAR_EMBEDWITHSIG;
         newEvPar->u.embWithSig.pres.pres = PRSNT_NODEF;
         cmMemcpy((U8*)&(newEvPar->u.embWithSig.sig), (U8*)&sigVal, 
                     sizeof(MgMgcoSignalsDesc));
         cmMemcpy((U8*)&(newEvPar->u.embWithSig.emb), (U8*)&val, 
                     sizeof(MgMgcoEmbedFirst));
      } else {
         /* construct a MgcoEvtPar of type EMBNOSIG*/
         newEvPar->type.val = MGT_EVTPAR_EMBEDNOSIG;
         cmMemcpy((U8*)&(newEvPar->u.embNoSig), (U8*)&val, sizeof(MgMgcoEmbNoSig));
      }
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->parms), &(evPtr->num), (Ptr*)&(newEvPar), 1)) != ROK) {
         RETVALUE(ret);
      } 
   }
   
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncEventParameterEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncEventParameterEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncEventParameterEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoEvtPar* evPtr;
   MgAsnElmntDef** saveSecElmntDef;

   /* we only expect type = MGT_EVTPAR_OTHER at this point */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncEventParameterEnc);
   saveSecElmntDef = msgCp->secElmntDef;
   evPtr = (MgMgcoEvtPar*)msgCp->evntStr;
   if (evPtr->type.val != MGT_EVTPAR_OTHER) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }
   ++msgCp->elmntDef;

   /* encode name */
   msgCp->evntStr = (TknU8*) &(evPtr->u.other.name);
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* value */
   if(evPtr->u.other.val.type.pres != NOTPRSNT)
   {
      msgCp->evntStr = (TknU8*) &(evPtr->u.other.val);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

      /* extra info from u.other.val as well */
      if (evPtr->u.other.val.type.val != MGT_VALUE_EQUAL) {
         msgCp->evntStr = (TknU8*) &(evPtr->u.other.val);
         if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      }
   }
   else
   {
      evPtr->u.other.val.type.pres = PRSNT_NODEF;
      if ((ret = mgAsnEncTag(msgCp)) != ROK) {
         if (ret == RSKIP) { RETVALUE(ROK); }
         RETVALUE(ret);
      }
   }
   msgCp->secElmntDef = saveSecElmntDef;

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncEventParameterDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncEventParameterDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncEventParameterDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoEvtPar* evPtr;
   MgMgcoValLst vals;
   MsgLen               elmntLen;       /* element length */
   MsgLen               prevLen;        /* previous length */
   MgAsnElmntDef** saveSecElmntDef;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncEventParameterDec);
   saveSecElmntDef = msgCp->secElmntDef;
   elmntLen = msgCp->elmntLen;
   evPtr = (MgMgcoEvtPar*)msgCp->evntStr;
   ++msgCp->elmntDef;

   /* decode always into an EvtPar with type as other */
   prevLen = mgAsnFindLen(msgCp);
   (void) cmMemset((U8*)evPtr, 0, sizeof(MgMgcoEvtPar));
   msgCp->evntStr = (TknU8*) &(evPtr->u.other.name);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   evPtr->type.pres = PRSNT_NODEF;
   evPtr->type.val  = MGT_EVTPAR_OTHER;
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* vals */
   prevLen = mgAsnFindLen(msgCp);
   (void)cmMemset((U8*)&vals, 0, sizeof(MgMgcoValLst));
   msgCp->evntStr = (TknU8*) &vals;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
/*   if(vals.num.val < 1) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
      RETVALUE(RFAILED);
   }*/
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0 ) {
      if(vals.num.val > 0)
      {
         evPtr->u.other.val.type.pres = PRSNT_NODEF;
         evPtr->u.other.val.type.val = MGT_VALUE_EQUAL;
         if((ret=mergeParmValue(&(evPtr->u.other.val),&vals))!=ROK){
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
            RETVALUE(ret);
         }
      }
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      msgCp->secElmntDef = saveSecElmntDef;
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }
   
   /* extra info partially populates u.other.val */
   msgCp->evntStr = (TknU8*) &(evPtr->u.other.val);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(evPtr->u.other.val.type.pres == NOTPRSNT) {
      /* this must be eq */
      evPtr->u.other.val.type.pres = PRSNT_NODEF;
      evPtr->u.other.val.type.val = MGT_VALUE_EQUAL;
   }
   if((ret=mergeParmValue(&(evPtr->u.other.val),&vals))!=ROK){
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
      RETVALUE(ret);
   }
   evPtr->type.pres = PRSNT_NODEF;
   evPtr->type.val = MGT_EVTPAR_OTHER;
   msgCp->secElmntDef = saveSecElmntDef;

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncSigParameterEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncSigParameterEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncSigParameterEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoSigPar* evPtr;
   MgAsnElmntDef** saveSecElmntDef;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncSigParameterEnc);
   /* we only expect type = MGT_SIGPAR_OTHER at this point */
   ++msgCp->elmntDef;
   saveSecElmntDef = msgCp->secElmntDef;
   evPtr = (MgMgcoSigPar*)msgCp->evntStr;
   if (evPtr->type.val != MGT_SIGPAR_OTHER) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }

   /* encode name */
   msgCp->evntStr = (TknU8*) &(evPtr->u.other.name);
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* encodes value from u.other.val */
   msgCp->evntStr = (TknU8*) &(evPtr->u.other.val);
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* encode extrainfo from u.other.val as well */
   if (evPtr->u.other.val.type.val != MGT_VALUE_EQUAL) {
      msgCp->evntStr = (TknU8*) &(evPtr->u.other.val);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
   msgCp->secElmntDef = saveSecElmntDef;

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncSigParameterDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncSigParameterDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncSigParameterDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoSigPar* evPtr;
   MgMgcoValLst vals;
   MsgLen               elmntLen;       /* element length */
   MsgLen               prevLen;        /* previous length */
   MgAsnElmntDef** saveSecElmntDef;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncSigParameterDec);
   saveSecElmntDef = msgCp->secElmntDef;
   evPtr = (MgMgcoSigPar*)msgCp->evntStr;
   elmntLen = msgCp->elmntLen;
   ++msgCp->elmntDef;

   /* decode always into a SigPar with type as other; name first */
   prevLen = mgAsnFindLen(msgCp);
   (void)cmMemset((U8*)evPtr, 0, sizeof(MgMgcoSigPar));
   msgCp->evntStr = (TknU8*) &(evPtr->u.other.name);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* vals */
   prevLen = mgAsnFindLen(msgCp);
   (void)cmMemset((U8*)&vals, 0, sizeof(MgMgcoValLst));
   msgCp->evntStr = (TknU8*) &vals;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(vals.num.val < 1) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
      RETVALUE(RFAILED);
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      /* this must be eq */
      /* mg004.105: Change - fix for the signal other parameter */
      evPtr->type.pres = PRSNT_NODEF;
      evPtr->type.val = MGT_SIGPAR_OTHER;
      evPtr->u.other.val.type.pres = PRSNT_NODEF;
      evPtr->u.other.val.type.val = MGT_VALUE_EQUAL;
      if((ret=mergeParmValue(&(evPtr->u.other.val),&vals))!=ROK){
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
         RETVALUE(ret);
      }
      msgCp->secElmntDef = saveSecElmntDef;
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }
   
   /* extra info partially populates u.other.val */
   msgCp->evntStr = (TknU8*) &(evPtr->u.other.val);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /*  Added because no where in mgAsnDecElmnt we are 
           setting evPtr->type.pres */
   if (evPtr->u.other.val.type.pres)
   {
      evPtr->type.pres = PRSNT_NODEF;
      evPtr->type.val = MGT_SIGPAR_OTHER;
   }

   if(evPtr->u.other.val.type.pres == NOTPRSNT) {
      /* this must be eq */
      /* mg007.105: Change - fix for the signal other parameter */
      evPtr->type.pres = PRSNT_NODEF;
      evPtr->type.val = MGT_SIGPAR_OTHER;
      evPtr->u.other.val.type.pres = PRSNT_NODEF;
      evPtr->u.other.val.type.val = MGT_VALUE_EQUAL;
   }
   if((ret=mergeParmValue(&(evPtr->u.other.val),&vals))!=ROK){
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
      RETVALUE(ret);
   }
   msgCp->secElmntDef = saveSecElmntDef;

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncSignalEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncSignalEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncSignalEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoSignalsReq* evPtr;
   MgMgcoSigPar *parPtr;
   S16 j;
   S16 foundKeepActive = 0;
   S16 foundOther = 0;
   S16 foundStreamId = 0;
   MgMgcoStreamId* streamIdPtr;
   S16 foundSignalType = 0;
   TknU8* sigTypePtr;
   S16 foundDuration = 0;
   TknU16* durPtr;
   S16 foundNtfyComp = 0;
   MgMgcoNtfyCmpl* ncPtr;
   TknBool kaVal;
   MgMgcoSigParLst newPtrList;
   MgMgcoSigPar** curNewPtr;

   /* first element is PkgdName, which will take first two
    * elements in evPtr, namely pkg and name 
    */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncSignalEnc);
   evPtr= (MgMgcoSignalsReq*)msgCp->evntStr;
   ++msgCp->elmntDef;

   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      msgCp->secElmntDef = (MgAsnElmntDef**)mgaPkgSignals[evPtr->pkg.val - 1];
   } else if(evPtr->pkg.val == 0) {
      /* allow it, but it's not defined */
      msgCp->secElmntDef = NULLP;
   }

   /* signal name */
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* Values in Signal can be found in the SigParList */
   /* mg003.105: If Event parameter list is not present encode with length of 00 */
   if(evPtr->pl.num.val  > 0) {
      for(j=0; j<evPtr->pl.num.val; ++j) {
         parPtr = evPtr->pl.parms[j];
         if(parPtr->type.val == MGT_SIGPAR_OTHER) {
            ++foundOther;
         } else if (parPtr->type.val == MGT_SIGPAR_STREAMID) {
            ++foundStreamId;
            streamIdPtr = &(parPtr->u.streamId);
         } else if (parPtr->type.val ==  MGT_SIGPAR_DURATION) {
            ++foundDuration;
            durPtr = &(parPtr->u.dura);
         } else if (parPtr->type.val == MGT_SIGPAR_NTFYCMPL) {
            ++foundNtfyComp;
            ncPtr = &(parPtr->u.nc);
         } else if(parPtr->type.val == MGT_SIGPAR_KEEPACTIVE) {
            ++foundKeepActive;
         } else if(parPtr->type.val == MGT_SIGPAR_TYPE) {
            ++foundSignalType;
            sigTypePtr = &(parPtr->u.type);
         }
      }
   }
   if( (foundStreamId > 1) || (foundSignalType> 1) ||
       (foundDuration > 1) || (foundNtfyComp > 1) || 
       (foundKeepActive > 1) ) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }

   /* encode, in order, streamID, sigType, duration, 
    * notifyCompletion, keepActive, and sigParList
    */
   if(foundStreamId == 0) {
      mgAsnSkipElmnt(msgCp);
   } else {
      msgCp->evntStr = (TknU8*) streamIdPtr;
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   if(foundSignalType == 0) {
      mgAsnSkipElmnt(msgCp);
   } else {
      msgCp->evntStr = (TknU8*) sigTypePtr;
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   if(foundDuration == 0) {
      mgAsnSkipElmnt(msgCp);
   } else {
      msgCp->evntStr = (TknU8*) durPtr;
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   if(foundNtfyComp == 0) {
      mgAsnSkipElmnt(msgCp);
   } else {
      msgCp->evntStr = (TknU8*) ncPtr;
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   if(foundKeepActive == 0) {
      mgAsnSkipElmnt(msgCp);
   } else {
      kaVal.pres = PRSNT_NODEF;
      kaVal.val = 1;
      msgCp->evntStr = (TknU8*) &kaVal;   
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      msgCp->evntStr = (TknU8*) evPtr;
   }

   /* sigParList - Make a new list of just the "others" and 
    * have the default for SigParList encode it up */
   (void)cmMemset((U8*)&newPtrList, 0, sizeof(MgMgcoSigParLst));
   if (foundOther > 0) {
      if (mgAsnEncGetMem(msgCp, (Ptr*)&(newPtrList.parms), (MsgLen)(foundOther * sizeof(MgMgcoSigPar*))) != ROK) { RETVALUE(RFAILED); }
      curNewPtr = newPtrList.parms;
      for(j=0; j<evPtr->pl.num.val; ++j) {
         parPtr = evPtr->pl.parms[j];
         if(parPtr->type.val == MGT_SIGPAR_OTHER) {
            *curNewPtr = parPtr;
            ++curNewPtr;
         }
      }
   }
      newPtrList.num.val = foundOther;
      newPtrList.num.pres = PRSNT_NODEF;
      msgCp->evntStr = (TknU8*) &(newPtrList);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) {
         if(foundOther > 0)
         {
            if (mgAsnEncPutMem(msgCp, (Ptr)newPtrList.parms, (MsgLen)(foundOther * sizeof(MgMgcoPropParm*))) != ROK) { RETVALUE(RFAILED); }
         }
         RETVALUE(ret);
      }
      if(foundOther > 0)
      {
         if (mgAsnEncPutMem(msgCp, (Ptr)newPtrList.parms, (MsgLen)(foundOther * sizeof(MgMgcoPropParm*))) != ROK) { RETVALUE(RFAILED); }
      }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncSignalDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncSignalDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncSignalDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoSignalsReq* evPtr;
   MgMgcoSigPar* newSigPar;
   MgMgcoSigParLst others;
   MsgLen               elmntLen;       /* element length */
   MsgLen               prevLen;        /* previous length */
   MgaPkg* pkgName;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncSignalDec);
   evPtr = (MgMgcoSignalsReq*)msgCp->evntStr;
   elmntLen = msgCp->elmntLen;
   ++msgCp->elmntDef;

   /* PkgdName decodes into pkg and name */
   prevLen = mgAsnFindLen(msgCp);
   (void)cmMemset((U8*)evPtr, 0, sizeof(MgMgcoSignalsReq));
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      /* validate the name */
      pkgName = mgaPkgSignals[evPtr->pkg.val - 1];
      if(pkgName != NULLP) {
         if( (evPtr->name.name.type.pres == PRSNT_NODEF) &&
            (evPtr->name.name.type.val == MGT_GEN_TYPE_KNOWN) &&
            (evPtr->name.name.u.val.val > 0) && 
            (evPtr->name.name.u.val.val <= pkgName->maxNumNames) )
         {
            if(pkgName->names[evPtr->name.name.u.val.val-1] != NULLP)
            {
               msgCp->secElmntDef = (MgAsnElmntDef**)(pkgName->names[evPtr->name.name.u.val.val - 1]->value);
            } else {
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(RFAILED);
            }
         } else {
            /* mg007.105: Fail the signal which id comes out side the boundary
             * limit*/
#ifdef MG_ASN_TEST
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
            RETVALUE(RFAILED);
#endif
         }
      }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* stream id*/
   prevLen = mgAsnFindLen(msgCp);
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(newSigPar), (sizeof(MgMgcoSigPar))) != ROK) { RETVALUE(RFAILED); }
   msgCp->evntStr = (TknU8*) &(newSigPar->u.streamId);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(newSigPar->u.streamId.pres) {
      newSigPar->type.pres = PRSNT_NODEF;
      newSigPar->type.val = MGT_SIGPAR_STREAMID;
      /* add new sigparameter to pl list */
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)&(newSigPar), 1)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newSigPar)) != ROK) { RETVALUE(ret); }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* Signal type */
   prevLen = mgAsnFindLen(msgCp);
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(newSigPar), (sizeof(MgMgcoSigPar))) != ROK) { RETVALUE(RFAILED); }
   msgCp->evntStr = (TknU8*) &(newSigPar->u.type);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(newSigPar->u.type.pres) {
      /* Construct an appropriate MgcoSigPar */
      newSigPar->type.pres = PRSNT_NODEF;
      newSigPar->type.val = MGT_SIGPAR_TYPE;
      /* add new sigparameter to pl list */
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)&(newSigPar), 1)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newSigPar)) != ROK) { RETVALUE(ret); }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* Duration */
   prevLen = mgAsnFindLen(msgCp);
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(newSigPar), (sizeof(MgMgcoSigPar))) != ROK) { RETVALUE(RFAILED); }
   msgCp->evntStr = (TknU8*) &(newSigPar->u.dura);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(newSigPar->u.dura.pres) {
      newSigPar->type.pres = PRSNT_NODEF;
      newSigPar->type.val = MGT_SIGPAR_DURATION;
      /* add new sigparameter to pl list */
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)&(newSigPar), 1)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newSigPar)) != ROK) { RETVALUE(ret); }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* Notify Complete */
   prevLen = mgAsnFindLen(msgCp);
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(newSigPar), (sizeof(MgMgcoSigPar))) != ROK) { RETVALUE(RFAILED); }
   msgCp->evntStr = (TknU8*) &(newSigPar->u.nc);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(newSigPar->u.nc.num.pres) {
      newSigPar->type.pres = PRSNT_NODEF;
      newSigPar->type.val = MGT_SIGPAR_NTFYCMPL;
      
      /* add new sigparameter to pl list */
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)&(newSigPar), 1)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newSigPar)) != ROK) { RETVALUE(ret); }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* Keep Active */
   prevLen = mgAsnFindLen(msgCp);
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(newSigPar), (sizeof(MgMgcoSigPar))) != ROK) { RETVALUE(RFAILED); }
   msgCp->evntStr = (TknU8*) (newSigPar);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(newSigPar->type.pres) {
      newSigPar->type.val = MGT_SIGPAR_KEEPACTIVE;
      /* add new sigparameter to pl list */
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)&(newSigPar), 1)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newSigPar)) != ROK) { RETVALUE(ret); }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* SigParList - all the "others" */
   (void)cmMemset((U8*)&others, 0, sizeof(MgMgcoSigParLst));
   msgCp->evntStr = (TknU8*) &others;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(others.num.pres) {
      evPtr->pl.num.pres = PRSNT_NODEF;
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)(others.parms), others.num.val)) != ROK) {
         RETVALUE(ret);
      }
   }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncSignalRequestEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncSignalRequestEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncSignalRequestEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   U8 saveVal;
   MgMgcoSignalsParm* evPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncSignalRequestEnc);

   /* Change the type temporarily for ASN */
   evPtr = (MgMgcoSignalsParm*)(msgCp->evntStr);
   saveVal = evPtr->type.val;
   if(evPtr->type.val == MGT_SIGSPAR_REQ) {
      evPtr->type.val = 1;
   } else if(evPtr->type.val == MGT_SIGSPAR_LST) {
      evPtr->type.val = 2;
   }

   /* encode */
   ret = mgAsnEncChoice(msgCp);
   evPtr->type.val = saveVal;
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncSignalRequestDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncSignalRequestDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncSignalRequestDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;

   TRC2(mgaFuncSignalRequestDec);
   if((ret = mgAsnDecChoice(msgCp)) != ROK) { RETVALUE(ret); }

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncTerminationIDListSpecialEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncTerminationIDListSpecialEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncTerminationIDListSpecialEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoTermId* evPtr;
   MgMgcaTerminationIDList val;
   MgMgcaTerminationID *tmpPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncTerminationIDListSpecialEnc);
   evPtr = (MgMgcoTermId*)(msgCp->evntStr);

   /* create automatic */
   val.num.pres =  evPtr->type.pres;
   val.num.val =  1;
   val.terminationIDList = &tmpPtr; /* That'll twist your melon */
   tmpPtr = (MgMgcaTerminationID*)evPtr;

   /* encode */
   msgCp->evntStr = (TknU8*)&(val);
   ret = mgAsnEncUnconsSetSeqOf(msgCp);

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncTerminationIDListSpecialDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncTerminationIDListSpecialDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncTerminationIDListSpecialDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoTermId* evPtr;
   MgMgcoTermIdLst val;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncTerminationIDListSpecialDec);
   evPtr = (MgMgcoTermId*)msgCp->evntStr;

   /* decode */
   (void) cmMemset((U8*)&val, 0, sizeof(val));
   msgCp->evntStr = (TknU8*) &(val);
   if ((ret = mgAsnDecUnconsSetSeqOf(msgCp)) != ROK) { RETVALUE(ret); }

   /* validate */
   if(val.num.val != 1) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
      RETVALUE(RFAILED);
   }

   /* copy */
   cmMemcpy((U8*)evPtr, (U8*)*(val.terms), sizeof(MgMgcoTermId));
   evPtr->type.pres = PRSNT_NODEF;    /* redundant, possibly */

   /* free stuff */
   if ((ret = mgAsnDecPutMem(msgCp, (Ptr)*(val.terms))) != ROK) {RETVALUE(ret);}
   if ((ret = mgAsnDecPutMem(msgCp, (Ptr)val.terms)) != ROK) {RETVALUE(ret);}

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncSecondRequestedEventEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncSecondRequestedEventEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncSecondRequestedEventEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoEvtSec* evPtr;
   MgMgcoEvtParSec* parPtr;
   MgMgcoEvtParSecLst newActLst;
   S16 j;
   S16 curCnt = 0;
   S16 foundStreamId = 0;
   MgMgcoStreamId* ptrStreamId = NULL;
   S16 foundSecReqAct = 0;
   S16 foundOther = 0;
   S16 foundSig = 0;
   S16 foundDM = 0;
   S16 foundKA = 0;
   MgMgcoEvtParSecLst newEvParLst;
   MgMgcoEvtParSec** curEvPar;
   
   /* encode PkgdName, first traverse the list to gather and encode,
    * in order, streamID, eventAction, and evParList 
    */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncSecondRequestedEventEnc);
   evPtr = (MgMgcoEvtSec*)msgCp->evntStr;
   ++msgCp->elmntDef;

   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      msgCp->secElmntDef = (MgAsnElmntDef**)mgaPkgReqEvts[evPtr->pkg.val - 1];
   } else if(evPtr->pkg.val == 0) {
      /* allow it, but it's not defined */
      msgCp->secElmntDef = NULLP;
   }

   for(j=0; j<evPtr->pl.num.val; ++j) {
      parPtr = evPtr->pl.parms[j];
      if(parPtr->type.val == MGT_EVTPAR_OTHER) {
         ++foundOther;
      } else if(parPtr->type.val == MGT_EVTPAR_STREAMID) {
         ++foundStreamId;
         ptrStreamId = &(parPtr->u.streamId);
      } else if(parPtr->type.val == MGT_EVTPAR_EMBEDSIG) {
         ++foundSecReqAct;
         ++foundSig;
      } else if(parPtr->type.val == MGT_EVTPAR_DIGMAP) {
         ++foundSecReqAct;
         ++foundDM;
      } else if(parPtr->type.val == MGT_EVTPAR_KEEPACTIVE) {
         ++foundSecReqAct;
         ++foundKA;
      }
   }

#ifndef MG_ASN_TEST
   if( (foundSig > 1) || (foundKA > 1) || (foundDM > 1) ||
       (foundStreamId > 1) ) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   } else if ( foundKA > 0 && foundSig > 0 ) {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }
#endif

   /* PkgdName */
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* StreamId */
   if(foundStreamId == 0) {
      mgAsnSkipElmnt(msgCp);
   } else {
      msgCp->evntStr = (TknU8*) ptrStreamId;
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
      
   /* SecondRequestedActions */
   if( foundSecReqAct == 0 ) {
      mgAsnSkipElmnt(msgCp);
   } else {
      if (mgAsnEncGetMem(msgCp, (Ptr*)&(newActLst.parms), (MsgLen)(foundSecReqAct * sizeof(MgMgcoEvtParSec*))) != ROK) { RETVALUE(RFAILED); }
      for(j=0; j<evPtr->pl.num.val; ++j) {
         parPtr = evPtr->pl.parms[j];
         if( (parPtr->type.val == MGT_EVTPAR_EMBEDSIG) ||
             (parPtr->type.val == MGT_EVTPAR_KEEPACTIVE) ||
             (parPtr->type.val == MGT_EVTPAR_DIGMAP) ) {
            newActLst.parms[curCnt++] = parPtr;
         }
      }
      newActLst.num.val = foundSecReqAct;
      newActLst.num.pres = PRSNT_NODEF;
      msgCp->evntStr = (TknU8*) &(newActLst);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) {
         if (mgAsnEncPutMem(msgCp, (Ptr)newActLst.parms, (MsgLen)(foundSecReqAct * sizeof(MgMgcoEvtParSec*))) != ROK) { RETVALUE(RFAILED); }
         RETVALUE(ret);
      }
      if (mgAsnEncPutMem(msgCp, (Ptr)newActLst.parms, (MsgLen)(foundSecReqAct * sizeof(MgMgcoEvtParSec*))) != ROK) { RETVALUE(RFAILED); }
   }

   /* evParList */
   if(foundOther < 1) {
      msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;
      /* mg003.105: Encode empty EventParLst if it is absent in ObservedEvent */
      /* Encode empty list */
      newEvParLst.num.val = 0;
      newEvParLst.num.pres = PRSNT_NODEF;
      newEvParLst.parms = NULL;
      msgCp->evntStr = (TknU8*) &(newEvParLst);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) {
         RETVALUE(ret);
      }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   } else {
      if (mgAsnEncGetMem(msgCp, (Ptr*)&(newEvParLst.parms), (MsgLen)(foundOther * sizeof(MgMgcoEvtParSec*))) != ROK) { RETVALUE(RFAILED); }
      curEvPar = newEvParLst.parms;
      for(j=0; j<evPtr->pl.num.val; ++j) {
         parPtr = evPtr->pl.parms[j];
         if(parPtr->type.val == MGT_EVTPAR_OTHER) {
            *(curEvPar) = parPtr;
            ++curEvPar;
         }
      }
      newEvParLst.num.val = foundOther;
      newEvParLst.num.pres = PRSNT_NODEF;
      msgCp->evntStr = (TknU8*) &(newEvParLst);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) {
         if (mgAsnEncPutMem(msgCp, (Ptr)newEvParLst.parms, (MsgLen)(foundOther * sizeof(MgMgcoEvtParSec*))) != ROK) { RETVALUE(RFAILED); }
         RETVALUE(ret);
      }
      if (mgAsnEncPutMem(msgCp, (Ptr)newEvParLst.parms, (MsgLen)(foundOther * sizeof(MgMgcoEvtParSec*))) != ROK) { RETVALUE(RFAILED); }
   }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;

   MGAFUNCSKIP(msgCp);
   RETVALUE(ROK);
}


/*
*
*       Fun:   mgaFuncSecondRequestedEventDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncSecondRequestedEventDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncSecondRequestedEventDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoEvtSec* evPtr;
   MgMgcoEvtParSec* newPar;
   MgMgcoEvtParSecLst others;
   MgMgcoEvtParSecLst reqActions;
   MsgLen               elmntLen;       /* element length */
   MsgLen               prevLen;        /* previous length */
   MgaPkg* pkgName;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncSecondRequestedEventDec);
   evPtr = (MgMgcoEvtSec*)msgCp->evntStr;
   elmntLen = msgCp->elmntLen;
   ++msgCp->elmntDef;

   /* pkg and name */
   prevLen = mgAsnFindLen(msgCp);
   (void)cmMemset((U8*)evPtr, 0, sizeof(MgMgcoEvtSec));
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      /* validate the name */
      pkgName = mgaPkgReqEvts[evPtr->pkg.val - 1];
      if(pkgName != NULLP) {
         if( (evPtr->name.name.type.pres == PRSNT_NODEF) &&
            (evPtr->name.name.type.val == MGT_GEN_TYPE_KNOWN) &&
            (evPtr->name.name.u.val.val > 0) && 
            (evPtr->name.name.u.val.val <= pkgName->maxNumNames) )
         {
            if(pkgName->names[evPtr->name.name.u.val.val-1] != NULLP)
            {
               msgCp->secElmntDef = (MgAsnElmntDef**)(pkgName->names[evPtr->name.name.u.val.val - 1]->value);
            } else {
#ifndef MG_ASN_TEST
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
            RETVALUE(RFAILED);
#endif
            }
         } else {
#ifndef MG_ASN_TEST
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
            RETVALUE(RFAILED);
#endif
         }
      }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* streamId */
   prevLen = mgAsnFindLen(msgCp);
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(newPar), (sizeof(MgMgcoEvtParSec))) != ROK) { RETVALUE(RFAILED); }
   msgCp->evntStr = (TknU8*) &(newPar->u.streamId);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(newPar->u.streamId.pres) {
      newPar->type.pres = PRSNT_NODEF;
      newPar->type.val = MGT_EVTPAR_STREAMID;
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)&(newPar), 1)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newPar)) != ROK) { RETVALUE(ret); }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* requested actions are DIGMAP, KEEPACTIVE, EMBEDSIG*/
   prevLen = mgAsnFindLen(msgCp);
   (void) cmMemset((U8*)&reqActions, 0, sizeof(MgMgcoEvtParSecLst));
   msgCp->evntStr = (TknU8*) &reqActions;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(reqActions.num.pres) {
      evPtr->pl.num.pres = PRSNT_NODEF;
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)(reqActions.parms), reqActions.num.val)) != ROK) {
         RETVALUE(ret);
      }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* EvParList is "others" */
   (void)cmMemset((U8*)&others, 0, sizeof(MgMgcoEvtParSecLst));
   msgCp->evntStr = (TknU8*) &others;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(others.num.pres) { 
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->pl.parms), &(evPtr->pl.num), (Ptr*)(others.parms), others.num.val)) != ROK) {
         RETVALUE(ret);
      }
   }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncSecondRequestedActionsEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncSecondRequestedActionsEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncSecondRequestedActionsEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   /* Go through MgMgcoEvtParSecLst searching for and encoding, 
    * in order, keepactive, eventDM, signals descriptor (all opt)
    */
   S16 ret;
   S16 j;
   MgMgcoEvtParSecLst* evPtr;
   MgMgcoEvtParSec* parPtr;
   S16 foundKeepActive = 0;
   MgMgcoEvtDM* dmPtr = NULL;
   MgMgcoSignalsDesc* sigPtr = NULL;
   TknBool kaVal;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncSecondRequestedActionsEnc);
   evPtr = (MgMgcoEvtParSecLst*)msgCp->evntStr;
   ++msgCp->elmntDef;
   for(j=0; j<evPtr->num.val; ++j) {
      parPtr = evPtr->parms[j];
      if(parPtr->type.val == MGT_EVTPAR_KEEPACTIVE) {
         ++foundKeepActive;
      } else if(parPtr->type.val == MGT_EVTPAR_DIGMAP ) {
         dmPtr = &(parPtr->u.dm);
      } else if(parPtr->type.val == MGT_EVTPAR_EMBEDSIG ) {
         sigPtr = &(parPtr->u.embSig);
      }
   }

   /* KeepActive */
   if(foundKeepActive == 0) {
      mgAsnSkipElmnt(msgCp);    
   } else {
      kaVal.pres = PRSNT_NODEF;
      kaVal.val = 1;
      msgCp->evntStr = (TknU8*) &kaVal;   
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      msgCp->evntStr = (TknU8*) evPtr;
   }

   /* EventDM */
   if(dmPtr == NULL) {
      mgAsnSkipElmnt(msgCp);    
   } else {
      msgCp->evntStr = (TknU8*) dmPtr;
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) {RETVALUE(ret); }
   }

   /* SignalsDescriptor */
   if(sigPtr == NULL) {
      mgAsnSkipElmnt(msgCp);    
   } else {
      msgCp->evntStr = (TknU8*) sigPtr;
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) {RETVALUE(ret); }
   }
      
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncSecondRequestedActionsDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncSecondRequestedActionsDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncSecondRequestedActionsDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoEvtParSecLst* evPtr;
   MgMgcoEvtParSec* newPar;
   MsgLen               elmntLen;       /* element length */
   MsgLen               prevLen;        /* previous length */

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncSecondRequestedActionsDec);
   evPtr = (MgMgcoEvtParSecLst*)msgCp->evntStr;
   elmntLen = msgCp->elmntLen;
   ++msgCp->elmntDef;

   /* Keep Active */
   prevLen = mgAsnFindLen(msgCp);
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(newPar), (sizeof(MgMgcoEvtParSec))) != ROK) { RETVALUE(RFAILED); }
   (void)cmMemset((U8*)newPar, 0, sizeof(MgMgcoEvtParSec));
   msgCp->evntStr = (TknU8*) (newPar);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) {RETVALUE(ret); }
   if(newPar->type.pres) {
      newPar->type.val = MGT_EVTPAR_KEEPACTIVE;
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->parms), &(evPtr->num), (Ptr*)&(newPar), 1)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newPar)) != ROK) { RETVALUE(ret); }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }
   
   /* eventDM */
   prevLen = mgAsnFindLen(msgCp);
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(newPar), (sizeof(MgMgcoEvtParSec))) != ROK) { RETVALUE(RFAILED); }
   (void)cmMemset((U8*)newPar, 0, sizeof(MgMgcoEvtParSec));
   msgCp->evntStr = (TknU8*) &(newPar->u.dm);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) {RETVALUE(ret); }
   if(newPar->u.dm.type.pres) {
      newPar->type.pres = PRSNT_NODEF;
      newPar->type.val = MGT_EVTPAR_DIGMAP;
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->parms), &(evPtr->num), (Ptr*)&(newPar), 1)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newPar)) != ROK) { RETVALUE(ret); }
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) {
      if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK) { RETVALUE(ret); }
      MGAFUNCSKIP(msgCp);
      RETVALUE(ROK);
   }

   /* Signals Descriptor */
   if (mgAsnDecGetMem(msgCp, (Ptr*)&(newPar), (sizeof(MgMgcoEvtParSec))) != ROK) { RETVALUE(RFAILED); }
   (void)cmMemset((U8*)newPar, 0, sizeof(MgMgcoEvtParSec));
   msgCp->evntStr = (TknU8*) &(newPar->u.embSig);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) {RETVALUE(ret); }
   if(newPar->u.embSig.pres.pres) {
      newPar->type.pres = PRSNT_NODEF;
      newPar->type.val = MGT_EVTPAR_EMBEDSIG;
      if((ret = mgAsnDecListAdd(msgCp, (Ptr**)&(evPtr->parms), &(evPtr->num), (Ptr*)&(newPar), 1)) != ROK) {
         RETVALUE(ret);
      }
   } else {
      if ((ret = mgAsnDecPutMem(msgCp, (Ptr)newPar)) != ROK) { RETVALUE(ret); }
   }
   
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}

#ifdef MGT_MGCO_V2
/*
*
*       Fun:   mgaFuncIndAudMediaDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudMediaDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudMediaDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret = ROK;
   MgMgcoIndAudMediaParm* evPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudMediaDescriptorEnc);

   /* Maps from MgMgcoIndAudMediaParm. Choice -> seq.
    * The ABNF does not support multiple prop audits, but will in V3.
    */
   evPtr = (MgMgcoIndAudMediaParm*) (msgCp->evntStr);
   if(evPtr->type.pres)
   {
      switch(evPtr->type.val)
      {
         case MGT_MEDIAPAR_LOCCTL:
         case MGT_MEDIAPAR_STRPAR:
            /* skip termStateDesc */
            ++msgCp->elmntDef;
            mgAsnSkipElmnt(msgCp);
            /* mg008.105: empty Indmedia descriptor */
            if(evPtr->u.streamParm.type.pres)
            {
               /* call child element  to encode onestream or multistream*/
               msgCp->evntStr = (TknU8*) evPtr;
               if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
            }
            break;
         case MGT_MEDIAPAR_TERMST:
            /* encode termStateDesc */
            msgCp->evntStr = (TknU8*) &(evPtr->u.termStateDesc);
            if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
            /* skip streamsIndAud */
            mgAsnSkipElmnt(msgCp);
            break;
      }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudMediaDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudMediaDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudMediaDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoIndAudMediaParm* evPtr;
   MsgLen               elmntLen;       /* element length */
   MsgLen               prevLen;        /* previous length */


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudMediaDescriptorDec);
   elmntLen = msgCp->elmntLen;


   prevLen = mgAsnFindLen(msgCp);
   evPtr = (MgMgcoIndAudMediaParm*) (msgCp->evntStr);
   /* decode termination state */
   msgCp->evntStr = (TknU8*) &(evPtr->u.termStateDesc);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(evPtr->u.termStateDesc.type.pres) {
      /* We got our choice */
      evPtr->type.val = MGT_MEDIAPAR_TERMST; 
      evPtr->type.pres = PRSNT_NODEF;
   } else {
      elmntLen -= prevLen - mgAsnFindLen(msgCp);
      if (elmntLen <= 0) { RETVALUE(mgAsnChkSeqMandMis(msgCp)); }

      /* We know it's the streamsIndAud, which is a choice */
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
      
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudTerminationStateDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudTerminationStateDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudTerminationStateDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoIndAudTermStateDesc* evPtr;
   MgMgcaEventBufferControlIndAud val1;
   MgMgcaServiceStateIndAud val2;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudTerminationStateDescriptorEnc);

   /* Maps from MgMgcoIndAudTermStateDesc.  
    * No pres over there.
    */
   evPtr = (MgMgcoIndAudTermStateDesc*) (msgCp->evntStr);
   if(evPtr->type.pres == PRSNT_NODEF) {
      switch( evPtr->type.val ) {
      case MGT_TERMST_EVTBUFCTL:
         /* skip property parms */
         mgAsnSkipElmnt(msgCp);
         /* do eventBufferControlIndAud */
         (void)cmMemset((U8*)&val1, 0, sizeof(val1));
         val1.pres = PRSNT_NODEF;
         val1.val = 1;
         msgCp->evntStr = (TknU8*) &val1;
         if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
         /* skip serviceStateIndAud */
         mgAsnSkipElmnt(msgCp);
         break;
      case MGT_TERMST_SVCST:
         /* skip property parms and eventBufferControlIndAud*/
         mgAsnSkipElmnt(msgCp);
         mgAsnSkipElmnt(msgCp);
         /* do serviceStateIndAud */
         (void)cmMemset((U8*)&val2, 0, sizeof(val2));
         val2.pres = PRSNT_NODEF;
         val2.val = 1;
         msgCp->evntStr = (TknU8*) &val2;
         if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
         break;
      case MGT_TERMST_PROPLST:
         /* do propertyParmsIndAud */
         msgCp->evntStr = (TknU8*) evPtr;
         if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
         /* skip eventBufferControlIndAud and serviceStateIndAud */
         mgAsnSkipElmnt(msgCp);
         mgAsnSkipElmnt(msgCp);
      default:
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
         RETVALUE(RFAILED);
      }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudTerminationStateDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudTerminationStateDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudTerminationStateDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknU8 val;
   MgMgcoIndAudTermStateDesc* evPtr;
   MsgLen               elmntLen;       /* element length */
   MsgLen               prevLen;        /* previous length */

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudTerminationStateDescriptorDec);
   elmntLen = msgCp->elmntLen;

   evPtr = (MgMgcoIndAudTermStateDesc*) (msgCp->evntStr);

   /* Decode the optional propertyParmsIndAud  - a list */
   prevLen = mgAsnFindLen(msgCp);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) { RETVALUE(mgAsnChkSeqMandMis(msgCp)); }

   prevLen = mgAsnFindLen(msgCp);
   /* decode optional event buffer control */
   (void)cmMemset((U8*)&val, 0, sizeof(val));
   msgCp->evntStr = (TknU8*) &val;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(val.pres == PRSNT_NODEF) {
      evPtr->type.pres = PRSNT_NODEF;
      evPtr->type.val = MGT_TERMST_EVTBUFCTL;
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) { RETVALUE(mgAsnChkSeqMandMis(msgCp)); }

   /* decode optional serviceStateIndAud */
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(val.pres == PRSNT_NODEF) {
      evPtr->type.pres = PRSNT_NODEF;
      evPtr->type.val = MGT_TERMST_SVCST;
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMultiStreamIndAudEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMultiStreamIndAudEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMultiStreamIndAudEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoIndAudStreamDesc* evPtr;
   MgMgcaMultiStreamIndAud listVal;
   MgMgcaIndAudStreamDescriptor* valPtr;
   
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncMultiStreamIndAudEnc);

   /* Need to encode a list (of 1) from the sequence passed in
    */
   evPtr= (MgMgcoIndAudStreamDesc*) (msgCp->evntStr);
   (void)cmMemset((U8*)&listVal, 0, sizeof(listVal));
   if(evPtr->streamId.pres) {
      /* the pres field is "supposed to be" a num */
      listVal.pres.pres = PRSNT_NODEF;
      listVal.pres.val = 1;
      /* hack */
      valPtr = (MgMgcaIndAudStreamDescriptor*) (evPtr);
      listVal.multiStream = &valPtr;
      msgCp->evntStr = (TknU8*) &listVal;
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
      
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMultiStreamIndAudDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMultiStreamIndAudDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMultiStreamIndAudDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncMultiStreamIndAudDec);

   /* the reverse hack is to just bypass the "list" part
    * of the ASN encoded buffer, and get to the one item
    * element of the list
    */
   ++msgCp->elmntDef;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncPropertyParmsIndAudEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncPropertyParmsIndAudEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncPropertyParmsIndAudEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;

   MgMgcoIndAudTermStateDesc* evPtr;
   MgMgcaPropertyParmsIndAud val;
   MgMgcaIndAudPropertyParm* valPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncPropertyParmsIndAudEnc);

   evPtr = (MgMgcoIndAudTermStateDesc*) (msgCp->evntStr);
   if(evPtr->type.pres == PRSNT_NODEF) {
      if(evPtr->type.val != MGT_TERMST_PROPLST) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
         RETVALUE(RFAILED);
      }
      /* We have a list, but ABNF side will have 1 item (until V3) */
      (void)cmMemset((U8*)&val, 0, sizeof(val));
      if(evPtr->pkg.pres == 1) {
         val.pres.pres = PRSNT_NODEF;
         val.pres.val = 1;
         /* hack */
         valPtr = (MgMgcaIndAudPropertyParm*) &(evPtr->pkg);
         val.propertyParmsIndAud = &valPtr;
         msgCp->evntStr = (TknU8*) &val;
         if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      }
   }
   
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncPropertyParmsIndAudDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncPropertyParmsIndAudDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncPropertyParmsIndAudDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncPropertyParmsIndAudDec);

   /* the decode hack is to just bypass the "list" part
    * of the ASN encoded buffer, and get to the one item
    * element of the list
    */
   ++msgCp->elmntDef;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudStatisticsDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudStatisticsDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudStatisticsDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoIndAudStatistics *evPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudStatisticsDescriptorEnc);
   evPtr = (MgMgcoIndAudStatistics*) (msgCp->evntStr);
   ++msgCp->elmntDef;

   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      msgCp->secElmntDef = (MgAsnElmntDef**)mgaPkgStatistics[evPtr->pkg.val - 1];
   } 

   /* No pres on mgco side; pointers are all lined up
    */
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudStatisticsDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudStatisticsDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudStatisticsDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoIndAudStatistics* evPtr;
   MgaPkg* pkgName;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudStatisticsDescriptorDec);
   evPtr = (MgMgcoIndAudStatistics*) (msgCp->evntStr);
   ++msgCp->elmntDef;

   /* Pres was used to set pkg.pres.  Reset it and decode.  */
   evPtr->pkg.pres = NOTPRSNT;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      /* validate the name */
      pkgName = mgaPkgStatistics[evPtr->pkg.val - 1];
      if(pkgName != NULLP) {
         if( (evPtr->name.name.type.pres == PRSNT_NODEF) &&
            (evPtr->name.name.type.val == MGT_GEN_TYPE_KNOWN) &&
            (evPtr->name.name.u.val.val > 0) && 
            (evPtr->name.name.u.val.val <= pkgName->maxNumNames) )
         {
            if(pkgName->names[evPtr->name.name.u.val.val-1] == NULLP)
            {
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(RFAILED);
            }
         } else {
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
            RETVALUE(RFAILED);
         }
      }
   }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudSeqSigListEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudSeqSigListEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudSeqSigListEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudSeqSigListEnc);

   /* No pres on Mgco side
    */
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudSeqSigListDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudSeqSigListDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudSeqSigListDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoIndAudSigLst* evPtr;
   MgAsnElmntDef* elmntDef;

   TRC2(mgaFuncIndAudSeqSigListDec);
   elmntDef = *msgCp->elmntDef;
   if (elmntDef->idNum == gcMsgIdNum.idNum) {
      /* Pres was used to set sigLstId.  Reset it and decode */
      evPtr = (MgMgcoIndAudSigLst*) (msgCp->evntStr);
      evPtr->sigLstId.pres = NOTPRSNT;
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if (elmntDef->idNum == gcMsgIndAudSignalO.idNum) {
      /* Signal Name */
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
   }
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudSignalEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudSignalEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudSignalEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoSigName *evPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudSignalEnc);
   evPtr = (MgMgcoSigName*)msgCp->evntStr;
   ++msgCp->elmntDef;

   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      msgCp->secElmntDef = (MgAsnElmntDef**)mgaPkgSignals[evPtr->pkg.val - 1];
   } else if(evPtr->pkg.val == 0) {
      /* allow it, but it's not defined */
      msgCp->secElmntDef = NULLP;
   }
   /* No pres over there, and no streamid */
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudSignalDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudSignalDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudSignalDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoSigName* evPtr;
   MgaPkg* pkgName;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudSignalDec);
   evPtr = (MgMgcoSigName*) (msgCp->evntStr);
   ++msgCp->elmntDef;

   /* No pres or streamID over there */
   evPtr->pkg.pres = NOTPRSNT;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      /* validate the name */
      pkgName = mgaPkgSignals[evPtr->pkg.val - 1];
      if(pkgName != NULLP) {
         if( (evPtr->name.name.type.pres == PRSNT_NODEF) &&
            (evPtr->name.name.type.val == MGT_GEN_TYPE_KNOWN) &&
            (evPtr->name.name.u.val.val > 0) && 
            (evPtr->name.name.u.val.val <= pkgName->maxNumNames) )
         {
            if(pkgName->names[evPtr->name.name.u.val.val-1] == NULLP)
            {
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(RFAILED);
            }
         } else {
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
            RETVALUE(RFAILED);
         }
      }
   }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudEventBufferDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudEventBufferDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudEventBufferDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoIndAudEventBuffer* evPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudEventBufferDescriptorEnc);
   evPtr = (MgMgcoIndAudEventBuffer*) (msgCp->evntStr);
   ++msgCp->elmntDef;

   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      msgCp->secElmntDef = (MgAsnElmntDef**)mgaPkgObsEvts[evPtr->pkg.val - 1];
   } else if(evPtr->pkg.val == 0) {
      /* allow it, but it's not defined */
      msgCp->secElmntDef = NULLP;
   }
   /* No pres over there, look through evSpecParm for streamid
    */
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if( (evPtr->evSpecParm.type.pres) && (evPtr->evSpecParm.type.val == MGT_EVTPAR_STREAMID) ) {
      msgCp->evntStr = (TknU8*) &(evPtr->evSpecParm.u.evStream);
   }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudEventBufferDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudEventBufferDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudEventBufferDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoIndAudEventBuffer* evPtr;
   MgAsnElmntDef *elmntDef;
   MgaPkg* pkgName;

   TRC2(mgaFuncIndAudEventBufferDescriptorDec);
   evPtr = (MgMgcoIndAudEventBuffer*) (msgCp->evntStr);
   elmntDef = *msgCp->elmntDef;

   if (elmntDef->idNum == gcMsgPkgdName0.idNum) {
      /* pkg and name */
      evPtr->pkg.pres = NOTPRSNT; /* No pres over there */
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      /* Error check the package id */
      if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
         /* validate the name */
         pkgName = mgaPkgObsEvts[evPtr->pkg.val - 1];
         if(pkgName != NULLP) {
            if( (evPtr->name.name.type.pres == PRSNT_NODEF) &&
               (evPtr->name.name.type.val == MGT_GEN_TYPE_KNOWN) &&
               (evPtr->name.name.u.val.val > 0) && 
               (evPtr->name.name.u.val.val <= pkgName->maxNumNames) )
            {
               if(pkgName->names[evPtr->name.name.u.val.val-1] == NULLP)
               {
                  MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
                  RETVALUE(RFAILED);
               }
            } else {
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(RFAILED);
            }
         }
      }
      msgCp->evntStr = (TknU8*)evPtr; /* reset for next */
   } else if (elmntDef->idNum == gcMsgStreamIDO1.idNum) {
      /* optional stream id */
      msgCp->evntStr = (TknU8*) &(evPtr->evSpecParm.u.evStream);
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      if( evPtr->evSpecParm.u.evStream.pres) {
         evPtr->evSpecParm.type.pres = PRSNT_NODEF;
         evPtr->evSpecParm.type.val = MGT_EVTPAR_STREAMID;
      }
   } else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
   }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;
   
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudEventsDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudEventsDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudEventsDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoIndAudEvents *evPtr;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudEventsDescriptorEnc);
   evPtr = (MgMgcoIndAudEvents*)msgCp->evntStr;

   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      msgCp->secElmntDef = (MgAsnElmntDef**)mgaPkgObsEvts[evPtr->pkg.val - 1];
   } 
   /* There's no streamid on mgco side, so just step through
    * the other elements
    */
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudEventsDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudEventsDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudEventsDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgAsnElmntDef *elmntDef;
   MgMgcoIndAudEvents *evPtr;
   MgaPkg* pkgName;

   TRC2(mgaFuncIndAudEventsDescriptorDec);
   evPtr = (MgMgcoIndAudEvents*)msgCp->evntStr;
   elmntDef = *msgCp->elmntDef;

   if (elmntDef->idNum == gcMsgRequestID.idNum) {
      /* requestId */
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if (elmntDef->idNum == gcMsgPkgdName1.idNum) {
      /* pkg & name */
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      /* Error check the package id */
      if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
         /* validate the name */
         pkgName = mgaPkgObsEvts[evPtr->pkg.val - 1];
         if(pkgName != NULLP) {
            if( (evPtr->name.name.type.pres == PRSNT_NODEF) &&
               (evPtr->name.name.type.val == MGT_GEN_TYPE_KNOWN) &&
               (evPtr->name.name.u.val.val > 0) && 
               (evPtr->name.name.u.val.val <= pkgName->maxNumNames) )
            {
               if(pkgName->names[evPtr->name.name.u.val.val-1] == NULLP)
               {
                  MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
                  RETVALUE(RFAILED);
               }
            } else {
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(RFAILED);
            }
         }
      }
   } else if (elmntDef->idNum == gcMsgStreamIDO2.idNum) {
      /* streamID - not supported on ABNF side */
      mgAsnSkipElmnt(msgCp);
   } else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
   }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudStreamParmsEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudStreamParmsEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudStreamParmsEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudStreamParmsEnc);
   ++msgCp->elmntDef;

   /*  Need to get this from MgMgcoIndAudStreamParm
    *  No pres over there
    *  Will only ever be LocalControlDescriptor, based on
    *  capabilities of ABNF
    */
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   /* local & remote */
   mgAsnSkipElmnt(msgCp);
   mgAsnSkipElmnt(msgCp);

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudStreamParmsDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudStreamParmsDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudStreamParmsDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudStreamParmsDec);
   /* Just decode the first element, LocalControlDesc, 
    * because ABNF doesn't support/have data for other
    * 2 elements until V3
    */
   ++msgCp->elmntDef;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudLocalControlDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudLocalControlDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudLocalControlDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoIndAudStreamParm* evPtr;
   TknU8 val;  /* used for streamMode, reserveVal, reserveGrp */

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudLocalControlDescriptorEnc);

   evPtr = (MgMgcoIndAudStreamParm*) (msgCp->evntStr);
   if(evPtr->type.pres == PRSNT_NODEF) {
      switch(evPtr->type.val) {
      case MGT_LCLCTL_MODE:
         (void)cmMemset((U8*)&val, 0, sizeof(val));
         val.pres = PRSNT_NODEF;
         val.val = 1;
         msgCp->evntStr = &val;
         if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
         mgAsnSkipElmnt(msgCp);    /* reserveValue */
         mgAsnSkipElmnt(msgCp);    /* reserveGroup */
         mgAsnSkipElmnt(msgCp);    /* propertyParms */
         break;
      case MGT_LCLCTL_RESVAL:
         mgAsnSkipElmnt(msgCp);    /* streamMode */
         (void)cmMemset((U8*)&val, 0, sizeof(val));
         val.pres = PRSNT_NODEF;
         val.val = 1;
         msgCp->evntStr = &val;
         if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
         mgAsnSkipElmnt(msgCp);    /* reserveGroup */
         mgAsnSkipElmnt(msgCp);    /* propertyParms */
         break;
      case MGT_LCLCTL_RESGRP:
         mgAsnSkipElmnt(msgCp);    /* streamMode */
         mgAsnSkipElmnt(msgCp);    /* reserveValue */
         (void)cmMemset((U8*)&val, 0, sizeof(val));
         val.pres = PRSNT_NODEF;
         val.val = 1;
         msgCp->evntStr = &val;
         if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
         mgAsnSkipElmnt(msgCp);    /* propertyParms */
         break;
      case MGT_LCLCTL_PROPPARM:
         mgAsnSkipElmnt(msgCp);    /* streamMode */
         mgAsnSkipElmnt(msgCp);    /* reserveValue */
         mgAsnSkipElmnt(msgCp);    /* reserveGroup */
         msgCp->evntStr = (TknU8*) evPtr;
         if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudLocalControlDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudLocalControlDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudLocalControlDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknU8 val;
   MgMgcoIndAudStreamParm* evPtr;
   MsgLen               elmntLen;       /* element length */
   MsgLen               prevLen;        /* previous length */

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudLocalControlDescriptorDec);
   evPtr = (MgMgcoIndAudStreamParm*) (msgCp->evntStr);
   elmntLen = msgCp->elmntLen;

   (void)cmMemset((U8*)&val, 0, sizeof(val));
   /* StreamModIndAud */
   prevLen = mgAsnFindLen(msgCp);
   msgCp->evntStr = (TknU8*) &val;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(val.pres == PRSNT_NODEF) {
      evPtr->type.pres = PRSNT_NODEF;
      evPtr->type.val = MGT_LCLCTL_MODE;
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) { RETVALUE(mgAsnChkSeqMandMis(msgCp)); }

   /* ReserveValueIndAud */
   prevLen = mgAsnFindLen(msgCp);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(val.pres == PRSNT_NODEF) {
      evPtr->type.pres = PRSNT_NODEF;
      evPtr->type.val = MGT_LCLCTL_RESVAL;
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) { RETVALUE(mgAsnChkSeqMandMis(msgCp)); }

   /* ReserveGroupIndAud */
   prevLen = mgAsnFindLen(msgCp);
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(val.pres == PRSNT_NODEF) {
      evPtr->type.pres = PRSNT_NODEF;
      evPtr->type.val = MGT_LCLCTL_RESGRP;
   }
   elmntLen -= prevLen - mgAsnFindLen(msgCp);
   if (elmntLen <= 0) { RETVALUE(mgAsnChkSeqMandMis(msgCp)); }
   
   /* PropertyParmsIndAud */
   msgCp->evntStr = (TknU8*) evPtr;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudPropertyParmEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudPropertyParmEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudPropertyParmEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoIndAudTermStateDesc* evPtr; 

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudPropertyParmEnc);
   evPtr = (MgMgcoIndAudTermStateDesc*) (msgCp->evntStr);
   ++msgCp->elmntDef;

   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      msgCp->secElmntDef = (MgAsnElmntDef**)mgaPkgProperties[evPtr->pkg.val - 1];
   } else if(evPtr->pkg.val == 0) {
      /* allow it, but it's not defined */
      msgCp->secElmntDef = NULLP;
   }

   /* No pres over there, but there is a type that is 
    * skipped.  
    */
   msgCp->evntStr = (TknU8*) &(evPtr->pkg);
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;
   
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudPropertyParmDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudPropertyParmDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudPropertyParmDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoIndAudStreamParm* evPtr;
   MgaPkg* pkgName;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudPropertyParmDec);
   ++msgCp->elmntDef;
   evPtr = (MgMgcoIndAudStreamParm*) (msgCp->evntStr);
   msgCp->evntStr = (TknU8*)&(evPtr->pkg);

   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   /* Error check the package id */
   if ((evPtr->pkg.val < MGA_MAXPKGID) && (evPtr->pkg.val >= 1)) {
      /* validate the name */
      pkgName = mgaPkgProperties[evPtr->pkg.val - 1];
      if(pkgName != NULLP) {
         if( (evPtr->name.name.type.pres == PRSNT_NODEF) &&
            (evPtr->name.name.type.val == MGT_GEN_TYPE_KNOWN) &&
            (evPtr->name.name.u.val.val > 0) && 
            (evPtr->name.name.u.val.val <= pkgName->maxNumNames) )
         {
            if(pkgName->names[evPtr->name.name.u.val.val-1] == NULLP)
            {
               MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
               RETVALUE(RFAILED);
            }
         } else {
            MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
            RETVALUE(RFAILED);
         }
      }
   }
   msgCp->secElmntDef = (MgAsnElmntDef**)NULLP;
   
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudStreamDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudStreamDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudStreamDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudStreamDescriptorEnc);

   /* No pres over there
    */
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudStreamDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudStreamDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudStreamDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoIndAudStreamDesc* evPtr;
   MgAsnElmntDef *elmntDef;

   TRC2(mgaFuncIndAudStreamDescriptorDec);
   elmntDef = *msgCp->elmntDef;

   /* Pres was used to set streamId.  Reset it and decode */
   if (elmntDef->idNum == gcMsgStreamID.idNum) {
      /* Stream Id */
      evPtr = (MgMgcoIndAudStreamDesc*) (msgCp->evntStr);
      evPtr->streamId.pres = NOTPRSNT;
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if (elmntDef->idNum == gcMsgIndAudStreamParms1.idNum) {
      /* StreamParm */
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
   }

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudDigitMapDescriptorEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudDigitMapDescriptorEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudDigitMapDescriptorEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;

   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncIndAudDigitMapDescriptorEnc);

   /* No pres over there
    */
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   
   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncIndAudDigitMapDescriptorDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncIndAudDigitMapDescriptorDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncIndAudDigitMapDescriptorDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgAsnElmntDef *elmntDef;
   MgMgcoName* evPtr;

   TRC2(mgaFuncIndAudDigitMapDescriptorDec);
   elmntDef = *msgCp->elmntDef;

   /* Pres was used to set type.  Reset it and decode */
   if (elmntDef->idNum == gcMsgDigitMapNameO.idNum) {
      evPtr = (MgMgcoName*) (msgCp->evntStr);
      evPtr->type.pres = NOTPRSNT;
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
   }

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMsgAuditDescriptorOV2Enc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncAuditDescriptorOV2Enc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncAuditDescriptorOV2Enc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcaAuditToken auditToken;
   MgMgcoAuditItem* evPtr;

   /*
    * When used in ServiceChangeParm, ASN.1 AuditDescriptor
    * maps directly to ABNF's AuditItem. 
    */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncAuditDescriptorOV2Enc);

   /*
    * No pres over there.
    */
   evPtr = (MgMgcoAuditItem*) (msgCp->evntStr);
   /* auditToken */
   if(evPtr->auditItem.pres == PRSNT_NODEF) {
      (void)cmMemset((U8*)&auditToken, '0', sizeof(auditToken));
      switch(evPtr->auditItem.val) {
         case MGT_MEDIADESC:
            auditToken.val[0] |= 1<<2; break;
         case MGT_MODEMDESC:
            auditToken.val[0] |= 1<<1; break;
         case MGT_MUXDESC:
            auditToken.val[0] |= 1; break;
         case MGT_REQEVTDESC:
            auditToken.val[0] |= 1<<3; break;
         case MGT_EVBUFDESC:
            auditToken.val[1] |= 1<<1; break;
         case MGT_SIGNALSDESC:
            auditToken.val[0] |= 1<<4; break;
         case MGT_DIGMAPDESC:
            auditToken.val[0] |= 1<<5; break;
         case MGT_OBSEVTDESC:
            auditToken.val[0] |= 1<<7; break;
         case MGT_STATSDESC:
            auditToken.val[0] |= 1<<6; break;
         case MGT_PKGSDESC:
            auditToken.val[1] |= 1; break;
         case MGT_INDAUD_TERMAUDDESC: /* the termAudit should be set */
            break;
         case MGT_AUDITDESC: /* Not defined */
         case MGT_ERRDESC: /* Not defined */
         default:
            MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
            RETVALUE(RFAILED);
      }
      msgCp->evntStr = (TknU8*) &auditToken;
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }
   /* parms */
   msgCp->evntStr = (TknU8*) &evPtr->termAudit;
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}

/*
*
*       Fun:   mgaFuncMsgAuditDescriptorOV2Dec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncAuditDescriptorOV2Dec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncAuditDescriptorOV2Dec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoAuditItem* evPtr;
   MgMgcaAuditToken auditToken;

   /*
    * When used in ServiceChangeParm, ASN.1 AuditDescriptor
    * maps directly to ABNF's AuditItem. 
    */
   TRC2(mgaFuncAuditDescriptorOV2Dec);
   evPtr = (MgMgcoAuditItem*) (msgCp->evntStr);

   /* Pres was used to set auditItem.pres.  Reset it and decode.  */
   evPtr->auditItem.pres = NOTPRSNT;
   (void)cmMemset((U8*)&auditToken, '0', sizeof(auditToken));
   msgCp->evntStr = (TknU8*) &auditToken;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(auditToken.pres == PRSNT_NODEF) {
      /* check length */
      if ((auditToken.len != 1) && (auditToken.len != 2)) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
         RETVALUE(RFAILED);
      }
      evPtr->auditItem.pres = PRSNT_NODEF;
      /* Since this goes to one AuditItem, only one bit should be set */
      if( auditToken.val[0] & ( 1 ) ) {
         evPtr->auditItem.val = MGT_MUXDESC;
      } else if( auditToken.val[0] & ( 1<<1 ) ) {
         evPtr->auditItem.val = MGT_MODEMDESC;
      } else if( auditToken.val[0] & ( 1<<2 ) ) {
         evPtr->auditItem.val = MGT_MEDIADESC;
      } else if( auditToken.val[0] & ( 1<<3 ) ) {
         evPtr->auditItem.val = MGT_REQEVTDESC;
      } else if( auditToken.val[0] & ( 1<<4 ) ) {
         evPtr->auditItem.val = MGT_SIGNALSDESC;
      } else if( auditToken.val[0] & ( 1<<5 ) ) {
         evPtr->auditItem.val = MGT_DIGMAPDESC;
      } else if( auditToken.val[0] & ( 1<<6 ) ) {
         evPtr->auditItem.val = MGT_STATSDESC;
      } else if( auditToken.val[0] & ( 1<<7 ) ) {
         evPtr->auditItem.val = MGT_OBSEVTDESC;
      } else if( auditToken.val[1] & (1) ) {
         evPtr->auditItem.val = MGT_PKGSDESC;
      } else if(auditToken.val[1] & ( 1<<1 ) ) {
         evPtr->auditItem.val = MGT_EVBUFDESC;
      } else {
         evPtr->auditItem.pres = NOTPRSNT;
      }
   }
   /* parms */
   msgCp->evntStr = (TknU8*) &evPtr->termAudit;
   if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   if(evPtr->termAudit.num.pres == PRSNT_NODEF) {
      evPtr->auditItem.val = MGT_INDAUD_TERMAUDDESC;
      evPtr->auditItem.pres = PRSNT_NODEF;
   }

   RETVALUE(ret);
}


#endif   /* MGT_MGCO_V2 */


/*
*
*       Fun:   mgaFuncPropertyGroupEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncPropertyGroupEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncPropertyGroupEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16            ret;
   MgMgcoPropParmLst* propParmLst;
/*   MgMgcoPropParm propParm;*/
   MgAsnElmntDef**   elmntDef;
   MgAsnElmntDef   **startDef;     /* element definition for seq/set start */
   U16          count;          /* element repeat counter */
   U16          nmbEnc;         /* minimum elements that need to be encoded */   
#ifdef CM_SDP_OPAQUE
   U16             found;           
   S8           *startPtr;
   S8           *ptr;
#else
/*   CmSdpInfo      *sdpPtr;
   S16            j;
   S16            k;*/
#endif


   /* Initialize */
   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncPropertyGroupEnc);
   startDef = msgCp->elmntDef;
   elmntDef = ++msgCp->elmntDef;

   /* Set up the property parm */
   /* mg004.105: Removed SDP which will support through Annex C */
   propParmLst = (MgMgcoPropParmLst*)(msgCp->evntStr);
   count = propParmLst->num.val;
   nmbEnc = 0;
   while(count)
   {
      msgCp->elmntDef = startDef;
      msgCp->evntStr = (TknU8*)(propParmLst->parms[nmbEnc]);
      msgCp->elmntDef++;
      /* encode the element depending on the element type */
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK)
      {
         RETVALUE(ret);
      }
      nmbEnc++;

      /* decrement count */
      count--;
   }
   msgCp->secElmntDef = NULLP;

   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncPropertyGroupDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncPropertyGroupDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncPropertyGroupDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoPropParmLst* propParmLst;
   TknU8*           saveSecEvntStr;
#ifdef CM_SDP_OPAQUE
   S8 *prefixes[] = {"v=", "o=", "s=", "i=", "u=", "e=", "p=", "c=", "b=", "z=", "k=", "a=", "t=", "r=", "m="};
   TknBuf         *sdpPtr;
#endif


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncPropertyGroupDec);
   saveSecEvntStr = (TknU8*) msgCp->secEvntStr;
#ifdef CM_SDP_OPAQUE
   sdpPtr = (TknBuf*)msgCp->secEvntStr;
#else
   msgCp->secEvntStr = msgCp->evntStr;
#endif

/*   msgCp->evntStr = (TknU8*)&propParmLst;*/
   propParmLst = (MgMgcoPropParmLst*)(msgCp->evntStr);
   /*msgCp->secElmntDef =  (MgAsnElmntDef**)&MgaPkgSDP;*/
   if ((ret = mgAsnDecUnconsSetSeqOf(msgCp)) != ROK) { RETVALUE(ret); }
   msgCp->secElmntDef = NULLP;
   /* msgCp->secEvntStr = NULLP; */
/*
#ifdef CM_SDP_OPAQUE
   if ((sdpPtr == NULLP) || (sdpPtr->val == NULLP)) {
      if ((ret = SGetMsg(msgCp->region, msgCp->pool, &sdpPtr->val)) != ROK) {
         MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
         RETVALUE(ret);
      }
   }

   for (j=0; j<propParmLst.num.val; ++j) {
      if ((propParmLst.parms[j]->name.name.u.val.val < VALUE_SDP_V) ||
          (propParmLst.parms[j]->name.name.u.val.val > VALUE_SDP_M)) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
         RETVALUE(RFAILED);
      }
      if (SAddPstMsgMult((U8*)prefixes[propParmLst.parms[j]->name.name.u.val.val-1], 2, sdpPtr->val) != ROK) {
         MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
         RETVALUE(RFAILED);
      }
      if (SAddPstMsgMult(propParmLst.parms[j]->val.u.eq.u.osxl.val, propParmLst.parms[j]->val.u.eq.u.osxl.len, sdpPtr->val) != ROK) {
         MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
         RETVALUE(RFAILED);
      }
      if (SAddPstMsgMult((U8*)"\n", 1, sdpPtr->val) != ROK) {
         MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
         RETVALUE(RFAILED);
      }
   }
#endif
*/

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMIdSpecialEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMIdSpecialEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMIdSpecialEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknStrOSXL*   evPtr;
   CmMemListCp   *abnfEvnt;
   CmAbnfErr     abnfErr;
   CmAbnfDecOff  bufOff;
   MsgLen        numDecBytes;
   Buffer        *mBuf;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncMIdSpecialEnc);
   evPtr = (TknStrOSXL*)msgCp->evntStr;
   (void)cmMemset((U8*)&abnfErr, 0, sizeof(abnfErr));
   (void)cmMemset((U8*)&bufOff, 0, sizeof(bufOff));

   /* create a message */
   if ((ret = SGetMsg(msgCp->region, msgCp->pool, &mBuf)) != ROK) {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(ret);
   }

   /* add the string */
   if ((ret = SAddPstMsgMult(evPtr->val, evPtr->len, mBuf)) != ROK) {
      SPutMsg(mBuf);
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }

   /* create event */
   if ((ret = cmAllocEvnt((sizeof(MgMgcoMid)+sizeof(CmMemListCp)), 1024, &(msgCp->memCp->memCb.sMem), (Ptr*)&abnfEvnt)) != ROK) {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      SPutMsg(mBuf);
      RETVALUE(ret);
   }

   /* decode abnf into an event */
   if ((ret = cmAbnfDecPduMsg(CM_ABNF_PROT_MEGACO_H248, abnfEvnt, (U8*)((long)abnfEvnt+(long)sizeof(CmMemListCp)), (Buffer*)mBuf, &mgMgcoMIDDef, &numDecBytes, &bufOff, &abnfErr)) != ROK) {
      S8 errBuf[1024];
      mwrapErrPrint(&abnfErr, errBuf);
      SPutMsg(mBuf);
      cmFreeMem(abnfEvnt);
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }
   SPutMsg(mBuf);

   /* encode */
   msgCp->evntStr = (TknU8*)((long)abnfEvnt + (long)sizeof(CmMemListCp));
   ret = mgaFuncMIdEnc(msgCp);
   MGAFUNCSKIP(msgCp);
   cmFreeMem(abnfEvnt);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMIdSpecialDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMIdSpecialDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMIdSpecialDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknStrOSXL*   evPtr;
   MgMgcoMid     mid;
   CmAbnfErr     abnfErr;
   CmAbnfDecOff  bufOff;
   Mem           memReg;
   Buffer        *mBuf;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncMIdSpecialDec);
   evPtr = (TknStrOSXL*)msgCp->evntStr;
   (void)cmMemset((U8*)&abnfErr, 0, sizeof(abnfErr));
   (void)cmMemset((U8*)&mid, 0, sizeof(mid));
   (void)cmMemset((U8*)&bufOff, 0, sizeof(bufOff));
   (void)cmMemset((U8*)&memReg, 0, sizeof(memReg));
   memReg.pool = msgCp->pool;
   memReg.region = msgCp->region;

   /* decode */
   msgCp->evntStr = (TknU8*)&mid;
   if ((ret = mgaFuncMIdDec(msgCp)) != ROK) { RETVALUE(ret); }

   /* get message buffer */
   if ((ret = SGetMsg(msgCp->region, msgCp->pool, &mBuf)) != ROK) {
      RETVALUE(ret);
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
   }

   /* encode to string */
   if ((ret = cmAbnfEncPduMsg(CM_ABNF_PROT_MEGACO_H248, (U8*)&mid, mBuf, &mgMgcoMIDDef, &memReg, &abnfErr)) != ROK) {
      S8 errBuf[1024];
      mwrapErrPrint(&abnfErr, errBuf);
      SPutMsg(mBuf);
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_MSG);
      RETVALUE(RFAILED);
   }

   /* get string length */
   if ((ret = SFndLenMsg(mBuf, (MsgLen*)&(evPtr->len))) != ROK) {
      SPutMsg(mBuf);
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(RFAILED);
   }

   /* get memory for val */
   if ((ret = mgAsnDecGetMem(msgCp, (Ptr*)&(evPtr->val), (MsgLen)(evPtr->len + 1))) != ROK) {
      SPutMsg(mBuf);
      RETVALUE(RFAILED);
   }
   cmMemset((U8 *)evPtr->val, 0, (evPtr->len+1));

   /* copy string */
   if ((ret = SRemPreMsgMult(evPtr->val, (MsgLen)evPtr->len, mBuf)) != ROK) {
      SPutMsg(mBuf);
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(RFAILED);
   }
   SPutMsg(mBuf);
   evPtr->pres = mid.type.pres;

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncNonStandardIdEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncNonStandardIdEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncNonStandardIdEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoNonStdId     tmpnsi;
   MgMgcoNonStdId     *evPtr;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncNonStandardIdEnc);
   /* NonStandardData doesn't exist for ABNF, so backspace */
   evPtr = (MgMgcoNonStdId*)msgCp->evntStr;
   (void)cmMemset((U8*)&tmpnsi, 0, sizeof(tmpnsi));

   /* prep */
   switch (evPtr->type.val) {
   case MGT_NONSTD_OBJID:
      tmpnsi.type.pres = evPtr->type.pres;
      tmpnsi.type.val = 1;
      (void)cmMemcpy((U8*)&(tmpnsi.u.objId), (U8*)&(evPtr->u.objId), sizeof(MgMgcoObjId));
      break;
   case MGT_NONSTD_H221:
      tmpnsi.type.pres = evPtr->type.pres;
      tmpnsi.type.val = 2;
      (void)cmMemcpy((U8*)&(tmpnsi.u.h221), (U8*)&(evPtr->u.h221), sizeof(MgMgcoH221NonStd));
      break;
   case MGT_EXTNPARM_MAND:
      tmpnsi.type.pres = evPtr->type.pres;
      tmpnsi.type.val = 3;
      tmpnsi.u.extn.pres = evPtr->type.pres;
      if ((evPtr->u.extn.len == 0) || (evPtr->u.extn.len > 6)) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
      }
      (void)cmMemcpy((U8*)tmpnsi.u.extn.val, (U8*)"X+", 2);
      (void)cmMemcpy((U8*)&(tmpnsi.u.extn.val[2]), (U8*)evPtr->u.extn.val, evPtr->u.extn.len);
      tmpnsi.u.extn.len = 2 + evPtr->u.extn.len;
      tmpnsi.u.extn.pres = PRSNT_NODEF;
      break;
   case MGT_EXTNPARM_OPT:
      tmpnsi.type.pres = evPtr->type.pres;
      tmpnsi.type.val = 3;
      if ((evPtr->u.extn.len == 0) || (evPtr->u.extn.len > 6)) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
      }
      (void)cmMemcpy((U8*)tmpnsi.u.extn.val, (U8*)"X-", 2);
      (void)cmMemcpy((U8*)&(tmpnsi.u.extn.val[2]), (U8*)evPtr->u.extn.val, evPtr->u.extn.len);
      tmpnsi.u.extn.len = 2 + evPtr->u.extn.len;
      tmpnsi.u.extn.pres = PRSNT_NODEF;
      break;
   default:
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }

   /* Encode */
   msgCp->evntStr = (TknU8*)&tmpnsi;
   ret = mgAsnEncChoice(msgCp);
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncNonStandardIdDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncNonStandardIdDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncNonStandardIdDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoNonStdId     tmpnsi;
   MgMgcoNonStdId     *evPtr;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncNonStandardIdEnc);
   evPtr = (MgMgcoNonStdId*)msgCp->evntStr;
   (void)cmMemset((U8*)&tmpnsi, 0, sizeof(tmpnsi));

   /* Encode */
   msgCp->evntStr = (TknU8*)&tmpnsi;
   if ((ret = mgAsnDecChoice(msgCp)) != ROK) { RETVALUE(ret); }

   /* switch it */
   switch (tmpnsi.type.val) {
   case 1:
      evPtr->type.pres = tmpnsi.type.pres;
      evPtr->type.val = MGT_NONSTD_OBJID;
      (void)cmMemcpy((U8*)&(evPtr->u.objId), (U8*)&(tmpnsi.u.objId), sizeof(MgMgcoObjId));
      break;
   case 2:
      evPtr->type.pres = tmpnsi.type.pres;
      evPtr->type.val = MGT_NONSTD_H221;
      (void)cmMemcpy((U8*)&(evPtr->u.h221), (U8*)&(tmpnsi.u.h221), sizeof(MgMgcoH221NonStd));
      break;
   case 3:
      evPtr->type.pres = tmpnsi.type.pres;
      evPtr->u.extn.pres = tmpnsi.u.extn.pres;
      if ((tmpnsi.u.extn.len < 3) || (tmpnsi.u.extn.len > 8)) {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
      }
      if (cmMemcmp((U8*)tmpnsi.u.extn.val, (U8*)"X+", 2) == 0) {
         evPtr->type.val = MGT_EXTNPARM_MAND;
      }
      else if (cmMemcmp((U8*)tmpnsi.u.extn.val, (U8*)"X-", 2) == 0) {
         evPtr->type.val = MGT_EXTNPARM_OPT;
      } else {
         MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
         RETVALUE(RFAILED);
      }
      (void)cmMemcpy((U8*)evPtr->u.extn.val, (U8*)&tmpnsi.u.extn.val[2], (tmpnsi.u.extn.len-2));
      /* mg008.105: Corrected the length of extn parameter value */
      evPtr->u.extn.len = tmpnsi.u.extn.len - 2;
      break;
   default:
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMuxTypeEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMuxTypeEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMuxTypeEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknU8     *evPtr;
   TknU8     eval;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncMuxTypeEnc);
   evPtr = (TknU8*)msgCp->evntStr;
   eval.pres = PRSNT_NODEF;
   switch (evPtr->val) {
   case MGT_MUXTYPE_H221:
      eval.val = 0; break;
   case MGT_MUXTYPE_H223:
      eval.val = 1; break;
   case MGT_MUXTYPE_H226:
      eval.val = 2; break;
   case MGT_MUXTYPE_V76:
      eval.val = 3; break;
#ifdef MGT_MGCO_V2
   case 5: /* Nx64k */
      eval.val = 4; break;
   case MGT_EXTNPARM:
      eval.val = 5; break;
#else
   case MGT_EXTNPARM:
      eval.val = 4; break;
#endif
   default:
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }

   /* Encode */
   msgCp->evntStr = (TknU8*)&eval;
   ret = mgAsnEncOctetEnum(msgCp);
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncMuxTypeDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncMuxTypeDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncMuxTypeDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknU8     *evPtr;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncMuxTypeDec);

   /* decode */
   evPtr = (TknU8*)msgCp->evntStr;
   ret = mgAsnDecOctetEnum(msgCp);

   /* recode */
   switch (evPtr->val) {
   case 0:
      evPtr->val = MGT_MUXTYPE_H221; break;
   case 1:
      evPtr->val = MGT_MUXTYPE_H223; break;
   case 2:
      evPtr->val = MGT_MUXTYPE_H226; break;
   case 3:
      evPtr->val = MGT_MUXTYPE_V76; break;
#ifdef MGT_MGCO_V2
   case 4: /* Nx64k */
      evPtr->val = 5; break;
   case 5:
      evPtr->val = MGT_EXTNPARM; break;
#else
   case 4:
      evPtr->val = MGT_EXTNPARM; break;
#endif
   default:
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncModemTypeEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncModemTypeEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncModemTypeEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknU8     *evPtr;
   TknU8     eval;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncModemTypeEnc);
   evPtr = (TknU8*)msgCp->evntStr;
   eval.pres = PRSNT_NODEF;
   switch (evPtr->val) {
   case MGT_MODEMTYPE_V32BIS:
      eval.val = 0; break;
   case MGT_MODEMTYPE_V22BIS:
      eval.val = 1; break;
   case MGT_MODEMTYPE_V18:
      eval.val = 2; break;
   case MGT_MODEMTYPE_V22:
      eval.val = 3; break;
   case MGT_MODEMTYPE_V32:
      eval.val = 4; break;
   case MGT_MODEMTYPE_V34:
      eval.val = 5; break;
   case MGT_MODEMTYPE_V90:
      eval.val = 6; break;
   case MGT_MODEMTYPE_V91:
      eval.val = 7; break;
   case MGT_MODEMTYPE_SYNCHISDN:
      eval.val = 8; break;
   case MGT_EXTNPARM:
      eval.val = 9; break;
   default:
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }

   /* Encode */
   msgCp->evntStr = (TknU8*)&eval;
   ret = mgAsnEncOctetEnum(msgCp);
   MGAFUNCSKIP(msgCp);

   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncModemTypeDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncModemTypeDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncModemTypeDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   TknU8     *evPtr;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncModemTypeDec);

   /* decode */
   evPtr = (TknU8*)msgCp->evntStr;
   ret = mgAsnDecOctetEnum(msgCp);

   /* recode */
   switch (evPtr->val) {
   case 0:
      evPtr->val = MGT_MODEMTYPE_V32BIS; break;
   case 1:
      evPtr->val = MGT_MODEMTYPE_V22BIS; break;
   case 2:
      evPtr->val = MGT_MODEMTYPE_V18; break;
   case 3:
      evPtr->val = MGT_MODEMTYPE_V22; break;
   case 4:
      evPtr->val = MGT_MODEMTYPE_V32; break;
   case 5:
      evPtr->val = MGT_MODEMTYPE_V34; break;
   case 6:
      evPtr->val = MGT_MODEMTYPE_V90; break;
   case 7:
      evPtr->val = MGT_MODEMTYPE_V91; break;
   case 8:
      evPtr->val = MGT_MODEMTYPE_SYNCHISDN; break;
   case 9:
      evPtr->val = MGT_EXTNPARM; break;
   default:
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_EVNT);
      RETVALUE(RFAILED);
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncNonStandardDataEnc
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncNonStandardDataEnc
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncNonStandardDataEnc(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgMgcoNonStdExtn     *evPtr;


   MGAFUNCSAVE(msgCp);
   TRC2(mgaFuncNonStandardDataEnc);
   evPtr = (MgMgcoNonStdExtn*)msgCp->evntStr;
   ++msgCp->elmntDef;

   /* NonStandardIdentifier */
   msgCp->evntStr = (TknU8*)&(evPtr->id);
   if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }

   /* Data */
   /* mg008.105: Data is of type octet string only, so no need of double
    * wrapping of data */
   if (evPtr->val.type.pres) {
      msgCp->evntStr = (TknU8*)&(evPtr->val.u.eq.u.osxl);
      if((ret = mgAsnEncElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   }

   MGAFUNCSKIP(msgCp);
   RETVALUE(ret);
}


/*
*
*       Fun:   mgaFuncNonStandardDataDec
*
*       Desc:  ABNF event to/from ASN.1 mapping function
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mgasnutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgaFuncNonStandardDataDec
(
MgAsnMsgCp *msgCp   /* message control point */
)
#else
PUBLIC S16 mgaFuncNonStandardDataDec(msgCp)
MgAsnMsgCp *msgCp;  /* message control point */
#endif
{
   S16 ret;
   MgAsnElmntDef* elmntDef;


   /* decode */
   TRC2(mgaFuncNonStandardDataDec);
   elmntDef = *msgCp->elmntDef;
   if (elmntDef->idNum == gcMsgNonStandardIdentifier.idNum) {
      /* mg007.105: Corrected the event structure pointer */
      MG_ASN_SKIP_TKNPRES(msgCp);
      /* NonStandardId */
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
   } else if (elmntDef->idNum == gcMsgData.idNum) {
      MgMgcoParmValue *evPtr;

      /* Data */
      evPtr = (MgMgcoParmValue*)msgCp->evntStr;
      /* mg008.105: Data is of type octet string only, so no need to expect the 
       * double wrapping of data */
      msgCp->evntStr = (TknU8*)&(evPtr->u.eq.u.osxl);
      if((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      evPtr->type.pres = evPtr->u.eq.u.osxl.pres;
      if (evPtr->type.pres) {
         evPtr->type.val = MGT_VALUE_EQUAL;
         evPtr->u.eq.type.pres = evPtr->u.eq.u.osxl.pres;
         evPtr->u.eq.type.val = MGT_VALTYPE_OCTSTRXL;
      }
   } else {
      MG_ASN_ERR(msgCp, MG_ASN_INVLD_ELMNT);
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}
#endif

/********************************************************************30**
 
        End of file:     mgasnutl.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 20 13:46:35 2005
*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      fl   1. initial release.
/main/1      ---      pk   1. GCP 1.5 release
           mg002.105  ps   1. Removed compilation warning 
           mg003.105  dp   1. Fixing ASN Encoding problem with GCP_CH
                      gk   2. Removing double quotes for service change reason in binary encoding
                      gk   3. Changes for 3GPP Termination Id Encoding
                      gk   4. Added element definitions for double encoding(wrap) of ServiceChangeReason element 
                      gk   5. Fix for CommandRequestDec
                      gk   6. Encode empty parameter list if it is absent in observed event
                      gk   7. Fix for ContextRequestEnc 
                      gk   8. Fixes for ServiceChangeReasonEnc 
                      gk   9. Removing double quotes for service change reason in binary encoding 
                      gk  10. Changes for RequestEventEnc 
                      gk  11. Added new macro for H2A conversion
                      gk  12. checking for streams is available or not
		                gk  13. fixes for the Media Descriptor
                      gk  14. Fix for Remote Descriptor
                      gk  15. Pointing event structure to context id
                      gk  16. Initializing with 0
                      gk  17. Changes for RequestEventEnc
                      gk  18. Fixes for the parameter list if not present encode tag and length 0
                      gk  19. encode/decode functions are adding for the events descriptor
                      gk  20. Fix for the Request ID
                      gk  21. Fixes for the 3GPP Termination ID
                      gk  22. Fixes for the filling sdp parameter event structure
                      gk  23. Fixes for the package name decoding
                      gk  24. Fixes for the property parm decoding
                      gk  25. fixes for the action request
           mg004.105  gk   1. Added Annex C support 
                           2. Add - support for the empty value
                           3. Changed for empty sequence of parameter values
                           4. Added IA5 type in the param value
                           5. Support for the empty parameter value
                           6. Modified for the empty value
                           7. Added Wildcard support for the Termination id
                           8. Modified for empty property parms 
                           9. Change - fix for the signal other parameter 
                          10. Removed SDP which will support through Annex C
           mg005.105  gk   1. Fix for Service change profile
                           2. Added prevention check for the type of the property 
                           3. Added Bool type for the property
                           4. Support for Package id U16
           mg007.105  gk   1. saving the audit token element definition
                           2. Changed the mapping of signal parameter from
                              mgaFuncSignalRequestDec
                           3. Fail the signal which id comes out side the boundary limit
                           4. Boolean field is added in MgMgcoValue union
                           5. Allowing empty property parms in termination state descriptor
                           6. If foundPP is empty don't allocate memory
                           7. If TerminationAudit is empty send empty sequence
                           8. If version is other than 1 and 2 fail it
           mg008.105  gk   1. Corrected the length of extn parameter value
                           2. Data is of type octet string only, so no need of double
                              wrapping of data
                           3. val is of TknOid and val.val is of type U32, but evPtr->val is
                              of type U8. So here cmMemcpy will not work
                           4. New function added for AmmRequestEnc
                           5. New functions added for priority encoding/decoding
*********************************************************************91*/
