/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                          All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     asn.1

     Type:     C Source file

     Desc:     C source code for common ASN.1 encoding/decoding
               routines

     File:     mg_asn.c

     Sid:      mg_asn.c@@/main/mgcp_rel_1.5_dev/gcp_mgcov2_dev/4 - Wed Dec 22 11:15:09 2004

     Prg:      sg

*********************************************************************21*/


/************************************************************************

     Note:
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------

************************************************************************/
 

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#ifdef GCP_ASN

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_err.h"        /* common error */
#include "cm_tkns.h"       /* common token structures */
#include "cm_mblk.h"       /* common event memory management */
#include "cm_tpt.h"        /* TPT header file */
#include "cm_dns.h"        /* DNS header file */
#include "cm_abnf.h"       /* ABNF header file */
#include "cm_sdp.h"        /* SDP header file */
#include "mgt.h"           /* ABNF events header file */
#include "mg_asn.h"        /* ASN.1 header file */
#include "mgasndb1.h"       /* ASN.1 database */
#include "mgasnpdb.h"      /* ASN.1 package database */
#include "mgasndb2.h"      /* ASN.1 database tree */
#include "mgasnwrp.h"         /* encode/decode wrappers */
#include "mg_err.h"
#include "cm_hash.h"
#include "cm_llist.h"

/* mg005.105: Fix for PSF */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */

#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */


#include "lmg.h"           /* layer management defines for MGCP */
#include "lhi.h"
#include "mg.h"
#include "mgasnutl.h"

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* general layer */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* common event memory management */
#include "cm_lib.x"        /* common structures */
#include "cm_tpt.x"        /* TPT structures */
#include "cm_dns.x"        /* DNS structures */
#include "cm_sdp.x"        /* SDP structures */
#include "cm_abnf.x"       /* ABNF structures */
#include "mg_asn.x"        /* ASN.1 structures */
#include "mg_db.x"
#include "mgco_db.x"       /* ABNF database */
#include "mgasnev.x"       /* ASN.1 events */
#include "mgasndb1.x"       /* ASN.1 database */
#include "mgasnpdb.x"      /* ASN.1 package database */
#include "mgt.x"           /* ABNF events */
#include "mgasnwrp.x"         /* encode/decode wrappers */
#include "cm_hash.x"
#include "cm_llist.x"
#ifdef GCP_PROV_MTP3
#include "cm_ss7.x"           /* layer management typedefs for MGCP */
#endif

/* mg005.105: Fix for PSF */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */

#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef GCP_PROV_SCTP
#include "sct.h"           /* layer management typedefs for MGCP */
#include "sct.x"           /* layer management typedefs for MGCP */
#endif
#include "lmg.x"           /* layer management typedefs for MGCP */
#include "lhi.x"
#include "mg.x"
#include "mgasnutl.x"
 

#ifdef CM_ABNF_MT_LIB
EXTERN Void mwrapErrMap ARGS((CmAbnfErr *err, MgAsnErr *asnErr));
#endif



/* Macro for logging error */

#define MGASNLOGERROR(errCls, errCode, errVal, errDesc) \
   SLogError(ENTNC, INSTNC, SFndProcId(), __FILE__, __LINE__, \
              errCls, errCode, errVal, errDesc )

/* prototypes */
PUBLIC S16 mgAsnFindLen ARGS((MgAsnMsgCp *msgCp));
PUBLIC S16 mgAsnGetOffset ARGS((MgAsnMsgCp *msgCp));
PUBLIC S16 mgAsnEncOut2Buf ARGS((MgAsnMsgCp *msgCp, Data* str, MsgLen len));
PUBLIC  S16 mgAsnEncSetOctet ARGS((MgAsnMsgCp *msgCp, Data octet, MsgLen offset));
PUBLIC S16 mgAsnEncSlide ARGS((MgAsnMsgCp *msgCp, MsgLen *lenOffset, MsgLen lenLen));
PRIVATE S16 mgAsnDecBuf2Out ARGS((MgAsnMsgCp *msgCp, Data* str, MsgLen len));
PUBLIC  S16 mgAsnDecIgnoreBytes ARGS((MgAsnMsgCp *msgCp, U16 len));
PUBLIC  S16 mgAsnDecChkOctet ARGS((MgAsnMsgCp *msgCp, Data* octet));
PUBLIC  S16 mgAsnDecGetOctet ARGS((MgAsnMsgCp *msgCp, Data* octet));

PUBLIC S16 mgAsnEncElmnt ARGS((MgAsnMsgCp *msgCp));
PUBLIC S16 mgAsnDecElmnt ARGS((MgAsnMsgCp *msgCp));

PUBLIC S16 mgAsnSkipElmnt ARGS((MgAsnMsgCp *msgCp));
PUBLIC S16 mgAsnInitAsnMsgCp ARGS((MgAsnMsgCp *msgCp));
PUBLIC S16 mgAsnEncTag ARGS((MgAsnMsgCp *msgCp));

PUBLIC S16 mgAsnChkTag ARGS((MgAsnMsgCp *msgCp));
PUBLIC S16 mgAsnDecChkFlag ARGS((MgAsnMsgCp *msgCp));

PUBLIC S16 mgAsnSetLen ARGS((MgAsnMsgCp *msgCp, MsgLen lenOffset));
PUBLIC S16 mgAsnDecTagLen ARGS((MgAsnMsgCp *msgCp));

PRIVATE S16 mgAsnChkEnum ARGS((U32 val, MgAsnElmntDef *elmntDef));
PUBLIC S16 mgAsnChkEncElmnt ARGS((U8 flag, MgAsnMsgCp *msgCp, TknU8 *evntStr));

PRIVATE S16 mgAsnChkMsgMandMis ARGS((MgAsnMsgCp *msgCp));
PUBLIC S16 mgAsnChkSeqMandMis ARGS((MgAsnMsgCp *msgCp));
PRIVATE S16 mgAsnChkSetMandMis ARGS((MgAsnMsgCp *msgCp));
PUBLIC Bool mgAsnChkEleMandMis ARGS((MgAsnMsgCp *msgCp));
PRIVATE S16 mgAsnInitConstType ARGS((MgAsnElmntDef ***ptr));
PRIVATE S16 mgAsnInitSeqOfElem ARGS((MgAsnElmntDef ***ptr));
PRIVATE S16 mgAsnCpyUnrecogElmnt ARGS((MgAsnMsgCp *msgCp, MsgLen *bytes));
#ifdef MG_ASN_DBG
PUBLIC  Void mgAsnDumpMsgDb        ARGS((MgAsnElmntDef **msgDef));
PRIVATE S16  mgAsnPrntElmntDb ARGS((MgAsnElmntDef *elmntDef));
#endif /* MG_ASN_DBG */

#ifdef MG_ASN_DBG
#ifndef MG_ASN_SS
PUBLIC Void cmPrntSBuf  ARGS((MgAsnMsgCp *msgCp));
#endif /* MG_ASN_SS */
#endif /* MG_ASN_DBG */

/*mg003.105: extern moved from mg.x for g++ compilation issue*/

EXTERN S16 mgAllocEventMem ARGS((
       Ptr       *memPtr,
       Size      memSize
    ));
       
EXTERN S16 mgFreeEventMem ARGS((
       Ptr       memPtr
    ));


#ifdef MG_ASN_DBG

/* ------------------------------------------------------------- */

/*
*
*       Fun:   mgAsnPrntElmntDb
*
*       Desc:  This prints a single the message database element
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnPrntElmntDb 
(
MgAsnElmntDef *elmntDef               /* message definition */
)
#else
PUBLIC S16 mgAsnPrntElmntDb (elmntDef)
MgAsnElmntDef *elmntDef;              /* message definition */
#endif
{
   Txt        prntBuf[255];        /* Buffer to print */
   S16        i;                   /* counter */

   TRC2(mgAsnPrntElmntDb)

   SPrint("\n");
#ifdef MG_ASN_DBG
   sprintf(prntBuf,"   Description: %s\n", elmntDef->str);
   SPrint(prntBuf);
#endif /* MG_ASN_DBG */

   sprintf(prntBuf, "   idNum      : %d\n",elmntDef->idNum);
   SPrint(prntBuf);
   sprintf(prntBuf, "   Tag        : 0x%x\n",elmntDef->tag);
   SPrint(prntBuf);
   sprintf(prntBuf, "   Min. Length: %ld\n",elmntDef->minLen);
   SPrint(prntBuf);
   sprintf(prntBuf, "   Max. Length: %ld\n",elmntDef->maxLen);
   SPrint(prntBuf);
   sprintf(prntBuf, "   Db Size    : %d\n",elmntDef->dbSize);
   SPrint(prntBuf);
   sprintf(prntBuf, "   Ev Size    : %d\n",elmntDef->evSize);
   SPrint(prntBuf);
   sprintf(prntBuf, "   Repeat Cntr: %ld\n", (Cntr) elmntDef->repCntr);
   SPrint(prntBuf);

   if (elmntDef->flagp != NULLP)
   {
      sprintf(prntBuf, "   Flag       : 0x%lx\n", (PTR) *elmntDef->flagp);
      SPrint(prntBuf);
   }
   else
   {
      SPrint("   Flag       : NULLP\n");
   }

   /* print the enumerated list */
   if (elmntDef->enumLst != NULLP)
   {
      sprintf(prntBuf, "   Enum List  :");
      SPrint(prntBuf);

      for (i=0; i < (S16) elmntDef->enumLst[0]; i++)
      {
         sprintf(prntBuf, " 0x%x",elmntDef->enumLst[i+1]);
         SPrint(prntBuf);
      } 

      SPrint("\n");
   }

   sprintf(prntBuf, "   Encode Func : 0x%lx\n", (PTR) elmntDef->funcEnc);
   sprintf(prntBuf, "   Decode Func : 0x%lx\n", (PTR) elmntDef->funcDec);
   SPrint(prntBuf);
   SPrint("\n");

   RETVALUE(ROK);
 
} /* mgAsnPrntElmntDb */


/*
*
*       Fun:   mgAsnDumpMsgDb 
*
*       Desc:  This function parses the message database and
*              calls routines to print the element defintions
*              in the message database
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC Void mgAsnDumpMsgDb 
(
MgAsnElmntDef **msgDef               /* message definition */
)
#else
PUBLIC Void mgAsnDumpMsgDb (msgDef)
MgAsnElmntDef **msgDef;              /* message definition */
#endif
{
   MgAsnElmntDef **dbPtr;            /* database pointer */
   MgAsnElmntDef *elmnt;             /* database element pointer */

   TRC2(mgAsnDumpMsgDb)

   /* initialize the database pointer to the message start */
   dbPtr = msgDef;

   while (*dbPtr != NULLP)
   {
      /* get the current element from the database pointer */
      elmnt = *dbPtr;

      mgAsnPrntElmntDb(elmnt);
      dbPtr++;

   } /* end while */

   RETVOID;

} /* mgAsnDumpMsgDb */

#endif /* MG_ASN_DBG */


/*
*
*       Fun:   mgAsnCpyUnrecogElmnt
*
*       Desc:  This function copies a unrecognized element to a
*              message buffer
*
*       Ret:   ROK 
*              RFAILED
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PRIVATE S16 mgAsnCpyUnrecogElmnt
(
MgAsnMsgCp   *msgCp,  /* message control pointer */
MsgLen       *bytes   /* number of bytes copied to the user buffer */
)
#else
PRIVATE S16 mgAsnCpyUnrecogElmnt (msgCp, bytes)
MgAsnMsgCp   *msgCp;  /* message control pointer */
MsgLen       *bytes;  /* number of bytes copied to the user buffer */
#endif
{
   MgAsnElmntDef   *elmntDef;      /* element definition */
   S16          ret;            /* return value */
   MsgLen       msgLen;         /* length of the set */
   MsgLen       elmntSize;      /* element size */
   Data         *pData;         /* static buffer pointer */


   TRC2(mgAsnCpyUnrecogElmnt)

   /* initialize the number of bytes copied */
   if (bytes != NULLP)
   {
      *bytes = 0;
   }

   /* get the size of the element */
   elmntDef = *msgCp->elmntDef;

   /*mg002.105: Removed compilation warning*/
   elmntSize = mgAsnFindLen(msgCp);

   switch(msgCp->cfg) {
   case MG_ASN_GEN_ERR:
      MG_ASN_ERR(msgCp, MG_ASN_EXTRA_PARAM);
      RETVALUE(RFAILED);
   case MG_ASN_DROP_ELMNTS:
      /* drop the unrecongnized element */
      if ((ret = mgAsnDecBuf2Out(msgCp, NULLP, elmntSize)) != ROK)
      {
         MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
         RETVALUE(RFAILED);
      }
      break;

   case MG_ASN_PASS_ELMNTS: /* pass the unrecongnized element to the user */
      if (SGetSBuf(msgCp->region, msgCp->pool, &pData, (Size) elmntSize) != ROK)
      {
         MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
         RETVALUE(RFAILED);
      }

      /* strip of the bytes from the begining of the message buffer */
      if ((ret = mgAsnDecBuf2Out(msgCp, pData, elmntSize)) != ROK)
      {
         (Void) SPutSBuf(msgCp->region,msgCp->pool,pData,(Size) elmntSize);
         MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
         RETVALUE(ret);
      }

      /* get a new message buffer if not already allocated */
      if (msgCp->uBuf == NULLP)
      {
         if ((ret = SGetMsg(msgCp->region, msgCp->pool, &msgCp->uBuf)) != ROK)
         {
            (Void) SPutSBuf(msgCp->region, msgCp->pool, pData, (Size) elmntSize);
            MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
            RETVALUE(RFAILED);
         }
      }

      /* copy the static encoded string to message buffer */
      if ((ret = SAddPstMsgMult(pData, elmntSize, msgCp->uBuf)) != ROK)
      {
         /* throw away the static buffer */
         (Void) SPutSBuf(msgCp->region, msgCp->pool, pData,(Size) elmntSize);
         (Void)SFndLenMsg (msgCp->uBuf, &msgLen);

         if (msgLen == 0)
         {
            (Void) SPutMsg(msgCp->uBuf);
            msgCp->uBuf = NULLP;
         }

         MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
         RETVALUE(RFAILED);
      }

      /* throw away the static buffer */
      (Void) SPutSBuf(msgCp->region, msgCp->pool, pData, (Size) elmntSize);
      break;

   case MG_ASN_IGN_ELMNTS:
      break;

   default:
      /* unknown configuration */
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(RFAILED);
   } /* end switch */

   /* indicate the number of bytes copied */
   if (bytes != NULLP)
   {
      *bytes = elmntSize;
   }

   RETVALUE(ROK);

} /* mgAsnCpyUnrecogElmnt */ 

#ifdef MG_ASN_DBG
#ifndef MG_ASN_SS

/*
*
*       Fun:   mgAsnPrntSBuf 
*
*       Desc:  This routines prints the static buffer associated
*              message control point. 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC Void mgAsnPrntSBuf 
(
MgAsnMsgCp  *msgCp  /* message control pointer */
)
#else
PUBLIC Void mgAsnPrntSBuf (msgCp)
MgAsnMsgCp  *msgCp; /* message control pointer */
#endif
{
   Txt  prntBuf[255];        /* Buffer to print */
   U16  i;                   /* counter */
   U16  j;                   /* counter */
   U8   data;                /* data */
   U16  tCount;              /* temporary counter */
   Data *msg;                /* message pointer */
 
   TRC2(mgAsnPrntSBuf)

   if (msgCp == NULLP)
   {
      RETVOID;
   }

   tCount = msgCp->sBuf.size;
   msg    = (Data *)(msgCp->sBuf.bufP + msgCp->sBuf.stIdx);
 
   SPrint("\n");
   sprintf(prntBuf,"   message size: %4d\n", msgCp->sBuf.size);
   SPrint(prntBuf);
   SPrint("   ");
 
   if (msgCp->sBuf.size == 0)
   {
      SPrint("<none>");
      return;
   }
 
   j = 0;
   i = 0;
 
   while (1)
   {
      if (tCount > 0)
      {
         data = msg[i];
 
         if (j < 16)
         {
            /* print the hex values first */
            sprintf(prntBuf, "%02x ", data);
            SPrint(prntBuf);
         }
         else
         {
            j = 0;
 
            /* for the next line, print three preceeding spaces */
            SPrint("\n   ");
 
            continue;
         }
 
      }
      else
      {
         break;
      }
 
      i++;
      j++;
 
      tCount--;
 
   } /* end while */
 
   SPrint("\n");
   SPrint("\n");
 
} /* mgAsnPrntSBuf */

#endif /* MG_ASN_SS */
#endif /* MG_ASN_DBG */


/*
*
*       Fun:   mgAsnInitAsnMsgCp 
*
*       Desc:  This function initializes the ASN.1 message control 
*              structure 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnInitAsnMsgCp 
(
MgAsnMsgCp  *msgCp  /* message control pointer */
)
#else
PUBLIC S16 mgAsnInitAsnMsgCp (msgCp)
MgAsnMsgCp  *msgCp; /* message control pointer */
#endif
{
   TRC2(mgAsnInitAsnMsgCp)

   msgCp->flagp      = NULLP;         /* protocol flag */
   msgCp->proType    = MEGACO_V1;     /* protocol flag */
   msgCp->mBuf       = NULLP;         /* msg buffer */
   msgCp->uBuf       = NULLP;         /* msg buffer */
   msgCp->region     = 0;             /* region */
   msgCp->pool       = 0;             /* pool */
   msgCp->cfg        = 0;             /* configuration */

   msgCp->sBuf.bufP  = NULLP;         /* pointer to static buffer */
   msgCp->sBuf.stIdx = 0;             /* start index */
   msgCp->sBuf.size  = 0;             /* size */
   msgCp->sBuf.max   = 0;             /* maximum size */

   msgCp->evntStr    = NULLP;         /* event structure */ 
   msgCp->elmntDef   = NULLP;         /* token list def in database */
   msgCp->err        = NULLP;         /* error definition */

   msgCp->sBuf.ctIdx = 0;             /* current index */

   RETVALUE(ROK);

} /* mgAsnInitAsnMsgCp */


/*
*
*      Fun:   mgAsnIncPtr
*
*      Desc:  increments address pointer, "addr", by "len".
*             used to access structures during encoding/decoding.
*
*      Ret:   ROK      - increment successful
*
*      Notes: None
*
*      File:  mg_asn.c
*
*/
 
#ifdef ANSI
PUBLIC  S16 mgAsnIncPtr
(
PTR *addr,     /* address pointer */
U32 len        /* length by which to increment the pointer */
)
#else
PUBLIC  S16 mgAsnIncPtr(addr, len)
PTR *addr;     /* address pointer */
U32 len;       /* length by which to increment the pointer */
#endif
{

   TRC2(mgAsnIncPtr)

   *addr += len;

   RETVALUE(ROK);

} /* end of mgAsnIncPtr */


/*
*
*       Fun:   mgAsnSkipElmnt
*
*       Desc:  This function skips the elements in event structure 
*              and increments the database pointer appropriately. 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnSkipElmnt 
(
MgAsnMsgCp  *msgCp    /* message control pointer */
)
#else
PUBLIC S16 mgAsnSkipElmnt (msgCp)
MgAsnMsgCp  *msgCp;   /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;     /* pointer to element defintion */

   TRC2 (mgAsnSkipElmnt)

   /* get the element defintion for the current element */
   elmntDef = *msgCp->elmntDef;

   if (elmntDef->type == TET_TAG)
   {
      /* increment the database pointer */
      msgCp->elmntDef++;

      (Void) mgAsnSkipElmnt(msgCp);

      /* skip over the end of constructor element */
      msgCp->elmntDef++;

   }
   else
   {

      /* increment the database pointer */
      msgCp->elmntDef = 
             (MgAsnElmntDef **) ((PTR) msgCp->elmntDef + elmntDef->dbSize); 

      /* increment the event structure pointer */
      msgCp->evntStr = 
             (TknU8 *) ((PTR) msgCp->evntStr + (PTR)elmntDef->evSize); 
   }

   RETVALUE(ROK);

} /* mgAsnSkipElmnt */


/*
*
*      Fun:   mgAsnEncTag
*
*      Desc:  Copies the ASN.1 tag to an array, pointer to which
*             is passed.
*
*      Ret:   Void
*
*      Notes: None
*
*      File:  mg_asn.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mgAsnEncTag
(
MgAsnMsgCp *msgCp         /* message control point */
)
#else
PUBLIC S16 mgAsnEncTag(msgCp)
MgAsnMsgCp *msgCp;        /* message control point */
#endif
{
   S16         ret;
   U8          flag;           /* protocol flag */


   TRC2(mgAsnEncTag)

   /* check flag and stop the core dump */
   if (((*(msgCp->elmntDef))->flagp) == NULLP) {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(RFAILED);
   }

   /* get the protocol flags from the database element defintion */
   flag = FLAG_TO_TYPE(((*(msgCp->elmntDef))->flagp), msgCp->proType);

   /* check the element for protocol type and mandatory/optional flags */
   if ((ret = mgAsnChkEncElmnt(flag, msgCp, msgCp->evntStr)) != ROK)
   {
      if (ret == RSKIP)
      {
         /* element can be skipped */
         mgAsnSkipElmnt(msgCp);
         RETVALUE(RSKIP);
      }

      RETVALUE(RFAILED);
   }
   /* mg003.105: Changes for Universal Tag */
   /* Skip encoding tags for sequence of choice */
   if (((*(msgCp->elmntDef))->tag) == MG_ASN_UCHOICE)
   {
      RETVALUE(ROK);
   }

   /* encode tag and leave one octet for length */
   if ((ret = mgAsnEncOut2Buf(msgCp, &((*(msgCp->elmntDef))->tag), 2)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(ret);
   }

   RETVALUE(ROK);
} /* end of mgAsnEncTag */


/*
*
*      Fun:   mgAsnChkTag
*
*      Desc:  Checks the tag value against the database defintion of
*             the element
*
*      Ret:   ROK (tag matches) 
*             RFAILED (otherwise)
*
*      Notes: None
*
*      File:  mg_asn.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mgAsnChkTag
(
MgAsnMsgCp *msgCp         /* message control point */
)
#else
PUBLIC S16 mgAsnChkTag(msgCp)
MgAsnMsgCp *msgCp;        /* message control point */
#endif
{
   S16         ret;
   U8          tmpTag;    /* temporary tag */

   TRC2(mgAsnChkTag)

   /* check if this element is defined for this protocol */
   if ((ret = mgAsnDecChkFlag(msgCp)) == RFAILED)
   {
      mgAsnSkipElmnt(msgCp);
      RETVALUE(RSKIP);
   }

   /* get tag */
   if ((ret = mgAsnDecChkOctet(msgCp, &tmpTag)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_TAG_ERR);
      RETVALUE(ret);
   }

   if (tmpTag != (*(msgCp->elmntDef))->tag)
   {
      /* there was an error, check if element is mandatory */
      if (mgAsnChkEleMandMis(msgCp) == TRUE)
      {
         MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
         RETVALUE(RFAILED);
      }

      /* element is optional, skip it */
      mgAsnSkipElmnt(msgCp);
      RETVALUE(RSKIP);
   }

   RETVALUE(ROK);
} /* end of mgAsnChkTag */


/*
*
*      Fun:   mgAsnDecTagLen
*
*      Desc:  Copies the ASN.1 length to an length var, pointer to which
*             is passed and returns the size of the length field too.
*
*      Ret:   ROK (Decode was successful)
*             RFAILED (otherwise)
*
*      Notes: Finds length of types types not encoded as EOC format.
*
*      File:  mg_asn.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mgAsnDecTagLen
(
MgAsnMsgCp *msgCp     /* message buffer */
)
#else
PUBLIC S16 mgAsnDecTagLen(msgCp)
MgAsnMsgCp *msgCp;    /* message buffer */
#endif
{
   MgAsnElmntDef  *elmntDef; /* database defintion for this element */
   MsgLen      i;         /* counter */
   MsgLen      totLen;    /* total length of the message */
   Data        tmpData;   /* temporary data */
   MsgLen      lenLen;    /* length of length field */
   S16         ret;       /* return value */


   TRC2(mgAsnDecTagLen)

   elmntDef = *msgCp->elmntDef;
   i        = 0;           /* Intialize the array index */
   msgCp->elmntLen  = 0;   /* Initialize the length of the element */
   msgCp->ignoreBytes  = 0; /* Initialize the ignored byte count */

   /* mg003.105: Changes for Universal Tag */
   /* Skip decoding tags for sequence of choice */
   if (elmntDef->tag == MG_ASN_UCHOICE)
   {
      RETVALUE(ROK);
   }

   /* Check the tag */
   if ((ret = mgAsnChkTag(msgCp)) != ROK)
   {
      RETVALUE(ret);
   }

   /* Skip tag */
   if ((ret = mgAsnDecIgnoreBytes(msgCp, 1)) != ROK) {
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(ret);
   }

   /* get the total length of the message */
   totLen = mgAsnFindLen(msgCp);

   /* get the first byte of the length field */
   if ((ret = mgAsnDecGetOctet(msgCp, &tmpData)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(RFAILED);
   }

   /* Check for single byte length encoding */
   if (tmpData < EOC_FLAG)
   {
      msgCp->elmntLen = (MsgLen)tmpData;
      lenLen = 1;
   }
   /* long form of length encoding */
   else if (tmpData > EOC_FLAG) {

      /* get the number of bytes in the length field */
      lenLen = (U8)(tmpData & ~EOC_FLAG);

      /* length field is sum of first byte & no. of bytes in length field */
      if (lenLen > MAX_LEN_BYTES)
      {
         MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
         RETVALUE(RFAILED);
      }

      /* copy the length from the array to a variable */
      msgCp->elmntLen = (MsgLen)0;
      for(i=0; i<lenLen; ++i)
      {
         if ((ret = mgAsnDecGetOctet(msgCp, &tmpData)) != ROK)
         {
            MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
            RETVALUE(RFAILED);
         }
         msgCp->elmntLen = (MsgLen)((msgCp->elmntLen << 8) | tmpData);
      }
   } /* end if */
   else {
      /* EOC not supported for now */
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(RFAILED);
   } /* end if */

   /* if element length is greater than the message length, error */
   if ((msgCp->elmntLen + lenLen) > (MsgLen)totLen)
   {
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(RFAILED);
   }

   /* primitive length should lie within the max and min values
    * avoid checking of length for TET_INT_RNG token type, as they use the 
    * fields minLen/maxLen differently.
    */
   if (elmntDef->type != TET_INT_RNG)
   {
      if ((MsgLen)elmntDef->minLen != MIN_LEN_NA)
      {
         if (msgCp->elmntLen < (MsgLen)elmntDef->minLen)
         {
            MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
            RETVALUE(RFAILED);
         }
      }

      if ((MsgLen)elmntDef->maxLen != MAX_LEN_NA)
      {
         if ((U32)msgCp->elmntLen > (U32)elmntDef->maxLen)
         {
            /* check the flag to see if need to ignore the extra octets */

	      /* mg007.105: put the check for the integer with allowing 
          * extra octet */
            if(!(((elmntDef->type == TET_INT8) || (elmntDef->type == TET_INT16) ||
                  (elmntDef->type == TET_INT32) || (elmntDef->type == TET_INT)) &&
		            ((U32)msgCp->elmntLen == ((U32)elmntDef->maxLen + 1))))
	         {
               if (! (IS_IGNORE_EXT(elmntDef, msgCp->proType)))
	            {
         		   MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
		            RETVALUE(RFAILED);
               }

               /* extra bytes at the end */
               msgCp->ignoreBytes = msgCp->elmntLen - elmntDef->maxLen;
               msgCp->elmntLen = elmntDef->maxLen;
	         }
         }
      }
   }

   RETVALUE(ROK);
} /* mgAsnDecTagLen */


/*
*
*      Fun:   mgAsnSetLen
*
*      Desc:  Sets the ASN.1 length in an array, pointer to which
*             is passed.
*
*      Ret:   Void
*
*      Notes: None
*
*      File:  mg_asn.c
*
*/
 
#ifdef ANSI
PUBLIC  S16 mgAsnSetLen
(
MgAsnMsgCp *msgCp,        /* message */
MsgLen      lenOffset        /* Offset to length */
)
#else
PUBLIC  S16 mgAsnSetLen(msgCp, lenOffset)
MgAsnMsgCp *msgCp;        /* message */
MsgLen      lenOffset;       /* Offset to length */
#endif
{
   U16 ret;
   U32 len;
   S32 tmpLenOffset;
   S32 lenLen;
   S32 j;

   TRC2(mgAsnSetLen)

   len = mgAsnGetOffset(msgCp) - lenOffset;

   --lenOffset;
   if ((lenLen = mgAsnFindNumOctets(len)) == 1) {
      /*mg002.105: Removed compilation warning*/
      if ((ret = mgAsnEncSetOctet(msgCp, (Data)len, lenOffset)) != ROK)
      {
         MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
         RETVALUE(ret);
      }
   }
   else {
      /* shuffle out data */
      /*mg002.105: Removed compilation warning*/
      if ((ret = mgAsnEncSlide(msgCp, &lenOffset, (MsgLen)(lenLen-1))) != ROK)
      {
         RETVALUE(ret);
      }

      /* write the length */
      --lenLen;
      tmpLenOffset = lenOffset;
      len = mgAsnGetOffset(msgCp) - lenOffset - 1;
      for (j=lenLen; j>0; j--)
      {
         /*mg002.105: Removed compilation warning*/
         if ((ret = mgAsnEncSetOctet(msgCp, (Data)(len&0xff), (MsgLen)tmpLenOffset)) != ROK)
         {
            MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
            RETVALUE(ret);
         }
         len = (len >> NUMBITS_BYTE);   /* shift out the LSB */
         --tmpLenOffset;
      }

      /* first byte contains the EOC_FLAG and number of bytes in length */
      /*mg002.105: Removed compilation warning*/
      if ((ret = mgAsnEncSetOctet(msgCp, (Data)(EOC_FLAG | lenLen), (MsgLen)tmpLenOffset)) != ROK)
      {
         MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
         RETVALUE(ret);
      }

   }

   RETVALUE(ROK);
} /* end of mgAsnSetLen */


/*
*
*      Fun:   mgAsnChkEnum
*
*      Desc:  tries to locate specified value in specified enumerated list.
*
*      Ret:   ROK          - value found in enumerated list
*             RFAILED      - value not found in enumerated list
*
*      Notes: None
*
*      File:  mg_asn.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mgAsnChkEnum
(
U32 val,                    /* value */
MgAsnElmntDef *elmntDef       /* token definition */
)
#else
PRIVATE S16 mgAsnChkEnum(val, elmntDef)
U32 val;                    /* value */
MgAsnElmntDef *elmntDef;        /* token definition */
#endif
{
   U32  count;          /* number of elements in enumerated list */
   U16 i;              /* counter */

   TRC2(mgAsnChkEnum)

   if (!(elmntDef->enumLst))
   {
      /* we want to allow unchecked enums for now */
      RETVALUE(ROK);
   }

   /* The first element of the array "enumLst" specifies the number
      of entries in enumerated list */
   count = elmntDef->enumLst[0];

   /* try to find a match for value in enumerated list */
   for (i = 1; i <= count; i++)
   {
      if (val == elmntDef->enumLst[i])
      {
         RETVALUE(ROK);
      }
   }

   RETVALUE(RFAILED);

} /* end of mgAsnChkEnum */


/*
*
*      Fun:   mgAsnDecChkFlag
*
*      Desc:  This routine checks if an element is defined for the
*             protocol being defined.
*
*      Ret:   ROK       - element defined by the protocol
*             RFAILED   - element is not defined for the protocol. 
*
*      Notes: None
*
*      File:  mg_asn.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mgAsnDecChkFlag
(
MgAsnMsgCp  *msgCp    /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecChkFlag(msgCp)
MgAsnMsgCp  *msgCp;   /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;      /* element definition */
   U8           flag;           /* protocol flag */

   TRC2(mgAsnDecChkFlag)

   elmntDef = *msgCp->elmntDef;        /* get the element defintion */ 

   /* get the protocol flags from the database element defintion */
   flag = FLAG_TO_TYPE(elmntDef->flagp, msgCp->proType);

   /* check if the element is defined for this protocol */ 
   if (flag == ELMNT_INV)
   {
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* end of mgAsnDecChkFlag */


/*
*
*      Fun:   mgAsnChkEncElmnt
*
*      Desc:  This routine checks whether the element defintion in the
*             database supports the indicated protocol. It also checks
*             for a mandatory element which might be missing.
*
*      Ret:   ROK       - element present and defined by the protocol
*             RFAILED   - element invalid and present or mandatory and missing
*             RSKIP     - element optional or invalid and not present
*
*      Notes: None
*
*      File:  mg_asn.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mgAsnChkEncElmnt
(
U8          flag,     /* flag for the element */
MgAsnMsgCp  *msgCp,   /* message control pointer */
TknU8       *evntStr  /* event structure pointer */
)
#else
PUBLIC S16 mgAsnChkEncElmnt(flag, msgCp, evntStr)
U8          flag;     /* flag for the element */
MgAsnMsgCp  *msgCp;   /* message control pointer */
TknU8       *evntStr; /* event structure pointer */
#endif
{
   Bool         pres;        /* Element present flag */
   MgAsnElmntDef **elmntDef;    /* element definition */

   TRC2(mgAsnChkEncElmnt)

   elmntDef = msgCp->elmntDef;

   /* if the type is a tag type, then the event structure is */
   /* associated only with the enclosed type, so for finding that */
   /* out, we will need to increment the database pointer. Note that */
   /* the message control point database pointer is unaffected by this */
   /* increment */
   if ((*elmntDef)->type == TET_TAG)
   {
      elmntDef++;
   }

   /* Check ignore pres flag. Used when pres isn't right there */
   if (IS_IGNORE_PRES((*elmntDef), msgCp->proType)) {
      RETVALUE(ROK);
   }

   /* TknStrXL type requires special treatment because of the difference
      in type definition */
   if ((*elmntDef)->type == TET_STRXL || 
       (*elmntDef)->type == TET_STRXL_MEM ||
       (*elmntDef)->type == TET_IA5STRXL || 
       (*elmntDef)->type == TET_IA5STRXL_MEM)
   {
      pres = ((TknStrXL *)evntStr)->pres;
   }
   else if (((*elmntDef)->type == TET_STROSXL_MEM) ||
            ((*elmntDef)->type == TET_IA5STROSXL_MEM))
   {
      pres = ((TknStrOSXL *)evntStr)->pres;
   }
   else
   {
      pres = evntStr->pres;
   }

   /* check if the element is defined for this protocol */ 
   if (flag == ELMNT_INV)
   {
      /* element not defined for this protocol */

      /* check if the element is present in the event structure */
      if (pres)
      {
         /* parameter is not defined for the protocol */
         MG_ASN_ERR(msgCp, MG_ASN_UNDEF_PARAM);
         RETVALUE(RFAILED);
      }
      else
      {
         /* element not present. Skip the element in event structure and 
            increments the data base pointer appropriately */

         RETVALUE(RSKIP);
      }

   } /* end if */


   /* if element not present and is mandatory, return error */
   if (! pres)
   {
      /* check if element is mandatory */
      if (flag == ELMNT_MAND)
      {
         /* mandatory element is missing */
         MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
         RETVALUE(RFAILED);
      }
      else
      {
         /* element not mandatory, skip it */
         RETVALUE(RSKIP);
      }

   } /* end if */

   RETVALUE(ROK);

} /* end of mgAsnChkEncElmnt */


/*
*
*       Fun:   mgAsnEncMsg 
*
*       Desc:  This function encodes the message by encoding all the token
*              elements it contains.
*
*       Ret:   ROK  (encoding successful)
*              RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncMsg 
(
TknU8       *evntStr,     /* pointer to the event structure */
Buffer      *mBuf,        /* ASN.1 encoded message buffer */
U32         protVar,      /* protocol variant */ 
MgAsnElmntDef  **elmntDef,   /* message defintion */
Region      region,       /* region to allocate the memory from */
Pool        pool,         /* pool to allocate the memory from */
MgAsnErr    *err          /* error to be returned back to the caller */ 
)
#else
PUBLIC S16 mgAsnEncMsg (evntStr, mBuf, protVar, elmntDef, region, pool, err)
TknU8       *evntStr;     /* pointer to the event structure */
Buffer      *mBuf;        /* ASN.1 encoded message buffer */
U32         protVar;      /* protocol variant */ 
MgAsnElmntDef  **elmntDef;   /* message defintion */
Region      region;       /* region to allocate the memory from */
Pool        pool;         /* pool to allocate the memory from */
MgAsnErr   *err;         /* error to be returned back to the caller */ 
#endif
{
   MgAsnMsgCp   msgCp;         /* message control point */
   MgAsnMsgCp   *cpPtr;        /* message control point */
   CmMemListCp  myMemCp;       /* memory control point */
   Mem          myMem;         /* memory control point */
   S16          ret;           /* return value */

   TRC2(mgAsnEncMsg)

   /* update the msgCp pointer */
   cpPtr = &msgCp;

   /* Initialize the message control structure */
   (Void) mgAsnInitAsnMsgCp(&msgCp);

   /* update the message control structure with passed values */

   msgCp.evntStr  = evntStr;      /* event structure */
   msgCp.mBuf     = mBuf;         /* pointer to the allocated message buffer */
   if (protVar == CM_ABNF_PROT_MEGACO_H248)
      msgCp.proType  = MEGACO_V1;     /* the protocol type */
   else
      msgCp.proType  = MEGACO_V2;     /* the protocol type */
   msgCp.elmntDef = elmntDef;     /* message defintion */
   msgCp.secElmntDef = NULLP;     /* secondary message defintion */
   msgCp.secEvntStr = NULLP;      /* secondary event structure */
   msgCp.region   = region;       /* region for the memory */
   msgCp.pool     = pool;         /* pool for the memory */
   msgCp.parents  = 0;            /* number of parents */
   msgCp.shiftOffset = 0;         /* offset to end of shift */
   msgCp.err      = err;          /* error structure pointer */
   msgCp.uBuf     = NULLP;         /* pointer to the allocated message buffer */

   msgCp.memCp    = &myMemCp;     /* automatic mem region/pool */
   myMem. region = region;
   myMem. pool = pool;
   cmInitMemCp(msgCp.memCp, 2048, &myMem); /* this might need cleanup when done */

   /* encode all the elements of the messages. End of message is indicated
      by a null pointer */
   while(*msgCp.elmntDef != (MgAsnElmntDef *)NULLP)
   {
      /* encode the element depending on the element type */
      if ((ret = mgAsnEncElmnt(&msgCp)) != ROK)
      {
         RETVALUE(RFAILED);
      }

   } /* end while */

   /* now add the passed unknown elements to the encoded */
   /* message buffer                                     */

   RETVALUE(ROK);
} /* end of mgAsnEncMsg */


/*
*
*       Fun:   mgAsnEncElmnt 
*
*       Desc:  This function invokes an appropriate encoding routine
*              depending on the element defintion. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncElmnt
(
MgAsnMsgCp  *msgCp  /* message control pointer */
)
#else
PUBLIC S16 mgAsnEncElmnt (msgCp)
MgAsnMsgCp  *msgCp; /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;     /* pointer to element defintion */
   S16          ret;           /* return value */
   U32          lenOffset;      /* Adjusted encoded length */

   TRC2 (mgAsnEncElmnt)

   /* get the element defintion */
   elmntDef = *msgCp->elmntDef;

   /* encode the tag into the array */
   if ((ret = mgAsnEncTag(msgCp)) != ROK) {
      if (ret == RSKIP) { RETVALUE(ROK); }
      RETVALUE(ret);
   }

   /* Store the curent offset for the length */
   lenOffset = mgAsnGetOffset(msgCp);

   /* mg003.105: Changes for Universal Tag */   
   /* Skip encoding tags for sequence of choice */
   if (elmntDef->tag != MG_ASN_UCHOICE)
   {
   ++msgCp->parents;
   }

   /* execute the user function */
   if ((ret = (*elmntDef->funcEnc)(msgCp)) != ROK) { RETVALUE(ret); }

   /* Skip encoding tags for sequence of choice */
   if (elmntDef->tag != MG_ASN_UCHOICE)
   {
   --msgCp->parents;

   /* set the length */
   /*mg002.105: Removed compilation warning*/
      if ((ret = mgAsnSetLen(msgCp, (MsgLen)lenOffset)) != ROK)
      {
         RETVALUE(ret);
      }
   }
   RETVALUE(ret);

} /* mgAsnEncElmnt */


/*
*
*       Fun:   mgAsnEncOctetEnum
*
*       Desc:  This function encodes an octet or a enumerated type
*
*       Ret:   ROK (encoding successful) 
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncOctetEnum 
(
MgAsnMsgCp  *msgCp    /* message control pointer */
)
#else
PUBLIC S16 mgAsnEncOctetEnum (msgCp)
MgAsnMsgCp  *msgCp;   /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;      /* element definition */
   U32           val = 0;            /* pointer to the string */
   U32           tmpVal = 0;         /* pointer to the string */
   U16           numBytes = 0;     /* number of bytes copied */
   Data          pkArray[STR_BUFSIZE]; /* temporary array for encoding */
   S16           ret;            /* return value */


   TRC2(mgAsnEncOctetEnum)
 
   elmntDef = *msgCp->elmntDef;        /* get the element defintion */ 

   /* mg007.105: Changed the encoding of enum similar to integer in
    * generic manner, depending on the type of enum whether TET_ENUM or
    * TET_ENUM32 it will take the event structure properly and supporting of
    * TET_ENUM32 is done under the GCP_ENUM_U32 flag */
   if (elmntDef->type == TET_ENUM) {
      val = ((TknU8*)(msgCp->evntStr))->val;
   }
#ifdef GCP_ENUM_U32
   else {
      val = ((TknU32*)(msgCp->evntStr))->val;
   }
#endif

   /* if enumerated, validate it's value */
   if ((elmntDef->type == TET_ENUM)
#ifdef GCP_ENUM_U32
         || (elmntDef->type == TET_ENUM32)
#endif
      )
   {
      if ((ret = mgAsnChkEnum(val, elmntDef)) != ROK)
      {
         MG_ASN_ERR(msgCp, MG_ASN_UNEXP_VAL);
         RETVALUE(ret);
      }
   }

   cmMemset((U8 *)pkArray, (U8 )0, (PTR)sizeof(pkArray));
   tmpVal = val;
   if(tmpVal != 0)
   {
      while( tmpVal != 0)
      {
         tmpVal >>= 8;
         numBytes++;
      }

      if( (val >> ((numBytes * 8) - 1)) & 0x01 )
      {
         numBytes++;
      }
   }
   else
      numBytes = 1;

   tmpVal = numBytes;   /* assigning number of bytes into tmpVal */
   
   while( numBytes != 0)
   {
      pkArray[--numBytes] = val & 0xff;
      val >>= 8;
   }

   /* encode the octet  in the message buffer */ 
   if ((ret = mgAsnEncOut2Buf(msgCp, pkArray, tmpVal)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(ret);
   }

   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnEncOctetEnum */


/*
*
*       Fun:   mgAsnEncOctetStr
*
*       Desc:  This function encodes an octet string 
*
*       Ret:   ROK (encoding successful) 
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncOctetStr 
(
MgAsnMsgCp   *msgCp         /* message control pointer */
)
#else
PUBLIC S16 mgAsnEncOctetStr (msgCp)
MgAsnMsgCp   *msgCp;        /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;       /* element definition */
   U16           len;            /* length of the string */
   U8           *val;            /* pointer to the string */
   S16           ret;            /* return value */


   TRC2(mgAsnEncOctetStr)

   /* check for the version */

   elmntDef = *msgCp->elmntDef;        /* get the element defintion */ 

   if ((elmntDef->type == TET_STRXL) ||
       (elmntDef->type == TET_STRXL_MEM) ||
       (elmntDef->type == TET_IA5STRXL) || 
       (elmntDef->type == TET_IA5STRXL_MEM))
   {
      len = ((TknStrXL *)msgCp->evntStr)->len;    /* length of the string */
      val = ((TknStrXL *)msgCp->evntStr)->val;    /* Pointer to the string */
   }
   else if ((elmntDef->type == TET_STROSXL_MEM) ||
            (elmntDef->type == TET_IA5STROSXL_MEM))
   {
      len = ((TknStrOSXL *)(msgCp->evntStr))->len;   /* length of the string */
      val = ((TknStrOSXL *)(msgCp->evntStr))->val;   /* Pointer to the string */
   }
   else
   {
      len = (U16) ((TknStr *)msgCp->evntStr)->len;  /* length of the string */
      val = &((TknStr *)msgCp->evntStr)->val[0];    /* Pointer to the string */
   }

   /* encode the value. Copy from the token string to the message buffer  */ 
   if ((ret = mgAsnEncOut2Buf(msgCp, val, len)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(ret);
   }

   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnEncOctetStr */


/*
*
*       Fun:   mgAsnEncIa5Str
*
*       Desc:  This function encodes an IA5 string 
*
*       Ret:   ROK (encoding successful) 
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncIa5Str 
(
MgAsnMsgCp   *msgCp         /* message control pointer */
)
#else
PUBLIC S16 mgAsnEncIa5Str (msgCp)
MgAsnMsgCp   *msgCp;        /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;       /* element definition */
   U16           len;            /* length of the string */
   U8           *val;            /* pointer to the string */
   U16           i;              /* counter */
   S16           ret;            /* return value */
   U16           idx;            /* loop counter */


   TRC2(mgAsnEncIa5Str)

   /* check for the version */

   elmntDef = *msgCp->elmntDef;        /* get the element defintion */ 

   /* get len and val part from token structure */
   if (elmntDef->type == TET_IA5STRXL || elmntDef->type == TET_IA5STRXL_MEM)
   {
      len = ((TknStrXL *)msgCp->evntStr)->len;    /* length of the string */
      val = ((TknStrXL *)msgCp->evntStr)->val;    /* Pointer to the string */
   }
   else
   {
      len = (U16) ((TknStr *)msgCp->evntStr)->len;  /* length of the string */
      val = &((TknStr *)msgCp->evntStr)->val[0];    /* Pointer to the string */
   }

   /* verify the data */
   for (idx = 0; idx < len; idx++)
   {
      /* MSB bit should not be set for IA5 character, IA5String consists of 
       * 128 (or 7 bits)  characters. */
      if (val[idx] & IA5_CHARMASK)
      {
         MG_ASN_ERR(msgCp, MG_ASN_INV_IA5STR);
         RETVALUE(RFAILED);
      }
   }
   i = 0;

   /* encode the value. Copy from the token string to the message buffer  */ 
   if ((ret = mgAsnEncOut2Buf(msgCp, val, len)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(ret);
   }

   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnEncIa5Str */


/*
*
*       Fun:   mgAsnEncNull
*
*       Desc:  This function encodes a Null tag 
*
*       Ret:   ROK (encoding successful) 
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncNull 
(
MgAsnMsgCp   *msgCp     /* message control pointer */
)
#else
PUBLIC S16 mgAsnEncNull (msgCp)
MgAsnMsgCp   *msgCp;    /* message control pointer */
#endif
{
   TRC2(mgAsnEncNull)

   mgAsnSkipElmnt(msgCp);
   RETVALUE(ROK);

} /* mgAsnEncNull */


/*
*
*       Fun:   mgAsnEncBitStr
*
*       Desc:  This function encodes Bit string. 
*
*       Ret:   ROK (encoding successful) 
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: This function is used to encode 8 bit enumerated 
*              bit string. This routine does not check if the user 
*              provides a string like "234A7F000". The maximum number 
*              of trailing zero's should be 7 for the logic to work properly.
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncBitStr 
(
MgAsnMsgCp   *msgCp     /* message control pointer */
)
#else
PUBLIC S16 mgAsnEncBitStr (msgCp)
MgAsnMsgCp   *msgCp;    /* message control pointer */
#endif
{
   U16          i;              /* counter */
   U16          j;              /* counter */
   S16          ret;            /* return value */
   U8           len;            /* length of the string */
   TknStr       *str;           /* token string stricture - size regular */
   TknU8        *evntStr;       /* pointer to event structure */
   U16           ubitIndex;      /* index for unused bit octets */
   MgAsnElmntDef   *elmntDef;      /* element definition */

   /* temporary array for encoding */
   Data         pkArray[BITSTR_BUFSIZE];

   TRC2(mgAsnEncBitStr)

   /* check for the version */

   elmntDef = *msgCp->elmntDef;        /* get the element defintion */ 
   evntStr = (TknU8 *)msgCp->evntStr;  /* get the event structure */
   str = (TknStr *)msgCp->evntStr;      /* pointer to the event structure */
   len = str->len;                      /* length of the string */
   ubitIndex = 0;    /* store the unused bit index */
   i = 1;
   j=0;              /* Initialize the loop counter */

   /* encode the value. Copy from the token string to the array */
   while (len-- > 0)
   {
      pkArray[i++] = str->val[j++]; 
   }

   /* mg007.105: Modified to encode bit string properly */
   if ((( (str->len * 8) - elmntDef->maxLen) > 8) && 
         (( (str->len * 8) - elmntDef->maxLen) <= 0))
   {
      MG_ASN_ERR(msgCp, MG_ASN_OUT_RANGE);
      RETVALUE(RFAILED);
   }

   /* Update the number of unused bits in the array */
   pkArray[ubitIndex] = (Data) ((str->len * 8) - elmntDef->maxLen); 

   /* encode the value */
   if ((ret = mgAsnEncOut2Buf(msgCp, pkArray, i)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(ret);
   }

   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnEncBitStr */


/*
*
*       Fun:   mgAsnEncSetSeq
*
*       Desc:  This function encodes the sequence or a set of tokens 
*
*       Ret:   ROK (encoding successful) 
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAsnEncSetSeq
(
MgAsnMsgCp   *msgCp    /* message control pointer */
)
#else
PUBLIC S16 mgAsnEncSetSeq(msgCp)
MgAsnMsgCp   *msgCp;    /* message control pointer */
#endif
{
   S16          ret;            /* return value */
   TknU8        *evntStr;       /* pointer to event structure */
   U16          i;              /* counter */


   TRC2(mgAsnEncSetSeq)

   /* check for the version */
   evntStr  = (TknU8 *)msgCp->evntStr;  /* get the event structure */
   i = 0;

   /* Increment the database pointer over seq start/set start defintion */
   ++msgCp->elmntDef;

   /* increment the event structure over present token */
   MG_ASN_SKIP_TKNPRES(msgCp);

   /* encode all elements till end of sequence element is encountered */
   while ((*(msgCp->elmntDef))->type != TET_SETSEQ_TERM)
   {
      /* encode the element depending on the element type */
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK)
      {
         /* the error code would already be set, do not do it again */
         RETVALUE(ret);
      }
   } /* end while */

   /* Increment the database pointer over the seq/set end element */
   msgCp->elmntDef++;

   RETVALUE(ROK);

} /* mgAsnEncSetSeq */


/*
*
*       Fun:   mgAsnEncSetSeqOf
*
*       Desc:  This function encodes the repeatable set or a sequence 
*
*       Ret:   ROK (encoding successful) 
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncSetSeqOf 
(
MgAsnMsgCp   *msgCp     /* message control pointer */
)
#else
PUBLIC S16 mgAsnEncSetSeqOf (msgCp)
MgAsnMsgCp   *msgCp;    /* message control pointer */
#endif
{
   S16          ret;            /* return value */
   MgAsnElmntDef   *elmntDef;      /* element definition */
   MgAsnElmntDef   **startDef;     /* element definition for seq/set start */
   TknU16       *startStr;      /* pointer to start of event structure */
   U16          count;          /* element repeat counter */
   U16          nmbEnc;         /* number of elements actually encoded */
   U16          minEnc;         /* minimum elements that need to be encoded */


   TRC2(mgAsnEncSetSeqOf)

   /* check for the version */
   elmntDef = *msgCp->elmntDef;        /* get the element defintion */ 
   startDef = msgCp->elmntDef;         /* pointer to seq/set start */
   startStr = (TknU16 *)msgCp->evntStr; /* get the start of event structure */

   /* get the minimum elements that need to be encoded */
   minEnc = elmntDef->minLen;

   /* get the repeat count for this element */
   count = ((TknU16*)(msgCp->evntStr))->val;
   if (count == 0) {
      MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
      RETVALUE(RFAILED);
   }

   /* increment the event structure over present token */
   MG_ASN_SKIP_TKNPRES(msgCp);

   /* Get pointer array */
   if ((*((TknU8***)msgCp->evntStr)) == NULLP)
   {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      /*mg002.105: Removed compilation warning*/
      RETVALUE(RFAILED);
   }

   /* Loop */
   nmbEnc = 0;
   msgCp->evntStr = *(TknU8**)(msgCp->evntStr);
   while(count)
   {
      /* point the database pointer to seq/set start */
      msgCp->elmntDef = startDef;
      msgCp->elmntDef++;

      /* encode the element depending on the element type */
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK)
      {
         RETVALUE(ret);
      }
      nmbEnc++;

      /* decrement count */
      count--;

   } /* end while */

   /* check for minimum number of elements encoded */
   if (nmbEnc < minEnc)
   {
      MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
      RETVALUE(RFAILED);
   }

   /* reset and skip */
   msgCp->elmntDef = startDef;
   msgCp->evntStr  = (TknU8*)startStr;
   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* end of mgAsnEncSetSeqOf */



/*
*
*       Fun:   mgAsnEncUnconsSetSeqOf
*
*       Desc:  This function encodes the repeatable set or a sequence 
*
*       Ret:   ROK (encoding successful) 
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: This functions is to encode token types :
*                         TET_UNCONS_SET_OF and
*                         TET_UNCONS_SEQ_OF.
*
*              This is similar to encoding of TET_SET_OF and TET_SEQ_OF.
*
*              Only difference is the event structure for UNCONS token types
*              contains only array of pointers instead of actual array of 
*              structure in it. This is done to support SET OF and SEQUENCE OF 
*              with number of elements unknown. 
*
*              But, there is a maximum limit on the number of pointers in the
*              event structure, similar to the number of structures in 
*              SET OF/SEQUENCE OF event structures. This limit is specified in
*              the element definition to library.
*
*              Everything else is similar to TET_SEQ_OF and TET_SET_OF.
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncUnconsSetSeqOf 
(
MgAsnMsgCp   *msgCp     /* message control pointer */
)
#else
PUBLIC S16 mgAsnEncUnconsSetSeqOf (msgCp)
MgAsnMsgCp   *msgCp;    /* message control pointer */
#endif
{
   S16          ret;            /* return value */
   MgAsnElmntDef   *elmntDef;      /* element definition */
   MgAsnElmntDef   **startDef;     /* element definition for seq/set start */
   TknU16       *startStr;      /* pointer to start of event structure */
   TknU8        **pointerArray; /* pointer to event structure */
   U16          count;          /* element repeat counter */
   U16          nmbEnc;         /* number of elements actually encoded */
   U16          minEnc;         /* minimum elements that need to be encoded */


   TRC2(mgAsnEncUnconsSetSeqOf)

   /* check for the version */
   elmntDef = *msgCp->elmntDef;        /* get the element defintion */ 
   startDef = msgCp->elmntDef;         /* pointer to seq/set start */
   startStr = (TknU16 *)msgCp->evntStr; /* get the start of event structure */

   /* get the minimum elements that need to be encoded */
   minEnc = elmntDef->minLen;

   /* get the repeat count for this element */
   count = ((TknU16*)(msgCp->evntStr))->val;
   /* mg003.105: Changes for min number of elements to encode */   
   if ((count == 0) && (minEnc != 0)) {
      MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
      RETVALUE(RFAILED);
   }

   /* increment the event structure over present token */
   MG_ASN_SKIP_TKNPRES(msgCp);

   /* Get pointer array */
   if (((*((TknU8***)msgCp->evntStr)) == NULLP) ||
       (*(*((TknU8***)msgCp->evntStr)) == NULLP))
   {
      if (count != 0) {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      /*mg002.105: Removed compilation warning*/
      RETVALUE(RFAILED);
      }
   }
   pointerArray = *((TknU8***)msgCp->evntStr);

   /* Loop */
   nmbEnc = 0;
   while(count)
   {
      /* point the database pointer to seq/set start */
      msgCp->elmntDef = startDef;
      msgCp->evntStr = pointerArray[nmbEnc];
      msgCp->elmntDef++;
      /* encode the element depending on the element type */
      if ((ret = mgAsnEncElmnt(msgCp)) != ROK)
      {
         RETVALUE(ret);
      }
      nmbEnc++;

      /* decrement count */
      count--;

   } /* end while */

   /* check for minimum number of elements encoded */
   if (nmbEnc < minEnc)
   {
      MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
      RETVALUE(RFAILED);
   }

   /* reset and skip */
   msgCp->elmntDef = startDef;
   msgCp->evntStr  = (TknU8*)startStr;
   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* end of mgAsnEncUnconsSetSeqOf */
#ifdef GCP_CH

/* mg003.105: Added a new function to encode Command Request Sequence set */

/*
*
*       Fun:   mgAsnEncUnconsCmdSetSeqOf
*
*       Desc:  This function encodes the repeatable set or a sequence 
*
*       Ret:   ROK (encoding successful) 
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: This functions is to encode token types :
*                         TET_UNCONS_SET_OF and
*                         TET_UNCONS_SEQ_OF.
*
*              This is similar to encoding of TET_SET_OF and TET_SEQ_OF.
*
*              Only difference is the event structure for UNCONS token types
*              contains only array of pointers instead of actual array of 
*              structure in it. This is done to support SET OF and SEQUENCE OF 
*              with number of elements unknown. 
*
*              But, there is a maximum limit on the number of pointers in the
*              event structure, similar to the number of structures in 
*              SET OF/SEQUENCE OF event structures. This limit is specified in
*              the element definition to library.
*
*              Everything else is similar to TET_SEQ_OF and TET_SET_OF.
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncUnconsCmdSetSeqOf 
(
MgAsnMsgCp   *msgCp     /* message control pointer */
)
#else
PUBLIC S16 mgAsnEncUnconsCmdSetSeqOf (msgCp)
MgAsnMsgCp   *msgCp;    /* message control pointer */
#endif
{
   S16          ret;            /* return value */
   MgAsnElmntDef   *elmntDef;      /* element definition */
   MgAsnElmntDef   **startDef;     /* element definition for seq/set start */
   TknU16       *startStr;      /* pointer to start of event structure */

   TknU8        **pointerArray; /* pointer to event structure */
   U16          count;          /* element repeat counter */
   U16          nmbEnc;         /* number of elements actually encoded */
   U16          minEnc;         /* minimum elements that need to be encoded */


   TRC2(mgAsnEncUnconsCmdSetSeqOf)

   /* check for the version */
   elmntDef = *msgCp->elmntDef;        /* get the element defintion */ 
   startDef = msgCp->elmntDef;         /* pointer to seq/set start */
   startStr = (TknU16 *)msgCp->evntStr; /* get the start of event structure */

   /* get the minimum elements that need to be encoded */
   minEnc = elmntDef->minLen;

   /* get the repeat count for this element */
   count = ((TknU16*)(msgCp->evntStr))->val;
   /* mg005.105: Changed to support empty commands in the action */
/*   if (count == 0) {
      MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
      RETVALUE(RFAILED);
   }*/

   if(count > 0)
   {
      /* increment the event structure over present token */
      MG_ASN_SKIP_TKNPRES(msgCp);

      /* Get pointer array */
#ifndef GCP_CH   
      if (((*((TknU8***)msgCp->evntStr)) == NULLP) ||
          (*(*((TknU8***)msgCp->evntStr)) == NULLP))
#else
      if ((*((TknU8***)msgCp->evntStr)) == NULLP) 
#endif /* GCP_CH */      
      {
         MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
         /*mg002.105: Removed compilation warning*/
         RETVALUE(RFAILED);
      }
#ifdef GCP_CH
      pointerArray = ((TknU8 **)msgCp->evntStr);
#else   
      pointerArray = *((TknU8***)msgCp->evntStr);
#endif /* GCP_CH */   

      /* Loop */
      nmbEnc = 0;
      while(count)
      {
         /* point the database pointer to seq/set start */
         msgCp->elmntDef = startDef;
         msgCp->evntStr = pointerArray[nmbEnc];
         msgCp->elmntDef++;
/*#   ifdef GCP_CH
         msgCp->evntStr += sizeof(CmMemListCp);*/
/*#   endif      */
         /* encode the element depending on the element type */
         if ((ret = mgAsnEncElmnt(msgCp)) != ROK)
         {
            RETVALUE(ret);
         }
         nmbEnc++;

         /* decrement count */
         count--;

      } /* end while */

      /* check for minimum number of elements encoded */
      if (nmbEnc < minEnc)
      {
         MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
         RETVALUE(RFAILED);
      }
   }

   /* reset and skip */
   msgCp->elmntDef = startDef;
   msgCp->evntStr  = (TknU8*)startStr;
   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* end of mgAsnEncUnconsCmdSetSeqOf */

#endif /* GCP_CH */



/* ************************************************************ */
/* Start of decoding functions */


/*
*
*       Fun:    mgAsnDecValue
*
*       Desc:   read the value
*
*       Ret:    ROK     - ok
*
*       Notes:  Does not handle contructor types, just primitives.
*
*       File:   mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecValue
(
Buffer       *mBuf,          /* message buffer */
MgAsnMsgCp   *msgCp,         /* Pointer to message control */
U8           *destStr        /* destination string */
)
#else
PUBLIC S16 mgAsnDecValue(mBuf, msgCp, destStr)
Buffer       *mBuf;          /* message buffer */
MgAsnMsgCp   *msgCp;         /* Pointer to message control */
U8           *destStr;       /* destination string */
#endif
{
   S16        ret;           /* return value */
   MgAsnElmntDef *elmntDef;     /* element defintion */


   TRC2(mgAsnDecValue)

   /* Value has zero length */
   if (msgCp->elmntLen == 0)
   {
      RETVALUE(ROK);
   }

   /* For TET_STRXL_MEM and TET_IA5STRXL_MEM types, destStr was passed as 
    * null. This is because caller don't know the size of the val part. 
    * Allocate the memory for the TknStrXL.val part */
   elmntDef = *msgCp->elmntDef; 
   if (elmntDef->type == TET_STRXL_MEM ||
       elmntDef->type == TET_STROSXL_MEM ||
       elmntDef->type == TET_IA5STROSXL_MEM ||
       elmntDef->type == TET_IA5STRXL_MEM)
   {
      if (mgAsnDecGetMem(msgCp, (Ptr*)&destStr, (msgCp->elmntLen)) != ROK) {
         RETVALUE(RFAILED);
      }

      /* set the val part in TknStrXL */
      if ((elmntDef->type == TET_STROSXL_MEM) ||
          (elmntDef->type == TET_IA5STROSXL_MEM))
         ((TknStrOSXL *)(msgCp->evntStr))->val = destStr;
      else
         ((TknStrXL *)(msgCp->evntStr))->val = destStr;
   }

   /* for NULL types, msgCp->elmntLen will be zero */

   /* copy the primitive to the destination string */
   if ((ret = mgAsnDecBuf2Out(msgCp, destStr, msgCp->elmntLen)) != ROK)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of mgAsnDecValue */


/*
*
*       Fun:   mgAsnChkMsgMandMis 
*
*       Desc:  This function checks whether any mandatory element is
*              missing in a sequence from the message buffer. This routine
*              checks all the elements of the sequence.
*
*       Ret:   ROK     - No mandatory information missing
*              RFAILED - Mandatory information missing
*
*       Notes: <None>
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PRIVATE S16 mgAsnChkMsgMandMis 
(
MgAsnMsgCp  *msgCp  /* message control pointer */
)
#else
PRIVATE S16 mgAsnChkMsgMandMis (msgCp)
MgAsnMsgCp  *msgCp; /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;     /* pointer to element defintion */
   U8           flag;          /* flag */

   TRC2 (mgAsnChkMsgMandMis)

   /* get the element defintion for this element */
   elmntDef = *msgCp->elmntDef;

   while (elmntDef != NULLP)
   {
      /* get the protocol flag for this element */
      flag = FLAG_TO_TYPE(elmntDef->flagp, msgCp->proType);

      /* if element is mandatory, error */
      if (flag == ELMNT_MAND)
      {
         RETVALUE(RFAILED);
      }

      /* element was optional, skip it */
      mgAsnSkipElmnt(msgCp);

      /* get the updated element defintion pointer */
      elmntDef = *msgCp->elmntDef;

   } /* end while */

   RETVALUE(ROK);

} /* mgAsnChkMsgMandMis */


/*
*
*       Fun:   mgAsnChkSeqMandMis 
*
*       Desc:  This function checks whether any mandatory element is
*              missing in a sequence from the message buffer. This routine
*              checks all the elements of the sequence.
*
*       Ret:   ROK/RFAILED 
*
*       Notes: db pointer - Always in the middle of the sequence over
*              the seq start token.
*              evnt pointer - Corresponding event structure.
*
*              db pointer   - element defintion after sequence end token. 
*              evnt pointer - Corresponding event structure.
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnChkSeqMandMis 
(
MgAsnMsgCp  *msgCp  /* message control pointer */
)
#else
PUBLIC S16 mgAsnChkSeqMandMis (msgCp)
MgAsnMsgCp  *msgCp; /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;     /* pointer to element defintion */
   U8           flag;          /* flag */

   TRC2 (mgAsnChkSeqMandMis)

   /* get the element defintion for this element */
   elmntDef = *msgCp->elmntDef;

   while (elmntDef->type != TET_SETSEQ_TERM)
   {
      /* get the protocol flag for this element */
      flag = FLAG_TO_TYPE(elmntDef->flagp, msgCp->proType);

      /* if element is mandatory, error */
      if (flag == ELMNT_MAND)
      {
         MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
         RETVALUE(RFAILED);
      }

      /* element was optional, skip it */
      mgAsnSkipElmnt(msgCp);

      /* get the updated element defintion pointer */
      elmntDef = *msgCp->elmntDef;

   } /* end while */

   /* increment the pointer over seq/set end element */
   msgCp->elmntDef++;

  RETVALUE(ROK);

} /* mgAsnChkSeqMandMis */


/*
*
*       Fun:   mgAsnChkSetMandMis 
*
*       Desc:  This function checks whether any mandatory element is
*          missing in a set from the message buffer. This routine
*              checks all the elements of the set.
*
*       Ret:   ROK/RFAILED 
*
*       Notes: db pointer - Always in the middle of the sequence over
*              the seq start token.
*              evnt pointer - Corresponding event structure.
*
*              db pointer   - element defintion after sequence end token. 
*              evnt pointer - Corresponding event structure.
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PRIVATE S16 mgAsnChkSetMandMis 
(
MgAsnMsgCp  *msgCp  /* message control pointer */
)
#else
PRIVATE S16 mgAsnChkSetMandMis (msgCp)
MgAsnMsgCp  *msgCp; /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;     /* pointer to element defintion */
   U8           flag;          /* flag */
   MgAsnElmntDef   **defPtr;      /* Database pointer */
   TknU8        *evntStr;      /* event structure pointer */

   TRC2 (mgAsnChkSetMandMis)

   /* increment over the start of set element */
   msgCp->elmntDef++;

   /* get the element defintion for the first element */
   elmntDef = *msgCp->elmntDef;

   /* increment the event structure over present token */
   MG_ASN_SKIP_TKNPRES(msgCp);

   while (elmntDef->type != TET_SETSEQ_TERM)
   {
      switch (elmntDef->type)
      {
         case TET_SEQ:
         case TET_SEQ_SPECIAL:
         case TET_SET:

            /* save the pointers */
            defPtr  = msgCp->elmntDef;
            evntStr = msgCp->evntStr;

            /* get the protocol flag for this element */
            flag = FLAG_TO_TYPE(elmntDef->flagp, msgCp->proType);

            /* sequence is mandatory and missing */
            if (flag == ELMNT_MAND)
            {
               if (mgAsnChkSetMandMis(msgCp) == RFAILED)
               {
                  /* no element present in the seq/set of, error  */
                  RETVALUE(RFAILED);
               }
            }

            /* restore the pointers */
            msgCp->elmntDef = defPtr;
            msgCp->evntStr = evntStr;

            /* skip the element */
            mgAsnSkipElmnt(msgCp);

            /* get the updated element defintion pointer */
            elmntDef = *msgCp->elmntDef;

            break;

         case TET_SEQ_OF:
         case TET_SET_OF:

            /* save the pointers */
            defPtr  = msgCp->elmntDef;
            evntStr = msgCp->evntStr;

            /* get the protocol flag for this element */
            flag = FLAG_TO_TYPE(elmntDef->flagp, msgCp->proType);

            /* sequence is mandatory and missing */
            if (flag == ELMNT_MAND)
            {
               if (mgAsnChkSetMandMis(msgCp) == RFAILED)
               {
                  /* no element present in the seq/set of, error  */
                  RETVALUE(RFAILED);
               }
            }

            /* retore the pointers */
            msgCp->elmntDef = defPtr;
            msgCp->evntStr = evntStr;

            /* skip over the sequence */
            mgAsnSkipElmnt(msgCp);

            /* get the updated element defintion pointer */
            elmntDef = *msgCp->elmntDef;

            break;

         case TET_UNCONS_SEQ_OF:
         case TET_UNCONS_SET_OF:
         {
            S32        cntr;        /* counter for elements in set/seq of */
            TknU8      **evntPtrs;  /* pointer to list of event structure 
                                     * pointers in SET/SEQ OF */
            U16        indx;       /* index to the above array of pointers */

            indx = 0;
            cntr  = elmntDef->minLen;  /* check for minimum number of elements 
                                        * in the set/seq of */

            /* save the pointers */
            defPtr  = msgCp->elmntDef;
            evntStr = msgCp->evntStr;

            /* get the protocol flag for this element */
            flag = FLAG_TO_TYPE(elmntDef->flagp, msgCp->proType);

            /* set the pointer to array of pointers in SET OF/SEQ OF 
             * event structure */
            evntPtrs = (TknU8 **)((PTR)evntStr + sizeof(TknU8));

            /* set the correct evntStr */
            msgCp->evntStr = evntPtrs[indx];

            /* sequence is mandatory and missing */
            if (flag == ELMNT_MAND)
            {
               /* check all elements in set/seq of */
               while (cntr && msgCp->evntStr)
               {
                  MgAsnElmntDef *tmpDef;
                  /* set/seq of element definition */
                  msgCp->elmntDef++;

                  tmpDef = *msgCp->elmntDef;

                  /* if element is SET */
                  if (tmpDef->type == TET_SET)
                  {
                     if (mgAsnChkSetMandMis(msgCp) == RFAILED)
                        /* no element present in the seq/set of, error  */
                        RETVALUE(RFAILED);
                  }
                  /* any other element */
                  else if (mgAsnChkEleMandMis(msgCp) == TRUE)
                  {
                     switch (tmpDef->type)
                     {
                        case TET_STRXL:
                        case TET_STRXL_MEM:
                        case TET_IA5STRXL:
                        case TET_IA5STRXL_MEM:
                           if (((TknStrXL *)(msgCp->evntStr))->pres == NOTPRSNT)
                              RETVALUE(RFAILED);
                           break;

                        default:
                           if ((msgCp->evntStr)->pres == NOTPRSNT)
                           {
                              /* mandatory element is missing */
                              MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
                              RETVALUE(RFAILED);
                           }
                           break;
                     }
                  }

                  msgCp->evntStr = evntPtrs[indx++];
                  msgCp->elmntDef = defPtr;
                  cntr--;
               }

               /* check if minimum number of elements were present */
               if (cntr != 0)
                  RETVALUE(RFAILED);
            }

            /* retore the pointers */
            msgCp->elmntDef = defPtr;
            msgCp->evntStr = evntStr;

            /* skip over the sequence */
            mgAsnSkipElmnt(msgCp);

            /* get the updated element defintion pointer */
            elmntDef = *msgCp->elmntDef;

            break;
         }

         default:
         {
            evntStr = msgCp->evntStr;

            /* get the protocol flag for this element */
            flag = FLAG_TO_TYPE(elmntDef->flagp, msgCp->proType);

            /* if element is mandatory, error */
            if (flag == ELMNT_MAND)
            {
               switch (elmntDef->type)
               {
                  case TET_STRXL:
                  case TET_STRXL_MEM:
                  case TET_IA5STRXL:
                  case TET_IA5STRXL_MEM:
                     if (((TknStrXL *)evntStr)->pres == NOTPRSNT)
                        RETVALUE(RFAILED);
                     break;

                  default:
                     if (evntStr->pres == NOTPRSNT)
                     {
                        /* mandatory element is missing */
                        RETVALUE(RFAILED);
                     }
                     break;
               }
            }

            /* skip over the element, event structure and the database
               pointers are both incremented */

            mgAsnSkipElmnt(msgCp);

            /* get the updated element defintion pointer */
            elmntDef = *msgCp->elmntDef;

            break;
         }

      } /* end switch */

   } /* end while */

   /* increment the pointer over seq/set end element */
   msgCp->elmntDef++;

  RETVALUE(ROK);

} /* mgAsnChkSetMandMis */


/*
*
*       Fun:   mgAsnChkEleMandMis 
*
*       Desc:  This function checks whether an element is mandatory. 
*
*       Ret:   TRUE (if element is mandatory)
*              FALSE (if element invalid or optional)
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC Bool mgAsnChkEleMandMis
(
MgAsnMsgCp  *msgCp  /* message control pointer */
)
#else
PUBLIC Bool mgAsnChkEleMandMis (msgCp)
MgAsnMsgCp  *msgCp; /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;     /* pointer to element defintion */
   U8           flag;          /* flag */

   TRC2 (mgAsnChkEleMandMis)

   /* get the element defintion for this element */
   elmntDef = *msgCp->elmntDef;

   /* get the protocol flag for this element */
   flag = FLAG_TO_TYPE(elmntDef->flagp, msgCp->proType);

   /* if element is mandatory, return true */
   if (flag == ELMNT_MAND)
   {
      RETVALUE(TRUE);
   }

   /* either element is optional or not defined for this protocol */
   RETVALUE(FALSE);

} /* mgAsnChkEleMandMis */


/*
*
*       Fun:   mgAsnDecElmnt 
*
*       Desc:  This function invokes an appropriate decoding routine
*              depending on the element defintion. 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecElmnt
(
MgAsnMsgCp  *msgCp  /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecElmnt (msgCp)
MgAsnMsgCp  *msgCp; /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;     /* pointer to element defintion */
   S16          ret;           /* return value */
   MsgLen       msgLen;        /* message length */
   MsgLen       decLen;        /* decode  length */
   /* mg008.105: Added debug prints */
#ifdef MG_ASN_DBG
   MgAsnElmntDef   *tmpElmntDef;     /* pointer to element defintion */
#endif

   TRC2 (mgAsnDecElmnt)

   /* get the element defintion */
   elmntDef = *msgCp->elmntDef;
#ifdef MG_ASN_DBG
   tmpElmntDef = *msgCp->elmntDef;
#endif

   /* get the tag and length */
   if ((ret = mgAsnDecTagLen(msgCp)) != ROK)
   {
      if (ret == RSKIP) { RETVALUE(ROK); }
      RETVALUE(ret);
   }
   msgCp->ignoreBytes = 0;

   /* mg008.105: Added check for elmntLen if it is lessthan msgLen */
   msgLen = mgAsnFindLen(msgCp);
   decLen = msgCp->elmntLen;
   if(decLen == msgLen)
      decLen = 0;
   /* execute the user function */
   if (elmntDef->type == TET_SEQ_SPECIAL) {
      ret = mgAsnDecSeqFunc(msgCp);
   }
   else {
      ret = (*elmntDef->funcDec)(msgCp);
   }

   /* check to see if any extra bytes need to be stripped off */
   if (msgCp->ignoreBytes) {
      if ((ret = mgAsnDecIgnoreBytes(msgCp, msgCp->ignoreBytes)) != ROK)
      {
         MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
         RETVALUE(ret);
      }
      msgCp->ignoreBytes = 0;
   }
   
   if((decLen) && (msgLen != decLen + mgAsnFindLen(msgCp)))
   {
#ifdef MG_ASN_DBG
    *msgCp->elmntDef = tmpElmntDef;
#endif
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(RFAILED);
   }

   RETVALUE(ret);

} /* mgAsnDecElmnt */


/*
*
*       Fun:   mgAsnDecMsg 
*
*       Desc:  This function encodes the message by encoding all the token
*              elements it contains.
*
*       Ret:   ROK  (encoding successful)
*              RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecMsg 
(
TknU8       *evntStr,     /* pointer to the event structure */
Buffer      *mBuf,        /* ASN.1 decoded message buffer */
U32         protVar,      /* protocol variant */ 
MgAsnElmntDef  **msgDef,  /* message defintion */
CmMemListCp *memCp,       /* memory list control block */
MgAsnErr    *err,         /* error to be returned back to the caller */ 
MsgLen      *numDecBytes  /* Number of message bytes decoded */
)
#else
PUBLIC S16 mgAsnDecMsg (evntStr, mBuf, protVar, msgDef, memCp, err, numDecBytes)
TknU8       *evntStr;     /* pointer to the event structure */
Buffer      *mBuf;        /* ASN.1 decoded message buffer */
U32         protVar;      /* protocol variant */ 
MgAsnElmntDef  **msgDef;  /* message defintion */
CmMemListCp *memCp;       /* memory list control block */
MgAsnErr    *err;         /* error to be returned back to the caller */ 
MsgLen      *numDecBytes; /* Number of message bytes decoded */
#endif
{
   MgAsnMsgCp   msgCp;         /* message control point */
   MgAsnMsgCp   *cpPtr;        /* message control point */
   MgAsnElmntDef   *elmntDef;     /* element defintion */
   MsgLen       elmntSize;     /* element size */
   S16          ret;           /* return value */
   MsgLen       msgLen;        /* message length */
   Bool         failure;

   TRC2(mgAsnDecMsg)

   /* update the msgCp pointer */
   cpPtr = &msgCp;

   /* Initialize the message control structure */
   (Void) mgAsnInitAsnMsgCp(&msgCp);

   /* update the message control structure with passed values */

   msgCp.evntStr  = evntStr;     /* event structure */
   msgCp.mBuf     = mBuf;        /* pointer to the allocated message buffer */
   if (protVar == CM_ABNF_PROT_MEGACO_H248)
      msgCp.proType  = MEGACO_V1;     /* the protocol type */
   else
      msgCp.proType  = MEGACO_V2;     /* the protocol type */
   msgCp.elmntDef = msgDef;      /* message defintion */
   msgCp.secElmntDef = NULLP;    /* secondary message defintion */
   msgCp.secEvntStr = NULLP;     /* secondary event structure */
   msgCp.memCp    = memCp;       /* mem region/pool */
   msgCp.region   = memCp->memCb.sMem.region;      /* region for the memory */
   msgCp.pool     = memCp->memCb.sMem.pool;        /* pool for the memory */
   msgCp.shiftOffset = 0;        /* offset to end of shift */
   msgCp.err      = err;         /* switch for unrecoggnized elements */

   elmntDef = *msgCp.elmntDef;   /* get the element defintion */

#if (ERRCLASS & ERRCLS_DEBUG)
   if (!msgCp.mBuf)
   {
      MGASNLOGERROR(ERRCLS_DEBUG, EMG001, (ErrVal)0, 
                               "mgAsnDecMsg () Failed: Null mBuf");
   }
#endif

   /* Get the length of the ASN.1 message buffer */
   msgLen = mgAsnFindLen(&msgCp);

#ifndef MG_ASN_SS

   if (SGetSBuf(msgCp.region, msgCp.pool, &msgCp.sBuf.bufP, 
                (Size) msgLen) != ROK)
   {
      MG_ASN_ERR(cpPtr, MG_ASN_RES_ERR);
      RETVALUE(NULLP);
   }

   msgCp.sBuf.max   = msgLen;             /* max size of the sBuf */
   msgCp.sBuf.stIdx = 0;                  /* start index */
   msgCp.sBuf.size  = 0;                  /* size */

   { 
      MsgLen count;         /* number of bytes copied */

      /* copy the static encoded string to message buffer */
      if ((ret = SCpyMsgFix(
                     msgCp.mBuf,                /* source */
                     0,                          /* source index */
                     msgLen,                     /* size to be copied */
                     msgCp.sBuf.bufP,           /* destination buffer */
                     &count)) != ROK)            /* size actually copied */
      {

         /* throw away the static buffer */
         (Void) SPutSBuf(msgCp.region, 
                         msgCp.pool, 
                         msgCp.sBuf.bufP, 
                         msgCp.sBuf.max);
         RETVALUE(ret);
      }

      /* initialize the static buffer structure */
      msgCp.sBuf.size  = count;
      msgCp.sBuf.stIdx = 0;
   }
#endif

   /* go through all the elements in the message database for this
      message */

   while(elmntDef != (MgAsnElmntDef *)NULLP) 
   {

      /* Check the message length. Bytes will be removed from the mBuf
         in each call of the routines below depending on the type decoded */ 

      msgLen = mgAsnFindLen(&msgCp);

      if (msgLen == 0)           /* no information left to be decoded */
      {
         /* check if any mandatory element misssing in the message */
         if (mgAsnChkMsgMandMis(&msgCp) != ROK)
         {

#ifndef MG_ASN_SS
            /* throw away the static buffer */
            (Void) SPutSBuf(msgCp.region, 
                            msgCp.pool, 
                            msgCp.sBuf.bufP, 
                            msgCp.sBuf.max);
#endif

            MG_ASN_ERR(cpPtr, MG_ASN_MAND_MIS);
            RETVALUE(RFAILED);
         }
         else
         {
            /* no mandatory information missing in the message */
            break;
         }
      }

      /* decode the element depending on the element type */
      if ((ret = mgAsnDecElmnt(&msgCp)) != ROK)
      {

#ifndef MG_ASN_SS
      /* throw away the static buffer */
      (Void) SPutSBuf(msgCp.region, 
                      msgCp.pool, 
                      msgCp.sBuf.bufP, 
                      msgCp.sBuf.max);
#endif
         RETVALUE(RFAILED);
      }

      /* get the incremented element defintion */
      elmntDef = *msgCp.elmntDef;

   } /* end while */

   elmntSize = mgAsnFindLen(&msgCp);
   *numDecBytes = msgLen - elmntSize;
   if (*numDecBytes > 0) *numDecBytes = *numDecBytes - 1;
   *numDecBytes = 1;

   failure = FALSE;

#ifndef MG_ASN_SS
      /* throw away the static buffer */
   (Void) SPutSBuf(msgCp.region, 
                   msgCp.pool, 
                   msgCp.sBuf.bufP, 
                   msgCp.sBuf.max);
#endif

   if (failure)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* end of mgAsnDecMsg */


/*
*
*       Fun:    mgAsnDecOctetEnum 
*
*       Desc:   This function decodes an octet and enumerated types.
*
*       Ret:    ROK 
*
*       Notes:  None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecOctetEnum 
(
MgAsnMsgCp   *msgCp   /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecOctetEnum (msgCp)
MgAsnMsgCp   *msgCp;  /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;      /* element definition */
   Buffer       *mBuf;          /* message buffer */
   U32          val;           /* decoded integer value */
   Data         unPkArray[STR_BUFSIZE]; /* temporary array for decoding */
   U8           i;             /* index into unPkArray */
   S16          ret;            /* return value */


   TRC2(mgAsnDecOctetEnum)


   elmntDef = *msgCp->elmntDef;        /* get the element definition */
   mBuf     = msgCp->mBuf;             /* get the message buffer */

   /* mg007.105: Changed the decoding of enum similar to integer in
    * generic manner, depending on the type of enum whether TET_ENUM or
    * TET_ENUM32 it will fill the event structure properly and supporting of
    * TET_ENUM32 is done under the GCP_ENUM_U32 flag */
   /* read the element value into the event structure */
   if ((ret = mgAsnDecValue(mBuf, msgCp, unPkArray)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(ret);
   }

   /* make the element present in the event structure */

   i = 0;
   if( msgCp->elmntLen > 1)
   {
      if( (unPkArray[0] == 0x00 ) && ((unPkArray[1] & 0x80) == 0x80)) /* Shouldn't consecutive 9 1's */ 
      {
         i++;
      }   
      else if( ((unPkArray[0] == 0x00 ) && ((unPkArray[1] & 0x80) == 0x00)) ||
               ((unPkArray[0] & 0x80) == 0x80)) /* Shouldn't consecutive 9 0's */
      {
         MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
         RETVALUE(RFAILED);
      }

   }
   else
      if((unPkArray[0] & 0x80) != 0x00)
      {
         MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
         RETVALUE(RFAILED);
      }

   val = 0;
   for ( ; i < msgCp->elmntLen; i++)
   {
       val = (U32)((val << 8) | unPkArray[i]);
   }

   if ( (elmntDef->type == TET_ENUM)
#ifdef GCP_ENUM_U32
         || (elmntDef->type == TET_ENUM32)
#endif
      )
   {
      /* enumerated type, check it's value */
      if ((ret = mgAsnChkEnum(val, elmntDef)) != ROK)
      {
         MG_ASN_ERR(msgCp, MG_ASN_UNEXP_VAL);
         RETVALUE(ret);
      }

   } /* endif */

   ((TknU8*)(msgCp->evntStr))->pres = PRSNT_NODEF;
   if (elmntDef->type == TET_ENUM) {
      ((TknU8*)(msgCp->evntStr))->val = val;
   }
#ifdef GCP_ENUM_U32
   else {
      ((TknU32*)(msgCp->evntStr))->val = val;
   }
#endif

   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnDecOctetEnum */


/*
*
*       Fun:   mgAsnDecNull 
*
*       Desc:  This function decodes a null ASN.1 type. 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecNull 
(
MgAsnMsgCp   *msgCp   /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecNull (msgCp)
MgAsnMsgCp   *msgCp;  /* message control pointer */
#endif
{
   TknU8        *evntStr;       /* pointer to event structure */


   TRC2(mgAsnDecNull)

   evntStr  = (TknU8 *)msgCp->evntStr; /* get the event structure */

   /* check if this is a duplicate element */
   if (evntStr->pres)
   {
      MG_ASN_ERR(msgCp, MG_ASN_DUP_ELMNT);
      RETVALUE(RFAILED);
   }

   /* no errors, make the element present in the event structure */
   evntStr->pres = PRSNT_NODEF;

   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnDecNull */


/*
*
*       Fun:    mgAsnDecOctetStr 
*
*       Desc:  This function decodes an octet string value
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecOctetStr 
(
MgAsnMsgCp   *msgCp   /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecOctetStr (msgCp)
MgAsnMsgCp   *msgCp;  /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;       /* element definition */
   Bool          pres;           /* element present flag */
   U8           *str;            /* String */
   S16           ret;            /* return value */


   TRC2(mgAsnDecOctetStr)

   elmntDef = *msgCp->elmntDef;        /* get the element definition */

   if (elmntDef->type == TET_STRXL ||
       elmntDef->type == TET_IA5STRXL ||
       elmntDef->type == TET_IA5STRXL_MEM ||
       elmntDef->type == TET_STRXL_MEM)
   {
      pres = ((TknStrXL *)(msgCp->evntStr))->pres;
   }
   else
   {
      pres = msgCp->evntStr->pres;
   }

   /* check if this is a duplicate element */
   if (pres)
   {
      /* duplicate element */
      MG_ASN_ERR(msgCp, MG_ASN_DUP_ELMNT);
      RETVALUE(RFAILED);
   }

   if ((elmntDef->type == TET_STRXL) ||
       (elmntDef->type == TET_IA5STRXL))
   {
      str = ((TknStrXL *)(msgCp->evntStr))->val;

      /* Check if storage for the sting hasn't been allocated by the user */
      if (str == NULLP)
      {
         MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
         RETVALUE(RFAILED);
      }
   }
   else if ((elmntDef->type == TET_STRXL_MEM) ||
            (elmntDef->type == TET_IA5STRXL_MEM))
   {
      str = ((TknStrXL *)(msgCp->evntStr))->val;

      /* Check if storage for the string already allocated by user */
      if (str != NULLP)
      {
         MG_ASN_ERR(msgCp, MG_ASN_MEM_ALRDY_ALLOCD);
         RETVALUE(RFAILED);
      }

      /* Allocate memory for val part: This cannot be done here, because
       * we don't know the length to allocate memory for TknStrXL. So,
       * allocate the memory in mgAsnDecValue when token type is TET_STRXL_MEM. */
   }
   else if ((elmntDef->type == TET_STROSXL_MEM) ||
            (elmntDef->type == TET_IA5STROSXL_MEM))
   {
      str = ((TknStrOSXL *)(msgCp->evntStr))->val;

      /* Check if storage for the string already allocated by user */
      if (str != NULLP)
      {
         MG_ASN_ERR(msgCp, MG_ASN_MEM_ALRDY_ALLOCD);
         RETVALUE(RFAILED);
      }

      /* Allocate memory for val part: This cannot be done here, because
       * we don't know the length to allocate memory for TknStrXL. So,
       * allocate the memory in mgAsnDecValue when token type is TET_STROSXL_MEM.*/
   }
   else
   {
      str = &((TknStr *)(msgCp->evntStr))->val[0];
   }

   /* read the element value into the event structure */
   if ((ret = mgAsnDecValue(msgCp->mBuf, msgCp, (U8 *)str)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(ret);
   }

   if ((elmntDef->type == TET_STRXL || elmntDef->type == TET_STRXL_MEM) ||
       (elmntDef->type == TET_IA5STRXL || elmntDef->type == TET_IA5STRXL_MEM))
   {
      /* make the element present in the event structure */
      ((TknStrXL *)(msgCp->evntStr))->pres = PRSNT_NODEF;

      /* update the length of the primitive */
      ((TknStrXL *)(msgCp->evntStr))->len  = msgCp->elmntLen;
   }
   else
   {
      /* make the element present in the event structure */
      ((TknStr *)(msgCp->evntStr))->pres = PRSNT_NODEF;

      /* update the length of the primitive */
      if ((elmntDef->type == TET_STROSXL_MEM) ||
          (elmntDef->type == TET_IA5STROSXL_MEM))
         ((TknStrOSXL *)(msgCp->evntStr))->len  = msgCp->elmntLen;
      else
         /*mg002.105: Removed compilation warning*/
         ((TknStr *)(msgCp->evntStr))->len  = (U8)msgCp->elmntLen;
   }

   /* now skip over the element */
   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnDecOctetStr */


/*
*
*       Fun:    mgAsnDecIa5Str 
*
*       Desc:  This function decodes an IA5 string value
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecIa5Str 
(
MgAsnMsgCp   *msgCp   /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecIa5Str (msgCp)
MgAsnMsgCp   *msgCp;  /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;       /* element definition */
   Bool          pres;           /* element present flag */
   U8           *str;            /* String */
   S16           ret;            /* return value */
   U16           i;              /* loop counter */


   TRC2(mgAsnDecIa5Str)

   elmntDef = *msgCp->elmntDef;        /* get the element definition */

   if (elmntDef->type == TET_IA5STRXL || elmntDef->type == TET_IA5STRXL_MEM)
   {
      pres = ((TknStrXL *)(msgCp->evntStr))->pres;
   }
   else
   {
      pres = msgCp->evntStr->pres;
   }

   /* check if this is a duplicate element */
   if (pres)
   {
      /* duplicate element */
      MG_ASN_ERR(msgCp, MG_ASN_DUP_ELMNT);
      RETVALUE(RFAILED);
   }

   if (elmntDef->type == TET_IA5STRXL)
   {
      str = ((TknStrXL *)(msgCp->evntStr))->val;

      /* Check if storage for the sting hasn't been allocated by the user */
      if (str == NULLP)
      {
         MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
         RETVALUE(RFAILED);
      }
   }
   else if (elmntDef->type == TET_IA5STRXL_MEM)
   {
      str = ((TknStrXL *)(msgCp->evntStr))->val;

      /* Check if storage for the sting has't been allocated by the user */
      if (str != NULLP)
      {
         MG_ASN_ERR(msgCp, MG_ASN_MEM_ALRDY_ALLOCD);
         RETVALUE(RFAILED);
      }

      /* Allocate memory for val part: This cannot be done here, because
       * we don't know the length to allocate memory for TknStrXL. So,
       * allocate the memory in mgAsnDecValue when token type is 
       * TET_IA5STRXL_MEM. */
   }
   else
   {
      str = &((TknStr *)(msgCp->evntStr))->val[0];
   }

   /* read the element value into the event structure */
   if ((ret = mgAsnDecValue(msgCp->mBuf, msgCp, (U8 *)str)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(ret);
   }

   if (elmntDef->type == TET_IA5STRXL || elmntDef->type == TET_IA5STRXL_MEM)
   {
      /* make the element present in the event structure */
      ((TknStrXL *)(msgCp->evntStr))->pres = PRSNT_NODEF;

      /* update the length of the primitive */
      ((TknStrXL *)(msgCp->evntStr))->len  = msgCp->elmntLen;

      /* get the str again, because val part was allocated in case STRXL_MEM */
      str = ((TknStrXL *)(msgCp->evntStr))->val;
   }
   else
   {
      /* make the element present in the event structure */
      ((TknStr *)(msgCp->evntStr))->pres = PRSNT_NODEF;

      /* update the length of the primitive */
      /*mg002.105: Removed compilation warning*/
      ((TknStr *)(msgCp->evntStr))->len  = (U8)msgCp->elmntLen;
   }

   /* verify the data */
   for (i = 0; i < msgCp->elmntLen; i++)
   {
      /* mask the MSB. This is required because, sender may be sending 0/1
       * as MSB */ 
      str[i] = str[i] & ~IA5_CHARMASK;
   }

   /* now skip over the element */
   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnDecIa5Str */


/*
*
*       Fun:   mgAsnDecBitStr
*
*       Desc:  This function decodes a bit string. 
*
*       Ret:   ROK 
*
*       Notes: This function decodes only 8 bit enumerated bit
*              string. 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecBitStr 
(
MgAsnMsgCp   *msgCp   /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecBitStr (msgCp) 
MgAsnMsgCp   *msgCp;  /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;      /* element definition */
   S16          ret;            /* return value */
   TknStr12     *evntStr;       /* pointer to event structure */
   Buffer       *mBuf;          /* message buffer */
   S16          j;


   TRC2(mgAsnDecBitStr)


   evntStr  = (TknStr12 *)(msgCp->evntStr); /* get the event structure */
   elmntDef = *msgCp->elmntDef;        /* get the element definition */
   mBuf     = msgCp->mBuf;             /* get the message buffer */

   /* check if this is a duplicate element */
   if (evntStr->pres)
   {
      /* duplicate element */
      MG_ASN_ERR(msgCp, MG_ASN_DUP_ELMNT);
      RETVALUE(RFAILED);
   }

   /* read the element value into the event structure */
   if ((ret = mgAsnDecValue(mBuf, msgCp, (U8 *)(evntStr->val))) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(ret);
   }

   /* mg007.105: Check if length is 1 and then it should only contain 
      value as 00 of initial octet */
   if ((evntStr->val[0] == 1) && (evntStr->val[1] == 0))
   {
      /* make the element present in the event structure */
      evntStr->pres = PRSNT_NODEF; 
      evntStr->val[0] = evntStr->val[1];
   }
   else
   {
      /* mg007.105: checking for the number of bits padded */
      if (!(evntStr->val[0] <= 7))
      {
         MG_ASN_ERR(msgCp, MG_ASN_OUT_RANGE);
         RETVALUE(RFAILED);
      }

      /* Check for the none of the unused bits are set */
      for (j = 0; j < evntStr->val[0];j++)
      {
         if((evntStr->val[msgCp->elmntLen - 1] >> j) & 0x01)
         {
            MG_ASN_ERR(msgCp, MG_ASN_UNEXP_VAL);
            RETVALUE(RFAILED);
         }
      }

      /* the first byte of the event structure contains the number of
         unused bits in the last byte, strip this byte and advance all
         bytes forward by 1 byte */
      for (j = 0; j < (msgCp->elmntLen -1); j++)
      {
         evntStr->val[j] = evntStr->val[j+1];
      }

      /* zero out the last octet as it is already advanced */
      evntStr->val[msgCp->elmntLen -1] = 0;

      /* make the element present in the event structure */
      evntStr->pres = PRSNT_NODEF; 
   }
   /* update the length in the bit string based on the maxLen in database
   * element */
   for (j=1;((S8)((j * 8) - elmntDef->maxLen) < 0); j++);

   evntStr->len = j;

   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnDecBitStr */


/*
*
*       Fun:   mgAsnDecSeq 
*
*       Desc:  This function decodes the sequence element 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecSeq 
(
MgAsnMsgCp   *msgCp   /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecSeq (msgCp)
MgAsnMsgCp   *msgCp;  /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;      /* element definition */
   S16          ret;            /* return value */
   TknU8        *evntStr;       /* pointer to event structure */
   MsgLen       prevLen;        /* msg length before decoding element */
   Buffer       *mBuf;          /* message buffer */
   MsgLen       elmntLen;       /* element length */


   TRC2(mgAsnDecSeq)

   evntStr  = (TknU8 *)msgCp->evntStr; /* get the event structure */
   elmntDef = *msgCp->elmntDef;        /* get the element definition */
   mBuf     = msgCp->mBuf;             /* get the message buffer */

   /* increment the data base pointer over the start of sequence element */
   ++msgCp->elmntDef;

   /* make the sequence present as true */
   evntStr->pres = PRSNT_NODEF;

   /* increment the event structure over present token */
   MG_ASN_SKIP_TKNPRES(msgCp);

   /* go through the loop and decode all the elements of the sequence */
   elmntLen = msgCp->elmntLen;
   while ((*(msgCp->elmntDef))->type != TET_SETSEQ_TERM)
   {
      if (elmntLen <= 0)
      {
         if (elmntLen < 0)
         {
            MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
            RETVALUE(RFAILED);
         }

         /* check for any mandatory element missing and return */
         if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK)
         {
            RETVALUE(ret);
         }
         RETVALUE(ROK);
      } /* end if */

      prevLen = mgAsnFindLen(msgCp);

      /* decode the element depending on the element type */
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK)
      {
         /* do not fill error as already filled in */ 
         RETVALUE(ret);
      }

      /* decrement the sequence length depending on the element size */
      elmntLen -= prevLen - mgAsnFindLen(msgCp);

   } /* end while */

   if (elmntLen != 0)
   {
      /* unknown bytes at the end of the sequence */
      if (! IS_IGNORE_EXT(elmntDef, msgCp->proType))
      {
         /* unrecognized element at the end of sequence, call the handler */
         prevLen = 0;
         while (elmntLen > 0)
         {
            if ((ret = mgAsnCpyUnrecogElmnt(msgCp, &prevLen)) != ROK)
            {
               RETVALUE(RFAILED);
            }

            if (elmntLen >= prevLen)
            {
               elmntLen = (elmntLen - prevLen);
            }
            else
            {
               MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
               RETVALUE(RFAILED);
            }

            prevLen = 0;
         }
      }

   } /* end if */

   /* Assuming the event structure pointer will be automatically
      incremented when the individual elements are decoded */

   /* Increment the database pointer over end of sequence element */
   msgCp->elmntDef++;

   RETVALUE(ROK);

}


/*
*
*       Fun:   mgAsnDecSeqFunc
*
*       Desc:  This function decodes the sequence element 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecSeqFunc
(
MgAsnMsgCp   *msgCp    /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecSeqFunc (msgCp)
MgAsnMsgCp   *msgCp;  /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;      /* element definition */
   S16          ret;            /* return value */
   TknU8        *evntStr;       /* pointer to event structure */
   MsgLen       prevLen;        /* msg length before decoding element */
   Buffer       *mBuf;          /* message buffer */
   MsgLen       elmntLen;       /* element length */
   MgAsnElmntDef   **saveElmntDef;
   TknU8*       saveEvntStr;


   TRC2(mgAsnDecSeqFunc)

   evntStr  = (TknU8 *)msgCp->evntStr; /* get the event structure */
   elmntDef = *msgCp->elmntDef;        /* get the element definition */
   mBuf     = msgCp->mBuf;             /* get the message buffer */
   saveElmntDef = msgCp->elmntDef;
   saveEvntStr = msgCp->evntStr;

   /* increment the data base pointer over the start of sequence element */
   ++msgCp->elmntDef;

   /* make the sequence present as true */
   evntStr->pres = PRSNT_NODEF;

   /* go through the loop and decode all the elements of the sequence */
   elmntLen = msgCp->elmntLen;
   while ((*(msgCp->elmntDef))->type != TET_SETSEQ_TERM)
   {
      if (elmntLen <= 0)
      {
         if (elmntLen < 0)
         {
            MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
            RETVALUE(RFAILED);
         }

         /* check for any mandatory element missing and return */
         if ((ret = mgAsnChkSeqMandMis(msgCp)) != ROK)
         {
            RETVALUE(ret);
         }
         msgCp->elmntDef = saveElmntDef;
         msgCp->evntStr = saveEvntStr;
         mgAsnSkipElmnt(msgCp);
         RETVALUE(ROK);
      } /* end if */

      prevLen = mgAsnFindLen(msgCp);

      /* decode the element depending on the element type */
      if ((ret = elmntDef->funcDec(msgCp)) != ROK)
      {
         RETVALUE(ret);
      }

      /* decrement the sequence length depending on the element size */
      elmntLen -= ((S16)prevLen - (S16)mgAsnFindLen(msgCp));

   } /* end while */

   if (elmntLen != 0)
   {
      /* unknown bytes at the end of the sequence */
      if (! IS_IGNORE_EXT(elmntDef, msgCp->proType))
      {
         /* unrecognized element at the end of sequence, call the handler */
         prevLen = 0;
         while (elmntLen > 0)
         {
            if ((ret = mgAsnCpyUnrecogElmnt(msgCp, &prevLen)) != ROK)
            {
               RETVALUE(RFAILED);
            }

            if (elmntLen >= prevLen)
            {
               elmntLen = (elmntLen - prevLen);
            }
            else
            {
               MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
               RETVALUE(RFAILED);
            }

            prevLen = 0;
         }
      }

   } /* end if */

   /* reset and skip */
   msgCp->elmntDef = saveElmntDef;
   msgCp->evntStr = saveEvntStr;
   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);
} /* mgAsnDecSeqFunc */


/*
*
*       Fun:   mgAsnDecSetSeqOf
*
*       Desc:  This function decodes the repeatable sequence or set
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecSetSeqOf
(
MgAsnMsgCp   *msgCp   /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecSetSeqOf (msgCp)
MgAsnMsgCp   *msgCp;  /* message control pointer */
#endif
{
   S16          ret;            /* return value */
   MgAsnElmntDef   *elmntDef;      /* element definition */
   MgAsnElmntDef   **startDef;      /* stored element definition */
   TknU16       *startEvnt;     /* pointer to event structure */
   TknU8        **arrPtr;       /* pointer to pointer array */
   MsgLen       prevLen;        /* msg length before decoding element */
   S32          cntr;           /* counter for elements in set/seq of */
   S32          minDec;         /* minimum number of elements to be decoded */
   S32          repCntr;        /* counter for elements in set/seq of */
   MsgLen       elmntLen;       /* elemnt length */


   TRC2(mgAsnDecSetSeqOf)

   startDef = msgCp->elmntDef;        /* store element definition pointer */
   startEvnt= (TknU16 *)msgCp->evntStr;/* store the event structure pointer */
   elmntDef = *msgCp->elmntDef;        /* get the element definition */
   cntr     = elmntDef->repCntr;       /* get the repeat counter */
   minDec   = elmntDef->minLen;        /* get the minimum no. to be decoded */
   repCntr  = cntr;                    /* save the repeat counter */

   /* make the set/sequence of present as true */
   startEvnt->pres = PRSNT_NODEF;

   /* increment the event structure over present token */
   MG_ASN_SKIP_TKNPRES(msgCp);

   /* go through the loop and decode all the elements of the sequence */
   elmntLen = msgCp->elmntLen;
   arrPtr = (TknU8**)(msgCp->evntStr);
   while ((cntr) && (elmntLen > 0))
   {
      /* reset the element defintions */
      msgCp->elmntDef = startDef;
      msgCp->elmntDef++;
      elmntDef = *msgCp->elmntDef;


      /* Allocate space for element */
      if (mgAsnDecGetMem(msgCp, (Ptr*)&arrPtr[(repCntr - cntr)], (elmntDef->evSize)) != ROK) {
         RETVALUE(RFAILED);
      }

      /* decode the element depending on the element type */
      msgCp->evntStr = arrPtr[(repCntr - cntr)];
      prevLen = mgAsnFindLen(msgCp);
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }

      /* decrement the sequence length depending on the element size */
      elmntLen -= prevLen - mgAsnFindLen(msgCp);

      /* decrement the counter */
      cntr--;
   } /* end while */
   msgCp->elmntDef = startDef;  /* restore db pointer to seq of start */
   msgCp->evntStr  = (TknU8*)startEvnt;  /* restore ev ptr to seq of start */
   startEvnt->val = (repCntr - cntr);

   /* minimum number of elements not decoded */
   if (minDec > (repCntr - cntr))
   {
      MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
      RETVALUE(RFAILED);
   }

   /* check for the seq/set of length */
   if (elmntLen > 0)
   {
      MG_ASN_ERR(msgCp, MG_ASN_EXTRA_PARAM);
      RETVALUE(RFAILED);
   }

   mgAsnSkipElmnt(msgCp);        /* skip the element */

   RETVALUE(ROK);

} /* end of mgAsnDecSetSeqOf */

#ifdef GCP_CH

/* mg003.105: Added a new function to encode Command Request Sequence set */
/*
*
*       Fun:   mgAsnDecCmdSetSeqOf
*
*       Desc:  This function decodes the repeatable sequence or set
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecCmdSetSeqOf
(
MgAsnMsgCp   *msgCp   /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecCmdSetSeqOf (msgCp)
MgAsnMsgCp   *msgCp;  /* message control pointer */
#endif
{
   S16          ret;            /* return value */
   MgAsnElmntDef   *elmntDef;      /* element definition */
   MgAsnElmntDef   **startDef;      /* stored element definition */
   TknU16       *startEvnt;     /* pointer to event structure */
   TknU8        **arrPtr;       /* pointer to pointer array */
   MsgLen       prevLen;        /* msg length before decoding element */
   S32          cntr;           /* counter for elements in set/seq of */
   S32          minDec;         /* minimum number of elements to be decoded */
   S32          repCntr;        /* counter for elements in set/seq of */
   MsgLen       elmntLen;       /* elemnt length */
   MgMgcoCommandReq  *cmd;


   TRC2(mgAsnDecCmdSetSeqOf)

   startDef = msgCp->elmntDef;        /* store element definition pointer */
   startEvnt= (TknU16 *)msgCp->evntStr;/* store the event structure pointer */
   elmntDef = *msgCp->elmntDef;        /* get the element definition */
   cntr     = elmntDef->repCntr;       /* get the repeat counter */
   minDec   = elmntDef->minLen;        /* get the minimum no. to be decoded */
   repCntr  = cntr;                    /* save the repeat counter */

   /* make the set/sequence of present as true */
   startEvnt->pres = PRSNT_NODEF;

   /* increment the event structure over present token */
   MG_ASN_SKIP_TKNPRES(msgCp);

   /* go through the loop and decode all the elements of the sequence */
   elmntLen = msgCp->elmntLen;
   arrPtr = (TknU8**)(msgCp->evntStr);
   while ((cntr) && (elmntLen > 0))
   {
      /* reset the element defintions */
      msgCp->elmntDef = startDef;
      msgCp->elmntDef++;
      elmntDef = *msgCp->elmntDef;


#ifdef GCP_CH

            if (mgAllocEventMem((Ptr *)&(cmd),
                                   sizeof(MgMgcoCommandReq)) != CM_ABNF_ROK){
         RETVALUE(RFAILED);
      }

#else               
      /* Allocate space for element */
      if (mgAsnDecGetMem(msgCp, (Ptr*)&arrPtr[(repCntr - cntr)], (elmntDef->evSize)) != ROK) {
         RETVALUE(RFAILED);
      }
#endif      

      prevLen = mgAsnFindLen(msgCp);
#ifdef GCP_CH
      msgCp->evntStr = (TknU8*)cmd;
#else               
      /* decode the element depending on the element type */
      msgCp->evntStr = arrPtr[(repCntr - cntr)];
#endif /* GCP_CH */
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
#ifdef GCP_CH
      msgCp->evntStr = (TknU8*)cmd;
#endif               

      /* decrement the sequence length depending on the element size */
      elmntLen -= prevLen - mgAsnFindLen(msgCp);

      /* decrement the counter */
      cntr--;
   } /* end while */
   msgCp->elmntDef = startDef;  /* restore db pointer to seq of start */
   msgCp->evntStr  = (TknU8*)startEvnt;  /* restore ev ptr to seq of start */
   startEvnt->val = (repCntr - cntr);

   /* minimum number of elements not decoded */
   if (minDec > (repCntr - cntr))
   {
      MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
      RETVALUE(RFAILED);
   }

   /* check for the seq/set of length */
   if (elmntLen > 0)
   {
      MG_ASN_ERR(msgCp, MG_ASN_EXTRA_PARAM);
      RETVALUE(RFAILED);
   }

   mgAsnSkipElmnt(msgCp);        /* skip the element */

   RETVALUE(ROK);

} /* end of mgAsnDecCmdSetSeqOf */

#endif /* GCP_CH */


/*
*
*       Fun:   mgAsnDecUnconsSetSeqOf
*
*       Desc:  This function decodes the repeatable sequence or set
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: This functions is to decode token types :
*                         TET_UNCONS_SET_OF and
*                         TET_UNCONS_SEQ_OF.
*
*              This is similar to decoding of TET_SET_OF and TET_SEQ_OF.
*
*              Only difference is the event structure for UNCONS token types
*              contains only array of pointers instead of actual array of
*              structure in it. This is done to support SET OF and SEQUENCE OF
*              with number of elements unknown.
*
*              But, there is a maximum limit on the number of pointers in the
*              event structure, similar to the number of structures in
*              SET OF/SEQUENCE OF event structures. This limit is specified in
*              the element definition to library.
*
*              Here, we dynamically allocate the memory for SET/SEQUENCE OF
*              elements before calling the mgAsnDecElmnt, if we have some thing
*              to decode.
*
*              Everything else is similar to TET_SEQ_OF and TET_SET_OF.
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecUnconsSetSeqOf
(
MgAsnMsgCp   *msgCp   /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecUnconsSetSeqOf (msgCp)
MgAsnMsgCp   *msgCp;  /* message control pointer */
#endif
{
   struct tmpList { TknU16 num; TknU8** lst; };
   S16          ret;            /* return value */
   MgAsnElmntDef   *elmntDef;      /* element definition */
   MgAsnElmntDef   **startDef;      /* stored element definition */
   struct tmpList  *startEvnt;     /* pointer to event structure */
   TknU8        **arrPtr;       /* pointer to pointer array */
   MsgLen       prevLen;        /* msg length before decoding element */
   S32          cntr;           /* counter for elements in set/seq of */
   S32          minDec;         /* minimum number of elements to be decoded */
   S32          repCntr;        /* counter for elements in set/seq of */
   MsgLen       elmntLen;       /* elemnt length */


   TRC2(mgAsnDecUnconsSetSeqOf)

   startDef = msgCp->elmntDef;        /* store element definition pointer */
   startEvnt= (struct tmpList *)msgCp->evntStr;/* store the event structure pointer */
   elmntDef = *msgCp->elmntDef;        /* get the element definition */
   cntr     = elmntDef->repCntr;       /* get the repeat counter */
   minDec   = elmntDef->minLen;        /* get the minimum no. to be decoded */
   repCntr  = cntr;                    /* save the repeat counter */

   /* make the set/sequence of present as true */
   startEvnt->num.pres = PRSNT_NODEF;

   /* create pointer array */
   /*mg002.105: Removed compilation warning*/
   if (mgAsnDecGetMem(msgCp, (Ptr*)&arrPtr, (MsgLen)(sizeof(TknU8*)*(unsigned long)cntr)) != ROK) {
      RETVALUE(RFAILED);
   }
   startEvnt->lst = arrPtr;

   /* increment the event structure over present token */
   MG_ASN_SKIP_TKNPRES(msgCp);

   /* go through the loop and decode all the elements of the sequence */
   elmntLen = msgCp->elmntLen;
   while ((cntr) && (elmntLen > 0))
   {
      /* reset the element defintions */
      msgCp->elmntDef = startDef;
      msgCp->elmntDef++;
      elmntDef = *msgCp->elmntDef;


      /* Allocate space for element */
      if (mgAsnDecGetMem(msgCp, (Ptr*)&arrPtr[(repCntr - cntr)], (elmntDef->evSize)) != ROK) {
         RETVALUE(RFAILED);
      }

      /* decode the element depending on the element type */
      prevLen = mgAsnFindLen(msgCp);
      msgCp->evntStr = arrPtr[(repCntr - cntr)];
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) { RETVALUE(ret); }
      elmntLen -= prevLen - mgAsnFindLen(msgCp);

      /* decrement the counter */
      cntr--;
   } /* end while */
   msgCp->elmntDef = startDef;  /* restore db pointer to seq of start */
   msgCp->evntStr  = (TknU8*)startEvnt;  /* restore ev ptr to seq of start */
   startEvnt->num.val = (repCntr - cntr);

   /* minimum number of elements not decoded */
   if (minDec > (repCntr - cntr))
   {
      MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
      RETVALUE(RFAILED);
   }

   /* check for the seq/set of length */
   if (elmntLen > 0)
   {
      MG_ASN_ERR(msgCp, MG_ASN_EXTRA_PARAM);
      RETVALUE(RFAILED);
   }

   mgAsnSkipElmnt(msgCp);        /* skip the element */

   RETVALUE(ROK);

} /* end of mgAsnDecUnconsSetSeqOf */

#ifdef GCP_CH

/* mg003.105: Added a new function to decode Command Request Sequence set */
/*
*
*       Fun:   mgAsnDecUnconsCmdSetSeqOf
*
*       Desc:  This function decodes the repeatable sequence or set
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: This functions is to decode token types :
*                         TET_UNCONS_SET_OF and
*                         TET_UNCONS_SEQ_OF.
*
*              This is similar to decoding of TET_SET_OF and TET_SEQ_OF.
*
*              Only difference is the event structure for UNCONS token types
*              contains only array of pointers instead of actual array of
*              structure in it. This is done to support SET OF and SEQUENCE OF
*              with number of elements unknown.
*
*              But, there is a maximum limit on the number of pointers in the
*              event structure, similar to the number of structures in
*              SET OF/SEQUENCE OF event structures. This limit is specified in
*              the element definition to library.
*
*              Here, we dynamically allocate the memory for SET/SEQUENCE OF
*              elements before calling the mgAsnDecElmnt, if we have some thing
*              to decode.
*
*              Everything else is similar to TET_SEQ_OF and TET_SET_OF.
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecUnconsCmdSetSeqOf
(
MgAsnMsgCp   *msgCp   /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecUnconsCmdSetSeqOf (msgCp)
MgAsnMsgCp   *msgCp;  /* message control pointer */
#endif
{
   struct tmpList { TknU16 num; TknU8* lst[MGT_MAX_CMDS]; };
   S16          ret;            /* return value */
   MgAsnElmntDef   *elmntDef;      /* element definition */
   MgAsnElmntDef   **startDef;      /* stored element definition */
   struct tmpList  *startEvnt;     /* pointer to event structure */
   /* mg003.105: Removed unused variable */
   /*MgMgcoCommandReq     *arrPtr[MGT_MAX_CMDS];*//* Commands */
   MgMgcoCommandReq  *cmd;
   CmMemListCp *txnMemCp;        /* memory list control block */
   MsgLen       prevLen;        /* msg length before decoding element */
   S32          cntr;           /* counter for elements in set/seq of */
   S32          minDec;         /* minimum number of elements to be decoded */
   S32          repCntr;        /* counter for elements in set/seq of */
   MsgLen       elmntLen;       /* elemnt length */


   TRC2(mgAsnDecUnconsCmdSetSeqOf)

   startDef = msgCp->elmntDef;        /* store element definition pointer */
   startEvnt= (struct tmpList *)msgCp->evntStr;/* store the event structure pointer */
   elmntDef = *msgCp->elmntDef;        /* get the element definition */
   cntr     = elmntDef->repCntr;       /* get the repeat counter */
   minDec   = elmntDef->minLen;        /* get the minimum no. to be decoded */
   repCntr  = cntr;                    /* save the repeat counter */

   /* mg005.105: Changed to support empty commands in the action */
   /* increment the event structure over present token */
      MG_ASN_SKIP_TKNPRES(msgCp);

   /* go through the loop and decode all the elements of the sequence */
   elmntLen = msgCp->elmntLen;

   /* make the set/sequence of present as true */
   if(elmntLen != 0)
      startEvnt->num.pres = PRSNT_NODEF;

   while ((cntr) && (elmntLen > 0))
   {
      /* reset the element defintions */
      msgCp->elmntDef = startDef;
      msgCp->elmntDef++;
      elmntDef = *msgCp->elmntDef;

      if (mgAllocEventMem((Ptr *)&(cmd), sizeof(MgMgcoCommandReq)) != CM_ABNF_ROK)
      {
         RETVALUE(RFAILED);
      }

      txnMemCp = msgCp->memCp;
      msgCp->memCp = &cmd->memCp;
      /* decode the element depending on the element type */
      prevLen = mgAsnFindLen(msgCp);
      msgCp->evntStr = (TknU8*)cmd;

      /* Set the present field  before decoding */
      cmd->pres.pres = PRSNT_NODEF;
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) 
      { 
         mgFreeEventMem((Ptr)cmd);                                       
         RETVALUE(ret); 
        }
      startEvnt->lst[repCntr-cntr] = (TknU8*)cmd;
      elmntLen -= prevLen - mgAsnFindLen(msgCp);

      msgCp->memCp = txnMemCp;
      /* decrement the counter */
      cntr--;
   } /* end while */
   msgCp->elmntDef = startDef;  /* restore db pointer to seq of start */
   msgCp->evntStr  = (TknU8*)startEvnt;  /* restore ev ptr to seq of start */
   startEvnt->num.val = (repCntr - cntr);

   /* minimum number of elements not decoded */
   if (minDec > (repCntr - cntr))
   {
      MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
      RETVALUE(RFAILED);
   }

   /* check for the seq/set of length */
   if (elmntLen > 0)
   {
      MG_ASN_ERR(msgCp, MG_ASN_EXTRA_PARAM);
      RETVALUE(RFAILED);
   }

   mgAsnSkipElmnt(msgCp);        /* skip the element */

   RETVALUE(ROK);

} /* end of mgAsnDecUnconsCmdSetSeqOf */

/*
*
*       Fun:   mgAsnDecUnconsCmdRepSetSeqOf
*
*       Desc:  This function decodes the repeatable sequence or set
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: This functions is to decode token types :
*                         TET_UNCONS_SET_OF and
*                         TET_UNCONS_SEQ_OF.
*
*              This is similar to decoding of TET_SET_OF and TET_SEQ_OF.
*
*              Only difference is the event structure for UNCONS token types
*              contains only array of pointers instead of actual array of
*              structure in it. This is done to support SET OF and SEQUENCE OF
*              with number of elements unknown.
*
*              But, there is a maximum limit on the number of pointers in the
*              event structure, similar to the number of structures in
*              SET OF/SEQUENCE OF event structures. This limit is specified in
*              the element definition to library.
*
*              Here, we dynamically allocate the memory for SET/SEQUENCE OF
*              elements before calling the mgAsnDecElmnt, if we have some thing
*              to decode.
*
*              Everything else is similar to TET_SEQ_OF and TET_SET_OF.
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecUnconsCmdRepSetSeqOf
(
MgAsnMsgCp   *msgCp   /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecUnconsCmdRepSetSeqOf (msgCp)
MgAsnMsgCp   *msgCp;  /* message control pointer */
#endif
{
   struct tmpList { TknU16 num; TknU8* lst[MGT_MAX_CMDS]; };
   S16          ret;            /* return value */
   MgAsnElmntDef   *elmntDef;      /* element definition */
   MgAsnElmntDef   **startDef;      /* stored element definition */
   struct tmpList  *startEvnt;     /* pointer to event structure */
   /* mg003.105: Removed unused variable */
   /*MgMgcoCmdReply     *arrPtr[MGT_MAX_CMDS];*//* Commands */
   MgMgcoCmdReply  *cmd;
   CmMemListCp *txnMemCp;        /* memory list control block */
   MsgLen       prevLen;        /* msg length before decoding element */
   S32          cntr;           /* counter for elements in set/seq of */
   S32          minDec;         /* minimum number of elements to be decoded */
   S32          repCntr;        /* counter for elements in set/seq of */
   MsgLen       elmntLen;       /* elemnt length */


   TRC2(mgAsnDecUnconsCmdRepSetSeqOf)

   startDef = msgCp->elmntDef;        /* store element definition pointer */
   startEvnt= (struct tmpList *)msgCp->evntStr;/* store the event structure pointer */
   elmntDef = *msgCp->elmntDef;        /* get the element definition */
   cntr     = elmntDef->repCntr;       /* get the repeat counter */
   minDec   = elmntDef->minLen;        /* get the minimum no. to be decoded */
   repCntr  = cntr;                    /* save the repeat counter */

   /* increment the event structure over present token */
   MG_ASN_SKIP_TKNPRES(msgCp);

   /* go through the loop and decode all the elements of the sequence */
   elmntLen = msgCp->elmntLen;
   /* make the set/sequence of present as true */
   if(elmntLen != 0)
      startEvnt->num.pres = PRSNT_NODEF;
   while ((cntr) && (elmntLen > 0))
   {
      /* reset the element defintions */
      msgCp->elmntDef = startDef;
      msgCp->elmntDef++;
      elmntDef = *msgCp->elmntDef;

      if (mgAllocEventMem((Ptr *)&(cmd), sizeof(MgMgcoCmdReply)) != CM_ABNF_ROK){
         RETVALUE(RFAILED);
      }
      txnMemCp = msgCp->memCp;
      msgCp->memCp = &cmd->memCp;
      /* decode the element depending on the element type */
      prevLen = mgAsnFindLen(msgCp);
      msgCp->evntStr = (TknU8*)cmd;
      if ((ret = mgAsnDecElmnt(msgCp)) != ROK) 
      { 
         mgFreeEventMem((Ptr)cmd);
         RETVALUE(ret); 
      }
      startEvnt->lst[repCntr-cntr] = (TknU8*)cmd;
      elmntLen -= prevLen - mgAsnFindLen(msgCp);

      msgCp->memCp = txnMemCp;
      /* decrement the counter */
      cntr--;
   } /* end while */
   msgCp->elmntDef = startDef;  /* restore db pointer to seq of start */
   msgCp->evntStr  = (TknU8*)startEvnt;  /* restore ev ptr to seq of start */
   startEvnt->num.val = (repCntr - cntr);

   /* minimum number of elements not decoded */
   if (minDec > (repCntr - cntr))
   {
      MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
      RETVALUE(RFAILED);
   }

   /* check for the seq/set of length */
   if (elmntLen > 0)
   {
      MG_ASN_ERR(msgCp, MG_ASN_EXTRA_PARAM);
      RETVALUE(RFAILED);
   }

   mgAsnSkipElmnt(msgCp);        /* skip the element */

   RETVALUE(ROK);

} /* end of mgAsnDecUnconsCmdRepSetSeqOf */

#endif /* GCP_CH */


/* **************************************************************** */


/*
*
*       Fun:   mgAsnEncChoice
*
*       Desc:  This function encodes the choice ASN.1 type
*
*       Ret:   ROK (encoding successful)
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncChoice
(
MgAsnMsgCp   *msgCp     /* message control pointer */
)
#else
PUBLIC S16 mgAsnEncChoice(msgCp)
MgAsnMsgCp   *msgCp;    /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;      /* element definition */
   MgAsnElmntDef   **tmpDef;       /* temporary element defintion */
   TknU8        *evntStr;       /* pointer to event structure */
   U8           elmntIdx;       /* element index */
   TknU8        *tmpStr;        /* temporary pointer */
   U16          i;              /* counter */


   TRC2(mgAsnEncChoice)


   /* set automatics */
   elmntDef = *msgCp->elmntDef;        /* get the element defintion */
   tmpDef   = msgCp->elmntDef;         /* store the element defn. pointer */
   tmpStr   = (TknU8 *)msgCp->evntStr; /* get the event structure */
   evntStr  = (TknU8 *)msgCp->evntStr; /* get the event structure */

   /* point the array index to the byte after the tag */
   i = 0;

   /* get the element index */
   if (elmntDef->type == TET_CHOICE) {
      elmntIdx = evntStr->val;
   }
   else {
      elmntIdx = evntStr->val + 1;
   }

   /* validate index */
   if (elmntIdx < 1) {
      MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
      RETVALUE(RFAILED);
   }

   /* increment the event structure over present token */
   MG_ASN_SKIP_TKNPRES(msgCp);
   evntStr = msgCp->evntStr;
   msgCp->elmntDef++;

   /* initialize counter */
   i = 1;

   /* skip n elements in the database */
   while ((i < elmntIdx) && (elmntDef->type != TET_SETSEQ_TERM))
   {
      /* skip the element */
      mgAsnSkipElmnt(msgCp);

      /* restore the event structure pointer */
      msgCp->evntStr = evntStr;

      /* update the element defintion */
      elmntDef = *msgCp->elmntDef;

      i++;
   }

   if (elmntDef->type == TET_SETSEQ_TERM)
   {
      /* reached the end of choice, error */
      MG_ASN_ERR(msgCp, MG_ASN_BAD_IDX);
      RETVALUE(RFAILED);
   }

   /* now encode the element */
   if (mgAsnEncElmnt(msgCp) != ROK)
   {
      RETVALUE(RFAILED);
   }

   /* restore and skip */
   msgCp->elmntDef = tmpDef;
   msgCp->evntStr  = tmpStr;
   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnEncChoice */


/*
*
*       Fun:   mgAsnDecChoice
*
*       Desc:  This function decodes the repeatable sequence or set
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecChoice
(
MgAsnMsgCp   *msgCp   /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecChoice (msgCp)
MgAsnMsgCp   *msgCp;  /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;      /* element definition */
   MgAsnElmntDef   **defPtr;       /* element definition */
   S16          ret;            /* return value */
   TknU8        *evntStr;       /* pointer to event structure */
   TknU8        *strPtr;        /* pointer to event structure */
   TknU8        *tmpPtr;        /* temporary pointer to event structure */
   Buffer       *mBuf;          /* message buffer */
   U16          j;              /* element counter */
   Bool         multChoice;     /* multiple choice flag */


   TRC2(mgAsnDecChoice)

   multChoice = FALSE;

   defPtr    = msgCp->elmntDef;        /* store element definition pointer */
   strPtr    = msgCp->evntStr;         /* store event structure pointer */

   evntStr  = (TknU8 *)msgCp->evntStr; /* get the event structure */
   elmntDef = *msgCp->elmntDef;        /* get the element definition */
   mBuf     = msgCp->mBuf;             /* get the message buffer */

   /* Set the start of the choice val */
   if (elmntDef->type == TET_CHOICE)
      j = 1;
   else
      j = 0;

   /* increment over the start of choice */
   msgCp->elmntDef++;

   /* get the element defintion of first element */
   elmntDef = *msgCp->elmntDef;

   /* skip over the present token */
   mgAsnIncPtr((PTR *)&msgCp->evntStr, sizeof(TknU8));

   /* initialize the element count */
   while (elmntDef->type != TET_SETSEQ_TERM)
   {
      /* Check the tag */
      tmpPtr = msgCp->evntStr;
      if ((ret = mgAsnChkTag(msgCp)) == ROK)
      {
         break;
      }
      if (ret != RSKIP) { mgAsnSkipElmnt(msgCp); }
      msgCp->evntStr = tmpPtr;

      elmntDef = *msgCp->elmntDef;
      ++j;
   } /* end while */

   if (elmntDef->type == TET_SETSEQ_TERM)
   {
      /* did not find a match, unknown element */

      /* Restore the pointers to the start of choice */
      msgCp->elmntDef = defPtr;
      msgCp->evntStr  = strPtr;

      /* Check if element is mandatory */
      if (mgAsnChkEleMandMis(msgCp) == TRUE)
      {
         /* element is mandatory, cannot be skipped */
         MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
         RETVALUE(RFAILED);
      }
      else
      {
         /* element is not mandatory, can be skipped */
         mgAsnSkipElmnt(msgCp);
         RETVALUE(ROK);
      }
   }
   else
   {
      /* make the element as present in the event structure */
      strPtr->pres = PRSNT_NODEF;                   /* choice present */
      strPtr->val  = (U8) j;                        /* element index */
   }

   /* decode the element depending on the element type */
   if (multChoice == FALSE && ((ret = mgAsnDecElmnt(msgCp)) != ROK))
   {
      /* error code already filled, don't do it again */
      RETVALUE(RFAILED);
   }

   /* restore the element defintion to choice start */
   msgCp->elmntDef = defPtr;

   /* restore the event structure */
   msgCp->evntStr = strPtr;

   /* now skip over the set */
   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* end of mgAsnDecChoice */

/*
*
*       Fun:    mgAsnEncOid
*
*       Desc:   This function encodes an object identifier type
*
*       Ret:   ROK (encoding successful)
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes:
*
*       File:   mg_asn.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAsnEncOid
(
MgAsnMsgCp    *msgCp             /* message control pointer */
)
#else
PUBLIC S16 mgAsnEncOid (msgCp)
MgAsnMsgCp    *msgCp;            /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;       /* element definition */
   TknOid       *evntStr;        /* pointer to event structure */
   U32           val;            /* value of an object Identifier component */
   Data          pkArray[OIDSTR_BUFSIZE]; /* temporary array for encoding */
   U16           idx;            /* Index thru pkArray */
   U16           i;              /* look counters */
   S16           ret;            /* return value */

   TRC2(mgAsnEncOid)

   /* check for the version */

   elmntDef = *msgCp->elmntDef;         /* get the element defintion */
   evntStr  = (TknOid *)msgCp->evntStr;  /* get the event structure */

   /* mg008.105: Corrected the encoding of subidentifiers,
    * idx has to start with 0 */
   idx = 0;

   /* derive value of first subidentifier from the first two Object Identifier
      components in the Object identifier string being encoded */

   val = (U32)(40 * evntStr->val[0] + evntStr->val[1]);

   for (i = 2; i <= evntStr->len; i++)
   {
       U8 tmpStr[6];   /* temporary string to hold subidentifier value */
       U8 k=0;         /* index into the temporary string */

       if (val == 0)
          pkArray[idx++] = 0;
       else
       {
          while (val)
          {
             tmpStr[k++] = (0x80 | (val & 0x7F));
             val >>= 7;
          }
          tmpStr[0] = (tmpStr[0] & 0x7F); /* bit 8 of LSB should be reset */

          /* copy the encoded value to the oid string in reverse order */
          while (k > 0)
          {
             pkArray[idx++] = tmpStr[k-1];
              k--;
          }
       }
       val = (U32)evntStr->val[i];
   }


   /* encode the value */
   if ((ret = mgAsnEncOut2Buf(msgCp, pkArray, idx)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(ret);
   }

   /* skip over the element */
   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnEncOid */

/*
*
*       Fun:    mgAsnDecOid
*
*       Desc:  This function decodes an Object Identifier value
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecOid
(
MgAsnMsgCp   *msgCp              /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecOid (msgCp)
MgAsnMsgCp   *msgCp;             /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;       /* element definition */
   TknOid       *evntStr;        /* pointer to event structure */
   Buffer       *mBuf;           /* message buffer */
   Data          unPkArray[OIDSTR_BUFSIZE]; /* temporary array for decoding */
   U16           idx;            /* index */
   U8            i;
   S16           ret;            /* return value */

   TRC2(mgAsnDecOid)

   evntStr  = (TknOid *)(msgCp->evntStr); /* get the event structure */
   elmntDef = *msgCp->elmntDef;           /* get the element definition */
   mBuf     = msgCp->mBuf;                /* get the message buffer */

   /* check if this is a duplicate element */
   if (evntStr->pres)
   {
      /* duplicate element */
      MG_ASN_ERR(msgCp, MG_ASN_DUP_ELMNT);
      RETVALUE(RFAILED);
   }

   /* read the element value into the event structure */
   if ((ret = mgAsnDecValue(mBuf, msgCp, unPkArray)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(ret);
   }

   idx = 0;
   i   = 0;
   while (msgCp->elmntLen > 0)
   {
      U32 val = 0;
      U16 oid1;
      U16 oid2;
      U8  data;

      do
      {
         data = unPkArray[i];
         val = ((val << 7) | ( data & 0x7F));
         i++;
         msgCp->elmntLen--;
      } while (data & 0x80);

      if (idx == 0)
      {
         oid1 = (val / 40);
         oid2 = (val % 40);
         if (oid1 > 2)
         {
            oid2 += ((oid1 - 2) * 40);
            oid1 = 2;
         }
         evntStr->val[idx++] = oid1;
         evntStr->val[idx++] = oid2;
      }
      else
         evntStr->val[idx++] = (U16)val;
   }

   /* make the element present in the event structure */
   evntStr->pres = PRSNT_NODEF;

   /* update the length of the primitive */
   evntStr->len = (U8) idx;

   /* skip over the element */
   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnDecOid */

/*
*
*       Fun:   mgAsnEncInteger
*
*       Desc:  This function encodes an Integer type
*
*       Ret:   ROK (encoding successful)
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncInteger
(
MgAsnMsgCp   *msgCp              /* message control pointer */
)
#else
PUBLIC S16 mgAsnEncInteger (msgCp)
MgAsnMsgCp   *msgCp;             /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;       /* element definition */
   U32           val;            /* pointer to the string */
   U32           tmpVal;         /* pointer to the string */
   U16           numBytes=0;     /* number of bytes copied */
   Data          pkArray[STR_BUFSIZE]; /* temporary array for encoding */
   S16           ret;            /* return value */

   TRC2(mgAsnEncInteger)


   elmntDef = *msgCp->elmntDef;        /* get the element defintion */
   if (elmntDef->type == TET_INT8) {
      val = ((TknU8*)(msgCp->evntStr))->val;
   }
   else if (elmntDef->type == TET_INT16) {
      val = ((TknU16*)(msgCp->evntStr))->val;
   }
   else {
      val = ((TknU32*)(msgCp->evntStr))->val;
   }

   cmMemset((U8 *)pkArray, (U8 )0, (PTR)sizeof(pkArray));
   tmpVal = val;
   if(tmpVal != 0)
   {
      while( tmpVal != 0)
      {
         tmpVal >>= 8;
         numBytes++;
      }

      if( (val >> ((numBytes * 8) - 1)) & 0x01 )
      {
         numBytes++;
      }
   }
   else
      numBytes = 1;

   tmpVal = numBytes;   /* assigning number of bytes into tmpVal */

   while( numBytes != 0)
   {
      pkArray[--numBytes] = val & 0xff;
      val >>= 8;
   }

   /* encode the value */
   if ((ret = mgAsnEncOut2Buf(msgCp, pkArray, tmpVal)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(ret);
   }

   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnEncInteger */

/*
*
*       Fun:    mgAsnDecInteger
*
*       Desc:  This function decodes an octet string value
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecInteger
(
MgAsnMsgCp   *msgCp   /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecInteger (msgCp)
MgAsnMsgCp   *msgCp;             /* message control pointer */
#endif
{
   MgAsnElmntDef    *elmntDef;      /* element definition */
   Buffer         *mBuf;          /* message buffer */
   U32            val;           /* decoded integer value */
   Data           unPkArray[STR_BUFSIZE]; /* temporary array for decoding */
   U8             i;             /* index into unPkArray */
   S16            ret;           /* return value */

   TRC2(mgAsnDecInteger)

   elmntDef = *msgCp->elmntDef;        /* get the element definition */
   mBuf     = msgCp->mBuf;             /* get the message buffer */

   /* read the element value into the event structure */
   if ((ret = mgAsnDecValue(mBuf, msgCp, unPkArray)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(ret);
   }

   /* make the element present in the event structure */

   i = 0;
   if( msgCp->elmntLen > 1)
   {
      if( (unPkArray[0] == 0x00 ) && ((unPkArray[1] & 0x80) == 0x80))  
      {
         i++;
      }   
      else if( (((unPkArray[0] == 0x00 ) && ((unPkArray[1] & 0x80) == 0x00)) ||
               ((unPkArray[0] & 0x80) == 0x80)) || 
               ((elmntDef->maxLen + 1 == msgCp->elmntLen) && (unPkArray[0] != 0x00 ))
            )
      {
         MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
         RETVALUE(RFAILED);
      }

   }
   else
      if((unPkArray[0] & 0x80) != 0x00)
      {
         MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
         RETVALUE(RFAILED);
      }
   val = 0;
   for ( ; i < msgCp->elmntLen; i++)
   {
       val = (U32)((val << 8) | unPkArray[i]);
   }

   ((TknU8*)(msgCp->evntStr))->pres = PRSNT_NODEF;

   if (elmntDef->type == TET_INT8) {
      ((TknU8*)(msgCp->evntStr))->val = val;
   }
   else if (elmntDef->type == TET_INT16) {
      ((TknU16*)(msgCp->evntStr))->val = val;
   }
   else {
      ((TknU32*)(msgCp->evntStr))->val = val;
   }

   /* skip over the element */
   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnDecInteger */


/*
*
*       Fun:   mgAsnEncIntRng
*
*       Desc:  This function encodes an Integer type with range check.
*
*       Ret:   ROK (encoding successful)
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncIntRng
(
MgAsnMsgCp   *msgCp              /* message control pointer */
)
#else
PUBLIC S16 mgAsnEncIntRng (msgCp)
MgAsnMsgCp   *msgCp;             /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;       /* element definition */
   TknU32       *evntStr;        /* pointer to event structure */
   U32           val;            /* pointer to the string */
   U16           numBytes=0;     /* number of bytes copied */
   Data          pkArray[STR_BUFSIZE]; /* temporary array for encoding */
   U16           i;              /* counter */
   S16           ret;            /* return value */
   U8            zero_oct;       /* flag TRUE if leading octet to be zero */

   TRC2(mgAsnEncIntRng)

   /* check for the version */

   elmntDef = *msgCp->elmntDef;        /* get the element defintion */
   evntStr = (TknU32 *)msgCp->evntStr;  /* get the event structure */

   /* point the array index to the byte after the tag */
   i = 0;

   val = evntStr->val;           /* value in the event structure */

   /* check for value within specified range */
   if ((val < elmntDef->minLen) || (val > elmntDef->maxLen))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGASNLOGERROR(ERRCLS_DEBUG, EMG002, (ErrVal)val,
                   "mgAsnEncIntRng () failed: value out of range");
#endif /* ERRCLASS & ERRCLS_DEBUG */

      RETVALUE(RFAILED);
   }

   zero_oct = FALSE;
   /* set zero_oct flag to true if MSB bit is set to 1 to fill a leading zero
    * octet.
    */

   if ((U32)val > (U32)0xFFFFFF)
   {
      if (val < 0x80FFFFFF)
        numBytes = (U8)4;
      else
      {
        numBytes = (U8)5;
        zero_oct = TRUE;
      }
   }
   else if ((U32)val > (U32)0xFFFF)
   {
      if (val < 0x80FFFF)
        numBytes = (U8)3;
      else
      {
        numBytes = (U8)4;
        zero_oct = TRUE;
      }
   }
   else if ((U32)val > (U32)0xFF)
   {
      if (val < 0x80FF)
        numBytes = (U8)2;
      else
      {
        numBytes = (U8)3;
        zero_oct = TRUE;
      }
   }
   else
   {
      if (val < 0x80)
        numBytes = (U8)1;
      else
      {
        numBytes = (U8)2;
        zero_oct = TRUE;
      }
   }

   pkArray[i++] = (Data) numBytes;

   /* fill leading zero octet if flag is TRUE */
   if (zero_oct)
   {
      pkArray[i++] = 0x00;
      numBytes--;
   }

   switch(numBytes)
   {
      case 4:
         pkArray[i++] = GetHiByte(GetHiWord(evntStr->val));;
      case 3:
         pkArray[i++] = GetLoByte(GetHiWord(evntStr->val));;
      case 2:
         pkArray[i++] = GetHiByte(GetLoWord(evntStr->val));;
      case 1:
         pkArray[i++] = GetLoByte(GetLoWord(evntStr->val));;
   }

   /* encode the value */
   if ((ret = mgAsnEncOut2Buf(msgCp, pkArray, i)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(ret);
   }

   /* skip over the element */
   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnEncIntRng */

/*
*
*       Fun:    mgAsnDecIntRng
*
*       Desc:  This function decodes an INTEGER value with range check.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecIntRng
(
MgAsnMsgCp   *msgCp   /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecIntRng (msgCp)
MgAsnMsgCp   *msgCp;             /* message control pointer */
#endif
{
   MgAsnElmntDef    *elmntDef;      /* element definition */
   TknU32       *evntStr;        /* pointer to event structure */
   Buffer        *mBuf;          /* message buffer */
   U32            val;           /* decoded integer value */
   Data           unPkArray[STR_BUFSIZE]; /* temporary array for decoding */
   U8             i;             /* index into unPkArray */
   S16            ret;           /* return value */

   TRC2(mgAsnDecIntRng)

   evntStr = (TknU32 *)msgCp->evntStr;  /* get the event structure */
   elmntDef = *msgCp->elmntDef;        /* get the element definition */
   mBuf     = msgCp->mBuf;             /* get the message buffer */

   /* check if this is a duplicate element */
   if (evntStr->pres)
   {
      /* duplicate element */
      MG_ASN_ERR(msgCp, MG_ASN_DUP_ELMNT);
      RETVALUE(RFAILED);
   }

   /* read the element value into the event structure */
   if ((ret = mgAsnDecValue(mBuf, msgCp, unPkArray)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(ret);
   }

   /* make the element present in the event structure */
   evntStr->pres = PRSNT_NODEF;

   val = (U32)unPkArray[0];

   /* check for the leading zero octet and skip if present */
   if ((val == 0) && (msgCp->elmntLen > 1))
   {
      val = (U32)unPkArray[1];
      for (i = 2; i < msgCp->elmntLen; i++)
      {
        val = (U32)((val << 8) | unPkArray[i]);
      }
   }
   else
   {
      for (i = 1; i < msgCp->elmntLen; i++)
        val = (U32)((val << 8) | unPkArray[i]);
   }

   evntStr->val = val;

   /* check for the value in specified range */
   if ((val < elmntDef->minLen) || (val > elmntDef->maxLen))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGASNLOGERROR(ERRCLS_DEBUG, EMG003, (ErrVal)val,
                   "mgAsnDecIntRng () failed: value out of range");
#endif /* ERRCLASS & ERRCLS_DEBUG */

      RETVALUE(RFAILED);
   }

   /* skip over the element */
   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnDecIntRng */

/* ------------------------------------------------------------- */

/*
*
*       Fun:   mgAsnEncBool
*
*       Desc:  This function encodes a boolean type
*
*       Ret:   ROK (encoding successful)
*              ROUTRES (out of resources)
*              RFAILED (general failure)
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncBool
(
MgAsnMsgCp  *msgCp    /* message control pointer */
)
#else
PUBLIC S16 mgAsnEncBool (msgCp)
MgAsnMsgCp  *msgCp;   /* message control pointer */
#endif
{
   MgAsnElmntDef   *elmntDef;      /* element definition */
   S16          ret;            /* return value */
   TknU8        *evntStr;       /* pointer to event structure */

   /* temporary array for encoding */
   Data         pkArray[OCTET_BUFSIZE];

   TRC2(mgAsnEncBool)

   elmntDef = *msgCp->elmntDef;        /* get the element defintion */
   evntStr = (TknU8 *)msgCp->evntStr;  /* get the event structure */

   /* copy from the event structure the boolean value */
   if (evntStr->val == TRUE)
   {
      pkArray[0] = MG_ASN_TRUE;
   }
   else
   {
      pkArray[0] = MG_ASN_FALSE;
   }

   /* encode the octet in the message buffer */
   if ((ret = mgAsnEncOut2Buf(msgCp, pkArray, 1)) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(ret);
   }

   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnEncBool */


/*
*
*       Fun:    mgAsnDecBool
*
*       Desc:   This function decodes an octet and enumerated types.
*
*       Ret:    ROK
*
*       Notes:  None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecBool
(
MgAsnMsgCp   *msgCp   /* message control pointer */
)
#else
PUBLIC S16 mgAsnDecBool (msgCp)
MgAsnMsgCp   *msgCp;  /* message control pointer */
#endif
{

   MgAsnElmntDef   *elmntDef;      /* element definition */
   S16          ret;            /* return value */
   TknU8        *evntStr;       /* pointer to event structure */
   Buffer       *mBuf;          /* message buffer */


   TRC2(mgAsnDecBool)


   elmntDef = *msgCp->elmntDef;        /* get the element definition */
   evntStr  = (TknU8 *)msgCp->evntStr; /* get the event structure */
   mBuf     = msgCp->mBuf;             /* get the message buffer */

   /* check if this is a duplicate element */
   if (evntStr->pres)
   {
      /* duplicate element */
      MG_ASN_ERR(msgCp, MG_ASN_DUP_ELMNT);
      RETVALUE(RFAILED);
   }

   /* read the element value into the event structure */
   if ((ret = mgAsnDecValue(mBuf, msgCp, (U8 *)(&(evntStr->val)))) != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_LEN_ERR);
      RETVALUE(ret);
   }

   if (evntStr->val == MG_ASN_FALSE)
   {
      evntStr->val = FALSE;
   }
   else
   {
      evntStr->val = TRUE;
   }

   /* no errors, make the element present in the event structure */
   evntStr->pres = PRSNT_NODEF;

   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnDecBool */

/* ------------------------------------------------------------- */
/*
*
*       Fun:   mgAsnDecAnyDefinedBy
*
*       Desc:  This function decodes a ANY DEFINED BY type.
*              This routine requires the caller to identify
*              the element to be decoded in form of a
*              element index. The encoding of the ANY DEFINED
*              BY type is the same as a choice type and is
*              handled in the routine mgAsnEncChoice.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecAnyDefinedBy
(
MgAsnMsgCp   *msgCp,  /* message control pointer */
U8           idx      /* element index */
)
#else
PUBLIC S16 mgAsnDecAnyDefinedBy (msgCp, idx)
MgAsnMsgCp   *msgCp;  /* message control pointer */
U8           idx;     /* element index */
#endif
{
   MgAsnElmntDef   *elmntDef;      /* element definition */
   MgAsnElmntDef   **defPtr;       /* element definition */
   S16          ret;            /* return value */
   TknU8        *evntStr;       /* pointer to event structure */
   TknU8        *strPtr;        /* pointer to event structure */
   TknU8        *tmpPtr;        /* temporary pointer to event structure */
   MsgLen       msgLen;         /* Length of message */
   Buffer       *mBuf;          /* message buffer */
   U16          j;              /* element counter */

   TRC2(mgAsnDecAnyDefinedBy)

   /* check if this element is defined for this protocol */
   if ((ret = mgAsnDecChkFlag(msgCp)) == RFAILED)
   {
      /* this element is not defined for this protocol, skip it */
      mgAsnSkipElmnt(msgCp);
      RETVALUE(ROK);
   }

   /* get the element defintion */
   elmntDef = *msgCp->elmntDef;

   msgLen = mgAsnFindLen(msgCp);

   if (msgLen == 0)
   {
      /* No bytes in the message buffer, check if element is mandatory */
      if (mgAsnChkEleMandMis(msgCp) == TRUE)
      {
         /* element is mandatory, cannot be skipped */
         MG_ASN_ERR(msgCp, MG_ASN_MAND_MIS);
         RETVALUE(RFAILED);
      }
      else
      {
         /* element is not mandatory, can be skipped */
         mgAsnSkipElmnt(msgCp);
         RETVALUE(ROK);
      }

   } /* end if */

   /* store the choice element present */
   j = (idx - 1);

   defPtr    = msgCp->elmntDef;        /* store element definition pointer */
   strPtr    = msgCp->evntStr;         /* store event structure pointer */

   evntStr  = (TknU8 *)msgCp->evntStr; /* get the event structure */
   elmntDef = *msgCp->elmntDef;        /* get the element definition */
   mBuf     = msgCp->mBuf;             /* get the message buffer */

   /* increment over the start of choice */
   msgCp->elmntDef++;

   /* skip over the present token */
   mgAsnIncPtr((PTR *)&msgCp->evntStr, sizeof(TknU8));

   /* skip over the database defintions of the first "(idx - 1)" elements */
   /* which are not present */

   for(; j > 0; j--)
   {
        /* store the event structure pointer */
        tmpPtr = msgCp->evntStr;

        mgAsnSkipElmnt(msgCp);

        /* restore the event structure pointer */
        msgCp->evntStr = tmpPtr;
   }

   /* make the element as present in the event structure */
   strPtr->pres = PRSNT_NODEF;                   /* choice present */
   strPtr->val  = idx;                           /* element index */

   /* decode the element depending on the element type */
   if ((ret = mgAsnDecElmnt(msgCp)) != ROK)
   {
      /* error code already filled, don't do it again */
      RETVALUE(RFAILED);
   }

   /* restore the element defintion to choice start */
   msgCp->elmntDef = defPtr;

   /* restore the event structure */
   msgCp->evntStr = strPtr;

   /* now skip over the choice */
   mgAsnSkipElmnt(msgCp);

   RETVALUE(ROK);

} /* mgAsnDecAnyDefinedBy */


/* ------------------------------------------------------------- */

/*
*
*       Fun:   mgAsnInitMsgDb
*
*       Desc:  This function initializes the message database
*              elements with information about the sizes of
*              the database elements for constructor types.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnInitMsgDb
(
MgAsnElmntDef **msgDef               /* message definition */
)
#else
PUBLIC S16 mgAsnInitMsgDb (msgDef)
MgAsnElmntDef **msgDef;              /* message definition */
#endif
{
   MgAsnElmntDef **dbPtr;            /* database pointer */
   MgAsnElmntDef *elmnt;             /* database element pointer */
   S16        ret;                /* return value */
   U32        tagCount = 0;       /* automatic tag count */

   TRC2(mgAsnInitMsgDb)

   /* initialize the database pointer to the message start */
   dbPtr = msgDef;

   while (*dbPtr != NULLP)
   {
      /* get the current element from the database pointer */
      elmnt = *dbPtr;

      switch (elmnt->type)
      {
      case TET_U8:
      case TET_ENUM:
      case TET_NULL:
      case TET_INT8:
      case TET_INT16:
      case TET_INT32:
      case TET_INT_RNG:
      case TET_STR4:
      case TET_STR12:
      case TET_STR32:
      case TET_STR64:
      case TET_STR256:
      case TET_BITSTR:
      case TET_STRXL:
      case TET_STRXL_MEM:
      case TET_STROSXL_MEM:
      case TET_OID:
      case TET_BOOL:
      case TET_ESC_PRIM:
      case TET_IA5STR4:
      case TET_IA5STR12:
      case TET_IA5STR32:
      case TET_IA5STR64:
      case TET_IA5STR256:
      case TET_IA5STRXL:
      case TET_IA5STRXL_MEM:
      case TET_IA5STROSXL_MEM:
         if (elmnt->tag == 0xFF) {
            elmnt->tag = tagCount + MG_ASN_PRIMITIVE_TAG_BASE;
         }
         else {
            if (elmnt->tag != (tagCount + MG_ASN_PRIMITIVE_TAG_BASE)) {
            }
         }
         ++dbPtr;
         break;

      case TET_SEQ:
      case TET_SEQ_SPECIAL:
      case TET_SET:
      case TET_CHOICE:
      case TET_CHOICE0:
      case TET_TAG:
      case TET_ESC_CONST:
         /* automatic tag */
         if (elmnt->tag == 0xFF) {
            elmnt->tag = tagCount + MG_ASN_CONSTRUCTOR_TAG_BASE;
         }
         else {
            if (elmnt->tag != (tagCount + MG_ASN_CONSTRUCTOR_TAG_BASE)) {
            }
         }

         if ((ret = mgAsnInitConstType(&dbPtr)) != ROK)
         {
            RETVALUE(RFAILED);
         }
         break;

      case TET_SEQ_OF:
      case TET_SET_OF:
      case TET_UNCONS_SEQ_OF:
      case TET_UNCONS_SET_OF:
         /* automatic tag */
         if (elmnt->tag == 0xFF) {
            elmnt->tag = tagCount + MG_ASN_CONSTRUCTOR_TAG_BASE;
         }
         else {
            if (elmnt->tag != (tagCount + MG_ASN_CONSTRUCTOR_TAG_BASE)) {
            }
         }

         if ((ret = mgAsnInitSeqOfElem(&dbPtr)) != ROK)
         {
            RETVALUE(RFAILED);
         }
         break;

      default:
         RETVALUE(RFAILED);
      } /* end switch */
      ++tagCount;

      /* Check the function pointers */
      if ((elmnt->funcEnc == NULLP) ||
          (elmnt->funcDec == NULLP)) {
#if (ERRCLASS & ERRCLS_DEBUG)
            MGASNLOGERROR(ERRCLS_DEBUG, EMG004, (ErrVal)ERRZERO,
                        "Null User function pointer");
#endif
            RETVALUE(RFAILED);
      }
   } /* end while */

   RETVALUE(ROK);

} /* mgAsnInitMsgDb */



/*
*
*       Fun:   mgAsnInitConstType
*
*       Desc:  This function parses the constructor types and
*              updates their database defintions
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PRIVATE S16 mgAsnInitConstType
(
MgAsnElmntDef ***ptr               /* message definition */
)
#else
PRIVATE S16 mgAsnInitConstType (ptr)
MgAsnElmntDef ***ptr;              /* message definition */
#endif
{
   MgAsnElmntDef **dbPtr;          /* database pointer */
   MgAsnElmntDef **savPtr;         /* saved database pointer */
   MgAsnElmntDef *elmnt;           /* element definition */
   S16        ret;              /* return value */
   U32        tagCount = 0;     /* automatic tag count */

   TRC2(mgAsnInitConstType)

   /* initialize the local database pointer */
   dbPtr  = *ptr;
   savPtr = *ptr;

   /* increment the database pointer over the start of the constructor type */
   dbPtr++;
   *ptr = dbPtr;

   /* get the current element defintion */
   elmnt = *dbPtr;

   while (elmnt->type != TET_SETSEQ_TERM)
   {
      switch (elmnt->type)
      {
      case TET_U8:
      case TET_ENUM:
      case TET_NULL:
      case TET_INT8:
      case TET_INT16:
      case TET_INT32:
      case TET_INT_RNG:
      case TET_STR4:
      case TET_STR12:
      case TET_STR32:
      case TET_STR64:
      case TET_STR256:
      case TET_BITSTR:
      case TET_STRXL:
      case TET_STRXL_MEM:
      case TET_STROSXL_MEM:
      case TET_OID:
      case TET_BOOL:
      case TET_ESC_PRIM:
      case TET_IA5STR4:
      case TET_IA5STR12:
      case TET_IA5STR32:
      case TET_IA5STR64:
      case TET_IA5STR256:
      case TET_IA5STRXL:
      case TET_IA5STRXL_MEM:
      case TET_IA5STROSXL_MEM:

         /* Set automatic tag */
         if (elmnt->tag == 0xFF) {
            elmnt->tag = tagCount + MG_ASN_PRIMITIVE_TAG_BASE;
         }
         else {
            if (elmnt->tag != (tagCount + MG_ASN_PRIMITIVE_TAG_BASE)) {
            }
         }

         /* increment the local database pointer */
         dbPtr++;

         /* update the passed pointer */
         *ptr = dbPtr;

         break;

      case TET_SEQ:
      case TET_SEQ_SPECIAL:
      case TET_SET:
      case TET_CHOICE:
      case TET_CHOICE0:
      case TET_TAG:
      case TET_ESC_CONST:

         /* Set automatic tag */
         if (elmnt->tag == 0xFF) {
            elmnt->tag = tagCount + MG_ASN_CONSTRUCTOR_TAG_BASE;
         }
         else {
            if (elmnt->tag != (tagCount + MG_ASN_CONSTRUCTOR_TAG_BASE)) {
            }
         }

         if ((ret = mgAsnInitConstType(ptr)) != ROK)
         {
            RETVALUE(RFAILED);
         }

         /* get the updated database pointer */
         dbPtr = *ptr;

         break;

      case TET_SEQ_OF:
      case TET_SET_OF:
      case TET_UNCONS_SEQ_OF:
      case TET_UNCONS_SET_OF:

         /* Set automatic tag */
         if (elmnt->tag == 0xFF) {
            elmnt->tag = tagCount + MG_ASN_CONSTRUCTOR_TAG_BASE;
         }
         else {
            if (elmnt->tag != (tagCount + MG_ASN_CONSTRUCTOR_TAG_BASE)) {
            }
         }

         if ((ret = mgAsnInitSeqOfElem(ptr)) != ROK)
         {
            RETVALUE(RFAILED);
         }

         /* get the updated database pointer */
         dbPtr = *ptr;

         break;

      default:
         RETVALUE(RFAILED);
      } /* end switch */
      ++tagCount;

      /* get the next element defintion */
      elmnt = *dbPtr;

   } /* end while */

   /* skip over the end of constructor type */
   dbPtr++;

   /* update the caller database pointer */
   *ptr = dbPtr;

   /* get the saved database pointer */
   elmnt = *savPtr;

   /* update the database defintion for this constructor type */
   if ((elmnt->dbSize != 0) && (elmnt->dbSize != (U16) ((PTR)dbPtr - (PTR)savPtr)))
   {
   }
   elmnt->dbSize = (U16) ((PTR)dbPtr - (PTR)savPtr);

   RETVALUE(ROK);

} /* mgAsnInitConstType */


/*
*
*       Fun:   mgAsnInitSeqOfElem
*
*       Desc:  This function parses the constructor types and
*              updates their database defintions
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PRIVATE S16 mgAsnInitSeqOfElem
(
MgAsnElmntDef ***ptr               /* message definition */
)
#else
PRIVATE S16 mgAsnInitSeqOfElem (ptr)
MgAsnElmntDef ***ptr;              /* message definition */
#endif
{
   MgAsnElmntDef **dbPtr;          /* database pointer */
   MgAsnElmntDef **savPtr;         /* saved database pointer */
   MgAsnElmntDef *elmnt;           /* element definition */
   S16        ret;              /* return value */
   U16        universalTag = 0; /* universal tag */

   TRC2(mgAsnInitSeqOfElem)

   /* initialize the local database pointer */
   dbPtr  = *ptr;
   savPtr = *ptr;

   /* increment the database pointer over the start of the constructor type */
   dbPtr++;
   *ptr = dbPtr;

   /* get the current element defintion */
   elmnt = *dbPtr;

   while (elmnt->type != TET_SETSEQ_TERM)
   {

      switch (elmnt->type) {
      case TET_U8:
      case TET_BOOL:
         universalTag = MG_ASN_UBOOL; break;
      case TET_INT8:
      case TET_INT16:
      case TET_INT32:
      case TET_INT_RNG:
         universalTag = MG_ASN_UINT; break;
      case TET_BITSTR:
         universalTag = MG_ASN_UBITSTR; break;
      case TET_STR4:
      case TET_STR12:
      case TET_STR32:
      case TET_STR64:
      case TET_STR256:
      case TET_STRXL:
      case TET_STRXL_MEM:
      case TET_STROSXL_MEM:
         universalTag = MG_ASN_UOCTSTR; break;
      case TET_NULL:
         universalTag = MG_ASN_UNULL; break;
      case TET_OID:
      case TET_ESC_PRIM:
      case TET_TAG:
      case TET_ESC_CONST:
         universalTag = MG_ASN_PRIM_UOID; break;
      case TET_ENUM:
         universalTag = MG_ASN_UENUM; break;
      case TET_IA5STR4:
      case TET_IA5STR12:
      case TET_IA5STR32:
      case TET_IA5STR64:
      case TET_IA5STR256:
      case TET_IA5STRXL:
      case TET_IA5STRXL_MEM:
      case TET_IA5STROSXL_MEM:
         universalTag = MG_ASN_UIA5; break;
      case TET_SEQ:
      case TET_SEQ_SPECIAL:
         universalTag = MG_ASN_USEQ; break;
      case TET_SET:
         universalTag = MG_ASN_USET; break;
      case TET_CHOICE:
      case TET_CHOICE0:
         universalTag = MG_ASN_UCHOICE; break;
      case TET_SEQ_OF:
      case TET_UNCONS_SEQ_OF:
         universalTag = MG_ASN_USEQOF; break;
      case TET_SET_OF:
      case TET_UNCONS_SET_OF:
         universalTag = MG_ASN_USETOF; break;
      default:
         RETVALUE(RFAILED);
      } /* end switch */

      /* set tag */
      if ((elmnt->tag != 0xFF) &&
          (elmnt->tag != universalTag)) {
      }
      /*mg002.105: Removed compilation warning*/
      elmnt->tag = (U8)universalTag;

      switch (elmnt->type)
      {
      case TET_U8:
      case TET_ENUM:
      case TET_NULL:
      case TET_INT8:
      case TET_INT16:
      case TET_INT32:
      case TET_INT_RNG:
      case TET_STR4:
      case TET_STR12:
      case TET_STR32:
      case TET_STR64:
      case TET_STR256:
      case TET_BITSTR:
      case TET_STRXL:
      case TET_STRXL_MEM:
      case TET_STROSXL_MEM:
      case TET_OID:
      case TET_BOOL:
      case TET_ESC_PRIM:
      case TET_IA5STR4:
      case TET_IA5STR12:
      case TET_IA5STR32:
      case TET_IA5STR64:
      case TET_IA5STR256:
      case TET_IA5STRXL:
      case TET_IA5STRXL_MEM:
      case TET_IA5STROSXL_MEM:
         dbPtr++;
         *ptr = dbPtr;
         break;

      case TET_SEQ:
      case TET_SEQ_SPECIAL:
      case TET_SET:
      case TET_CHOICE:
      case TET_CHOICE0:
      case TET_TAG:
      case TET_ESC_CONST:
         if ((ret = mgAsnInitConstType(ptr)) != ROK)
         {
            RETVALUE(RFAILED);
         }
         dbPtr = *ptr;
         break;

      case TET_SEQ_OF:
      case TET_SET_OF:
      case TET_UNCONS_SEQ_OF:
      case TET_UNCONS_SET_OF:
         if ((ret = mgAsnInitSeqOfElem(ptr)) != ROK)
         {
            RETVALUE(RFAILED);
         }
         dbPtr = *ptr;
         break;

      default:
         RETVALUE(RFAILED);
      } /* end switch */

      /* get the next element defintion */
      elmnt = *dbPtr;
   } /* end while */

   /* skip over the end of constructor type */
   dbPtr++;

   /* update the caller database pointer */
   *ptr = dbPtr;

   /* get the saved database pointer */
   elmnt = *savPtr;

   /* update the database defintion for this constructor type */
   if ((elmnt->dbSize != 0) && (elmnt->dbSize != (U16) ((PTR)dbPtr - (PTR)savPtr)))
   {
   }
   elmnt->dbSize = (U16) ((PTR)dbPtr - (PTR)savPtr);

   RETVALUE(ROK);

} /* mgAsnInitSeqOfElem */


/*
*
*       Fun:   mgAsnFindNumOctets
*
*       Desc:  This function finds the number of octets required to encode a
*              length.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC U8 mgAsnFindNumOctets
(
U32   value     /* Integer value */
)
#else
PUBLIC U8 mgAsnFindNumOctets (value)
U32   value;    /* Integer value */
#endif
{
   U8   numBytes;
   U32  tmpVal;

   TRC2(mgAsnFindNumOctets)

   if (value <= MAX_SBYTE_VAL)
   {
      numBytes = 1;
   }
   else
   {
      numBytes = 1;
      tmpVal   = value;
      while(tmpVal != 0)
      {
         tmpVal = (tmpVal >> NUMBITS_BYTE);
         numBytes++;
      }
   }

   RETVALUE(numBytes);
} /* End of mgAsnFindNumOctets */


/*
*
*       Fun:   mgAsnFindLen
*
*       Desc:  Find length of buffer
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC MsgLen mgAsnFindLen
(
MgAsnMsgCp   *msgCp    /* message control point */
)
#else
PUBLIC MsgLen mgAsnFindLen (msgCp)
MgAsnMsgCp   *msgCp;   /* message control point */
#endif
{
#ifdef MG_ASN_SS
   MsgLen      totLen;    /* total length of the message */

   /* get the total length of the message */
   TRC2(mgAsnFindLen)
   (Void)SFndLenMsg(msgCp->mBuf, &totLen);
   RETVALUE(totLen);
#else
   /* get the total length of the message */
   TRC2(mgAsnFindLen)
   RETVALUE(msgCp->sBuf.size);
#endif
}


/*
*
*       Fun:   mgAsnGetOffset
*
*       Desc:  Get offset in buffer
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC MsgLen mgAsnGetOffset
(
MgAsnMsgCp   *msgCp    /* message control point */
)
#else
PUBLIC MsgLen mgAsnGetOffset (msgCp)
MgAsnMsgCp   *msgCp;   /* message control point */
#endif
{
#ifdef MG_ASN_SS
   MsgLen      totLen;    /* total length of the message */

   /* get the total length of the message */
   TRC2(mgAsnGetOffset)
   (Void)SFndLenMsg(msgCp->mBuf, &totLen);
   RETVALUE(totLen);
#else
   /* get the current offset in the message */
   TRC2(mgAsnGetOffset)
   RETVALUE((msgCp->sBuf.stIdx!=0)?(unsigned int)(msgCp->sBuf.stIdx):msgCp->sBuf.size);
#endif
}


/*
*
*       Fun:   mgAsnEncOut2Buf
*
*       Desc:  Encode out to buffer
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncOut2Buf
(
MgAsnMsgCp   *msgCp,   /* message control point */
Data          *str,         /* string to be encoded in the buffer */
MsgLen        len           /* length of the string */
)
#else
PUBLIC S16 mgAsnEncOut2Buf (msgCp, str, len)
MgAsnMsgCp   *msgCp;   /* message control point */
Data          *str;         /* string to be encoded in the buffer */
MsgLen        len;          /* length of the string */
#endif
{
#ifdef MG_ASN_SS
   TRC2(mgAsnEncOut2Buf)
   RETVALUE(SAddPstMsgMult(str, (MsgLen)len, msgCp->mBuf));
#else
   TRC2(mgAsnEncOut2Buf)
   if (((U16)(msgCp->sBuf.stIdx + msgCp->sBuf.size + (U16)len)) > msgCp->sBuf.max)
   {
      RETVALUE(RFAILED);
   }
   (Void)cmMemcpy((msgCp->sBuf.bufP + msgCp->sBuf.stIdx + msgCp->sBuf.size), str, len);

   msgCp->sBuf.size = (msgCp->sBuf.size + len);
   RETVALUE(ROK);
#endif
}


/*
*
*       Fun:   mgAsnDecBuf2Out
*
*       Desc:  Decode buffer out
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PRIVATE S16 mgAsnDecBuf2Out
(
MgAsnMsgCp   *msgCp,   /* message control point */
Data          *str,         /* string to be decoded in the buffer */
MsgLen        len           /* length of the string */
)
#else
PRIVATE S16 mgAsnDecBuf2Out (msgCp, str, len)
MgAsnMsgCp   *msgCp;   /* message control point */
Data          *str;         /* string to be decoded in the buffer */
MsgLen        len;          /* length of the string */
#endif
{
#ifdef MG_ASN_SS
   U8            *pData;     /* tmp decoding buffer */
   S16           ret;


   /* allocate a static buffer if needed */
   TRC2(mgAsnDecBuf2Out)
   pData = str;
   if (str == NULLP) {
      if (SGetSBuf(msgCp->region, msgCp->pool, &pData, len) != ROK)
      {
         MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
         RETVALUE(RFAILED);
      }
   }

   ret = SRemPreMsgMult(pData, (MsgLen)len, msgCp->mBuf);

   /* throw away the static buffer */
   if (str == NULLP) {
      (Void) SPutSBuf(msgCp->region, msgCp->pool, pData, len);
   }
#else
   TRC2(mgAsnDecBuf2Out)
   if (msgCp->sBuf.size < (U16) len)
   {
      RETVALUE(ROKDNA);
   }
   if (str != NULLP)
   {
      (Void)cmMemcpy(str, (msgCp->sBuf.bufP + msgCp->sBuf.stIdx), len);
   }

   msgCp->sBuf.stIdx = msgCp->sBuf.stIdx + len;
   msgCp->sBuf.size  = (msgCp->sBuf.size - len);
#endif
   RETVALUE(ROK);
}


/*
*
*       Fun:   mgAsnDecIgnoreBytes
*
*       Desc:  Ignore bytes
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecIgnoreBytes
(
MgAsnMsgCp   *msgCp,   /* message control point */
U16           len           /* length of the string */
)
#else
PUBLIC S16 mgAsnDecIgnoreBytes (msgCp, len)
MgAsnMsgCp   *msgCp;   /* message control point */
U16           len;          /* length of the string */
#endif
{
   /* ignore extra octets in the end */
#ifdef MG_ASN_SS
   Data       tmp;           /* temporary data */
   S16        ret;
   S16        j;

   TRC2(mgAsnDecIgnoreBytes)
   for (j=0; j<len; ++j) {
      if ((ret = SRemPreMsg(&tmp, msgCp->mBuf)) != ROK) { RETVALUE(ret); }
   }
#else
   TRC2(mgAsnIgnoreBytes)
   if (msgCp->sBuf.size < (U16) len)
   {
      RETVALUE(ROKDNA);
   }
   msgCp->sBuf.stIdx = msgCp->sBuf.stIdx + len;
   msgCp->sBuf.size  = (msgCp->sBuf.size - len);
#endif
   RETVALUE(ROK);
}


/*
*
*       Fun:   mgAsnDecGetOctet
*
*       Desc:  Get octet
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecGetOctet
(
MgAsnMsgCp   *msgCp,   /* message control point */
Data         *octet    /* data */
)
#else
PUBLIC S16 mgAsnDecGetOctet(msgCp, octet)
MgAsnMsgCp   *msgCp;   /* message control point */
Data         *octet;   /* data */
#endif
{
#ifdef MG_ASN_SS
   TRC2(mgAsnDecGetOctet)
   RETVALUE(SRemPreMsg(octet, msgCp->mBuf));
#else
   TRC2(mgAsnDecGetOctet)
   if (msgCp->sBuf.size < (U16) 1) { RETVALUE(ROKDNA); }
   *octet = *(msgCp->sBuf.bufP + msgCp->sBuf.stIdx + msgCp->sBuf.ctIdx);
   msgCp->sBuf.stIdx = msgCp->sBuf.stIdx + 1;
   msgCp->sBuf.size  = (msgCp->sBuf.size - 1);
   RETVALUE(ROK);
#endif
}


/*
*
*       Fun:   mgAsnDecChkOctet
*
*       Desc:  Check octet
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnDecChkOctet
(
MgAsnMsgCp   *msgCp,   /* message control point */
Data         *octet    /* data */
)
#else
PUBLIC S16 mgAsnDecChkOctet(msgCp, octet)
MgAsnMsgCp   *msgCp;   /* message control point */
Data         *octet;   /* data */
#endif
{
#ifdef MG_ASN_SS
   TRC2(mgAsnDecChkOctet)
   RETVALUE(SExamMsg(octet, msgCp->mBuf, 0));
#else
   TRC2(mgAsnDecChkOctet)
   if (msgCp->sBuf.size <= (U16) 1) { RETVALUE(ROKDNA); }
   *octet = *(msgCp->sBuf.bufP + msgCp->sBuf.stIdx + msgCp->sBuf.ctIdx);
   RETVALUE(ROK);
#endif
}


/*
*
*       Fun:   mgAsnEncSetOctet
*
*       Desc:  Set octet
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncSetOctet
(
MgAsnMsgCp   *msgCp,   /* message control point */
Data         octet,    /* data */
MsgLen       offset    /* offset */
)
#else
PUBLIC S16 mgAsnEncSetOctet(msgCp, octet, offset)
MgAsnMsgCp   *msgCp;   /* message control point */
Data         octet;    /* data */
MsgLen       offset;   /* offset */
#endif
{
#ifdef MG_ASN_SS
   TRC2(mgAsnEncSetOctet)
   RETVALUE(SRepMsg(octet, msgCp->mBuf, offset));
#else
   TRC2(mgAsnEncSetOctet)
  if (msgCp->sBuf.size <= (U16)offset) { RETVALUE(ROKDNA); }
  *(msgCp->sBuf.bufP + msgCp->sBuf.stIdx + offset) = octet;
   RETVALUE(ROK);
#endif
}


/*
*
*       Fun:   mgAsnEncSlide
*
*       Desc:  Set octet
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAsnEncSlide
(
MgAsnMsgCp   *msgCp,   /* message control point */
MsgLen       *lenOffset,/* length offset */
MsgLen       lenLen    /* length offset */
)
#else
PUBLIC S16 mgAsnEncSlide(msgCp, lenOffset, lenLen)
MgAsnMsgCp   *msgCp;   /* message control point */
MsgLen       *lenOffset;/* length offset */
MsgLen       lenLen;   /* length offset */
#endif
{
#ifdef MG_ASN_SS
   S16 ret;
   Buffer *mBuf2;
   Data octet = 0;
   S32 j;

   TRC2(mgAsnEncSlide)
   if ((ret = SSegMsg(msgCp->mBuf, *lenOffset, &mBuf2)) != ROK)
   {
      RETVALUE(ret);
   }
   /* Add some octets */
   for (j=0; j<lenLen; ++j) {
      if ((ret = SAddPstMsg(octet, msgCp->mBuf)) != ROK) { RETVALUE(ret); }
   }
   if ((ret = SCatMsg(msgCp->mBuf, mBuf2, M1M2)) != ROK) { RETVALUE(ret); }
   (Void)SPutMsg(mBuf2);
   *lenOffset += lenLen;
   RETVALUE(ROK);
#else
   U8 *startPtr;
   U8 *endPtr;
   U16 bytesNeeded;

   /* shuffle out data */
   TRC2(mgAsnEncSlide)
   bytesNeeded  = (msgCp->parents+1) * lenLen;
   if ((msgCp->shiftOffset == 0) &&
       (((U16)(msgCp->sBuf.stIdx+msgCp->sBuf.size+(U16)bytesNeeded)) > msgCp->sBuf.max))
   {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(RFAILED);
   }
   if (msgCp->shiftOffset == 0)
   {
      msgCp->shiftOffset = msgCp->sBuf.stIdx + msgCp->sBuf.size - 1;
      msgCp->sBuf.size  = (msgCp->sBuf.size + bytesNeeded);
   }
   startPtr = msgCp->sBuf.bufP + (msgCp->shiftOffset + bytesNeeded);
   endPtr = msgCp->sBuf.bufP + (*lenOffset) + bytesNeeded;
   while (startPtr > endPtr) {
      *startPtr = *(startPtr-bytesNeeded);
      --startPtr;
      --msgCp->shiftOffset;
   }
   *lenOffset = *lenOffset + bytesNeeded;
   --msgCp->shiftOffset;
   RETVALUE(ROK);
#endif
}


/*
*
*       Fun:   mgAsnEncGetMem
*
*       Desc:  Get memory for encode
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAsnEncGetMem
(
MgAsnMsgCp   *msgCp,   /* message control point */
Ptr*         ptr,      /* address */
MsgLen       siz       /* size */
)
#else
PUBLIC S16 mgAsnEncGetMem(msgCp, ptr, siz)
MgAsnMsgCp   *msgCp;   /* message control point */
Ptr*         ptr;      /* address */
MsgLen       siz;      /* size */
#endif
{
   TRC2(mgAsnEncGetMem)
   if (SGetSBuf(msgCp->memCp->memCb.sMem.region, msgCp->memCp->memCb.sMem.pool, (Data **)ptr, (Size)siz )  != ROK)
   {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(RFAILED);
   }
   cmMemset((U8 *)*ptr, (U8 )0, (PTR)siz);

   RETVALUE(ROK);
}


/*
*
*       Fun:   mgAsnEncPutMem
*
*       Desc:  Get memory for encode
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAsnEncPutMem
(
MgAsnMsgCp   *msgCp,   /* message control point */
Ptr          ptr,      /* address */
MsgLen       siz       /* size */
)
#else
PUBLIC S16 mgAsnEncPutMem(msgCp, ptr, siz)
MgAsnMsgCp   *msgCp;   /* message control point */
Ptr          ptr;      /* address */
MsgLen       siz;      /* size */
#endif
{
   TRC2(mgAsnEncPutMem)
   SPutSBuf(msgCp->memCp->memCb.sMem.region, msgCp->memCp->memCb.sMem.pool, (Data*)ptr, (Size)siz );
   RETVALUE(ROK);
}


/*
*
*       Fun:   mgAsnDecPutMem
*
*       Desc:  Get memory for encode
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAsnDecPutMem
(
MgAsnMsgCp   *msgCp,   /* message control point */
Ptr          ptr       /* address */
)
#else
PUBLIC S16 mgAsnDecPutMem(msgCp, ptr)
MgAsnMsgCp   *msgCp;   /* message control point */
Ptr          ptr;      /* address */
#endif
{
   TRC2(mgAsnDecPutMem)
   /* cmFreeMem((Ptr)ptr); Allow clean up at message level */
   RETVALUE(ROK);
}


/*
*
*       Fun:   mgAsnDecGetMem
*
*       Desc:  Get memory for decode
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAsnDecGetMem
(
MgAsnMsgCp   *msgCp,   /* message control point */
Ptr*         ptr,      /* address */
MsgLen       siz       /* size */
)
#else
PUBLIC S16 mgAsnDecGetMem(msgCp, ptr, siz)
MgAsnMsgCp   *msgCp;   /* message control point */
Ptr*         ptr;      /* address */
MsgLen       siz;      /* size */
#endif
{
   TRC2(mgAsnDecGetMem)
   if (cmGetMem(msgCp->memCp, siz, ptr) != ROK) {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
}


/*
*
*       Fun:   mgAsnDecGetMoreMem
*
*       Desc:  Get memory for decode
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAsnDecGetMoreMem
(
MgAsnMsgCp   *msgCp,   /* message control point */
Ptr*         ptr,      /* address */
MsgLen       siz,      /* size */
MsgLen       oldSiz    /* size */
)
#else
PUBLIC S16 mgAsnDecGetMoreMem(msgCp, ptr, siz, oldSiz)
MgAsnMsgCp   *msgCp;   /* message control point */
Ptr*         ptr;      /* address */
MsgLen       siz;      /* size */
MsgLen       oldSiz;   /* size */
#endif
{
   Ptr tmpPtr;

   TRC2(mgAsnDecGetMoreMem)
   /* get new memory */
   if (cmGetMem(msgCp->memCp, siz, &tmpPtr) != ROK) {
      MG_ASN_ERR(msgCp, MG_ASN_RES_ERR);
      RETVALUE(RFAILED);
   }
   /* deal with old memory */
   if ((*ptr) && (oldSiz != 0)) {
      /*mg002.105: Removed compilation warning*/
      (void)cmMemcpy((U8*)tmpPtr, (CONSTANT U8*)*ptr, oldSiz);
      mgAsnDecPutMem(msgCp, ptr);
   }
   *ptr = tmpPtr;
   RETVALUE(ROK);
}


/*
*
*       Fun:   mgAsnDecListAdd
*
*       Desc:  Get memory for encode
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_asn.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAsnDecListAdd
(
MgAsnMsgCp   *msgCp,   /* message control point */
Ptr**        listPtr,  /* list */
TknU16*      listLen,  /* current list length */
Ptr*         addPtr,   /* additional list items */
MsgLen       addLen    /* size to add */
)
#else
PUBLIC S16 mgAsnDecListAdd(msgCp, listPtr, listLen, addPtr, addLen)
MgAsnMsgCp   *msgCp;   /* message control point */
Ptr**        listPtr;  /* list */
TknU16*      listLen;  /* current list length */
Ptr*         addPtr;   /* additional list items */
MsgLen       addLen;   /* size to add */
#endif
{
   TRC2(mgAsnDecListAdd);
   listLen->pres = PRSNT_NODEF;
   if((listLen->val) == 0) {
      *listPtr = NULLP;
   }

   /*mg002.105: Removed compilation warning*/
   if (mgAsnDecGetMoreMem(msgCp, (Ptr*)(listPtr), (MsgLen)(((listLen->val) + addLen) * sizeof(S32*)), (MsgLen)((listLen->val) * sizeof(S32*))) != ROK) { RETVALUE(RFAILED); }
   (void)cmMemcpy((U8*)&((*listPtr)[listLen->val]), (U8*)addPtr, (addLen * sizeof(S32*)));
   listLen->val += addLen;

   RETVALUE(ROK);
}

#ifdef CM_ABNF_MT_LIB


/*
*
*       Fun:   mgAsnDecCfm 
*
*       Desc:  send decode cfm
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 mgAsnDecCfm
(
Pst           *pst,        /* Post structure */
U32           protVar,     /* protocol and variant */
U8            *event,      /* pointer to the event structure */
Buffer        *mBuf,       /* Message buffer */
MsgLen        *numDecBytes,/* no of decoded bytes */
CmAbnfErr     *err,        /* error */
Ptr           usrCxt       /* user context */
)
#else
PUBLIC S16 mgAsnDecCfm(pst, protVar, event, mBuf, numDecBytes, err, usrCxt)
Pst           *pst;        /* Post structure */
U32           protVar;     /* protocol and variant */
U8            *event;      /* pointer to the event structure */
Buffer        *mBuf;       /* Message buffer */
MsgLen        *numDecBytes;/* no of decoded bytes */
CmAbnfErr     *err;        /* error */
Ptr           usrCxt;      /* user context */
#endif
{
   Pst        cfmPst;     /* post structure */

   TRC3(mgAsnDecCfm)

   /* Copy post structure */
   cmMemcpy((U8 *)&cfmPst, (U8 *)pst, sizeof(Pst));
   cfmPst.srcProcId = pst->dstProcId;
   cfmPst.dstProcId = pst->srcProcId;
   cfmPst.srcInst = pst->dstInst;
   cfmPst.dstInst = pst->srcInst;
   cfmPst.event = EVTMEDDECCFM;

   mgAsnPkMedDecCfm(&cfmPst, protVar, event, mBuf,
                       *numDecBytes, err, usrCxt);
   
   RETVALUE(ROK);
} /* mgAsnDecCfm */
  

/*
*
*       Fun:   mgAsnEncCfm 
*
*       Desc:  send Encode cfm
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 mgAsnEncCfm
(
Pst           *pst,       /* Post structure */
U32           protVar,    /* protocol and variant */
U8            *event,     /* pointer to the event structure */
Buffer        *mBuf,      /* Message buffer */
CmAbnfErr     *err,       /* error */
Ptr           usrCxt      /* user context */
)
#else
PUBLIC S16 mgAsnEncCfm(pst, protVar, event, mBuf, err, usrCxt)
Pst           *pst;       /* Post structure */
U32           protVar;    /* protocol and variant */
U8            *event;     /* pointer to the event structure */
Buffer        *mBuf;      /* Message buffer */
CmAbnfErr     *err;       /* error */
Ptr           usrCxt;     /* user context */
#endif
{
   Pst        cfmPst;     /* post structure */

   TRC3(mgAsnEncCfm)
   /* Copy post structure */
   cmMemcpy((U8 *)&cfmPst, (U8 *)pst, sizeof(Pst));

   cfmPst.srcProcId = pst->dstProcId;
   cfmPst.dstProcId = pst->srcProcId;
   cfmPst.srcInst = pst->dstInst;
   cfmPst.dstInst = pst->srcInst;
   cfmPst.event = EVTMEDENCCFM;
   mgAsnPkMedEncCfm(&cfmPst, protVar, event, mBuf, 
          err, usrCxt);
   
   RETVALUE(ROK);
} /* mgAsnEncCfm */
 

/*
*
*       Fun:   mgAsnDecReq 
*
*       Desc:  Process decode Req
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 mgAsnDecReq
(
Pst           *pst,       /* post structure */
U32           protVar,    /* protocol and variant */
U8            *event,     /* pointer to the event structure */
Buffer        *mBuf,      /* Message buffer */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmMemListCp   *memCp,     /* Memory: region/pool */
Ptr           usrCxt      /* user context */
)
#else
PUBLIC S16 mgAsnDecReq(pst, protVar, event, mBuf, elmDef, memCp, usrCxt)
Pst           *pst;       /* post structure */
U32           protVar;    /* protocol and variant */
U8            *event;     /* pointer to the event structure */
Buffer        *mBuf;      /* Message buffer */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmMemListCp   *memCp;     /* Memory: region/pool */
Ptr           usrCxt;     /* user context */
#endif
{
   S16             ret;               /* return code */
   MsgLen          numDecBytes;       /* no of decoded bytes */
   CmAbnfErr       err;               /* error */
   MgAsnErr        asnErr;            /* error */
   CmAbnfDecOff    offset;            /* DBUF offset information */
   
   

   TRC2(mgAsnDecReq)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((mBuf == NULLP) || (event == NULLP) || (elmDef == NULLP))
   {
      CMABNFLOGERROR(ERRCLS_INT_PAR, ECMABNFXXX, 0,
         "mgAsnDecReq() failed, Invalid parameters ");

      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
   /* Initialize err */
   cmMemset((U8 *)&err, 0, sizeof(CmAbnfErr));
   err.code = CM_ABNF_ERR_NONE;
   cmMemset((U8 *)&offset, 0, sizeof(CmAbnfDecOff));
   cmMemset((U8*)&asnErr, 0, sizeof(MgAsnErr));
   ret = mgAsnDecMsg((TknU8*)mwrapEvntGet((PTR)event,MG_WRAP_ASN, MGED_MEGACO, 0), mBuf, CM_ABNF_PROT_MEGACO_H248, (MgAsnElmntDef**)elmDef, memCp, &asnErr, &numDecBytes);
   if (ret != ROK) { mwrapErrMap(&err, &asnErr); }

   /* send Decode cfm back */
   mgAsnDecCfm(pst, protVar, event, mBuf, &numDecBytes, &err, usrCxt);
   RETVALUE(ROK);
}


/*
*
*       Fun:   mgAsnEncReq 
*
*       Desc:  Process Encode Req
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 mgAsnEncReq
(
Pst           *pst,       /* post structure */
U32           protVar,    /* protocol and variant */
U8            *event,     /* pointer to the event structure */
Buffer        *mBuf,      /* Message buffer */
CmAbnfElmDef  *elmDef,    /* message defintion */
Mem           *memReg,    /* Memory: region/pool */
Ptr           usrCxt      /* user context */
)
#else
PUBLIC S16 mgAsnEncReq(pst, protVar, event, mBuf, elmDef, memReg, usrCxt)
Pst           *pst;       /* post structure */
U32           protVar;    /* protocol and variant */
U8            *event;     /* pointer to the event structure */
Buffer        *mBuf;      /* Message buffer */
CmAbnfElmDef  *elmDef;    /* message defintion */
Mem           *memReg;    /* Memory: region/pool */
Ptr           usrCxt;     /* user context */
#endif
{
   CmAbnfErr     err;     /* error */
   MgAsnErr      asnErr;
   S16           ret;     /* return value */

   TRC2(mgAsnEncReq)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((mBuf == NULLP) || (event == NULLP) || (elmDef == NULLP))
   {
      CMABNFLOGERROR(ERRCLS_INT_PAR, ECMABNFXXX, 0,
         "mgAsnEncReq() failed, Invalid parameters ");

      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   /* Initialize err */
   cmMemset((U8 *)&err, 0, sizeof(CmAbnfErr));
   cmMemset((U8 *)&asnErr, 0, sizeof(MgAsnErr));
   err.code = CM_ABNF_ERR_NONE;

   ret = mgAsnEncMsg((TknU8*)event, mBuf, CM_ABNF_PROT_MEGACO_H248, (MgAsnElmntDef**)elmDef, memReg->region, memReg->pool, &asnErr);
   if (ret != ROK) { mwrapErrMap(&err, &asnErr); }

   /* send cfm back */
   mgAsnEncCfm(pst, protVar, event, mBuf, &err, usrCxt);

   RETVALUE(ret);
} /* mgAsnEncReq */
 
/* Pack unpack functions for mgAsnLib */

/*
*
*       Fun:   mgAsnUnpkMedEncReq
*
*       Desc:  Unpack Encode Req
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_abnf.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAsnUnpkMedEncReq
(
MedEncReq  func,                    /* function */
Pst        *pst,                    /* post structure */
Buffer     *mBuf                    /* message buffer */
)
#else
PUBLIC S16 mgAsnUnpkMedEncReq(func, pst, mBuf)
MedEncReq  func;                    /* function */
Pst        *pst;                    /* post structure */
Buffer     *mBuf;                   /* message buffer */
#endif
{

   U32            protVar;          /* protocol variant */
   U8             *event;           /* event structure */
   Buffer         *encBuf;          /* Buffer */
   CmAbnfElmDef   *elmDef;          /* root of database tree */
   Mem            mem;              /* memory region/pool */
   Ptr            usrCxt;           /* user context */
    
   TRC3(mgAsnUnpkMedEncReq)
   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&usrCxt, mBuf, EMEDXXX, pst);
   /* Now unpack memory region/pool */
   CMCHKUNPKLOG(cmUnpkPool, &(mem.pool), mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(cmUnpkRegion, &(mem.region), mBuf, EMEDXXX, pst);

   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&elmDef, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&encBuf, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&event, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(SUnpkU32,   &protVar, mBuf, EMEDXXX, pst);
   SPutMsg(mBuf);
   /* call the primitive */
   (*func)(pst, protVar, event, encBuf, elmDef, &mem, usrCxt);

   RETVALUE(ROK);
} /* end of mgAsnUnpkMedEncReq */



/*
*
*       Fun:   mgAsnUnpkMedDecReq
*
*       Desc:  Unpack Dec Req
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_abnf.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAsnUnpkMedDecReq
(
MedDecReq  func,                    /* function */
Pst        *pst,                    /* post structure */
Buffer     *mBuf                    /* message buffer */
)
#else
PUBLIC S16 mgAsnUnpkMedDecReq(func, pst, mBuf)
MedDecReq  func;                    /* function */
Pst        *pst;                    /* post structure */
Buffer     *mBuf;                   /* message buffer */
#endif
{

   U32            protVar;          /* protocol variant */
   U8             *event;           /* event structure */
   Buffer         *decBuf;          /* Buffer */
   CmAbnfElmDef   *elmDef;          /* root of database tree */
   CmMemListCp    *memCp;           /* memory region/pool */
   Ptr            usrCxt;           /* user context */
    
   TRC3(mgAsnUnpkMedDecReq)
   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&usrCxt, mBuf, EMEDXXX, pst);
   /* Now unpack memory control block */
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&memCp, mBuf, EMEDXXX, pst);

   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&elmDef, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&decBuf, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&event, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(SUnpkU32,   &protVar, mBuf, EMEDXXX, pst);

   SPutMsg(mBuf);
   /* call the primitive */
   (*func)(pst, protVar, event, decBuf, elmDef, memCp, usrCxt);

   RETVALUE(ROK);
} /* end of mgAsnUnpkMedDecReq */


/*
*
*    Fun:    mgAsnPkMedEncCfm
*
*    Desc:    pack the primitive Encode Cfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_abnf.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAsnPkMedEncCfm
(
Pst            *pst,           /* post structure */
U32            protVar,        /* protocol variant */
U8             *event,         /* event structure */
Buffer         *encBuf,          /* encoded buffer */
CmAbnfErr      *err,           /* error */
Ptr            usrCxt          /* user context */
)
#else
PUBLIC S16 mgAsnPkMedEncCfm(pst, protVar, event, encBuf, err, usrCxt)
Pst            *pst;           /* post structure */
U32            protVar;        /* protocol variant */
U8             *event;         /* event structure */
Buffer         *encBuf;          /* encoded buffer */
CmAbnfErr      *err;           /* error */
Ptr            usrCxt;         /* user context */
#endif
{
    S16        ret1;
    Buffer     *mBuf;

    TRC3(mgAsnPkMedEncCfm)

    mBuf = NULLP;

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMEDXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(cmPkPtr, (PTR)event, mBuf, EMEDXXX, pst); 
    CMCHKPKLOG(SPkU32, protVar, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(cmPkPtr, (PTR)encBuf, mBuf, EMEDXXX, pst); 
    /* Now pack error->idNum and error->code */
    CMCHKPKLOG(SPkU16, err->code, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(SPkU16, err->idNum, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(cmPkPtr, (PTR)usrCxt, mBuf, EMEDXXX, pst); 
    
    pst->event = (Event) EVTMEDENCCFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function mgAsnPkMedEncCfm */



/*
 * 004.main_6 : Corrected the type of argument - numDecBytes
 */

/*
*
*    Fun:    mgAsnPkMedDecCfm
*
*    Desc:    pack the primitive Encode Cfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_abnf.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAsnPkMedDecCfm
(
Pst            *pst,           /* post structure */
U32            protVar,        /* protocol variant */
U8             *event,         /* event structure */
Buffer         *decBuf,        /* encoded buffer */
MsgLen         numDecBytes,    /* no of decoded bytes */
CmAbnfErr      *err,           /* error */
Ptr            usrCxt          /* user context */
)
#else
PUBLIC S16 mgAsnPkMedDecCfm(pst, protVar, event, decBuf, numDecBytes, err, usrCxt)
Pst            *pst;           /* post structure */
U32            protVar;        /* protocol variant */
U8             *event;         /* event structure */
Buffer         *decBuf;        /* encoded buffer */
MsgLen         numDecBytes;    /* no of decoded bytes */
CmAbnfErr      *err;           /* error */
Ptr            usrCxt;         /* user context */
#endif
{
    S16        ret1;
    Buffer     *mBuf;

    TRC3(mgAsnPkMedDecCfm)

    mBuf = NULLP;

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMEDXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(SPkU32, protVar, mBuf, EMEDXXX, pst);
/*
 * 004.main_6 : Corrected the packing function for numDecBytes
 */
    CMCHKPKLOG(cmPkMsgLen, numDecBytes, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(cmPkPtr, (PTR)decBuf, mBuf, EMEDXXX, pst); 
    /* Now pack error->idNum and error->code */
    CMCHKPKLOG(SPkU16, err->code, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(SPkU16, err->idNum, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(cmPkPtr, (PTR)usrCxt, mBuf, EMEDXXX, pst); 
    CMCHKPKLOG(cmPkPtr, (PTR)event, mBuf, EMEDXXX, pst); 
    
    pst->event = (Event) EVTMEDDECCFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function mgAsnPkMedDecCfm */




#endif /* CM_ABNF_MT_LIB */
#endif

/********************************************************************30**

         End of file:     mg_asn.c@@/main/mgcp_rel_1.5_dev/gcp_mgcov2_dev/4 - Wed Dec 22 11:15:09 2004

*********************************************************************31*/


/********************************************************************40**

       Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

          Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      tlh  1. Created
/main/1      ---      pk   1. GCP 1.5 release
          mg002.105   ps   1. Removed compilation warning
          mg003.105   dp   1. Fixing ASN Encoding problem with GCP_CH
                      gk   2. Changes for Universal Tag    
                           3. Changes for min number of elements to encode  
                           4. Function added to support Unsigned integer
                           5. Fix for Unsigned integer type
                           6. Fix for the integer decoding according to X.690
          mg004.105   gk   1. Adding support for the X.690 integer type 
          mg005.105   gk   1. Fix for PSF
                           2. Changed to support empty commands in the action
          mg007.105   gk   1. Modified to encode bit string properly
                           2. checking for the number of bits padded
                           3. put the check for the integer with allowing
                              extra octet
                      gk   4. Changed the encdoing/decoding of enum similar to
                              integer in generic manner depending on the type
                              of enum whether TET_ENUM or TET_ENUM32 and 
                              supporting of TET_ENUM32 is done under the 
                              GCP_ENUM_U32 flag
          mg008.105   gk   1. Corrected the encoding of subidentifiers
                           2. Added check for elmntLen if it is lessthan msgLen
*********************************************************************91*/
