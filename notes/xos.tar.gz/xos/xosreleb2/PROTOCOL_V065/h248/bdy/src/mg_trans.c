/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
 
     Name:     GCP - Transaction Management Module
 
     Type:     C source file
  
     Desc:     C Source Code for Transaction Management Module
 
     File:     mg_trans.c
  
     Sid:      mp_trans.c@@/main/mgcp_rel_1.5_mnt/3 - Tue May 31 11:49:17 2005
       
     Prg:      bbk
  
*********************************************************************21*/
 
/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*
*/
 
/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*    
*   
*
*/

 
/*
 * The core of MGC product is implemented in following files:
 *
 *    mg_dns.c      DNS Interaction functions 
 *    mg_tmr.c      Timer Management/Maintenance functions
 *    mg_tpt.c      Transport Layer Interaction functions
 *    mg_trans.c    Transaction Management functions
 *    mg_peer.c     Peer Manangement functions
 *    mg_cord.c     Co-ordinator Module functions
 *    mg_ui.c       MGCP Upper Interface Functions
 *    mg_mi.c       MGCP Layer Management Interface
 *    mg_li.c       MGCP Lower Layer (TUCL) Interface
 *    cm_tenc.c     Common Text Based Encode Engine for MGCP messages
 *    cm_tdec.c     Common Text Based Decode Engine for MGCP messages
 */

/* header include files (.h) */
#include "envopt.h"        /* Environment options */  
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */

#ifdef MG

#include "gen.h"           /* General layer */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common Timer functions */
#include "cm_hash.h"       /* Hash library */
#include "cm_llist.h"      /* Doubly Linked List library */
#include "cm_inet.h"       /* Common Sockets Library */
#include "cm_tpt.h"        /* Common Transport Defines */
#include "cm_tkns.h"       /* Common Tokens Defines */
#include "cm_sdp.h"        /* SDP Defines */
#include "cm_dns.h"        /* common DNS library */
#include "cm_mblk.h"       /* Memory Management Defines */
#include "cm_abnf.h" 
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include  "cm_ss7.h"       /* Common SS7 Defines */
#include  "snt.h"          /* MTP3 Interface Defines */
#endif   /* GCP_PROV_MTP3 */

#include "mgt.h"           /* MGT Interface Defines */
#include "lmg.h"           /* MGCP Layer Management */
#include "mg_err.h"        /* MGCP Error Codes */
#ifdef ZG
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#endif /* ZG */
#include "mg.h"            /* MGCP Defines */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer */
#include "ssi.x"           /* System services */
#include "cm5.x"           /* Common timer functions */
#include "cm_hash.x"       /* Hash library */
#include "cm_llist.x"      /* Doubly Linked List library */
#include "cm_inet.x"       /* Common Sockets Library */
#include "cm_tpt.x"        /* Common Transport Definitions */
#include "cm_tkns.x"       /* Common Tokens Defines */
#include "cm_sdp.x"        /* SDP Definitions */
#include "cm_mblk.x"       /* Memory Block Management */
#include "cm_abnf.x"   
#include "cm_lib.x"        /* Common library functions */
#include "cm_dns.x"        /* common dns library */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3 
#include  "cm_ss7.x"       /* Common SS7 Structure */
#include  "snt.x"          /* MTP3 Interface Structure */
#endif    /* GCP_PROV_MTP3 */

#include "mgt.x"           /* MGT Interface Structures */
#include "lmg.x"           /* MGCP Layer Management */
#include "mg.x"            /* MGCP Data Structures */
#ifdef ZG
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#endif /* ZG */


/* local defines, if any */
 
/* local typedefs, if any */
 
/* local externs, if any */

/* forward references */


/* Function to verify peer state and start txn timer */
#ifdef    GCP_PROV_SCTP
PRIVATE S16 mgStartTxnReq ARGS((
        MgPeerCb        *peer,         /* Pointer to Peer Control Block */
        MgTxTransIdEnt  *txCb,         /* Transaction Control Block */
        MgAssocCb       *assocCb,      /* Association Control Block */
        MgTptSrvr       *srvr,         /* Server Control Block */
        Bool            *txnSend       /* Txn to be sent/ queued */ 
       ));
#else     /* GCP_PROV_SCTP */
PRIVATE S16 mgStartTxnReq ARGS((
        MgPeerCb        *peer,         /* Pointer to Peer Control Block */
        MgTxTransIdEnt  *txCb,         /* Transaction Control Block */
        MgTptSrvr       *srvr,         /* Server Control Block */
        Bool            *txnSend       /* Txn to be sent/ queued */ 
       ));
#endif    /* GCP_PROV_SCTP */


/* Function to verify peer state and start rsp timer */
PRIVATE S16 mgStartTxnRsp ARGS((
        U8              protocol,      /* Protocol */  
        MgPeerCb        *peer,         /* Pointer to Peer Control Block */
        MgRxTransIdEnt  *rxCb,         /* Transaction Control Block */
        Bool            strtTmr        /* Start 30 Sec. Timer */    
       ));


PRIVATE MgTxTransIdEnt * mgInitTxCb ARGS((
        MgTransId       transId,       /* Transaction Identifier */
        U8              msgType,       /* Protocol Message Type */
        U8              msgInfo,       /* txCb->msgInfo */
        Bool            retxOnIpAddr,  /* Retransmission on IP address only */
        CmTptAddr       *remoteAddr,   /* Remote Address */
        MgPeerCb        *peer,         /* Pointer to Peer Control Block */
        MgTptSrvr       *tptCb,        /* transport block for transmission */
        Void            *mBuf          /* Message Buffer */
       ));


PRIVATE MgRxTransIdEnt * mgInitRxCb ARGS((
        MgPeerCb        *peer,         /* Pointer to Peer Control Block */
        CmTptAddr       *destTptAddr,  /* Destination Transport Address */
        MgTransId       transId,       /* Transaction Identifier */
        Bool            chkRspParam,   /* Check Response Parameter */
        U8              msgType,       /* Message Type */
        U8              method         /* RSIP/ServiceChange Method */
       ));
#if (defined(GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))
PRIVATE  Void  mgFillLimt ARGS((
         MgTxTransIdEnt  *txCb , 
         MgPeerCb *peer
));
#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */

/******************************************************************************/
/*               Transaction Control Block Related Functions                  */
/******************************************************************************/

/******************************************************************************/
/*               Function to fill the pending limit to txcb                 */
/******************************************************************************/

#if (defined(GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))
#ifdef ANSI
PRIVATE  Void  mgFillLimt
( 
MgTxTransIdEnt  *txCb , 
MgPeerCb *peer
)
#else
PRIVATE  Void  mgFillLimt(txCb,peer)  
MgTxTransIdEnt  *txCb; 
MgPeerCb *peer;
#endif /* if ANSI */
{
  if((peer == NULLP) || (txCb ==NULLP) )
  {
   RETVOID;
  }
  cmMemcpy ((U8 *) &(txCb->limit), (U8 *) &(peer->limit), 
                                    sizeof (MgMgcoPendingLimit)); 
}  

#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */

/******************************************************************************/
/*               Outgoing Transaction Processing  Functions                   */
/******************************************************************************/
/*
*
*       Fun:    mgPrcOutGoingTxn
*
*       Desc:   This function allocates, initializes a transaction control
*               block for outgoing transaction and starts timers for txn 
*               if necessary
*
*       Ret:    Pointer to MgTxTransIdEnt - SUCCESS
*               NULLP                     - FAILURE
*
*       Notes:  None
*
*       File:   mg_trans.c
*
*/
#ifdef    GCP_PROV_SCTP

#ifdef ANSI
PUBLIC MgTxTransIdEnt * mgPrcOutGoingTxn
(
MgTransId          transId,            /* Transaction Identifier */
U8                 msgType,            /* Protocol Message Type */
U8                 msgInfo,            /* txCb->msgInfo = msgInfo */
Bool               retxOnIpAddr,       /* Retransmission on IP address only */
CmTptAddr          *remoteAddr,        /* Remote Address */
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
MgAssocCb          *assoc,             /* Association control block */
MgTptSrvr          *tptCb,             /* transport block for transmission */
Void               *mBuf,              /* Message Buffer */
Bool               *txnSend            /* Txn to be sent/ queued */ 
)
#else
PUBLIC MgTxTransIdEnt * mgPrcOutGoingTxn (transId, msgType, msgInfo,
                                          retxOnIpAddr,
                                          remoteAddr,ssap, peer, assoc,
                                          tptCb, mBuf, txnSend)
MgTransId          transId;            /* Transaction Identifier */
U8                 msgType;            /* Protocol Message Type */
U8                 msgInfo;            /* txCb->msgInfo = msgInfo */
Bool               retxOnIpAddr;       /* Retransmission on IP address only */
CmTptAddr          *remoteAddr;        /* Remote Address */
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
MgAssocCb          *assoc;             /* Association control block */
MgTptSrvr          *tptCb;             /* transport block for transmission */
Void               *mBuf;              /* Message Buffer */
Bool               *txnSend;           /* Txn to be sent/ queued */
#endif

#else     /* GCP_PROV_SCTP */

#ifdef ANSI
PUBLIC MgTxTransIdEnt * mgPrcOutGoingTxn
(
MgTransId          transId,            /* Transaction Identifier */
U8                 msgType,            /* Protocol Message Type */
U8                 msgInfo,            /* txCb->msgInfo = msgInfo */
Bool               retxOnIpAddr,       /* Retransmission on IP address only */
CmTptAddr          *remoteAddr,        /* Remote Address */
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
MgTptSrvr          *tptCb,             /* transport block for transmission */
Void               *mBuf,              /* Message Buffer */
Bool               *txnSend            /* Txn to be sent/ queued */ 
)
#else
PUBLIC MgTxTransIdEnt * mgPrcOutGoingTxn (transId, msgType, msgInfo, retxOnIpAddr,
                                          remoteAddr,ssap, peer, tptCb, mBuf, txnSend)
MgTransId          transId;            /* Transaction Identifier */
U8                 msgType;            /* Protocol Message Type */
U8                 msgInfo;            /* txCb->msgInfo = msgInfo */
Bool               retxOnIpAddr;       /* Retransmission on IP address only */
CmTptAddr          *remoteAddr;        /* Remote Address */
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
MgTptSrvr          *tptCb;             /* transport block for transmission */
Void               *mBuf;              /* Message Buffer */
Bool               *txnSend;           /* Txn to be sent/ queued */
#endif

#endif    /* GCP_PROV_SCTP */
{
   MgTxTransIdEnt  *txCb;              /* Command Transaction Control Block */
   S16             ret;                /* Return Value */

   TRC2(mgPrcOutGoingTxn);

   txCb = NULLP;

   if ((txCb = mgInitTxCb(transId, msgType, msgInfo, retxOnIpAddr, remoteAddr, 
                           peer, tptCb, mBuf)) == NULLP)
   {
      RETVALUE(NULLP);
   }

   /* Based on the peer state, insert it in appropriate linked list and
    * start the retransmission timer if peer state indicates it would be
    * transmitted right away. Update transaction state too
    */


#ifdef    GCP_PROV_SCTP
   ret = mgStartTxnReq(peer, txCb, assoc, tptCb, txnSend);
#else     /* GCP_PROV_SCTP */
   ret = mgStartTxnReq(peer, txCb, tptCb, txnSend);
#endif    /* GCP_PROV_SCTP */


   
#ifdef    GCP_PROV_SCTP
   /*
    *   For SCTP, its possible that the assoc still be NULLP
    *   since the association may not yet have been established;
    *   Therfore, do NOT check assoc for NULLP for SCTP case;
    */
   if ((ret != ROK) ||
       ((*txnSend == TRUE)  && (tptCb == NULLP) &&
        (peer->accessInfo.transportType != LMG_TPT_SCTP)))
#else     /* GCP_PROV_SCTP */
   if ((ret != ROK) || 
      ((*txnSend == TRUE)  && (tptCb == NULLP) && 
       (peer->accessInfo.transportType != LMG_TPT_MTP3)))                                          
#endif    /* GCP_PROV_SCTP */
   {
      mgDeAlloc((Data *)txCb, sizeof(MgTxTransIdEnt));
      RETVALUE(NULLP);
   }
#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
#ifndef GCP_USER_RETX_CNTRL
   /* Check if ..txCb is going to be transmitted now (i.e it isn't queued ) then
    * start disconnect timer..time out period as twice of txn timeout period..
    * this timer will be stopped when response is received from peer. */
   if((peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP) &&
      (peer->mntInfo.variant == LMG_VER_PROF_MGCP_RFC2705_1_0))
   {
      if(peer->ssap->ssapCfg.reCfg.txnTmoutTmr.enb == TRUE)
      {
         /* Disconnect Timer is NOT to be started for MESG msg */
         if ((*txnSend == TRUE)
#ifdef GCP_PKG_MGCP_BASE
                       &&
             (msgType != MGT_MSG_MESG)
#endif /* GCP_PKG_MGCP_BASE */
            )
         {
            (Void) mgStartTmr (MG_TXN_DISC_TMR, 
                          (2 * peer->ssap->ssapCfg.reCfg.txnTmoutTmr.val), 
                          (PTR) txCb, &(txCb->discTmr));
         }
      }
   }
#endif /* ! GCP_USER_RETX_CNTRL */
#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */

#ifdef ZG
   /* mg003.105: Bug Fix for GCP PSF */
   ZG_INIT_RSETID_IN_MAPCB(&(txCb->mapCb));
   zgAddMapping(ZG_CBTYPE_TXN_TX, (Ptr)txCb);
#ifdef ZG_TXN_LVL_UPD
   zgRtUpd(ZG_CBTYPE_TXN_TX, (Ptr)txCb, CMPFTHA_UPDTYPE_NORMAL,
      CMPFTHA_ACTN_ADD);
   zgUpdPeer();
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */

   RETVALUE(txCb);

} /* end of mgPrcOutGoingTxn() */




/*
*
*       Fun:    mgStartTxnReq
*
*       Desc:   Function queues msg or starts txn timer based on peer state 
*               for MEGACO
*
*       Ret:    Pointer to MgTxTransIdEnt - SUCCESS
*               NULLP                     - FAILURE
*
*       Notes:  None
*
*       File:   mg_trans.c
*
*/

#ifdef    GCP_PROV_SCTP

#ifdef ANSI
PRIVATE S16 mgStartTxnReq
(
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
MgTxTransIdEnt     *txCb,              /* Transaction Control Block */
MgAssocCb          *assoc,             /* Association Control Block */
MgTptSrvr          *srvr,              /* Server Control Block */
Bool               *txnSend            /* Txn to be sent/ queued */ 
)
#else
PRIVATE S16 mgStartTxnReq(peer, txCb, assoc, srvr, txnSend)
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
MgTxTransIdEnt     *txCb;              /* Transaction Control Block */
MgAssocCb          *assoc;             /* Association Control Block */
MgTptSrvr          *srvr;              /* Server Control Block */
Bool               *txnSend;           /* Txn to be sent/ queued */ 
#endif

#else     /* GCP_PROV_SCTP */

#ifdef ANSI
PRIVATE S16 mgStartTxnReq
(
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
MgTxTransIdEnt     *txCb,              /* Transaction Control Block */
MgTptSrvr          *srvr,              /* Server Control Block */
Bool               *txnSend            /* Txn to be sent/ queued */ 
)
#else
PRIVATE S16 mgStartTxnReq(peer, txCb, srvr, txnSend)
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
MgTxTransIdEnt     *txCb;              /* Transaction Control Block */
MgTptSrvr          *srvr;              /* Server Control Block */
Bool               *txnSend;           /* Txn to be sent/ queued */ 
#endif

#endif    /* GCP_PROV_SCTP */
{
   Bool            transmitTxn;        /* Transmit Transaction ? */

   TRC2(mgStartTxnReq)
  
   transmitTxn = FALSE;
#ifdef GCP_MGC
   /*
    * Fill the limits to TxCb here 
      This function is used because MgcoTxn is not visible inside 
      the fucntion.Also txCb corresponds to one txn.
    */
 
#if (defined(GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))
   mgFillLimt(txCb,peer);
#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */
#endif /* GCP_MGC */   
   txCb->lnkLstNode.node = (PTR) txCb;

   switch (peer->state)
   {
      case LMG_PEER_STATE_RESOLVING:
      case LMG_PEER_STATE_CONNECT:
      case LMG_PEER_STATE_DISCONNECTED:
         break;

      case LMG_PEER_STATE_REGISTER:
      {
         if (mgCb.genCfg.entType == LMG_ENT_GW)
         {
            transmitTxn = TRUE;
         }
      }
      break;

      case LMG_PEER_STATE_AWAIT_REG:
      {

         /* In this state there can only be service change for the MG */
#ifdef    GCP_PROV_SCTP
         if ((peer->accessInfo.transportType == LMG_TPT_TCP) ||
             (peer->accessInfo.transportType == LMG_TPT_SCTP))
#else     /* GCP_PROV_SCTP */
         if (peer->accessInfo.transportType == LMG_TPT_TCP)
#endif    /* GCP_PROV_SCTP */
         {
           /* If transport is TCP, initiate TCP connection & Q message */
           break;
         }

         /* For UDP ...fall through */
      }

      case LMG_PEER_STATE_ACTIVE:
      {
         transmitTxn = TRUE;        
         break;
      }

      default:
         RETVALUE(RFAILED);
   }


   /* If srvr is available at this point, and its state is not connected,
    * queue this transaction*/
#ifdef    GCP_PROV_MTP3    
   if (peer->accessInfo.transportType == LMG_TPT_MTP3)
   {
   /* If Point Code is not online then queue the Transaction */   
      if(!(peer->mgcoMtpCb.status & SP_ONLINE))
            transmitTxn = FALSE;
   }         
   else
#endif    /* GCP_PROV_MTP3 */   

#ifdef    GCP_PROV_SCTP
   if (peer->accessInfo.transportType == LMG_TPT_SCTP)
   {
      /*
       *   if association has not yet been established OR
       *   if the association request has been sent but cfm
       *   is still awaited, queue the transactions
       */
      if ((assoc == NULLP) || (assoc->assocState != LMG_ASSOC_STATE_ACTIVE))
         transmitTxn = FALSE;
   }
   else 
#endif    /* GCP_PROV_SCTP */
     if (srvr != NULLP)
     {
       if (srvr->state == LMG_LSTNR_STATE_CONNECTING)
         transmitTxn = FALSE;
     }


   if (transmitTxn == TRUE)
   {
      MG_XMIT_TRANS(peer, txCb);     
      *txnSend = TRUE;
   }
   else
      MG_QUEUE_TRANS(peer, txCb);

   RETVALUE(ROK);
   
} /* end of mgStartTxnReq() */



/*
*
*       Fun:    mgInitTxCb
*
*       Desc:   This function allocates, initializes a transaction control
*               block for outgoing transaction
*
*       Ret:    Pointer to MgTxTransIdEnt - SUCCESS
*               NULLP                     - FAILURE
*
*       Notes:  None
*
*       File:   mg_trans.c
*
*/

#ifdef ANSI
PRIVATE MgTxTransIdEnt * mgInitTxCb
(
MgTransId          transId,            /* Transaction Identifier */
U8                 msgType,            /* Protocol Message Type */
U8                 msgInfo,            /* txCb->msgInfo */
Bool               retxOnIpAddr,       /* Retransmission on IP address only */
CmTptAddr          *remoteAddr,        /* Remote Address */
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
MgTptSrvr          *tptCb,             /* transport block for transmission */
Void               *mBuf              /* Message Buffer */
)
#else
PRIVATE MgTxTransIdEnt * mgInitTxCb(transId,  msgType, msgInfo, retxOnIpAddr,
                                          remoteAddr,peer, tptCb, mBuf)
MgTransId          transId;            /* Transaction Identifier */
U8                 msgType;            /* Protocol Message Type */
U8                 msgInfo;            /* txCb->msgInfo */
Bool               retxOnIpAddr;       /* Retransmission on IP address only */
CmTptAddr          *remoteAddr;        /* Remote Address */
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
MgTptSrvr          *tptCb;             /* transport block for transmission */
Void               *mBuf;              /* Message Buffer */
#endif
{
   MgTxTransIdEnt  *txCb;              /* Command Transaction Control Block */

   TRC2(mgInitTxCb);

   txCb    = NULLP;

   /* Allocate transaction control block */
   if ((txCb = (MgTxTransIdEnt *)mgMalloc(sizeof(MgTxTransIdEnt))) == NULLP)
      RETVALUE(NULLP);
   /* Initialize the transaction control block */
   txCb->trType           = MG_TRANS_TYPE_TX;
   txCb->transId          = transId;
   txCb->peer             = peer;
   if(LMG_PROTOCOL_MGCP == peer->mntInfo.protocolType)
   {
#ifdef GCP_MGCP
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
      txCb->u.txBufInfo        = (MgTxBufInfo *)mBuf;
#else
      txCb->u.mBuf             = (Buffer *)mBuf;
#endif
#endif /* GCP_MGCP */
   }
   else
   {
      txCb->u.mBuf             = (Buffer *)mBuf;
   }
   txCb->msgType          = msgType;
   txCb->retxOnIpAddr     = retxOnIpAddr;
   txCb->everRetxed       = FALSE;
   txCb->msgInfo          = msgInfo;

/* initialize values of acknowledgement delay and retransmission
 * timer value fromt the peer control block */
   txCb->aad              = peer->mntInfo.aad;
   txCb->rto              = peer->mntInfo.rto;
   txCb->retxCnt          = 0;

   /* Note the transmission transport information */
   if (tptCb != NULLP)
     txCb->suConnId  = tptCb->suConnId;

   /* Initialise timer control blocks */
   cmInitTimers(&(txCb->retxTmr), MG_DEFAULT_MAXTMR);
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
   cmInitTimers(&(txCb->discTmr), MG_DEFAULT_MAXTMR);
#endif /* GCP_VER_1_3 && GCP_2705BIS */

   /* Store the gateway's IP Address being used */
   txCb->addrTbl.count = 1;

#ifdef GCP_MGCP
   if ((remoteAddr->type == CM_TPTADDR_IPV4) ||
       (remoteAddr->type == CM_TPTADDR_IPV6))
   {
      /* copy IPV4/IPV6 address */
      MG_FILL_NETADDR_FRM_TPTADDR(&(txCb->addrTbl.netAddr[0]),
                                  remoteAddr);
      MG_FILL_PORT_FRM_TPTADDR(txCb->remotePort, remoteAddr);
   }
   else
#endif /* GCP_MGCP */
   if (remoteAddr->type == CM_TPTADDR_NOTPRSNT)
   {
      txCb->remotePort = peer->accessInfo.remotePort;
      cmMemcpy((U8 *)&(txCb->addrTbl.netAddr[0]), 
            (CONSTANT U8 *)&(peer->accessInfo.peerAddrTbl.netAddr[0]), 
               sizeof(CmNetAddr));
   }

#ifdef ZG
   ZG_INIT_RSETID_IN_MAPCB(&(txCb->mapCb));
#endif /* ZG */

/* mg008.105: Corrected the comments */
#if (defined(GCP_VER_1_5) && defined(GCP_PKG_MGCO_ROOT))
   cmInitTimers(&(txCb->provRspRtTmr), MG_DEFAULT_MAXTMR);
#endif /* GCP_VER_1_5 && GCP_PKG_MGCO_ROOT */
   RETVALUE(txCb);

} /* end of mgInitTxCb() */



/******************************************************************************/
/*               Outgoing Ack Processing  Functions                           */
/******************************************************************************/

/*
*
*       Fun:    mgPrcOutGoingAck
*
*       Desc:   This function stores the acknowledgement being sent out for
*               a previously received command and does maintenance of 
*               MgRxTransIdEnt data structure identifying the command rcvd.
*
*       Ret:    Pointer to MgRxTransIdEnt - SUCCESS
*               NULLP                     - FAILURE
*
*       Notes:  If the stack is MGC and the user is trying to issue an ack
*               for a txn for which it the stack doesnot have context, the 
*               outgoing ack will still be processed and sent out if the peer
*               is under handoff. A new context is also created for this txn.
*               This is done because the stack may be acting as new MGC to
*               a peer which is being handed off so may not have context of
*               previous txn received, but the service user might have a 
*               context for it and may be trying to respond to a previously
*               received command. 
*
*       File:   mg_trans.c
*
*/
#ifdef ANSI
PUBLIC MgRxTransIdEnt * mgPrcOutGoingAck
(
U8                 protocol,           /* MGCP/MEGACO */
U8                 rspType,            /* ResponseType:Provisional/Normal etc*/
MgTransId          transId,            /* Transaction Identifier */
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
Buffer             *mBuf,              /* Message Buffer */
Bool               *immAck,            /* Fill immAck Request ? */
Bool               rsp2RegCmd          /* Response to Registration Cmd ? */
)
#else
PUBLIC MgRxTransIdEnt * mgPrcOutGoingAck (protocol, rspType, transId, peer, 
                                          mBuf,immAck, rsp2RegCmd)
U8                 protocol;           /* MGCP/MEGACO */
U8                 rspType;            /* ResponseType:Provisional/Normal etc*/
MgTransId          transId;            /* Transaction Identifier */
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
Buffer             *mBuf;              /* Message Buffer */
Bool               *immAck;            /* Fill immAck Request ? */
Bool               rsp2RegCmd;         /* Response to Registration Cmd ? */
#endif
{
   MgRxTransIdEnt  *rxCb;              /* Response Transaction Control Block */
   S16             ret;                /* Return Value */
#if (defined(ZG) || (defined(GCP_MGC) && defined(GCP_MGCO)))
   U8              msgType;            /* Message Type */
   CmTptAddr       destTptAddr;        /* Remote Address */
#endif /* (defined(ZG) || (defined(GCP_MGC) && defined(GCP_MGCO))) */
   U8              method;             /* RSIP/SvcChg Command Method */
#ifdef  GCP_2705BIS
#ifdef  GCP_VER_1_3
   U16             idx;
#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */


   TRC2(mgPrcOutGoingAck);

   rxCb    = NULLP;
   *immAck = FALSE;
   method  = MG_NONE;

   /* Search for the control block */
   if ((cmHashListFind(&(peer->inTransLst), (U8 *)&transId, MG_TRANSID_LEN,
                     MG_HASH_SEQNMB_DEF, (PTR *)&rxCb)) != ROK)
   {
#ifdef ZG

      /* In case of fault tolerance..create context for 
         unknown outgoing responses */
      if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
      {
#ifdef GCP_MGCO
         if (rspType == MG_RESPONSE_PROV)
         {
            msgType = MGT_TXNPEND;
         }
         else
            msgType = MGT_TXNREPLY;

         if ((peer->state == LMG_PEER_STATE_REGISTER) && (rsp2RegCmd == TRUE))
         {
            method = MGT_SVCCHGMETH_RESTART;
         }
#endif /* GCP_MGCO */
      }
      else if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
      {
#ifdef GCP_MGCP
          msgType = MGT_MSG_RSP;
#endif /* GCP_MGCP */
      }

      MG_FILL_TPTADDR_FRM_NETADDR(&destTptAddr, 
                                  &(peer->accessInfo.peerAddrTbl.netAddr[0]));
      MG_FILL_TPTADDR_PORT(&destTptAddr, peer->accessInfo.remotePort);

      if ((rxCb = mgInitRxCb(peer, &destTptAddr, transId, FALSE, 
                             msgType, method)) == NULLP)
      {
         RETVALUE(NULLP);
      }

      /* mg003.105: Bug Fix for GCP PSF */
      ZG_INIT_RSETID_IN_MAPCB(&(rxCb->mapCb));
      zgAddMapping(ZG_CBTYPE_TXN_RX,(Ptr)rxCb);
#ifdef ZG_TXN_LVL_UPD
      zgRtUpd(ZG_CBTYPE_TXN_RX, (Ptr)rxCb, 
              CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_ADD);
      zgUpdPeer();
#endif /* ZG_TXN_LVL_UPD */
#else /* ZG */
#ifdef GCP_MGCO
#ifdef GCP_MGC
     /* 
      * if peer is under handoff and there is no context, accept the ack and
      * create a context for it 
      */

     if ((mgCb.genCfg.entType == LMG_ENT_GC) &&
         (peer->mgcoInfo.hndOffInProg == TRUE))
     {
       if (rspType == MG_RESPONSE_PROV)
       {
         msgType = MGT_TXNPEND;
       }
       else
         msgType = MGT_TXNREPLY;

       MG_FILL_TPTADDR_FRM_NETADDR(&destTptAddr,
                                   &(peer->accessInfo.peerAddrTbl.netAddr[0]));

      if ((rxCb = mgInitRxCb(peer,&destTptAddr, transId, FALSE, 
                             msgType, MG_NONE)) == NULLP)
      {
         RETVALUE(NULLP);
      }

#ifdef ZG
      zgAddMapping(ZG_CBTYPE_TXN_RX,(Ptr)rxCb);
#ifdef ZG_TXN_LVL_UPD
      zgRtUpd(ZG_CBTYPE_TXN_RX, (Ptr)rxCb, 
              CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_ADD);
      zgUpdPeer();
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */
     }
     else
#endif /* GCP_MGC */
#endif /* GCP_MGCO */
       RETVALUE(NULLP);
#endif /* ZG_DFTHA */
   }

   /* Change txn state depending on type of response */
   if (rspType == MG_RESPONSE_PROV)
   {
      rxCb->state     = MG_INTXN_PROVRSP_SENT;
      rxCb->rspStatus = MG_RESPONSE_PROV;
   }
   else
   {
/* mg003.105: Changes to send immAck only if rspAckEnb is configured as
 * LMG_GET_RSPACK_MGCO in general configuration */
if(((rxCb->rspStatus == MG_RESPONSE_PROV)
#if (defined(GCP_MGCO) && defined(GCP_VER_1_3))
         || (protocol == LMG_PROTOCOL_MGCO)) &&
         (mgCb.genCfg.reCfg.rspAckEnb & LMG_GET_RSPACK_MGCO
#endif /* GCP_MGCO && GCP_VER_1_3 */
         ))
      {
         *immAck = TRUE;
      }
      rxCb->state     = MG_INTXN_RSP_SENT;
      rxCb->rspStatus = MG_NONE;
#ifdef GCP_MGCP
#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
      /* if transaction timeout is started ..then stop it */
      if(protocol == LMG_PROTOCOL_MGCP)
      {
         idx = MG_TXNTMOUT_TMR - MG_INTXN_TMR_BASE;
         if (rxCb->tmr[idx].tmrEvnt == MG_TXNTMOUT_TMR)
         {
            mgStopTmr(MG_TXNTMOUT_TMR, (PTR) rxCb, &(rxCb->tmr[idx]));
         }
      }
#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */
#endif /* GCP_MGCP */
   }

   /* Store the response buffer */
   if (rxCb->mBuf != NULLP)   
      mgPutMsg(rxCb->mBuf);    /* keep latest one */

   rxCb->mBuf = mBuf;

   /* Process outgoing response */
   ret = mgStartTxnRsp(protocol, peer, rxCb, *immAck);
   
   if (ret != ROK)
   {
      rxCb->state      = MG_INTXN_TXN_RCVD;
      RETVALUE(NULLP);
   }

#ifdef GCP_MGCP
#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
      /* if transaction timeout is started ..then stop it */
   if (rspType != MG_RESPONSE_PROV)
   {
      if(protocol == LMG_PROTOCOL_MGCP)
      {
         idx = MG_TXNTMOUT_TMR - MG_INTXN_TMR_BASE;
         if (rxCb->tmr[idx].tmrEvnt == MG_TXNTMOUT_TMR)
         {
            mgStopTmr(MG_TXNTMOUT_TMR, (PTR) rxCb, &(rxCb->tmr[idx]));
         }
      }
   }
#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */
#endif /* GCP_MGCP */

   RETVALUE(rxCb);
} /* end of mgPrcOutGoingAck() */





/*
*
*       Fun:    mgStartTxnRsp
*
*       Desc:   Function queues rsp or starts rsp timer based on peer state 
*               
*
*       Ret:    Pointer to MgTxTransIdEnt - SUCCESS
*               NULLP                     - FAILURE
*
*       Notes:  None
*
*       File:   mg_trans.c
*
*/

#ifdef ANSI
PRIVATE S16 mgStartTxnRsp
(
U8                 protocol,           /* Protocol */
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
MgRxTransIdEnt     *rxCb,              /* Transaction Control Block */
Bool               noTmr               /* 30 Sec Timer */
)
#else
PRIVATE S16 mgStartTxnRsp(protocol,peer, rxCb, noTmr)
U8                 protocol;           /* Protocol */
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
MgRxTransIdEnt     *rxCb;              /* Transaction Control Block */
Bool               noTmr;              /* 30 Sec Timer */
#endif
{
   U16             idx;                /* Index */
   Bool            strtTmr;

   TRC2(mgStartTxnRsp)
  
   strtTmr = FALSE;
   if (peer->ssap->ssapCfg.reCfg.atMostOnceTmr.enb == TRUE)
   {
      strtTmr = TRUE;
   }
   switch (peer->state)
   {
      case LMG_PEER_STATE_RESOLVING:
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         MGLOGERROR(ERRCLS_DEBUG, EMG293, 0,
                     "[MGCP] mgStartTxnRsp: Invalid Peer State\n");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         RETVALUE(RFAILED);
      }
      break;

      case LMG_PEER_STATE_REGISTER:
#ifdef GCP_MGCO 
      case LMG_PEER_STATE_UNDR_HNDOFF:
#endif /* GCP_MGCO */
      case LMG_PEER_STATE_ACTIVE:
      {
         /* 
          * If peer is in register state messages/rsp are allowed only on 
          * the MGC side 
          */
         if ((peer->state != LMG_PEER_STATE_REGISTER) || 
            (mgCb.genCfg.entType == LMG_ENT_GC))
         {
            if (rxCb->rspStatus == MG_RESPONSE_PROV)
            {
               idx = MG_PROVRSP_TMR - MG_INTXN_TMR_BASE;
               if (rxCb->tmr[idx].tmrEvnt == MG_PROVRSP_TMR)
                  mgStopTmr(MG_PROVRSP_TMR, (PTR) rxCb, &(rxCb->tmr[idx]));
            }
            else
            {
               /* Stop provisional response timer */
               idx = MG_PROVRSP_TMR - MG_INTXN_TMR_BASE;
               if (rxCb->tmr[idx].tmrEvnt == MG_PROVRSP_TMR)
                  mgStopTmr(MG_PROVRSP_TMR, (PTR) rxCb, &(rxCb->tmr[idx]));
#ifdef GCP_MGCP
#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
               /* In Case of 2705Bis , For final responses 30 sec timer will not
                * be started as it is going to be retransmitted if no Response
                * Ack Response is rcved. It will follow the same retransmission
                * algorithm as that of outgoing command. This rxCb will be
                * deallocated either when RspAckRsp is rcved or retxAlgo has
                * exhausted */
               if(LMG_PROTOCOL_MGCP == peer->mntInfo.protocolType)
               {
                  /* mg002.105: Made rspAckEnb reconfigurable */
                  if((noTmr == FALSE) && 
                     (mgCb.genCfg.reCfg.rspAckEnb & LMG_EMBD_EMPTY_RSPACK_MGCP))
                  {
                     if (peer->ssap->ssapCfg.reCfg.atMostOnceTmr.enb == TRUE)
                     {
                        strtTmr = FALSE;
                     }
                  }
               }
#endif
#endif
#endif /* GCP_MGCP */
               if(TRUE == strtTmr)
               {
                     /* Start 30 sec timer */
                  idx = MG_30SEC_TMR - MG_INTXN_TMR_BASE;
                  mgStartTmr(MG_30SEC_TMR, 
                              peer->ssap->ssapCfg.reCfg.atMostOnceTmr.val, 
                              (PTR)rxCb,&(rxCb->tmr[idx]));
               }
            }
         }
         else
            RETVALUE(RFAILED);
      }
      break;
   }

   RETVALUE(ROK);

} /* end of mgStartTxnRsp() */



/*
*
*       Fun:    mgInitRxCb
*
*       Desc:   This function allocates and initialises transaction control 
*               block identifying the transaction received
*
*       Ret:    ROK     - SUCCESS
*               RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_trans.c
*
*/

#ifdef ANSI
PRIVATE MgRxTransIdEnt * mgInitRxCb
(
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
CmTptAddr          *destTptAddr,       /* Destination Transport Address */
MgTransId          transId,            /* Transaction Identifier */
Bool               chkRspParam,        /* Check Response Parameter */
U8                 msgType,            /* Message Type */
U8                 method              /* RSIP/ServiceChange Method */
)
#else
PRIVATE MgRxTransIdEnt * mgInitRxCb (peer, destTptAddr, transId, chkRspParam,
                                     msgType, method)
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
CmTptAddr          *destTptAddr;       /* Destination Transport Address */
MgTransId          transId;            /* Transaction Identifier */
Bool               chkRspParam;        /* Check Response Parameter */
U8                 msgType;            /* Message Type */
U8                 method;             /* RSIP/ServiceChange Method */
#endif
{
   MgRxTransIdEnt  *rxCb;              /* Transaction Control Block */

   TRC2(mgPrcInitRxCb)

   rxCb = NULLP;

   /* New Transaction : allocate a transaction control block */
   if ((rxCb = (MgRxTransIdEnt *)mgMalloc(sizeof(MgRxTransIdEnt))) == NULLP)
      RETVALUE(NULLP);

   /* Initialise the transaction control block */
   rxCb->trType      = MG_TRANS_TYPE_RX;
   rxCb->transId     = transId;
   rxCb->peer        = peer;
   rxCb->msgType     = msgType;
   rxCb->rspStatus   = MG_NONE;
   rxCb->chkRspParam = chkRspParam;
   rxCb->regCmdMethod = method;

#ifdef GCP_VER_1_3
#ifdef GCP_MGCP
#ifdef GCP_2705BIS
   if(peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
   {
      rxCb->aad = peer->mntInfo.aad;
      rxCb->adev = peer->mntInfo.adev;
      rxCb->rto = peer->mntInfo.rto;
      rxCb->retxCnt = 0;
   }
#endif /* GCP_2705BIS */
#endif /* GCP_MGCP */
#endif /* GCP_VER_1_3 */
  
#ifdef   GCP_PROV_MTP3
    if(peer->accessInfo.transportType != LMG_TPT_MTP3)
#endif   /* GCP_PROV_MTP3 */   
      /* Store destination tranport Address */
         cmMemcpy((U8 *)&(rxCb->tptAddr), (CONSTANT U8 *)destTptAddr, 
            sizeof(CmTptAddr));

   /* Initialise timer control blocks */
   cmInitTimers(rxCb->tmr, MG_INTXN_TMR);

   /* Insert it into incoming transaction hash list */
   if ((cmHashListInsert (&(peer->inTransLst), (PTR) rxCb, 
                          (U8 *)&(rxCb->transId), MG_TRANSID_LEN)) != ROK)
   {
      mgDeAlloc((Data *)rxCb, sizeof(MgRxTransIdEnt));
      RETVALUE(NULLP);
   }

   rxCb->state = MG_INTXN_TXN_RCVD;

#ifdef ZG
   ZG_INIT_RSETID_IN_MAPCB(&(rxCb->mapCb));
#endif /* ZG */

   RETVALUE(rxCb);

} /* end of mgInitRxCb() */

/******************************************************************************/
/*               Incoming  Transaction Processing  Functions                  */
/******************************************************************************/

/*
*
*       Fun:    mgPrcIncomingTxn
*
*       Desc:   This function process command received from network..It 
*               allocates and initialises transaction control block identifying
*               the transaction received
*
*       Ret:    ROK     - SUCCESS
*               RFAILED - FAILURE
*
*       Notes:  If a duplicate transaction is received the following may happen:
*               - If the user has already responded the stored response will be 
*                 sent out and the transaction is not given to the user.
*               - If user has already responded with a provisional response send
*                 out the provisional response and indicate txn to the user    
*               - If user has not responded but the provisional response timer
*                 is enabled, the stack will automayically generate a 
*                 provisional response and txn will be indicated to the user
*                 with duplicate flag set.
*
*       File:   mg_trans.c
*
*/

#ifdef    GCP_PROV_SCTP

#ifdef ANSI
PUBLIC MgRxTransIdEnt * mgPrcIncomingTxn
(
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
CmTptAddr          *destTptAddr,       /* Destination Transport Address */
MgTransId          transId,            /* Transaction Identifier */
U8                 *dupFlag,           /* Duplicate Transaction marker */
Bool               chkRspParam,        /* Check Response Parameter */
MgAssocCb          *assoc,             /* Association control block */
MgTptSrvr          *srvrCb,            /* Server control block */
U8                 msgType,            /* Message Type */
U8                 method              /* RSIP/Service Change Method */
)
#else
PUBLIC MgRxTransIdEnt * mgPrcIncomingTxn (peer, destTptAddr, transId, dupFlag,
                                          chkRspParam, assoc, srvrCb,
                                          msgType, method)
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
CmTptAddr          *destTptAddr;       /* Destination Transport Address */
MgTransId          transId;            /* Transaction Identifier */
U8                 *dupFlag;           /* Duplicate Transaction marker */
Bool               chkRspParam;        /* Check Response Parameter */
MgAssocCb          *assoc;             /* Association control block */
MgTptSrvr          *srvrCb;            /* Server control block */
U8                 msgType;            /* Message Type */
U8                 method;             /* RSIP/Service Change Method */
#endif

#else     /* GCP_PROV_SCTP */

#ifdef ANSI
PUBLIC MgRxTransIdEnt * mgPrcIncomingTxn
(
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
CmTptAddr          *destTptAddr,       /* Destination Transport Address */
MgTransId          transId,            /* Transaction Identifier */
U8                 *dupFlag,           /* Duplicate Transaction marker */
Bool               chkRspParam,        /* Check Response Parameter */
MgTptSrvr          *srvrCb,            /* Server control block */
U8                 msgType,            /* Message Type */
U8                 method              /* RSIP/Service Change Method */
)
#else
PUBLIC MgRxTransIdEnt * mgPrcIncomingTxn (peer, destTptAddr, transId, dupFlag,
                                          chkRspParam, srvrCb,
                                          msgType, method)
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
CmTptAddr          *destTptAddr;       /* Destination Transport Address */
MgTransId          transId;            /* Transaction Identifier */
U8                 *dupFlag;           /* Duplicate Transaction marker */
Bool               chkRspParam;        /* Check Response Parameter */
MgTptSrvr          *srvrCb;            /* Server control block */
U8                 msgType;            /* Message Type */
U8                 method;             /* RSIP/Service Change Method */
#endif

#endif    /* GCP_PROV_SCTP */
{
   MgRxTransIdEnt  *rxCb;              /* Transaction Control Block */
   Buffer          *mBuf;              /* Message Buffer */
   U16             idx;                /* Timer Index */
   MgTptSrvr       *srvr;              /* Server For retransmission */

   TRC2(mgPrcIncomingTxn)

   rxCb = NULLP;

   srvr = NULLP;

   /* Check if received transaction is a retransmission from peer */
   if ((cmHashListFind(&(peer->inTransLst), (U8 *)&transId, MG_TRANSID_LEN,
                     MG_HASH_SEQNMB_DEF, (PTR *)&rxCb)) == ROK)
   {

	  /* Update Statistics, added by cdw on 2006.9.26 */
	  MG_UPD_MGCO_PEER_RERX_STS(msgType, peer->peerSts);
     
      /* Send Duplicate Txn, with dupFlag set, to the service user */
      *dupFlag = PRSNT_NODEF;

      /* 
       * For the retransmission received, if the service user has not responded
       * yet, copy the source transport address. The response will always be 
       * sent to the latest source address of the command
       */
#ifdef GCP_MGCP

      if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
      {
#if (defined(GCP_VER_1_3) && (!defined(GCP_2705BIS)))
         if (peer->mntInfo.variant == LMG_VER_PROF_MGCP_NCS_1_0 ||
             peer->mntInfo.variant == LMG_VER_PROF_MGCP_TGCP_1_0)
#endif /* GCP_VER_1_3 & ! GCP_2705BIS */
         {
            /*
             * NCS 1.0 - Page 86; TGCP 1.0 - Page 89
             * says response buffer can be freed, but keep a record
             * of execution of transaction; Commands received with same 
             * transactionId should be discarded till atmost once timer expires
             */
             if (rxCb->rspStatus == MG_RESPONSE_ACKED)
             {
                RETVALUE(NULLP);
             }
         }
      }
#endif /* GCP_MGCP */

      /* If no response has been sent out before */
      if (rxCb->mBuf == NULLP)
      {
#ifdef   GCP_PROV_MTP3
    if(peer->accessInfo.transportType != LMG_TPT_MTP3)
#endif   /* GCP_PROV_MTP3 */   
         cmMemcpy((U8 *)&(rxCb->tptAddr), (CONSTANT U8 *)destTptAddr, 
                  sizeof(CmTptAddr));
         
         /* If provional Response Timer is running, stop the timer and
            send out the provisional Response*/
         idx = MG_PROVRSP_TMR - MG_INTXN_TMR_BASE;

         if (rxCb->tmr[idx].tmrEvnt != TMR_NONE)
         {
            S16 tmrEvnt = rxCb->tmr[idx].tmrEvnt;
            mgStopTmr(rxCb->tmr[idx].tmrEvnt, (PTR)rxCb, &(rxCb->tmr[idx]));
            
            if (peer->ssap->ssapCfg.reCfg.provRspTmr.enb == TRUE)
              mgPrcTmrExpiry((PTR)rxCb, tmrEvnt);
         }

         /* 
          * If the user expects environment to be lossy and wants to receive
          * retransmissions of the command; send it to him by returning rxCb
          */
         if (mgCb.genCfg.indicateRetx == TRUE)
            RETVALUE(rxCb);
         else
            RETVALUE(NULLP);
      }

      /* Try to get server for transmission */
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
      if ((peer->accessInfo.transportType != LMG_TPT_SCTP)  &&
         (peer->accessInfo.transportType != LMG_TPT_MTP3))
      {
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */

         srvr = mgGetSendSrvr(peer->ssap, peer);
         if (srvr == NULLP)
         {
           *dupFlag = NOTPRSNT;
           RETVALUE(NULLP);
         }

#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
      }
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3*/
      

      /* Create a copy of buffer for transmission */
      if ((SAddMsgRef (rxCb->mBuf, peer->tsap->tsapCfg.memId.region,
                       peer->tsap->tsapCfg.memId.pool, &mBuf)) != ROK)
      {
        *dupFlag = NOTPRSNT;
         RETVALUE(NULLP);
      }

      /* 
       * If User has sent a  response before and if it is not a prov rsp, 
       * start 30 sec timer( if required ) and send message out 
       */
      if (rxCb->rspStatus != MG_RESPONSE_PROV)
      {
         /* If user has already responded retransmit the message */
         idx = MG_30SEC_TMR - MG_INTXN_TMR_BASE;

         if (rxCb->tmr[idx].tmrEvnt == TMR_NONE)
         {
            mgStartTmr (MG_30SEC_TMR, MG_30SEC_TMR_VALUE, (PTR) rxCb, 
                        &(rxCb->tmr[idx]));
         }
      }

#ifdef GCP_MGCO
      if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
      {
         /* Update Statistics */
         MG_UPD_MGCO_PEER_TX_STS(MGT_TXNREPLY, peer->peerSts);
      }
#endif /* GCP_MGCO */

#ifdef GCP_MGCP
      if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
      {
         /* Update Statistics */
         MG_UPD_MGCP_PEER_TX_STS(MGT_MSG_RSP, peer->peerSts);
      }
#endif /* GCP_MGCP */

      /* Retransmit the response */
      if (srvr)
         mgSrvDatReq(srvr, destTptAddr, mBuf);

#ifdef   GCP_PROV_MTP3      
      else if (peer->accessInfo.transportType == LMG_TPT_MTP3)
         mgMtpDatReq(peer, NULLD, NULLD,peer->tsap,mBuf); 
#endif   /* GCP_PROV_MTP3 */         

#ifdef    GCP_PROV_SCTP
      else           /*  strm needed */
      {
         CmNetAddr  tmpNetAddr;
         SctStrmId  strm;
         TknU32     ctxId;


         /* For retransmission we shall use another stream-Id */
         /* mg002.105: Removed compilation warning */
         ctxId.pres = NOTPRSNT;
         ctxId.val    = 0;

         MG_MGCO_GET_STRMID_FRM_CTXID(strm,(&ctxId),assoc);

         tmpNetAddr.type = CM_NETADDR_NOTPRSNT;

         /*
          * Deliver the msg using unordered delivery. If the previous
          * transmission got lost because of head of line blocking,
          * using the unordered delivery might help in this retransmission
          */
         MgLiSctDatReq(&(peer->tsap->spPst), peer->tsap->tsapCfg.spId,
                       assoc->spAssocId, &tmpNetAddr, strm,
                       TRUE, FALSE, 0, SCT_PROTID_H248, mBuf);
      }
#endif    /* GCP_PROV_SCTP */

      /* 
       * If the Service user hasn't sent final response, indicate the 
       * retransmission to him only if he has configured us to do so, else
       * return NULLP
       */
      if (rxCb->rspStatus == MG_RESPONSE_PROV) 
      {
         if (mgCb.genCfg.indicateRetx == TRUE)
            RETVALUE(rxCb);
         else
            RETVALUE(NULLP);
      }
      else
         RETVALUE(NULLP);
   }

   /* Initialize new transaction */
   if ((rxCb = mgInitRxCb(peer, destTptAddr, transId, chkRspParam,
                          msgType, method)) == NULLP)
   {
     RETVALUE(NULLP);
   }

   if(srvrCb != NULLP)
   {
      rxCb->suConnId = srvrCb->suConnId;
   }

   *dupFlag = NOTPRSNT;

#ifdef GCP_MGCP
#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
   /* Check for transaction timeout timer..if enabled then start it */
   if(peer->ssap->ssapCfg.reCfg.txnTmoutTmr.enb == TRUE)
   {
      if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
      {
         /* This timer is not started for NCS/TGCP profiles */
         if(peer->mntInfo.variant == LMG_VER_PROF_MGCP_RFC2705_1_0)
         {
            /* start transaction timeout timer */
            idx = MG_TXNTMOUT_TMR - MG_INTXN_TMR_BASE;
            (Void) mgStartTmr (MG_TXNTMOUT_TMR, 
                           peer->ssap->ssapCfg.reCfg.txnTmoutTmr.val, 
                           (PTR) rxCb, &(rxCb->tmr[idx]));
         }
      }
   }
#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */
#endif /* GCP_MGCP */ 
   /* Start Provisional Response Timer , if enabled */
   if (peer->ssap->ssapCfg.reCfg.provRspTmr.enb == TRUE)
   {
     /* Provisional Response timer is not valid for NCS and TGCP */
     if ((peer->mntInfo.variant != LMG_VER_PROF_MGCP_TGCP_1_0) &&
         (peer->mntInfo.variant != LMG_VER_PROF_MGCP_NCS_1_0))
     {
       idx = MG_PROVRSP_TMR - MG_INTXN_TMR_BASE;
       (Void) mgStartTmr (MG_PROVRSP_TMR, 
                          peer->ssap->ssapCfg.reCfg.provRspTmr.val, 
                          (PTR) rxCb, &(rxCb->tmr[idx]));
     }
   }
#ifdef ZG
   /* mg003.105: Bug Fix for GCP PSF */
   ZG_INIT_RSETID_IN_MAPCB(&(rxCb->mapCb));
   zgAddMapping(ZG_CBTYPE_TXN_RX,(Ptr)rxCb);
#ifdef ZG_TXN_LVL_UPD
   zgRtUpd(ZG_CBTYPE_TXN_RX, (Ptr)rxCb, CMPFTHA_UPDTYPE_NORMAL,CMPFTHA_ACTN_ADD);
   zgUpdPeer();
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */
   RETVALUE(rxCb);

} /* end of mgPrcIncomingTxn() */




/******************************************************************************/
/*               Incoming  Ack Processing  Functions                          */
/******************************************************************************/

/*
*
*       Fun:    mgPrcIncomingAck
*
*       Desc:   This function process acknowledgement received for a previously
*               transmitted command
*
*       Ret:    ROK     - SUCCESS
*               RFAILED - FAILURE
*
*       Notes:  If the stack is MGC and the peer from which the ack was
*               received is in handoff state, the  ack would be received and
*               sent to the user even if the stack doesnot have a context for 
*               it. But this is only done as long as peer is in handoff state.
*               This is done because the stack may be the new MGC to which 
*               the MG is connecting and os it maynot have context for previous 
*               txns sent to the MG. But the service user may have a context 
*               for it because of synch procedures with the old MGCs service 
*               user.
*
*       File:   mg_trans.c
*
*/

#ifdef ANSI
PUBLIC S16 mgPrcIncomingAck
(
MgTxTransIdEnt     **transCb,          /* transaction cb */
U8                 *cmdType,           /* Command Type */
MgTptSrvr          *srvr,              /* Transport Server */
MgPeerCb           *peer,              /* Peer Control Block */
MgTransId          transId,            /* Transaction Identifier */
U8                 rspCode             /* Response Code */
)
#else
PUBLIC S16 mgPrcIncomingAck (transCb, cmdType, srvr,  peer, transId, rspCode)
MgTxTransIdEnt     **transCb;          /* transaction cb */
U8                 *cmdType;           /* Command Type */
MgTptSrvr          *srvr;              /* Transport Server */
MgPeerCb           *peer;              /* Peer Control Block */
MgTransId          transId;            /* Transaction Identifier */
U8                 rspCode;            /* Response Code */
#endif

{
   MgTxTransIdEnt  *txCb;              /* Transaction Control Block */
   Ticks           crntTime;           /* Current Time */
   S16             ret;                /* return value */
   Bool            found;
#ifdef GCP_MGCO
#ifdef GCP_MGC
   CmTptAddr       remoteAddr;         /* Remote Address */   
#endif /* GCP_MGC */
#endif /* GCP_MGCO */
   Bool            freemBuf;           /* free mBUf */
   /* Added new variables for sending RTO_CAP_REACHED status ind */
   Reason          reason;             /* Reason */



   TRC2(mgPrcIncomingAck)
   
   ret = ROK;
   txCb = *transCb; 
   found = FALSE;
   freemBuf = TRUE;



   /* Locate the transaction control block */
   if(txCb == NULLP)
   {
      ret = cmHashListFind(&(peer->outTransLst), (U8 *)&transId, 
                       MG_TRANSID_LEN, MG_HASH_SEQNMB_DEF, 
                       (PTR *) &txCb);
      found = TRUE;
   }
   if(ret != ROK)
   {
     /* If in a handoff process then send txn ack up even if the 
        context is not found */
#ifdef GCP_MGCO
#ifdef GCP_MGC
     if ((mgCb.genCfg.entType == LMG_ENT_GC) &&
         (peer->mgcoInfo.hndOffInProg == TRUE))
     {
       if (rspCode == MG_RESPONSE_PROV)
       {
         remoteAddr.type = CM_TPTADDR_NOTPRSNT;
         txCb = mgInitTxCb(transId, MGT_MSG_NONE, MG_NONE, FALSE,
                           &remoteAddr, peer, srvr, NULLP);

         if (txCb == NULLP)
           RETVALUE(RFAILED);
#ifdef ZG
         /* mg003.105: Bug Fix for GCP PSF */
         ZG_INIT_RSETID_IN_MAPCB(&(txCb->mapCb));
         zgAddMapping(ZG_CBTYPE_TXN_TX, (Ptr)txCb);
#ifdef ZG_TXN_LVL_UPD
         zgRtUpd(ZG_CBTYPE_TXN_TX,(Ptr)txCb,CMPFTHA_UPDTYPE_NORMAL,
            CMPFTHA_ACTN_ADD); 
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */
         
       }
       else
         RETVALUE(ROK);
     }
     else
#endif /* GCP_MGC */
#endif /* GCP_MGCO */
#ifdef ZG
      /* In case of fault tolerance..unknown Incoming responses 
         should be accepted */
      RETVALUE(ROK);
#else
      RETVALUE(RFAILED);
#endif /* ZG */
   }

   /* 
    * Ensure that response is received on the source transport address used
    * for transmission
    * This check is done only if txCb is searched inside this function. If
    * txCb is searched outside this function, this check is performed there.
    */
   if(TRUE == found)
   {
      if ((srvr) && (txCb->suConnId != srvr->suConnId))
         RETVALUE(RFAILED);
   }

   /* If transaction wasn't retransmitted; use it for RTO calculation */
    if (txCb->everRetxed == FALSE)
    {
       /* Find current time */
       if ((SGetSysTime (&(crntTime))) == ROK)
       {
          /* Take time difference in ticks */
          crntTime -= txCb->timeStamp;
          MG_UPDATE_RTO_PARMS(peer->mntInfo.aad, peer->mntInfo.adev, 
                              peer->mntInfo.rto, crntTime);
          if(MG_RESPONSE_PROV == rspCode)
          {
             txCb->everRetxed = TRUE;
          }
       }
    } /* if transaction has not been retransmitted */
    else /* update the peer RTO from the transaction cb if it has
          * been successfully acknowledged after retransmissions */
    {
       peer->mntInfo.rto = txCb->rto;
    }

    /* generate a status indication to service user if rto exceeds
     * tMax */
    if (peer->mntInfo.rto >= peer->tsap->tsapCfg.reCfg.tMax)
    {
       peer->mntInfo.rto = peer->tsap->tsapCfg.reCfg.tMax;
       peer->mntInfo.rtoCap = TRUE;
       reason = MGT_RTO_CAP_REACHED;
       mgGenUserStaInd(peer, peer->ssap, MGT_STATUS_PEER, &reason);
    }

   /* 
    * If it is a provisional response don't remove the the transaction control 
    * block 
    */
   if (rspCode == MG_RESPONSE_PROV)
   {
      U32   tmrVal;

      txCb->state = MG_OUTTXN_PROVRSP_RCVD;

      /* 
       * It is a provisional response so we shouldn't retransmit txn so
       * soon. Delay the retransmission by some factor of rto i.e.
       * switch to a longer timer
       */

      if(txCb->retxTmr.tmrEvnt != TMR_NONE)
         mgStopTmr (MG_RETX_TMR, (PTR) txCb, &(txCb->retxTmr));

      /* Restart for a longer duration, since provisional response was
         received */
      tmrVal = (peer->ssap->ssapCfg.reCfg.provRspDelay + 
                peer->mntInfo.rto)/mgCb.genCfg.timeRes;

      mgStartTmr (MG_RETX_TMR, tmrVal, (PTR) txCb, &(txCb->retxTmr));

#ifdef GCP_MGCO
      if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
      {
         /* Update Statistics */
         MG_UPD_MGCO_PEER_RX_STS(MGT_TXNPEND, peer->peerSts);
      }
#endif /* GCP_MGCO */

#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
      zgRtUpd(ZG_CBTYPE_TXN_TX,(Ptr)txCb,CMPFTHA_UPDTYPE_NORMAL,
         CMPFTHA_ACTN_MOD);
      zgUpdPeer();
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */

      RETVALUE(ROK);
   }


#ifdef GCP_MGCO
   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
   {
      /* Update Statistics */
      MG_UPD_MGCO_PEER_RX_STS(MGT_TXNREPLY, peer->peerSts);
   }
#endif /* GCP_MGCO */

#ifdef GCP_MGCP
   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
   {
      /* Update Statistics */
      MG_UPD_MGCP_PEER_RX_STS(MGT_MSG_RSP, peer->peerSts, rspCode);
      *cmdType = txCb->msgType; 
   }

#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
#ifndef GCP_USER_RETX_CNTRL
   /* Stop disconnect timer..if started */
   if(peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
   {
      if(txCb->discTmr.tmrEvnt != TMR_NONE)
      {
         mgStopTmr(MG_TXN_DISC_TMR, (PTR)txCb, &txCb->discTmr);
      }
   }
#endif /* GCP_USER_RETX_CNTRL */
#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */

#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
   if(peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
   {
      if(txCb->u.txBufInfo->expctdRspCnt > txCb->u.txBufInfo->rcvdRspCnt)
         freemBuf = FALSE;
   }
#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */

#endif /* GCP_MGCP */

   /* Since response has been received for the txn , remove the txn */ 
   mgDeAllocTxTransIdEnt(peer, txCb, freemBuf);

   RETVALUE(ROK);

} /* end of mgPrcIncomingAck() */





/******************************************************************************/
/*               Incoming  Response Ack Processing  Functions                 */
/******************************************************************************/


/*
*
*       Fun:    mgPrcRcvdResponseAck
*
*       Desc:   This function process acknowledgement received for the 
*               acknowledgements transmitted 
*
*       Ret:    ROK     - SUCCESS
*               RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_trans.c
*
*/

#ifdef ANSI
PUBLIC S16 mgPrcRcvdResponseAck
(
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
MgTransId          transId             /* Transaction Identifier */
)
#else
PUBLIC S16 mgPrcRcvdResponseAck (peer, transId)
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
MgTransId          transId;            /* Transaction Identifier */
#endif
{
   MgRxTransIdEnt  *rxCb;              /* Response Transaction Control Block */

   TRC2(mgPrcRcvdResponseAck)

   rxCb = NULLP;

   /* Search for the control block */
   if ((cmHashListFind(&(peer->inTransLst), (U8 *)&transId, MG_TRANSID_LEN,
                     MG_HASH_SEQNMB_DEF, (PTR *)&rxCb)) != ROK)
   {
      RETVALUE(RFAILED);
   }

#ifdef GCP_MGCP
   if(LMG_PROTOCOL_MGCP == peer->mntInfo.protocolType)
   {
      /* 
       * For 2705 BIS, NCS, TGCP, we should not deleted the rxCb on receipt of
       * response ack. Only mBuf should be freed. For 2705, rxCb should also
       * be freed.
       */
#ifndef GCP_2705BIS
      if (peer->mntInfo.variant == LMG_VER_PROF_MGCP_NCS_1_0 ||
          peer->mntInfo.variant == LMG_VER_PROF_MGCP_TGCP_1_0)
#endif /* GCP_2705BIS */
      {
         /*
          * NCS 1.0 - Page 86; TGCP 1.0 - Page 89 or RFC 2705Bis 
          * says response buffer can be freed, but keep a record
          * of execution of transaction; Commands received with same transaction
          * id should be discarded till atmost once timer expires
          */
         rxCb->rspStatus = MG_RESPONSE_ACKED;

         if (rxCb->mBuf != NULLP)
         {
            mgPutMsg(rxCb->mBuf);
            rxCb->mBuf = NULLP;
         }
         RETVALUE(ROK);
      }
   }
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
#ifdef GCP_VER_1_3
   if(LMG_PROTOCOL_MGCO == peer->mntInfo.protocolType)
   {
      /*
         * NCS 1.0 - Page 86; TGCP 1.0 - Page 89 or RFC 2705Bis 
         * says response buffer can be freed, but keep a record
         * of execution of transaction; Commands received with same transaction
         * id should be discarded till atmost once timer expires
         */
      rxCb->rspStatus = MG_RESPONSE_ACKED;

      if (rxCb->mBuf != NULLP)
      {
         mgPutMsg(rxCb->mBuf);
         rxCb->mBuf = NULLP;
      }
      RETVALUE(ROK);
   }
#endif /* GCP_VER_1_3 */
#endif /* GCP_MGCO */
   /* Since a response ack has been received the transaction context can
      be cleared */
   mgDeAllocRxTransIdEnt(peer, rxCb, TRUE);

   RETVALUE(ROK);

} /* end of mgPrcRcvdResponseAck() */





/******************************************************************************/
/*                   Transaction Deallocation  Functions                      */
/******************************************************************************/

/*
*
*       Fun:    mgDeAllocTxTransIdEnt
*
*       Desc:   This function frees resources attached with MgTxTransIdEnt
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_trans.c
*
*/

#ifdef ANSI
PUBLIC Void mgDeAllocTxTransIdEnt
(
MgPeerCb           *peer,              /* Peer Control Block */
MgTxTransIdEnt     *txCb,              /* Transaction Control Block */
Bool               freeMbuf            /* Free mBuf */
)
#else
PUBLIC Void mgDeAllocTxTransIdEnt(peer, txCb, freeMbuf)
MgPeerCb           *peer;              /* Peer Control Block */
MgTxTransIdEnt     *txCb;              /* Transaction Control Block */
Bool               freeMbuf;           /* Free mBuf */
#endif
{
   TRC2(mgDeAllocTxTransIdEnt)

#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
   if ((txCb != NULLP) && (zgChkTxnRsetState(txCb->mapCb.rsetId)))
   {
      /* Send Update del to standby; del mapping for txn*/
      zgRtUpd(ZG_CBTYPE_TXN_TX,(Ptr)txCb, CMPFTHA_UPDTYPE_NORMAL,
           CMPFTHA_ACTN_DEL);
   }
#endif /* ZG_TXN_LVL_UPD */
   zgDelMapping(ZG_CBTYPE_TXN_TX ,(Ptr)txCb);
#endif /* ZG */

   /* Stop Retransmission timer */
   if(txCb->retxTmr.tmrEvnt != TMR_NONE)
      mgStopTmr (MG_RETX_TMR, (PTR) txCb, &(txCb->retxTmr));

   /* If transaction is in queued state, remove it from queue*/
   if (txCb->state == MG_OUTTXN_TXN_QUEUED)
   {
     cmLListDelFrm(&(peer->transQ), &(txCb->lnkLstNode));
   }

   /* Delete it from hash list */
   cmHashListDelete (&(peer->outTransLst), (PTR) txCb);

#ifdef GCP_MGCP
   if(LMG_PROTOCOL_MGCP == peer->mntInfo.protocolType)
   {
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
      if(freeMbuf == TRUE)
      {
         if (txCb->u.txBufInfo->mBuf != NULLP)
         {
            mgPutMsg(txCb->u.txBufInfo->mBuf);
            txCb->u.txBufInfo->mBuf = NULLP;
         }
         /* Free the transmitted buffer info block  */
         if(txCb->u.txBufInfo != NULLP)
            mgDeAlloc((Data *)txCb->u.txBufInfo, sizeof(MgTxBufInfo));
      }
#else
      if (txCb->u.mBuf != NULLP && freeMbuf == TRUE)
      {
         mgPutMsg(txCb->u.mBuf);
         txCb->u.mBuf = NULLP;
      }
#endif /* GCP_VER_1_3 && GCP_2705BIS */
   }
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
   if(LMG_PROTOCOL_MGCO == peer->mntInfo.protocolType)
   {
      if (txCb->u.mBuf != NULLP && freeMbuf == TRUE)
      {
         mgPutMsg(txCb->u.mBuf);
         txCb->u.mBuf = NULLP;
      }
   }
#endif /* GCP_MGCO */

   /* Free the transaction control block memory */
   mgDeAlloc((Data *)txCb, sizeof(MgTxTransIdEnt));

   RETVOID;

} /* end of mgDeAllocTxTransIdEnt() */




/*
*
*       Fun:    mgDeAllocRxTransIdEnt
*
*       Desc:   This function frees resources attached with MgRxTransIdEnt
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_trans.c
*
*/

#ifdef ANSI
PUBLIC Void mgDeAllocRxTransIdEnt
(
MgPeerCb           *peer,              /* Peer Control Block */
MgRxTransIdEnt     *rxCb,              /* Transaction Control Block */
Bool               freeMbuf            /* Free mBuf */
)
#else
PUBLIC Void mgDeAllocRxTransIdEnt(peer, rxCb, freeMbuf)
MgPeerCb           *peer;              /* Peer Control Block */
MgRxTransIdEnt     *rxCb;              /* Transaction Control Block */
Bool               freeMbuf;           /* Free mBuf */
#endif
{
   TRC2(mgDeAllocRxTransIdEnt)

#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
   if ((rxCb != NULLP) && (zgChkTxnRsetState(rxCb->mapCb.rsetId)))
   {
      /* Send Update del to standby; del mapping for txn*/
      zgRtUpd(ZG_CBTYPE_TXN_RX,(Ptr)rxCb, CMPFTHA_UPDTYPE_NORMAL,
           CMPFTHA_ACTN_DEL);
   }
#endif /* ZG_TXN_LVL_UPD */
   zgDelMapping(ZG_CBTYPE_TXN_RX ,(Ptr)rxCb);
#endif /* ZG */

   /* Free Response Buffer */
   if (rxCb->mBuf != NULLP && freeMbuf == TRUE)
   {
      mgPutMsg(rxCb->mBuf);
      rxCb->mBuf = NULLP;        /* re-initialize to NULLP */
   }

   /* if message is queued , remove from queue */
   if (rxCb->state == MG_INTXN_RSP_QUEUED)
      cmLListDelFrm(&(peer->transQ), &(rxCb->lnkLstNode));

   /* Delete from hash list */
   cmHashListDelete(&(peer->inTransLst), (PTR) rxCb);

   MG_STOP_INTXN_TMRS(rxCb);

   /* Free the transaction control block memory */
   mgDeAlloc((Data *)rxCb, sizeof(MgRxTransIdEnt));

   RETVOID;

} /* end of mgDeAllocRxTransIdEnt() */




/******************************************************************************/
/*                       Remove All Transactions on Peer                      */
/******************************************************************************/
/*
*
*       Fun:    mgRemoveAllTxn
*
*       Desc:   This function removes all transactions and informs the service
*               user if errType passed is other than MGT_NONE
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_trans.c
*
*/

#ifdef ANSI
PUBLIC Void mgRemoveAllTxn             
(
U8                 mgtError,           /* Error to be indicated */
MgPeerCb           *peer               /* Peer Control Block */
)
#else
PUBLIC Void mgRemoveAllTxn(mgtError, peer)
U8                 mgtError;           /* Error to be indicated */
MgPeerCb           *peer;              /* Peer Control Block */
#endif
{
   MgTxTransIdEnt  *outTxCb;           /* Outgoing Transaction */
   MgRxTransIdEnt  *inTxCb;            /* Incoming Transaction */
   U16             numTxn;             /* Number of Transactions in hashlist */
   CmLList         *cmLstEnt;          /* Linked List Node */

   TRC2(mgRemoveAllTxn)
   
   /* Initialise */
   outTxCb   = NULLP;
   inTxCb    = NULLP;
   
   /* Free all the incoming transactions */
   numTxn = CM_HASH_NMBENT(&peer->inTransLst);

   while (numTxn)
   {
      if ((cmHashListGetNext(&(peer->inTransLst), NULLP,
                           (PTR *)&inTxCb)) == ROK)
      {
         mgAbortRxTrans(peer, inTxCb, MG_IGNORE);
         inTxCb = NULLP;
      }
      numTxn --;
   }
   

   /* Free all the outgoing transactions */
   numTxn = CM_HASH_NMBENT(&peer->outTransLst);

   while (numTxn)
   {
     if ((cmHashListGetNext(&(peer->outTransLst), NULLP,
                            (PTR *)&outTxCb)) == ROK)
     {
         mgAbortTxTrans(peer, outTxCb, MG_IGNORE);
         outTxCb = NULLP;
     }
     numTxn--;
   }


   /* There could be some transaction entries present in pending list */
   cmLstEnt = peer->transQ.first;

   /* TransQ can have both inTxCb and outTxCb*/
   outTxCb = NULLP;
   inTxCb  = NULLP;

   while (cmLstEnt != NULLP)
   {
      if (*((U8 *)(cmLstEnt->node)) == MG_TRANS_TYPE_TX)
      {
         outTxCb = (MgTxTransIdEnt *)cmLstEnt->node;

         /* Move to next entry in the list */
         cmLstEnt = cmLstEnt->next;

         /* Delete the transaction */
         mgAbortTxTrans(peer, outTxCb, MG_IGNORE);
         outTxCb = NULLP;
      }
      else if ((*((U8 *)(cmLstEnt->node)) == MG_TRANS_TYPE_RX))
      {
         inTxCb = (MgRxTransIdEnt *)cmLstEnt->node;

         /* Move to next entry in the list */
         cmLstEnt = cmLstEnt->next;

         /* Delete the transaction */
         mgAbortRxTrans(peer, inTxCb, MG_IGNORE);
         inTxCb = NULLP;
      }
   }

   if (mgtError != MG_IGNORE)
   {
      /* Indicate abort all transactions to service user */
      mgIndicateAbortTxnToUsr(mgtError, MG_INVALID_TRANSID, peer);
   }

   RETVOID;

} /* end of mgRemoveAllTxn () */


/******************************************************************************/
/*                  Move All Transactions from one Peer to another            */
/******************************************************************************/

/*
*
*       Fun:    mgMoveAllTxn
*
*       Desc:   This function moves all transactions from one peer to another.
*               This function shall be used in case of handoff at MG and 
*               failover at MGC
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_util.c
*
*/

#ifdef ANSI
PUBLIC Void mgMoveAllTxn             
(
MgPeerCb           *oldpeer,              /* Peer Control Block */
MgPeerCb           *newpeer,              /* Peer Control Block */
U8                 source                 /* Initiated by user/ internal */
)
#else
PUBLIC Void mgMoveAllTxn(oldpeer, newpeer, source)
MgPeerCb           *oldpeer;              /* Peer Control Block */
MgPeerCb           *newpeer;              /* Peer Control Block */
U8                 source;                /* Initiated by user/ internal */
#endif
{
   MgTxTransIdEnt  *outTxCb;           /* Outgoing Transaction */
   MgRxTransIdEnt  *inTxCb;            /* Incoming Transaction */
   U16             numTxn;             /* Number of Transactions in hashlist */

   TRC2(mgMoveAllTxn)
   
   /* Initialise */
   outTxCb   = NULLP;
   inTxCb    = NULLP;
   
   /* Move all the incoming transactions */
   numTxn = oldpeer->inTransLst.nmbEnt;

   while (numTxn)
   {
      numTxn--;

      /* corrected the 2nd arg to the following func */
      if ((cmHashListGetNext(&(oldpeer->inTransLst), NULLP,
                             (PTR *)&inTxCb)) != ROK)
        continue;
      if (inTxCb->regCmdMethod == MG_NONE)
      {
         mgMoveInTxn(oldpeer, newpeer, inTxCb, MGT_ALL_TRANS);     
      }
   } /* while numTxn */
   

   /* move all the outgoing transactions */
   numTxn = oldpeer->outTransLst.nmbEnt;
 
   while (numTxn)
   {
      numTxn--;

      if ((cmHashListGetNext(&(oldpeer->outTransLst), NULLP,
                           (PTR *)&outTxCb)) != ROK)
        continue;
      mgMoveOutTxn(oldpeer, newpeer, outTxCb, source, MGT_ALL_TRANS);
   }
   
   /* Move All Transactions in the Q to the new Peer */
   mgMoveTransFromQ(MG_INVALID_TRANSID, oldpeer, newpeer,MGT_ALL_TRANS);

   RETVOID;

} /* end of mgMoveAllTxn () */



/*
*
*       Fun:   mgMoveTransFromQ
*
*       Desc:  Move Transactions from queue on old peer to queue on new peer
*
*       Ret:   MGT_NONE              : Success
*              MGT_ERR_INVALID_TRANS : Transaction not found
*
*       Notes: This function is used for moving either a single txn, 
*              range of txn and all txns from one peer to another. The
*              number of transactions to be moved is specified by the
*              transType parameter.
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMoveTransFromQ
(
MgTransId         transId,             /* Transaction id */
MgPeerCb          *oldPeer,            /* Old peer cb */
MgPeerCb          *newPeer,            /* Peer where txns are to be moved */
U8                transType            /* Single Transaction / All trans */
)
#else
PUBLIC S16 mgMoveTransFromQ(transId, oldPeer, newPeer, transType)
MgTransId         transId;             /* Transaction id */
MgPeerCb          *oldPeer;            /* Old peer cb */
MgPeerCb          *newPeer;            /* Peer where txns are to be moved */
U8                transType;           /* Single Transaction / All trans */
#endif
{
  CmLList         *cmLstEnt;          /* Linked List Entry */
  MgTxTransIdEnt  *outTxnCb;          /* Pending Transactions */
  MgRxTransIdEnt  *inTxnCb;           /* Pending Transaction */
  Bool            found;              /* Transaction Found / Not */       

  TRC2(mgMoveTransFromQ);

  cmLstEnt = oldPeer->transQ.first;
  outTxnCb = NULLP;
  inTxnCb  = NULLP;
  found    = FALSE;

  /* Go through the queue to find txn*/
  while (cmLstEnt != NULLP)
  {
    found = FALSE;
    
    /* if entry is a outgoing txn */
    if (*((U8 *)(cmLstEnt->node)) == MG_TRANS_TYPE_TX)
    {
      outTxnCb = (MgTxTransIdEnt *)cmLstEnt->node;
      
      /* Move to next entry in the list */
      cmLstEnt = cmLstEnt->next;
      
      /* if there is a transId match(for a simngle txn) or if all transactions
         have to be moved, delete from old list and add to new one. */

      if ((outTxnCb->transId == transId) || (transType == MGT_ALL_TRANS))
      {
        cmLListDelFrm(&(oldPeer->transQ), &(outTxnCb->lnkLstNode));
        if (newPeer != NULLP)
        {
          cmLListAdd2Tail(&(newPeer->transQ), &(outTxnCb->lnkLstNode));
          outTxnCb->peer = newPeer;
        }
        outTxnCb = NULLP;

        if (transType == MGT_ALL_TRANS)
          continue;

        /* if transType is a single txn and the move operation is over , 
           return */
        found = TRUE;
        break;
      }
    }
    /* if entry is a incoming txn */
    else if (*((U8 *)(cmLstEnt->node)) == MG_TRANS_TYPE_RX)
    {
      inTxnCb = (MgRxTransIdEnt *)cmLstEnt->node;
      
      /* Move to next entry in the list */
      cmLstEnt = cmLstEnt->next;
      
      if ((outTxnCb->transId == transId) || (transType == MGT_ALL_TRANS))
      {
        
        cmLListDelFrm(&(oldPeer->transQ), &(inTxnCb->lnkLstNode));

        if (newPeer != NULLP)
        {
          cmLListAdd2Tail(&(newPeer->transQ), &(inTxnCb->lnkLstNode));
          inTxnCb->peer = newPeer;
        }
        inTxnCb = NULLP;

        if (transType == MGT_ALL_TRANS)
          continue;
        found = TRUE;
        break;
      }
    } /* If it is an incoming txn */
  } /* while */

  if ((found != TRUE) && (transType != MGT_ALL_TRANS))
    RETVALUE(MGT_ERR_INVALID_TRANS);

  RETVALUE(MGT_NONE);
} /* End of mgMoveTransFromQ */




/******************************************************************************/
/*                         Transaction Abort  Functions                       */
/******************************************************************************/

/*
*
*       Fun:    mgAbortTxTrans
*
*       Desc:   This function aborts the command to be transmitted and informs
*               Service User that transaction was discarded. Resources attached
*               are freed too
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_trans.c
*
*/

#ifdef ANSI
PUBLIC Void mgAbortTxTrans
(
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
MgTxTransIdEnt     *txCb,              /* Transaction Control Block */
U8                 mgtError            /* Inform Service User ? */
)
#else
PUBLIC Void mgAbortTxTrans (peer, txCb, mgtError)
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
MgTxTransIdEnt     *txCb;              /* Transaction Control Block */
U8                 mgtError;           /* Inform Service User ? */
#endif
{
   MgTransId       transId;            /* Transaction Id */
   Bool            freeBuf;

   TRC2(mgAbortTxTrans)

   if(MG_INVALID_TRANSID != txCb->transId)
      transId = txCb->transId;
   else
      transId = MG_IGNORE_TRANSID;

   freeBuf = TRUE;

#ifdef GCP_MGCP
#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
   if(peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
   {
      /* If expected response count more than rcvd response count..then we can't
       * free txBufInfo inside txCb..
       * txBufInfo will be freed when last txCb is freed */
      if(txCb->u.txBufInfo)
      {
         txCb->u.txBufInfo->rcvdRspCnt++;
         if(txCb->u.txBufInfo->expctdRspCnt > txCb->u.txBufInfo->rcvdRspCnt)
         {
            freeBuf = FALSE;
         }
      }
   }
#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */
#endif /* GCP_MGCP */
   mgDeAllocTxTransIdEnt(peer, txCb, freeBuf);

#ifdef ZG
   zgUpdPeer();
#endif /* ZG */

   if (mgtError == MG_IGNORE)
      RETVOID;

   mgIndicateAbortTxnToUsr(mgtError, transId, peer);

   RETVOID;

} /* end of mgAbortTxTrans() */



/*
*
*       Fun:    mgAbortRxTrans
*
*       Desc:   This function aborts the response to be transmitted or the
*               incoming transaction received
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_trans.c
*
*/

#ifdef ANSI
PUBLIC Void mgAbortRxTrans
(
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
MgRxTransIdEnt     *rxCb,              /* Transaction Control Block */
U8                 mgtError            /* Error to report */
)
#else
PUBLIC Void mgAbortRxTrans (peer, rxCb, mgtError)
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
MgRxTransIdEnt     *rxCb;              /* Transaction Control Block */
U8                 mgtError;           /* Error to report */
#endif
{
   MgTransId       transId;            /* Transaction Id */

   TRC2(mgAbortRxTrans)

   transId = rxCb->transId;

   /* remove txn */
   mgDeAllocRxTransIdEnt(peer, rxCb, TRUE);

   if (mgtError == MG_IGNORE)
      RETVOID;

   /* Indicate removal to user */
   mgIndicateAbortTxnToUsr(mgtError, transId, peer);

   RETVOID;

} /* end of mgAbortRxTrans() */




/*
*
*       Fun:    mgIndicateAbortTxnToUsr
*
*       Desc:   This function fills transaction structure to inform user about
*               transaction being aborted
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_trans.c
*
*/

#ifdef ANSI
PUBLIC Void mgIndicateAbortTxnToUsr
(
U8                 mgtError,           /* Error to be indicated */
MgTransId          transId,            /* Transaction Identifier */
MgPeerCb           *peer               /* Peer Control Block */
)
#else
PUBLIC Void mgIndicateAbortTxnToUsr(mgtError, transId, peer)
U8                 mgtError;           /* Error to be indicated */
MgTransId          transId;            /* Transaction Identifier */
MgPeerCb           *peer;              /* Peer Control Block */
#endif
{
/* mg003.105: Moved code for send command in case of CH to mg_util.c */ 
   TRC2(mgIndicateAbortTxnToUsr);

#ifdef GCP_MGCO
   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
   {
/* mg003.105: Moved code for send command in case of CH to mg_util.c */ 
     mgIssueMgcoTxnErr(peer->ssap, mgtError, peer, transId);
   }
#endif /* GCP_MGCO */

#ifdef GCP_MGCP 
   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
   {
     mgIssueMgcpTxnErr(peer->ssap, mgtError, peer, transId);
   }
#endif /* GCP_MGCP */
   RETVOID;

} /* end of mgIndicateAbortTxnToUsr () */




#ifdef GCP_MGCP

/******************************************************************************/
/*              Detection of Loss of Association Algorithm                    */
/******************************************************************************/

/*
*
*       Fun:    mgMgcpExecRetxAlgo
*
*       Desc:   This function implements the Detection of Loss Of Association
*               algorithm as specified in MGCP Standards
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_trans.c
*
*/

#ifdef ANSI
PUBLIC Void mgMgcpExecRetxAlgo 
(
MgTSAPCb           *tsap,              /* TSAP Control Block */
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
MgTxTransIdEnt     *txCb,              /* Transaction Control Block */
Bool               *retx               /* Retransmit or not ? */
)
#else
PUBLIC Void mgMgcpExecRetxAlgo (tsap, peer, txCb, retx)
MgTSAPCb           *tsap;              /* TSAP Control Block */
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
MgTxTransIdEnt     *txCb;              /* Transaction Control Block */
Bool               *retx;              /* Retransmit or not ? */
#endif 
{
   MgNetAddrTbl    *addrTbl;           /* Peer Addresses */
   MgNetAddrTbl    *taddrTbl;          /* TxCb Addresses */

   TRC2(mgMgcpExecRetxAlgo)

   /* Initialise for no retransmission */
   *retx    = FALSE;
   addrTbl  = &(peer->accessInfo.peerAddrTbl);
   taddrTbl = &(txCb->addrTbl);

   if (txCb->retxCnt < peer->mgcpInfo.suspThold)
   {
      /* Retransmit the packet */
      *retx = TRUE;
      txCb->retxCnt++;
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
      txCb->u.txBufInfo->retxCnt++;
#endif /* GCP_VER_1_3 && GCP_2705BIS */
   }
   else
   if (((taddrTbl->count == 1) && 
         (txCb->retxCnt == peer->mgcpInfo.suspThold)) ||
         ((taddrTbl->count == addrTbl->count) &&
         (txCb->retxCnt == peer->mgcpInfo.disconThold)))
   {
      /*
       * Above If condition indicates the criterion in algorithm to send
       * out a DNS request. The criterion is:
       *
       * If ((firstAddressInUse and suspicion threshold is reached) ||
       *     (lastAddressInUse  and disconnect threshold is reached))
       */


      /*
       * Also Coming Here Implies we need to go to DNS; However, we will go to
       * DNS only if we are not required to keep transmission of this
       * transaction to a particular IP Address
       */

      if (txCb->retxOnIpAddr == TRUE)
      {
         *retx = TRUE;
         txCb->retxCnt++;
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
         txCb->u.txBufInfo->retxCnt++;
#endif /* GCP_VER_1_3 && GCP_2705BIS */
      }
      else
      if (tsap->dnsInfo.dnsState == MG_DNS_STATE_UP &&  
            tsap->tsapCfg.reCfg.dnsCfg.dnsAccess != LMG_DNS_DISABLED)
      {
         /* 
          *  Resolve with DNS only if domain name is known or if DNS exists
          *  a ttl of 0 implies DNS doesn't exist
          */
         if (peer->accessInfo.namePres != TRUE || peer->mgcpInfo.ttl == 0)
         {
            *retx = TRUE;
            txCb->retxCnt++;
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
            txCb->u.txBufInfo->retxCnt++;
#endif /* GCP_VER_1_3 && GCP_2705BIS */
         }
         else
         {
            /* Queue the transaction in transQ */
            txCb->lnkLstNode.node = (PTR) txCb;

            cmLListAdd2Tail (&(peer->transQ), &(txCb->lnkLstNode));

            /* Update Transaction State to DNS Response Awaited */
            txCb->state = MG_OUTTXN_TXN_QUEUED;       

            /* Request DNS for resolution */
#ifdef ZG_DFTHA
            /* 
             * If Critical Rset is there on the same copy then resolve peer
             * else send reverse update to master 
             */
            if(((zgChkCRsetStatus()) == TRUE))
            {
#endif /* ZG_DFTHA */
               mgSendDnsRslvPeer(peer);
#ifdef ZG_DFTHA
            }
            else
            {
               /* send reverse update */
               ZgRvUpdInfo  info;
               info.action = ZG_RVUPD_RSLV_PEER;
               info.u.rslvPeer = peer->accessInfo.peerId;
               zgReverseUpd(&info, peer->accessInfo.peerId, MG_QUEUE_NONE,
                            peer->tsap->tsapCfg.tSAPId);
            }
#endif /* ZG_DFTHA */

            RETVOID;
         }
      }
      else
      {
         /* 
          * If DNS is not up or DNS is disabled then proceed with 
          * retransmissions..
          */
         *retx = TRUE;
         txCb->retxCnt++;
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
         txCb->u.txBufInfo->retxCnt++;
#endif /* GCP_VER_1_3 && GCP_2705BIS */ 
      }
   }
   else
   {
      /*
       * For Intermediate addresses (> first, < last) go upto suspicion threshold;
       * For last address go upto disconnect threshold
       */
      if (((taddrTbl->count < addrTbl->count) &&    /* Intermediate */
            (txCb->retxCnt <= peer->mgcpInfo.suspThold)) ||
            ((taddrTbl->count == addrTbl->count) && /* Last Address */
            (txCb->retxCnt < peer->mgcpInfo.disconThold)))
      {
         /* Mark for immediate retransmission if we are here */
         *retx = TRUE;
         txCb->retxCnt++;
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
         txCb->u.txBufInfo->retxCnt++;
#endif /* GCP_VER_1_3 && GCP_2705BIS */
      }
      else
      {
         /* 
         * Coming Here Implies that for an IP address (not first and 
         * not last), we have reached suspicion threshold for INTERMEDIATE
         * address; Switch to a new IP Address
         */
         if ((mgGetIpAddrForTx (txCb, peer)) == ROK)
         {
            /* Reset the retransmission count */
            txCb->retxCnt = 0;

#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
            txCb->u.txBufInfo->retxCnt = 0;
#endif /* GCP_VER_1_3 && GCP_2705BIS */

            /* Set Retransmission flag to TRUE */
            *retx = TRUE;
         }
      }
   }

   RETVOID;

} /* end of mgMgcpExecRetxAlgo() */

#endif /* GCP_MGCP */


#endif /* ifdef MG */

/********************************************************************30**
 
        End of file:     mp_trans.c@@/main/mgcp_rel_1.5_mnt/3 - Tue May 31 11:49:17 2005
*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      bbk  1. Initial release.
1.1+         mg002.101bbk  1. Added code for supporting max UDP pdu size
             mg003.101bbk  1. Copy the source transport address for the 
                              retransmission received for later use
             mg003.101bbk  1. Added support for handling provisional responses
                              sent out by our service user or received from
                              the network
                           2. In mgRcvDnsRslvCfm(), ssap state was not being
                              checked against correct define
                           3. Removed warnings with solaris C++ compiler
             mg005.101bbk  1. In mgDeletePeer() value of updateUsr wasn't being
                              update correctly
                           2. In mgBringPeerToCfgStatus, transQ can have both
                              MgTxTransIdEnt and MgRxTransIdEnt; Fixed that
                           3. In mgUpdatePeerIpAddr() made changes to ensure
                              that number of addresses don't exceed finalLst
                              address table array size
            mg007.101  bbk 1. Added changes to LMG Interface to perform
                              layer management operations on a peer entity
                              by using IP Address only also. Changes have
                              been added under GCP_ENHNC_1_2 compile time
                              flag. Added port configuration for a peer
                           2. Changed data type for peerId from U16 to U32
            mg008.101  bbk 1. Changed mgUpdatePeerIpAddr() function to optimise
                              it and also fixed problems in updating tables
                           2. Added remotePort variable to MgTxTransIdEnt
                              structure to ensure that retransmission happens
                              to same remote port. This ensures that 
                              message always goes to the notified entity 
                              port specified previously by Service User
            mg009.101  bbk 1. Added support for discovery of a new call agent
                              in response to RSIP. The function name 
                              mgPrcIncomingAck() was enhanced.
                           2. For Incoming DLCX, added support for checking 
                              outgoing response for Connection Parameters only
                              if DLCX was from MGC with ConnId present
/main/2      ----        pk 1. Modularized existing Functions.
                           2. Added support for MEGACO.
                           3. Added support for moving transactions/
                              removing transactions from a peer.
                           4. Moved peer control functions to mp_peer.c
                              and mp_util.c
             mg003.102   vj 1. Added updation of retransmission timer parameters 
                               on receipt of a provisional response as the first 
                               response.
             mg008.102   vj 1. In mgAbortTxTrans, add a if condition to make 
                               sure that no stack generated transId are 
                               indicated to SU in MGT error indications.
             mg009.102   vj 1. In mgPrcRcvdResponseAck transmit statistics 
                               should not be updated .  Deleted the code which 
                               was updating transmit stats in these functions.
/main/3      ---      ra   1. GCP 1.3 release
            mg004.103 rg   1. Added variables to txCb for exponential backoff
                              for retransmitted transactions. The AAD for peer
                              should not be modified for retransmitted
                              transactions, so for exponential backoff, the
                              retransmission timer value is calculated by
                              doubling the AAD stored in txCb.
                           2. Update the peer RTO on receipt of an ack for a
                              retransmitted command.
            mg015.103 ra   1. Corrected the 2nd argument cmHashListGetNext().
            mg017.103 ra   1. Re-intialize rxCb->mBuf to NULLP
/main/4      ---      ka   1. Changes for Release v 1.4            
            mg005.104 ra   1. FTHA related changes.
/main/5      ---      pk   1. GCP 1.5 release
           mg002.105 ra   1. Made rspAckEnb a reconfigurable parameter.
                          2. Removed compilation warning
                          3. Removed patch reference for 1.3 and 1.4
           mg003.105 ps   1. Changes to send command in case of CH to inform user
                             about transaction being aborted
                     dp   2. Changes to send immAck only if rspAckEnb is configured as
                     dp   3. Moved code for send command in case of CH to mg_util.c                            LMG_GET_RSPACK_MGCO in general configuration
                          4. Bug Fix for GCP PSF 
           mg008.105 gk   1. Corrected the comments
*********************************************************************91*/
