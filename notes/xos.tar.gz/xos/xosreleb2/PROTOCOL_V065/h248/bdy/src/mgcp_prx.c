/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Mgcp packages RegExp file

     Type:     C source file

     Desc:     Regular expressions for Mgcp packages

     File:     mgcp_prx.c

     Sid:      mgcp_prx.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:52:55 2005

     Prg:      ra

*********************************************************************21*/


   

/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */


#ifdef GCP_MGCP 

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tkns.h"       /* common token structures */
#include "cm_abnf.h"       /* ABNF header file */
#include "cm_inet.h"       /* Inet header file */
#include "cm_tpt.h"        /* Transport  header file */
#include "cm_dns.h"
#ifdef ZG
#include "cm_psfft.h"      /* common PSF defines */
#include "cm_ftha.h"       /* common DFT/HA defines */
#endif /* ZG */
#include "mgt.h"
#include "cm_sdp.h"
#include "cm_mblk.h"       /* common event memory management */
#include "mgcp_pdb.h"

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* common event memory management */
#include "cm_abnf.x"       /* ABNF header file */
#include "cm_inet.x"       /* Inet header file */
#include "cm_tpt.x"        /* Transport  header file */
#include "cm_sdp.x"
#ifdef ZG
#include "cm_ftha.x"       /* common DFT/HA types */
#include "cm_psfft.x"      /* common PSF types */
#endif /* ZG */
#include "mgt.x"
#include "cm_abndb.x"
#include "cm_sdpdb.x"
#include "mg_db.x"
#include "mgcp_pdb.x"
   

/*
*  THE FOLLOWING PACKAGES ARE SUPPORTED GCP RELEASE 1.3 ONWARDS ONLY
*/
#ifdef GCP_VER_1_3

   

#ifdef  GCP_PKG_MGCP_ANNC_SERVER

/*
    Func:  ARqEvSymType  ->     */
/*!re2c

               known = [oO][cC] | [oO][fF];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgARqEvSymType
*
*       Desc:  Description for the regular expression PkgARqEvSymType
*              
*                             known = [oO][cC] | [oO][fF];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgARqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgARqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgARqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy10;
   case '*':   goto yy9;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'A':   case 'a':   goto yy4;
   case 'O':   case 'o':   goto yy3;
   case '[':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy21;
   default:   goto yy8;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yy8;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy8;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy8;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yy8;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgARqEvSymType */

/*
    Func:  ARqEvSymVal  ->     */
/*!re2c
[oO][cC]          { return (MGT_MGCP_PKG_A_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_A_RQ_EV_SYM_OPER_FAIL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgARqEvSymVal
*
*       Desc:  Description for the regular expression PkgARqEvSymVal
*              [oO][cC]          { return (MGT_MGCP_PKG_A_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_A_RQ_EV_SYM_OPER_FAIL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgARqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgARqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgARqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy6;
   case 'F':   case 'f':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_A_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_A_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgARqEvSymVal */

/*
    Func:  ASgRqSymType  ->     */
/*!re2c

               known = [aA][nN][nN];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgASgRqSymType
*
*       Desc:  Description for the regular expression PkgASgRqSymType
*              
*                             known = [aA][nN][nN];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgASgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgASgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgASgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy9;
   case '*':   goto yy8;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy6;
   case 'A':   case 'a':   goto yy3;
   case '[':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy16;
   case 'N':   case 'n':   goto yy17;
   default:   goto yy7;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy6:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy7:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy6;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy12;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy21;
   default:   goto yy7;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy18;
   default:   goto yy7;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy7;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yy7;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgASgRqSymType */

/*
    Func:  ASgRqSymVal  ->     */
/*!re2c
[aA][nN][nN]          { return (MGT_MGCP_PKG_A_SG_RQ_SYM_PLAY_AN_ANNC); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgASgRqSymVal
*
*       Desc:  Description for the regular expression PkgASgRqSymVal
*              [aA][nN][nN]          { return (MGT_MGCP_PKG_A_SG_RQ_SYM_PLAY_AN_ANNC); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgASgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgASgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgASgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_A_SG_RQ_SYM_PLAY_AN_ANNC;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgASgRqSymVal */

#endif  /* GCP_PKG_MGCP_ANNC_SERVER */



#ifdef  GCP_PKG_MGCP_ATM

/*
    Func:  AtmRqEvSymType  ->     */
/*!re2c

               known = [sS][cC] | [sS][fF] | [uU][cC] | [pP][tT][iI][mM][eE] | [pP][fF][tT][rR][aA][nN][sS] | [cC][lL][eE] | [pP][lL] | [oO][fF];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgAtmRqEvSymType
*
*       Desc:  Description for the regular expression PkgAtmRqEvSymType
*              
*                             known = [sS][cC] | [sS][fF] | [uU][cC] | [pP][tT][iI][mM][eE] | [pP][fF][tT][rR][aA][nN][sS] | [cC][lL][eE] | [pP][lL] | [oO][fF];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgAtmRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgAtmRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgAtmRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy14;
   case '*':   goto yy13;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'Q':
   case 'R':   case 'T':   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'q':
   case 'r':   case 't':   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   case 'A':   case 'a':   goto yy8;
   case 'C':   case 'c':   goto yy6;
   case 'O':   case 'o':   goto yy7;
   case 'P':   case 'p':   goto yy5;
   case 'S':   case 's':   goto yy3;
   case 'U':   case 'u':   goto yy4;
   case '[':   goto yy9;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy25;
   default:   goto yy12;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy25;
   default:   goto yy12;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy29;
   case 'L':   case 'l':   goto yy25;
   case 'T':   case 't':   goto yy30;
   default:   goto yy12;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy28;
   default:   goto yy12;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy25;
   default:   goto yy12;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy21;
   default:   goto yy12;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy11:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy12:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy17;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy22;
   default:   goto yy12;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yy12;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy26;
   default:   goto yy12;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy25;
   default:   goto yy12;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy33;
   default:   goto yy12;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy31;
   default:   goto yy12;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy32;
   default:   goto yy12;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy25;
   default:   goto yy12;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy34;
   default:   goto yy12;
   }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy35;
   default:   goto yy12;
   }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy36;
   default:   goto yy12;
   }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy25;
   default:   goto yy12;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgAtmRqEvSymType */

/*
    Func:  AtmRqEvSymVal  ->     */
/*!re2c
[sS][cC]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_BRR_PATH_SETUP1); }
[sS][fF]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_BRR_PATH_SETUP2); }
[uU][cC]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_USED_CODEC_CHNGD); }
[pP][tT][iI][mM][eE]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_PCKTZN_PERIOD); }
[pP][fF][tT][rR][aA][nN][sS]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_PROF_ELMNT); }
[cC][lL][eE]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_CELL_LOSS); }
[pP][lL]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_PCKT_LOSS_THRES); }
[oO][fF]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_OPER_FAIL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgAtmRqEvSymVal
*
*       Desc:  Description for the regular expression PkgAtmRqEvSymVal
*              [sS][cC]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_BRR_PATH_SETUP1); }
*              [sS][fF]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_BRR_PATH_SETUP2); }
*              [uU][cC]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_USED_CODEC_CHNGD); }
*              [pP][tT][iI][mM][eE]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_PCKTZN_PERIOD); }
*              [pP][fF][tT][rR][aA][nN][sS]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_PROF_ELMNT); }
*              [cC][lL][eE]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_CELL_LOSS); }
*              [pP][lL]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_PCKT_LOSS_THRES); }
*              [oO][fF]          { return (MGT_MGCP_PKG_ATM_RQ_EV_SYM_OPER_FAIL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgAtmRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgAtmRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgAtmRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy6;
   case 'O':   case 'o':   goto yy7;
   case 'P':   case 'p':   goto yy5;
   case 'S':   case 's':   goto yy3;
   case 'U':   case 'u':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy31;
   case 'F':   case 'f':   goto yy29;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy27;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy15;
   case 'L':   case 'l':   goto yy13;
   case 'T':   case 't':   goto yy16;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy10;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_ATM_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_ATM_RQ_EV_SYM_CELL_LOSS;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_ATM_RQ_EV_SYM_PCKT_LOSS_THRES;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy21;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy18;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy19;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_ATM_RQ_EV_SYM_PCKTZN_PERIOD;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy22;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy24;
   default:   goto yyErr;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy25;
   default:   goto yyErr;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_ATM_RQ_EV_SYM_PROF_ELMNT;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_ATM_RQ_EV_SYM_USED_CODEC_CHNGD;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_ATM_RQ_EV_SYM_BRR_PATH_SETUP2;
      goto yyReturn;
    }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_ATM_RQ_EV_SYM_BRR_PATH_SETUP1;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgAtmRqEvSymVal */

/*
    Func:  AtmSgRqSymType  ->     */
/*!re2c

               known = [eE][cC] | [eE][tT][dD] | [eE][tT][mM] | [eE][tT][rR][1] | [eE][tT][rR][2];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgAtmSgRqSymType
*
*       Desc:  Description for the regular expression PkgAtmSgRqSymType
*              
*                             known = [eE][cC] | [eE][tT][dD] | [eE][tT][mM] | [eE][tT][rR][1] | [eE][tT][rR][2];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgAtmSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgAtmSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgAtmSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy10;
   case '*':   goto yy9;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'A':   case 'a':   goto yy4;
   case 'E':   case 'e':   goto yy3;
   case '[':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy21;
   case 'T':   case 't':   goto yy22;
   default:   goto yy8;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yy8;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy8;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy8;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy24;
   default:   goto yy8;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'M':   case 'd':   case 'm':   goto yy21;
   case 'R':   case 'r':   goto yy23;
   default:   goto yy8;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':
   case '2':   goto yy21;
   default:   goto yy8;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgAtmSgRqSymType */

/*
    Func:  AtmSgRqSymVal  ->     */
/*!re2c
[eE][cC]          { return (MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_C_A_S); }
[eE][tT][dD]          { return (MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_D_T_M_F_TONE); }
[eE][tT][mM]          { return (MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_M_F_TONE); }
[eE][tT][rR][1]          { return (MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_M_F_R1_TONE); }
[eE][tT][rR][2]          { return (MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_M_F_R2_TONE); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgAtmSgRqSymVal
*
*       Desc:  Description for the regular expression PkgAtmSgRqSymVal
*              [eE][cC]          { return (MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_C_A_S); }
*              [eE][tT][dD]          { return (MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_D_T_M_F_TONE); }
*              [eE][tT][mM]          { return (MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_M_F_TONE); }
*              [eE][tT][rR][1]          { return (MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_M_F_R1_TONE); }
*              [eE][tT][rR][2]          { return (MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_M_F_R2_TONE); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgAtmSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgAtmSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgAtmSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy5;
   case 'T':   case 't':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy7;
   case 'M':   case 'm':   goto yy9;
   case 'R':   case 'r':   goto yy11;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_C_A_S;
      goto yyReturn;
    }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_D_T_M_F_TONE;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_M_F_TONE;
      goto yyReturn;
    }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy14;
   case '2':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_M_F_R2_TONE;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_M_F_R1_TONE;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgAtmSgRqSymVal */


/*
    Func:  ConnOptAtmExtnName  ->     */
/*!re2c

[]/[0-9A-Za-z+\-_&!'|=#?.$*@[\]\^`{}~/]+          { return (MGT_MGCP_CONN_OPT_PKG_EXTN_NAME_UNKNOWN_EXTN); }
[cC][tT]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_CONN_TYPE); }
[vV][cC]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_VC_BRR_TYPE); }
[sS][eE]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ENABLE_PATH_SET_UP); }
[cC][iI]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_CONN_ELMNT_ID); }
[aA][aA][lL][Aa][pP][pP]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_APPLI); }
[sS][bB][cC]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_SUB_CHNL_CNT); }
[pP][fF]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_PART_FILL); }
[cC][rR][tT]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_CLK_REC_TYPE); }
[fF][eE]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FEC_ENABLE); }
[pP][fF][lL]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_PROF_LST_TYPE); }
[sS][mM][pP][lL][Cc][Pp][Ss]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_SIMPL_CPS); }
[tT][mM][cC][uU]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_COMB_USE_TMR); }
[aA][aA][lL][sS][aA][pP]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_SRVC_ACCESS_PT); }
[cC][kK][tT][mM][dD]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_CKT_MODE); }
[fF][rR][mM][dD]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FRAME_MOD_ENABLE); }
[gG][eE][nN][pP][cC][mM]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_GENER_PCM_SETNG); }
[tT][eE][dD]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_TX_ERR_DETECT); }
[rR][aA][sS][tT][iI][mM][eE][rR]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_SSAR_REASSEM_TMR); }
[vV][sS][eE][lL]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_VOICE_CODEC_SELEC); }
[dD][sS][eE][lL]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_DATA_CODEC_SELEC); }
[fF][sS][eE][lL]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FAX_CODEC_SELEC); }
[cC][cC][nN][fF]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_CODEC_CFG); }
[uU][sS][iI]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ISUP_USR_INFO); }
[aA][tT][cC]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATM_TRANSF_CAPAB); }
[sS][bB][tT]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATC_SUB_TYPE); }
[qQ][oO][sS]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_QOS_CLS); }
[bB][cC][oO][bB]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_BROAD_BND_CONN_ORI_BRR_CLS); }
[eE][eE][tT][iI][mM]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ET_E_TMG_RQD); }
[sS][tT][cC]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_SUSCEP_TO_CLIP); }
[uU][pP][cC][cC]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_USR_PLN_CONN_CFG); }
[aA][qQ][fF]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATM_QOS_PARMS_FORWRD); }
[aA][qQ][bB]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATM_QOS_PARMS_BCKWRD); }
[aA][dD][fF][0][+][1]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_FORWRD_CLP_IND); }
[aA][dD][fF][0]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_FORWRD_CLP_ZERO); }
[aA][dD][bB][0][+][1]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_BCKWRD_CLP_IND); }
[aA][dD][bB]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_BCKWRD_CLP_ZERO); }
[aA][bB][rR][fF]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ABR_PARMS_FORWRD); }
[aA][bB][rR][bB]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ABR_PARMS_BCKWRD); }
[aA][bB][rR][Ss][eE][tT][uU][pP]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ABR_CONN_SETUP_PARMS); }
[sS][tT][rR]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_STRUCT_SIZE); }
[cC][bB][rR][Rr][aA][tT][eE]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_CBR_RATE); }
[fF][cC][pP][cC][sS]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FOR_MAX_CPCS_SDU_SIZE); }
[bB][cC][pP][cC][sS]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_BCK_MAX_CPCS_SDU_SIZE); }
[fF][Ss][Dd][Uu][rR][aA][tT][eE]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FOR_MAX_AAL2_CPS_SDU_SIZE); }
[bB][Ss][Dd][Uu][rR][aA][tT][eE]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_BCK_MAX_AAL2_CPS_SDU_SIZE); }
[fF][fF][rR][mM]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FOR_MAX_FRAME_BLK_SIZE); }
[bB][fF][rR][mM]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_BCK_MAX_FRAME_BLK_SIZE); }
[fF][sS][sS][sS][aA][rR]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FOR_MAX_SSSAR_SDU_SIZE); }
[bB][sS][sS][sS][aA][rR]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_BCK_MAX_SSSAR_SDU_SIZE); }
[fF][sS][sS][cC][oO][pP][sS][dD][uU]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FOR_MAX_SSCOP_SDU_SIZE); }
[bB][sS][sS][cC][oO][pP][sS][dD][uU]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_BCK_MAX_SSCOP_SDU_SIZE); }
[fF][sS][sS][cC][oO][pP][uU][uU]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FOR_MAX_SSCOP_UU_SIZE); }
[bB][sS][sS][cC][oO][pP][uU][uU]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_BCK_MAX_SSCOP_UU_SIZE); }
*/

 /*
 *
 *       Fun:   mgMsgRegExpConnOptPkgAtmExtnName
 *
 *       Desc:  Description for the regular expression ConnOptPkgAtmExtnName
 *              
 *              
 *                            
 *                            
 *                            
 *                            []/[0-9A-Za-z+\-_&!'|=#?.$*@[\]\^`{}~/]+          { return (MGT_MGCP_CONN_OPT_PKG_EXTN_NAME_UNKNOWN_EXTN); }
 *                            [cC][tT]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_CONN_TYPE); }
 *                            [vV][cC]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_VC_BRR_TYPE); }
 *                            [sS][eE]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ENABLE_PATH_SET_UP); }
 *                            [cC][iI]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_CONN_ELMNT_ID); }
 *                            [aA][aA][lL][Aa][pP][pP]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_APPLI); }
 *                            [sS][bB][cC]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_SUB_CHNL_CNT); }
 *                            [pP][fF]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_PART_FILL); }
 *                            [cC][rR][tT]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_CLK_REC_TYPE); }
 *                            [fF][eE]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FEC_ENABLE); }
 *                            [pP][fF][lL]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_PROF_LST_TYPE); }
 *                            [sS][mM][pP][lL][Cc][Pp][Ss]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_SIMPL_CPS); }
 *                            [tT][mM][cC][uU]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_COMB_USE_TMR); }
 *                            [aA][aA][lL][sS][aA][pP]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_SRVC_ACCESS_PT); }
 *                            [cC][kK][tT][mM][dD]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_CKT_MODE); }
 *                            [fF][rR][mM][dD]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FRAME_MOD_ENABLE); }
 *                            [gG][eE][nN][pP][cC][mM]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_GENER_PCM_SETNG); }
 *                            [tT][eE][dD]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_TX_ERR_DETECT); }
 *                            [rR][aA][sS][tT][iI][mM][eE][rR]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_SSAR_REASSEM_TMR); }
 *                            [vV][sS][eE][lL]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_VOICE_CODEC_SELEC); }
 *                            [dD][sS][eE][lL]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_DATA_CODEC_SELEC); }
 *                            [fF][sS][eE][lL]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FAX_CODEC_SELEC); }
 *                            [cC][cC][nN][fF]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_CODEC_CFG); }
 *                            [uU][sS][iI]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ISUP_USR_INFO); }
 *                            [aA][tT][cC]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATM_TRANSF_CAPAB); }
 *                            [sS][bB][tT]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATC_SUB_TYPE); }
 *                            [qQ][oO][sS]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_QOS_CLS); }
 *                            [bB][cC][oO][bB]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_BROAD_BND_CONN_ORI_BRR_CLS); }
 *                            [eE][eE][tT][iI][mM]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ET_E_TMG_RQD); }
 *                            [sS][tT][cC]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_SUSCEP_TO_CLIP); }
 *                            [uU][pP][cC][cC]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_USR_PLN_CONN_CFG); }
 *                            [aA][qQ][fF]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATM_QOS_PARMS_FORWRD); }
 *                            [aA][qQ][bB]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATM_QOS_PARMS_BCKWRD); }
 *                            [aA][dD][fF][0][+][1]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_FORWRD_CLP_IND); }
 *                            [aA][dD][fF][0]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_FORWRD_CLP_ZERO); }
 *                            [aA][dD][bB][0][+][1]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_BCKWRD_CLP_IND); }
 *                            [aA][dD][bB]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_BCKWRD_CLP_ZERO); }
 *                            [aA][bB][rR][fF]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ABR_PARMS_FORWRD); }
 *                            [aA][bB][rR][bB]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ABR_PARMS_BCKWRD); }
 *                            [aA][bB][rR][Ss][eE][tT][uU][pP]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_ABR_CONN_SETUP_PARMS); }
 *                            [sS][tT][rR]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_STRUCT_SIZE); }
 *                            [cC][bB][rR][Rr][aA][tT][eE]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_CBR_RATE); }
 *                            [fF][cC][pP][cC][sS]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FOR_MAX_CPCS_SDU_SIZE); }
 *                            [bB][cC][pP][cC][sS]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_BCK_MAX_CPCS_SDU_SIZE); }
 *                            [fF][Ss][Dd][Uu][rR][aA][tT][eE]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FOR_MAX_AAL2_CPS_SDU_SIZE); }
 *                            [bB][Ss][Dd][Uu][rR][aA][tT][eE]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_BCK_MAX_AAL2_CPS_SDU_SIZE); }
 *                            [fF][fF][rR][mM]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FOR_MAX_FRAME_BLK_SIZE); }
 *                            [bB][fF][rR][mM]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_BCK_MAX_FRAME_BLK_SIZE); }
 *                            [fF][sS][sS][sS][aA][rR]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FOR_MAX_SSSAR_SDU_SIZE); }
 *                            [bB][sS][sS][sS][aA][rR]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_BCK_MAX_SSSAR_SDU_SIZE); }
 *                            [fF][sS][sS][cC][oO][pP][sS][dD][uU]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FOR_MAX_SSCOP_SDU_SIZE); }
 *                            [bB][sS][sS][cC][oO][pP][sS][dD][uU]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_BCK_MAX_SSCOP_SDU_SIZE); }
 *                            [fF][sS][sS][cC][oO][pP][uU][uU]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_FOR_MAX_SSCOP_UU_SIZE); }
 *                            [bB][sS][sS][cC][oO][pP][uU][uU]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_ATM_BCK_MAX_SSCOP_UU_SIZE); }
 *                            
 *                            
 *              
 *       Ret:  < 0 failure
 *             > 0 success
 *
 *       Notes: none
 *
 *       File:  {FileName}
 *
 */
 
#ifdef ANSI
PUBLIC S16 mgMsgRegExpConnOptPkgAtmExtnName
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpConnOptPkgAtmExtnName(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
 
 {
    S16 yych;
    S16 yyret = -1;
    U16 yydecode = 0;
    
 
    TRC2(mgMsgRegExpConnOptPkgAtmExtnName)
 
    yych = cmAbnfGetChar(decCp->offset);
    switch(yych)
    {
    case '!':   case '#':
    case '$':   case '&':
    case '\'':   case '*':
    case '+':   case '-':
    case '.':
    case '/':
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9':   case '=':   case '?':
    case '@':   case 'H':
    case 'I':
    case 'J':
    case 'K':
    case 'L':
    case 'M':
    case 'N':
    case 'O':   case 'W':
    case 'X':
    case 'Y':
    case 'Z':
    case '[':   case ']':
    case '^':
    case '_':
    case '`':   case 'h':
    case 'i':
    case 'j':
    case 'k':
    case 'l':
    case 'm':
    case 'n':
    case 'o':   case 'w':
    case 'x':
    case 'y':
    case 'z':
    case '{':
    case '|':
    case '}':
    case '~':   goto yy3;
    case 'A':   case 'a':   goto yy6;
    case 'B':   case 'b':   goto yy7;
    case 'C':   case 'c':   goto yy8;
    case 'D':   case 'd':   goto yy9;
    case 'E':   case 'e':   goto yy10;
    case 'F':   case 'f':   goto yy11;
    case 'G':   case 'g':   goto yy12;
    case 'P':   case 'p':   goto yy13;
    case 'Q':   case 'q':   goto yy14;
    case 'R':   case 'r':   goto yy15;
    case 'S':   case 's':   goto yy16;
    case 'T':   case 't':   goto yy17;
    case 'U':   case 'u':   goto yy18;
    case 'V':   case 'v':   goto yy19;
    default:   goto yyErr;
    }
 yy3:
    (++yydecode);
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
 yy4:   switch(yych)
    {
    case '!':   case '#':
    case '$':   case '&':
    case '\'':   case '*':
    case '+':   case '-':
    case '.':
    case '/':
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9':   case '=':   case '?':
    case '@':
    case 'A':
    case 'B':
    case 'C':
    case 'D':
    case 'E':
    case 'F':
    case 'G':
    case 'H':
    case 'I':
    case 'J':
    case 'K':
    case 'L':
    case 'M':
    case 'N':
    case 'O':
    case 'P':
    case 'Q':
    case 'R':
    case 'S':
    case 'T':
    case 'U':
    case 'V':
    case 'W':
    case 'X':
    case 'Y':
    case 'Z':
    case '[':   case ']':
    case '^':
    case '_':
    case '`':
    case 'a':
    case 'b':
    case 'c':
    case 'd':
    case 'e':
    case 'f':
    case 'g':
    case 'h':
    case 'i':
    case 'j':
    case 'k':
    case 'l':
    case 'm':
    case 'n':
    case 'o':
    case 'p':
    case 'q':
    case 'r':
    case 's':
    case 't':
    case 'u':
    case 'v':
    case 'w':
    case 'x':
    case 'y':
    case 'z':
    case '{':
    case '|':
    case '}':
    case '~':   goto yy3;
    default:   goto yy5;
    }
 yy5:
    { 
       yyret = MGT_MGCP_CONN_OPT_PKG_EXTN_NAME_UNKNOWN_EXTN;      tknCons = FALSE;
       goto yyReturn;
     }
 yy6:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'A':   case 'a':   goto yy233;
    case 'B':   case 'b':   goto yy229;
    case 'D':   case 'd':   goto yy230;
    case 'Q':   case 'q':   goto yy231;
    case 'T':   case 't':   goto yy232;
    default:   goto yy4;
    }
 yy7:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'C':   case 'c':   goto yy189;
    case 'F':   case 'f':   goto yy188;
    case 'S':   case 's':   goto yy187;
    default:   goto yy4;
    }
 yy8:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'B':   case 'b':   goto yy158;
    case 'C':   case 'c':   goto yy159;
    case 'I':   case 'i':   goto yy162;
    case 'K':   case 'k':   goto yy160;
    case 'R':   case 'r':   goto yy161;
    case 'T':   case 't':   goto yy163;
    default:   goto yy4;
    }
 yy9:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'S':   case 's':   goto yy153;
    default:   goto yy4;
    }
 yy10:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'E':   case 'e':   goto yy147;
    default:   goto yy4;
    }
 yy11:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'C':   case 'c':   goto yy99;
    case 'E':   case 'e':   goto yy101;
    case 'F':   case 'f':   goto yy98;
    case 'R':   case 'r':   goto yy100;
    case 'S':   case 's':   goto yy97;
    default:   goto yy4;
    }
 yy12:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'E':   case 'e':   goto yy90;
    default:   goto yy4;
    }
 yy13:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'F':   case 'f':   goto yy84;
    default:   goto yy4;
    }
 yy14:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'O':   case 'o':   goto yy80;
    default:   goto yy4;
    }
 yy15:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'A':   case 'a':   goto yy71;
    default:   goto yy4;
    }
 yy16:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'B':   case 'b':   goto yy47;
    case 'E':   case 'e':   goto yy49;
    case 'M':   case 'm':   goto yy48;
    case 'T':   case 't':   goto yy46;
    default:   goto yy4;
    }
 yy17:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'E':   case 'e':   goto yy37;
    case 'M':   case 'm':   goto yy38;
    default:   goto yy4;
    }
 yy18:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'P':   case 'p':   goto yy28;
    case 'S':   case 's':   goto yy29;
    default:   goto yy4;
    }
 yy19:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'C':   case 'c':   goto yy21;
    case 'S':   case 's':   goto yy20;
    default:   goto yy4;
    }
 yy20:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'E':   case 'e':   goto yy24;
    default:   goto yy4;
    }
 yy21:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy22;
    default:   goto yy4;
    }
 yy22:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_VC_BRR_TYPE;
       goto yyReturn;
     }
 yy24:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'L':   case 'l':   goto yy25;
    default:   goto yy4;
    }
 yy25:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy26;
    default:   goto yy4;
    }
 yy26:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_VOICE_CODEC_SELEC;
       goto yyReturn;
     }
 yy28:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'C':   case 'c':   goto yy33;
    default:   goto yy4;
    }
 yy29:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'I':   case 'i':   goto yy30;
    default:   goto yy4;
    }
 yy30:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy31;
    default:   goto yy4;
    }
 yy31:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_ISUP_USR_INFO;
       goto yyReturn;
     }
 yy33:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'C':   case 'c':   goto yy34;
    default:   goto yy4;
    }
 yy34:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy35;
    default:   goto yy4;
    }
 yy35:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_USR_PLN_CONN_CFG;
       goto yyReturn;
     }
 yy37:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'D':   case 'd':   goto yy43;
    default:   goto yy4;
    }
 yy38:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'C':   case 'c':   goto yy39;
    default:   goto yy4;
    }
 yy39:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'U':   case 'u':   goto yy40;
    default:   goto yy4;
    }
 yy40:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy41;
    default:   goto yy4;
    }
 yy41:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_COMB_USE_TMR;
       goto yyReturn;
     }
 yy43:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy44;
    default:   goto yy4;
    }
 yy44:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_TX_ERR_DETECT;
       goto yyReturn;
     }
 yy46:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'C':   case 'c':   goto yy65;
    case 'R':   case 'r':   goto yy66;
    default:   goto yy4;
    }
 yy47:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'C':   case 'c':   goto yy59;
    case 'T':   case 't':   goto yy60;
    default:   goto yy4;
    }
 yy48:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'P':   case 'p':   goto yy52;
    default:   goto yy4;
    }
 yy49:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy50;
    default:   goto yy4;
    }
 yy50:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_ENABLE_PATH_SET_UP;
       goto yyReturn;
     }
 yy52:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'L':   case 'l':   goto yy53;
    default:   goto yy4;
    }
 yy53:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'C':   case 'c':   goto yy54;
    default:   goto yy4;
    }
 yy54:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'P':   case 'p':   goto yy55;
    default:   goto yy4;
    }
 yy55:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'S':   case 's':   goto yy56;
    default:   goto yy4;
    }
 yy56:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy57;
    default:   goto yy4;
    }
 yy57:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_SIMPL_CPS;
       goto yyReturn;
     }
 yy59:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy63;
    default:   goto yy4;
    }
 yy60:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy61;
    default:   goto yy4;
    }
 yy61:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_ATC_SUB_TYPE;
       goto yyReturn;
     }
 yy63:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_SUB_CHNL_CNT;
       goto yyReturn;
     }
 yy65:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy69;
    default:   goto yy4;
    }
 yy66:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy67;
    default:   goto yy4;
    }
 yy67:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_STRUCT_SIZE;
       goto yyReturn;
     }
 yy69:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_SUSCEP_TO_CLIP;
       goto yyReturn;
     }
 yy71:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'S':   case 's':   goto yy72;
    default:   goto yy4;
    }
 yy72:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'T':   case 't':   goto yy73;
    default:   goto yy4;
    }
 yy73:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'I':   case 'i':   goto yy74;
    default:   goto yy4;
    }
 yy74:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'M':   case 'm':   goto yy75;
    default:   goto yy4;
    }
 yy75:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'E':   case 'e':   goto yy76;
    default:   goto yy4;
    }
 yy76:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'R':   case 'r':   goto yy77;
    default:   goto yy4;
    }
 yy77:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy78;
    default:   goto yy4;
    }
 yy78:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_SSAR_REASSEM_TMR;
       goto yyReturn;
     }
 yy80:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'S':   case 's':   goto yy81;
    default:   goto yy4;
    }
 yy81:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy82;
    default:   goto yy4;
    }
 yy82:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_QOS_CLS;
       goto yyReturn;
     }
 yy84:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy86;
    case 'L':   case 'l':   goto yy85;
    default:   goto yy4;
    }
 yy85:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy88;
    default:   goto yy4;
    }
 yy86:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_PART_FILL;
       goto yyReturn;
     }
 yy88:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_PROF_LST_TYPE;
       goto yyReturn;
     }
 yy90:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'N':   case 'n':   goto yy91;
    default:   goto yy4;
    }
 yy91:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'P':   case 'p':   goto yy92;
    default:   goto yy4;
    }
 yy92:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'C':   case 'c':   goto yy93;
    default:   goto yy4;
    }
 yy93:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'M':   case 'm':   goto yy94;
    default:   goto yy4;
    }
 yy94:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy95;
    default:   goto yy4;
    }
 yy95:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_GENER_PCM_SETNG;
       goto yyReturn;
     }
 yy97:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'D':   case 'd':   goto yy117;
    case 'E':   case 'e':   goto yy118;
    case 'S':   case 's':   goto yy119;
    default:   goto yy4;
    }
 yy98:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'R':   case 'r':   goto yy113;
    default:   goto yy4;
    }
 yy99:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'P':   case 'p':   goto yy108;
    default:   goto yy4;
    }
 yy100:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'M':   case 'm':   goto yy104;
    default:   goto yy4;
    }
 yy101:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy102;
    default:   goto yy4;
    }
 yy102:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_FEC_ENABLE;
       goto yyReturn;
     }
 yy104:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'D':   case 'd':   goto yy105;
    default:   goto yy4;
    }
 yy105:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy106;
    default:   goto yy4;
    }
 yy106:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_FRAME_MOD_ENABLE;
       goto yyReturn;
     }
 yy108:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'C':   case 'c':   goto yy109;
    default:   goto yy4;
    }
 yy109:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'S':   case 's':   goto yy110;
    default:   goto yy4;
    }
 yy110:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy111;
    default:   goto yy4;
    }
 yy111:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_FOR_MAX_CPCS_SDU_SIZE;
       goto yyReturn;
     }
 yy113:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'M':   case 'm':   goto yy114;
    default:   goto yy4;
    }
 yy114:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy115;
    default:   goto yy4;
    }
 yy115:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_FOR_MAX_FRAME_BLK_SIZE;
       goto yyReturn;
     }
 yy117:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'U':   case 'u':   goto yy140;
    default:   goto yy4;
    }
 yy118:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'L':   case 'l':   goto yy137;
    default:   goto yy4;
    }
 yy119:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'C':   case 'c':   goto yy120;
    case 'S':   case 's':   goto yy121;
    default:   goto yy4;
    }
 yy120:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'O':   case 'o':   goto yy126;
    default:   goto yy4;
    }
 yy121:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'A':   case 'a':   goto yy122;
    default:   goto yy4;
    }
 yy122:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'R':   case 'r':   goto yy123;
    default:   goto yy4;
    }
 yy123:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy124;
    default:   goto yy4;
    }
 yy124:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_FOR_MAX_SSSAR_SDU_SIZE;
       goto yyReturn;
     }
 yy126:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'P':   case 'p':   goto yy127;
    default:   goto yy4;
    }
 yy127:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'S':   case 's':   goto yy128;
    case 'U':   case 'u':   goto yy129;
    default:   goto yy4;
    }
 yy128:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'D':   case 'd':   goto yy133;
    default:   goto yy4;
    }
 yy129:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'U':   case 'u':   goto yy130;
    default:   goto yy4;
    }
 yy130:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy131;
    default:   goto yy4;
    }
 yy131:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_FOR_MAX_SSCOP_UU_SIZE;
       goto yyReturn;
     }
 yy133:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'U':   case 'u':   goto yy134;
    default:   goto yy4;
    }
 yy134:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy135;
    default:   goto yy4;
    }
 yy135:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_FOR_MAX_SSCOP_SDU_SIZE;
       goto yyReturn;
     }
 yy137:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy138;
    default:   goto yy4;
    }
 yy138:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_FAX_CODEC_SELEC;
       goto yyReturn;
     }
 yy140:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'R':   case 'r':   goto yy141;
    default:   goto yy4;
    }
 yy141:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'A':   case 'a':   goto yy142;
    default:   goto yy4;
    }
 yy142:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'T':   case 't':   goto yy143;
    default:   goto yy4;
    }
 yy143:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'E':   case 'e':   goto yy144;
    default:   goto yy4;
    }
 yy144:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy145;
    default:   goto yy4;
    }
 yy145:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_FOR_MAX_AAL2_CPS_SDU_SIZE;
       goto yyReturn;
     }
 yy147:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'T':   case 't':   goto yy148;
    default:   goto yy4;
    }
 yy148:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'I':   case 'i':   goto yy149;
    default:   goto yy4;
    }
 yy149:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'M':   case 'm':   goto yy150;
    default:   goto yy4;
    }
 yy150:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy151;
    default:   goto yy4;
    }
 yy151:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_ET_E_TMG_RQD;
       goto yyReturn;
     }
 yy153:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'E':   case 'e':   goto yy154;
    default:   goto yy4;
    }
 yy154:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'L':   case 'l':   goto yy155;
    default:   goto yy4;
    }
 yy155:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy156;
    default:   goto yy4;
    }
 yy156:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_DATA_CODEC_SELEC;
       goto yyReturn;
     }
 yy158:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'R':   case 'r':   goto yy180;
    default:   goto yy4;
    }
 yy159:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'N':   case 'n':   goto yy176;
    default:   goto yy4;
    }
 yy160:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'T':   case 't':   goto yy171;
    default:   goto yy4;
    }
 yy161:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'T':   case 't':   goto yy168;
    default:   goto yy4;
    }
 yy162:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy166;
    default:   goto yy4;
    }
 yy163:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy164;
    default:   goto yy4;
    }
 yy164:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_CONN_TYPE;
       goto yyReturn;
     }
 yy166:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_CONN_ELMNT_ID;
       goto yyReturn;
     }
 yy168:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy169;
    default:   goto yy4;
    }
 yy169:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_CLK_REC_TYPE;
       goto yyReturn;
     }
 yy171:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'M':   case 'm':   goto yy172;
    default:   goto yy4;
    }
 yy172:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'D':   case 'd':   goto yy173;
    default:   goto yy4;
    }
 yy173:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy174;
    default:   goto yy4;
    }
 yy174:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_CKT_MODE;
       goto yyReturn;
     }
 yy176:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'F':   case 'f':   goto yy177;
    default:   goto yy4;
    }
 yy177:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy178;
    default:   goto yy4;
    }
 yy178:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_CODEC_CFG;
       goto yyReturn;
     }
 yy180:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'R':   case 'r':   goto yy181;
    default:   goto yy4;
    }
 yy181:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'A':   case 'a':   goto yy182;
    default:   goto yy4;
    }
 yy182:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'T':   case 't':   goto yy183;
    default:   goto yy4;
    }
 yy183:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'E':   case 'e':   goto yy184;
    default:   goto yy4;
    }
 yy184:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy185;
    default:   goto yy4;
    }
 yy185:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_CBR_RATE;
       goto yyReturn;
     }
 yy187:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'D':   case 'd':   goto yy203;
    case 'S':   case 's':   goto yy204;
    default:   goto yy4;
    }
 yy188:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'R':   case 'r':   goto yy199;
    default:   goto yy4;
    }
 yy189:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'O':   case 'o':   goto yy190;
    case 'P':   case 'p':   goto yy191;
    default:   goto yy4;
    }
 yy190:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'B':   case 'b':   goto yy196;
    default:   goto yy4;
    }
 yy191:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'C':   case 'c':   goto yy192;
    default:   goto yy4;
    }
 yy192:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'S':   case 's':   goto yy193;
    default:   goto yy4;
    }
 yy193:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy194;
    default:   goto yy4;
    }
 yy194:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_BCK_MAX_CPCS_SDU_SIZE;
       goto yyReturn;
     }
 yy196:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy197;
    default:   goto yy4;
    }
 yy197:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_BROAD_BND_CONN_ORI_BRR_CLS;
       goto yyReturn;
     }
 yy199:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'M':   case 'm':   goto yy200;
    default:   goto yy4;
    }
 yy200:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy201;
    default:   goto yy4;
    }
 yy201:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_BCK_MAX_FRAME_BLK_SIZE;
       goto yyReturn;
     }
 yy203:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'U':   case 'u':   goto yy222;
    default:   goto yy4;
    }
 yy204:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'C':   case 'c':   goto yy205;
    case 'S':   case 's':   goto yy206;
    default:   goto yy4;
    }
 yy205:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'O':   case 'o':   goto yy211;
    default:   goto yy4;
    }
 yy206:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'A':   case 'a':   goto yy207;
    default:   goto yy4;
    }
 yy207:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'R':   case 'r':   goto yy208;
    default:   goto yy4;
    }
 yy208:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy209;
    default:   goto yy4;
    }
 yy209:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_BCK_MAX_SSSAR_SDU_SIZE;
       goto yyReturn;
     }
 yy211:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'P':   case 'p':   goto yy212;
    default:   goto yy4;
    }
 yy212:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'S':   case 's':   goto yy213;
    case 'U':   case 'u':   goto yy214;
    default:   goto yy4;
    }
 yy213:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'D':   case 'd':   goto yy218;
    default:   goto yy4;
    }
 yy214:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'U':   case 'u':   goto yy215;
    default:   goto yy4;
    }
 yy215:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy216;
    default:   goto yy4;
    }
 yy216:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_BCK_MAX_SSCOP_UU_SIZE;
       goto yyReturn;
     }
 yy218:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'U':   case 'u':   goto yy219;
    default:   goto yy4;
    }
 yy219:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy220;
    default:   goto yy4;
    }
 yy220:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_BCK_MAX_SSCOP_SDU_SIZE;
       goto yyReturn;
     }
 yy222:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'R':   case 'r':   goto yy223;
    default:   goto yy4;
    }
 yy223:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'A':   case 'a':   goto yy224;
    default:   goto yy4;
    }
 yy224:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'T':   case 't':   goto yy225;
    default:   goto yy4;
    }
 yy225:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'E':   case 'e':   goto yy226;
    default:   goto yy4;
    }
 yy226:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy227;
    default:   goto yy4;
    }
 yy227:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_BCK_MAX_AAL2_CPS_SDU_SIZE;
       goto yyReturn;
     }
 yy229:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'R':   case 'r':   goto yy270;
    default:   goto yy4;
    }
 yy230:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'B':   case 'b':   goto yy254;
    case 'F':   case 'f':   goto yy255;
    default:   goto yy4;
    }
 yy231:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'B':   case 'b':   goto yy248;
    case 'F':   case 'f':   goto yy249;
    default:   goto yy4;
    }
 yy232:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'C':   case 'c':   goto yy245;
    default:   goto yy4;
    }
 yy233:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'L':   case 'l':   goto yy234;
    default:   goto yy4;
    }
 yy234:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'A':   case 'a':   goto yy236;
    case 'S':   case 's':   goto yy235;
    default:   goto yy4;
    }
 yy235:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'A':   case 'a':   goto yy241;
    default:   goto yy4;
    }
 yy236:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'P':   case 'p':   goto yy237;
    default:   goto yy4;
    }
 yy237:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'P':   case 'p':   goto yy238;
    default:   goto yy4;
    }
 yy238:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy239;
    default:   goto yy4;
    }
 yy239:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_APPLI;
       goto yyReturn;
     }
 yy241:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'P':   case 'p':   goto yy242;
    default:   goto yy4;
    }
 yy242:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy243;
    default:   goto yy4;
    }
 yy243:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_SRVC_ACCESS_PT;
       goto yyReturn;
     }
 yy245:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy246;
    default:   goto yy4;
    }
 yy246:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_ATM_TRANSF_CAPAB;
       goto yyReturn;
     }
 yy248:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy252;
    default:   goto yy4;
    }
 yy249:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy250;
    default:   goto yy4;
    }
 yy250:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_ATM_QOS_PARMS_FORWRD;
       goto yyReturn;
     }
 yy252:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_ATM_QOS_PARMS_BCKWRD;
       goto yyReturn;
     }
 yy254:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy263;
    case '0':   goto yy265;
    default:   goto yy4;
    }
 yy255:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '0':   goto yy256;
    default:   goto yy4;
    }
 yy256:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy258;
    case '+':   goto yy257;
    default:   goto yy4;
    }
 yy257:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '1':   goto yy260;
    default:   goto yy4;
    }
 yy258:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_FORWRD_CLP_ZERO;
       goto yyReturn;
     }
 yy260:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy261;
    default:   goto yy4;
    }
 yy261:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_FORWRD_CLP_IND;
       goto yyReturn;
     }
 yy263:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_BCKWRD_CLP_ZERO;
       goto yyReturn;
     }
 yy265:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '+':   goto yy266;
    default:   goto yy4;
    }
 yy266:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '1':   goto yy267;
    default:   goto yy4;
    }
 yy267:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy268;
    default:   goto yy4;
    }
 yy268:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_BCKWRD_CLP_IND;
       goto yyReturn;
     }
 yy270:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'B':   case 'b':   goto yy272;
    case 'F':   case 'f':   goto yy273;
    case 'S':   case 's':   goto yy271;
    default:   goto yy4;
    }
 yy271:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'E':   case 'e':   goto yy278;
    default:   goto yy4;
    }
 yy272:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy276;
    default:   goto yy4;
    }
 yy273:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy274;
    default:   goto yy4;
    }
 yy274:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_ABR_PARMS_FORWRD;
       goto yyReturn;
     }
 yy276:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_ABR_PARMS_BCKWRD;
       goto yyReturn;
     }
 yy278:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'T':   case 't':   goto yy279;
    default:   goto yy4;
    }
 yy279:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'U':   case 'u':   goto yy280;
    default:   goto yy4;
    }
 yy280:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case 'P':   case 'p':   goto yy281;
    default:   goto yy4;
    }
 yy281:      (++yydecode);
 
    yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
    switch(yych)
    {
    case '\t':
    case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy282;
    default:   goto yy4;
    }
 yy282:      (++yydecode);
 
        
    (--yydecode);
    { 
       yyret = MGT_MGCP_CO_PKG_ATM_ABR_CONN_SETUP_PARMS;
       goto yyReturn;
     }
 
 
 yyReturn:
 
 yyErr:
    CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
 } /* mgMsgRegExpConnOptPkgAtmExtnName */

#endif  /* GCP_PKG_MGCP_ATM */


#ifdef  GCP_PKG_MGCP_DTMF_DLPL_BASPBX


/*
    Func:  BLRqEvSymType  ->     */
/*!re2c

               known = [hH][dD] | [hH][fF] | [hH][uU] | [oO][cC] | [oO][fF];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgBLRqEvSymType
*
*       Desc:  Description for the regular expression PkgBLRqEvSymType
*              
*                             known = [hH][dD] | [hH][fF] | [hH][uU] | [oO][cC] | [oO][fF];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgBLRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgBLRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgBLRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy11;
   case '*':   goto yy10;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'A':   case 'a':   goto yy5;
   case 'H':   case 'h':   goto yy3;
   case 'O':   case 'o':   goto yy4;
   case '[':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'F':   case 'U':   case 'd':   case 'f':   case 'u':   goto yy22;
   default:   goto yy9;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy22;
   default:   goto yy9;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy9;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy19;
   default:   goto yy9;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy20;
   default:   goto yy9;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yy9;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgBLRqEvSymType */

/*
    Func:  BLRqEvSymVal  ->     */
/*!re2c
[hH][dD]          { return (MGT_MGCP_PKG_B_L_RQ_EV_SYM_OFFHOOK); }
[hH][fF]          { return (MGT_MGCP_PKG_B_L_RQ_EV_SYM_FLASH_HOOK); }
[hH][uU]          { return (MGT_MGCP_PKG_B_L_RQ_EV_SYM_ONHOOK); }
[oO][cC]          { return (MGT_MGCP_PKG_B_L_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_B_L_RQ_EV_SYM_OPER_FAIL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgBLRqEvSymVal
*
*       Desc:  Description for the regular expression PkgBLRqEvSymVal
*              [hH][dD]          { return (MGT_MGCP_PKG_B_L_RQ_EV_SYM_OFFHOOK); }
*              [hH][fF]          { return (MGT_MGCP_PKG_B_L_RQ_EV_SYM_FLASH_HOOK); }
*              [hH][uU]          { return (MGT_MGCP_PKG_B_L_RQ_EV_SYM_ONHOOK); }
*              [oO][cC]          { return (MGT_MGCP_PKG_B_L_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_B_L_RQ_EV_SYM_OPER_FAIL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgBLRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgBLRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgBLRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy3;
   case 'O':   case 'o':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy13;
   case 'F':   case 'f':   goto yy11;
   case 'U':   case 'u':   goto yy9;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy7;
   case 'F':   case 'f':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_L_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_L_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_L_RQ_EV_SYM_ONHOOK;
      goto yyReturn;
    }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_L_RQ_EV_SYM_FLASH_HOOK;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_L_RQ_EV_SYM_OFFHOOK;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgBLRqEvSymVal */

/*
    Func:  BLSgRqSymType  ->     */
/*!re2c

               known = [bB][zZ] | [dD][lL] | [rR][eE][lL] | [rR][gG] | [rR][oO] | [rR][tT];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgBLSgRqSymType
*
*       Desc:  Description for the regular expression PkgBLSgRqSymType
*              
*                             known = [bB][zZ] | [dD][lL] | [rR][eE][lL] | [rR][gG] | [rR][oO] | [rR][tT];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgBLSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgBLSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgBLSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy12;
   case '*':   goto yy11;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'C':   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'c':   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   case 'A':   case 'a':   goto yy6;
   case 'B':   case 'b':   goto yy3;
   case 'D':   case 'd':   goto yy4;
   case 'R':   case 'r':   goto yy5;
   case '[':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy24;
   default:   goto yy10;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy24;
   default:   goto yy10;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy23;
   case 'G':   case 'O':   case 'T':   case 'g':   case 'o':   case 't':   goto yy24;
   default:   goto yy10;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy19;
   default:   goto yy10;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy9:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy10:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy17;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy20;
   default:   goto yy10;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy21;
   default:   goto yy10;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy24;
   default:   goto yy10;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy25;
   default:   goto yy10;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgBLSgRqSymType */

/*
    Func:  BLSgRqSymVal  ->     */
/*!re2c
[bB][zZ]          { return (MGT_MGCP_PKG_B_L_SG_RQ_SYM_BUSY_TONE); }
[dD][lL]          { return (MGT_MGCP_PKG_B_L_SG_RQ_SYM_DIAL_TONE); }
[rR][eE][lL]          { return (MGT_MGCP_PKG_B_L_SG_RQ_SYM_RELEASE); }
[rR][gG]          { return (MGT_MGCP_PKG_B_L_SG_RQ_SYM_RINGING); }
[rR][oO]          { return (MGT_MGCP_PKG_B_L_SG_RQ_SYM_REORDER_TONE); }
[rR][tT]          { return (MGT_MGCP_PKG_B_L_SG_RQ_SYM_RINGBACK_TONE); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgBLSgRqSymVal
*
*       Desc:  Description for the regular expression PkgBLSgRqSymVal
*              [bB][zZ]          { return (MGT_MGCP_PKG_B_L_SG_RQ_SYM_BUSY_TONE); }
*              [dD][lL]          { return (MGT_MGCP_PKG_B_L_SG_RQ_SYM_DIAL_TONE); }
*              [rR][eE][lL]          { return (MGT_MGCP_PKG_B_L_SG_RQ_SYM_RELEASE); }
*              [rR][gG]          { return (MGT_MGCP_PKG_B_L_SG_RQ_SYM_RINGING); }
*              [rR][oO]          { return (MGT_MGCP_PKG_B_L_SG_RQ_SYM_REORDER_TONE); }
*              [rR][tT]          { return (MGT_MGCP_PKG_B_L_SG_RQ_SYM_RINGBACK_TONE); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgBLSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgBLSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgBLSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy3;
   case 'D':   case 'd':   goto yy4;
   case 'R':   case 'r':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy17;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy15;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy12;
   case 'G':   case 'g':   goto yy10;
   case 'O':   case 'o':   goto yy8;
   case 'T':   case 't':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_L_SG_RQ_SYM_RINGBACK_TONE;
      goto yyReturn;
    }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_L_SG_RQ_SYM_REORDER_TONE;
      goto yyReturn;
    }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_L_SG_RQ_SYM_RINGING;
      goto yyReturn;
    }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_L_SG_RQ_SYM_RELEASE;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_L_SG_RQ_SYM_DIAL_TONE;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_L_SG_RQ_SYM_BUSY_TONE;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgBLSgRqSymVal */

#endif  /* GCP_PKG_MGCP_DTMF_DLPL_BASPBX */


#ifdef  GCP_PKG_MGCP_CNTRY_SPEC_TONE


/*
    Func:  CSTRqEvSymType  ->     */
/*!re2c

               known = [oO][cC] | [oO][fF];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgCSTRqEvSymType
*
*       Desc:  Description for the regular expression PkgCSTRqEvSymType
*              
*                             known = [oO][cC] | [oO][fF];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgCSTRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgCSTRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgCSTRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy10;
   case '*':   goto yy9;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'A':   case 'a':   goto yy4;
   case 'O':   case 'o':   goto yy3;
   case '[':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy21;
   default:   goto yy8;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yy8;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy8;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy8;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yy8;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgCSTRqEvSymType */

/*
    Func:  CSTRqEvSymVal  ->     */
/*!re2c
[oO][cC]          { return (MGT_MGCP_PKG_C_S_T_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_C_S_T_RQ_EV_SYM_OPER_FAIL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgCSTRqEvSymVal
*
*       Desc:  Description for the regular expression PkgCSTRqEvSymVal
*              [oO][cC]          { return (MGT_MGCP_PKG_C_S_T_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_C_S_T_RQ_EV_SYM_OPER_FAIL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgCSTRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgCSTRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgCSTRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy6;
   case 'F':   case 'f':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgCSTRqEvSymVal */

/*
    Func:  CSTSgRqSymType  ->     */
/*!re2c

               known = [aA][cC] | [bB][zZ][2] | [bB][zZ][3] | [cC][fF][2] | [cC][gG][2] | [cC][gG][3] | [dD][lL][2] | [dD][lL][3] | [sS][dD][1] | [sS][dD][2] | [sS][dD][3] | [eE][oO] | [eE][sS] | [fF][cC] | [lL][lL] | [nN][uU][2] | [oO][rR] | [pP][rR][2] | [pP][rR][3] | [pP][rR][4] | [qQ][uU] | [rR][fF] | [rR][uU][1] | [rR][uU][2] | [rR][tT][2] | [rR][tT][3] | [rR][tT][4] | [sS][aA] | [vV][aA] | [wW][aA][1] | [wW][aA][2] | [wW][aA][3] | [wW][eE] | [wW][pP] | [wW][rR][1] | [wW][rR][2];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgCSTSgRqSymType
*
*       Desc:  Description for the regular expression PkgCSTSgRqSymType
*              
*                             known = [aA][cC] | [bB][zZ][2] | [bB][zZ][3] | [cC][fF][2] | [cC][gG][2] | [cC][gG][3] | [dD][lL][2] | [dD][lL][3] | [sS][dD][1] | [sS][dD][2] | [sS][dD][3] | [eE][oO] | [eE][sS] | [fF][cC] | [lL][lL] | [nN][uU][2] | [oO][rR] | [pP][rR][2] | [pP][rR][3] | [pP][rR][4] | [qQ][uU] | [rR][fF] | [rR][uU][1] | [rR][uU][2] | [rR][tT][2] | [rR][tT][3] | [rR][tT][4] | [sS][aA] | [vV][aA] | [wW][aA][1] | [wW][aA][2] | [wW][aA][3] | [wW][eE] | [wW][pP] | [wW][rR][1] | [wW][rR][2];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgCSTSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgCSTSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgCSTSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy23;
   case '*':   goto yy22;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':   case 'M':   case 'T':
   case 'U':   case 'X':
   case 'Y':
   case 'Z':   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':   case 'm':   case 't':
   case 'u':   case 'x':
   case 'y':
   case 'z':   goto yy20;
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'C':   case 'c':   goto yy5;
   case 'D':   case 'd':   goto yy6;
   case 'E':   case 'e':   goto yy8;
   case 'F':   case 'f':   goto yy9;
   case 'L':   case 'l':   goto yy10;
   case 'N':   case 'n':   goto yy11;
   case 'O':   case 'o':   goto yy12;
   case 'P':   case 'p':   goto yy13;
   case 'Q':   case 'q':   goto yy14;
   case 'R':   case 'r':   goto yy15;
   case 'S':   case 's':   goto yy7;
   case 'V':   case 'v':   goto yy16;
   case 'W':   case 'w':   goto yy17;
   case '[':   goto yy18;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy31;
   case 'L':   case 'l':   goto yy44;
   default:   goto yy21;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy43;
   default:   goto yy21;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy41;
   case 'G':   case 'g':   goto yy42;
   default:   goto yy21;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy40;
   default:   goto yy21;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy31;
   case 'D':   case 'd':   goto yy39;
   default:   goto yy21;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'S':   case 'o':   case 's':   goto yy31;
   default:   goto yy21;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy31;
   default:   goto yy21;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy31;
   default:   goto yy21;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy38;
   default:   goto yy21;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy31;
   default:   goto yy21;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy37;
   default:   goto yy21;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy31;
   default:   goto yy21;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy31;
   case 'T':   case 't':   goto yy35;
   case 'U':   case 'u':   goto yy36;
   default:   goto yy21;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy31;
   default:   goto yy21;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy30;
   case 'E':   case 'P':   case 'e':   case 'p':   goto yy31;
   case 'R':   case 'r':   goto yy32;
   default:   goto yy21;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy20:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy21:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy28;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy20;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy26;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy24;
   default:   goto yyErr;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':
   case '2':
   case '3':   goto yy31;
   default:   goto yy21;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy33;
   default:   goto yy21;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':
   case '2':   goto yy31;
   default:   goto yy21;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '2':
   case '3':
   case '4':   goto yy31;
   default:   goto yy21;
   }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':
   case '2':   goto yy31;
   default:   goto yy21;
   }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '2':
   case '3':
   case '4':   goto yy31;
   default:   goto yy21;
   }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '2':   goto yy31;
   default:   goto yy21;
   }
yy39:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':
   case '2':
   case '3':   goto yy31;
   default:   goto yy21;
   }
yy40:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '2':
   case '3':   goto yy31;
   default:   goto yy21;
   }
yy41:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '2':   goto yy31;
   default:   goto yy21;
   }
yy42:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '2':
   case '3':   goto yy31;
   default:   goto yy21;
   }
yy43:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '2':
   case '3':   goto yy31;
   default:   goto yy21;
   }
yy44:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy45;
   default:   goto yy21;
   }
yy45:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy46;
   default:   goto yy21;
   }
yy46:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgCSTSgRqSymType */

/*
    Func:  CSTSgRqSymVal  ->     */
/*!re2c
[aA][cC]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_ACCEPTANCE_TONE); }
[bB][zZ][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_BUSY_TONES2); }
[bB][zZ][3]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_BUSY_TONES3); }
[cC][fF][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_CNFRMN_TONE_I_I); }
[cC][gG][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_CONGES_TONES2); }
[cC][gG][3]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_CONGES_TONES3); }
[dD][lL][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_DIAL_TONES2); }
[dD][lL][3]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_DIAL_TONES3); }
[sS][dD][1]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SECOND_DIAL_TONES1); }
[sS][dD][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SECOND_DIAL_TONES2); }
[sS][dD][3]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SECOND_DIAL_TONES3); }
[eE][oO]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_EXEC_OVER_RIDE_TONE); }
[eE][sS]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_END_OF3_PARTY_SERV); }
[fF][cC]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_FACILITIES_TONE); }
[lL][lL]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_LINE_LOCKOUT); }
[nN][uU][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_NUM_UNOBTAINABLE_I_I); }
[oO][rR]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OFFERING_TONE); }
[pP][rR][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_PAYPHONE_RECOG2); }
[pP][rR][3]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_PAYPHONE_RECOG3); }
[pP][rR][4]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_PAYPHONE_RECOG4); }
[qQ][uU]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_QUEUE_TONE); }
[rR][fF]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_REFUSAL_TONE); }
[rR][uU][1]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_ROUTE_TONE1); }
[rR][uU][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_ROUTE_TONE2); }
[rR][tT][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_RINGING_TONE2); }
[rR][tT][3]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_RINGING_TONE3); }
[rR][tT][4]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_RINGING_TONE4); }
[sS][aA]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SRVC_ACTIVTD_TONE); }
[vV][aA]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_VALID_TONE); }
[wW][aA][1]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WAITING_TONE1); }
[wW][aA][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WAITING_TONE2); }
[wW][aA][3]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WAITING_TONE3); }
[wW][eE]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_END_OR_PERIOD); }
[wW][pP]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_P_I_P_TONE); }
[wW][rR][1]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_TONE_OPER1); }
[wW][rR][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_TONE_OPER2); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgCSTSgRqSymVal
*
*       Desc:  Description for the regular expression PkgCSTSgRqSymVal
*              [aA][cC]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_ACCEPTANCE_TONE); }
*              [bB][zZ][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_BUSY_TONES2); }
*              [bB][zZ][3]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_BUSY_TONES3); }
*              [cC][fF][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_CNFRMN_TONE_I_I); }
*              [cC][gG][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_CONGES_TONES2); }
*              [cC][gG][3]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_CONGES_TONES3); }
*              [dD][lL][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_DIAL_TONES2); }
*              [dD][lL][3]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_DIAL_TONES3); }
*              [sS][dD][1]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SECOND_DIAL_TONES1); }
*              [sS][dD][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SECOND_DIAL_TONES2); }
*              [sS][dD][3]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SECOND_DIAL_TONES3); }
*              [eE][oO]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_EXEC_OVER_RIDE_TONE); }
*              [eE][sS]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_END_OF3_PARTY_SERV); }
*              [fF][cC]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_FACILITIES_TONE); }
*              [lL][lL]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_LINE_LOCKOUT); }
*              [nN][uU][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_NUM_UNOBTAINABLE_I_I); }
*              [oO][rR]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OFFERING_TONE); }
*              [pP][rR][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_PAYPHONE_RECOG2); }
*              [pP][rR][3]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_PAYPHONE_RECOG3); }
*              [pP][rR][4]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_PAYPHONE_RECOG4); }
*              [qQ][uU]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_QUEUE_TONE); }
*              [rR][fF]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_REFUSAL_TONE); }
*              [rR][uU][1]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_ROUTE_TONE1); }
*              [rR][uU][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_ROUTE_TONE2); }
*              [rR][tT][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_RINGING_TONE2); }
*              [rR][tT][3]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_RINGING_TONE3); }
*              [rR][tT][4]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_RINGING_TONE4); }
*              [sS][aA]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SRVC_ACTIVTD_TONE); }
*              [vV][aA]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_VALID_TONE); }
*              [wW][aA][1]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WAITING_TONE1); }
*              [wW][aA][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WAITING_TONE2); }
*              [wW][aA][3]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WAITING_TONE3); }
*              [wW][eE]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_END_OR_PERIOD); }
*              [wW][pP]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_P_I_P_TONE); }
*              [wW][rR][1]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_TONE_OPER1); }
*              [wW][rR][2]          { return (MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_TONE_OPER2); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgCSTSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgCSTSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgCSTSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'C':   case 'c':   goto yy5;
   case 'D':   case 'd':   goto yy6;
   case 'E':   case 'e':   goto yy8;
   case 'F':   case 'f':   goto yy9;
   case 'L':   case 'l':   goto yy10;
   case 'N':   case 'n':   goto yy11;
   case 'O':   case 'o':   goto yy12;
   case 'P':   case 'p':   goto yy13;
   case 'Q':   case 'q':   goto yy14;
   case 'R':   case 'r':   goto yy15;
   case 'S':   case 's':   goto yy7;
   case 'V':   case 'v':   goto yy16;
   case 'W':   case 'w':   goto yy17;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy99;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy94;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy87;
   case 'G':   case 'g':   goto yy86;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy81;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy72;
   case 'D':   case 'd':   goto yy74;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy70;
   case 'S':   case 's':   goto yy68;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy66;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy64;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy61;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy59;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy52;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy50;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy38;
   case 'T':   case 't':   goto yy36;
   case 'U':   case 'u':   goto yy37;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy34;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy23;
   case 'E':   case 'e':   goto yy21;
   case 'P':   case 'p':   goto yy19;
   case 'R':   case 'r':   goto yy18;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy30;
   case '2':   goto yy32;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_P_I_P_TONE;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_END_OR_PERIOD;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy24;
   case '2':   goto yy26;
   case '3':   goto yy28;
   default:   goto yyErr;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WAITING_TONE1;
      goto yyReturn;
    }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WAITING_TONE2;
      goto yyReturn;
    }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WAITING_TONE3;
      goto yyReturn;
    }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_TONE_OPER1;
      goto yyReturn;
    }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_TONE_OPER2;
      goto yyReturn;
    }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_VALID_TONE;
      goto yyReturn;
    }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '2':   goto yy44;
   case '3':   goto yy46;
   case '4':   goto yy48;
   default:   goto yyErr;
   }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy40;
   case '2':   goto yy42;
   default:   goto yyErr;
   }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_REFUSAL_TONE;
      goto yyReturn;
    }
yy40:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_ROUTE_TONE1;
      goto yyReturn;
    }
yy42:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_ROUTE_TONE2;
      goto yyReturn;
    }
yy44:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_RINGING_TONE2;
      goto yyReturn;
    }
yy46:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_RINGING_TONE3;
      goto yyReturn;
    }
yy48:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_RINGING_TONE4;
      goto yyReturn;
    }
yy50:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_QUEUE_TONE;
      goto yyReturn;
    }
yy52:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '2':   goto yy53;
   case '3':   goto yy55;
   case '4':   goto yy57;
   default:   goto yyErr;
   }
yy53:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_PAYPHONE_RECOG2;
      goto yyReturn;
    }
yy55:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_PAYPHONE_RECOG3;
      goto yyReturn;
    }
yy57:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_PAYPHONE_RECOG4;
      goto yyReturn;
    }
yy59:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OFFERING_TONE;
      goto yyReturn;
    }
yy61:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '2':   goto yy62;
   default:   goto yyErr;
   }
yy62:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_NUM_UNOBTAINABLE_I_I;
      goto yyReturn;
    }
yy64:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_LINE_LOCKOUT;
      goto yyReturn;
    }
yy66:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_FACILITIES_TONE;
      goto yyReturn;
    }
yy68:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_END_OF3_PARTY_SERV;
      goto yyReturn;
    }
yy70:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_EXEC_OVER_RIDE_TONE;
      goto yyReturn;
    }
yy72:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SRVC_ACTIVTD_TONE;
      goto yyReturn;
    }
yy74:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy75;
   case '2':   goto yy77;
   case '3':   goto yy79;
   default:   goto yyErr;
   }
yy75:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SECOND_DIAL_TONES1;
      goto yyReturn;
    }
yy77:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SECOND_DIAL_TONES2;
      goto yyReturn;
    }
yy79:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SECOND_DIAL_TONES3;
      goto yyReturn;
    }
yy81:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '2':   goto yy82;
   case '3':   goto yy84;
   default:   goto yyErr;
   }
yy82:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_DIAL_TONES2;
      goto yyReturn;
    }
yy84:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_DIAL_TONES3;
      goto yyReturn;
    }
yy86:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '2':   goto yy90;
   case '3':   goto yy92;
   default:   goto yyErr;
   }
yy87:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '2':   goto yy88;
   default:   goto yyErr;
   }
yy88:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_CNFRMN_TONE_I_I;
      goto yyReturn;
    }
yy90:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_CONGES_TONES2;
      goto yyReturn;
    }
yy92:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_CONGES_TONES3;
      goto yyReturn;
    }
yy94:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '2':   goto yy95;
   case '3':   goto yy97;
   default:   goto yyErr;
   }
yy95:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_BUSY_TONES2;
      goto yyReturn;
    }
yy97:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_BUSY_TONES3;
      goto yyReturn;
    }
yy99:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_ACCEPTANCE_TONE;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgCSTSgRqSymVal */

#endif  /* GCP_PKG_MGCP_CNTRY_SPEC_TONE */




#ifdef  GCP_PKG_MGCP_DTMF


/*
    Func:  DRqEvSymType  ->     */
/*!re2c

               known = [0] | [1] | [2] | [3] | [4] | [5] | [6] | [7] | [8] | [9] | [#] | [*] | [Aa] | [Bb] | [Cc] | [Dd] | [Ll] | [Dd][Dd] | [Xx] | [oO][cC] | [oO][fF] | [Tt];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgDRqEvSymType
*
*       Desc:  Description for the regular expression PkgDRqEvSymType
*              
*                             known = [0] | [1] | [2] | [3] | [4] | [5] | [6] | [7] | [8] | [9] | [#] | [*] | [Aa] | [Bb] | [Cc] | [Dd] | [Ll] | [Dd][Dd] | [Xx] | [oO][cC] | [oO][fF] | [Tt];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgDRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgDRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgDRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy3;
   case '*':   goto yy4;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':   case 'L':   case 'T':   case 'X':   case 'b':
   case 'c':   case 'l':   case 't':   case 'x':   goto yy5;
   case 'A':   case 'a':   goto yy6;
   case 'D':   case 'd':   goto yy7;
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':   case 'M':
   case 'N':   case 'P':
   case 'Q':
   case 'R':
   case 'S':   case 'U':
   case 'V':
   case 'W':   case 'Y':
   case 'Z':   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':   case 'm':
   case 'n':   case 'p':
   case 'q':
   case 'r':
   case 's':   case 'u':
   case 'v':
   case 'w':   case 'y':
   case 'z':   goto yy11;
   case 'O':   case 'o':   goto yy8;
   case '[':   goto yy9;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy21;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   default:   goto yy12;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   case 'L':   case 'l':   goto yy17;
   default:   goto yy12;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   case 'D':   case 'd':   goto yy5;
   default:   goto yy12;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy5;
   default:   goto yy12;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy11:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy12:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy16:
   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy12;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy12;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   goto yy16;
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   goto yy16;



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgDRqEvSymType */

/*
    Func:  DRqEvSymVal  ->     */
/*!re2c
[0]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF0); }
[1]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF1); }
[2]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF2); }
[3]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF3); }
[4]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF4); }
[5]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF5); }
[6]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF6); }
[7]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF7); }
[8]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF8); }
[9]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF9); }
[#]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_POUND); }
[*]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_STAR); }
[Aa]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_A); }
[Bb]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_B); }
[Cc]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_C); }
[Dd]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_D); }
[Ll]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_LONG_DUR_IND); }
[Dd][Dd]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_TONE_DUR); }
[Xx]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_WILDCARD_MATCH); }
[oO][cC]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_OPER_FAIL); }
[Tt]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_INTERDGT_TMR); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgDRqEvSymVal
*
*       Desc:  Description for the regular expression PkgDRqEvSymVal
*              [0]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF0); }
*              [1]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF1); }
*              [2]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF2); }
*              [3]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF3); }
*              [4]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF4); }
*              [5]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF5); }
*              [6]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF6); }
*              [7]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF7); }
*              [8]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF8); }
*              [9]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF9); }
*              [#]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_POUND); }
*              [*]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_STAR); }
*              [Aa]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_A); }
*              [Bb]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_B); }
*              [Cc]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_C); }
*              [Dd]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_D); }
*              [Ll]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_LONG_DUR_IND); }
*              [Dd][Dd]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_TONE_DUR); }
*              [Xx]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_WILDCARD_MATCH); }
*              [oO][cC]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_OPER_FAIL); }
*              [Tt]          { return (MGT_MGCP_PKG_D_RQ_EV_SYM_INTERDGT_TMR); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgDRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgDRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgDRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy23;
   case '*':   goto yy25;
   case '0':   goto yy3;
   case '1':   goto yy5;
   case '2':   goto yy7;
   case '3':   goto yy9;
   case '4':   goto yy11;
   case '5':   goto yy13;
   case '6':   goto yy15;
   case '7':   goto yy17;
   case '8':   goto yy19;
   case '9':   goto yy21;
   case 'A':   case 'a':   goto yy27;
   case 'B':   case 'b':   goto yy29;
   case 'C':   case 'c':   goto yy31;
   case 'D':   case 'd':   goto yy33;
   case 'L':   case 'l':   goto yy35;
   case 'O':   case 'o':   goto yy39;
   case 'T':   case 't':   goto yy40;
   case 'X':   case 'x':   goto yy37;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF0;
      goto yyReturn;
    }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF1;
      goto yyReturn;
    }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF2;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF3;
      goto yyReturn;
    }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF4;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF5;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF6;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF7;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF8;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF9;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_POUND;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_STAR;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_A;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_B;
      goto yyReturn;
    }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_C;
      goto yyReturn;
    }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy46;
   default:   goto yy34;
   }
yy34:
   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_D;
      goto yyReturn;
    }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_LONG_DUR_IND;
      goto yyReturn;
    }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_WILDCARD_MATCH;
      goto yyReturn;
    }
yy39:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy44;
   case 'F':   case 'f':   goto yy42;
   default:   goto yyErr;
   }
yy40:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_INTERDGT_TMR;
      goto yyReturn;
    }
yy42:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy44:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }
yy46:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_TONE_DUR;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgDRqEvSymVal */

/*
    Func:  DSgRqSymType  ->     */
/*!re2c

               known = [0] | [1] | [2] | [3] | [4] | [5] | [6] | [7] | [8] | [9] | [#] | [*] | [Aa] | [Bb] | [Cc] | [Dd] | [Dd][Dd] | [Dd][Oo] | [Tt];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgDSgRqSymType
*
*       Desc:  Description for the regular expression PkgDSgRqSymType
*              
*                             known = [0] | [1] | [2] | [3] | [4] | [5] | [6] | [7] | [8] | [9] | [#] | [*] | [Aa] | [Bb] | [Cc] | [Dd] | [Dd][Dd] | [Dd][Oo] | [Tt];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgDSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgDSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgDSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy3;
   case '*':   goto yy4;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':   case 'T':   case 'b':
   case 'c':   case 't':   goto yy5;
   case 'A':   case 'a':   goto yy6;
   case 'D':   case 'd':   goto yy7;
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   case '[':   goto yy8;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy21;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy20;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yy11;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   case 'L':   case 'l':   goto yy16;
   default:   goto yy11;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   case 'D':   case 'O':   case 'd':   case 'o':   goto yy5;
   default:   goto yy11;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy10:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy11:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy12;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy15:
   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yy11;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy18;
   default:   goto yy11;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   goto yy15;
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   goto yy15;



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgDSgRqSymType */

/*
    Func:  DSgRqSymVal  ->     */
/*!re2c
[0]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF0); }
[1]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF1); }
[2]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF2); }
[3]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF3); }
[4]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF4); }
[5]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF5); }
[6]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF6); }
[7]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF7); }
[8]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF8); }
[9]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF9); }
[#]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_POUND); }
[*]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_STAR); }
[Aa]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_A); }
[Bb]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_B); }
[Cc]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_C); }
[Dd]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_D); }
[Dd][Dd]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_TONE_DUR); }
[Dd][Oo]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_OO_SIG); }
[Tt]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_INTERDGT_TMR); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgDSgRqSymVal
*
*       Desc:  Description for the regular expression PkgDSgRqSymVal
*              [0]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF0); }
*              [1]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF1); }
*              [2]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF2); }
*              [3]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF3); }
*              [4]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF4); }
*              [5]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF5); }
*              [6]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF6); }
*              [7]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF7); }
*              [8]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF8); }
*              [9]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF9); }
*              [#]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_POUND); }
*              [*]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_STAR); }
*              [Aa]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_A); }
*              [Bb]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_B); }
*              [Cc]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_C); }
*              [Dd]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_D); }
*              [Dd][Dd]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_TONE_DUR); }
*              [Dd][Oo]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_OO_SIG); }
*              [Tt]          { return (MGT_MGCP_PKG_D_SG_RQ_SYM_INTERDGT_TMR); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgDSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgDSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgDSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy23;
   case '*':   goto yy25;
   case '0':   goto yy3;
   case '1':   goto yy5;
   case '2':   goto yy7;
   case '3':   goto yy9;
   case '4':   goto yy11;
   case '5':   goto yy13;
   case '6':   goto yy15;
   case '7':   goto yy17;
   case '8':   goto yy19;
   case '9':   goto yy21;
   case 'A':   case 'a':   goto yy27;
   case 'B':   case 'b':   goto yy29;
   case 'C':   case 'c':   goto yy31;
   case 'D':   case 'd':   goto yy33;
   case 'T':   case 't':   goto yy35;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF0;
      goto yyReturn;
    }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF1;
      goto yyReturn;
    }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF2;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF3;
      goto yyReturn;
    }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF4;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF5;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF6;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF7;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF8;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF9;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_POUND;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_STAR;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_A;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_B;
      goto yyReturn;
    }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_C;
      goto yyReturn;
    }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy39;
   case 'O':   case 'o':   goto yy37;
   default:   goto yy34;
   }
yy34:
   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_D;
      goto yyReturn;
    }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_INTERDGT_TMR;
      goto yyReturn;
    }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_OO_SIG;
      goto yyReturn;
    }
yy39:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_TONE_DUR;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgDSgRqSymVal */

#endif  /* GCP_PKG_MGCP_DTMF */




#ifdef  GCP_PKG_MGCP_FXO_LSG_ANALOG


/*
    Func:  DORqEvSymType  ->     */
/*!re2c

               known = [cC][iI] | [oO][cC] | [oO][fF] | [rR][eE][lL] | [rR][gG] | [rR][lL][cC];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgDORqEvSymType
*
*       Desc:  Description for the regular expression PkgDORqEvSymType
*              
*                             known = [cC][iI] | [oO][cC] | [oO][fF] | [rR][eE][lL] | [rR][gG] | [rR][lL][cC];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgDORqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgDORqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgDORqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy12;
   case '*':   goto yy11;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   case 'A':   case 'a':   goto yy6;
   case 'C':   case 'c':   goto yy3;
   case 'O':   case 'o':   goto yy4;
   case 'R':   case 'r':   goto yy5;
   case '[':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy24;
   default:   goto yy10;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy24;
   default:   goto yy10;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy23;
   case 'G':   case 'g':   goto yy24;
   case 'L':   case 'l':   goto yy25;
   default:   goto yy10;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy19;
   default:   goto yy10;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy9:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy10:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy17;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy20;
   default:   goto yy10;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy21;
   default:   goto yy10;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy24;
   default:   goto yy10;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy26;
   default:   goto yy10;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy24;
   default:   goto yy10;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgDORqEvSymType */

/*
    Func:  DORqEvSymVal  ->     */
/*!re2c
[cC][iI]          { return (MGT_MGCP_PKG_D_O_RQ_EV_SYM_CALLER_ID); }
[oO][cC]          { return (MGT_MGCP_PKG_D_O_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_D_O_RQ_EV_SYM_OPER_FAIL); }
[rR][eE][lL]          { return (MGT_MGCP_PKG_D_O_RQ_EV_SYM_RELEASE_CALL); }
[rR][gG]          { return (MGT_MGCP_PKG_D_O_RQ_EV_SYM_RINGING); }
[rR][lL][cC]          { return (MGT_MGCP_PKG_D_O_RQ_EV_SYM_RELEASE_COMPLT); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgDORqEvSymVal
*
*       Desc:  Description for the regular expression PkgDORqEvSymVal
*              [cC][iI]          { return (MGT_MGCP_PKG_D_O_RQ_EV_SYM_CALLER_ID); }
*              [oO][cC]          { return (MGT_MGCP_PKG_D_O_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_D_O_RQ_EV_SYM_OPER_FAIL); }
*              [rR][eE][lL]          { return (MGT_MGCP_PKG_D_O_RQ_EV_SYM_RELEASE_CALL); }
*              [rR][gG]          { return (MGT_MGCP_PKG_D_O_RQ_EV_SYM_RINGING); }
*              [rR][lL][cC]          { return (MGT_MGCP_PKG_D_O_RQ_EV_SYM_RELEASE_COMPLT); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgDORqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgDORqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgDORqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy3;
   case 'O':   case 'o':   goto yy4;
   case 'R':   case 'r':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy18;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy16;
   case 'F':   case 'f':   goto yy14;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy9;
   case 'G':   case 'g':   goto yy7;
   case 'L':   case 'l':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy12;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_O_RQ_EV_SYM_RINGING;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_O_RQ_EV_SYM_RELEASE_CALL;
      goto yyReturn;
    }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_O_RQ_EV_SYM_RELEASE_COMPLT;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_O_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_O_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_O_RQ_EV_SYM_CALLER_ID;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgDORqEvSymVal */

/*
    Func:  DOSgRqSymType  ->     */
/*!re2c

               known = [hH][dD] | [hH][fF] | [hH][uU] | [sS][uU][pP];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgDOSgRqSymType
*
*       Desc:  Description for the regular expression PkgDOSgRqSymType
*              
*                             known = [hH][dD] | [hH][fF] | [hH][uU] | [sS][uU][pP];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgDOSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgDOSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgDOSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy11;
   case '*':   goto yy10;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'A':   case 'a':   goto yy5;
   case 'H':   case 'h':   goto yy3;
   case 'S':   case 's':   goto yy4;
   case '[':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'F':   case 'U':   case 'd':   case 'f':   case 'u':   goto yy23;
   default:   goto yy9;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy22;
   default:   goto yy9;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy9;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy19;
   default:   goto yy9;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy20;
   default:   goto yy9;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy23;
   default:   goto yy9;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy24;
   default:   goto yy9;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgDOSgRqSymType */

/*
    Func:  DOSgRqSymVal  ->     */
/*!re2c
[hH][dD]          { return (MGT_MGCP_PKG_D_O_SG_RQ_SYM_OFFHOOK); }
[hH][fF]          { return (MGT_MGCP_PKG_D_O_SG_RQ_SYM_HOOK_FLASH); }
[hH][uU]          { return (MGT_MGCP_PKG_D_O_SG_RQ_SYM_ONHOOK); }
[sS][uU][pP]          { return (MGT_MGCP_PKG_D_O_SG_RQ_SYM_CALL_SETUP); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgDOSgRqSymVal
*
*       Desc:  Description for the regular expression PkgDOSgRqSymVal
*              [hH][dD]          { return (MGT_MGCP_PKG_D_O_SG_RQ_SYM_OFFHOOK); }
*              [hH][fF]          { return (MGT_MGCP_PKG_D_O_SG_RQ_SYM_HOOK_FLASH); }
*              [hH][uU]          { return (MGT_MGCP_PKG_D_O_SG_RQ_SYM_ONHOOK); }
*              [sS][uU][pP]          { return (MGT_MGCP_PKG_D_O_SG_RQ_SYM_CALL_SETUP); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgDOSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgDOSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgDOSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy3;
   case 'S':   case 's':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy12;
   case 'F':   case 'f':   goto yy10;
   case 'U':   case 'u':   goto yy8;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_O_SG_RQ_SYM_CALL_SETUP;
      goto yyReturn;
    }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_O_SG_RQ_SYM_ONHOOK;
      goto yyReturn;
    }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_O_SG_RQ_SYM_HOOK_FLASH;
      goto yyReturn;
    }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_O_SG_RQ_SYM_OFFHOOK;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgDOSgRqSymVal */

#endif  /* GCP_PKG_MGCP_FXO_LSG_ANALOG */



#ifdef  GCP_PKG_MGCP_DTMF_DIAL_PULSE


/*
    Func:  DTRqEvSymType  ->     */
/*!re2c

               known = [aA][nN][sS] | [bB][lL] | [oO][cC] | [oO][fF] | [rR][eE][lL] | [rR][eE][sS] | [rR][lL][cC] | [sS][uU][pP] | [sS][uU][sS];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgDTRqEvSymType
*
*       Desc:  Description for the regular expression PkgDTRqEvSymType
*              
*                             known = [aA][nN][sS] | [bB][lL] | [oO][cC] | [oO][fF] | [rR][eE][lL] | [rR][eE][sS] | [rR][lL][cC] | [sS][uU][pP] | [sS][uU][sS];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgDTRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgDTRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgDTRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy13;
   case '*':   goto yy12;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'O':   case 'o':   goto yy5;
   case 'R':   case 'r':   goto yy6;
   case 'S':   case 's':   goto yy7;
   case '[':   goto yy8;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy26;
   case 'N':   case 'n':   goto yy27;
   default:   goto yy11;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy21;
   default:   goto yy11;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy21;
   default:   goto yy11;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy24;
   case 'L':   case 'l':   goto yy25;
   default:   goto yy11;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy20;
   default:   goto yy11;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy10:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy11:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy18;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'S':   case 'p':   case 's':   goto yy21;
   default:   goto yy11;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yy11;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'S':   case 'l':   case 's':   goto yy21;
   default:   goto yy11;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy21;
   default:   goto yy11;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy28;
   default:   goto yy11;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy21;
   default:   goto yy11;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy29;
   default:   goto yy11;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgDTRqEvSymType */

/*
    Func:  DTRqEvSymVal  ->     */
/*!re2c
[aA][nN][sS]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_CALL_ANSWER); }
[bB][lL]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_BLOCK); }
[oO][cC]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_OPER_FAIL); }
[rR][eE][lL]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_RELEASE_CALL); }
[rR][eE][sS]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_RESUME_CALL); }
[rR][lL][cC]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_RELEASE_COMPLT); }
[sS][uU][pP]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_CALL_SETUP); }
[sS][uU][sS]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_SUSPEND_CALL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgDTRqEvSymVal
*
*       Desc:  Description for the regular expression PkgDTRqEvSymVal
*              [aA][nN][sS]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_CALL_ANSWER); }
*              [bB][lL]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_BLOCK); }
*              [oO][cC]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_OPER_FAIL); }
*              [rR][eE][lL]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_RELEASE_CALL); }
*              [rR][eE][sS]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_RESUME_CALL); }
*              [rR][lL][cC]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_RELEASE_COMPLT); }
*              [sS][uU][pP]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_CALL_SETUP); }
*              [sS][uU][sS]          { return (MGT_MGCP_PKG_D_T_RQ_EV_SYM_SUSPEND_CALL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgDTRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgDTRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgDTRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'O':   case 'o':   goto yy5;
   case 'R':   case 'r':   goto yy6;
   case 'S':   case 's':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy27;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy25;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy23;
   case 'F':   case 'f':   goto yy21;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy14;
   case 'L':   case 'l':   goto yy13;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy9;
   case 'S':   case 's':   goto yy11;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_RQ_EV_SYM_CALL_SETUP;
      goto yyReturn;
    }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_RQ_EV_SYM_SUSPEND_CALL;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy19;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy15;
   case 'S':   case 's':   goto yy17;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_RQ_EV_SYM_RELEASE_CALL;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_RQ_EV_SYM_RESUME_CALL;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_RQ_EV_SYM_RELEASE_COMPLT;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_RQ_EV_SYM_BLOCK;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy28;
   default:   goto yyErr;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_RQ_EV_SYM_CALL_ANSWER;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgDTRqEvSymVal */

/*
    Func:  DTSgRqSymType  ->     */
/*!re2c

               known = [aA][nN][sS] | [bB][lL] | [bB][zZ] | [dD][lL] | [rR][eE][lL] | [rR][eE][sS] | [rR][lL][cC] | [rR][oO] | [rR][tT] | [sS][uU][pP] | [sS][uU][sS];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgDTSgRqSymType
*
*       Desc:  Description for the regular expression PkgDTSgRqSymType
*              
*                             known = [aA][nN][sS] | [bB][lL] | [bB][zZ] | [dD][lL] | [rR][eE][lL] | [rR][eE][sS] | [rR][lL][cC] | [rR][oO] | [rR][tT] | [sS][uU][pP] | [sS][uU][sS];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgDTSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgDTSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgDTSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy13;
   case '*':   goto yy12;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'C':   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'c':   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'D':   case 'd':   goto yy5;
   case 'R':   case 'r':   goto yy6;
   case 'S':   case 's':   goto yy7;
   case '[':   goto yy8;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy26;
   case 'N':   case 'n':   goto yy27;
   default:   goto yy11;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'Z':   case 'l':   case 'z':   goto yy21;
   default:   goto yy11;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy21;
   default:   goto yy11;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy24;
   case 'L':   case 'l':   goto yy25;
   case 'O':   case 'T':   case 'o':   case 't':   goto yy21;
   default:   goto yy11;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy20;
   default:   goto yy11;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy10:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy11:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy18;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'S':   case 'p':   case 's':   goto yy21;
   default:   goto yy11;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yy11;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'S':   case 'l':   case 's':   goto yy21;
   default:   goto yy11;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy21;
   default:   goto yy11;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy28;
   default:   goto yy11;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy21;
   default:   goto yy11;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy29;
   default:   goto yy11;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgDTSgRqSymType */

/*
    Func:  DTSgRqSymVal  ->     */
/*!re2c
[aA][nN][sS]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_CALL_ANSWER); }
[bB][lL]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_BLOCK); }
[bB][zZ]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_BUSY_TONE); }
[dD][lL]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_DIAL_TONE); }
[rR][eE][lL]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_RELEASE_CALL); }
[rR][eE][sS]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_RESUME_CALL); }
[rR][lL][cC]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_RELEASE_COMPLT); }
[rR][oO]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_REORDER_TONE); }
[rR][tT]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_RINGBACK_TONE); }
[sS][uU][pP]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_CALL_SETUP); }
[sS][uU][sS]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_SUSPEND_CALL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgDTSgRqSymVal
*
*       Desc:  Description for the regular expression PkgDTSgRqSymVal
*              [aA][nN][sS]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_CALL_ANSWER); }
*              [bB][lL]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_BLOCK); }
*              [bB][zZ]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_BUSY_TONE); }
*              [dD][lL]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_DIAL_TONE); }
*              [rR][eE][lL]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_RELEASE_CALL); }
*              [rR][eE][sS]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_RESUME_CALL); }
*              [rR][lL][cC]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_RELEASE_COMPLT); }
*              [rR][oO]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_REORDER_TONE); }
*              [rR][tT]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_RINGBACK_TONE); }
*              [sS][uU][pP]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_CALL_SETUP); }
*              [sS][uU][sS]          { return (MGT_MGCP_PKG_D_T_SG_RQ_SYM_SUSPEND_CALL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgDTSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgDTSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgDTSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'D':   case 'd':   goto yy5;
   case 'R':   case 'r':   goto yy6;
   case 'S':   case 's':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy31;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy29;
   case 'Z':   case 'z':   goto yy27;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy25;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy18;
   case 'L':   case 'l':   goto yy17;
   case 'O':   case 'o':   goto yy15;
   case 'T':   case 't':   goto yy13;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy9;
   case 'S':   case 's':   goto yy11;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_SG_RQ_SYM_CALL_SETUP;
      goto yyReturn;
    }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_SG_RQ_SYM_SUSPEND_CALL;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_SG_RQ_SYM_RINGBACK_TONE;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_SG_RQ_SYM_REORDER_TONE;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy23;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy19;
   case 'S':   case 's':   goto yy21;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_SG_RQ_SYM_RELEASE_CALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_SG_RQ_SYM_RESUME_CALL;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_SG_RQ_SYM_RELEASE_COMPLT;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_SG_RQ_SYM_DIAL_TONE;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_SG_RQ_SYM_BUSY_TONE;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_SG_RQ_SYM_BLOCK;
      goto yyReturn;
    }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy32;
   default:   goto yyErr;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_D_T_SG_RQ_SYM_CALL_ANSWER;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgDTSgRqSymVal */

#endif  /* GCP_PKG_MGCP_DTMF_DIAL_PULSE */




#ifdef  GCP_PKG_MGCP_GENERIC_MEDIA

/*
    Func:  GRqEvSymType  ->     */
/*!re2c

               known = [fF][tT] | [lL][dD] | [mM][tT] | [oO][cC] | [oO][fF] | [rR][tT] | [pP][aA][tT];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgGRqEvSymType
*
*       Desc:  Description for the regular expression PkgGRqEvSymType
*              
*                             known = [fF][tT] | [lL][dD] | [mM][tT] | [oO][cC] | [oO][fF] | [rR][tT] | [pP][aA][tT];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgGRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgGRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgGRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy15;
   case '*':   goto yy14;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':   case 'N':   case 'Q':   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':   case 'n':   case 'q':   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy12;
   case 'A':   case 'a':   goto yy9;
   case 'F':   case 'f':   goto yy3;
   case 'L':   case 'l':   goto yy4;
   case 'M':   case 'm':   goto yy5;
   case 'O':   case 'o':   goto yy6;
   case 'P':   case 'p':   goto yy8;
   case 'R':   case 'r':   goto yy7;
   case '[':   goto yy10;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy27;
   default:   goto yy13;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy27;
   default:   goto yy13;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy27;
   default:   goto yy13;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy27;
   default:   goto yy13;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy27;
   default:   goto yy13;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy26;
   default:   goto yy13;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy22;
   default:   goto yy13;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy12:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy13:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy20;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy12;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy18;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy23;
   default:   goto yy13;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy24;
   default:   goto yy13;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy27;
   default:   goto yy13;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy28;
   default:   goto yy13;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgGRqEvSymType */

/*
    Func:  GRqEvSymVal  ->     */
/*!re2c
[fF][tT]          { return (MGT_MGCP_PKG_G_RQ_EV_SYM_FAX_TONE_DETECT); }
[lL][dD]          { return (MGT_MGCP_PKG_G_RQ_EV_SYM_LONG_DUR_CONN); }
[mM][tT]          { return (MGT_MGCP_PKG_G_RQ_EV_SYM_MODEM_DETECT); }
[oO][cC]          { return (MGT_MGCP_PKG_G_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_G_RQ_EV_SYM_OPER_FAIL); }
[rR][tT]          { return (MGT_MGCP_PKG_G_RQ_EV_SYM_RINGBACK_TONE); }
[pP][aA][tT]          { return (MGT_MGCP_PKG_G_RQ_EV_SYM_PATTERN_DETECT); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgGRqEvSymVal
*
*       Desc:  Description for the regular expression PkgGRqEvSymVal
*              [fF][tT]          { return (MGT_MGCP_PKG_G_RQ_EV_SYM_FAX_TONE_DETECT); }
*              [lL][dD]          { return (MGT_MGCP_PKG_G_RQ_EV_SYM_LONG_DUR_CONN); }
*              [mM][tT]          { return (MGT_MGCP_PKG_G_RQ_EV_SYM_MODEM_DETECT); }
*              [oO][cC]          { return (MGT_MGCP_PKG_G_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_G_RQ_EV_SYM_OPER_FAIL); }
*              [rR][tT]          { return (MGT_MGCP_PKG_G_RQ_EV_SYM_RINGBACK_TONE); }
*              [pP][aA][tT]          { return (MGT_MGCP_PKG_G_RQ_EV_SYM_PATTERN_DETECT); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgGRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgGRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgGRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy3;
   case 'L':   case 'l':   goto yy4;
   case 'M':   case 'm':   goto yy5;
   case 'O':   case 'o':   goto yy6;
   case 'P':   case 'p':   goto yy8;
   case 'R':   case 'r':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy22;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy20;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy18;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy16;
   case 'F':   case 'f':   goto yy14;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy12;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_G_RQ_EV_SYM_PATTERN_DETECT;
      goto yyReturn;
    }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_G_RQ_EV_SYM_RINGBACK_TONE;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_G_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_G_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_G_RQ_EV_SYM_MODEM_DETECT;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_G_RQ_EV_SYM_LONG_DUR_CONN;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_G_RQ_EV_SYM_FAX_TONE_DETECT;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgGRqEvSymVal */

/*
    Func:  GSgRqSymType  ->     */
/*!re2c

               known = [cC][fF] | [cC][gG] | [iI][tT] | [pP][tT] | [rR][tT] | [rR][bB][kK] | [pP][aA][tT];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgGSgRqSymType
*
*       Desc:  Description for the regular expression PkgGSgRqSymType
*              
*                             known = [cC][fF] | [cC][gG] | [iI][tT] | [pP][tT] | [rR][tT] | [rR][bB][kK] | [pP][aA][tT];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgGSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgGSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgGSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy13;
   case '*':   goto yy12;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':   case 'Q':   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':   case 'q':   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   case 'A':   case 'a':   goto yy7;
   case 'C':   case 'c':   goto yy3;
   case 'I':   case 'i':   goto yy4;
   case 'P':   case 'p':   goto yy5;
   case 'R':   case 'r':   goto yy6;
   case '[':   goto yy8;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':
   case 'G':   case 'f':
   case 'g':   goto yy25;
   default:   goto yy11;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy25;
   default:   goto yy11;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy28;
   case 'T':   case 't':   goto yy25;
   default:   goto yy11;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy24;
   case 'T':   case 't':   goto yy25;
   default:   goto yy11;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy20;
   default:   goto yy11;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy10:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy11:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy18;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy21;
   default:   goto yy11;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yy11;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy25;
   default:   goto yy11;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy26;
   default:   goto yy11;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy25;
   default:   goto yy11;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgGSgRqSymType */

/*
    Func:  GSgRqSymVal  ->     */
/*!re2c
[cC][fF]          { return (MGT_MGCP_PKG_G_SG_RQ_SYM_CONFIRM_TONE); }
[cC][gG]          { return (MGT_MGCP_PKG_G_SG_RQ_SYM_CONGESTION_TONE); }
[iI][tT]          { return (MGT_MGCP_PKG_G_SG_RQ_SYM_INTERCEPT_TONE); }
[pP][tT]          { return (MGT_MGCP_PKG_G_SG_RQ_SYM_PREEMPTION_TONE); }
[rR][tT]          { return (MGT_MGCP_PKG_G_SG_RQ_SYM_RINGBACK_TONE); }
[rR][bB][kK]          { return (MGT_MGCP_PKG_G_SG_RQ_SYM_RINGBACK); }
[pP][aA][tT]          { return (MGT_MGCP_PKG_G_SG_RQ_SYM_PATTERN_DETECT); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgGSgRqSymVal
*
*       Desc:  Description for the regular expression PkgGSgRqSymVal
*              [cC][fF]          { return (MGT_MGCP_PKG_G_SG_RQ_SYM_CONFIRM_TONE); }
*              [cC][gG]          { return (MGT_MGCP_PKG_G_SG_RQ_SYM_CONGESTION_TONE); }
*              [iI][tT]          { return (MGT_MGCP_PKG_G_SG_RQ_SYM_INTERCEPT_TONE); }
*              [pP][tT]          { return (MGT_MGCP_PKG_G_SG_RQ_SYM_PREEMPTION_TONE); }
*              [rR][tT]          { return (MGT_MGCP_PKG_G_SG_RQ_SYM_RINGBACK_TONE); }
*              [rR][bB][kK]          { return (MGT_MGCP_PKG_G_SG_RQ_SYM_RINGBACK); }
*              [pP][aA][tT]          { return (MGT_MGCP_PKG_G_SG_RQ_SYM_PATTERN_DETECT); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgGSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgGSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgGSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy3;
   case 'I':   case 'i':   goto yy4;
   case 'P':   case 'p':   goto yy5;
   case 'R':   case 'r':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy21;
   case 'G':   case 'g':   goto yy19;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy17;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy12;
   case 'T':   case 't':   goto yy13;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy7;
   case 'T':   case 't':   goto yy8;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy10;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_G_SG_RQ_SYM_RINGBACK_TONE;
      goto yyReturn;
    }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_G_SG_RQ_SYM_RINGBACK;
      goto yyReturn;
    }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy15;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_G_SG_RQ_SYM_PREEMPTION_TONE;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_G_SG_RQ_SYM_PATTERN_DETECT;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_G_SG_RQ_SYM_INTERCEPT_TONE;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_G_SG_RQ_SYM_CONGESTION_TONE;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_G_SG_RQ_SYM_CONFIRM_TONE;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgGSgRqSymVal */

#endif  /* GCP_PKG_MGCP_GENERIC_MEDIA */




#ifdef  GCP_PKG_MGCP_HANDSET_EMUL

/*
    Func:  HRqEvSymType  ->     */
/*!re2c

               known = [aA][dD][sS][iI] | [aA][wW] | [bB][zZ] | [cC][iI] | [dD][lL] | [eE] | [hH][dD] | [hH][uU] | [hH][fF] | [hH][tT] | [mM][wW][iI] | [oO][cC] | [oO][tT] | [oO][fF] | [rR][gG] | [rR][0] | [rR][1] | [rR][2] | [rR][3] | [rR][4] | [rR][5] | [rR][6] | [rR][7] | [rR][oO] | [rR][sS] | [sS][lL] | [sS][iI][tT] | [vV] | [vV][mM][wW][iI] | [wW][tT] | [yY] | [zZ] | [pP] | [nN][bB][zZ] | [sS] | [lL][sS][aA] | [oO][sS][iI] | [wW][tT][1] | [wW][tT][2] | [wW][tT][3] | [wW][tT][4];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgHRqEvSymType
*
*       Desc:  Description for the regular expression PkgHRqEvSymType
*              
*                             known = [aA][dD][sS][iI] | [aA][wW] | [bB][zZ] | [cC][iI] | [dD][lL] | [eE] | [hH][dD] | [hH][uU] | [hH][fF] | [hH][tT] | [mM][wW][iI] | [oO][cC] | [oO][tT] | [oO][fF] | [rR][gG] | [rR][0] | [rR][1] | [rR][2] | [rR][3] | [rR][4] | [rR][5] | [rR][6] | [rR][7] | [rR][oO] | [rR][sS] | [sS][lL] | [sS][iI][tT] | [vV] | [vV][mM][wW][iI] | [wW][tT] | [yY] | [zZ] | [pP] | [nN][bB][zZ] | [sS] | [lL][sS][aA] | [oO][sS][iI] | [wW][tT][1] | [wW][tT][2] | [wW][tT][3] | [wW][tT][4];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgHRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgHRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgHRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy22;
   case '*':   goto yy21;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'F':
   case 'G':   case 'I':
   case 'J':
   case 'K':   case 'Q':   case 'T':
   case 'U':   case 'X':   case 'f':
   case 'g':   case 'i':
   case 'j':
   case 'k':   case 'q':   case 't':
   case 'u':   case 'x':   goto yy19;
   case 'A':   case 'a':   goto yy6;
   case 'B':   case 'b':   goto yy7;
   case 'C':   case 'c':   goto yy8;
   case 'D':   case 'd':   goto yy9;
   case 'E':   case 'P':   case 'Y':
   case 'Z':   case 'e':   case 'p':   case 'y':
   case 'z':   goto yy3;
   case 'H':   case 'h':   goto yy10;
   case 'L':   case 'l':   goto yy16;
   case 'M':   case 'm':   goto yy11;
   case 'N':   case 'n':   goto yy15;
   case 'O':   case 'o':   goto yy12;
   case 'R':   case 'r':   goto yy13;
   case 'S':   case 's':   goto yy4;
   case 'V':   case 'v':   goto yy5;
   case 'W':   case 'w':   goto yy14;
   case '[':   goto yy17;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy32;
   default:   goto yy20;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy32;
   case 'I':   case 'i':   goto yy44;
   case 'L':   case 'l':   goto yy3;
   default:   goto yy20;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy32;
   case 'M':   case 'm':   goto yy42;
   default:   goto yy20;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy36;
   case 'L':   case 'l':   goto yy37;
   case 'W':   case 'w':   goto yy3;
   default:   goto yy20;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy3;
   default:   goto yy20;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yy20;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy3;
   default:   goto yy20;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'F':   case 'T':
   case 'U':   case 'd':   case 'f':   case 't':
   case 'u':   goto yy3;
   default:   goto yy20;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy35;
   default:   goto yy20;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'T':   case 'c':   case 'f':   case 't':   goto yy3;
   case 'S':   case 's':   goto yy34;
   default:   goto yy20;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':   case 'G':   case 'O':   case 'S':   case 'g':   case 'o':   case 's':   goto yy3;
   default:   goto yy20;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy31;
   default:   goto yy20;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy30;
   default:   goto yy20;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy29;
   default:   goto yy20;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy19:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy20:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy27;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy19;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy25;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   default:   goto yy20;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy3;
   default:   goto yy20;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy32;
   case '1':
   case '2':
   case '3':
   case '4':   goto yy3;
   default:   goto yy20;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yy20;
   }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yy20;
   }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy41;
   default:   goto yy20;
   }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy38;
   default:   goto yy20;
   }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy39;
   default:   goto yy20;
   }
yy39:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy41:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yy20;
   }
yy42:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy43;
   default:   goto yy20;
   }
yy43:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yy20;
   }
yy44:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy3;
   default:   goto yy20;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgHRqEvSymType */

/*
    Func:  HRqEvSymVal  ->     */
/*!re2c
[aA][dD][sS][iI]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ADSI_DISPLAY); }
[aA][wW]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ANSWER_TONE); }
[bB][zZ]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_BUSY_TONE); }
[cC][iI]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_CALLER_ID); }
[dD][lL]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DIAL_TONE); }
[eE]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ERROR_TONE); }
[hH][dD]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_OFF_HOOK_TRANS); }
[hH][uU]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ON_HOOK_TRANS); }
[hH][fF]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_FLASH_HOOK); }
[hH][tT]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_TONE_ON_HOLD); }
[mM][wW][iI]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_MSG_WAITNG_IND); }
[oO][cC]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_OPER_COMPLT); }
[oO][tT]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_OFF_HOOK_WARNING_TONE); }
[oO][fF]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_REPORT_FAIL); }
[rR][gG]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_RINGING); }
[rR][0]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING0); }
[rR][1]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING1); }
[rR][2]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING2); }
[rR][3]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING3); }
[rR][4]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING4); }
[rR][5]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING5); }
[rR][6]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING6); }
[rR][7]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING7); }
[rR][oO]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_REORDER_TONE); }
[rR][sS]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_RINGSPLASH); }
[sS][lL]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_STUTTER_DIALTONE); }
[sS][iI][tT]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_SIT_TONE); }
[vV]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ALERTING_TONE); }
[vV][mM][wW][iI]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_VIS_MSG_WAITNG_IND); }
[wW][tT]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_CALL_WAITNG_TONE); }
[yY]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_RECORDER_WARNING_TONE); }
[zZ]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_CALLING_CARD_SERV_TONE); }
[pP]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_PROMPT_TONE); }
[nN][bB][zZ]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_NETWORK_BUSY); }
[sS]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCT_TONE_PATTERN); }
[lL][sS][aA]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_LINE_SIDE_ANSWER_SUP); }
[oO][sS][iI]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_NETWORK_DIS_CONN); }
[wW][tT][1]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL1); }
[wW][tT][2]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL2); }
[wW][tT][3]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL3); }
[wW][tT][4]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL4); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgHRqEvSymVal
*
*       Desc:  Description for the regular expression PkgHRqEvSymVal
*              [aA][dD][sS][iI]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ADSI_DISPLAY); }
*              [aA][wW]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ANSWER_TONE); }
*              [bB][zZ]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_BUSY_TONE); }
*              [cC][iI]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_CALLER_ID); }
*              [dD][lL]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DIAL_TONE); }
*              [eE]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ERROR_TONE); }
*              [hH][dD]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_OFF_HOOK_TRANS); }
*              [hH][uU]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ON_HOOK_TRANS); }
*              [hH][fF]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_FLASH_HOOK); }
*              [hH][tT]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_TONE_ON_HOLD); }
*              [mM][wW][iI]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_MSG_WAITNG_IND); }
*              [oO][cC]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][tT]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_OFF_HOOK_WARNING_TONE); }
*              [oO][fF]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_REPORT_FAIL); }
*              [rR][gG]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_RINGING); }
*              [rR][0]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING0); }
*              [rR][1]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING1); }
*              [rR][2]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING2); }
*              [rR][3]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING3); }
*              [rR][4]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING4); }
*              [rR][5]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING5); }
*              [rR][6]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING6); }
*              [rR][7]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING7); }
*              [rR][oO]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_REORDER_TONE); }
*              [rR][sS]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_RINGSPLASH); }
*              [sS][lL]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_STUTTER_DIALTONE); }
*              [sS][iI][tT]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_SIT_TONE); }
*              [vV]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ALERTING_TONE); }
*              [vV][mM][wW][iI]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_VIS_MSG_WAITNG_IND); }
*              [wW][tT]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_CALL_WAITNG_TONE); }
*              [yY]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_RECORDER_WARNING_TONE); }
*              [zZ]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_CALLING_CARD_SERV_TONE); }
*              [pP]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_PROMPT_TONE); }
*              [nN][bB][zZ]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_NETWORK_BUSY); }
*              [sS]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCT_TONE_PATTERN); }
*              [lL][sS][aA]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_LINE_SIDE_ANSWER_SUP); }
*              [oO][sS][iI]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_NETWORK_DIS_CONN); }
*              [wW][tT][1]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL1); }
*              [wW][tT][2]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL2); }
*              [wW][tT][3]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL3); }
*              [wW][tT][4]          { return (MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL4); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgHRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgHRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgHRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'C':   case 'c':   goto yy5;
   case 'D':   case 'd':   goto yy6;
   case 'E':   case 'e':   goto yy7;
   case 'H':   case 'h':   goto yy9;
   case 'L':   case 'l':   goto yy25;
   case 'M':   case 'm':   goto yy10;
   case 'N':   case 'n':   goto yy24;
   case 'O':   case 'o':   goto yy11;
   case 'P':   case 'p':   goto yy22;
   case 'R':   case 'r':   goto yy12;
   case 'S':   case 's':   goto yy13;
   case 'V':   case 'v':   goto yy15;
   case 'W':   case 'w':   goto yy17;
   case 'Y':   case 'y':   goto yy18;
   case 'Z':   case 'z':   goto yy20;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy101;
   case 'W':   case 'w':   goto yy99;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy97;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy95;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy93;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_ERROR_TONE;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy91;
   case 'F':   case 'f':   goto yy87;
   case 'T':   case 't':   goto yy85;
   case 'U':   case 'u':   goto yy89;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy82;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy78;
   case 'F':   case 'f':   goto yy74;
   case 'S':   case 's':   goto yy73;
   case 'T':   case 't':   goto yy76;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy69;
   case '1':   goto yy67;
   case '2':   goto yy65;
   case '3':   goto yy63;
   case '4':   goto yy61;
   case '5':   goto yy59;
   case '6':   goto yy57;
   case '7':   goto yy55;
   case 'G':   case 'g':   goto yy71;
   case 'O':   case 'o':   goto yy53;
   case 'S':   case 's':   goto yy51;
   default:   goto yyErr;
   }
yy13:   
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy46;
   case 'L':   case 'l':   goto yy47;
   default:   goto yy14;
   }
yy14:
   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCT_TONE_PATTERN;
      goto yyReturn;
    }
yy15:   
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy42;
   default:   goto yy16;
   }
yy16:
   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_ALERTING_TONE;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy32;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_RECORDER_WARNING_TONE;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_CALLING_CARD_SERV_TONE;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_PROMPT_TONE;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy29;
   default:   goto yyErr;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy26;
   default:   goto yyErr;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy27;
   default:   goto yyErr;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_LINE_SIDE_ANSWER_SUP;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy30;
   default:   goto yyErr;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_NETWORK_BUSY;
      goto yyReturn;
    }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy34;
   case '2':   goto yy36;
   case '3':   goto yy38;
   case '4':   goto yy40;
   default:   goto yy33;
   }
yy33:
   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_CALL_WAITNG_TONE;
      goto yyReturn;
    }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL1;
      goto yyReturn;
    }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL2;
      goto yyReturn;
    }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL3;
      goto yyReturn;
    }
yy40:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL4;
      goto yyReturn;
    }
yy42:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy43;
   default:   goto yyErr;
   }
yy43:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy44;
   default:   goto yyErr;
   }
yy44:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_VIS_MSG_WAITNG_IND;
      goto yyReturn;
    }
yy46:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy49;
   default:   goto yyErr;
   }
yy47:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_STUTTER_DIALTONE;
      goto yyReturn;
    }
yy49:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_SIT_TONE;
      goto yyReturn;
    }
yy51:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_RINGSPLASH;
      goto yyReturn;
    }
yy53:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_REORDER_TONE;
      goto yyReturn;
    }
yy55:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING7;
      goto yyReturn;
    }
yy57:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING6;
      goto yyReturn;
    }
yy59:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING5;
      goto yyReturn;
    }
yy61:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING4;
      goto yyReturn;
    }
yy63:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING3;
      goto yyReturn;
    }
yy65:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING2;
      goto yyReturn;
    }
yy67:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING1;
      goto yyReturn;
    }
yy69:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING0;
      goto yyReturn;
    }
yy71:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_RINGING;
      goto yyReturn;
    }
yy73:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy80;
   default:   goto yyErr;
   }
yy74:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_REPORT_FAIL;
      goto yyReturn;
    }
yy76:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_OFF_HOOK_WARNING_TONE;
      goto yyReturn;
    }
yy78:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }
yy80:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_NETWORK_DIS_CONN;
      goto yyReturn;
    }
yy82:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy83;
   default:   goto yyErr;
   }
yy83:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_MSG_WAITNG_IND;
      goto yyReturn;
    }
yy85:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_TONE_ON_HOLD;
      goto yyReturn;
    }
yy87:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_FLASH_HOOK;
      goto yyReturn;
    }
yy89:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_ON_HOOK_TRANS;
      goto yyReturn;
    }
yy91:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_OFF_HOOK_TRANS;
      goto yyReturn;
    }
yy93:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_DIAL_TONE;
      goto yyReturn;
    }
yy95:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_CALLER_ID;
      goto yyReturn;
    }
yy97:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_BUSY_TONE;
      goto yyReturn;
    }
yy99:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_ANSWER_TONE;
      goto yyReturn;
    }
yy101:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy102;
   default:   goto yyErr;
   }
yy102:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy103;
   default:   goto yyErr;
   }
yy103:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_RQ_EV_SYM_ADSI_DISPLAY;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgHRqEvSymVal */

/*
    Func:  HSgRqSymType  ->     */
/*!re2c

               known = [aA][dD][sS][iI] | [aA][wW] | [bB][zZ] | [cC][iI] | [dD][lL] | [eE] | [hH][dD] | [hH][uU] | [hH][fF] | [hH][tT] | [mM][wW][iI] | [oO][tT] | [rR][gG] | [rR][0] | [rR][1] | [rR][2] | [rR][3] | [rR][4] | [rR][5] | [rR][6] | [rR][7] | [rR][oO] | [rR][sS] | [sS][lL] | [sS][iI][tT] | [vV] | [vV][mM][wW][iI] | [wW][tT] | [yY] | [zZ] | [pP] | [nN][bB][zZ] | [sS] | [lL][sS][aA] | [oO][sS][iI] | [wW][tT][1] | [wW][tT][2] | [wW][tT][3] | [wW][tT][4];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgHSgRqSymType
*
*       Desc:  Description for the regular expression PkgHSgRqSymType
*              
*                             known = [aA][dD][sS][iI] | [aA][wW] | [bB][zZ] | [cC][iI] | [dD][lL] | [eE] | [hH][dD] | [hH][uU] | [hH][fF] | [hH][tT] | [mM][wW][iI] | [oO][tT] | [rR][gG] | [rR][0] | [rR][1] | [rR][2] | [rR][3] | [rR][4] | [rR][5] | [rR][6] | [rR][7] | [rR][oO] | [rR][sS] | [sS][lL] | [sS][iI][tT] | [vV] | [vV][mM][wW][iI] | [wW][tT] | [yY] | [zZ] | [pP] | [nN][bB][zZ] | [sS] | [lL][sS][aA] | [oO][sS][iI] | [wW][tT][1] | [wW][tT][2] | [wW][tT][3] | [wW][tT][4];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgHSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgHSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgHSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy22;
   case '*':   goto yy21;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'F':
   case 'G':   case 'I':
   case 'J':
   case 'K':   case 'Q':   case 'T':
   case 'U':   case 'X':   case 'f':
   case 'g':   case 'i':
   case 'j':
   case 'k':   case 'q':   case 't':
   case 'u':   case 'x':   goto yy19;
   case 'A':   case 'a':   goto yy6;
   case 'B':   case 'b':   goto yy7;
   case 'C':   case 'c':   goto yy8;
   case 'D':   case 'd':   goto yy9;
   case 'E':   case 'P':   case 'Y':
   case 'Z':   case 'e':   case 'p':   case 'y':
   case 'z':   goto yy3;
   case 'H':   case 'h':   goto yy10;
   case 'L':   case 'l':   goto yy16;
   case 'M':   case 'm':   goto yy11;
   case 'N':   case 'n':   goto yy15;
   case 'O':   case 'o':   goto yy12;
   case 'R':   case 'r':   goto yy13;
   case 'S':   case 's':   goto yy4;
   case 'V':   case 'v':   goto yy5;
   case 'W':   case 'w':   goto yy14;
   case '[':   goto yy17;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy32;
   default:   goto yy20;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy32;
   case 'I':   case 'i':   goto yy44;
   case 'L':   case 'l':   goto yy3;
   default:   goto yy20;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy32;
   case 'M':   case 'm':   goto yy42;
   default:   goto yy20;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy36;
   case 'L':   case 'l':   goto yy37;
   case 'W':   case 'w':   goto yy3;
   default:   goto yy20;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy3;
   default:   goto yy20;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yy20;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy3;
   default:   goto yy20;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'F':   case 'T':
   case 'U':   case 'd':   case 'f':   case 't':
   case 'u':   goto yy3;
   default:   goto yy20;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy35;
   default:   goto yy20;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy34;
   case 'T':   case 't':   goto yy3;
   default:   goto yy20;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':   case 'G':   case 'O':   case 'S':   case 'g':   case 'o':   case 's':   goto yy3;
   default:   goto yy20;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy31;
   default:   goto yy20;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy30;
   default:   goto yy20;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy29;
   default:   goto yy20;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy19:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy20:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy27;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy19;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy25;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   default:   goto yy20;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy3;
   default:   goto yy20;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy32;
   case '1':
   case '2':
   case '3':
   case '4':   goto yy3;
   default:   goto yy20;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yy20;
   }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yy20;
   }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy41;
   default:   goto yy20;
   }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy38;
   default:   goto yy20;
   }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy39;
   default:   goto yy20;
   }
yy39:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy41:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yy20;
   }
yy42:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy43;
   default:   goto yy20;
   }
yy43:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yy20;
   }
yy44:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy3;
   default:   goto yy20;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgHSgRqSymType */

/*
    Func:  HSgRqSymVal  ->     */
/*!re2c
[aA][dD][sS][iI]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ADSI_DISPLAY); }
[aA][wW]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ANSWER_TONE); }
[bB][zZ]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_BUSY_TONE); }
[cC][iI]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_CALLER_ID); }
[dD][lL]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DIAL_TONE); }
[eE]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ERROR_TONE); }
[hH][dD]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_OFF_HOOK_TRANS); }
[hH][uU]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ON_HOOK_TRANS); }
[hH][fF]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_FLASH_HOOK); }
[hH][tT]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_TONE_ON_HOLD); }
[mM][wW][iI]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_MSG_WAITNG_IND); }
[oO][tT]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_OFF_HOOK_WARNING_TONE); }
[rR][gG]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_RINGING); }
[rR][0]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING0); }
[rR][1]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING1); }
[rR][2]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING2); }
[rR][3]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING3); }
[rR][4]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING4); }
[rR][5]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING5); }
[rR][6]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING6); }
[rR][7]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING7); }
[rR][oO]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_REORDER_TONE); }
[rR][sS]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_RINGSPLASH); }
[sS][lL]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_STUTTER_DIALTONE); }
[sS][iI][tT]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_SIT_TONE); }
[vV]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ALERTING_TONE); }
[vV][mM][wW][iI]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_VIS_MSG_WAITNG_IND); }
[wW][tT]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_CALL_WAITNG_TONE); }
[yY]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_RECORDER_WARNING_TONE); }
[zZ]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_CALLING_CARD_SERV_TONE); }
[pP]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_PROMPT_TONE); }
[nN][bB][zZ]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_NETWORK_BUSY); }
[sS]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCT_TONE_PATTERN); }
[lL][sS][aA]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_LINE_SIDE_ANSWER_SUP); }
[oO][sS][iI]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_NETWORK_DIS_CONN); }
[wW][tT][1]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL1); }
[wW][tT][2]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL2); }
[wW][tT][3]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL3); }
[wW][tT][4]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL4); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgHSgRqSymVal
*
*       Desc:  Description for the regular expression PkgHSgRqSymVal
*              [aA][dD][sS][iI]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ADSI_DISPLAY); }
*              [aA][wW]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ANSWER_TONE); }
*              [bB][zZ]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_BUSY_TONE); }
*              [cC][iI]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_CALLER_ID); }
*              [dD][lL]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DIAL_TONE); }
*              [eE]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ERROR_TONE); }
*              [hH][dD]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_OFF_HOOK_TRANS); }
*              [hH][uU]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ON_HOOK_TRANS); }
*              [hH][fF]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_FLASH_HOOK); }
*              [hH][tT]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_TONE_ON_HOLD); }
*              [mM][wW][iI]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_MSG_WAITNG_IND); }
*              [oO][tT]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_OFF_HOOK_WARNING_TONE); }
*              [rR][gG]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_RINGING); }
*              [rR][0]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING0); }
*              [rR][1]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING1); }
*              [rR][2]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING2); }
*              [rR][3]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING3); }
*              [rR][4]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING4); }
*              [rR][5]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING5); }
*              [rR][6]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING6); }
*              [rR][7]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING7); }
*              [rR][oO]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_REORDER_TONE); }
*              [rR][sS]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_RINGSPLASH); }
*              [sS][lL]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_STUTTER_DIALTONE); }
*              [sS][iI][tT]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_SIT_TONE); }
*              [vV]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ALERTING_TONE); }
*              [vV][mM][wW][iI]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_VIS_MSG_WAITNG_IND); }
*              [wW][tT]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_CALL_WAITNG_TONE); }
*              [yY]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_RECORDER_WARNING_TONE); }
*              [zZ]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_CALLING_CARD_SERV_TONE); }
*              [pP]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_PROMPT_TONE); }
*              [nN][bB][zZ]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_NETWORK_BUSY); }
*              [sS]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCT_TONE_PATTERN); }
*              [lL][sS][aA]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_LINE_SIDE_ANSWER_SUP); }
*              [oO][sS][iI]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_NETWORK_DIS_CONN); }
*              [wW][tT][1]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL1); }
*              [wW][tT][2]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL2); }
*              [wW][tT][3]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL3); }
*              [wW][tT][4]          { return (MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL4); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgHSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgHSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgHSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'C':   case 'c':   goto yy5;
   case 'D':   case 'd':   goto yy6;
   case 'E':   case 'e':   goto yy7;
   case 'H':   case 'h':   goto yy9;
   case 'L':   case 'l':   goto yy25;
   case 'M':   case 'm':   goto yy10;
   case 'N':   case 'n':   goto yy24;
   case 'O':   case 'o':   goto yy11;
   case 'P':   case 'p':   goto yy22;
   case 'R':   case 'r':   goto yy12;
   case 'S':   case 's':   goto yy13;
   case 'V':   case 'v':   goto yy15;
   case 'W':   case 'w':   goto yy17;
   case 'Y':   case 'y':   goto yy18;
   case 'Z':   case 'z':   goto yy20;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy97;
   case 'W':   case 'w':   goto yy95;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy93;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy91;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy89;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_ERROR_TONE;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy87;
   case 'F':   case 'f':   goto yy83;
   case 'T':   case 't':   goto yy81;
   case 'U':   case 'u':   goto yy85;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy78;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy73;
   case 'T':   case 't':   goto yy74;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy69;
   case '1':   goto yy67;
   case '2':   goto yy65;
   case '3':   goto yy63;
   case '4':   goto yy61;
   case '5':   goto yy59;
   case '6':   goto yy57;
   case '7':   goto yy55;
   case 'G':   case 'g':   goto yy71;
   case 'O':   case 'o':   goto yy53;
   case 'S':   case 's':   goto yy51;
   default:   goto yyErr;
   }
yy13:   
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy46;
   case 'L':   case 'l':   goto yy47;
   default:   goto yy14;
   }
yy14:
   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCT_TONE_PATTERN;
      goto yyReturn;
    }
yy15:   
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy42;
   default:   goto yy16;
   }
yy16:
   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_ALERTING_TONE;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy32;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_RECORDER_WARNING_TONE;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_CALLING_CARD_SERV_TONE;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_PROMPT_TONE;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy29;
   default:   goto yyErr;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy26;
   default:   goto yyErr;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy27;
   default:   goto yyErr;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_LINE_SIDE_ANSWER_SUP;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy30;
   default:   goto yyErr;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_NETWORK_BUSY;
      goto yyReturn;
    }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy34;
   case '2':   goto yy36;
   case '3':   goto yy38;
   case '4':   goto yy40;
   default:   goto yy33;
   }
yy33:
   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_CALL_WAITNG_TONE;
      goto yyReturn;
    }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL1;
      goto yyReturn;
    }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL2;
      goto yyReturn;
    }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL3;
      goto yyReturn;
    }
yy40:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL4;
      goto yyReturn;
    }
yy42:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy43;
   default:   goto yyErr;
   }
yy43:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy44;
   default:   goto yyErr;
   }
yy44:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_VIS_MSG_WAITNG_IND;
      goto yyReturn;
    }
yy46:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy49;
   default:   goto yyErr;
   }
yy47:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_STUTTER_DIALTONE;
      goto yyReturn;
    }
yy49:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_SIT_TONE;
      goto yyReturn;
    }
yy51:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_RINGSPLASH;
      goto yyReturn;
    }
yy53:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_REORDER_TONE;
      goto yyReturn;
    }
yy55:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING7;
      goto yyReturn;
    }
yy57:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING6;
      goto yyReturn;
    }
yy59:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING5;
      goto yyReturn;
    }
yy61:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING4;
      goto yyReturn;
    }
yy63:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING3;
      goto yyReturn;
    }
yy65:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING2;
      goto yyReturn;
    }
yy67:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING1;
      goto yyReturn;
    }
yy69:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING0;
      goto yyReturn;
    }
yy71:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_RINGING;
      goto yyReturn;
    }
yy73:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy76;
   default:   goto yyErr;
   }
yy74:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_OFF_HOOK_WARNING_TONE;
      goto yyReturn;
    }
yy76:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_NETWORK_DIS_CONN;
      goto yyReturn;
    }
yy78:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy79;
   default:   goto yyErr;
   }
yy79:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_MSG_WAITNG_IND;
      goto yyReturn;
    }
yy81:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_TONE_ON_HOLD;
      goto yyReturn;
    }
yy83:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_FLASH_HOOK;
      goto yyReturn;
    }
yy85:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_ON_HOOK_TRANS;
      goto yyReturn;
    }
yy87:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_OFF_HOOK_TRANS;
      goto yyReturn;
    }
yy89:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_DIAL_TONE;
      goto yyReturn;
    }
yy91:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_CALLER_ID;
      goto yyReturn;
    }
yy93:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_BUSY_TONE;
      goto yyReturn;
    }
yy95:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_ANSWER_TONE;
      goto yyReturn;
    }
yy97:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy98;
   default:   goto yyErr;
   }
yy98:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy99;
   default:   goto yyErr;
   }
yy99:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_H_SG_RQ_SYM_ADSI_DISPLAY;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgHSgRqSymVal */

#endif  /* GCP_PKG_MGCP_HANDSET_EMUL */




#ifdef  GCP_PKG_MGCP_LINE

/*
    Func:  LRqEvSymType  ->     */
/*!re2c

               known = [aA][wW] | [eE] | [hH][dD] | [hH][uU] | [hH][fF] | [oO][cC] | [oO][fF] | [pP] | [nN][bB][zZ] | [sS];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgLRqEvSymType
*
*       Desc:  Description for the regular expression PkgLRqEvSymType
*              
*                             known = [aA][wW] | [eE] | [hH][dD] | [hH][uU] | [hH][fF] | [oO][cC] | [oO][fF] | [pP] | [nN][bB][zZ] | [sS];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgLRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgLRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgLRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy13;
   case '*':   goto yy12;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':   case 'F':
   case 'G':   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':   case 'Q':
   case 'R':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':   case 'f':
   case 'g':   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':   case 'q':
   case 'r':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   case 'A':   case 'a':   goto yy4;
   case 'E':   case 'P':   case 'S':   case 'e':   case 'p':   case 's':   goto yy3;
   case 'H':   case 'h':   goto yy5;
   case 'N':   case 'n':   goto yy7;
   case 'O':   case 'o':   goto yy6;
   case '[':   goto yy8;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy25;
   default:   goto yy11;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy21;
   case 'W':   case 'w':   goto yy3;
   default:   goto yy11;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'F':   case 'U':   case 'd':   case 'f':   case 'u':   goto yy3;
   default:   goto yy11;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy3;
   default:   goto yy11;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy20;
   default:   goto yy11;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy10:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy11:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy18;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy3;
   default:   goto yy11;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy22;
   default:   goto yy11;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yy11;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgLRqEvSymType */

/*
    Func:  LRqEvSymVal  ->     */
/*!re2c
[aA][wW]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_ANSWER_TONE); }
[eE]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_ERROR_TONE); }
[hH][dD]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_OFF_HOOK_TRANS); }
[hH][uU]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_ON_HOOK_TRANS); }
[hH][fF]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_FLASH_HOOK); }
[oO][cC]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_OPER_FAIL); }
[pP]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_PROMPT_TONE); }
[nN][bB][zZ]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_NETWORK_BUSY); }
[sS]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_DISTINCT_TONE_PATTERN); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgLRqEvSymVal
*
*       Desc:  Description for the regular expression PkgLRqEvSymVal
*              [aA][wW]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_ANSWER_TONE); }
*              [eE]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_ERROR_TONE); }
*              [hH][dD]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_OFF_HOOK_TRANS); }
*              [hH][uU]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_ON_HOOK_TRANS); }
*              [hH][fF]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_FLASH_HOOK); }
*              [oO][cC]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_OPER_FAIL); }
*              [pP]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_PROMPT_TONE); }
*              [nN][bB][zZ]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_NETWORK_BUSY); }
*              [sS]          { return (MGT_MGCP_PKG_L_RQ_EV_SYM_DISTINCT_TONE_PATTERN); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgLRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgLRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgLRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   case 'E':   case 'e':   goto yy4;
   case 'H':   case 'h':   goto yy6;
   case 'N':   case 'n':   goto yy10;
   case 'O':   case 'o':   goto yy7;
   case 'P':   case 'p':   goto yy8;
   case 'S':   case 's':   goto yy11;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy26;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_RQ_EV_SYM_ERROR_TONE;
      goto yyReturn;
    }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy24;
   case 'F':   case 'f':   goto yy20;
   case 'U':   case 'u':   goto yy22;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy18;
   case 'F':   case 'f':   goto yy16;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_RQ_EV_SYM_PROMPT_TONE;
      goto yyReturn;
    }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy13;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_RQ_EV_SYM_DISTINCT_TONE_PATTERN;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_RQ_EV_SYM_NETWORK_BUSY;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_RQ_EV_SYM_FLASH_HOOK;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_RQ_EV_SYM_ON_HOOK_TRANS;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_RQ_EV_SYM_OFF_HOOK_TRANS;
      goto yyReturn;
    }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_RQ_EV_SYM_ANSWER_TONE;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgLRqEvSymVal */



/*
    Func:  LSgRqSymType  ->     */
/*!re2c

               known = [aA][dD][sS][iI] | [aA][wW] | [bB][zZ] | [cC][iI] | [dD][lL] | [eE] | [hH][tT] | [lL][sS][aA] | [mM][wW][iI] | [oO][sS][iI] | [oO][tT] | [rR][gG] | [rR][0] | [rR][1] | [rR][2] | [rR][3] | [rR][4] | [rR][5] | [rR][6] | [rR][7] | [rR][oO] | [rR][sS] | [sS][iI][tT] | [sS][lL] | [vV] | [vV][mM][wW][iI] | [wW][tT] | [wW][tT][1] | [wW][tT][2] | [wW][tT][3] | [wW][tT][4] | [yY] | [zZ] | [pP] | [nN][bB][zZ] | [sS];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgLSgRqSymType
*
*       Desc:  Description for the regular expression PkgLSgRqSymType
*              
*                             known = [aA][dD][sS][iI] | [aA][wW] | [bB][zZ] | [cC][iI] | [dD][lL] | [eE] | [hH][tT] | [lL][sS][aA] | [mM][wW][iI] | [oO][sS][iI] | [oO][tT] | [rR][gG] | [rR][0] | [rR][1] | [rR][2] | [rR][3] | [rR][4] | [rR][5] | [rR][6] | [rR][7] | [rR][oO] | [rR][sS] | [sS][iI][tT] | [sS][lL] | [vV] | [vV][mM][wW][iI] | [wW][tT] | [wW][tT][1] | [wW][tT][2] | [wW][tT][3] | [wW][tT][4] | [yY] | [zZ] | [pP] | [nN][bB][zZ] | [sS];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgLSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgLSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgLSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy22;
   case '*':   goto yy21;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'F':
   case 'G':   case 'I':
   case 'J':
   case 'K':   case 'Q':   case 'T':
   case 'U':   case 'X':   case 'f':
   case 'g':   case 'i':
   case 'j':
   case 'k':   case 'q':   case 't':
   case 'u':   case 'x':   goto yy19;
   case 'A':   case 'a':   goto yy6;
   case 'B':   case 'b':   goto yy7;
   case 'C':   case 'c':   goto yy8;
   case 'D':   case 'd':   goto yy9;
   case 'E':   case 'P':   case 'Y':
   case 'Z':   case 'e':   case 'p':   case 'y':
   case 'z':   goto yy3;
   case 'H':   case 'h':   goto yy10;
   case 'L':   case 'l':   goto yy11;
   case 'M':   case 'm':   goto yy12;
   case 'N':   case 'n':   goto yy16;
   case 'O':   case 'o':   goto yy13;
   case 'R':   case 'r':   goto yy14;
   case 'S':   case 's':   goto yy4;
   case 'V':   case 'v':   goto yy5;
   case 'W':   case 'w':   goto yy15;
   case '[':   goto yy17;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   default:   goto yy20;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   case 'I':   case 'i':   goto yy44;
   case 'L':   case 'l':   goto yy3;
   default:   goto yy20;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   case 'M':   case 'm':   goto yy42;
   default:   goto yy20;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy36;
   case 'L':   case 'l':   goto yy37;
   case 'W':   case 'w':   goto yy3;
   default:   goto yy20;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy3;
   default:   goto yy20;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yy20;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy3;
   default:   goto yy20;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy3;
   default:   goto yy20;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy35;
   default:   goto yy20;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy34;
   default:   goto yy20;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy33;
   case 'T':   case 't':   goto yy3;
   default:   goto yy20;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':   case 'G':   case 'O':   case 'S':   case 'g':   case 'o':   case 's':   goto yy3;
   default:   goto yy20;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy30;
   default:   goto yy20;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy29;
   default:   goto yy20;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy19:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy20:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy27;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy19;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy25;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy3;
   default:   goto yy20;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   case '1':
   case '2':
   case '3':
   case '4':   goto yy3;
   default:   goto yy20;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yy20;
   }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yy20;
   }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   default:   goto yy20;
   }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy41;
   default:   goto yy20;
   }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy38;
   default:   goto yy20;
   }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy39;
   default:   goto yy20;
   }
yy39:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy41:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yy20;
   }
yy42:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy43;
   default:   goto yy20;
   }
yy43:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yy20;
   }
yy44:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy3;
   default:   goto yy20;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgLSgRqSymType */



/*
    Func:  LSgRqSymVal  ->     */
/*!re2c
[aA][dD][sS][iI]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ADSI_DISPLAY); }
[aA][wW]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ANSWER_TONE); }
[bB][zZ]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_BUSY_TONE); }
[cC][iI]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_CALLER_ID); }
[dD][lL]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DIAL_TONE); }
[eE]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ERROR_TONE); }
[hH][tT]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ON_HOLD_TONE); }
[lL][sS][aA]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_LINE_SIDE_ANSWER_SUP); }
[mM][wW][iI]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_MSG_WAITNG_IND); }
[oO][sS][iI]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_NETWORK_DIS_CONN); }
[oO][tT]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_OFF_HOOK_WARNING_TONE); }
[rR][gG]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_RINGING); }
[rR][0]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING0); }
[rR][1]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING1); }
[rR][2]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING2); }
[rR][3]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING3); }
[rR][4]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING4); }
[rR][5]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING5); }
[rR][6]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING6); }
[rR][7]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING7); }
[rR][oO]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_REORDER_TONE); }
[rR][sS]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_RINGSPLASH); }
[sS][iI][tT]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_SPECIAL_INFO_TONE); }
[sS][lL]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_STUTTER_DIALTONE); }
[vV]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ALERTING_TONE); }
[vV][mM][wW][iI]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_VISUAL_MSG); }
[wW][tT]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_CALL_WAITNG_TONE); }
[wW][tT][1]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL1); }
[wW][tT][2]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL2); }
[wW][tT][3]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL3); }
[wW][tT][4]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL4); }
[yY]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_RECORDER_WARNING_TONE); }
[zZ]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_CALLING_CARD_SERVICE_TONE); }
[pP]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_PROMPT_TONE); }
[nN][bB][zZ]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_NETWORK_BUSY); }
[sS]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCT_TONE_PATTERN); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgLSgRqSymVal
*
*       Desc:  Description for the regular expression PkgLSgRqSymVal
*              [aA][dD][sS][iI]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ADSI_DISPLAY); }
*              [aA][wW]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ANSWER_TONE); }
*              [bB][zZ]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_BUSY_TONE); }
*              [cC][iI]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_CALLER_ID); }
*              [dD][lL]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DIAL_TONE); }
*              [eE]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ERROR_TONE); }
*              [hH][tT]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ON_HOLD_TONE); }
*              [lL][sS][aA]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_LINE_SIDE_ANSWER_SUP); }
*              [mM][wW][iI]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_MSG_WAITNG_IND); }
*              [oO][sS][iI]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_NETWORK_DIS_CONN); }
*              [oO][tT]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_OFF_HOOK_WARNING_TONE); }
*              [rR][gG]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_RINGING); }
*              [rR][0]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING0); }
*              [rR][1]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING1); }
*              [rR][2]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING2); }
*              [rR][3]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING3); }
*              [rR][4]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING4); }
*              [rR][5]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING5); }
*              [rR][6]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING6); }
*              [rR][7]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING7); }
*              [rR][oO]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_REORDER_TONE); }
*              [rR][sS]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_RINGSPLASH); }
*              [sS][iI][tT]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_SPECIAL_INFO_TONE); }
*              [sS][lL]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_STUTTER_DIALTONE); }
*              [vV]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ALERTING_TONE); }
*              [vV][mM][wW][iI]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_VISUAL_MSG); }
*              [wW][tT]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_CALL_WAITNG_TONE); }
*              [wW][tT][1]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL1); }
*              [wW][tT][2]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL2); }
*              [wW][tT][3]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL3); }
*              [wW][tT][4]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL4); }
*              [yY]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_RECORDER_WARNING_TONE); }
*              [zZ]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_CALLING_CARD_SERVICE_TONE); }
*              [pP]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_PROMPT_TONE); }
*              [nN][bB][zZ]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_NETWORK_BUSY); }
*              [sS]          { return (MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCT_TONE_PATTERN); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgLSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgLSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgLSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'C':   case 'c':   goto yy5;
   case 'D':   case 'd':   goto yy6;
   case 'E':   case 'e':   goto yy7;
   case 'H':   case 'h':   goto yy9;
   case 'L':   case 'l':   goto yy10;
   case 'M':   case 'm':   goto yy11;
   case 'N':   case 'n':   goto yy25;
   case 'O':   case 'o':   goto yy12;
   case 'P':   case 'p':   goto yy23;
   case 'R':   case 'r':   goto yy13;
   case 'S':   case 's':   goto yy14;
   case 'V':   case 'v':   goto yy16;
   case 'W':   case 'w':   goto yy18;
   case 'Y':   case 'y':   goto yy19;
   case 'Z':   case 'z':   goto yy21;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy91;
   case 'W':   case 'w':   goto yy89;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy87;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy85;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy83;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_ERROR_TONE;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy81;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy78;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy75;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy72;
   case 'T':   case 't':   goto yy70;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy66;
   case '1':   goto yy64;
   case '2':   goto yy62;
   case '3':   goto yy60;
   case '4':   goto yy58;
   case '5':   goto yy56;
   case '6':   goto yy54;
   case '7':   goto yy52;
   case 'G':   case 'g':   goto yy68;
   case 'O':   case 'o':   goto yy50;
   case 'S':   case 's':   goto yy48;
   default:   goto yyErr;
   }
yy14:   
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy45;
   case 'L':   case 'l':   goto yy43;
   default:   goto yy15;
   }
yy15:
   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCT_TONE_PATTERN;
      goto yyReturn;
    }
yy16:   
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy39;
   default:   goto yy17;
   }
yy17:
   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_ALERTING_TONE;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy29;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_RECORDER_WARNING_TONE;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_CALLING_CARD_SERVICE_TONE;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_PROMPT_TONE;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy26;
   default:   goto yyErr;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy27;
   default:   goto yyErr;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_NETWORK_BUSY;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy31;
   case '2':   goto yy33;
   case '3':   goto yy35;
   case '4':   goto yy37;
   default:   goto yy30;
   }
yy30:
   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_CALL_WAITNG_TONE;
      goto yyReturn;
    }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL1;
      goto yyReturn;
    }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL2;
      goto yyReturn;
    }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL3;
      goto yyReturn;
    }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL4;
      goto yyReturn;
    }
yy39:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy40;
   default:   goto yyErr;
   }
yy40:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy41;
   default:   goto yyErr;
   }
yy41:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_VISUAL_MSG;
      goto yyReturn;
    }
yy43:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_STUTTER_DIALTONE;
      goto yyReturn;
    }
yy45:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy46;
   default:   goto yyErr;
   }
yy46:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_SPECIAL_INFO_TONE;
      goto yyReturn;
    }
yy48:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_RINGSPLASH;
      goto yyReturn;
    }
yy50:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_REORDER_TONE;
      goto yyReturn;
    }
yy52:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING7;
      goto yyReturn;
    }
yy54:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING6;
      goto yyReturn;
    }
yy56:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING5;
      goto yyReturn;
    }
yy58:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING4;
      goto yyReturn;
    }
yy60:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING3;
      goto yyReturn;
    }
yy62:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING2;
      goto yyReturn;
    }
yy64:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING1;
      goto yyReturn;
    }
yy66:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING0;
      goto yyReturn;
    }
yy68:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_RINGING;
      goto yyReturn;
    }
yy70:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_OFF_HOOK_WARNING_TONE;
      goto yyReturn;
    }
yy72:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy73;
   default:   goto yyErr;
   }
yy73:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_NETWORK_DIS_CONN;
      goto yyReturn;
    }
yy75:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy76;
   default:   goto yyErr;
   }
yy76:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_MSG_WAITNG_IND;
      goto yyReturn;
    }
yy78:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy79;
   default:   goto yyErr;
   }
yy79:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_LINE_SIDE_ANSWER_SUP;
      goto yyReturn;
    }
yy81:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_ON_HOLD_TONE;
      goto yyReturn;
    }
yy83:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_DIAL_TONE;
      goto yyReturn;
    }
yy85:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_CALLER_ID;
      goto yyReturn;
    }
yy87:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_BUSY_TONE;
      goto yyReturn;
    }
yy89:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_ANSWER_TONE;
      goto yyReturn;
    }
yy91:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy92;
   default:   goto yyErr;
   }
yy92:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy93;
   default:   goto yyErr;
   }
yy93:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_L_SG_RQ_SYM_ADSI_DISPLAY;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgLSgRqSymVal */

#endif  /* GCP_PKG_MGCP_LINE */



#ifdef  GCP_PKG_MGCP_NAM_MF_GRP_DE


/*
    Func:  MDRqEvSymType  ->     */
/*!re2c

               known = [aA][nN][sS] | [aA][wW][kK] | [bB][lL] | [iI][nN][fF] | [oO][cC] | [oO][fF] | [rR][eE][lL] | [rR][eE][sS] | [rR][lL][cC] | [sS][uU][pP] | [sS][uU][sS] | [sS][wW][kK];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMDRqEvSymType
*
*       Desc:  Description for the regular expression PkgMDRqEvSymType
*              
*                             known = [aA][nN][sS] | [aA][wW][kK] | [bB][lL] | [iI][nN][fF] | [oO][cC] | [oO][fF] | [rR][eE][lL] | [rR][eE][sS] | [rR][lL][cC] | [sS][uU][pP] | [sS][uU][sS] | [sS][wW][kK];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMDRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMDRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMDRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy14;
   case '*':   goto yy13;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'I':   case 'i':   goto yy5;
   case 'O':   case 'o':   goto yy6;
   case 'R':   case 'r':   goto yy7;
   case 'S':   case 's':   goto yy8;
   case '[':   goto yy9;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy29;
   case 'N':   case 'n':   goto yy30;
   case 'W':   case 'w':   goto yy31;
   default:   goto yy12;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy23;
   default:   goto yy12;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy28;
   default:   goto yy12;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy23;
   default:   goto yy12;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy26;
   case 'L':   case 'l':   goto yy27;
   default:   goto yy12;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy21;
   case 'W':   case 'w':   goto yy22;
   default:   goto yy12;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy11:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy12:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy17;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'S':   case 'p':   case 's':   goto yy23;
   default:   goto yy12;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy23;
   default:   goto yy12;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy24;
   default:   goto yy12;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'S':   case 'l':   case 's':   goto yy23;
   default:   goto yy12;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy23;
   default:   goto yy12;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy23;
   default:   goto yy12;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy32;
   default:   goto yy12;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy23;
   default:   goto yy12;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy23;
   default:   goto yy12;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy33;
   default:   goto yy12;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMDRqEvSymType */

/*
    Func:  MDRqEvSymVal  ->     */
/*!re2c
[aA][nN][sS]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_CALL_ANSWER); }
[aA][wW][kK]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_ACK_WINK); }
[bB][lL]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_CALL_BLOCK); }
[iI][nN][fF]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_INFO_DGTS); }
[oO][cC]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_OPER_FAIL); }
[rR][eE][lL]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_RELEASE_CALL); }
[rR][eE][sS]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_RESUME_CALL); }
[rR][lL][cC]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_RELEASE_COMPLT); }
[sS][uU][pP]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_CALL_SETUP); }
[sS][uU][sS]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_SUSPEND_CALL); }
[sS][wW][kK]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_START_WINK); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMDRqEvSymVal
*
*       Desc:  Description for the regular expression PkgMDRqEvSymVal
*              [aA][nN][sS]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_CALL_ANSWER); }
*              [aA][wW][kK]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_ACK_WINK); }
*              [bB][lL]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_CALL_BLOCK); }
*              [iI][nN][fF]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_INFO_DGTS); }
*              [oO][cC]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_OPER_FAIL); }
*              [rR][eE][lL]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_RELEASE_CALL); }
*              [rR][eE][sS]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_RESUME_CALL); }
*              [rR][lL][cC]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_RELEASE_COMPLT); }
*              [sS][uU][pP]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_CALL_SETUP); }
*              [sS][uU][sS]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_SUSPEND_CALL); }
*              [sS][wW][kK]          { return (MGT_MGCP_PKG_M_D_RQ_EV_SYM_START_WINK); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMDRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMDRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMDRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'I':   case 'i':   goto yy5;
   case 'O':   case 'o':   goto yy6;
   case 'R':   case 'r':   goto yy7;
   case 'S':   case 's':   goto yy8;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy35;
   case 'W':   case 'w':   goto yy34;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy32;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy29;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy27;
   case 'F':   case 'f':   goto yy25;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy18;
   case 'L':   case 'l':   goto yy17;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy10;
   case 'W':   case 'w':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy15;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy11;
   case 'S':   case 's':   goto yy13;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_RQ_EV_SYM_CALL_SETUP;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_RQ_EV_SYM_SUSPEND_CALL;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_RQ_EV_SYM_START_WINK;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy23;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy19;
   case 'S':   case 's':   goto yy21;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_RQ_EV_SYM_RELEASE_CALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_RQ_EV_SYM_RESUME_CALL;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_RQ_EV_SYM_RELEASE_COMPLT;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy30;
   default:   goto yyErr;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_RQ_EV_SYM_INFO_DGTS;
      goto yyReturn;
    }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_RQ_EV_SYM_CALL_BLOCK;
      goto yyReturn;
    }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy38;
   default:   goto yyErr;
   }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy36;
   default:   goto yyErr;
   }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_RQ_EV_SYM_CALL_ANSWER;
      goto yyReturn;
    }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_RQ_EV_SYM_ACK_WINK;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMDRqEvSymVal */

/*
    Func:  MDSgRqSymType  ->     */
/*!re2c

               known = [aA][nN][sS] | [aA][wW][kK] | [bB][lL] | [bB][zZ] | [cC][wW][kK] | [iI][nN][fF] | [rR][eE][lL] | [rR][eE][sS] | [rR][lL][cC] | [rR][oO] | [rR][tT] | [sS][uU][pP] | [sS][uU][sS];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMDSgRqSymType
*
*       Desc:  Description for the regular expression PkgMDSgRqSymType
*              
*                             known = [aA][nN][sS] | [aA][wW][kK] | [bB][lL] | [bB][zZ] | [cC][wW][kK] | [iI][nN][fF] | [rR][eE][lL] | [rR][eE][sS] | [rR][lL][cC] | [rR][oO] | [rR][tT] | [sS][uU][pP] | [sS][uU][sS];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMDSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMDSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMDSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy14;
   case '*':   goto yy13;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'C':   case 'c':   goto yy5;
   case 'I':   case 'i':   goto yy6;
   case 'R':   case 'r':   goto yy7;
   case 'S':   case 's':   goto yy8;
   case '[':   goto yy9;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy29;
   case 'N':   case 'n':   goto yy30;
   case 'W':   case 'w':   goto yy31;
   default:   goto yy12;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'Z':   case 'l':   case 'z':   goto yy22;
   default:   goto yy12;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy28;
   default:   goto yy12;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy27;
   default:   goto yy12;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy25;
   case 'L':   case 'l':   goto yy26;
   case 'O':   case 'T':   case 'o':   case 't':   goto yy22;
   default:   goto yy12;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy21;
   default:   goto yy12;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy11:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy12:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy17;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'S':   case 'p':   case 's':   goto yy22;
   default:   goto yy12;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yy12;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'S':   case 'l':   case 's':   goto yy22;
   default:   goto yy12;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy22;
   default:   goto yy12;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy22;
   default:   goto yy12;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy22;
   default:   goto yy12;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy32;
   default:   goto yy12;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy22;
   default:   goto yy12;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy22;
   default:   goto yy12;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy33;
   default:   goto yy12;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMDSgRqSymType */

/*
    Func:  MDSgRqSymVal  ->     */
/*!re2c
[aA][nN][sS]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_CALL_ANSWER); }
[aA][wW][kK]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_ACK_WINK); }
[bB][lL]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_CALL_BLOCK); }
[bB][zZ]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_BUSY_TONE); }
[cC][wW][kK]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_CONTINUE_WINK); }
[iI][nN][fF]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_INFO_DGTS); }
[rR][eE][lL]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_RELEASE_CALL); }
[rR][eE][sS]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_RESUME_CALL); }
[rR][lL][cC]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_RELEASE_COMPLETE); }
[rR][oO]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_REORDER_TONE); }
[rR][tT]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_RINGBACK_TONE); }
[sS][uU][pP]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_CALL_SETUP); }
[sS][uU][sS]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_SUSPEND_CALL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMDSgRqSymVal
*
*       Desc:  Description for the regular expression PkgMDSgRqSymVal
*              [aA][nN][sS]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_CALL_ANSWER); }
*              [aA][wW][kK]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_ACK_WINK); }
*              [bB][lL]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_CALL_BLOCK); }
*              [bB][zZ]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_BUSY_TONE); }
*              [cC][wW][kK]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_CONTINUE_WINK); }
*              [iI][nN][fF]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_INFO_DGTS); }
*              [rR][eE][lL]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_RELEASE_CALL); }
*              [rR][eE][sS]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_RESUME_CALL); }
*              [rR][lL][cC]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_RELEASE_COMPLETE); }
*              [rR][oO]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_REORDER_TONE); }
*              [rR][tT]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_RINGBACK_TONE); }
*              [sS][uU][pP]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_CALL_SETUP); }
*              [sS][uU][sS]          { return (MGT_MGCP_PKG_M_D_SG_RQ_SYM_SUSPEND_CALL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMDSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMDSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMDSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'C':   case 'c':   goto yy5;
   case 'I':   case 'i':   goto yy6;
   case 'R':   case 'r':   goto yy7;
   case 'S':   case 's':   goto yy8;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy37;
   case 'W':   case 'w':   goto yy36;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy34;
   case 'Z':   case 'z':   goto yy32;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy29;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy26;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy19;
   case 'L':   case 'l':   goto yy18;
   case 'O':   case 'o':   goto yy16;
   case 'T':   case 't':   goto yy14;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy10;
   case 'S':   case 's':   goto yy12;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_SG_RQ_SYM_CALL_SETUP;
      goto yyReturn;
    }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_SG_RQ_SYM_SUSPEND_CALL;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_SG_RQ_SYM_RINGBACK_TONE;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_SG_RQ_SYM_REORDER_TONE;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy24;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy20;
   case 'S':   case 's':   goto yy22;
   default:   goto yyErr;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_SG_RQ_SYM_RELEASE_CALL;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_SG_RQ_SYM_RESUME_CALL;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_SG_RQ_SYM_RELEASE_COMPLETE;
      goto yyReturn;
    }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy27;
   default:   goto yyErr;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_SG_RQ_SYM_INFO_DGTS;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy30;
   default:   goto yyErr;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_SG_RQ_SYM_CONTINUE_WINK;
      goto yyReturn;
    }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_SG_RQ_SYM_BUSY_TONE;
      goto yyReturn;
    }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_SG_RQ_SYM_CALL_BLOCK;
      goto yyReturn;
    }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy40;
   default:   goto yyErr;
   }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy38;
   default:   goto yyErr;
   }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_SG_RQ_SYM_CALL_ANSWER;
      goto yyReturn;
    }
yy40:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_D_SG_RQ_SYM_ACK_WINK;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMDSgRqSymVal */

#endif  /* GCP_PKG_MGCP_NAM_MF_GRP_DE */


#ifdef  GCP_PKG_MGCP_FGD_OP_SR_SIGOUT


/*
    Func:  MORqEvSymType  ->     */
/*!re2c

               known = [aA][nN][sS] | [oO][cC] | [oO][fF] | [oO][rR][bB][kK] | [rR][bB][zZ] | [rR][eE][lL] | [rR][lL][cC] | [sS][wW][kK];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMORqEvSymType
*
*       Desc:  Description for the regular expression PkgMORqEvSymType
*              
*                             known = [aA][nN][sS] | [oO][cC] | [oO][fF] | [oO][rR][bB][kK] | [rR][bB][zZ] | [rR][eE][lL] | [rR][lL][cC] | [sS][wW][kK];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMORqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMORqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMORqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy12;
   case '*':   goto yy11;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   case 'A':   case 'a':   goto yy3;
   case 'O':   case 'o':   goto yy4;
   case 'R':   case 'r':   goto yy5;
   case 'S':   case 's':   goto yy6;
   case '[':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy28;
   case 'N':   case 'n':   goto yy29;
   default:   goto yy10;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy20;
   case 'R':   case 'r':   goto yy26;
   default:   goto yy10;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy23;
   case 'E':   case 'e':   goto yy24;
   case 'L':   case 'l':   goto yy25;
   default:   goto yy10;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy19;
   default:   goto yy10;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy9:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy10:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy17;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy20;
   default:   goto yy10;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy21;
   default:   goto yy10;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy20;
   default:   goto yy10;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy20;
   default:   goto yy10;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy20;
   default:   goto yy10;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy27;
   default:   goto yy10;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy20;
   default:   goto yy10;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy30;
   default:   goto yy10;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy20;
   default:   goto yy10;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   default:   goto yy10;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMORqEvSymType */

/*
    Func:  MORqEvSymVal  ->     */
/*!re2c
[aA][nN][sS]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_CALL_ANSWER); }
[oO][cC]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_OPER_FAIL); }
[oO][rR][bB][kK]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_OPER_RINGBACK); }
[rR][bB][zZ]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_REVERSE_MAKE_BUSY); }
[rR][eE][lL]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_RELEASE_CALL); }
[rR][lL][cC]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_RELEASE_COMPLETE); }
[sS][wW][kK]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_START_WINK); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMORqEvSymVal
*
*       Desc:  Description for the regular expression PkgMORqEvSymVal
*              [aA][nN][sS]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_CALL_ANSWER); }
*              [oO][cC]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_OPER_FAIL); }
*              [oO][rR][bB][kK]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_OPER_RINGBACK); }
*              [rR][bB][zZ]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_REVERSE_MAKE_BUSY); }
*              [rR][eE][lL]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_RELEASE_CALL); }
*              [rR][lL][cC]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_RELEASE_COMPLETE); }
*              [sS][wW][kK]          { return (MGT_MGCP_PKG_M_O_RQ_EV_SYM_START_WINK); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMORqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMORqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMORqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   case 'O':   case 'o':   goto yy4;
   case 'R':   case 'r':   goto yy5;
   case 'S':   case 's':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy27;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy22;
   case 'F':   case 'f':   goto yy20;
   case 'R':   case 'r':   goto yy19;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy12;
   case 'E':   case 'e':   goto yy11;
   case 'L':   case 'l':   goto yy10;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_O_RQ_EV_SYM_START_WINK;
      goto yyReturn;
    }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy17;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy15;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_O_RQ_EV_SYM_REVERSE_MAKE_BUSY;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_O_RQ_EV_SYM_RELEASE_CALL;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_O_RQ_EV_SYM_RELEASE_COMPLETE;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy24;
   default:   goto yyErr;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_O_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_O_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy25;
   default:   goto yyErr;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_O_RQ_EV_SYM_OPER_RINGBACK;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy28;
   default:   goto yyErr;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_O_RQ_EV_SYM_CALL_ANSWER;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMORqEvSymVal */

/*
    Func:  MOSgRqSymType  ->     */
/*!re2c

               known = [rR][cC][lL] | [rR][eE][lL] | [rR][eE][sS] | [rR][lL][cC] | [sS][uU][pP] | [sS][uU][sS];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMOSgRqSymType
*
*       Desc:  Description for the regular expression PkgMOSgRqSymType
*              
*                             known = [rR][cC][lL] | [rR][eE][lL] | [rR][eE][sS] | [rR][lL][cC] | [sS][uU][pP] | [sS][uU][sS];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMOSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMOSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMOSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy11;
   case '*':   goto yy10;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'A':   case 'a':   goto yy5;
   case 'R':   case 'r':   goto yy3;
   case 'S':   case 's':   goto yy4;
   case '[':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy26;
   case 'E':   case 'e':   goto yy27;
   case 'L':   case 'l':   goto yy28;
   default:   goto yy9;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy22;
   default:   goto yy9;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy9;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy19;
   default:   goto yy9;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy20;
   default:   goto yy9;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'S':   case 'p':   case 's':   goto yy23;
   default:   goto yy9;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy24;
   default:   goto yy9;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy23;
   default:   goto yy9;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'S':   case 'l':   case 's':   goto yy23;
   default:   goto yy9;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy23;
   default:   goto yy9;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMOSgRqSymType */

/*
    Func:  MOSgRqSymVal  ->     */
/*!re2c
[rR][cC][lL]          { return (MGT_MGCP_PKG_M_O_SG_RQ_SYM_OPER_RECALL); }
[rR][eE][lL]          { return (MGT_MGCP_PKG_M_O_SG_RQ_SYM_RELEASE_CALL); }
[rR][eE][sS]          { return (MGT_MGCP_PKG_M_O_SG_RQ_SYM_RESUME_CALL); }
[rR][lL][cC]          { return (MGT_MGCP_PKG_M_O_SG_RQ_SYM_RELEASE_COMPLETE); }
[sS][uU][pP]          { return (MGT_MGCP_PKG_M_O_SG_RQ_SYM_CALL_SETUP); }
[sS][uU][sS]          { return (MGT_MGCP_PKG_M_O_SG_RQ_SYM_SUSPEND_CALL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMOSgRqSymVal
*
*       Desc:  Description for the regular expression PkgMOSgRqSymVal
*              [rR][cC][lL]          { return (MGT_MGCP_PKG_M_O_SG_RQ_SYM_OPER_RECALL); }
*              [rR][eE][lL]          { return (MGT_MGCP_PKG_M_O_SG_RQ_SYM_RELEASE_CALL); }
*              [rR][eE][sS]          { return (MGT_MGCP_PKG_M_O_SG_RQ_SYM_RESUME_CALL); }
*              [rR][lL][cC]          { return (MGT_MGCP_PKG_M_O_SG_RQ_SYM_RELEASE_COMPLETE); }
*              [sS][uU][pP]          { return (MGT_MGCP_PKG_M_O_SG_RQ_SYM_CALL_SETUP); }
*              [sS][uU][sS]          { return (MGT_MGCP_PKG_M_O_SG_RQ_SYM_SUSPEND_CALL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMOSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMOSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMOSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy3;
   case 'S':   case 's':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy12;
   case 'E':   case 'e':   goto yy11;
   case 'L':   case 'l':   goto yy10;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy6;
   case 'S':   case 's':   goto yy8;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_O_SG_RQ_SYM_CALL_SETUP;
      goto yyReturn;
    }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_O_SG_RQ_SYM_SUSPEND_CALL;
      goto yyReturn;
    }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy19;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy15;
   case 'S':   case 's':   goto yy17;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_O_SG_RQ_SYM_OPER_RECALL;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_O_SG_RQ_SYM_RELEASE_CALL;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_O_SG_RQ_SYM_RESUME_CALL;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_O_SG_RQ_SYM_RELEASE_COMPLETE;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMOSgRqSymVal */

#endif  /* GCP_PKG_MGCP_FGD_OP_SR_SIGOUT */



#ifdef  GCP_PKG_MGCP_MF_WINKSTART

/*
    Func:  MSRqEvSymType  ->     */
/*!re2c

               known = [aA][nN][sS] | [bB][lL] | [iI][nN][fF] | [oO][cC] | [oO][fF] | [rR][eE][lL] | [rR][eE][sS] | [rR][lL][cC] | [sS][uU][pP] | [sS][uU][sS];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMSRqEvSymType
*
*       Desc:  Description for the regular expression PkgMSRqEvSymType
*              
*                             known = [aA][nN][sS] | [bB][lL] | [iI][nN][fF] | [oO][cC] | [oO][fF] | [rR][eE][lL] | [rR][eE][sS] | [rR][lL][cC] | [sS][uU][pP] | [sS][uU][sS];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMSRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMSRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMSRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy14;
   case '*':   goto yy13;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'I':   case 'i':   goto yy5;
   case 'O':   case 'o':   goto yy6;
   case 'R':   case 'r':   goto yy7;
   case 'S':   case 's':   goto yy8;
   case '[':   goto yy9;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy28;
   case 'N':   case 'n':   goto yy29;
   default:   goto yy12;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy22;
   default:   goto yy12;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy27;
   default:   goto yy12;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy22;
   default:   goto yy12;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy25;
   case 'L':   case 'l':   goto yy26;
   default:   goto yy12;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy21;
   default:   goto yy12;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy11:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy12:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy17;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'S':   case 'p':   case 's':   goto yy22;
   default:   goto yy12;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yy12;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'S':   case 'l':   case 's':   goto yy22;
   default:   goto yy12;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy22;
   default:   goto yy12;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy22;
   default:   goto yy12;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy30;
   default:   goto yy12;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy22;
   default:   goto yy12;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   default:   goto yy12;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMSRqEvSymType */

/*
    Func:  MSRqEvSymVal  ->     */
/*!re2c
[aA][nN][sS]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_CALL_ANSWER); }
[bB][lL]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_BLOCK); }
[iI][nN][fF]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_INFO_DGTS); }
[oO][cC]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_OPER_FAIL); }
[rR][eE][lL]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_RELEASE_CALL); }
[rR][eE][sS]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_RESUME_CALL); }
[rR][lL][cC]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_RELEASE_COMPLETE); }
[sS][uU][pP]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_CALL_SETUP); }
[sS][uU][sS]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_SUSPEND_CALL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMSRqEvSymVal
*
*       Desc:  Description for the regular expression PkgMSRqEvSymVal
*              [aA][nN][sS]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_CALL_ANSWER); }
*              [bB][lL]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_BLOCK); }
*              [iI][nN][fF]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_INFO_DGTS); }
*              [oO][cC]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_OPER_FAIL); }
*              [rR][eE][lL]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_RELEASE_CALL); }
*              [rR][eE][sS]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_RESUME_CALL); }
*              [rR][lL][cC]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_RELEASE_COMPLETE); }
*              [sS][uU][pP]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_CALL_SETUP); }
*              [sS][uU][sS]          { return (MGT_MGCP_PKG_M_S_RQ_EV_SYM_SUSPEND_CALL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMSRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMSRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMSRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'I':   case 'i':   goto yy5;
   case 'O':   case 'o':   goto yy6;
   case 'R':   case 'r':   goto yy7;
   case 'S':   case 's':   goto yy8;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy31;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy29;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy26;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy24;
   case 'F':   case 'f':   goto yy22;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy15;
   case 'L':   case 'l':   goto yy14;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy10;
   case 'S':   case 's':   goto yy12;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_RQ_EV_SYM_CALL_SETUP;
      goto yyReturn;
    }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_RQ_EV_SYM_SUSPEND_CALL;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy20;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy16;
   case 'S':   case 's':   goto yy18;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_RQ_EV_SYM_RELEASE_CALL;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_RQ_EV_SYM_RESUME_CALL;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_RQ_EV_SYM_RELEASE_COMPLETE;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy27;
   default:   goto yyErr;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_RQ_EV_SYM_INFO_DGTS;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_RQ_EV_SYM_BLOCK;
      goto yyReturn;
    }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy32;
   default:   goto yyErr;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_RQ_EV_SYM_CALL_ANSWER;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMSRqEvSymVal */

/*
    Func:  MSSgRqSymType  ->     */
/*!re2c

               known = [aA][nN][sS] | [bB][lL] | [bB][zZ] | [rR][eE][lL] | [rR][eE][sS] | [rR][lL][cC] | [rR][oO] | [rR][tT] | [sS][uU][pP] | [sS][uU][sS];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMSSgRqSymType
*
*       Desc:  Description for the regular expression PkgMSSgRqSymType
*              
*                             known = [aA][nN][sS] | [bB][lL] | [bB][zZ] | [rR][eE][lL] | [rR][eE][sS] | [rR][lL][cC] | [rR][oO] | [rR][tT] | [sS][uU][pP] | [sS][uU][sS];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMSSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMSSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMSSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy12;
   case '*':   goto yy11;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'R':   case 'r':   goto yy5;
   case 'S':   case 's':   goto yy6;
   case '[':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy25;
   case 'N':   case 'n':   goto yy26;
   default:   goto yy10;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'Z':   case 'l':   case 'z':   goto yy20;
   default:   goto yy10;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy23;
   case 'L':   case 'l':   goto yy24;
   case 'O':   case 'T':   case 'o':   case 't':   goto yy20;
   default:   goto yy10;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy19;
   default:   goto yy10;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy9:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy10:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy17;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'S':   case 'p':   case 's':   goto yy20;
   default:   goto yy10;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy21;
   default:   goto yy10;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'S':   case 'l':   case 's':   goto yy20;
   default:   goto yy10;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy20;
   default:   goto yy10;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy27;
   default:   goto yy10;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy20;
   default:   goto yy10;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy28;
   default:   goto yy10;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMSSgRqSymType */

/*
    Func:  MSSgRqSymVal  ->     */
/*!re2c
[aA][nN][sS]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_CALL_ANSWER); }
[bB][lL]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_BLOCK); }
[bB][zZ]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_BUSY_TONE); }
[rR][eE][lL]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_RELEASE_CALL); }
[rR][eE][sS]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_RESUME_CALL); }
[rR][lL][cC]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_RELEASE_COMPLETE); }
[rR][oO]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_REORDER_TONE); }
[rR][tT]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_RINGBACK_TONE); }
[sS][uU][pP]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_CALL_SETUP); }
[sS][uU][sS]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_SUSPEND_CALL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMSSgRqSymVal
*
*       Desc:  Description for the regular expression PkgMSSgRqSymVal
*              [aA][nN][sS]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_CALL_ANSWER); }
*              [bB][lL]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_BLOCK); }
*              [bB][zZ]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_BUSY_TONE); }
*              [rR][eE][lL]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_RELEASE_CALL); }
*              [rR][eE][sS]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_RESUME_CALL); }
*              [rR][lL][cC]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_RELEASE_COMPLETE); }
*              [rR][oO]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_REORDER_TONE); }
*              [rR][tT]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_RINGBACK_TONE); }
*              [sS][uU][pP]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_CALL_SETUP); }
*              [sS][uU][sS]          { return (MGT_MGCP_PKG_M_S_SG_RQ_SYM_SUSPEND_CALL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMSSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMSSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMSSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'R':   case 'r':   goto yy5;
   case 'S':   case 's':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy28;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy26;
   case 'Z':   case 'z':   goto yy24;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy17;
   case 'L':   case 'l':   goto yy16;
   case 'O':   case 'o':   goto yy14;
   case 'T':   case 't':   goto yy12;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy8;
   case 'S':   case 's':   goto yy10;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_SG_RQ_SYM_CALL_SETUP;
      goto yyReturn;
    }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_SG_RQ_SYM_SUSPEND_CALL;
      goto yyReturn;
    }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_SG_RQ_SYM_RINGBACK_TONE;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_SG_RQ_SYM_REORDER_TONE;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy22;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   case 'S':   case 's':   goto yy20;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_SG_RQ_SYM_RELEASE_CALL;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_SG_RQ_SYM_RESUME_CALL;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_SG_RQ_SYM_RELEASE_COMPLETE;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_SG_RQ_SYM_BUSY_TONE;
      goto yyReturn;
    }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_SG_RQ_SYM_BLOCK;
      goto yyReturn;
    }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy29;
   default:   goto yyErr;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_S_SG_RQ_SYM_CALL_ANSWER;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMSSgRqSymVal */

#endif  /* GCP_PKG_MGCP_MF_WINKSTART */




#ifdef  GCP_PKG_MGCP_RTP

/*
    Func:  RRqEvSymType  ->     */
/*!re2c

               known = [iI][uU] | [rR][tT][oO] | [uU][cC] | [sS][rR] | [jJ][iI] | [pP][lL] | [qQ][aA] | [cC][oO][1] | [cC][oO][2] | [oO][cC] | [oO][fF] | [mM][aA];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgRRqEvSymType
*
*       Desc:  Description for the regular expression PkgRRqEvSymType
*              
*                             known = [iI][uU] | [rR][tT][oO] | [uU][cC] | [sS][rR] | [jJ][iI] | [pP][lL] | [qQ][aA] | [cC][oO][1] | [cC][oO][2] | [oO][cC] | [oO][fF] | [mM][aA];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgRRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgRRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgRRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy19;
   case '*':   goto yy18;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':   case 'K':
   case 'L':   case 'N':   case 'T':   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':   case 'k':
   case 'l':   case 'n':   case 't':   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy16;
   case 'A':   case 'a':   goto yy13;
   case 'C':   case 'c':   goto yy10;
   case 'I':   case 'i':   goto yy3;
   case 'J':   case 'j':   goto yy7;
   case 'M':   case 'm':   goto yy12;
   case 'O':   case 'o':   goto yy11;
   case 'P':   case 'p':   goto yy8;
   case 'Q':   case 'q':   goto yy9;
   case 'R':   case 'r':   goto yy4;
   case 'S':   case 's':   goto yy6;
   case 'U':   case 'u':   goto yy5;
   case '[':   goto yy14;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy30;
   default:   goto yy17;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy34;
   default:   goto yy17;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy30;
   default:   goto yy17;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy30;
   default:   goto yy17;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy30;
   default:   goto yy17;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy30;
   default:   goto yy17;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy30;
   default:   goto yy17;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy33;
   default:   goto yy17;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy30;
   default:   goto yy17;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy30;
   default:   goto yy17;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy26;
   default:   goto yy17;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy16:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy17:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy24;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy16;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy20;
   default:   goto yyErr;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy27;
   default:   goto yy17;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy28;
   default:   goto yy17;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   default:   goto yy17;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':
   case '2':   goto yy30;
   default:   goto yy17;
   }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy30;
   default:   goto yy17;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgRRqEvSymType */

/*
    Func:  RRqEvSymVal  ->     */
/*!re2c
[iI][uU]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_ICMP_UNREACHABLE); }
[rR][tT][oO]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_RTP_OR_RTCP_TIMEOUT); }
[uU][cC]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_USED_CODEC_CHNGD); }
[sS][rR]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_SAMPL_RATE_CHNGD); }
[jJ][iI]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_JITTER_BUFF_SIZE_CHNGD); }
[pP][lL]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_PCKT_LOSS_EXCEEDED); }
[qQ][aA]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_QUALITY_ALERT); }
[cC][oO][1]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_CONTINUITY_TONE); }
[cC][oO][2]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_CONTINUITY_TEST); }
[oO][cC]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_OPER_FAIL); }
[mM][aA]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_MEDIA_START); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgRRqEvSymVal
*
*       Desc:  Description for the regular expression PkgRRqEvSymVal
*              [iI][uU]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_ICMP_UNREACHABLE); }
*              [rR][tT][oO]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_RTP_OR_RTCP_TIMEOUT); }
*              [uU][cC]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_USED_CODEC_CHNGD); }
*              [sS][rR]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_SAMPL_RATE_CHNGD); }
*              [jJ][iI]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_JITTER_BUFF_SIZE_CHNGD); }
*              [pP][lL]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_PCKT_LOSS_EXCEEDED); }
*              [qQ][aA]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_QUALITY_ALERT); }
*              [cC][oO][1]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_CONTINUITY_TONE); }
*              [cC][oO][2]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_CONTINUITY_TEST); }
*              [oO][cC]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_OPER_FAIL); }
*              [mM][aA]          { return (MGT_MGCP_PKG_R_RQ_EV_SYM_MEDIA_START); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgRRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgRRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgRRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy10;
   case 'I':   case 'i':   goto yy3;
   case 'J':   case 'j':   goto yy7;
   case 'M':   case 'm':   goto yy12;
   case 'O':   case 'o':   goto yy11;
   case 'P':   case 'p':   goto yy8;
   case 'Q':   case 'q':   goto yy9;
   case 'R':   case 'r':   goto yy4;
   case 'S':   case 's':   goto yy6;
   case 'U':   case 'u':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy37;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy34;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy32;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy30;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy28;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy26;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy24;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy19;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy17;
   case 'F':   case 'f':   goto yy15;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_RQ_EV_SYM_MEDIA_START;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy20;
   case '2':   goto yy22;
   default:   goto yyErr;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_RQ_EV_SYM_CONTINUITY_TONE;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_RQ_EV_SYM_CONTINUITY_TEST;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_RQ_EV_SYM_QUALITY_ALERT;
      goto yyReturn;
    }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_RQ_EV_SYM_PCKT_LOSS_EXCEEDED;
      goto yyReturn;
    }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_RQ_EV_SYM_JITTER_BUFF_SIZE_CHNGD;
      goto yyReturn;
    }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_RQ_EV_SYM_SAMPL_RATE_CHNGD;
      goto yyReturn;
    }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_RQ_EV_SYM_USED_CODEC_CHNGD;
      goto yyReturn;
    }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy35;
   default:   goto yyErr;
   }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_RQ_EV_SYM_RTP_OR_RTCP_TIMEOUT;
      goto yyReturn;
    }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_RQ_EV_SYM_ICMP_UNREACHABLE;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgRRqEvSymVal */

/*
    Func:  RSgRqSymType  ->     */
/*!re2c

               known = [cC][oO][1] | [cC][oO][2];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgRSgRqSymType
*
*       Desc:  Description for the regular expression PkgRSgRqSymType
*              
*                             known = [cC][oO][1] | [cC][oO][2];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgRSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgRSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgRSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy10;
   case '*':   goto yy9;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'A':   case 'a':   goto yy4;
   case 'C':   case 'c':   goto yy3;
   case '[':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy21;
   default:   goto yy8;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yy8;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy8;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy8;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':
   case '2':   goto yy22;
   default:   goto yy8;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yy8;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgRSgRqSymType */

/*
    Func:  RSgRqSymVal  ->     */
/*!re2c
[cC][oO][1]          { return (MGT_MGCP_PKG_R_SG_RQ_SYM_CONTINUITY_TONE); }
[cC][oO][2]          { return (MGT_MGCP_PKG_R_SG_RQ_SYM_CONTINUITY_TEST); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgRSgRqSymVal
*
*       Desc:  Description for the regular expression PkgRSgRqSymVal
*              [cC][oO][1]          { return (MGT_MGCP_PKG_R_SG_RQ_SYM_CONTINUITY_TONE); }
*              [cC][oO][2]          { return (MGT_MGCP_PKG_R_SG_RQ_SYM_CONTINUITY_TEST); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgRSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgRSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgRSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy5;
   case '2':   goto yy7;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_SG_RQ_SYM_CONTINUITY_TONE;
      goto yyReturn;
    }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_SG_RQ_SYM_CONTINUITY_TEST;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgRSgRqSymVal */

#endif  /* GCP_PKG_MGCP_RTP */




#ifdef  GCP_PKG_MGCP_RES_RESERV

/*
    Func:  RESRqEvSymType  ->     */
/*!re2c

               known = [rR][lL] | [rR][eE];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgRESRqEvSymType
*
*       Desc:  Description for the regular expression PkgRESRqEvSymType
*              
*                             known = [rR][lL] | [rR][eE];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgRESRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgRESRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgRESRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy10;
   case '*':   goto yy9;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'A':   case 'a':   goto yy4;
   case 'R':   case 'r':   goto yy3;
   case '[':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'L':   case 'e':   case 'l':   goto yy21;
   default:   goto yy8;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yy8;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy8;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy8;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yy8;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgRESRqEvSymType */

/*
    Func:  RESRqEvSymVal  ->     */
/*!re2c
[rR][lL]          { return (MGT_MGCP_PKG_R_E_S_RQ_EV_SYM_RESOURCE_LOST); }
[rR][eE]          { return (MGT_MGCP_PKG_R_E_S_RQ_EV_SYM_RESOURCE_ERROR); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgRESRqEvSymVal
*
*       Desc:  Description for the regular expression PkgRESRqEvSymVal
*              [rR][lL]          { return (MGT_MGCP_PKG_R_E_S_RQ_EV_SYM_RESOURCE_LOST); }
*              [rR][eE]          { return (MGT_MGCP_PKG_R_E_S_RQ_EV_SYM_RESOURCE_ERROR); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgRESRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgRESRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgRESRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy4;
   case 'L':   case 'l':   goto yy6;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_E_S_RQ_EV_SYM_RESOURCE_ERROR;
      goto yyReturn;
    }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_R_E_S_RQ_EV_SYM_RESOURCE_LOST;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgRESRqEvSymVal */

#endif  /* GCP_PKG_MGCP_RES_RESERV */




#ifdef  GCP_PKG_MGCP_SCRIPT

/*
    Func:  ScriptRqEvSymType  ->     */
/*!re2c

               known = [oO][cC] | [oO][fF] | [iI][rR];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgScriptRqEvSymType
*
*       Desc:  Description for the regular expression PkgScriptRqEvSymType
*              
*                             known = [oO][cC] | [oO][fF] | [iI][rR];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgScriptRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgScriptRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgScriptRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy11;
   case '*':   goto yy10;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'A':   case 'a':   goto yy5;
   case 'I':   case 'i':   goto yy4;
   case 'O':   case 'o':   goto yy3;
   case '[':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy22;
   default:   goto yy9;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy22;
   default:   goto yy9;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy9;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy19;
   default:   goto yy9;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy20;
   default:   goto yy9;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yy9;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgScriptRqEvSymType */


/*
    Func:  ScriptRqEvSymVal  ->     */
/*!re2c
[oO][cC]          { return (MGT_MGCP_PKG_SCRIPT_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_SCRIPT_RQ_EV_SYM_OPER_FAIL); }
[iI][rR]          { return (MGT_MGCP_PKG_SCRIPT_RQ_EV_SYM_INTERMEDIATE_RES); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgScriptRqEvSymVal
*
*       Desc:  Description for the regular expression PkgScriptRqEvSymVal
*              [oO][cC]          { return (MGT_MGCP_PKG_SCRIPT_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_SCRIPT_RQ_EV_SYM_OPER_FAIL); }
*              [iI][rR]          { return (MGT_MGCP_PKG_SCRIPT_RQ_EV_SYM_INTERMEDIATE_RES); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgScriptRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgScriptRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgScriptRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy4;
   case 'O':   case 'o':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy9;
   case 'F':   case 'f':   goto yy7;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_SCRIPT_RQ_EV_SYM_INTERMEDIATE_RES;
      goto yyReturn;
    }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_SCRIPT_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_SCRIPT_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgScriptRqEvSymVal */

/*
    Func:  ScriptSgRqSymType  ->     */
/*!re2c

               known = [jJ][aA][vV][aA] | [pP][eE][rR][lL] | [tT][cC][lL] | [xX][mM][lL] | [vV][xX][mM][lL] | [iI][rR];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgScriptSgRqSymType
*
*       Desc:  Description for the regular expression PkgScriptSgRqSymType
*              
*                             known = [jJ][aA][vV][aA] | [pP][eE][rR][lL] | [tT][cC][lL] | [xX][mM][lL] | [vV][xX][mM][lL] | [iI][rR];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgScriptSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgScriptSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgScriptSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy15;
   case '*':   goto yy14;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':   case 'Q':
   case 'R':
   case 'S':   case 'U':   case 'W':   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':   case 'q':
   case 'r':
   case 's':   case 'u':   case 'w':   case 'y':
   case 'z':   goto yy12;
   case 'A':   case 'a':   goto yy9;
   case 'I':   case 'i':   goto yy8;
   case 'J':   case 'j':   goto yy3;
   case 'P':   case 'p':   goto yy4;
   case 'T':   case 't':   goto yy5;
   case 'V':   case 'v':   goto yy7;
   case 'X':   case 'x':   goto yy6;
   case '[':   goto yy10;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy35;
   default:   goto yy13;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy33;
   default:   goto yy13;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy32;
   default:   goto yy13;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy31;
   default:   goto yy13;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy29;
   default:   goto yy13;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy26;
   default:   goto yy13;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy22;
   default:   goto yy13;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy12:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy13:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy20;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy12;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy18;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy23;
   default:   goto yy13;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy24;
   default:   goto yy13;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy27;
   default:   goto yy13;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy30;
   default:   goto yy13;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy26;
   default:   goto yy13;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy26;
   default:   goto yy13;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy26;
   default:   goto yy13;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy34;
   default:   goto yy13;
   }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy26;
   default:   goto yy13;
   }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy36;
   default:   goto yy13;
   }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy26;
   default:   goto yy13;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgScriptSgRqSymType */

/*
    Func:  ScriptSgRqSymVal  ->     */
/*!re2c
[jJ][aA][vV][aA]          { return (MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_JAVA_SCRIPT); }
[pP][eE][rR][lL]          { return (MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_PERL_SCRIPT); }
[tT][cC][lL]          { return (MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_T_C_L_SCRIPT); }
[xX][mM][lL]          { return (MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_X_M_L_SCRIPT); }
[vV][xX][mM][lL]          { return (MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_V_X_M_L_DOC); }
[iI][rR]          { return (MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_INTERMEDIATE_RES); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgScriptSgRqSymVal
*
*       Desc:  Description for the regular expression PkgScriptSgRqSymVal
*              [jJ][aA][vV][aA]          { return (MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_JAVA_SCRIPT); }
*              [pP][eE][rR][lL]          { return (MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_PERL_SCRIPT); }
*              [tT][cC][lL]          { return (MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_T_C_L_SCRIPT); }
*              [xX][mM][lL]          { return (MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_X_M_L_SCRIPT); }
*              [vV][xX][mM][lL]          { return (MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_V_X_M_L_DOC); }
*              [iI][rR]          { return (MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_INTERMEDIATE_RES); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgScriptSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgScriptSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgScriptSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy8;
   case 'J':   case 'j':   goto yy3;
   case 'P':   case 'p':   goto yy4;
   case 'T':   case 't':   goto yy5;
   case 'V':   case 'v':   goto yy7;
   case 'X':   case 'x':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy25;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy21;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy18;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy15;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy11;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_INTERMEDIATE_RES;
      goto yyReturn;
    }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_V_X_M_L_DOC;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_X_M_L_SCRIPT;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy19;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_T_C_L_SCRIPT;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy22;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_PERL_SCRIPT;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy26;
   default:   goto yyErr;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy27;
   default:   goto yyErr;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_JAVA_SCRIPT;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgScriptSgRqSymVal */

#endif  /* GCP_PKG_MGCP_SCRIPT */



#ifdef  GCP_PKG_MGCP_SIGLST

/*
    Func:  SLRqEvSymType  ->     */
/*!re2c

               known = [oO][cC] | [oO][fF];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgSLRqEvSymType
*
*       Desc:  Description for the regular expression PkgSLRqEvSymType
*              
*                             known = [oO][cC] | [oO][fF];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgSLRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgSLRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgSLRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy10;
   case '*':   goto yy9;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'A':   case 'a':   goto yy4;
   case 'O':   case 'o':   goto yy3;
   case '[':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy21;
   default:   goto yy8;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yy8;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy8;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy8;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yy8;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgSLRqEvSymType */

/*
    Func:  SLRqEvSymVal  ->     */
/*!re2c
[oO][cC]          { return (MGT_MGCP_PKG_S_L_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_S_L_RQ_EV_SYM_OPER_FAIL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgSLRqEvSymVal
*
*       Desc:  Description for the regular expression PkgSLRqEvSymVal
*              [oO][cC]          { return (MGT_MGCP_PKG_S_L_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_S_L_RQ_EV_SYM_OPER_FAIL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgSLRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgSLRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgSLRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy6;
   case 'F':   case 'f':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_S_L_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_S_L_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgSLRqEvSymVal */

/*
    Func:  SLSgRqSymType  ->     */
/*!re2c

               known = [sS];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgSLSgRqSymType
*
*       Desc:  Description for the regular expression PkgSLSgRqSymType
*              
*                             known = [sS];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgSLSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgSLSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgSLSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy10;
   case '*':   goto yy9;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'A':   case 'a':   goto yy4;
   case 'S':   case 's':   goto yy3;
   case '[':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy21;
   default:   goto yy8;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yy8;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy8;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy8;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgSLSgRqSymType */

/*
    Func:  SLSgRqSymVal  ->     */
/*!re2c
[sS]          { return (MGT_MGCP_PKG_S_L_SG_RQ_SYM_SIG_LST); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgSLSgRqSymVal
*
*       Desc:  Description for the regular expression PkgSLSgRqSymVal
*              [sS]          { return (MGT_MGCP_PKG_S_L_SG_RQ_SYM_SIG_LST); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgSLSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgSLSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgSLSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'S':   case 's':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_S_L_SG_RQ_SYM_SIG_LST;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgSLSgRqSymVal */

#endif  /* GCP_PKG_MGCP_SIGLST */




#ifdef  GCP_PKG_MGCP_SUPPL_SRVS_TONE

/*
    Func:  SSTRqEvSymType  ->     */
/*!re2c

               known = [oO][cC] | [oO][fF];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgSSTRqEvSymType
*
*       Desc:  Description for the regular expression PkgSSTRqEvSymType
*              
*                             known = [oO][cC] | [oO][fF];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgSSTRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgSSTRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgSSTRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy10;
   case '*':   goto yy9;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'A':   case 'a':   goto yy4;
   case 'O':   case 'o':   goto yy3;
   case '[':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy21;
   default:   goto yy8;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yy8;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy8;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy8;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yy8;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgSSTRqEvSymType */

/*
    Func:  SSTRqEvSymVal  ->     */
/*!re2c
[oO][cC]          { return (MGT_MGCP_PKG_S_S_T_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_S_S_T_RQ_EV_SYM_OPER_FAIL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgSSTRqEvSymVal
*
*       Desc:  Description for the regular expression PkgSSTRqEvSymVal
*              [oO][cC]          { return (MGT_MGCP_PKG_S_S_T_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_S_S_T_RQ_EV_SYM_OPER_FAIL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgSSTRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgSSTRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgSSTRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy6;
   case 'F':   case 'f':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_S_S_T_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_S_S_T_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgSSTRqEvSymVal */

/*
    Func:  SSTSgRqSymType  ->     */
/*!re2c

               known = [cC][dD] | [cC][jJ] | [cC][mM] | [cC][wW] | [nN][iI] | [nN][uU] | [pP][rR] | [pP][tT] | [hH][tT];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgSSTSgRqSymType
*
*       Desc:  Description for the regular expression PkgSSTSgRqSymType
*              
*                             known = [cC][dD] | [cC][jJ] | [cC][mM] | [cC][wW] | [nN][iI] | [nN][uU] | [pP][rR] | [pP][tT] | [hH][tT];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgSSTSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgSSTSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgSSTSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy13;
   case '*':   goto yy12;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':   case 'O':   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':   case 'o':   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   case 'A':   case 'a':   goto yy7;
   case 'C':   case 'c':   goto yy3;
   case 'H':   case 'h':   goto yy6;
   case 'N':   case 'n':   goto yy4;
   case 'P':   case 'p':   goto yy5;
   case '[':   goto yy8;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'J':   case 'M':   case 'W':   case 'd':   case 'j':   case 'm':   case 'w':   goto yy24;
   default:   goto yy11;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'U':   case 'i':   case 'u':   goto yy24;
   default:   goto yy11;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'T':   case 'r':   case 't':   goto yy24;
   default:   goto yy11;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy24;
   default:   goto yy11;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy20;
   default:   goto yy11;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy10:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy11:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy18;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy21;
   default:   goto yy11;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yy11;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy25;
   default:   goto yy11;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgSSTSgRqSymType */

/*
    Func:  SSTSgRqSymVal  ->     */
/*!re2c
[cC][dD]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_CONFERENCE_DEPART); }
[cC][jJ]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_CONFERENCE_JOIN); }
[cC][mM]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_COMFORT_TONE); }
[cC][wW]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_CALLER_WAITING_TONE); }
[nN][iI]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_NEGATIVE_IND); }
[nN][uU]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_NUMBER_UNOBTAINABLE); }
[pP][rR]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_PAYPHONE_RECOG); }
[pP][tT]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_PAY_TONE); }
[hH][tT]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_ON_HOLD_TONE); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgSSTSgRqSymVal
*
*       Desc:  Description for the regular expression PkgSSTSgRqSymVal
*              [cC][dD]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_CONFERENCE_DEPART); }
*              [cC][jJ]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_CONFERENCE_JOIN); }
*              [cC][mM]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_COMFORT_TONE); }
*              [cC][wW]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_CALLER_WAITING_TONE); }
*              [nN][iI]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_NEGATIVE_IND); }
*              [nN][uU]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_NUMBER_UNOBTAINABLE); }
*              [pP][rR]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_PAYPHONE_RECOG); }
*              [pP][tT]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_PAY_TONE); }
*              [hH][tT]          { return (MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_ON_HOLD_TONE); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgSSTSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgSSTSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgSSTSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy3;
   case 'H':   case 'h':   goto yy6;
   case 'N':   case 'n':   goto yy4;
   case 'P':   case 'p':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy23;
   case 'J':   case 'j':   goto yy21;
   case 'M':   case 'm':   goto yy19;
   case 'W':   case 'w':   goto yy17;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy15;
   case 'U':   case 'u':   goto yy13;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy11;
   case 'T':   case 't':   goto yy9;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_ON_HOLD_TONE;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_PAY_TONE;
      goto yyReturn;
    }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_PAYPHONE_RECOG;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_NUMBER_UNOBTAINABLE;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_NEGATIVE_IND;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_CALLER_WAITING_TONE;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_COMFORT_TONE;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_CONFERENCE_JOIN;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_CONFERENCE_DEPART;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgSSTSgRqSymVal */

#endif  /* GCP_PKG_MGCP_SUPPL_SRVS_TONE */




#ifdef  GCP_PKG_MGCP_TRUNK


/*
    Func:  TRqEvSymType  ->     */
/*!re2c

               known = [cC][oO][1] | [cC][oO][2] | [nN][mM] | [mM][mM] | [oO][cC] | [oO][fF] | [oO][mM] | [rR][oO] | [sS][iI][tT] | [tT][lL] | [tT][pP] | [zZ][zZ] | [aA][sS];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgTRqEvSymType
*
*       Desc:  Description for the regular expression PkgTRqEvSymType
*              
*                             known = [cC][oO][1] | [cC][oO][2] | [nN][mM] | [mM][mM] | [oO][cC] | [oO][fF] | [oO][mM] | [rR][oO] | [sS][iI][tT] | [tT][lL] | [tT][pP] | [zZ][zZ] | [aA][sS];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgTRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgTRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgTRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy17;
   case '*':   goto yy16;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':   case 'P':
   case 'Q':   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':   case 'p':
   case 'q':   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':   goto yy14;
   case 'A':   case 'a':   goto yy11;
   case 'C':   case 'c':   goto yy3;
   case 'M':   case 'm':   goto yy5;
   case 'N':   case 'n':   goto yy4;
   case 'O':   case 'o':   goto yy6;
   case 'R':   case 'r':   goto yy7;
   case 'S':   case 's':   goto yy8;
   case 'T':   case 't':   goto yy9;
   case 'Z':   case 'z':   goto yy10;
   case '[':   goto yy12;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy32;
   default:   goto yy15;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy25;
   default:   goto yy15;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy25;
   default:   goto yy15;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'M':   case 'c':   case 'f':   case 'm':   goto yy25;
   default:   goto yy15;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy25;
   default:   goto yy15;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy31;
   default:   goto yy15;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'P':   case 'l':   case 'p':   goto yy25;
   default:   goto yy15;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy25;
   default:   goto yy15;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy24;
   case 'S':   case 's':   goto yy25;
   default:   goto yy15;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy14:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy15:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy14;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy20;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy18;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy28;
   default:   goto yy15;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy26;
   default:   goto yy15;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy29;
   default:   goto yy15;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy25;
   default:   goto yy15;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':
   case '2':   goto yy25;
   default:   goto yy15;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgTRqEvSymType */

/*
    Func:  TRqEvSymVal  ->     */
/*!re2c
[cC][oO][1]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_CONTINUITY_TONE); }
[cC][oO][2]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_CONTINUITY_TEST); }
[nN][mM]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_NEW_MILLIWATT_TONE); }
[mM][mM]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_NEWEST_MILLIWATT_TONE); }
[oO][cC]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_REPORT_FAILURE); }
[oO][mM]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_OLD_MILLIWATT_TONE); }
[rR][oO]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_REORDER_TONE); }
[sS][iI][tT]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_SPECIAL_INFO_TONE); }
[tT][lL]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_TEST_LINE); }
[tT][pP]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_TEST_PATTERN); }
[zZ][zZ]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_NO_CIRCUIT); }
[aA][sS]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_ANSWER_SUPERVIS); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgTRqEvSymVal
*
*       Desc:  Description for the regular expression PkgTRqEvSymVal
*              [cC][oO][1]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_CONTINUITY_TONE); }
*              [cC][oO][2]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_CONTINUITY_TEST); }
*              [nN][mM]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_NEW_MILLIWATT_TONE); }
*              [mM][mM]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_NEWEST_MILLIWATT_TONE); }
*              [oO][cC]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_REPORT_FAILURE); }
*              [oO][mM]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_OLD_MILLIWATT_TONE); }
*              [rR][oO]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_REORDER_TONE); }
*              [sS][iI][tT]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_SPECIAL_INFO_TONE); }
*              [tT][lL]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_TEST_LINE); }
*              [tT][pP]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_TEST_PATTERN); }
*              [zZ][zZ]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_NO_CIRCUIT); }
*              [aA][sS]          { return (MGT_MGCP_PKG_T_RQ_EV_SYM_ANSWER_SUPERVIS); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgTRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgTRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgTRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy11;
   case 'C':   case 'c':   goto yy3;
   case 'M':   case 'm':   goto yy5;
   case 'N':   case 'n':   goto yy4;
   case 'O':   case 'o':   goto yy6;
   case 'R':   case 'r':   goto yy7;
   case 'S':   case 's':   goto yy8;
   case 'T':   case 't':   goto yy9;
   case 'Z':   case 'z':   goto yy10;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy35;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy33;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy31;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy29;
   case 'F':   case 'f':   goto yy27;
   case 'M':   case 'm':   goto yy25;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy23;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy20;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   case 'P':   case 'p':   goto yy16;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy14;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_RQ_EV_SYM_ANSWER_SUPERVIS;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_RQ_EV_SYM_NO_CIRCUIT;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_RQ_EV_SYM_TEST_PATTERN;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_RQ_EV_SYM_TEST_LINE;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy21;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_RQ_EV_SYM_SPECIAL_INFO_TONE;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_RQ_EV_SYM_REORDER_TONE;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_RQ_EV_SYM_OLD_MILLIWATT_TONE;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_RQ_EV_SYM_REPORT_FAILURE;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_RQ_EV_SYM_NEWEST_MILLIWATT_TONE;
      goto yyReturn;
    }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_RQ_EV_SYM_NEW_MILLIWATT_TONE;
      goto yyReturn;
    }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy36;
   case '2':   goto yy38;
   default:   goto yyErr;
   }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_RQ_EV_SYM_CONTINUITY_TONE;
      goto yyReturn;
    }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_RQ_EV_SYM_CONTINUITY_TEST;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgTRqEvSymVal */

/*
    Func:  TSgRqSymType  ->     */
/*!re2c

               known = [cC][oO][1] | [cC][oO][2] | [lL][bB] | [nN][mM] | [mM][mM] | [oO][mM] | [qQ][tT] | [rR][oO] | [sS][iI][tT] | [tT][lL] | [tT][pP] | [zZ][zZ] | [aA][sS] | [bB][lL] | [bB][zZ] | [cC][tT] | [pP][sS][tT];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgTSgRqSymType
*
*       Desc:  Description for the regular expression PkgTSgRqSymType
*              
*                             known = [cC][oO][1] | [cC][oO][2] | [lL][bB] | [nN][mM] | [mM][mM] | [oO][mM] | [qQ][tT] | [rR][oO] | [sS][iI][tT] | [tT][lL] | [tT][pP] | [zZ][zZ] | [aA][sS] | [bB][lL] | [bB][zZ] | [cC][tT] | [pP][sS][tT];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgTSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgTSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgTSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy21;
   case '*':   goto yy20;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':   goto yy18;
   case 'A':   case 'a':   goto yy13;
   case 'B':   case 'b':   goto yy14;
   case 'C':   case 'c':   goto yy3;
   case 'L':   case 'l':   goto yy4;
   case 'M':   case 'm':   goto yy6;
   case 'N':   case 'n':   goto yy5;
   case 'O':   case 'o':   goto yy7;
   case 'P':   case 'p':   goto yy15;
   case 'Q':   case 'q':   goto yy8;
   case 'R':   case 'r':   goto yy9;
   case 'S':   case 's':   goto yy10;
   case 'T':   case 't':   goto yy11;
   case 'Z':   case 'z':   goto yy12;
   case '[':   goto yy16;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy37;
   case 'T':   case 't':   goto yy29;
   default:   goto yy19;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy29;
   default:   goto yy19;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy29;
   default:   goto yy19;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy29;
   default:   goto yy19;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy29;
   default:   goto yy19;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy29;
   default:   goto yy19;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy29;
   default:   goto yy19;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy36;
   default:   goto yy19;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'P':   case 'l':   case 'p':   goto yy29;
   default:   goto yy19;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy29;
   default:   goto yy19;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy32;
   case 'S':   case 's':   goto yy29;
   default:   goto yy19;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'Z':   case 'l':   case 'z':   goto yy29;
   default:   goto yy19;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy28;
   default:   goto yy19;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy18:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy19:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy26;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy18;
   default:   goto yyErr;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy24;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy29;
   default:   goto yy19;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy30;
   default:   goto yy19;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy33;
   default:   goto yy19;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy34;
   default:   goto yy19;
   }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy29;
   default:   goto yy19;
   }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':
   case '2':   goto yy29;
   default:   goto yy19;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgTSgRqSymType */

/*
    Func:  TSgRqSymVal  ->     */
/*!re2c
[cC][oO][1]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_CONTINUITY_TONE); }
[cC][oO][2]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_CONTINUITY_TEST); }
[lL][bB]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_LOOPBACK); }
[nN][mM]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_NEW_MILLIWATT_TONE); }
[mM][mM]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_NEWEST_MILLIWATT_TONE); }
[oO][mM]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_OLD_MILLIWATT_TONE); }
[qQ][tT]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_QUIET_TERMINATION); }
[rR][oO]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_REORDER_TONE); }
[sS][iI][tT]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_SPECIAL_INFO_TONE); }
[tT][lL]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_TEST_LINE); }
[tT][pP]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_TEST_PATTERN); }
[zZ][zZ]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_NO_CIRCUIT); }
[aA][sS]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_ANSWER_SUPERVIS); }
[bB][lL]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_BLOCKING); }
[bB][zZ]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_BUSY); }
[cC][tT]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_CONTINUITY_TRSPDR); }
[pP][sS][tT]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_PERM_SIG_TONE); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgTSgRqSymVal
*
*       Desc:  Description for the regular expression PkgTSgRqSymVal
*              [cC][oO][1]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_CONTINUITY_TONE); }
*              [cC][oO][2]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_CONTINUITY_TEST); }
*              [lL][bB]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_LOOPBACK); }
*              [nN][mM]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_NEW_MILLIWATT_TONE); }
*              [mM][mM]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_NEWEST_MILLIWATT_TONE); }
*              [oO][mM]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_OLD_MILLIWATT_TONE); }
*              [qQ][tT]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_QUIET_TERMINATION); }
*              [rR][oO]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_REORDER_TONE); }
*              [sS][iI][tT]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_SPECIAL_INFO_TONE); }
*              [tT][lL]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_TEST_LINE); }
*              [tT][pP]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_TEST_PATTERN); }
*              [zZ][zZ]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_NO_CIRCUIT); }
*              [aA][sS]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_ANSWER_SUPERVIS); }
*              [bB][lL]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_BLOCKING); }
*              [bB][zZ]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_BUSY); }
*              [cC][tT]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_CONTINUITY_TRSPDR); }
*              [pP][sS][tT]          { return (MGT_MGCP_PKG_T_SG_RQ_SYM_PERM_SIG_TONE); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgTSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgTSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgTSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy13;
   case 'B':   case 'b':   goto yy14;
   case 'C':   case 'c':   goto yy3;
   case 'L':   case 'l':   goto yy4;
   case 'M':   case 'm':   goto yy6;
   case 'N':   case 'n':   goto yy5;
   case 'O':   case 'o':   goto yy7;
   case 'P':   case 'p':   goto yy15;
   case 'Q':   case 'q':   goto yy8;
   case 'R':   case 'r':   goto yy9;
   case 'S':   case 's':   goto yy10;
   case 'T':   case 't':   goto yy11;
   case 'Z':   case 'z':   goto yy12;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy48;
   case 'T':   case 't':   goto yy46;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy44;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy42;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy40;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy38;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy36;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy34;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy31;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy29;
   case 'P':   case 'p':   goto yy27;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy25;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy23;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy21;
   case 'Z':   case 'z':   goto yy19;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_PERM_SIG_TONE;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_BUSY;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_BLOCKING;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_ANSWER_SUPERVIS;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_NO_CIRCUIT;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_TEST_PATTERN;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_TEST_LINE;
      goto yyReturn;
    }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy32;
   default:   goto yyErr;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_SPECIAL_INFO_TONE;
      goto yyReturn;
    }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_REORDER_TONE;
      goto yyReturn;
    }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_QUIET_TERMINATION;
      goto yyReturn;
    }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_OLD_MILLIWATT_TONE;
      goto yyReturn;
    }
yy40:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_NEWEST_MILLIWATT_TONE;
      goto yyReturn;
    }
yy42:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_NEW_MILLIWATT_TONE;
      goto yyReturn;
    }
yy44:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_LOOPBACK;
      goto yyReturn;
    }
yy46:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_CONTINUITY_TRSPDR;
      goto yyReturn;
    }
yy48:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy49;
   case '2':   goto yy51;
   default:   goto yyErr;
   }
yy49:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_CONTINUITY_TONE;
      goto yyReturn;
    }
yy51:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_T_SG_RQ_SYM_CONTINUITY_TEST;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgTSgRqSymVal */

#endif  /* GCP_PKG_MGCP_TRUNK */





/*
  Following are for the old packages which were shifted from 1.2 implementation
*/


   

#ifdef  GCP_PKG_MGCP_FAX


/*
    Func:  FXRRqEvSymType  ->     */
/*!re2c

               known = [gG][wW][fF][aA][xX] | [nN][oO][pP][fF][aA][xX] | [tT][3][8];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgFXRRqEvSymType
*
*       Desc:  Description for the regular expression PkgFXRRqEvSymType
*              
*                             known = [gG][wW][fF][aA][xX] | [nN][oO][pP][fF][aA][xX] | [tT][3][8];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgFXRRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgFXRRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgFXRRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy12;
   case '*':   goto yy11;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   case 'A':   case 'a':   goto yy6;
   case 'G':   case 'g':   goto yy3;
   case 'N':   case 'n':   goto yy4;
   case 'T':   case 't':   goto yy5;
   case '[':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy31;
   default:   goto yy10;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy27;
   default:   goto yy10;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '3':   goto yy23;
   default:   goto yy10;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy19;
   default:   goto yy10;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy9:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy10:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy17;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy20;
   default:   goto yy10;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy21;
   default:   goto yy10;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '8':   goto yy24;
   default:   goto yy10;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy25;
   default:   goto yy10;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy28;
   default:   goto yy10;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy29;
   default:   goto yy10;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy30;
   default:   goto yy10;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy24;
   default:   goto yy10;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy32;
   default:   goto yy10;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy33;
   default:   goto yy10;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy24;
   default:   goto yy10;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgFXRRqEvSymType */

/*
    Func:  FXRRqEvSymVal  ->     */
/*!re2c
[gG][wW][fF][aA][xX]          { return (MGT_MGCP_PKG_F_X_R_RQ_EV_SYM_GW_CNTRLD_FAX); }
[nN][oO][pP][fF][aA][xX]          { return (MGT_MGCP_PKG_F_X_R_RQ_EV_SYM_NO_SP_FAX_HNDLNG); }
[tT][3][8]          { return (MGT_MGCP_PKG_F_X_R_RQ_EV_SYM_T38_FAX_RELAY); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgFXRRqEvSymVal
*
*       Desc:  Description for the regular expression PkgFXRRqEvSymVal
*              [gG][wW][fF][aA][xX]          { return (MGT_MGCP_PKG_F_X_R_RQ_EV_SYM_GW_CNTRLD_FAX); }
*              [nN][oO][pP][fF][aA][xX]          { return (MGT_MGCP_PKG_F_X_R_RQ_EV_SYM_NO_SP_FAX_HNDLNG); }
*              [tT][3][8]          { return (MGT_MGCP_PKG_F_X_R_RQ_EV_SYM_T38_FAX_RELAY); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgFXRRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgFXRRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgFXRRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy3;
   case 'N':   case 'n':   goto yy4;
   case 'T':   case 't':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy15;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy9;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '3':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '8':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_F_X_R_RQ_EV_SYM_T38_FAX_RELAY;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_F_X_R_RQ_EV_SYM_NO_SP_FAX_HNDLNG;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy18;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_F_X_R_RQ_EV_SYM_GW_CNTRLD_FAX;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgFXRRqEvSymVal */

/*
    Func:  ConnOptFXRExtnName  ->     */
/*!re2c

[]/[0-9A-Za-z+\-_&!'|=#?.$*@[\]\^`{}~/]+          { return (MGT_MGCP_CONN_OPT_PKG_EXTN_NAME_UNKNOWN_EXTN); }
[fF][xX]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_FXR_FAX_HNDLNG); }
*/

/*
*
*       Fun:   mgMsgRegExpConnOptPkgFXRExtnName
*
*       Desc:  Description for the regular expression ConnOptPkgFXRExtnName
*              
*              []/[0-9A-Za-z+\-_&!'|=#?.$*@[\]\^`{}~/]+          { return (MGT_MGCP_CONN_OPT_PKG_EXTN_NAME_UNKNOWN_EXTN); }
*              [fF][xX]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_FXR_FAX_HNDLNG); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpConnOptPkgFXRExtnName
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpConnOptPkgFXRExtnName(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpConnOptPkgFXRExtnName)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '!':   case '#':
   case '$':   case '&':
   case '\'':   case '*':
   case '+':   case '-':
   case '.':
   case '/':
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case '=':   case '?':
   case '@':
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':
   case '[':   case ']':
   case '^':
   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':
   case '{':
   case '|':
   case '}':
   case '~':   goto yy3;
   case 'F':   case 'f':   goto yy6;
   default:   goto yyErr;
   }
yy3:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy4:   switch(yych)
   {
   case '!':   case '#':
   case '$':   case '&':
   case '\'':   case '*':
   case '+':   case '-':
   case '.':
   case '/':
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case '=':   case '?':
   case '@':
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':
   case '[':   case ']':
   case '^':
   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':
   case '{':
   case '|':
   case '}':
   case '~':   goto yy3;
   default:   goto yy5;
   }
yy5:
   { 
      yyret = MGT_MGCP_CONN_OPT_PKG_EXTN_NAME_UNKNOWN_EXTN;      tknCons = FALSE;
      goto yyReturn;
    }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy7;
   default:   goto yy4;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy8;
   default:   goto yy4;
   }
yy8:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = MGT_MGCP_CO_PKG_FXR_FAX_HNDLNG;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpConnOptPkgFXRExtnName */

/*
    Func:  CPFXRCPNames  ->     */
/*!re2c

[]/[A-Za-z0-9\-]+          { return (MGT_MGCP_CONN_PAR_PKG_EXTN_NAME_UNKNOWN_EXTN); }
[Pp][Gg][Ss]/[=]          { return (MGT_MGCP_CP_PKG_FXR_NUM_FAX_PGS_SENT); }
[Pp][Gg][Rr]/[=]          { return (MGT_MGCP_CP_PKG_FXR_NUM_FAX_PGS_RCVD); }
*/

/*
*
*       Fun:   mgMsgRegExpCPPkgFXRCPNames
*
*       Desc:  Description for the regular expression CPPkgFXRCPNames
*              
*              []/[A-Za-z0-9\-]+          { return (MGT_MGCP_CONN_PAR_PKG_EXTN_NAME_UNKNOWN_EXTN); }
*              [Pp][Gg][Ss]/[=]          { return (MGT_MGCP_CP_PKG_FXR_NUM_FAX_PGS_SENT); }
*              [Pp][Gg][Rr]/[=]          { return (MGT_MGCP_CP_PKG_FXR_NUM_FAX_PGS_RCVD); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpCPPkgFXRCPNames
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpCPPkgFXRCPNames(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpCPPkgFXRCPNames)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy3;
   case 'P':   case 'p':   goto yy6;
   default:   goto yyErr;
   }
yy3:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy4:   switch(yych)
   {
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy3;
   default:   goto yy5;
   }
yy5:
   { 
      yyret = MGT_MGCP_CONN_PAR_PKG_EXTN_NAME_UNKNOWN_EXTN;      tknCons = FALSE;
      goto yyReturn;
    }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy7;
   default:   goto yy4;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy8;
   case 'S':   case 's':   goto yy9;
   default:   goto yy4;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '=':   goto yy12;
   default:   goto yy4;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '=':   goto yy10;
   default:   goto yy4;
   }
yy10:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = MGT_MGCP_CP_PKG_FXR_NUM_FAX_PGS_SENT;
      goto yyReturn;
    }
yy12:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = MGT_MGCP_CP_PKG_FXR_NUM_FAX_PGS_RCVD;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpCPPkgFXRCPNames */

#endif   /* GCP_PKG_MGCP_FAX */



#ifdef  GCP_PKG_MGCP_ISUP_TRUNK

/*
    Func:  ITRqEvSymType  ->     */
/*!re2c

               known = [Cc][oO][1] | [cC][oO][2] | [Ff][tT] | [lL][dD] | [Mm][aA] | [Mm][tT] | [Oo][cC] | [Oo][fF];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgITRqEvSymType
*
*       Desc:  Description for the regular expression PkgITRqEvSymType
*              
*                             known = [Cc][oO][1] | [cC][oO][2] | [Ff][tT] | [lL][dD] | [Mm][aA] | [Mm][tT] | [Oo][cC] | [Oo][fF];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgITRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgITRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgITRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy14;
   case '*':   goto yy13;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':   case 'D':
   case 'E':   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':   case 'N':   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':   case 'd':
   case 'e':   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':   case 'n':   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   case 'A':   case 'a':   goto yy8;
   case 'C':   case 'c':   goto yy3;
   case 'F':   case 'f':   goto yy4;
   case 'L':   case 'l':   goto yy5;
   case 'M':   case 'm':   goto yy6;
   case 'O':   case 'o':   goto yy7;
   case '[':   goto yy9;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy28;
   default:   goto yy12;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy25;
   default:   goto yy12;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy25;
   default:   goto yy12;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'T':   case 'a':   case 't':   goto yy25;
   default:   goto yy12;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy25;
   default:   goto yy12;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy21;
   default:   goto yy12;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy11:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy12:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy17;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy22;
   default:   goto yy12;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yy12;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy26;
   default:   goto yy12;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':
   case '2':   goto yy25;
   default:   goto yy12;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgITRqEvSymType */

/*
    Func:  ITRqEvSymVal  ->     */
/*!re2c
[Cc][oO][1]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_CONTINUITY_TONE1); }
[cC][oO][2]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_CONTINUITY_TONE2); }
[Ff][tT]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_FAX_TONE); }
[lL][dD]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_LONG_DUR_CONN); }
[Mm][aA]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_MEDIA_START); }
[Mm][tT]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_MODEM_TONE); }
[Oo][cC]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_OPER_COMPLT); }
[Oo][fF]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_OPER_FAIL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgITRqEvSymVal
*
*       Desc:  Description for the regular expression PkgITRqEvSymVal
*              [Cc][oO][1]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_CONTINUITY_TONE1); }
*              [cC][oO][2]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_CONTINUITY_TONE2); }
*              [Ff][tT]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_FAX_TONE); }
*              [lL][dD]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_LONG_DUR_CONN); }
*              [Mm][aA]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_MEDIA_START); }
*              [Mm][tT]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_MODEM_TONE); }
*              [Oo][cC]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_OPER_COMPLT); }
*              [Oo][fF]          { return (MGT_MGCP_PKG_I_T_RQ_EV_SYM_OPER_FAIL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgITRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgITRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgITRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy3;
   case 'F':   case 'f':   goto yy4;
   case 'L':   case 'l':   goto yy5;
   case 'M':   case 'm':   goto yy6;
   case 'O':   case 'o':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy20;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy18;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy16;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy14;
   case 'T':   case 't':   goto yy12;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy10;
   case 'F':   case 'f':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_I_T_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_I_T_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_I_T_RQ_EV_SYM_MODEM_TONE;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_I_T_RQ_EV_SYM_MEDIA_START;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_I_T_RQ_EV_SYM_LONG_DUR_CONN;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_I_T_RQ_EV_SYM_FAX_TONE;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy21;
   case '2':   goto yy23;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_I_T_RQ_EV_SYM_CONTINUITY_TONE1;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_I_T_RQ_EV_SYM_CONTINUITY_TONE2;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgITRqEvSymVal */

/*
    Func:  ITSgRqSymType  ->     */
/*!re2c

               known = [Cc][oO][1] | [cC][oO][2] | [Rr][oO] | [Rr][tT];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgITSgRqSymType
*
*       Desc:  Description for the regular expression PkgITSgRqSymType
*              
*                             known = [Cc][oO][1] | [cC][oO][2] | [Rr][oO] | [Rr][tT];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgITSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgITSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgITSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy11;
   case '*':   goto yy10;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'A':   case 'a':   goto yy5;
   case 'C':   case 'c':   goto yy3;
   case 'R':   case 'r':   goto yy4;
   case '[':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy25;
   default:   goto yy9;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'T':   case 'o':   case 't':   goto yy22;
   default:   goto yy9;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy9;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy19;
   default:   goto yy9;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy20;
   default:   goto yy9;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yy9;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':
   case '2':   goto yy22;
   default:   goto yy9;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgITSgRqSymType */

/*
    Func:  ITSgRqSymVal  ->     */
/*!re2c
[Cc][oO][1]          { return (MGT_MGCP_PKG_I_T_SG_RQ_SYM_CONTINUITY_TONE1); }
[cC][oO][2]          { return (MGT_MGCP_PKG_I_T_SG_RQ_SYM_CONTINUITY_TONE2); }
[Rr][oO]          { return (MGT_MGCP_PKG_I_T_SG_RQ_SYM_REORDER_TONE); }
[Rr][tT]          { return (MGT_MGCP_PKG_I_T_SG_RQ_SYM_RINGBACK_TONE); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgITSgRqSymVal
*
*       Desc:  Description for the regular expression PkgITSgRqSymVal
*              [Cc][oO][1]          { return (MGT_MGCP_PKG_I_T_SG_RQ_SYM_CONTINUITY_TONE1); }
*              [cC][oO][2]          { return (MGT_MGCP_PKG_I_T_SG_RQ_SYM_CONTINUITY_TONE2); }
*              [Rr][oO]          { return (MGT_MGCP_PKG_I_T_SG_RQ_SYM_REORDER_TONE); }
*              [Rr][tT]          { return (MGT_MGCP_PKG_I_T_SG_RQ_SYM_RINGBACK_TONE); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgITSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgITSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgITSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy3;
   case 'R':   case 'r':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy9;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy7;
   case 'T':   case 't':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_I_T_SG_RQ_SYM_RINGBACK_TONE;
      goto yyReturn;
    }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_I_T_SG_RQ_SYM_REORDER_TONE;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy10;
   case '2':   goto yy12;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_I_T_SG_RQ_SYM_CONTINUITY_TONE1;
      goto yyReturn;
    }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_I_T_SG_RQ_SYM_CONTINUITY_TONE2;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgITSgRqSymVal */

#endif  /* GCP_PKG_MGCP_ISUP_TRUNK */



#ifdef  GCP_PKG_MGCP_MF

/*
    Func:  MRqEvSymType  ->     */
/*!re2c

               known = [0] | [1] | [2] | [3] | [4] | [5] | [6] | [7] | [8] | [9] | [Xx] | [Tt] | [Kk][0] | [Kk][1] | [Kk][2] | [Ss][0] | [Ss][1] | [Ss][2] | [Ss][3] | [wW][kK] | [wW][kK][oO] | [iI][sS] | [rR][sS] | [uU][sS] | [oO][fF];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMRqEvSymType
*
*       Desc:  Description for the regular expression PkgMRqEvSymType
*              
*                             known = [0] | [1] | [2] | [3] | [4] | [5] | [6] | [7] | [8] | [9] | [Xx] | [Tt] | [Kk][0] | [Kk][1] | [Kk][2] | [Ss][0] | [Ss][1] | [Ss][2] | [Ss][3] | [wW][kK] | [wW][kK][oO] | [iI][sS] | [rR][sS] | [uU][sS] | [oO][fF];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy17;
   case '*':   goto yy16;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'T':   case 'X':   case 't':   case 'x':   goto yy3;
   case 'A':   case 'a':   goto yy11;
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':   case 'J':   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':   case 'V':   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':   case 'j':   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':   case 'v':   case 'y':
   case 'z':   goto yy14;
   case 'I':   case 'i':   goto yy7;
   case 'K':   case 'k':   goto yy4;
   case 'O':   case 'o':   goto yy10;
   case 'R':   case 'r':   goto yy8;
   case 'S':   case 's':   goto yy5;
   case 'U':   case 'u':   goto yy9;
   case 'W':   case 'w':   goto yy6;
   case '[':   goto yy12;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy29;
   default:   goto yy15;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':   goto yy3;
   default:   goto yy15;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':   goto yy3;
   default:   goto yy15;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy28;
   default:   goto yy15;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy3;
   default:   goto yy15;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy3;
   default:   goto yy15;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy3;
   default:   goto yy15;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy3;
   default:   goto yy15;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy24;
   default:   goto yy15;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy14:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy15:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy14;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy20;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy18;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy25;
   default:   goto yy15;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy26;
   default:   goto yy15;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy29;
   case 'O':   case 'o':   goto yy3;
   default:   goto yy15;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMRqEvSymType */

/*
    Func:  MRqEvSymVal  ->     */
/*!re2c
[0]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF0); }
[1]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF1); }
[2]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF2); }
[3]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF3); }
[4]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF4); }
[5]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF5); }
[6]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF6); }
[7]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF7); }
[8]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF8); }
[9]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF9); }
[Xx]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_WILD_CARD_MATCH); }
[Tt]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_INTERDIG_TMR); }
[Kk][0]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF_K0_OR_KP); }
[Kk][1]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF_K1); }
[Kk][2]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF_K2); }
[Ss][0]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S0_OR_ST); }
[Ss][1]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S1); }
[Ss][2]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S2); }
[Ss][3]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S3); }
[wW][kK]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_WINK); }
[wW][kK][oO]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_WINK_OFF); }
[iI][sS]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_INCOMING_SEIZURE); }
[rR][sS]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_RET_SEIZURE); }
[uU][sS]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_UNSEIZE_CKT); }
[oO][fF]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_RPT_FAILURE); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMRqEvSymVal
*
*       Desc:  Description for the regular expression PkgMRqEvSymVal
*              [0]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF0); }
*              [1]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF1); }
*              [2]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF2); }
*              [3]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF3); }
*              [4]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF4); }
*              [5]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF5); }
*              [6]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF6); }
*              [7]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF7); }
*              [8]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF8); }
*              [9]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF9); }
*              [Xx]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_WILD_CARD_MATCH); }
*              [Tt]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_INTERDIG_TMR); }
*              [Kk][0]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF_K0_OR_KP); }
*              [Kk][1]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF_K1); }
*              [Kk][2]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF_K2); }
*              [Ss][0]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S0_OR_ST); }
*              [Ss][1]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S1); }
*              [Ss][2]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S2); }
*              [Ss][3]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S3); }
*              [wW][kK]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_WINK); }
*              [wW][kK][oO]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_WINK_OFF); }
*              [iI][sS]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_INCOMING_SEIZURE); }
*              [rR][sS]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_RET_SEIZURE); }
*              [uU][sS]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_UNSEIZE_CKT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_M_RQ_EV_SYM_RPT_FAILURE); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '0':   goto yy3;
   case '1':   goto yy5;
   case '2':   goto yy7;
   case '3':   goto yy9;
   case '4':   goto yy11;
   case '5':   goto yy13;
   case '6':   goto yy15;
   case '7':   goto yy17;
   case '8':   goto yy19;
   case '9':   goto yy21;
   case 'I':   case 'i':   goto yy30;
   case 'K':   case 'k':   goto yy27;
   case 'O':   case 'o':   goto yy33;
   case 'R':   case 'r':   goto yy31;
   case 'S':   case 's':   goto yy28;
   case 'T':   case 't':   goto yy25;
   case 'U':   case 'u':   goto yy32;
   case 'W':   case 'w':   goto yy29;
   case 'X':   case 'x':   goto yy23;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF0;
      goto yyReturn;
    }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF1;
      goto yyReturn;
    }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF2;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF3;
      goto yyReturn;
    }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF4;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF5;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF6;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF7;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF8;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF9;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_WILD_CARD_MATCH;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_INTERDIG_TMR;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy58;
   case '1':   goto yy56;
   case '2':   goto yy54;
   default:   goto yyErr;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy52;
   case '1':   goto yy50;
   case '2':   goto yy48;
   case '3':   goto yy46;
   default:   goto yyErr;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy42;
   default:   goto yyErr;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy40;
   default:   goto yyErr;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy38;
   default:   goto yyErr;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy36;
   default:   goto yyErr;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy34;
   default:   goto yyErr;
   }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_RPT_FAILURE;
      goto yyReturn;
    }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_UNSEIZE_CKT;
      goto yyReturn;
    }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_RET_SEIZURE;
      goto yyReturn;
    }
yy40:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_INCOMING_SEIZURE;
      goto yyReturn;
    }
yy42:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy44;
   default:   goto yy43;
   }
yy43:
   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_WINK;
      goto yyReturn;
    }
yy44:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_WINK_OFF;
      goto yyReturn;
    }
yy46:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S3;
      goto yyReturn;
    }
yy48:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S2;
      goto yyReturn;
    }
yy50:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S1;
      goto yyReturn;
    }
yy52:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S0_OR_ST;
      goto yyReturn;
    }
yy54:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF_K2;
      goto yyReturn;
    }
yy56:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF_K1;
      goto yyReturn;
    }
yy58:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_RQ_EV_SYM_MF_K0_OR_KP;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMRqEvSymVal */

/*
    Func:  MSgRqSymType  ->     */
/*!re2c

               known = [0] | [1] | [2] | [3] | [4] | [5] | [6] | [7] | [8] | [9] | [Tt] | [Kk][0] | [Kk][1] | [Kk][2] | [Ss][0] | [Ss][1] | [Ss][2] | [Ss][3] | [wW][kK] | [wW][kK][oO] | [iI][sS] | [rR][sS] | [uU][sS];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMSgRqSymType
*
*       Desc:  Description for the regular expression PkgMSgRqSymType
*              
*                             known = [0] | [1] | [2] | [3] | [4] | [5] | [6] | [7] | [8] | [9] | [Tt] | [Kk][0] | [Kk][1] | [Kk][2] | [Ss][0] | [Ss][1] | [Ss][2] | [Ss][3] | [wW][kK] | [wW][kK][oO] | [iI][sS] | [rR][sS] | [uU][sS];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy16;
   case '*':   goto yy15;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'T':   case 't':   goto yy3;
   case 'A':   case 'a':   goto yy10;
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':   case 'J':   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':   case 'V':   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':   case 'j':   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':   case 'v':   case 'x':
   case 'y':
   case 'z':   goto yy13;
   case 'I':   case 'i':   goto yy7;
   case 'K':   case 'k':   goto yy4;
   case 'R':   case 'r':   goto yy8;
   case 'S':   case 's':   goto yy5;
   case 'U':   case 'u':   goto yy9;
   case 'W':   case 'w':   goto yy6;
   case '[':   goto yy11;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy28;
   default:   goto yy14;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':   goto yy3;
   default:   goto yy14;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':   goto yy3;
   default:   goto yy14;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy27;
   default:   goto yy14;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy3;
   default:   goto yy14;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy3;
   default:   goto yy14;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy3;
   default:   goto yy14;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy23;
   default:   goto yy14;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy13:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy14:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy21;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy13;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy24;
   default:   goto yy14;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy25;
   default:   goto yy14;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy28;
   case 'O':   case 'o':   goto yy3;
   default:   goto yy14;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMSgRqSymType */

/*
    Func:  MSgRqSymVal  ->     */
/*!re2c
[0]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF0); }
[1]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF1); }
[2]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF2); }
[3]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF3); }
[4]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF4); }
[5]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF5); }
[6]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF6); }
[7]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF7); }
[8]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF8); }
[9]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF9); }
[Tt]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_INTERDIG_TMR); }
[Kk][0]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF_K0_OR_KP); }
[Kk][1]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF_K1); }
[Kk][2]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF_K2); }
[Ss][0]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S0_OR_ST); }
[Ss][1]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S1); }
[Ss][2]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S2); }
[Ss][3]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S3); }
[wW][kK]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_WINK); }
[wW][kK][oO]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_WINK_OFF); }
[iI][sS]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_INCOMING_SEIZURE); }
[rR][sS]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_RET_SEIZURE); }
[uU][sS]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_UNSEIZE_CKT); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMSgRqSymVal
*
*       Desc:  Description for the regular expression PkgMSgRqSymVal
*              [0]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF0); }
*              [1]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF1); }
*              [2]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF2); }
*              [3]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF3); }
*              [4]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF4); }
*              [5]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF5); }
*              [6]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF6); }
*              [7]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF7); }
*              [8]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF8); }
*              [9]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF9); }
*              [Tt]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_INTERDIG_TMR); }
*              [Kk][0]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF_K0_OR_KP); }
*              [Kk][1]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF_K1); }
*              [Kk][2]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF_K2); }
*              [Ss][0]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S0_OR_ST); }
*              [Ss][1]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S1); }
*              [Ss][2]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S2); }
*              [Ss][3]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S3); }
*              [wW][kK]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_WINK); }
*              [wW][kK][oO]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_WINK_OFF); }
*              [iI][sS]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_INCOMING_SEIZURE); }
*              [rR][sS]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_RET_SEIZURE); }
*              [uU][sS]          { return (MGT_MGCP_PKG_M_SG_RQ_SYM_UNSEIZE_CKT); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '0':   goto yy3;
   case '1':   goto yy5;
   case '2':   goto yy7;
   case '3':   goto yy9;
   case '4':   goto yy11;
   case '5':   goto yy13;
   case '6':   goto yy15;
   case '7':   goto yy17;
   case '8':   goto yy19;
   case '9':   goto yy21;
   case 'I':   case 'i':   goto yy28;
   case 'K':   case 'k':   goto yy25;
   case 'R':   case 'r':   goto yy29;
   case 'S':   case 's':   goto yy26;
   case 'T':   case 't':   goto yy23;
   case 'U':   case 'u':   goto yy30;
   case 'W':   case 'w':   goto yy27;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF0;
      goto yyReturn;
    }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF1;
      goto yyReturn;
    }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF2;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF3;
      goto yyReturn;
    }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF4;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF5;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF6;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF7;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF8;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF9;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_INTERDIG_TMR;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy53;
   case '1':   goto yy51;
   case '2':   goto yy49;
   default:   goto yyErr;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy47;
   case '1':   goto yy45;
   case '2':   goto yy43;
   case '3':   goto yy41;
   default:   goto yyErr;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy37;
   default:   goto yyErr;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy35;
   default:   goto yyErr;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy33;
   default:   goto yyErr;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy31;
   default:   goto yyErr;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_UNSEIZE_CKT;
      goto yyReturn;
    }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_RET_SEIZURE;
      goto yyReturn;
    }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_INCOMING_SEIZURE;
      goto yyReturn;
    }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy39;
   default:   goto yy38;
   }
yy38:
   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_WINK;
      goto yyReturn;
    }
yy39:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_WINK_OFF;
      goto yyReturn;
    }
yy41:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S3;
      goto yyReturn;
    }
yy43:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S2;
      goto yyReturn;
    }
yy45:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S1;
      goto yyReturn;
    }
yy47:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S0_OR_ST;
      goto yyReturn;
    }
yy49:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF_K2;
      goto yyReturn;
    }
yy51:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF_K1;
      goto yyReturn;
    }
yy53:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_SG_RQ_SYM_MF_K0_OR_KP;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMSgRqSymVal */

#endif  /* GCP_PKG_MGCP_MF */



#ifdef  GCP_PKG_MGCP_MF_TERM_PROTO


/*
    Func:  MTRqEvSymType  ->     */
/*!re2c

               known = [Ii][nN][fF] | [Oo][cC] | [Oo][fF] | [Oo][iI] | [Rr][eE][lL] | [Rr][lL][cC] | [Ss][uU][pP];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMTRqEvSymType
*
*       Desc:  Description for the regular expression PkgMTRqEvSymType
*              
*                             known = [Ii][nN][fF] | [Oo][cC] | [Oo][fF] | [Oo][iI] | [Rr][eE][lL] | [Rr][lL][cC] | [Ss][uU][pP];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMTRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMTRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMTRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy13;
   case '*':   goto yy12;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   case 'A':   case 'a':   goto yy7;
   case 'I':   case 'i':   goto yy3;
   case 'O':   case 'o':   goto yy4;
   case 'R':   case 'r':   goto yy5;
   case 'S':   case 's':   goto yy6;
   case '[':   goto yy8;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy30;
   default:   goto yy11;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'I':   case 'c':   case 'f':   case 'i':   goto yy25;
   default:   goto yy11;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy28;
   case 'L':   case 'l':   goto yy29;
   default:   goto yy11;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy24;
   default:   goto yy11;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy20;
   default:   goto yy11;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy10:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy11:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy18;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy21;
   default:   goto yy11;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yy11;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy25;
   default:   goto yy11;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy26;
   default:   goto yy11;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy25;
   default:   goto yy11;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy25;
   default:   goto yy11;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy25;
   default:   goto yy11;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMTRqEvSymType */

/*
    Func:  MTRqEvSymVal  ->     */
/*!re2c
[Ii][nN][fF]          { return (MGT_MGCP_PKG_M_T_RQ_EV_SYM_INFO_DGTS); }
[Oo][cC]          { return (MGT_MGCP_PKG_M_T_RQ_EV_SYM_OPER_COMPLT); }
[Oo][fF]          { return (MGT_MGCP_PKG_M_T_RQ_EV_SYM_OPER_FAIL); }
[Oo][iI]          { return (MGT_MGCP_PKG_M_T_RQ_EV_SYM_OPER_INTRPT); }
[Rr][eE][lL]          { return (MGT_MGCP_PKG_M_T_RQ_EV_SYM_RELEASE_CALL); }
[Rr][lL][cC]          { return (MGT_MGCP_PKG_M_T_RQ_EV_SYM_RELEASE_COMPLETE); }
[Ss][uU][pP]          { return (MGT_MGCP_PKG_M_T_RQ_EV_SYM_CALL_SETUP); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMTRqEvSymVal
*
*       Desc:  Description for the regular expression PkgMTRqEvSymVal
*              [Ii][nN][fF]          { return (MGT_MGCP_PKG_M_T_RQ_EV_SYM_INFO_DGTS); }
*              [Oo][cC]          { return (MGT_MGCP_PKG_M_T_RQ_EV_SYM_OPER_COMPLT); }
*              [Oo][fF]          { return (MGT_MGCP_PKG_M_T_RQ_EV_SYM_OPER_FAIL); }
*              [Oo][iI]          { return (MGT_MGCP_PKG_M_T_RQ_EV_SYM_OPER_INTRPT); }
*              [Rr][eE][lL]          { return (MGT_MGCP_PKG_M_T_RQ_EV_SYM_RELEASE_CALL); }
*              [Rr][lL][cC]          { return (MGT_MGCP_PKG_M_T_RQ_EV_SYM_RELEASE_COMPLETE); }
*              [Ss][uU][pP]          { return (MGT_MGCP_PKG_M_T_RQ_EV_SYM_CALL_SETUP); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMTRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMTRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMTRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   case 'O':   case 'o':   goto yy4;
   case 'R':   case 'r':   goto yy5;
   case 'S':   case 's':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy22;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy20;
   case 'F':   case 'f':   goto yy18;
   case 'I':   case 'i':   goto yy16;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy11;
   case 'L':   case 'l':   goto yy10;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_RQ_EV_SYM_CALL_SETUP;
      goto yyReturn;
    }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy14;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_RQ_EV_SYM_RELEASE_CALL;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_RQ_EV_SYM_RELEASE_COMPLETE;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_RQ_EV_SYM_OPER_INTRPT;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_RQ_EV_SYM_INFO_DGTS;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMTRqEvSymVal */

/*
    Func:  MTSgRqSymType  ->     */
/*!re2c

               known = [Aa][nN][sS] | [Bb][zZ] | [Hh][fF] | [Pp][sS][tT] | [Rr][eE][lL] | [Rr][eE][sS] | [Rr][lL][cC] | [Rr][oO] | [Ss][uU][sS];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMTSgRqSymType
*
*       Desc:  Description for the regular expression PkgMTSgRqSymType
*              
*                             known = [Aa][nN][sS] | [Bb][zZ] | [Hh][fF] | [Pp][sS][tT] | [Rr][eE][lL] | [Rr][eE][sS] | [Rr][lL][cC] | [Rr][oO] | [Ss][uU][sS];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMTSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMTSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMTSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy14;
   case '*':   goto yy13;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':   case 'Q':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':   case 'q':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'H':   case 'h':   goto yy5;
   case 'P':   case 'p':   goto yy6;
   case 'R':   case 'r':   goto yy7;
   case 'S':   case 's':   goto yy8;
   case '[':   goto yy9;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy28;
   case 'N':   case 'n':   goto yy29;
   default:   goto yy12;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy22;
   default:   goto yy12;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy22;
   default:   goto yy12;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy27;
   default:   goto yy12;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy25;
   case 'L':   case 'l':   goto yy26;
   case 'O':   case 'o':   goto yy22;
   default:   goto yy12;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy21;
   default:   goto yy12;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy11:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy12:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy17;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy22;
   default:   goto yy12;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yy12;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'S':   case 'l':   case 's':   goto yy22;
   default:   goto yy12;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy22;
   default:   goto yy12;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy22;
   default:   goto yy12;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy30;
   default:   goto yy12;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy22;
   default:   goto yy12;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   default:   goto yy12;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMTSgRqSymType */

/*
    Func:  MTSgRqSymVal  ->     */
/*!re2c
[Aa][nN][sS]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_CALL_ANSWER); }
[Bb][zZ]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_BUSY_TONE); }
[Hh][fF]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_HOOK_FLASH); }
[Pp][sS][tT]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_PERM_SIG_TONE); }
[Rr][eE][lL]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_RELEASE_CALL); }
[Rr][eE][sS]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_RESUME_CALL); }
[Rr][lL][cC]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_RELEASE_COMPLETE); }
[Rr][oO]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_REORDER_TONE); }
[Ss][uU][sS]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_SUSPEND_CALL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgMTSgRqSymVal
*
*       Desc:  Description for the regular expression PkgMTSgRqSymVal
*              [Aa][nN][sS]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_CALL_ANSWER); }
*              [Bb][zZ]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_BUSY_TONE); }
*              [Hh][fF]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_HOOK_FLASH); }
*              [Pp][sS][tT]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_PERM_SIG_TONE); }
*              [Rr][eE][lL]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_RELEASE_CALL); }
*              [Rr][eE][sS]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_RESUME_CALL); }
*              [Rr][lL][cC]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_RELEASE_COMPLETE); }
*              [Rr][oO]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_REORDER_TONE); }
*              [Ss][uU][sS]          { return (MGT_MGCP_PKG_M_T_SG_RQ_SYM_SUSPEND_CALL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgMTSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgMTSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgMTSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy4;
   case 'H':   case 'h':   goto yy5;
   case 'P':   case 'p':   goto yy6;
   case 'R':   case 'r':   goto yy7;
   case 'S':   case 's':   goto yy8;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy29;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy27;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy25;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy22;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy15;
   case 'L':   case 'l':   goto yy14;
   case 'O':   case 'o':   goto yy12;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_SG_RQ_SYM_SUSPEND_CALL;
      goto yyReturn;
    }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_SG_RQ_SYM_REORDER_TONE;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy20;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy16;
   case 'S':   case 's':   goto yy18;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_SG_RQ_SYM_RELEASE_CALL;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_SG_RQ_SYM_RESUME_CALL;
      goto yyReturn;
    }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_SG_RQ_SYM_RELEASE_COMPLETE;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_SG_RQ_SYM_PERM_SIG_TONE;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_SG_RQ_SYM_HOOK_FLASH;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_SG_RQ_SYM_BUSY_TONE;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy30;
   default:   goto yyErr;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_M_T_SG_RQ_SYM_CALL_ANSWER;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgMTSgRqSymVal */

#endif  /* GCP_PKG_MGCP_MF_TERM_PROTO */


#ifdef  GCP_PKG_MGCP_NAS_DATAOUT


/*
    Func:  NAORqEvSymType  ->     */
/*!re2c

               known = [rR][qQ];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgNAORqEvSymType
*
*       Desc:  Description for the regular expression PkgNAORqEvSymType
*              
*                             known = [rR][qQ];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgNAORqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgNAORqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgNAORqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy10;
   case '*':   goto yy9;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'A':   case 'a':   goto yy4;
   case 'R':   case 'r':   goto yy3;
   case '[':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Q':   case 'q':   goto yy21;
   default:   goto yy8;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yy8;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy8;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy8;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yy8;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgNAORqEvSymType */

/*
    Func:  NAORqEvSymVal  ->     */
/*!re2c
[rR][qQ]          { return (MGT_MGCP_PKG_N_A_O_RQ_EV_SYM_OUT_CALL_REQ); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgNAORqEvSymVal
*
*       Desc:  Description for the regular expression PkgNAORqEvSymVal
*              [rR][qQ]          { return (MGT_MGCP_PKG_N_A_O_RQ_EV_SYM_OUT_CALL_REQ); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgNAORqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgNAORqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgNAORqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Q':   case 'q':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_N_A_O_RQ_EV_SYM_OUT_CALL_REQ;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgNAORqEvSymVal */

/*
    Func:  ConnOptNAOExtnName  ->     */
/*!re2c

[]/[0-9A-Za-z+\-_&!'|=#?.$*@[\]\^`{}~/]+          { return (MGT_MGCP_CONN_OPT_PKG_EXTN_NAME_UNKNOWN_EXTN); }
[dD][uU][hH]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_NAO_DATA_USR_HNDL); }
*/

/*
*
*       Fun:   mgMsgRegExpConnOptPkgNAOExtnName
*
*       Desc:  Description for the regular expression ConnOptPkgNAOExtnName
*              
*              []/[0-9A-Za-z+\-_&!'|=#?.$*@[\]\^`{}~/]+          { return (MGT_MGCP_CONN_OPT_PKG_EXTN_NAME_UNKNOWN_EXTN); }
*              [dD][uU][hH]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_NAO_DATA_USR_HNDL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpConnOptPkgNAOExtnName
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpConnOptPkgNAOExtnName(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpConnOptPkgNAOExtnName)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '!':   case '#':
   case '$':   case '&':
   case '\'':   case '*':
   case '+':   case '-':
   case '.':
   case '/':
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case '=':   case '?':
   case '@':
   case 'A':
   case 'B':
   case 'C':   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':
   case '[':   case ']':
   case '^':
   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':
   case '{':
   case '|':
   case '}':
   case '~':   goto yy3;
   case 'D':   case 'd':   goto yy6;
   default:   goto yyErr;
   }
yy3:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy4:   switch(yych)
   {
   case '!':   case '#':
   case '$':   case '&':
   case '\'':   case '*':
   case '+':   case '-':
   case '.':
   case '/':
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case '=':   case '?':
   case '@':
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':
   case '[':   case ']':
   case '^':
   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':
   case '{':
   case '|':
   case '}':
   case '~':   goto yy3;
   default:   goto yy5;
   }
yy5:
   { 
      yyret = MGT_MGCP_CONN_OPT_PKG_EXTN_NAME_UNKNOWN_EXTN;      tknCons = FALSE;
      goto yyReturn;
    }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy7;
   default:   goto yy4;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy8;
   default:   goto yy4;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy9;
   default:   goto yy4;
   }
yy9:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = MGT_MGCP_CO_PKG_NAO_DATA_USR_HNDL;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpConnOptPkgNAOExtnName */

#endif  /* GCP_PKG_MGCP_NAS_DATAOUT */



#ifdef  GCP_PKG_MGCP_BASIC_NAS

/*
    Func:  NASRqEvSymType  ->     */
/*!re2c

               known = [aA][uU] | [aA][xX] | [cC][rR][qQ] | [oO][fF];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgNASRqEvSymType
*
*       Desc:  Description for the regular expression PkgNASRqEvSymType
*              
*                             known = [aA][uU] | [aA][xX] | [cC][rR][qQ] | [oO][fF];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgNASRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgNASRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgNASRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy11;
   case '*':   goto yy10;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'A':   case 'a':   goto yy3;
   case 'C':   case 'c':   goto yy4;
   case 'O':   case 'o':   goto yy5;
   case '[':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy22;
   case 'U':   case 'X':   case 'u':   case 'x':   goto yy18;
   default:   goto yy9;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy21;
   default:   goto yy9;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy18;
   default:   goto yy9;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy9;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Q':   case 'q':   goto yy18;
   default:   goto yy9;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy23;
   default:   goto yy9;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy24;
   default:   goto yy9;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgNASRqEvSymType */

/*
    Func:  NASRqEvSymVal  ->     */
/*!re2c
[aA][uU]          { return (MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_AUTH_SUCCD); }
[aA][xX]          { return (MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_AUTH_DENIED); }
[cC][rR][qQ]          { return (MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_CALL_REQ); }
[oO][fF]          { return (MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_NAS_FAIL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgNASRqEvSymVal
*
*       Desc:  Description for the regular expression PkgNASRqEvSymVal
*              [aA][uU]          { return (MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_AUTH_SUCCD); }
*              [aA][xX]          { return (MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_AUTH_DENIED); }
*              [cC][rR][qQ]          { return (MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_CALL_REQ); }
*              [oO][fF]          { return (MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_NAS_FAIL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgNASRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgNASRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgNASRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   case 'C':   case 'c':   goto yy4;
   case 'O':   case 'o':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy13;
   case 'X':   case 'x':   goto yy11;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy8;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_NAS_FAIL;
      goto yyReturn;
    }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Q':   case 'q':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_CALL_REQ;
      goto yyReturn;
    }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_AUTH_DENIED;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_AUTH_SUCCD;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgNASRqEvSymVal */

/*
    Func:  ConnOptNASExtnName  ->     */
/*!re2c

[]/[0-9A-Za-z+\-_&!'|=#?.$*@[\]\^`{}~/]+          { return (MGT_MGCP_CONN_OPT_PKG_EXTN_NAME_UNKNOWN_EXTN); }
[cC][dD][nN]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_NAS_CALLD_PARTY_NUM); }
[cC][gG][nN]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_NAS_CALLNG_PARTY_NUM); }
[bB][tT]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_NAS_BRR_TYPE); }
*/

/*
*
*       Fun:   mgMsgRegExpConnOptPkgNASExtnName
*
*       Desc:  Description for the regular expression ConnOptPkgNASExtnName
*              
*              []/[0-9A-Za-z+\-_&!'|=#?.$*@[\]\^`{}~/]+          { return (MGT_MGCP_CONN_OPT_PKG_EXTN_NAME_UNKNOWN_EXTN); }
*              [cC][dD][nN]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_NAS_CALLD_PARTY_NUM); }
*              [cC][gG][nN]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_NAS_CALLNG_PARTY_NUM); }
*              [bB][tT]/[:, \t\r\n]          { return (MGT_MGCP_CO_PKG_NAS_BRR_TYPE); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpConnOptPkgNASExtnName
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpConnOptPkgNASExtnName(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpConnOptPkgNASExtnName)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '!':   case '#':
   case '$':   case '&':
   case '\'':   case '*':
   case '+':   case '-':
   case '.':
   case '/':
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case '=':   case '?':
   case '@':
   case 'A':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':
   case '[':   case ']':
   case '^':
   case '_':
   case '`':
   case 'a':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':
   case '{':
   case '|':
   case '}':
   case '~':   goto yy3;
   case 'B':   case 'b':   goto yy6;
   case 'C':   case 'c':   goto yy7;
   default:   goto yyErr;
   }
yy3:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy4:   switch(yych)
   {
   case '!':   case '#':
   case '$':   case '&':
   case '\'':   case '*':
   case '+':   case '-':
   case '.':
   case '/':
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case '=':   case '?':
   case '@':
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':
   case '[':   case ']':
   case '^':
   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':
   case '{':
   case '|':
   case '}':
   case '~':   goto yy3;
   default:   goto yy5;
   }
yy5:
   { 
      yyret = MGT_MGCP_CONN_OPT_PKG_EXTN_NAME_UNKNOWN_EXTN;      tknCons = FALSE;
      goto yyReturn;
    }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy16;
   default:   goto yy4;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy9;
   case 'G':   case 'g':   goto yy8;
   default:   goto yy4;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy13;
   default:   goto yy4;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy10;
   default:   goto yy4;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy11;
   default:   goto yy4;
   }
yy11:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = MGT_MGCP_CO_PKG_NAS_CALLD_PARTY_NUM;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy14;
   default:   goto yy4;
   }
yy14:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = MGT_MGCP_CO_PKG_NAS_CALLNG_PARTY_NUM;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ':':   goto yy17;
   default:   goto yy4;
   }
yy17:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = MGT_MGCP_CO_PKG_NAS_BRR_TYPE;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpConnOptPkgNASExtnName */

/*
    Func:  ConnModValsNAS  ->     */
/*!re2c

[]/[A-Za-z0-9]+          { return (MGT_MGCP_CONN_MODE_PKG_EXTN_NAME_UNKNOWN_EXTN); }
[dD][aA][tT][aA]/[;\r\n]          { return (MGT_MGCP_CONN_MODE_PKG_NAS_EXTN_NAME_DATA); }
*/

/*
*
*       Fun:   mgMsgRegExpConnModValsPkgNAS
*
*       Desc:  Description for the regular expression ConnModValsPkgNAS
*              
*              []/[A-Za-z0-9]+          { return (MGT_MGCP_CONN_MODE_PKG_EXTN_NAME_UNKNOWN_EXTN); }
*              [dD][aA][tT][aA]/[;\r\n]          { return (MGT_MGCP_CONN_MODE_PKG_NAS_EXTN_NAME_DATA); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpConnModValsPkgNAS
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpConnModValsPkgNAS(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpConnModValsPkgNAS)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy3;
   case 'D':   case 'd':   goto yy6;
   default:   goto yyErr;
   }
yy3:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy4:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy3;
   default:   goto yy5;
   }
yy5:
   { 
      yyret = MGT_MGCP_CONN_MODE_PKG_EXTN_NAME_UNKNOWN_EXTN;      tknCons = FALSE;
      goto yyReturn;
    }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy7;
   default:   goto yy4;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy8;
   default:   goto yy4;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy9;
   default:   goto yy4;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case ';':   goto yy10;
   default:   goto yy4;
   }
yy10:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = MGT_MGCP_CONN_MODE_PKG_NAS_EXTN_NAME_DATA;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpConnModValsPkgNAS */

#endif  /* GCP_PKG_MGCP_BASIC_NAS */


#ifdef  GCP_PKG_MGCP_ADSI


/*
    Func:  SSgRqSymType  ->     */
/*!re2c

               known = [aA][dD][sS][iI];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgSSgRqSymType
*
*       Desc:  Description for the regular expression PkgSSgRqSymType
*              
*                             known = [aA][dD][sS][iI];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgSSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgSSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgSSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy9;
   case '*':   goto yy8;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy6;
   case 'A':   case 'a':   goto yy3;
   case '[':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy16;
   case 'L':   case 'l':   goto yy17;
   default:   goto yy7;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy6:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy7:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy6;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy12;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy21;
   default:   goto yy7;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy7;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy7;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy22;
   default:   goto yy7;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yy7;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgSSgRqSymType */

/*
    Func:  SSgRqSymVal  ->     */
/*!re2c
[aA][dD][sS][iI]          { return (MGT_MGCP_PKG_S_SG_RQ_SYM_ADSI_DISPLAY); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgSSgRqSymVal
*
*       Desc:  Description for the regular expression PkgSSgRqSymVal
*              [aA][dD][sS][iI]          { return (MGT_MGCP_PKG_S_SG_RQ_SYM_ADSI_DISPLAY); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgSSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgSSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgSSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_S_SG_RQ_SYM_ADSI_DISPLAY;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgSSgRqSymVal */

#endif /* GCP_PKG_MGCP_ADSI */

/* addition of new packages -
   Audio server packages - BAU & AAU
 */

#ifdef GCP_PKG_MGCP_AU_SRVR

/*
    Func:  BAURqEvSymType  ->     */
/*!re2c

               known = [oO][cC] | [oO][fF];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgBAURqEvSymType
*
*       Desc:  Description for the regular expression PkgBAURqEvSymType
*              
*                             known = [oO][cC] | [oO][fF];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgBAURqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgBAURqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgBAURqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy10;
   case '*':   goto yy9;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'A':   case 'a':   goto yy4;
   case 'O':   case 'o':   goto yy3;
   case '[':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'F':   case 'c':   case 'f':   goto yy21;
   default:   goto yy8;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yy8;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy8;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy8;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy22;
   default:   goto yy8;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgBAURqEvSymType */

/*
    Func:  BAURqEvSymVal  ->     */
/*!re2c
[oO][cC]          { return (MGT_MGCP_PKG_B_A_U_RQ_EV_SYM_OPER_COMPLT); }
[oO][fF]          { return (MGT_MGCP_PKG_B_A_U_RQ_EV_SYM_OPER_FAIL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgBAURqEvSymVal
*
*       Desc:  Description for the regular expression PkgBAURqEvSymVal
*              [oO][cC]          { return (MGT_MGCP_PKG_B_A_U_RQ_EV_SYM_OPER_COMPLT); }
*              [oO][fF]          { return (MGT_MGCP_PKG_B_A_U_RQ_EV_SYM_OPER_FAIL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgBAURqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgBAURqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgBAURqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy6;
   case 'F':   case 'f':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_A_U_RQ_EV_SYM_OPER_FAIL;
      goto yyReturn;
    }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_A_U_RQ_EV_SYM_OPER_COMPLT;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgBAURqEvSymVal */

/*
    Func:  BAUSgRqSymType  ->     */
/*!re2c

               known = [mM][aA] | [pP][aA] | [pP][cC] | [pP][rR];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgBAUSgRqSymType
*
*       Desc:  Description for the regular expression PkgBAUSgRqSymType
*              
*                             known = [mM][aA] | [pP][aA] | [pP][cC] | [pP][rR];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgBAUSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgBAUSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgBAUSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy11;
   case '*':   goto yy10;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':   case 'N':
   case 'O':   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':   case 'n':
   case 'o':   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'A':   case 'a':   goto yy5;
   case 'M':   case 'm':   goto yy3;
   case 'P':   case 'p':   goto yy4;
   case '[':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy22;
   default:   goto yy9;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'C':   case 'R':   case 'a':   case 'c':   case 'r':   goto yy22;
   default:   goto yy9;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy9;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy19;
   default:   goto yy9;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy20;
   default:   goto yy9;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yy9;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgBAUSgRqSymType */

/*
    Func:  BAUSgRqSymVal  ->     */
/*!re2c
[mM][aA]          { return (MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_MNG_AUDIO); }
[pP][aA]          { return (MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_PLAY_ANNC); }
[pP][cC]          { return (MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_PLAY_COLLECT); }
[pP][rR]          { return (MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_PLAY_RECORD); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgBAUSgRqSymVal
*
*       Desc:  Description for the regular expression PkgBAUSgRqSymVal
*              [mM][aA]          { return (MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_MNG_AUDIO); }
*              [pP][aA]          { return (MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_PLAY_ANNC); }
*              [pP][cC]          { return (MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_PLAY_COLLECT); }
*              [pP][rR]          { return (MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_PLAY_RECORD); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgBAUSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgBAUSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgBAUSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy3;
   case 'P':   case 'p':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy11;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy9;
   case 'C':   case 'c':   goto yy7;
   case 'R':   case 'r':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_PLAY_RECORD;
      goto yyReturn;
    }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_PLAY_COLLECT;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_PLAY_ANNC;
      goto yyReturn;
    }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_MNG_AUDIO;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgBAUSgRqSymVal */


#endif /* GCP_PKG_MGCP_AU_SRVR */

/* 
 * [TEL]: Code added for Display XML package
 */
#ifdef GCP_PKG_MGCP_DISPLAY_XML

/*
    Func:  XMLRqEvSymType  ->     */
/*!re2c

               known = [xX][mM][lL];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgXMLRqEvSymType
*
*       Desc:  Description for the regular expression PkgXMLRqEvSymType
*              
*                             known = [xX][mM][lL];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgXMLRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgXMLRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgXMLRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy10;
   case '*':   goto yy9;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':   case 'y':
   case 'z':   goto yy7;
   case 'A':   case 'a':   goto yy4;
   case 'X':   case 'x':   goto yy3;
   case '[':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy21;
   default:   goto yy8;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yy8;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy8;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy8;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy22;
   default:   goto yy8;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yy8;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgXMLRqEvSymType */

/*
    Func:  XMLRqEvSymVal  ->     */
/*!re2c
[xX][mM][lL]          { return (MGT_MGCP_PKG_X_M_L_RQ_EV_SYM_XML_DATA); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgXMLRqEvSymVal
*
*       Desc:  Description for the regular expression PkgXMLRqEvSymVal
*              [xX][mM][lL]          { return (MGT_MGCP_PKG_X_M_L_RQ_EV_SYM_XML_DATA); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgXMLRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgXMLRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgXMLRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_X_M_L_RQ_EV_SYM_XML_DATA;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgXMLRqEvSymVal */

/*
    Func:  XMLSgRqSymType  ->     */
/*!re2c

               known = [xX][mM][lL];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgXMLSgRqSymType
*
*       Desc:  Description for the regular expression PkgXMLSgRqSymType
*              
*                             known = [xX][mM][lL];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgXMLSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgXMLSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgXMLSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy10;
   case '*':   goto yy9;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':   case 'y':
   case 'z':   goto yy7;
   case 'A':   case 'a':   goto yy4;
   case 'X':   case 'x':   goto yy3;
   case '[':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy21;
   default:   goto yy8;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yy8;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy8;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy8;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy22;
   default:   goto yy8;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yy8;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgXMLSgRqSymType */

/*
    Func:  XMLSgRqSymVal  ->     */
/*!re2c
[xX][mM][lL]          { return (MGT_MGCP_PKG_X_M_L_SG_RQ_SYM_XML_DATA); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgXMLSgRqSymVal
*
*       Desc:  Description for the regular expression PkgXMLSgRqSymVal
*              [xX][mM][lL]          { return (MGT_MGCP_PKG_X_M_L_SG_RQ_SYM_XML_DATA); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgXMLSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgXMLSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgXMLSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_X_M_L_SG_RQ_SYM_XML_DATA;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgXMLSgRqSymVal */

#endif /* GCP_PKG_MGCP_DISPLAY_XML */

/* 
 * [TEL]: Code added for Feature Key package
 */
#ifdef GCP_PKG_MGCP_FEATURE_KEY

/*
    Func:  KYRqEvSymType  ->     */
/*!re2c

               known = [fF][kK][1] | [fF][kK][2] | [fF][kK][3] | [fF][kK][4] | [fF][kK][5] | [fF][kK][6] | [fF][kK][7] | [fF][kK][8] | [fF][kK][9] | [fF][kK][1][0] | [fF][kK][1][1] | [fF][kK][1][2] | [fF][kK][1][3] | [fF][kK][1][4] | [fF][kK][1][5] | [fF][kK][1][6] | [fF][kK][1][7] | [fF][kK][1][8] | [fF][kK][1][9] | [fF][kK][2][0] | [fF][kK][2][1] | [fF][kK][2][2] | [fF][kK][2][3] | [fF][kK][2][4] | [fF][kK][2][5] | [fF][kK][2][6] | [fF][kK][2][7] | [fF][kK][2][8] | [fF][kK][2][9] | [fF][kK][3][0] | [fF][kK][3][1] | [fF][kK][3][2] | [fF][kK][3][3] | [fF][kK][3][4] | [fF][kK][3][5] | [fF][kK][3][6] | [fF][kK][3][7] | [fF][kK][3][8] | [fF][kK][3][9] | [fF][kK][4][0] | [fF][kK][4][1] | [fF][kK][4][2] | [fF][kK][4][3] | [fF][kK][4][4] | [fF][kK][4][5] | [fF][kK][4][6] | [fF][kK][4][7] | [fF][kK][4][8] | [fF][kK][4][9] | [fF][kK][5][0] | [fF][kK][5][1] | [fF][kK][5][2] | [fF][kK][5][3] | [fF][kK][5][4] | [fF][kK][5][5] | [fF][kK][5][6] | [fF][kK][5][7] | [fF][kK][5][8] | [fF][kK][5][9] | [fF][kK][6][0] | [fF][kK][6][1] | [fF][kK][6][2] | [fF][kK][6][3] | [fF][kK][6][4] | [fF][kK][6][5] | [fF][kK][6][6] | [fF][kK][6][7] | [fF][kK][6][8] | [fF][kK][6][9] | [fF][kK][7][0] | [fF][kK][7][1] | [fF][kK][7][2] | [fF][kK][7][3] | [fF][kK][7][4] | [fF][kK][7][5] | [fF][kK][7][6] | [fF][kK][7][7] | [fF][kK][7][8] | [fF][kK][7][9] | [fF][kK][8][0] | [fF][kK][8][1] | [fF][kK][8][2] | [fF][kK][8][3] | [fF][kK][8][4] | [fF][kK][8][5] | [fF][kK][8][6] | [fF][kK][8][7] | [fF][kK][8][8] | [fF][kK][8][9] | [fF][kK][9][0] | [fF][kK][9][1] | [fF][kK][9][2] | [fF][kK][9][3] | [fF][kK][9][4] | [fF][kK][9][5] | [fF][kK][9][6] | [fF][kK][9][7] | [fF][kK][9][8] | [fF][kK][9][9];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgKYRqEvSymType
*
*       Desc:  Description for the regular expression PkgKYRqEvSymType
*              
*                             known = [fF][kK][1] | [fF][kK][2] | [fF][kK][3] | [fF][kK][4] | [fF][kK][5] | [fF][kK][6] | [fF][kK][7] | [fF][kK][8] | [fF][kK][9] | [fF][kK][1][0] | [fF][kK][1][1] | [fF][kK][1][2] | [fF][kK][1][3] | [fF][kK][1][4] | [fF][kK][1][5] | [fF][kK][1][6] | [fF][kK][1][7] | [fF][kK][1][8] | [fF][kK][1][9] | [fF][kK][2][0] | [fF][kK][2][1] | [fF][kK][2][2] | [fF][kK][2][3] | [fF][kK][2][4] | [fF][kK][2][5] | [fF][kK][2][6] | [fF][kK][2][7] | [fF][kK][2][8] | [fF][kK][2][9] | [fF][kK][3][0] | [fF][kK][3][1] | [fF][kK][3][2] | [fF][kK][3][3] | [fF][kK][3][4] | [fF][kK][3][5] | [fF][kK][3][6] | [fF][kK][3][7] | [fF][kK][3][8] | [fF][kK][3][9] | [fF][kK][4][0] | [fF][kK][4][1] | [fF][kK][4][2] | [fF][kK][4][3] | [fF][kK][4][4] | [fF][kK][4][5] | [fF][kK][4][6] | [fF][kK][4][7] | [fF][kK][4][8] | [fF][kK][4][9] | [fF][kK][5][0] | [fF][kK][5][1] | [fF][kK][5][2] | [fF][kK][5][3] | [fF][kK][5][4] | [fF][kK][5][5] | [fF][kK][5][6] | [fF][kK][5][7] | [fF][kK][5][8] | [fF][kK][5][9] | [fF][kK][6][0] | [fF][kK][6][1] | [fF][kK][6][2] | [fF][kK][6][3] | [fF][kK][6][4] | [fF][kK][6][5] | [fF][kK][6][6] | [fF][kK][6][7] | [fF][kK][6][8] | [fF][kK][6][9] | [fF][kK][7][0] | [fF][kK][7][1] | [fF][kK][7][2] | [fF][kK][7][3] | [fF][kK][7][4] | [fF][kK][7][5] | [fF][kK][7][6] | [fF][kK][7][7] | [fF][kK][7][8] | [fF][kK][7][9] | [fF][kK][8][0] | [fF][kK][8][1] | [fF][kK][8][2] | [fF][kK][8][3] | [fF][kK][8][4] | [fF][kK][8][5] | [fF][kK][8][6] | [fF][kK][8][7] | [fF][kK][8][8] | [fF][kK][8][9] | [fF][kK][9][0] | [fF][kK][9][1] | [fF][kK][9][2] | [fF][kK][9][3] | [fF][kK][9][4] | [fF][kK][9][5] | [fF][kK][9][6] | [fF][kK][9][7] | [fF][kK][9][8] | [fF][kK][9][9];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgKYRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgKYRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgKYRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy10;
   case '*':   goto yy9;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'A':   case 'a':   goto yy4;
   case 'F':   case 'f':   goto yy3;
   case '[':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy21;
   default:   goto yy8;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yy8;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy8;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy19;
   default:   goto yy8;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy22;
   case '2':   goto yy23;
   case '3':   goto yy24;
   case '4':   goto yy25;
   case '5':   goto yy26;
   case '6':   goto yy27;
   case '7':   goto yy28;
   case '8':   goto yy29;
   case '9':   goto yy30;
   default:   goto yy8;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy33;
   default:   goto yy8;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy33;
   default:   goto yy8;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy33;
   default:   goto yy8;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy33;
   default:   goto yy8;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy33;
   default:   goto yy8;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy33;
   default:   goto yy8;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy33;
   default:   goto yy8;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy33;
   default:   goto yy8;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy33;
   default:   goto yy8;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy31;
   default:   goto yy8;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgKYRqEvSymType */

/*
    Func:  KYRqEvSymVal  ->     */
/*!re2c
[fF][kK][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY1); }
[fF][kK][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY2); }
[fF][kK][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY3); }
[fF][kK][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY4); }
[fF][kK][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY5); }
[fF][kK][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY6); }
[fF][kK][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY7); }
[fF][kK][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY8); }
[fF][kK][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY9); }
[fF][kK][1][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY10); }
[fF][kK][1][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY11); }
[fF][kK][1][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY12); }
[fF][kK][1][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY13); }
[fF][kK][1][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY14); }
[fF][kK][1][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY15); }
[fF][kK][1][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY16); }
[fF][kK][1][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY17); }
[fF][kK][1][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY18); }
[fF][kK][1][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY19); }
[fF][kK][2][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY20); }
[fF][kK][2][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY21); }
[fF][kK][2][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY22); }
[fF][kK][2][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY23); }
[fF][kK][2][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY24); }
[fF][kK][2][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY25); }
[fF][kK][2][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY26); }
[fF][kK][2][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY27); }
[fF][kK][2][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY28); }
[fF][kK][2][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY29); }
[fF][kK][3][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY30); }
[fF][kK][3][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY31); }
[fF][kK][3][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY32); }
[fF][kK][3][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY33); }
[fF][kK][3][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY34); }
[fF][kK][3][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY35); }
[fF][kK][3][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY36); }
[fF][kK][3][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY37); }
[fF][kK][3][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY38); }
[fF][kK][3][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY39); }
[fF][kK][4][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY40); }
[fF][kK][4][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY41); }
[fF][kK][4][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY42); }
[fF][kK][4][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY43); }
[fF][kK][4][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY44); }
[fF][kK][4][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY45); }
[fF][kK][4][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY46); }
[fF][kK][4][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY47); }
[fF][kK][4][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY48); }
[fF][kK][4][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY49); }
[fF][kK][5][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY50); }
[fF][kK][5][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY51); }
[fF][kK][5][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY52); }
[fF][kK][5][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY53); }
[fF][kK][5][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY54); }
[fF][kK][5][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY55); }
[fF][kK][5][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY56); }
[fF][kK][5][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY57); }
[fF][kK][5][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY58); }
[fF][kK][5][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY59); }
[fF][kK][6][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY60); }
[fF][kK][6][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY61); }
[fF][kK][6][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY62); }
[fF][kK][6][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY63); }
[fF][kK][6][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY64); }
[fF][kK][6][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY65); }
[fF][kK][6][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY66); }
[fF][kK][6][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY67); }
[fF][kK][6][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY68); }
[fF][kK][6][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY69); }
[fF][kK][7][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY70); }
[fF][kK][7][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY71); }
[fF][kK][7][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY72); }
[fF][kK][7][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY73); }
[fF][kK][7][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY74); }
[fF][kK][7][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY75); }
[fF][kK][7][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY76); }
[fF][kK][7][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY77); }
[fF][kK][7][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY78); }
[fF][kK][7][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY79); }
[fF][kK][8][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY80); }
[fF][kK][8][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY81); }
[fF][kK][8][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY82); }
[fF][kK][8][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY83); }
[fF][kK][8][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY84); }
[fF][kK][8][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY85); }
[fF][kK][8][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY86); }
[fF][kK][8][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY87); }
[fF][kK][8][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY88); }
[fF][kK][8][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY89); }
[fF][kK][9][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY90); }
[fF][kK][9][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY91); }
[fF][kK][9][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY92); }
[fF][kK][9][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY93); }
[fF][kK][9][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY94); }
[fF][kK][9][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY95); }
[fF][kK][9][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY96); }
[fF][kK][9][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY97); }
[fF][kK][9][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY98); }
[fF][kK][9][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY99); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgKYRqEvSymVal
*
*       Desc:  Description for the regular expression PkgKYRqEvSymVal
*              [fF][kK][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY1); }
*              [fF][kK][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY2); }
*              [fF][kK][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY3); }
*              [fF][kK][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY4); }
*              [fF][kK][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY5); }
*              [fF][kK][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY6); }
*              [fF][kK][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY7); }
*              [fF][kK][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY8); }
*              [fF][kK][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY9); }
*              [fF][kK][1][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY10); }
*              [fF][kK][1][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY11); }
*              [fF][kK][1][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY12); }
*              [fF][kK][1][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY13); }
*              [fF][kK][1][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY14); }
*              [fF][kK][1][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY15); }
*              [fF][kK][1][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY16); }
*              [fF][kK][1][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY17); }
*              [fF][kK][1][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY18); }
*              [fF][kK][1][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY19); }
*              [fF][kK][2][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY20); }
*              [fF][kK][2][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY21); }
*              [fF][kK][2][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY22); }
*              [fF][kK][2][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY23); }
*              [fF][kK][2][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY24); }
*              [fF][kK][2][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY25); }
*              [fF][kK][2][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY26); }
*              [fF][kK][2][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY27); }
*              [fF][kK][2][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY28); }
*              [fF][kK][2][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY29); }
*              [fF][kK][3][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY30); }
*              [fF][kK][3][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY31); }
*              [fF][kK][3][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY32); }
*              [fF][kK][3][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY33); }
*              [fF][kK][3][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY34); }
*              [fF][kK][3][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY35); }
*              [fF][kK][3][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY36); }
*              [fF][kK][3][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY37); }
*              [fF][kK][3][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY38); }
*              [fF][kK][3][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY39); }
*              [fF][kK][4][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY40); }
*              [fF][kK][4][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY41); }
*              [fF][kK][4][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY42); }
*              [fF][kK][4][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY43); }
*              [fF][kK][4][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY44); }
*              [fF][kK][4][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY45); }
*              [fF][kK][4][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY46); }
*              [fF][kK][4][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY47); }
*              [fF][kK][4][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY48); }
*              [fF][kK][4][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY49); }
*              [fF][kK][5][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY50); }
*              [fF][kK][5][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY51); }
*              [fF][kK][5][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY52); }
*              [fF][kK][5][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY53); }
*              [fF][kK][5][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY54); }
*              [fF][kK][5][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY55); }
*              [fF][kK][5][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY56); }
*              [fF][kK][5][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY57); }
*              [fF][kK][5][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY58); }
*              [fF][kK][5][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY59); }
*              [fF][kK][6][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY60); }
*              [fF][kK][6][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY61); }
*              [fF][kK][6][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY62); }
*              [fF][kK][6][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY63); }
*              [fF][kK][6][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY64); }
*              [fF][kK][6][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY65); }
*              [fF][kK][6][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY66); }
*              [fF][kK][6][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY67); }
*              [fF][kK][6][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY68); }
*              [fF][kK][6][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY69); }
*              [fF][kK][7][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY70); }
*              [fF][kK][7][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY71); }
*              [fF][kK][7][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY72); }
*              [fF][kK][7][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY73); }
*              [fF][kK][7][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY74); }
*              [fF][kK][7][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY75); }
*              [fF][kK][7][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY76); }
*              [fF][kK][7][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY77); }
*              [fF][kK][7][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY78); }
*              [fF][kK][7][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY79); }
*              [fF][kK][8][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY80); }
*              [fF][kK][8][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY81); }
*              [fF][kK][8][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY82); }
*              [fF][kK][8][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY83); }
*              [fF][kK][8][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY84); }
*              [fF][kK][8][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY85); }
*              [fF][kK][8][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY86); }
*              [fF][kK][8][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY87); }
*              [fF][kK][8][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY88); }
*              [fF][kK][8][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY89); }
*              [fF][kK][9][0]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY90); }
*              [fF][kK][9][1]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY91); }
*              [fF][kK][9][2]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY92); }
*              [fF][kK][9][3]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY93); }
*              [fF][kK][9][4]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY94); }
*              [fF][kK][9][5]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY95); }
*              [fF][kK][9][6]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY96); }
*              [fF][kK][9][7]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY97); }
*              [fF][kK][9][8]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY98); }
*              [fF][kK][9][9]          { return (MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY99); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgKYRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgKYRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgKYRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '1':   goto yy5;
   case '2':   goto yy7;
   case '3':   goto yy9;
   case '4':   goto yy11;
   case '5':   goto yy13;
   case '6':   goto yy15;
   case '7':   goto yy17;
   case '8':   goto yy19;
   case '9':   goto yy21;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy201;
   case '1':   goto yy199;
   case '2':   goto yy197;
   case '3':   goto yy195;
   case '4':   goto yy193;
   case '5':   goto yy191;
   case '6':   goto yy189;
   case '7':   goto yy187;
   case '8':   goto yy185;
   case '9':   goto yy183;
   default:   goto yy6;
   }
yy6:
   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY1;
      goto yyReturn;
    }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy181;
   case '1':   goto yy179;
   case '2':   goto yy177;
   case '3':   goto yy175;
   case '4':   goto yy173;
   case '5':   goto yy171;
   case '6':   goto yy169;
   case '7':   goto yy167;
   case '8':   goto yy165;
   case '9':   goto yy163;
   default:   goto yy8;
   }
yy8:
   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY2;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy161;
   case '1':   goto yy159;
   case '2':   goto yy157;
   case '3':   goto yy155;
   case '4':   goto yy153;
   case '5':   goto yy151;
   case '6':   goto yy149;
   case '7':   goto yy147;
   case '8':   goto yy145;
   case '9':   goto yy143;
   default:   goto yy10;
   }
yy10:
   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY3;
      goto yyReturn;
    }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy141;
   case '1':   goto yy139;
   case '2':   goto yy137;
   case '3':   goto yy135;
   case '4':   goto yy133;
   case '5':   goto yy131;
   case '6':   goto yy129;
   case '7':   goto yy127;
   case '8':   goto yy125;
   case '9':   goto yy123;
   default:   goto yy12;
   }
yy12:
   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY4;
      goto yyReturn;
    }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy121;
   case '1':   goto yy119;
   case '2':   goto yy117;
   case '3':   goto yy115;
   case '4':   goto yy113;
   case '5':   goto yy111;
   case '6':   goto yy109;
   case '7':   goto yy107;
   case '8':   goto yy105;
   case '9':   goto yy103;
   default:   goto yy14;
   }
yy14:
   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY5;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy101;
   case '1':   goto yy99;
   case '2':   goto yy97;
   case '3':   goto yy95;
   case '4':   goto yy93;
   case '5':   goto yy91;
   case '6':   goto yy89;
   case '7':   goto yy87;
   case '8':   goto yy85;
   case '9':   goto yy83;
   default:   goto yy16;
   }
yy16:
   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY6;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy81;
   case '1':   goto yy79;
   case '2':   goto yy77;
   case '3':   goto yy75;
   case '4':   goto yy73;
   case '5':   goto yy71;
   case '6':   goto yy69;
   case '7':   goto yy67;
   case '8':   goto yy65;
   case '9':   goto yy63;
   default:   goto yy18;
   }
yy18:
   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY7;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy61;
   case '1':   goto yy59;
   case '2':   goto yy57;
   case '3':   goto yy55;
   case '4':   goto yy53;
   case '5':   goto yy51;
   case '6':   goto yy49;
   case '7':   goto yy47;
   case '8':   goto yy45;
   case '9':   goto yy43;
   default:   goto yy20;
   }
yy20:
   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY8;
      goto yyReturn;
    }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy41;
   case '1':   goto yy39;
   case '2':   goto yy37;
   case '3':   goto yy35;
   case '4':   goto yy33;
   case '5':   goto yy31;
   case '6':   goto yy29;
   case '7':   goto yy27;
   case '8':   goto yy25;
   case '9':   goto yy23;
   default:   goto yy22;
   }
yy22:
   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY9;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY99;
      goto yyReturn;
    }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY98;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY97;
      goto yyReturn;
    }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY96;
      goto yyReturn;
    }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY95;
      goto yyReturn;
    }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY94;
      goto yyReturn;
    }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY93;
      goto yyReturn;
    }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY92;
      goto yyReturn;
    }
yy39:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY91;
      goto yyReturn;
    }
yy41:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY90;
      goto yyReturn;
    }
yy43:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY89;
      goto yyReturn;
    }
yy45:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY88;
      goto yyReturn;
    }
yy47:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY87;
      goto yyReturn;
    }
yy49:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY86;
      goto yyReturn;
    }
yy51:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY85;
      goto yyReturn;
    }
yy53:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY84;
      goto yyReturn;
    }
yy55:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY83;
      goto yyReturn;
    }
yy57:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY82;
      goto yyReturn;
    }
yy59:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY81;
      goto yyReturn;
    }
yy61:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY80;
      goto yyReturn;
    }
yy63:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY79;
      goto yyReturn;
    }
yy65:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY78;
      goto yyReturn;
    }
yy67:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY77;
      goto yyReturn;
    }
yy69:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY76;
      goto yyReturn;
    }
yy71:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY75;
      goto yyReturn;
    }
yy73:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY74;
      goto yyReturn;
    }
yy75:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY73;
      goto yyReturn;
    }
yy77:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY72;
      goto yyReturn;
    }
yy79:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY71;
      goto yyReturn;
    }
yy81:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY70;
      goto yyReturn;
    }
yy83:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY69;
      goto yyReturn;
    }
yy85:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY68;
      goto yyReturn;
    }
yy87:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY67;
      goto yyReturn;
    }
yy89:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY66;
      goto yyReturn;
    }
yy91:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY65;
      goto yyReturn;
    }
yy93:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY64;
      goto yyReturn;
    }
yy95:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY63;
      goto yyReturn;
    }
yy97:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY62;
      goto yyReturn;
    }
yy99:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY61;
      goto yyReturn;
    }
yy101:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY60;
      goto yyReturn;
    }
yy103:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY59;
      goto yyReturn;
    }
yy105:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY58;
      goto yyReturn;
    }
yy107:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY57;
      goto yyReturn;
    }
yy109:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY56;
      goto yyReturn;
    }
yy111:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY55;
      goto yyReturn;
    }
yy113:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY54;
      goto yyReturn;
    }
yy115:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY53;
      goto yyReturn;
    }
yy117:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY52;
      goto yyReturn;
    }
yy119:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY51;
      goto yyReturn;
    }
yy121:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY50;
      goto yyReturn;
    }
yy123:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY49;
      goto yyReturn;
    }
yy125:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY48;
      goto yyReturn;
    }
yy127:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY47;
      goto yyReturn;
    }
yy129:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY46;
      goto yyReturn;
    }
yy131:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY45;
      goto yyReturn;
    }
yy133:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY44;
      goto yyReturn;
    }
yy135:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY43;
      goto yyReturn;
    }
yy137:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY42;
      goto yyReturn;
    }
yy139:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY41;
      goto yyReturn;
    }
yy141:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY40;
      goto yyReturn;
    }
yy143:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY39;
      goto yyReturn;
    }
yy145:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY38;
      goto yyReturn;
    }
yy147:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY37;
      goto yyReturn;
    }
yy149:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY36;
      goto yyReturn;
    }
yy151:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY35;
      goto yyReturn;
    }
yy153:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY34;
      goto yyReturn;
    }
yy155:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY33;
      goto yyReturn;
    }
yy157:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY32;
      goto yyReturn;
    }
yy159:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY31;
      goto yyReturn;
    }
yy161:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY30;
      goto yyReturn;
    }
yy163:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY29;
      goto yyReturn;
    }
yy165:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY28;
      goto yyReturn;
    }
yy167:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY27;
      goto yyReturn;
    }
yy169:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY26;
      goto yyReturn;
    }
yy171:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY25;
      goto yyReturn;
    }
yy173:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY24;
      goto yyReturn;
    }
yy175:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY23;
      goto yyReturn;
    }
yy177:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY22;
      goto yyReturn;
    }
yy179:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY21;
      goto yyReturn;
    }
yy181:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY20;
      goto yyReturn;
    }
yy183:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY19;
      goto yyReturn;
    }
yy185:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY18;
      goto yyReturn;
    }
yy187:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY17;
      goto yyReturn;
    }
yy189:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY16;
      goto yyReturn;
    }
yy191:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY15;
      goto yyReturn;
    }
yy193:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY14;
      goto yyReturn;
    }
yy195:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY13;
      goto yyReturn;
    }
yy197:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY12;
      goto yyReturn;
    }
yy199:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY11;
      goto yyReturn;
    }
yy201:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY10;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgKYRqEvSymVal */

/*
    Func:  KYSgRqSymType  ->     */
/*!re2c

               known = [kK][sS] | [lL][sS];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgKYSgRqSymType
*
*       Desc:  Description for the regular expression PkgKYSgRqSymType
*              
*                             known = [kK][sS] | [lL][sS];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgKYSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgKYSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgKYSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy11;
   case '*':   goto yy10;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'A':   case 'a':   goto yy5;
   case 'K':   case 'k':   goto yy3;
   case 'L':   case 'l':   goto yy4;
   case '[':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy22;
   default:   goto yy9;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy22;
   default:   goto yy9;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy9;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy19;
   default:   goto yy9;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy20;
   default:   goto yy9;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy23;
   default:   goto yy9;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgKYSgRqSymType */

/*
    Func:  KYSgRqSymVal  ->     */
/*!re2c
[kK][sS]          { return (MGT_MGCP_PKG_K_Y_SG_RQ_SYM_KEY_STATE); }
[lL][sS]          { return (MGT_MGCP_PKG_K_Y_SG_RQ_SYM_SET_LABEL); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgKYSgRqSymVal
*
*       Desc:  Description for the regular expression PkgKYSgRqSymVal
*              [kK][sS]          { return (MGT_MGCP_PKG_K_Y_SG_RQ_SYM_KEY_STATE); }
*              [lL][sS]          { return (MGT_MGCP_PKG_K_Y_SG_RQ_SYM_SET_LABEL); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgKYSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgKYSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgKYSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy3;
   case 'L':   case 'l':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy7;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_SG_RQ_SYM_SET_LABEL;
      goto yyReturn;
    }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_K_Y_SG_RQ_SYM_KEY_STATE;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgKYSgRqSymVal */

#endif /* GCP_PKG_MGCP_FEATURE_KEY */

/*
 * [TEL]: Code added for Business Phone package 
 */
#ifdef GCP_PKG_MGCP_BUS_PHONE

/*
    Func:  BPSgRqSymType  ->     */
/*!re2c

               known = [hH][dD] | [hH][uU] | [bB][eE][eE][pP];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgBPSgRqSymType
*
*       Desc:  Description for the regular expression PkgBPSgRqSymType
*              
*                             known = [hH][dD] | [hH][uU] | [bB][eE][eE][pP];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgBPSgRqSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgBPSgRqSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgBPSgRqSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy11;
   case '*':   goto yy10;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'A':   case 'a':   goto yy5;
   case 'B':   case 'b':   goto yy4;
   case 'H':   case 'h':   goto yy3;
   case '[':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'U':   case 'd':   case 'u':   goto yy24;
   default:   goto yy9;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy22;
   default:   goto yy9;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy9;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy16;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy14;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy19;
   default:   goto yy9;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy20;
   default:   goto yy9;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy23;
   default:   goto yy9;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy24;
   default:   goto yy9;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy25;
   default:   goto yy9;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgBPSgRqSymType */

/*
    Func:  BPSgRqSymVal  ->     */
/*!re2c
[hH][dD]          { return (MGT_MGCP_PKG_B_P_SG_RQ_SYM_FRC_OFF_HK); }
[hH][uU]          { return (MGT_MGCP_PKG_B_P_SG_RQ_SYM_FRC_ON_HK); }
[bB][eE][eE][pP]          { return (MGT_MGCP_PKG_B_P_SG_RQ_SYM_BEEP); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgBPSgRqSymVal
*
*       Desc:  Description for the regular expression PkgBPSgRqSymVal
*              [hH][dD]          { return (MGT_MGCP_PKG_B_P_SG_RQ_SYM_FRC_OFF_HK); }
*              [hH][uU]          { return (MGT_MGCP_PKG_B_P_SG_RQ_SYM_FRC_ON_HK); }
*              [bB][eE][eE][pP]          { return (MGT_MGCP_PKG_B_P_SG_RQ_SYM_BEEP); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgBPSgRqSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgBPSgRqSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgBPSgRqSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy4;
   case 'H':   case 'h':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy11;
   case 'U':   case 'u':   goto yy9;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_P_SG_RQ_SYM_BEEP;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_P_SG_RQ_SYM_FRC_ON_HK;
      goto yyReturn;
    }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_P_SG_RQ_SYM_FRC_OFF_HK;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgBPSgRqSymVal */

#endif /* GCP_PKG_MGCP_BUS_PHONE */

/*
 * [TEL]: Code added for Base package 
 */
#ifdef  GCP_PKG_MGCP_BASE

/*
    Func:  BRqEvSymType  ->     */
/*!re2c

               known = [eE][nN][fF] | [oO][eE][fF] | [qQ][bB][oO];
               all = [Aa][Ll][Ll];
               range = "[";
               known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
               all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
               range                { return (MGT_DESC_EVENT_RANGE); }
[A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
               "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
               "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgBRqEvSymType
*
*       Desc:  Description for the regular expression PkgBRqEvSymType
*              
*                             known = [eE][nN][fF] | [oO][eE][fF] | [qQ][bB][oO];
*                             all = [Aa][Ll][Ll];
*                             range = "[";
*                             known[,()@\r\n]      { return (MGT_DESC_EVENT_KNOWN); }
*                             all[,()@\r\n]        { return (MGT_DESC_EVENT_ALL); }
*                             range                { return (MGT_DESC_EVENT_RANGE); }
*              [A-Za-z0-9][A-Za-z0-9-]*[,()@\r\n]  { return (MGT_DESC_EVENT_ID); }
*                             "*"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_STAR); }
*                             "#"[,()@\r\n]        { return (MGT_DESC_EVENT_DTMF_POUND); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgBRqEvSymType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgBRqEvSymType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgBRqEvSymType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '#':   goto yy12;
   case '*':   goto yy11;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   case 'A':   case 'a':   goto yy6;
   case 'E':   case 'e':   goto yy3;
   case 'O':   case 'o':   goto yy4;
   case 'Q':   case 'q':   goto yy5;
   case '[':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy28;
   default:   goto yy10;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy27;
   default:   goto yy10;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy23;
   default:   goto yy10;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy19;
   default:   goto yy10;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_RANGE;
      goto yyReturn;
    }
yy9:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy10:   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy17;
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy15;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_POUND;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_DTMF_STAR;
      goto yyReturn;
    }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ID;
      goto yyReturn;
    }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy20;
   default:   goto yy10;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy21;
   default:   goto yy10;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_ALL;
      goto yyReturn;
    }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy24;
   default:   goto yy10;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case '(':
   case ')':   case ',':   case '@':   goto yy25;
   default:   goto yy10;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_DESC_EVENT_KNOWN;
      goto yyReturn;
    }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy24;
   default:   goto yy10;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy24;
   default:   goto yy10;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgBRqEvSymType */

/*
    Func:  BRqEvSymVal  ->     */
/*!re2c
[eE][nN][fF]          { return (MGT_MGCP_PKG_B_RQ_EV_SYM_EM_RQNT_FAIL); }
[oO][eE][fF]          { return (MGT_MGCP_PKG_B_RQ_EV_SYM_OBS_EVTS_FUL); }
[qQ][bB][oO]          { return (MGT_MGCP_PKG_B_RQ_EV_SYM_QRTIN_BUF_OF); }
*/

/*
*
*       Fun:   mgMsgRegExpPkgBRqEvSymVal
*
*       Desc:  Description for the regular expression PkgBRqEvSymVal
*              [eE][nN][fF]          { return (MGT_MGCP_PKG_B_RQ_EV_SYM_EM_RQNT_FAIL); }
*              [oO][eE][fF]          { return (MGT_MGCP_PKG_B_RQ_EV_SYM_OBS_EVTS_FUL); }
*              [qQ][bB][oO]          { return (MGT_MGCP_PKG_B_RQ_EV_SYM_QRTIN_BUF_OF); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpPkgBRqEvSymVal
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpPkgBRqEvSymVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpPkgBRqEvSymVal)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy3;
   case 'O':   case 'o':   goto yy4;
   case 'Q':   case 'q':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy12;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy9;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_RQ_EV_SYM_QRTIN_BUF_OF;
      goto yyReturn;
    }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_RQ_EV_SYM_OBS_EVTS_FUL;
      goto yyReturn;
    }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   { 
      yyret = MGT_MGCP_PKG_B_RQ_EV_SYM_EM_RQNT_FAIL;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpPkgBRqEvSymVal */

/*
    Func:  ExtnParamB  ->     */
/*!re2c

[]/[A-Za-z0-9\-]+          { return (MGT_MGCP_PKG_EP_UNKNOWN_EXTN); }
[Pp][Rr]/[:,\r\n]          { return (MGT_MGCP_PKG_B_EP_PST_EVTS); }
[Nn][Ss]/[:,\r\n]          { return (MGT_MGCP_PKG_B_EP_NOT_FN_ST); }
*/

/*
*
*       Fun:   mgMsgRegExpExtnParamPkgB
*
*       Desc:  Description for the regular expression ExtnParamPkgB
*              
*              []/[A-Za-z0-9\-]+          { return (MGT_MGCP_PKG_EP_UNKNOWN_EXTN); }
*              [Pp][Rr]/[:,\r\n]          { return (MGT_MGCP_PKG_B_EP_PST_EVTS); }
*              [Nn][Ss]/[:,\r\n]          { return (MGT_MGCP_PKG_B_EP_NOT_FN_ST); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMsgRegExpExtnParamPkgB
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMsgRegExpExtnParamPkgB(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMsgRegExpExtnParamPkgB)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':   case 'O':   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':   case 'o':   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy3;
   case 'N':   case 'n':   goto yy6;
   case 'P':   case 'p':   goto yy7;
   default:   goto yyErr;
   }
yy3:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy4:   switch(yych)
   {
   case '-':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy3;
   default:   goto yy5;
   }
yy5:
   { 
      yyret = MGT_MGCP_PKG_EP_UNKNOWN_EXTN;
      goto yyReturn;
    }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy11;
   default:   goto yy4;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy8;
   default:   goto yy4;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case ',':   case ':':   goto yy9;
   default:   goto yy4;
   }
yy9:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = MGT_MGCP_PKG_B_EP_PST_EVTS;
      goto yyReturn;
    }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   case ',':   case ':':   goto yy12;
   default:   goto yy4;
   }
yy12:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = MGT_MGCP_PKG_B_EP_NOT_FN_ST;
      goto yyReturn;
    }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMsgRegExpExtnParamPkgB */

#endif /* GCP_PKG_MGCP_BASE */

/*
 *  [TEL]: End of additions for the packages
 */

#endif   /* GCP_VER_1_3 */

#endif   /* GCP_MGCP */




/********************************************************************30**

         End of file:     mgcp_prx.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:52:55 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      ra   1. GCP 1.3 release
/main/1    mg003.103  ra   1. Addition of support for Packet Cable Audio
                              Server packges - BAU & AAU. New functions
                              added.
                           2. Changed ALL function definations to return S16
                              instead of S8. Changed the type of yyret type
                              variables to S16.
/main/2      ---       TEL 1. Added regular expressions for the  
                              following MGCP packages.
                              1. Base package. 
                              2. Business phone package. 
                              3. Feature Key package. 
                              4. Display XML package. 
/main/2      ---      ka   1. Changes for Release v 1.4
/main/3      ---      pk   1. GCP 1.5 release
           mg002.105  ps   1. Removed patch reference for 1.3
*********************************************************************91*/
