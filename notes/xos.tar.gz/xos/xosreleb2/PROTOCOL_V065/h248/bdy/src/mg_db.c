/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     MGCP message database for encoding/decoding

     Type:     C include file

     Desc:     Definition for MGCP encoding/decoding routines

     File:     mg_db.c

     Sid:      mp_db.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:53:01 2005

     Prg:      rm

*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tkns.h"       /* common token structures */
#include "cm_abnf.h"       /* ABNF header file */
#include "cm_inet.h"       /* Inet header file */
#include "cm_tpt.h"        /* Transport  header file */
#include "cm_dns.h"        /* common DNS library defines */
#ifdef ZG
#include "cm_ftha.h"
#include "cm_psfft.h"
#endif /* ZG */
#include "cm_sdp.h"        /* SDP  header file */
#include "cm_mblk.h"       /*  Evenet memory managemnt header file */
#include "mgt.h"           /*  MGT interface definition */
#ifdef GCP_MGCP
#ifdef GCP_VER_1_3
#include "mgcp_pdb.h"   /*  Mgcp Packages specific header file  */
#endif /* GCP_VER_1_3 */
#endif /* GCP_MGCP */

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* Event memory managemnt header file */
#include "cm_abnf.x"       /* ABNF header file */
#include "cm_inet.x"       /* Inet header file */
#include "cm_tpt.x"        /* Transport  header file */
#include "cm_sdp.x"        /* SDP  header file */
#ifdef ZG
#include "cm_ftha.x"
#include "cm_psfft.x"
#endif /* ZG */
#include "cm_abndb.x"      /* Common database elemet definition */
#include "cm_sdpdb.x"
#include "mgt.x"           /* MGT interface definition */
#include "mg_db.x"         /* MGT database definition header file */
#ifdef GCP_MGCP
#ifdef GCP_VER_1_3
#include "mgcp_pdb.x"   /* Mgcp Packages specific extern file  */
#endif /* GCP_VER_1_3 */
#endif /* GCP_MGCP */

PUBLIC CmAbnfElmDef *mgMsgDefOnOffChcEnum[] =
{
   &cmMsgDefEnumOffBool,
   &cmMsgDefEnumOnBool
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefOnOffChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMsgDefOnOffChcEnum
};

PUBLIC CmAbnfElmDef mgMsgDefOnOff = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ECHCL/SIL ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 1,
   sizeof(TknU8),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefOnOffChc,
   mgMsgRegExpR30 
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMsgDefPortNumberRng = {1, 5, 0, (U32)0xFFFF};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefPortNumberRng = {1, 5};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMsgDefPortNumber = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NUMBER ",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 2,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&mgMsgDefPortNumberRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMsgDefPortNmbSeqElmnt[] =
{
   &cmMsgDefMetaColon,
   &mgMsgDefPortNumber
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefPortNmbSeq =
{
   2,
   mgMsgDefPortNmbSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefPortNmb = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PORTNMB ",
   "CM_RCOLON",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 3,
   sizeof(TknU16),
   (CM_ABNF_TKN_NOT_CONSUMED| CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefPortNmbSeq,
   cmAbnfRegExpColon
};

#ifdef GCP_MGCP
#define MG_ABNF_NEW_ELMNT_OFFSET 500
/************************************************************************
               Database element for Response ACK  paramater
************************************************************************/

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMsgDefCfmTrIdRng = {1, 9, 0, (U32)999999999};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefCfmTrIdRng = {1, 9};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMsgDefCfmTrId = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CFMTRID",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 4,
   sizeof(TknU32),  
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMsgDefCfmTrIdRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMsgDefCfmTrIdUprBndSeqElmnt[] =
{
   &cmMsgDefMetaHyphen,
   &mgMsgDefCfmTrId
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefCfmTrIdUprBndSeq =
{
   2,
   mgMsgDefCfmTrIdUprBndSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefCfmTrIdUprBnd = 
{
#ifdef CM_ABNF_DBG
   "MGCP: UPR_CFMTRID",
   "CM_RDASH",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 5,
   sizeof(TknU32),  
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefCfmTrIdUprBndSeq,
   cmAbnfRegExpHyphen
};

PUBLIC CmAbnfElmDef *mgMsgDefRspAckSeqElmnt[] =
{
   &mgMsgDefCfmTrId,
   &mgMsgDefCfmTrIdUprBnd
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefRspAckSeq =
{
   2,
   mgMsgDefRspAckSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefRspAck = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSPACK_VAL",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 6,
   sizeof(MgRspAck),  
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefRspAckSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefRspAckSetSeqOfElmnt[] =
{
   &cmMsgDefMetaComma,
   &cmMsgDefOptMetaSpace,  
   &mgMsgDefRspAck
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefRspAckSetSeqOf =
{
   1,
   MGT_MAX_RSP_ACK,
   3,
   mgMsgDefRspAckSetSeqOfElmnt,
   sizeof(MgRspAck)
};

PUBLIC CmAbnfElmDef mgMsgDefRspAckSet = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSPACK_SET ",
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 7,
   sizeof(MgRspAckSet),  
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefRspAckSetSeqOf,
   cmAbnfRegExpComma
};

PUBLIC CmAbnfElmDef *mgMsgDefRspAckParamSeqOfElmnt[] =
{
   &mgMsgDefRspAck,
   &mgMsgDefRspAckSet
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefRspAckParamSeqOf =
{
   2,
   mgMsgDefRspAckParamSeqOfElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefRspAckParam = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSPACK", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 8,
   sizeof(MgRspAckSet),   
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   (CM_ABNF_OPTIONAL),
#else
   (CM_ABNF_MANDATORY),
#endif
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefRspAckParamSeqOf,
   NULLP
};

/************************************************************************
               Database element for Bearer Information paramater
************************************************************************/

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))

EXTERN  CmAbnfElmDef  mgMsgDefPkgUnknownConnOptName;
 
 PUBLIC CmAbnfElmDef  *mgMsgDefBrrAttrPkgTreeChcElmnt[] =
 {
     &mgMsgDefPkgUnknownConnOptName ,
 };

/*
 * [TEL]: Enhanced to MGT_MGCP_PKG_MAX
 */ 
PUBLIC U8  mgMsgDefBrrAttrPkgTreeIdx[] = { 0,0,0,0,0, 0,0,0,0,0, 0,0,0,
                                           0,0,0,0,0, 0,0,0,0,0, 0,0,0, 0,0,0, 
                                           0,0,0,0,0,0};
 PUBLIC CmAbnfElmTypeChoice  mgMsgDefBrrAttrPkgTreeChc =
 {
     1 ,
     MGT_MGCP_PKG_MAX,
     mgMsgDefBrrAttrPkgTreeIdx,
     mgMsgDefBrrAttrPkgTreeChcElmnt ,
     NULLP
 };
 
 PUBLIC CmAbnfElmDef  mgMsgDefBrrAttrPkgTree =
 {
 #ifdef  CM_ABNF_DBG
     "MGCP: CONN OPT PKG TREE " ,
     "ConnOptPkgName" ,
 #endif
     CM_ABNF_ELMNID_MG_BASE + 9,
     sizeof(MgPkgName) + sizeof(MgMgcpName) ,
     ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
     CM_ABNF_TYPE_CHOICE ,
     (U8 *) &mgMsgDefBrrAttrPkgTreeChc ,
     mgMsgRegExpPackageName
 };
 

EXTERN  CmAbnfElmDef  mgMsgDefStdConnOptExtnValSet;
EXTERN  CmAbnfElmDef  mgMsgDefStdConnOptExtnValSetOpt;

PUBLIC CmAbnfElmDef  *mgMsgDefBrrAttrPkgExtnSeqElmnts[] =
{
    &mgMsgDefBrrAttrPkgTree ,
    &mgMsgDefStdConnOptExtnValSetOpt ,
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefBrrAttrPkgExtnSeq =
{
    2 ,
    mgMsgDefBrrAttrPkgExtnSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefBrrAttrPkgExtn =
{
#ifdef  CM_ABNF_DBG
    "ConnOptPkgExtn" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 10,
    sizeof (MgMgcpPkgSpcExtn) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefBrrAttrPkgExtnSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefBrrAttrEnum =
{
    NULLP ,
    MGT_MGCP_BRR_ENCODING
};

PUBLIC CmAbnfElmDef  mgMsgDefBrrAttrEnumDef =
{
#ifdef CM_ABNF_DBG
    "BrrAttr_0_EnumDef" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 11,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefBrrAttrEnum ,
    NULLP
};



PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgExtnEnum =
{
    NULLP ,
    MGT_MGCP_BRR_EXTN
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgExtnEnumDef =
{
#ifdef CM_ABNF_DBG
    "ConnOptPkgExtn_1_EnumDef" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 12,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgExtnEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefBrrAttrExtnChcEnum[] =
{
&mgMsgDefBrrAttrEnumDef ,
&mgMsgDefConnOptPkgExtnEnumDef ,

};

EXTERN  CmAbnfElmDef  mgMsgDefBrrAttr;

PUBLIC CmAbnfElmDef  *mgMsgDefBrrAttrExtnChcElmnt[] =
{
    &mgMsgDefBrrAttr ,
    &mgMsgDefBrrAttrPkgExtn ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefBrrAttrExtnChc =
{
    2 ,
    0 ,
    NULLP ,
    mgMsgDefBrrAttrExtnChcElmnt ,
    mgMsgDefBrrAttrExtnChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefBrrAttrExtn =
{
#ifdef  CM_ABNF_DBG
    "BrrAttrExtn" ,
    "R42" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 13,
    sizeof (MgMgcpBrrAttr) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefBrrAttrExtnChc ,
    mgMsgRegExpR42
};


#endif


PUBLIC CmAbnfElmTypeEnum mgMsgDefBrrEncAlawEnum =
{
   (Data *)"e:A",
   MGT_BEAR_ENC_ALAW
};

PUBLIC CmAbnfElmDef mgMsgDefBrrEncAlaw = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ALAW",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 14,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefBrrEncAlawEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefBrrEncMulawEnum =
{
   (Data *)"e:mu",
   MGT_BEAR_ENC_MULAW
};

PUBLIC CmAbnfElmDef mgMsgDefBrrEncMulaw = 
{
#ifdef CM_ABNF_DBG
   "MGCP: MULAW",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 15,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefBrrEncMulawEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefBrrAttrChcEnum[] =
{
   NULLP,
   &mgMsgDefBrrEncAlaw,
   &mgMsgDefBrrEncMulaw
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefBrrAttrChc =
{
   3,
   0,
   NULLP,
   NULLP,
   mgMsgDefBrrAttrChcEnum
};

PUBLIC CmAbnfElmDef mgMsgDefBrrAttr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ATTR", 
   "R40",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 16,
   sizeof(TknU8),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefBrrAttrChc,
   mgMsgRegExpR40
};

PUBLIC CmAbnfElmDef *mgMsgDefBrrInfoSeqOfElmnt[] =
{
   &cmMsgDefMetaComma,
   &cmMsgDefOptMetaSpace,  
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefBrrAttrExtn
#else
   &mgMsgDefBrrAttr
#endif
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefBrrInfoSeqOf =
{
   1,
   MGT_MAX_BEAR_ENC,
   3,                  
   mgMsgDefBrrInfoSeqOfElmnt,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   sizeof(MgMgcpBrrAttr)
#else
   sizeof(TknU8)
#endif
};

PUBLIC CmAbnfElmDef mgMsgDefBrrInfo = 
{
#ifdef CM_ABNF_DBG
   "MGCP: BRR_SET ",
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 17,
   sizeof(MgBearerInfo),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefBrrInfoSeqOf,
   cmAbnfRegExpComma
};

PUBLIC CmAbnfElmDef *mgMsgDefBrrInfoParamSeqOfElmnt[] =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefBrrAttrExtn,
#else
   &mgMsgDefBrrAttr,
#endif
   &mgMsgDefBrrInfo,
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefBrrInfoParamSeqOf =
{
   2,
   mgMsgDefBrrInfoParamSeqOfElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefBrrInfoParam = 
{
#ifdef CM_ABNF_DBG
   "MGCP: BRRINF", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 18,
   sizeof(MgBearerInfo),
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   (CM_ABNF_OPTIONAL),
#else
   (CM_ABNF_MANDATORY),
#endif
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefBrrInfoParamSeqOf,
   NULLP
};

/************************************************************************
               Database element for CallId paramater
************************************************************************/
PUBLIC CmAbnfElmTypeRange mgMsgDefCallIdRng = {1, 32};

PUBLIC CmAbnfElmDef mgMsgDefCallId = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CALLID", 
   "CM_RXDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 19,
   sizeof(MgCallId),   
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   (CM_ABNF_OPTIONAL),
#else
   (CM_ABNF_MANDATORY),
#endif
   CM_ABNF_TYPE_OCTSTR32,
   (U8 *)&mgMsgDefCallIdRng,
   cmAbnfRegExpXDgt
};

/************************************************************************
               Database element for ConnId paramater
               Database element for Second ConnId paramater
************************************************************************/
PUBLIC CmAbnfElmTypeRange mgMsgDefConnIdRng = {1, 32};

PUBLIC CmAbnfElmDef mgMsgDefConnId = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CONID", 
   "CM_RXDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 20,
   sizeof(MgConnId),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTR32,
   (U8 *)&mgMsgDefConnIdRng,
   cmAbnfRegExpXDgt
};

PUBLIC CmAbnfElmDef *mgMsgDefConnIdListSeqOfElmnt[] =
{
   &cmMsgDefMetaComma,
   &cmMsgDefOptMetaSpace,  
   &mgMsgDefConnId
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefConnIdListSeqOf =
{
   1,
   MGT_MAX_CONNID,
   3,
   mgMsgDefConnIdListSeqOfElmnt,
   sizeof(MgConnId)
};

PUBLIC CmAbnfElmDef mgMsgDefConnIdList = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CONIDLIST", 
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 21,
   sizeof(MgConnIdSet),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefConnIdListSeqOf,
   cmAbnfRegExpComma
};

PUBLIC CmAbnfElmDef *mgMsgDefConnIdSeqOfElmnt[] =
{
   &mgMsgDefConnId,
   &mgMsgDefConnIdList
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefConnIdSeqOf =
{
   2,
   mgMsgDefConnIdSeqOfElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefConnIdSet = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CONIDSET", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 22,
   sizeof(MgConnIdSet),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefConnIdSeqOf,
   NULLP
};

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))

PUBLIC CmAbnfElmDef mgMsgDefConnIdSetOpt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CONIDSET OPT", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 23,
   sizeof(MgConnIdSet),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefConnIdSeqOf,
   NULLP
};
#endif

/************************************************************************
               Database element for Notified Entity parameter
************************************************************************/

PUBLIC CmAbnfElmTypeRange mgMsgDefDomainNameRng = { 1, 0xFFFF}; 

PUBLIC CmAbnfElmDef mgMsgDefDomainName = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DNAME ",
   "R13",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 24,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefDomainNameRng,
   mgMsgRegExpR13
};

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
PUBLIC CmAbnfElmTypeRange mgMsgDefLcNameStrRng = {1, 0xffff};
#else
PUBLIC CmAbnfElmTypeRange mgMsgDefLcNameStrRng = {1, 32};
#endif

PUBLIC CmAbnfElmDef mgMsgDefLcNameStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: LCNAMESTR  ",
   "R39",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 25,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   sizeof(TknStrOSXL),
#else
   sizeof(TknStr32),
#endif
   (CM_ABNF_MANDATORY),
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   CM_ABNF_TYPE_OCTSTRXL,
#else
   CM_ABNF_TYPE_OCTSTR32,
#endif
   (U8 *)&mgMsgDefLcNameStrRng,
   mgMsgRegExpR39
};


PUBLIC CmAbnfElmDef *mgMsgDefLocalNameSeqElmnt[] =
{
   &mgMsgDefLcNameStr,
   &cmMsgDefMetaAt
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefLocalNameSeq =
{
   2,
   mgMsgDefLocalNameSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefLocalName = 
{
#ifdef CM_ABNF_DBG
   "MGCP: LCNAME ",
   "R39",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 26,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   sizeof(TknStrOSXL),
#else
   sizeof(TknStr32),
#endif
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefLocalNameSeq,
   mgMsgRegExpR39
};
PUBLIC CmAbnfElmDef *mgMsgDefNotifyEntSeqElmnt[] =
{
   &mgMsgDefLocalName,
   &mgMsgDefDomainName,
   &mgMsgDefPortNmb,
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefNotifyEntSeq =
{
   3,
   mgMsgDefNotifyEntSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefNotifyEnt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NTFY", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 27,
   sizeof(MgNtfiedEnt),   
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED),
#else
   (CM_ABNF_MANDATORY),
#endif
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefNotifyEntSeq,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   mgMsgRegExpChkParamPres
#else
   NULLP
#endif
};

/************************************************************************
               Database element for ReqId parameter
************************************************************************/
PUBLIC CmAbnfElmTypeRange mgMsgDefReqIdRng = {1, 32};

PUBLIC CmAbnfElmDef mgMsgDefReqId = 
{
#ifdef CM_ABNF_DBG
   "MGCP: REQID", 
   "CM_RXDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 28,
   sizeof(MgRqstId),   
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   (CM_ABNF_OPTIONAL),
#else
   (CM_ABNF_MANDATORY),
#endif
   CM_ABNF_TYPE_OCTSTR32,
   (U8 *)&mgMsgDefReqIdRng,
   cmAbnfRegExpXDgt
};

/************************************************************************
               Database element for Connection Opts parameter
************************************************************************/

/************************************************************************
          Database element for Connection Opts: Non standard Options 
************************************************************************/
PUBLIC CmAbnfElmTypeRange mgMsgDefNonStdConnOptExtnValRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefNonStdConnOptExtnVal = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EXTNVAL", 
   "R37",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 29,
   sizeof(TknStrOSXL),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefNonStdConnOptExtnValRng,
   mgMsgRegExpR37
};

PUBLIC CmAbnfElmTypeRange mgMsgDefNonStdConnOptExtnNameRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefNonStdConnOptExtnName = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EXTNNAME", 
   "R38",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 30,
   sizeof(TknStrOSXL),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefNonStdConnOptExtnNameRng,
   mgMsgRegExpR38
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefNonStdTypeMandatoryEnum = 
{
   (Data *)"+",
   MGT_NONSTD_TYPE_MANDATORY
};

PUBLIC CmAbnfElmDef mgMsgDefNonStdTypeMandatory = 
{
#ifdef CM_ABNF_DBG
   "MGCP: MANDATORY", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 31,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefNonStdTypeMandatoryEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefNonStdTypeOptEnum = 
{
   (Data *)"-",
   MGT_NONSTD_TYPE_OPTIONAL
};

PUBLIC CmAbnfElmDef mgMsgDefNonStdTypeOpt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: OPT", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 32,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefNonStdTypeOptEnum,
   NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefNonStdTypeChcEnum[] = 
{ 
   NULLP,
   &mgMsgDefNonStdTypeMandatory,
   &mgMsgDefNonStdTypeOpt
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefNonStdTypeChc = 
{
   3, 
   0,
   NULLP,
   NULLP,
   mgMsgDefNonStdTypeChcEnum
};

PUBLIC CmAbnfElmDef mgMsgDefNonStdType = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NSTDTYPE", 
   "R41",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 33,
   sizeof(TknU8),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefNonStdTypeChc,
   mgMsgRegExpR41
};

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
PUBLIC CmAbnfElmDef  *mgMsgDefStdConnOptExtnValSetOptSeqElmnts[] =
{
    &cmMsgDefMetaColon,
    &mgMsgDefStdConnOptExtnValSet
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefStdConnOptExtnValSetOptSeq =
{
    2 ,
    mgMsgDefStdConnOptExtnValSetOptSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefStdConnOptExtnValSetOpt =
{
#ifdef  CM_ABNF_DBG
    "MGCP: CONN OPT PKG EXTN NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 34,
    sizeof (MgMgcpExtValSet) ,   /* bug fix */
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefStdConnOptExtnValSetOptSeq ,
    cmAbnfRegExpColon
};

#endif

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
PUBLIC CmAbnfElmTypeMeta mgMsgDefXMeta = {(Data *)"X"};

PUBLIC CmAbnfElmDef mgMsgDefX =
{
#ifdef CM_ABNF_DBG
   "MGCP: X",
   "RM",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 35,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&mgMsgDefXMeta,
   mgMsgRegExpRX
};
#endif

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
PUBLIC CmAbnfElmDef *mgMsgDefNonStdConnOptValSeqElmnt[] =
{
   &mgMsgDefX,
   &mgMsgDefNonStdType,
   &mgMsgDefNonStdConnOptExtnName,
   &mgMsgDefStdConnOptExtnValSetOpt
};

#else

PUBLIC CmAbnfElmDef *mgMsgDefNonStdConnOptValSeqElmnt[] =
{
   &mgMsgDefNonStdType,
   &mgMsgDefNonStdConnOptExtnName,
   &cmMsgDefMetaColon,
   &mgMsgDefNonStdConnOptExtnVal
};
#endif

PUBLIC CmAbnfElmTypeSeq mgMsgDefNonStdConnOptValSeq =
{
   4,
   mgMsgDefNonStdConnOptValSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefNonStdConnOptVal = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NONSDTD_CON", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 36,
   sizeof(MgNonStdExtn),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefNonStdConnOptValSeq,
   NULLP
};

/************************************************************************
 Database element for Connection Opts: Non standard Options V1.3: Bis changes
************************************************************************/
/*  ~~~~~~~~~~~  */

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))


PUBLIC CmAbnfElmTypeRange  mgMsgDefStdConnOptExtnValParamStr_0_Range
                             =  {1, 0xffff};

PUBLIC CmAbnfElmDef  mgMsgDefStdConnOptExtnValParamStr =
{
#ifdef  CM_ABNF_DBG
    "StdConnOptExtnValParamStr_0" ,
    "R48" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 37,
    sizeof (TknStrOSXL) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OCTSTRXL ,
    (U8 *) &mgMsgDefStdConnOptExtnValParamStr_0_Range ,
    mgMsgRegExpConnOptExtLcoVal
};



PUBLIC CmAbnfElmTypeEnum  mgMsgDefStdConnOptExtnValParamStr_0_Enum =
{
    NULLP ,
    MGT_MGCP_LCL_OPT_EXTN_VAL_STR
};

PUBLIC CmAbnfElmDef  mgMsgDefStdConnOptExtnValParamStr_0_EnumDef =
{
#ifdef CM_ABNF_DBG
    "StdConnOptExtnValParamStr_0_EnumDef" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 38,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefStdConnOptExtnValParamStr_0_Enum ,
    NULLP
};



PUBLIC CmAbnfElmTypeEnum  mgMsgDefDQoute_1_Enum =
{
    NULLP ,
    MGT_MGCP_LCL_OPT_EXTN_VAL_QUOTED
};

PUBLIC CmAbnfElmDef  mgMsgDefDQoute_1_EnumDef =
{
#ifdef CM_ABNF_DBG
    "DQoute_1_EnumDef" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 39,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefDQoute_1_Enum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefStdConnOptExtnValChcEnum[] =
{
    NULLP ,
&mgMsgDefStdConnOptExtnValParamStr_0_EnumDef ,
&mgMsgDefDQoute_1_EnumDef ,

};

EXTERN  CmAbnfElmDef  mgMsgDefDQoute;

PUBLIC CmAbnfElmDef  *mgMsgDefStdConnOptExtnValChcElmnt[] =
{
    NULLP ,
    &mgMsgDefStdConnOptExtnValParamStr ,
    &mgMsgDefDQoute ,
};
PUBLIC CmAbnfElmTypeChoice  mgMsgDefStdConnOptExtnValChc =
{
    3 ,
    0 ,
    NULLP ,
    mgMsgDefStdConnOptExtnValChcElmnt ,
    mgMsgDefStdConnOptExtnValChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefStdConnOptExtnVal =
{
#ifdef  CM_ABNF_DBG
    "StdConnOptExtnVal" ,
    "R47" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 40,
    sizeof (MgMgcpExtVal) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefStdConnOptExtnValChc ,
    mgMsgRegExpR47
};

PUBLIC CmAbnfElmDef  *mgMsgDefStdConnOptExtnVallistSeqOfElmnts[] =
{
    &cmMsgDefMetaSemiColon ,
    &cmMsgDefOptMetaSpace ,
    &mgMsgDefStdConnOptExtnVal
};

PUBLIC CmAbnfElmTypeSeqOf  mgMsgDefStdConnOptExtnVallistSeqOf =
{
    1 ,
    (U16)~0 ,
    3 ,
    mgMsgDefStdConnOptExtnVallistSeqOfElmnts ,
    sizeof (MgMgcpExtVal)
};

PUBLIC CmAbnfElmDef  mgMsgDefStdConnOptExtnVallist =
{
#ifdef  CM_ABNF_DBG
    "StdConnOptExtnVallist" ,
    "cmMsgDefMetaColon" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 41,
    sizeof (MgMgcpExtValSet) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_SEQOF ,
    (U8 *) &mgMsgDefStdConnOptExtnVallistSeqOf ,
    cmAbnfRegExpSemiColon
};

PUBLIC CmAbnfElmDef  *mgMsgDefStdConnOptExtnValSetSeqElmnts[] =
{
    &mgMsgDefStdConnOptExtnVal ,
    &mgMsgDefStdConnOptExtnVallist
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefStdConnOptExtnValSetSeq =
{
    2 ,
    mgMsgDefStdConnOptExtnValSetSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefStdConnOptExtnValSet =
{
#ifdef  CM_ABNF_DBG
    "StdConnOptExtnValSet" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 42,
    sizeof (MgMgcpExtValSet) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQOF ,
    (U8 *) &mgMsgDefStdConnOptExtnValSetSeq ,
    NULLP
};

/* ~~~~~~~~~~ */




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgExtnNameUnknownExtnEnum =
{
    NULLP ,
    MGT_MGCP_CONN_OPT_PKG_EXTN_NAME_UNKNOWN_EXTN
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgExtnNameUnknownExtn =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG EXTN NAME UNKNOWN EXTN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 43,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgExtnNameUnknownExtnEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeRange  mgMsgDefConnOptPkgExtnNameUnknownExtnValRange =  {   1 , 0xffff  };

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgExtnNameUnknownExtnVal =
{
#ifdef  CM_ABNF_DBG
    "MGCP: CONN OPT PKG EXTN NAME UNKNOWN EXTN VAL " ,
    "ConnOptPkgExtnName" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 44,
    sizeof (TknStrOSXL) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OCTSTRXL ,
    (U8 *) &mgMsgDefConnOptPkgExtnNameUnknownExtnValRange ,
    mgMsgRegExpConnOptPkgExtnName
};

PUBLIC CmAbnfElmDef  *mgMsgDefConnOptPkgExtnNameSeqElmnts[] =
{
    &mgMsgDefConnOptPkgExtnNameUnknownExtn ,
    &mgMsgDefConnOptPkgExtnNameUnknownExtnVal
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefConnOptPkgExtnNameSeq =
{
    2 ,
    mgMsgDefConnOptPkgExtnNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgExtnName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: CONN OPT PKG EXTN NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 45,
    sizeof(MgMgcpName) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefConnOptPkgExtnNameSeq ,
    NULLP
};


 
 PUBLIC CmAbnfElmDef  *mgMsgDefPkgUnknownConnOptNameSeqElmnts[] =
 {
     &mgMsgDefPkgNameString ,
     &cmMsgDefMetaSlash ,
     &mgMsgDefConnOptPkgExtnName
 };
 
 PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgUnknownConnOptNameSeq =
 {
     3 ,
     mgMsgDefPkgUnknownConnOptNameSeqElmnts
 };
 
 PUBLIC CmAbnfElmDef  mgMsgDefPkgUnknownConnOptName =
 {
 #ifdef  CM_ABNF_DBG
     "MGCP: PKG UNKNOWN CONN OPT NAME " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_MG_BASE + 46,
     sizeof(MgPkgName) + sizeof(MgMgcpName) ,
     ( CM_ABNF_MANDATORY ) ,
     CM_ABNF_TYPE_OPTSEQ ,
     (U8 *) &mgMsgDefPkgUnknownConnOptNameSeq ,
     NULLP
 };
 
 
 PUBLIC CmAbnfElmDef  *mgMsgDefConnOptPkgTreeChcElmnt[] =
 {
     &mgMsgDefPkgUnknownConnOptName ,
#ifdef  GCP_PKG_MGCP_BASIC_NAS
     &mgMsgDefPkgNASConnOptName ,
#else
     &mgMsgDefPkgUnknownConnOptName ,
#endif

#ifdef  GCP_PKG_MGCP_ATM
     &mgMsgDefPkgAtmConnOptName ,
#else
     &mgMsgDefPkgUnknownConnOptName ,
#endif

#ifdef  GCP_PKG_MGCP_NAS_DATAOUT
     &mgMsgDefPkgNAOConnOptName ,
#else
     &mgMsgDefPkgUnknownConnOptName ,
#endif

#ifdef  GCP_PKG_MGCP_FAX
     &mgMsgDefPkgFXRConnOptName ,
#else
     &mgMsgDefPkgUnknownConnOptName ,
#endif
 };
 
/*
 * [TEL]: Enhanced to MGT_MGCP_PKG_MAX
 */ 
PUBLIC U8  mgMsgDefConnOptPkgTreeIdx[] = { 0,0,0,0,0, 0,0,0,1,0, 0,0,0,
                                            0,0,0,0,0, 0,2,0,0,0, 0,0,0,
                                            3,4,0,
                                            0,0,0,0,0,0};
 PUBLIC CmAbnfElmTypeChoice  mgMsgDefConnOptPkgTreeChc =
 {
     5 ,
     MGT_MGCP_PKG_MAX,
     mgMsgDefConnOptPkgTreeIdx ,
     mgMsgDefConnOptPkgTreeChcElmnt ,
     NULLP
 };
 
 PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgTree =
 {
 #ifdef  CM_ABNF_DBG
     "MGCP: CONN OPT PKG TREE " ,
     "ConnOptPkgName" ,
 #endif
     CM_ABNF_ELMNID_MG_BASE + 47,
     sizeof(MgPkgName) + sizeof(MgMgcpName) ,
     ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
     CM_ABNF_TYPE_CHOICE ,
     (U8 *) &mgMsgDefConnOptPkgTreeChc ,
     mgMsgRegExpPackageName
 };
 


PUBLIC CmAbnfElmDef  *mgMsgDefConnOptPkgExtnSeqElmnts[] =
{
    &mgMsgDefConnOptPkgTree ,
    &mgMsgDefStdConnOptExtnValSetOpt
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefConnOptPkgExtnSeq =
{
    2 ,
    mgMsgDefConnOptPkgExtnSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgExtn =
{
#ifdef  CM_ABNF_DBG
    "ConnOptPkgExtn" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 48,
    sizeof (MgMgcpPkgSpcExtn) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefConnOptPkgExtnSeq ,
    NULLP
};

PUBLIC CmAbnfElmTypeRange  mgMsgDefConnOptOtherExtnNameRange =  {   1 , 32  };

PUBLIC CmAbnfElmDef  mgMsgDefConnOptOtherExtnName =
{
#ifdef  CM_ABNF_DBG
    "ConnOptOtherExtnName_0" ,
    "R46" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 49,
    sizeof (TknStr32) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OCTSTR32 ,
    (U8 *) &mgMsgDefConnOptOtherExtnNameRange ,
    mgMsgRegExpR46
};

PUBLIC CmAbnfElmDef  *mgMsgDefConnOptOtherExtnSeqElmnts[] =
{
    &mgMsgDefConnOptOtherExtnName ,
    &mgMsgDefStdConnOptExtnValSetOpt
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefConnOptOtherExtnSeq =
{
    2 ,
    mgMsgDefConnOptOtherExtnSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptOtherExtn =
{
#ifdef  CM_ABNF_DBG
    "ConnOptOtherExtn" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 50,
    sizeof (MgMgcpOthExtn) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefConnOptOtherExtnSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefNonStdConnOptVal_0_Enum =
{
    NULLP ,
    MGT_MGCP_LCL_CONNOPT_VNDR_EXT
};

PUBLIC CmAbnfElmDef  mgMsgDefNonStdConnOptVal_0_EnumDef =
{
#ifdef CM_ABNF_DBG
    "NonStdConnOptVal_0_EnumDef" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 51,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefNonStdConnOptVal_0_Enum ,
    NULLP
};



PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgExtn_1_Enum =
{
    NULLP ,
    MGT_MGCP_LCL_CONNOPT_PKG_EXT
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgExtn_1_EnumDef =
{
#ifdef CM_ABNF_DBG
    "ConnOptPkgExtn_1_EnumDef" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 52,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgExtn_1_Enum ,
    NULLP
};



PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptOtherExtnEnum =
{
    NULLP ,
    MGT_MGCP_LCL_CONNOPT_OTHR_EXT
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptOtherExtnEnumDef =
{
#ifdef CM_ABNF_DBG
    "ConnOptOtherExtn_2_EnumDef" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 53,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptOtherExtnEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefStdConnOptValChcEnum[] =
{
&mgMsgDefNonStdConnOptVal_0_EnumDef ,
&mgMsgDefConnOptPkgExtn_1_EnumDef ,
&mgMsgDefConnOptOtherExtnEnumDef ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefStdConnOptValChcElmnt[] =
{
    &mgMsgDefNonStdConnOptVal ,
    &mgMsgDefConnOptPkgExtn ,
    &mgMsgDefConnOptOtherExtn ,
};
PUBLIC CmAbnfElmTypeChoice  mgMsgDefStdConnOptValChc =
{
    3 ,
    0 ,
    NULLP ,
    mgMsgDefStdConnOptValChcElmnt ,
    mgMsgDefStdConnOptValChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefStdConnOptVal =
{
#ifdef  CM_ABNF_DBG
    "StdConnOptVal" ,
    "R45" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 54,
    sizeof (MgMgcpExtn) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefStdConnOptValChc ,
    mgMsgRegExpR45
};

#endif
/*  ~~~~~~~~~~~  */


/************************************************************************
          Database element for extension Parameter
************************************************************************/
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))


PUBLIC CmAbnfElmTypeRange  mgMsgDefOtherExtnParamRange =  {   1 , 32  };

PUBLIC CmAbnfElmDef  mgMsgDefOtherExtnParam =
{
#ifdef  CM_ABNF_DBG
    "MGCP: OTHER EXTN PARAM" ,
    "OtherExtnParam" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 55,
    sizeof (TknStr32) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OCTSTR32 ,
    (U8 *) &mgMsgDefOtherExtnParamRange ,
     mgMsgRegExpOtherExtnParam
};




/* ---------- */


 PUBLIC CmAbnfElmTypeRange  mgMsgDefPkgExtnParamNameUnknownExtnValRange =  {   1 , 32  };
 
 PUBLIC CmAbnfElmDef  mgMsgDefPkgExtnParamNameUnknownExtnVal =
 {
 #ifdef  CM_ABNF_DBG
     "MGCP: PKG EXTN PARAM NAME " ,
     "PkgExtnParamExtnName" ,
 #endif
     CM_ABNF_ELMNID_MG_BASE + 56,
     sizeof (TknStrOSXL) ,
     ( CM_ABNF_MANDATORY ) ,
     CM_ABNF_TYPE_OCTSTRXL ,
     (U8 *) &mgMsgDefPkgExtnParamNameUnknownExtnValRange ,
     mgMsgRegExpPkgExtnParamExtnUnknownName
 };




PUBLIC CmAbnfElmTypeEnum  mgMsgDefPkgExtnParamNameUnknownExtnEnum =
{
    NULLP ,
    MGT_MGCP_PKG_EXTN_PARAM_NAME_UNKNOWN_EXTN
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgExtnParamNameUnknownExtn =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG EXTN PARAM NAME UNKNOWN EXTN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 57,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefPkgExtnParamNameUnknownExtnEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgExtnParamNameSeqElmnts[] =
{
    &mgMsgDefPkgExtnParamNameUnknownExtn ,
    &mgMsgDefPkgExtnParamNameUnknownExtnVal
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgExtnParamNameSeq =
{
    2 ,
    mgMsgDefPkgExtnParamNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgExtnParamName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG EXTN PARAM NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 58,
    sizeof(MgMgcpName) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgExtnParamNameSeq ,
    NULLP
};

 
 
 PUBLIC CmAbnfElmDef  *mgMsgDefPkgExtnParamUnkownPkgExtnNameSeqElmnts[] =
 {
     &mgMsgDefPkgNameString ,
     &cmMsgDefMetaSlash ,
     &mgMsgDefPkgExtnParamName
 };
 
 PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgExtnParamUnkownPkgExtnNameSeq =
 {
     3 ,
     mgMsgDefPkgExtnParamUnkownPkgExtnNameSeqElmnts
 };
 
 PUBLIC CmAbnfElmDef  mgMsgDefPkgExtnParamUnkownPkgExtnName =
 {
 #ifdef  CM_ABNF_DBG
     "MGCP: PKG EXTN PARAM UNKOWN PKG EXTN NAME " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_MG_BASE + 59,
     sizeof(MgMgcpPkgSpcExtnParam) ,
     ( CM_ABNF_MANDATORY ) ,
     CM_ABNF_TYPE_OPTSEQ ,
     (U8 *) &mgMsgDefPkgExtnParamUnkownPkgExtnNameSeq ,
     NULLP
 };
 
 
 
 
 PUBLIC CmAbnfElmDef  *mgMsgDefPkgExtnParamTreeChcElmnt[] =
 {
   &mgMsgDefPkgExtnParamUnkownPkgExtnName ,
   
   /*
    * [TEL]: Added for Base Package
    */
#ifdef GCP_PKG_MGCP_BASE
   &mgMsgDefPkgBExtnParamExtnName ,
#else 
   &mgMsgDefPkgExtnParamUnkownPkgExtnName ,
#endif 

 };
 
/*
 * [TEL]: Enhnanced to MGT_MGCP_PKG_MAX
 */
PUBLIC U8  mgMsgDefPkgExtnParamTreeIdx[] = { 0,0,0,0,0, 0,0,0,0,0, 0,0,0,
                                             0,0,0,0,0, 0,0,0,0,0, 0,0,0, 0,0,0,
                                             0,0,0,0,0,1 };
 PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgExtnParamTreeChc =
 {
     /* [TEL]: Increased from one for Base package */
     2 ,
     MGT_MGCP_PKG_MAX,
     mgMsgDefPkgExtnParamTreeIdx,
     mgMsgDefPkgExtnParamTreeChcElmnt ,
     NULLP ,
 };
 
 PUBLIC CmAbnfElmDef  mgMsgDefPkgExtnParamTree =
 {
 #ifdef  CM_ABNF_DBG
     "MGCP: PKG EXTN PARAM TREE " ,
     "ExtnParamPkgExtnNames" ,
 #endif
     CM_ABNF_ELMNID_MG_BASE + 60,
     sizeof(MgMgcpPkgSpcExtnParam) ,
     ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
     CM_ABNF_TYPE_CHOICE ,
     (U8 *) &mgMsgDefPkgExtnParamTreeChc ,
     mgMsgRegExpPackageName
 };

PUBLIC CmAbnfElmDef  *mgMsgDefPkgExtnParamSeqElmnts[] =
{
    &mgMsgDefPkgExtnParamTree
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgExtnParamSeq =
{
    1 ,
    mgMsgDefPkgExtnParamSeqElmnts
};


PUBLIC CmAbnfElmDef  mgMsgDefPkgExtnParam =
{
#ifdef  CM_ABNF_DBG
    "PkgExtnParam" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 61,
    sizeof (MgMgcpPkgSpcExtnParam ) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgExtnParamSeq ,
    NULLP
};


PUBLIC CmAbnfElmTypeRange mgMsgDefVndrExtnParamExtnNameRng = {1, 6};

PUBLIC CmAbnfElmDef mgMsgDefVndrExtnParamExtnName = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EXTNNAME", 
   "VndrExtnExtnName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 62,
   sizeof(TknStrOSXL),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefVndrExtnParamExtnNameRng,
   cmAbnfRegExpAlDgChar
};

PUBLIC CmAbnfElmDef *mgMsgDefVndrExtnParamSeqElmnt[] =
{
   &mgMsgDefNonStdType,
   &mgMsgDefVndrExtnParamExtnName,
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefVndrExtnParamSeq =
{
   2,
   mgMsgDefVndrExtnParamSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefVndrExtnParam = 
{
#ifdef CM_ABNF_DBG
   "MGCP: VNDR_EXTN_PARAM", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 63,
   sizeof(MgNonStdExtnParam),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefVndrExtnParamSeq,
   NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefVndrExtnParamEnum =
{
    (Data *)"X" ,
    MGT_MGCP_EXTN_PARAM_VNDR
};

PUBLIC CmAbnfElmDef  mgMsgDefVndrExtnParamEnumDef =
{
#ifdef CM_ABNF_DBG
    "VndrExtnParamEnumDef" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 64,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefVndrExtnParamEnum ,
    NULLP
};



PUBLIC CmAbnfElmTypeEnum  mgMsgDefPkgExtnParamEnum =
{
    NULLP ,
    MGT_MGCP_EXTN_PARAM_PKG
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgExtnParamEnumDef =
{
#ifdef CM_ABNF_DBG
    "PkgExtnParamEnumDef" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 65,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefPkgExtnParamEnum ,
    NULLP
};



PUBLIC CmAbnfElmTypeEnum  mgMsgDefOtherExtnParamEnum =
{
    NULLP ,
    MGT_MGCP_EXTN_PARAM_OTHER
};

PUBLIC CmAbnfElmDef  mgMsgDefOtherExtnParamEnumDef =
{
#ifdef CM_ABNF_DBG
    "OtherExtnParamEnumDef" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 66,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefOtherExtnParamEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefExtnParamChcEnum[] =
{
&mgMsgDefVndrExtnParamEnumDef ,
&mgMsgDefPkgExtnParamEnumDef ,
&mgMsgDefOtherExtnParamEnumDef ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefExtnParamChcElmnt[] =
{
    &mgMsgDefVndrExtnParam ,
    &mgMsgDefPkgExtnParam  ,
    &mgMsgDefOtherExtnParam ,        /* &mgMsgDefOtherExtnParam */
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefExtnParamChc =
{
    3 ,
    0 ,
    NULLP ,
    mgMsgDefExtnParamChcElmnt ,
    mgMsgDefExtnParamChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefExtnParam =
{
#ifdef  CM_ABNF_DBG
    "StdConnOptVal" ,
    "R55" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 67,
    sizeof (MgMgcpExtnParam) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefExtnParamChc ,
    mgMsgRegExpR55
};

#endif


/************************************************************************
          Database element for Connection Opts: Support Modes 
************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMsgDefSendOnlyEnum =
{
   (Data *)"sendonly",
   MGT_SUPP_MODE_SEND_ONLY
};

PUBLIC CmAbnfElmDef mgMsgDefSendOnly = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SND ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 68,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSendOnlyEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefRecvOnlyEnum =
{
   (Data *)"recvonly",
   MGT_SUPP_MODE_RECV_ONLY
};

PUBLIC CmAbnfElmDef mgMsgDefRecvOnly = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RCV", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 69,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefRecvOnlyEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefSendRecvEnum =
{
   (Data *)"sendrecv",
   MGT_SUPP_MODE_SEND_RECV
};

PUBLIC CmAbnfElmDef mgMsgDefSendRecv = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SNDRCV ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 70,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSendRecvEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefConferrenceEnum =
{
   (Data *)"confrnce",
   MGT_SUPP_MODE_CONF
};

PUBLIC CmAbnfElmDef mgMsgDefConferrence = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CONF", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 71,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefConferrenceEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefInactiveEnum =
{
   (Data *)"inactive",
   MGT_SUPP_MODE_INACTIVE
};

PUBLIC CmAbnfElmDef mgMsgDefInactive = 
{
#ifdef CM_ABNF_DBG
   "MGCP: INACTIVE", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 72,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefInactiveEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefLoopbackEnum =
{
   (Data *)"loopback",
   MGT_SUPP_MODE_LOOPBK
};

PUBLIC CmAbnfElmDef mgMsgDefLoopback = 
{
#ifdef CM_ABNF_DBG
   "MGCP: LOOPBACK ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 73,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefLoopbackEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefConttestEnum =
{
   (Data *)"conttest",
   MGT_SUPP_MODE_CONT_TEST
};

PUBLIC CmAbnfElmDef mgMsgDefConttest = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CONTTEST", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 74,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefConttestEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefNetwloopEnum =
{
   (Data *)"netwloop",
   MGT_SUPP_MODE_NET_WLOOP
};

PUBLIC CmAbnfElmDef mgMsgDefNetwloop = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NETWLOOP", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 75,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefNetwloopEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefNetwtestEnum =
{
   (Data *)"netwtest",
   MGT_SUPP_MODE_NET_WTEST
};

PUBLIC CmAbnfElmDef mgMsgDefNetwtest = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NETWTEST", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 76,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefNetwtestEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefDataEnum =
{
   (Data *)"data",
   MGT_SUPP_MODE_DATA
};

PUBLIC CmAbnfElmDef mgMsgDefData = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DATA", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 77,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefDataEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReplicateEnum =
{
   (Data *)"replcate",
   MGT_SUPP_MODE_REPLCATE
};

PUBLIC CmAbnfElmDef mgMsgDefReplicate = 
{
#ifdef CM_ABNF_DBG
   "MGCP: REPLICATE", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 78,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReplicateEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefSendResvEnum =
{
   (Data *)"sendresv",
   MGT_SUPP_MODE_SENDRESV
};

PUBLIC CmAbnfElmDef mgMsgDefSendResv = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SNDRESV ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 79,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSendResvEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefRecvResvEnum =
{
   (Data *)"recvresv",
   MGT_SUPP_MODE_RECVRESV
};

PUBLIC CmAbnfElmDef mgMsgDefRecvResv = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RECVRESV ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 80,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefRecvResvEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefSnrcResvEnum =
{
   (Data *)"snrcresv",
   MGT_SUPP_MODE_SNRCRESV
};

PUBLIC CmAbnfElmDef mgMsgDefSnrcResv = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SNRCRESV ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 81,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSnrcResvEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefSendComtEnum =
{
   (Data *)"sendcomt",
   MGT_SUPP_MODE_SENDCOMT
};

PUBLIC CmAbnfElmDef mgMsgDefSendComt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SNDCOMT", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 82,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSendComtEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefRecvComtEnum =
{
   (Data *)"recvcomt",
   MGT_SUPP_MODE_RECVCOMT
};

PUBLIC CmAbnfElmDef mgMsgDefRecvComt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RECVCOMT", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 83,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefRecvComtEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefSnrcComtEnum =
{
   (Data *)"snrccomt",
   MGT_SUPP_MODE_SNRCCOMT
};

PUBLIC CmAbnfElmDef mgMsgDefSnrcComt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SNRCCOMT", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 84,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSnrcComtEnum,
   NULLP
};

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))


PUBLIC CmAbnfElmTypeRange  mgMsgDefConnModExtnValUnknownExtnValRange =  {   1 , 0xffff  };

PUBLIC CmAbnfElmDef  mgMsgDefConnModExtnValUnknownExtnVal =
{
#ifdef  CM_ABNF_DBG
    "MGCP: CONN MOD EXTN VAL" ,
    "ConnModExtnVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 85,
    sizeof (TknStrOSXL) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OCTSTRXL ,
    (U8 *) &mgMsgDefConnModExtnValUnknownExtnValRange ,
    mgMsgRegExpConnModExtnVal
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnModExtnValUnknownExtnEnum =
{
    NULLP ,
    MGT_MGCP_CONN_MOD_EXTN_VAL_UNKNOWN_EXTN
};

PUBLIC CmAbnfElmDef  mgMsgDefConnModExtnValUnknownExtn =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN MOD EXTN VAL UNKNOWN EXTN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 86,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnModExtnValUnknownExtnEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefConnModExtnValSeqElmnts[] =
{
    &mgMsgDefConnModExtnValUnknownExtn ,
    &mgMsgDefConnModExtnValUnknownExtnVal
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefConnModExtnValSeq =
{
    2 ,
    mgMsgDefConnModExtnValSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefConnModExtnVal =
{
#ifdef  CM_ABNF_DBG
    "MGCP: CONN MOD EXTN VAL " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 87,
    sizeof(MgConnModVal) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefConnModExtnValSeq ,
    NULLP
};

 
 PUBLIC CmAbnfElmDef  *mgMsgDefConnModeExtnPkgUnknownPkgSeqElmnts[] =
 {
     &mgMsgDefPkgNameString ,
     &cmMsgDefMetaSlash ,
     &mgMsgDefConnModExtnVal
 };
 
 PUBLIC CmAbnfElmTypeSeq  mgMsgDefConnModeExtnPkgUnknownPkgSeq =
 {
     3 ,
     mgMsgDefConnModeExtnPkgUnknownPkgSeqElmnts
 };
 
 PUBLIC CmAbnfElmDef  mgMsgDefConnModeExtnPkgUnknownPkg =
 {
 #ifdef  CM_ABNF_DBG
     "MGCP: CONN MODE EXTN PKG UNKNOWN PKG " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_MG_BASE + 88,
     sizeof(MgConnModeX) ,
     ( CM_ABNF_MANDATORY ) ,
     CM_ABNF_TYPE_OPTSEQ ,
     (U8 *) &mgMsgDefConnModeExtnPkgUnknownPkgSeq ,
     NULLP
 };
 
 
 
 
 PUBLIC CmAbnfElmDef  *mgMsgDefConnModeExtnTreeChcElmnt[] =
 {
     &mgMsgDefConnModeExtnPkgUnknownPkg ,
#ifdef  GCP_PKG_MGCP_BASIC_NAS
     &mgMsgDefConnModeExtnPkgNAS ,
#else
     &mgMsgDefConnModeExtnPkgUnknownPkg ,
#endif
 };
 
/*
 * [TEL]: Enhnanced to MGT_MGCP_PKG_MAX
 */
PUBLIC U8  mgMsgDefConnModeExtnTreeIdx[] = { 0,0,0,0,0, 0,0,0,1,0, 0,0,0,
                                             0,0,0,0,0, 0,0,0,0,0, 0,0,0,
                                             0,0,      0, 
                                             0,0,0,0,0,0};
  
 PUBLIC CmAbnfElmTypeChoice  mgMsgDefConnModeExtnTreeChc =
 {
     2 ,
     MGT_MGCP_PKG_MAX,
     mgMsgDefConnModeExtnTreeIdx,
     mgMsgDefConnModeExtnTreeChcElmnt ,
     NULLP
 };
 
 PUBLIC CmAbnfElmDef  mgMsgDefConnModeExtnTree =
 {
 #ifdef  CM_ABNF_DBG
     "MGCP: CONN MODE EXTN TREE " ,
     "ConnModeExtnPkgs" ,
 #endif
     CM_ABNF_ELMNID_MG_BASE + 89,
     sizeof(MgConnModeX) ,
     ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
     CM_ABNF_TYPE_CHOICE ,
     (U8 *) &mgMsgDefConnModeExtnTreeChc ,
     mgMsgRegExpPackageName
 };


PUBLIC CmAbnfElmDef  *mgMsgDefConnModeExtnSeqElmnts[] =
{
    &mgMsgDefConnModeExtnTree
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefConnModeExtnSeq =
{
    1 ,
    mgMsgDefConnModeExtnSeqElmnts
};


PUBLIC CmAbnfElmDef  mgMsgDefConnModeExtn =
{
#ifdef  CM_ABNF_DBG
    "ConnModeExtn" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 90,
    sizeof (MgConnModeX) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefConnModeExtnSeq ,
    NULLP
};



PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnModeExtnEnum =
{
   NULLP ,
   MGT_SUPP_MODE_EXTENSION
};

PUBLIC CmAbnfElmDef mgMsgDefConnModeExtnEnumDef =
{
#ifdef CM_ABNF_DBG
   "MGCP: CONNEXTN", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 91,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefConnModeExtnEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefConnModeChcElmnt[] =
{
   NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,
   NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,  &mgMsgDefConnModeExtn
};
#endif

PUBLIC CmAbnfElmDef *mgMsgDefConnModeChcEnum[] =
{
   NULLP,
   &mgMsgDefSendOnly,
   &mgMsgDefRecvOnly,
   &mgMsgDefSendRecv,
   &mgMsgDefConferrence,
   &mgMsgDefInactive,
   &mgMsgDefLoopback,
   &mgMsgDefConttest,
   &mgMsgDefNetwloop,
   &mgMsgDefNetwtest,
   &mgMsgDefData,
   &mgMsgDefReplicate,
   &mgMsgDefSendResv,
   &mgMsgDefRecvResv,
   &mgMsgDefSnrcResv,
   &mgMsgDefSendComt,
   &mgMsgDefRecvComt,
   &mgMsgDefSnrcComt,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefConnModeExtnEnumDef
#endif
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefModesTypeChc =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   19,
#else
   18,
#endif
   0,
   NULLP,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   mgMsgDefConnModeChcElmnt,
#else
   NULLP,
#endif
   mgMsgDefConnModeChcEnum
};

PUBLIC CmAbnfElmDef mgMsgDefConnMode = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CONMODE", 
   "R28",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 92,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   sizeof(MgConnMode),
#else
   sizeof(TknU8),   
#endif
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefModesTypeChc,
   mgMsgRegExpR28
};

PUBLIC CmAbnfElmDef *mgMsgDefSuppModeListSeqOfElmnt[] =
{
   &cmMsgDefMetaSemiColon,
   &mgMsgDefConnMode
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefSuppModeListSeqOf =
{
   1,
   MGT_MAX_SUPP_MODE,
   2,
   mgMsgDefSuppModeListSeqOfElmnt,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   sizeof(MgConnMode)
#else
   sizeof(TknU8)   
#endif
};

PUBLIC CmAbnfElmDef mgMsgDefSuppModeList = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SUPMDLST", 
   "CM_RSEMICOLON",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 93,
   sizeof(MgSuppModes),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefSuppModeListSeqOf,
   cmAbnfRegExpSemiColon
};

PUBLIC CmAbnfElmDef *mgMsgDefSuppModesSeqOfElmnt[] =
{
   &mgMsgDefConnMode,
   &mgMsgDefSuppModeList
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefSuppModesSeqOf =
{
   2,
   mgMsgDefSuppModesSeqOfElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefSuppModes = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SUPMD", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 94,
   sizeof(MgSuppModes),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefSuppModesSeqOf,
   NULLP
};

/************************************************************************
          Database element for Connection Opts: Support packages
************************************************************************/
PUBLIC CmAbnfElmTypeRange mgMsgDefUnknownPkgNameStringRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefUnknownPkgNameString = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PKGNM ", 
   "R23",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 95,
   sizeof(MgPkgName) - sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefUnknownPkgNameStringRng,
   mgMsgRegExpR23
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgGenericEnum =
{
   (Data *)"G",
   MGT_MGCP_PKG_GENERIC
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgGenericStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgGeneric enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 96,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgGenericEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgDtmfEnum =
{
   (Data *)"D",
   MGT_MGCP_PKG_DTMF
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgDtmfStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgDtmf enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 97,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgDtmfEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgMfEnum =
{
   (Data *)"M",
   MGT_MGCP_PKG_MF
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgMfStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgMf enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 98,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgMfEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgTrunkEnum =
{
   (Data *)"T",
   MGT_MGCP_PKG_TRUNK
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgTrunkStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgTrunk enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 99,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgTrunkEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgLineEnum =
{
   (Data *)"L",
   MGT_MGCP_PKG_LINE
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgLineStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgLine enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 100,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgLineEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgHandsetEnum =
{
   (Data *)"H",
   MGT_MGCP_PKG_HANDSET
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgHandsetStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgHandset enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 101,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgHandsetEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgRtpEnum =
{
   (Data *)"R",
   MGT_MGCP_PKG_RTP
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgRtpStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgRtp enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 102,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgRtpEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgNasEnum =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   (Data *)"NAS",
#else
   (Data *)"N",
#endif
   MGT_MGCP_PKG_NAS
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgNasStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgNas enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 103,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgNasEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgAnnEnum =
{
   (Data *)"A",
   MGT_MGCP_PKG_ANN
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgAnnStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgAnn enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 104,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgAnnEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgScriptEnum =
{
   (Data *)"Script",
   MGT_MGCP_PKG_SCRIPT
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgScriptStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgScript enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 105,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgScriptEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgAdsiEnum =
{
   (Data *)"S",
   MGT_MGCP_PKG_ADSI
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgAdsiStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgAdsi enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 106,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgAdsiEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgIsupTrunkEnum =
{
   (Data *)"IT",
   MGT_MGCP_PKG_ISUP_TRUNK
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgIsupTrunkStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgIsupTrunk enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 107,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgIsupTrunkEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgMfFgdEnum =
{
   (Data *)"MO",
   MGT_MGCP_PKG_MF_FGD
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgMfFgdStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgMfFgd enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 108,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgMfFgdEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgMfTermEnum =
{
   (Data *)"MT",
   MGT_MGCP_PKG_MF_TERM
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgMfTermStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgMfTerm enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 109,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgMfTermEnum,
   NULLP
};

#ifdef GCP_VER_1_3


PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgSstEnum =
{
   (Data *)"SST",
   MGT_MGCP_PKG_SUPP_SRV
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgSstStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgMfTerm enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 110,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgSstEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgCstEnum =
{
   (Data *)"CST",
   MGT_MGCP_PKG_COUN_SPC_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgCstStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgMfTerm enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 111,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgCstEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgDm1Enum =
{
   (Data *)"DM1",
   MGT_MGCP_PKG_DGT_MAP_EXT
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgDm1Str =
{
#ifdef CM_ABNF_DBG
   "KnownPkgMfTerm enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 112,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgDm1Enum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgSlEnum =
{
   (Data *)"SL",
   MGT_MGCP_PKG_SIG_LIST
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgSlStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgMfTerm enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 113,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgSlEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgAtmEnum =
{
   (Data *)"ATM",
   MGT_MGCP_PKG_ATM
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgAtmStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgMfTerm enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 114,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgAtmEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgBlEnum =
{
   (Data *)"BL",
   MGT_MGCP_PKG_DTMF_BAS_PBX
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgBlStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgMfTerm enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 115,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgBlEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgDoEnum =
{
   (Data *)"DO",
   MGT_MGCP_PKG_GRD_ANALOG
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgDoStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgMfTerm enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 116,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgDoEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgDtEnum =
{
   (Data *)"DT",
   MGT_MGCP_PKG_DTMF_DIAL_PULSE
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgDtStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgMfTerm enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 117,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgDtEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgMdEnum =
{
   (Data *)"MD",
   MGT_MGCP_PKG_NRAM_MF_GRPD
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgMdStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgMfTerm enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 118,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgMdEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgMsEnum =
{
   (Data *)"MS",
   MGT_MGCP_PKG_MF_WINK_STRT
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgMsStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgMfTerm enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 119,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgMsEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgResEnum =
{
   (Data *)"RES",
   MGT_MGCP_PKG_RES_RESERV
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgResStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgMfTerm enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 120,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgResEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgNaoEnum =
{
   (Data *)"NAO",
   MGT_MGCP_PKG_NAO
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgNaoStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgNao enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 120,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgNaoEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgFaxEnum =
{
   (Data *)"FXR",
   MGT_MGCP_PKG_FAX
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgFaxStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgFax enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 120,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgFaxEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgBauEnum =
{
   (Data *)"BAU",
   MGT_MGCP_PKG_AU_SRVR_BAU
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgBauStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgFax enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 120,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgBauEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgAauEnum =
{
   (Data *)"AAU",
   MGT_MGCP_PKG_AU_SRVR_AAU
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgAauStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgFax enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 120,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgAauEnum,
   NULLP
};

/*
 * [TEL]: Added Defn for Display XML package
 */
PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgXmlEnum =
{
   (Data *)"XML",
   MGT_MGCP_PKG_DISPLAY_XML
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgXmlStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgFax enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 120,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgXmlEnum,
   NULLP
};

/*
 * [TEL]: Added Defn for Feature Key package
 */
PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgKyEnum =
{
   (Data *)"KY",
   MGT_MGCP_PKG_FEATURE_KEY
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgKyStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgFax enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 120,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgKyEnum,
   NULLP
};

/*
 * [TEL]: Added Defn for Business Phone package
 */
PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgBpEnum =
{
   (Data *)"BP",
   MGT_MGCP_PKG_BUS_PHONE
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgBpStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgFax enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 120,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgBpEnum,
   NULLP
};

/*
 * [TEL]: Added Defn for Base package
 */
PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgBEnum =
{
   (Data *)"B",
   MGT_MGCP_PKG_BASE
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgBStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgFax enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 120,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgBEnum,
   NULLP
};
#endif

PUBLIC CmAbnfElmTypeEnum mgMsgDefKnownPkgAllEnum =
{
   (Data *)"*",
   MGT_MGCP_PKG_ALL
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgAllStr =
{
#ifdef CM_ABNF_DBG
   "KnownPkgAll enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 121,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefKnownPkgAllEnum,
   NULLP
};

PUBLIC CmAbnfElmDef mgMsgDefSkipKnownPkgNameString =
{
#ifdef CM_ABNF_DBG
   "MGCP: Skip package name string",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 122,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};



#ifdef GCP_VER_1_3
PUBLIC CmAbnfElmDef *mgMsgDefKnownPkgNameEnum[] =
{
   NULLP,
   &mgMsgDefKnownPkgGenericStr,
   &mgMsgDefKnownPkgDtmfStr,
   &mgMsgDefKnownPkgMfStr,
   &mgMsgDefKnownPkgTrunkStr,
   &mgMsgDefKnownPkgLineStr,
   &mgMsgDefKnownPkgHandsetStr,
   &mgMsgDefKnownPkgRtpStr,
   &mgMsgDefKnownPkgNasStr,
   &mgMsgDefKnownPkgAnnStr,
   &mgMsgDefKnownPkgScriptStr,
   &mgMsgDefKnownPkgAdsiStr,
   &mgMsgDefKnownPkgIsupTrunkStr,
   &mgMsgDefKnownPkgMfFgdStr,
   &mgMsgDefKnownPkgMfTermStr,

   &mgMsgDefKnownPkgSstStr ,
   &mgMsgDefKnownPkgCstStr ,
   &mgMsgDefKnownPkgDm1Str ,
   &mgMsgDefKnownPkgSlStr ,
   &mgMsgDefKnownPkgAtmStr ,
   &mgMsgDefKnownPkgBlStr ,
   &mgMsgDefKnownPkgDoStr ,
   &mgMsgDefKnownPkgDtStr ,
   &mgMsgDefKnownPkgMdStr ,
   &mgMsgDefKnownPkgMsStr ,
   &mgMsgDefKnownPkgResStr ,

   &mgMsgDefKnownPkgNaoStr ,
   &mgMsgDefKnownPkgFaxStr ,

   &mgMsgDefKnownPkgAllStr ,

   &mgMsgDefKnownPkgBauStr ,  /* addition */
   &mgMsgDefKnownPkgAauStr ,  /* addition */

   &mgMsgDefKnownPkgXmlStr,   /* [TEL]: Addition */
   &mgMsgDefKnownPkgKyStr,    /* [TEL]: Addition */
   &mgMsgDefKnownPkgBpStr,    /* [TEL]: Addition */
   &mgMsgDefKnownPkgBStr,     /* [TEL]: Addition */

};
#else
PUBLIC CmAbnfElmDef *mgMsgDefKnownPkgNameEnum[] =
{
   NULLP,
   &mgMsgDefKnownPkgGenericStr,
   &mgMsgDefKnownPkgDtmfStr,
   &mgMsgDefKnownPkgMfStr,
   &mgMsgDefKnownPkgTrunkStr,
   &mgMsgDefKnownPkgLineStr,
   &mgMsgDefKnownPkgHandsetStr,
   &mgMsgDefKnownPkgRtpStr,
   &mgMsgDefKnownPkgNasStr,
   &mgMsgDefKnownPkgAnnStr,
   &mgMsgDefKnownPkgScriptStr,
   &mgMsgDefKnownPkgAdsiStr,
   &mgMsgDefKnownPkgIsupTrunkStr,
   &mgMsgDefKnownPkgMfFgdStr,
   &mgMsgDefKnownPkgMfTermStr,
   NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,
   &mgMsgDefKnownPkgAllStr,NULLP,NULLP,  /* addition */
   NULLP,  /* [TEL]: Addition */
   NULLP,  /* [TEL]: Addition */
   NULLP,  /* [TEL]: Addition */
   NULLP   /* [TEL]: Addition */
};
#endif

PUBLIC CmAbnfElmDef *mgMsgDefKnownPkgNameElmnts[] =
{
   &mgMsgDefSkipKnownPkgNameString
};

/*
 * [TEL]: Changed to MGT_MGCP_PKG_MAX
 */
PUBLIC U8 mgMsgDefKnownPkgNameIdx[] = {
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 
};


PUBLIC CmAbnfElmTypeChoice mgMsgDefKnownPkgNameChc =
{
   1,
   MGT_MGCP_PKG_MAX,
   mgMsgDefKnownPkgNameIdx,
   mgMsgDefKnownPkgNameElmnts,
   mgMsgDefKnownPkgNameEnum
};

PUBLIC CmAbnfElmDef mgMsgDefKnownPkgName =
{
#ifdef CM_ABNF_DBG
   "MGCP: Known package name",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 123,
   sizeof(MgPkgName), 
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefKnownPkgNameChc,
   mgMsgRegExpPackageName
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefUnknownPkgNameEnum =
{
   NULLP,
   MGT_MGCP_PKG_UNKNOWN
};

PUBLIC CmAbnfElmDef mgMsgDefUnknownPkgNameStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: Unknown PkgName enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 124,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefUnknownPkgNameEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefPkgNameStringElmnts[] =
{
   &mgMsgDefUnknownPkgNameString,
   &mgMsgDefKnownPkgName
};

/*
 * [TEL]: Enhanced to MGT_MGCP_PKG_MAX
 */
PUBLIC CmAbnfElmDef *mgMsgDefPkgNameStringEnum[] =
{
   &mgMsgDefUnknownPkgNameStr,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP  
};

/*
 * [TEL]: Enhanced to MGT_MGCP_PKG_MAX
 */
PUBLIC U8 mgMsgDefPkgNameStringIdx[] = {0, 
   1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
   1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
   1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefPkgNameStringChc =
{
   2,
   MGT_MGCP_PKG_MAX,
   mgMsgDefPkgNameStringIdx,
   mgMsgDefPkgNameStringElmnts,
   mgMsgDefPkgNameStringEnum
};

#ifdef GCP_VER_1_3

PUBLIC CmAbnfElmDef mgMsgDefPkgNameStringReal =  /* change */
{
#ifdef CM_ABNF_DBG
   "MGCP: Package name",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 125,
   sizeof(MgPkgName),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefPkgNameStringChc,
   mgMsgRegExpPackageName
};

/* start of addition */
PUBLIC CmAbnfElmTypeMarker mgMsgDefMarkPkgNameStringMarker =
{
   CM_ABNF_MARKER_ESC_FUNC,
   (U8 *)mgMsgMrkFuncPkgNameString
};

PUBLIC CmAbnfElmDef mgMsgDefMarkPkgNameString =
{
#ifdef CM_ABNF_DBG
   "Marker PkgName",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 125,
   0,
   0,
   CM_ABNF_TYPE_MARKER,
   (U8 *)&mgMsgDefMarkPkgNameStringMarker,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefMarkedPkgNameStringSeqElmnt[] =
{
   &mgMsgDefPkgNameStringReal,
   &mgMsgDefMarkPkgNameString,
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefMarkedPkgNameStringSeq =
{
   2,
   mgMsgDefMarkedPkgNameStringSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefPkgNameString =
{
#ifdef CM_ABNF_DBG
   "MGCP: Marked Package name",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 125,
   sizeof(MgPkgName),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefMarkedPkgNameStringSeq,
   NULLP
};
/* end of addition */

#else  /* addition of else part and flags */

PUBLIC CmAbnfElmDef mgMsgDefPkgNameString =
{
#ifdef CM_ABNF_DBG
   "MGCP: Package name",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 125,
   sizeof(MgPkgName),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefPkgNameStringChc,
   mgMsgRegExpPackageName
};

#endif /* GCP_VER_1_3 */


PUBLIC CmAbnfElmDef *mgMsgDefSuppPkgListSeqOfElmnt[] =
{
   &cmMsgDefMetaSemiColon,
   &mgMsgDefPkgNameString
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefSuppPkgListSeqOf =
{
   1,
   MGT_MAX_SUPP_PKG,
   2,
   mgMsgDefSuppPkgListSeqOfElmnt,
   sizeof(MgPkgName)  
};

PUBLIC CmAbnfElmDef mgMsgDefSuppPkgList = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SUPPKGLST", 
   "CM_RSEMICOLON",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 126,
   sizeof(MgSuppPkgs),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefSuppPkgListSeqOf,
   cmAbnfRegExpSemiColon
};

PUBLIC CmAbnfElmDef *mgMsgDefSuppPkgsSeqOfElmnt[] =
{
   &mgMsgDefPkgNameString,
   &mgMsgDefSuppPkgList
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefSuppPkgsSeqOf =
{
   2,
   mgMsgDefSuppPkgsSeqOfElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefSuppPkgs = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SUPPKG", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 127,
   sizeof(MgSuppPkgs),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefSuppPkgsSeqOf,
   NULLP
};
/************************************************************************
          Database element for Connection Opts: Encryption Information
************************************************************************/
PUBLIC CmAbnfElmTypeRange mgMsgDefEncryptLKeyUriRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefEncryptLKeyUri = 
{
#ifdef CM_ABNF_DBG
   "MGCP: URIKEY", 
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   "R35",
#else
   "R37",
#endif
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 128,
   sizeof(TknStrOSXL),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefEncryptLKeyUriRng,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   mgMsgRegExpR35                    /* the new R35 */
#else
   mgMsgRegExpR37
#endif
};

PUBLIC CmAbnfElmTypeRange mgMsgDefEncryptLKeyBase64Rng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefEncryptLKeyBase64 = 
{
#ifdef CM_ABNF_DBG
   "MGCP: BASE64KEY", 
   "R36",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 129,
   sizeof(TknStrOSXL),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefEncryptLKeyBase64Rng,
   mgMsgRegExpR36
};

PUBLIC CmAbnfElmTypeRange mgMsgDefEncryptLKeyClearRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefEncryptLKeyClear = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CLEARKEY", 
   "R35",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 130,
   sizeof(TknStrOSXL),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefEncryptLKeyClearRng,
   mgMsgRegExpR35
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefEncryptMthUriEnum =
{
   (Data *)"uri:",
   CM_SDP_KEY_TYPE_URI
};

PUBLIC CmAbnfElmDef mgMsgDefEncryptMthUriStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: URI", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 131,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEncryptMthUriEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefEncryptMthBase64Enum =
{
   (Data *)"base64:",
   CM_SDP_KEY_TYPE_BASE64
};

PUBLIC CmAbnfElmDef mgMsgDefEncryptMthBase64Str = 
{
#ifdef CM_ABNF_DBG
   "MGCP: BASE64", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 132,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEncryptMthBase64Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefEncryptMthClearEnum =
{
   (Data *)"clear:",
   CM_SDP_KEY_TYPE_CLEAR
};

PUBLIC CmAbnfElmDef mgMsgDefEncryptMthClearStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CLEAR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 133,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEncryptMthClearEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefEncryptMethodChcEnum[] =
{
   NULLP,
   NULLP,
   &mgMsgDefEncryptMthClearStr,
   &mgMsgDefEncryptMthBase64Str,
   &mgMsgDefEncryptMthUriStr
};

PUBLIC CmAbnfElmDef *mgMsgDefEncryptMethodChcElmnt[] =
{
   NULLP,
   NULLP,
   &mgMsgDefEncryptLKeyClear,
   &mgMsgDefEncryptLKeyBase64,
   &mgMsgDefEncryptLKeyUri
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefEncryptMethodChc =
{
   5,
   0,
   NULLP,
   mgMsgDefEncryptMethodChcElmnt,
   mgMsgDefEncryptMethodChcEnum
};

PUBLIC CmAbnfElmDef mgMsgDefEncryptMethod = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ECRPTMTHD ", 
   "R34",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 134,
   sizeof(MgEncryptInfo) - sizeof(TknPres),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefEncryptMethodChc,
   mgMsgRegExpR34
};

PUBLIC CmAbnfElmDef *mgMsgDefEncryptInfoSeqElmnt[] =
{
   &mgMsgDefEncryptMethod
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefEncryptInfoSeq =
{
   1,
   mgMsgDefEncryptInfoSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefEncryptInfo = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ECRTPT ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 135,
   sizeof(MgEncryptInfo),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefEncryptInfoSeq,
   NULLP
};

/************************************************************************
          Database element for Connection Opts: Type of Services  
************************************************************************/
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
PUBLIC CmAbnfElmTypeRange mgMsgDefTONTypeOtherTONRange = { 1 , (U16 )~0 };

PUBLIC CmAbnfElmDef mgMsgDefTONTypeOtherTON =
{
#ifdef CM_ABNF_DBG
    "MGCP: OtherTON",
    "R44",
#endif
    CM_ABNF_ELMNID_MG_BASE + 136,
    sizeof(TknStrOSXL),
    CM_ABNF_MANDATORY,
    CM_ABNF_TYPE_OCTSTRXL,
    (U8 *) &mgMsgDefTONTypeOtherTONRange,
    mgMsgRegExpR44
};

PUBLIC CmAbnfElmDef *mgMsgDefTONTypeChcElmnt[] =
{
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   &mgMsgDefTONTypeOtherTON
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefTONTypeOtherTONEnum =        /* V1.3 */
{
   NULLP,
   MGT_MGCP_LCL_CONNOPT_TON_OTHER
};

PUBLIC CmAbnfElmDef mgMsgDefTONTypeOtherTONEnumDef =          /* V1.3 */
{
#ifdef CM_ABNF_DBG
   "MGCP: TON_LCL", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 137,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefTONTypeOtherTONEnum,
   NULLP
};
#endif

PUBLIC CmAbnfElmTypeEnum mgMsgDefTONTypeLOCALEnum =
{
   (Data *)"LOCAL",
   MGT_LCL_CONNOPT_TON_LOCAL
};

PUBLIC CmAbnfElmDef mgMsgDefTONTypeLOCAL = 
{
#ifdef CM_ABNF_DBG
   "MGCP: TON_LCL", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 138,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefTONTypeLOCALEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefTONTypeATMEnum =
{
   (Data *)"ATM",
   MGT_LCL_CONNOPT_TON_ATM
};

PUBLIC CmAbnfElmDef mgMsgDefTONTypeATM = 
{
#ifdef CM_ABNF_DBG
   "MGCP: TON_ATM ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 139,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefTONTypeATMEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefTONTypeINEnum =
{
   (Data *)"IN",
   MGT_LCL_CONNOPT_TON_IN
};

PUBLIC CmAbnfElmDef mgMsgDefTONTypeIN = 
{
#ifdef CM_ABNF_DBG
   "MGCP: TON_IN", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 140,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefTONTypeINEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefTONTypeChcEnum[] =
{
   NULLP,
   &mgMsgDefTONTypeIN,
   &mgMsgDefTONTypeATM,
   &mgMsgDefTONTypeLOCAL,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefTONTypeOtherTONEnumDef       /* V1.3 */
#endif
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefTONTypeChc =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   5,                             /* V1.3 */
#else
   4,
#endif
   0,
   NULLP,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   mgMsgDefTONTypeChcElmnt,       /* V1.3 */
#else
   NULLP,
#endif
   mgMsgDefTONTypeChcEnum
};

PUBLIC CmAbnfElmDef mgMsgDefTON = 
{
#ifdef CM_ABNF_DBG
   "MGCP: TONTYPE ", 
   "R33",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 141,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   sizeof(MgTypNwSupp),
#else
   sizeof(TknU8),   
#endif
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefTONTypeChc,
   mgMsgRegExpR33
};

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
/* ~~~~~~~~~~~~~~ */

PUBLIC CmAbnfElmDef  *mgMsgDefTONlistSeqOfElmnts[] =
{
    &cmMsgDefMetaSemiColon ,
    &mgMsgDefTON
};

PUBLIC CmAbnfElmTypeSeqOf  mgMsgDefTONlistSeqOf =
{
    1 ,
    (U16)~0 ,
    2 ,
    mgMsgDefTONlistSeqOfElmnts ,
    sizeof (MgTypNwSupp)
};

PUBLIC CmAbnfElmDef  mgMsgDefTONlist =
{
#ifdef  CM_ABNF_DBG
    "MGCP: TONlist" ,
    "CM_RSEMICOLON" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 142,
    sizeof (MgTypNwSuppSeq) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_SEQOF ,
    (U8 *) &mgMsgDefTONlistSeqOf ,
    cmAbnfRegExpSemiColon
};

PUBLIC CmAbnfElmDef  *mgMsgDefSuppTONsSeqElmnts[] =
{
    &mgMsgDefTON ,
    &mgMsgDefTONlist
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefSuppTONsSeq =
{
    2 ,
    mgMsgDefSuppTONsSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefSuppTONs =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SuppTONs" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 143,
    sizeof (MgTypNwSuppSeq) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQOF ,
    (U8 *) &mgMsgDefSuppTONsSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefTON_0_Enum =
{
    NULLP ,
    MGT_MGCP_TON
};

PUBLIC CmAbnfElmDef  mgMsgDefTONEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: TON_0_EnumDef" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 144,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefTON_0_Enum ,
    NULLP
};



PUBLIC CmAbnfElmTypeEnum  mgMsgDefSuppTONs_1_Enum =
{
    NULLP ,
    MGT_MGCP_SUPP_TONS
};

PUBLIC CmAbnfElmDef  mgMsgDefSuppTONsEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SuppTONs_1_EnumDef" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 145,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefSuppTONs_1_Enum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefChoiceTONChcEnum[] =
{
&mgMsgDefTONEnumDef ,
&mgMsgDefSuppTONsEnumDef ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefChoiceTONChcElmnt[] =
{
    &mgMsgDefTON ,
    &mgMsgDefSuppTONs ,
};
PUBLIC CmAbnfElmTypeChoice  mgMsgDefChoiceTONChc =
{
    2 ,
    0 ,
    NULLP ,
    mgMsgDefChoiceTONChcElmnt ,
    mgMsgDefChoiceTONChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefChoiceTON =
{
#ifdef  CM_ABNF_DBG
    "MGCP: ChoiceTON" ,
    "R43" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 146,
    sizeof (MgNwTypeChc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefChoiceTONChc ,
    mgMsgRegExpR43
};

/* ~~~~~~~~~~~~~~ */
#endif


/************************************************************************
          Database element for Connection Opts: Resource  Reservation 
************************************************************************/
PUBLIC CmAbnfElmTypeEnum mgMsgDefRsRsvGEnum =
{
   (Data *)"g",
   MGT_LCL_CONNOPT_RSRC_RESV_G
};

PUBLIC CmAbnfElmDef mgMsgDefRsRsvG = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSTYPE_G", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 147,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefRsRsvGEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefRsRsvCLEnum =
{
   (Data *)"cl",
   MGT_LCL_CONNOPT_RSRC_RESV_CL
};

PUBLIC CmAbnfElmDef mgMsgDefRsRsvCL = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSTYPE_CL ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 148,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefRsRsvCLEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefRsRsvBEEnum =
{
   (Data *)"be",
   MGT_LCL_CONNOPT_RSRC_RESV_BE
};

PUBLIC CmAbnfElmDef mgMsgDefRsRsvBE = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSTYPE_BE ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 149,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefRsRsvBEEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefRsRsvChcEnum[] =
{
   NULLP,
   &mgMsgDefRsRsvG,
   &mgMsgDefRsRsvCL,
   &mgMsgDefRsRsvBE
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefRsRsvCh =
{
   4,
   0,
   NULLP,
   NULLP,
   mgMsgDefRsRsvChcEnum
};

PUBLIC CmAbnfElmDef mgMsgDefRsRsv = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSTYPE ", 
   "R32",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 150,
   sizeof(TknU8),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefRsRsvCh,
   mgMsgRegExpR32
};

/************************************************************************
          Database element for Connection Opts: Type of Services 
************************************************************************/

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMsgDefTOSRng =  {1, 2, 0, (U32)255};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefTOSRng =  {1,2};
#endif /* CM_ABNF_V_1_2 */

#else

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMsgDefTOSRng =  {2, 2, 0, (U32)255};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefTOSRng =  {2,2};
#endif /* CM_ABNF_V_1_2 */

#endif

PUBLIC CmAbnfElmDef mgMsgDefTOS = 
{
#ifdef CM_ABNF_DBG
   "MGCP: TOS ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 151,
   sizeof(TknU16),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_HEXUINT16,
   (U8 *)&mgMsgDefTOSRng,
   cmAbnfRegExpXDgt
};


/* new element added */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
PUBLIC CmAbnfElmTypeMarker mgMsgDefMarkEncDecTOSMarker =
{
   CM_ABNF_MARKER_ESC_FUNC,
   (U8 *)mgMsgMrkFuncTOS
};

PUBLIC CmAbnfElmDef mgMsgDefMarkEncDecTOS =
{
#ifdef CM_ABNF_DBG
   "Marker func TOS",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 151,
   0,
   0,
   CM_ABNF_TYPE_MARKER,
   (U8 *)&mgMsgDefMarkEncDecTOSMarker,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefMarkedTOSSeqElmnt[] =
{
   &mgMsgDefMarkEncDecTOS,
   &mgMsgDefTOS,
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefMarkedTOSSeq =
{
   2,
   mgMsgDefMarkedTOSSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefMarkedTOS = 
{
#ifdef CM_ABNF_DBG
   "MGCP: Marked TOS", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 151,
   sizeof(TknU16),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefMarkedTOSSeq,
   NULLP
};
#endif
/* end of addition */

/************************************************************************
          Database element for Connection Opts: Gain Control 
************************************************************************/
#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeSIntRange mgMsgDefGainCtrlValRng = {1, 5, -9999, (U32)9999};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefGainCtrlValRng = {1,4};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMsgDefGainCtrlVal = 
{
#ifdef CM_ABNF_DBG
   "MGCP: GC_VAL ",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 152,
   sizeof(TknS16),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SINT16,
   (U8 *)&mgMsgDefGainCtrlValRng,
   cmAbnfRegExpSDgt
};

PUBLIC CmAbnfElmDef mgMsgDefGainCtrlAuto = 
{
#ifdef CM_ABNF_DBG
   "MGCP: GCAUTO", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 153,
   sizeof(TknU16),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefGainCtrlAutoStrEnum =
{
   (Data *)"auto",
   MGT_GAIN_CTRL_AUTO
};

PUBLIC CmAbnfElmDef mgMsgDefGainCtrlAutoStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: GCAUTO_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 154,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefGainCtrlAutoStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefGainCtrlValStrEnum =
{
   NULLP,
   MGT_GAIN_CTRL_VAL
};

PUBLIC CmAbnfElmDef mgMsgDefGainCtrlValStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: GCVAL_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 155,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefGainCtrlValStrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefGainCtrlChcEnum[] =
{
   NULLP,
   &mgMsgDefGainCtrlAutoStr,
   &mgMsgDefGainCtrlValStr
};

PUBLIC CmAbnfElmDef *mgMsgDefGainCtrlChcElmnt[] =
{
   NULLP,
   &mgMsgDefGainCtrlAuto,
   &mgMsgDefGainCtrlVal
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefGainCtrlChc =
{
   3,
   0,
   NULLP,
   mgMsgDefGainCtrlChcElmnt,
   mgMsgDefGainCtrlChcEnum
};

PUBLIC CmAbnfElmDef mgMsgDefGainCtrl = 
{
#ifdef CM_ABNF_DBG
   "MGCP: GCTRL ", 
   "R31",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 156,
   sizeof(MgGainCtrl),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefGainCtrlChc,
   mgMsgRegExpR31
};

/************************************************************************
          Database element for Connection Opts: Echo Cancellation 
          Database element for Connection Opts: Silence Suppression 
************************************************************************/
/************************************************************************
          Database element for Connection Opts: Bandwidth 
************************************************************************/
#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMsgDefBwValRng =  {1, 4, 0, (U32)9999};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefBwValRng =  {1, 4};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMsgDefBwVal = 
{
#ifdef CM_ABNF_DBG
   "MGCP: BWVAL ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 157,
   sizeof(TknU16),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&mgMsgDefBwValRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMsgDefBwUprValSeqElmnt[] =
{
   &cmMsgDefMetaHyphen,
   &mgMsgDefBwVal
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefBwUprValSeq =
{
   2,
   mgMsgDefBwUprValSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefBwUprVal = 
{
#ifdef CM_ABNF_DBG
   "MGCP: BWUPRVAL ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 158,
   sizeof(TknU16),   
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefBwUprValSeq,
   cmAbnfRegExpHyphen
};

PUBLIC CmAbnfElmDef *mgMsgDefBwSeqElmnt[] =
{
   &mgMsgDefBwVal,
   &mgMsgDefBwUprVal
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefBwSeq =
{
   2,
   mgMsgDefBwSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefBw = 
{
#ifdef CM_ABNF_DBG
   "MGCP: BW ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 159,
   sizeof(MgBw),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefBwSeq,
   NULLP
};
/************************************************************************
          Database element for Connection Opts: Compression Algorithm 
************************************************************************/

PUBLIC CmAbnfElmTypeRange mgMsgDefAlgoNameRng
#ifdef MGT_GCP_VER_1_4
                                           =     {1, 0xFFFF};
#else  /* MGT_GCP_VER_1_4 */
                                           =     {1, 32};
#endif /* MGT_GCP_VER_1_4 */


PUBLIC CmAbnfElmDef mgMsgDefAlgoName = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ALGONM", 
   "CM_RSUTBLCHAR",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 160,

#ifdef MGT_GCP_VER_1_4
   sizeof(TknStrOSXL),
#else  /* MGT_GCP_VER_1_4 */
   sizeof(TknStr32),   
#endif /* MGT_GCP_VER_1_4 */

   (CM_ABNF_MANDATORY),

#ifdef MGT_GCP_VER_1_4
   CM_ABNF_TYPE_OCTSTRXL,
#else  /* MGT_GCP_VER_1_4 */
   CM_ABNF_TYPE_OCTSTR32,
#endif /* MGT_GCP_VER_1_4 */

   (U8 *)&mgMsgDefAlgoNameRng,

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
    mgMsgRegExpR48         /* actually it shd be cmAbnfRegExpSutblLCOChar */
#else
   cmAbnfRegExpSutblChar
#endif
};

PUBLIC CmAbnfElmDef *mgMsgDefAlgoNameSeqOfElmnt[] =
{
   &cmMsgDefMetaSemiColon,
   &mgMsgDefAlgoName
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefAlgoNameSeqOf =
{
   1, 
   MGT_MAX_ALGO_NAMES,
   2,
   mgMsgDefAlgoNameSeqOfElmnt,

#ifdef MGT_GCP_VER_1_4
   sizeof(TknStrOSXL)   
#else  /* MGT_GCP_VER_1_4 */
   sizeof(TknStr32)   
#endif /* MGT_GCP_VER_1_4 */

};

PUBLIC CmAbnfElmDef mgMsgDefAlgoNameList = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ALGONM_SET", 
   "CM_RSEMICOLON",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 161,
   sizeof(MgAlgoNameSet),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefAlgoNameSeqOf,
   cmAbnfRegExpSemiColon
};

PUBLIC CmAbnfElmDef *mgMsgDefAlgoNameSetSeqOfElmnt[] =
{
   &mgMsgDefAlgoName,
   &mgMsgDefAlgoNameList
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefAlgoNameSetSeqOf =
{
   2, 
   mgMsgDefAlgoNameSetSeqOfElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefAlgoNameSet = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ALGO", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 162,
   sizeof(MgAlgoNameSet),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefAlgoNameSetSeqOf,
   NULLP
};

/************************************************************************
          Database element for Connection Opts: Packetized Period 
************************************************************************/
#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMsgDefPktzPerBndRng = {1, 4, 0, (U32)9999};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefPktzPerBndRng = {1,4};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMsgDefPktzPerBnd = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PKTZ_LOW", 
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 163,
   sizeof(TknU16),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&mgMsgDefPktzPerBndRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMsgDefPktzPerUprBndSeqElmnt[] =
{
   &cmMsgDefMetaHyphen,
   &mgMsgDefPktzPerBnd

};

PUBLIC CmAbnfElmTypeSeq mgMsgDefPktzPerUprBndSeq =
{
   2,
   mgMsgDefPktzPerUprBndSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefPktzPerUprBnd = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PKTZ_UPR", 
   "CM_RDASH",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 164,
   sizeof(TknU16),   
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefPktzPerUprBndSeq,
   cmAbnfRegExpHyphen
};

PUBLIC CmAbnfElmDef *mgMsgDefPktzPeriodSeqElmnt[] =
{
   &mgMsgDefPktzPerBnd,
   &mgMsgDefPktzPerUprBnd
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefPktzPeriodSeq =
{
   2,
   mgMsgDefPktzPeriodSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefPktzPeriod = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PKTZVAL", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 165,
   sizeof(MgPktzPeriod),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefPktzPeriodSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefDqosRsvDestSeqElmnt[] =
{
   &mgMsgDefDomainName,
   &mgMsgDefPortNmb,
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefDqosRsvDestSeq =
{
   2,
   mgMsgDefDqosRsvDestSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefDqosRsvDest =
{
#ifdef CM_ABNF_DBG
   "MGCP: NCS: DQOSRSVDEST",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 166,
   sizeof(MgRsvDest),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_NCS_OFFSET,
   CM_ABNF_TYPE_SEQ,            
   (U8 *)&mgMsgDefDqosRsvDestSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefSecSecretMethodClearEnum =
{
   (Data *)"clear:",
   MGT_LCL_CONNOPT_SEC_SECRET_CLEAR
};

PUBLIC CmAbnfElmDef mgMsgDefSecSecretMethodClearStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: SecSecretMethodClear",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 167,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSecSecretMethodClearEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefSecSecretMethodBase64Enum =
{
   (Data *)"base64:",
   MGT_LCL_CONNOPT_SEC_SECRET_BASE64
};

PUBLIC CmAbnfElmDef mgMsgDefSecSecretMethodBase64Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: SecSecretMethodBase64",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 168,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSecSecretMethodBase64Enum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefSecSecretMethodChcElmnt[] =
{
   NULLP,
   &mgMsgDefSecSecretMethodClearStr,
   &mgMsgDefSecSecretMethodBase64Str,
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefSecSecretMethodChc =
{
   3,
   0,
   NULLP,
   NULLP,
   mgMsgDefSecSecretMethodChcElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefSecSecretMethod =
{
#ifdef CM_ABNF_DBG     
   "MGCP: SecSecretMethod",
   "RSecSecretMethod",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 169,
   sizeof(TknU8),   
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_TGCP_OFFSET |
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_NCS_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefSecSecretMethodChc,
   mgMsgRegExpRSecSecretMethod
};

PUBLIC CmAbnfElmTypeRange mgMsgDefSecSecretKeyRng = { 1, 0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefSecSecretKey =
{
#ifdef CM_ABNF_DBG
   "MGCP: SecSecretKey",
   "RSecSecretKey",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 170,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_TGCP_OFFSET |
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_NCS_OFFSET,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefSecSecretKeyRng,
   mgMsgRegExpRSecSecretKey
};

PUBLIC CmAbnfElmDef *mgMsgDefSecSecretSeqElmnt[] =
{
   &mgMsgDefSecSecretMethod,
   &mgMsgDefSecSecretKey
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefSecSecretSeq =
{
   2,
   mgMsgDefSecSecretSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefSecSecret =
{
#ifdef CM_ABNF_DBG
   "MGCP: SECSECRET",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 171,
   sizeof(MgSecret),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_NCS_OFFSET |
    CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_TGCP_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefSecSecretSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeRange mgMsgDefSecCipherAuthOrEncAlgoRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefSecCipherAuthOrEncAlgoStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: SecCipherAuthOrEncAlgoStr",
   "RSecCipherAuthOrEncAlgo",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 172,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefSecCipherAuthOrEncAlgoRng,
   mgMsgRegExpRSecCipherAuthOrEncAlgo
};

PUBLIC CmAbnfElmDef *mgMsgDefSecAuthEncAlgoSetSeqOfElmnt[] =
{
   &cmMsgDefMetaSemiColon,
   &mgMsgDefSecCipherAuthOrEncAlgoStr,
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefSecAuthEncAlgoSetSeqOf =
{
   1,
   MGT_MAX_CIPHER_SUITE,
   2,
   mgMsgDefSecAuthEncAlgoSetSeqOfElmnt,
   sizeof(TknStrOSXL),
};

PUBLIC CmAbnfElmDef mgMsgDefSecAuthEncAlgoSet =
{
#ifdef CM_ABNF_DBG
   "MGCP: SecAuthEncAlgoSet",
   "CM_RSEMICOLON",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 173,
   sizeof(MgAuthEncAlgoSet),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MGCP_TGCP_OFFSET |
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MGCP_NCS_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefSecAuthEncAlgoSetSeqOf,
   cmAbnfRegExpSemiColon
};

PUBLIC CmAbnfElmDef *mgMsgDefSecAuthEncAlgoLstSeqElmnt[] =
{
   &mgMsgDefSecCipherAuthOrEncAlgoStr,
   &mgMsgDefSecAuthEncAlgoSet
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefSecAuthEncAlgoLstSeq =
{
   2,
   mgMsgDefSecAuthEncAlgoLstSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefSecAuthEncAlgoLst =
{
#ifdef CM_ABNF_DBG
   "MGCP: SecAuthEncAlgoLst",
   "SecCipherAuthOrEncAlgo",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 174,
   sizeof(MgAuthEncAlgoSet),
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MGCP_TGCP_OFFSET |
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MGCP_NCS_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefSecAuthEncAlgoLstSeq,
   mgMsgRegExpRSecCipherAuthOrEncAlgo
};

PUBLIC CmAbnfElmDef *mgMsgDefSecRtpRtcpSuiteSeqElmnt[] =
{
   &mgMsgDefSecAuthEncAlgoLst,
   &cmMsgDefMetaSlash,
   &mgMsgDefSecAuthEncAlgoLst,
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefSecRtpRtcpSuiteSeq =
{
   3,
   mgMsgDefSecRtpRtcpSuiteSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefSecRtpRtcpSuite =
{
#ifdef CM_ABNF_DBG
   "MGCP: SecRtpRtcpSuite",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 175,
   sizeof(MgCipherSuite),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_TGCP_OFFSET |
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_NCS_OFFSET,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefSecRtpRtcpSuiteSeq,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefDqosSendResvEnum =
{
   (Data *)"sendresv",
   MGT_LCL_CONNOPT_DQOS_RSRCRSV_SENDRESV
};

PUBLIC CmAbnfElmDef mgMsgDefDqosSendResvStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: DqosSendResvStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 176,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefDqosSendResvEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefDqosRecvResvEnum =
{
   (Data *)"recvresv",
   MGT_LCL_CONNOPT_DQOS_RSRCRSV_RECVRESV
};

PUBLIC CmAbnfElmDef mgMsgDefDqosRecvResvStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: DqosRecvResvStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 177,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefDqosRecvResvEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefDqosSnrcResvEnum =
{
   (Data *)"snrcresv",
   MGT_LCL_CONNOPT_DQOS_RSRCRSV_SNRCRESV
};

PUBLIC CmAbnfElmDef mgMsgDefDqosSnrcResvStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: DqosSnrcResvStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 178,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefDqosSnrcResvEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefDqosSendComtEnum =
{
   (Data *)"sendcomt",
   MGT_LCL_CONNOPT_DQOS_RSRCRSV_SENDCOMT
};

PUBLIC CmAbnfElmDef mgMsgDefDqosSendComtStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: DqosSendComtStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 179,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefDqosSendComtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefDqosRecvComtEnum =
{
   (Data *)"recvcomt",
   MGT_LCL_CONNOPT_DQOS_RSRCRSV_RECVCOMT
};

PUBLIC CmAbnfElmDef mgMsgDefDqosRecvComtStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: DqosRecvComtStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 180,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefDqosRecvComtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefDqosSnrcComtEnum =
{
   (Data *)"snrccomt",
   MGT_LCL_CONNOPT_DQOS_RSRCRSV_SNRCCOMT
};

PUBLIC CmAbnfElmDef mgMsgDefDqosSnrcComtStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: DqosSnrcComtStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 181,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefDqosSnrcComtEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefDqosRsrcRsvCompEnum[] =
{
   NULLP,
   &mgMsgDefDqosSendResvStr,
   &mgMsgDefDqosRecvResvStr,
   &mgMsgDefDqosSnrcResvStr,
   &mgMsgDefDqosSendComtStr,
   &mgMsgDefDqosRecvComtStr,
   &mgMsgDefDqosSnrcComtStr,
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefDqosRsrcRsvCompChc =
{
   7,
   0,
   NULLP,
   NULLP,
   mgMsgDefDqosRsrcRsvCompEnum
};

PUBLIC CmAbnfElmDef mgMsgDefDqosRsrcRsvComp =
{
#ifdef CM_ABNF_DBG        
   "MGCP: DQOSRSRCRSVCOMP",
   "RDqosRsrcRsvComp",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 182,
   sizeof(TknU8),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_NCS_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefDqosRsrcRsvCompChc,
   mgMsgRegExpRDqosRsrcRsvComp
};

PUBLIC CmAbnfElmDef *mgMsgDefDqosRsrcRsvCompSetSeqOfElmnt[] =
{
   &cmMsgDefMetaSemiColon,
   &mgMsgDefDqosRsrcRsvComp,
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefDqosRsrcRsvCompSetSeqOf =
{
   1,
   MGT_MAX_RSRC_RSV_COMP,
   2,
   mgMsgDefDqosRsrcRsvCompSetSeqOfElmnt,
   sizeof(TknU8),
};

PUBLIC CmAbnfElmDef mgMsgDefDqosRsrcRsvCompSet =
{
#ifdef CM_ABNF_DBG
   "MGCP: NCS: DQOSRSRCRSVCOMP_SET",
   "CM_RSEMICOLON",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 183,
   sizeof(MgRsrcRsvSet),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MGCP_NCS_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefDqosRsrcRsvCompSetSeqOf,
   cmAbnfRegExpSemiColon
};

PUBLIC CmAbnfElmDef *mgMsgDefDqosRsrcRsvSeqElmnt[] =
{
   &mgMsgDefDqosRsrcRsvComp,
   &mgMsgDefDqosRsrcRsvCompSet
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefDqosRsrcRsvSeq =
{
   2,
   mgMsgDefDqosRsrcRsvSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefDqosRsrcRsv =
{
#ifdef CM_ABNF_DBG        
   "MGCP: NCS: RsrcRsv",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 184,
   sizeof(MgRsrcRsvSet),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_NCS_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefDqosRsrcRsvSeq,
   NULLP
};


#ifdef GCP_VER_1_3


#ifdef  CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange  mgMsgDefLclFmtpCodecInstRange =  {   1 , 3 , 0 , (U32)255  };
#else
PUBLIC CmAbnfElmTypeRange  mgMsgDefLclFmtpCodecInstRange =  {   1 , 3  };
#endif

PUBLIC CmAbnfElmDef  mgMsgDefLclFmtpCodecInst =
{
#ifdef  CM_ABNF_DBG
    "MGCP: LCL FMTP CODEC INST " ,
    "cmAbnfRegExpDgt" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 185,
    sizeof (TknU8) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_UINT8 ,
    (U8 *) &mgMsgDefLclFmtpCodecInstRange ,
    cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef  *mgMsgDefLclFmtpOptCodecInstSeqElmnts[] =
{
    &cmMsgDefMetaColon ,
    &mgMsgDefLclFmtpCodecInst
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefLclFmtpOptCodecInstSeq =
{
    2 ,
    mgMsgDefLclFmtpOptCodecInstSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefLclFmtpOptCodecInst =
{
#ifdef  CM_ABNF_DBG
    "MGCP: LCL FMTP OPT CODEC INST " ,
    "cmAbnfRegExpColon" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 186,
    sizeof(TknU8) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefLclFmtpOptCodecInstSeq ,
    cmAbnfRegExpColon
};

PUBLIC CmAbnfElmTypeRange  mgMsgDefLclFmtpCodecNameRange =  {   1 , 0xffff  };

PUBLIC CmAbnfElmDef  mgMsgDefLclFmtpCodecName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: LCL FMTP CODEC NAME " ,
    "mgMsgRegExpCodecFormat" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 187,
    sizeof (TknStrOSXL) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OCTSTRXL ,
    (U8 *) &mgMsgDefLclFmtpCodecNameRange ,
    mgMsgRegExpCodecFormat
};


PUBLIC CmAbnfElmTypeMeta  mgMsgDefQuoteMeta =  {  (Data *) "\""  };

PUBLIC CmAbnfElmDef  mgMsgDefQuote =
{
#ifdef  CM_ABNF_DBG
    "MGCP: QUOTE " ,
    "mgMsgRegExpQuote" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 188,
    0 ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_META ,
    (U8 *) &mgMsgDefQuoteMeta ,
    mgMsgRegExpQuote
};

PUBLIC CmAbnfElmDef  *mgMsgDefLclFmtpValSeqElmnts[] =
{
    &mgMsgDefQuote ,
    &mgMsgDefLclFmtpCodecName ,
    &mgMsgDefLclFmtpOptCodecInst ,
    &cmMsgDefMetaSpace ,
    &mgMsgDefLclFmtpCodecName ,
    &mgMsgDefQuote
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefLclFmtpValSeq =
{
    6 ,
    mgMsgDefLclFmtpValSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefLclFmtpVal =
{
#ifdef  CM_ABNF_DBG
    "MGCP: LCL FMTP VAL " ,
    "mgMsgRegExpQuote" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 189,
    sizeof(MgMgcpLclFmtpVal) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQ ,
    (U8 *) &mgMsgDefLclFmtpValSeq ,
    mgMsgRegExpQuote
};

PUBLIC CmAbnfElmDef  *mgMsgDefLclFmtpValListSeqOfElmnts[] =
{
    &cmMsgDefMetaSemiColon ,
    &cmMsgDefOptMetaSpace ,
    &mgMsgDefLclFmtpVal
};

PUBLIC CmAbnfElmTypeSeqOf  mgMsgDefLclFmtpValListSeqOf =
{
    1 ,
    100 ,
    3 ,
    mgMsgDefLclFmtpValListSeqOfElmnts ,
    sizeof (MgMgcpLclFmtpVal)
};

PUBLIC CmAbnfElmDef  mgMsgDefLclFmtpValList =
{
#ifdef  CM_ABNF_DBG
    "MGCP: LCL FMTP VAL LIST " ,
    "cmAbnfRegExpSemiColon" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 190,
    sizeof(MgMgcpLclFmtpValSet) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQOF ,
    (U8 *) &mgMsgDefLclFmtpValListSeqOf ,
    cmAbnfRegExpSemiColon
};

PUBLIC CmAbnfElmDef  *mgMsgDefLclFmtpSeqElmnts[] =
{
    &mgMsgDefLclFmtpVal ,
    &mgMsgDefLclFmtpValList
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefLclFmtpSeq =
{
    2 ,
    mgMsgDefLclFmtpSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefLclFmtp =
{
#ifdef  CM_ABNF_DBG
    "MGCP: LCL FMTP " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 191,
    sizeof(MgMgcpLclFmtpValSet) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQOF ,
    (U8 *) &mgMsgDefLclFmtpSeq ,
    NULLP
};



PUBLIC CmAbnfElmTypeEnum  mgMsgDefLclRsShThisConnEnum =
{
    (Data *)"$" ,
    MGT_MGCP_LCL_CONNOPT_RS_SH_THIS_CONN
};

PUBLIC CmAbnfElmDef  mgMsgDefLclRsShThisConnEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: LCL RS SH THIS CONN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 192,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefLclRsShThisConnEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefLclRsShEmptyConnEnum =
{
    NULLP ,
    MGT_MGCP_LCL_CONNOPT_RS_SH_EMPTY_CONN
};

PUBLIC CmAbnfElmDef  mgMsgDefLclRsShEmptyConnEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: LCL RS SH EMPTY CONN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 193,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefLclRsShEmptyConnEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefLclRsShSpecficConnEnum =
{
    NULLP ,
    MGT_MGCP_LCL_CONNOPT_RS_SH_SPECFIC_CONN
};

PUBLIC CmAbnfElmDef  mgMsgDefLclRsShSpecficConnEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: LCL RS SH SPECFIC CONN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 194,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefLclRsShSpecficConnEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefLclRsShChcEnum[] =
{
&mgMsgDefLclRsShThisConnEnumDef ,
&mgMsgDefLclRsShEmptyConnEnumDef ,
&mgMsgDefLclRsShSpecficConnEnumDef ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefLclRsShChcElmnt[] =
{
    NULLP ,
    NULLP ,
    &mgMsgDefConnId ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefLclRsShChc =
{
    3 ,
    0 ,
    NULLP ,
    mgMsgDefLclRsShChcElmnt ,
    mgMsgDefLclRsShChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefLclRsSh =
{
#ifdef  CM_ABNF_DBG
    "MGCP: LCL RS SH " ,
    "mgMsgRegExpResShr" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 195,
    sizeof(MgMgcpLclRsSh) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefLclRsShChc ,
    mgMsgRegExpResShr
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefLclRsRsvDirSndOnlyEnum =
{
    (Data *)"sendonly" ,
    MGT_MGCP_CONNOPT_LCL_RS_RSV_DIR_SND_ONLY
};

PUBLIC CmAbnfElmDef  mgMsgDefLclRsRsvDirSndOnlyEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: LCL RS RSV DIR SND ONLY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 196,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefLclRsRsvDirSndOnlyEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefLclRsRsvDirRcvOnlyEnum =
{
    (Data *)"recvonly" ,
    MGT_MGCP_CONNOPT_LCL_RS_RSV_DIR_RCV_ONLY
};

PUBLIC CmAbnfElmDef  mgMsgDefLclRsRsvDirRcvOnlyEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: LCL RS RSV DIR RCV ONLY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 197,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefLclRsRsvDirRcvOnlyEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefLclRsRsvDirSndRcvEnum =
{
    (Data *)"sendrecv" ,
    MGT_MGCP_CONNOPT_LCL_RS_RSV_DIR_SND_RCV
};

PUBLIC CmAbnfElmDef  mgMsgDefLclRsRsvDirSndRcvEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: LCL RS RSV DIR SND RCV ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 198,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefLclRsRsvDirSndRcvEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefLclRsRsvDirChcEnum[] =
{
&mgMsgDefLclRsRsvDirSndOnlyEnumDef ,
&mgMsgDefLclRsRsvDirRcvOnlyEnumDef ,
&mgMsgDefLclRsRsvDirSndRcvEnumDef ,

};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefLclRsRsvDirChc =
{
    3 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefLclRsRsvDirChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefLclRsRsvDir =
{
#ifdef  CM_ABNF_DBG
    "MGCP: LCL RS RSV DIR " ,
    "mgMsgRegExpRsRsvDir" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 199,
    sizeof(TknU8) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefLclRsRsvDirChc ,
    mgMsgRegExpRsRsvDir
};






PUBLIC CmAbnfElmTypeEnum  mgMsgDefLclRsRsvCnfSndOnlyEnum =
{
    (Data *)"sendonly" ,
    MGT_MGCP_CONNOPT_LCL_RS_RSV_CNF_SND_ONLY
};

PUBLIC CmAbnfElmDef  mgMsgDefLclRsRsvCnfSndOnlyEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: LCL RS RSV CNF SND ONLY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 200,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefLclRsRsvCnfSndOnlyEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefLclRsRsvCnfRcvOnlyEnum =
{
    (Data *)"recvonly" ,
    MGT_MGCP_CONNOPT_LCL_RS_RSV_CNF_RCV_ONLY
};

PUBLIC CmAbnfElmDef  mgMsgDefLclRsRsvCnfRcvOnlyEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: LCL RS RSV CNF RCV ONLY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 201,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefLclRsRsvCnfRcvOnlyEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefLclRsRsvCnfSndRcvEnum =
{
    (Data *)"sendrecv" ,
    MGT_MGCP_CONNOPT_LCL_RS_RSV_CNF_SND_RCV
};

PUBLIC CmAbnfElmDef  mgMsgDefLclRsRsvCnfSndRcvEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: LCL RS RSV CNF SND RCV ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 202,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefLclRsRsvCnfSndRcvEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefLclRsRsvCnfNoneEnum =
{
    (Data *)"none" ,
    MGT_MGCP_CONNOPT_LCL_RS_RSV_CNF_NONE
};

PUBLIC CmAbnfElmDef  mgMsgDefLclRsRsvCnfNoneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: LCL RS RSV CNF NONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 203,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefLclRsRsvCnfNoneEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefLclRsRsvCnfChcEnum[] =
{
&mgMsgDefLclRsRsvCnfSndOnlyEnumDef ,
&mgMsgDefLclRsRsvCnfRcvOnlyEnumDef ,
&mgMsgDefLclRsRsvCnfSndRcvEnumDef ,
&mgMsgDefLclRsRsvCnfNoneEnumDef ,

};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefLclRsRsvCnfChc =
{
    4 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefLclRsRsvCnfChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefLclRsRsvCnf =
{
#ifdef  CM_ABNF_DBG
    "MGCP: LCL RS RSV CNF " ,
    "mgMsgRegExpRsRsvCnf" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 204,
    sizeof(TknU8) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefLclRsRsvCnfChc ,
    mgMsgRegExpRsRsvCnf
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefOptFmtpSetStrEnum =
{
   (Data *)"o-fmtp:",
   MGT_MGCP_LCL_CONNOPT_OPT_FMTP
};

PUBLIC CmAbnfElmDef mgMsgDefOptFmtpSetStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: OptFmtpSetStr", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 205,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefOptFmtpSetStrEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefFmtpSetStrEnum =
{
   (Data *)"fmtp:",
   MGT_MGCP_LCL_CONNOPT_FMTP
};

PUBLIC CmAbnfElmDef mgMsgDefFmtpSetStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: FmtpSetStr", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 206,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefFmtpSetStrEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefRsResDirStrEnum =
{
   (Data *)"r-dir:",
   MGT_MGCP_LCL_CONNOPT_RES_DIR
};

PUBLIC CmAbnfElmDef mgMsgDefRsResDirStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RsResDirStr", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 207,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefRsResDirStrEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefRsResCnfStrEnum =
{
   (Data *)"r-cnf:",
   MGT_MGCP_LCL_CONNOPT_RES_CNFM
};

PUBLIC CmAbnfElmDef mgMsgDefRsResCnfStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RsResDirStr", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 208,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefRsResCnfStrEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefRsResShStrEnum =
{
   (Data *)"r-sh:",
   MGT_MGCP_LCL_CONNOPT_RES_SHARE
};

PUBLIC CmAbnfElmDef mgMsgDefRsResShStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RsResDirStr", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 209,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefRsResShStrEnum,
   NULLP
};

#endif

PUBLIC CmAbnfElmTypeEnum mgMsgDefNonStdConnOptValStrEnum =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   NULLP,
#else
   (Data *)"x",
#endif
   MGT_MGCP_LCL_CONNOPT_STD_EXT
};

PUBLIC CmAbnfElmDef mgMsgDefNonStdConnOptValStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NSTDCONP_STR ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 210,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefNonStdConnOptValStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefSuppPkgsStrEnum =
{
   (Data *)"v:",
   MGT_LCL_CONNOPT_SUPP_PKGS
};

PUBLIC CmAbnfElmDef mgMsgDefSuppPkgsStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SUPPKG_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 211,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSuppPkgsStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefDqosGateIdStrEnum =
{
   (Data *)"dq-gi:",
   MGT_LCL_CONNOPT_DQOS_GATEID
};

PUBLIC CmAbnfElmDef mgMsgDefDqosGateIdStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NCS: GateIdStr", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 212,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefDqosGateIdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefDqosRsrcRsvStrEnum =
{
   (Data *)"dq-rr:",
   MGT_LCL_CONNOPT_DQOS_RSRCRSV
};

PUBLIC CmAbnfElmDef mgMsgDefDqosRsrcRsvStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NCS: RsrcRsvStr", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 213,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefDqosRsrcRsvStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefDqosRsrcIdStrEnum =
{
   (Data *)"dq-ri:",
   MGT_LCL_CONNOPT_DQOS_RSRCID
};

PUBLIC CmAbnfElmDef mgMsgDefDqosRsrcIdStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NCS: RsrcIdStr", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 214,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefDqosRsrcIdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefDqosRsvDestStrEnum =
{
   (Data *)"dq-rd:",
   MGT_LCL_CONNOPT_DQOS_RSVDEST
};

PUBLIC CmAbnfElmDef mgMsgDefDqosRsvDestStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NCS: RsvDestStr", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 215,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefDqosRsvDestStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefSecSecretStrEnum =
{
   (Data *)"sc-st:",
   MGT_LCL_CONNOPT_SEC_SECRET
};

PUBLIC CmAbnfElmDef mgMsgDefSecSecretStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SecSecretStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 216,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSecSecretStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefSecRtpSuiteStrEnum =
{
   (Data *)"sc-rtp:",
   MGT_LCL_CONNOPT_SEC_RTPSUITE
};

PUBLIC CmAbnfElmDef mgMsgDefSecRtpSuiteStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RtpSuiteStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 217,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSecRtpSuiteStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefSecRtcpSuiteStrEnum =
{
   (Data *)"sc-rtcp:",
   MGT_LCL_CONNOPT_SEC_RTCPSUITE
};

PUBLIC CmAbnfElmDef mgMsgDefSecRtcpSuiteStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RtcpSuiteStr", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 218,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSecRtcpSuiteStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefSuppModesStrEnum =
{
   (Data *)"m:",
   MGT_LCL_CONNOPT_SUPP_MODES
};

PUBLIC CmAbnfElmDef mgMsgDefSuppModesStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SUPMD_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 219,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSuppModesStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefTONStrEnum =
{
   (Data *)"nt:",
   MGT_LCL_CONNOPT_TYPE_OF_NET
};

PUBLIC CmAbnfElmDef mgMsgDefTONStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: TON_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 220,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefTONStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefEncryptInfoStrEnum =
{
   (Data *)"k:",
   MGT_LCL_CONNOPT_ENCRYPT_INFO
};

PUBLIC CmAbnfElmDef mgMsgDefEncryptInfoStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ENCRPTINFO_STR ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 221,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEncryptInfoStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefRsRsvStrEnum =
{
   (Data *)"r:",
   MGT_LCL_CONNOPT_RSRC_RESV
};

PUBLIC CmAbnfElmDef mgMsgDefRsRsvStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSRSV_STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 222,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefRsRsvStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefTOSStrEnum =
{
   (Data *)"t:",
   MGT_LCL_CONNOPT_TYPE_SRVC
};

PUBLIC CmAbnfElmDef mgMsgDefTOSStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: TOS_STR ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 223,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefTOSStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefSilSuppStrEnum =
{
   (Data *)"s:",
   MGT_LCL_CONNOPT_SIL_SUPP
};

PUBLIC CmAbnfElmDef mgMsgDefSilSuppStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SILSUP_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 224,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSilSuppStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefGainCtrlStrEnum =
{
   (Data *)"gc:",
   MGT_LCL_CONNOPT_GAIN_CTRL
};

PUBLIC CmAbnfElmDef mgMsgDefGainCtrlStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: GCTRL_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 225,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefGainCtrlStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefECancelStrEnum =
{
   (Data *)"e:",
   MGT_LCL_CONNOPT_ECHO_CAN
};

PUBLIC CmAbnfElmDef mgMsgDefECancelStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ECHCL_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 226,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefECancelStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefBwStrEnum =
{
   (Data *)"b:",
   MGT_LCL_CONNOPT_BW
};

PUBLIC CmAbnfElmDef mgMsgDefBwStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: BW_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 227,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefBwStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefAlgoStrEnum =
{
   (Data *)"a:",
   MGT_LCL_CONNOPT_ALGO_NAME
};

PUBLIC CmAbnfElmDef mgMsgDefAlgoStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ALOGNM_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 228,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefAlgoStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefPktzPeriodStrEnum =
{
   (Data *)"p:",
   MGT_LCL_CONNOPT_PKTZ_PERIOD
};

PUBLIC CmAbnfElmDef mgMsgDefPktzPeriodStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PTKTZ_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 229,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefPktzPeriodStrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefConnOptValChcEnum[] =
{
   &mgMsgDefNonStdConnOptValStr,                /*  0 */
   &mgMsgDefPktzPeriodStr,                      /*  1 */
   &mgMsgDefBwStr,                              /*  2 */
   &mgMsgDefAlgoStr,                            /*  3 */
   &mgMsgDefECancelStr,                         /*  4 */
   &mgMsgDefSilSuppStr,                         /*  5 */
   &mgMsgDefGainCtrlStr,                        /*  6 */
   &mgMsgDefTOSStr,                             /*  7 */
   &mgMsgDefRsRsvStr,                           /*  8 */
   &mgMsgDefTONStr,                             /*  9 */
   &mgMsgDefEncryptInfoStr,                     /* 10 */
   &mgMsgDefSuppModesStr,                       /* 11 */
   &mgMsgDefSuppPkgsStr,                        /* 12 */
   &mgMsgDefDqosGateIdStr,                      /* 13 */
   &mgMsgDefDqosRsrcRsvStr,                     /* 14 */
   &mgMsgDefDqosRsrcIdStr,                      /* 15 */
   &mgMsgDefDqosRsvDestStr,                     /* 16 */
   &mgMsgDefSecSecretStr,                       /* 17 */
   &mgMsgDefSecRtpSuiteStr,                     /* 18 */
   &mgMsgDefSecRtcpSuiteStr,                    /* 19 */
#ifdef GCP_VER_1_3
   &mgMsgDefOptFmtpSetStr ,                  /* 20 */
   &mgMsgDefFmtpSetStr ,                     /* 21 */
   &mgMsgDefRsResDirStr ,                    /* 22 */
   &mgMsgDefRsResCnfStr ,                    /* 23 */
   &mgMsgDefRsResShStr ,                     /* 24 */
#endif
};

EXTERN CmAbnfElmDef mgMsgDefDqosResourceId;

PUBLIC CmAbnfElmDef *mgMsgDefConnOptValChcElmnt[] =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefStdConnOptVal,                      /*  0 */
#else
   &mgMsgDefNonStdConnOptVal,                   /*  0 */
#endif
   &mgMsgDefPktzPeriod,                         /*  1 */
   &mgMsgDefBw,                                 /*  2 */
   &mgMsgDefAlgoNameSet,                        /*  3 */
   &mgMsgDefOnOff,                              /*  4 */
   &mgMsgDefOnOff,                              /*  5 */
   &mgMsgDefGainCtrl,                           /*  6 */

/* change */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefMarkedTOS,                          /*  7 */
#else
   &mgMsgDefTOS,                                /*  7 */
#endif

   &mgMsgDefRsRsv,                              /*  8 */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefChoiceTON ,
#else
   &mgMsgDefTON,                                /*  9 */
#endif
   &mgMsgDefEncryptInfo,                        /* 10 */
   &mgMsgDefSuppModes,                          /* 11 */
   &mgMsgDefSuppPkgs,                           /* 12 */
   &mgMsgDefDqosResourceId,    /* Gate ID */    /* 13 */
   &mgMsgDefDqosRsrcRsv,                        /* 14 */
   &mgMsgDefDqosResourceId,                     /* 15 */
   &mgMsgDefDqosRsvDest,                        /* 16 */
   &mgMsgDefSecSecret,                          /* 17 */
   &mgMsgDefSecRtpRtcpSuite,                    /* 18 */
   &mgMsgDefSecRtpRtcpSuite,                    /* 19 */
#ifdef GCP_VER_1_3
   &mgMsgDefLclFmtp ,                           /* 20 */
   &mgMsgDefLclFmtp ,                           /* 21 */
   &mgMsgDefLclRsRsvDir ,                       /* 22 */
   &mgMsgDefLclRsRsvCnf ,                       /* 23 */
   &mgMsgDefLclRsSh ,                           /* 24 */

#endif
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefConnOptValChc =
{
#ifdef GCP_VER_1_3
   25,
#else
   20,
#endif
   0,
   NULLP,
   mgMsgDefConnOptValChcElmnt,
   mgMsgDefConnOptValChcEnum
};

PUBLIC CmAbnfElmDef mgMsgDefConnOptVal = 
{
#ifdef CM_ABNF_DBG
   "MGCP: LCCONVAL", 
   "R29",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 230,
   sizeof(MgLclConnOpts),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefConnOptValChc,
   mgMsgRegExpR29
};

PUBLIC CmAbnfElmDef *mgMsgDefConnOptSeqElmnt[] =
{
   &mgMsgDefConnOptVal,
   &cmMsgDefOptMetaSpace
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefConnOptSeq =
{
   2,
   mgMsgDefConnOptSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefConnOpt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: LCCONPT", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 231,
   sizeof(MgLclConnOpts),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefConnOptSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefConnOptsSeOfElmnt[] =
{
   &cmMsgDefMetaComma,
   &cmMsgDefOptMetaSpace,
   &mgMsgDefConnOpt
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefConnOptsSeqOf =
{
   1, 
   MGT_MAX_LCL_CONNOPTS,
   3,
   mgMsgDefConnOptsSeOfElmnt,
   sizeof(MgLclConnOpts)   
};

PUBLIC CmAbnfElmDef mgMsgDefConnOpts = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CONNOPTS", 
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 232,
   sizeof(MgLclConnOptSet),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefConnOptsSeqOf,
   cmAbnfRegExpComma
};


PUBLIC CmAbnfElmDef *mgMsgDefConnOptsParamSeqOfElmnt[] =
{
   &mgMsgDefConnOpt,
   &mgMsgDefConnOpts
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefConnOptsParamSeqOf =
{
   2,
   mgMsgDefConnOptsParamSeqOfElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefConnOptsParam = 
{
#ifdef CM_ABNF_DBG
   "MGCP: LCCON", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 233,
   sizeof(MgLclConnOptSet),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefConnOptsParamSeqOf,
   NULLP
};

/************************************************************************
         Database element for Event Name (Signal Req/ Request Event) 
************************************************************************/

/* Known events/signals */

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymMtStrEnum =
{
   (Data *)"mt",
   MGT_MGCP_PKG_SYM_MODEM_DET

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymMtStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: mt enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 234,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymMtStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymFtStrEnum =
{
   (Data *)"ft",
   MGT_MGCP_PKG_SYM_FAX_DET

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymFtStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ft enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 235,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymFtStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymLdStrEnum =
{
   (Data *)"ld",
   MGT_MGCP_PKG_SYM_LONG_DUR_DET

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymLdStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ld enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 236,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymLdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymPatStrEnum =
{
   (Data *)"pat",
   MGT_MGCP_PKG_SYM_PAT

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymPatStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: pat enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 237,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymPatStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymRtStrEnum =
{
   (Data *)"rt",
   MGT_MGCP_PKG_SYM_RINGBACK_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymRtStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: rt enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 238,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymRtStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymRbkStrEnum =
{
   (Data *)"rbk",
   MGT_MGCP_PKG_SYM_RINGBACK

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymRbkStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: rbk enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 239,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymRbkStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymCfStrEnum =
{
   (Data *)"cf",
   MGT_MGCP_PKG_SYM_CONFIRM_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymCfStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: cf enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 240,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymCfStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymCgStrEnum =
{
   (Data *)"cg",
   MGT_MGCP_PKG_SYM_NETWORK_CONGESTION_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymCgStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: cg enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 241,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymCgStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymItStrEnum =
{
   (Data *)"it",
   MGT_MGCP_PKG_SYM_INTERCEPT_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymItStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: it enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 242,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymItStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymPtStrEnum =
{
   (Data *)"pt",
   MGT_MGCP_PKG_SYM_PREEMPT_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymPtStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: pt enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 243,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymPtStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymOfStrEnum =
{
   (Data *)"of",
   MGT_MGCP_PKG_SYM_REPORT_FAIL

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymOfStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: of enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 244,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymOfStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymXStrEnum =
{
   (Data *)"x",
   MGT_MGCP_PKG_SYM_X

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymXStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: x enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 245,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymXStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymTStrEnum =
{
   (Data *)"t",
   MGT_MGCP_PKG_SYM_T

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymTStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: t enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 246,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymTStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymAStrEnum =
{
   (Data *)"a",
   MGT_MGCP_PKG_SYM_DTMF_A

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymAStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: a enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 247,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymAStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymBStrEnum =
{
   (Data *)"b",
   MGT_MGCP_PKG_SYM_DTMF_B

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymBStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: b enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 248,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymBStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymCStrEnum =
{
   (Data *)"c",
   MGT_MGCP_PKG_SYM_DTMF_C

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymCStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: c enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 249,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymCStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymDStrEnum =
{
   (Data *)"d",
   MGT_MGCP_PKG_SYM_DTMF_D

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymDStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: d enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 250,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymDStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymHashStrEnum =
{
   (Data *)"#",
   MGT_MGCP_PKG_SYM_DTMF_OCTOTHORPE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymHashStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: hash enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 251,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymHashStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymStarStrEnum =
{
   (Data *)"*",
   MGT_MGCP_PKG_SYM_DTMF_STAR

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymStarStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: star enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 252,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymStarStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymLStrEnum =
{
   (Data *)"l",
   MGT_MGCP_PKG_SYM_DTMF_L

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymLStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: l enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 253,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymLStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymK0StrEnum =
{
   (Data *)"k0",
   MGT_MGCP_PKG_SYM_MF_K0KP

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymK0Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: k0 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 254,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymK0StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymK1StrEnum =
{
   (Data *)"k1",
   MGT_MGCP_PKG_SYM_MF_K1

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymK1Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: k1 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 255,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymK1StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymK2StrEnum =
{
   (Data *)"k2",
   MGT_MGCP_PKG_SYM_MF_K2

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymK2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: k2 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 256,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymK2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymS0StrEnum =
{
   (Data *)"s0",
   MGT_MGCP_PKG_SYM_MF_S0ST

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymS0Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: s0 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 257,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymS0StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymS1StrEnum =
{
   (Data *)"s1",
   MGT_MGCP_PKG_SYM_MF_S1

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymS1Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: s1 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 258,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymS1StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymS2StrEnum =
{
   (Data *)"s2",
   MGT_MGCP_PKG_SYM_MF_S2

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymS2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: s2 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 259,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymS2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymS3StrEnum =
{
   (Data *)"s3",
   MGT_MGCP_PKG_SYM_MF_S3

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymS3Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: s3 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 260,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymS3StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymWkStrEnum =
{
   (Data *)"wk",
   MGT_MGCP_PKG_SYM_MF_WINK

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymWkStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: wk enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 261,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymWkStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymWkoStrEnum =
{
   (Data *)"wko",
   MGT_MGCP_PKG_SYM_MF_WINK_OFF

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymWkoStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: wko enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 262,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymWkoStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymIsStrEnum =
{
   (Data *)"is",
   MGT_MGCP_PKG_SYM_MF_IN_SEIZURE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymIsStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: is enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 263,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymIsStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymRsStrEnum =
{
   (Data *)"rs",
   MGT_MGCP_PKG_SYM_MF_RS_OR_LINE_RS

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymRsStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: rs enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 264,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymRsStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymUsStrEnum =
{
   (Data *)"us",
   MGT_MGCP_PKG_SYM_MF_UNSEIZURE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymUsStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: us enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 265,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymUsStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymCo1StrEnum =
{
   (Data *)"co1",
   MGT_MGCP_PKG_SYM_TRUNK_CO1

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymCo1Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: co1 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 266,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymCo1StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymCo2StrEnum =
{
   (Data *)"co2",
   MGT_MGCP_PKG_SYM_TRUNK_CO2

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymCo2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: co2 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 267,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymCo2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymLbStrEnum =
{
   (Data *)"lb",
   MGT_MGCP_PKG_SYM_TRUNK_LPBK

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymLbStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: lb enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 268,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymLbStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymOmStrEnum =
{
   (Data *)"om",
   MGT_MGCP_PKG_SYM_TRUNK_OLD_MW_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymOmStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: om enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 269,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymOmStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymNmStrEnum =
{
   (Data *)"nm",
   MGT_MGCP_PKG_SYM_TRUNK_NEW_MW_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymNmStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: nm enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 270,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymNmStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymTlStrEnum =
{
   (Data *)"tl",
   MGT_MGCP_PKG_SYM_TRUNK_TEST_LINE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymTlStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: tl enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 271,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymTlStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymZzStrEnum =
{
   (Data *)"zz",
   MGT_MGCP_PKG_SYM_TRUNK_ZZ

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymZzStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: zz enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 272,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymZzStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymAsStrEnum =
{
   (Data *)"as",
   MGT_MGCP_PKG_SYM_TRUNK_ANS_SUPER

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymAsStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: as enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 273,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymAsStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymRoStrEnum =
{
   (Data *)"ro",
   MGT_MGCP_PKG_SYM_REORDER_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymRoStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ro enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 274,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymRoStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymBlStrEnum =
{
   (Data *)"bl",
   MGT_MGCP_PKG_SYM_TRUNK_BLOCKING

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymBlStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: bl enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 275,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymBlStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymQaStrEnum =
{
   (Data *)"qa",
   MGT_MGCP_PKG_SYM_RTP_QA

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymQaStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: qa enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 276,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymQaStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymUcStrEnum =
{
   (Data *)"uc",
   MGT_MGCP_PKG_SYM_RTP_UC

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymUcStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: uc enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 277,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymUcStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymSrStrEnum =
{
   (Data *)"sr",
   MGT_MGCP_PKG_SYM_RTP_SR

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymSrStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: sr enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 278,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymSrStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymJiStrEnum =
{
   (Data *)"ji",
   MGT_MGCP_PKG_SYM_RTP_JI

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymJiStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ji enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 279,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymJiStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymPlStrEnum =
{
   (Data *)"pl",
   MGT_MGCP_PKG_SYM_RTP_PL

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymPlStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: pl enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 280,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymPlStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSym0StrEnum =
{
   (Data *)"0",
   MGT_MGCP_PKG_SYM_0

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSym0Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: 0 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 281,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSym0StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSym1StrEnum =
{
   (Data *)"1",
   MGT_MGCP_PKG_SYM_1

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSym1Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: 1 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 282,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSym1StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSym2StrEnum =
{
   (Data *)"2",
   MGT_MGCP_PKG_SYM_2

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSym2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: 2 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 283,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSym2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSym3StrEnum =
{
   (Data *)"3",
   MGT_MGCP_PKG_SYM_3

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSym3Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: 3 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 284,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSym3StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSym4StrEnum =
{
   (Data *)"4",
   MGT_MGCP_PKG_SYM_4

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSym4Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: 4 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 285,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSym4StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSym5StrEnum =
{
   (Data *)"5",
   MGT_MGCP_PKG_SYM_5

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSym5Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: 5 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 286,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSym5StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSym6StrEnum =
{
   (Data *)"6",
   MGT_MGCP_PKG_SYM_6

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSym6Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: 6 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 287,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSym6StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSym7StrEnum =
{
   (Data *)"7",
   MGT_MGCP_PKG_SYM_7

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSym7Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: 7 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 288,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSym7StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSym8StrEnum =
{
   (Data *)"8",
   MGT_MGCP_PKG_SYM_8

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSym8Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: 8 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 289,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSym8StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSym9StrEnum =
{
   (Data *)"9",
   MGT_MGCP_PKG_SYM_9

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSym9Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: 9 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 290,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSym9StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymAdsiStrEnum =
{
   (Data *)"adsi",
   MGT_MGCP_PKG_SYM_LINE_ADSI

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymAdsiStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: adsi enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 291,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymAdsiStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymVmwiStrEnum =
{
   (Data *)"vmwi",
   MGT_MGCP_PKG_SYM_LINE_VMWI

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymVmwiStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: vmwi enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 292,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymVmwiStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymHdStrEnum =
{
   (Data *)"hd",
   MGT_MGCP_PKG_SYM_LINE_OFFHOOK

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymHdStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: hd enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 293,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymHdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymHuStrEnum =
{
   (Data *)"hu",
   MGT_MGCP_PKG_SYM_LINE_ONHOOK

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymHuStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: hu enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 294,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymHuStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymHfStrEnum =
{
   (Data *)"hf",
   MGT_MGCP_PKG_SYM_LINE_FLASHHOOK

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymHfStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: hf enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 295,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymHfStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymAwStrEnum =
{
   (Data *)"aw",
   MGT_MGCP_PKG_SYM_LINE_ANSWER_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymAwStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: aw enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 296,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymAwStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymBzStrEnum =
{
   (Data *)"bz",
   MGT_MGCP_PKG_SYM_LINE_BUSY_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymBzStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: bz enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 297,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymBzStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymCiStrEnum =
{
   (Data *)"ci",
   MGT_MGCP_PKG_SYM_LINE_CALLER_ID

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymCiStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ci enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 298,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymCiStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymWtStrEnum =
{
   (Data *)"wt",
   MGT_MGCP_PKG_SYM_LINE_CALL_WAITING_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymWtStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: wt enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 299,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymWtStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymWt1StrEnum =
{
   (Data *)"wt1",
   MGT_MGCP_PKG_SYM_LINE_CALL_WAITING_TONE1

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymWt1Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: wt1 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 300,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymWt1StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymWt2StrEnum =
{
   (Data *)"wt2",
   MGT_MGCP_PKG_SYM_LINE_CALL_WAITING_TONE2

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymWt2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: wt2 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 301,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymWt2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymWt3StrEnum =
{
   (Data *)"wt3",
   MGT_MGCP_PKG_SYM_LINE_CALL_WAITING_TONE3

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymWt3Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: wt3 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 302,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymWt3StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymWt4StrEnum =
{
   (Data *)"wt4",
   MGT_MGCP_PKG_SYM_LINE_CALL_WAITING_TONE4

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymWt4Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: wt4 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 303,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymWt4StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymDlStrEnum =
{
   (Data *)"dl",
   MGT_MGCP_PKG_SYM_LINE_DIAL_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymDlStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: dl enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 304,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymDlStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymMwiStrEnum =
{
   (Data *)"mwi",
   MGT_MGCP_PKG_SYM_LINE_MWI

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymMwiStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: mwi enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 305,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymMwiStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymNbzStrEnum =
{
   (Data *)"nbz",
   MGT_MGCP_PKG_SYM_LINE_NETWORK_BUSY_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymNbzStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: nbz enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 306,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymNbzStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymRgStrEnum =
{
   (Data *)"rg",
   MGT_MGCP_PKG_SYM_LINE_RING

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymRgStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: rg enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 307,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymRgStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymR0StrEnum =
{
   (Data *)"r0",
   MGT_MGCP_PKG_SYM_LINE_RING0

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymR0Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: r0 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 308,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymR0StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymR1StrEnum =
{
   (Data *)"r1",
   MGT_MGCP_PKG_SYM_LINE_RING1

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymR1Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: r1 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 309,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymR1StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymR2StrEnum =
{
   (Data *)"r2",
   MGT_MGCP_PKG_SYM_LINE_RING2

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymR2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: r2 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 310,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymR2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymR3StrEnum =
{
   (Data *)"r3",
   MGT_MGCP_PKG_SYM_LINE_RING3

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymR3Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: r3 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 311,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymR3StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymR4StrEnum =
{
   (Data *)"r4",
   MGT_MGCP_PKG_SYM_LINE_RING4

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymR4Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: r4 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 312,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymR4StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymR5StrEnum =
{
   (Data *)"r5",
   MGT_MGCP_PKG_SYM_LINE_RING5

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymR5Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: r5 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 313,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymR5StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymR6StrEnum =
{
   (Data *)"r6",
   MGT_MGCP_PKG_SYM_LINE_RING6

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymR6Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: r6 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 314,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymR6StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymR7StrEnum =
{
   (Data *)"r7",
   MGT_MGCP_PKG_SYM_LINE_RING7

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymR7Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: r7 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 315,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymR7StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymMaStrEnum =
{
   (Data *)"ma",
   MGT_MGCP_PKG_SYM_LINE_MEDIA_START

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymMaStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: r7 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 316,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymMaStrEnum,
   NULLP
};
PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymPStrEnum =
{
   (Data *)"p",
   MGT_MGCP_PKG_SYM_LINE_PROMPT_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymPStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: p enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 317,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymPStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymEStrEnum =
{
   (Data *)"e",
   MGT_MGCP_PKG_SYM_LINE_ERROR_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymEStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: e enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 318,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymEStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymSlStrEnum =
{
   (Data *)"sl",
   MGT_MGCP_PKG_SYM_LINE_STUTTER_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymSlStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: sl enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 319,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymSlStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymVStrEnum =
{
   (Data *)"v",
   MGT_MGCP_PKG_SYM_LINE_ALERT_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymVStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: v enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 320,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymVStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefEvntKnownSymYStrEnum =
{
   (Data *)"y",
   MGT_MGCP_PKG_SYM_LINE_REORDER_WARN_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymYStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: y enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 321,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEvntKnownSymYStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymSitStrEnum =
{
   (Data *)"sit",
   MGT_MGCP_PKG_SYM_LINE_SIT_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymSitStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: sit enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 322,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymSitStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymZStrEnum =
{
   (Data *)"z",
   MGT_MGCP_PKG_SYM_LINE_Z_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymZStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: z enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 323,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymZStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymOcStrEnum =
{
   (Data *)"oc",
   MGT_MGCP_PKG_SYM_REPORT_COMPLETION

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymOcStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: oc enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 324,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymOcStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymOtStrEnum =
{
   (Data *)"ot",
   MGT_MGCP_PKG_SYM_LINE_OFFHOOK_WARN_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymOtStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ot enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 325,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymOtStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymSStrEnum =
{
   (Data *)"s",
   MGT_MGCP_PKG_SYM_LINE_TONE_PATTERN

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymSStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: s enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 326,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymSStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymTddStrEnum =
{
   (Data *)"tdd",
   MGT_MGCP_PKG_SYM_TDD

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymTddStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: tdd enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 327,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymTddStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymPaStrEnum =
{
   (Data *)"pa",
   MGT_MGCP_PKG_SYM_NAS_PACKET_ARRIVAL

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymPaStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: pa enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 328,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymPaStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymCbkStrEnum =
{
   (Data *)"cbk",
   MGT_MGCP_PKG_SYM_NAS_CALLBACK_REQUEST

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymCbkStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: cbk enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 329,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymCbkStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymClStrEnum =
{
   (Data *)"cl",
   MGT_MGCP_PKG_SYM_NAS_CARRIER_LOST

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymClStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: cl enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 330,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymClStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymAuStrEnum =
{
   (Data *)"au",
   MGT_MGCP_PKG_SYM_NAS_AUTH_SUCCESS

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymAuStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: au enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 331,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymAuStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymAxStrEnum =
{
   (Data *)"ax",
   MGT_MGCP_PKG_SYM_NAS_AUTH_DENIED

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymAxStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ax enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 332,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymAxStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymAnnStrEnum =
{
   (Data *)"ann",
   MGT_MGCP_PKG_SYM_ANN_ANN

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymAnnStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ann enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 333,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymAnnStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymJavaStrEnum =
{
   (Data *)"java",
   MGT_MGCP_PKG_SYM_SCRIPT_JAVA

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymJavaStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: java enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 334,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymJavaStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymPerlStrEnum =
{
   (Data *)"perl",
   MGT_MGCP_PKG_SYM_SCRIPT_PERL

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymPerlStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: perl enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 335,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymPerlStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymTclStrEnum =
{
   (Data *)"tcl",
   MGT_MGCP_PKG_SYM_SCRIPT_TCL

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymTclStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: tcl enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 336,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymTclStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymXmlStrEnum =
{
   (Data *)"xml",
   MGT_MGCP_PKG_SYM_SCRIPT_XML

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymXmlStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: xml enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 337,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymXmlStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymAnsStrEnum =
{
   (Data *)"ans",
   MGT_MGCP_PKG_SYM_MF_CALL_ANSWER

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymAnsStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ans enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 338,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymAnsStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymOrbkStrEnum =
{
   (Data *)"orbk",
   MGT_MGCP_PKG_SYM_MF_OPER_RINGBACK

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymOrbkStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: orbk enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 339,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymOrbkStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymRbzStrEnum =
{
   (Data *)"rbz",
   MGT_MGCP_PKG_SYM_MF_REV_BUSY

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymRbzStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: rbz enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 340,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymRbzStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymRclStrEnum =
{
   (Data *)"rcl",
   MGT_MGCP_PKG_SYM_MF_OPER_RECALL

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymRclStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: rcl enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 341,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymRclStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymRelStrEnum =
{
   (Data *)"rel",
   MGT_MGCP_PKG_SYM_MF_RELEASE_CALL

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymRelStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: rel enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 342,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymRelStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymResStrEnum =
{
   (Data *)"res",
   MGT_MGCP_PKG_SYM_MF_RESUME_CALL

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymResStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: res enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 343,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymResStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymRlcStrEnum =
{
   (Data *)"rlc",
   MGT_MGCP_PKG_SYM_MF_RELEASE_COMPLETE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymRlcStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: rlc enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 344,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymRlcStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymSupStrEnum =
{
   (Data *)"sup",
   MGT_MGCP_PKG_SYM_MF_CALL_SETUP

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymSupStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: sup enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 345,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymSupStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymSusStrEnum =
{
   (Data *)"sus",
   MGT_MGCP_PKG_SYM_MF_SUSPEND_CALL

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymSusStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: sus enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 346,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymSusStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymPstStrEnum =
{
   (Data *)"pst",
   MGT_MGCP_PKG_SYM_MF_PERM_SIGNAL_TONE

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymPstStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: pst enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 347,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymPstStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymOiStrEnum =
{
   (Data *)"oi",
   MGT_MGCP_PKG_SYM_MF_OPER_INTR

};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymOiStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: oi enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 348,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymOiStrEnum,
   NULLP
};



#ifdef GCP_VER_1_3

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymscStrEnum =
{
   (Data *)"sc",
   MGT_MGCP_PKG_SYM_BRR_PATH_SETUP1
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymscStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: sc enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 888,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymscStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymsfStrEnum =
{
   (Data *)"sf",
   MGT_MGCP_PKG_SYM_BRR_PATH_SETUP2
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymsfStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: sf enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 889,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymsfStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymptimeStrEnum =
{
   (Data *)"ptime",
   MGT_MGCP_PKG_SYM_PCKTZN_PERIOD
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymptimeStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ptime enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 890,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymptimeStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSympftransStrEnum =
{
   (Data *)"pftrans",
   MGT_MGCP_PKG_SYM_PROF_ELMNT
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSympftransStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: pftrans enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 891,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSympftransStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymcleStrEnum =
{
   (Data *)"cle",
   MGT_MGCP_PKG_SYM_CELL_LOSS
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymcleStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: cle enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 892,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymcleStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymecStrEnum =
{
   (Data *)"ec",
   MGT_MGCP_PKG_SYM_ENABLE_C_A_S
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymecStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ec enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 893,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymecStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymetdStrEnum =
{
   (Data *)"etd",
   MGT_MGCP_PKG_SYM_ENABLE_D_T_M_F_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymetdStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: etd enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 894,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymetdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymetmStrEnum =
{
   (Data *)"etm",
   MGT_MGCP_PKG_SYM_ENABLE_M_F_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymetmStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: etm enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 895,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymetmStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymetr1StrEnum =
{
   (Data *)"etr1",
   MGT_MGCP_PKG_SYM_ENABLE_M_F_R1_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymetr1Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: etr1 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 896,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymetr1StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymetr2StrEnum =
{
   (Data *)"etr2",
   MGT_MGCP_PKG_SYM_ENABLE_M_F_R2_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymetr2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: etr2 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 897,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymetr2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymacStrEnum =
{
   (Data *)"ac",
   MGT_MGCP_PKG_SYM_ACCEPTANCE_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymacStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ac enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 898,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymacStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymbz2StrEnum =
{
   (Data *)"bz2",
   MGT_MGCP_PKG_SYM_OTHER_BUSY_TONES2
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymbz2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: bz2 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 899,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymbz2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymbz3StrEnum =
{
   (Data *)"bz3",
   MGT_MGCP_PKG_SYM_OTHER_BUSY_TONES3
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymbz3Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: bz3 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 900,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymbz3StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymcf2StrEnum =
{
   (Data *)"cf2",
   MGT_MGCP_PKG_SYM_CNFRMN_TONE_I_I
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymcf2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: cf2 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 901,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymcf2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymcg2StrEnum =
{
   (Data *)"cg2",
   MGT_MGCP_PKG_SYM_OTHER_CONGES_TONES2
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymcg2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: cg2 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 902,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymcg2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymcg3StrEnum =
{
   (Data *)"cg3",
   MGT_MGCP_PKG_SYM_OTHER_CONGES_TONES3
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymcg3Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: cg3 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 903,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymcg3StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymdl2StrEnum =
{
   (Data *)"dl2",
   MGT_MGCP_PKG_SYM_OTHER_DIAL_TONES2
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymdl2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: dl2 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 904,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymdl2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymdl3StrEnum =
{
   (Data *)"dl3",
   MGT_MGCP_PKG_SYM_OTHER_DIAL_TONES3
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymdl3Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: dl3 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 905,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymdl3StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymsd1StrEnum =
{
   (Data *)"sd1",
   MGT_MGCP_PKG_SYM_SECOND_DIAL_TONES1
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymsd1Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: sd1 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 906,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymsd1StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymsd2StrEnum =
{
   (Data *)"sd2",
   MGT_MGCP_PKG_SYM_SECOND_DIAL_TONES2
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymsd2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: sd2 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 907,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymsd2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymsd3StrEnum =
{
   (Data *)"sd3",
   MGT_MGCP_PKG_SYM_SECOND_DIAL_TONES3
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymsd3Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: sd3 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 908,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymsd3StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymeoStrEnum =
{
   (Data *)"eo",
   MGT_MGCP_PKG_SYM_EXEC_OVER_RIDE_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymeoStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: eo enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 909,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymeoStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymesStrEnum =
{
   (Data *)"es",
   MGT_MGCP_PKG_SYM_END_OF3_PARTY_SERV
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymesStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: es enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 910,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymesStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfcStrEnum =
{
   (Data *)"fc",
   MGT_MGCP_PKG_SYM_FACILITIES_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfcStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: fc enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 911,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfcStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymllStrEnum =
{
   (Data *)"ll",
   MGT_MGCP_PKG_SYM_LINE_LOCKOUT
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymllStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ll enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 912,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymllStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymnu2StrEnum =
{
   (Data *)"nu2",
   MGT_MGCP_PKG_SYM_NUM_UNOBTAINABLE_I_I
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymnu2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: nu2 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 913,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymnu2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymorStrEnum =
{
   (Data *)"or",
   MGT_MGCP_PKG_SYM_OFFERING_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymorStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: or enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 914,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymorStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSympr2StrEnum =
{
   (Data *)"pr2",
   MGT_MGCP_PKG_SYM_PAYPHONE_RECOG2
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSympr2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: pr2 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 915,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSympr2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSympr3StrEnum =
{
   (Data *)"pr3",
   MGT_MGCP_PKG_SYM_PAYPHONE_RECOG3
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSympr3Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: pr3 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 916,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSympr3StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSympr4StrEnum =
{
   (Data *)"pr4",
   MGT_MGCP_PKG_SYM_PAYPHONE_RECOG4
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSympr4Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: pr4 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 917,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSympr4StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymquStrEnum =
{
   (Data *)"qu",
   MGT_MGCP_PKG_SYM_QUEUE_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymquStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: qu enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 918,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymquStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymrfStrEnum =
{
   (Data *)"rf",
   MGT_MGCP_PKG_SYM_REFUSAL_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymrfStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: rf enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 919,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymrfStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymru1StrEnum =
{
   (Data *)"ru1",
   MGT_MGCP_PKG_SYM_ROUTE_TONE1
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymru1Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: ru1 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 920,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymru1StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymru2StrEnum =
{
   (Data *)"ru2",
   MGT_MGCP_PKG_SYM_ROUTE_TONE2
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymru2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: ru2 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 921,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymru2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymrt2StrEnum =
{
   (Data *)"rt2",
   MGT_MGCP_PKG_SYM_RINGING_TONE2
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymrt2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: rt2 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 922,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymrt2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymrt3StrEnum =
{
   (Data *)"rt3",
   MGT_MGCP_PKG_SYM_RINGING_TONE3
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymrt3Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: rt3 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 923,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymrt3StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymrt4StrEnum =
{
   (Data *)"rt4",
   MGT_MGCP_PKG_SYM_RINGING_TONE4
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymrt4Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: rt4 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 924,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymrt4StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymsaStrEnum =
{
   (Data *)"sa",
   MGT_MGCP_PKG_SYM_SRVC_ACTIVTD_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymsaStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: sa enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 925,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymsaStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymvaStrEnum =
{
   (Data *)"va",
   MGT_MGCP_PKG_SYM_VALID_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymvaStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: va enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 926,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymvaStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymwa1StrEnum =
{
   (Data *)"wa1",
   MGT_MGCP_PKG_SYM_WAITING_TONE1
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymwa1Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: wa1 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 927,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymwa1StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymwa2StrEnum =
{
   (Data *)"wa2",
   MGT_MGCP_PKG_SYM_WAITING_TONE2
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymwa2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: wa2 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 928,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymwa2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymwa3StrEnum =
{
   (Data *)"wa3",
   MGT_MGCP_PKG_SYM_WAITING_TONE3
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymwa3Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: wa3 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 929,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymwa3StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymweStrEnum =
{
   (Data *)"we",
   MGT_MGCP_PKG_SYM_WARNING_END_OR_PERIOD
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymweStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: we enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 930,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymweStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymwpStrEnum =
{
   (Data *)"wp",
   MGT_MGCP_PKG_SYM_WARNING_P_I_P_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymwpStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: wp enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 931,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymwpStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymwr1StrEnum =
{
   (Data *)"wr1",
   MGT_MGCP_PKG_SYM_WARNING_TONE_OPER1
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymwr1Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: wr1 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 932,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymwr1StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymwr2StrEnum =
{
   (Data *)"wr2",
   MGT_MGCP_PKG_SYM_WARNING_TONE_OPER2
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymwr2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: wr2 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 933,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymwr2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymDDStrEnum =
{
   (Data *)"DD",
   MGT_MGCP_PKG_SYM_DTMF_TONE_DUR
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymDDStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: DD enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 934,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymDDStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymDOStrEnum =
{
   (Data *)"DO",
   MGT_MGCP_PKG_SYM_DTMF_OO_SIG
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymDOStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: DO enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 935,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymDOStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymgwfaxStrEnum =
{
   (Data *)"gwfax",
   MGT_MGCP_PKG_SYM_GW_CNTRLD_FAX
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymgwfaxStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: gwfax enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 936,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymgwfaxStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymnopfaxStrEnum =
{
   (Data *)"nopfax",
   MGT_MGCP_PKG_SYM_NO_SP_FAX_HNDLNG
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymnopfaxStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: nopfax enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 937,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymnopfaxStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymt38StrEnum =
{
   (Data *)"t38",
   MGT_MGCP_PKG_SYM_T38_FAX_RELAY
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymt38Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: t38 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 938,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymt38StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymhtStrEnum =
{
   (Data *)"ht",
   MGT_MGCP_PKG_SYM_TONE_ON_HOLD
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymhtStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ht enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 939,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymhtStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymyStrEnum =
{
   (Data *)"y",
   MGT_MGCP_PKG_SYM_RECORDER_WARNING_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymyStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: y enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 940,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymyStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymlsaStrEnum =
{
   (Data *)"lsa",
   MGT_MGCP_PKG_SYM_LINE_SIDE_ANSWER_SUP
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymlsaStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: lsa enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 941,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymlsaStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymosiStrEnum =
{
   (Data *)"osi",
   MGT_MGCP_PKG_SYM_NETWORK_DIS_CONN
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymosiStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: osi enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 942,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymosiStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymrgpStrEnum =
{
   (Data *)"rgp",
   MGT_MGCP_PKG_SYM_PRECEDENCE_RINGING
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymrgpStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: rgp enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 943,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymrgpStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymrtpStrEnum =
{
   (Data *)"rtp",
   MGT_MGCP_PKG_SYM_PRECEDENCE_RINGBACK
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymrtpStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: rtp enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 944,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymrtpStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymirStrEnum =
{
   (Data *)"ir",
   MGT_MGCP_PKG_SYM_INTERMEDIATE_RES
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymirStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ir enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 945,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymirStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymawkStrEnum =
{
   (Data *)"awk",
   MGT_MGCP_PKG_SYM_ACK_WINK
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymawkStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: awk enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 946,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymawkStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSyminfStrEnum =
{
   (Data *)"inf",
   MGT_MGCP_PKG_SYM_INFO_DGTS
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSyminfStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: inf enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 947,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSyminfStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymswkStrEnum =
{
   (Data *)"swk",
   MGT_MGCP_PKG_SYM_START_WINK
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymswkStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: swk enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 948,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymswkStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymcwkStrEnum =
{
   (Data *)"cwk",
   MGT_MGCP_PKG_SYM_CONTINUE_WINK
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymcwkStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: cwk enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 949,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymcwkStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymrqStrEnum =
{
   (Data *)"rq",
   MGT_MGCP_PKG_SYM_OUT_CALL_REQ
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymrqStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: rq enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 950,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymrqStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymcrqStrEnum =
{
   (Data *)"crq",
   MGT_MGCP_PKG_SYM_CALL_REQ
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymcrqStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: crq enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 951,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymcrqStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymiuStrEnum =
{
   (Data *)"iu",
   MGT_MGCP_PKG_SYM_ICMP_UNREACHABLE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymiuStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: iu enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 952,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymiuStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymrtoStrEnum =
{
   (Data *)"rto",
   MGT_MGCP_PKG_SYM_RTP_OR_RTCP_TIMEOUT
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymrtoStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: rto enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 953,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymrtoStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymrlStrEnum =
{
   (Data *)"rl",
   MGT_MGCP_PKG_SYM_RESOURCE_LOST
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymrlStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: rl enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 954,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymrlStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymvxmlStrEnum =
{
   (Data *)"vxml",
   MGT_MGCP_PKG_SYM_LOAD_AND_RUN_V_X_M_L_DOC
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymvxmlStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: vxml enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 955,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymvxmlStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymcdStrEnum =
{
   (Data *)"cd",
   MGT_MGCP_PKG_SYM_CONFERENCE_DEPART
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymcdStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: cd enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 956,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymcdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymcjStrEnum =
{
   (Data *)"cj",
   MGT_MGCP_PKG_SYM_CONFERENCE_JOIN
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymcjStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: cj enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 957,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymcjStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymcmStrEnum =
{
   (Data *)"cm",
   MGT_MGCP_PKG_SYM_COMFORT_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymcmStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: cm enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 958,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymcmStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymcwStrEnum =
{
   (Data *)"cw",
   MGT_MGCP_PKG_SYM_CALLER_WAITING_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymcwStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: cw enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 959,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymcwStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymniStrEnum =
{
   (Data *)"ni",
   MGT_MGCP_PKG_SYM_NEGATIVE_IND
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymniStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ni enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 960,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymniStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymprStrEnum =
{
   (Data *)"pr",
   MGT_MGCP_PKG_SYM_PAYPHONE_RECOG
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymprStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: pr enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 961,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymprStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymmmStrEnum =
{
   (Data *)"mm",
   MGT_MGCP_PKG_SYM_NEWEST_MILLIWATT_TONE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymmmStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: mm enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 962,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymmmStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymtpStrEnum =
{
   (Data *)"tp",
   MGT_MGCP_PKG_SYM_TEST_PATTERN
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymtpStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: tp enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 963,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymtpStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymqtStrEnum =
{
   (Data *)"qt",
   MGT_MGCP_PKG_SYM_QUIET_TERMINATION
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymqtStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: qt enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 964,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymqtStrEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymtiStrEnum =
{
   (Data *)"ti",
   MGT_MGCP_PKG_SYM_LINE_CALLER_ID1
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymtiStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ti enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 964,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymtiStrEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymnuStrEnum =
{
   (Data *)"nu",
   MGT_MGCP_PKG_SYM_LINE_CALLER_ID2
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymnuStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: nu enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 964,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymnuStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymnaStrEnum =
{
   (Data *)"na",
   MGT_MGCP_PKG_SYM_LINE_CALLER_ID3
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymnaStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: na enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 964,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymnaStrEnum,
   NULLP
};

/* 
 * [TEL]: Added Code for new Events/signals
 */
PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk1StrEnum =
{
   (Data *)"fk1",
   MGT_MGCP_PKG_SYM_FEATURE_KEY1
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk1Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk1 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2194,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk1StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk2StrEnum =
{
   (Data *)"fk2",
   MGT_MGCP_PKG_SYM_FEATURE_KEY2
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk2Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk2 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2195,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk2StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk3StrEnum =
{
   (Data *)"fk3",
   MGT_MGCP_PKG_SYM_FEATURE_KEY3
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk3Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk3 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2196,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk3StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk4StrEnum =
{
   (Data *)"fk4",
   MGT_MGCP_PKG_SYM_FEATURE_KEY4
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk4Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk4 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2197,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk4StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk5StrEnum =
{
   (Data *)"fk5",
   MGT_MGCP_PKG_SYM_FEATURE_KEY5
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk5Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk5 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2198,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk5StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk6StrEnum =
{
   (Data *)"fk6",
   MGT_MGCP_PKG_SYM_FEATURE_KEY6
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk6Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk6 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2199,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk6StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk7StrEnum =
{
   (Data *)"fk7",
   MGT_MGCP_PKG_SYM_FEATURE_KEY7
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk7Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk7 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2200,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk7StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk8StrEnum =
{
   (Data *)"fk8",
   MGT_MGCP_PKG_SYM_FEATURE_KEY8
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk8Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk8 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2201,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk8StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk9StrEnum =
{
   (Data *)"fk9",
   MGT_MGCP_PKG_SYM_FEATURE_KEY9
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk9Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk9 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2202,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk9StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk10StrEnum =
{
   (Data *)"fk10",
   MGT_MGCP_PKG_SYM_FEATURE_KEY10
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk10Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk10 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2203,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk10StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk11StrEnum =
{
   (Data *)"fk11",
   MGT_MGCP_PKG_SYM_FEATURE_KEY11
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk11Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk11 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2204,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk11StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk12StrEnum =
{
   (Data *)"fk12",
   MGT_MGCP_PKG_SYM_FEATURE_KEY12
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk12Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk12 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2205,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk12StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk13StrEnum =
{
   (Data *)"fk13",
   MGT_MGCP_PKG_SYM_FEATURE_KEY13
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk13Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk13 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2206,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk13StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk14StrEnum =
{
   (Data *)"fk14",
   MGT_MGCP_PKG_SYM_FEATURE_KEY14
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk14Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk14 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2207,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk14StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk15StrEnum =
{
   (Data *)"fk15",
   MGT_MGCP_PKG_SYM_FEATURE_KEY15
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk15Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk15 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2208,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk15StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk16StrEnum =
{
   (Data *)"fk16",
   MGT_MGCP_PKG_SYM_FEATURE_KEY16
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk16Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk16 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2209,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk16StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk17StrEnum =
{
   (Data *)"fk17",
   MGT_MGCP_PKG_SYM_FEATURE_KEY17
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk17Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk17 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2210,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk17StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk18StrEnum =
{
   (Data *)"fk18",
   MGT_MGCP_PKG_SYM_FEATURE_KEY18
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk18Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk18 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2211,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk18StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk19StrEnum =
{
   (Data *)"fk19",
   MGT_MGCP_PKG_SYM_FEATURE_KEY19
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk19Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk19 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2212,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk19StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk20StrEnum =
{
   (Data *)"fk20",
   MGT_MGCP_PKG_SYM_FEATURE_KEY20
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk20Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk20 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2213,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk20StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk21StrEnum =
{
   (Data *)"fk21",
   MGT_MGCP_PKG_SYM_FEATURE_KEY21
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk21Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk21 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2214,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk21StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk22StrEnum =
{
   (Data *)"fk22",
   MGT_MGCP_PKG_SYM_FEATURE_KEY22
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk22Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk22 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2215,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk22StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk23StrEnum =
{
   (Data *)"fk23",
   MGT_MGCP_PKG_SYM_FEATURE_KEY23
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk23Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk23 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2216,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk23StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk24StrEnum =
{
   (Data *)"fk24",
   MGT_MGCP_PKG_SYM_FEATURE_KEY24
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk24Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk24 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2217,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk24StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk25StrEnum =
{
   (Data *)"fk25",
   MGT_MGCP_PKG_SYM_FEATURE_KEY25
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk25Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk25 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2218,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk25StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk26StrEnum =
{
   (Data *)"fk26",
   MGT_MGCP_PKG_SYM_FEATURE_KEY26
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk26Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk26 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2219,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk26StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk27StrEnum =
{
   (Data *)"fk27",
   MGT_MGCP_PKG_SYM_FEATURE_KEY27
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk27Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk27 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2220,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk27StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk28StrEnum =
{
   (Data *)"fk28",
   MGT_MGCP_PKG_SYM_FEATURE_KEY28
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk28Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk28 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2221,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk28StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk29StrEnum =
{
   (Data *)"fk29",
   MGT_MGCP_PKG_SYM_FEATURE_KEY29
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk29Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk29 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2222,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk29StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk30StrEnum =
{
   (Data *)"fk30",
   MGT_MGCP_PKG_SYM_FEATURE_KEY30
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk30Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk30 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2223,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk30StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk31StrEnum =
{
   (Data *)"fk31",
   MGT_MGCP_PKG_SYM_FEATURE_KEY31
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk31Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk31 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2224,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk31StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk32StrEnum =
{
   (Data *)"fk32",
   MGT_MGCP_PKG_SYM_FEATURE_KEY32
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk32Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk32 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2225,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk32StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk33StrEnum =
{
   (Data *)"fk33",
   MGT_MGCP_PKG_SYM_FEATURE_KEY33
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk33Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk33 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2226,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk33StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk34StrEnum =
{
   (Data *)"fk34",
   MGT_MGCP_PKG_SYM_FEATURE_KEY34
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk34Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk34 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2227,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk34StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk35StrEnum =
{
   (Data *)"fk35",
   MGT_MGCP_PKG_SYM_FEATURE_KEY35
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk35Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk35 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2228,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk35StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk36StrEnum =
{
   (Data *)"fk36",
   MGT_MGCP_PKG_SYM_FEATURE_KEY36
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk36Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk36 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2229,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk36StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk37StrEnum =
{
   (Data *)"fk37",
   MGT_MGCP_PKG_SYM_FEATURE_KEY37
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk37Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk37 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2230,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk37StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk38StrEnum =
{
   (Data *)"fk38",
   MGT_MGCP_PKG_SYM_FEATURE_KEY38
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk38Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk38 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2231,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk38StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk39StrEnum =
{
   (Data *)"fk39",
   MGT_MGCP_PKG_SYM_FEATURE_KEY39
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk39Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk39 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2232,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk39StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk40StrEnum =
{
   (Data *)"fk40",
   MGT_MGCP_PKG_SYM_FEATURE_KEY40
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk40Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk40 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2233,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk40StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk41StrEnum =
{
   (Data *)"fk41",
   MGT_MGCP_PKG_SYM_FEATURE_KEY41
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk41Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk41 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2234,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk41StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk42StrEnum =
{
   (Data *)"fk42",
   MGT_MGCP_PKG_SYM_FEATURE_KEY42
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk42Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk42 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2235,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk42StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk43StrEnum =
{
   (Data *)"fk43",
   MGT_MGCP_PKG_SYM_FEATURE_KEY43
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk43Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk43 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2236,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk43StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk44StrEnum =
{
   (Data *)"fk44",
   MGT_MGCP_PKG_SYM_FEATURE_KEY44
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk44Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk44 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2237,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk44StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk45StrEnum =
{
   (Data *)"fk45",
   MGT_MGCP_PKG_SYM_FEATURE_KEY45
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk45Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk45 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2238,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk45StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk46StrEnum =
{
   (Data *)"fk46",
   MGT_MGCP_PKG_SYM_FEATURE_KEY46
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk46Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk46 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2239,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk46StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk47StrEnum =
{
   (Data *)"fk47",
   MGT_MGCP_PKG_SYM_FEATURE_KEY47
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk47Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk47 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2240,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk47StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk48StrEnum =
{
   (Data *)"fk48",
   MGT_MGCP_PKG_SYM_FEATURE_KEY48
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk48Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk48 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2241,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk48StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk49StrEnum =
{
   (Data *)"fk49",
   MGT_MGCP_PKG_SYM_FEATURE_KEY49
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk49Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk49 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2242,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk49StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk50StrEnum =
{
   (Data *)"fk50",
   MGT_MGCP_PKG_SYM_FEATURE_KEY50
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk50Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk50 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2243,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk50StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk51StrEnum =
{
   (Data *)"fk51",
   MGT_MGCP_PKG_SYM_FEATURE_KEY51
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk51Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk51 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2244,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk51StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk52StrEnum =
{
   (Data *)"fk52",
   MGT_MGCP_PKG_SYM_FEATURE_KEY52
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk52Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk52 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2245,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk52StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk53StrEnum =
{
   (Data *)"fk53",
   MGT_MGCP_PKG_SYM_FEATURE_KEY53
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk53Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk53 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2246,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk53StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk54StrEnum =
{
   (Data *)"fk54",
   MGT_MGCP_PKG_SYM_FEATURE_KEY54
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk54Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk54 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2247,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk54StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk55StrEnum =
{
   (Data *)"fk55",
   MGT_MGCP_PKG_SYM_FEATURE_KEY55
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk55Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk55 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2248,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk55StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk56StrEnum =
{
   (Data *)"fk56",
   MGT_MGCP_PKG_SYM_FEATURE_KEY56
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk56Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk56 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2249,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk56StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk57StrEnum =
{
   (Data *)"fk57",
   MGT_MGCP_PKG_SYM_FEATURE_KEY57
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk57Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk57 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2250,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk57StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk58StrEnum =
{
   (Data *)"fk58",
   MGT_MGCP_PKG_SYM_FEATURE_KEY58
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk58Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk58 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2251,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk58StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk59StrEnum =
{
   (Data *)"fk59",
   MGT_MGCP_PKG_SYM_FEATURE_KEY59
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk59Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk59 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2252,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk59StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk60StrEnum =
{
   (Data *)"fk60",
   MGT_MGCP_PKG_SYM_FEATURE_KEY60
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk60Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk60 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2253,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk60StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk61StrEnum =
{
   (Data *)"fk61",
   MGT_MGCP_PKG_SYM_FEATURE_KEY61
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk61Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk61 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2254,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk61StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk62StrEnum =
{
   (Data *)"fk62",
   MGT_MGCP_PKG_SYM_FEATURE_KEY62
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk62Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk62 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2255,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk62StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk63StrEnum =
{
   (Data *)"fk63",
   MGT_MGCP_PKG_SYM_FEATURE_KEY63
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk63Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk63 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2256,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk63StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk64StrEnum =
{
   (Data *)"fk64",
   MGT_MGCP_PKG_SYM_FEATURE_KEY64
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk64Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk64 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2257,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk64StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk65StrEnum =
{
   (Data *)"fk65",
   MGT_MGCP_PKG_SYM_FEATURE_KEY65
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk65Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk65 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2258,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk65StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk66StrEnum =
{
   (Data *)"fk66",
   MGT_MGCP_PKG_SYM_FEATURE_KEY66
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk66Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk66 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2259,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk66StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk67StrEnum =
{
   (Data *)"fk67",
   MGT_MGCP_PKG_SYM_FEATURE_KEY67
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk67Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk67 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2260,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk67StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk68StrEnum =
{
   (Data *)"fk68",
   MGT_MGCP_PKG_SYM_FEATURE_KEY68
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk68Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk68 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2261,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk68StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk69StrEnum =
{
   (Data *)"fk69",
   MGT_MGCP_PKG_SYM_FEATURE_KEY69
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk69Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk69 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2262,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk69StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk70StrEnum =
{
   (Data *)"fk70",
   MGT_MGCP_PKG_SYM_FEATURE_KEY70
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk70Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk70 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2263,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk70StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk71StrEnum =
{
   (Data *)"fk71",
   MGT_MGCP_PKG_SYM_FEATURE_KEY71
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk71Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk71 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2264,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk71StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk72StrEnum =
{
   (Data *)"fk72",
   MGT_MGCP_PKG_SYM_FEATURE_KEY72
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk72Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk72 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2265,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk72StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk73StrEnum =
{
   (Data *)"fk73",
   MGT_MGCP_PKG_SYM_FEATURE_KEY73
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk73Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk73 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2266,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk73StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk74StrEnum =
{
   (Data *)"fk74",
   MGT_MGCP_PKG_SYM_FEATURE_KEY74
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk74Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk74 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2267,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk74StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk75StrEnum =
{
   (Data *)"fk75",
   MGT_MGCP_PKG_SYM_FEATURE_KEY75
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk75Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk75 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2268,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk75StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk76StrEnum =
{
   (Data *)"fk76",
   MGT_MGCP_PKG_SYM_FEATURE_KEY76
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk76Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk76 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2269,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk76StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk77StrEnum =
{
   (Data *)"fk77",
   MGT_MGCP_PKG_SYM_FEATURE_KEY77
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk77Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk77 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2270,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk77StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk78StrEnum =
{
   (Data *)"fk78",
   MGT_MGCP_PKG_SYM_FEATURE_KEY78
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk78Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk78 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2271,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk78StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk79StrEnum =
{
   (Data *)"fk79",
   MGT_MGCP_PKG_SYM_FEATURE_KEY79
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk79Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk79 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2272,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk79StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk80StrEnum =
{
   (Data *)"fk80",
   MGT_MGCP_PKG_SYM_FEATURE_KEY80
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk80Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk80 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2273,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk80StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk81StrEnum =
{
   (Data *)"fk81",
   MGT_MGCP_PKG_SYM_FEATURE_KEY81
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk81Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk81 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2274,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk81StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk82StrEnum =
{
   (Data *)"fk82",
   MGT_MGCP_PKG_SYM_FEATURE_KEY82
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk82Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk82 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2275,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk82StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk83StrEnum =
{
   (Data *)"fk83",
   MGT_MGCP_PKG_SYM_FEATURE_KEY83
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk83Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk83 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2276,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk83StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk84StrEnum =
{
   (Data *)"fk84",
   MGT_MGCP_PKG_SYM_FEATURE_KEY84
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk84Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk84 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2277,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk84StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk85StrEnum =
{
   (Data *)"fk85",
   MGT_MGCP_PKG_SYM_FEATURE_KEY85
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk85Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk85 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2278,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk85StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk86StrEnum =
{
   (Data *)"fk86",
   MGT_MGCP_PKG_SYM_FEATURE_KEY86
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk86Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk86 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2279,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk86StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk87StrEnum =
{
   (Data *)"fk87",
   MGT_MGCP_PKG_SYM_FEATURE_KEY87
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk87Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk87 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2280,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk87StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk88StrEnum =
{
   (Data *)"fk88",
   MGT_MGCP_PKG_SYM_FEATURE_KEY88
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk88Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk88 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2281,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk88StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk89StrEnum =
{
   (Data *)"fk89",
   MGT_MGCP_PKG_SYM_FEATURE_KEY89
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk89Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk89 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2282,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk89StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk90StrEnum =
{
   (Data *)"fk90",
   MGT_MGCP_PKG_SYM_FEATURE_KEY90
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk90Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk90 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2283,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk90StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk91StrEnum =
{
   (Data *)"fk91",
   MGT_MGCP_PKG_SYM_FEATURE_KEY91
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk91Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk91 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2284,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk91StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk92StrEnum =
{
   (Data *)"fk92",
   MGT_MGCP_PKG_SYM_FEATURE_KEY92
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk92Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk92 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2285,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk92StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk93StrEnum =
{
   (Data *)"fk93",
   MGT_MGCP_PKG_SYM_FEATURE_KEY93
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk93Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk93 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2286,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk93StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk94StrEnum =
{
   (Data *)"fk94",
   MGT_MGCP_PKG_SYM_FEATURE_KEY94
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk94Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk94 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2287,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk94StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk95StrEnum =
{
   (Data *)"fk95",
   MGT_MGCP_PKG_SYM_FEATURE_KEY95
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk95Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk95 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2288,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk95StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk96StrEnum =
{
   (Data *)"fk96",
   MGT_MGCP_PKG_SYM_FEATURE_KEY96
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk96Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk96 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2289,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk96StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk97StrEnum =
{
   (Data *)"fk97",
   MGT_MGCP_PKG_SYM_FEATURE_KEY97
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk97Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk97 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2290,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk97StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk98StrEnum =
{
   (Data *)"fk98",
   MGT_MGCP_PKG_SYM_FEATURE_KEY98
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk98Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk98 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2291,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk98StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymfk99StrEnum =
{
   (Data *)"fk99",
   MGT_MGCP_PKG_SYM_FEATURE_KEY99
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymfk99Str =
{
#ifdef CM_ABNF_DBG
   "MGCP: fk99 enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2292,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymfk99StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymksStrEnum =
{
   (Data *)"ks",
   MGT_MGCP_PKG_SYM_KEY_STATE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymksStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ks enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2293,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymksStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymlsStrEnum =
{
   (Data *)"ls",
   MGT_MGCP_PKG_SYM_SET_LABEL
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymlsStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ls enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2294,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymlsStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymbeepStrEnum =
{
   (Data *)"beep",
   MGT_MGCP_PKG_SYM_BEEP
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymbeepStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: beep enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2295,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymbeepStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymenfStrEnum =
{
   (Data *)"enf",
   MGT_MGCP_PKG_SYM_EM_RQNT_FAIL
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymenfStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: enf enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2796,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymenfStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymoefStrEnum =
{
   (Data *)"oef",
   MGT_MGCP_PKG_SYM_OBS_EVTS_FUL
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymoefStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: oef enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2797,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymoefStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymqboStrEnum =
{
   (Data *)"qbo",
   MGT_MGCP_PKG_SYM_QRTIN_BUF_OF
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymqboStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: qbo enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 2798,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymqboStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymctStrEnum =
{
   (Data *)"ct",
   MGT_MGCP_PKG_SYM_CONTINUITY_TRSPDR
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymctStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: ct enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 10208,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymctStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeU16Enum mgMsgDefEvntKnownSymreStrEnum =
{
   (Data *)"re",
   MGT_MGCP_PKG_SYM_RESOURCE_ERROR
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownSymreStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: re enum",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 10209,
   sizeof(TknU16),
   0,
   CM_ABNF_TYPE_ENUM_U16,
   (U8 *)&mgMsgDefEvntKnownSymreStrEnum,
   NULLP
};

#endif /* GCP_VER_1_3 */



/* End of Known events/signals */

PUBLIC CmAbnfElmDef *mgMsgDefEvntKnownChcEnum[] =
{
   NULLP,
   &mgMsgDefEvntKnownSymMtStr,      /*    1 */
   &mgMsgDefEvntKnownSymFtStr,      /*    2 */
   &mgMsgDefEvntKnownSymLdStr,      /*    3 */
   &mgMsgDefEvntKnownSymPatStr,     /*    4 */
   &mgMsgDefEvntKnownSymRtStr,      /*    5 */
   &mgMsgDefEvntKnownSymRbkStr,     /*    6 */
   &mgMsgDefEvntKnownSymCfStr,      /*    7 */
   &mgMsgDefEvntKnownSymCgStr,      /*    8 */
   &mgMsgDefEvntKnownSymItStr,      /*    9 */
   &mgMsgDefEvntKnownSymPtStr,      /*   10 */
   &mgMsgDefEvntKnownSymOfStr,      /*   11 */
   &mgMsgDefEvntKnownSymXStr,       /*   12 */
   &mgMsgDefEvntKnownSymTStr,       /*   13 */
   &mgMsgDefEvntKnownSymAStr,       /*   14 */
   &mgMsgDefEvntKnownSymBStr,       /*   15 */
   &mgMsgDefEvntKnownSymCStr,       /*   16 */
   &mgMsgDefEvntKnownSymDStr,       /*   17 */
   &mgMsgDefEvntKnownSymHashStr,    /*   18 */
   &mgMsgDefEvntKnownSymStarStr,    /*   19 */
   &mgMsgDefEvntKnownSymLStr,       /*   20 */
   &mgMsgDefEvntKnownSymK0Str,      /*   21 */
   &mgMsgDefEvntKnownSymK1Str,      /*   22 */
   &mgMsgDefEvntKnownSymK2Str,      /*   23 */
   &mgMsgDefEvntKnownSymS0Str,      /*   24 */
   &mgMsgDefEvntKnownSymS1Str,      /*   25 */
   &mgMsgDefEvntKnownSymS2Str,      /*   26 */
   &mgMsgDefEvntKnownSymS3Str,      /*   27 */
   &mgMsgDefEvntKnownSymWkStr,      /*   28 */
   &mgMsgDefEvntKnownSymWkoStr,     /*   29 */
   &mgMsgDefEvntKnownSymIsStr,      /*   30 */
   &mgMsgDefEvntKnownSymRsStr,      /*   31 */
   &mgMsgDefEvntKnownSymUsStr,      /*   32 */
   &mgMsgDefEvntKnownSymCo1Str,     /*   33 */
   &mgMsgDefEvntKnownSymCo2Str,     /*   34 */
   &mgMsgDefEvntKnownSymLbStr,      /*   35 */
   &mgMsgDefEvntKnownSymOmStr,      /*   36 */
   &mgMsgDefEvntKnownSymNmStr,      /*   37 */
   &mgMsgDefEvntKnownSymTlStr,      /*   38 */
   &mgMsgDefEvntKnownSymZzStr,      /*   39 */
   &mgMsgDefEvntKnownSymAsStr,      /*   40 */
   &mgMsgDefEvntKnownSymRoStr,      /*   41 */
   &mgMsgDefEvntKnownSymBlStr,      /*   42 */
   &mgMsgDefEvntKnownSymQaStr,      /*   43 */
   &mgMsgDefEvntKnownSymUcStr,      /*   44 */
   &mgMsgDefEvntKnownSymSrStr,      /*   45 */
   &mgMsgDefEvntKnownSymJiStr,      /*   46 */
   &mgMsgDefEvntKnownSymPlStr,      /*   47 */
   &mgMsgDefEvntKnownSym0Str,       /*   48 */
   &mgMsgDefEvntKnownSym1Str,       /*   49 */
   &mgMsgDefEvntKnownSym2Str,       /*   50 */
   &mgMsgDefEvntKnownSym3Str,       /*   51 */
   &mgMsgDefEvntKnownSym4Str,       /*   52 */
   &mgMsgDefEvntKnownSym5Str,       /*   53 */
   &mgMsgDefEvntKnownSym6Str,       /*   54 */
   &mgMsgDefEvntKnownSym7Str,       /*   55 */
   &mgMsgDefEvntKnownSym8Str,       /*   56 */
   &mgMsgDefEvntKnownSym9Str,       /*   57 */
   &mgMsgDefEvntKnownSymAdsiStr,    /*   58 */
   &mgMsgDefEvntKnownSymVmwiStr,    /*   59 */
   &mgMsgDefEvntKnownSymHdStr,      /*   60 */
   &mgMsgDefEvntKnownSymHuStr,      /*   61 */
   &mgMsgDefEvntKnownSymHfStr,      /*   62 */
   &mgMsgDefEvntKnownSymAwStr,      /*   63 */
   &mgMsgDefEvntKnownSymBzStr,      /*   64 */
   &mgMsgDefEvntKnownSymCiStr,      /*   65 */
   &mgMsgDefEvntKnownSymWtStr,      /*   66 */
   &mgMsgDefEvntKnownSymWt1Str,     /*   67 */
   &mgMsgDefEvntKnownSymWt2Str,     /*   68 */
   &mgMsgDefEvntKnownSymWt3Str,     /*   69 */
   &mgMsgDefEvntKnownSymWt4Str,     /*   70 */
   &mgMsgDefEvntKnownSymDlStr,      /*   71 */
   &mgMsgDefEvntKnownSymMwiStr,     /*   72 */
   &mgMsgDefEvntKnownSymNbzStr,     /*   73 */
   &mgMsgDefEvntKnownSymRgStr,      /*   74 */
   &mgMsgDefEvntKnownSymR0Str,      /*   75 */
   &mgMsgDefEvntKnownSymR1Str,      /*   76 */
   &mgMsgDefEvntKnownSymR2Str,      /*   77 */
   &mgMsgDefEvntKnownSymR3Str,      /*   78 */
   &mgMsgDefEvntKnownSymR4Str,      /*   79 */
   &mgMsgDefEvntKnownSymR5Str,      /*   80 */
   &mgMsgDefEvntKnownSymR6Str,      /*   81 */
   &mgMsgDefEvntKnownSymR7Str,      /*   82 */
   &mgMsgDefEvntKnownSymMaStr,      /*   83 */ 
   &mgMsgDefEvntKnownSymPStr,       /*   84 */
   &mgMsgDefEvntKnownSymEStr,       /*   85 */
   &mgMsgDefEvntKnownSymSlStr,      /*   86 */
   &mgMsgDefEvntKnownSymVStr,       /*   87 */
   &mgMsgDefEvntKnownSymYStr,       /*   88 */
   &mgMsgDefEvntKnownSymSitStr,     /*   89 */
   &mgMsgDefEvntKnownSymZStr,       /*   90 */
   &mgMsgDefEvntKnownSymOcStr,      /*   91 */
   &mgMsgDefEvntKnownSymOtStr,      /*   92 */
   &mgMsgDefEvntKnownSymSStr,       /*   93 */
   &mgMsgDefEvntKnownSymTddStr,     /*   94 */
   &mgMsgDefEvntKnownSymPaStr,      /*   95 */
   &mgMsgDefEvntKnownSymCbkStr,     /*   96 */
   &mgMsgDefEvntKnownSymClStr,      /*   97 */
   &mgMsgDefEvntKnownSymAuStr,      /*   98 */
   &mgMsgDefEvntKnownSymAxStr,      /*   99 */
   &mgMsgDefEvntKnownSymAnnStr,     /*  100 */
   &mgMsgDefEvntKnownSymJavaStr,    /*  101 */
   &mgMsgDefEvntKnownSymPerlStr,    /*  102 */
   &mgMsgDefEvntKnownSymTclStr,     /*  103 */
   &mgMsgDefEvntKnownSymXmlStr,     /*  104 */
   &mgMsgDefEvntKnownSymAnsStr,     /*  105 */
   &mgMsgDefEvntKnownSymOrbkStr,    /*  106 */
   &mgMsgDefEvntKnownSymRbzStr,     /*  107 */
   &mgMsgDefEvntKnownSymRclStr,     /*  108 */
   &mgMsgDefEvntKnownSymRelStr,     /*  109 */
   &mgMsgDefEvntKnownSymResStr,     /*  110 */
   &mgMsgDefEvntKnownSymRlcStr,     /*  111 */
   &mgMsgDefEvntKnownSymSupStr,     /*  112 */
   &mgMsgDefEvntKnownSymSusStr,     /*  113 */
   &mgMsgDefEvntKnownSymPstStr,     /*  114 */
   &mgMsgDefEvntKnownSymOiStr,      /*  115 */

#ifdef GCP_VER_1_3
   &mgMsgDefEvntKnownSymscStr,      /*  116 */
   &mgMsgDefEvntKnownSymsfStr,      /*  117 */
   &mgMsgDefEvntKnownSymptimeStr,   /*  118 */
   &mgMsgDefEvntKnownSympftransStr, /*  119 */
   &mgMsgDefEvntKnownSymcleStr,     /*  120 */
   &mgMsgDefEvntKnownSymecStr,      /*  121 */
   &mgMsgDefEvntKnownSymetdStr,     /*  122 */
   &mgMsgDefEvntKnownSymetmStr,     /*  123 */
   &mgMsgDefEvntKnownSymetr1Str,    /*  124 */
   &mgMsgDefEvntKnownSymetr2Str,    /*  125 */
   &mgMsgDefEvntKnownSymacStr,      /*  126 */
   &mgMsgDefEvntKnownSymbz2Str,     /*  127 */
   &mgMsgDefEvntKnownSymbz3Str,     /*  128 */
   &mgMsgDefEvntKnownSymcf2Str,     /*  129 */
   &mgMsgDefEvntKnownSymcg2Str,     /*  130 */
   &mgMsgDefEvntKnownSymcg3Str,     /*  131 */
   &mgMsgDefEvntKnownSymdl2Str,     /*  132 */
   &mgMsgDefEvntKnownSymdl3Str,     /*  133 */
   &mgMsgDefEvntKnownSymsd1Str,     /*  134 */
   &mgMsgDefEvntKnownSymsd2Str,     /*  135 */
   &mgMsgDefEvntKnownSymsd3Str,     /*  136 */
   &mgMsgDefEvntKnownSymeoStr,      /*  137 */
   &mgMsgDefEvntKnownSymesStr,      /*  138 */
   &mgMsgDefEvntKnownSymfcStr,      /*  139 */
   &mgMsgDefEvntKnownSymllStr,      /*  140 */
   &mgMsgDefEvntKnownSymnu2Str,     /*  141 */
   &mgMsgDefEvntKnownSymorStr,      /*  142 */
   &mgMsgDefEvntKnownSympr2Str,     /*  143 */
   &mgMsgDefEvntKnownSympr3Str,     /*  144 */
   &mgMsgDefEvntKnownSympr4Str,     /*  145 */
   &mgMsgDefEvntKnownSymquStr,      /*  146 */
   &mgMsgDefEvntKnownSymrfStr,      /*  147 */
   &mgMsgDefEvntKnownSymru1Str,     /*  148 */
   &mgMsgDefEvntKnownSymru2Str,     /*  149 */
   &mgMsgDefEvntKnownSymrt2Str,     /*  150 */
   &mgMsgDefEvntKnownSymrt3Str,     /*  151 */
   &mgMsgDefEvntKnownSymrt4Str,     /*  152 */
   &mgMsgDefEvntKnownSymsaStr,      /*  153 */
   &mgMsgDefEvntKnownSymvaStr,      /*  154 */
   &mgMsgDefEvntKnownSymwa1Str,     /*  155 */
   &mgMsgDefEvntKnownSymwa2Str,     /*  156 */
   &mgMsgDefEvntKnownSymwa3Str,     /*  157 */
   &mgMsgDefEvntKnownSymweStr,      /*  158 */
   &mgMsgDefEvntKnownSymwpStr,      /*  159 */
   &mgMsgDefEvntKnownSymwr1Str,     /*  160 */
   &mgMsgDefEvntKnownSymwr2Str,     /*  161 */
   &mgMsgDefEvntKnownSymDDStr,      /*  162 */
   &mgMsgDefEvntKnownSymDOStr,      /*  163 */
   &mgMsgDefEvntKnownSymgwfaxStr,   /*  164 */
   &mgMsgDefEvntKnownSymnopfaxStr,  /*  165 */
   &mgMsgDefEvntKnownSymt38Str,     /*  166 */
   &mgMsgDefEvntKnownSymhtStr,      /*  167 */
   &mgMsgDefEvntKnownSymyStr,       /*  168 */
   &mgMsgDefEvntKnownSymlsaStr,     /*  169 */
   &mgMsgDefEvntKnownSymosiStr,     /*  170 */
   &mgMsgDefEvntKnownSymrgpStr,     /*  171 */
   &mgMsgDefEvntKnownSymrtpStr,     /*  172 */
   &mgMsgDefEvntKnownSymirStr,      /*  173 */
   &mgMsgDefEvntKnownSymawkStr,     /*  174 */
   &mgMsgDefEvntKnownSyminfStr,     /*  175 */
   &mgMsgDefEvntKnownSymswkStr,     /*  176 */
   &mgMsgDefEvntKnownSymcwkStr,     /*  177 */
   &mgMsgDefEvntKnownSymrqStr,      /*  178 */
   &mgMsgDefEvntKnownSymcrqStr,     /*  179 */
   &mgMsgDefEvntKnownSymiuStr,      /*  180 */
   &mgMsgDefEvntKnownSymrtoStr,     /*  181 */
   &mgMsgDefEvntKnownSymrlStr,      /*  182 */
   &mgMsgDefEvntKnownSymvxmlStr,    /*  183 */
   &mgMsgDefEvntKnownSymcdStr,      /*  184 */
   &mgMsgDefEvntKnownSymcjStr,      /*  185 */
   &mgMsgDefEvntKnownSymcmStr,      /*  186 */
   &mgMsgDefEvntKnownSymcwStr,      /*  187 */
   &mgMsgDefEvntKnownSymniStr,      /*  188 */
   &mgMsgDefEvntKnownSymprStr,      /*  189 */
   &mgMsgDefEvntKnownSymmmStr,      /*  190 */
   &mgMsgDefEvntKnownSymtpStr,      /*  191 */
   &mgMsgDefEvntKnownSymqtStr,      /*  192 */

   &mgMsgDefEvntKnownSymtiStr,      /*  193 */
   &mgMsgDefEvntKnownSymnuStr,      /*  194 */
   &mgMsgDefEvntKnownSymnaStr,      /*  195 */

   /*
    * [TEL]: Added for new Events/Signals
    */
   &mgMsgDefEvntKnownSymfk1Str,     /*  196 */
   &mgMsgDefEvntKnownSymfk2Str,     /*  197 */
   &mgMsgDefEvntKnownSymfk3Str,     /*  198 */
   &mgMsgDefEvntKnownSymfk4Str,     /*  199 */
   &mgMsgDefEvntKnownSymfk5Str,     /*  200 */
   &mgMsgDefEvntKnownSymfk6Str,     /*  201 */
   &mgMsgDefEvntKnownSymfk7Str,     /*  202 */
   &mgMsgDefEvntKnownSymfk8Str,     /*  203 */
   &mgMsgDefEvntKnownSymfk9Str,     /*  204 */
   &mgMsgDefEvntKnownSymfk10Str,    /*  205 */
   &mgMsgDefEvntKnownSymfk11Str,    /*  206 */
   &mgMsgDefEvntKnownSymfk12Str,    /*  207 */
   &mgMsgDefEvntKnownSymfk13Str,    /*  208 */
   &mgMsgDefEvntKnownSymfk14Str,    /*  209 */
   &mgMsgDefEvntKnownSymfk15Str,    /*  210 */
   &mgMsgDefEvntKnownSymfk16Str,    /*  211 */
   &mgMsgDefEvntKnownSymfk17Str,    /*  212 */
   &mgMsgDefEvntKnownSymfk18Str,    /*  213 */
   &mgMsgDefEvntKnownSymfk19Str,    /*  214 */
   &mgMsgDefEvntKnownSymfk20Str,    /*  215 */
   &mgMsgDefEvntKnownSymfk21Str,    /*  216 */
   &mgMsgDefEvntKnownSymfk22Str,    /*  217 */
   &mgMsgDefEvntKnownSymfk23Str,    /*  218 */
   &mgMsgDefEvntKnownSymfk24Str,    /*  219 */
   &mgMsgDefEvntKnownSymfk25Str,    /*  220 */
   &mgMsgDefEvntKnownSymfk26Str,    /*  221 */
   &mgMsgDefEvntKnownSymfk27Str,    /*  222 */
   &mgMsgDefEvntKnownSymfk28Str,    /*  223 */
   &mgMsgDefEvntKnownSymfk29Str,    /*  224 */
   &mgMsgDefEvntKnownSymfk30Str,    /*  225 */
   &mgMsgDefEvntKnownSymfk31Str,    /*  226 */
   &mgMsgDefEvntKnownSymfk32Str,    /*  227 */
   &mgMsgDefEvntKnownSymfk33Str,    /*  228 */
   &mgMsgDefEvntKnownSymfk34Str,    /*  229 */
   &mgMsgDefEvntKnownSymfk35Str,    /*  230 */
   &mgMsgDefEvntKnownSymfk36Str,    /*  231 */
   &mgMsgDefEvntKnownSymfk37Str,    /*  232 */
   &mgMsgDefEvntKnownSymfk38Str,    /*  233 */
   &mgMsgDefEvntKnownSymfk39Str,    /*  234 */
   &mgMsgDefEvntKnownSymfk40Str,    /*  235 */
   &mgMsgDefEvntKnownSymfk41Str,    /*  236 */
   &mgMsgDefEvntKnownSymfk42Str,    /*  237 */
   &mgMsgDefEvntKnownSymfk43Str,    /*  238 */
   &mgMsgDefEvntKnownSymfk44Str,    /*  239 */
   &mgMsgDefEvntKnownSymfk45Str,    /*  240 */
   &mgMsgDefEvntKnownSymfk46Str,    /*  241 */
   &mgMsgDefEvntKnownSymfk47Str,    /*  242 */
   &mgMsgDefEvntKnownSymfk48Str,    /*  243 */
   &mgMsgDefEvntKnownSymfk49Str,    /*  244 */
   &mgMsgDefEvntKnownSymfk50Str,    /*  245 */
   &mgMsgDefEvntKnownSymfk51Str,    /*  246 */
   &mgMsgDefEvntKnownSymfk52Str,    /*  247 */
   &mgMsgDefEvntKnownSymfk53Str,    /*  248 */
   &mgMsgDefEvntKnownSymfk54Str,    /*  249 */
   &mgMsgDefEvntKnownSymfk55Str,    /*  250 */
   &mgMsgDefEvntKnownSymfk56Str,    /*  251 */
   &mgMsgDefEvntKnownSymfk57Str,    /*  252 */
   &mgMsgDefEvntKnownSymfk58Str,    /*  253 */
   &mgMsgDefEvntKnownSymfk59Str,    /*  254 */
   &mgMsgDefEvntKnownSymfk60Str,    /*  255 */
   &mgMsgDefEvntKnownSymfk61Str,    /*  256 */
   &mgMsgDefEvntKnownSymfk62Str,    /*  257 */
   &mgMsgDefEvntKnownSymfk63Str,    /*  258 */
   &mgMsgDefEvntKnownSymfk64Str,    /*  259 */
   &mgMsgDefEvntKnownSymfk65Str,    /*  260 */
   &mgMsgDefEvntKnownSymfk66Str,    /*  261 */
   &mgMsgDefEvntKnownSymfk67Str,    /*  262 */
   &mgMsgDefEvntKnownSymfk68Str,    /*  263 */
   &mgMsgDefEvntKnownSymfk69Str,    /*  264 */
   &mgMsgDefEvntKnownSymfk70Str,    /*  265 */
   &mgMsgDefEvntKnownSymfk71Str,    /*  266 */
   &mgMsgDefEvntKnownSymfk72Str,    /*  267 */
   &mgMsgDefEvntKnownSymfk73Str,    /*  268 */
   &mgMsgDefEvntKnownSymfk74Str,    /*  269 */
   &mgMsgDefEvntKnownSymfk75Str,    /*  270 */
   &mgMsgDefEvntKnownSymfk76Str,    /*  271 */
   &mgMsgDefEvntKnownSymfk77Str,    /*  272 */
   &mgMsgDefEvntKnownSymfk78Str,    /*  273 */
   &mgMsgDefEvntKnownSymfk79Str,    /*  274 */
   &mgMsgDefEvntKnownSymfk80Str,    /*  275 */
   &mgMsgDefEvntKnownSymfk81Str,    /*  276 */
   &mgMsgDefEvntKnownSymfk82Str,    /*  277 */
   &mgMsgDefEvntKnownSymfk83Str,    /*  278 */
   &mgMsgDefEvntKnownSymfk84Str,    /*  279 */
   &mgMsgDefEvntKnownSymfk85Str,    /*  280 */
   &mgMsgDefEvntKnownSymfk86Str,    /*  281 */
   &mgMsgDefEvntKnownSymfk87Str,    /*  282 */
   &mgMsgDefEvntKnownSymfk88Str,    /*  283 */
   &mgMsgDefEvntKnownSymfk89Str,    /*  284 */
   &mgMsgDefEvntKnownSymfk90Str,    /*  285 */
   &mgMsgDefEvntKnownSymfk91Str,    /*  286 */
   &mgMsgDefEvntKnownSymfk92Str,    /*  287 */
   &mgMsgDefEvntKnownSymfk93Str,    /*  288 */
   &mgMsgDefEvntKnownSymfk94Str,    /*  289 */
   &mgMsgDefEvntKnownSymfk95Str,    /*  290 */
   &mgMsgDefEvntKnownSymfk96Str,    /*  291 */
   &mgMsgDefEvntKnownSymfk97Str,    /*  292 */
   &mgMsgDefEvntKnownSymfk98Str,    /*  293 */
   &mgMsgDefEvntKnownSymfk99Str,    /*  294 */
   &mgMsgDefEvntKnownSymksStr,      /*  295 */
   &mgMsgDefEvntKnownSymlsStr,      /*  296 */
   &mgMsgDefEvntKnownSymbeepStr,    /*  297 */
   &mgMsgDefEvntKnownSymenfStr,     /*  298 */
   &mgMsgDefEvntKnownSymoefStr,     /*  299 */
   &mgMsgDefEvntKnownSymqboStr,     /*  300 */

   &mgMsgDefEvntKnownSymctStr,      /*  301 */
   &mgMsgDefEvntKnownSymreStr,      /*  302 */
#endif /* GCP_VER_1_3 */

};

PUBLIC CmAbnfElmTypeU16Choice mgMsgDefEvntKnownChc =
{
   MGT_MGCP_PKG_SYM_MAX,
   0,
   NULLP,
   NULLP,
   mgMsgDefEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnown =
{
#ifdef CM_ABNF_DBG        
   "MGCP: Known event name",
   "SymVal",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 349,
   sizeof(TknU16),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE_U16,
   (U8 *)&mgMsgDefEvntKnownChc,
   mgMsgRegExpSymVal
};

PUBLIC CmAbnfElmTypeRange mgMsgDefEvntEvntIdRng = {1,0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefEvntEvntId = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EVTID ", 
   "CM_RSUTBLCHAR",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 350,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefEvntEvntIdRng,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   mgMsgRegExpEventId
#else
   cmAbnfRegExpSutblChar
#endif
};

PUBLIC CmAbnfElmTypeRange mgMsgDefEvntAllRng = {3,3};

PUBLIC CmAbnfElmDef mgMsgDefEvntAll = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ALL", 
   "R27",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 351,
   sizeof(((MgEventDesc *)0)->t),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SKIP,
   (U8 *)&mgMsgDefEvntAllRng,
   mgMsgRegExpR27
};

#ifdef GCP_VER_1_3
PUBLIC CmAbnfElmTypeRange mgMsgDefEvntDtmfRng = {1,1};

PUBLIC CmAbnfElmDef mgMsgDefEvntDtmf = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DTMF * OR #", 
   "R27",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 352,
   sizeof(((MgEventDesc *)0)->t),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SKIP,
   (U8 *)&mgMsgDefEvntDtmfRng,
   mgMsgRegExpDtmf
};

#endif

PUBLIC CmAbnfElmTypeRange mgMsgDefEvntRng = {3, 0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefEvntRange = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EVTRNG ", 
   "R26",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 353,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefEvntRng,
   mgMsgRegExpR26
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefEvntRangeStrEnum =
{
   NULLP,
   MGT_DESC_EVENT_RANGE
};

PUBLIC CmAbnfElmDef mgMsgDefEvntRangeStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EVTRNG_STR ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 354,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEvntRangeStrEnum
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefEvntAllStrEnum =
{
   (Data *)"all",
   MGT_DESC_EVENT_ALL
};

PUBLIC CmAbnfElmDef mgMsgDefEvntAllStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ALL_ENUM ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 355,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEvntAllStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefEvntEvntIdStrEnum =
{
   NULLP,
   MGT_DESC_EVENT_ID
};

PUBLIC CmAbnfElmDef mgMsgDefEvntEvntIdStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EVTID_STR ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 356,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEvntEvntIdStrEnum,
   NULLP
};



#ifdef GCP_VER_1_3

PUBLIC CmAbnfElmTypeEnum mgMsgDefEvntDtmfPoundEnum =
{
   (Data *)"#",
   MGT_DESC_EVENT_DTMF_POUND
};

PUBLIC CmAbnfElmDef mgMsgDefEvntDtmfPoundStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DTMF_POUND_ENUM ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 357,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEvntDtmfPoundEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefEvntDtmfStarEnum =
{
   (Data *)"*",
   MGT_DESC_EVENT_DTMF_STAR
};

PUBLIC CmAbnfElmDef mgMsgDefEvntDtmfStarStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DTMF_STAR_ENUM ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 358,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEvntDtmfStarEnum,
   NULLP
};

#endif

PUBLIC CmAbnfElmTypeEnum mgMsgDefEvntKnownStrEnum =
{
   NULLP,
   MGT_DESC_EVENT_KNOWN
};

PUBLIC CmAbnfElmDef mgMsgDefEvntKnownStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EVTKNOWN_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 359,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEvntKnownStrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefEvntDescChcEnum[] =
{
   NULLP,
   &mgMsgDefEvntEvntIdStr,
   &mgMsgDefEvntAllStr,
   &mgMsgDefEvntRangeStr,
   &mgMsgDefEvntKnownStr,
#ifdef GCP_VER_1_3
   &mgMsgDefEvntDtmfStarStr,
   &mgMsgDefEvntDtmfPoundStr,
#endif
};

PUBLIC CmAbnfElmDef *mgMsgDefEvntDescChcElmnt[] =
{
   NULLP,
   &mgMsgDefEvntEvntId,
   &mgMsgDefEvntAll,
   &mgMsgDefEvntRange,
   &mgMsgDefEvntKnown
#ifdef GCP_VER_1_3
   , &mgMsgDefEvntDtmf ,
   &mgMsgDefEvntDtmf ,
#endif
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefEvntDescChc =
{
#ifdef GCP_VER_1_3
   7,
#else
   5,
#endif
   0,
   NULLP,
   mgMsgDefEvntDescChcElmnt,
   mgMsgDefEvntDescChcEnum
};

PUBLIC CmAbnfElmDef mgMsgDefEvntDesc = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EVTDESC ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 360,
   sizeof(MgEventDesc),   
   (CM_ABNF_TKN_NOT_CONSUMED|CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefEvntDescChc,
   mgMsgRegExpSymType
};

PUBLIC CmAbnfElmTypeRange mgMsgDefDesConnIdRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefDesConnId = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DESCONID ", 
   "R24",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 361,
   sizeof(TknStr32),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTR32,
   (U8 *)&mgMsgDefDesConnIdRng,
   mgMsgRegExpR24
};

PUBLIC CmAbnfElmDef *mgMsgDefEvntDesConnIdSeqElmnt[] =
{
   &cmMsgDefMetaAt,
   &mgMsgDefDesConnId
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefEvntDesConnIdSeq =
{
   2,
   mgMsgDefEvntDesConnIdSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefEvntDesConnId = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CONID ", 
   "CM_RATCHAR",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 362,
   sizeof(TknStr32),   
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefEvntDesConnIdSeq,
   cmAbnfRegExpAt
};


#ifdef GCP_VER_1_3


EXTERN  CmAbnfElmDef  mgMsgDefPkgUnknownEvntName;

/* PUBLIC CmAbnfElmDef *mgMsgDefPkgNameStringElmnts[] = */
PUBLIC CmAbnfElmDef *mgMsgDefSpcPkgTreeElmnts[] =
{        /* PUBLIC CmAbnfelmDef *mgMsgDefSpcPkgTreeElmnts */
   &mgMsgDefPkgUnknownEvntName
};

PUBLIC U8 mgMsgDefSpcPkgTreeIdx[] = {0, 
   1, 2
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefSpcPkgTreeChc=
{
   3,
   3,/*MGT_MGCP_PKG_MAX, */
   mgMsgDefSpcPkgTreeIdx,
   mgMsgDefSpcPkgTreeElmnts,
   NULLP
};

PUBLIC CmAbnfElmDef mgMsgDefSpcPkgTree =
{
#ifdef CM_ABNF_DBG
   "MGCP: Specific Package name",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 363,
   sizeof(MgPkgName)+ sizeof(MgEventDesc),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefSpcPkgTreeChc,
   mgMsgRegExpPackageName
};
#endif

PUBLIC CmAbnfElmDef *mgMsgDefPkgNameSeqElmnt[] =
{
   &mgMsgDefPkgNameString,
   &cmMsgDefMetaSlash
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefPkgNameSeq =
{
   2,
   mgMsgDefPkgNameSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefPkgName = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PKGNM ", 
   "R22",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 364,
   sizeof(MgPkgName),   
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefPkgNameSeq,
   mgMsgRegExpR22
};

PUBLIC CmAbnfElmDef *mgMsgDefEventNameSeqElmnt[] =
{
   &mgMsgDefPkgName,
#ifndef GCP_VER_1_3
   &mgMsgDefEvntDesc,
#endif
   &mgMsgDefEvntDesConnId
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefEventNameSeq =
{
#ifdef GCP_VER_1_3
   2,
#else
   3,
#endif
   mgMsgDefEventNameSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefEventName = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EVTNAME ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 365,
   sizeof(MgEvntName),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefEventNameSeq,
   NULLP
};
/* following is for Event in Requested Events */

#ifdef GCP_VER_1_3       /* NO Bis flag here */

/* following is for the defns of PkgUnknownEvntName & PkgAllEvntName */

PUBLIC CmAbnfElmDef  *mgMsgDefPkgUnknownEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgUnknownEvntNameSeq =
{
    3 ,
    mgMsgDefPkgUnknownEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgUnknownEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG UNKNOWN EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 366,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgUnknownEvntNameSeq ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgAllEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgAllEvntNameSeq =
{
    3 ,
    mgMsgDefPkgAllEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAllEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG ALL EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 367,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgAllEvntNameSeq ,
    NULLP
};


/* above is for the defns of PkgUnknownEvntName & PkgAllEvntName */

PUBLIC CmAbnfElmDef *mgMsgDefSpcPkgRqEvTreeElmnts[] =
{        /* PUBLIC CmAbnfelmDef *mgMsgDefSpcPkgTreeElmnts */
   &mgMsgDefPkgUnknownEvntName ,

#ifdef  GCP_PKG_MGCP_GENERIC_MEDIA
   &mgMsgDefPkgGRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_DTMF
   &mgMsgDefPkgDRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_TRUNK
   &mgMsgDefPkgTRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_LINE
   &mgMsgDefPkgLRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_HANDSET_EMUL
   &mgMsgDefPkgHRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_RTP
   &mgMsgDefPkgRRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_ANNC_SERVER
   &mgMsgDefPkgARqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_SCRIPT
   &mgMsgDefPkgScriptRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_SUPPL_SRVS_TONE
   &mgMsgDefPkgSSTRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_CNTRY_SPEC_TONE
   &mgMsgDefPkgCSTRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

     /* DM1 */
#ifdef  GCP_PKG_MGCP_SIGLST
   &mgMsgDefPkgSLRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_ATM
   &mgMsgDefPkgAtmRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_DTMF_DLPL_BASPBX
   &mgMsgDefPkgBLRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_FXO_LSG_ANALOG
   &mgMsgDefPkgDORqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_DTMF_DIAL_PULSE
   &mgMsgDefPkgDTRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_NAM_MF_GRP_DE
   &mgMsgDefPkgMDRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_MF_WINKSTART
   &mgMsgDefPkgMSRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_RES_RESERV
   &mgMsgDefPkgRESRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

   
   &mgMsgDefPkgAllEvntName ,          /* index is 19 */

#ifdef  GCP_PKG_MGCP_MF
   &mgMsgDefPkgMRqEvEvntName ,        /* 20 */
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_BASIC_NAS
   &mgMsgDefPkgNASRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_ISUP_TRUNK
   &mgMsgDefPkgITRqEvEvntName ,       /* 22 */
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_MF_TERM_PROTO
   &mgMsgDefPkgMTRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif


#ifdef  GCP_PKG_MGCP_NAS_DATAOUT
   &mgMsgDefPkgNAORqEvEvntName ,      /* 24 */
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_FAX
   &mgMsgDefPkgFXRRqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_FGD_OP_SR_SIGOUT
   &mgMsgDefPkgMORqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

/* Audio Server BAU & AAU package */
#ifdef GCP_PKG_MGCP_AU_SRVR
   &mgMsgDefPkgBAURqEvEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

   /*
    * [TEL]: Added for Display XML package
    */
#ifdef GCP_PKG_MGCP_DISPLAY_XML      /* 28 */
   &mgMsgDefPkgXMLRqEvEvntName,
#else
   &mgMsgDefPkgUnknownEvntName,
#endif

   /*
    * [TEL]: Added for Feature Key package
    */
#ifdef GCP_PKG_MGCP_FEATURE_KEY
   &mgMsgDefPkgKYRqEvEvntName,   /* 29 */
#else
   &mgMsgDefPkgUnknownEvntName,
#endif

   /*
    * [TEL]: Added for Base package
    */
#if (defined(GCP_PKG_MGCP_BASE) && defined(GCP_2705BIS))
   &mgMsgDefPkgBRqEvEvntName,   /* 30 */
#else
   &mgMsgDefPkgUnknownEvntName,
#endif

};

/*
 * [TEL]: Enhanced to MGT_MGCP_PKG_MAX
 */
PUBLIC U8 mgMsgDefSpcPkgRqEvTreeIdx[] = {0, 1, 2, 20, 3, 4, 5, 6, 21, 7, 8,
                                         0, 22, 26, 23, 9, 10, 0, 11, 12, 13,
                                         14, 15, 16, 17, 18,  24, 25,  19, 27, 
                                         27, 28, 29, 0, 30};

PUBLIC CmAbnfElmTypeChoice mgMsgDefSpcPkgRqEvTreeChc=
{
   /* [TEL]: Changed from 28 */
   31,    /* Dm1 is not added - most likely won't be added */
   MGT_MGCP_PKG_MAX, 
   mgMsgDefSpcPkgRqEvTreeIdx,
   mgMsgDefSpcPkgRqEvTreeElmnts,
   NULLP
};

PUBLIC CmAbnfElmDef mgMsgDefSpcPkgRqEvTree =
{
#ifdef CM_ABNF_DBG
   "MGCP: Specific Package name",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 368,
   sizeof(MgPkgName)+ sizeof(MgEventDesc),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefSpcPkgRqEvTreeChc,
   mgMsgRegExpPackageName
};

PUBLIC CmAbnfElmDef *mgMsgDefPkgNameRqEvSeqElmnt[] =
{
   &mgMsgDefSpcPkgRqEvTree
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefPkgNameRqEvSeq =
{
   1,
   mgMsgDefPkgNameRqEvSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefPkgNameRqEv = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PKGNM ", 
   "R22",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 369,
   sizeof(MgPkgName)+ sizeof(MgEventDesc),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefPkgNameRqEvSeq,
   mgMsgRegExpR22
};


PUBLIC CmAbnfElmDef *mgMsgDefPkgNameEvntDescSeqElmnt[] =
{
   &mgMsgDefPkgName,
   &mgMsgDefEvntDesc,
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefPkgNameEvntDescSeq =
{
   2,
   mgMsgDefPkgNameEvntDescSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefPkgNameEvntDesc = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EVTNAME ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 370,
   sizeof(MgPkgName)+ sizeof(MgEventDesc),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefPkgNameEvntDescSeq,
   NULLP
};



PUBLIC CmAbnfElmTypeEnum mgMsgDefPkgNameRqEvEnum=
{
   NULLP,
   0
};

PUBLIC CmAbnfElmDef mgMsgDefPkgNameRqEvEnumDef = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EnumDef Chc0 EventName", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 371,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefPkgNameRqEvEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefPkgNameEvntDescEnum=
{
   NULLP,
   1
};

PUBLIC CmAbnfElmDef mgMsgDefPkgNameEvntDescEnumDef= 
{
#ifdef CM_ABNF_DBG
   "MGCP: EnumDef Chc1 EventName", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 372,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefPkgNameEvntDescEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefPkgNameRqEvChcTreeChcEnum[] =
{
   &mgMsgDefPkgNameRqEvEnumDef ,
   &mgMsgDefPkgNameEvntDescEnumDef
};

PUBLIC CmAbnfElmDef *mgMsgDefPkgNameRqEvChcTreeChcElmnts[] =
{
   &mgMsgDefPkgNameRqEv ,
   &mgMsgDefPkgNameEvntDesc
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefPkgNameRqEvChcTreeChc =
{
   2,
   0,
   NULLP,
   mgMsgDefPkgNameRqEvChcTreeChcElmnts ,
   mgMsgDefPkgNameRqEvChcTreeChcEnum   
};


PUBLIC CmAbnfElmDef mgMsgDefPkgNameRqEvChcTree =
{
#ifdef CM_ABNF_DBG
   "MGCP: Choice for opt Pkg Name",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 373,
   sizeof(TknU8) + sizeof(MgPkgName)+ sizeof(MgEventDesc),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefPkgNameRqEvChcTreeChc,
   mgMsgRegExpEvntNameType
};

PUBLIC CmAbnfElmDef *mgMsgDefEventNameRqEvSeqElmnt[] =
{
   &mgMsgDefPkgNameRqEvChcTree,
   &mgMsgDefEvntDesConnId
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefEventNameRqEvSeq =
{
   2,
   mgMsgDefEventNameRqEvSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefEventNameRqEv = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EVTNAME ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 374,
   sizeof(MgEvntName),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefEventNameRqEvSeq,
   NULLP
};


/* following is for Event in Signal Request */


PUBLIC CmAbnfElmDef *mgMsgDefSpcPkgSgRqTreeElmnts[] =
{        /* PUBLIC CmAbnfelmDef *mgMsgDefSpcPkgTreeElmnts */
   &mgMsgDefPkgUnknownEvntName ,

#ifdef  GCP_PKG_MGCP_GENERIC_MEDIA
   &mgMsgDefPkgGSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_DTMF
   &mgMsgDefPkgDSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_TRUNK
   &mgMsgDefPkgTSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_LINE
   &mgMsgDefPkgLSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_HANDSET_EMUL
   &mgMsgDefPkgHSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_RTP
   &mgMsgDefPkgRSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_ANNC_SERVER
   &mgMsgDefPkgASgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_SCRIPT
   &mgMsgDefPkgScriptSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_SUPPL_SRVS_TONE
   &mgMsgDefPkgSSTSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_CNTRY_SPEC_TONE
   &mgMsgDefPkgCSTSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

     /* Dm1 */
#ifdef  GCP_PKG_MGCP_SIGLST
   &mgMsgDefPkgSLSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_ATM
   &mgMsgDefPkgAtmSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_DTMF_DLPL_BASPBX
   &mgMsgDefPkgBLSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_FXO_LSG_ANALOG
   &mgMsgDefPkgDOSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_DTMF_DIAL_PULSE
   &mgMsgDefPkgDTSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_NAM_MF_GRP_DE
   &mgMsgDefPkgMDSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_MF_WINKSTART
   &mgMsgDefPkgMSSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

   
   &mgMsgDefPkgAllEvntName ,        /* index is 18 */

#ifdef  GCP_PKG_MGCP_MF
   &mgMsgDefPkgMSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_ADSI
   &mgMsgDefPkgSSgRqEvntName ,      /* 20 */
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_ISUP_TRUNK
   &mgMsgDefPkgITSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_MF_TERM_PROTO
   &mgMsgDefPkgMTSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

#ifdef  GCP_PKG_MGCP_FGD_OP_SR_SIGOUT
   &mgMsgDefPkgMOSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

/* Audio Server BAU & AAU package */
#ifdef  GCP_PKG_MGCP_AU_SRVR
   &mgMsgDefPkgBAUSgRqEvntName ,
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

   /*
    * [TEL]: Added for Display XML package
    */
#ifdef  GCP_PKG_MGCP_DISPLAY_XML
   &mgMsgDefPkgXMLSgRqEvntName ,   /* 25 */
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

   /*
    * [TEL]: Added for Feature key package
    */
#ifdef  GCP_PKG_MGCP_FEATURE_KEY
   &mgMsgDefPkgKYSgRqEvntName ,   /* 26 */
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

   /*
    * [TEL]: Added for Business Phone package
    */
#ifdef  GCP_PKG_MGCP_BUS_PHONE
   &mgMsgDefPkgBPSgRqEvntName ,   /* 27 */
#else
   &mgMsgDefPkgUnknownEvntName ,
#endif

};

/*
 * [TEL]: Enhanced to MGT_MGCP_PKG_MAX 
 */
PUBLIC U8 mgMsgDefSpcPkgSgRqTreeIdx[] = {0, 1, 2, 19, 3, 4, 5, 6, 0, 7, 8,
                                         20, 21, 23, 22, 9, 10, 0, 11, 12, 13,
                                         14, 15, 16, 17, 0, 0,0,  18, 24, 24 ,
                                         25, 26, 27, 0};

PUBLIC CmAbnfElmTypeChoice mgMsgDefSpcPkgSgRqTreeChc=
{
   /* [TEL]: Increased from 25 */
   28,    /* Dm1 is not included */
   MGT_MGCP_PKG_MAX,
   mgMsgDefSpcPkgSgRqTreeIdx,
   mgMsgDefSpcPkgSgRqTreeElmnts,
   NULLP
};

PUBLIC CmAbnfElmDef mgMsgDefSpcPkgSgRqTree =
{
#ifdef CM_ABNF_DBG
   "MGCP: Specific Package name",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 375,
   sizeof(MgPkgName)+ sizeof(MgEventDesc),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefSpcPkgSgRqTreeChc,
   mgMsgRegExpPackageName
};

PUBLIC CmAbnfElmDef *mgMsgDefPkgNameSgRqSeqElmnt[] =
{
   &mgMsgDefSpcPkgSgRqTree
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefPkgNameSgRqSeq =
{
   1,
   mgMsgDefPkgNameSgRqSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefPkgNameSgRq = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PKGNM ", 
   "R22",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 376,
   sizeof(MgPkgName)+ sizeof(MgEventDesc),   
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefPkgNameSgRqSeq,
   NULLP
};



PUBLIC CmAbnfElmTypeEnum mgMsgDefPkgNameSgRqEnum=
{
   NULLP,
   0
};

PUBLIC CmAbnfElmDef mgMsgDefPkgNameSgRqEnumDef = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EnumDef Chc0 EventName", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 377,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefPkgNameSgRqEnum,
   NULLP
};


PUBLIC CmAbnfElmDef *mgMsgDefPkgNameSgRqChcTreeChcEnum[] =
{
   &mgMsgDefPkgNameSgRqEnumDef ,
   &mgMsgDefPkgNameEvntDescEnumDef
};

PUBLIC CmAbnfElmDef *mgMsgDefPkgNameSgRqChcTreeChcElmnts[] =
{
   &mgMsgDefPkgNameSgRq ,
   &mgMsgDefPkgNameEvntDesc
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefPkgNameSgRqChcTreeChc =
{
   2,
   0,
   NULLP,
   mgMsgDefPkgNameSgRqChcTreeChcElmnts ,
   mgMsgDefPkgNameSgRqChcTreeChcEnum   
};


PUBLIC CmAbnfElmDef mgMsgDefPkgNameSgRqChcTree =
{
#ifdef CM_ABNF_DBG
   "MGCP: Choice for opt Pkg Name",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 378,
   sizeof(TknU8) + sizeof(MgPkgName)+ sizeof(MgEventDesc),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefPkgNameSgRqChcTreeChc,
   mgMsgRegExpEvntNameType
};

PUBLIC CmAbnfElmDef *mgMsgDefEventNameSgRqSeqElmnt[] =
{
   &mgMsgDefPkgNameSgRqChcTree,
   &mgMsgDefEvntDesConnId
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefEventNameSgRqSeq =
{
   2,
   mgMsgDefEventNameSgRqSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefEventNameSgRq = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EVTNAME ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 379,
   sizeof(MgEvntName),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefEventNameSgRqSeq,
   NULLP
};

#endif

/************************************************************************
               Database element for Digit Map 
************************************************************************/
PUBLIC CmAbnfElmTypeRange mgMsgDefDgtMapStringRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefDgtMapString = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DGTLST", 
   "R21",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 380,
   sizeof(TknStrOSXL),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefDgtMapStringRng,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   mgMsgRegExpR51
#else
   mgMsgRegExpR21
#endif
};

PUBLIC CmAbnfElmDef *mgMsgDefDgtMapStringListSeqOfElmnt[] =
{
   &cmMsgDefMetaPipe,
   &mgMsgDefDgtMapString
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefDgtMapStringListSeqOf =
{
   1,
   MGT_MAX_DGT_MAP,
   2,
   mgMsgDefDgtMapStringListSeqOfElmnt,
   sizeof(TknStrOSXL)  
};

PUBLIC CmAbnfElmDef mgMsgDefDgtMapStringList = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DGTLST", 
   "CM_RPIPE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 381,
   sizeof(MgDgtMap),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefDgtMapStringListSeqOf,
   cmAbnfRegExpPipe
};

PUBLIC CmAbnfElmDef *mgMsgDefDgtMapListSeqElmnt[] =
{
   &mgMsgDefDgtMapString,    
   &mgMsgDefDgtMapStringList 
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefDgtMapListSeq =
{
   2,
   mgMsgDefDgtMapListSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefDgtMapList = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DGTLST", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 382,
   sizeof(MgDgtMap),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefDgtMapListSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefDgtMapsSeqElmnt[] =
{
   &cmMsgDefMetaOpenBrace,
   &mgMsgDefDgtMapList,
   &cmMsgDefMetaCloseBrace
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefDgtMapsSeq =
{
   3,
   mgMsgDefDgtMapsSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefDgtMaps = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DGTLST", 
   "CM_ROPENBRACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 383,
   sizeof(MgDgtMap),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMsgDefDgtMapsSeq,
   cmAbnfRegExpOpenBrace
};

PUBLIC CmAbnfElmDef *mgMsgDefDgtMapSeqElmnt[] =
{
   &mgMsgDefDgtMapString,    /* number of element is one */
   &mgMsgDefDgtMaps          /* more than on element */
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefDgtMapSeq =
{
   2,
   mgMsgDefDgtMapSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefDgtMap = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DGT", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 384,
   sizeof(MgDgtMap),   
#if defined (GCP_VER_1_3) && defined (GCP_2705BIS) && defined (GCP_MGCP_PARSE_DIG_MAP)
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefDgtMapStringRng,
   mgMsgRegExpR52
#else
   (CM_ABNF_TKN_NOT_CONSUMED|CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHSEQOF,
   (U8 *)&mgMsgDefDgtMapSeq,
   mgMsgRegExpR20 
#endif
};

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
PUBLIC CmAbnfElmDef mgMsgDefDgtMapOpt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DGT OPT", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 385,
   sizeof(MgDgtMap),   
#ifdef GCP_MGCP_PARSE_DIG_MAP
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefDgtMapStringRng,
   mgMsgRegExpR52
#else
   (CM_ABNF_TKN_NOT_CONSUMED|CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_CHSEQOF,
   (U8 *)&mgMsgDefDgtMapSeq,
   mgMsgRegExpR20 
#endif
};
#endif

/************************************************************************
               Database element for Signal Request 
************************************************************************/
PUBLIC CmAbnfElmTypeRange mgMsgDefDQouteStringRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefDQouteString= 
{
#ifdef CM_ABNF_DBG
   "MGCP: QTSTRING", 
   "R19",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 386,
   sizeof(TknStrOSXL),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefDQouteStringRng,
   mgMsgRegExpR19
};

   /* new elmnt added */
PUBLIC CmAbnfElmDef *mgMsgDefDQuoteStrSqSeqElmnt[] =
{
   &mgMsgDefDQouteString
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefDQuoteStrSqSeq =
{
   1, 
   mgMsgDefDQuoteStrSqSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefDQuoteStrSeq = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SIGREQ_VAL", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 386,
   sizeof(TknStrOSXL),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefDQuoteStrSqSeq,
   NULLP
};


PUBLIC CmAbnfElmDef *mgMsgDefDQouteStringListSeqOfSeq[] =
{
   &cmMsgDefQuoteEsc,
   &mgMsgDefDQuoteStrSeq
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefDQouteStringListSeqOf=
{
   1,
   MGT_MAX_DQOUTE_STR,
   2,
   mgMsgDefDQouteStringListSeqOfSeq,
   sizeof(TknStrOSXL)  
};

PUBLIC CmAbnfElmDef mgMsgDefDQouteStringList= 
{
#ifdef CM_ABNF_DBG
   "MGCP: DQT_STR", 
   "CM_RQTESC",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 387,
   sizeof(MgQuoteStr),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefDQouteStringListSeqOf,
   cmAbnfRegExpQuoteEsc 
};

PUBLIC CmAbnfElmDef *mgMsgDefDQouteSetSeqElmnt[] =
{
   &mgMsgDefDQuoteStrSeq,
   &mgMsgDefDQouteStringList
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefDQouteSetSeq=
{
   2,
   mgMsgDefDQouteSetSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefDQouteSet= 
{
#ifdef CM_ABNF_DBG
   "MGCP: DQT_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 388,
   sizeof(MgQuoteStr),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefDQouteSetSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefDQouteSeqElmnt[] =
{
   &cmMsgDefMetaDQoute,
   &mgMsgDefDQouteSet,
   &cmMsgDefMetaDQoute
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefDQouteSeq =
{
   3,
   mgMsgDefDQouteSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefDQoute= 
{
#ifdef CM_ABNF_DBG
   "MGCP: DQT_STR", 
   "CM_RDQOUTE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 389,
   sizeof(MgQuoteStr),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMsgDefDQouteSeq,
   cmAbnfRegExpDquote
};

PUBLIC CmAbnfElmTypeRange mgMsgDefEvntParamStringRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefEvntParamString = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PARM_STR", 
   "EvntParamString",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 390,
   sizeof(TknStrOSXL),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefEvntParamStringRng,
   mgMsgRegExpEvntParamString
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefDQouteStrEnum =
{
   NULLP,
   MGT_TYPE_QUOTED_STR
};

PUBLIC CmAbnfElmDef mgMsgDefDQouteStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PARAM_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 391,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefDQouteStrEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefEvntParamStrEnum =
{
   NULLP,
   MGT_TYPE_STR
};

PUBLIC CmAbnfElmDef mgMsgDefEvntParamStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PARAM_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 392,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEvntParamStrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefEvntParamTypeChcEnum[] =
{
   NULLP,
   &mgMsgDefEvntParamStr,
   &mgMsgDefDQouteStr
};

PUBLIC CmAbnfElmDef *mgMsgDefEvntParamTypeChcElmnt[] =
{
   NULLP,
   &mgMsgDefEvntParamString,
   &mgMsgDefDQoute
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefEvntParamTypeChc =
{
   3,
   0,
   NULLP,
   mgMsgDefEvntParamTypeChcElmnt,
   mgMsgDefEvntParamTypeChcEnum
};

PUBLIC CmAbnfElmDef mgMsgDefEvntParamType = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PARMTYPE", 
   "MGCP: R18",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 393,
   sizeof(MgEvntParamType),   
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefEvntParamTypeChc,
   mgMsgRegExpR18
};

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))

EXTERN  CmAbnfElmDef mgMsgDefEvntOneParamType;
EXTERN  CmAbnfElmDef mgMsgDefEvntParamTypeSet;

PUBLIC CmAbnfElmDef *mgMsgDefEvntOneParamValSeqElmnt[] =
{
   &mgMsgDefEvntParamString,
   &cmMsgDefMetaEqual,
   &mgMsgDefEvntParamType,
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefEvntOneParamTypeValSeq =
{
   3, 
   mgMsgDefEvntOneParamValSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefEvntOneParamTypeVal =
{
#ifdef CM_ABNF_DBG
   "MGCP: One param",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 394,
   sizeof(MgEvntOneParamTypeVal),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefEvntOneParamTypeValSeq,
   NULLP,
};


PUBLIC CmAbnfElmDef *mgMsgDefEvntParamSetValSeqElmnt[] =
{
   &mgMsgDefEvntParamString,
   &cmMsgDefMetaOpenBrace,
   &mgMsgDefEvntParamTypeSet,
   &cmMsgDefMetaCloseBrace
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefEvntParamTypeSetValSeq =
{
   4, 
   mgMsgDefEvntParamSetValSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefEvntParamTypeSetVal =
{
#ifdef CM_ABNF_DBG
   "MGCP: param ValSet",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_MG_BASE + 395,
   sizeof(MgEvntParamTypeValSet),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefEvntParamTypeSetValSeq,
   NULLP,
};



PUBLIC CmAbnfElmTypeEnum  mgMsgDefEvntParamTypeEnum =
{
    NULLP ,
    MGT_EVNT_PARAM_ONLY_VAL
};

PUBLIC CmAbnfElmDef  mgMsgDefEvntParamTypeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: EVNT PARAM TYPE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 396,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefEvntParamTypeEnum ,
    NULLP
};



PUBLIC CmAbnfElmTypeEnum  mgMsgDefEvntOneParamTypeValEnum =
{
    NULLP ,
    MGT_EVNT_PARAM_ONE_VAL
};

PUBLIC CmAbnfElmDef  mgMsgDefEvntOneParamTypeValEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: EVNT ONE PARAM TYPE VAL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 397,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefEvntOneParamTypeValEnum ,
    NULLP
};



PUBLIC CmAbnfElmTypeEnum  mgMsgDefEvntParamTypeSetValEnum =
{
    NULLP ,
    MGT_EVNT_PARAM_SET_VAL
};

PUBLIC CmAbnfElmDef  mgMsgDefEvntParamTypeSetValEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: EVNT PARAM TYPE SET VAL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 398,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefEvntParamTypeSetValEnum ,
    NULLP
};


PUBLIC CmAbnfElmDef *mgMsgDefEvntOneParamTypeChcEnm[] =
{
   &mgMsgDefEvntParamTypeEnumDef ,
   &mgMsgDefEvntOneParamTypeValEnumDef ,
   &mgMsgDefEvntParamTypeSetValEnumDef
};

PUBLIC CmAbnfElmDef *mgMsgDefEvntOneParamTypeChcElmnt[] =
{
   &mgMsgDefEvntParamType,
   &mgMsgDefEvntOneParamTypeVal,
   &mgMsgDefEvntParamTypeSetVal,
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefEvntOneParamTypeChc =
{
   3,
   0,
   NULLP,
   mgMsgDefEvntOneParamTypeChcElmnt,
   mgMsgDefEvntOneParamTypeChcEnm
};

PUBLIC CmAbnfElmDef mgMsgDefEvntOneParamType = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PARMTYPE", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 399,
   sizeof(MgEvntOneParamType),   
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefEvntOneParamTypeChc,
   mgMsgRegExpAlEqOrBrc   /* This regular exp will look for alpha follwed by
"="or "("*/ 
};

#endif
PUBLIC CmAbnfElmDef *mgMsgDefEvntParamTypeListSeqElmnt[] =
{
   &cmMsgDefMetaComma,
   &cmMsgDefOptMetaSpace,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefEvntOneParamType
#else
   &mgMsgDefEvntParamType
#endif
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefEvntParamTypeListSeq =
{
   1,
   MGT_MAX_EVENT_PARAM,
   3,
   mgMsgDefEvntParamTypeListSeqElmnt,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   sizeof(MgEvntOneParamType)
#else
   sizeof(MgEvntParamType)
#endif
};

PUBLIC CmAbnfElmDef mgMsgDefEvntParamTypeList = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PARMTYPE", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 400,
   sizeof(MgEvntParamTypeSet),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefEvntParamTypeListSeq,
   cmAbnfRegExpComma
};

PUBLIC CmAbnfElmDef *mgMsgDefEvntParamTypeSetSeqElmnt[] =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefEvntOneParamType,
#else
   &mgMsgDefEvntParamType,
#endif
   &mgMsgDefEvntParamTypeList
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefEvntParamTypeSetSeq =
{
   2,
   mgMsgDefEvntParamTypeSetSeqElmnt
};

#ifdef GCP_VER_1_3

PUBLIC CmAbnfElmDef mgMsgDefEvntParamTypeSetReal = /* change */
{
#ifdef CM_ABNF_DBG
   "MGCP: PARMTYPE", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 401,
   sizeof(MgEvntParamTypeSet),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefEvntParamTypeSetSeq,
   NULLP
};

/* start of addition */
PUBLIC CmAbnfElmDef mgMsgDefSkipEvntParamSetSize =
{
#ifdef CM_ABNF_DBG
   "MGCP: skip EvntParamSet",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 151,
   sizeof(MgEvntParamTypeSet),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmTypeMarker mgMsgDefMarkEvntParamTypeSetMarker =
{
   CM_ABNF_MARKER_ESC_FUNC,
   (U8 *)mgMsgMrkFuncEvntParamTypeSet
};

PUBLIC CmAbnfElmDef mgMsgDefMarkEvntParamTypeSet =
{
#ifdef CM_ABNF_DBG
   "Marker EvntParm",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 401,
   0,
   0,
   CM_ABNF_TYPE_MARKER,
   (U8 *)&mgMsgDefMarkEvntParamTypeSetMarker,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefMarkedEvntParamTypeSetSeqElmnt[] =
{
   &mgMsgDefMarkEvntParamTypeSet,           /* this changes the next field at runtime */
   &mgMsgDefEvntParamTypeSetReal,
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefMarkedEvntParamTypeSetSeq =
{
   2,
   mgMsgDefMarkedEvntParamTypeSetSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefEvntParamTypeSet = 
{
#ifdef CM_ABNF_DBG
   "MGCP: OptSeq - PARMTYPE & mrkr", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 401,
   sizeof(MgEvntParamTypeSet),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefMarkedEvntParamTypeSetSeq,
   NULLP
};
/* end of addition */

#else  /* addition of else part and flags */

PUBLIC CmAbnfElmDef mgMsgDefEvntParamTypeSet = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PARMTYPE", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 401,
   sizeof(MgEvntParamTypeSet),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefEvntParamTypeSetSeq,
   NULLP
};

#endif /* GCP_VER_1_3 */


PUBLIC CmAbnfElmDef *mgMsgDefSigEvntParamTypeSeqElmnt[] =
{
   &cmMsgDefMetaOpenBrace,
   &mgMsgDefEvntParamTypeSet,
   &cmMsgDefMetaCloseBrace
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefSigEvntParamTypeSeq =
{
   3,
   mgMsgDefSigEvntParamTypeSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefSigEvntParamType = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PARMTYPE_SET ", 
   "CM_OPENBRACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 402,
   sizeof(MgEvntParamTypeSet),   
   CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMsgDefSigEvntParamTypeSeq,
   cmAbnfRegExpOpenBrace
};


#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
PUBLIC CmAbnfElmDef mgMsgDefSigEvntParamTypeMand = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PARMTYPE_SET ", 
   "CM_OPENBRACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 403,
   sizeof(MgEvntParamTypeSet),   
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMsgDefSigEvntParamTypeSeq,
   cmAbnfRegExpOpenBrace
};
#endif

PUBLIC CmAbnfElmDef *mgMsgDefSigReqValSeqElmnt[] =
{
#ifdef GCP_VER_1_3
   &mgMsgDefEventNameSgRq,
#else
   &mgMsgDefEventName,
#endif
   &mgMsgDefSigEvntParamType
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefSigReqValSeq =
{
   2, 
   mgMsgDefSigReqValSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefSigReqVal = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SIGREQ_VAL", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 404,
   sizeof(MgSignalRqst),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefSigReqValSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefSigReqSeqOfElmnt[] =
{
   &cmMsgDefMetaComma,
   &cmMsgDefOptMetaSpace,
   &mgMsgDefSigReqVal
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefSigReqSeqOf =
{
   1,
   MGT_MAX_UNKNWON, 
   3,
   mgMsgDefSigReqSeqOfElmnt,
   sizeof(MgSignalRqst)   
};

PUBLIC CmAbnfElmDef mgMsgDefSigReq = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SIGREQ_SET", 
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 405,
   sizeof(MgSignalRqstSet),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefSigReqSeqOf,
   cmAbnfRegExpComma
};

PUBLIC CmAbnfElmDef *mgMsgDefSigReqSetSeqElmnt[] =
{
   &mgMsgDefSigReqVal,
   &mgMsgDefSigReq
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefSigReqSetSeq =
{
   2,
   mgMsgDefSigReqSetSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefSigReqSet = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SIGREQ", 
   "R22",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 406,
   sizeof(MgSignalRqstSet),   
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefSigReqSetSeq,
   mgMsgRegExpSigReqSetFirst
};

#ifdef GCP_VER_1_3

PUBLIC CmAbnfElmDef *mgMsgDefObsEvtValSeqElmnt[] =
{
   &mgMsgDefEventNameRqEv,
   &mgMsgDefSigEvntParamType
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefObsEvtValSeq =
{
   2, 
   mgMsgDefObsEvtValSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefObsEvtVal = 
{
#ifdef CM_ABNF_DBG
   "MGCP: OBS EVT VAL", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 404,
   sizeof(MgSignalRqst),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefObsEvtValSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefObsEvtSeqOfElmnt[] =
{
   &cmMsgDefMetaComma,
   &cmMsgDefOptMetaSpace,
   &mgMsgDefObsEvtVal
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefObsEvtSeqOf =
{
   1,
   MGT_MAX_UNKNWON, 
   3,
   mgMsgDefObsEvtSeqOfElmnt,
   sizeof(MgSignalRqst)   
};

PUBLIC CmAbnfElmDef mgMsgDefObsEvt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: OBS EVT SET", 
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 405,
   sizeof(MgSignalRqstSet),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefObsEvtSeqOf,
   cmAbnfRegExpComma
};

PUBLIC CmAbnfElmDef *mgMsgDefObsEvtSetSeqElmnt[] =
{
   &mgMsgDefObsEvtVal,
   &mgMsgDefObsEvt
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefObsEvtSetSeq =
{
   2,
   mgMsgDefObsEvtSetSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefObsEvtSet = 
{
#ifdef CM_ABNF_DBG
   "MGCP: OBS EVT", 
   "SigReqSetFirst",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 406,
   sizeof(MgSignalRqstSet),   
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefObsEvtSetSeq,
   mgMsgRegExpSigReqSetFirst
};

#endif

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
PUBLIC CmAbnfElmDef mgMsgDefSigReqSetMndt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SIGREQ Mandatory", 
   "R22",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 407,
   sizeof(MgSignalRqstSet),   
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefSigReqSetSeq,
   mgMsgRegExpSigReqSetFirst
};
#endif
/************************************************************************
               Database element for max and num endpoint IDs
************************************************************************/

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMsgDefNumEndptsRng = {1, 10, 0, (U32)~0};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefNumEndptsRng = {1, 10};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMsgDefNumEndpts =
{
#ifdef CM_ABNF_DBG        
   "MGCP: NUMENDPTS",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 408,
   sizeof(TknU32), 
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_TGCP_OFFSET | 
    CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_NCS_OFFSET),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMsgDefNumEndptsRng,
   cmAbnfRegExpDgt
};

/************************************************************************
               Database element for resource ID in NCS
************************************************************************/

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMsgDefDqosResourceIdRng = {1, 8, 0, (U32)~0};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefDqosResourceIdRng = {1, 8};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMsgDefDqosResourceId =
{
#ifdef CM_ABNF_DBG
   "MGCP: NCS: RESOURCEID",
   "XDgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 409,
   sizeof(TknU32),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_NCS_OFFSET,
   CM_ABNF_TYPE_HEXUINT32,
   (U8 *)&mgMsgDefDqosResourceIdRng,
   cmAbnfRegExpXDgt
};

/************************************************************************
               Database element for version supported
************************************************************************/

EXTERN CmAbnfElmDef mgMsgDefMgcpVer;

PUBLIC CmAbnfElmDef *mgMsgDefMgcpVerSetSeqOfElmnt[] =
{
   &cmMsgDefMetaComma,
   &mgMsgDefMgcpVer,
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefMgcpVerSetSeqOf =
{
   1,
   MGT_MAX_VERS_SUPP,
   2,
   mgMsgDefMgcpVerSetSeqOfElmnt,
   sizeof(MgMgcpVer)
};

PUBLIC CmAbnfElmDef mgMsgDefMgcpVerSet =
{
#ifdef CM_ABNF_DBG
   "MGCP: MGCPVER_SET",
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 410,
   sizeof(MgMgcpVerSet),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MGCP_TGCP_OFFSET |
    CM_ABNF_OPTIONAL << CM_ABNF_PROT_MGCP_NCS_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefMgcpVerSetSeqOf,
   cmAbnfRegExpComma
};

PUBLIC CmAbnfElmDef *mgMsgDefVersSupportedSeqElmnt[] =
{
   &mgMsgDefMgcpVer, 
   &mgMsgDefMgcpVerSet
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefVersSupportedSeq =
{
   2,
   mgMsgDefVersSupportedSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefVersSupported =
{
#ifdef CM_ABNF_DBG
   "MGCP: VERSSUPP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 411,
   sizeof(MgMgcpVerSet),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_NCS_OFFSET |
    CM_ABNF_MANDATORY << CM_ABNF_PROT_MGCP_TGCP_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefVersSupportedSeq,
   NULLP
};


/************************************************************************
               Database element for Package List
************************************************************************/

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))


PUBLIC CmAbnfElmTypeRange  mgMsgDefPkgVersRange =  {   1 , 0xffff  };

PUBLIC CmAbnfElmDef  mgMsgDefPkgVers =
{
#ifdef  CM_ABNF_DBG
    "PkgVers_2" ,
    "R56" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 412,
    sizeof (TknStrOSXL) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OCTSTRXL ,
    (U8 *) &mgMsgDefPkgVersRange ,
    mgMsgRegExpR56
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgNameAndVersSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaColon ,
    &mgMsgDefPkgVers
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgNameAndVersSeq =
{
    3 ,
    mgMsgDefPkgNameAndVersSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgNameAndVers =
{
#ifdef  CM_ABNF_DBG
    "PkgNameAndVers" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 413,
    sizeof (MgMgcpPkgNmVer) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgNameAndVersSeq ,
    NULLP
};


/* Use "," defined in RFC 3435 during encoding */
PUBLIC CmAbnfElmTypeMeta mgMsgDefMetaSemiColonORCommaStr =  {(Data *)","};

PUBLIC CmAbnfElmDef mgMsgDefMetaSemiColonORComma = 
{
#ifdef CM_ABNF_DBG
   "CM: Comma",
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 12,
   0,
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&mgMsgDefMetaSemiColonORCommaStr,
   /* accept ";" OR "," during decoding */
   mgMsgRegExpSemiColonORComma
};


PUBLIC CmAbnfElmDef  *mgMsgDefPkgNameAndVersListSeqOfElmnts[] =
{
    /*
     *   for interoperability purposes accept -
     *   ";" OR "," as list seperator. Consequently,
     *   the database element -
     *
     *   &cmMsgDefMetaSemiColon ,
     *
     *   is replaced by one which accepts both ";" OR ","
     *   during decoding BUT which always encodes using ","
     */
    &mgMsgDefMetaSemiColonORComma ,
    &mgMsgDefPkgNameAndVers
};

PUBLIC CmAbnfElmTypeSeqOf  mgMsgDefPkgNameAndVersListSeqOf =
{
    1 ,
    0xffff ,
    2 ,
    mgMsgDefPkgNameAndVersListSeqOfElmnts ,
    sizeof (MgMgcpPkgNmVer)
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgNameAndVersList =
{
#ifdef  CM_ABNF_DBG
    "PkgNameAndVersList" ,
    "cmAbnfRegExpSemiColon" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 414,
    sizeof (MgMgcpPkgList) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_SEQOF ,
    (U8 *) &mgMsgDefPkgNameAndVersListSeqOf ,
    /*
     *   RFC 3435 defines "," as the list seperator
     *   whereas draft-andreasen-mgcp-rfc2705bis-0?.txt
     *   defines ";" as the list seperator
     *
     *   for interoperability purposes accept -
     *   ";" OR "," as list seperator. Consequently,
     *   the RE -
     *
     *   cmAbnfRegExpSemiColon
     *
     *   is replaced by one which accepts both
     */
    mgMsgRegExpSemiColonORComma
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgListSeqElmnts[] =
{
    &mgMsgDefPkgNameAndVers ,
    &mgMsgDefPkgNameAndVersList
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgListSeq =
{
    2 ,
    mgMsgDefPkgListSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgList =
{
#ifdef  CM_ABNF_DBG
    "PkgList" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 415,
    sizeof (MgMgcpPkgList) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQOF ,
    (U8 *) &mgMsgDefPkgListSeq ,
    NULLP
};



#endif


/************************************************************************
               Database element for Observed Events 
               Same as signal request 
************************************************************************/

/************************************************************************
               Database element for Requested Event 
************************************************************************/

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))


PUBLIC CmAbnfElmTypeRange  mgMsgDefExtnActionUnknownExtnValRange =  {   1 , 0xffff  };

PUBLIC CmAbnfElmDef  mgMsgDefExtnActionUnknownExtnVal =
{
#ifdef  CM_ABNF_DBG
    "ExtnAction" ,
    "R50" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 416,
    sizeof (TknStrOSXL) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OCTSTRXL ,
    (U8 *) &mgMsgDefExtnActionUnknownExtnValRange ,
    mgMsgRegExpR50
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefExtnActionUnknownExtnEnum =
{
    NULLP ,
    MGT_MGCP_EXTN_ACTION_UNKNOWN_EXTN
};

PUBLIC CmAbnfElmDef  mgMsgDefExtnActionUnknownExtn =
{
#ifdef CM_ABNF_DBG
    "MGCP: EXTN ACTION UNKNOWN EXTN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 417,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefExtnActionUnknownExtnEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefExtnActionSeqElmnts[] =
{
    &mgMsgDefExtnActionUnknownExtn ,
    &mgMsgDefExtnActionUnknownExtnVal
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefExtnActionSeq =
{
    2 ,
    mgMsgDefExtnActionSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefExtnAction =
{
#ifdef  CM_ABNF_DBG
    "MGCP: EXTN ACTION " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 418,
    sizeof(MgAction) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefExtnActionSeq ,
    NULLP
};




 PUBLIC CmAbnfElmDef  *mgMsgDefReqActnExtnActnPkgUnknownSeqElmnts[] =
 {
     &mgMsgDefPkgNameString ,
     &cmMsgDefMetaSlash ,
     &mgMsgDefExtnAction ,
     &mgMsgDefSigEvntParamType
 };
 
 PUBLIC CmAbnfElmTypeSeq  mgMsgDefReqActnExtnActnPkgUnknownSeq =
 {
     4 ,
     mgMsgDefReqActnExtnActnPkgUnknownSeqElmnts
 };
 
 PUBLIC CmAbnfElmDef  mgMsgDefReqActnExtnActnPkgUnknown =
 {
 #ifdef  CM_ABNF_DBG
     "MGCP: REQ ACTN EXTN ACTN PKG UNKNOWN " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_MG_BASE + 419,
     sizeof(MgPkgXActn) ,
     ( CM_ABNF_MANDATORY ) ,
     CM_ABNF_TYPE_OPTSEQ ,
     (U8 *) &mgMsgDefReqActnExtnActnPkgUnknownSeq ,
     NULLP
 };
 
 
 PUBLIC CmAbnfElmDef  *mgMsgDefReqActnExtnActnPkgTreeChcElmnt[] =
 {
     &mgMsgDefReqActnExtnActnPkgUnknown ,
 };

/*
 * [TEL]: Enhanced to MGT_MGCP_PKG_MAX
 */ 
PUBLIC U8  mgMsgDefReqActnExtnActnPkgTreeIdx[] = { 0,0,0,0,0, 0,0,0,0,0, 0,0,0,
                                                   0,0,0,0,0, 0,0,0,0,0, 0,0,0,
                                                   0,0,0, 
                                                   0,0,0,0,0, 0};

 PUBLIC CmAbnfElmTypeChoice  mgMsgDefReqActnExtnActnPkgTreeChc =
 {
     1 ,
     MGT_MGCP_PKG_MAX,
     mgMsgDefReqActnExtnActnPkgTreeIdx,
     mgMsgDefReqActnExtnActnPkgTreeChcElmnt ,
     NULLP
 };
 
 PUBLIC CmAbnfElmDef  mgMsgDefReqActnExtnActnPkgTree =
 {
 #ifdef  CM_ABNF_DBG
     "MGCP: REQ ACTN EXTN ACTN PKG TREE " ,
     "ReqActnPkgs" ,
 #endif
     CM_ABNF_ELMNID_MG_BASE + 420,
     sizeof(MgPkgXActn) ,
     ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
     CM_ABNF_TYPE_CHOICE ,
     (U8 *) &mgMsgDefReqActnExtnActnPkgTreeChc ,
     mgMsgRegExpPackageName
 };



PUBLIC CmAbnfElmDef  *mgMsgDefReqEvntExtnActnSeqElmnts[] =
{
    &mgMsgDefReqActnExtnActnPkgTree
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefReqEvntExtnActnSeq =
{
    1 ,
    mgMsgDefReqEvntExtnActnSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefReqEvntExtnActn =
{
#ifdef  CM_ABNF_DBG
    "ReqEvntExtnActn" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 421,
    sizeof (MgPkgXActn) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefReqEvntExtnActnSeq ,
    NULLP
};

#endif

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntEmbReqEvntSeqElmnt[] =
{
   &cmMsgDefMetaOpenBrace,
   &mgMsgDefReqEvntSet,
   &cmMsgDefMetaCloseBrace
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefReqEvntEmbReqEvntSeq =
{
   3,
   mgMsgDefReqEvntEmbReqEvntSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntEmbReqEvnt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EMB_REQEVNT ", 
   "CM_ROPENBRACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 422,
   (sizeof(((MgRqstEmbedType *)0)->t)),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMsgDefReqEvntEmbReqEvntSeq,
   cmAbnfRegExpOpenBrace 
};


PUBLIC CmAbnfElmDef *mgMsgDefReqEvntEmbSigReqSeqElmnt[] =
{
   &cmMsgDefMetaOpenBrace,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefSigReqSetMndt,
#else
   &mgMsgDefSigReqSet,
#endif
   &cmMsgDefMetaCloseBrace
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefReqEvntEmbSigReqSeq =
{
   3,
   mgMsgDefReqEvntEmbSigReqSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntEmbSigReq = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EMB_SIGREQ", 
   "CM_ROPENBRACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 423,
   (sizeof(((MgRqstEmbedType *)0)->t)),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMsgDefReqEvntEmbSigReqSeq,
   cmAbnfRegExpOpenBrace 
};


PUBLIC CmAbnfElmDef *mgMsgDefReqEvntEmbDgtMapSeqElmnt[] =
{
   &cmMsgDefMetaOpenBrace,
   &mgMsgDefDgtMap,
   &cmMsgDefMetaCloseBrace
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefReqEvntEmbDgtMapSeq =
{
   3,
   mgMsgDefReqEvntEmbDgtMapSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntEmbDgtMap = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EMB_DGTMAP ", 
   "CM_ROPENBRACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 424,
   sizeof(((MgRqstEmbedType *)0)->t),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMsgDefReqEvntEmbDgtMapSeq,
   cmAbnfRegExpOpenBrace 
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefEnumDEnum =
{
   (Data *)"D",
   MGT_PARAM_DGT_MAP
};

PUBLIC CmAbnfElmDef mgMsgDefEnumD =
{
#ifdef CM_ABNF_DBG
   "MGCP: D_ENUM ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 425,
   sizeof(TknU8), 
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEnumDEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefEnumSEnum =
{
   (Data *)"S",
   MGT_PARAM_SIG_RQST
};

PUBLIC CmAbnfElmDef mgMsgDefEnumS =
{
#ifdef CM_ABNF_DBG
   "MGCP: S_ENUM ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 426,
   sizeof(TknU8), 
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEnumSEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefEnumREnum =
{
   (Data *)"R",
   MGT_PARAM_RQSTD_EVENT
};

PUBLIC CmAbnfElmDef mgMsgDefEnumR =
{
#ifdef CM_ABNF_DBG
   "MGCP: R_ENUM ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 427,
   sizeof(TknU8), 
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEnumREnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntEmbActnTypeChcElmnt[] =
{  
   &mgMsgDefReqEvntEmbReqEvnt,
   &mgMsgDefReqEvntEmbSigReq,
   &mgMsgDefReqEvntEmbDgtMap
};

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntEmbActnTypeChcEnum[] =
{ 
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,  
   &mgMsgDefEnumR,
   &mgMsgDefEnumS,
   &mgMsgDefEnumD
};

PUBLIC U8  mgMsgDefReqEvntEmbActnTypeIdx[] =
{0,1,2,0,0,0,0,0,0,0,1,2}; 

PUBLIC CmAbnfElmTypeChoice mgMsgDefReqEvntEmbActnTypeChc =
{
   3,
   12,
   mgMsgDefReqEvntEmbActnTypeIdx,
   mgMsgDefReqEvntEmbActnTypeChcElmnt,
   mgMsgDefReqEvntEmbActnTypeChcEnum
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntEmbType = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EMBTP", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 428,
   sizeof(MgRqstEmbedType),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefReqEvntEmbActnTypeChc,
   mgMsgRegExpR17,
};

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntEmbTypeSetSeqofElmnt[] =
{
   &cmMsgDefMetaComma,
   &cmMsgDefOptMetaSpace,
   &mgMsgDefReqEvntEmbType
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefReqEvntEmbTypeSetSeqof =
{
   1,
   MGT_MAX_REQEMBD_TYPE,   
   3,
   mgMsgDefReqEvntEmbTypeSetSeqofElmnt,
   sizeof(MgRqstEmbedType)
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntEmbTypeSet = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EMBTP_SET  ", 
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 429,
   sizeof(MgEmbedActn), 
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefReqEvntEmbTypeSetSeqof,
   cmAbnfRegExpComma
};

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntEmbSetSeqElmnt[] =
{
   &mgMsgDefReqEvntEmbType,
   &mgMsgDefReqEvntEmbTypeSet,
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefReqEvntEmbSetSeq =
{
   2,
   mgMsgDefReqEvntEmbSetSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntEmbSet = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EMBACTN_SET  ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 430,
   sizeof(MgEmbedActn),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefReqEvntEmbSetSeq,
   NULLP

};

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntEmbdSeqElmnt[] =
{
   &cmMsgDefMetaOpenBrace,
   &mgMsgDefReqEvntEmbSet,
   &cmMsgDefMetaCloseBrace
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefReqEvntEmbdSeq =
{
   3,
   mgMsgDefReqEvntEmbdSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntEmbd = 
{
#ifdef CM_ABNF_DBG
   "MGCP: REQEVT_EMB ", 
   "CM_ROPENBRACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 431,
   sizeof(MgEmbedActn),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMsgDefReqEvntEmbdSeq,
   cmAbnfRegExpOpenBrace 
};

PUBLIC CmAbnfElmTypeMeta mgMsgDefMMeta = {(Data *)"M"};

PUBLIC CmAbnfElmDef mgMsgDefM =
{
#ifdef CM_ABNF_DBG
   "MGCP: M",
   "RM",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 432,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&mgMsgDefMMeta,
   mgMsgRegExpRM
};

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntEmbModeSeqElmnt[] =
{
   &mgMsgDefM,
   &cmMsgDefMetaOpenBrace,
   &mgMsgDefConnMode,
   &cmMsgDefMetaOpenBrace,
   &mgMsgDefDesConnId,
   &cmMsgDefMetaCloseBrace,
   &cmMsgDefMetaCloseBrace,
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefReqEvntEmbModeSeq =
{
   7,
   mgMsgDefReqEvntEmbModeSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntEmbMode =
{
#ifdef CM_ABNF_DBG
   "MGCP: ReqEvntEmbMode",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 433,
   sizeof(MgRqstEmbedMDCXMode),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefReqEvntEmbModeSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntEmbModeArraySeqOfElmnt[] =
{
   &cmMsgDefMetaComma,
   &mgMsgDefReqEvntEmbMode
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefReqEvntEmbModeArraySeqOf =
{
   1,
   MGT_MAX_REQEMBD_MDCX_MODE,
   2,
   mgMsgDefReqEvntEmbModeArraySeqOfElmnt,
   sizeof(MgRqstEmbedMDCXMode)
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntEmbModeArray =
{
#ifdef CM_ABNF_DBG
   "MGCP: ReqEvntEmbModeArray",
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 434,
   sizeof(MgEmbedMDCX),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefReqEvntEmbModeArraySeqOf,
   cmAbnfRegExpComma
};

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntEmbModeSetSeqElmnt[] =
{
   &mgMsgDefReqEvntEmbMode,
   &mgMsgDefReqEvntEmbModeArray
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefReqEvntEmbModeSetSeq =
{
   2,
   mgMsgDefReqEvntEmbModeSetSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntEmbModeSet =
{
#ifdef CM_ABNF_DBG
   "MGCP: ReqEvntEmbModeSet",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 435,
   sizeof(MgEmbedMDCX),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefReqEvntEmbModeSetSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntMdcxSeqElmnt[] =
{
   &cmMsgDefMetaOpenBrace,
   &mgMsgDefReqEvntEmbModeSet,
   &cmMsgDefMetaCloseBrace
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefReqEvntMdcxSeq = 
{
   3,
   mgMsgDefReqEvntMdcxSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntMdcx =
{
#ifdef CM_ABNF_DBG
   "MGCP: REQEVT_EMB_MDCX",
   "CM_ROPENBRACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 436,
   sizeof(MgEmbedMDCX),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMsgDefReqEvntMdcxSeq,
   cmAbnfRegExpOpenBrace
};


PUBLIC CmAbnfElmTypeEnum mgMsgDefReqEvntEmbdStrEnum =
{
   (Data *)"E",
   MGT_RQSTD_ACTN_EMB
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntEmbdStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: E_STR  ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 437,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqEvntEmbdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqEvntMdcxStrEnum =
{
   (Data *)"C",
   MGT_RQSTD_ACTN_MDCX
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntMdcxStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: C_STR  ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 438,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqEvntMdcxStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqEvntActnSEnum =
{
   (Data *)"S",
   MGT_RQSTD_ACTN_S
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntActnS = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ACTNS ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 439,
   sizeof(MgRqstdActn),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqEvntActnSEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqEvntActnIEnum =
{
   (Data *)"I",
   MGT_RQSTD_ACTN_I
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntActnI = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ACTNI ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 440,
   sizeof(MgRqstdActn),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqEvntActnIEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqEvntActnKEnum =
{
   (Data *)"K",
   MGT_RQSTD_ACTN_K
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntActnK = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ACTNK ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 441,
   sizeof(MgRqstdActn),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqEvntActnKEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqEvntActnDEnum =
{
   (Data *)"D",
   MGT_RQSTD_ACTN_D
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntActnD = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ACTND ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 442,
   sizeof(MgRqstdActn),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqEvntActnDEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqEvntActnAEnum =
{
   (Data *)"A",
   MGT_RQSTD_ACTN_A
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntActnA = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ACTNA ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 443,
   sizeof(MgRqstdActn),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqEvntActnAEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqEvntActnNEnum =
{
   (Data *)"N",
   MGT_RQSTD_ACTN_N
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntActnN = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ACTNN ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 444,
   sizeof(MgRqstdActn),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqEvntActnNEnum,
   NULLP
};


#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))


PUBLIC CmAbnfElmTypeEnum mgMsgDefReqEvntExtnActnEnum =
{
   NULLP,
   MGT_RQSTD_ACTN_EXTN            /* this needs to be defined to 9 */
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntExtnActnEnumDef =
{
#ifdef CM_ABNF_DBG
   "MGCP: ACTNN ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 445,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqEvntExtnActnEnum,
   NULLP
};
#endif

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntActnChcElmnt[] =
{
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   &mgMsgDefReqEvntEmbd,
   &mgMsgDefReqEvntMdcx,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefReqEvntExtnActn
#endif
};

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntActnChcEnum[] =
{
   NULLP,
   &mgMsgDefReqEvntActnN,
   &mgMsgDefReqEvntActnA,
   &mgMsgDefReqEvntActnD,
   &mgMsgDefReqEvntActnS,
   &mgMsgDefReqEvntActnI,
   &mgMsgDefReqEvntActnK,
   &mgMsgDefReqEvntEmbdStr,
   &mgMsgDefReqEvntMdcxStr,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefReqEvntExtnActnEnumDef
#endif
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefReqEvntActnChc =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   10,
#else
   9,
#endif
   0,
   NULLP,
   mgMsgDefReqEvntActnChcElmnt,
   mgMsgDefReqEvntActnChcEnum
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntActn = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ACTNTP", 
   "R15",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 446,
   sizeof(MgRqstdActn),   
   (CM_ABNF_MANDATORY ),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefReqEvntActnChc,
   mgMsgRegExpR15
};

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntActnListSeqofElmnt[] =
{
   &cmMsgDefMetaComma,
   &cmMsgDefOptMetaSpace,
   &mgMsgDefReqEvntActn
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefReqEvntActnListSeqof =
{
   1,
   MGT_MAX_RQSTD_ACTION,
   3,
   mgMsgDefReqEvntActnListSeqofElmnt,
   sizeof(MgRqstdActn)  
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntActnList = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ACTN_SET ", 
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 447,
   sizeof(MgRqstdActnSet),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefReqEvntActnListSeqof,
   cmAbnfRegExpComma 
};

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntActnsSeqElmnt[] =
{
   &mgMsgDefReqEvntActn,
   &mgMsgDefReqEvntActnList,
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefReqEvntActnsSeq =
{
   2,
   mgMsgDefReqEvntActnsSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntActns = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ACTN_SET ", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 448,
   sizeof(MgRqstdActnSet),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefReqEvntActnsSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntActnSetElmnt[] =
{
   &cmMsgDefMetaOpenBrace,
   &mgMsgDefReqEvntActns,
   &cmMsgDefMetaCloseBrace
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefReqEvntActnSetSeq =
{
   3,
   mgMsgDefReqEvntActnSetElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntActnSet = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ACTN_SET ", 
   "CM_ROPENBRACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 449,
   sizeof(MgRqstdActnSet),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMsgDefReqEvntActnSetSeq,
   cmAbnfRegExpOpenBrace
};


#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
PUBLIC CmAbnfElmDef mgMsgDefReqEvntActnSetMand = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ACTN_SET ", 
   "CM_ROPENBRACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 450,
   sizeof(MgRqstdActnSet),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMsgDefReqEvntActnSetSeq,
   cmAbnfRegExpOpenBrace
};
#endif

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntValSeqElmnt[] =
{
#ifdef GCP_VER_1_3
   &mgMsgDefEventNameRqEv,
   &mgMsgDefReqEvntActnSet,
#ifdef GCP_2705BIS
   &mgMsgDefSigEvntParamType,
#endif
#else
   &mgMsgDefEventName,
   &mgMsgDefReqEvntActnSet,
#endif
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefReqEvntValSeq =
{
#ifdef GCP_2705BIS
   3,
#else
   2,
#endif
   mgMsgDefReqEvntValSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntVal = 
{
#ifdef CM_ABNF_DBG
   "MGCP: REQEVT_VAL", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 451,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   sizeof (MgRqstdEvntSeq) ,
#else
   sizeof(MgRqstdEvnt),   
#endif
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefReqEvntValSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntSeqofElmnt[] =
{
   &cmMsgDefMetaComma,
   &cmMsgDefOptMetaSpace,
   &mgMsgDefReqEvntVal
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefReqEvntSeqof =
{
   1,
   MGT_MAX_UNKNWON,
   3,
   mgMsgDefReqEvntSeqofElmnt,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   sizeof (MgRqstdEvntSeq) ,
#else
   sizeof(MgRqstdEvnt)  
#endif
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvnt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: REQEVT_SET", 
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 452,
   sizeof(MgRqstdEvntSet),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefReqEvntSeqof,
   cmAbnfRegExpComma
};

PUBLIC CmAbnfElmDef *mgMsgDefReqEvntSetSeqElmnt[] =
{
   &mgMsgDefReqEvntVal,
   &mgMsgDefReqEvnt
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefReqEvntSetSeqOf =
{
   2,
   mgMsgDefReqEvntSetSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntSet = 
{
#ifdef CM_ABNF_DBG
   "MGCP: REQEVT", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 453,
   sizeof(MgRqstdEvntSet),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefReqEvntSetSeqOf,
   NULLP
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntSetOpt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: REQEVT OPT", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 454,
   sizeof(MgRqstdEvntSet),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefReqEvntSetSeqOf,
   NULLP
};

/************************************************************************
               Database element for Connection Parameter 
************************************************************************/
#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMsgDefConnParValRng = {1, 9, 0, (U32)999999999};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefConnParValRng = {1, 9};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMsgDefConnParVal = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CONNPAR_VAL ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 455,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMsgDefConnParValRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmTypeRange mgMsgDefConnParNstdExtnNameRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefConnParNstdExtnName = 
{
#ifdef CM_ABNF_DBG
   "MGCP: X-NAME", 
   "CM_RALPHA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 456,
   sizeof(TknStrOSXL),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefConnParNstdExtnNameRng,
   cmAbnfRegExpAlpha
};

PUBLIC CmAbnfElmTypeRange mgMsgDefConnParNstdExtnValRng = {1, 9};

PUBLIC CmAbnfElmDef mgMsgDefConnParNstdExtnVal = 
{
#ifdef CM_ABNF_DBG
   "MGCP: X-VAL", 
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 457,
   sizeof(TknStrOSXL),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefConnParNstdExtnValRng,
   cmAbnfRegExpDgt
};


#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))


PUBLIC CmAbnfElmTypeRange  mgMsgDefConnParCPNameUnknownExtnValRange =  {   1 , 0xffff  };

PUBLIC CmAbnfElmDef  mgMsgDefConnParCPNameUnknownExtnVal =
{
#ifdef  CM_ABNF_DBG
    "ConnParCPName_2" ,
    "R54" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 458,
    sizeof (TknStrOSXL) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OCTSTRXL ,
    (U8 *) &mgMsgDefConnParCPNameUnknownExtnValRange ,
    mgMsgRegExpR54
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnParCPNameUnknownExtnEnum =
{
    NULLP ,
    MGT_MGCP_CONN_PAR_C_P_NAME_UNKNOWN_EXTN
};

PUBLIC CmAbnfElmDef  mgMsgDefConnParCPNameUnknownExtn =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN PAR C P NAME UNKNOWN EXTN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 459,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnParCPNameUnknownExtnEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefConnParCPNameSeqElmnts[] =
{
    &mgMsgDefConnParCPNameUnknownExtn ,
    &mgMsgDefConnParCPNameUnknownExtnVal
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefConnParCPNameSeq =
{
    2 ,
    mgMsgDefConnParCPNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefConnParCPName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: CONN PAR C P NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 460,
    sizeof(MgPkgCPName) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefConnParCPNameSeq ,
    NULLP
};


 PUBLIC CmAbnfElmDef  *mgMsgDefConnParPkgExtnNameUnknownPkgSeqElmnts[] =
 {
     &mgMsgDefPkgNameString ,
     &cmMsgDefMetaSlash ,
     &mgMsgDefConnParCPName
 };
 
 PUBLIC CmAbnfElmTypeSeq  mgMsgDefConnParPkgExtnNameUnknownPkgSeq =
 {
     3 ,
     mgMsgDefConnParPkgExtnNameUnknownPkgSeqElmnts
 };
 
 PUBLIC CmAbnfElmDef  mgMsgDefConnParPkgExtnNameUnknownPkg =
 {
 #ifdef  CM_ABNF_DBG
     "MGCP: CONN PAR PKG EXTN NAME UNKNOWN PKG " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_MG_BASE + 461,
     sizeof(MgPkgCPXNm) ,
     ( CM_ABNF_MANDATORY ) ,
     CM_ABNF_TYPE_OPTSEQ ,
     (U8 *) &mgMsgDefConnParPkgExtnNameUnknownPkgSeq ,
     NULLP
 };
 
 

 
 PUBLIC CmAbnfElmDef  *mgMsgDefConnParPkgExtnNameTreeChcElmnt[] =
 {
     &mgMsgDefConnParPkgExtnNameUnknownPkg ,
#ifdef  GCP_PKG_MGCP_FAX
     &mgMsgDefConnParPkgExtnNamePkgFXR ,
#else
     &mgMsgDefConnParPkgExtnNameUnknownPkg ,
#endif

 };
 
/*
 * [TEL]: Enhanced to MGT_MGCP_PKG_MAX
 */ 
PUBLIC U8  mgMsgDefConnParPkgExtnNameTreeIdx[] = { 0,0,0,0,0, 0,0,0,0,0, 0,0,0,
                                                   0,0,0,0,0, 0,0,0,0,0, 0,0,0,
                                                   0,1,0, 0,0,0,0,0,0};

 PUBLIC CmAbnfElmTypeChoice  mgMsgDefConnParPkgExtnNameTreeChc =
 {
     2 ,
     MGT_MGCP_PKG_MAX,
     mgMsgDefConnParPkgExtnNameTreeIdx,
     mgMsgDefConnParPkgExtnNameTreeChcElmnt ,
     NULLP
 };
 
 PUBLIC CmAbnfElmDef  mgMsgDefConnParPkgExtnNameTree =
 {
 #ifdef  CM_ABNF_DBG
     "MGCP: CONN PAR PKG EXTN NAME TREE " ,
     "CPPkgExtns" ,
 #endif
     CM_ABNF_ELMNID_MG_BASE + 462,
     sizeof(MgPkgCPXNm) ,
     ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
     CM_ABNF_TYPE_CHOICE ,
     (U8 *) &mgMsgDefConnParPkgExtnNameTreeChc ,
     mgMsgRegExpPackageName
 };


PUBLIC CmAbnfElmDef  *mgMsgDefConnParPkgExtnNameSeqElmnts[] =
{
    &mgMsgDefConnParPkgExtnNameTree
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefConnParPkgExtnNameSeq =
{
    1 ,
    mgMsgDefConnParPkgExtnNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefConnParPkgExtnName =
{
#ifdef  CM_ABNF_DBG
    "ConnParPkgExtnName" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 463,
    sizeof (MgPkgCPXNm) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefConnParPkgExtnNameSeq ,
    NULLP
};









PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnParNstdExtnNameEnum =
{
    (Data *)"X-",
    MGT_MGCP_CONN_PAR_VNDR_EXTN
};

PUBLIC CmAbnfElmDef  mgMsgDefConnParNstdExtnNameEnumDef =
{
#ifdef CM_ABNF_DBG
    "ConnParNstdExtnNameEnumDef" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 464,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnParNstdExtnNameEnum ,
    NULLP
};



PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnParPkgExtnNameEnum =
{
    NULLP ,
    MGT_MGCP_CONN_PAR_PKG_EXTN
};

PUBLIC CmAbnfElmDef  mgMsgDefConnParPkgExtnNameEnumDef =
{
#ifdef CM_ABNF_DBG
    "ConnParPkgExtnNameEnumDef" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 465,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnParPkgExtnNameEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefConnParExtnNameChcEnum[] =
{
&mgMsgDefConnParNstdExtnNameEnumDef ,
&mgMsgDefConnParPkgExtnNameEnumDef ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefConnParExtnNameChcElmnt[] =
{
    &mgMsgDefConnParNstdExtnName ,
    &mgMsgDefConnParPkgExtnName ,
};
PUBLIC CmAbnfElmTypeChoice  mgMsgDefConnParExtnNameChc =
{
    2 ,
    0 ,
    NULLP,
    mgMsgDefConnParExtnNameChcElmnt ,
    mgMsgDefConnParExtnNameChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefConnParExtnName =
{
#ifdef  CM_ABNF_DBG
    "ConnParExtnName" ,
    "R53" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 466,
    sizeof (MgCPName) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefConnParExtnNameChc ,
    mgMsgRegExpR53
};

#endif


PUBLIC CmAbnfElmDef *mgMsgDefConnParamNonStdExtnSeqElmt[] =
{
#ifndef GCP_VER_1_3
   &mgMsgDefNonStdType,
#endif
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefConnParExtnName,
#else
   &mgMsgDefConnParNstdExtnName,
#endif
   &cmMsgDefMetaEqual,
   &mgMsgDefConnParNstdExtnVal
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefConnParamNonStdExtnSeq =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   3,
#else
   4,
#endif
   mgMsgDefConnParamNonStdExtnSeqElmt
};

PUBLIC CmAbnfElmDef mgMsgDefConnParamNonStd = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NONSTD_PARAM", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 467,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   sizeof(MgConnParExtn),
#else
   sizeof(MgNonStdExtn),   
#endif
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefConnParamNonStdExtnSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefConnParamNonStdStrEnum =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   NULLP,
#else
   (Data *)"X",
#endif
   MGT_PARAM_CONN_PARAM_NONSTD
};

PUBLIC CmAbnfElmDef mgMsgDefConnParamNonStdStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: XPARM_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 468,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefConnParamNonStdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefLAStrEnum =
{
   (Data *)"LA=",
   MGT_PARAM_CONN_PARAM_LA
};

PUBLIC CmAbnfElmDef mgMsgDefLAStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: LA_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 469,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefLAStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefJIStrEnum =
{
   (Data *)"JI=",
   MGT_PARAM_CONN_PARAM_JI
};

PUBLIC CmAbnfElmDef mgMsgDefJIStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: JI_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 470,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefJIStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefPLStrEnum =
{
   (Data *)"PL=",
   MGT_PARAM_CONN_PARAM_PL
};

PUBLIC CmAbnfElmDef mgMsgDefPLStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PL_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 471,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefPLStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefORStrEnum =
{
   (Data *)"OR=",
   MGT_PARAM_CONN_PARAM_OR
};

PUBLIC CmAbnfElmDef mgMsgDefORStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: OR_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 472,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefORStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefPRStrEnum =
{
   (Data *)"PR=",
   MGT_PARAM_CONN_PARAM_PR
};

PUBLIC CmAbnfElmDef mgMsgDefPRStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PR_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 473,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefPRStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefOSStrEnum =
{
   (Data *)"OS=",
   MGT_PARAM_CONN_PARAM_OS
};

PUBLIC CmAbnfElmDef mgMsgDefOSStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: OS_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 474,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefOSStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefPSStrEnum =
{
   (Data *)"PS=",
   MGT_PARAM_CONN_PARAM_PS
};

PUBLIC CmAbnfElmDef mgMsgDefPSStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PS_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 475,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefPSStrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefConnParamValChcEnum[] =
{
   &mgMsgDefConnParamNonStdStr,
   &mgMsgDefPSStr,
   &mgMsgDefOSStr,
   &mgMsgDefPRStr,
   &mgMsgDefORStr,
   &mgMsgDefPLStr,
   &mgMsgDefJIStr,
   &mgMsgDefLAStr
};

PUBLIC CmAbnfElmDef *mgMsgDefConnParamValChcElmnt[] =
{
   &mgMsgDefConnParamNonStd,
   &mgMsgDefConnParVal,
   &mgMsgDefConnParVal,
   &mgMsgDefConnParVal,
   &mgMsgDefConnParVal,
   &mgMsgDefConnParVal,
   &mgMsgDefConnParVal,
   &mgMsgDefConnParVal
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefConnParamValChc =
{
   8,
   0,
   NULLP,
   mgMsgDefConnParamValChcElmnt,
   mgMsgDefConnParamValChcEnum
};

PUBLIC CmAbnfElmDef mgMsgDefConnParamVal = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PARM_VAL", 
   "R14",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 476,
   sizeof(MgConnParam),   
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefConnParamValChc,
   mgMsgRegExpR14
};

PUBLIC CmAbnfElmDef *mgMsgDefConnParamSeqOfElmnt[] =
{
   &cmMsgDefMetaComma,
   &cmMsgDefOptMetaSpace,
   &mgMsgDefConnParamVal
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefConnParamSeqOf =
{
   1,
   MGT_MAX_CONN_PARAM,
   3,
   mgMsgDefConnParamSeqOfElmnt,
   sizeof(MgConnParam)   
};

PUBLIC CmAbnfElmDef mgMsgDefConnParam = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PARM_SET", 
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 477,
   sizeof(MgConnParamSet),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefConnParamSeqOf,
   cmAbnfRegExpComma 
};

PUBLIC CmAbnfElmDef *mgMsgDefConnParamSetSeqElmnt[] =
{
   &mgMsgDefConnParamVal,
   &mgMsgDefConnParam
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefConnParamSetSeq =
{
   2,
   mgMsgDefConnParamSetSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefConnParamSet = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CONPARM", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 478,
   sizeof(MgConnParamSet),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefConnParamSetSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefCapbGateIdStrEnum =
{
   (Data *)"dq-gi",
   MGT_LCL_CONNOPT_DQOS_GATEID
};

PUBLIC CmAbnfElmDef mgMsgDefCapbGateIdStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: CapbGateId",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 479,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefCapbGateIdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefCapSecretStrEnum =
{
   (Data *)"sc-st",
   MGT_LCL_CONNOPT_SEC_SECRET
};

PUBLIC CmAbnfElmDef mgMsgDefCapSecretStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: CapSecret",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 480,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefCapSecretStrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefCapabilityChcEnum[] =
{
   &mgMsgDefNonStdConnOptValStr,                /*  0 */
   &mgMsgDefPktzPeriodStr,                      /*  1 */
   &mgMsgDefBwStr,                              /*  2 */
   &mgMsgDefAlgoStr,                            /*  3 */
   &mgMsgDefECancelStr,                         /*  4 */
   &mgMsgDefSilSuppStr,                         /*  5 */
   &mgMsgDefGainCtrlStr,                        /*  6 */
   &mgMsgDefTOSStr,                             /*  7 */
   &mgMsgDefRsRsvStr,                           /*  8 */
   &mgMsgDefTONStr,                             /*  9 */
   &mgMsgDefEncryptInfoStr,                     /* 10 */
   &mgMsgDefSuppModesStr,                       /* 11 */
   &mgMsgDefSuppPkgsStr,                        /* 12 */
   &mgMsgDefCapbGateIdStr,                      /* 13 */
   &mgMsgDefDqosRsrcRsvStr,                     /* 14 */
   &mgMsgDefDqosRsrcIdStr,                      /* 15 */
   &mgMsgDefDqosRsvDestStr,                     /* 16 */
   &mgMsgDefCapSecretStr,                       /* 17 */
   &mgMsgDefSecRtpSuiteStr,                     /* 18 */
   &mgMsgDefSecRtcpSuiteStr,                    /* 19 */
#ifdef GCP_VER_1_3
   &mgMsgDefOptFmtpSetStr ,                  /* 20 */
   &mgMsgDefFmtpSetStr ,                     /* 21 */
   &mgMsgDefRsResDirStr ,                    /* 22 */
   &mgMsgDefRsResCnfStr ,                    /* 23 */
   &mgMsgDefRsResShStr ,                     /* 24 */
#endif
};

PUBLIC CmAbnfElmDef *mgMsgDefCapabilityChcElmnt[] =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefStdConnOptVal,                      /*  0 */
#else
   &mgMsgDefNonStdConnOptVal,                   /*  0 */
#endif
   &mgMsgDefPktzPeriod,                         /*  1 */
   &mgMsgDefBw,                                 /*  2 */
   &mgMsgDefAlgoNameSet,                        /*  3 */
   &mgMsgDefOnOff,                              /*  4 */
   &mgMsgDefOnOff,                              /*  5 */
   &mgMsgDefGainCtrl,                           /*  6 */

/* change */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefMarkedTOS,                          /*  7 */
#else
   &mgMsgDefTOS,                                /*  7 */
#endif

   &mgMsgDefRsRsv,                              /*  8 */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefChoiceTON ,
#else
   &mgMsgDefTON,                                /*  9 */
#endif
   &mgMsgDefEncryptInfo,                        /* 10 */
   &mgMsgDefSuppModes,                          /* 11 */
   &mgMsgDefSuppPkgs,                           /* 12 */
   NULLP,                                       /* 13 */
   &mgMsgDefDqosRsrcRsv,                        /* 14 */
   &mgMsgDefDqosResourceId,                     /* 15 */
   &mgMsgDefDqosRsvDest,                        /* 16 */
   NULLP,                                       /* 17 */
   &mgMsgDefSecRtpRtcpSuite,                    /* 18 */
   &mgMsgDefSecRtpRtcpSuite,                    /* 19 */
#ifdef GCP_VER_1_3
   &mgMsgDefLclFmtp ,                           /* 20 */
   &mgMsgDefLclFmtp ,                           /* 21 */
   &mgMsgDefLclRsRsvDir ,                       /* 22 */
   &mgMsgDefLclRsRsvCnf ,                       /* 23 */
   &mgMsgDefLclRsSh ,                           /* 24 */

#endif
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefCapabilityChc =
{
#ifdef GCP_VER_1_3
   25,
#else
   20,
#endif
   0,
   NULLP,
   mgMsgDefCapabilityChcElmnt,
   mgMsgDefCapabilityChcEnum,
};

PUBLIC CmAbnfElmDef mgMsgDefCapability =
{
#ifdef CM_ABNF_DBG
   "MGCP: Capability",
   "RAlmost29",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 481,
   sizeof(MgLclConnOpts),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefCapabilityChc,
   mgMsgRegExpRAlmost29
};


PUBLIC CmAbnfElmDef *mgMsgDefCapabilityOptSeqElmnt[] =
{
   &mgMsgDefCapability,
   &cmMsgDefOptMetaSpace
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefCapabilityOptSeq =
{
   2,
   mgMsgDefCapabilityOptSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefCapabilityOpt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: LCCONPT", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 482,
   sizeof(MgLclConnOpts),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefCapabilityOptSeq,
   NULLP
};


PUBLIC CmAbnfElmDef *mgMsgDefCapabilitySetSeqOfElmnt[] =
{
   &cmMsgDefOptMetaSpace,
   &cmMsgDefMetaComma,
   &cmMsgDefOptMetaSpace,
   &mgMsgDefCapabilityOpt,
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefCapabilitySetSeqOf =
{
   1,
   MGT_MAX_CONN_PARAM,
   4,
   mgMsgDefCapabilitySetSeqOfElmnt,
   sizeof(MgLclConnOpts)
};

PUBLIC CmAbnfElmDef mgMsgDefCapabilitySet =
{
#ifdef CM_ABNF_DBG
   "MGCP: CapabilitySet",
   "ROptSpaceComma",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 483,
   sizeof(MgLclConnOptSet),
   CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefCapabilitySetSeqOf,
   mgMsgRegExpROptSpaceComma
};

PUBLIC CmAbnfElmDef *mgMsgDefCapabilitiesSeqElmnt[] =
{
   &mgMsgDefCapabilityOpt,
   &mgMsgDefCapabilitySet
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefCapabilitiesSeq =
{
   2,
   mgMsgDefCapabilitiesSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefCapabilities =
{
#ifdef CM_ABNF_DBG
   "MGCP: CAPABILITIES",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 484,
   sizeof(MgLclConnOptSet),
   CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefCapabilitiesSeq,
   NULLP
};



/************************************************************************
               Database element for Reason Code  
************************************************************************/
PUBLIC CmAbnfElmTypeRange mgMsgDefRsParamRng = {1,0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefRsParam = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSPARM ",
   "CM_RSTR",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 485,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefRsParamRng,
   cmAbnfRegExpStrChar
};

PUBLIC CmAbnfElmDef *mgMsgDefRsOptParamSeqElmnt[] =
{
   &cmMsgDefMetaSpace,
   &mgMsgDefRsParam
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefRsOptParamSeq =
{
   2,
   mgMsgDefRsOptParamSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefRsOptParam = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSPARM ",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 486,
   sizeof(TknStrOSXL),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefRsOptParamSeq,
   cmAbnfRegExpSpace
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMsgDefRsCodeRng = {3, 3, 0, (U32)999};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefRsCodeRng = {3,3};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMsgDefRsCode = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CODE ",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 487,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&mgMsgDefRsCodeRng,
   cmAbnfRegExpDgt
};


#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))


PUBLIC CmAbnfElmDef  *mgMsgDefRsCdOptPkgNameSeqSeqElmnts[] =
{
    &cmMsgDefMetaSpace ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgNameString
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefRsCdOptPkgNameSeqSeq =
{
    3 ,
    mgMsgDefRsCdOptPkgNameSeqSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefRsCdOptPkgNameSeq =
{
#ifdef  CM_ABNF_DBG
    "RsCdOptPkgNameSeq" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 488,
    sizeof (MgPkgName) ,
    ( CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefRsCdOptPkgNameSeqSeq ,
    mgMsgRegExpSpSlash
};

#endif


PUBLIC CmAbnfElmDef *mgMsgDefReasonCodeSeqElmnt[] =
{
   &cmMsgDefOptMetaSpace,
   &mgMsgDefRsCode,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefRsCdOptPkgNameSeq,
#endif
   &mgMsgDefRsOptParam
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefReasonCodeSeq =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   4,
#else
   3,                   
#endif
   mgMsgDefReasonCodeSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefReasonCode = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSCODE ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 489,
   sizeof(MgReasonCode),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefReasonCodeSeq,
   NULLP
};

/************************************************************************
       Database element for Specific EndPoint Id/Second Endpoint Id  
************************************************************************/
PUBLIC CmAbnfElmTypeRange mgMsgDefLcEndptNameRng = { 1, 0xFFFF}; 

PUBLIC CmAbnfElmDef mgMsgDefLcEndptName = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EPTNAME ",
   "R12",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 490,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefLcEndptNameRng,
   mgMsgRegExpR12
};

PUBLIC CmAbnfElmDef *mgMsgDefEpNameSeqElmnt[] =
{
   &mgMsgDefLcEndptName,
   &cmMsgDefMetaAt,
   &mgMsgDefDomainName
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefEpNameSeq =
{
   3,
   mgMsgDefEpNameSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefEpName = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EPNAME",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 491,
   sizeof(MgEPName),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefEpNameSeq,
   NULLP
};


#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
PUBLIC CmAbnfElmDef mgMsgDefEpNameOpt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EPNAME OPT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 492,
   sizeof(MgEPName),
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefEpNameSeq,
   mgMsgRegExpChkParamPres
};
#endif

/************************************************************************
               Database element for Requested Information  
************************************************************************/
PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeBEnum =
{
   (Data *)"B",
   MGT_INFO_CODE_B
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeB = 
{
#ifdef CM_ABNF_DBG
   "MGCP: B", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 493,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeBEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeCEnum =
{
   (Data *)"C",
   MGT_INFO_CODE_C
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeC = 
{
#ifdef CM_ABNF_DBG
   "MGCP: C", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 494,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeCEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeIEnum =
{
   (Data *)"I",
   MGT_INFO_CODE_I
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeI = 
{
#ifdef CM_ABNF_DBG
   "MGCP: I", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 495,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeIEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeNEnum =
{
   (Data *)"N",
   MGT_INFO_CODE_N
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeN = 
{
#ifdef CM_ABNF_DBG
   "MGCP: N", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 496,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeNEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeXEnum =
{
   (Data *)"X",
   MGT_INFO_CODE_X
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeX = 
{
#ifdef CM_ABNF_DBG
   "MGCP: X", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 497,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeXEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeLEnum =
{
   (Data *)"L",
   MGT_INFO_CODE_L
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeL = 
{
#ifdef CM_ABNF_DBG
   "MGCP: L", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 498,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeLEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeMEnum =
{
   (Data *)"M",
   MGT_INFO_CODE_M
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeM = 
{
#ifdef CM_ABNF_DBG
   "MGCP: M", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 499,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeMEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeREnum =
{
   (Data *)"R",
   MGT_INFO_CODE_R
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeR = 
{
#ifdef CM_ABNF_DBG
   "MGCP: R", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 500,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeREnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeSEnum =
{
   (Data *)"S",
   MGT_INFO_CODE_S
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeS = 
{
#ifdef CM_ABNF_DBG
   "MGCP: S", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 501,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeSEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeDEnum =
{
   (Data *)"D",
   MGT_INFO_CODE_D
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeD = 
{
#ifdef CM_ABNF_DBG
   "MGCP: D", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 502,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeDEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeOEnum =
{
   (Data *)"O",
   MGT_INFO_CODE_O
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeO = 
{
#ifdef CM_ABNF_DBG
   "MGCP: O", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 503,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeOEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodePEnum =
{
   (Data *)"P",
   MGT_INFO_CODE_P
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeP = 
{
#ifdef CM_ABNF_DBG
   "MGCP: P", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 504,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodePEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeEEnum =
{
   (Data *)"E",
   MGT_INFO_CODE_E
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeE = 
{
#ifdef CM_ABNF_DBG
   "MGCP: E", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 505,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeEEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeZEnum =
{
   (Data *)"Z",
   MGT_INFO_CODE_Z
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeZ = 
{
#ifdef CM_ABNF_DBG
   "MGCP: Z", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 506,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeZEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeQEnum =
{
   (Data *)"Q",
   MGT_INFO_CODE_Q
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeQ = 
{
#ifdef CM_ABNF_DBG
   "MGCP: Q", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 507,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeQEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeTEnum =
{
   (Data *)"T",
   MGT_INFO_CODE_T
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeT = 
{
#ifdef CM_ABNF_DBG
   "MGCP: T", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 508,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeTEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeRCEnum =
{
   (Data *)"RC",
   MGT_INFO_CODE_RC
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeRC = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RC", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 509,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeRCEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeLCEnum =
{
   (Data *)"LC",
   MGT_INFO_CODE_LC
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeLC = 
{
#ifdef CM_ABNF_DBG
   "MGCP: LC", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 510,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeLCEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeAEnum =
{
   (Data *)"A",
   MGT_INFO_CODE_A
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeA = 
{
#ifdef CM_ABNF_DBG
   "MGCP: A", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 511,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeAEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeESEnum =
{
   (Data *)"ES",
   MGT_INFO_CODE_ES
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeES =
{
#ifdef CM_ABNF_DBG
   "MGCP: ES", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 512,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeESEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeRMEnum =
{
   (Data *)"RM",
   MGT_INFO_CODE_RM
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeRM = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RM", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 513,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeRMEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeRDEnum =
{
   (Data *)"RD",
   MGT_INFO_CODE_RD
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeRD = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RD", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 514,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeRDEnum,
   NULLP
};


#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodePLEnum =
{
   (Data *)"PL",
   MGT_INFO_CODE_PL
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodePL = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RD", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 514,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodePLEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeMDEnum =
{
   (Data *)"MD",
   MGT_INFO_CODE_MD
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeMD = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RD", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 514,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeMDEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoCodeExtnEnumDef =
{
   NULLP,
   MGT_INFO_CODE_EXTN
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCodeExtnEnum = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RD", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 515,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoCodeExtnEnumDef,
   NULLP
};
#endif


#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
PUBLIC CmAbnfElmDef *mgMsgDefReqInfoCodeChcDefs[] =
{
   NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,
   NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,
   &mgMsgDefExtnParam
};
#endif

PUBLIC CmAbnfElmDef *mgMsgDefReqInfoCodeChcElmnt[] =
{
   NULLP,
   &mgMsgDefReqInfoCodeB,
   &mgMsgDefReqInfoCodeC,
   &mgMsgDefReqInfoCodeI,
   &mgMsgDefReqInfoCodeN,
   &mgMsgDefReqInfoCodeX,
   &mgMsgDefReqInfoCodeL,
   &mgMsgDefReqInfoCodeM,
   &mgMsgDefReqInfoCodeR,
   &mgMsgDefReqInfoCodeS,
   &mgMsgDefReqInfoCodeD,
   &mgMsgDefReqInfoCodeO,
   &mgMsgDefReqInfoCodeP,
   &mgMsgDefReqInfoCodeE,
   &mgMsgDefReqInfoCodeZ,
   &mgMsgDefReqInfoCodeQ,
   &mgMsgDefReqInfoCodeT,
   &mgMsgDefReqInfoCodeRC,
   &mgMsgDefReqInfoCodeLC,
   &mgMsgDefReqInfoCodeA,
   &mgMsgDefReqInfoCodeES,
   &mgMsgDefReqInfoCodeRM,
   &mgMsgDefReqInfoCodeRD,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefReqInfoCodePL,
   &mgMsgDefReqInfoCodeMD,
   &mgMsgDefReqInfoCodeExtnEnum,
#endif
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefReqInfoCodeChc =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   26,
#else
   23,
#endif
   0,
   NULLP,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   mgMsgDefReqInfoCodeChcDefs ,
#else
   NULLP,
#endif
   mgMsgDefReqInfoCodeChcElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoCode = 
{
#ifdef CM_ABNF_DBG
   "MGCP:CODE", 
   "MGCP: R11",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 516,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   sizeof(InfoCode),
#else
   sizeof(TknU8),   
#endif
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefReqInfoCodeChc,
   mgMsgRegExpR11
};

PUBLIC CmAbnfElmDef *mgMsgDefReqInfoSeqOfElmnt[] =
{
   &cmMsgDefMetaComma,
   &cmMsgDefOptMetaSpace,  
   &mgMsgDefReqInfoCode
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefReqInfoSeqOf =
{
   1,
   MGT_MAX_INFO_CODE,
   3,
   mgMsgDefReqInfoSeqOfElmnt,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   sizeof(InfoCode),
#else
   sizeof(TknU8)  
#endif
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfo = 
{
#ifdef CM_ABNF_DBG
   "MGCP: REQINFO_SET", 
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 517,
   sizeof(MgRqstdInfo),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefReqInfoSeqOf,
   cmAbnfRegExpComma
};

PUBLIC CmAbnfElmDef *mgMsgDefReqInfoSetSeqOfElmnt[] =
{
   &mgMsgDefReqInfoCode,
   &mgMsgDefReqInfo
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefReqInfoSetSeqOf =
{
   2,
   mgMsgDefReqInfoSetSeqOfElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoSet = 
{
#ifdef CM_ABNF_DBG
   "MGCP: REQINFO", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 518,
   sizeof(MgRqstdInfo),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefReqInfoSetSeqOf,
   NULLP
};

/************************************************************************
               Database element for Quarantine Handle 
************************************************************************/
PUBLIC CmAbnfElmTypeEnum mgMsgDefQrntCntrlStepEnum =
{
   (Data *)"step",
   MGT_QRNT_STEP
};

PUBLIC CmAbnfElmDef mgMsgDefQrntCntrlStep = 
{
#ifdef CM_ABNF_DBG
   "MGCP: QSTEP", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 519,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefQrntCntrlStepEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefQrntCntrlLoopEnum =
{
   (Data *)"loop",
   MGT_QRNT_LOOP 
};

PUBLIC CmAbnfElmDef mgMsgDefQrntCntrlLoop = 
{
#ifdef CM_ABNF_DBG
   "MGCP: QLOOP", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 520,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefQrntCntrlLoopEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefQrntCntrlProcessEnum =
{
   (Data *)"process",
   MGT_QRNT_PROCESS 
};

PUBLIC CmAbnfElmDef mgMsgDefQrntCntrlProcess = 
{
#ifdef CM_ABNF_DBG
   "MGCP: QPROC", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 521,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefQrntCntrlProcessEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefQrntCntrlDiscardEnum =
{
   (Data *)"discard",
   MGT_QRNT_DISCARD 
};

PUBLIC CmAbnfElmDef mgMsgDefQrntCntrlDiscard = 
{
#ifdef CM_ABNF_DBG
   "MGCP: QDISC", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 522,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefQrntCntrlDiscardEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefQrntCntrlTypeChcElmnt[] =
{
   NULLP,
   &mgMsgDefQrntCntrlStep,
   &mgMsgDefQrntCntrlLoop,
   &mgMsgDefQrntCntrlProcess,
   &mgMsgDefQrntCntrlDiscard
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefQrntCntrlTypeChc =
{
   5,
   0,
   NULLP,
   NULLP,
   mgMsgDefQrntCntrlTypeChcElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefQrntCntrlType = 
{
#ifdef CM_ABNF_DBG
   "MGCP: QCTRLTP", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 523,
   sizeof(TknU8),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefQrntCntrlTypeChc,
   mgMsgRegExpR10
};

PUBLIC CmAbnfElmDef *mgMsgDefQrntHndlSetSeqOfElmt[] =
{
   &cmMsgDefMetaComma,
   &cmMsgDefOptMetaSpace,  
   &mgMsgDefQrntCntrlType
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefQrntHndlSetSeqOf =
{
   1,
   MGT_MAX_QRNT_CNTRL,
   3,
   mgMsgDefQrntHndlSetSeqOfElmt,
   sizeof(TknU8)  
};

PUBLIC CmAbnfElmDef mgMsgDefQrntHndlSet = 
{
#ifdef CM_ABNF_DBG
   "MGCP: QCTRL_SET", 
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 524,
   sizeof(MgQrntHandling),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefQrntHndlSetSeqOf,
   cmAbnfRegExpComma 
};

PUBLIC CmAbnfElmDef *mgMsgDefQrntHndlSeqOfElmnt[] =
{
   &mgMsgDefQrntCntrlType,
   &mgMsgDefQrntHndlSet
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefQrntHndlSeqOf =
{
   2,
   mgMsgDefQrntHndlSeqOfElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefQrntHndl = 
{
#ifdef CM_ABNF_DBG
   "MGCP: QRNT", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 525,
   sizeof(MgQrntHandling),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefQrntHndlSeqOf,
   NULLP 
};
/************************************************************************
               Database element for Detected Event 
************************************************************************/
PUBLIC CmAbnfElmDef *mgMsgDefEventNameSetSeqOfElmt[] =
{
   &cmMsgDefMetaComma,
   &mgMsgDefEventName
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefEventNameSetSeqOf =
{
   1,
   MGT_MAX_UNKNWON,
   2,
   mgMsgDefEventNameSetSeqOfElmt,
   sizeof(MgEvntName)
};

PUBLIC CmAbnfElmDef mgMsgDefEventNameSet = 
{
#ifdef CM_ABNF_DBG
   "MGCP: TNAME_SET", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 526,
   sizeof(MgDetectEvent),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefEventNameSetSeqOf,
   cmAbnfRegExpComma 
};

PUBLIC CmAbnfElmDef *mgMsgDefDetEvntSeqOfElmnt[] =
{
   &mgMsgDefEventName,
   &mgMsgDefEventNameSet
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefDetEvntSeqOf =
{
   2,
   mgMsgDefDetEvntSeqOfElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefDetEvnts = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DETEVT", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 527,
   sizeof(MgDetectEvent),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMsgDefDetEvntSeqOf,
   NULLP
};

/************************************************************************
               Database element for Restart Method 
************************************************************************/
PUBLIC CmAbnfElmTypeEnum mgMsgDefMethodGracefulEnum =
{
   (Data *)"graceful",
   MGT_PARAM_RSTRT_GRACE
};

PUBLIC CmAbnfElmDef mgMsgDefMethodGraceful = 
{
#ifdef CM_ABNF_DBG
   "MGCP: GRACE", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 528,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefMethodGracefulEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefMethodForcedEnum =
{
   (Data *)"forced",
   MGT_PARAM_RSTRT_FORCE
};

PUBLIC CmAbnfElmDef mgMsgDefMethodForced = 
{
#ifdef CM_ABNF_DBG
   "MGCP: FORCED", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 529,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefMethodForcedEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefMethodRstrtEnum =
{
   (Data *)"restart",
   MGT_PARAM_RSTRT_RSTRT
};

PUBLIC CmAbnfElmDef mgMsgDefMethodRstrt = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSTRT", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 530,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefMethodRstrtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefMethodDiscEnum =
{
   (Data *)"disconnected",
   MGT_PARAM_RSTRT_DISC
};

PUBLIC CmAbnfElmDef mgMsgDefMethodDisc = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DISC", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 531,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefMethodDiscEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefMethodCancelGrcFulEnum =
{
   (Data *)"cancel-graceful",
   MGT_PARAM_RSTRT_CANCL_GRCFUL
};

PUBLIC CmAbnfElmDef mgMsgDefMethodCancelGrcful = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DISC", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 532,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefMethodCancelGrcFulEnum,
   NULLP
};

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))


PUBLIC CmAbnfElmTypeEnum mgMsgDefMethodExtnEnumDef =
{
   NULLP,
   MGT_PARAM_RSTRT_EXTN_METHOD
};

PUBLIC CmAbnfElmDef mgMsgDefMethodExtn = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DISC", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 533,
   sizeof(TknU8),   
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefMethodExtnEnumDef ,
   NULLP
};
#endif

PUBLIC CmAbnfElmDef *mgMsgDefMethodChcElmnt[] =
{
   NULLP,
   &mgMsgDefMethodGraceful,
   &mgMsgDefMethodForced,
   &mgMsgDefMethodRstrt,
   &mgMsgDefMethodDisc,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefMethodCancelGrcful,
   &mgMsgDefMethodExtn,
#endif
};

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
 
 PUBLIC CmAbnfElmDef  *mgMsgDefPkgExtnRMTreeChcElmnt[] =
 {
     &mgMsgDefPkgExtnParamUnkownPkgExtnName ,
 };
 
/*
 * [TEL]: Enhanced to MGT_MGCP_PKG_MAX
 */ 
PUBLIC U8  mgMsgDefPkgExtnRMTreeIdx[] = { 0,0,0,0,0, 0,0,0,0,0, 0,0,0,
                                          0,0,0,0,0, 0,0,0,0,0, 0,0,0, 0,0,0, 
                                          0,0,0,0,0,0};

 PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgExtnRMTreeChc =
 {
     1 ,
     MGT_MGCP_PKG_MAX,
     mgMsgDefPkgExtnRMTreeIdx,
     mgMsgDefPkgExtnRMTreeChcElmnt ,
     NULLP ,
 };
 
 PUBLIC CmAbnfElmDef  mgMsgDefPkgExtnRMTree =
 {
 #ifdef  CM_ABNF_DBG
     "MGCP: PKG EXTN PARAM TREE " ,
     "ExtnParamPkgExtnNames" ,
 #endif
     CM_ABNF_ELMNID_MG_BASE + 534,
     sizeof(MgMgcpPkgSpcExtnParam) ,
     ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
     CM_ABNF_TYPE_CHOICE ,
     (U8 *) &mgMsgDefPkgExtnRMTreeChc ,
     mgMsgRegExpPackageName
 };

PUBLIC CmAbnfElmDef  *mgMsgDefPkgExtnRMSeqElmnts[] =
{
    &mgMsgDefPkgExtnRMTree
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgExtnRMSeq =
{
    1 ,
    mgMsgDefPkgExtnRMSeqElmnts
};


PUBLIC CmAbnfElmDef  mgMsgDefPkgExtnRM =
{
#ifdef  CM_ABNF_DBG
    "PkgExtnParam" ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 535,
    sizeof (MgMgcpPkgSpcExtnParam ) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgExtnRMSeq ,
    NULLP
};


PUBLIC CmAbnfElmDef *mgMsgDefMethodChcDefs[] =
{
   NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,
   &mgMsgDefPkgExtnRM
};
#endif

PUBLIC CmAbnfElmTypeChoice mgMsgDefMethodChc =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   7,
#else
   6,
#endif
   0,
   NULLP,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   mgMsgDefMethodChcDefs,
#else
   NULLP,
#endif
   mgMsgDefMethodChcElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefRstrtMethod = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RM ", 
   "R9",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 536,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   sizeof(MgRsrtMethod),
#else
   sizeof(TknU8),   
#endif
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefMethodChc,
   mgMsgRegExpR9
};

/************************************************************************
               Database element for Restart Delay 
************************************************************************/
#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMsgDefRstrtDelayRng = {1, 6, 0, (U32)999999};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefRstrtDelayRng = {1,6};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMsgDefRstrtDelay =
{
#ifdef CM_ABNF_DBG
   "CM: RSTRDELY",
   "RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 537,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMsgDefRstrtDelayRng,
   cmAbnfRegExpDgt
};

/************************************************************************
               Database element for Non Standard Parameters 
************************************************************************/
PUBLIC CmAbnfElmTypeRange mgMsgDefParmExtNameRng = {1,6};

PUBLIC CmAbnfElmDef mgMsgDefParmExtName =
{
#ifdef CM_ABNF_DBG
   "CM: NONSTDPARAM",
   "R8",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 538,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefParmExtNameRng,
   mgMsgRegExpR8
};

PUBLIC CmAbnfElmTypeRange mgMsgDefParmExtValRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefParmExtVal =
{
#ifdef CM_ABNF_DBG
   "CM: NONSTDPARAM",
   "RSTRCHAR",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 539,
   sizeof(TknStrOSXL),
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   (CM_ABNF_OPTIONAL),
#else
   (CM_ABNF_MANDATORY),
#endif
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefParmExtValRng,
   cmAbnfRegExpStrChar
};

PUBLIC CmAbnfElmDef *mgMsgDefNonStdParmSeqElmnt[] =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefExtnParam,
#else
   &mgMsgDefNonStdType,
   &mgMsgDefParmExtName,
#endif
   &cmMsgDefMetaColon,
   &cmMsgDefOptMetaSpace,
   &mgMsgDefParmExtVal
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefNonStdParmSeq =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   4,
#else
   5,
#endif
   mgMsgDefNonStdParmSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefNonStdParam = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NONSTD_VAL", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 540,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   sizeof(MgMgcpParamExtn),
#else
   sizeof(MgNonStdExtn),   
#endif
   (CM_ABNF_MANDATORY),
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   CM_ABNF_TYPE_OPTSEQ,
#else
   CM_ABNF_TYPE_SEQ,
#endif
   (U8 *)&mgMsgDefNonStdParmSeq,
   NULLP
};

/************************************************************************
               Database element for Command parameters
************************************************************************/
PUBLIC CmAbnfElmTypeEnum mgMsgDefNonStdParmStrEnum =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   NULLP,
#else
   (Data *)"X",
#endif
   MGT_PARAM_NON_STD   
};

PUBLIC CmAbnfElmDef mgMsgDefNonStdParmStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: XPARM_STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 541,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefNonStdParmStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefEvntStatesStrEnum =
{
   (Data *)"ES:",
   MGT_PARAM_EVNTSTATES
};

PUBLIC CmAbnfElmDef mgMsgDefEvntStatesStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ES_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 542,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEvntStatesStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefCapabilitiesStrEnum =
{
   (Data *)"A:",
   MGT_PARAM_CAPABILITIES
};

PUBLIC CmAbnfElmDef mgMsgDefCapabilitiesStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: A_STR" ,
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 543,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefCapabilitiesStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefDetEvntsStrEnum =
{
   (Data *)"T:",
   MGT_PARAM_DETECT_EVENT
};

PUBLIC CmAbnfElmDef mgMsgDefDetEvntsStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: T_STR" ,
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 544,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefDetEvntsStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefRstrtDelayStrEnum =
{
   (Data *)"RD:",
   MGT_PARAM_RSTRT_DELAY
};

PUBLIC CmAbnfElmDef mgMsgDefRstrtDelayStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RD_STR" ,
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 545,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefRstrtDelayStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefRstrtMethodStrEnum =
{
   (Data *)"RM:",
   MGT_PARAM_RSTRT_METHOD
};

PUBLIC CmAbnfElmDef mgMsgDefRstrtMethodStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RM_STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 546,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefRstrtMethodStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefQrntHndlStrEnum =
{
   (Data *)"Q:",
   MGT_PARAM_QRNT_HANDLING
};

PUBLIC CmAbnfElmDef mgMsgDefQrntHndlStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: Q_STR", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 547,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefQrntHndlStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqInfoStrEnum =
{
   (Data *)"F:",
   MGT_PARAM_RQSTD_INFO
};

PUBLIC CmAbnfElmDef mgMsgDefReqInfoStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: FSTR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 548,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqInfoStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDef2ndConnIdStrEnum =
{
   (Data *)"I2:",
   MGT_PARAM_SCND_CONNID
};

PUBLIC CmAbnfElmDef mgMsgDef2ndConnIdStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: 2CONID_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 549,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDef2ndConnIdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDef2ndEptIdStrEnum =
{
   (Data *)"Z2:",
   MGT_PARAM_SECND_EPID
};

PUBLIC CmAbnfElmDef mgMsgDef2ndEptIdStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: Z2_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 550,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDef2ndEptIdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefSpfEptIdStrEnum =
{
   (Data *)"Z:",
   MGT_PARAM_SPEC_EPID
};

PUBLIC CmAbnfElmDef mgMsgDefSpfEptIdStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: Z_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 551,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSpfEptIdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReasonCodeStrEnum =
{
   (Data *)"E:",
   MGT_PARAM_REASON
};

PUBLIC CmAbnfElmDef mgMsgDefReasonCodeStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: E_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 552,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReasonCodeStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefConnParamStrEnum =
{
   (Data *)"P:",
   MGT_PARAM_CONN_PARAM
};

PUBLIC CmAbnfElmDef mgMsgDefConnParamStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: P_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 553,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefConnParamStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefObsvEvntsStrEnum =
{
   (Data *)"O:",
   MGT_PARAM_OBS_EVENT
};

PUBLIC CmAbnfElmDef mgMsgDefObsvEvntsStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: O_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 554,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefObsvEvntsStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefDgtMapStrEnum =
{
   (Data *)"D:",
   MGT_PARAM_DGT_MAP
};

PUBLIC CmAbnfElmDef mgMsgDefDgtMapStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: D_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 555,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefDgtMapStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefSigReqStrEnum =
{
   (Data *)"S:",
   MGT_PARAM_SIG_RQST
};

PUBLIC CmAbnfElmDef mgMsgDefSigReqStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: S_STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 556,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefSigReqStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqEvntStrEnum =
{
   (Data *)"R:",
   MGT_PARAM_RQSTD_EVENT
};

PUBLIC CmAbnfElmDef mgMsgDefReqEvntStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: M_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 557,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqEvntStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefConnModeStrEnum =
{
   (Data *)"M:",
   MGT_PARAM_CONN_MODE
};

PUBLIC CmAbnfElmDef mgMsgDefConnModeStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CONMD_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 558,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefConnModeStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefConnOptsStrEnum =
{
   (Data *)"L:",
   MGT_PARAM_LCL_CONNOPTS
};

PUBLIC CmAbnfElmDef mgMsgDefConnOptsStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: LCCON_STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 559,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefConnOptsStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefReqIdStrEnum =
{
   (Data *)"X:",
   MGT_PARAM_RQSTID
};

PUBLIC CmAbnfElmDef mgMsgDefReqIdStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: REQID_STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 560,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefReqIdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefNotifyEntStrEnum =
{
   (Data *)"N:",
   MGT_PARAM_NTFIED_ENT
};

PUBLIC CmAbnfElmDef mgMsgDefNotifyEntStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP NTFY_STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 561,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefNotifyEntStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefConnIdStrEnum =
{
   (Data *)"I:",
   MGT_PARAM_CONNID
};

PUBLIC CmAbnfElmDef mgMsgDefConnIdStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CONID_STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 562,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefConnIdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefCallIdStrEnum =
{
   (Data *)"C:",
   MGT_PARAM_CALLID
};

PUBLIC CmAbnfElmDef mgMsgDefCallIdStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CALLID_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 563,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefCallIdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefBrrInfoStrEnum =
{
   (Data *)"B:",
   MGT_PARAM_BEAR_INFO
};

PUBLIC CmAbnfElmDef mgMsgDefBrrInfoStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: BRRINF_STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 564,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefBrrInfoStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefRspAckStrEnum =
{
   (Data *)"K:",
   MGT_PARAM_RSPACK
};

PUBLIC CmAbnfElmDef mgMsgDefRspAckStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSPACK_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 565,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefRspAckStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefMaxEndptIdsStrEnum =
{
   (Data *)"ZM:",
   MGT_PARAM_MAX_ENDPT_IDS
};

PUBLIC CmAbnfElmDef mgMsgDefMaxEndptIdsStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: MaxEndptIdsStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 566,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefMaxEndptIdsStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefNumEndptIdsStrEnum =
{
   (Data *)"ZN:",
   MGT_PARAM_NUM_ENDPT_IDS
};

PUBLIC CmAbnfElmDef mgMsgDefNumEndptIdsStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NumEndptIdsStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 567,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefNumEndptIdsStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefResourceIdStrEnum =
{
   (Data *)"DQ-RI:",
   MGT_PARAM_RESOURCE_ID
};

PUBLIC CmAbnfElmDef mgMsgDefResourceIdStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: ResourceIdStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 568,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefResourceIdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefVersSupportedStrEnum =
{
   (Data *)"VS:",
   MGT_PARAM_VERSN_SUPRTD
};

PUBLIC CmAbnfElmDef mgMsgDefVersSupportedStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: VersSupportedStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 569,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefVersSupportedStrEnum,
   NULLP
};

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))


PUBLIC CmAbnfElmTypeEnum mgMsgDefPkgListStrEnum =
{
   (Data *)"PL:",
   MGT_PARAM_PACKAGE_LIST
};

PUBLIC CmAbnfElmDef mgMsgDefPkgListStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: VersSupportedStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 570,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefPkgListStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefMaxDataGramStrEnum =
{
   (Data *)"MD:",
   MGT_PARAM_MAX_DATAGRAM
};

PUBLIC CmAbnfElmDef mgMsgDefMaxDataGramStr =
{
#ifdef CM_ABNF_DBG
   "MGCP: MaxDataGramStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 570,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefMaxDataGramStrEnum,
   NULLP
};

#endif

PUBLIC CmAbnfElmDef *mgMsgDefParamValEnum[] =
{
   &mgMsgDefNonStdParmStr,                   /*  0 */
   &mgMsgDefRspAckStr,                       /*  1 */
   &mgMsgDefBrrInfoStr,                      /*  2 */
   &mgMsgDefCallIdStr,                       /*  3 */
   &mgMsgDefConnIdStr,                       /*  4 */
   &mgMsgDefNotifyEntStr,                    /*  5 */
   &mgMsgDefReqIdStr,                        /*  6 */
   &mgMsgDefConnOptsStr,                     /*  7 */
   &mgMsgDefConnModeStr,                     /*  8 */
   &mgMsgDefReqEvntStr,                      /*  9 */
   &mgMsgDefSigReqStr,                       /* 10 */
   &mgMsgDefDgtMapStr,                       /* 11 */
   &mgMsgDefObsvEvntsStr,                    /* 12 */
   &mgMsgDefConnParamStr,                    /* 13 */
   &mgMsgDefReasonCodeStr,                   /* 14 */
   &mgMsgDefSpfEptIdStr,                     /* 15 */
   &mgMsgDef2ndEptIdStr,                     /* 16 */
   &mgMsgDef2ndConnIdStr,                    /* 17 */
   &mgMsgDefReqInfoStr,                      /* 18 */
   &mgMsgDefQrntHndlStr,                     /* 19 */
   &mgMsgDefRstrtMethodStr,                  /* 20 */
   &mgMsgDefRstrtDelayStr,                   /* 21 */
   &mgMsgDefDetEvntsStr,                     /* 22 */
   &mgMsgDefCapabilitiesStr,                 /* 23 */
   &mgMsgDefEvntStatesStr,                   /* 24 */
   &mgMsgDefMaxEndptIdsStr,                  /* 25 */
   &mgMsgDefNumEndptIdsStr,                  /* 26 */
   &mgMsgDefResourceIdStr,                   /* 27 */
   &mgMsgDefVersSupportedStr,                /* 28 */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefPkgListStr,                      /* 29 */
   &mgMsgDefMaxDataGramStr,                  /* 30 */
#endif
};

PUBLIC CmAbnfElmDef *mgMsgDefParamValChcElmnt[] =
{
   &mgMsgDefNonStdParam,                                       /*  0 */
   &mgMsgDefRspAckParam,                                       /*  1 */
   &mgMsgDefBrrInfoParam,                                      /*  2 */
   &mgMsgDefCallId,                                            /*  3 */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefConnIdSetOpt,                                      /*  4 */
#else
   &mgMsgDefConnIdSet,                                      /*  4 */
#endif
   &mgMsgDefNotifyEnt,                                         /*  5 */
   &mgMsgDefReqId,                                             /*  6 */
   &mgMsgDefConnOptsParam,                                     /*  7 */
   &mgMsgDefConnMode,                                          /*  8 */
   &mgMsgDefReqEvntSetOpt,                                        /*  9 */
   &mgMsgDefSigReqSet,                                         /* 10 */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefDgtMapOpt,                                         /* 11 */
#else
   &mgMsgDefDgtMap,                                            /* 11 */
#endif
#ifdef GCP_VER_1_3
   &mgMsgDefObsEvtSet,           /* Observed events */         /* 12 */
#else
   &mgMsgDefSigReqSet,           /* Observed events */         /* 12 */
#endif
   &mgMsgDefConnParamSet,                                      /* 13 */
   &mgMsgDefReasonCode,                                        /* 14 */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefEpNameOpt,                                         /* 15 */
#else
   &mgMsgDefEpName,                                            /* 16 */
#endif
   &mgMsgDefEpName,                                            /* 16 */
   &mgMsgDefConnIdSet,           /* Second connection Id */    /* 17 */
   &mgMsgDefReqInfoSet,                                        /* 18 */
   &mgMsgDefQrntHndl,                                          /* 19 */
   &mgMsgDefRstrtMethod,                                       /* 20 */
   &mgMsgDefRstrtDelay,                                        /* 21 */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefSigReqSet,          /* New DetectEvents defn */    /* 22 */
#else
   &mgMsgDefDetEvnts,                                          /* 22 */
#endif
   &mgMsgDefCapabilities,        /* Capability set */          /* 23 */
   &mgMsgDefSigReqSet,            /* Event states */           /* 24 */
   &mgMsgDefNumEndpts,            /* Max endpoint IDs */       /* 25 */
   &mgMsgDefNumEndpts,            /* Num endpoint IDs */       /* 26 */
   &mgMsgDefDqosResourceId,                                    /* 27 */
   &mgMsgDefVersSupported,                                     /* 28 */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefPkgList,              /* Package List */           /* 29 */
   &mgMsgDefConnParVal,           /* Max MGCP Datagram */      /* 30 */
#endif
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefParamValChc =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   31,
#else
   29,
#endif
   0,
   NULLP,
   mgMsgDefParamValChcElmnt,
   mgMsgDefParamValEnum
};

PUBLIC CmAbnfElmDef mgMsgDefParamVal = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PARM", 
   "R7",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 571,
   sizeof(MgMgcpParam),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefParamValChc,
   mgMsgRegExpR7 
};

PUBLIC CmAbnfElmDef *mgMsgDefParamsSeqOfElmnt[] =
{
   &mgMsgDefParamVal,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeqOf mgMsgDefParamsSeqOf =
{
   0,
   MGT_MAX_UNKNWON,         
   2,
   mgMsgDefParamsSeqOfElmnt,
   sizeof(MgMgcpParam)   
};

PUBLIC CmAbnfElmDef mgMsgDefParams = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PARM_SET ", 
   "R7",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 572,
   sizeof(MgMgcpParamSet),   
   (CM_ABNF_TKN_NOT_CONSUMED|CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMsgDefParamsSeqOf,
   mgMsgRegExpR7 
};

/************************************************************************
               Database element for SDP Information Present
************************************************************************/

PUBLIC CmAbnfElmDef *mgMsgDefSdpInfoPresSeqElmnt[] =
{
   &cmMsgDefMetaEOL,
#ifdef CM_SDP_OPAQUE
   &cmMsgDefSdpTknBuf,
   &cmMsgDefSkipSdpInfo,
#else /* not CM_SDP_OPAQUE */
   &cmMsgDefSkipSdpTknBuf,
   &cmMsgDefSdpBegin,
   &cmMsgDefSdpInfoSet,
   &cmMsgDefSdpEnd
#endif /* CM_SDP_OPAQUE */
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefSdpInfoPresSeq =
{
#ifdef CM_SDP_OPAQUE
   3,
#else /* not CM_SDP_OPAQUE */
   5,
#endif /* CM_SDP_OPAQUE */
   mgMsgDefSdpInfoPresSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefSdpInfoPres = 
{
#ifdef CM_ABNF_DBG
   "MGCP: SDP",
   "CM_REOL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 573,
   sizeof(TknBuf) + sizeof(CmSdpInfoSet),   
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefSdpInfoPresSeq,
   cmAbnfRegExpEOL
};

/************************************************************************
               Database element for Transaction Id
************************************************************************/

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMsgDefTrIdRng = {1, 9, 0, (U32)999999999};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefTrIdRng = {1,9};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMsgDefTrId = 
{
#ifdef CM_ABNF_DBG
   "MGCP: TRID",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 574,
   sizeof(TknU32),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMsgDefTrIdRng,
   cmAbnfRegExpDgt                     /* R6: hole */
};

/************************************************************************
               Database element for Command
************************************************************************/

PUBLIC CmAbnfElmTypeMeta mgMsgDefMGCPKeyStr = {(Data *)"MGCP"}; 

PUBLIC CmAbnfElmDef mgMsgDefMGCPKey = 
{
#ifdef CM_ABNF_DBG
   "MGCP: KEY",
   "R5",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 575,
   0,   
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&mgMsgDefMGCPKeyStr,
   mgMsgRegExpR5
};

PUBLIC CmAbnfElmTypeRange mgMsgDefVerProfileRng = {1,0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefVerProfile = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PROF",
   "R4",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 576,
   sizeof(TknStrOSXL),   
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefVerProfileRng,
   mgMsgRegExpR4
};

PUBLIC CmAbnfElmDef *mgMsgDefMgcpProfileSeqElmnt[] = 
{
   &cmMsgDefMetaSpace,
   &mgMsgDefVerProfile
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefMgcpProfileSeq = 
{
   2, 
   mgMsgDefMgcpProfileSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefMgcpProfileDef = 
{
#ifdef CM_ABNF_DBG
   "MGCP: PROF",
   "R4",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 577,
   sizeof(TknStrOSXL),   
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefMgcpProfileSeq, 
   cmAbnfRegExpSpace
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMsgDefVerMinorRng = {1, 5, 0, (U32)65535};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefVerMinorRng = {1, 5};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMsgDefVerMinor = 
{
#ifdef CM_ABNF_DBG
   "MGCP: MINOR",
   "R2",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 578,
   sizeof(TknU16),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&mgMsgDefVerMinorRng,
   mgMsgRegExpR2
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMsgDefVerMajorRng = {1, 5, 0, (U32)65535};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefVerMajorRng = {1, 5};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMsgDefVerMajor = 
{
#ifdef CM_ABNF_DBG
   "MGCP: MAJOR",
   "R3",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 579,
   sizeof(TknU16),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&mgMsgDefVerMajorRng,
   mgMsgRegExpR3
};

PUBLIC CmAbnfElmDef *mgMsgDefMgcpVerSeqElmnt[] =
{
   &mgMsgDefMGCPKey,
   &cmMsgDefMetaSpace,
   &mgMsgDefVerMinor,
   &cmMsgDefMetaDot,
   &mgMsgDefVerMajor,
   &mgMsgDefMgcpProfileDef  
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefMgcpVerSeq =
{
   6,
   mgMsgDefMgcpVerSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefMgcpVer = 
{
#ifdef CM_ABNF_DBG
   "MGCP: VER",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 580,
   sizeof(MgMgcpVer),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefMgcpVerSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefCmdLineSeqElmnt[] =
{
   &mgMsgDefTrId,
   &cmMsgDefMetaSpace,
   &mgMsgDefEpName,
   &cmMsgDefMetaSpace,
   &mgMsgDefMgcpVer,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefCmdLineSeq =
{
   6,
   mgMsgDefCmdLineSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefCmdLine = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CMDLN",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 581,
   sizeof(MgMgcpCmdLine),
   (CM_ABNF_MANDATORY),  
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefCmdLineSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefCmdSeqElmnt[] =
{
   &cmMsgDefMetaSpace,
   &mgMsgDefCmdLine,
   &mgMsgDefParams,
   &mgMsgDefSdpInfoPres
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefCmdSeq =
{
   4,
   mgMsgDefCmdSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefCmd = 
{
#ifdef CM_ABNF_DBG
   "MGCP: MSGCMD",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 582,
   sizeof(MgMgcpCmd),
   (CM_ABNF_MANDATORY), 
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefCmdSeq,
   NULLP
};


/************************************************************************
               Database element for Message NON standard 

               extensionVerb  = ALPHA 3(ALPHA / DIGIT); 
               experimental starts with X

               The ALPHA part of the above grammar is already
               checked in RE function mgMsgRegExpR1
************************************************************************/

PUBLIC CmAbnfElmTypeRange mgMsgDefNonStdExtnNameRng = {4, 4};

PUBLIC CmAbnfElmDef mgMsgDefNonStdExtnName =
{
#ifdef CM_ABNF_DBG
   "CM: NONSTD",
   "CM_RALDG",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 583,
   sizeof(TknStr8),
   0,
   CM_ABNF_TYPE_OCTSTR8,
   (U8 *)&mgMsgDefNonStdExtnNameRng,
   cmAbnfRegExpAlDgChar
};

/* 
 * For Non Standard Just remove extension name
 * the definition of mgMsgDefCmd begins with removing spaces
 */
PUBLIC CmAbnfElmDef *mgMsgDefNonStdSeqElmnt[] =
{
   &mgMsgDefNonStdExtnName,
   &mgMsgDefCmd
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefNonStdSeq =
{
   2,
   mgMsgDefNonStdSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefNonStd = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NONSTD",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 584,
   sizeof(MgMsgNonStd),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefNonStdSeq,
   NULLP
};

/************************************************************************
               Database element for Message Response 
************************************************************************/
PUBLIC CmAbnfElmTypeRange mgMsgDefRspStrngXLRng = {0,0xFFFF};

PUBLIC CmAbnfElmDef mgMsgDefRspStrngXL =
{
#ifdef CM_ABNF_DBG
   "CM: RSPSTR",
   "CM_RSTRCHAR",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 585,
   sizeof(TknStrOSXL),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMsgDefRspStrngXLRng,
   cmAbnfRegExpStrChar
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMsgDefRspCodeRng = {3, 3, 0, (U32)999};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMsgDefRspCodeRng = {3,3};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMsgDefRspCode=
{
#ifdef CM_ABNF_DBG
   "MG: RSPCODE",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 586,
   sizeof(TknU32),
   0,
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMsgDefRspCodeRng,
   cmAbnfRegExpDgt
};
PUBLIC CmAbnfElmDef *mgMsgDefOptRspStrngXLSeqElmnt[] =
{
   &cmMsgDefMetaSpace,
   &mgMsgDefRspStrngXL,
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefOptRspStrngXLSeq =
{
   2,
   mgMsgDefOptRspStrngXLSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefOptRspStrngXL =
{
#ifdef CM_ABNF_DBG
   "MGCP: optional response string",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + MG_ABNF_NEW_ELMNT_OFFSET + 587,
   sizeof(TknStrOSXL),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMsgDefOptRspStrngXLSeq,
   cmAbnfRegExpSpace
};


#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))

PUBLIC CmAbnfElmDef  *mgMsgDefSdpInfoSetListSeqOfElmnts[] =
{
    &mgMsgDefSdpInfoPres
};

PUBLIC CmAbnfElmTypeSeqOf  mgMsgDefSdpInfoSetListSeqOf =
{
    0 ,
    2 ,
    1 ,
    mgMsgDefSdpInfoSetListSeqOfElmnts ,
    sizeof (MgMgcpSdpInfo)
};

PUBLIC CmAbnfElmDef  mgMsgDefSdpInfoSetList =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP INFO SET LIST " ,
    "cmAbnfRegExpEOL" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 602 ,
    sizeof(MgMgcpSdpInfoSet) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQOF ,
    (U8 *) &mgMsgDefSdpInfoSetListSeqOf ,
    cmAbnfRegExpEOL
};

PUBLIC CmAbnfElmDef  *mgMsgDefSdpInfoSetArraySeqElmnts[] =
{
    &mgMsgDefSdpInfoPres ,
    &mgMsgDefSdpInfoSetList
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefSdpInfoSetArraySeq =
{
    2 ,
    mgMsgDefSdpInfoSetArraySeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefSdpInfoSetArray =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP INFO SET ARRAY " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 603 ,
    sizeof(MgMgcpSdpInfoSet) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQOF ,
    (U8 *) &mgMsgDefSdpInfoSetArraySeq ,
    NULLP
};

#endif


PUBLIC CmAbnfElmDef *mgMsgDefRspSeqElmnt[] =
{
   &mgMsgDefRspCode,
   &cmMsgDefMetaSpace,
   &mgMsgDefTrId,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefRsCdOptPkgNameSeq,
#endif
   &mgMsgDefOptRspStrngXL,
   &cmMsgDefMetaEOL,
   &mgMsgDefParams,
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   &mgMsgDefSdpInfoSetArray
#else
   &mgMsgDefSdpInfoPres
#endif
};

PUBLIC CmAbnfElmTypeSeq mgMsgDefRspSeq =
{
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   8,
#else
   7,
#endif
   mgMsgDefRspSeqElmnt
};

PUBLIC CmAbnfElmDef mgMsgDefRsp = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 588,
   sizeof(MgMgcpRsp), 
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMsgDefRspSeq,
   NULLP
};
/************************************************************************
               Database element for MGCP Message Command
************************************************************************/
PUBLIC CmAbnfElmTypeEnum mgMsgDefNonStdStrEnum =
{
   NULLP,
   MGT_MSG_NONSTD
};

PUBLIC CmAbnfElmDef mgMsgDefNonStdStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NONSTD_STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 589,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefNonStdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefRsipStrEnum =
{
   (Data *)"RSIP",
   MGT_MSG_RSIP
};

PUBLIC CmAbnfElmDef mgMsgDefRsipStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSIP_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 590,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefRsipStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefAucxStrEnum =
{
   (Data *)"AUCX",
   MGT_MSG_AUCX
};

PUBLIC CmAbnfElmDef mgMsgDefAucxStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: AUCX_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 591,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefAucxStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefAuepStrEnum =
{
   (Data *)"AUEP",
   MGT_MSG_AUEP
};

PUBLIC CmAbnfElmDef mgMsgDefAuepStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: AUEP_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 592,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefAuepStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefNtfyStrEnum =
{
   (Data *)"NTFY",
   MGT_MSG_NTFY
};

PUBLIC CmAbnfElmDef mgMsgDefNtfyStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: NTFY_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 593,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefNtfyStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefRqntStrEnum =
{
   (Data *)"RQNT",
   MGT_MSG_RQNT
};

PUBLIC CmAbnfElmDef mgMsgDefRqntStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RQNT_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 594,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM, 
   (U8 *)&mgMsgDefRqntStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefDlcxStrEnum =
{
   (Data *)"DLCX",
   MGT_MSG_DLCX
};

PUBLIC CmAbnfElmDef mgMsgDefDlcxStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: DLCX_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 595,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefDlcxStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefMdcxStrEnum =
{
   (Data *)"MDCX",
   MGT_MSG_MDCX
};

PUBLIC CmAbnfElmDef mgMsgDefMdcxStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: MDCX_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 596,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefMdcxStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefCrcxStrEnum =
{
   (Data *)"CRCX",
   MGT_MSG_CRCX
};

PUBLIC CmAbnfElmDef mgMsgDefCrcxStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: CRCX_STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 597,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefCrcxStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMsgDefEpcfStrEnum =
{
   (Data *)"EPCF",
   MGT_MSG_EPCF
};

PUBLIC CmAbnfElmDef mgMsgDefEpcfStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: EPCF_STR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 598,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefEpcfStrEnum,
   NULLP
};


#ifdef GCP_PKG_MGCP_BASE
PUBLIC CmAbnfElmTypeEnum mgMsgDefMesgStrEnum =
{
   (Data *)"MESG",
   MGT_MSG_MESG
};

PUBLIC CmAbnfElmDef mgMsgDefMesgStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: MESG",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 598,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefMesgStrEnum,
   NULLP
};
#endif /* GCP_PKG_MGCP_BASE */


PUBLIC CmAbnfElmDef *mgMsgDefMsgCmdChcEnum [] =
{
   &mgMsgDefNonStdStr,
   &mgMsgDefEpcfStr,
   &mgMsgDefCrcxStr,
   &mgMsgDefMdcxStr,
   &mgMsgDefDlcxStr,
   &mgMsgDefRqntStr,
   &mgMsgDefNtfyStr,
   &mgMsgDefAuepStr,
   &mgMsgDefAucxStr,
   &mgMsgDefRsipStr,
#ifdef GCP_PKG_MGCP_BASE
   &mgMsgDefMesgStr,
#endif /* GCP_PKG_MGCP_BASE */
};

PUBLIC U8 mgMsgDefCmdChcIdx[] =
   { 0, 1, 1, 1, 1,
     1, 1, 1, 1, 1,
#ifdef GCP_PKG_MGCP_BASE
     1          /* we shall treat MESG as a standard cmd */
#endif /* GCP_PKG_MGCP_BASE */
   };

PUBLIC CmAbnfElmDef *mgMsgDefMsgCmdChcElmnt[] =
{
   &mgMsgDefNonStd,
   &mgMsgDefCmd,
};

PUBLIC CmAbnfElmTypeChoice mgMsgDefMsgCmdChc =
{
   2,
#ifdef GCP_PKG_MGCP_BASE
   11,
#else  /* GCP_PKG_MGCP_BASE */
   10,
#endif /* GCP_PKG_MGCP_BASE */
   mgMsgDefCmdChcIdx,
   mgMsgDefMsgCmdChcElmnt,
   mgMsgDefMsgCmdChcEnum 
};

PUBLIC CmAbnfElmDef mgMsgDefMsgCmd = 
{
#ifdef CM_ABNF_DBG
   "MGCP CMD",
   "R1",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 599,
   ((sizeof(((MgMgcpMsg *)0)->t)) + sizeof(TknU8)),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefMsgCmdChc,
   mgMsgRegExpR1 
};

/************************************************************************
               Database element for MGCP Message Database Root
************************************************************************/
PUBLIC CmAbnfElmTypeEnum mgMsgDefRspStrEnum =
{
   NULLP,
   MGT_MSG_RSP
};

PUBLIC CmAbnfElmDef mgMsgDefRspStr = 
{
#ifdef CM_ABNF_DBG
   "MGCP: RSPSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 600,
   sizeof(TknU8),      
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMsgDefRspStrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMsgDefChcEnum[] =
{
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,
#ifdef GCP_PKG_MGCP_BASE
   NULLP,
#endif /* GCP_PKG_MGCP_BASE */
   &mgMsgDefRspStr,
};

PUBLIC CmAbnfElmDef *mgMsgDefChcElmnt[] =
{
   &mgMsgDefMsgCmd,
   &mgMsgDefRsp
};

PUBLIC U8 mgMsgDefChcIdx[] =
   { 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0,
#ifdef GCP_PKG_MGCP_BASE
     0,      /* MESG Command */
#endif /* GCP_PKG_MGCP_BASE */
     1
   };

PUBLIC CmAbnfElmTypeChoice mgMsgDefChc =
{
   2,
#ifdef GCP_PKG_MGCP_BASE
   12,
#else  /* GCP_PKG_MGCP_BASE */
   11,
#endif /* GCP_PKG_MGCP_BASE */
   mgMsgDefChcIdx,
   mgMsgDefChcElmnt,
   mgMsgDefChcEnum
};

PUBLIC MgMgcpMsg *mgAbnfMgcpMsg;

PUBLIC CmAbnfElmDef mgMsgDef = 
{
#ifdef CM_ABNF_DBG
   "MGCP CMD/RSP",
   "R1",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 601,
   ((sizeof(((MgMgcpMsg *)0)->t)) + sizeof(TknU8)),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMsgDefChc,
   mgMsgRegExpR1 
};

#endif /* GCP_MGCP */

  
/********************************************************************30**

         End of file:     mp_db.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:53:01 2005

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**


*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rm   1. initial release.
1.1+         mg003.101bbk  1. Fixed compilation errors under CM_ABNF_DBG
                              flag
             mg004.101bbk  1. mgMsgDefNonStdSeq needs number of elements
                              to be decoded as 2
             mg005.101bbk  1. Changed mgMsgDefNonStdExtnNameRng from
                              {3,3} to {3,4}
             mg006.101bbk  1. Changed mgMsgDefReqEvnt in 
                              mgMsgDefReqEvntEmbReqEvntSeqElmnt to
                              mgMsgDefReqEvntSet to handle embedded
                              requested events
             mg007.101bbk  1. Added cancel-graceful as a Restart Method
             mg008.101bbk  1. Fixed bug in decoding of Profile when present.
                              The database wasn't decoding MGCP 1.0 NCS 1.0
                              as it didn't expect 1.0 after NCS.
                           2. On encoding path, made sure that encoder
                              puts a white space between MGCP version
                              and profile
             mg009.101bbk  1. Added an optional space in decoding of bearer 
                              attribute list
                           2. Added mgMsgDefPkgSuppString for decoding of 
                              package lists properly
                           3. Added an optional space in decoding of reason 
                              code
                           4. Fixed reference to ReqInfoCodeEnum in 
                              mgMsgDefReqInfoCodeI
                           5. Changed parameter database element from 
                              SignalRequest to SignalRequestSet while 
                              decoding of parameters in 
                              mgMsgDefParamValChcElmnt
/main/2      ---       nct 1. Release 1.2
             mg001.102  sk 1. Added enums for more supported modes.
             mg004.102  sk 1. Added new elements to make Space optional in
                              element mgMsgDefRsp 
             mg008.102  sk 1. Some of elements changed from mandatory to
                              optional.
             mg009.102  vj 1. Change in mgMsgDefReqEvntSet, from mandatory 
                              to optional.
/main/3      ---        ra 1. GCP 1.3 release
             mg001.103  ra 1. Patch for allowing empty eventParameters
                              and empty quoted strings
             mg002.103  ra 1. Patch for interoperating with non Bis compliant
                              peer a la HEXDIGs in type of service.
             mg003.103  ra 1. Added support for MGCP audio server packages.
                           2. Added changes to support the deviant ABNF
                              grammar of this package via use of marked
                              functions in pkg name definations and event
                              parameter definations. This allow to give
                              the complete event parameters in the form
                              of a single string to the MGT user.
             mg004.103  ra 1. Bug fix - now passing the correct structure.
             mg008.103  ra 1. Added code for #else part of GCP_VER_1_3.
/main/4      ---       TEL 1. Added definition for MGCP encoding/decoding 
                              routines for the following MGCP packages.
                              1. Base package. 
                              2. Business phone package. 
                              3. Feature Key package. 
                              4. Display XML package. 
/main/4      ---        ka 1. Changes for Release v 1.4
/main/5      ---      pk   1. GCP 1.5 release
             mg002.105  ps 1. Removed patch reference for 1.3
*********************************************************************91*/
