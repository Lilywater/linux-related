/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**

     Name:     mg_msg.c -

     Type:     C source file

     Desc:     C code for

     File:     mg_msg.c

     Sid:      mg_msg.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:57:09 2005

     Prg:      nct

*********************************************************************21*/
/*
 *     this software may be combined with the following TRILLIUM
 *     software:
 *
 *     part no.                      description
 *     --------    ----------------------------------------------
 *     1000177                      MGCP v 1.2
 */

/* header include files (.h) */
#include "envopt.h"        /* Environment options */
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */


#include "gen.h"           /* General layer */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common Timer Library */
#include "cm_hash.h"       /* Hash library */
#include "cm_llist.h"      /* Doubly Linked List library */
#include "cm_inet.h"       /* Common Sockets Library */
#include "cm_tpt.h"        /* Common Transport Defines */
#include "cm_tkns.h"       /* Common Tokens Defines */
#include "cm_sdp.h"        /* Session Description Protocol Defines */
#include "cm_mblk.h"       /* Common Memory Manager Defines */
#include "cm_abnf.h"       /* Common ABNF  Defines */
#include "cm_dns.h"        /* common DNS library */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#include "mgt.h"           /* MGT Interface Defines */
#include "lmg.h"           /* MGCP Layer Management */
#include "mg_err.h"        /* MGCP Error Codes */
#include "mg.h"            /* MGCP Defines */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer */
#include "ssi.x"           /* System services */
#include "cm5.x"           /* Common Timer Library */
#include "cm_hash.x"       /* Hash library */
#include "cm_llist.x"      /* Doubly Linked List library */
#include "cm_inet.x"       /* Common Sockets Library */
#include "cm_tpt.x"        /* Common Transport Definitions */
#include "cm_tkns.x"       /* Common Tokens Defines */
#include "cm_lib.x"        /* Common library functions */
#include "cm_sdp.x"        /* Session Description Protocol Defines */
#include "cm_mblk.x"       /* Common Memory Manager Defines */
#include "cm_abnf.x"       /* Common ABNF  Defines */
#include "cm_dns.x"        /* common dns library */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#include "mgt.x"           /* MGT Interface Structures */
#ifdef GCP_PROV_MTP3
#include "cm_ss7.x"           /* layer management typedefs for MGCP */
#endif
#include "lmg.x"           /* MGCP Layer Management */
#include "mg.x"            /* MGCP Data Structures */
#ifdef GCP_MGCP
#include "mg_db.x"         /* MGCP ABNF Datbase */
#endif /* GCP_MGCP */

#include "mg_macro.h"

/* MEGACO specific files */
#include "mg_msg.x"

/*mg002.105: Extern moved from mg.x for g++ compilation issue*/
EXTERN S16 mgAllocEventMem ARGS((
       Ptr       *memPtr,
       Size      memSize
    ));
       
EXTERN S16 mgFreeEventMem ARGS((
       Ptr       memPtr
    ));



/*
 * Macros common to this file
 */

#define MG_ACC_CHK_RETVAL(_ret)                          \
{                                                        \
    if(RFAILED == _ret)                                  \
    {                                                    \
        RETVALUE(_ret);                                  \
    }                                                    \
}

#ifdef GCP_MGCO

/*
*
*       Fun:   mgAccFillMgcoVal
*
*       Desc:  If "fill" is TRUE, Auth header needs to be filled, else it is 
*              not reqd. If fill=FALSE, secIdx, seqNum, authData * aLen are 
*              irelevant, and not used.
*
*       Ret:   void
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillMgcoVal
(
CmMemListCp          *memCp,
MgMgcoValue          *val,
MgMgcoAccValInfo     *valInfo
)
#else
PUBLIC S16 mgAccFillMgcoVal(memCp,val,valInfo)
CmMemListCp          *memCp;
MgMgcoValue          *val;
MgMgcoAccValInfo     *valInfo;
#endif
{
    S16           ret = ROK;
    U16           idx;
    Size          size;
    TRC3(mgAccFillMgcoVal);

    MG_ACC_INIT_TOKEN_VALUE(&(val->type), valInfo->valType);

    switch(valInfo->valType)
    {
       case MGT_VALTYPE_ENUM :
          MG_ACC_INIT_TOKEN_VALUE(&(val->u.enume),valInfo->u.enume);
          break;

       case MGT_VALTYPE_UINT32 :
          MG_ACC_INIT_TOKEN_VALUE(&(val->u.decInt),valInfo->u.decInt);
          break;

       case MGT_VALTYPE_HEX_UINT32 :
          MG_ACC_INIT_TOKEN_VALUE(&(val->u.hexInt),valInfo->u.hexInt);
          break;

       case MGT_VALTYPE_OCTSTRXL :
          if(NULLP != valInfo->u.str)
          {
            MG_ACC_INIT_TKNSTROSXL(&(val->u.osxl),valInfo->u.str,valInfo->len);
          }
          else
            ret = RFAILED;
          break;

       case MGT_VALTYPE_TKNBUF :
          MG_ACC_INIT_TOKEN_BUF(&(val->u.mBuf),valInfo->u.buf);
          break;

       case MGT_VALTYPE_SIGNAME:
          /* Fill Pkg ID */
          MG_ACC_INIT_TOKEN_VALUE(&(val->u.sigName.pkg),
                    valInfo->u.sigInfo[0]->pkgId);

          /* Fill Pkg name */
          ret = mgAccFillMgcoName(&(val->u.sigName.name.name),
                    valInfo->u.sigInfo[0]->name.str,
                    valInfo->u.sigInfo[0]->name.len,
                    valInfo->u.sigInfo[0]->name.value);
          if(NULLP != valInfo->u.sigInfo[0]->pkgStr)
          {
             MG_ACC_INIT_TKNSTROSXL(&(val->u.sigName.name.pkgName),
                    valInfo->u.sigInfo[0]->pkgStr,valInfo->u.sigInfo[0]->pkgLen);
          }
          break;

       case MGT_VALTYPE_SIGLST:
          size = (valInfo->numSig * (sizeof(MgMgcoSigName*)));
          MG_ACC_GETMEM((val->u.sigLst.sigs),size,memCp);
          
          for(idx=0;idx<valInfo->numSig;idx++)
          {
             MG_ACC_GETMEM((val->u.sigLst.sigs[idx]),sizeof(MgMgcoSigName),memCp);

             /* Fill Pkg ID */
             MG_ACC_INIT_TOKEN_VALUE(&(val->u.sigLst.sigs[idx]->pkg),
                       valInfo->u.sigInfo[idx]->pkgId);

             /* Fill Pkg Name */
             ret = mgAccFillMgcoName(&(val->u.sigLst.sigs[idx]->name.name),
                       valInfo->u.sigInfo[idx]->name.str,
                       valInfo->u.sigInfo[idx]->name.len,
                       valInfo->u.sigInfo[idx]->name.value);
             MG_ACC_CHK_RETVAL(ret);
             if(NULLP != valInfo->u.sigInfo[idx]->pkgStr)
             {
                MG_ACC_INIT_TKNSTROSXL(&(val->u.sigLst.sigs[idx]->name.pkgName),
                       valInfo->u.sigInfo[idx]->pkgStr,
                       valInfo->u.sigInfo[0]->pkgLen);
              }
          } /* End of for */
          MG_ACC_INIT_TOKEN_VALUE(&(val->u.sigLst.id),valInfo->id);
          MG_ACC_INIT_TOKEN_VALUE(&(val->u.sigLst.numSigs),valInfo->numSig);
          break;

       default :
          RETVALUE(RFAILED);
    }
    RETVALUE(ret);
}

/*
*
*       Fun:   mgAccFillAuthHdr
*
*       Desc:  If "fill" is TRUE, Auth header needs to be filled, else it is 
*              not reqd. If fill=FALSE, secIdx, seqNum, authData * aLen are 
*              irelevant, and not used.
*
*       Ret:   void
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillAuthHdr
(
Bool                 fill,
MgMgcoAuthHdr        *auth,
U32                  secIdx,
U32                  seqNum,
U8                   *authData,
U8                   aLen
)
#else
PUBLIC S16 mgAccFillAuthHdr(fill,auth,secIdx,seqNum,authData,aLen)
Bool                 fill;
MgMgcoAuthHdr        *auth;
U32                  secIdx;
U32                  seqNum;
U8                   *authData;
U8                   aLen;
#endif
{
    TRC3(mgAccFillAuthHdr);

    if(TRUE != fill)
    {
        /* Auth header not present */
        auth->pres.pres = NOTPRSNT;

        /* No auth data */
        MG_ACC_INIT_TKNSTR(&(auth->aData),NULLP,0);
    }
    else
    {
        /* Auth header present. check val */
        MG_ACC_INIT_TOKEN_VALUE(&(auth->pres),1);

        /* Set the security param index */
        MG_ACC_INIT_TOKEN_VALUE(&(auth->spi),secIdx);

        /* Set the sequence number */
        MG_ACC_INIT_TOKEN_VALUE(&(auth->sn),seqNum);

        /* Initialize to auth data provided */
        MG_ACC_INIT_TKNSTR(&(auth->aData),authData,aLen);
    }

    RETVALUE(ROK);
}




/*
*
*       Fun:   mgAccFillVersion
*
*       Desc:  If "fill" is TRUE, version needs to be filled, else it is ignored
*
*       Ret:   void
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillVersion
(
Bool                 fill,
MgMgcoVersion        *version,
U8                   verNo
)
#else
PUBLIC S16 mgAccFillVersion(fill,version,verNo)
Bool                 fill;
MgMgcoVersion        *version;
U8                   verNo;
#endif
{
    TRC3(mgAccFillVersion);

    if(TRUE != fill)
    {
        /* Version info not present */
        version->pres = NOTPRSNT;
        version->val = 0;
    }
    else
    {
        MG_ACC_INIT_TOKEN_VALUE(version,verNo);
    }

    RETVALUE(ROK);
}



/*
*
*       Fun:   mgAccFillMid
*
*       Desc:  If "fill" is TRUE, MID needs to be filled, else it is ignored
*              Memory for all U8* parameters is allocated by the calling function
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillMid
(
MgMgcoMid            *mid,
U8                   midType,
U8                   addrType,/* addr type. Valid only for IP addr- IP4/IP6 */
U16                  addrLen, /* length of *addr field */
U8                   *addr,   /* IP addr/domain name/MTP addr/path domain name*/
U8                   *lcl,    /* lcl name, valid when midType=MGT_MID_DEVICE */
U16                  lclLen,  /* Local name length, only when lcl!=NULLP */
Bool                 prtPres, /* Port is present or not */
U16                  port
)
#else
PUBLIC S16 mgAccFillMid(mid,midType,addrType,addrLen,addr,lcl,lclLen,prtPres,port)
MgMgcoMid            *mid;
U8                   midType;
U8                   addrType;
U16                  addrLen;
U8                   *addr;  
U8                   *lcl; 
U16                  lclLen;
Bool                 prtPres; 
U16                  port;
#endif
{
    TRC3(mgAccFillMid);

    /* Initialise */
    mid->type.pres = NOTPRSNT;
    mid->type.val = 0;

    switch (midType)
    {
        case MGT_MID_DADDRPORT :
            /* IP Addr + Port is present. Value field is useless */
            MG_ACC_INIT_TOKEN_VALUE(&(mid->u.dAddrPort.pres),1);

            if(NULLP == addr)
            {
               RETVALUE(RFAILED);
            }
            switch (addrType)
            {
                case MGT_IPV4 :
                    MG_ACC_INIT_TKNSTROSXL(&(mid->u.dAddrPort.u.ipv4),addr,addrLen);
                    break;

                case MGT_IPV6 :
                    MG_ACC_INIT_TKNSTROSXL(&(mid->u.dAddrPort.u.ipv6),addr,addrLen);
                    break;

                default :
                    RETVALUE(RFAILED);
            }
            /* Initialize whether IP4 or IP6 addre */
            MG_ACC_INIT_TOKEN_VALUE(&(mid->u.dAddrPort.type),addrType);

            if(TRUE == prtPres)
            {
               /* Port number initialization */
               MG_ACC_INIT_TOKEN_VALUE(&(mid->u.dAddrPort.port),port);
            }
            else
               mid->u.dAddrPort.port.pres = NOTPRSNT;
            break;

        case MGT_MID_DNAMEPORT :
            /* Domain name + Port is present. Value field is useless */
            MG_ACC_INIT_TOKEN_VALUE(&(mid->u.dNamePort.pres),1);

            /* Set domain name */
            if(NULLP != addr)
            {
               MG_ACC_INIT_TKNSTROSXL(&(mid->u.dNamePort.name),addr,addrLen);
            }
            else
            {
               RETVALUE(RFAILED);
            }

            /* Port number initialization */
            if(TRUE == prtPres)
            {
               MG_ACC_INIT_TOKEN_VALUE(&(mid->u.dNamePort.port),port);
            }
            else
               mid->u.dNamePort.port.pres = NOTPRSNT;
            break;

        case MGT_MID_MTPADDR :
            /* Set MTP address */
            MG_ACC_INIT_TKNSTR(&(mid->u.mtpAddr),addr,addrLen);
            break;

        case MGT_MID_DEVICE :
            /* Device name is present. Value field is useless */
            MG_ACC_INIT_TOKEN_VALUE(&(mid->u.dNamePort.pres),1);

            /* Set local name & path domain name */
            MG_ACC_INIT_TKNSTROSXL(&(mid->u.dev.lcl),lcl,lclLen);
            MG_ACC_INIT_TKNSTROSXL(&(mid->u.dev.dom),addr,addrLen);
            break;

        case MGT_MID_PORT :
            /* Port number initialization */
            MG_ACC_INIT_TOKEN_VALUE(&(mid->u.port),port);
            break;

        default :
            RETVALUE(RFAILED);
    } /* end of switch */
    MG_ACC_INIT_TOKEN_VALUE(&(mid->type),midType);
    RETVALUE(ROK);
}



/*
*
*       Fun:   mgAccFillErrDesc
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillErrDesc
(
MgMgcoErrDesc        *errDesc,
U32                  errCode,
U8                   *errTxt,
U16                  errLen
)
#else
PUBLIC S16 mgAccFillErrDesc(errDesc,errCode,errTxt,errLen)
MgMgcoErrDesc        *errDesc;
U32                  errCode;
U8                   *errTxt;
U16                  errLen;
#endif
{
    TRC3(mgAccFillErrDesc);

    /* Error code present */
    MG_ACC_INIT_TOKEN_VALUE(&(errDesc->pres),1);

    /* Set error code */
    MG_ACC_INIT_TOKEN_VALUE(&(errDesc->code),errCode);
          
    /* Set error text */
    if(NULLP != errTxt)
    {
       MG_ACC_INIT_TKNSTROSXL(&(errDesc->text),errTxt,errLen);
    }
    else
    {
        errDesc->text.pres = NOTPRSNT;
    }

    RETVALUE(ROK);
}



/*
*
*       Fun:   mgAccFillMgcoActnReply
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillMgcoActnReply
(
CmMemListCp           *memCp,
MgMgcoActnReply       *actRep,
U8                    repType,     /* MGT_ERRDESC/MGT_CXTCMDREPLY */
U8                    cxt,         /* Context ID */
U32                   cxtIdVal,
Bool                  fillCxtProp, /* To fill context propertioes or not */
MgMgcoAccCxtPropInfo  *cxtInfo,    /* Context info, valid only if fillCxtProp=TRUE */
Bool                  fillCmdRep,  /* To fill command replies or not */
U16                   numRep,      /* No of command replies Valid only if fillCmdRep=TRUE */
MgMgcoAccErrDesc      *errDesc,    /* Only if repType =MGT_ERRDESC */
MgMgcoAccCmdReplyInfo **cmdRep     /* Info for command reply */
)
#else
PUBLIC S16 mgAccFillMgcoActnReply(memCp,actRep,repType,cxt,cxtIdVal,fillCxtProp,
                              cxtInfo,fillCmdRep,numRep,errDesc,cmdRep)
CmMemListCp           *memCp;
MgMgcoActnReply       *actRep;
U8                    repType;  
U8                    cxt; 
U32                   cxtIdVal;
Bool                  fillCxtProp;
MgMgcoAccCxtPropInfo  *cxtInfo;   
Bool                  fillCmdRep;
U16                   numRep;
MgMgcoAccErrDesc      *errDesc; 
MgMgcoAccCmdReplyInfo **cmdRep;   
#endif
{
    S16        ret = ROK;
    U16        idx;

    TRC3(MgMgcoActnReply);

    /* Action reply present */
    MG_ACC_INIT_TOKEN_VALUE(&(actRep->pres), 1);
    
    /* Set the context Id */
    if( MGT_CXTID_OTHER != cxt)
    {
        /* Set to "*" or "-" or "$" */
        MG_ACC_INIT_TOKEN_VALUE(&(actRep->cxtId.type),cxt);
    }
    else
    {
        MG_ACC_INIT_TOKEN_VALUE(&(actRep->cxtId.type),MGT_CXTID_OTHER);
        MG_ACC_INIT_TOKEN_VALUE(&(actRep->cxtId.val),cxtIdVal);
    }
    switch(repType)
    {
        case MGT_ERRDESC :

#ifdef MGT_GCP_VER_1_4
            actRep->repErrSet.pres.pres       = PRSNT_NODEF;
            actRep->repErrSet.err.pres.pres   = PRSNT_NODEF;
            actRep->repErrSet.reply.pres.pres = NOTPRSNT;

            ret = mgAccFillErrDesc(&(actRep->repErrSet.err),errDesc->errCode,
                             errDesc->errTxt,errDesc->errLen);
#else /* MGT_GCP_VER_1_4 */
            /* Set Reply type */
            MG_ACC_INIT_TOKEN_VALUE(&(actRep->type),MGT_ERRDESC);
            ret = mgAccFillErrDesc(&(actRep->u.err),errDesc->errCode,
                             errDesc->errTxt,errDesc->errLen);
#endif /* MGT_GCP_VER_1_4 */

            break;

        case MGT_CXTCMDREPLY:

#ifdef MGT_GCP_VER_1_4

            actRep->repErrSet.pres.pres       = PRSNT_NODEF;

            /* ErrDesc not present */
            actRep->repErrSet.err.pres.pres   = NOTPRSNT;

            /* CxtCmdRep present */
            actRep->repErrSet.reply.pres.pres = PRSNT_NODEF;

            if(TRUE == fillCxtProp)
            {
                ret = mgAccFillCxtProps(memCp,&(actRep->repErrSet.reply.cxt),
                                        cxtInfo->priorFlag,
                                        cxtInfo->cxtPrior,
                                        cxtInfo->cxtEmerg,cxtInfo->numTpl,
                                        cxtInfo->frmTerm,
                                        cxtInfo->toTerm,cxtInfo->dir);
                MG_ACC_CHK_RETVAL(ret);
            }

            if(TRUE == fillCmdRep)
            {
                Size  size;
                size = (numRep * (sizeof(MgMgcoCmdReply*)));
#ifndef GCP_CH
                MG_ACC_GETMEM((actRep->repErrSet.reply.cl.repl),size,memCp);
#endif /* GCP_CH */

                MG_ACC_INIT_TOKEN_VALUE(&(actRep->repErrSet.reply.cl.num),
                                        numRep);

                for(idx=0;idx<numRep;idx++)
                {
#ifndef GCP_CH
                   /* Allocate memory for each command reply */
                   MG_ACC_GETMEM(((actRep->repErrSet.reply.cl.repl)[idx]),
                                            sizeof(MgMgcoCmdReply),memCp);
#else
                   MG_ALLOC_EVNT_MEM(((actRep->repErrSet.reply.cl.repl)[idx]), 
                                          ret, sizeof(MgMgcoCmdReply));
#endif /* GCP_CH */


                   ret = mgAccFillCmdReply(memCp,
                              ((actRep->repErrSet.reply.cl.repl)[idx]),
                              cmdRep[idx]->repType,cmdRep[idx]->fillTermAud,
                              cmdRep[idx]->numAud,cmdRep[idx]->audInfo,
                              cmdRep[idx]->numTerm,cmdRep[idx]->termInfo,
                              cmdRep[idx]->type,&(cmdRep[idx]->errDesc),
                              &(cmdRep[idx]->scRes));
                   MG_ACC_CHK_RETVAL(ret);
                }
            }

#else /* MGT_GCP_VER_1_4 */

            /* Set Reply type */
            MG_ACC_INIT_TOKEN_VALUE(&(actRep->type),MGT_CXTCMDREPLY);

            /* CxtCmdRep present */
            MG_ACC_INIT_TOKEN_VALUE(&(actRep->u.reply.pres), 1);

            if(TRUE == fillCxtProp)
            {
                ret = mgAccFillCxtProps(memCp,&(actRep->u.reply.cxt),cxtInfo->priorFlag,
                                cxtInfo->cxtPrior,cxtInfo->cxtEmerg,cxtInfo->numTpl,
                                cxtInfo->frmTerm,cxtInfo->toTerm,cxtInfo->dir);
                MG_ACC_CHK_RETVAL(ret);
            }

            if(TRUE == fillCmdRep)
            {
                Size  size;
                size = (numRep * (sizeof(MgMgcoCmdReply*)));
 
#ifndef GCP_CH
                MG_ACC_GETMEM((actRep->u.reply.cl.repl),size,memCp);
#endif /* GCP_CH */

                MG_ACC_INIT_TOKEN_VALUE(&(actRep->u.reply.cl.num), numRep);

                for(idx=0;idx<numRep;idx++)
                {
#ifndef GCP_CH
                   /* Allocate memory for each command reply */
                   MG_ACC_GETMEM(((actRep->u.reply.cl.repl)[idx]),
                                            sizeof(MgMgcoCmdReply),memCp);
#else
                   MG_ALLOC_EVNT_MEM(((actRep->u.reply.cl.repl)[idx]), 
                                          ret, sizeof(MgMgcoCmdReply));
#endif /* GCP_CH */
                   /* Allocate memory for each command reply */

                   ret = mgAccFillCmdReply(memCp,((actRep->u.reply.cl.repl)[idx]),
                              cmdRep[idx]->repType,cmdRep[idx]->fillTermAud,
                              cmdRep[idx]->numAud,cmdRep[idx]->audInfo,
                              cmdRep[idx]->numTerm,cmdRep[idx]->termInfo,
                              cmdRep[idx]->type,&(cmdRep[idx]->errDesc),
                              &(cmdRep[idx]->scRes));
                   MG_ACC_CHK_RETVAL(ret);
                }
            }

#endif /* MGT_GCP_VER_1_4 */

            break;

        default :
            ret = RFAILED;
            break;
    }
    RETVALUE(ret);
}



/*
*
*       Fun:   mgFillCxtProps
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillCxtProps
(
CmMemListCp          *memCp,
MgMgcoContextProps   *cxtProp,
Bool                 priorFlag,   /* Priority set? */
U16                  cxtPrior,    /* Priority, if priorFlag=TRUE */
Bool                 cxtEmerg,    /* Emergency set? */
U16                  numTpl,      /* number of topologies */
MgMgcoAccTermInfo    **frmTerm,   /* From Termination info */
MgMgcoAccTermInfo    **toTerm,    /* To Termination info */
U8                   dir          /* Direction */
)
#else
PUBLIC S16 mgAccFillCxtProps(memCp,cxtProp,priorFlag,cxtPrior,cxtEmerg,numTpl,
                       frmTerm,toTerm,dir)
CmMemListCp          *memCp;
MgMgcoContextProps   *cxtProp;
Bool                 priorFlag;   
U16                  cxtPrior;   
Bool                 cxtEmerg;  
U16                  numTpl;   
MgMgcoAccTermInfo    **frmTerm;
MgMgcoAccTermInfo    **toTerm;
U8                   dir;
#endif
{
    S16           ret = ROK;
    U16           idx;
    Size          size;
    TRC3(mgAccFillCxtProps);

    MG_ACC_INIT_TOKEN_VALUE(&(cxtProp->pres), 1);

    if(TRUE == priorFlag)
    {
        MG_ACC_INIT_TOKEN_VALUE(&(cxtProp->pri), cxtPrior);
    }

    if(TRUE == cxtEmerg)
    {
        MG_ACC_INIT_TOKEN_VALUE(&(cxtProp->pres), 1);
    }

    /* Set number of topologies */
    MG_ACC_INIT_TOKEN_VALUE(&(cxtProp->tl.num), numTpl);

    size = (numTpl * (sizeof(MgMgcoTopoDesc*)));
    MG_ACC_GETMEM((cxtProp->tl.descs),size,memCp );
    for(idx=0;idx<numTpl;idx++)
    { 

        if( (NULLP == toTerm[idx]) || (NULLP == frmTerm[idx]) )
        {
            RETVALUE(RFAILED);
        }

        /* Allocate memory for each command reply */
        MG_ACC_GETMEM( ((cxtProp->tl.descs)[idx]),sizeof(MgMgcoTopoDesc),memCp );

        MG_ACC_INIT_TOKEN_VALUE(&(((cxtProp->tl.descs)[idx])->pres), 1);
         
        /* Set direction */
        MG_ACC_INIT_TOKEN_VALUE(&(((cxtProp->tl.descs)[idx])->dir), dir);

        /* Fill "to" termination info */
        ret = mgAccFillTermId(memCp,&(((cxtProp->tl.descs)[idx])->to),toTerm[idx]);
        MG_ACC_CHK_RETVAL(ret);

        /* Fill "from" termination info */
        ret = mgAccFillTermId(memCp,&(((cxtProp->tl.descs)[idx])->from),frmTerm[idx]);
        MG_ACC_CHK_RETVAL(ret);
    } /* End of for */

    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillAuditDesc
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillAuditDesc
(
CmMemListCp              *memCp,
MgMgcoAuditDesc          *aud,
MgMgcoAccAudDescInfo     *audInfo
)
#else
PUBLIC S16 mgAccFillAuditDesc(memCp,aud,audInfo)
CmMemListCp              *memCp;
MgMgcoAuditDesc          *aud;
MgMgcoAccAudDescInfo     *audInfo;
#endif
{
   U16          idx = 0;

   TRC3(mgAccFillAuditDesc)

   if(audInfo->num > MGT_MAX_AUDS)
   {
       RETVALUE(RFAILED);
   }

   /*
    * Set the pres field in auditDescriptor, which has been added in mgt.x
    */
   MG_ACC_INIT_TOKEN_VALUE(&(aud->pres),1);

   /* Set number of tokens */
   MG_ACC_INIT_TOKEN_VALUE(&(aud->num),audInfo->num);
   MG_ACC_GETMEM(aud->al, audInfo->num * sizeof(TknU8 *), memCp);
   (void)idx;
   for(idx=0; idx<audInfo->num; idx++)
   {
#ifdef MGT_MGCO_V2
       MG_ACC_GETMEM(aud->al[idx], sizeof(MgMgcoAuditItem), memCp);
      aud->al[idx]->auditItem.pres=PRSNT_NODEF;
      aud->al[idx]->auditItem.val=audInfo->aud[idx];
#else
       MG_ACC_GETMEM(aud->al[idx], sizeof(TknU8), memCp);
       MG_ACC_INIT_TOKEN_VALUE(((aud->al[idx])),audInfo->aud[idx]);

#endif
/*MgMgcoAuditDesc          *aud;*/
   }
   RETVALUE(ROK);
}



/*
*
*       Fun:   mgAccFillAmmDescLst
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillAmmDescLst
(
CmMemListCp              *memCp,
MgMgcoAmmDescLst         *adl,
U16                      num,         
MgMgcoAccAmmDescInfo     **ammInfo
)
#else
PUBLIC S16 mgAccFillAmmDescLst(memCp,adl,num,ammInfo)
CmMemListCp              *memCp;
MgMgcoAmmDescLst         *adl;
U16                      num;
MgMgcoAccAmmDescInfo     **ammInfo;
#endif
{
   S16          ret = ROK;
   U16          idx = 0;
   Size         size;

   TRC3(mgAccFillAmmDescLst)

   /* Number of AMM descriptors */
   MG_ACC_INIT_TOKEN_VALUE(&(adl->num),num);

   size = (num * (sizeof(MgMgcoAmmDesc*)));
   MG_ACC_GETMEM((adl->descs),size,memCp );
   for(idx=0; idx<num; idx++)
   {
       MG_ACC_GETMEM( ((adl->descs)[idx]),sizeof(MgMgcoAmmDesc),memCp );

       switch(ammInfo[idx]->type)
       {
          case MGT_MEDIADESC :
            ret = mgAccFillMediaDesc(memCp,&(((adl->descs)[idx])->u.media),
                             (ammInfo[idx])->u.medInfo.num,
                             (ammInfo[idx])->u.medInfo.parInfo);
            MG_ACC_CHK_RETVAL(ret);
            break;

          case MGT_MODEMDESC :
            ret = mgAccFillModemDesc(memCp,&(((adl->descs)[idx])->u.modem),
                              &((ammInfo[idx])->u.modInfo) );
            MG_ACC_CHK_RETVAL(ret);
            break;

          case MGT_MUXDESC :
            ret = mgAccFillMuxDesc(memCp,&(((adl->descs)[idx])->u.mux),
                              &((ammInfo[idx])->u.muxInfo));
            MG_ACC_CHK_RETVAL(ret);
            break;

          case MGT_REQEVTDESC :
            ret = mgAccFillReqEvtDesc(memCp,&(((adl->descs)[idx])->u.evts),
                              &((ammInfo[idx])->u.evtInfo));
            MG_ACC_CHK_RETVAL(ret);
            break;

          case MGT_EVBUFDESC :
             ret = mgAccFillEvBufDesc(memCp,&(((adl->descs)[idx])->u.evBuf),
                              (ammInfo[idx])->u.evtBuf.numEvts,
                              &((ammInfo[idx])->u.evtBuf.evtInfo));
            MG_ACC_CHK_RETVAL(ret);
             break;

          case MGT_SIGNALSDESC :
            ret = mgAccFillSignalDesc(memCp,&(((adl->descs)[idx])->u.sig),
                              (ammInfo[idx])->u.sigInfo.num,
                              (ammInfo[idx])->u.sigInfo.sigPar);
            MG_ACC_CHK_RETVAL(ret);
            break;

          case MGT_DIGMAPDESC :
             if(MGT_DIGMAP_NAME == ammInfo[idx]->u.dmInfo.type)
             {
                ret = mgAccFillDigMapDesc(memCp,&(((adl->descs)[idx])->u.dm),
                             TRUE,&(ammInfo[idx]->u.dmInfo.name),FALSE,NULLP);
             }
             else if(MGT_DIGMAP_VAL == ammInfo[idx]->u.dmInfo.type)
             {
               ret = mgAccFillDigMapDesc(memCp,&(((adl->descs)[idx])->u.dm),
                             FALSE,NULLP,TRUE,&(ammInfo[idx]->u.dmInfo.val));
             }
             MG_ACC_CHK_RETVAL(ret);
             break;

          case MGT_AUDITDESC :
             ret = mgAccFillAuditDesc(memCp,&(((adl->descs)[idx])->u.audit),
                              &((ammInfo[idx])->u.audItem));
             MG_ACC_CHK_RETVAL(ret);
             break;

          default :
            RETVALUE(RFAILED);
       } /* end of switch */

       /* Fill the type field */
       MG_ACC_INIT_TOKEN_VALUE(&(((adl->descs)[idx])->type),(ammInfo[idx])->type);
   } /* end of for */
   RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillSvcChgPar
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillSvcChgPar
(
CmMemListCp              *memCp,
MgMgcoSvcChgPar          *svc,
MgMgcoAccSvcParInfo      *svcInfo
)
#else
PUBLIC S16 mgAccFillSvcChgPar(memCp,svc,svcInfo)
CmMemListCp              *memCp;
MgMgcoSvcChgPar          *svc;
MgMgcoAccSvcParInfo      *svcInfo;
#endif
{
   S16          ret = ROK;

   TRC3(mgAccFillSvcChgPar);

   MG_ACC_INIT_TOKEN_VALUE(&(svc->pres),1);

   /* Fill non std extension */
   if(TRUE == svcInfo->extPres)
   {
      ret = mgAccFillNonStdExtn(memCp,&(svc->extn),&(svcInfo->ext));
      MG_ACC_CHK_RETVAL(ret);
   }

   /* Fill service change method */
   MG_ACC_INIT_TOKEN_VALUE(&(svc->meth.pres),1);
   MG_ACC_INIT_TOKEN_VALUE(&(svc->meth.type),svcInfo->svcMeth);

   if(TRUE == svcInfo->nonStdIdPres)
   {
      ret = mgAccFillNonStdId(memCp,&(svc->meth.extn),&(svcInfo->nonStdId));
      MG_ACC_CHK_RETVAL(ret);
   }

   /* Fill service change address */
   if(TRUE == svcInfo->svcAddrPres)
   {
      ret = mgAccFillMid(&(svc->addr),svcInfo->aInfo.midType,svcInfo->aInfo.aType,
                    svcInfo->aInfo.aLen,svcInfo->aInfo.addr,svcInfo->aInfo.lcl,
                    svcInfo->aInfo.lclLen,svcInfo->aInfo.prtPres,svcInfo->aInfo.port);
      MG_ACC_CHK_RETVAL(ret);
   }

   /* Fill vertion number */ 
   MG_ACC_INIT_TOKEN_VALUE(&(svc->ver),svcInfo->ver);
   
   /* Fill Service change profile */
   if(TRUE == svcInfo->prof.profPres)
   {
      ret = mgAccFillSvcChgProf(&(svc->prof),svcInfo->prof.profVer,
                       svcInfo->prof.name.str,svcInfo->prof.name.len,
                       svcInfo->prof.name.value);
   }  
   MG_ACC_CHK_RETVAL(ret);

   /* Fill service change reason */
   if(NULLP != svcInfo->reason)
   {
      MG_ACC_INIT_TKNSTROSXL(&(svc->reason), svcInfo->reason, svcInfo->len);
   }

   /* Fill service change delay */
   if(TRUE == svcInfo->svcDelayPres)
   {
      MG_ACC_INIT_TOKEN_VALUE(&(svc->delay),svcInfo->delay);
   }

   /* Fill new MGC ID */
   if(TRUE == svcInfo->mgcIdPres)
   {
      ret = mgAccFillMid(&(svc->mgcId),svcInfo->aInfo.midType,svcInfo->aInfo.aType,
                    svcInfo->aInfo.aLen,svcInfo->aInfo.addr,svcInfo->aInfo.lcl,
                    svcInfo->aInfo.lclLen,svcInfo->aInfo.prtPres,svcInfo->aInfo.port);
      MG_ACC_CHK_RETVAL(ret);
   }

   /* Fill time stamp information */
   if(TRUE == svcInfo->tsPres)
   {
      MG_ACC_INIT_TOKEN_VALUE(&(svc->time.pres),1);
      MG_ACC_INIT_TKNSTR(&(svc->time.date),svcInfo->date,8); 
      MG_ACC_INIT_TKNSTR(&(svc->time.time),svcInfo->tm,8); 
   }

   RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillCmdReqLst
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillCmdReqLst
(
CmMemListCp              *memCp,
MgMgcoCmdReqLst          *cmdLst,
U16                      num,
MgMgcoAccCmdReqInfo      **cmdInfo
)
#else
PUBLIC S16 mgAccFillCmdReqLst(memCp,cmdLst,num,cmdInfo)
CmMemListCp              *memCp;
MgMgcoCmdReqLst          *cmdLst;
U16                      num;
MgMgcoAccCmdReqInfo      **cmdInfo;
#endif
{
   S16          ret = ROK;
   U16          idx = 0;
#ifndef GCP_CH
   Size         size;
#endif /* GCP_CH */

   TRC3(mgAccFillCmdReqLst)

   MG_ACC_INIT_TOKEN_VALUE(&(cmdLst->num),num);

#ifndef GCP_CH
   size = (num * (sizeof(MgMgcoCommandReq*)));
   MG_ACC_GETMEM((cmdLst->cmds),size,memCp );
#endif /* GCP_CH */
 
   for(idx=0;idx<num;idx++)
   {
#ifndef GCP_CH
       MG_ACC_GETMEM( ((cmdLst->cmds)[idx]),sizeof(MgMgcoCommandReq),memCp );
#else
       MG_ALLOC_EVNT_MEM(((cmdLst->cmds)[idx]), ret, sizeof(MgMgcoCommandReq));
#endif /* GCP_CH */

       MG_ACC_INIT_TOKEN_VALUE(&((cmdLst->cmds)[idx]->pres),1);

       /* Set is command optional */
       if(TRUE == cmdInfo[idx]->opt)
       {
          MG_ACC_INIT_TOKEN_VALUE(&((cmdLst->cmds)[idx]->opt),1);
       }
       else
          (cmdLst->cmds)[idx]->opt.pres = NOTPRSNT;

       /* Set, is wild carded response reqd */
       if(TRUE == cmdInfo[idx]->wild)
       {
          MG_ACC_INIT_TOKEN_VALUE(&((cmdLst->cmds)[idx]->wild),1);
       }
       else
          (cmdLst->cmds)[idx]->wild.pres = NOTPRSNT;

       switch(cmdInfo[idx]->type)
       {
          /* Since add/move & modify has the same type, and they r in union, fill any 
             one of them fpr any one */
          case MGT_ADD :
          case MGT_MOVE :
          case MGT_MODIFY :
            MG_ACC_INIT_TOKEN_VALUE(&((cmdLst->cmds)[idx]->cmd.u.add.pres),1);
            ret = mgAccFillTermId(memCp,
                           &((cmdLst->cmds)[idx]->cmd.u.add.termId),
                           cmdInfo[idx]->termInfo[0]);
            MG_ACC_CHK_RETVAL(ret);
            if((cmdInfo[idx])->numAmmDesc > 0)
            {
              ret = mgAccFillAmmDescLst(memCp,
                           &((cmdLst->cmds)[idx]->cmd.u.add.dl),
                           (cmdInfo[idx])->numAmmDesc,(cmdInfo[idx])->ammInfo);
            }
            MG_ACC_CHK_RETVAL(ret);
            break;

          case MGT_SUB :
          case MGT_AUDITCAP :
          case MGT_AUDITVAL :
            MG_ACC_INIT_TOKEN_VALUE(&((cmdLst->cmds)[idx]->cmd.u.sub.pres),1);
            ret = mgAccFillTermId(memCp,&((cmdLst->cmds)[idx]->cmd.u.sub.termId),
                           cmdInfo[idx]->termInfo[0]);
            MG_ACC_CHK_RETVAL(ret);
            if(TRUE == (cmdInfo[idx])->audDescPres)
            {
               ret = mgAccFillAuditDesc(memCp,
                                  &((cmdLst->cmds)[idx]->cmd.u.sub.audit),
                                  &((cmdInfo[idx])->audInfo));
               MG_ACC_CHK_RETVAL(ret);
            }
            MG_ACC_CHK_RETVAL(ret);
            break;

          case MGT_NTFY :
            MG_ACC_INIT_TOKEN_VALUE(&((cmdLst->cmds)[idx]->cmd.u.ntfy.pres),1);
            ret = mgAccFillTermId(memCp,
                           &((cmdLst->cmds)[idx]->cmd.u.ntfy.termId),
                           cmdInfo[idx]->termInfo[0]);
            MG_ACC_CHK_RETVAL(ret);
            ret = mgAccFillObsEvtDesc(memCp,
                               &((cmdLst->cmds)[idx]->cmd.u.ntfy.obs),
                               &((cmdInfo[idx])->evt.reqId),
                               (cmdInfo[idx])->evt.numEvt,
                               (cmdInfo[idx])->evt.evt);
            MG_ACC_CHK_RETVAL(ret);

            if(TRUE == (cmdInfo[idx])->errDescPres)
            {
               ret = mgAccFillErrDesc(&((cmdLst->cmds)[idx]->cmd.u.ntfy.err),
                                  (cmdInfo[idx])->err.errCode,(cmdInfo[idx])->err.errTxt,
                                  (cmdInfo[idx])->err.errLen);
               MG_ACC_CHK_RETVAL(ret);
            }
            break;

          case MGT_SVCCHG :
            MG_ACC_INIT_TOKEN_VALUE(&((cmdLst->cmds)[idx]->cmd.u.svc.pres),1);
            ret = mgAccFillTermId(memCp,&((cmdLst->cmds)[idx]->cmd.u.svc.termId),
                           cmdInfo[idx]->termInfo[0]);
            MG_ACC_CHK_RETVAL(ret);
            ret = mgAccFillSvcChgPar(memCp,&((cmdLst->cmds)[idx]->cmd.u.svc.parm),
                                  &((cmdInfo[idx])->svcInfo));
            MG_ACC_CHK_RETVAL(ret);
            break;

          default :
             RETVALUE(RFAILED);
       } /* end of switch */
       /* Set the command type */
       MG_ACC_INIT_TOKEN_VALUE(&((cmdLst->cmds)[idx]->cmd.type),cmdInfo[idx]->type);
   } /* end of for */

    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillCmdReply
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillCmdReply
(
CmMemListCp              *memCp,
MgMgcoCmdReply           *cmdRep,
U8                       repType,    /* Add/move/sub/...etc */
Bool                     fillTermAud,/* To fill termination audit or not in AMMS */
U16                      numAud,
MgMgcoAccAuditInfo       **audInfo,
U16                      numTerm,    /* Number of terminations */ 
MgMgcoAccTermInfo        **termInfo, /* Information for each termination.
                                        For AMMS, only 1 elem present & used */ 
U8                       type,       /* COntext/Termination audit/error desc in audit, 
                                   service change result/err desc is SC rep */
MgMgcoAccErrDesc         *errDesc,   /* Err desc with audit reply/SC reply */
MgMgcoAccServChgResInfo  *scRes     /* Service change result info */
)
#else
PUBLIC S16 mgAccFillCmdReply(memCp,cmdRep,repType,fillTermAud,numAud,
                               audInfo,numTerm,termInfo,type,errDesc,scRes)
CmMemListCp              *memCp;
MgMgcoCmdReply           *cmdRep;
U8                       repType;
Bool                     fillTermAud; 
U16                      numAud;
MgMgcoAccAuditInfo       **audInfo;
U16                      numTerm; 
MgMgcoAccTermInfo        **termInfo;  
U8                       type;
MgMgcoAccErrDesc         *errDesc;
MgMgcoAccServChgResInfo  *scRes;  
#endif
{
    S16          ret = ROK;
    TRC3(MgMgcoCmdReply);

    MG_ACC_INIT_TOKEN_VALUE(&(cmdRep->pres),1);

    MG_ACC_INIT_TOKEN_VALUE(&(cmdRep->type),repType);

    switch(repType)
    {
        /* Since add/sub/mod/move reply have same types, and r within a union, 
           it doesnt make a diff, for which one of them, the fields r filled. */
        case MGT_ADD :
        case MGT_MOVE :
        case MGT_MODIFY :
        case MGT_SUB :
            MG_ACC_INIT_TOKEN_VALUE(&(cmdRep->u.add.pres),1);
            ret = mgAccFillTermId(memCp,&(cmdRep->u.add.termId),termInfo[0]);
            MG_ACC_CHK_RETVAL(ret);
            if(TRUE == fillTermAud)
            {
                ret = mgAccFillAuditRes(memCp,&(cmdRep->u.add.audit),numAud,audInfo );
            }
            break;


        /* Since audit cap reply & audit val reply have same types, and r within a union, 
           it doesnt make a diff, for which one of them, the fields r filled. */
        case MGT_AUDITCAP :
        case MGT_AUDITVAL :
            switch (type)
            {
                case MGT_ERRDESC :
                    MG_ACC_INIT_TOKEN_VALUE(&(cmdRep->u.acap.type),MGT_ERRDESC);
                    ret = mgAccFillErrDesc(&(cmdRep->u.acap.u.err),errDesc->errCode,
                                 errDesc->errTxt,errDesc->errLen);
                    break;

                case MGT_CXTAUDIT :
                    MG_ACC_INIT_TOKEN_VALUE(&(cmdRep->u.acap.type),MGT_CXTAUDIT);

                   /* Allocates and fills termination ID list */
                    if(numTerm > 0)
                    {
                      ret = mgAccFillTermIdLst(memCp,&(cmdRep->u.acap.u.cxt),
                                            numTerm,termInfo);
                    }
                    break;

                case MGT_TERMAUDIT :
                    MG_ACC_INIT_TOKEN_VALUE(&(cmdRep->u.acap.type),MGT_TERMAUDIT);

                    MG_ACC_INIT_TOKEN_VALUE(&(cmdRep->u.acap.u.other.pres),1);
 
                   /* Allocates and fills termination ID list */
                    if(numTerm > 0)
                    {
                      ret = mgAccFillTermIdLst(memCp,&(cmdRep->u.acap.u.cxt),
                                               numTerm,termInfo);
                    }
                    MG_ACC_CHK_RETVAL(ret);

                    if(numAud > 0)
                    {
                       /* Allocates & fills audit result */
                       ret = mgAccFillAuditRes(memCp,
                                 &(cmdRep->u.acap.u.other.audit),numAud,audInfo);
                    }
                    break;

                default :
                   RETVALUE(RFAILED);
            }
            break;

        case MGT_NTFY :
            MG_ACC_INIT_TOKEN_VALUE(&(cmdRep->u.ntfy.pres),1);

            ret = mgAccFillTermId(memCp,&(cmdRep->u.ntfy.termId),termInfo[0]);
            MG_ACC_CHK_RETVAL(ret);
            if(NULLP != errDesc)
            {
               if(TRUE == errDesc->pres)
                  ret = mgAccFillErrDesc(&(cmdRep->u.ntfy.err),errDesc->errCode,
                             errDesc->errTxt,errDesc->errLen);
            }
            break;

        case MGT_SVCCHG :
            MG_ACC_INIT_TOKEN_VALUE(&(cmdRep->u.svc.pres),1);

            switch(type)
            {
                case MGT_ERRDESC :
                   MG_ACC_INIT_TOKEN_VALUE(&(cmdRep->u.svc.res.type),MGT_ERRDESC);
                   ret = mgAccFillErrDesc(&(cmdRep->u.svc.res.u.err),errDesc->errCode,
                                 errDesc->errTxt,errDesc->errLen);
                   break;

                case MGT_SVCCHGDESC :
                   if(NULLP == scRes)
                   {
                       RETVALUE(RFAILED);
                   }
                   MG_ACC_INIT_TOKEN_VALUE(&(cmdRep->u.svc.res.type),MGT_SVCCHGDESC);

                   MG_ACC_INIT_TOKEN_VALUE(&(cmdRep->u.svc.res.u.parm.pres),1);

                   /* Set vertion number */
                   MG_ACC_INIT_TOKEN_VALUE(&(cmdRep->u.svc.res.u.parm.ver),scRes->verNum);

                   switch(scRes->type)
                   {
                      case MG_ACC_SERCHG_SERCHGADDR :
                           ret = mgAccFillMid(&(cmdRep->u.svc.res.u.parm.addr),
                                     scRes->aInfo.midType,scRes->aInfo.aType,scRes->aInfo.aLen,
                                     scRes->aInfo.addr,scRes->aInfo.lcl,scRes->aInfo.lclLen,
                                     scRes->aInfo.prtPres,scRes->aInfo.port);
                           break;

                      case MG_ACC_SERCHG_MGCID :
                           ret = mgAccFillMid(&(cmdRep->u.svc.res.u.parm.mgcId),
                                     scRes->aInfo.midType,scRes->aInfo.aType,scRes->aInfo.aLen,
                                     scRes->aInfo.addr,scRes->aInfo.lcl,scRes->aInfo.lclLen,
                                     scRes->aInfo.prtPres,scRes->aInfo.port);
                           break;

                      case MG_ACC_SERCHG_SERCHGPROF :
                           if(TRUE == scRes->prof.profPres)
                           {
                              ret = mgAccFillSvcChgProf(
                                     &(cmdRep->u.svc.res.u.parm.prof),
                                     scRes->prof.profVer,scRes->prof.name.str,
                                     scRes->prof.name.len,scRes->prof.name.value);
                           }
                           break;

                      default :
                           RETVALUE(RFAILED);
                   }
                   break;

                default :
                   RETVALUE(RFAILED);
            }
            MG_ACC_CHK_RETVAL(ret);

           /* Allocates and fills termination ID */
           ret = mgAccFillTermId(memCp,&(cmdRep->u.svc.termId),termInfo[0]);
           break;

        default :
            ret = RFAILED;
    }

    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillSvcChgProf
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillSvcChgProf
(
MgMgcoSvcChgProf    *scProf,
U8                  profVer,
U8                  *str,
U16                 strLen, 
U16                 val     /* Valid only if str != NULLP */
)
#else
PUBLIC S16 mgAccFillSvcChgProf(scProf,profVer,str,strLen,val)
MgMgcoSvcChgProf    *scProf;
U8                  profVer;
U8                  *str;
U16                 strLen; 
U16                 val; 
#endif
{
    S16       ret = ROK;

    TRC3(mgAccFillSvcChgProf);

    MG_ACC_INIT_TOKEN_VALUE(&(scProf->pres),1);

    /* Fill profile vertion number */
    MG_ACC_INIT_TOKEN_VALUE(&(scProf->ver),profVer);

    ret = mgAccFillMgcoName(&(scProf->name),str,strLen,val);

    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillMgcoName
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillMgcoName
(
MgMgcoName          *name,
U8                  *str,
U16                 strLen, 
U16                 val     /* Valid only if str != NULLP */
)
#else
PUBLIC S16 mgAccFillMgcoName(name,str,strLen,val)
MgMgcoName          *name;
U8                  *str;
U16                 strLen; 
U16                 val; 
#endif
{
    TRC3(mgAccFillMgcoName);

    if( NULLP != str)
    {
        MG_ACC_INIT_TKNSTROSXL(&(name->u.str),str,strLen);
        MG_ACC_INIT_TOKEN_VALUE(&(name->type),MGT_GEN_TYPE_UNKNOWN);
    }
    else
    {
        MG_ACC_INIT_TOKEN_VALUE(&(name->u.val),(U8)val);
        MG_ACC_INIT_TOKEN_VALUE(&(name->type),MGT_GEN_TYPE_KNOWN);
    }
    RETVALUE(ROK);
}



/*
*
*       Fun:   mgAccFillTermIdLst
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillTermIdLst
(
CmMemListCp          *memCp,
MgMgcoTermIdLst      *termLst,
U16                  numTerm,
MgMgcoAccTermInfo    **termInfo
)
#else
PUBLIC S16 mgAccFillTermIdLst(memCp,termLst,numTerm,termInfo)
CmMemListCp          *memCp;
MgMgcoTermIdLst      *termLst;
U16                  numTerm;
MgMgcoAccTermInfo    **termInfo;
#endif
{
    S16       ret = ROK;
    U16       idx = 0;
    Size      size;

    TRC3(mgAccFillTermIdLst);

    /* Initialize number of terminations */
    MG_ACC_INIT_TOKEN_VALUE(&(termLst->num),numTerm);

    size = (numTerm * (sizeof(MgMgcoTermId*)));
    MG_ACC_GETMEM((termLst->terms),size,memCp );
    for(idx=0; idx<numTerm; idx++)
    {
        if(NULLP == termInfo[idx])
        {
            RETVALUE(RFAILED);
        }
        MG_ACC_GETMEM( ((termLst->terms)[idx]),sizeof(MgMgcoTermId),memCp);

        ret = mgAccFillTermId(memCp,((termLst->terms)[idx]),termInfo[idx]);
        MG_ACC_CHK_RETVAL(ret);
    } /* end of for */

    RETVALUE(ret);
}


/*
*
*       Fun:   mgAccFillTermId
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillTermId
(
CmMemListCp          *memCp,
MgMgcoTermId         *term,
MgMgcoAccTermInfo    *termInfo
)
#else
PUBLIC S16 mgAccFillTermId(memCp,term,termInfo)
CmMemListCp          *memCp;
MgMgcoTermId         *term;
MgMgcoAccTermInfo    *termInfo;
#endif
{
    S16          ret = ROK;
#ifdef GCP_ASN 
    Size      size;
    U16       idx = 0;
#endif

    TRC3(mgAccFillTermId);

    if(NULLP == termInfo) 
    {
        RETVALUE(RFAILED);
    }

    if(MGT_TERMID_OTHER == termInfo->type )
    {
        if( (NULLP == termInfo->lcl) &&
            (NULLP == termInfo->dom) )
        {
           RETVALUE(RFAILED);
        }
        /* Set termination ID type */
        MG_ACC_INIT_TOKEN_VALUE(&(term->type),MGT_TERMID_OTHER);

        MG_ACC_INIT_TOKEN_VALUE(&(term->name.pres),1);
        /* Set local name */
        MG_ACC_INIT_TKNSTROSXL(&(term->name.lcl),termInfo->lcl,
                           termInfo->lclLen);
        
        /* Set domain name */
        /* mg008.105: Corrected the Sanity check */
        if(NULLP != termInfo->dom)
            MG_ACC_INIT_TKNSTROSXL(&(term->name.dom),termInfo->dom,
                           termInfo->domLen);
    }
    else
    {
        /* TermId is either ROOT/ALL/CHOOSE */
        MG_ACC_INIT_TOKEN_VALUE(&(term->type),termInfo->type);
        /* mg005.105: Modified for the termination id wildcard */
#ifdef GCP_ASN 
      if(termInfo->num != 0)
      {

           if( (NULLP == termInfo->lcl) &&
               (NULLP == termInfo->dom) )
           {
              RETVALUE(RFAILED);
           }
           /* Set termination ID type */
           MG_ACC_INIT_TOKEN_VALUE(&(term->name.pres),1);
           /* Set local name */
           MG_ACC_INIT_TKNSTROSXL(&(term->name.lcl),termInfo->lcl,
                              termInfo->lclLen);
           
           /* Set domain name */
           if(NULLP != termInfo->dom)
              MG_ACC_INIT_TKNSTROSXL(&(term->name.dom),termInfo->dom,
                              termInfo->domLen);

           if(termInfo->num != 0)
           {
             MG_ACC_INIT_TOKEN_VALUE(&(term->wildcard.num), termInfo->num);

             size = (termInfo->num * (sizeof(MgMgcoWildcardField*)));
             MG_ACC_GETMEM(term->wildcard.wildcard,size,memCp );
             for(idx=0;idx<termInfo->num;idx++)
             { 

                 /* Allocate memory for each command reply */
                 MG_ACC_GETMEM( (term->wildcard.wildcard[idx]),sizeof(MgMgcoWildcardField),memCp );
                 term->wildcard.wildcard[idx]->pres = PRSNT_NODEF;
                 term->wildcard.wildcard[idx]->len  = 1;
                 term->wildcard.wildcard[idx]->val[0] = termInfo->wildcardInfo[idx];
                  
             } /* End of for */
    
           }
       }
#endif
    }

    RETVALUE(ret);
}

/*
*
*       Fun:   mgAccFillAuditRes
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillAuditRes
(
CmMemListCp          *memCp,
MgMgcoTermAuditRes   *audit,
U16                  numAud,
MgMgcoAccAuditInfo   **audInfo
)
#else
PUBLIC S16 mgAccFillAuditRes(memCp,audit,numAud,audInfo)
CmMemListCp          *memCp;
MgMgcoTermAuditRes   *audit;
U16                  numAud;
MgMgcoAccAuditInfo   **audInfo;
#endif
{
    S16       ret = ROK;
    U16       idx = 0;
    Size      size;

    TRC3(mgAccFillAuditRes);

    /* Initialize number of terminations */
    MG_ACC_INIT_TOKEN_VALUE(&(audit->num),numAud);

    size = (numAud * (sizeof(MgMgcoAudRetParm*)));
    MG_ACC_GETMEM((audit->parms),size,memCp );
    for(idx=0; idx<numAud; idx++)
    {
        MG_ACC_GETMEM( ((audit->parms)[idx]),sizeof(MgMgcoAudRetParm),memCp);

        switch( (audInfo[idx])->audType )
        {
           case MGT_ERRDESC :
              ret = mgAccFillErrDesc(&(((audit->parms)[idx])->u.err),
                             (audInfo[idx])->u.err.errCode,(audInfo[idx])->u.err.errTxt,
                             (audInfo[idx])->u.err.errLen);
              break;

           case MGT_MEDIADESC :
              ret = mgAccFillMediaDesc(memCp,&(((audit->parms)[idx])->u.media),
                             (audInfo[idx])->u.medInfo.num,
                             (audInfo[idx])->u.medInfo.parInfo);
              break;

           case MGT_MODEMDESC :
              ret = mgAccFillModemDesc(memCp,&(((audit->parms)[idx])->u.modem),
                              &((audInfo[idx])->u.modInfo) );
              break;

           case MGT_MUXDESC :
              ret = mgAccFillMuxDesc(memCp,&(((audit->parms)[idx])->u.mux),
                              &((audInfo[idx])->u.muxInfo));
              break;

           case MGT_REQEVTDESC :
              ret = mgAccFillReqEvtDesc(memCp,&(((audit->parms)[idx])->u.evts),
                              &((audInfo[idx])->u.evtInfo));
              break;

           case MGT_EVBUFDESC :
              ret = mgAccFillEvBufDesc(memCp,&(((audit->parms)[idx])->u.evBuf),
                              (audInfo[idx])->u.evtBuf.numEvts, 
                              &((audInfo[idx])->u.evtBuf.evtInfo));
              break;

           case MGT_SIGNALSDESC :
              ret = mgAccFillSignalDesc(memCp,&(((audit->parms)[idx])->u.sig),
                              (audInfo[idx])->u.sigInfo.num,
                              (audInfo[idx])->u.sigInfo.sigPar);
              break;

           case MGT_DIGMAPDESC :
              if(MGT_DIGMAP_NAME == audInfo[idx]->u.dmInfo.type)
              {
                 ret = mgAccFillDigMapDesc(memCp,&(((audit->parms)[idx])->u.dm),
                              TRUE,&(audInfo[idx]->u.dmInfo.name),FALSE,NULLP);
              }
              else if(MGT_DIGMAP_VAL == audInfo[idx]->u.dmInfo.type)
              {
                 ret = mgAccFillDigMapDesc(memCp,&(((audit->parms)[idx])->u.dm),
                              FALSE,NULLP,TRUE,&(audInfo[idx]->u.dmInfo.val));
              }
              break;

           case MGT_OBSEVTDESC :
              ret = mgAccFillObsEvtDesc(memCp,&(((audit->parms)[idx])->u.obs),
                              &((audInfo[idx])->u.obEvt.reqId),
                              (audInfo[idx])->u.obEvt.numEvt,
                              (audInfo[idx])->u.obEvt.evt);
              break;

           case MGT_STATSDESC :
              ret = mgAccFillStatsDesc(memCp,&(((audit->parms)[idx])->u.stats),
                              (audInfo[idx])->u.sts.num,(audInfo[idx])->u.sts.stsInfo);
              break;

           case MGT_PKGSDESC :
              ret = mgAccFillPkgsDesc(memCp,&(((audit->parms)[idx])->u.pkgs),
                              (audInfo[idx])->u.pkg.num,(audInfo[idx])->u.pkg.item);
              break;

           case MGT_AUDITDESC :
#ifdef MGT_MGCO_V2              
              MG_ACC_INIT_TOKEN_VALUE(&(((audit->parms)[idx])->u.item.auditItem),
                              (audInfo[idx])->u.audItem);
#endif              
              break;
 
           default :
              ret = RFAILED;
        } /* end of switch */
        MG_ACC_CHK_RETVAL(ret);

        /* Set descriptor type */
        MG_ACC_INIT_TOKEN_VALUE(&(((audit->parms)[idx])->type), (audInfo[idx])->audType);
    } /* end of for */
    RETVALUE(ROK);
}



/*
*
*       Fun:   mgAccFillParmValue
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillParmValue
(
CmMemListCp           *memCp,
MgMgcoParmValue       *param,
MgMgcoAccParmVal      *val
)
#else
PUBLIC S16 mgAccFillParmValue(memCp,param,val)
CmMemListCp           *memCp;
MgMgcoParmValue       *param;
MgMgcoAccParmVal      *val;
#endif
{
    S16         ret = ROK;
    U16         idx = 0;
    Size        size;
    TRC3(mgAccFillParmValue);

    switch(val->type)
    {
       case MGT_VALUE_EQUAL :
       case MGT_VALUE_GREATERTHAN :
       case MGT_VALUE_LESSTHAN :
       case MGT_VALUE_NOTEQUAL :
           ret = mgAccFillMgcoVal(memCp,&(param->u.eq),(val->valInfo[0]));
           break;

       case MGT_VALUE_AND :
       case MGT_VALUE_OR :
           size = (val->num * (sizeof(MgMgcoValue*)));
           MG_ACC_GETMEM((param->u.and.vals),size,memCp );

           MG_ACC_INIT_TOKEN_VALUE(&(param->u.and.num),val->num);
           for(idx=0; idx<val->num; idx++)
           {
              MG_ACC_GETMEM((param->u.and.vals[idx]),sizeof(MgMgcoValue),memCp);
             
              ret = mgAccFillMgcoVal(memCp,(param->u.and.vals[idx]),
                                (val->valInfo[idx]));
              MG_ACC_CHK_RETVAL(ret);
           }
           break;

       case MGT_VALUE_RANGE :
           MG_ACC_INIT_TOKEN_VALUE(&(param->u.rng.pres),1);
           ret = mgAccFillMgcoVal(memCp,&(param->u.rng.low),(val->valInfo[0]));
           ret = mgAccFillMgcoVal(memCp,&(param->u.rng.up),(val->valInfo[1]));
           break;

       default :
          RETVALUE(RFAILED);
    }
    MG_ACC_INIT_TOKEN_VALUE(&(param->type),val->type);

    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillLocRemDesc
*
*       Desc:  Fills MgMgcoLocalDesc/MgMgcoRemoteDesc
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAccFillLocRemDesc
(
CmMemListCp             *memCp,
MgMgcoLocalDesc         *lclDesc,
MgMgcoAccLocRemDescInfo *info
)
#else
PUBLIC S16 mgAccFillLocRemDesc(memCp,lclDesc,info)
CmMemListCp             *memCp;
MgMgcoLocalDesc         *lclDesc;
MgMgcoAccLocRemDescInfo *info;
#endif
{
   S16                     ret = ROK;
   TRC3(mgAccFillLocRemDesc);

   if(TRUE != info->pres)
   {
      lclDesc->pres.pres = NOTPRSNT;
      RETVALUE(ROK);
   }
   MG_ACC_INIT_TOKEN_VALUE(&(lclDesc->pres),1);
   
   /* Fill Token Buf */

#ifdef CM_SDP_V_2
   /* Fill cmSdpInfoSet */
   if(NULLP != info->sdpInfo)
   {
      ret = mgAccFillSdpInfoSet(memCp,&(lclDesc->sdp),info->numSdp,info->sdpInfo);
   }
#endif

   RETVALUE(ret);
}

#ifdef CM_SDP_V_2
/*
*
*       Fun:   mgAccFillSdpInfoSet
*
*       Desc:  Fills CmSdpInfoSet
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAccFillSdpInfoSet
(
CmMemListCp             *memCp,
CmSdpInfoSet            *sdp,
U16                     num,
MgMgcoAccSdpInfo        **info
)
#else
PUBLIC S16 mgAccFillSdpInfoSet(memCp,sdp,num,info)
CmMemListCp             *memCp;
CmSdpInfoSet            *sdp;
U16                     num;
MgMgcoAccSdpInfo        **info;
#endif
{
   S16                     ret = ROK;
   RETVALUE(ret);
}

#endif /*CM_SDP_V_2*/

/*
*
*       Fun:   mgAccFillNonStdId
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAccFillNonStdId
(
CmMemListCp           *memCp,
MgMgcoNonStdId        *nonStdId,
MgMgcoAccNonStdIdInfo *nonStdInfo
)
#else
PUBLIC S16 mgAccFillNonStdId(memCp,nonStdId,nonStdInfo)
CmMemListCp           *memCp;
MgMgcoNonStdId        *nonStdId;
MgMgcoAccNonStdIdInfo *nonStdInfo;
#endif
{
   S16         ret = ROK;
   TRC3(mgAccFillNonStdId);

   switch(nonStdInfo->type)
   {
      case MGT_EXTNPARM_OPT:
      case MGT_EXTNPARM_MAND:
         MG_ACC_INIT_TKNSTR(&(nonStdId->u.extn),nonStdInfo->val,nonStdInfo->len);
         break;

      case MGT_NONSTD_OBJID:
         if(NULLP != nonStdInfo->val)
         {
            MG_ACC_INIT_TKNSTROSXL(&(nonStdId->u.objId),
                             nonStdInfo->val,nonStdInfo->len);
         }
         else
            ret = RFAILED;
         break;

      case MGT_NONSTD_H221:
         MG_ACC_INIT_TOKEN_VALUE(&(nonStdId->u.h221.pres),1);
         MG_ACC_INIT_TOKEN_VALUE(&(nonStdId->u.h221.t35cc1),nonStdInfo->t35cc1);
         MG_ACC_INIT_TOKEN_VALUE(&(nonStdId->u.h221.t35cc2),nonStdInfo->t35cc2);
         MG_ACC_INIT_TOKEN_VALUE(&(nonStdId->u.h221.t35ext),nonStdInfo->t35ext);
         MG_ACC_INIT_TOKEN_VALUE(&(nonStdId->u.h221.mfc),nonStdInfo->mfc);
         break;

      default:
         RETVALUE(RFAILED);
   }
   MG_ACC_INIT_TOKEN_VALUE(&(nonStdId->type),nonStdInfo->type);
   RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillNonStdExtn
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAccFillNonStdExtn
(
CmMemListCp             *memCp,
MgMgcoNonStdExtn        *nonStdEx,
MgMgcoAccNonStdExtnInfo *extn
)
#else
PUBLIC S16 mgAccFillNonStdExtn(memCp,nonStdEx,extn)
CmMemListCp             *memCp;
MgMgcoNonStdExtn        *nonStdEx;
MgMgcoAccNonStdExtnInfo *extn;
#endif
{
   S16         ret = ROK;
   TRC3(mgAccFillNonStdExtn);

   if(TRUE == extn->nonStdIdPres)
   {
      ret = mgAccFillNonStdId(memCp,&(nonStdEx->id),&(extn->nonStdId));
      MG_ACC_CHK_RETVAL(ret);
   }

   ret = mgAccFillParmValue(memCp,&(nonStdEx->val),&(extn->parmVal));
   RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillPropParm
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillPropParm
(
CmMemListCp           *memCp,
MgMgcoPropParm        *prop,
U8                    pkgId,
U8                    *pkgStr,
U8                    pkgLen,
U16                   pkgVal,
U8                    *str,
U8                    strLen,
MgMgcoAccParmVal      *val
)
#else
PUBLIC S16 mgAccFillPropParm(memCp,prop,pkgId,pkgStr,pkgLen,pkgVal,str,strLen,val)
CmMemListCp           *memCp;
MgMgcoPropParm        *prop;
U8                    pkgId;
U8                    *pkgStr;
U8                    pkgLen;
U16                   pkgVal;
U8                    *str;
U8                    strLen;
MgMgcoAccParmVal      *val;
#endif
{
    S16         ret = ROK;
    TRC3(mgAccFillPropParm);

    MG_ACC_INIT_TOKEN_VALUE(&(prop->pkg),pkgId);

    /* Fill package name */
    ret = mgAccFillMgcoName(&(prop->name.name),pkgStr,pkgLen,pkgVal);
    MG_ACC_CHK_RETVAL(ret);

    if(NULLP != str)
    {
       MG_ACC_INIT_TKNSTROSXL(&(prop->name.pkgName),str,strLen);
    }
 
    /* Fill parm value */
    ret = mgAccFillParmValue(memCp,&(prop->val),val);

    RETVALUE(ret);
}


/*
*
*       Fun:   mgAccFillLclCtlDesc
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillLclCtlDesc
(
CmMemListCp            *memCp,
MgMgcoLclCtlDesc       *lclCtl,
U16                    num,
MgMgcoAccLocalParmInfo **info
)
#else
PUBLIC S16 mgAccFillLclCtlDesc(memCp,lclCtl,num,info)
CmMemListCp            *memCp;
MgMgcoLclCtlDesc       *lclCtl;
U16                    num;
MgMgcoAccLocalParmInfo **info;
#endif
{
    S16      ret = ROK;
    U16      idx;
    Size     size;

    MG_ACC_INIT_TOKEN_VALUE(&(lclCtl->num),num);

    size = (num * (sizeof(MgMgcoLocalParm*)));
    MG_ACC_GETMEM((lclCtl->parms),size,memCp );

    for(idx=0;idx<num;idx++)
    {
       MG_ACC_GETMEM((lclCtl->parms[idx]),sizeof(MgMgcoLocalParm),memCp);
       switch(info[idx]->type)
       {
          case MGT_LCLCTL_MODE:
             /* Set stream mode */
             MG_ACC_INIT_TOKEN_VALUE(&(((lclCtl->parms)[idx])->u.mode),
                      (info[idx])->val);
             break;

          case MGT_LCLCTL_RESVAL:
             /* Set reserve value */
             MG_ACC_INIT_TOKEN_VALUE(&(((lclCtl->parms)[idx])->u.resVal),
                      (info[idx])->val);
             break;

          case MGT_LCLCTL_RESGRP:
             MG_ACC_INIT_TOKEN_VALUE(&(((lclCtl->parms)[idx])->u.resGrp),
                      (info[idx])->val);
             break;

          case MGT_LCLCTL_PROPPARM:
             ret = mgAccFillPropParm(memCp,
                          (&(((lclCtl->parms)[idx])->u.propParm)),
                          (info[idx])->par.pkgId,
                          (info[idx])->par.pkgStr,
                          (info[idx])->par.pkgLen,
                          (info[idx])->par.pkgVal,
                          (info[idx])->par.str,
                          (info[idx])->par.strLen,
                          &((info[idx])->par.val));
             MG_ACC_CHK_RETVAL(ret);
             break;

          default:
             RETVALUE(RFAILED);
       }
       MG_ACC_INIT_TOKEN_VALUE(&(((lclCtl->parms)[idx])->type),info[idx]->type);
   } /* end of for */
   RETVALUE(ret);
}

/*
*
*       Fun:   mgAccFillMediaDesc
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillMediaDesc
(
CmMemListCp            *memCp,
MgMgcoMediaDesc        *media,
U16                    numDesc,
MgMgcoAccMediaParInfo  **medInfo
)
#else
PUBLIC S16 mgAccFillMediaDesc(memCp,media,numDesc,medInfo)
CmMemListCp          *memCp;
MgMgcoMediaDesc      *media;
U16                  numDesc;
MgMgcoAccMediaParInfo  **medInfo;
#endif
{
    S16      ret = ROK;
    U16      idx = 0;
    Size     size;

    TRC3(mgAccFillMediaDesc);

    MG_ACC_INIT_TOKEN_VALUE(&(media->num), numDesc);

    size = (numDesc * (sizeof(MgMgcoMediaPar*)));
    MG_ACC_GETMEM((media->parms),size,memCp );
    for(idx=0; idx<numDesc; idx++)
    {
        if(NULLP == medInfo[idx] )
        {
            RETVALUE(RFAILED);
        }
        MG_ACC_GETMEM( ((media->parms)[idx]),sizeof(MgMgcoMediaPar),memCp);

        MG_ACC_INIT_TOKEN_VALUE(&(((media->parms)[idx])->type),(medInfo[idx])->type);

        switch( (medInfo[idx])->type )
        {
           case MGT_MEDIAPAR_LOCCTL :
              ret = mgAccFillLclCtlDesc(memCp,
                                &(((media->parms)[idx])->u.locCtl),
                                (medInfo[idx])->u.lcCtl.num,
                                (medInfo[idx])->u.lcCtl.par);
              break;

           case MGT_MEDIAPAR_LOCAL :
              ret = mgAccFillLocRemDesc(memCp,&(((media->parms)[idx])->u.local),
                             &(medInfo[idx]->u.locRem));
              break;

           case MGT_MEDIAPAR_REMOTE :
              ret = mgAccFillLocRemDesc(memCp,&(((media->parms)[idx])->u.remote),
                             &(medInfo[idx]->u.locRem));
              break;

           case MGT_MEDIAPAR_STRPAR :
              MG_ACC_INIT_TOKEN_VALUE(&(((media->parms)[idx])->u.stream.pres),1);

              /* STream Id */
              MG_ACC_INIT_TOKEN_VALUE(&(((media->parms)[idx])->u.stream.streamId),
                                  (medInfo[idx])->u.stream.strId);

              /* Fill MgMgcoStreamParm */
              MG_ACC_INIT_TOKEN_VALUE(&(((media->parms)[idx])->u.stream.sl.pres),1);

              /* Fill local and remote descriptor */
              ret = mgAccFillLocRemDesc(memCp,
                               &(((media->parms)[idx])->u.stream.sl.local),
                               &((medInfo[idx])->u.stream.local));
              MG_ACC_CHK_RETVAL(ret);
              ret = mgAccFillLocRemDesc(memCp,
                               &(((media->parms)[idx])->u.stream.sl.remote),
                               &((medInfo[idx])->u.stream.remote));
              MG_ACC_CHK_RETVAL(ret);

              /* Media Param local control */ 
              if(TRUE == medInfo[idx]->u.stream.lcCtl.pres)
              {
                  ret = mgAccFillLclCtlDesc(memCp,
                                &(((media->parms)[idx])->u.stream.sl.locCtl),
                                (medInfo[idx])->u.stream.lcCtl.num,
                                (medInfo[idx])->u.stream.lcCtl.par);
              }
              break;

           case MGT_MEDIAPAR_TERMST :
/* changes to reflect event structure change */
           {
            U8 j=1,i=0;

              if(TRUE == (medInfo[idx])->u.tState.stPres)
                  j++;

              if(TRUE == (medInfo[idx])->u.tState.evtCtPres)
                  j++;

              MG_ACC_GETMEM(((media->parms)[idx])->u.tstate.trmStPar,
                              j * sizeof(MgMgcoTermStateParm *),memCp);

              if(TRUE == (medInfo[idx])->u.tState.stPres)
              {
                  /* Service state */
                  MG_ACC_GETMEM(((media->parms)[idx])->u.tstate.trmStPar[i],
                                  sizeof(MgMgcoTermStateParm),memCp);
                  MG_ACC_INIT_TOKEN_VALUE(&(((media->parms)[idx])->u.tstate.
                                              trmStPar[i]->type),1);
                  MG_ACC_INIT_TOKEN_VALUE(&(((media->parms)[idx])->u.tstate.
                                              trmStPar[i++]->u.svcState),
                                  (medInfo[idx])->u.tState.state);
              }

              if(TRUE == (medInfo[idx])->u.tState.evtCtPres)
              {
                  /* Event buffer control */ 
                  MG_ACC_GETMEM(((media->parms)[idx])->u.tstate.trmStPar[i],
                                  sizeof(MgMgcoTermStateParm),memCp);
                  MG_ACC_INIT_TOKEN_VALUE(&(((media->parms)[idx])->u.tstate.
                                              trmStPar[i]->type),0);
                  MG_ACC_INIT_TOKEN_VALUE(&(((media->parms)[idx])->u.tstate.
                                              trmStPar[i++]->u.evtBufCtl),
                                  (medInfo[idx])->u.tState.evtBufCtl);
              }

              MG_ACC_GETMEM(((media->parms)[idx])->u.tstate.trmStPar[i],
                              sizeof(MgMgcoTermStateParm),memCp);
              MG_ACC_INIT_TOKEN_VALUE(&(((media->parms)[idx])->u.tstate.
                                          trmStPar[i]->type),2);
              ret = mgAccFillPropParm(memCp,
                                 &(((media->parms)[idx])->u.tstate.
                                     trmStPar[i++]->u.parm), 
                                 (medInfo[idx])->u.tState.par.pkgId,
                                 (medInfo[idx])->u.tState.par.pkgStr,
                                 (medInfo[idx])->u.tState.par.pkgLen,
                                 (medInfo[idx])->u.tState.par.pkgVal,
                                 (medInfo[idx])->u.tState.par.str,
                                 (medInfo[idx])->u.tState.par.strLen,
                                 &((medInfo[idx])->u.tState.par.val));
              MG_ACC_INIT_TOKEN_VALUE(&(((media->parms)[idx])->u.tstate.numComp),i);

               break;
            }

           default :
              ret = RFAILED;
        } /* End of switch */
        MG_ACC_CHK_RETVAL(ret);
    } /* End of for */

    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillModemDesc
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillModemDesc
(
CmMemListCp            *memCp,
MgMgcoModemDesc        *modem,
MgMgcoAccModemDescInfo *modInfo
)
#else
PUBLIC S16 mgAccFillModemDesc(memCp,modem,modInfo)
CmMemListCp            *memCp;
MgMgcoModemDesc        *modem;
MgMgcoAccModemDescInfo *modInfo;
#endif
{
    S16      ret=ROK;
    U16      idx;
    Size     size;

    TRC3(mgAccFillModemDesc);

    MG_ACC_INIT_TOKEN_VALUE(&(modem->pres),1);

    /* Number of modems */
    MG_ACC_INIT_TOKEN_VALUE(&(modem->mtl.num),modInfo->numMod);

    size = ((modInfo->numMod) * (sizeof(MgMgcoModemType*)));
    MG_ACC_GETMEM((modem->mtl.modems),size,memCp);
    for(idx=0; idx<modInfo->numMod; idx++)
    {
        MG_ACC_GETMEM(((modem->mtl.modems)[idx]),sizeof(MgMgcoModemType),memCp);

        /* Set modem type */
        MG_ACC_INIT_TOKEN_VALUE(&((modem->mtl.modems[idx])->type), 
                     (modInfo->modem[idx])->type);

        if(TRUE == (modInfo->modem[idx])->nonStdIdPres)
        {
           ret = mgAccFillNonStdId( memCp,&((modem->mtl.modems[idx])->extnId),
                             &((modInfo->modem[idx])->nonStdId) );
           MG_ACC_CHK_RETVAL(ret);
        }
    }

     /* Fill parameters if present */
    if(modInfo->numParms != 0)
    {
       /* Number of parameters */
       MG_ACC_INIT_TOKEN_VALUE(&(modem->mpl.num),modInfo->numParms);

       /* Fill all the parameters */
       size = ((modInfo->numParms) * (sizeof(MgMgcoPropParm*)));
       MG_ACC_GETMEM((modem->mpl.parms),size,memCp);
       for(idx=0;idx<modInfo->numParms;idx++)
       {
           MG_ACC_GETMEM(((modem->mpl.parms)[idx]),sizeof(MgMgcoPropParm),memCp);
   
           ret = mgAccFillPropParm(memCp,((modem->mpl.parms)[idx]),
                          modInfo->parm.pkgId,modInfo->parm.pkgStr,
                          modInfo->parm.pkgLen,modInfo->parm.pkgVal,modInfo->parm.str,
                          modInfo->parm.strLen,&(modInfo->parm.val)); 
           MG_ACC_CHK_RETVAL(ret);
       }
    }
    else
        modem->mpl.num.pres = NOTPRSNT;
    /* Fill non-standard extension */
    if(TRUE == modInfo->extPres)
    {
       ret = mgAccFillNonStdExtn(memCp,&(modem->extn),&(modInfo->ext));
    }

    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillMuxDesc
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillMuxDesc
(
CmMemListCp            *memCp,
MgMgcoMuxDesc          *mux,
MgMgcoAccMuxDescInfo   *muxInfo
)
#else
PUBLIC S16 mgAccFillMuxDesc(memCp,mux,muxInfo)
CmMemListCp            *memCp;
MgMgcoMuxDesc          *mux;
MgMgcoAccMuxDescInfo   *muxInfo;
#endif
{
    S16      ret=ROK;

    TRC3(mgAccFillMuxDesc);

    MG_ACC_INIT_TOKEN_VALUE(&(mux->pres),1);

    /* Set MUX type */
    MG_ACC_INIT_TOKEN_VALUE(&(mux->type),muxInfo->type);

    if(TRUE == muxInfo->nonStdIdPres)
    {
        ret = mgAccFillNonStdId(memCp,&(mux->id),&(muxInfo->nonStdId));
        MG_ACC_CHK_RETVAL(ret);
    }
    /* Allocates and fills termination ID list */
    if(muxInfo->numTerm > 0)
    {
        ret = mgAccFillTermIdLst(memCp,&(mux->tl),
                         muxInfo->numTerm,muxInfo->termInfo);
    }
    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillReqEvtDesc
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillReqEvtDesc
(
CmMemListCp             *memCp,
MgMgcoReqEvtDesc        *reqEvt,
MgMgcoAccReqEvtDescInfo *rEvtInfo
)
#else
PUBLIC S16 mgAccFillReqEvtDesc(memCp,reqEvt,rEvtInfo)
CmMemListCp             *memCp;
MgMgcoReqEvtDesc        *reqEvt;
MgMgcoAccReqEvtDescInfo *rEvtInfo;
#endif
{
    S16      ret = ROK;
    U16      idx = 0;
    Size     size;
    TRC3(mgAccFillReqEvtDesc);

    MG_ACC_INIT_TOKEN_VALUE(&(reqEvt->pres),1);

    /* Set request identifier */
    MG_ACC_INIT_TOKEN_VALUE(&(reqEvt->reqId.type),rEvtInfo->reqId.type);
    if(MGT_REQID_OTHER == rEvtInfo->reqId.type)
    {
       MG_ACC_INIT_TOKEN_VALUE(&(reqEvt->reqId.id),rEvtInfo->reqId.val);
    }

    MG_ACC_INIT_TOKEN_VALUE(&(reqEvt->el.num),rEvtInfo->numEvt);
    size = ((rEvtInfo->numEvt) * (sizeof(MgMgcoReqEvt*)));
    MG_ACC_GETMEM((reqEvt->el.revts),size,memCp);
    for(idx=0;idx<rEvtInfo->numEvt;idx++)
    {
        MG_ACC_GETMEM(((reqEvt->el.revts)[idx]),sizeof(MgMgcoReqEvt),memCp);

        ret = mgAccFillReqEvt(memCp,((reqEvt->el.revts)[idx]),rEvtInfo->evt[idx]);
        MG_ACC_CHK_RETVAL(ret);
    }
    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillReqEvt
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAccFillReqEvt
(
CmMemListCp             *memCp,
MgMgcoReqEvt            *reqEvt,
MgMgcoAccReqEvtInfo     *evt
)
#else
PUBLIC S16 mgAccFillReqEvt(memCp,reqEvt,evt)
CmMemListCp             *memCp;
MgMgcoReqEvt            *reqEvt;
MgMgcoAccReqEvtInfo     *evt;
#endif
{
    S16      ret = ROK;
    TRC3(mgAccFillReqEvt);

    MG_ACC_INIT_TOKEN_VALUE(&(reqEvt->pkg),evt->pkgId);

    /* Fill event name */
    ret = mgAccFillMgcoName(&(reqEvt->name.name),evt->pkg.str,
                    evt->pkg.len,evt->pkg.value);
    MG_ACC_CHK_RETVAL(ret);
    if(NULLP != evt->str)
    {
       MG_ACC_INIT_TKNSTROSXL(&(reqEvt->name.pkgName),evt->str,evt->strLen);
    }

    /*Fill parameter list */
    if(evt->numPar > 0)
    {
       ret = mgAccFillEvtParList(memCp,&(reqEvt->pl),evt->numPar,evt->par);
    }

    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillEvtSecLst
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAccFillEvtSecLst
(
CmMemListCp             *memCp,
MgMgcoEvtSecLst         *sl,
U16                     num,
MgMgcoAccEvtSecInfo     **slInfo
)
#else
PUBLIC S16 mgAccFillEvtSecLst(memCp,sl,num,slInfo)
CmMemListCp             *memCp;
MgMgcoEvtSecLst         *sl;
U16                     num;
MgMgcoAccEvtSecInfo     **slInfo;
#endif
{
    S16      ret = ROK;
    U16      idx = 0;
    U16      loop = 0;
    Size     size;

    TRC3(mgAccFillEvtSecLst);

    MG_ACC_INIT_TOKEN_VALUE(&(sl->num),num);

    size = (num * (sizeof(MgMgcoEvtSec*)));
    MG_ACC_GETMEM((sl->evts),size,memCp);
    for(idx=0; idx<num; idx++)
    {
        MG_ACC_GETMEM(((sl->evts)[idx]),sizeof(MgMgcoEvtSec),memCp);

        MG_ACC_INIT_TOKEN_VALUE(&(((sl->evts)[idx])->pkg),slInfo[idx]->pkgId);

        /* Fill name info */
        ret = mgAccFillMgcoName(&(sl->evts[idx]->name.name),slInfo[idx]->pkg.str,
                     slInfo[idx]->pkg.len,slInfo[idx]->pkg.value);
        MG_ACC_CHK_RETVAL(ret);
        if(NULLP != slInfo[idx]->str)
        {
           MG_ACC_INIT_TKNSTROSXL(&(sl->evts[idx]->name.pkgName),
                     slInfo[idx]->str,slInfo[idx]->strLen);
        }

        /* Fill MgMgcoEvtParSecLst */
        MG_ACC_INIT_TOKEN_VALUE(&(((sl->evts)[idx])->pl.num),slInfo[idx]->numPar);

        size = ((slInfo[idx]->numPar) * (sizeof(MgMgcoEvtParSec*)));
        MG_ACC_GETMEM((((sl->evts)[idx])->pl.parms),size,memCp);
        for(loop=0; loop<slInfo[idx]->numPar; loop++)
        {
           MG_ACC_GETMEM( (((sl->evts)[idx])->pl.parms[loop]),sizeof(MgMgcoEvtParSec),memCp);
           ret = mgAccFillParSec(memCp, (((sl->evts)[idx])->pl.parms[loop]),
                       slInfo[idx]->par[loop]);
            MG_ACC_CHK_RETVAL(ret);
        }
    }
    RETVALUE(ret);
}


/*
*
*       Fun:   mgAccFillParSec
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAccFillParSec
(
CmMemListCp             *memCp,
MgMgcoEvtParSec         *pSec,
MgMgcoAccParSecInfo     *secInfo
)
#else
PUBLIC S16 mgAccFillParSec(memCp,pSec,secInfo)
CmMemListCp             *memCp;
MgMgcoEvtParSec         *pSec;
MgMgcoAccParSecInfo     *secInfo;
#endif
{
    S16      ret = ROK;
    TRC3(mgAccFillParSec);

    switch(secInfo->type)
    {
       case MGT_EVTPAR_OTHER :
          MG_ACC_INIT_TOKEN_VALUE(&(pSec->type),MGT_EVTPAR_OTHER);
          ret = mgAccFillEvtOther(memCp,&(pSec->u.other),&(secInfo->name),
                        &(secInfo->valInfo));
          break;

       case MGT_EVTPAR_STREAMID :
          MG_ACC_INIT_TOKEN_VALUE(&(pSec->type),MGT_EVTPAR_STREAMID);
          MG_ACC_INIT_TOKEN_VALUE(&(pSec->u.streamId),secInfo->strId);
          break;

       case MGT_EVTPAR_EMBEDSIG:
          MG_ACC_INIT_TOKEN_VALUE(&(pSec->type),MGT_EVTPAR_EMBEDSIG);
          /* Fill signal descriptor */
          ret = mgAccFillSignalDesc(memCp,&(pSec->u.embSig),secInfo->numSig,
                          (secInfo->signal));
          break;

       case MGT_EVTPAR_DIGMAP :
          MG_ACC_INIT_TOKEN_VALUE(&(pSec->type),MGT_EVTPAR_DIGMAP);
          ret = mgAccFillEvtDM(memCp,&(pSec->u.dm),&(secInfo->dmInfo));
          break;

       case MGT_EVTPAR_KEEPACTIVE :
          MG_ACC_INIT_TOKEN_VALUE(&(pSec->type),MGT_EVTPAR_KEEPACTIVE);
          /* Nothin else to do. No field in union corresponding to this */
          break;

       default :
          ret = RFAILED;
          break;
    }/* end of switch */
    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillEvtDM
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAccFillEvtDM
(
CmMemListCp             *memCp,
MgMgcoEvtDM             *dm,
MgMgcoAccDigMapInfo     *dmInfo
)
#else
PUBLIC S16 mgAccFillEvtDM(memCp,dm,dmInfo)
CmMemListCp             *memCp;
MgMgcoEvtDM             *dm;
MgMgcoAccDigMapInfo     *dmInfo;
#endif
{
    S16      ret = ROK;
    TRC3(mgAccFillEvtDM);

    switch(dmInfo->type)
    {
       case MGT_DIGMAP_NAME :
          MG_ACC_INIT_TOKEN_VALUE(&(dm->type),MGT_DIGMAP_NAME);
          ret = mgAccFillMgcoName(&(dm->u.name),dmInfo->name.str,
                             dmInfo->name.len,dmInfo->name.value);
          break;

       case MGT_DIGMAP_VAL :
          MG_ACC_INIT_TOKEN_VALUE(&(dm->type),MGT_DIGMAP_VAL);
          ret = mgAccFillDigMapVal(memCp,&(dm->u.val),&(dmInfo->val));
          break;

       default :
          ret = RFAILED;
          break;
    }
    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillDigMapVal
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAccFillDigMapVal
(
CmMemListCp             *memCp,
MgMgcoDigMapVal         *dmv,
MgMgcoAccDigMapValInfo  *dmInfo
)
#else
PUBLIC S16 mgAccFillDigMapVal(memCp,dmv,dmInfo)
CmMemListCp             *memCp;
MgMgcoDigMapVal         *dmv;
MgMgcoAccDigMapValInfo  *dmInfo;
#endif
{
    S16      ret = ROK;
#if (!defined(GCP_VER_1_3) || !defined(GCP_MGCO_PARSE_DIG_MAP))
    U16      idx = 0;
    U16      loop = 0;
    Size     size;
#endif /* (!defined(GCP_VER_1_3) || !defined(GCP_MGCO_PARSE_DIG_MAP)) */
    TRC3(mgAccFillDigMapVal);

    MG_ACC_INIT_TOKEN_VALUE(&(dmv->pres),1);

    /* Set "t", "s" & "l" timer */
    MG_ACC_INIT_TOKEN_VALUE(&(dmv->t),dmInfo->tTmr);
    MG_ACC_INIT_TOKEN_VALUE(&(dmv->s),dmInfo->sTmr);
    MG_ACC_INIT_TOKEN_VALUE(&(dmv->l),dmInfo->lTmr);

    /* Set digit map */
#if defined (GCP_VER_1_3) && defined (GCP_MGCO_PARSE_DIG_MAP)
;
#else
    MG_ACC_INIT_TOKEN_VALUE(&(dmv->dm.num),dmInfo->numDs);
    size = ((idx<dmInfo->numDs) * (sizeof(MgMgcoDigMap*)));
    MG_ACC_GETMEM((dmv->dm.ds),size,memCp);
    for(idx=0; idx<dmInfo->numDs; idx++)
    {
        MG_ACC_GETMEM(((dmv->dm.ds)[idx]),sizeof(MgMgcoDigMap),memCp);
       
        /* Set elements per digit string */
        MG_ACC_INIT_TOKEN_VALUE(&(((dmv->dm.ds)[idx])->num),((dmInfo->ds)[idx])->numEl);
        size = ((((dmInfo->ds)[idx])->numEl) * (sizeof(MgMgcoDigStrElem*)));
        MG_ACC_GETMEM((((dmv->dm.ds)[idx])->elems),size,memCp);
        for(loop=0; loop<((dmInfo->ds)[idx])->numEl; loop++)
        {
           MG_ACC_GETMEM( ((((dmv->dm.ds)[idx])->elems)[loop]),
                                        sizeof(MgMgcoDigStrElem),memCp);
           switch( ((((dmInfo->ds)[idx])->el)[loop])->type )
           {
              case MGT_DIGSTR_RNG :
                 MG_ACC_INIT_TOKEN_VALUE(
                               &(((((dmv->dm.ds)[idx])->elems)[loop])->type), 
                               MGT_DIGSTR_RNG);
                if(MGT_DIGMAP_X == ((((dmInfo->ds)[idx])->el)[loop])->digRgType)
                {
                    MG_ACC_INIT_TOKEN_VALUE(
                         &(((((dmv->dm.ds)[idx])->elems)[loop])->u.range.type), 
                         MGT_DIGMAP_X);
                 }
                 else if(MGT_DIGSTR_LET ==  
                              ((((dmInfo->ds)[idx])->el)[loop])->digRgType)
                 {
                    MG_ACC_INIT_TOKEN_VALUE(
                         &(((((dmv->dm.ds)[idx])->elems)[loop])->u.range.type), 
                         MGT_DIGSTR_LET);
                    ret = mgAccFillDigMapLet(memCp, 
                        &(((((dmv->dm.ds)[idx])->elems)[loop])->u.range.u.let), 
                        ((((dmInfo->ds)[idx])->el)[loop])->numLet,
                        ((((dmInfo->ds)[idx])->el)[loop])->let);
                 }
                 else
                 {
                    RETVALUE(RFAILED);
                 }
                 break;

              case MGT_DIGSTR_LET :
                 MG_ACC_INIT_TOKEN_VALUE(
                               &(((((dmv->dm.ds)[idx])->elems)[loop])->type), 
                               MGT_DIGSTR_LET);
                 MG_ACC_INIT_TOKEN_VALUE(
                               &(((((dmv->dm.ds)[idx])->elems)[loop])->u.let), 
                               ((((dmInfo->ds)[idx])->el)[loop])->letVal);
                 break;

              default :
                 RETVALUE(RFAILED);
           }/* end of switch */ 
           MG_ACC_CHK_RETVAL(ret);
           if(TRUE == ((((dmInfo->ds)[idx])->el)[loop])->dotPres)
           {
              MG_ACC_INIT_TOKEN_VALUE(&(((((dmv->dm.ds)[idx])->elems)[loop])->dot),1); 
           }
        }/* End of for */
    } /* End of idx for */
#endif

    /* Set for binary */
    /*  Not required for ABNF encoding */

    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillDigMapLet
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillDigMapLet
(
CmMemListCp             *memCp,
MgMgcoDigMapLet         *dmLet,
U16                     num,
MgMgcoAccDigMapLetInfo  **letInfo
)
#else
PUBLIC S16 mgAccFillDigMapLet(memCp,dmLet,num,letInfo)
CmMemListCp             *memCp;
MgMgcoDigMapLet         *dmLet;
U16                     num;
MgMgcoAccDigMapLetInfo  **letInfo;
#endif
{
    S16      ret = ROK;
    U16      idx = 0;
    Size     size;

    TRC3(mgAccFillDigMapLet);

    MG_ACC_INIT_TOKEN_VALUE(&(dmLet->num),num);

    size = ((num) * (sizeof(MgMgcoDigRng*)));
    MG_ACC_GETMEM((dmLet->mapLets),size,memCp);
    for(idx=0; idx<num; idx++)
    {
        MG_ACC_GETMEM( ((dmLet->mapLets)[idx]),sizeof(MgMgcoDigRng),memCp);

        MG_ACC_INIT_TOKEN_VALUE(&(((dmLet->mapLets)[idx])->pres),1);
        MG_ACC_INIT_TOKEN_VALUE(&(((dmLet->mapLets)[idx])->low),letInfo[idx]->low);
        if(TRUE == letInfo[idx]->highPres)
        {
           MG_ACC_INIT_TOKEN_VALUE(&(((dmLet->mapLets)[idx])->up),letInfo[idx]->high);
        }
    }

    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillDigMapDesc
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillDigMapDesc
(
CmMemListCp             *memCp,
MgMgcoDigMapDesc        *digMap,
Bool                    namePres,
MgMgcoAccNameInfo       *name,
Bool                    valPres,
MgMgcoAccDigMapValInfo  *dmInfo
)
#else
PUBLIC S16 mgAccFillDigMapDesc(memCp,digMap,namePres,name,valPres,dmInfo)
CmMemListCp             *memCp;
MgMgcoDigMapDesc        *digMap;
Bool                    namePres;
MgMgcoAccNameInfo       *name;
Bool                    valPres;
MgMgcoAccDigMapValInfo  *dmInfo;
#endif
{
    S16      ret=ROK;

    TRC3(mgAccFillDigMapDesc);

    MG_ACC_INIT_TOKEN_VALUE(&(digMap->pres),1);

    if(TRUE == namePres)
    {
       /* Fill Parameter name */
       ret = mgAccFillMgcoName(&(digMap->name),name->str,name->len,name->value);
       MG_ACC_CHK_RETVAL(ret);
    }
    if(TRUE == valPres)
    {
       ret = mgAccFillDigMapVal(memCp,&(digMap->val),dmInfo);
       MG_ACC_CHK_RETVAL(ret);
    }
    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillEvtOther
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/
#ifdef ANSI
PUBLIC S16 mgAccFillEvtOther
(
CmMemListCp             *memCp,
MgMgcoEvtOther          *other,
MgMgcoAccNameInfo       *name,
MgMgcoAccParmVal        *valInfo
)
#else
PUBLIC S16 mgAccFillEvtOther(memCp,other,name,valInfo)
CmMemListCp             *memCp;
MgMgcoEvtOther          *other;
MgMgcoAccNameInfo       *name;
MgMgcoAccParmVal        *valInfo;
#endif
{
    S16      ret = ROK;
    TRC3(mgAccFillEvtOther);

    /* Fill Parameter name */
    ret = mgAccFillMgcoName(&(other->name),name->str,name->len,name->value);
    MG_ACC_CHK_RETVAL(ret);

    ret = mgAccFillParmValue(memCp,&(other->val),valInfo);
    MG_ACC_CHK_RETVAL(ret);

    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillEvtParList
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillEvtParList
(
CmMemListCp             *memCp,
MgMgcoEvtParLst         *pl,
U16                     numPar,
MgMgcoAccParInfo        **par
)
#else
PUBLIC S16 mgAccFillEvtParList(memCp,pl,numPar,par)
CmMemListCp             *memCp;
MgMgcoEvtParLst         *pl;
U16                     numPar;
MgMgcoAccParInfo        **par;
#endif
{
    S16      ret = ROK;
    U16      idx = 0;
    Size     size;
    TRC3(mgAccFillEvtParList);

    MG_ACC_INIT_TOKEN_VALUE(&(pl->num),numPar);

    size = ((numPar) * (sizeof(MgMgcoEvtPar*)));
    MG_ACC_GETMEM((pl->parms),size,memCp);
    for(idx=0;idx<numPar;idx++)
    {
        MG_ACC_GETMEM(((pl->parms)[idx]),sizeof(MgMgcoEvtPar),memCp);
        
        switch(par[idx]->parType)
        {
           case MGT_EVTPAR_OTHER :
              MG_ACC_INIT_TOKEN_VALUE(&(((pl->parms)[idx])->type),MGT_EVTPAR_OTHER);

              ret = mgAccFillEvtOther(memCp,&(((pl->parms)[idx])->u.other),
                           &(par[idx]->name),&(par[idx]->valInfo));
              break;

           case MGT_EVTPAR_STREAMID :
              MG_ACC_INIT_TOKEN_VALUE(&(((pl->parms)[idx])->type),MGT_EVTPAR_STREAMID);
              MG_ACC_INIT_TOKEN_VALUE(&(((pl->parms)[idx])->u.streamId),par[idx]->streamId);
              break;

           case MGT_EVTPAR_EMBEDWITHSIG :
              MG_ACC_INIT_TOKEN_VALUE(&(((pl->parms)[idx])->type),MGT_EVTPAR_EMBEDWITHSIG);
              MG_ACC_INIT_TOKEN_VALUE(&(((pl->parms)[idx])->u.embWithSig.pres),1);
 
              /* Fill signal descriptor */
              ret = mgAccFillSignalDesc(memCp,&(((pl->parms)[idx])->u.embWithSig.sig),
                                par[idx]->numSig,(par[idx]->signal));
              MG_ACC_CHK_RETVAL(ret);

              MG_ACC_INIT_TOKEN_VALUE(
                              &(((pl->parms)[idx])->u.embWithSig.emb.pres),1);

              /* Fill RequestId */
              MG_ACC_INIT_TOKEN_VALUE(
                       &(((pl->parms)[idx])->u.embWithSig.emb.reqId.type),
                       par[idx]->reqId.type);
              if(MGT_REQID_OTHER == par[idx]->reqId.type)
              {
                 MG_ACC_INIT_TOKEN_VALUE(
                       &(((pl->parms)[idx])->u.embWithSig.emb.reqId.id),
                       par[idx]->reqId.val);
              }
   
              /* Fill event security list */
              if(par[idx]->num > 0)
              {
                 ret = mgAccFillEvtSecLst(memCp,
                             &(((pl->parms)[idx])->u.embWithSig.emb.sl),
                             par[idx]->num, (par[idx]->sec));
              }
              break;

           case MGT_EVTPAR_EMBEDNOSIG :
              MG_ACC_INIT_TOKEN_VALUE(&(((pl->parms)[idx])->type),
                                                  MGT_EVTPAR_EMBEDNOSIG);
              MG_ACC_INIT_TOKEN_VALUE(&(((pl->parms)[idx])->u.embNoSig.pres),1);
              MG_ACC_INIT_TOKEN_VALUE(
                           &(((pl->parms)[idx])->u.embNoSig.reqId.type),
                           par[idx]->reqId.type);
              if(MGT_REQID_OTHER == par[idx]->reqId.type)
              {
                 MG_ACC_INIT_TOKEN_VALUE(
                           &(((pl->parms)[idx])->u.embNoSig.reqId.id),
                           par[idx]->reqId.val);
              }

              /* Fill event security list */
              if(par[idx]->num > 0)
              {
                 ret = mgAccFillEvtSecLst(memCp,
                                &(((pl->parms)[idx])->u.embNoSig.sl),
                                par[idx]->num, (par[idx]->sec));
              }
              break;

           case MGT_EVTPAR_DIGMAP :
              MG_ACC_INIT_TOKEN_VALUE(&(((pl->parms)[idx])->type),MGT_EVTPAR_DIGMAP);
              ret = mgAccFillEvtDM(memCp,&(((pl->parms)[idx])->u.dm),&(par[idx]->dmInfo));
              break;

           case MGT_EVTPAR_KEEPACTIVE :
              MG_ACC_INIT_TOKEN_VALUE(&(((pl->parms)[idx])->type),MGT_EVTPAR_DIGMAP);
              /* Nothin else to do. No field in union corresponding to this */
              break;

           default :
              ret = RFAILED;
              break;
        } /* end of switch */
        MG_ACC_CHK_RETVAL(ret);
    } /* End of for */

    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillEvBufDesc
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillEvBufDesc
(
CmMemListCp             *memCp,
MgMgcoEvBufDesc         *evBuf,
U16                     numEvt,
MgMgcoAccReqEvtInfo     *evtInfo
)
#else
PUBLIC S16 mgAccFillEvBufDesc(memCp,evBuf,numEvt,evtInfo)
CmMemListCp             *memCp;
MgMgcoEvBufDesc         *evBuf;
U16                     numEvt;
MgMgcoAccReqEvtInfo     *evtInfo;
#endif
{
    S16      ret=ROK;
    U16      idx = 0;
    Size     size;
    TRC3(mgAccFillEvBufDesc);

    /* Number of events */
    MG_ACC_INIT_TOKEN_VALUE(&(evBuf->num),numEvt);

    size = ((numEvt) * (sizeof(MgMgcoEvSpec*)));
    MG_ACC_GETMEM((evBuf->evts),size,memCp);
    for(idx=0;idx<numEvt;idx++)
    {
        MG_ACC_GETMEM(((evBuf->evts)[idx]),sizeof(MgMgcoEvSpec),memCp);

        ret = mgAccFillReqEvt(memCp,((evBuf->evts)[idx]),evtInfo);
        MG_ACC_CHK_RETVAL(ret);
    }

    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillSignalReq
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillSignalReq
(
CmMemListCp             *memCp,
MgMgcoSignalsReq        *sigReq,
MgMgcoAccSigReqInfo     *sigInfo
)
#else
PUBLIC S16 mgAccFillSignalReq(memCp,sigReq,sigInfo)
CmMemListCp             *memCp;
MgMgcoSignalsReq        *sigReq;
MgMgcoAccSigReqInfo     *sigInfo;
#endif
{
    S16      ret = ROK;
    U16      idx = 0;
    U16      loop = 0;
    Size     size;

    TRC3(mgAccFillSignalReq);

    /* Fill package ID */
    MG_ACC_INIT_TOKEN_VALUE(&(sigReq->pkg),sigInfo->pkgId);

    /* Fill Package name info */
    ret = mgAccFillMgcoName(&(sigReq->name.name),sigInfo->pkg.str,
                    sigInfo->pkg.len,sigInfo->pkg.value);
    MG_ACC_CHK_RETVAL(ret);
    if(NULLP != sigInfo->str)
    {
      MG_ACC_INIT_TKNSTROSXL(&(sigReq->name.pkgName),sigInfo->str,sigInfo->len);
    }

    /* Fill number of signal paramteres */
    MG_ACC_INIT_TOKEN_VALUE(&(sigReq->pl.num),sigInfo->numPar);

    size = ((sigInfo->numPar) * (sizeof(MgMgcoSigPar*)));
    MG_ACC_GETMEM((sigReq->pl.parms),size,memCp);
    for(idx=0;idx<sigInfo->numPar; idx++)
    {
        MG_ACC_GETMEM(((sigReq->pl.parms)[idx]),sizeof(MgMgcoSigPar),memCp);

        switch(((sigInfo->sig)[idx])->type)
        {
           case MGT_SIGPAR_OTHER :
              MG_ACC_INIT_TOKEN_VALUE(&(((sigReq->pl.parms)[idx])->type),MGT_SIGPAR_OTHER);
              ret = mgAccFillEvtOther(memCp,&(((sigReq->pl.parms)[idx])->u.other),
                                &(((sigInfo->sig)[idx])->other),
                                &(((sigInfo->sig)[idx])->valInfo));
              break;

           case MGT_SIGPAR_STREAMID :
              MG_ACC_INIT_TOKEN_VALUE(&(((sigReq->pl.parms)[idx])->type),MGT_SIGPAR_STREAMID);
              MG_ACC_INIT_TOKEN_VALUE(&(((sigReq->pl.parms)[idx])->u.streamId),
                                ((sigInfo->sig)[idx])->streamId);
              break;

           case MGT_SIGPAR_TYPE :
              MG_ACC_INIT_TOKEN_VALUE(&(((sigReq->pl.parms)[idx])->type),MGT_SIGPAR_TYPE);
              MG_ACC_INIT_TOKEN_VALUE(&(((sigReq->pl.parms)[idx])->u.type),
                                ((sigInfo->sig)[idx])->sType);
              break;

           case MGT_SIGPAR_DURATION :
              MG_ACC_INIT_TOKEN_VALUE(&(((sigReq->pl.parms)[idx])->type),MGT_SIGPAR_DURATION);
              MG_ACC_INIT_TOKEN_VALUE(&(((sigReq->pl.parms)[idx])->u.dura),
                                ((sigInfo->sig)[idx])->duration);
              break;

           case MGT_SIGPAR_NTFYCMPL :
              MG_ACC_INIT_TOKEN_VALUE(&(((sigReq->pl.parms)[idx])->type),MGT_SIGPAR_NTFYCMPL);
              MG_ACC_INIT_TOKEN_VALUE(&(((sigReq->pl.parms)[idx])->u.nc.num),
                                ((sigInfo->sig)[idx])->numNtfy);

              size = ((((sigInfo->sig)[idx])->numNtfy) * (sizeof(TknU8*)));
              MG_ACC_GETMEM((((sigReq->pl.parms)[idx])->u.nc.reasons),size,memCp);
              for(loop=0; loop<((sigInfo->sig)[idx])->numNtfy;loop++)
              {
                 MG_ACC_GETMEM(((((sigReq->pl.parms)[idx])->u.nc.reasons)[loop]),
                                sizeof(TknU8),memCp);

                 MG_ACC_INIT_TOKEN_VALUE(((((sigReq->pl.parms)[idx])->u.nc.reasons)[loop]),
                                ((sigInfo->sig)[idx])->ntfy[loop]);
              }
              break;

           case MGT_SIGPAR_KEEPACTIVE :
              MG_ACC_INIT_TOKEN_VALUE(&(((sigReq->pl.parms)[idx])->type),
                                 MGT_SIGPAR_KEEPACTIVE);
              /* Nothing else needs to be done */
              break;

           default :
              ret = RFAILED;
        }/* end of switch */
        MG_ACC_CHK_RETVAL(ret);
    } /* End of for */
    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillSignalDesc
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillSignalDesc
(
CmMemListCp             *memCp,
MgMgcoSignalsDesc       *signal,
U16                     numPar,
MgMgcoAccSigParInfo     **sigInfo
)
#else
PUBLIC S16 mgAccFillSignalDesc(memCp,signal,numPar,sigInfo)
CmMemListCp             *memCp;
MgMgcoSignalsDesc       *signal;
U16                     numPar;
MgMgcoAccSigParInfo     **sigInfo;
#endif
{
    S16      ret = ROK;
    U16      idx = 0;
    U16      loop = 0;
    Size     size;
    TRC3(mgAccFillSignalDesc);

    MG_ACC_INIT_TOKEN_VALUE(&(signal->pres),1);

    /* Number of params */
    MG_ACC_INIT_TOKEN_VALUE(&(signal->num),numPar);

    size = ((numPar) * (sizeof(MgMgcoSignalsParm*)));
    MG_ACC_GETMEM((signal->parms),size,memCp);
    for(idx=0;idx<numPar;idx++)
    {
        MG_ACC_GETMEM(((signal->parms)[idx]),sizeof(MgMgcoSignalsParm),memCp);
        switch((sigInfo[idx])->type)
        {   
           case MGT_SIGSPAR_REQ :
              MG_ACC_INIT_TOKEN_VALUE(&(((signal->parms)[idx])->type),MGT_SIGSPAR_REQ);
              ret = mgAccFillSignalReq(memCp,&(((signal->parms)[idx])->u.req), 
                                &(sigInfo[idx]->sigReq));
              MG_ACC_CHK_RETVAL(ret);
              break;

           case MGT_SIGSPAR_LST :
              MG_ACC_INIT_TOKEN_VALUE(&(((signal->parms)[idx])->type),MGT_SIGSPAR_LST);

              /* Fill MgMgcoSignalsLst */
              MG_ACC_INIT_TOKEN_VALUE(&(((signal->parms)[idx])->u.lst.pres),1);
              MG_ACC_INIT_TOKEN_VALUE(&(((signal->parms)[idx])->u.lst.id),sigInfo[idx]->id);

              /* Fill number of signal requests in the list */
              MG_ACC_INIT_TOKEN_VALUE(&(((signal->parms)[idx])->u.lst.pl.num),
                                sigInfo[idx]->numSig);
              
              size = ((sigInfo[idx]->numSig) * (sizeof(MgMgcoSignalsReq*)));
              MG_ACC_GETMEM((((signal->parms)[idx])->u.lst.pl.reqs),size,memCp);
              for(loop=0; loop<sigInfo[idx]->numSig; loop++)
              {
                 MG_ACC_GETMEM( ((((signal->parms)[idx])->u.lst.pl.reqs)[loop]),
                                sizeof(MgMgcoSignalsReq),memCp );

                 ret = mgAccFillSignalReq(memCp,
                                ((((signal->parms)[idx])->u.lst.pl.reqs)[loop]),
                                ((sigInfo[idx])->sigLst[loop]) );
                 MG_ACC_CHK_RETVAL(ret);
              }
              break;

           default :
              ret = RFAILED;
              break;
        }
    } /* End of for */
    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillObsEvtDesc
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillObsEvtDesc
(
CmMemListCp             *memCp,
MgMgcoObsEvtDesc        *obsEvt,
MgMgcoAccReqId          *reqId,
U16                     numEvt,
MgMgcoAccObsEvtInfo     **evtInfo
)
#else
PUBLIC S16 mgAccFillObsEvtDesc(memCp,obsEvt,reqId,numEvt,evtInfo)
CmMemListCp             *memCp;
MgMgcoObsEvtDesc        *obsEvt;
MgMgcoAccReqId          *reqId;
U16                     numEvt;
MgMgcoAccObsEvtInfo     **evtInfo;
#endif
{
    S16      ret = ROK;
    U16      idx = 0;
    Size     size;
    TRC3(mgAccFillObsEvtDesc);

    MG_ACC_INIT_TOKEN_VALUE(&(obsEvt->pres),1);

    /* Fill Request ID */
    MG_ACC_INIT_TOKEN_VALUE(&(obsEvt->reqId.type),reqId->type);
    if(MGT_REQID_OTHER == reqId->type)
    {
       MG_ACC_INIT_TOKEN_VALUE(&(obsEvt->reqId.id),reqId->val);
    }

    MG_ACC_INIT_TOKEN_VALUE(&(obsEvt->el.num),numEvt);
    size = ((numEvt) * (sizeof(MgMgcoObsEvt*)));
    MG_ACC_GETMEM((obsEvt->el.evts),size,memCp);
    for(idx=0;idx<numEvt;idx++)
    {
        MG_ACC_GETMEM(((obsEvt->el.evts)[idx]),sizeof(MgMgcoObsEvt),memCp);

        MG_ACC_INIT_TOKEN_VALUE(&(((obsEvt->el.evts)[idx])->pres),1);
        
        /* Set time stamp info */
        MG_ACC_INIT_TOKEN_VALUE(&(((obsEvt->el.evts)[idx])->time.pres),1); 
        MG_ACC_INIT_TKNSTR(&(((obsEvt->el.evts)[idx])->time.date),
                          evtInfo[idx]->date,8);
        MG_ACC_INIT_TKNSTR(&(((obsEvt->el.evts)[idx])->time.time),
                          evtInfo[idx]->tm,8);

        /* Set Package ID */
        MG_ACC_INIT_TOKEN_VALUE(&(((obsEvt->el.evts)[idx])->pkg),
                           evtInfo[idx]->pkgId);

        /* Set event name info */
        ret = mgAccFillMgcoName(&(((obsEvt->el.evts)[idx])->name.name),
                           evtInfo[idx]->evtName.str,evtInfo[idx]->evtName.len,
                           evtInfo[idx]->evtName.value);
        MG_ACC_CHK_RETVAL(ret);
        if(NULLP != evtInfo[idx]->str)
        {
           MG_ACC_INIT_TKNSTROSXL(&(((obsEvt->el.evts)[idx])->name.pkgName),
                           evtInfo[idx]->str,evtInfo[idx]->len);
        }
        if(evtInfo[idx]->numPar > 0)
        {
           /* Set parameter list */
           ret = mgAccFillEvtParList(memCp,&(((obsEvt->el.evts)[idx])->pl),
                           evtInfo[idx]->numPar,evtInfo[idx]->par);
        }
        MG_ACC_CHK_RETVAL(ret);
    }
    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillStatsDesc
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillStatsDesc
(
CmMemListCp             *memCp,
MgMgcoStatsDesc         *stats,
U16                     numPar,
MgMgcoAccStatsInfo      **stsInfo
)
#else
PUBLIC S16 mgAccFillStatsDesc(memCp,stats,numPar,stsInfo)
CmMemListCp             *memCp;
MgMgcoStatsDesc         *stats;
U16                     numPar;
MgMgcoAccStatsInfo      **stsInfo;
#endif
{
    S16      ret = ROK;
    U16      idx = 0;
    Size     size;
    TRC3(mgAccFillStatsDesc);

    MG_ACC_INIT_TOKEN_VALUE(&(stats->num),numPar);
 
    size = ((numPar) * (sizeof(MgMgcoStatsPar*)));
    MG_ACC_GETMEM((stats->parms),size,memCp);
    for(idx=0;idx<numPar;idx++)
    {
        MG_ACC_GETMEM(((stats->parms)[idx]),sizeof(MgMgcoStatsPar),memCp);

        /* Set package ID */
        MG_ACC_INIT_TOKEN_VALUE(&(((stats->parms)[idx])->pkg),
                           stsInfo[idx]->pkgId);
        
        /* Set package name */
        ret = mgAccFillMgcoName(&(((stats->parms)[idx])->name.name),
                           stsInfo[idx]->pkg.str,stsInfo[idx]->pkg.len,
                           stsInfo[idx]->pkg.value);
        MG_ACC_CHK_RETVAL(ret);
        if(NULLP != stsInfo[idx]->str)
        {
           MG_ACC_INIT_TKNSTROSXL(&(stats->parms[idx]->name.pkgName),
                           stsInfo[idx]->str,stsInfo[idx]->len);
        }

        /* Set value */
        ret = mgAccFillMgcoVal(memCp,&(((stats->parms)[idx])->val),
                           &(stsInfo[idx]->value));
        MG_ACC_CHK_RETVAL(ret);
    }
    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillPkgsDesc
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillPkgsDesc
(
CmMemListCp             *memCp,
MgMgcoPkgsDesc          *pkg,
U16                     numItem,
MgMgcoAccPkgItemInfo    **item
)
#else
PUBLIC S16 mgAccFillPkgsDesc(memCp,pkg,numItem,item)
CmMemListCp             *memCp;
MgMgcoPkgsDesc          *pkg;
U16                     numItem;
MgMgcoAccPkgItemInfo    **item;
#endif
{
    S16      ret=ROK;
    U16      idx = 0;
    Size     size;

    TRC3(mgAccFillPkgsDesc);

    MG_ACC_INIT_TOKEN_VALUE(&(pkg->num),numItem);
 
    size = ((numItem) * (sizeof(MgMgcoPkgsItem*)));
    MG_ACC_GETMEM((pkg->items),size,memCp);
    for(idx=0;idx<numItem;idx++)
    {
        MG_ACC_GETMEM(((pkg->items)[idx]),sizeof(MgMgcoPkgsItem),memCp);

        /* Fill name */
        ret = mgAccFillMgcoName(&(((pkg->items)[idx])->name),item[idx]->name.str,
                          item[idx]->name.len,item[idx]->name.value);
        MG_ACC_CHK_RETVAL(ret);

        /* Fill vertion */
        MG_ACC_INIT_TOKEN_VALUE(&(((pkg->items)[idx])->ver),item[idx]->ver);
    }
    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillTxnPend
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillTxnPend
(
MgMgcoTxnPend        *txnPend,
U32                  txnId
)
#else
PUBLIC S16 mgAccFillTxnPend(txnPend,txnId)
MgMgcoTxnPend        *txnPend;
U32                  txnId;
#endif
{
    TRC3(mgAccFillTxnPend);

    /* Txn Pending present */
    MG_ACC_INIT_TOKEN_VALUE(&(txnPend->pres), 1);

    /* Set the Txn Id which is pending */
    MG_ACC_INIT_TOKEN_VALUE(&(txnPend->transId), txnId);

    RETVALUE(ROK);
}



/*
*
*       Fun:   mgAccFillTxnRspAck
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillTxnRspAck
(
CmMemListCp          *memCp,
MgMgcoTxnRspAck      *rspAck,
U16                  numAck,
MgMgcoAccRspAck      **ack
)
#else
PUBLIC S16 mgAccFillTxnRspAck(memCp,rspAck,numAck,ack)
CmMemListCp          *memCp;
MgMgcoTxnRspAck      *rspAck;
U16                  numAck;
MgMgcoAccRspAck      **ack;
#endif
{
    U8            idx;
    Size          size;

    if(0 == numAck)
    {
        RETVALUE(RFAILED);
    }
    /* Initialize number of response acks */
    MG_ACC_INIT_TOKEN_VALUE(&(rspAck->num),numAck);

    size = ((numAck) * (sizeof(MgMgcoTxnAck*)));
    MG_ACC_GETMEM((rspAck->acks),size,memCp);
    /* Set the acknowledgements */
    for (idx=0; idx<numAck; idx++)
    {
        MG_ACC_GETMEM((rspAck->acks[idx]),sizeof(MgMgcoTxnAck),memCp);

        /* Mark resp ack as present */
        MG_ACC_INIT_TOKEN_VALUE(&(rspAck->acks[idx]->pres),1);

        /* Set the first val of range */
        MG_ACC_INIT_TOKEN_VALUE(&(rspAck->acks[idx]->first), ack[idx]->firstAck);

        /* Set the last val of range */
        MG_ACC_INIT_TOKEN_VALUE(&(rspAck->acks[idx]->last), ack[idx]->lastAck);
    }
    RETVALUE(ROK);
}



/*
*
*       Fun:   mgAccFillTxnReply
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillTxnReply
(
CmMemListCp           *memCp,
MgMgcoTxnReply        *txnRep,
U32                   txnId,
Bool                  ackReqd,  /* Immediate ack reqd */
U8                    repType,  /* MGT_ERRDESC/MGT_ACTIONREPLY */
MgMgcoAccErrDesc      *errDesc, /* valid if, repType = MGT_ERRDESC */
U16                   numRep,   /* Number of replies in reply list */
MgMgcoAccActnReplInfo **actnRep /* valid if repType = MGT_ACTIONREPLY */
)
#else
PUBLIC S16 mgAccFillTxnReply(memCp,txnRep,txnId,ackReqd,repType,errDesc,numRep,actnRep)
CmMemListCp           *memCp;
MgMgcoTxnReply        *txnRep;
U32                   txnId;
Bool                  ackReqd;  
U8                    repType; 
MgMgcoAccErrDesc      *errDesc;
U16                   numRep;
MgMgcoAccActnReplInfo **actnRep;
#endif
{
    S16        ret = ROK;
    U32        idx = 0;
    Size       size;

    TRC3(mgAccFillTxnReply);

    /* Action reply present */
    MG_ACC_INIT_TOKEN_VALUE(&(txnRep->pres), 1);
    
    /* Fill transaction ID */
    MG_ACC_INIT_TOKEN_VALUE(&(txnRep->transId), txnId);

    if(TRUE == ackReqd)
    {
        /* Immediate ack reqd */
        MG_ACC_INIT_TOKEN_VALUE(&(txnRep->immAck), 1);
    }
    else
    {
        txnRep->immAck.pres = NOTPRSNT;
    }

    switch(repType)
    {
        case MGT_ERRDESC :
            MG_ACC_INIT_TOKEN_VALUE(&(txnRep->type), MGT_ERRDESC);
            ret = mgAccFillErrDesc(&(txnRep->u.err),errDesc->errCode,
                             errDesc->errTxt,errDesc->errLen);
  
            break;

        case MGT_ACTIONREPLY :
            MG_ACC_INIT_TOKEN_VALUE(&(txnRep->type), MGT_ACTIONREPLY);

            MG_ACC_INIT_TOKEN_VALUE(&(txnRep->u.arl.num), numRep); 
            size = ((numRep) * (sizeof(MgMgcoActnReply*)));
            MG_ACC_GETMEM((txnRep->u.arl.repl),size,memCp);
            for(idx=0; idx<numRep; idx++)
            {
                /* Get memory for action reply */
                MG_ACC_GETMEM( ((txnRep->u.arl.repl)[idx]),sizeof(MgMgcoActnReply),memCp);

                /* Fill action reply */
                ret = mgAccFillMgcoActnReply(memCp,((txnRep->u.arl.repl)[idx]),
                               actnRep[idx]->repType,actnRep[idx]->cxt,
                               actnRep[idx]->cxtIdVal,
                               actnRep[idx]->fillCxtProp,&(actnRep[idx]->cxtInfo),
                               actnRep[idx]->fillCmdRep,actnRep[idx]->numRep,
                               &(actnRep[idx]->errDesc),(actnRep[idx]->cmdRep));
                 MG_ACC_CHK_RETVAL(ret);
            }
            break;

        default :
            ret = RFAILED;
            break;
    }
    RETVALUE(ret);
}



/*
*
*       Fun:   mgAccFillTxnReq
*
*       Desc:  
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: <NONE>
*
*       File:  mg_msg.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAccFillTxnReq
(
CmMemListCp           *memCp,
MgMgcoTxnReq          *txnReq,
U32                   transId,
U16                   numActn,  /* Number of actions */
MgMgcoAccActnReqInfo  **actnInfo
)
#else
PUBLIC S16 mgAccFillTxnReq(memCp,txnReq,transId,numActn,actnInfo)
MgMgcoTxnReq          *txnReq;
CmMemListCp           *memCp;
U32                   transId;
U16                   numActn;
MgMgcoAccActnReqInfo  **actnInfo;
#endif
{
    S16               ret = ROK;
    U16               idx = 0;
    Size              size;

    TRC3(mgAccFillTxnReq);

    MG_ACC_INIT_TOKEN_VALUE(&(txnReq->pres), 1);

    /* Set transaction ID */
    MG_ACC_INIT_TOKEN_VALUE(&(txnReq->transId), transId);

    /* Set number of actions */
    MG_ACC_INIT_TOKEN_VALUE(&(txnReq->al.num), numActn);
    
    size = ((numActn) * (sizeof(MgMgcoActionReq*)));
    MG_ACC_GETMEM((txnReq->al.actns),size,memCp);
    for(idx=0; idx<numActn; idx++)
    {
         MG_ACC_GETMEM( ((txnReq->al.actns)[idx]),sizeof(MgMgcoActionReq),memCp);
 
         if(MGT_CXTID_OTHER != actnInfo[idx]->cxtIdType)
         {
             MG_ACC_INIT_TOKEN_VALUE(&(((txnReq->al.actns)[idx])->cxtId.type), 
                              actnInfo[idx]->cxtIdType);
         }
         else
         {
             MG_ACC_INIT_TOKEN_VALUE(&(((txnReq->al.actns)[idx])->cxtId.type), 
                              actnInfo[idx]->cxtIdType);
             MG_ACC_INIT_TOKEN_VALUE(&(((txnReq->al.actns)[idx])->cxtId.val), 
                              actnInfo[idx]->cxtIdVal);
         }

         /* Initialize to not present */
         ((txnReq->al.actns)[idx])->pres.pres = NOTPRSNT;

         if(TRUE == actnInfo[idx]->cxtPropPres)
         {
             MG_ACC_INIT_TOKEN_VALUE(&(((txnReq->al.actns)[idx])->pres),1);
             ret = mgAccFillCxtProps(memCp,&(((txnReq->al.actns)[idx])->cxtProps),
                            (actnInfo[idx])->cxtProp.priorFlag,
                            (actnInfo[idx])->cxtProp.cxtPrior,(actnInfo[idx])->cxtProp.cxtEmerg,
                            (actnInfo[idx])->cxtProp.numTpl,(actnInfo[idx])->cxtProp.frmTerm,
                            (actnInfo[idx])->cxtProp.toTerm,(actnInfo[idx])->cxtProp.dir);
             MG_ACC_CHK_RETVAL(ret);
         }
         if(TRUE == actnInfo[idx]->cxtAudPres)
         {
             MG_ACC_INIT_TOKEN_VALUE(&(((txnReq->al.actns)[idx])->pres),1);
             MG_ACC_INIT_TOKEN_VALUE(&(((txnReq->al.actns)[idx])->cxtAud.pres),1);
             if(TRUE == actnInfo[idx]->cxtAudTop)
             {
                 MG_ACC_INIT_TOKEN_VALUE(&(((txnReq->al.actns)[idx])->cxtAud.topo),1);
             }
             if(TRUE == actnInfo[idx]->cxtAudEmerg)
             {
                 MG_ACC_INIT_TOKEN_VALUE(&(((txnReq->al.actns)[idx])->cxtAud.emerg),1);
             }
             if(TRUE == actnInfo[idx]->cxtAudPri)
             {
                 MG_ACC_INIT_TOKEN_VALUE(&(((txnReq->al.actns)[idx])->cxtAud.pri),1);
             }
         }
         if(TRUE == actnInfo[idx]->cmdReqPres)
         {
             MG_ACC_INIT_TOKEN_VALUE(&(((txnReq->al.actns)[idx])->pres),1);
             ret = mgAccFillCmdReqLst(memCp,&(((txnReq->al.actns)[idx])->cl),
                             actnInfo[idx]->numCmd,actnInfo[idx]->cmd);
             MG_ACC_CHK_RETVAL(ret);
         }
    } /* end of for loop */

    RETVALUE(ret);
}

#endif /* GCP_MGCO */


/********************************************************************30**

         End of file:     mg_msg.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:57:09 2005

*********************************************************************31*/
/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      VJ  1.Initial version
/main/1      ---      vj  1.Sample fn for filling MEGACO Txn Structure. 
           mg002.102  vj  1.Set the pres field in auditDescriptor, which 
                            has been added in mgt.x, in function 
                            mgAccFillAuditDesc
/main/2      ---      ra   1. GCP 1.3 release
/main/2    mg004.103  ra   1. Changes to reflect the MGT interface changes.
/main/3      ---      ka   1. Changes for Release v 1.4
/main/4      ---      pk   1. GCP 1.5 release
           mg002.105  ps   1. Removed patch reference for 1.3
                           2. Extern moved from mg.x for g++ compilation issue
           mg005.105  gk   1. Modified for the termination id wildcard
           mg008.105  gk   1. Corrected the Sanity check
*********************************************************************91*/
