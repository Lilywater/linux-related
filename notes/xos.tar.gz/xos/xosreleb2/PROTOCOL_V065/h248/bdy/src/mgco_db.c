/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Megaco database file

     Type:     C source file

     Desc:     global database definition elements for Megaco

     File:     mgco_db.c

     Sid:      mgco_db.c@@/main/mgcp_rel_1.5_mnt/3 - Fri Jun 24 18:38:59 2005

     Prg:      nct

*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tkns.h"       /* common token structures */
#include "cm_mblk.h"       /* common event memory management */
#include "cm_abnf.h"       /* ABNF header file */
#include "cm_inet.h"       /* Inet header file */
#include "cm_tpt.h"        /* Transport  header file */
#include "cm_sdp.h"
#include "cm_dns.h"
#ifdef ZG
#include "cm_ftha.h"
#include "cm_psfft.h"
#endif /* ZG */
#include "mgt.h"
#include "mgcopdb1.h"
#ifdef GCP_MGCO
#ifdef GCP_VER_1_3
#include "mgcopdb2.h"      /* [TEL]: Hash defines for megaco packages */
#include "mgcopdb3.h"      /* [TEL2]: Hash defines for megaco packages */
#endif /* GCP_VER_1_3 */
#endif /* GCP_MGCO */

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* common event memory management */
#include "cm_abnf.x"       /* ABNF header file */
#include "cm_lib.x"        /* common library file */
#include "cm_inet.x"       /* Inet header file */
#include "cm_tpt.x"        /* Transport  header file */
#include "cm_sdp.x"
#ifdef ZG
#include "cm_ftha.x"
#include "cm_psfft.x"
#endif /* ZG */
#include "mgt.x"
#include "cm_abndb.x"
#include "cm_sdpdb.x"
#include "mgco_db.x"
#include "mgcopdb1.x"
#ifdef GCP_MGCO
#ifdef GCP_VER_1_3
#include "mgcopdb2.x"      /* [TEL]: Extern declarations for megaco packages */
#include "mgcopdb3.x"      /* [TEL2]: Extern declarations for megaco packages */
#endif /* GCP_VER_1_3 */
#endif /* GCP_MGCO */

#ifdef GCP_MGCO
#ifdef GCP_CH

EXTERN PUBLIC S16 mgMgcoEscFuncCmdReqArray ARGS((
         U8            path,
         Buffer       *mBuf,
         U8           **event,
         U16           idNum,
         CmAbnfDecCp  *decCp,
         CmAbnfEncCp  *encCp
));
 
EXTERN PUBLIC S16 mgMgcoEscFuncCmdReqLst ARGS((
         U8            path,
         Buffer       *mBuf,
         U8           **event,
         U16           idNum,
         CmAbnfDecCp  *decCp,
         CmAbnfEncCp  *encCp
));

EXTERN PUBLIC S16 mgMgcoEscFuncCmdRepArray ARGS((
         U8            path,
         Buffer       *mBuf,
         U8           **event,
         U16           idNum,
         CmAbnfDecCp  *decCp,
         CmAbnfEncCp  *encCp
));
 
EXTERN PUBLIC S16 mgMgcoEscFuncCmdRepLst ARGS((
         U8            path,
         Buffer       *mBuf,
         U8           **event,
         U16           idNum,
         CmAbnfDecCp  *decCp,
         CmAbnfEncCp  *encCp
));


#endif /* GCP_CH  */

/* mg003.105: Add - Added new function for checking the presence of 
   method and reason of service change request */
EXTERN PUBLIC S16 mgMgcoEscFuncSvcChgReqDesc ARGS((
         U8            path,
         Buffer       *mBuf,
         U8           **event,
         U16           idNum,
         CmAbnfDecCp  *decCp,
         CmAbnfEncCp  *encCp
));


/************************************************************************/
/* Meta strings */
/* Don't appear anywhere in the event structure */

/************************************************************************/

PUBLIC CmAbnfElmTypeMeta mgMgcoWHyphenDefMeta = {(Data *)"W-"};

/* W- */
PUBLIC CmAbnfElmDef mgMgcoWHyphenDef   =
{
#ifdef CM_ABNF_DBG
   "W-",
   "W-",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 1,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoWHyphenDefMeta,
   mgMgcoRegExpWHyphen
};

/************************************************************************/

PUBLIC CmAbnfElmTypeMeta mgMgcoOHyphenDefMeta = {(Data *)"O-"};

/* O- */
PUBLIC CmAbnfElmDef mgMgcoOHyphenDef   =
{
#ifdef CM_ABNF_DBG
   "O-",
   "O-",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 2,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoOHyphenDefMeta,
   mgMgcoRegExpOHyphen
};

/************************************************************************/

PUBLIC CmAbnfElmTypeMeta mgMgcoTDefMeta = {(Data *)"T"};

/* T */
PUBLIC CmAbnfElmDef mgMgcoTDef   =
{
#ifdef CM_ABNF_DBG
   "T",
   "T",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 3,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoTDefMeta,
   mgMgcoRegExpT
};

/************************************************************************/

PUBLIC CmAbnfElmTypeMeta mgMgcoSDefMeta = {(Data *)"S"};

/* S */
PUBLIC CmAbnfElmDef mgMgcoSDef   =
{
#ifdef CM_ABNF_DBG
   "S",
   "S",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 4,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoSDefMeta,
   mgMgcoRegExpS
};

/************************************************************************/

PUBLIC CmAbnfElmTypeMeta mgMgcoLDefMeta = {(Data *)"L"};

/* L */
PUBLIC CmAbnfElmDef mgMgcoLDef   =
{
#ifdef CM_ABNF_DBG
   "L",
   "L",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 5,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoLDefMeta,
   mgMgcoRegExpL
};

/************************************************************************/
#ifdef MGT_MGCO_V2
/* milton-14 */
PUBLIC CmAbnfElmTypeMeta mgMgcoZDefMeta = {(Data *)"Z"};

/* Z */
PUBLIC CmAbnfElmDef mgMgcoZDef   =
{
#ifdef CM_ABNF_DBG
   "Z",
   "Z",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 999,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoZDefMeta,
   mgMgcoRegExpZ
};
#endif /* MGT_MGCO_V2 */
/* end milton-14 */
/************************************************************************/

PUBLIC CmAbnfElmTypeMeta mgMgcoLABRKTDefMeta = {(Data *)"<"};

/* LABRKT */
PUBLIC CmAbnfElmDef mgMgcoLABRKTDef   =
{
#ifdef CM_ABNF_DBG
   "<",
   "LABRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 6,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoLABRKTDefMeta,
   mgMgcoRegExpLABRKT
};

/************************************************************************/

PUBLIC CmAbnfElmTypeMeta mgMgcoRABRKTDefMeta = {(Data *)">"};

/* RABRKT */
PUBLIC CmAbnfElmDef mgMgcoRABRKTDef   =
{
#ifdef CM_ABNF_DBG
   ">",
   "RABRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 7,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoRABRKTDefMeta,
   mgMgcoRegExpRABRKT
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoLWSPPipeLWSPDefMeta = {(Data *)"|"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoLWSPPipeLWSPDefMeta = {(Data *)" | "};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* LWSPPipeLWSP                = LWSP "|" LWSP */
PUBLIC CmAbnfElmDef mgMgcoLWSPPipeLWSPDef   =
{
#ifdef CM_ABNF_DBG
   "LWSP | LWSP",
   "LWSPPipeLWSP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 8,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoLWSPPipeLWSPDefMeta,
   mgMgcoRegExpLWSPPipeLWSP
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoEQUALDefMeta = {(Data *)"="};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoEQUALDefMeta = {(Data *)" = "};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* EQUAL                = LWSP %x3D LWSP; "=" */
PUBLIC CmAbnfElmDef mgMgcoEQUALDef   =
{
#ifdef CM_ABNF_DBG
   "LWSP = LWSP",
   "EQUAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 9,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoEQUALDefMeta,
   mgMgcoRegExpEQUAL
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoGREATERTHANDefMeta = {(Data *)">"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoGREATERTHANDefMeta = {(Data *)" > "};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* GREATERTHAN                = LWSP ">" LWSP */
PUBLIC CmAbnfElmDef mgMgcoGREATERTHANDef   =
{
#ifdef CM_ABNF_DBG
   "LWSP > LWSP",
   "GREATERTHAN",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 10,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoGREATERTHANDefMeta,
   mgMgcoRegExpGREATERTHAN
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoLESSTHANDefMeta = {(Data *)"<"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoLESSTHANDefMeta = {(Data *)" < "};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* LESSTHAN                = LWSP "<" LWSP */
PUBLIC CmAbnfElmDef mgMgcoLESSTHANDef   =
{
#ifdef CM_ABNF_DBG
   "LWSP < LWSP",
   "LESSTHAN",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 11,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoLESSTHANDefMeta,
   mgMgcoRegExpLESSTHAN
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoNOTEQUALDefMeta = {(Data *)"#"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoNOTEQUALDefMeta = {(Data *)" # "};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* NOTEQUAL                = LWSP "#" LWSP */
PUBLIC CmAbnfElmDef mgMgcoNOTEQUALDef   =
{
#ifdef CM_ABNF_DBG
   "LWSP # LWSP",
   "NOTEQUAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 12,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoNOTEQUALDefMeta,
   mgMgcoRegExpNOTEQUAL
};

/************************************************************************/

PUBLIC CmAbnfElmTypeMeta mgMgcoStrictLSBRKTDefMeta = {(Data *)"["};

/* StrictLSBRKT                =  "["  */
PUBLIC CmAbnfElmDef mgMgcoStrictLSBRKTDef   =
{
#ifdef CM_ABNF_DBG
   "[",
   "StrictLSBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 13,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoStrictLSBRKTDefMeta,
   mgMgcoRegExpStrictLSBRKT
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoLSBRKTDefMeta = {(Data *)"["};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoLSBRKTDefMeta = {(Data *)" [ "};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* LSBRKT                = LWSP "[" LWSP */
PUBLIC CmAbnfElmDef mgMgcoLSBRKTDef   =
{
#ifdef CM_ABNF_DBG
   "LWSP [ LWSP",
   "LSBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 14,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoLSBRKTDefMeta,
   mgMgcoRegExpLSBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmTypeMeta mgMgcoStrictRSBRKTDefMeta = {(Data *)"]"};

/* StrictRSBRKT                =  "]"  */
PUBLIC CmAbnfElmDef mgMgcoStrictRSBRKTDef   =
{
#ifdef CM_ABNF_DBG
   "]",
   "StrictRSBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 15,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoStrictRSBRKTDefMeta,
   mgMgcoRegExpStrictRSBRKT
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoRSBRKTDefMeta = {(Data *)"]"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoRSBRKTDefMeta = {(Data *)" ] "};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* RSBRKT                = LWSP "]" LWSP */
PUBLIC CmAbnfElmDef mgMgcoRSBRKTDef   =
{
#ifdef CM_ABNF_DBG
   "LWSP ] LWSP",
   "RSBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 16,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoRSBRKTDefMeta,
   mgMgcoRegExpRSBRKT
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoLBRKTDefMeta = {(Data *)"{"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoLBRKTDefMeta = {(Data *)"{"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* LBRKT                = LWSP "{" LWSP */
PUBLIC CmAbnfElmDef mgMgcoLBRKTDef   =
{
#ifdef CM_ABNF_DBG
   "LWSP { LWSP",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 17,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoLBRKTDefMeta,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoRBRKTDefMeta = {(Data *)"}"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoRBRKTDefMeta = {(Data *)"}"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* RBRKT                = LWSP "}" LWSP */
PUBLIC CmAbnfElmDef mgMgcoRBRKTDef   =
{
#ifdef CM_ABNF_DBG
   "LWSP } LWSP",
   "RBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 18,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoRBRKTDefMeta,
   mgMgcoRegExpRBRKT
};

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoStrictRBRKTDefMeta = {(Data *)"}"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoStrictRBRKTDefMeta = {(Data *)"}"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* StrictRBRKT                = LWSP "}" LWSP */
PUBLIC CmAbnfElmDef mgMgcoStrictRBRKTDef   =
{
#ifdef CM_ABNF_DBG
   "LWSP }",
   "StrictRBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 19,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoStrictRBRKTDefMeta,
   mgMgcoRegExpStrictRBRKT
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoCOMMADefMeta = {(Data *)","};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoCOMMADefMeta = {(Data *)" , "};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* COMMA                = LWSP "," LWSP */
PUBLIC CmAbnfElmDef mgMgcoCOMMADef   =
{
#ifdef CM_ABNF_DBG
   "LWSP , LWSP",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 20,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoCOMMADefMeta,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef mgMgcoOptCOMMADef   =
{
#ifdef CM_ABNF_DBG
   "opt LWSP , LWSP",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 21,
   0,
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoCOMMADefMeta,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

PUBLIC CmAbnfElmTypeMeta mgMgcoSLASHDefMeta = {(Data *)"/"};

/* SLASH                = "/" */
PUBLIC CmAbnfElmDef mgMgcoSLASHDef   =
{
#ifdef CM_ABNF_DBG
   "/",
   "SLASH",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 22,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoSLASHDefMeta,
   mgMgcoRegExpSLASH
};

/************************************************************************/

PUBLIC CmAbnfElmTypeMeta mgMgcoLWSPDefMeta = {(Data *)" "};

/* LWSP                = " " */
PUBLIC CmAbnfElmDef mgMgcoLWSPDef   =
{
#ifdef CM_ABNF_DBG
   "LWSP",
   "LWSP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 23,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoLWSPDefMeta,
   mgMgcoRegExpLWSP
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoSEPDefMeta = {(Data *)" "};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoSEPDefMeta = {(Data *)"\r\n"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* SEP                  = ( WSP / EOL / COMMENT) LWSP */
PUBLIC CmAbnfElmDef mgMgcoSEPDef   =
{
#ifdef CM_ABNF_DBG
   "SEPerator",
   "RSEP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 24,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoSEPDefMeta,
   mgMgcoRegExpSEP
}; 

/************************************************************************/

/* Tokens */
/* Don't appear anywhere in the event structure */

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoMegacopTokenDefMeta = {(Data *)"!"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoMegacopTokenDefMeta = {(Data *)"MEGACO"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* MegacopToken               = ("MEGACO"                / "!") */
PUBLIC CmAbnfElmDef mgMgcoMegacopTokenDef   =
{
#ifdef CM_ABNF_DBG      
   "MEGACO",
   "RMegaco",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 25,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoMegacopTokenDefMeta,
   mgMgcoRegExpMegacopToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoAuthTokenDefMeta = {(Data *)"AU"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoAuthTokenDefMeta = {(Data *)"Authentication"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* AuthToken                  = ("Authentication"        / "AU") */
PUBLIC CmAbnfElmDef mgMgcoAuthTokenDef   =
{
#ifdef CM_ABNF_DBG
   "Authentication token",
   "AuthToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 26,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoAuthTokenDefMeta,
   mgMgcoRegExpAuthToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoAuditTokenDefMeta = {(Data *)"AT"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoAuditTokenDefMeta = {(Data *)"Audit"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* AuditToken                  = ("Audit"        / "AT") */
PUBLIC CmAbnfElmDef mgMgcoAuditTokenDef   =
{
#ifdef CM_ABNF_DBG
   "Audit token",
   "AuditToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 27,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoAuditTokenDefMeta,
   mgMgcoRegExpAuditToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoBufferTokenDefMeta = {(Data *)"BF"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoBufferTokenDefMeta = {(Data *)"Buffer"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* BufferToken                  = ("Buffer"        / "BF") */
PUBLIC CmAbnfElmDef mgMgcoBufferTokenDef =
{
#ifdef CM_ABNF_DBG
   "Buffer token",
   "BufferToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 28,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoBufferTokenDefMeta,
   mgMgcoRegExpBufferToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoContextAuditTokenDefMeta = {(Data *)"CA"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoContextAuditTokenDefMeta = 
   {(Data *)"ContextAudit"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* ContextAuditToken                  = ("ContextAudit"        / "CA") */
PUBLIC CmAbnfElmDef mgMgcoContextAuditTokenDef =
{
#ifdef CM_ABNF_DBG
   "ContextAudit token",
   "ContextAuditToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 29,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoContextAuditTokenDefMeta,
   mgMgcoRegExpContextAuditToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoCtxTokenDefMeta = {(Data *)"C"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoCtxTokenDefMeta = {(Data *)"Context"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* CtxToken                  = ("Context"        / "C") */
PUBLIC CmAbnfElmDef mgMgcoCtxTokenDef =
{
#ifdef CM_ABNF_DBG
   "Context token",
   "CtxToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 30,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoCtxTokenDefMeta,
   mgMgcoRegExpCtxToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoDelayTokenDefMeta = {(Data *)"DL"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoDelayTokenDefMeta = {(Data *)"Delay"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* DelayToken                  = ("Delay"        / "DL") */
PUBLIC CmAbnfElmDef mgMgcoDelayTokenDef =
{
#ifdef CM_ABNF_DBG
   "Delay token",
   "DelayToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 31,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoDelayTokenDefMeta,
   mgMgcoRegExpDelayToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoDigitMapTokenDefMeta = {(Data *)"DM"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoDigitMapTokenDefMeta = {(Data *)"DigitMap"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* DigitMapToken                  = ("DigitMap"        / "DM") */
PUBLIC CmAbnfElmDef mgMgcoDigitMapTokenDef =
{
#ifdef CM_ABNF_DBG
   "DigitMap token",
   "DigitMapToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 32,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoDigitMapTokenDefMeta,
   mgMgcoRegExpDigitMapToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoDurationTokenDefMeta = {(Data *)"DR"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoDurationTokenDefMeta = {(Data *)"Duration"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* DurationToken                  = ("Duration"        / "DR") */
PUBLIC CmAbnfElmDef mgMgcoDurationTokenDef =
{
#ifdef CM_ABNF_DBG
   "Duration token",
   "DurationToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 33,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoDurationTokenDefMeta,
   mgMgcoRegExpDurationToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoEmbedTokenDefMeta = {(Data *)"EM"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoEmbedTokenDefMeta = {(Data *)"Embed"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* EmbedToken                  = ("Embed"        / "EM") */
PUBLIC CmAbnfElmDef mgMgcoEmbedTokenDef =
{
#ifdef CM_ABNF_DBG
   "Embed token",
   "EmbedToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 34,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoEmbedTokenDefMeta,
   mgMgcoRegExpEmbedToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoEmergencyTokenDefMeta = {(Data *)"EG"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoEmergencyTokenDefMeta = {(Data *)"Emergency"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* EmergencyToken                  = ("Emergency"        / "EG") */
PUBLIC CmAbnfElmDef mgMgcoEmergencyTokenDef =
{
#ifdef CM_ABNF_DBG
   "Emergency token",
   "EmergencyToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 35,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoEmergencyTokenDefMeta,
   mgMgcoRegExpEmergencyToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoEmergencyOffTokenDefMeta = {(Data *)"EGO"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoEmergencyOffTokenDefMeta = {(Data *)"EmergencyOff"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* EmergencyOffToken                  = ("EmergencyOff"        / "EGO") */
PUBLIC CmAbnfElmDef mgMgcoEmergencyOffTokenDef =
{
#ifdef CM_ABNF_DBG
   "EmergencyOff token",
   "EmergencyOffToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 35,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoEmergencyOffTokenDefMeta,
   mgMgcoRegExpEmergencyOffToken
};


/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoErrorTokenDefMeta = {(Data *)"ER"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoErrorTokenDefMeta = {(Data *)"Error"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* ErrorToken                  = ("Error"        / "ER") */
PUBLIC CmAbnfElmDef mgMgcoErrorTokenDef =
{
#ifdef CM_ABNF_DBG
   "Error token",
   "ErrorToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 36,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoErrorTokenDefMeta,
   mgMgcoRegExpErrorToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoEventBufferTokenDefMeta = {(Data *)"EB"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoEventBufferTokenDefMeta = {(Data *)"EventBuffer"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* EventBufferToken                  = ("EventBuffer"        / "EB") */
/* Note: Conflicts with embed, sloppy spec */
PUBLIC CmAbnfElmDef mgMgcoEventBufferTokenDef =
{
#ifdef CM_ABNF_DBG
   "EventBuffer token",
   "EventBufferToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 37,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoEventBufferTokenDefMeta,
   mgMgcoRegExpEventBufferToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoEventsTokenDefMeta = {(Data *)"E"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoEventsTokenDefMeta = {(Data *)"Events"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* EventsToken                  = ("Events"        / "E") */
PUBLIC CmAbnfElmDef mgMgcoEventsTokenDef =
{
#ifdef CM_ABNF_DBG
   "Events token",
   "EventsToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 38,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoEventsTokenDefMeta,
   mgMgcoRegExpEventsToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoLocalTokenDefMeta = {(Data *)"L"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoLocalTokenDefMeta = {(Data *)"Local"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* LocalToken                  = ("Local"        / "L") */
PUBLIC CmAbnfElmDef mgMgcoLocalTokenDef =
{
#ifdef CM_ABNF_DBG
   "Local token",
   "LocalToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 39,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoLocalTokenDefMeta,
   mgMgcoRegExpLocalToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoLocalControlTokenDefMeta = {(Data *)"O"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoLocalControlTokenDefMeta = 
   {(Data *)"LocalControl"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* LocalControlToken                  = ("LocalControl"        / "O") */
PUBLIC CmAbnfElmDef mgMgcoLocalControlTokenDef =
{
#ifdef CM_ABNF_DBG
   "LocalControl token",
   "LocalControlToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 40,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoLocalControlTokenDefMeta,
   mgMgcoRegExpLocalControlToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoMediaTokenDefMeta = {(Data *)"M"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoMediaTokenDefMeta = {(Data *)"Media"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* MediaToken                  = ("Media"        / "M") */
PUBLIC CmAbnfElmDef mgMgcoMediaTokenDef =
{
#ifdef CM_ABNF_DBG
   "Media token",
   "MediaToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 41,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoMediaTokenDefMeta,
   mgMgcoRegExpMediaToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoMethodTokenDefMeta = {(Data *)"MT"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoMethodTokenDefMeta = {(Data *)"Method"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* MethodToken                  = ("Method"        / "MT") */
PUBLIC CmAbnfElmDef mgMgcoMethodTokenDef =
{
#ifdef CM_ABNF_DBG
   "Method token",
   "MethodToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 42,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoMethodTokenDefMeta,
   mgMgcoRegExpMethodToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
       /* changed , it was "MT" */
PUBLIC CmAbnfElmTypeMeta mgMgcoSignalsTokenDefMeta = {(Data *)"SG"};  
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoSignalsTokenDefMeta = {(Data *)"Signals"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* SignalsToken                  = ("Signals"        / "SG") */
PUBLIC CmAbnfElmDef mgMgcoSignalsTokenDef =
{
#ifdef CM_ABNF_DBG
   "Signals token",
   "SignalsToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 43,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoSignalsTokenDefMeta,
   mgMgcoRegExpSignalsToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoMgcIdTokenDefMeta = {(Data *)"MG"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoMgcIdTokenDefMeta = {(Data *)"MgcIdToTry"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* MgcIdToken                  = ("MgcIdToTry"        / "MG") */
PUBLIC CmAbnfElmDef mgMgcoMgcIdTokenDef =
{
#ifdef CM_ABNF_DBG
   "MgcId token",
   "MgcIdToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 44,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoMgcIdTokenDefMeta,
   mgMgcoRegExpMgcIdToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoModemTokenDefMeta = {(Data *)"MD"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoModemTokenDefMeta = {(Data *)"Modem"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* ModemToken                  = ("Modem"        / "MD") */
PUBLIC CmAbnfElmDef mgMgcoModemTokenDef =
{
#ifdef CM_ABNF_DBG
   "Modem token",
   "ModemToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 45,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoModemTokenDefMeta,
   mgMgcoRegExpModemToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoModeTokenDefMeta = {(Data *)"MO"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoModeTokenDefMeta = {(Data *)"Mode"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* ModeToken                  = ("Mode"        / "MO") */
PUBLIC CmAbnfElmDef mgMgcoModeTokenDef =
{
#ifdef CM_ABNF_DBG
   "Mode token",
   "ModeToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 46,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoModeTokenDefMeta,
   mgMgcoRegExpModeToken
};

/************************************************************************/

PUBLIC CmAbnfElmTypeMeta mgMgcoMtpTokenDefMeta = {(Data *)"MTP"};

/* MTPToken                  = "MTP" */
PUBLIC CmAbnfElmDef mgMgcoMtpTokenDef =
{
#ifdef CM_ABNF_DBG
   "Mtp token",
   "MtpToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 47,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoMtpTokenDefMeta,
   mgMgcoRegExpMtpToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoMuxTokenDefMeta = {(Data *)"MX"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoMuxTokenDefMeta = {(Data *)"Mux"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* MuxToken                  = ("Mux"        / "MX") */
PUBLIC CmAbnfElmDef mgMgcoMuxTokenDef =
{
#ifdef CM_ABNF_DBG
   "Mux token",
   "MuxToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 48,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoMuxTokenDefMeta,
   mgMgcoRegExpMuxToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoNotifyCompletionTokenDefMeta = {(Data *)"NC"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoNotifyCompletionTokenDefMeta = 
   {(Data *)"NotifyCompletion"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* NotifyCompletionToken       = ("NotifyCompletion"        / "NC") */
PUBLIC CmAbnfElmDef mgMgcoNotifyCompletionTokenDef =
{
#ifdef CM_ABNF_DBG
   "NotifyCompletion token",
   "NotifyCompletionToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 49,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoNotifyCompletionTokenDefMeta,
   mgMgcoRegExpNotifyCompletionToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoObservedEventsTokenDefMeta = {(Data *)"OE"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoObservedEventsTokenDefMeta = 
   {(Data *)"ObservedEvents"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* ObservedEventsToken                  = ("ObservedEvents"        / "OE") */
PUBLIC CmAbnfElmDef mgMgcoObservedEventsTokenDef =
{
#ifdef CM_ABNF_DBG
   "ObservedEvents token",
   "ObservedEventsToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 50,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoObservedEventsTokenDefMeta,
   mgMgcoRegExpObservedEventsToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoPackagesTokenDefMeta = {(Data *)"PG"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoPackagesTokenDefMeta = {(Data *)"Packages"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* PackagesToken                  = ("Packages"        / "PG") */
PUBLIC CmAbnfElmDef mgMgcoPackagesTokenDef =
{
#ifdef CM_ABNF_DBG
   "Packages token",
   "PackagesToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 51,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoPackagesTokenDefMeta,
   mgMgcoRegExpPackagesToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoPriorityTokenDefMeta = {(Data *)"PR"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoPriorityTokenDefMeta = {(Data *)"Priority"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* PriorityToken                  = ("Priority"        / "PR") */
PUBLIC CmAbnfElmDef mgMgcoPriorityTokenDef =
{
#ifdef CM_ABNF_DBG
   "Priority token",
   "PriorityToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 52,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoPriorityTokenDefMeta,
   mgMgcoRegExpPriorityToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoProfileTokenDefMeta = {(Data *)"PF"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoProfileTokenDefMeta = {(Data *)"Profile"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* ProfileToken                  = ("Profile"        / "PF") */
PUBLIC CmAbnfElmDef mgMgcoProfileTokenDef =
{
#ifdef CM_ABNF_DBG
   "Profile token",
   "ProfileToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 53,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoProfileTokenDefMeta,
   mgMgcoRegExpProfileToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoReasonTokenDefMeta = {(Data *)"RE"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoReasonTokenDefMeta = {(Data *)"Reason"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* ReasonToken                  = ("Reason"        / "RE") */
PUBLIC CmAbnfElmDef mgMgcoReasonTokenDef =
{
#ifdef CM_ABNF_DBG
   "Reason token",
   "ReasonToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 54,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoReasonTokenDefMeta,
   mgMgcoRegExpReasonToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoRemoteTokenDefMeta = {(Data *)"R"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoRemoteTokenDefMeta = {(Data *)"Remote"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* RemoteToken                  = ("Remote"        / "R") */
PUBLIC CmAbnfElmDef mgMgcoRemoteTokenDef =
{
#ifdef CM_ABNF_DBG
   "Remote token",
   "RemoteToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 55,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoRemoteTokenDefMeta,
   mgMgcoRegExpRemoteToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoReservedGroupTokenDefMeta = {(Data *)"RG"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoReservedGroupTokenDefMeta = {(Data *)"ReservedGroup"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* ReservedGroupToken                  = ("ReservedGroup"        / "RG") */
PUBLIC CmAbnfElmDef mgMgcoReservedGroupTokenDef =
{
#ifdef CM_ABNF_DBG
   "ReservedGroup token",
   "ReservedGroupToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 56,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoReservedGroupTokenDefMeta,
   mgMgcoRegExpReservedGroupToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoReservedValueTokenDefMeta = {(Data *)"RV"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoReservedValueTokenDefMeta = {(Data *)"ReservedValue"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* ReservedValueToken                  = ("ReservedValue"        / "RV") */
PUBLIC CmAbnfElmDef mgMgcoReservedValueTokenDef =
{
#ifdef CM_ABNF_DBG
   "ReservedValue token",
   "ReservedValueToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 57,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoReservedValueTokenDefMeta,
   mgMgcoRegExpReservedValueToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoServiceChangeAddressTokenDefMeta = 
   {(Data *)"AD"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoServiceChangeAddressTokenDefMeta = 
   {(Data *)"ServiceChangeAddress"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* ServiceChangeAddressToken      = ("ServiceChangeAddress"        / "AD") */
PUBLIC CmAbnfElmDef mgMgcoServiceChangeAddressTokenDef =
{
#ifdef CM_ABNF_DBG
   "ServiceChangeAddress token",
   "ServiceChangeAddressToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 58,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoServiceChangeAddressTokenDefMeta,
   mgMgcoRegExpServiceChangeAddressToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoServiceStatesTokenDefMeta = {(Data *)"SI"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoServiceStatesTokenDefMeta = 
   {(Data *)"ServiceStates"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* ServiceStatesToken                  = ("ServiceStates"        / "SI") */
PUBLIC CmAbnfElmDef mgMgcoServiceStatesTokenDef =
{
#ifdef CM_ABNF_DBG
   "ServiceStates token",
   "ServiceStatesToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 59,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoServiceStatesTokenDefMeta,
   mgMgcoRegExpServiceStatesToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoServicesTokenDefMeta = {(Data *)"SV"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoServicesTokenDefMeta = {(Data *)"Services"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* ServicesToken                  = ("Services"        / "SV") */
PUBLIC CmAbnfElmDef mgMgcoServicesTokenDef =
{
#ifdef CM_ABNF_DBG
   "Services token",
   "ServicesToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 60,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoServicesTokenDefMeta,
   mgMgcoRegExpServicesToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoSignalListTokenDefMeta = {(Data *)"SL"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoSignalListTokenDefMeta = {(Data *)"SignalList"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* SignalListToken                  = ("SignalList"        / "SL") */
PUBLIC CmAbnfElmDef mgMgcoSignalListTokenDef =
{
#ifdef CM_ABNF_DBG
   "SignalList token",
   "SignalListToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 61,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoSignalListTokenDefMeta,
   mgMgcoRegExpSignalListToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoStatsTokenDefMeta = {(Data *)"SA"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoStatsTokenDefMeta = {(Data *)"Statistics"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* StatsToken                  = ("Statistics"        / "SA") */
PUBLIC CmAbnfElmDef mgMgcoStatsTokenDef =
{
#ifdef CM_ABNF_DBG
   "Stats token",
   "StatsToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 62,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoStatsTokenDefMeta,
   mgMgcoRegExpStatsToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoStreamTokenDefMeta = {(Data *)"ST"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoStreamTokenDefMeta = {(Data *)"Stream"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* StreamToken                  = ("Stream"        / "ST") */
PUBLIC CmAbnfElmDef mgMgcoStreamTokenDef =
{
#ifdef CM_ABNF_DBG
   "Stream token",
   "StreamToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 63,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoStreamTokenDefMeta,
   mgMgcoRegExpStreamToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoTerminationStateTokenDefMeta = {(Data *)"TS"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoTerminationStateTokenDefMeta = 
   {(Data *)"TerminationState"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* TerminationStateToken        = ("TerminationState"        / "TS") */
PUBLIC CmAbnfElmDef mgMgcoTerminationStateTokenDef =
{
#ifdef CM_ABNF_DBG
   "TerminationState token",
   "TerminationStateToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 64,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoTerminationStateTokenDefMeta,
   mgMgcoRegExpTerminationStateToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoTopologyTokenDefMeta = {(Data *)"TP"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoTopologyTokenDefMeta = {(Data *)"Topology"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* TopologyToken                  = ("Topology"        / "TP") */
PUBLIC CmAbnfElmDef mgMgcoTopologyTokenDef =
{
#ifdef CM_ABNF_DBG
   "Topology token",
   "TopologyToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 65,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoTopologyTokenDefMeta,
   mgMgcoRegExpTopologyToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoVersionTokenDefMeta = {(Data *)"V"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoVersionTokenDefMeta = {(Data *)"Version"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* VersionToken                  = ("Version"        / "V") */
PUBLIC CmAbnfElmDef mgMgcoVersionTokenDef =
{
#ifdef CM_ABNF_DBG
   "Version token",
   "VersionToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 66,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoVersionTokenDefMeta,
   mgMgcoRegExpVersionToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoKeepActiveTokenDefMeta = {(Data *)"KA"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoKeepActiveTokenDefMeta = {(Data *)"KeepActive"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* KeepActiveToken                  = ("KeepActive"        / "KA") */
PUBLIC CmAbnfElmDef mgMgcoKeepActiveTokenDef =
{
#ifdef CM_ABNF_DBG
   "KeepActive token",
   "KeepActiveToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 67,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoKeepActiveTokenDefMeta,
   mgMgcoRegExpKeepActiveToken
};

/************************************************************************/

#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoSignalTypeTokenDefMeta = {(Data *)"SY"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoSignalTypeTokenDefMeta = {(Data *)"SignalType"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* SignalTypeToken                  = ("SignalType"        / "SY") */
PUBLIC CmAbnfElmDef mgMgcoSignalTypeTokenDef =
{
#ifdef CM_ABNF_DBG
   "SignalType token",
   "SignalTypeToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 68,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoSignalTypeTokenDefMeta,
   mgMgcoRegExpSignalTypeToken
};

/************************************************************************/

/* Bools */
/* Correspond to TknBool in the event structure */

/************************************************************************/

/* ImmAckRequiredToken */
#ifdef GCP_MGCO_SHORT_TOKEN
PUBLIC CmAbnfElmTypeMeta mgMgcoImmAckTokenDefMeta = 
   {(Data *)"IA"};
#else /* !GCP_MGCO_SHORT_TOKEN */
PUBLIC CmAbnfElmTypeMeta mgMgcoImmAckTokenDefMeta =
   {(Data *)"ImmAckRequired"};
#endif /* GCP_MGCO_SHORT_TOKEN */

/* ImmAckRequiredToken        = ("ImmAckRequired"        / "IA") */
PUBLIC CmAbnfElmDef mgMgcoImmAckTokenDef   =
{
#ifdef CM_ABNF_DBG
   "ImmAckRequiredToken",
   "ImmAckToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 69,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,   /* BOOL */
   (U8 *)&mgMgcoImmAckTokenDefMeta,
   mgMgcoRegExpImmAckToken
};

/************************************************************************/

/* Optional dot */
PUBLIC CmAbnfElmDef *mgMgcoOptDotDefSeqElmnts[] =
{
   &cmMsgDefMetaDot
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptDotDefSeq =
{
   1,
   mgMgcoOptDotDefSeqElmnts
};

/* [DOT] */
PUBLIC CmAbnfElmDef mgMgcoOptDotDef   =
{
#ifdef CM_ABNF_DBG
   "Optional dot",
   "Dot",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 70,
   sizeof(TknPres),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ, /* BOOL */
   (U8 *)&mgMgcoOptDotDefSeq,
   cmAbnfRegExpDot
};

/************************************************************************/

/* Enums */
/* Correspond to 'TknU8 type' in the event structure */

/************************************************************************/
/* Choice: mgMgcoAmmParmDef (among others) */

PUBLIC CmAbnfElmTypeEnum mgMgcoAuditDescDefEnum =
{
   NULLP,
   MGT_AUDITDESC
};

PUBLIC CmAbnfElmDef mgMgcoAuditDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Audit descriptor enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 71,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoAuditDescDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapDescDefEnum =
{
   NULLP,
   MGT_DIGMAPDESC
};

PUBLIC CmAbnfElmDef mgMgcoDigMapDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "DigMap descriptor enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 72,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapDescDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEvBufDescDefEnum =
{
   NULLP,
   MGT_EVBUFDESC
};

PUBLIC CmAbnfElmDef mgMgcoEvBufDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "EvBuf descriptor enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 73,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvBufDescDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoMediaDescDefEnum =
{
   NULLP,
   MGT_MEDIADESC
};

PUBLIC CmAbnfElmDef mgMgcoMediaDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Media descriptor enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 74,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoMediaDescDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoModemDescDefEnum =
{
   NULLP,
   MGT_MODEMDESC
};

PUBLIC CmAbnfElmDef mgMgcoModemDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Modem descriptor enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 75,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoModemDescDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoMuxDescDefEnum =
{
   NULLP,
   MGT_MUXDESC
};

PUBLIC CmAbnfElmDef mgMgcoMuxDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Mux descriptor enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 76,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoMuxDescDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoObsEvtDescDefEnum =
{
   NULLP,
   MGT_OBSEVTDESC
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "ObsEvt descriptor enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 77,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoObsEvtDescDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPkgsDescDefEnum =
{
   NULLP,
   MGT_PKGSDESC
};

PUBLIC CmAbnfElmDef mgMgcoPkgsDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Pkgs descriptor enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 78,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPkgsDescDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoReqEvtDescDefEnum =
{
   NULLP,
   MGT_REQEVTDESC
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "ReqEvt descriptor enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 79,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoReqEvtDescDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoSignalsDescDefEnum =
{
   NULLP,
   MGT_SIGNALSDESC
};

PUBLIC CmAbnfElmDef mgMgcoSignalsDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Signals descriptor enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 80,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSignalsDescDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoStatsDescDefEnum =
{
   NULLP,
   MGT_STATSDESC
};

PUBLIC CmAbnfElmDef mgMgcoStatsDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Statistics descriptor enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 81,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoStatsDescDefEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoMsgBodyDef (among others) */

PUBLIC CmAbnfElmTypeEnum mgMgcoErrDescDefEnum = 
{
   NULLP,
   MGT_ERRDESC
};

PUBLIC CmAbnfElmDef mgMgcoErrDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Error descriptor enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 82,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoErrDescDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoTxnLstDefEnum =
{
   NULLP,
   MGT_TXN
};

PUBLIC CmAbnfElmDef mgMgcoTxnLstDefEnumDef =
{
#ifdef CM_ABNF_DBG
   "Transaction list enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 83,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoTxnLstDefEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoErrorOrReplyDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoCtxTokenDefEnum =
{
   NULLP,
   MGT_ACTIONREPLY
};

PUBLIC CmAbnfElmDef mgMgcoCtxTokenDefEnumDef =
{
#ifdef CM_ABNF_DBG
   "Action reply enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 84,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoCtxTokenDefEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoErrorOrCmdReplyDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoCxtCmdReplyDefEnum =
{
   NULLP,
   MGT_CXTCMDREPLY
};

PUBLIC CmAbnfElmDef mgMgcoCxtCmdReplyDefEnumDef =
{
#ifdef CM_ABNF_DBG
   "context/command reply enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 85,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoCxtCmdReplyDefEnum,
   NULLP
};

/************************************************************************/

/* Choice: Error vs Services tokens in ErrOrSvcChg */

PUBLIC CmAbnfElmTypeEnum mgMgcoSvcChgDescDefEnum =
{
   NULLP,
   MGT_SVCCHGDESC
};

PUBLIC CmAbnfElmDef mgMgcoSvcChgDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Service change descriptor enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 86,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSvcChgDescDefEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoAuditReplyDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoAuditOtherDefEnum =
{
   NULLP,
   MGT_TERMAUDIT
};

PUBLIC CmAbnfElmDef mgMgcoAuditOtherDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Audit - other (term) enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 87,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoAuditOtherDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoCxtAuditDefEnum =
{
   NULLP,
   MGT_CXTAUDIT
};

PUBLIC CmAbnfElmDef mgMgcoCxtAuditDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Audit - context",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 88,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoCxtAuditDefEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoContextIdDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoContextIdAllDefEnum =
{
   (Data *)"*",
   MGT_CXTID_ALL
};

PUBLIC CmAbnfElmDef mgMgcoContextIdAllDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Context ID - all",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 89,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoContextIdAllDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoContextIdChooseDefEnum =
{
   (Data *)"$",
   MGT_CXTID_CHOOSE
};

PUBLIC CmAbnfElmDef mgMgcoContextIdChooseDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Context ID - choose",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 90,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoContextIdChooseDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoContextIdNullDefEnum =
{
   (Data *)"-",
   MGT_CXTID_NULL
};

PUBLIC CmAbnfElmDef mgMgcoContextIdNullDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Context ID - null",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 91,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoContextIdNullDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoContextIdOtherDefEnum =
{
   (Data *)NULLP,
   MGT_CXTID_OTHER
};

PUBLIC CmAbnfElmDef mgMgcoContextIdOtherDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Context ID - other",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 92,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoContextIdOtherDefEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoMIDDef  */

PUBLIC CmAbnfElmTypeEnum mgMgcoDevDefEnum =
{
   NULLP,
   MGT_MID_DEVICE
};

PUBLIC CmAbnfElmDef mgMgcoDevDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "MID - device enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 93,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDevDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDomAddrPortDefEnum =
{
   NULLP,
   MGT_MID_DADDRPORT
};

PUBLIC CmAbnfElmDef mgMgcoDomAddrPortDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "MID - IP addr + port enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 94,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDomAddrPortDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDomNamePortDefEnum =
{
   NULLP,
   MGT_MID_DNAMEPORT
};

PUBLIC CmAbnfElmDef mgMgcoDomNamePortDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "MID - domain name + port enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 95,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDomNamePortDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoMtpAddrDefEnum =
{
   NULLP,
   MGT_MID_MTPADDR
};

PUBLIC CmAbnfElmDef mgMgcoMtpAddrDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "MID - MTP addrress enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 96,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoMtpAddrDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPortDefEnum =
{
   NULLP,
   MGT_MID_PORT
};

PUBLIC CmAbnfElmDef mgMgcoPortDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "MID - port enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 97,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPortDefEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoDigPosDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLetDefEnum =
{
   NULLP,
   MGT_DIGSTR_LET
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLetDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Digitmap - letter",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 98,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLetDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapRngDefEnum =
{
   NULLP,
   MGT_DIGSTR_RNG
};

PUBLIC CmAbnfElmDef mgMgcoDigMapRngDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Digitmap - range/x",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 99,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapRngDefEnum,
   NULLP
};
/************************************************************************/

/* Choice: mgMgcoEvtParmDef and mgMgcoEvtSecParmDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtOtherDefEnum =
{
   NULLP,
   MGT_EVTPAR_OTHER
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Event - other enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 100,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtOtherDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtStreamDefEnum =
{
   NULLP,
   MGT_EVTPAR_STREAMID
};

PUBLIC CmAbnfElmDef mgMgcoEvtStreamDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Event - stream enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 101,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtStreamDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoKeepActiveDefEnum =
{
   NULLP,
   MGT_EVTPAR_KEEPACTIVE
};

PUBLIC CmAbnfElmDef mgMgcoKeepActiveDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Event - Keepactive",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 102,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoKeepActiveDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtEmbWithSigDefEnum =
{
   NULLP,
   MGT_EVTPAR_EMBEDWITHSIG
};

PUBLIC CmAbnfElmDef mgMgcoEvtEmbWithSigDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Event - evt w/ sig enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 103,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtEmbWithSigDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtEmbNoSigDefEnum =
{
   NULLP,
   MGT_EVTPAR_EMBEDNOSIG
};

PUBLIC CmAbnfElmDef mgMgcoEvtEmbNoSigDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Event - evt no sig enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 104,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtEmbNoSigDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtDigMapDefEnum =
{
   NULLP,
   MGT_EVTPAR_DIGMAP
};

PUBLIC CmAbnfElmDef mgMgcoEvtDigMapDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Event - digit map enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 105,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtDigMapDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtEmbSigDefEnum =
{
   NULLP,
   MGT_EVTPAR_EMBEDSIG
};

PUBLIC CmAbnfElmDef mgMgcoEvtEmbSigDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Event - sig enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 106,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtEmbSigDefEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoIpAddr */

PUBLIC CmAbnfElmTypeEnum mgMgcoIPv4DefEnum =
{
   NULLP,
   MGT_IPV4
};

PUBLIC CmAbnfElmDef mgMgcoIPv4DefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "IPV4 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 107,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoIPv4DefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoIPv6DefEnum =
{
   NULLP,
   MGT_IPV6
};

PUBLIC CmAbnfElmDef mgMgcoIPv6DefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "IPV6 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 108,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoIPv6DefEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoMediaParDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoMediaParLclCtlDescDefEnum =
{
   NULLP,
   MGT_MEDIAPAR_LOCCTL
};

PUBLIC CmAbnfElmDef mgMgcoMediaParLclCtlDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "MediaParm - local control enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 109,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoMediaParLclCtlDescDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoMediaParLocalDescDefEnum =
{
   NULLP,
   MGT_MEDIAPAR_LOCAL
};

PUBLIC CmAbnfElmDef mgMgcoMediaParLocalDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "MediaParm - local enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 110,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoMediaParLocalDescDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoMediaParRemoteDescDefEnum =
{
   NULLP,
   MGT_MEDIAPAR_REMOTE
};

PUBLIC CmAbnfElmDef mgMgcoMediaParRemoteDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "MediaParm - remote enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 111,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoMediaParRemoteDescDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoMediaParStreamDescDefEnum =
{
   NULLP,
   MGT_MEDIAPAR_STRPAR
};

PUBLIC CmAbnfElmDef mgMgcoMediaParStreamDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "MediaParm - sream enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 112,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoMediaParStreamDescDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoMediaParTermStDescDefEnum =
{
   NULLP,
   MGT_MEDIAPAR_TERMST
};

PUBLIC CmAbnfElmDef mgMgcoMediaParTermStDescDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "MediaParm - termState enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 113,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoMediaParTermStDescDefEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoSigDescParmDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoSigDescParmSigLstDefEnum =
{
   NULLP,
   MGT_SIGSPAR_LST
};

PUBLIC CmAbnfElmDef mgMgcoSigDescParmSigLstDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Signalsparm - list enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 114,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSigDescParmSigLstDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoSigDescParmSigReqDefEnum =
{
   NULLP,
   MGT_SIGSPAR_REQ
};

PUBLIC CmAbnfElmDef mgMgcoSigDescParmSigReqDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Signalsparm - request enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 115,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSigDescParmSigReqDefEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoTermIdDef */

PUBLIC CmAbnfElmTypeEnum  mgMgcoTermIdRootDefEnum =
{
   (Data *) "ROOT",
   MGT_TERMID_ROOT
};

PUBLIC CmAbnfElmDef mgMgcoTermIdRootDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Term ID - ROOT enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 116,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoTermIdRootDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum  mgMgcoTermIdAllDefEnum =
{
   (Data *) "*",
   MGT_TERMID_ALL
};

PUBLIC CmAbnfElmDef mgMgcoTermIdAllDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Term ID - all enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 117,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoTermIdAllDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum  mgMgcoTermIdChooseDefEnum =
{
   (Data *) "$",
   MGT_TERMID_CHOOSE
};

PUBLIC CmAbnfElmDef mgMgcoTermIdChooseDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Term ID - choose enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 118,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoTermIdChooseDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum  mgMgcoTermIdOtherDefEnum =
{
   NULLP,
   MGT_TERMID_OTHER
};

PUBLIC CmAbnfElmDef mgMgcoTermIdOtherDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Term ID - other enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 119,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoTermIdOtherDefEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoParmValDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValDefEqEnum =
{
   NULLP,
   MGT_VALUE_EQUAL
};

PUBLIC CmAbnfElmDef mgMgcoParmValDefEqEnumDef   =
{
#ifdef CM_ABNF_DBG
   "VALUE - Eq enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 120,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValDefEqEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValDefGtEnum =
{
   NULLP,
   MGT_VALUE_GREATERTHAN
};

PUBLIC CmAbnfElmDef mgMgcoParmValDefGtEnumDef   =
{
#ifdef CM_ABNF_DBG
   "VALUE - Gt enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 121,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValDefGtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValDefLtEnum =
{
   NULLP,
   MGT_VALUE_LESSTHAN
};

PUBLIC CmAbnfElmDef mgMgcoParmValDefLtEnumDef   =
{
#ifdef CM_ABNF_DBG
   "VALUE - Lt enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 122,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValDefLtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValDefNeEnum =
{
   NULLP,
   MGT_VALUE_NOTEQUAL
};

PUBLIC CmAbnfElmDef mgMgcoParmValDefNeEnumDef   =
{
#ifdef CM_ABNF_DBG
   "VALUE - Ne enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 123,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValDefNeEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValDefAndEnum =
{
   NULLP,
   MGT_VALUE_AND
};

PUBLIC CmAbnfElmDef mgMgcoParmValDefAndEnumDef   =
{
#ifdef CM_ABNF_DBG
   "VALUE - And enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 124,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValDefAndEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValDefOrEnum =
{
   NULLP,
   MGT_VALUE_OR
};

PUBLIC CmAbnfElmDef mgMgcoParmValDefOrEnumDef   =
{
#ifdef CM_ABNF_DBG
   "VALUE - Or enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 125,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValDefOrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValDefRngEnum =
{
   NULLP,
   MGT_VALUE_RANGE
};

PUBLIC CmAbnfElmDef mgMgcoParmValDefRngEnumDef   =
{
#ifdef CM_ABNF_DBG
   "VALUE - Rng enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 126,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValDefRngEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoSigParDef */

PUBLIC CmAbnfElmTypeEnum  mgMgcoSigTypeDefEnum =
{
   NULLP,
   MGT_SIGPAR_TYPE
};

PUBLIC CmAbnfElmDef mgMgcoSigTypeDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "SignalParm - type enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 127,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSigTypeDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum  mgMgcoSigDurationDefEnum =
{
   NULLP,
   MGT_SIGPAR_DURATION
};

PUBLIC CmAbnfElmDef mgMgcoSigDurationDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "SignalParm - duration enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 128,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSigDurationDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum  mgMgcoSigNtfyCmplDefEnum =
{
   NULLP,
   MGT_SIGPAR_NTFYCMPL
};

PUBLIC CmAbnfElmDef mgMgcoSigNtfyCmplDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "SignalParm - noifyCompletion enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 129,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSigNtfyCmplDefEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoDigitMapChcDef */

PUBLIC CmAbnfElmTypeEnum  mgMgcoDigMapNameDefEnum =
{
   NULLP,
   MGT_DIGMAP_NAME
};

PUBLIC CmAbnfElmDef mgMgcoDigMapNameDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Digitmap - name enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 130,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapNameDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum  mgMgcoDigMapValDefEnum =
{
   NULLP,
   MGT_DIGMAP_VAL
};

PUBLIC CmAbnfElmDef mgMgcoDigMapValDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Digitmap - value enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 131,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapValDefEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoSvcStValDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoTestEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"TE",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Test",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_SVCST_TEST
};

PUBLIC CmAbnfElmDef mgMgcoTestEnum   =
{
#ifdef CM_ABNF_DBG
   "Test enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 132,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoTestEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoInSvcEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"IV",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"InService",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_SVCST_INSVC
};

PUBLIC CmAbnfElmDef mgMgcoInSvcEnum   =
{
#ifdef CM_ABNF_DBG
   "InSvc enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 133,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoInSvcEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoOutOfSvcEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"OS",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"OutOfService",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_SVCST_OUTOFSVC
};

PUBLIC CmAbnfElmDef mgMgcoOutOfSvcEnum   =
{
#ifdef CM_ABNF_DBG
   "OutOfSvc enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 134,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoOutOfSvcEnumEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoTopologyDirDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoBothwayEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"BW",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Bothway",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_TOPODIR_BOTHWAY
};

PUBLIC CmAbnfElmDef mgMgcoBothwayEnum   =
{
#ifdef CM_ABNF_DBG
   "Bothway enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 135,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoBothwayEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoOnewayEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"OW",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Oneway",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_TOPODIR_ONEWAY
};

PUBLIC CmAbnfElmDef mgMgcoOnewayEnum   =
{
#ifdef CM_ABNF_DBG
   "Oneway enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 136,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoOnewayEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoIsolateEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"IS",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Isolate",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_TOPODIR_ISOLATE
};

PUBLIC CmAbnfElmDef mgMgcoIsolateEnum   =
{
#ifdef CM_ABNF_DBG
   "Isolate enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 137,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoIsolateEnumEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoExtnParmDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoExtnParmOptEnumEnum =
{
   (Data *)"-",
   MGT_EXTNPARM_OPT
};

PUBLIC CmAbnfElmDef mgMgcoExtnParmOptEnum   =
{
#ifdef CM_ABNF_DBG
   "- enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 138,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoExtnParmOptEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoExtnParmMandEnumEnum =
{
   (Data *)"+",
   MGT_EXTNPARM_MAND
};

PUBLIC CmAbnfElmDef mgMgcoExtnParmMandEnum   =
{
#ifdef CM_ABNF_DBG
   "+ enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 139,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoExtnParmMandEnumEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoSvcChgMethodTypeDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoExtnParmEnumEnum =
{
   (Data *)"X",
   MGT_EXTNPARM
};

PUBLIC CmAbnfElmDef mgMgcoExtnParmEnum   =
{
#ifdef CM_ABNF_DBG
   "ExtnParm enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 140,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoExtnParmEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta mgMgcoExtnParmMetaDefMeta = {(Data *)"X"};
PUBLIC CmAbnfElmDef mgMgcoExtnParmMetaDef =
{
#ifdef CM_ABNF_DBG
   "ExtnParm Meta",
   "X",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 141,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoExtnParmMetaDefMeta,
   mgMgcoRegExpX
};

PUBLIC CmAbnfElmTypeEnum mgMgcoFailoverEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"FL",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Failover",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_SVCCHGMETH_FAILOVER
};

PUBLIC CmAbnfElmDef mgMgcoFailoverEnum   =
{
#ifdef CM_ABNF_DBG
   "Failover enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 142,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoFailoverEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoForcedEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"FO",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Forced",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_SVCCHGMETH_FORCED
};

PUBLIC CmAbnfElmDef mgMgcoForcedEnum   =
{
#ifdef CM_ABNF_DBG
   "Forced enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 143,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoForcedEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoGracefulEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"GR",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Graceful",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_SVCCHGMETH_GRACEFUL
};

PUBLIC CmAbnfElmDef mgMgcoGracefulEnum   =
{
#ifdef CM_ABNF_DBG
   "Graceful enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 144,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoGracefulEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoRestartEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"RS",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Restart",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_SVCCHGMETH_RESTART
};

PUBLIC CmAbnfElmDef mgMgcoRestartEnum   =
{
#ifdef CM_ABNF_DBG
   "Restart enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 145,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoRestartEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDisconnectedEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"DC",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Disconnected",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_SVCCHGMETH_DISCON
};

PUBLIC CmAbnfElmDef mgMgcoDisconnectedEnum   =
{
#ifdef CM_ABNF_DBG
   "Disconnected enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 146,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDisconnectedEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoHandOffEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"HO",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"HandOff",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_SVCCHGMETH_HANDOFF
};

PUBLIC CmAbnfElmDef mgMgcoHandOffEnum   =
{
#ifdef CM_ABNF_DBG
   "HandOff enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 147,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoHandOffEnumEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoModemTypeDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoV32bisEnumEnum =
{
   (Data *)"V32b",
   MGT_MODEMTYPE_V32BIS
};

PUBLIC CmAbnfElmDef mgMgcoV32bisEnum   =
{
#ifdef CM_ABNF_DBG
   "V32bis enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 148,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoV32bisEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoV22bisEnumEnum =
{
   (Data *)"V22b",
   MGT_MODEMTYPE_V22BIS
};

PUBLIC CmAbnfElmDef mgMgcoV22bisEnum   =
{
#ifdef CM_ABNF_DBG
   "V22bis enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 149,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoV22bisEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoV18EnumEnum =
{
   (Data *)"V18",
   MGT_MODEMTYPE_V18
};

PUBLIC CmAbnfElmDef mgMgcoV18Enum   =
{
#ifdef CM_ABNF_DBG
   "V18 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 150,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoV18EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoV22EnumEnum =
{
   (Data *)"V22",
   MGT_MODEMTYPE_V22
};

PUBLIC CmAbnfElmDef mgMgcoV22Enum   =
{
#ifdef CM_ABNF_DBG
   "V22 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 151,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoV22EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoV32EnumEnum =
{
   (Data *)"V32",
   MGT_MODEMTYPE_V32
};

PUBLIC CmAbnfElmDef mgMgcoV32Enum   =
{
#ifdef CM_ABNF_DBG
   "V32 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 152,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoV32EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoV34EnumEnum =
{
   (Data *)"V34",
   MGT_MODEMTYPE_V34
};

PUBLIC CmAbnfElmDef mgMgcoV34Enum   =
{
#ifdef CM_ABNF_DBG
   "V34 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 153,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoV34EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoV90EnumEnum =
{
   (Data *)"V90",
   MGT_MODEMTYPE_V90
};

PUBLIC CmAbnfElmDef mgMgcoV90Enum   =
{
#ifdef CM_ABNF_DBG
   "V90 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 154,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoV90EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoV91EnumEnum =
{
   (Data *)"V91",
   MGT_MODEMTYPE_V91
};

PUBLIC CmAbnfElmDef mgMgcoV91Enum   =
{
#ifdef CM_ABNF_DBG
   "V91 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 155,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoV91EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoSynchISDNEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"SN",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"SynchISDN",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_MODEMTYPE_SYNCHISDN
};

PUBLIC CmAbnfElmDef mgMgcoSynchISDNEnum   =
{
#ifdef CM_ABNF_DBG
   "SynchISDN enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 156,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSynchISDNEnumEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoMuxTypeDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoH221EnumEnum =
{
   (Data *)"H221",
   MGT_MUXTYPE_H221
};

PUBLIC CmAbnfElmDef mgMgcoH221Enum   =
{
#ifdef CM_ABNF_DBG
   "H221 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 157,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoH221EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoH223EnumEnum =
{
   (Data *)"H223",
   MGT_MUXTYPE_H223
};

PUBLIC CmAbnfElmDef mgMgcoH223Enum   =
{
#ifdef CM_ABNF_DBG
   "H223 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 158,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoH223EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoH226EnumEnum =
{
   (Data *)"H226",
   MGT_MUXTYPE_H226
};

PUBLIC CmAbnfElmDef mgMgcoH226Enum   =
{
#ifdef CM_ABNF_DBG
   "H226 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 159,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoH226EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoV76EnumEnum =
{
   (Data *)"V76",
   MGT_MUXTYPE_V76
};

PUBLIC CmAbnfElmDef mgMgcoV76Enum   =
{
#ifdef CM_ABNF_DBG
   "V76 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 160,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoV76EnumEnum,
   NULLP
};

/* mg004.105: Added support for Nx64 */
PUBLIC CmAbnfElmTypeEnum mgMgcoN64EnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"N64",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Nx64Kservice",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_MUXTYPE_N64
};

PUBLIC CmAbnfElmDef mgMgcoN64Enum   =
{
#ifdef CM_ABNF_DBG
   "N64 enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 161,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoN64EnumEnum,
   NULLP
};


/************************************************************************/

/* Choice: mgMgcoSigSigTypeDef */

/* mg007.105: Modified Timeout element definition for Signal Type and 
 * Notify Completion seperate */
PUBLIC CmAbnfElmTypeEnum mgMgcoSigTimeOutEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"TO",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"TimeOut",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_SIGTYPE_TIMEOUT
};

PUBLIC CmAbnfElmDef mgMgcoSigTimeOutEnum   =
{
#ifdef CM_ABNF_DBG
   "TimeOut enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 161,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSigTimeOutEnumEnum,
   NULLP
};

/* Choice: mgMgcoNtfyReasonTypeDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoNtfyTimeOutEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"TO",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"TimeOut",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_NTFYRES_TIMEOUT
};

PUBLIC CmAbnfElmDef mgMgcoNtfyTimeOutEnum   =
{
#ifdef CM_ABNF_DBG
   "TimeOut enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 161,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoNtfyTimeOutEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoOnOffEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"OO",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"OnOff",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_SIGTYPE_ONOFF
};

PUBLIC CmAbnfElmDef mgMgcoOnOffEnum   =
{
#ifdef CM_ABNF_DBG
   "OnOff enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 162,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoOnOffEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoBriefEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"BR",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Brief",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_SIGTYPE_BRIEF
};

PUBLIC CmAbnfElmDef mgMgcoBriefEnum   =
{
#ifdef CM_ABNF_DBG
   "Brief enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 163,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoBriefEnumEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoNtfyReasonDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoInterruptByEventEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"IBE",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"IntByEvent",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_NTFYRES_IBYEVT
};

PUBLIC CmAbnfElmDef mgMgcoInterruptByEventEnum   =
{
#ifdef CM_ABNF_DBG
   "InterruptByEvent enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 164,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoInterruptByEventEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoInterruptByNewSignalsDescrEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"IBS",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"IntBySigDescr",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_NTFYRES_IBYNEWSIG
};

PUBLIC CmAbnfElmDef mgMgcoInterruptByNewSignalsDescrEnum   =
{
#ifdef CM_ABNF_DBG
   "InterruptByNewSignalsDescr enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 165,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoInterruptByNewSignalsDescrEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoOtherReasonEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"OR",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"OtherReason",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_NTFYRES_OTHER
};

PUBLIC CmAbnfElmDef mgMgcoOtherReasonEnum   =
{
#ifdef CM_ABNF_DBG
   "OtherReason enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 166,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoOtherReasonEnumEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoDigMapLetDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_0_EnumEnum = 
{ 
   (Data *)"0",
   MGT_DIGMAP_0
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_0_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - 0",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 167,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_0_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_1_EnumEnum = 
{ 
   (Data *)"1",
   MGT_DIGMAP_1
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_1_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - 1",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 168,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_1_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_2_EnumEnum = 
{ 
   (Data *)"2",
   MGT_DIGMAP_2
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_2_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - 2",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 169,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_2_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_3_EnumEnum = 
{ 
   (Data *)"3",
   MGT_DIGMAP_3
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_3_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - 3",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 170,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_3_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_4_EnumEnum = 
{ 
   (Data *)"4",
   MGT_DIGMAP_4
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_4_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - 4",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 171,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_4_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_5_EnumEnum = 
{ 
   (Data *)"5",
   MGT_DIGMAP_5
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_5_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - 5",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 172,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_5_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_6_EnumEnum = 
{ 
   (Data *)"6",
   MGT_DIGMAP_6
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_6_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - 6",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 173,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_6_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_7_EnumEnum = 
{ 
   (Data *)"7",
   MGT_DIGMAP_7
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_7_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - 7",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 174,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_7_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_8_EnumEnum = 
{ 
   (Data *)"8",
   MGT_DIGMAP_8
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_8_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - 8",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 175,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_8_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_9_EnumEnum = 
{ 
   (Data *)"9",
   MGT_DIGMAP_9
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_9_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - 9",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 176,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_9_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_A_EnumEnum = 
{ 
   (Data *)"A",
   MGT_DIGMAP_A
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_A_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - A",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 177,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_A_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_B_EnumEnum = 
{ 
   (Data *)"B",
   MGT_DIGMAP_B
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_B_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - B",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 178,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_B_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_C_EnumEnum = 
{ 
   (Data *)"C",
   MGT_DIGMAP_C
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_C_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - C",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 179,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_C_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_D_EnumEnum = 
{ 
   (Data *)"D",
   MGT_DIGMAP_D
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_D_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - D",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 180,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_D_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_E_EnumEnum = 
{ 
   (Data *)"E",
   MGT_DIGMAP_E
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_E_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - E",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 181,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_E_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_F_EnumEnum = 
{ 
   (Data *)"F",
   MGT_DIGMAP_F
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_F_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - F",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 182,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_F_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_G_EnumEnum = 
{ 
   (Data *)"G",
   MGT_DIGMAP_G
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_G_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - G",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 183,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_G_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_H_EnumEnum = 
{ 
   (Data *)"H",
   MGT_DIGMAP_H
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_H_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - H",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 184,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_H_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_I_EnumEnum = 
{ 
   (Data *)"I",
   MGT_DIGMAP_I
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_I_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - I",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 185,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_I_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_J_EnumEnum = 
{ 
   (Data *)"J",
   MGT_DIGMAP_J
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_J_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - J",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 186,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_J_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_K_EnumEnum = 
{ 
   (Data *)"K",
   MGT_DIGMAP_K
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_K_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - K",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 187,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_K_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_L_EnumEnum = 
{ 
   (Data *)"L",
   MGT_DIGMAP_L
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_L_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - L",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 188,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_L_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_S_EnumEnum = 
{ 
   (Data *)"S",
   MGT_DIGMAP_S
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_S_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - S",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 189,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_S_EnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLet_Z_EnumEnum = 
{ 
   (Data *)"Z",
   MGT_DIGMAP_Z
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLet_Z_Enum   =
{
#ifdef CM_ABNF_DBG
   "Digit map - Z",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 190,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLet_Z_EnumEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoDigMapRngDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapXEnumEnum =
{
   (Data *)"x",
   MGT_DIGMAP_X
};

PUBLIC CmAbnfElmDef mgMgcoDigMapXEnum   =
{
#ifdef CM_ABNF_DBG
   "Digmap - X enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 191,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapXEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapLSBRKTEnumEnum =
{
   (Data *)"[",
   MGT_DIGMAP_LET
};

PUBLIC CmAbnfElmDef mgMgcoDigMapLSBRKTEnum   =
{
#ifdef CM_ABNF_DBG
   "Digmap - [ (range) enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 192,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapLSBRKTEnumEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoModeValDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoSendonlyEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"SO",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"SendOnly",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_MODE_SENDONLY
};

PUBLIC CmAbnfElmDef mgMgcoSendonlyEnum   =
{
#ifdef CM_ABNF_DBG
   "SendOnly enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 193,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSendonlyEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoRecvonlyEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"RC",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"ReceiveOnly",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_MODE_RECVONLY
};

PUBLIC CmAbnfElmDef mgMgcoRecvonlyEnum   =
{
#ifdef CM_ABNF_DBG
   "RecvOnly enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 194,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoRecvonlyEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoSendrecvEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"SR",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"SendReceive",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_MODE_SENDRECV
};

PUBLIC CmAbnfElmDef mgMgcoSendrecvEnum   =
{
#ifdef CM_ABNF_DBG
   "Sendrecv enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 195,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSendrecvEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoInactiveEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"IN",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Inactive",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_MODE_INACTIVE
};

PUBLIC CmAbnfElmDef mgMgcoInactiveEnum   =
{
#ifdef CM_ABNF_DBG
   "Inactive enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 196,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoInactiveEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoLoopbackEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"LB",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Loopback",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_MODE_LOOPBACK
};

PUBLIC CmAbnfElmDef mgMgcoLoopbackEnum   =
{
#ifdef CM_ABNF_DBG
   "Loopback enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 197,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoLoopbackEnumEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoBufCtlDef */

PUBLIC CmAbnfElmTypeEnum mgMgcoLockStepEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"SP",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"LockStep",
#endif /* GCP_MGCO_SHORT_TOKEN */
   TRUE
};

PUBLIC CmAbnfElmDef mgMgcoLockStepEnum   =
{
#ifdef CM_ABNF_DBG
   "LockStep enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 198,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoLockStepEnumEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoAuditItemDef */

/* MediaToken                 = ("Media"                 / "M") */
PUBLIC CmAbnfElmTypeEnum mgMgcoMediaDescEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"M",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Media",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_MEDIADESC
};

PUBLIC CmAbnfElmDef mgMgcoMediaDescEnum   =
{
#ifdef CM_ABNF_DBG
   "Media token enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 199,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoMediaDescEnumEnum,
   NULLP
};

/* ModemToken                 = ("Modem"                 / "MD") */
PUBLIC CmAbnfElmTypeEnum mgMgcoModemDescEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"MD",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Modem",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_MODEMDESC
};

PUBLIC CmAbnfElmDef mgMgcoModemDescEnum   =
{
#ifdef CM_ABNF_DBG
   "Modem token enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 200,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoModemDescEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoMuxDescEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"MX",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Mux",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_MUXDESC
};

PUBLIC CmAbnfElmDef mgMgcoMuxDescEnum   =
{
#ifdef CM_ABNF_DBG
   "Mux token enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 201,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoMuxDescEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoReqEvtDescEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"E",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Events",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_REQEVTDESC
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtDescEnum   =
{
#ifdef CM_ABNF_DBG
   "Events token enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 202,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoReqEvtDescEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEvBufDescEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"EB",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"EventBuffer",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_EVBUFDESC
};

PUBLIC CmAbnfElmDef mgMgcoEvBufDescEnum   =
{
#ifdef CM_ABNF_DBG
   "EventBuffer token enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 203,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvBufDescEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoSignalsDescEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"SG",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Signals",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_SIGNALSDESC
};

PUBLIC CmAbnfElmDef mgMgcoSignalsDescEnum   =
{
#ifdef CM_ABNF_DBG
   "Signals token enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 204,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSignalsDescEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDigMapDescEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"DM",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"DigitMap",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_DIGMAPDESC
};

PUBLIC CmAbnfElmDef mgMgcoDigMapDescEnum   =
{
#ifdef CM_ABNF_DBG
   "DigitMap token enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 205,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDigMapDescEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoObsEvtDescEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"OE",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"ObservedEvents",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_OBSEVTDESC
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtDescEnum   =
{
#ifdef CM_ABNF_DBG
   "ObservedEvents token enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 206,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoObsEvtDescEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoStatsDescEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"SA",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Statistics",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_STATSDESC
};

PUBLIC CmAbnfElmDef mgMgcoStatsDescEnum   =
{
#ifdef CM_ABNF_DBG
   "Stats token enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 207,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoStatsDescEnumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPkgsDescEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"PG",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Packages",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_PKGSDESC
};

PUBLIC CmAbnfElmDef mgMgcoPkgsDescEnum   =
{
#ifdef CM_ABNF_DBG
   "Packages token enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 208,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPkgsDescEnumEnum,
   NULLP
};


#ifdef    MGT_MGCO_V2
PUBLIC CmAbnfElmTypeEnum mgMgcoIndAudTermAuditDescEnumEnum =
{
   (Data *)NULLP,
   MGT_INDAUD_TERMAUDDESC
};

PUBLIC CmAbnfElmDef mgMgcoIndAudTermAuditDescEnum   =
{
#ifdef CM_ABNF_DBG
   "Packages token enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 208,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoIndAudTermAuditDescEnumEnum,
   NULLP
};
#endif /* MGT_MGCO_V2 */


/************************************************************************/

/* Choice: mgMgcoTxnDef */

/* TransToken                 = ("Transaction"           / "T") */
PUBLIC CmAbnfElmTypeEnum mgMgcoTxnReqDefEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"T",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Transaction",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_TXNREQ
};

PUBLIC CmAbnfElmDef mgMgcoTxnReqDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Transaction request enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 209,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoTxnReqDefEnum,
   NULLP
};

/* ReplyToken                 = ("Reply"                 / "P") */
PUBLIC CmAbnfElmTypeEnum mgMgcoTxnReplyDefEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"P",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Reply",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_TXNREPLY
};

PUBLIC CmAbnfElmDef mgMgcoTxnReplyDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Transaction reply enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 210,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoTxnReplyDefEnum,
   NULLP
};

/* PendingToken               = ("Pending"               / "PN") */
PUBLIC CmAbnfElmTypeEnum mgMgcoTxnPendDefEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"PN",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Pending",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_TXNPEND
};

PUBLIC CmAbnfElmDef mgMgcoTxnPendDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Transaction pending enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 211,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoTxnPendDefEnum,
   NULLP
};

/* ResponseAckToken           = ("TransactionResponseAck"/ "K") */
PUBLIC CmAbnfElmTypeEnum mgMgcoTxnRspAckDefEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"K",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"TransactionResponseAck",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_TXNRSPACK
};

PUBLIC CmAbnfElmDef mgMgcoTxnRspAckDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "Transaction response ack enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 212,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoTxnRspAckDefEnum,
   NULLP
};

/************************************************************************/

/* Choice: mgMgcoCmdDefChc */

/* AddToken                   = ("Add"                   / "A") */
PUBLIC CmAbnfElmTypeEnum mgMgcoAddEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"A",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Add",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_ADD
};

PUBLIC CmAbnfElmDef mgMgcoAddEnum   =
{
#ifdef CM_ABNF_DBG
   "Add enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 213,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoAddEnumEnum,
   NULLP
};

/* MoveToken                  = ("Move"                  / "MV") */
PUBLIC CmAbnfElmTypeEnum mgMgcoMoveEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"MV",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Move",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_MOVE
};

PUBLIC CmAbnfElmDef mgMgcoMoveEnum   =
{
#ifdef CM_ABNF_DBG
   "Move enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 214,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoMoveEnumEnum,
   NULLP
};

/* ModifyToken                = ("Modify"                / "MF") */
PUBLIC CmAbnfElmTypeEnum mgMgcoModEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"MF",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Modify",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_MODIFY
};

PUBLIC CmAbnfElmDef mgMgcoModEnum   =
{
#ifdef CM_ABNF_DBG
   "Mod enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 215,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoModEnumEnum,
   NULLP
};

/* SubtractToken              = ("Subtract"              / "S") */
PUBLIC CmAbnfElmTypeEnum mgMgcoSubEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"S",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Subtract",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_SUB
};

PUBLIC CmAbnfElmDef mgMgcoSubEnum   =
{
#ifdef CM_ABNF_DBG
   "Sub enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 216,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSubEnumEnum,
   NULLP
};

/* AuditCapToken              = ("AuditCapability"       / "AC") */
PUBLIC CmAbnfElmTypeEnum mgMgcoAudCapEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"AC",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"AuditCapability",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_AUDITCAP
};

PUBLIC CmAbnfElmDef mgMgcoAudCapEnum   =
{
#ifdef CM_ABNF_DBG
   "AudCap enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 217,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoAudCapEnumEnum,
   NULLP
};

/* AuditValueToken              = ("AuditValue"       / "AV") */
PUBLIC CmAbnfElmTypeEnum mgMgcoAudValEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"AV",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"AuditValue",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_AUDITVAL
};

PUBLIC CmAbnfElmDef mgMgcoAudValEnum   =
{
#ifdef CM_ABNF_DBG
   "AudVal enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 218,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoAudValEnumEnum,
   NULLP
};

/* NotifyToken                = ("Notify"                / "N") */
PUBLIC CmAbnfElmTypeEnum mgMgcoNtfyEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"N",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Notify",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_NTFY
};

PUBLIC CmAbnfElmDef mgMgcoNtfyEnum   =
{
#ifdef CM_ABNF_DBG
   "Ntfy enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 219,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoNtfyEnumEnum,
   NULLP
};

/* ServiceChangeToken         = ("ServiceChange"         / "SC") */
PUBLIC CmAbnfElmTypeEnum mgMgcoSvcChgEnumEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"SC",
#else /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"ServiceChange",
#endif /* GCP_MGCO_SHORT_TOKEN */
   MGT_SVCCHG
};

PUBLIC CmAbnfElmDef mgMgcoSvcChgEnum   =
{
#ifdef CM_ABNF_DBG
   "SvcChg enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 220,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSvcChgEnumEnum,
   NULLP
};

/************************************************************************/

/* Integers of various sizes */

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMgcoU32DefRng = {1, 10, 0, (U32)~0};
PUBLIC CmAbnfElmTypeIntRange mgMgcoU16DefRng = {1, 5, 0, (U32)65535};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMgcoU32DefRng = {1, 10};
PUBLIC CmAbnfElmTypeRange mgMgcoU16DefRng = {1, 5};
#endif /* CM_ABNF_V_1_2 */

/************************************************************************/

/* Megaco version */
#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMgcoVersionRng = {1, 2, 0, 99};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMgcoVersionRng = {1, 2};
#endif /* CM_ABNF_V_1_2 */

/* Version              = 1*2(DIGIT) */
PUBLIC CmAbnfElmDef mgMgcoVersionDef   =
{
#ifdef CM_ABNF_DBG
   "Version",
   "cmAbnfRegExpDgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 221,
   sizeof(MgMgcoVersion),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT8,
   (U8 *)&mgMgcoVersionRng,
   cmAbnfRegExpDgt
};

/************************************************************************/

/* Timer */

/* Timer              = 1*2DIGIT */
PUBLIC CmAbnfElmDef mgMgcoTimerDef   =
{
#ifdef CM_ABNF_DBG
   "Timer",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 222,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT8,
   (U8 *)&mgMgcoVersionRng,
   cmAbnfRegExpDgt
};

/************************************************************************/

/* Priority value */

/* UINT16 */
PUBLIC CmAbnfElmDef mgMgcoPriorityValDef   =
{
#ifdef CM_ABNF_DBG
   "Priority value",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 223,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&mgMgcoU16DefRng,
   cmAbnfRegExpDgt
};

/************************************************************************/

/* Error code */

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMgcoErrorCodeDefRng = {1, 4, 0, 9999};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMgcoErrorCodeDefRng = {1, 4};
#endif /* CM_ABNF_V_1_2 */

/* ErrorCode            = 1*4(DIGIT) */
PUBLIC CmAbnfElmDef mgMgcoErrorCodeDef   =
{
#ifdef CM_ABNF_DBG
   "Error code",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 224,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&mgMgcoErrorCodeDefRng,
   cmAbnfRegExpDgt
};

/************************************************************************/

/* Package item value */

/* UINT16 */
PUBLIC CmAbnfElmDef mgMgcoPkgsItemValDef   =
{
#ifdef CM_ABNF_DBG
   "Package item value",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 225,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&mgMgcoU16DefRng,
   cmAbnfRegExpDgt
};

/************************************************************************/

/* Stream ID */

/* StreamId        = UINT16 = 1*5(DIGIT) */
PUBLIC CmAbnfElmDef mgMgcoStreamIdDef   =
{
#ifdef CM_ABNF_DBG
   "Stream ID",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 226,
   sizeof(MgMgcoStreamId),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&mgMgcoU16DefRng,
   cmAbnfRegExpDgt
};

/************************************************************************/
/* Transaction ID */

/* TransactionID        = UINT32 = 1*10(DIGIT) */
PUBLIC CmAbnfElmDef mgMgcoTransIdDef   =
{
#ifdef CM_ABNF_DBG
   "Transaction ID",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 227,
   sizeof(MgMgcoTransId),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgcoU32DefRng,
   cmAbnfRegExpDgt
};

/************************************************************************/

/* Other context ID */

/* ContextID = UINT32 */
PUBLIC CmAbnfElmDef mgMgcoContextIdOtherDef   =
{
#ifdef CM_ABNF_DBG
   "Context ID - other",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 228,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgcoU32DefRng,
   cmAbnfRegExpDgt
};

/************************************************************************/

/* Signal list ID */

/* signalListId         = UINT16 */
PUBLIC CmAbnfElmDef mgMgcoSigLstIdDef   =
{
#ifdef CM_ABNF_DBG
   "Signal list ID",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 229,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&mgMgcoU16DefRng,
   cmAbnfRegExpDgt
};

/************************************************************************/

/* Signal duration */

/* UINT16 */
PUBLIC CmAbnfElmDef mgMgcoSigSigDurationDef   =
{
#ifdef CM_ABNF_DBG
   "Signal duration",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 230,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&mgMgcoU16DefRng,
   cmAbnfRegExpDgt
};

/************************************************************************/

/* Request ID */

/* Request        = UINT32 = 1*10(DIGIT) */
PUBLIC CmAbnfElmDef mgMgcoRequestIdOtherDef   =
{
#ifdef CM_ABNF_DBG
   "Request ID Other",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 231,
   sizeof(MgMgcoRequestId) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgcoU32DefRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmTypeRange mgMgcoSkipRequestIdDefRng = {1, 1};

PUBLIC CmAbnfElmDef mgMgcoSkipRequestIdDef =
{
#ifdef CM_ABNF_DBG
   "Skip * in RequestID",
   "Star",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 232,
   sizeof(MgMgcoRequestId) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   (U8 *)&mgMgcoSkipRequestIdDefRng,
   cmAbnfRegExpStar
};

PUBLIC CmAbnfElmTypeEnum mgMgcoRequestIdAllEnum =
{
   (Data *)"*",
   MGT_REQID_ALL
};

PUBLIC CmAbnfElmDef mgMgcoRequestIdAllEnumDef =
{
#ifdef CM_ABNF_DBG
   "Request ID - all enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 233,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoRequestIdAllEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoRequestIdOtherEnum =
{
   (Data *)NULLP,
   MGT_REQID_OTHER
};

PUBLIC CmAbnfElmDef mgMgcoRequestIdOtherEnumDef =
{
#ifdef CM_ABNF_DBG
   "Request ID - other enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 234,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoRequestIdOtherEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoRequestIdDefChcEnum[] =
{
   &mgMgcoRequestIdAllEnumDef,
   &mgMgcoRequestIdOtherEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoRequestIdDefChcElmnts[] =
{
   &mgMgcoSkipRequestIdDef,
   &mgMgcoRequestIdOtherDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoRequestIdDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoRequestIdDefChcElmnts,
   mgMgcoRequestIdDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoRequestIdDef =
{
#ifdef CM_ABNF_DBG
   "RequestId",
   "RequestIdType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 235,
   sizeof(MgMgcoRequestId),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoRequestIdDefChc,
   mgMgcoRegExpRequestIdType
};

/************************************************************************/

/* Service change delay value  */

/* UINT32 = 1*10(DIGIT) */
PUBLIC CmAbnfElmDef mgMgcoSvcChgDelayValDef   =
{
#ifdef CM_ABNF_DBG
   "Service change delay value",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 236,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgcoU32DefRng,
   cmAbnfRegExpDgt
};

/************************************************************************/

/* Strings of various sizes */

/************************************************************************/

/* NAME string */
PUBLIC CmAbnfElmTypeRange mgMgcoNAMEStrDefRng = {1, 64};

/* NAME                 = ALPHA *63(ALPHA / DIGIT / "_" ) */
PUBLIC CmAbnfElmDef mgMgcoNAMEStrDef   =
{
#ifdef CM_ABNF_DBG
   "NAME string",
   "NAME",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 237,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoNAMEStrDefRng,
   mgMgcoRegExpNAME
};

/************************************************************************/

/* Quoted string */

PUBLIC CmAbnfElmTypeRange mgMgcoQuotedStringDefRng = {3, 0xFFFF};

/* quotedString         = DQUOTE 1*(SafeChar / RestChar/ WSP) DQUOTE */
PUBLIC CmAbnfElmDef mgMgcoQuotedStringDef   =
{
#ifdef CM_ABNF_DBG
   "Quoted string",
   "QuotedString",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 238,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoQuotedStringDefRng,
   mgMgcoRegExpQuotedString
};

/************************************************************************/

/* Value */

PUBLIC CmAbnfElmTypeRange mgMgcoValueValDefRng = {1, 0xFFFF};

/* VALUE                = quotedString / 1*(SafeChar) */
PUBLIC CmAbnfElmDef mgMgcoValueValDef   =
{
#ifdef CM_ABNF_DBG
   "Value",
   "Value",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 239,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoValueValDefRng,
   mgMgcoRegExpValue
};

PUBLIC CmAbnfElmDef *mgMgcoValueDefChcElmnts[] =
{
   NULLP, NULLP, NULLP,
   &mgMgcoValueValDef,
   NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoValueDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoValueDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoValueDef =
{
#ifdef CM_ABNF_DBG
   "Value type OSXL",
   "ParmValOctStrXL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 240,
   sizeof(MgMgcoValue),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoValueDefChc,
   mgMgcoRegExpParmValOctStrXL
};

/************************************************************************/

/* IPV4 address */
PUBLIC CmAbnfElmTypeRange mgMgcoIPv4DefRng = {7, 15};

/* IPv4address          = V4hex DOT V4hex DOT V4hex DOT V4hex
 * V4hex                = 1*3(DIGIT); "0".."255"
 */
PUBLIC CmAbnfElmDef mgMgcoIPv4Def   =
{
#ifdef CM_ABNF_DBG
   "IPV4 address",
   "Ipv4Char",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 241,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoIPv4DefRng,
   mgMgcoRegExpIpv4Char
};

/************************************************************************/

/* IPV6 address */

PUBLIC CmAbnfElmTypeRange mgMgcoIPv6DefRng = {2, 55};

/* IPv6address          = hexpart [ ":" IPv4address ]
 * hexpart              = hexseq "::" [ hexseq ] / "::" [ hexseq ] / hexseq
 * hexseq               = hex4 *( ":" hex4)
 * hex4                 = 1*4HEXDIG
 */
PUBLIC CmAbnfElmDef mgMgcoIPv6Def   =
{
#ifdef CM_ABNF_DBG
   "IPV6 address",
   "Ipv6Char",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 242,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoIPv6DefRng,
   mgMgcoRegExpIpv6Char
};

/************************************************************************/

/* domain name */
PUBLIC CmAbnfElmTypeRange mgMgcoDomNameDefRng = {1, 64};

/* (ALPHA / DIGIT) *63(ALPHA / DIGIT / "-" / ".") */
PUBLIC CmAbnfElmDef mgMgcoDomNameDef   =
{
#ifdef CM_ABNF_DBG
   "domain name",
   "DomNameChar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 243,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoDomNameDefRng,
   mgMgcoRegExpDomNameChar
};

/************************************************************************/

/* MTP */
PUBLIC CmAbnfElmTypeRange mgMgcoMtpDefRng = {0, 8}; /* presumably! */

/* octetString */
PUBLIC CmAbnfElmDef mgMgcoMtpDef   =
{
#ifdef CM_ABNF_DBG
   "MTP",
   "MtpChar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 244,
   sizeof(TknStr8), 
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTR8,
   (U8 *)&mgMgcoMtpDefRng,
   mgMgcoRegExpMtpChar
};

/************************************************************************/

/* PName = almost NAME */
PUBLIC CmAbnfElmTypeRange mgMgcoPNameDefRng = {1, 64};

/* ["*"] NAME *("/" / "*"/ ALPHA / DIGIT /"_" / "$") */
PUBLIC CmAbnfElmDef mgMgcoPNameDef   =
{
#ifdef CM_ABNF_DBG
   "PName",
   "PNameChar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 245,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoPNameDefRng,
   mgMgcoRegExpPNameChar
};

/************************************************************************/

/* Path domain name */
PUBLIC CmAbnfElmTypeRange mgMgcoPathDomainNameDefRng = {1, 64};

/* pathDomainName = (ALPHA / DIGIT / "*" ) *63(ALPHA / DIGIT / "-" / "*" / ".")
 */
PUBLIC CmAbnfElmDef mgMgcoPathDomainNameDef   =
{
#ifdef CM_ABNF_DBG
   "Path domain name",
   "PathDomainNameChar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 246,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoPathDomainNameDefRng,
   mgMgcoRegExpPathDomainNameChar
};

/************************************************************************/

/* Time */
PUBLIC CmAbnfElmTypeRange mgMgcoTimeDefRng = {8, 8};

/* Time                 = 8(DIGIT) */
PUBLIC CmAbnfElmDef mgMgcoTimeDef   =
{
#ifdef CM_ABNF_DBG
   "Time",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 247,
   sizeof(TknStr8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTR8,
   (U8 *)&mgMgcoTimeDefRng,
   cmAbnfRegExpDgt
};

/************************************************************************/

/* Date */
/* Date                 = 8(DIGIT) */
PUBLIC CmAbnfElmDef mgMgcoDateDef   =
{
#ifdef CM_ABNF_DBG
   "Date",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 248,
   sizeof(TknStr8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTR8,
   (U8 *)&mgMgcoTimeDefRng,
   cmAbnfRegExpDgt
};

/************************************************************************/

/* Extension parameter */
PUBLIC CmAbnfElmTypeRange mgMgcoExtnParmValDefRng = {1, 6};

/* 1*6(ALPHA / DIGIT) */
PUBLIC CmAbnfElmDef mgMgcoExtnParmValDef   =
{
#ifdef CM_ABNF_DBG
   "ExtnParmVal",
   "AlDgChar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 249,
   sizeof(TknStr8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTR8,
   (U8 *)&mgMgcoExtnParmValDefRng,
   cmAbnfRegExpAlDgChar
};

/************************************************************************/

/* Various IDs */

PUBLIC CmAbnfElmTypeRange mgMgcoCharDefRng = {1, 1};

/************************************************************************/

/* Opt Path domain name */
PUBLIC CmAbnfElmDef *mgMgcoOptPathDomainNameDefSeqElmnts[]   =
{
   &cmMsgDefMetaAt,
   &mgMgcoPathDomainNameDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptPathDomainNameDefSeq =
{
   2,
   mgMgcoOptPathDomainNameDefSeqElmnts
};

/* ["@" pathDomainName] */
PUBLIC CmAbnfElmDef mgMgcoOptPathDomainNameDef   =
{
#ifdef CM_ABNF_DBG
   "Opt Path domain name",
   "At",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 250,
   sizeof(TknStrOSXL),
   ((CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptPathDomainNameDefSeq,
   cmAbnfRegExpAt
};

/************************************************************************/

/* Path name */
PUBLIC CmAbnfElmDef *mgMgcoPathNameDefSeqElmnts[]   =
{
   &mgMgcoPNameDef,
   &mgMgcoOptPathDomainNameDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPathNameDefSeq =
{
   2,
   mgMgcoPathNameDefSeqElmnts
};

/* pathNAME        = ["*"] NAME *("/" / "*"/ ALPHA / DIGIT /"_" / "$")
 *                   ["@" pathDomainName]
 */
PUBLIC CmAbnfElmDef mgMgcoPathNameDef   =
{
#ifdef CM_ABNF_DBG
   "Path name",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 251,
   sizeof(MgMgcoPathName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPathNameDefSeq,
   NULLP
};

/************************************************************************/

/* Special context ID - all/choose/null */

/* "*" / "$" / "-" */
PUBLIC CmAbnfElmDef mgMgcoContextIdSpecialDef   =
{
#ifdef CM_ABNF_DBG
   "Special context ID",
   "ContextId",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 252,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   (U8 *)&mgMgcoCharDefRng,
   mgMgcoRegExpContextId
};

/************************************************************************/

/* Termination ID - "$" */

PUBLIC CmAbnfElmDef mgMgcoTermIdChooseDef   =
{
#ifdef CM_ABNF_DBG
   "Termination ID - $",
   "Dollar",
#endif /* CM_ABNF_DBG */ 
   CM_ABNF_ELMNID_MGCO_BASE + 253,
   sizeof(MgMgcoPathName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   (U8 *)&mgMgcoCharDefRng,
   cmAbnfRegExpDollar
};

/************************************************************************/

/* Termination ID - "*" */

PUBLIC CmAbnfElmDef mgMgcoTermIdAllDef   =
{
#ifdef CM_ABNF_DBG
   "Termination ID - *",
   "Star",
#endif /* CM_ABNF_DBG */ 
   CM_ABNF_ELMNID_MGCO_BASE + 254,
   sizeof(MgMgcoPathName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   (U8 *)&mgMgcoCharDefRng,
   cmAbnfRegExpStar
};

/************************************************************************/

/* Termination ID - "ROOT" */
PUBLIC CmAbnfElmTypeRange mgMgcoTermIdRootDefRng = {4, 4};

PUBLIC CmAbnfElmDef mgMgcoTermIdRootDef   =
{
#ifdef CM_ABNF_DBG
   "Termination ID - ROOT",
   "Root",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 255,
   sizeof(MgMgcoPathName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   (U8 *)&mgMgcoTermIdRootDefRng,
   mgMgcoRegExpRoot
};

/************************************************************************/

/* Termination ID */

PUBLIC CmAbnfElmDef *mgMgcoTermIdDefChcEnum[]   =
{
   &mgMgcoTermIdRootDefEnumDef,
   &mgMgcoTermIdAllDefEnumDef,
   &mgMgcoTermIdChooseDefEnumDef,
   &mgMgcoTermIdOtherDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoTermIdDefChcElmnts[]   =
{
   &mgMgcoTermIdRootDef,
   &mgMgcoTermIdAllDef,
   &mgMgcoTermIdChooseDef,
   &mgMgcoPathNameDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoTermIdDefChc =
{
   4,
   0,
   NULLP,
   mgMgcoTermIdDefChcElmnts,
   mgMgcoTermIdDefChcEnum
};

/* TerminationID        = "ROOT" / pathNAME / "$" / "*" */
PUBLIC CmAbnfElmDef mgMgcoTermIdDef   =
{
#ifdef CM_ABNF_DBG
   "Termination ID",
   "TermId",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 256,
   sizeof(MgMgcoTermId),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoTermIdDefChc,
   mgMgcoRegExpTermId
};

/************************************************************************/

/* Context ID */

PUBLIC CmAbnfElmDef *mgMgcoContextIdDefChcEnum[]   =
{
   &mgMgcoContextIdNullDefEnumDef,
   &mgMgcoContextIdAllDefEnumDef,
   &mgMgcoContextIdChooseDefEnumDef,
   &mgMgcoContextIdOtherDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoContextIdDefChcElmnts[]   =
{
   &mgMgcoContextIdSpecialDef,
   &mgMgcoContextIdOtherDef
};

PUBLIC U8 mgMgcoContextIdDefChcIdx[] = {0, 0, 0, 1};

PUBLIC CmAbnfElmTypeChoice mgMgcoContextIdDefChc =
{
   2,
   4,
   mgMgcoContextIdDefChcIdx,
   mgMgcoContextIdDefChcElmnts,
   mgMgcoContextIdDefChcEnum
};

/* ContextID            = (UINT32 / "*" / "-" / "$") */
PUBLIC CmAbnfElmDef mgMgcoContextIdDef   =
{
#ifdef CM_ABNF_DBG
   "Context ID",
   "ContextId",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 257,
   sizeof(MgMgcoContextId),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoContextIdDefChc,
   mgMgcoRegExpContextId
};

/************************************************************************/

/* General database definition elements */

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoNAMEDefChcElmnts[] =
{
   &mgMgcoUnknownNameDef,
   &mgMgcoSkipStarDef
};

/* NAME */
PUBLIC CmAbnfElmTypeChoice mgMgcoNAMEDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoNAMEDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoNAMEDef   =
{
#ifdef CM_ABNF_DBG
   "NAME",
   "NameAllOrSpec",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 258,
   sizeof(MgMgcoName),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoNAMEDefChc,
   mgMgcoRegExpNameAllOrSpec
};

/************************************************************************/

/* Timestamp */
PUBLIC CmAbnfElmDef *mgMgcoTimeStampDefSeqElmnts[]   =
{
   &mgMgcoDateDef,
   &mgMgcoTDef,
   &mgMgcoTimeDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoTimeStampDefSeq =
{
   3,
   mgMgcoTimeStampDefSeqElmnts
};

/* TimeStamp            = Date "T" Time */
PUBLIC CmAbnfElmDef mgMgcoTimeStampDef   =
{
#ifdef CM_ABNF_DBG
   "Timestamp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 259,
   sizeof(MgMgcoTimeStamp),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoTimeStampDefSeq,
   NULLP
};

/************************************************************************/

/* PkgdName or EvtName - Package Information or Event Name */
PUBLIC CmAbnfElmDef *mgMgcoPkgdNameDefSeqElmnts[]   =
{
   &mgMgcoUnknownNameDef,
   &mgMgcoSLASHDef,
   &mgMgcoNAMEDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPkgdNameDefSeq =
{
   3,
   mgMgcoPkgdNameDefSeqElmnts
};

/* pkgdName             = (PackageName SLASH ItemID) /
 *                        (PackageName SLASH "*") /
 *                        ("*" SLASH "*")
 */
PUBLIC CmAbnfElmDef mgMgcoPkgdNameDef   =
{
#ifdef CM_ABNF_DBG
   "PkgdName or EvtName",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 260,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPkgdNameDefSeq,
   NULLP
};

/************************************************************************/

/* IP address */
PUBLIC CmAbnfElmDef *mgMgcoIpAddrDefChcEnum[] =
{
   &mgMgcoIPv4DefEnumDef,
   &mgMgcoIPv6DefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoIpAddrDefChcElmnts[]   =
{
   &mgMgcoIPv4Def,
   &mgMgcoIPv6Def
};

PUBLIC CmAbnfElmTypeChoice mgMgcoIpAddrDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoIpAddrDefChcElmnts,
   mgMgcoIpAddrDefChcEnum
};

/* IPv4address / IPv6address */
PUBLIC CmAbnfElmDef mgMgcoIpAddrDef   =
{
#ifdef CM_ABNF_DBG
   "IP address",
   "IpV4OrV6",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 261,
   sizeof(((MgMgcoDomAddrPort *)0)->u) + sizeof(TknU8),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoIpAddrDefChc,
   mgMgcoRegExpIpV4OrV6
};

/************************************************************************/

/* opt port */

/* [":" portNumber] */

/************************************************************************/

/* Domain address + (opt) port */
PUBLIC CmAbnfElmDef *mgMgcoDomAddrPortDefSeqElmnts[]   =
{
   &mgMgcoStrictLSBRKTDef,
   &mgMgcoIpAddrDef,
   &mgMgcoStrictRSBRKTDef,
   &mgMsgDefPortNmb
};

PUBLIC CmAbnfElmTypeSeq mgMgcoDomAddrPortDefSeq =
{
   4,
   mgMgcoDomAddrPortDefSeqElmnts
};

/* domainAddress [":" portNumber]
 * domainAddress        = "[" (IPv4address / IPv6address) "]"
 */
PUBLIC CmAbnfElmDef mgMgcoDomAddrPortDef   =
{
#ifdef CM_ABNF_DBG
   "Domain address + (opt) port",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 262,
   sizeof(MgMgcoDomAddrPort),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoDomAddrPortDefSeq,
   NULLP
};

/************************************************************************/

/* domain name + (opt) port */
PUBLIC CmAbnfElmDef *mgMgcoDomNamePortDefSeqElmnts[]   =
{
   &mgMgcoLABRKTDef,
   &mgMgcoDomNameDef,
   &mgMgcoRABRKTDef,
   &mgMsgDefPortNmb
};

PUBLIC CmAbnfElmTypeSeq mgMgcoDomNamePortDefSeq =
{
   4,
   mgMgcoDomNamePortDefSeqElmnts
};

/* domainName [":" portNumber]
 * domainName           = "<" (ALPHA / DIGIT) 
 *                        *63(ALPHA / DIGIT / "-" / ".") ">"
 */
PUBLIC CmAbnfElmDef mgMgcoDomNamePortDef   =
{
#ifdef CM_ABNF_DBG
   "domain name + (opt) port",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 263,
   sizeof(MgMgcoDomNamePort),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoDomNamePortDefSeq,
   NULLP
};

/************************************************************************/

/* MTP address */
PUBLIC CmAbnfElmDef *mgMgcoMtpAddrDefSeqElmnts[]   =
{
   &mgMgcoMtpTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoMtpDef,
   &mgMgcoStrictRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoMtpAddrDefSeq =
{
   4,
   mgMgcoMtpAddrDefSeqElmnts
};

/* mtpAddress           = MTPToken LBRKT octetString RBRKT */
PUBLIC CmAbnfElmDef mgMgcoMtpAddrDef   =
{
#ifdef CM_ABNF_DBG
   "MTP address",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 264,
   sizeof(MgMgcoMtpAddr),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ, 
   (U8 *)&mgMgcoMtpAddrDefSeq,
   NULLP
};

/************************************************************************/

/* MID */

PUBLIC CmAbnfElmDef *mgMgcoMIDDefChcEnum[]   =
{
   &mgMgcoDevDefEnumDef,
   &mgMgcoDomAddrPortDefEnumDef,
   &mgMgcoDomNamePortDefEnumDef,
   &mgMgcoMtpAddrDefEnumDef,
   &mgMgcoPortDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoMIDDefChcElmnts[]   =
{
   &mgMgcoPathNameDef,
   &mgMgcoDomAddrPortDef,
   &mgMgcoDomNamePortDef,
   &mgMgcoMtpAddrDef,
   &mgMsgDefPortNumber
};

PUBLIC CmAbnfElmTypeChoice mgMgcoMIDDefChc =
{
   5,
   0,
   NULLP,
   mgMgcoMIDDefChcElmnts,
   mgMgcoMIDDefChcEnum
};

/* mId = ((domainAddress / domainName) [":" portNumber]) /
 *       mtpAddress / deviceName
 */
PUBLIC CmAbnfElmDef mgMgcoMIDDef   =
{
#ifdef CM_ABNF_DBG
   "MID",
   "MidChc",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 265,
   sizeof(MgMgcoMid),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoMIDDefChc,
   mgMgcoRegExpMidChc
};

/* Added a new element for MID as string */

PUBLIC CmAbnfElmTypeRange  mgMgcoMIDStrDefRange =  {   1 , 0xffff  };

PUBLIC CmAbnfElmDef  mgMgcoMIDStrDef =
{
#ifdef  CM_ABNF_DBG
    "MGCP: D STR DEF " ,
    "MidAsStr" ,
#endif
    CM_ABNF_ELMNID_MGCO_BASE  +  999 ,
    sizeof (TknStrOSXL) ,
    (( CM_ABNF_MANDATORY  << CM_ABNF_PROT_MEGACO_DEF_OFFSET ))|(( CM_ABNF_MANDATORY  << CM_ABNF_PROT_MEGACO_V2_OFFSET )),
    CM_ABNF_TYPE_OCTSTRXL ,
    (U8 *) &mgMgcoMIDStrDefRange ,
    mgMsgRegExpMidAsStr
};


/************************************************************************/

/* Termination ID array */
PUBLIC CmAbnfElmDef *mgMgcoTermIdArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoTermIdDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoTermIdArrayDefSeqOf =
{
   1,
   MGT_MAX_TERMS,
   2,
   mgMgcoTermIdArrayDefSeqOfElmnts,
   sizeof(MgMgcoTermId)
};

/* *(COMMA TerminationID) */
PUBLIC CmAbnfElmDef mgMgcoTermIdArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Termination ID array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 266,
   sizeof(MgMgcoTermIdLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoTermIdArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Terminator 2 */
PUBLIC CmAbnfElmDef *mgMgcoTermIdLst2DefSeqElmnts[]   =
{
   &mgMgcoTermIdDef,
   &mgMgcoTermIdArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoTermIdLst2DefSeq =
{
   2,
   mgMgcoTermIdLst2DefSeqElmnts
};

/* TerminationID *(COMMA TerminationID) */
PUBLIC CmAbnfElmDef mgMgcoTermIdLst2Def   =
{
#ifdef CM_ABNF_DBG
   "Terminator 2",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 267,
   sizeof(MgMgcoTermIdLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoTermIdLst2DefSeq,
   NULLP
};

/************************************************************************/

/* Termination ID list */
PUBLIC CmAbnfElmDef *mgMgcoTermIdLstDefSeqElmnts[]   =
{
   &mgMgcoLBRKTDef,
   &mgMgcoTermIdLst2Def,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoTermIdLstDefSeq =
{
   3,
   mgMgcoTermIdLstDefSeqElmnts
};

/* terminationIDList    = LBRKT TerminationID *(COMMA TerminationID)
 *                        RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoTermIdLstDef   =
{
#ifdef CM_ABNF_DBG
   "Termination ID list - bracketed",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 268,
   sizeof(MgMgcoTermIdLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoTermIdLstDefSeq,
   NULLP,
};

/************************************************************************/

/* Reserved group mode */
PUBLIC CmAbnfElmDef *mgMgcoResGrpDefSeqElmnts[]   =
{
   &mgMgcoReservedGroupTokenDef,
   &mgMgcoEQUALDef,
   &mgMsgDefOnOff
};

PUBLIC CmAbnfElmTypeSeq mgMgcoResGrpDefSeq =
{
   3,
   mgMgcoResGrpDefSeqElmnts
};

/* reservedGroupMode       = ReservedGroupToken EQUAL ( "ON" / "OFF" ) */
PUBLIC CmAbnfElmDef mgMgcoResGrpDef   =
{
#ifdef CM_ABNF_DBG
   "Reserved group mode",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 269,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoResGrpDefSeq,
   NULLP
};

/************************************************************************/

/* Reserved value mode */
PUBLIC CmAbnfElmDef *mgMgcoResValDefSeqElmnts[]   =
{
   &mgMgcoReservedValueTokenDef,
   &mgMgcoEQUALDef,
   &mgMsgDefOnOff
};

PUBLIC CmAbnfElmTypeSeq mgMgcoResValDefSeq =
{
   3,
   mgMgcoResValDefSeqElmnts
};

/* reservedValueMode       = ReservedValueToken EQUAL ( "ON" / "OFF" ) */
PUBLIC CmAbnfElmDef mgMgcoResValDef   =
{
#ifdef CM_ABNF_DBG
   "Reserved value mode",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 270,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoResValDefSeq,
   NULLP
};

/************************************************************************/

/* Stream mode value aka streamModes */
PUBLIC CmAbnfElmDef *mgMgcoModeValDefChcEnum[]   =
{
   &mgMgcoSendonlyEnum,
   &mgMgcoRecvonlyEnum,
   &mgMgcoSendrecvEnum,
   &mgMgcoInactiveEnum,
   &mgMgcoLoopbackEnum
};

PUBLIC CmAbnfElmTypeChoice mgMgcoModeValDefChc =
{
   5,
   0,
   NULLP,
   NULLP,
   mgMgcoModeValDefChcEnum
};

/* streamModes          = (SendonlyToken / RecvonlyToken / SendrecvToken /
 *                         InactiveToken / LoopbackToken)
 */
PUBLIC CmAbnfElmDef mgMgcoModeValDef   =
{
#ifdef CM_ABNF_DBG
   "streamModes",
   "StreamModes",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 271,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoModeValDefChc,
   mgMgcoRegExpStreamModes
};

/************************************************************************/

/* Stream mode */
PUBLIC CmAbnfElmDef *mgMgcoStreamModeDefSeqElmnts[]   =
{
   &mgMgcoModeTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoModeValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoStreamModeDefSeq =
{
   3,
   mgMgcoStreamModeDefSeqElmnts
};

/* streamMode           = ModeToken EQUAL streamModes */
PUBLIC CmAbnfElmDef mgMgcoStreamModeDef   =
{
#ifdef CM_ABNF_DBG
   "Stream mode",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 272,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoStreamModeDefSeq,
   NULLP
};

/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoParmValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoValueDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoParmValEqDefSeq =
{
   2,
   mgMgcoParmValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoParmValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 273,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoParmValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoParmValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoValueDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoParmValGtDefSeq =
{
   2,
   mgMgcoParmValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoParmValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 274,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoParmValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoParmValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoValueDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoParmValLtDefSeq =
{
   2,
   mgMgcoParmValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoParmValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 275,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoParmValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoParmValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoValueDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoParmValNeDefSeq =
{
   2,
   mgMgcoParmValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoParmValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 276,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoParmValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoParmValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoValueDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoParmValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoParmValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoParmValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 277,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoParmValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoParmValLstDefSeqElmnts[]   =
{
   &mgMgcoValueDef,
   &mgMgcoParmValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoParmValLstDefSeq =
{
   2,
   mgMgcoParmValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoParmValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 278,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoParmValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoParmValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoParmValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoParmValAndDefSeq =
{
   4,
   mgMgcoParmValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoParmValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 279,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoParmValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoParmValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoParmValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoParmValOrDefSeq =
{
   4,
   mgMgcoParmValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoParmValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 280,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoParmValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoParmValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoValueDef,
   &cmMsgDefMetaColon,
   &mgMgcoValueDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoParmValRngDefSeq =
{
   6,
   mgMgcoParmValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoParmValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 281,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoParmValRngDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value */
PUBLIC CmAbnfElmDef *mgMgcoParmValDefChcEnum[]   =
{
   &mgMgcoParmValDefEqEnumDef,
   &mgMgcoParmValDefGtEnumDef,
   &mgMgcoParmValDefLtEnumDef,
   &mgMgcoParmValDefNeEnumDef,
   &mgMgcoParmValDefAndEnumDef,
   &mgMgcoParmValDefOrEnumDef,
   &mgMgcoParmValDefRngEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoParmValDefChcElmnts[]   =
{
   &mgMgcoParmValEqDef,
   &mgMgcoParmValGtDef,
   &mgMgcoParmValLtDef,
   &mgMgcoParmValNeDef,
   &mgMgcoParmValAndDef,
   &mgMgcoParmValOrDef,
   &mgMgcoParmValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoParmValDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoParmValDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

/* parmValue            = (EQUAL alternativeValue / INEQUAL VALUE)
 * alternativeValue     = ( VALUE / LSBRKT VALUE *(COMMA VALUE) RSBRKT
 *                          / LBRKT VALUE *(COMMA VALUE) RBRKT
 *                          / LSBRKT VALUE COLON VALUE RSBRKT
 *                        )
 */
PUBLIC CmAbnfElmDef mgMgcoParmValDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 282,
   sizeof(MgMgcoParmValue),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoParmValDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

/* Property parameter - package "*" */
PUBLIC CmAbnfElmDef *mgMgcoPropParmAllPkgDefSeqElmnts[]   =
{
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSLASHDef,
   &mgMgcoNAMEDef,
   &mgMgcoParmValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmAllPkgDefSeq =
{
   4,
   mgMgcoPropParmAllPkgDefSeqElmnts
};

/* propertyParm         = pkgdName parmValue */
PUBLIC CmAbnfElmDef mgMgcoPropParmAllPkgDef   =
{
#ifdef CM_ABNF_DBG
   "Property parameter - all",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 283,
   sizeof(MgMgcoPropParm) - sizeof(TknPkgId),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmAllPkgDefSeq,
   NULLP
};

/* Property parameter */
PUBLIC CmAbnfElmDef *mgMgcoPropParmUnknownPkgDefSeqElmnts[]   =
{
   &mgMgcoPkgdNameDef,
   &mgMgcoParmValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmUnknownPkgDefSeq =
{
   2,
   mgMgcoPropParmUnknownPkgDefSeqElmnts
};

/* propertyParm         = pkgdName parmValue */
PUBLIC CmAbnfElmDef mgMgcoPropParmUnknownPkgDef   =
{
#ifdef CM_ABNF_DBG
   "Property parameter - unknown",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 284,
   sizeof(MgMgcoPropParm) - sizeof(TknPkgId),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmUnknownPkgDefSeq,
   NULLP
};

/************************************************************************/

/*************  New Package Enum Definations  ***************************/
#define MGT_PKG_FAXTONEDET 14

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameFaxToneDetEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameFaxToneDetEnum =
#endif
{
   (Data *)"ftmd",
   MGT_PKG_FAXTONEDET
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameFaxToneDetEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - FaxToneDet",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 788,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameFaxToneDetEnum,
   NULLP
};
#define MGT_PKG_GENERIC_ANNC 29 

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameGenAnncEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameGenAnncEnum =
#endif
{
   (Data *)"an",
   MGT_PKG_GENERIC_ANNC
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameGenAnncEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - GenAnnc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1018,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameGenAnncEnum,
   NULLP
};
#define MGT_PKG_ANCILLARYINPUT 27

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameAncillaryInputEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameAncillaryInputEnum =
#endif
{
   (Data *)"anci",
   MGT_PKG_ANCILLARYINPUT
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameAncillaryInputEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - AncillaryInput",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1185,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameAncillaryInputEnum,
   NULLP
};
#define MGT_PKG_CALLTYPDISCR 17

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameCallTypDiscrEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameCallTypDiscrEnum =
#endif
{
   (Data *)"ctyp",
   MGT_PKG_CALLTYPDISCR
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameCallTypDiscrEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - CallTypDiscr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1226,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameCallTypDiscrEnum,
   NULLP
};
#define MGT_PKG_DISPLAY 20

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameDisplayEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameDisplayEnum =
#endif
{
   (Data *)"dis",
   MGT_PKG_DISPLAY
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameDisplayEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - Display",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1594,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameDisplayEnum,
   NULLP
};
#define MGT_PKG_FAX 18

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameFaxEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameFaxEnum =
#endif
{
   (Data *)"fax",
   MGT_PKG_FAX
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameFaxEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - Fax",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1734,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameFaxEnum,
   NULLP
};
#define MGT_PKG_INDICATOR 25

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameIndicatorEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameIndicatorEnum =
#endif
{
   (Data *)"ind",
   MGT_PKG_INDICATOR
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameIndicatorEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - Indicator",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1870,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameIndicatorEnum,
   NULLP
};
#define MGT_PKG_IPFAX 19

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameIpFaxEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameIpFaxEnum =
#endif
{
   (Data *)"ipfax",
   MGT_PKG_IPFAX
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameIpFaxEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - IpFax",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1928,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameIpFaxEnum,
   NULLP
};
#define MGT_PKG_KEY 21

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameKeyEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameKeyEnum =
#endif
{
   (Data *)"key",
   MGT_PKG_KEY
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameKeyEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - Key",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 2102,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameKeyEnum,
   NULLP
};
#define MGT_PKG_KEYPAD 22

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameKeyPadEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameKeyPadEnum =
#endif
{
   (Data *)"kp",
   MGT_PKG_KEYPAD
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameKeyPadEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - KeyPad",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 2824,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameKeyPadEnum,
   NULLP
};
#define MGT_PKG_LABELKEY 23

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameLabelKeyEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameLabelKeyEnum =
#endif
{
   (Data *)"labelkey",
   MGT_PKG_LABELKEY
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameLabelKeyEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - LabelKey",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 2341,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameLabelKeyEnum,
   NULLP
};
#define MGT_PKG_FUNCKEY 24

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameFuncKeyEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameFuncKeyEnum =
#endif
{
   (Data *)"kf",
   MGT_PKG_FUNCKEY
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameFuncKeyEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - FuncKey",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 2372,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameFuncKeyEnum,
   NULLP
};
#define MGT_PKG_SOFTKEY 26

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameSoftKeyEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameSoftKeyEnum =
#endif
{
   (Data *)"ks",
   MGT_PKG_SOFTKEY
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameSoftKeyEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - SoftKey",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 2391,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameSoftKeyEnum,
   NULLP
};
#define MGT_PKG_TXTCNVR 15

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameTxtCnvrEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameTxtCnvrEnum =
#endif
{
   (Data *)"txc",
   MGT_PKG_TXTCNVR
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameTxtCnvrEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - TxtCnvr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 2485,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameTxtCnvrEnum,
   NULLP
};
#define MGT_PKG_TXTTELPHONE 16

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameTxtTelPhoneEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameTxtTelPhoneEnum =
#endif
{
   (Data *)"txp",
   MGT_PKG_TXTTELPHONE
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameTxtTelPhoneEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - TxtTelPhone",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 2650,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameTxtTelPhoneEnum,
   NULLP
};

#define MGT_PKG_ADVAUSRVRBASE 51

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameAdvAuSrvrBaseEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameAdvAuSrvrBaseEnum =
#endif
{
   (Data *)"aasb",
   MGT_PKG_ADVAUSRVRBASE
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameAdvAuSrvrBaseEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - AdvAuSrvrBase",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 3103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameAdvAuSrvrBaseEnum,
   NULLP
};
#define MGT_PKG_AASDIGCOLLECT 52

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameAasDigCollectEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameAasDigCollectEnum =
#endif
{
   (Data *)"aasdc",
   MGT_PKG_AASDIGCOLLECT
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameAasDigCollectEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - AasDigCollect",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 3219,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameAasDigCollectEnum,
   NULLP
};
#define MGT_PKG_AASRECODING 53

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameAasRecodingEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameAasRecodingEnum =
#endif
{
   (Data *)"aasrec",
   MGT_PKG_AASRECODING
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameAasRecodingEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - AasRecoding",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 3512,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameAasRecodingEnum,
   NULLP
};
#define MGT_PKG_ADVAUSRVRSEGMNGMT 54

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameAdvAuSrvrSegMngmtEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameAdvAuSrvrSegMngmtEnum =
#endif
{
   (Data *)"aassm",
   MGT_PKG_ADVAUSRVRSEGMNGMT
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameAdvAuSrvrSegMngmtEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - AdvAuSrvrSegMngmt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 3851,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameAdvAuSrvrSegMngmtEnum,
   NULLP
};

/* 
 * [TEL]: Following lines added from pkg_enum.c 
 */

/*
 * [TEL]: Generic Bearer Connection Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_gen_brr_conEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_gen_brr_conEnum =
#endif
{
   (Data *)"GB",
   MGT_PKG_GEN_BRR_CON
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_gen_brr_conEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _gen_brr_con",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_gen_brr_conEnum,
   NULLP
};

/*
 * [TEL]: End of additions for Generic Bearer Connection Package
 */

/*
 * [TEL]: Basic CAS addressing Package 
 */


#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_bcasaddrEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_bcasaddrEnum =
#endif
{
   (Data *)"bcasaddr",
   MGT_PKG_BCASADDR
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_bcasaddrEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _bcasaddr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_bcasaddrEnum,
   NULLP
};

/*
 * [TEL]: End of additions for Basic CAS addressing Package 
 */

/*
 * [TEL]: Intrusion Tone Generator Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_int_tngnEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_int_tngnEnum =
#endif
{
   (Data *)"int",
   MGT_PKG_INT_TNGN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_int_tngnEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _int_tngn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_int_tngnEnum,
   NULLP
};

/*
 * [TEL]: End of additions for Intrusion Tone Generator Package 
 */

/*
 * [TEL]: Bearer Control Tunneling Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_brr_ctl_tnEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_brr_ctl_tnEnum =
#endif
{
   (Data *)"BT",
   MGT_PKG_BRR_CTL_TN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_brr_ctl_tnEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _brr_ctl_tn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_brr_ctl_tnEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for Bearer Control Tunneling Package 
 */

/*
 * [TEL]: Bearer Characteristics Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_brr_charEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_brr_charEnum =
#endif
{
   (Data *)"BCP",
   MGT_PKG_BRR_CHAR
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_brr_charEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _brr_char",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_brr_charEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for Bearer Characteristics Package 
 */

/* 
 * [TEL]: TFO Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_tri_gtfoEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_tri_gtfoEnum =
#endif
{
   (Data *)"threegtfoc",
   MGT_PKG_TRI_GTFO
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_tri_gtfoEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _tri_gtfo",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_tri_gtfoEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for TFO Package 
 */

/* 
 * [TEL]: Quiet Termination Test Component Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_qt_tm_ltcEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_qt_tm_ltcEnum =
#endif
{
   (Data *)"qtlt",
   MGT_PKG_QT_TM_LTC
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_qt_tm_ltcEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _qt_tm_ltc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_qt_tm_ltcEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for Quiet Termination Test Component Package 
 */

/* 
 * [TEL]: Basic CAS Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_bcasEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_bcasEnum =
#endif
{
   (Data *)"bcas",
   MGT_PKG_BCAS
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_bcasEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _bcas",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_bcasEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for Basic CAS Package 
 */

/* 
 * [TEL]: Robbed Bit Signaling Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_rbsEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_rbsEnum =
#endif
{
   (Data *)"rbs",
   MGT_PKG_RBS
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_rbsEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _rbs",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_rbsEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for Robbed Bit Signaling Package 
 */

/* 
 * [TEL]: Operator Services Emergency Services Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_osesEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_osesEnum =
#endif
{
   (Data *)"oses",
   MGT_PKG_OSES
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_osesEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _oses",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_osesEnum,
   NULLP
};

/*
 * [TEL]: End of additions for Operator Services Emergency Services Package 
 */

/* 
 * [TEL]: Modification of link characteristics bearer capability Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_tri_gmlcEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_tri_gmlcEnum =
#endif
{
   (Data *)"threegmlc",
   MGT_PKG_TRI_GMLC
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_tri_gmlcEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _tri_gmlc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_tri_gmlcEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for Modification of link characteristics bearer 
 * capability Package 
 */

/* 
 * [TEL]: Loop back line test response Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_lp_bk_ltrEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_lp_bk_ltrEnum =
#endif
{
   (Data *)"lltr",
   MGT_PKG_LP_BK_LTR
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_lp_bk_ltrEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _lp_bk_ltr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_lp_bk_ltrEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for Loop back line test response Package 
 */

/* 
 * [TEL]: Cellular text telephone modem text transport Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_tri_gctmEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_tri_gctmEnum =
#endif
{
   (Data *)"threegctm",
   MGT_PKG_TRI_GCTM
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_tri_gctmEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _tri_gctm",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_tri_gctmEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for Cellular text telephone modem text transport 
 * Package 
 */

/* 
 * [TEL]: 3GUP User plane Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_tri_gupEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_tri_gupEnum =
#endif
{
   (Data *)"threegup",
   MGT_PKG_TRI_GUP
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_tri_gupEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _tri_gup",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_tri_gupEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for 3GUP User Plane Package 
 */

/* 
 * [TEL]: Inactivity Timer Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_inacttimerEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_inacttimerEnum =
#endif
{
   (Data *)"it",
   MGT_PKG_INACTTIMER
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_inacttimerEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _inacttimer",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4197,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_inacttimerEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for Inactivity Timer Package 
 */

/* 
 * [TEL]: Bearer Network Connection Cut Through Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_bnctEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_bnctEnum =
#endif
{
   (Data *)"BNCT",
   MGT_PKG_BNCT
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_bnctEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _bnct",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_bnctEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for Bearer Network Connection 
 * Cut Through Package 
 */

/* 
 * [TEL]: Reuse Idle Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_riEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_riEnum =
#endif
{
   (Data *)"RI",
   MGT_PKG_RI
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_riEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _ri",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_riEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for Reuse Idle Package 
 */

/* 
 * [TEL]: Circuit Switched Data Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_tri_gcsdEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_tri_gcsdEnum =
#endif
{
   (Data *)"threegcsd",
   MGT_PKG_TRI_GCSD
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_tri_gcsdEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _tri_gcsd",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_tri_gcsdEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for Circuit Switched Data Package 
 */

/* 
 * [TEL]: Media Gateway Resource Congestion Handling Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_CHPEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_CHPEnum =
#endif
{
   (Data *)"chp",
   MGT_PKG_CHP
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_CHPEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _CHP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_CHPEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for Media Gateway Resource Congestion Handling 
 * Package 
 */

/* 
 * [TEL]: ITU-T 2804 Hz Tone line test Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_itu_lt_2804Enum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_itu_lt_2804Enum =
#endif
{
   (Data *)"itult2804",
   MGT_PKG_ITU_LT_2804
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_itu_lt_2804EnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _itu_lt_2804",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_itu_lt_2804Enum,
   NULLP
};

/* 
 * [TEL]: End of additions for ITU-T 2804 Hz Tone line test Package 
 */

/* 
 * [TEL]: ANSI 1004 Hz Test tone line test Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_ansi_lt_1004Enum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_ansi_lt_1004Enum =
#endif
{
   (Data *)"ansilt1004",
   MGT_PKG_ANSI_LT_1004
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_ansi_lt_1004EnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _ansi_lt_1004",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_ansi_lt_1004Enum,
   NULLP
};

/* 
 * [TEL]: End of additions for ANSI 1004 Hz Test tone line test Package 
 */

/* 
 * [TEL]: ANSI 2225 Hz Test progress tone line test Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_ansi_lt_2225Enum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_ansi_lt_2225Enum =
#endif
{
   (Data *)"ansilt2225",
   MGT_PKG_ANSI_LT_2225
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_ansi_lt_2225EnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _ansi_lt_2225",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_ansi_lt_2225Enum,
   NULLP
};


/* 
 * [TEL]: End of additions for ANSI 2225 Hz Test progress tone line test 
 * Package 
 */

/* 
 * [TEL]: ITU-T 404 Hz Line test Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_itu_lt_404Enum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_itu_lt_404Enum =
#endif
{
   (Data *)"itult404",
   MGT_PKG_ITU_LT_404
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_itu_lt_404EnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _itu_lt_404",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_itu_lt_404Enum,
   NULLP
};

/* 
 * [TEL]: End of additions for ITU-T 404 Hz Line test Package 
 */

/* 
 * [TEL]: ITU-T 816 Hz Line test Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_itu_lt_816Enum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_itu_lt_816Enum =
#endif
{
   (Data *)"itult816",
   MGT_PKG_ITU_LT_816
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_itu_lt_816EnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _itu_lt_816",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_itu_lt_816Enum,
   NULLP
};

/* 
 * [TEL]: End of additions for ITU-T 816 Hz Line test Package 
 */

/* 
 * [TEL]: ITU-T 1020 Hz Line test Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_itu_lt_1020Enum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_itu_lt_1020Enum =
#endif
{
   (Data *)"itult1020",
   MGT_PKG_ITU_LT_1020
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_itu_lt_1020EnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _itu_lt_1020",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_itu_lt_1020Enum,
   NULLP
};

/* 
 * [TEL]: End of additions for ITU-T 1020 Hz Line test Package 
 */

/*
 * [TEL]: ITU-T ATME2 Test line response Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_itu_lt_atme2Enum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_itu_lt_atme2Enum =
#endif
{
   (Data *)"itultatme2",
   MGT_PKG_ITU_LT_ATME2
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_itu_lt_atme2EnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _itu_lt_atme2",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_itu_lt_atme2Enum,
   NULLP
};

/*
 * [TEL]: End of additions for ITU-T ATME2 Test line response Package
 */

/* 
 * [TEL]: ITU-T Noise Test Tone Line Test Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_itu_lt_nttEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_itu_lt_nttEnum =
#endif
{
   (Data *)"itultntt",
   MGT_PKG_ITU_LT_NTT
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_itu_lt_nttEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _itu_lt_ntt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_itu_lt_nttEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for ITU-T Noise Test Tone Line Test Package 
 */

/* 
 * [TEL]: ITU-T Digital Pseudo Random Test tone Line test Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_itu_lt_dprtEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_itu_lt_dprtEnum =
#endif
{
   (Data *)"itultdprt",
   MGT_PKG_ITU_LT_DPRT
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_itu_lt_dprtEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _itu_lt_dprt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_itu_lt_dprtEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for ITU-T Digital Pseudo Random 
 * Test tone Line test Package 
 */

/* 
 * [TEL]: ANSI test responder line test Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_ansi_lt_trEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_ansi_lt_trEnum =
#endif
{
   (Data *)"ansilttres",
   MGT_PKG_ANSI_LT_TR
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_ansi_lt_trEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _ansi_lt_tr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_ansi_lt_trEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for ANSI test responder line test Package 
 */

/* 
 * [TEL]: ANSI Digital test signal line test Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_ansi_lt_dtsEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_ansi_lt_dtsEnum =
#endif
{
   (Data *)"ansiltdts",
   MGT_PKG_ANSI_LT_DTS
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_ansi_lt_dtsEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _ansi_lt_dts",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_ansi_lt_dtsEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for ANSI Digital test signal line test Package 
 */

/* 
 * [TEL]: ANSI Inverting loop back line test Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_ansi_in_ltrEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_ansi_in_ltrEnum =
#endif
{
   (Data *)"ansiinvlltr",
   MGT_PKG_ANSI_IN_LTR
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_ansi_in_ltrEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _ansi_in_ltr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_ansi_in_ltrEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for ANSI Inverting loop back 
 * line test Package 
 */

/* 
 * [TEL]: ITU-T 2100Hz Disable Tone line test Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_itu_lt_distEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_itu_lt_distEnum =
#endif
{
   (Data *)"itultdist",
   MGT_PKG_ITU_LT_DIST
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_itu_lt_distEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _itu_lt_dist",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_itu_lt_distEnum,
   NULLP
};

/* 
 * [TEL]: End of additions for ITU-T 2100Hz Disable Tone 
 * line test Package 
 */

/* 
 * [TEL]: ITU-T 2100Hz Disable Echo Canceller Tone 
 * line test Package 
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_itu_lt_dsecEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_itu_lt_dsecEnum =
#endif
{
   (Data *)"itultdisecd",
   MGT_PKG_ITU_LT_DSEC
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_itu_lt_dsecEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _itu_lt_dsec",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_itu_lt_dsecEnum,
   NULLP
};

/*
 * [TEL]: End of additions for ITU-T 2100Hz Disable Echo 
 * Canceller Tone line test Package 
 */

/*
 * [TEL]: IP Transport Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_tri_giptraEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_tri_giptraEnum =
#endif
{
   (Data *)"threegiptra",
   MGT_PKG_TRI_GIPTRA
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_tri_giptraEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _tri_giptra",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_tri_giptraEnum,
   NULLP
};

/*
 * [TEL]: End of additions for IP Transport Package
 */

/*
 * [TEL]: Business Tonegen Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_bsns_tngnEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_bsns_tngnEnum =
#endif
{
   (Data *)"biztn",
   MGT_PKG_BSNS_TNGN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_bsns_tngnEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _bsns_tngn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_bsns_tngnEnum,
   NULLP
};

/*
 * [TEL]: End of additions for Business Tonegen Package
 */

/*
 * [TEL]: Expanded Service Tonegen Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_xd_srv_tngnEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_xd_srv_tngnEnum =
#endif
{
   (Data *)"xsrvtn",
   MGT_PKG_XD_SRV_TNGN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_xd_srv_tngnEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _xd_srv_tngn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_xd_srv_tngnEnum,
   NULLP
};

/*
 * [TEL]: End of additions for Expanded Service Tonegen Package
 */

/*
 * [TEL]: Basic Service Tonegen Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_bsc_srv_tnEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_bsc_srv_tnEnum =
#endif
{
   (Data *)"srvtn",
   MGT_PKG_BSC_SRV_TN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_bsc_srv_tnEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _bsc_srv_tn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_bsc_srv_tnEnum,
   NULLP
};

/*
 * [TEL]: End of additions for Basic Service Tonegen Package
 */

/*
 * [TEL]: Operator Service and Extension Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_osextEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_osextEnum =
#endif
{
   (Data *)"osext",
   MGT_PKG_OSEXT
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_osextEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _osext",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_osextEnum,
   NULLP
};

/*
 * [TEL]: End of additions for Operator Service and Extension Package
 */

/*
 * [TEL]: Expanded Call Progress Tonegen Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_xd_calpg_tngnEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_xd_calpg_tngnEnum =
#endif
{
   (Data *)"xcg",
   MGT_PKG_XD_CALPG_TNGN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_xd_calpg_tngnEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _xd_calpg_tngn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_xd_calpg_tngnEnum,
   NULLP
};

/*
 * [TEL]: End of additions for Expanded Call Progress Tonegen Package
 */

/*
 * [TEL]: 3G Expanded Call Progress Tonegen Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_trig_xd_calpg_tngnEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_trig_xd_calpg_tngnEnum =
#endif
{
   (Data *)"threegxcg",
   MGT_PKG_TRIG_XD_CALPG_TNGN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_trig_xd_calpg_tngnEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _trig_xd_calpg_tngn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_trig_xd_calpg_tngnEnum,
   NULLP
};
/*
 * [TEL]: End of additions for 3G Expanded Call Progress Tonegen Package
 */

/*
 * [TEL]: Flexible Tonegen Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_trig_flex_tnEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_trig_flex_tnEnum =
#endif
{
   (Data *)"threegflex",
   MGT_PKG_TRIG_FLEX_TN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_trig_flex_tnEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _trig_flex_tn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_trig_flex_tnEnum,
   NULLP
};

/*
 * [TEL]: End of additions for Flexible Tonegen Package
 */

/*
 * [TEL]: Basic Call Progress Tonegen with directionality Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_bsc_cal_tnEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_bsc_cal_tnEnum =
#endif
{
   (Data *)"bcg",
   MGT_PKG_BSC_CAL_TN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_bsc_cal_tnEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _bsc_cal_tn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_bsc_cal_tnEnum,
   NULLP
};

/*
 * [TEL]: End of additions for Basic Call Progress Tonegen with directionality 
 * Package
 */

/*
 * [TEL2]: Media Gateway Overload Control Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_OcpEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_OcpEnum =
#endif
{
   (Data *)"ocp",
   MGT_PKG_OCP
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_OcpEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Ocp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_OcpEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Media Gateway Overload Control Package
 */

/*
 * [TEL2]: Floor Control Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Flr_CtlEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Flr_CtlEnum =
#endif
{
   (Data *)"fcp",
   MGT_PKG_FLR_CTL
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Flr_CtlEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Flr_Ctl",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Flr_CtlEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Floor Control Package
 */

/*
 * [TEL2]: Indication Of Being Viewed Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Ind_ViewEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Ind_ViewEnum =
#endif
{
   (Data *)"indview",
   MGT_PKG_IND_VIEW
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Ind_ViewEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Ind_View",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Ind_ViewEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Indication Of Being Viewed Package
 */

/*
 * [TEL2]: Volume Control Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Vol_CtlEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Vol_CtlEnum =
#endif
{
   (Data *)"vcp",
   MGT_PKG_VOL_CTL
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Vol_CtlEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Vol_Ctl",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Vol_CtlEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Volume Control Package
 */

/*
 * [TEL2]: Volume Detection Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Vol_DetEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Vol_DetEnum =
#endif
{
   (Data *)"vdp",
   MGT_PKG_VOL_DET
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Vol_DetEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Vol_Det",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Vol_DetEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Volume Detection Package
 */

/*
 * [TEL2]: Volume Level Mixing Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Vol_Lev_MixEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Vol_Lev_MixEnum =
#endif
{
   (Data *)"vlmp",
   MGT_PKG_VOL_LEV_MIX
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Vol_Lev_MixEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Vol_Lev_Mix",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Vol_Lev_MixEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Volume Level Mixing Package
 */

/*
 * [TEL2]: Voice Activated Video Switch Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Voi_Act_Vid_SwEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Voi_Act_Vid_SwEnum =
#endif
{
   (Data *)"vavsp",
   MGT_PKG_VOI_ACT_VID_SW
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Voi_Act_Vid_SwEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Voi_Act_Vid_Sw",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Voi_Act_Vid_SwEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Voice Activated Video Switch Package
 */

/*
 * [TEL2]: Lecture Video Mode Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Lec_Vid_ModEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Lec_Vid_ModEnum =
#endif
{
   (Data *)"lvmp",
   MGT_PKG_LEC_VID_MOD
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Lec_Vid_ModEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Lec_Vid_Mod",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Lec_Vid_ModEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Lecture Video Mode Package
 */

/*
 * [TEL2]: Contributing Video Source Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Con_Vid_SrcEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Con_Vid_SrcEnum =
#endif
{
   (Data *)"cvsp",
   MGT_PKG_CON_VID_SRC
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Con_Vid_SrcEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Con_Vid_Src",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Con_Vid_SrcEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Contributing Video Source Package
 */

/*
 * [TEL2]: Profile Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_ProfEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_ProfEnum =
#endif
{
   (Data *)"prp",
   MGT_PKG_PROF
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_ProfEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Prof",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_ProfEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Profile Package
 */

/*
 * [TEL2]: Semi-permanent Connection Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Sem_PerEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Sem_PerEnum =
#endif
{
   (Data *)"semper",
   MGT_PKG_SEM_PER
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Sem_PerEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Sem_Per",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Sem_PerEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Semi-permanent Connection Package
 */

/*
 * [TEL2]: Video Window Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Vid_WinEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Vid_WinEnum =
#endif
{
   (Data *)"vwp",
   MGT_PKG_VID_WIN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Vid_WinEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Vid_Win",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Vid_WinEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Video Window Package
 */

/*
 * [TEL2]: Tiled Window Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Til_WinEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Til_WinEnum =
#endif
{
   (Data *)"tilwin",
   MGT_PKG_TIL_WIN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Til_WinEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Til_Win",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Til_WinEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Tiled Window Package
 */

/*
 * [TEL2]: Enhanced Alerting Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_En_AlertEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_En_AlertEnum =
#endif
{
   (Data *)"alert",
   MGT_PKG_EN_ALERT
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_En_AlertEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _En_Alert",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_En_AlertEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Enhanced Alerting Package
 */

/*
 * [TEL2]: Shared Risk Group Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Sh_RiskEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Sh_RiskEnum =
#endif
{
   (Data *)"shrisk",
   MGT_PKG_SH_RISK
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Sh_RiskEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Sh_Risk",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Sh_RiskEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Shared Risk Group Package
 */

/*
 * [TEL2]: Mixing Volume Level Control Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Mix_Vol_CtlEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Mix_Vol_CtlEnum =
#endif
{
   (Data *)"mvlcp",
   MGT_PKG_MIX_VOL_CTL
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Mix_Vol_CtlEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Mix_Vol_Ctl",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Mix_Vol_CtlEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Mixing Volume Level Control Package
 */

/*
 * [TEL2]: CAS Blocking Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Cas_BlkEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Cas_BlkEnum =
#endif
{
   (Data *)"casblk",
   MGT_PKG_CAS_BLK
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Cas_BlkEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Cas_Blk",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Cas_BlkEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for CAS Blocking Package
 */

/*
 * [TEL2]: Conferencing Tones Generation Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Conf_TnEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Conf_TnEnum =
#endif
{
   (Data *)"conftn",
   MGT_PKG_CONF_TN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Conf_TnEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Conf_Tn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Conf_TnEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Conferencing Tones Generation Package
 */

/*
 * [TEL2]: Diagnostic Tones Generation Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_TestEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_TestEnum =
#endif
{
   (Data *)"test",
   MGT_PKG_TEST
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_TestEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Test",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_TestEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Diagnostic Tones Generation Package
 */

/*
 * [TEL2]: Carrier Tones Generation Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Carr_TnEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Carr_TnEnum =
#endif
{
   (Data *)"carr",
   MGT_PKG_CARR_TN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Carr_TnEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Carr_Tn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Carr_TnEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Carrier Tones Generation Package
 */

/*
 * [TEL2]: Analog Display signalling Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_An_DispEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_An_DispEnum =
#endif
{
   (Data *)"andisp",
   MGT_PKG_AN_DISP
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_An_DispEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _An_Disp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_An_DispEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Analog Display signalling Package
 */

/*
 * [TEL2]: Extended Analog Line Supervision Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Ext_AlgEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Ext_AlgEnum =
#endif
{
   (Data *)"xal",
   MGT_PKG_EXT_ALG
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Ext_AlgEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Ext_Alg",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Ext_AlgEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Extended Analog Line Supervision Package
 */

/*
 * [TEL2]: Automatic Metering Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Aut_MetEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Aut_MetEnum =
#endif
{
   (Data *)"amet",
   MGT_PKG_AUT_MET
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Aut_MetEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Aut_Met",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Aut_MetEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Automatic Metering Package
 */

/*
 * [TEL2]: H.324 Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_H_324Enum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_H_324Enum =
#endif
{
   (Data *)"h324",
   MGT_PKG_H_324
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_H_324EnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _H_324",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_H_324Enum,
   NULLP
};

/*
 * [TEL2]: End of additions for H.324 Package
 */

/*
 * [TEL2]: H.245 Command Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_H_245_ComEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_H_245_ComEnum =
#endif
{
   (Data *)"h245com",
   MGT_PKG_H_245_COM
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_H_245_ComEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _H_245_Com",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_H_245_ComEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for H.245 Command Package
 */

/*
 * [TEL2]: H.245 Indication Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_H_245_IndEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_H_245_IndEnum =
#endif
{
   (Data *)"h245ind",
   MGT_PKG_H_245_IND
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_H_245_IndEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _H_245_Ind",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_H_245_IndEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for H.245 Indication Package
 */

/*
 * [TEL2]: Extended H.245 Command Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_H245_Com_ExtEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_H245_Com_ExtEnum =
#endif
{
   (Data *)"h245comext",
   MGT_PKG_H245_COM_EXT
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_H245_Com_ExtEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _H245_Com_Ext",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_H245_Com_ExtEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Extended H.245 Command Package
 */

/*
 * [TEL2]: Extended H.245 Indication Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_H245_Ind_EXtEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_H245_Ind_EXtEnum =
#endif
{
   (Data *)"h245indext",
   MGT_PKG_H245_IND_EXT
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_H245_Ind_EXtEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _H245_Ind_EXt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_H245_Ind_EXtEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Extended H.245 Indication Package
 */

/*
 * [TEL2]: Quality Alert Ceasing Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Qty_AltEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Qty_AltEnum =
#endif
{
   (Data *)"qac",
   MGT_PKG_QTY_ALT
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Qty_AltEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Qty_Alt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Qty_AltEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Quality Alert Ceasing Package
 */

/*
 * [TEL2]: Extended H.324 Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_H324_ExtEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_H324_ExtEnum =
#endif
{
   (Data *)"h324ext",
   MGT_PKG_H324_EXT
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_H324_ExtEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _H324_Ext",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_H324_ExtEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Extended H.324 Package
 */

/*
 * [TEL2]: Adaptive Jitter Buffer Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Ad_Jit_BuffEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Ad_Jit_BuffEnum =
#endif
{
   (Data *)"ajb",
   MGT_PKG_AD_JIT_BUFF
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Ad_Jit_BuffEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Ad_Jit_Buff",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Ad_Jit_BuffEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Adaptive Jitter Buffer Package
 */

/*
 * [TEL2]: International CAS Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_IcasEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_IcasEnum =
#endif
{
   (Data *)"icas",
   MGT_PKG_ICAS
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_IcasEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Icas",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_IcasEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for International CAS Package
 */

/*
 * [TEL2]: Multi-Frequency Tone Generation Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_MFq_tn_genEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_MFq_tn_genEnum =
#endif
{
   (Data *)"mfg",
   MGT_PKG_MFQ_TN_GEN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_MFq_tn_genEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _MFq_tn_gen",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_MFq_tn_genEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Multi-Frequency Tone Generation Package
 */

/*
 * [TEL2]: Multi-Frequency Tone Detection Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_MFq_tn_detEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_MFq_tn_detEnum =
#endif
{
   (Data *)"mfd",
   MGT_PKG_MFQ_TN_DET
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_MFq_tn_detEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _MFq_tn_det",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_MFq_tn_detEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Multi-Frequency Tone Detection Package
 */

/*
 * [TEL2]: Extended DTMF Detection Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Ext_DtmfEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Ext_DtmfEnum =
#endif
{
   (Data *)"xdd",
   MGT_PKG_EXT_DTMF
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Ext_DtmfEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Ext_Dtmf",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Ext_DtmfEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Extended DTMF Detection Package
 */

/*
 * [TEL2]: Enhanced DTMF Detection Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Enh_DtmfEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Enh_DtmfEnum =
#endif
{
   (Data *)"edd",
   MGT_PKG_ENH_DTMF
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Enh_DtmfEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Enh_Dtmf",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Enh_DtmfEnum,
   NULLP
};

/*
 * [TEL2]: End of additions for Enhanced DTMF Detection Package
 */

/*
 * [TEL3]: MSF UK Call Progess Tones Generator Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Msf_Uk_CgEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Msf_Uk_CgEnum =
#endif
{
   (Data *)"msfukcg",
   MGT_PKG_MSF_UK_CG
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Msf_Uk_CgEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Msf_Uk_Cg",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Msf_Uk_CgEnum,
   NULLP
};

/*
 * [TEL3]: End of additions for MSF UK Call Progess Tones Generator Package
 */

/*
 * [TEL3]: MSF UK Announcement Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Msf_Uk_AnEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Msf_Uk_AnEnum =
#endif
{
   (Data *)"msfukan",
   MGT_PKG_MSF_UK_AN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Msf_Uk_AnEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Msf_Uk_An",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Msf_Uk_AnEnum,
   NULLP
};

/*
 * [TEL3]: End of additions for MSF UK Announcement Package
 */

/*
 * [TEL3]: MSF UK Analogue Line Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Msf_Uk_AlgEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Msf_Uk_AlgEnum =
#endif
{
   (Data *)"msfukal",
   MGT_PKG_MSF_UK_ALG
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Msf_Uk_AlgEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Msf_Uk_Alg",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Msf_Uk_AlgEnum,
   NULLP
};

/*
 * [TEL3]: End of additions for MSF UK Analogue Line Package
 */

/*
 * [TEL3]: MSF UK Automatic Metering Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Msf_Uk_AutometEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Msf_Uk_AutometEnum =
#endif
{
   (Data *)"msfukautomet",
   MGT_PKG_MSF_UK_AUTOMET
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Msf_Uk_AutometEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Msf_Uk_Automet",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Msf_Uk_AutometEnum,
   NULLP
};

/*
 * [TEL3]: End of additions for MSF UK Automatic Metering Package
 */

/* 
 * [TEL3]: Stimulus Lines Analogue Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_Stim_AlEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_Stim_AlEnum =
#endif
{
   (Data *)"stimal",
   MGT_PKG_STIMAL
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_Stim_AlEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _Stim_Al",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4632,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_Stim_AlEnum,
   NULLP
};

/*
 * [TEL3]: End of additions for  Stimulus Lines Analogue Package
 */

/*
 * Enhanced Circuit Switched Data Package
 */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgName_tri_gcsdenEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgName_tri_gcsdenEnum =
#endif
{
   (Data *)"threegcsden",
   MGT_PKG_TRI_GCSDEN
};

PUBLIC CmAbnfElmDef mgMgcoPkgName_tri_gcsdenEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - _tri_gcsden",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 5069,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgName_tri_gcsdenEnum,
   NULLP
};

/*
 * End of additions for Enhanced Circuit Switched Data Package
 */


/* 
 * [TEL]: End of additions from pkg_enum.c 
 */
 
/*************  New Package Enum Definations  ***************************/

PUBLIC CmAbnfElmDef *mgMgcoPkgNameEnum[] =
{
   NULLP,
   /* mg005.105: changed unknown package id from 0 to 255
    *         ASN Annex C uses package id 0
    *         &mgMgcoPkgNameUnknownEnumDef,          */
   &mgMgcoPkgNameGenericEnumDef,                 /* package ID 1 */
   &mgMgcoPkgNameRootEnumDef,                    /* package ID 2 */
   &mgMgcoPkgNameToneGenEnumDef,                 /* package ID 3 */
   &mgMgcoPkgNameToneDetEnumDef,                 /* package ID 4 */
   &mgMgcoPkgNameDtmfGenEnumDef,                 /* package ID 5 */
   &mgMgcoPkgNameDtmfDetEnumDef,                 /* package ID 6 */
   &mgMgcoPkgNameCpGenEnumDef,                   /* package ID 7 */
   &mgMgcoPkgNameCpDetEnumDef,                   /* package ID 8 */
   &mgMgcoPkgNameAnalogEnumDef,                  /* package ID 9 */
   &mgMgcoPkgNameContEnumDef,                    /* package ID 10 */
   &mgMgcoPkgNameNetworkEnumDef,                 /* package ID 11 */
   &mgMgcoPkgNameRtpEnumDef,                     /* package ID 12 */
   &mgMgcoPkgNameTdmcEnumDef,                    /* package ID 13 */

   &mgMgcoPkgNameFaxToneDetEnumDef,              /* package ID 14 */
   &mgMgcoPkgNameTxtCnvrEnumDef,                 /* package ID 15 */
   &mgMgcoPkgNameTxtTelPhoneEnumDef,             /* package ID 16 */
   &mgMgcoPkgNameCallTypDiscrEnumDef,            /* package ID 17 */
   &mgMgcoPkgNameFaxEnumDef,                     /* package ID 18 */
   &mgMgcoPkgNameIpFaxEnumDef,                   /* package ID 19 */
   &mgMgcoPkgNameDisplayEnumDef,                 /* package ID 20 */
   &mgMgcoPkgNameKeyEnumDef,                     /* package ID 21 */
   &mgMgcoPkgNameKeyPadEnumDef,                  /* package ID 22 */
   &mgMgcoPkgNameLabelKeyEnumDef,                /* package ID 23 */
   &mgMgcoPkgNameFuncKeyEnumDef,                 /* package ID 24 */
   &mgMgcoPkgNameIndicatorEnumDef,               /* package ID 25 */
   &mgMgcoPkgNameSoftKeyEnumDef,                 /* package ID 26 */
   &mgMgcoPkgNameAncillaryInputEnumDef,          /* package ID 27 */

   NULLP,                                        /* package ID 28 */

   /*
    * [TEL]: Changed from NULLP
    */
   &mgMgcoPkgNameGenAnncEnumDef,                 /* package ID 29 */
   &mgMgcoPkgName_brr_charEnumDef,               /* package ID 30 */
   &mgMgcoPkgName_bnctEnumDef,                   /* package ID 31 */
   &mgMgcoPkgName_riEnumDef,                     /* package ID 32 */
   &mgMgcoPkgName_gen_brr_conEnumDef,            /* package ID 33 */
   &mgMgcoPkgName_brr_ctl_tnEnumDef,             /* package ID 34 */
   &mgMgcoPkgName_bsc_cal_tnEnumDef,             /* package ID 35 */
   &mgMgcoPkgName_xd_calpg_tngnEnumDef,          /* package ID 36 */  
   &mgMgcoPkgName_bsc_srv_tnEnumDef,             /* package ID 37 */  
   &mgMgcoPkgName_xd_srv_tngnEnumDef,            /* package ID 38 */
   &mgMgcoPkgName_int_tngnEnumDef,               /* package ID 39 */
   &mgMgcoPkgName_bsns_tngnEnumDef,              /* package ID 40 */ 
   &mgMgcoPkgName_CHPEnumDef,                    /* package ID 41 */  
   
   NULLP,                                        /* package ID 42 */
   NULLP,                                        /* package ID 43 */
   
   /*
    * [TEL2]: Changed from NULLP
    */
   &mgMgcoPkgName_H_324EnumDef,                  /* package ID 44 */
   &mgMgcoPkgName_H_245_ComEnumDef,              /* package ID 45 */
   &mgMgcoPkgName_H_245_IndEnumDef,              /* package ID 46 */
   
   /*
    * [TEL]: Changed from NULLP
    */
   &mgMgcoPkgName_tri_gupEnumDef,                /* package ID 47 */
   &mgMgcoPkgName_tri_gcsdEnumDef,               /* package ID 48 */
   &mgMgcoPkgName_tri_gtfoEnumDef,               /* package ID 49 */
   &mgMgcoPkgName_trig_xd_calpg_tngnEnumDef,     /* package ID 50 */

   &mgMgcoPkgNameAdvAuSrvrBaseEnumDef,           /* packate ID 51 */
   &mgMgcoPkgNameAasDigCollectEnumDef,           /* packate ID 52 */
   &mgMgcoPkgNameAasRecodingEnumDef,             /* packate ID 53 */
   &mgMgcoPkgNameAdvAuSrvrSegMngmtEnumDef,       /* packate ID 54 */
   
   /*
    * [TEL2]: Changed from NULLP
    */
   &mgMgcoPkgName_Qty_AltEnumDef,                /* package ID 55 */
   &mgMgcoPkgName_Conf_TnEnumDef,                /* package ID 56 */
   &mgMgcoPkgName_TestEnumDef,                   /* package ID 57 */
   &mgMgcoPkgName_Carr_TnEnumDef,                /* package ID 58 */
   &mgMgcoPkgName_En_AlertEnumDef,               /* package ID 59 */
   &mgMgcoPkgName_An_DispEnumDef,                /* package ID 60 */
   &mgMgcoPkgName_MFq_tn_genEnumDef,             /* package ID 61 */
   &mgMgcoPkgName_MFq_tn_detEnumDef,             /* package ID 62 */

   /*
    * [TEL]: Changed from NULLP
    */
   &mgMgcoPkgName_bcasEnumDef,                   /* package ID 63 */
   &mgMgcoPkgName_rbsEnumDef,                    /* package ID 64 */
   &mgMgcoPkgName_osesEnumDef,                   /* package ID 65 */
   &mgMgcoPkgName_osextEnumDef,                  /* package ID 66 */
   
   /*
    * [TEL]: Changed from NULLP
    */
   &mgMgcoPkgName_Ext_AlgEnumDef,                /* package ID 67 */
   &mgMgcoPkgName_Aut_MetEnumDef,                /* package ID 68 */
   &mgMgcoPkgName_inacttimerEnumDef,             /* package ID 69 */
   &mgMgcoPkgName_tri_gmlcEnumDef,               /* package ID 70 */

   NULLP, NULLP, NULLP,                          /* package IDs 71 - 73 */
   NULLP,                                        /* package ID 74 */

   /*
    * [TEL]: Moved from location 37-41 
    */
   &mgMgcoPkgNameNasEnumDef,                     /* package ID 75 */   
   &mgMgcoPkgNameNasInEnumDef,                   /* package ID 76 */
   &mgMgcoPkgNameNasOutEnumDef,                  /* package ID 77 */
   &mgMgcoPkgNameNasCtlEnumDef,                  /* package ID 78 */
   &mgMgcoPkgNameNasRootEnumDef,                 /* package ID 79 */
 
   /*
    * [TEL2]: Changed from NULLP
    */
   &mgMgcoPkgName_ProfEnumDef,                    /* package ID 80 */
 
   /*
    * [TEL2]: Changed from NULLP
    */
   &mgMgcoPkgName_OcpEnumDef,                     /* package ID 81 */
   &mgMgcoPkgName_Ext_DtmfEnumDef,                /* package ID 82 */

   /*
    * [TEL]: Changed from NULLP
    */
   &mgMgcoPkgName_qt_tm_ltcEnumDef,               /* pacakge ID 83 */
   &mgMgcoPkgName_lp_bk_ltrEnumDef,               /* package ID 84 */ 
   &mgMgcoPkgName_itu_lt_404EnumDef,              /* package ID 85 */
   &mgMgcoPkgName_itu_lt_816EnumDef,              /* package ID 86 */
   &mgMgcoPkgName_itu_lt_1020EnumDef,             /* package ID 87 */
   &mgMgcoPkgName_itu_lt_distEnumDef,             /* package ID 88 */
   &mgMgcoPkgName_itu_lt_dsecEnumDef,             /* package ID 89 */
   &mgMgcoPkgName_itu_lt_2804EnumDef,             /* package ID 90 */ 
   &mgMgcoPkgName_itu_lt_nttEnumDef,              /* package ID 91 */
   &mgMgcoPkgName_itu_lt_dprtEnumDef,             /* package ID 92 */
   &mgMgcoPkgName_itu_lt_atme2EnumDef,            /* package ID 93 */
   &mgMgcoPkgName_ansi_lt_1004EnumDef,            /* package ID 94 */ 
   &mgMgcoPkgName_ansi_lt_trEnumDef,              /* package ID 95 */
   &mgMgcoPkgName_ansi_lt_2225EnumDef,            /* package ID 96 */
   &mgMgcoPkgName_ansi_lt_dtsEnumDef,             /* package ID 97 */  
   &mgMgcoPkgName_ansi_in_ltrEnumDef,             /* package ID 98 */ 
   
   /* [TEL2]: Changed from NULLP */
   &mgMgcoPkgName_H324_ExtEnumDef,                /* package ID 99 */
   &mgMgcoPkgName_H245_Com_ExtEnumDef,            /* package ID 100 */
   &mgMgcoPkgName_H245_Ind_EXtEnumDef,            /* package ID 101 */
   &mgMgcoPkgName_Enh_DtmfEnumDef,                /* package ID 102 */

   NULLP,                                         /* package ID 103 */

   /* [TEL]: Changed from NULLP */
   &mgMgcoPkgName_tri_gctmEnumDef,                /* package ID 104 */
   NULLP,                                         /* package ID 105 */

   /* [TEL2]: Changed from NULLP */
   &mgMgcoPkgName_Sem_PerEnumDef,                 /* package ID 106 */

   /* [TEL2]: Changed from NULLP */
   &mgMgcoPkgName_Sh_RiskEnumDef,                 /* package ID 107 */

   NULLP,                                         /* package ID 108 */

   &mgMgcoPkgName_bcasaddrEnumDef,                /* package ID 109 */

   /*
    * [TEL2]: Changed from NULLP
    */
   &mgMgcoPkgName_Flr_CtlEnumDef,                 /* package ID 110 */
   &mgMgcoPkgName_Ind_ViewEnumDef,                /* package ID 111 */
   &mgMgcoPkgName_Vol_CtlEnumDef,                 /* package ID 112 */

   &mgMgcoPkgName_tri_giptraEnumDef,              /* package ID 113 */

   /*
    * [TEL2]: Changed from NULLP
    */
   &mgMgcoPkgName_Vol_DetEnumDef,                 /* package ID 114 */
   &mgMgcoPkgName_Vol_Lev_MixEnumDef,             /* package ID 115 */
   &mgMgcoPkgName_Mix_Vol_CtlEnumDef,             /* package ID 116 */
   &mgMgcoPkgName_Voi_Act_Vid_SwEnumDef,          /* package ID 117 */
   &mgMgcoPkgName_Lec_Vid_ModEnumDef,             /* package ID 118 */
   &mgMgcoPkgName_Con_Vid_SrcEnumDef,             /* package ID 119 */
   &mgMgcoPkgName_Vid_WinEnumDef,                 /* package ID 120 */
   &mgMgcoPkgName_Til_WinEnumDef,                 /* package ID 121 */
   &mgMgcoPkgName_Ad_Jit_BuffEnumDef,             /* package ID 122 */
   &mgMgcoPkgName_IcasEnumDef,                    /* package ID 123 */

   /*
    * [TEL2]: Changed from NULLP
    */
   &mgMgcoPkgName_Cas_BlkEnumDef,                 /* package ID 124 */

   NULLP, NULLP, NULLP, NULLP, NULLP,             /* package IDs 125 -129 */

   /*
    * Changed from NULLP
    */
   &mgMgcoPkgName_tri_gcsdenEnumDef,              /* package ID 130 */
   
   NULLP,                                         /* package ID 131 */
   
   /*
    * [TEL]: Changed from NULLP
    */
   &mgMgcoPkgName_trig_flex_tnEnumDef,            /* packate ID 132 */

   /* [TEL]: Moved from location 36 */
   &mgMgcoPkgNameAllEnumDef,                      /* package ID 133 */

   /*
    * [TEL3]: Changed from NULLP
    */
   &mgMgcoPkgName_Msf_Uk_CgEnumDef,               /* packate ID 134 */
   &mgMgcoPkgName_Msf_Uk_AnEnumDef,               /* packate ID 135 */
   &mgMgcoPkgName_Msf_Uk_AlgEnumDef,              /* packate ID 136 */
   &mgMgcoPkgName_Msf_Uk_AutometEnumDef,          /* packate ID 137 */

   NULLP, NULLP, NULLP, NULLP, NULLP,             /* package IDs 138 - 146 */
   NULLP, NULLP, NULLP, NULLP,

   &mgMgcoPkgName_Stim_AlEnumDef,                 /* packate ID 147 */ 

   NULLP, NULLP, NULLP,                         /* package ID 148 - 150 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 151 - 160 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 161 - 170 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 171 - 180 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 181 - 190 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 191 - 200 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 201 - 210 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 211 - 220 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 221 - 230 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 231 - 124 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 241 - 250 */
   NULLP, NULLP,                          /* package ID 251 - 253 */
   &mgMgcoPkgNameUnknownEnumDef,
};

PUBLIC CmAbnfElmDef *mgMgcoPkgChcEnum[] =
{
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 0 */

#ifdef GCP_PKG_MGCO_GENERIC
   NULLP, 
#else /* !GCP_PKG_MGCO_GENERIC */                /* package ID 1 */
   &mgMgcoPkgNameUnknownEnumDef,
#endif /* GCP_PKG_MGCO_GENERIC */

#ifdef GCP_PKG_MGCO_ROOT
   NULLP, 
#else /* !GCP_PKG_MGCO_ROOT */                   /* package ID 2 */
   &mgMgcoPkgNameUnknownEnumDef,
#endif /* GCP_PKG_MGCO_ROOT */

#ifdef GCP_PKG_MGCO_TONEGEN
   NULLP, 
#else /* !GCP_PKG_MGCO_TONEGEN */                /* package ID 3 */
   &mgMgcoPkgNameUnknownEnumDef,
#endif /* GCP_PKG_MGCO_TONEGEN */

#ifdef GCP_PKG_MGCO_TONEDET
   NULLP, 
#else /* !GCP_PKG_MGCO_TONEDET */                /* package ID 4 */
   &mgMgcoPkgNameUnknownEnumDef,
#endif /* GCP_PKG_MGCO_TONEDET */

#ifdef GCP_PKG_MGCO_DTMFGEN
   NULLP, 
#else /* !GCP_PKG_MGCO_DTMFGEN */                /* package ID 5 */
   &mgMgcoPkgNameUnknownEnumDef,
#endif /* GCP_PKG_MGCO_DTMFGEN */

#ifdef GCP_PKG_MGCO_DTMFDET
   NULLP, 
#else /* !GCP_PKG_MGCO_DTMFDET */                /* package ID 6 */
   &mgMgcoPkgNameUnknownEnumDef,
#endif /* GCP_PKG_MGCO_DTMFDET */

#ifdef GCP_PKG_MGCO_CPGEN
   NULLP, 
#else /* !GCP_PKG_MGCO_CPGEN */                  /* package ID 7 */
   &mgMgcoPkgNameUnknownEnumDef,
#endif /* GCP_PKG_MGCO_CPGEN */

#ifdef GCP_PKG_MGCO_CPDET
   NULLP, 
#else /* !GCP_PKG_MGCO_CPDET */                  /* package ID 8 */
   &mgMgcoPkgNameUnknownEnumDef,
#endif /* GCP_PKG_MGCO_CPDET */

#ifdef GCP_PKG_MGCO_ANALOG
   NULLP, 
#else /* !GCP_PKG_MGCO_ANALOG */                 /* package ID 9 */
   &mgMgcoPkgNameUnknownEnumDef,
#endif /* GCP_PKG_MGCO_ANALOG */

#ifdef GCP_PKG_MGCO_CONT
   NULLP, 
#else /* !GCP_PKG_MGCO_CONT */                   /* package ID 10 */
   &mgMgcoPkgNameUnknownEnumDef,
#endif /* GCP_PKG_MGCO_CONT */

#ifdef GCP_PKG_MGCO_NETWORK
   NULLP, 
#else /* !GCP_PKG_MGCO_NETWORK */                /* package ID 11 */
   &mgMgcoPkgNameUnknownEnumDef,
#endif /* GCP_PKG_MGCO_NETWORK */

#ifdef GCP_PKG_MGCO_RTP
   NULLP, 
#else /* !GCP_PKG_MGCO_RTP */                    /* package ID 12 */
   &mgMgcoPkgNameUnknownEnumDef,
#endif /* GCP_PKG_MGCO_RTP */

#ifdef GCP_PKG_MGCO_TDMC
   NULLP, 
#else /* !GCP_PKG_MGCO_TDMC */                   /* package ID 13 */
   &mgMgcoPkgNameUnknownEnumDef,
#endif /* GCP_PKG_MGCO_TDMC */

#ifdef GCP_PKG_MGCO_FAXTONEDET                   /* package ID 14 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_TXTCNVR                      /* package ID 15 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_TXTTELPHONE                  /* package ID 16 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_CALLTYPDISCR                 /* package ID 17 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_FAX                          /* package ID 18 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_IPFAX                       /* package ID 19 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_DISPLAY                     /* package ID 20 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_KEY                         /* package ID 21 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_KEYPAD                      /* package ID 22 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_LABELKEY                    /* package ID 23 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_FUNCKEY                     /* package ID 24 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_INDICATOR                   /* package ID 25 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_SOFTKEY                     /* package ID 26 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_ANCILLARYINPUT              /* package ID 27 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

/* ------------------- package IDs 28-29 --------------------- */
   &mgMgcoPkgNameUnknownEnumDef,                /* package ID 28 */

#ifdef GCP_PKG_MGCO_GENANNC                     /* package ID 29*/
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif


   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_BRR_CHAR                    /* package ID 30 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_BNCT
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,                /* package ID 31 */
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_RI
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,                /* package ID 32 */
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_GEN_BRR_CON
   NULLP,                                       /* package ID 33 */
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_BRR_CTL_TN                  /* package ID 34 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_BSC_CAL_TN                  /* package ID 35 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_XD_CALPG_TNGN               /* package ID 36 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif               
 
   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_BSC_SRV_TN                  /* package ID 37 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif
 
   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_XD_SRV_TNGN               /* package ID 38 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif
 
   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_INT_TNGN                   /* package ID 39 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif
 
   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_BSNS_TNGN                 /* package ID 40 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif
 
   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_CHP
   NULLP,                                        /* package ID 41 */
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   &mgMgcoPkgNameUnknownEnumDef,                   /* package ID 42 */
   &mgMgcoPkgNameUnknownEnumDef,                   /* package ID 43 */
 
   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_H_324
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,                   /* package ID 44 */
#endif
 
#ifdef GCP_PKG_MGCO_H_245_COM
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,                   /* package ID 45 */
#endif
 
#ifdef GCP_PKG_MGCO_H_245_IND
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,                   /* package ID 46 */
#endif
 
   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_TRI_GUP
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,                   /* package ID 47 */
#endif
 
   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_TRI_GCSD
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,                   /* package ID 48 */
#endif
 
   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_TRI_GTFO                       /* package ID 49 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_TRIG_XD_CALPG_TNGN            /* package ID 50 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_ADVAUSRVRBASE                 /* package ID 51 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_AASDIGCOLLECT                 /* package ID 52 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_AASRECODING                   /* package ID 53 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT             /* package ID 54 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_QTY_ALT                       /* package ID 55 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_CONF_TN                       /* package ID 56 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_TEST                          /* package ID 57 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_CARR_TN                       /* package ID 58 */
   NULLP, 
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_EN_ALERT                      /* package ID 59 */ 
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_AN_DISP                       /* package ID 60 */ 
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_MFQ_TN_GEN                    /* package ID 61 */ 
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_MFQ_TN_DET                    /* package ID 62 */ 
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_BCAS                        /* package ID 63 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_RBS                         /* package ID 64 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_OSES                        /* package ID 65 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif 

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_OSEXT                       /* package ID 66 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_EXT_ALG
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 67 */
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_AUT_MET
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 68 */
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_INACTTIMER
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 69 */
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_TRI_GMLC                     /* package ID 70 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   &mgMgcoPkgNameUnknownEnumDef,                /* package ID 71 */
   &mgMgcoPkgNameUnknownEnumDef,                /* package ID 72 */
   &mgMgcoPkgNameUnknownEnumDef,                /* package ID 73 */
   &mgMgcoPkgNameUnknownEnumDef,                /* package ID 74 */ 

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_NAS_SUPPORT                 /* package IDs 75-79 */ 
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   NULLP,
#else /* !GCP_PKG_MGCO_NAS_SUPPORT */
   &mgMgcoPkgNameUnknownEnumDef,
   &mgMgcoPkgNameUnknownEnumDef,
   &mgMgcoPkgNameUnknownEnumDef,
   &mgMgcoPkgNameUnknownEnumDef,
   &mgMgcoPkgNameUnknownEnumDef,
#endif /* GCP_PKG_MGCO_NAS_SUPPORT */

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_PROF                        /* package ID 80 */ 
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_OCP                        /* package ID 81 */ 
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_EXT_DTMF                   /* package ID 82 */ 
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_QT_TM_LTC                  /* package ID 83 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_LP_BK_LTR
   NULLP,                                       /* package ID 84 */
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_ITU_LT_404                  /* package ID 85 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_ITU_LT_816                  /* package ID 86 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_ITU_LT_1020                 /* package ID 87 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_ITU_LT_DIST                  /* package ID 88 */ 
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_ITU_LT_DSEC                   /* package ID 89 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_ITU_LT_2804                   /* package ID 90 */ 
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_ITU_LT_NTT                  /* package ID 91 */ 
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_ITU_LT_DPRT                /* package ID 92 */  
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_ITU_LT_ATME2               /* package ID 93 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_1004               /* package ID 94 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_TR                 /* package ID 95 */ 
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_2225               /* package ID 96 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_DTS                /* package ID 97 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_ANSI_IN_LTR                /* package ID 98 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_H324_EXT                    /* package ID 99 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_H245_COM_EXT                /* package ID 100 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_H245_IND_EXT                /* package ID 101 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

#ifdef GCP_PKG_MGCO_ENH_DTMF                    /* package ID 102 */ 
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   &mgMgcoPkgNameUnknownEnumDef,                /* package ID 103 */

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_TRI_GCTM                    /* package ID 104 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   &mgMgcoPkgNameUnknownEnumDef,                /* package ID 105 */

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_SEM_PER                     /* package ID 106 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_SH_RISK                     /* package ID 107 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   &mgMgcoPkgNameUnknownEnumDef,                /* package ID 108 */

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_BCASADDR
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 109 */
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_FLR_CTL                     /* package ID 110 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_IND_VIEW                    /* package ID 111 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_VOL_CTL                     /* package ID 112 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif
  
   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_TRI_GIPTRA                 /* package ID 113 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif
   
   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_VOL_DET                     /* package ID 114 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif
  
   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_VOL_LEV_MIX                  /* package ID 115 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_MIX_VOL_CTL                  /* package ID 116 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif
  
   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_VOI_ACT_VID_SW               /* package ID 117 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif
  
   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_LEC_VID_MOD                  /* package ID 118 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif
  
   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_CON_VID_SRC                  /* package ID 119 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif
  
   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_VID_WIN                      /* package ID 120 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif
  
   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_TIL_WIN                      /* package ID 121 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_AD_JIT_BUFF                  /* package ID 122 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_ICAS                         /* package ID 123 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL2]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_CAS_BLK                      /* package ID 124 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 125 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 126 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 127 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 128 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 129 */

   /*
    * Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_TRI_GCSDEN                   /* package ID 130 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif
 
   
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 131 */

   /*
    * [TEL]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_TRIG_FLEX_TN                 /* package ID 132 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /* [TEL]: Moved from location 36 */
   NULLP,                                        /* package ID 133 */

   /*
    * [TEL3]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_MSF_UK_CG                    /* package ID 134 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL3]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_MSF_UK_AN                    /* package ID 135 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL3]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_MSF_UK_ALG                   /* package ID 136 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   /*
    * [TEL3]: Changed from &mgMgcoPkgNameUnknownEnumDef
    */
#ifdef GCP_PKG_MGCO_MSF_UK_AUTOMET               /* package ID 137 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif

   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 138 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 139 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 140 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 141 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 142 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 143 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 144 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 145 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 146 */

#ifdef GCP_PKG_MGCO_STIM_AL                      /* package ID 147 */
   NULLP,
#else
   &mgMgcoPkgNameUnknownEnumDef,
#endif
   
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 146 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 147 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 148 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 149 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 150 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 151 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 152 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 153 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 154 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 155 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 156 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 157 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 158 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 159 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 160 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 161 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 162 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 163 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 164 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 165 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 166 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 167 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 168 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 169 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 170 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 171 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 172 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 173 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 174 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 175 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 176 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 177 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 178 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 179 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 180 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 181 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 182 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 183 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 184 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 185 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 186 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 187 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 188 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 189 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 190 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 191 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 192 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 193 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 194 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 195 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 196 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 197 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 198 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 199 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 200 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 201 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 202 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 203 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 204 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 205 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 206 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 207 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 208 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 209 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 210 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 211 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 212 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 213 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 214 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 215 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 216 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 217 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 218 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 219 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 220 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 221 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 222 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 223 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 224 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 225 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 226 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 227 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 228 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 229 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 230 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 231 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 232 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 233 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 234 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 235 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 236 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 237 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 238 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 239 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 240 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 241 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 242 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 243 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 244 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 245 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 246 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 247 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 248 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 249 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 250 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 246 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 251 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 252 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 253 */
   &mgMgcoPkgNameUnknownEnumDef,                 /* package ID 254 */
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC U16 mgMgcoPkgChcIdx[] =
#else
PUBLIC U8 mgMgcoPkgChcIdx[] =
#endif
{
   0,                                           /* package ID 0 */

#ifdef GCP_PKG_MGCO_GENERIC
   1, 
#else /* !GCP_PKG_MGCO_GENERIC */               /* package ID 1 */
   0,
#endif /* GCP_PKG_MGCO_GENERIC */

#ifdef GCP_PKG_MGCO_ROOT
   1, 
#else /* !GCP_PKG_MGCO_ROOT */                  /* package ID 2 */
   0,
#endif /* GCP_PKG_MGCO_ROOT */

#ifdef GCP_PKG_MGCO_TONEGEN
   1, 
#else /* !GCP_PKG_MGCO_TONEGEN */               /* package ID 3 */
   0,
#endif /* GCP_PKG_MGCO_TONEGEN */

#ifdef GCP_PKG_MGCO_TONEDET
   1, 
#else /* !GCP_PKG_MGCO_TONEDET */               /* package ID 4 */
   0,
#endif /* GCP_PKG_MGCO_TONEDET */

#ifdef GCP_PKG_MGCO_DTMFGEN
   1, 
#else /* !GCP_PKG_MGCO_DTMFGEN */               /* package ID 5 */
   0,
#endif /* GCP_PKG_MGCO_DTMFGEN */

#ifdef GCP_PKG_MGCO_DTMFDET
   1, 
#else /* !GCP_PKG_MGCO_DTMFDET */               /* package ID 6 */
   0,
#endif /* GCP_PKG_MGCO_DTMFDET */

#ifdef GCP_PKG_MGCO_CPGEN
   1, 
#else /* !GCP_PKG_MGCO_CPGEN */                 /* package ID 7 */
   0,
#endif /* GCP_PKG_MGCO_CPGEN */

#ifdef GCP_PKG_MGCO_CPDET
   1, 
#else /* !GCP_PKG_MGCO_CPDET */                 /* package ID 8 */
   0,
#endif /* GCP_PKG_MGCO_CPDET */

#ifdef GCP_PKG_MGCO_ANALOG
   1, 
#else /* !GCP_PKG_MGCO_ANALOG */                /* package ID 9 */
   0,
#endif /* GCP_PKG_MGCO_ANALOG */

#ifdef GCP_PKG_MGCO_CONT
   1, 
#else /* !GCP_PKG_MGCO_CONT */                  /* package ID 10 */
   0,
#endif /* GCP_PKG_MGCO_CONT */

#ifdef GCP_PKG_MGCO_NETWORK
   1, 
#else /* !GCP_PKG_MGCO_NETWORK */               /* package ID 11 */
   0,
#endif /* GCP_PKG_MGCO_NETWORK */

#ifdef GCP_PKG_MGCO_RTP
   1, 
#else /* !GCP_PKG_MGCO_RTP */                   /* package ID 12 */
   0,
#endif /* GCP_PKG_MGCO_RTP */

#ifdef GCP_PKG_MGCO_TDMC
   1, 
#else /* !GCP_PKG_MGCO_TDMC */                  /* package ID 13 */
   0,
#endif /* GCP_PKG_MGCO_TDMC */

#ifdef GCP_PKG_MGCO_FAXTONEDET                  /* package ID 14 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_TXTCNVR                     /* package ID 15 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_TXTTELPHONE                 /* package ID 16 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_CALLTYPDISCR                /* package ID 17 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_FAX                         /* package ID 18 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_IPFAX                       /* package ID 19 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_DISPLAY                     /* package ID 20 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_KEY                         /* package ID 21 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_KEYPAD                      /* package ID 22 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_LABELKEY                    /* package ID 23 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_FUNCKEY                     /* package ID 24 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_INDICATOR                   /* package ID 25 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_SOFTKEY                     /* package ID 26 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_ANCILLARYINPUT              /* package ID 27 */
   1,
#else
   0,
#endif

   0,                        /* ------ package IDs 28 ------ */

#ifdef GCP_PKG_MGCO_GENANNC                     /* package ID 29 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_BRR_CHAR                    /* package ID 30 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_BNCT                        /* package ID 31 */
   1,                                           
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_RI                          /* package ID 32 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_GEN_BRR_CON
   1,                                            /* package ID 33 */
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_BRR_CTL_TN                  /* package ID 34 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_BSC_CAL_TN                  /* package ID 35 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_XD_CALPG_TNGN               /* Package Id 36 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_BSC_SRV_TN                  /* Package Id 37 */
   1,
#else
   0,
#endif 

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_XD_SRV_TNGN                 /* Package Id 38 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_INT_TNGN                    /* package Id 39 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_BSNS_TNGN                   /* package Id 40 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_CHP                         /* package Id 41 */
   1,
#else
   0,
#endif

   /* ------ package IDs 42-43 ------ */ 

   0,0,

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_H_324                       /* package ID 44 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_H_245_COM                   /* package ID 45 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_H_245_IND                   /* package ID 46 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_TRI_GUP                     /* package ID 47 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_TRI_GCSD                    /* package ID 48 */
   1,                                           
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_TRI_GTFO                    /* package ID 49 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_TRIG_XD_CALPG_TNGN          /* package ID 50 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_ADVAUSRVRBASE                /* package ID 51 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_AASDIGCOLLECT                /* package ID 52 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_AASRECODING                  /* package ID 53 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT            /* package ID 54 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_QTY_ALT                      /* package ID 55 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_CONF_TN                      /* package ID 56 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_TEST                          /* package ID 57 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_CARR_TN                       /* package ID 58 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_EN_ALERT                     /* package ID 59 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_AN_DISP                     /* package ID 60 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_MFQ_TN_GEN                   /* package ID 61 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_MFQ_TN_DET                   /* package ID 62 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_BCAS                        /* package ID 63*/
   1,
#else                                            
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_RBS                         /*package ID 64*/
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_OSES                        /* package ID 65 */
   1,
#else
   0,
#endif  

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_OSEXT                        /* package ID 66 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_EXT_ALG                      /* package ID 67 */
   1,
#else
   0,
#endif


   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_AUT_MET                      /* package ID 68 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_INACTTIMER                  /* package ID 69 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_TRI_GMLC                    /* package ID 70 */
   1,
#else
   0,
#endif
 
   0, 0, 0,                                      /* package Ids  71 - 73 */
   0,                                            /* package Id 74 */

   /*
    * [TEL]: Moved from location 37-41 
    */
#ifdef GCP_PKG_MGCO_NAS_SUPPORT                  /* package IDs 75 - 79 */ 
   1, 1, 1, 1, 1,
#else /* !GCP_PKG_MGCO_NAS_SUPPORT */
   0, 0, 0, 0, 0,
#endif /* GCP_PKG_MGCO_NAS_SUPPORT */
 
   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_PROF                       /* package ID 80 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_OCP                        /* package ID 81 */
   1,
#else
   0,
#endif
   
#ifdef GCP_PKG_MGCO_EXT_DTMF                   /* package ID 82 */
   1,
#else
   0,
#endif
  
   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_QT_TM_LTC                   /* package ID 83 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_LP_BK_LTR                   /* package ID 84 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_ITU_LT_404                 /* package ID 85 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_ITU_LT_816                  /* package ID 86 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_ITU_LT_1020                 /* package ID 87 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_ITU_LT_DIST                 /* package ID 88 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_ITU_LT_DSEC                 /* package ID 89 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_ITU_LT_2804                 /* package ID 90 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_ITU_LT_NTT                  /* package ID 91 */ 
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_ITU_LT_DPRT                 /* package ID 92 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_ITU_LT_ATME2                /* package ID 93 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_1004                /* package ID 94 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_TR                  /* package ID 95 */ 
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_2225                /* package ID 96 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_DTS                 /* package ID 97 */ 
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_ANSI_IN_LTR                 /* package ID 98 */ 
   1,
#else
   0,
#endif
 
   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_H324_EXT                    /* package ID 99 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_H245_COM_EXT                /* package ID 100 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_H245_IND_EXT                /* package ID 101 */
   1,
#else
   0,
#endif

#ifdef GCP_PKG_MGCO_ENH_DTMF                    /* package ID 102 */
   1,
#else
   0,
#endif
  
   0,                                           /* package ID 103 */

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_TRI_GCTM                    /* package ID 104 */ 
   1,
#else
   0,
#endif

   0,                                           /* package ID 105 */ 

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_SEM_PER                     /* package ID 106 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_SH_RISK                     /* package ID 107 */
   1,
#else
   0,
#endif

   0,                                           /* package ID 108 */

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_BCASADDR                    /* package ID 109 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_FLR_CTL                     /* package ID 110 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_IND_VIEW                    /* package ID 111 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_VOL_CTL                     /* package ID 112 */
   1,
#else
   0,
#endif

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_TRI_GIPTRA                 /* package ID 113 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_VOL_DET                    /* package ID 114 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_VOL_LEV_MIX                 /* package ID 115 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_MIX_VOL_CTL                 /* package ID 116 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_VOI_ACT_VID_SW              /* package ID 117 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_LEC_VID_MOD                 /* package ID 118 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_CON_VID_SRC                 /* package ID 119 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_VID_WIN                     /* package ID 120 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_TIL_WIN                     /* package ID 121 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_AD_JIT_BUFF                 /* package ID 122 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_ICAS                        /* package ID 123 */
   1,
#else
   0,
#endif

   /*
    * [TEL2]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_CAS_BLK                     /* package ID 124 */
   1,
#else
   0,
#endif

   0, 0, 0, 0, 0,                               /* package IDs 125 - 129 */

   /*
    * Changed from 0
    */
#ifdef GCP_PKG_MGCO_TRI_GCSDEN                  /* package ID 130 */
   1,
#else
   0,
#endif
    
   0,                                           /* package ID 131 */

   /*
    * [TEL]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_TRIG_FLEX_TN                /* package ID 132 */
   1,
#else
   0,
#endif

   /* [TEL]: Moved from location 36 */
   1,                                           /* package ID 133 */

   /*
    * [TEL3]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_MSF_UK_CG                   /* package ID 134 */
   1,
#else
   0,
#endif

   /*
    * [TEL3]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_MSF_UK_AN                   /* package ID 135 */
   1,
#else
   0,
#endif

   /*
    * [TEL3]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_MSF_UK_ALG                  /* package ID 136 */
   1,
#else
   0,
#endif

   /*
    * [TEL3]: Changed from 0
    */
#ifdef GCP_PKG_MGCO_MSF_UK_AUTOMET              /* package ID 137 */
   1,
#else
   0,
#endif

   0, 0, 0, 0, 0, 0, 0, 0, 0,                   /* package IDs 138 - 146 */

#ifdef GCP_PKG_MGCO_STIM_AL                     /* package ID 147 */ 
   1,
#else
   0,
#endif
   0,0,0,                                       /* package ID 148 - 150 */
   0,0,0,0,0,0,0,0,0,0,                         /* package ID 151 - 160 */
   0,0,0,0,0,0,0,0,0,0,                         /* package ID 161 - 170 */
   0,0,0,0,0,0,0,0,0,0,                         /* package ID 171 - 180 */
   0,0,0,0,0,0,0,0,0,0,                         /* package ID 181 - 190 */
   0,0,0,0,0,0,0,0,0,0,                         /* package ID 191 - 200 */
   0,0,0,0,0,0,0,0,0,0,                         /* package ID 201 - 210 */
   0,0,0,0,0,0,0,0,0,0,                         /* package ID 211 - 220 */
   0,0,0,0,0,0,0,0,0,0,                         /* package ID 221 - 230 */
   0,0,0,0,0,0,0,0,0,0,                         /* package ID 231 - 240 */
   0,0,0,0,0,0,0,0,0,0,                         /* package ID 241 - 250 */
   0,0,0,0,                                     /* package ID 251 - 254 */
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoPropParmKnownPkgDefChcElmnts[] =
{
   NULLP,
   /* mg005.105: changed unknown package id from 0 to 255
    *         ASN Annex C uses package id 0
    *         &mgMgcoPropParmUnknownPkgDef,          */
   NULLP, /* !mgMgcoPropParmGenericDef - no properties def for generic pkg */
#ifdef GCP_PKG_MGCO_ROOT
   &mgMgcoPropParmRootDef,
#else /* !GCP_PKG_MGCO_ROOT */
   NULLP,
#endif /* GCP_PKG_MGCO_ROOT */
   NULLP, /* !mgMgcoPropParmToneGenDef - no properties def for tonegen pkg */
   NULLP, /* !mgMgcoPropParmToneDetDef - no properties def for tonedet pkg */
   NULLP, /* !mgMgcoPropParmDtmfGenDef - no properties def for dtmfgen pkg */
   NULLP, /* !mgMgcoPropParmDtmfDetDef - no properties def for dtmfdet pkg */
   NULLP, /* !mgMgcoPropParmCpGenDef - no properties def for cpgen  pkg */
   NULLP, /* !mgMgcoPropParmCpDetDef - no properties def for cpdet pkg */
   NULLP, /* !mgMgcoPropParmAnalogDef - no properties def for analog pkg */
   NULLP, /* !mgMgcoPropParmContDef - no properties def for cont pkg */
#ifdef GCP_PKG_MGCO_NETWORK
   &mgMgcoPropParmNetworkDef,
#else /* !GCP_PKG_MGCO_NETWORK */
   NULLP,
#endif /* GCP_PKG_MGCO_NETWORK */
#ifdef GCP_PKG_MGCO_RTP
   &mgMgcoPropParmNetworkDef,
#else /* !GCP_PKG_MGCO_RTP */
   NULLP,
#endif /* GCP_PKG_MGCO_RTP */
#ifdef GCP_PKG_MGCO_TDMC
   &mgMgcoPropParmTdmcDef,
#else /* !GCP_PKG_MGCO_TDMC */
   NULLP,
#endif /* GCP_PKG_MGCO_TDMC */



   NULLP,                                        /* package ID 14 */


#ifdef GCP_PKG_MGCO_TXTCNVR                      /* package ID 15 */
   &mgMgcoPropParmTxtCnvrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTTELPHONE                  /* package ID 16 */
   &mgMgcoPropParmTxtTelPhoneDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_CALLTYPDISCR                 /* package ID 17 */
   &mgMgcoPropParmCallTypDiscrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FAX                          /* package ID 18 */
   &mgMgcoPropParmFaxDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_IPFAX                        /* package ID 19 */
   &mgMgcoPropParmIpFaxDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_DISPLAY                      /* package ID 20 */
   &mgMgcoPropParmDisplayDef,
#else
   NULLP,
#endif

   NULLP, NULLP,                                 /* package IDs 21-22 */

#ifdef GCP_PKG_MGCO_LABELKEY                     /* package ID 23 */
   &mgMgcoPropParmLabelKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FUNCKEY                      /* package ID 24 */
   &mgMgcoPropParmFuncKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_INDICATOR                    /* package ID 25 */
   &mgMgcoPropParmIndicatorDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_SOFTKEY                      /* package ID 26 */
   &mgMgcoPropParmSoftKeyDef,
#else
   NULLP,
#endif

   /* package IDs 27-29 */
   NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BRR_CHAR                     /* package ID 30 */
   &mgMgcoPropParm_brr_charDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BNCT                         /* package ID 31 */
   &mgMgcoPropParm_bnctDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_RI                           /* package ID 32 */
   &mgMgcoPropParm_riDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package IDs 33 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BRR_CTL_TN                   /* package ID 34 */
   &mgMgcoPropParm_brr_ctl_tnDef,
#else
   NULLP,
#endif
 
   NULLP,                                        /* package ID 35 */
   NULLP,                                        /* package ID 36 */

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package ID 37 - 41 */
   
   NULLP, NULLP,                                 /* package IDs  42-43 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_H_324
   &mgMgcoPropParm_H_324Def,
#else                                            /* package ID 44 */
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_H_245_COM
   &mgMgcoPropParm_H_245_ComDef,
#else                                            /* package ID 45 */
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_H_245_IND
   &mgMgcoPropParm_H_245_IndDef,
#else                                            /* package ID 46 */
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GUP
   &mgMgcoPropParm_tri_gupDef,
#else                                            /* package ID 47 */
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCSD                     /* package ID 48 */
   &mgMgcoPropParm_tri_gcsdDef,
#else
   NULLP,
#endif                                         

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GTFO                     /* package ID 49 */
   &mgMgcoPropParm_tri_gtfoDef,
#else
   NULLP,
#endif

   /* package IDs 50 - 52 */   
   NULLP, NULLP, NULLP,

#ifdef GCP_PKG_MGCO_AASRECODING                  /* package ID 53 */
   &mgMgcoPropParmAasRecodingDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT            /* package ID 54 */
   &mgMgcoPropParmAdvAuSrvrSegMngmtDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_QTY_ALT                       /* package ID 55 */
   &mgMgcoPropParm_Qty_AltDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                    /* package IDs 56 - 63 */
   NULLP, NULLP, NULLP, NULLP,
 
   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_RBS                          /* package ID 64 */
   &mgMgcoPropParm_rbsDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 65 - 74 */
   NULLP, NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Moved from location 37-41
    */
#ifdef GCP_PKG_MGCO_NAS_SUPPORT                  /* package IDs 75 - 79 */
   &mgMgcoPropParmNasDef,
   &mgMgcoPropParmNasInDef,
   &mgMgcoPropParmNasOutDef,
   NULLP, /* !&mgMgcoPropParmNasCtlDef, */
   &mgMgcoPropParmNasRootDef,
#else /* !GCP_PKG_MGCO_NAS_SUPPORT */
   NULLP, NULLP, NULLP, NULLP, NULLP,
#endif /* GCP_PKG_MGCO_NAS_SUPPORT */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_PROF                         /* package ID 80 */
   &mgMgcoPropParm_ProfDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 81 - 98 */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, 

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_H324_EXT                     /* package ID 99 */
   &mgMgcoPropParm_H324_ExtDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_H245_COM_EXT                 /* package ID 100 */
   &mgMgcoPropParm_H245_Com_ExtDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_H245_IND_EXT                 /* package ID 101 */
   &mgMgcoPropParm_H245_Ind_EXtDef,
#else
   NULLP,
#endif

   NULLP, NULLP,                                 /* package IDs 102 - 103 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCTM                     /* package ID 104 */
   &mgMgcoPropParm_tri_gctmDef,                 
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 105 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_SEM_PER                      /* package ID 106 */
   &mgMgcoPropParm_Sem_PerDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_SH_RISK                      /* package ID 107 */
   &mgMgcoPropParm_Sh_RiskDef,
#else
   NULLP,
#endif

   NULLP, NULLP,                          /* package IDs 108 - 109 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_FLR_CTL                      /* package ID 110 */
   &mgMgcoPropParm_Flr_CtlDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 111 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_VOL_CTL                       /* package ID 112 */
   &mgMgcoPropParm_Vol_CtlDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GIPTRA                   /* package ID 113 */
   &mgMgcoPropParm_tri_giptraDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 114 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_VOL_LEV_MIX                   /* package ID 115 */
   &mgMgcoPropParm_Vol_Lev_MixDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MIX_VOL_CTL                   /* package ID 116 */
   &mgMgcoPropParm_Mix_Vol_CtlDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_VOI_ACT_VID_SW                /* package ID 117 */
   &mgMgcoPropParm_Voi_Act_Vid_SwDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_LEC_VID_MOD                   /* package ID 118 */ 
   &mgMgcoPropParm_Lec_Vid_ModDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_CON_VID_SRC                   /* package ID 119 */ 
   &mgMgcoPropParm_Con_Vid_SrcDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_VID_WIN                       /* package ID 120 */ 
   &mgMgcoPropParm_Vid_WinDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TIL_WIN                       /* package ID 121 */ 
   &mgMgcoPropParm_Til_WinDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_AD_JIT_BUFF                   /* package ID 122 */ 
   &mgMgcoPropParm_Ad_Jit_BuffDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ICAS                          /* package ID 123 */ 
   &mgMgcoPropParm_IcasDef,
#else
   NULLP,
#endif

   NULLP,                                         /* package ID 124 */

   NULLP, NULLP, NULLP, NULLP, NULLP,             /* package IDs 125 -129 */

   /*
    *  Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCSDEN                    /* package ID 130 */
   &mgMgcoPropParm_tri_gcsdenDef,
#else
   NULLP,
#endif

   
   NULLP, NULLP,                                  /* package IDs 131 -132 */ 
   
   /* [TEL]: Moved from location 36 */
   &mgMgcoPropParmAllPkgDef,                      /* package ID 133 */

   NULLP, NULLP, NULLP, NULLP,                    /* package IDs 134 -137 */

   NULLP, NULLP, NULLP,                         /* package ID 138 - 140 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 141 - 150 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 151 - 160 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 161 - 170 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 171 - 180 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 181 - 190 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 191 - 200 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 201 - 210 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 211 - 220 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 221 - 230 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 231 - 124 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 241 - 250 */
   NULLP, NULLP, NULLP,                         /* package ID 250 - 253 */
   &mgMgcoPropParmUnknownPkgDef,
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoPropParmKnownPkgDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmKnownPkgDefChc =
#endif
{
   MGT_PKG_MAX,
   0,
   NULLP,
   mgMgcoPropParmKnownPkgDefChcElmnts,
   mgMgcoPkgNameEnum
};

/* Property parameter  - known package */
PUBLIC CmAbnfElmDef mgMgcoPropParmKnownPkgDef =
{
#ifdef CM_ABNF_DBG
   "Property parameter - known package",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 285,
   sizeof(MgMgcoPropParm),
   ((CM_ABNF_MANDATORY) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoPropParmKnownPkgDefChc,
   mgMgcoRegExpPackageName
};

/* Property parameter */
PUBLIC CmAbnfElmDef *mgMgcoPropParmDefChcElmnts[] =
{
   &mgMgcoPropParmUnknownPkgDef,
   &mgMgcoPropParmKnownPkgDef
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoPropParmDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmDefChc =
#endif
{
   2,
   MGT_PKG_MAX,
   mgMgcoPkgChcIdx,
   mgMgcoPropParmDefChcElmnts,
   mgMgcoPkgChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmDef =
{
#ifdef CM_ABNF_DBG
   "Property parameter",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 286,
   sizeof(MgMgcoPropParm),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoPropParmDefChc,
   mgMgcoRegExpPackageName
};


/************************************************************************/

/* Property parameter array */
PUBLIC CmAbnfElmDef *mgMgcoPropParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoPropParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPropParmArrayDefSeqOf =
{
   1,
   MGT_MAX_PROPPARMS,
   2,
   mgMgcoPropParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoPropParm)
};

/* *(COMMA propertyParm) */
PUBLIC CmAbnfElmDef mgMgcoPropParmArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Property parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 287,
   sizeof(MgMgcoPropParmLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPropParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Property parameter list */
PUBLIC CmAbnfElmDef *mgMgcoPropParmLstDefSeqElmnts[]   =
{
   &mgMgcoPropParmDef,
   &mgMgcoPropParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmLstDefSeq =
{
   2,
   mgMgcoPropParmLstDefSeqElmnts
};

/* propertyParm *(COMMA propertyParm) */
PUBLIC CmAbnfElmDef mgMgcoPropParmLstDef   =
{
#ifdef CM_ABNF_DBG
   "Property parameter list",
   "NAME",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 288,
   sizeof(MgMgcoPropParmLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPropParmLstDefSeq,
   mgMgcoRegExpNameAllOrSpec
};

/************************************************************************/

/* Buffer control */
PUBLIC CmAbnfElmDef *mgMgcoBufCtlDefChcEnum[]   =
{
   &cmMsgDefEnumOffBool,
   &mgMgcoLockStepEnum,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoBufCtlDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoBufCtlDefChcEnum
};

/* "OFF" / LockStepToken */
PUBLIC CmAbnfElmDef mgMgcoBufCtlDef   =
{
#ifdef CM_ABNF_DBG
   "Buffer control",
   "OffLockstep",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 289,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoBufCtlDefChc,
   mgMgcoRegExpOffLockstep
};

/************************************************************************/

/* Event buffer control */
PUBLIC CmAbnfElmDef *mgMgcoEvBufCtlDefSeqElmnts[]   =
{
   &mgMgcoBufferTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoBufCtlDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvBufCtlDefSeq =
{
   3,
   mgMgcoEvBufCtlDefSeqElmnts
};

/* eventBufferControl     = BufferToken EQUAL ( "OFF" / LockStepToken ) */
PUBLIC CmAbnfElmDef mgMgcoEvBufCtlDef   =
{
#ifdef CM_ABNF_DBG
   "Event buffer control",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 290,
   sizeof(MgMgcoEvtBufCtl),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvBufCtlDefSeq,
   NULLP
};

/************************************************************************/

/* Event - other */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherDefSeqElmnts[]   =
{
   &mgMgcoNAMEDef,
   &mgMgcoParmValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherDefSeq =
{
   2,
   mgMgcoEvtOtherDefSeqElmnts
};

/* eventOther           = eventParameterName parmValue
 * eventParameterName   = NAME
 */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherDef   =
{
#ifdef CM_ABNF_DBG
   "Event - other",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 291,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherDefSeq,
   NULLP
};

/************************************************************************/

/* Event - stream */
PUBLIC CmAbnfElmDef *mgMgcoEvtStreamDefSeqElmnts[]   =
{
   &mgMgcoStreamTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoStreamIdDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtStreamDefSeq =
{
   3,
   mgMgcoEvtStreamDefSeqElmnts
};

/* eventStream          = StreamToken EQUAL StreamID */
PUBLIC CmAbnfElmDef mgMgcoEvtStreamDef   =
{
#ifdef CM_ABNF_DBG
   "Event - stream",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 292,
   sizeof(MgMgcoStreamId),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtStreamDefSeq,
   NULLP
};

/************************************************************************/

/* T Timer */

/* ["T" COLON Timer COMMA] */
PUBLIC CmAbnfElmDef *mgMgcoOptTTimerDefSeqElmnts[]   =
{
   &mgMgcoTDef,
   &cmMsgDefMetaColon,
   &mgMgcoTimerDef,
   &mgMgcoCOMMADef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptTTimerDefSeq =
{
   4,
   mgMgcoOptTTimerDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoOptTTimerDef   =
{
#ifdef CM_ABNF_DBG
   "T Timer",
   "T",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 293,
   sizeof(TknU8),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ, 
   (U8 *)&mgMgcoOptTTimerDefSeq,
   mgMgcoRegExpT
};

/************************************************************************/

/* S Timer */

/* ["S" COLON Timer COMMA] */
PUBLIC CmAbnfElmDef *mgMgcoOptSTimerDefSeqElmnts[]   =
{
   &mgMgcoSDef,
   &cmMsgDefMetaColon,
   &mgMgcoTimerDef,
   &mgMgcoCOMMADef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptSTimerDefSeq =
{
   4,
   mgMgcoOptSTimerDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoOptSTimerDef   =
{
#ifdef CM_ABNF_DBG
   "S Timer",
   "S",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 294,
   sizeof(TknU8),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ, 
   (U8 *)&mgMgcoOptSTimerDefSeq,
   mgMgcoRegExpS
};

/************************************************************************/

/* L Timer */

/* ["L" COLON Timer COMMA] */
PUBLIC CmAbnfElmDef *mgMgcoOptLTimerDefSeqElmnts[]   =
{
   &mgMgcoLDef,
   &cmMsgDefMetaColon,
   &mgMgcoTimerDef,
   &mgMgcoCOMMADef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptLTimerDefSeq =
{
   4,
   mgMgcoOptLTimerDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoOptLTimerDef   =
{
#ifdef CM_ABNF_DBG
   "L Timer",
   "L",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 295,
   sizeof(TknU8),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ, 
   (U8 *)&mgMgcoOptLTimerDefSeq,
   mgMgcoRegExpLColon
};

/************************************************************************/
/* milton-14 */
#ifdef MGT_MGCO_V2
/* Z Timer */

/* ["Z" COLON Timer COMMA] */
PUBLIC CmAbnfElmDef *mgMgcoOptZTimerDefSeqElmnts[]   =
{
   &mgMgcoZDef,
   &cmMsgDefMetaColon,
   &mgMgcoTimerDef,
   &mgMgcoCOMMADef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptZTimerDefSeq =
{
   4,
   mgMgcoOptZTimerDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoOptZTimerDef   =
{
#ifdef CM_ABNF_DBG
   "Z Timer",
   "Z",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 295,
   sizeof(TknU8),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ, 
   (U8 *)&mgMgcoOptZTimerDefSeq,
   mgMgcoRegExpZColon
};
#endif /* MGT_MGCO_V2 */
/* end milton-14 */
/* Digit map letter */
PUBLIC CmAbnfElmDef *mgMgcoDigMapLetDefChcEnum[]   =
{
   &mgMgcoDigMapLet_0_Enum,
   &mgMgcoDigMapLet_1_Enum,
   &mgMgcoDigMapLet_2_Enum,
   &mgMgcoDigMapLet_3_Enum,
   &mgMgcoDigMapLet_4_Enum,
   &mgMgcoDigMapLet_5_Enum,
   &mgMgcoDigMapLet_6_Enum,
   &mgMgcoDigMapLet_7_Enum,
   &mgMgcoDigMapLet_8_Enum,
   &mgMgcoDigMapLet_9_Enum,
   &mgMgcoDigMapLet_A_Enum,
   &mgMgcoDigMapLet_B_Enum,
   &mgMgcoDigMapLet_C_Enum,
   &mgMgcoDigMapLet_D_Enum,
   &mgMgcoDigMapLet_E_Enum,
   &mgMgcoDigMapLet_F_Enum,
   &mgMgcoDigMapLet_G_Enum,
   &mgMgcoDigMapLet_H_Enum,
   &mgMgcoDigMapLet_I_Enum,
   &mgMgcoDigMapLet_J_Enum,
   &mgMgcoDigMapLet_K_Enum,
   &mgMgcoDigMapLet_L_Enum,
   &mgMgcoDigMapLet_S_Enum,
   &mgMgcoDigMapLet_Z_Enum
};

PUBLIC CmAbnfElmTypeChoice mgMgcoDigMapLetDefChc =
{
   24,
   0,
   NULLP,
   NULLP,
   mgMgcoDigMapLetDefChcEnum
};

/* digitMapLetter       = DIGIT / %x41-4B / %x61-6B / "L" / "S" / "Z" */
PUBLIC CmAbnfElmDef mgMgcoDigMapLetDef   =
{
#ifdef CM_ABNF_DBG
   "Digit map letter",
   "DigMapLet",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 296,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoDigMapLetDefChc,
   mgMgcoRegExpDigMapLet
};

/************************************************************************/

/* Optional 'up' in digit range */
PUBLIC CmAbnfElmDef *mgMgcoOptHyphenDigMapLetDefSeqElmnts[]   =
{
   &cmMsgDefMetaHyphen,
   &mgMgcoDigMapLetDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptHyphenDigMapLetDefSeq =
{
   2,
   mgMgcoOptHyphenDigMapLetDefSeqElmnts
};

/* ["-" DIGIT] */
PUBLIC CmAbnfElmDef mgMgcoOptHyphenDigMapLetDef   =
{
#ifdef CM_ABNF_DBG
   "Optional 'up' in digit range",
   "Hyphen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 297,
   sizeof(TknU8),
   ((CM_ABNF_TKN_NOT_CONSUMED| CM_ABNF_OPTIONAL) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_TKN_NOT_CONSUMED| CM_ABNF_OPTIONAL) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptHyphenDigMapLetDefSeq,
   cmAbnfRegExpHyphen
};

/************************************************************************/

/* Digit range */
PUBLIC CmAbnfElmDef *mgMgcoDigRngDefSeqElmnts[]   =
{
   &mgMgcoDigMapLetDef,
   &mgMgcoOptHyphenDigMapLetDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoDigRngDefSeq =
{
   2,
   mgMgcoDigRngDefSeqElmnts
};

/* (DIGIT "-" DIGIT ) / digitMapLetter */
PUBLIC CmAbnfElmDef mgMgcoDigRngDef   =
{
#ifdef CM_ABNF_DBG
   "Digit range",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 298,
   sizeof(MgMgcoDigRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoDigRngDefSeq,
   NULLP
};

/************************************************************************/

/* Digit letter */
PUBLIC CmAbnfElmDef *mgMgcoDigLetDefSeqOfElmnts[]   =
{
   &mgMgcoDigRngDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoDigLetDefSeqOf =
{
   1,
   MGT_MAX_DIGRNGS,
   1,
   mgMgcoDigLetDefSeqOfElmnts,
   sizeof(MgMgcoDigRng)
};

/* digitLetter          = *((DIGIT "-" DIGIT ) / digitMapLetter) */
PUBLIC CmAbnfElmDef mgMgcoDigLetDef   =
{
#ifdef CM_ABNF_DBG
   "Digit letter",
   "DigMapLet",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 299,
   sizeof(MgMgcoDigMapLet),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoDigLetDefSeqOf,
   mgMgcoRegExpDigMapLet
};

/************************************************************************/

/* Skip MgMgcoDigMapLet for x */

PUBLIC CmAbnfElmDef mgMgcoDigMapXSkipDef   =
{
#ifdef CM_ABNF_DBG
   "Skip MgMgcoDigMapLet for x",
   "EMPTY",
#endif /* CM_ABNF_DBG */ 
   CM_ABNF_ELMNID_MGCO_BASE + 300,
   sizeof(((MgMgcoDigMapRng *)0)->u),
   (CM_ABNF_OPTIONAL  << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL  << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

/************************************************************************/

/* Digit letter + ] */
PUBLIC CmAbnfElmDef *mgMgcoDigLetRSBRKTDefSeqElmnts[]   =
{
   &mgMgcoDigLetDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoDigLetRSBRKTDefSeq =
{
   2,
   mgMgcoDigLetRSBRKTDefSeqElmnts
};

/* digitLetter LWSP "]" LWSP */
PUBLIC CmAbnfElmDef mgMgcoDigLetRSBRKTDef   =
{
#ifdef CM_ABNF_DBG
   "Digit letter + ]",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 301,
   sizeof(MgMgcoDigMapLet),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoDigLetRSBRKTDefSeq,
   NULLP
};

/************************************************************************/

/* Digit map range */
PUBLIC CmAbnfElmDef *mgMgcoDigMapRngDefChcEnum[]   =
{
   &mgMgcoDigMapXEnum,
   &mgMgcoDigMapLSBRKTEnum
};

PUBLIC CmAbnfElmDef *mgMgcoDigMapRngDefChcElmnts[]   =
{
   &mgMgcoDigMapXSkipDef,
   &mgMgcoDigLetRSBRKTDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoDigMapRngDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoDigMapRngDefChcElmnts,
   mgMgcoDigMapRngDefChcEnum
};

/* digitMapRange      = ("x" / LWSP "[" LWSP digitLetter LWSP "]" LWSP) */
PUBLIC CmAbnfElmDef mgMgcoDigMapRngDef   =
{
#ifdef CM_ABNF_DBG
   "Digit map range",
   "DigMapXLSBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 302,
   sizeof(MgMgcoDigMapRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET), /* consume x or LWSP [ LWSP */
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoDigMapRngDefChc,
   mgMgcoRegExpDigMapXLSBRKT
};

/************************************************************************/

/* Digit position */
PUBLIC CmAbnfElmDef *mgMgcoDigPosDefChcEnum[]   =
{
   &mgMgcoDigMapRngDefEnumDef,
   &mgMgcoDigMapLetDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoDigPosDefChcElmnts[]   =
{
   &mgMgcoDigMapRngDef,
   &mgMgcoDigMapLetDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoDigPosDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoDigPosDefChcElmnts,
   mgMgcoDigPosDefChcEnum
};

/* digitPosition        = digitMapLetter / digitMapRange */
PUBLIC CmAbnfElmDef mgMgcoDigPosDef   =
{
#ifdef CM_ABNF_DBG
   "Digit position",
   "DigMapLetRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 303,
   sizeof(((MgMgcoDigStrElem *)0)->u) + sizeof(TknU8),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoDigPosDefChc,
   mgMgcoRegExpDigMapLetRng
};

/************************************************************************/

/* Digit string element */
PUBLIC CmAbnfElmDef *mgMgcoDigStrElemDefSeqElmnts[]   =
{
   &mgMgcoDigPosDef,
   &mgMgcoOptDotDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoDigStrElemDefSeq =
{
   2,
   mgMgcoDigStrElemDefSeqElmnts
};

/* digitStringElement   = digitPosition [DOT] */
PUBLIC CmAbnfElmDef mgMgcoDigStrElemDef   =
{
#ifdef CM_ABNF_DBG
   "Digit string element",
   "EMPTY",
#endif /* CM_ABNF_DBG */ 
   CM_ABNF_ELMNID_MGCO_BASE + 304,
   sizeof(MgMgcoDigStrElem),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoDigStrElemDefSeq,
   NULLP
};

/************************************************************************/

/* Digit string */
PUBLIC CmAbnfElmDef *mgMgcoDigStrDefSeqOfElmnts[]   =
{
   &mgMgcoDigStrElemDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoDigStrDefSeqOf =
{
   1,
   MGT_MAX_DIGSTRELEMS,
   1,
   mgMgcoDigStrDefSeqOfElmnts,
   sizeof(MgMgcoDigStrElem)
};

/* digitString          = 1*(digitStringElement) */
PUBLIC CmAbnfElmDef mgMgcoDigStrDef   =
{
#ifdef CM_ABNF_DBG
   "Digit string",
   "DigMapLetRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 305,
   sizeof(MgMgcoDigStr),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoDigStrDefSeqOf,
   mgMgcoRegExpDigMapLetRng
};

/************************************************************************/

/* Digit string array */
PUBLIC CmAbnfElmDef *mgMgcoDigStrArrayDefSeqOfElmnts[]   =
{
   &mgMgcoLWSPPipeLWSPDef,
   &mgMgcoDigStrDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoDigStrArrayDefSeqOf =
{
   1,
   MGT_MAX_DIGSTRS,
   2,
   mgMgcoDigStrArrayDefSeqOfElmnts,
   sizeof(MgMgcoDigStr)
};

/* *(LWSP "|" LWSP digitString) */
PUBLIC CmAbnfElmDef mgMgcoDigStrArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Digit string array",
   "LWSPPipeLWSP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 306,
   sizeof(MgMgcoDigMap),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoDigStrArrayDefSeqOf,
   mgMgcoRegExpLWSPPipeLWSP
};

/************************************************************************/

/* Digit string list */
PUBLIC CmAbnfElmDef *mgMgcoDigStrLstDefSeqElmnts[]   =
{
   &mgMgcoDigStrDef,
   &mgMgcoDigStrArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoDigStrLstDefSeq =
{
   2,
   mgMgcoDigStrLstDefSeqElmnts
};

/* digitStringList      = digitString *( LWSP "|" LWSP digitString ) */
PUBLIC CmAbnfElmDef mgMgcoDigStrLstDef   =
{
#ifdef CM_ABNF_DBG
   "Digit string list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 307,
   sizeof(MgMgcoDigMap),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoDigStrLstDefSeq,
   NULLP
};

/************************************************************************/

/* Digit string queue */
PUBLIC CmAbnfElmDef *mgMgcoDigStrQDefSeqElmnts[]   =
{
   &mgMgcoLWSPDef,
   &cmMsgDefMetaOpenBrace,
   &mgMgcoLWSPDef,
   &mgMgcoDigStrLstDef,
   &mgMgcoLWSPDef,
   &cmMsgDefMetaCloseBrace,
   &mgMgcoLWSPDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoDigStrQDefSeq =
{
   7,
   mgMgcoDigStrQDefSeqElmnts
};

/* LWSP "(" LWSP digitStringList LWSP ")" LWSP */
PUBLIC CmAbnfElmDef mgMgcoDigStrQDef   =
{
#ifdef CM_ABNF_DBG
   "Digit string queue",
   "StartsWithLWSPOpenBrace",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 308,
   sizeof(MgMgcoDigMap),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoDigStrQDefSeq,
   mgMgcoRegExpStartsWithLWSPOpenBrace
};

/************************************************************************/

/* Digit map */
PUBLIC CmAbnfElmDef *mgMgcoDigMapDefSeqElmnts[]   =
{
   &mgMgcoDigStrDef,
   &mgMgcoDigStrQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoDigMapDefSeq =
{
   2,
   mgMgcoDigMapDefSeqElmnts
};

#if defined (GCP_VER_1_3) && defined (GCP_MGCO_PARSE_DIG_MAP)
PUBLIC CmAbnfElmTypeRange mgMgcoDigMapStringRng = {1, 0xFFFF};
#endif

/* digitMap =  digitString / LWSP "(" LWSP digitStringList LWSP ")" LWSP */
PUBLIC CmAbnfElmDef mgMgcoDigMapDef   =
{
#ifdef CM_ABNF_DBG
   "Digit map",
   "StartsWithLWSPOpenBrace",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 309,
#if defined (GCP_VER_1_3) && defined (GCP_MGCO_PARSE_DIG_MAP)
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY ) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoDigMapStringRng,
   mgMgcoRegExpDigMapAsStr
#else
   sizeof(MgMgcoDigMap),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHSEQOF,
   (U8 *)&mgMgcoDigMapDefSeq,
   mgMgcoRegExpStartsWithLWSPOpenBrace
#endif
};

/************************************************************************/

/* Skip dmIn - TknStrOSXL */

PUBLIC CmAbnfElmDef mgMgcoDigMapSkipDef   =
{
#ifdef CM_ABNF_DBG
   "Skip dmIn - TknStrOSXL",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 310,
   sizeof(TknStrOSXL),
   (CM_ABNF_OPTIONAL  << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL  << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

/************************************************************************/

/* Digit map value */
PUBLIC CmAbnfElmDef *mgMgcoDigMapValDefSeqElmnts[]   =
{
   &mgMgcoOptTTimerDef,
   &mgMgcoOptSTimerDef,
   &mgMgcoOptLTimerDef,
#ifdef MGT_MGCO_V2
   &mgMgcoOptZTimerDef, /* milton-14 */
#endif
   &mgMgcoDigMapDef,
   &mgMgcoDigMapSkipDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoDigMapValDefSeq =
{
#ifdef MGT_MGCO_V2
    6,
#else
    5,
#endif
   mgMgcoDigMapValDefSeqElmnts
};

/* digitMapValue      = ["T" COLON Timer COMMA] ["S" COLON Timer COMMA] 
 *                      ["L" COLON Timer COMMA] digitMap
 */
PUBLIC CmAbnfElmDef mgMgcoDigMapValDef   =
{
#ifdef CM_ABNF_DBG
   "Digit map value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 311,
   sizeof(MgMgcoDigMapVal),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoDigMapValDefSeq,
   NULLP
};

/************************************************************************/

/* Digit map value in event */
PUBLIC CmAbnfElmDef *mgMgcoEvtDigMapValDefSeqElmnts[]   =
{
   &mgMgcoLBRKTDef,
   &mgMgcoDigMapValDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtDigMapValDefSeq =
{
   3,
   mgMgcoEvtDigMapValDefSeqElmnts
};

/* LBRKT digitMapValue RBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtDigMapValDef   =
{
#ifdef CM_ABNF_DBG
   "Digit map value in event",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 312,
   sizeof(MgMgcoDigMapVal),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtDigMapValDefSeq,
   NULLP
};

/************************************************************************/

/* Digit map name */

/* digitMapName       = NAME */

/************************************************************************/

/* Digit map name in event */
PUBLIC CmAbnfElmDef *mgMgcoEvtDigMapNameDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoNAMEDef,
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtDigMapNameDefSeq =
{
   2,
   mgMgcoEvtDigMapNameDefSeqElmnts
};

/* EQUAL digitMapName */
PUBLIC CmAbnfElmDef mgMgcoEvtDigMapNameDef   =
{
#ifdef CM_ABNF_DBG
   "Digit map name in event",
   "EMPTY",
#endif /* CM_ABNF_DBG */ 
   CM_ABNF_ELMNID_MGCO_BASE + 313,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtDigMapNameDefSeq,
   NULLP
};

/************************************************************************/

/* Digit map choice */
PUBLIC CmAbnfElmDef *mgMgcoDigitMapChcDefChcEnum[]   =
{
   &mgMgcoDigMapNameDefEnumDef,
   &mgMgcoDigMapValDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoDigitMapChcDefChcElmnts[]   =
{
   &mgMgcoNAMEDef,
   &mgMgcoEvtDigMapValDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoDigitMapChcDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoDigitMapChcDefChcElmnts,
   mgMgcoDigitMapChcDefChcEnum
};

/* ( digitMapName) /  (LBRKT digitMapValue RBRKT) */
PUBLIC CmAbnfElmDef mgMgcoDigitMapChcDef   =
{
#ifdef CM_ABNF_DBG
   "Digit map choice",
   "DigMapNameVal",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 314,
   sizeof(MgMgcoEvtDM),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoDigitMapChcDefChc,
   mgMgcoRegExpDigMapNameVal
};

/************************************************************************/

/* Event - digit map */
PUBLIC CmAbnfElmDef *mgMgcoEvtDigMapDefSeqElmnts[]   =
{
   &mgMgcoDigitMapTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoDigitMapChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtDigMapDefSeq =
{
   3,
   mgMgcoEvtDigMapDefSeqElmnts
};

/* eventDM              = DigitMapToken EQUAL (    ( digitMapName) /  
 *                                                 (LBRKT digitMapValue RBRKT)
 *                                            )
 */
PUBLIC CmAbnfElmDef mgMgcoEvtDigMapDef   =
{
#ifdef CM_ABNF_DBG
   "Event - digit map",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 315,
   sizeof(MgMgcoEvtDM),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtDigMapDefSeq,
   NULLP
};

/************************************************************************/

/* Embedded signal descriptor */
PUBLIC CmAbnfElmDef *mgMgcoEvtEmbSigDefSeqElmnts[]   =
{
   &mgMgcoEmbedTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoSignalsDescDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtEmbSigDefSeq =
{
   4,
   mgMgcoEvtEmbSigDefSeqElmnts
};

/* embedSig  = EmbedToken LBRKT signalsDescriptor RBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtEmbSigDef   =
{
#ifdef CM_ABNF_DBG
   "Embedded signal descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 316,
   sizeof(MgMgcoSignalsDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtEmbSigDefSeq,
   NULLP
};

/************************************************************************/

/* Second event parameter */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecParmChcEnum[]   =
{
   &mgMgcoEvtOtherDefEnumDef,
   &mgMgcoEvtStreamDefEnumDef,
   &mgMgcoEvtEmbSigDefEnumDef,
   &mgMgcoEvtEmbNoSigDefEnumDef,
   &mgMgcoEvtDigMapDefEnumDef,
   &mgMgcoKeepActiveDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecParmChcElmnts[]   =
{
   &mgMgcoEvtOtherDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC U8 mgMgcoEvtSecParmChcIdx[] = {0, 1, 4, 99, 2, 3};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecParmChc =
{
   5,
   6,
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecParmChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

/* secondEventParameter = (EmbedSig / KeepActiveToken / eventDM /  eventStream
 *                         / eventOther)
 */
PUBLIC CmAbnfElmDef mgMgcoEvtSecParmDef   =
{
#ifdef CM_ABNF_DBG
   "Second event parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 317,
   sizeof(MgMgcoEvtParSec),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecParmChc,
   mgMgcoRegExpEvtPar
};

/************************************************************************/

/* Second event parameter array */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecParmArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec),
};

/* *(COMMA secondEventParameter) */
PUBLIC CmAbnfElmDef mgMgcoEvtSecParmArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Second event parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 318,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Second event parameter list */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecParmLstDefSeqElmnts[]   =
{
   &mgMgcoEvtSecParmDef,
   &mgMgcoEvtSecParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecParmLstDefSeq =
{
   2,
   mgMgcoEvtSecParmLstDefSeqElmnts
};

/* secondEventParameter *(COMMA secondEventParameter) */
PUBLIC CmAbnfElmDef  mgMgcoEvtSecParmLstDef   =
{
#ifdef CM_ABNF_DBG
   "Second event parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 319,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecParmLstDefSeq,
   NULLP
};

/************************************************************************/

/* Second event parameter queue */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecParmQDefSeqElmnts[]   =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecParmQDefSeq =
{
   3,
   mgMgcoEvtSecParmQDefSeqElmnts
};

/* [LBRKT secondEventParameter *(COMMA secondEventParameter) RBRKT] */
PUBLIC CmAbnfElmDef mgMgcoEvtSecParmQDef   =
{
#ifdef CM_ABNF_DBG
   "Second event parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 320,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecParmQDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

/* Second req event - unknown */

PUBLIC CmAbnfElmDef *mgMgcoEvtSecUnknownPkgDefSeqElmnts[]   =
{
   &mgMgcoPkgdNameDef,
   &mgMgcoEvtSecParmQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecUnknownPkgDefSeq =
{
   2,
   mgMgcoEvtSecUnknownPkgDefSeqElmnts
};


/* secondRequestedEvent = pkgdName [LBRKT secondEventParameter
 *                        *(COMMA secondEventParameter) RBRKT]
 */
PUBLIC CmAbnfElmDef mgMgcoEvtSecUnknownPkgDef   =
{
#ifdef CM_ABNF_DBG
   "Second req event",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 321,
   sizeof(MgMgcoEvtSec) - sizeof(TknU8),
   ((CM_ABNF_MANDATORY) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtSecUnknownPkgDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecAllDefSeqElmnts[] =
{
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSLASHDef,
   &mgMgcoNAMEDef,
   &mgMgcoEvtSecParmQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecAllDefSeq =
{
   4,
   mgMgcoEvtSecAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecAllDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - ALL",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 322,
   sizeof(MgMgcoEvtSec) - sizeof(TknU8),
   ((CM_ABNF_MANDATORY) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ, 
   (U8 *)&mgMgcoEvtSecAllDefSeq,
   NULLP
};


/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecKnownPkgDefChcElmnts[] =
{
   NULLP,
   /* mg005.105: changed unknown package id from 0 to 255
    *         ASN Annex C uses package id 0
    *         &mgMgcoEvtSecUnknownPkgDef,            */
#ifdef GCP_PKG_MGCO_GENERIC
   &mgMgcoEvtSecGenericDef,
#else /* !GCP_PKG_MGCO_GENERIC */
   NULLP,
#endif /* GCP_PKG_MGCO_GENERIC */
   NULLP,                        /* !mgMgcoEvtSecRootDef, */
   NULLP,                        /* !mgMgcoEvtSecToneGenDef, */
#ifdef GCP_PKG_MGCO_TONEDET
   &mgMgcoEvtSecToneDetDef,
#else /* !GCP_PKG_MGCO_TONEDET */
   NULLP,
#endif /* GCP_PKG_MGCO_TONEDET */
   NULLP,                        /* !mgMgcoEvtSecDtmfGenDef, */
#ifdef GCP_PKG_MGCO_DTMFDET
   &mgMgcoEvtSecDtmfDetDef,
#else /* !GCP_PKG_MGCO_DTMFDET */
   NULLP,
#endif /* GCP_PKG_MGCO_DTMFDET */
   NULLP,                        /* !mgMgcoEvtSecCpGenDef, */
#ifdef GCP_PKG_MGCO_CPDET
   &mgMgcoEvtSecCpDetDef,
#else /* !GCP_PKG_MGCO_CPDET */
   NULLP,
#endif /* GCP_PKG_MGCO_CPDET */
#ifdef GCP_PKG_MGCO_ANALOG
   &mgMgcoEvtSecAnalogDef,
#else /* !GCP_PKG_MGCO_ANALOG */
   NULLP,
#endif /* GCP_PKG_MGCO_ANALOG */
#ifdef GCP_PKG_MGCO_CONT
   &mgMgcoEvtSecContDef,
#else /* !GCP_PKG_MGCO_CONT */
   NULLP,
#endif /* GCP_PKG_MGCO_CONT */
#ifdef GCP_PKG_MGCO_NETWORK
   &mgMgcoEvtSecNetworkDef,
#else /* !GCP_PKG_MGCO_NETWORK */
   NULLP,
#endif /* GCP_PKG_MGCO_NETWORK */
#ifdef GCP_PKG_MGCO_RTP
   &mgMgcoEvtSecRtpDef,
#else /* !GCP_PKG_MGCO_RTP */
   NULLP,
#endif /* GCP_PKG_MGCO_RTP */
#ifdef GCP_PKG_MGCO_TDMC
   &mgMgcoEvtSecNetworkDef,
#else /* !GCP_PKG_MGCO_TDMC */
   NULLP,
#endif /* GCP_PKG_MGCO_TDMC */


#ifdef GCP_PKG_MGCO_FAXTONEDET                   /* package ID 14 */
   &mgMgcoEvtSecFaxToneDetDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTCNVR                      /* package ID 15 */
   &mgMgcoEvtSecTxtCnvrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTTELPHONE                  /* package ID 16 */
   &mgMgcoEvtSecTxtTelPhoneDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_CALLTYPDISCR                 /* package ID 17 */
   &mgMgcoEvtSecCallTypDiscrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FAX                          /* package ID 18 */
   &mgMgcoEvtSecFaxDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_IPFAX                        /* package ID 19 */
   &mgMgcoEvtSecIpFaxDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 20 */

#ifdef GCP_PKG_MGCO_KEY                          /* package ID 21 */
   &mgMgcoEvtSecKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_KEYPAD                       /* package ID 22 */
   &mgMgcoEvtSecKeyPadDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_LABELKEY                     /* package ID 23 */
   &mgMgcoEvtSecLabelKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FUNCKEY                      /* package ID 24 */
   &mgMgcoEvtSecFuncKeyDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 25 */

#ifdef GCP_PKG_MGCO_SOFTKEY                      /* package ID 26 */
   &mgMgcoEvtSecSoftKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_ANCILLARYINPUT               /* package ID 27 */
   &mgMgcoEvtSecAncillaryInputDef,
#else
   NULLP,
#endif

   /* package IDs 28-32 */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   
   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_GEN_BRR_CON                  /* package ID 33 */
   &mgMgcoEvtSec_gen_brr_conDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BRR_CTL_TN                   /* package ID 34 */
   &mgMgcoEvtSec_brr_ctl_tnDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 35 */ 
   NULLP,                                        /* package ID 36 */

   NULLP,                                        /* package ID 37 */ 
   NULLP,                                        /* package ID 38 */
   NULLP,                                        /* package ID 39 */
   NULLP,                                        /* package ID 40 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_CHP                          /* Package Id 41 */
   &mgMgcoEvtSec_CHPDef,
#else
   NULLP,
#endif

   /* package IDs 42-47 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCSD                     /* package ID 48 */
   &mgMgcoEvtSec_tri_gcsdDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GTFO                     /* package ID 49 */
   &mgMgcoEvtSec_tri_gtfoDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 50 */

#ifdef GCP_PKG_MGCO_ADVAUSRVRBASE                /* package ID 51 */
   &mgMgcoEvtSecAdvAuSrvrBaseDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASDIGCOLLECT                /* package ID 52 */
   &mgMgcoEvtSecAasDigCollectDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASRECODING                  /* package ID 53 */
   &mgMgcoEvtSecAasRecodingDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 54 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_QTY_ALT                       /* package ID 55 */
   &mgMgcoEvtSec_Qty_AltDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 56 - 61 */
   NULLP,

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MFQ_TN_DET                    /* package ID 62 */
   &mgMgcoEvtSec_MFq_tn_detDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BCAS                         /* package ID 63 */
      &mgMgcoEvtSec_bcasDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_RBS                          /* package ID 64 */
   &mgMgcoEvtSec_rbsDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OSES                         /* package ID 65 */
     &mgMgcoEvtSec_osesDef,
#else
     NULLP,
#endif  

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OSEXT                        /* package ID 66 */
   &mgMgcoEvtSec_osextDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_EXT_ALG                      /* package ID 67 */
   &mgMgcoEvtSec_Ext_AlgDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_AUT_MET                      /* package ID 68 */
   &mgMgcoEvtSec_Aut_MetDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_INACTTIMER                   /* package ID 69 */
   &mgMgcoEvtSec_inacttimerDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GMLC                     /* package ID 70 */ 
   &mgMgcoEvtSec_tri_gmlcDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 71 - 74 */ 

   /*
    * [TEL]: Moved from location 37-41 
    */
#ifdef GCP_PKG_MGCO_NAS_SUPPORT                  /* package IDs 75 - 79 */ 
   &mgMgcoEvtSecNasDef,
   &mgMgcoEvtSecNasInDef,
   &mgMgcoEvtSecNasDef, /* for nasout */
   &mgMgcoEvtSecNasCtlDef,
   NULLP, /* !mgMgcoEvtSecNasRootDef */
#else /* !GCP_PKG_MGCO_NAS_SUPPORT */
   NULLP, NULLP, NULLP, NULLP, NULLP,
#endif /* GCP_PKG_MGCO_NAS_SUPPORT */
  
   NULLP,                                        /* package ID 80 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OCP                         /* package ID 81 */
   &mgMgcoEvtSec_OcpDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_EXT_DTMF                     /* package ID 82 */
   &mgMgcoEvtSec_Ext_DtmfDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 83 - 101 */ 
   NULLP, NULLP, NULLP, NULLP, NULLP, 
   NULLP, NULLP, NULLP, NULLP, NULLP, 
   NULLP, NULLP, NULLP, NULLP, 

#ifdef GCP_PKG_MGCO_ENH_DTMF                     /* package ID 102 */
   &mgMgcoEvtSec_Enh_DtmfDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 103 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCTM                     /* package ID 104 */
   &mgMgcoEvtSec_tri_gctmDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 105 - 108 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BCASADDR                     /* package ID 109 */
   &mgMgcoEvtSec_bcasaddrDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 110 - 113 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_VOL_DET                      /* package ID 114 */
   &mgMgcoEvtSec_Vol_DetDef,
#else
   NULLP,
#endif

   NULLP, NULLP,                                 /* package IDs 115 - 116 */

   /*
    * [TEL2]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_VOI_ACT_VID_SW               /* package ID 117 */
   &mgMgcoEvtSec_Voi_Act_Vid_SwDef,
#else
   NULLP,
#endif
   
   NULLP, NULLP,                                 /* package IDs 118 - 119 */
   
   NULLP, NULLP,                                 /* package IDs 120 - 121 */
   
   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_AD_JIT_BUFF                  /* package ID 122 */
   &mgMgcoEvtSec_Ad_Jit_BuffDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ICAS                         /* package ID 123 */
   &mgMgcoEvtSec_IcasDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_CAS_BLK                      /* package ID 124 */
   &mgMgcoEvtSec_Cas_BlkDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 125 -129 */

   /*
    * Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCSDEN
   &mgMgcoEvtSec_tri_gcsdenDef,
#else
   NULLP,
#endif
   
   NULLP, NULLP, 
   
   /* [TEL]: Moved from location 36 */
   &mgMgcoEvtSecAllDef,                          /* package ID 133 */

   NULLP, NULLP,                                 /* package IDs 134 -135 */

   /*
    * [TEL3]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MSF_UK_ALG                   /* package ID 136 */
   &mgMgcoEvtSec_Msf_Uk_AlgDef,
#else
   NULLP,
#endif

   /*
    * [TEL3]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MSF_UK_AUTOMET               /* package ID 137 */
   &mgMgcoEvtSec_Msf_Uk_AutometDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 138 -146 */
   NULLP, NULLP, NULLP, NULLP,

#ifdef GCP_PKG_MGCO_STIM_AL                      /* package ID 147 */
   &mgMgcoEvtSec_Stim_AlDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP,                         /* package ID 148 - 150 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 151 - 160 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 161 - 170 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 171 - 180 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 181 - 190 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 191 - 200 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 201 - 210 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 211 - 220 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 221 - 230 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 231 - 124 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 241 - 250 */
   NULLP, NULLP, NULLP,                         /* package ID 250 - 253 */
   &mgMgcoEvtSecUnknownPkgDef,
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoEvtSecKnownPkgDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecKnownPkgDefChc =
#endif
{
   MGT_PKG_MAX,
   0,
   NULLP,
   mgMgcoEvtSecKnownPkgDefChcElmnts,
   mgMgcoPkgNameEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecKnownPkgDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - known package",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 323,
   sizeof(MgMgcoEvtSec),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoEvtSecKnownPkgDefChc,
   mgMgcoRegExpPackageName
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecDefChcElmnts[] =
{
   &mgMgcoEvtSecUnknownPkgDef,
   &mgMgcoEvtSecKnownPkgDef
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoEvtSecDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecDefChc =
#endif
{
   2,
   MGT_PKG_MAX,
   mgMgcoPkgChcIdx,
   mgMgcoEvtSecDefChcElmnts,
   mgMgcoPkgChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecDef =
{
#ifdef CM_ABNF_DBG
   "Second req event",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 324,
   sizeof(MgMgcoEvtSec),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoEvtSecDefChc,
   mgMgcoRegExpPackageName
};

/************************************************************************/

/* Second req event array */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECS,
   2,
   mgMgcoEvtSecArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtSec)
};

/* *(COMMA secondRequestedEvent) */
PUBLIC CmAbnfElmDef mgMgcoEvtSecArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Second req event array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 325,
   sizeof(MgMgcoEvtSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Second req event list */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecLstDefSeqElmnts[]   =
{
   &mgMgcoEvtSecDef,
   &mgMgcoEvtSecArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecLstDefSeq =
{
   2,
   mgMgcoEvtSecLstDefSeqElmnts
};

/* secondRequestedEvent *(COMMA secondRequestedEvent) */
PUBLIC CmAbnfElmDef mgMgcoEvtSecLstDef   =
{
#ifdef CM_ABNF_DBG
   "Second req event list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 326,
   sizeof(MgMgcoEvtSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecLstDefSeq,
   NULLP
};


/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoOptRealEmbedFirstDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoRequestIdDef,
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptRealEmbedFirstDefSeq =
{
   5,
   mgMgcoOptRealEmbedFirstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoOptRealEmbedFirstDef =
{
#ifdef CM_ABNF_DBG
   "TerminationAudit in auditOther 1",
   "EQUAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 468,
   sizeof(MgMgcoEmbedFirst) - sizeof(TknPres),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptRealEmbedFirstDefSeq ,
   mgMgcoRegExpEQUAL
};

/* Embed first */
PUBLIC CmAbnfElmDef *mgMgcoEmbedFirstDefSeqElmnts[]   =
{
   &mgMgcoEventsTokenDef,
   &mgMgcoOptRealEmbedFirstDef,
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEmbedFirstDefSeq =
{
   2,
   mgMgcoEmbedFirstDefSeqElmnts
};

/* embedFirst      = EventsToken EQUAL RequestID LBRKT
 *                   secondRequestedEvent *(COMMA secondRequestedEvent)
 *                   RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoEmbedFirstDef   =
{
#ifdef CM_ABNF_DBG
   "Embed first",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 327,
   sizeof(MgMgcoEmbedFirst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoEmbedFirstDefSeq,
   NULLP
};

/************************************************************************/

/* Embed no sig */
PUBLIC CmAbnfElmDef *mgMgcoEvtEmbNoSigDefSeqElmnts[]   =
{
   &mgMgcoEmbedTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoEmbedFirstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtEmbNoSigDefSeq =
{
   4,
   mgMgcoEvtEmbNoSigDefSeqElmnts
};

/* embedNoSig           = EmbedToken LBRKT embedFirst RBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtEmbNoSigDef   =
{
#ifdef CM_ABNF_DBG
   "Embed no sig",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 328,
   sizeof(MgMgcoEmbNoSig),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtEmbNoSigDefSeq,
   NULLP
};

/************************************************************************/

/* Optional embedFirst */
PUBLIC CmAbnfElmDef *mgMgcoOptEmbedFirstDefSeqElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEmbedFirstDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptEmbedFirstDefSeq =
{
   2,
   mgMgcoOptEmbedFirstDefSeqElmnts
};

/* [COMMA embedFirst] */
PUBLIC CmAbnfElmDef mgMgcoOptEmbedFirstDef =
{
#ifdef CM_ABNF_DBG
   "Optional embedFirst",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 329,
   sizeof(MgMgcoEmbedFirst),
   ((CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptEmbedFirstDefSeq,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Embed with sig */
PUBLIC CmAbnfElmDef *mgMgcoEvtEmbWithSigDefSeqElmnts[]   =
{
   &mgMgcoEmbedTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoSignalsDescDef,
   &mgMgcoOptEmbedFirstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtEmbWithSigDefSeq =
{
   5,
   mgMgcoEvtEmbWithSigDefSeqElmnts
};

/* embedWithSig         = EmbedToken LBRKT signalsDescriptor
 *                        [COMMA embedFirst ] RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoEvtEmbWithSigDef   =
{
#ifdef CM_ABNF_DBG
   "Embed with sig",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 330,
   sizeof(MgMgcoEmbWithSig),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoEvtEmbWithSigDefSeq,
   NULLP
};

/************************************************************************/

/* Event spec parameter */
PUBLIC CmAbnfElmDef *mgMgcoEvtSpecParmDefChcEnum[]   =
{
   &mgMgcoEvtOtherDefEnumDef,
   &mgMgcoEvtStreamDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSpecParmDefChcElmnts[]   =
{
   &mgMgcoEvtOtherDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSpecParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvtSpecParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

/* eventSpecParameter   = (eventStream / eventOther) */
PUBLIC CmAbnfElmDef mgMgcoEvtSpecParmDef   =
{
#ifdef CM_ABNF_DBG
   "Event spec parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 331,
   sizeof(MgMgcoEvtPar),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSpecParmDefChc,
   mgMgcoRegExpEvtPar
};

/************************************************************************/

/* KeepActiveToken - skip EvtPar/SigPar */

PUBLIC CmAbnfElmDef mgMgcoEvtKASkipDef   =
{
#ifdef CM_ABNF_DBG
   "KeepActiveToken - skip EvtPar",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 332,
   sizeof(((MgMgcoEvtPar *)0)->u),
   (CM_ABNF_OPTIONAL  << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL  << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

/************************************************************************/

/* KeepActiveToken - consume and skip */
PUBLIC CmAbnfElmDef *mgMgcoEvtKAConsumeSkipDefSeqElmnts[] =
{
   &mgMgcoKeepActiveTokenDef,
   &mgMgcoEvtKASkipDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtKAConsumeSkipDefSeq =
{
   2,
   mgMgcoEvtKAConsumeSkipDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtKAConsumeSkipDef   =
{
#ifdef CM_ABNF_DBG
   "KeepActiveToken - consume and skip",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 333,
   sizeof(((MgMgcoEvtPar *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtKAConsumeSkipDefSeq,
   NULLP
};

/************************************************************************/

/* Event parameter */
PUBLIC CmAbnfElmDef *mgMgcoEvtParmDefChcEnum[]   =
{
   &mgMgcoEvtOtherDefEnumDef,
   &mgMgcoEvtStreamDefEnumDef,
   &mgMgcoEvtEmbWithSigDefEnumDef,
   &mgMgcoEvtEmbNoSigDefEnumDef,
   &mgMgcoEvtDigMapDefEnumDef,
   &mgMgcoKeepActiveDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoEvtParmDefChcElmnts[]   =
{
   &mgMgcoEvtOtherDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoEvtParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

/* eventParameter       = (embedWithSig / embedNoSig / KeepActiveToken /
 *                         eventDM / eventStream / eventOther)
 */
PUBLIC CmAbnfElmDef mgMgcoEvtParmDef   =
{
#ifdef CM_ABNF_DBG
   "Event parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 334,
   sizeof(MgMgcoEvtPar),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtParmDefChc,
   mgMgcoRegExpEvtPar
};

/************************************************************************/

/* Event spec parameter array */
PUBLIC CmAbnfElmDef *mgMgcoEvtSpecParmArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSpecParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSpecParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvtSpecParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

/* *(COMMA eventSpecParameter) */
PUBLIC CmAbnfElmDef mgMgcoEvtSpecParmArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Event spec parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 335,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSpecParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Event spec parameter list */
PUBLIC CmAbnfElmDef *mgMgcoEvtSpecParmLstDefSeqElmnts[]   =
{
   &mgMgcoEvtSpecParmDef,
   &mgMgcoEvtSpecParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSpecParmLstDefSeq =
{
   2,
   mgMgcoEvtSpecParmLstDefSeqElmnts
};

/* eventSpecParameter *(COMMA eventSpecParameter) */
PUBLIC CmAbnfElmDef mgMgcoEvtSpecParmLstDef   =
{
#ifdef CM_ABNF_DBG
   "Event spec parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 336,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSpecParmLstDefSeq,
   NULLP
};

/************************************************************************/

/* Event spec parameter queue */
PUBLIC CmAbnfElmDef *mgMgcoEvtSpecParmQDefSeqElmnts[]   =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSpecParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSpecParmQDefSeq =
{
   3,
   mgMgcoEvtSpecParmQDefSeqElmnts
};

/* [LBRKT eventSpecParameter *(COMMA eventSpecParameter) RBRKT] */
PUBLIC CmAbnfElmDef mgMgcoEvtSpecParmQDef   =
{
#ifdef CM_ABNF_DBG
   "Event spec parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 337,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSpecParmQDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

/* Event spec */
/* NOTE: has the same typedef as requested event but different params */
PUBLIC CmAbnfElmDef *mgMgcoEvSpecUnknownPkgDefSeqElmnts[]   =
{
   &mgMgcoPkgdNameDef,
   &mgMgcoEvtSpecParmQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecUnknownPkgDefSeq =
{
   2,
   mgMgcoEvSpecUnknownPkgDefSeqElmnts
};

/* eventSpec            = pkgdName [LBRKT eventSpecParameter *(COMMA
 *                        eventSpecParameter) RBRKT]
 */
PUBLIC CmAbnfElmDef mgMgcoEvSpecUnknownPkgDef   =
{
#ifdef CM_ABNF_DBG
   "Event spec - unknown",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 338,
   sizeof(MgMgcoEvSpec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvSpecUnknownPkgDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecAllDefSeqElmnts[] =
{
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSLASHDef,
   &mgMgcoNAMEDef,
   &mgMgcoEvtSpecParmQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecAllDefSeq =
{
   4,
   mgMgcoEvSpecAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAllDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - all",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 339,
   sizeof(MgMgcoEvSpec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvSpecAllDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecKnownPkgDefChcElmnts[] =
{
   NULLP,
   /* mg005.105: changed unknown package id from 0 to 255
    *         ASN Annex C uses package id 0
    *         &mgMgcoEvSpecUnknownPkgDef,            */
#ifdef GCP_PKG_MGCO_GENERIC
   &mgMgcoEvSpecGenericDef,
#else /* !GCP_PKG_MGCO_GENERIC */
   NULLP,
#endif /* GCP_PKG_MGCO_GENERIC */
   NULLP,
   NULLP,
#ifdef GCP_PKG_MGCO_TONEDET
   &mgMgcoEvSpecToneDetDef,
#else /* !GCP_PKG_MGCO_TONEDET */
   NULLP,
#endif /* GCP_PKG_MGCO_TONEDET */
   NULLP,
#ifdef GCP_PKG_MGCO_DTMFDET
   &mgMgcoEvSpecDtmfDetDef,
#else /* !GCP_PKG_MGCO_DTMFDET */
   NULLP,
#endif /* GCP_PKG_MGCO_DTMFDET */
   NULLP,
#ifdef GCP_PKG_MGCO_CPDET
   &mgMgcoEvSpecCpDetDef,
#else /* !GCP_PKG_MGCO_CPDET */
   NULLP,
#endif /* GCP_PKG_MGCO_CPDET */
#ifdef GCP_PKG_MGCO_ANALOG
   &mgMgcoEvSpecAnalogDef,
#else /* !GCP_PKG_MGCO_ANALOG */
   NULLP,
#endif /* GCP_PKG_MGCO_ANALOG */
#ifdef GCP_PKG_MGCO_CONT
   &mgMgcoEvSpecContDef,
#else /* !GCP_PKG_MGCO_CONT */
   NULLP,
#endif /* GCP_PKG_MGCO_CONT */
#ifdef GCP_PKG_MGCO_NETWORK
   &mgMgcoEvSpecNetworkDef,
#else /* !GCP_PKG_MGCO_NETWORK */
   NULLP,
#endif /* GCP_PKG_MGCO_NETWORK */
#ifdef GCP_PKG_MGCO_RTP
   &mgMgcoEvSpecRtpDef,
#else /* !GCP_PKG_MGCO_RTP */
   NULLP,
#endif /* GCP_PKG_MGCO_RTP */
#ifdef GCP_PKG_MGCO_TDMC
   &mgMgcoEvSpecNetworkDef,
#else /* !GCP_PKG_MGCO_TDMC */
   NULLP,
#endif /* GCP_PKG_MGCO_TDMC */


#ifdef GCP_PKG_MGCO_FAXTONEDET                   /* package ID 14 */
   &mgMgcoEvSpecFaxToneDetDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTCNVR                      /* package ID 15 */
   &mgMgcoEvSpecTxtCnvrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTTELPHONE                  /* package ID 16 */
   &mgMgcoEvSpecTxtTelPhoneDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_CALLTYPDISCR                 /* package ID 17 */
   &mgMgcoEvSpecCallTypDiscrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FAX                          /* package ID 18 */
   &mgMgcoEvSpecFaxDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_IPFAX                        /* package ID 19 */
   &mgMgcoEvSpecIpFaxDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 20 */

#ifdef GCP_PKG_MGCO_KEY                          /* package ID 21 */
   &mgMgcoEvSpecKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_KEYPAD                       /* package ID 22 */
   &mgMgcoEvSpecKeyPadDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_LABELKEY                     /* package ID 23 */
   &mgMgcoEvSpecLabelKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FUNCKEY                      /* package ID 24 */
   &mgMgcoEvSpecFuncKeyDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 25 */

#ifdef GCP_PKG_MGCO_SOFTKEY                      /* package ID 26 */
   &mgMgcoEvSpecSoftKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_ANCILLARYINPUT               /* package ID 27 */
   &mgMgcoEvSpecAncillaryInputDef,
#else
   NULLP,
#endif

   /* package IDs 28-32 */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   
   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_GEN_BRR_CON                  /* package ID 33 */
   &mgMgcoEvSpec_gen_brr_conDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BRR_CTL_TN                   /* package ID 34 */
   &mgMgcoEvSpec_brr_ctl_tnDef,
#else
   NULLP,
#endif
 
   NULLP,                                        /* package ID 35 */
   NULLP,                                        /* package ID 36 */ 
   NULLP,                                        /* package ID 37 */ 
   NULLP,                                        /* package ID 38 */
   NULLP,                                        /* package ID 39 */
   NULLP,                                        /* package ID 40 */

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_CHP                          /* package ID 41 */
   &mgMgcoEvSpec_CHPDef,
#else
   NULLP,
#endif

     /* package IDs 42-47 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_TRI_GCSD                     /* package ID 48 */
   &mgMgcoEvSpec_tri_gcsdDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_TRI_GTFO                     /* package ID 49 */
   &mgMgcoEvSpec_tri_gtfoDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 50 */

#ifdef GCP_PKG_MGCO_ADVAUSRVRBASE                /* package ID 51 */
   &mgMgcoEvSpecAdvAuSrvrBaseDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASDIGCOLLECT                /* package ID 52 */
   &mgMgcoEvSpecAasDigCollectDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASRECODING                  /* package ID 53 */
   &mgMgcoEvSpecAasRecodingDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 54 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_QTY_ALT                       /* package ID 55 */
   &mgMgcoEvSpec_Qty_AltDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 56 - 61 */ 
   NULLP,

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MFQ_TN_DET                    /* package ID 62 */
   &mgMgcoEvSpec_MFq_tn_detDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_BCAS                         /* package ID 63 */
   &mgMgcoEvSpec_bcasDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_RBS                          /* package ID 64 */
   &mgMgcoEvSpec_rbsDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_OSES                         /* package ID 65 */
   &mgMgcoEvSpec_osesDef,
#else
    NULLP,
#endif  

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_OSEXT                        /* package ID 66 */
   &mgMgcoEvSpec_osextDef,
#else
   NULLP,
#endif 

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_EXT_ALG                      /* package ID 67 */
   &mgMgcoEvSpec_Ext_AlgDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_AUT_MET                      /* package ID 68 */
   &mgMgcoEvSpec_Aut_MetDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_INACTTIMER                   /* package ID 69 */
   &mgMgcoEvSpec_inacttimerDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_TRI_GMLC                     /* package ID 70 */
   &mgMgcoEvSpec_tri_gmlcDef,
#else
   NULLP,
#endif
 
   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 71 - 74 */

   /*
    * [TEL]: Moved from location 37-41
    */  
#ifdef GCP_PKG_MGCO_NAS_SUPPORT                  /* package IDs 75 - 79 */ 
   &mgMgcoEvSpecNasDef,
   &mgMgcoEvSpecNasInDef,
   &mgMgcoEvSpecNasDef, /* for nasout */
   &mgMgcoEvSpecNasCtlDef,
   NULLP, /* !mgMgcoEvSpecNasRootDef */
#else /* !GCP_PKG_MGCO_NAS_SUPPORT */
   NULLP, NULLP, NULLP, NULLP, NULLP,
#endif /* GCP_PKG_MGCO_NAS_SUPPORT */
  
   NULLP,                                        /* package ID 80 */   
   
   /*
    * [TEL2]: Changed from NULLP
    */   
#ifdef GCP_PKG_MGCO_OCP                         /* package ID 81 */
   &mgMgcoEvSpec_OcpDef, 
#else
   NULLP,
#endif
   
#ifdef GCP_PKG_MGCO_EXT_DTMF                     /* package ID 82 */
   &mgMgcoEvSpec_Ext_DtmfDef, 
#else
   NULLP,
#endif
   
   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 83 - 101 */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP,

#ifdef GCP_PKG_MGCO_ENH_DTMF                     /* package ID 102 */
   &mgMgcoEvSpec_Enh_DtmfDef, 
#else
   NULLP,
#endif
   
   NULLP,                                        /* package ID 103 */

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_TRI_GCTM                     /* package ID 104 */
   &mgMgcoEvSpec_tri_gctmDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 105 - 108 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BCASADDR                     /* package ID 109 */
   &mgMgcoEvSpec_bcasaddrDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 110 - 113 */

   /*
    * [TEL2]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_VOL_DET                      /* package ID 114 */
   &mgMgcoEvSpec_Vol_DetDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 115 */
   NULLP,                                        /* package ID 116 */

   /*
    * [TEL2]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_VOI_ACT_VID_SW               /* package ID 117 */
   &mgMgcoEvSpec_Voi_Act_Vid_SwDef,
#else
   NULLP,
#endif
   
   NULLP, NULLP,                                 /* package ID 118 - 119 */

   NULLP, NULLP,                                 /* package ID 120 - 121 */
   
   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_AD_JIT_BUFF                  /* package ID 122 */
   &mgMgcoEvSpec_Ad_Jit_BuffDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ICAS                         /* package ID 123 */
   &mgMgcoEvSpec_IcasDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_CAS_BLK                      /* package ID 124 */
   &mgMgcoEvSpec_Cas_BlkDef,
#else
   NULLP,
#endif
   
   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 125 -129 */
 
   /*
    * Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_TRI_GCSDEN                   /* package ID 130 */
   &mgMgcoEvSpec_tri_gcsdenDef,
#else
   NULLP,
#endif
   
   NULLP, NULLP,                                 /* package IDs 131 -132 */
   
   /* [TEL]: Moved from location 36 */
   &mgMgcoEvSpecAllDef,                          /* package ID 133 */

   NULLP, NULLP,                                 /* package IDs 134 -135 */

   /*
    * [TEL3]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MSF_UK_ALG                   /* package ID 136 */
   &mgMgcoEvSpec_Msf_Uk_AlgDef,
#else
   NULLP,
#endif

   /*
    * [TEL3]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MSF_UK_AUTOMET               /* package ID 137 */
   &mgMgcoEvSpec_Msf_Uk_AutometDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 138 -146 */
   NULLP, NULLP, NULLP, NULLP,

#ifdef GCP_PKG_MGCO_STIM_AL                      /* package ID 147 */
   &mgMgcoEvSpec_Stim_AlDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP,                         /* package ID 148 - 150 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 151 - 160 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 161 - 170 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 171 - 180 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 181 - 190 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 191 - 200 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 201 - 210 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 211 - 220 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 221 - 230 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 231 - 240 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 241 - 250 */
   NULLP, NULLP, NULLP,                         /* package ID 251 - 253 */
   &mgMgcoEvSpecUnknownPkgDef,
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoEvSpecKnownPkgDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecKnownPkgDefChc =
#endif
{
   MGT_PKG_MAX,
   0,
   NULLP,
   mgMgcoEvSpecKnownPkgDefChcElmnts,
   mgMgcoPkgNameEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecKnownPkgDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - known package",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 340,
   sizeof(MgMgcoEvSpec),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoEvSpecKnownPkgDefChc,
   mgMgcoRegExpPackageName
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecDefChcElmnts[] =
{
   &mgMgcoEvSpecUnknownPkgDef,
   &mgMgcoEvSpecKnownPkgDef
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoEvSpecDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecDefChc =
#endif
{
   2,
   MGT_PKG_MAX,
   mgMgcoPkgChcIdx,
   mgMgcoEvSpecDefChcElmnts,
   mgMgcoPkgChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecDef =
{
#ifdef CM_ABNF_DBG
   "Event spec",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 341,
   sizeof(MgMgcoEvSpec),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoEvSpecDefChc,
   mgMgcoRegExpPackageName
};

/************************************************************************/

/* Event parameter array */
PUBLIC CmAbnfElmDef *mgMgcoEvtParmArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoEvtParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

/* *(COMMA eventParameter) */
PUBLIC CmAbnfElmDef mgMgcoEvtParmArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Event parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 342,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Event parameter list */
PUBLIC CmAbnfElmDef *mgMgcoEvtParmLstDefSeqElmnts[]   =
{
   &mgMgcoEvtParmDef,
   &mgMgcoEvtParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtParmLstDefSeq =
{
   2,
   mgMgcoEvtParmLstDefSeqElmnts
};

/* eventParameter *(COMMA eventParameter) */
PUBLIC CmAbnfElmDef  mgMgcoEvtParmLstDef   =
{
#ifdef CM_ABNF_DBG
   "Event parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 343,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtParmLstDefSeq,
   NULLP
};

/************************************************************************/

/* Event parameter queue */
PUBLIC CmAbnfElmDef *mgMgcoEvtParmQDefSeqElmnts[]   =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtParmQDefSeq =
{
   3,
   mgMgcoEvtParmQDefSeqElmnts
};

/* [LBRKT eventParameter *(COMMA eventParameter) RBRKT] */
PUBLIC CmAbnfElmDef mgMgcoEvtParmQDef   =
{
#ifdef CM_ABNF_DBG
   "Event parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 344,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtParmQDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

/* (Requested) event */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtUnknownPkgDefSeqElmnts[]   =
{
   &mgMgcoPkgdNameDef,
   &mgMgcoEvtParmQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtUnknownPkgDefSeq =
{
   2,
   mgMgcoReqEvtUnknownPkgDefSeqElmnts
};

/* requestedEvent       = pkgdName [LBRKT eventParameter 
 *                        *(COMMA eventParameter) RBRKT]
 */
PUBLIC CmAbnfElmDef mgMgcoReqEvtUnknownPkgDef   =
{
#ifdef CM_ABNF_DBG
   "Event - unknown",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 345,
   sizeof(MgMgcoReqEvt) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtUnknownPkgDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtAllDefSeqElmnts[] =
{
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSLASHDef,
   &mgMgcoNAMEDef,
   &mgMgcoEvtParmQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtAllDefSeq =
{
   4,
   mgMgcoReqEvtAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtAllDef =
{
#ifdef CM_ABNF_DBG
   "Event - all",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 346,
   sizeof(MgMgcoReqEvt) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtAllDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtKnownPkgDefChcElmnts[] =
{
   NULLP,
   /* mg005.105: changed unknown package id from 0 to 255
    *         ASN Annex C uses package id 0
    *         &mgMgcoReqEvtUnknownPkgDef,            */
#ifdef GCP_PKG_MGCO_GENERIC
   &mgMgcoReqEvtGenericDef,
#else /* !GCP_PKG_MGCO_GENERIC */
   NULLP,
#endif /* GCP_PKG_MGCO_GENERIC */
   NULLP,
   NULLP,
#ifdef GCP_PKG_MGCO_TONEDET
   &mgMgcoReqEvtToneDetDef,
#else /* !GCP_PKG_MGCO_TONEDET */
   NULLP,
#endif /* GCP_PKG_MGCO_TONEDET */
   NULLP,
#ifdef GCP_PKG_MGCO_DTMFDET
   &mgMgcoReqEvtDtmfDetDef,
#else /* !GCP_PKG_MGCO_DTMFDET */
   NULLP,
#endif /* GCP_PKG_MGCO_DTMFDET */
   NULLP,
#ifdef GCP_PKG_MGCO_CPDET 
   &mgMgcoReqEvtCpDetDef,
#else /* !GCP_PKG_MGCO_CPDET */
   NULLP,
#endif /* GCP_PKG_MGCO_CPDET */
#ifdef GCP_PKG_MGCO_ANALOG
   &mgMgcoReqEvtAnalogDef,
#else /* !GCP_PKG_MGCO_ANALOG */
   NULLP,
#endif /* GCP_PKG_MGCO_ANALOG */
#ifdef GCP_PKG_MGCO_CONT
   &mgMgcoReqEvtContDef,
#else /* !GCP_PKG_MGCO_CONT */
   NULLP,
#endif /* GCP_PKG_MGCO_CONT */
#ifdef GCP_PKG_MGCO_NETWORK
   &mgMgcoReqEvtNetworkDef,
#else /* !GCP_PKG_MGCO_NETWORK */
   NULLP,
#endif /* GCP_PKG_MGCO_NETWORK */
#ifdef GCP_PKG_MGCO_RTP
   &mgMgcoReqEvtRtpDef,
#else /* !GCP_PKG_MGCO_RTP */
   NULLP,
#endif /* GCP_PKG_MGCO_RTP */
#ifdef GCP_PKG_MGCO_TDMC
   &mgMgcoReqEvtNetworkDef,
#else /* !GCP_PKG_MGCO_TDMC */
   NULLP,
#endif /* GCP_PKG_MGCO_TDMC */


#ifdef GCP_PKG_MGCO_FAXTONEDET                   /* package ID 14 */
   &mgMgcoReqEvtFaxToneDetDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTCNVR                      /* package ID 15 */
   &mgMgcoReqEvtTxtCnvrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTTELPHONE                  /* package ID 16 */
   &mgMgcoReqEvtTxtTelPhoneDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_CALLTYPDISCR                 /* package ID 17 */
   &mgMgcoReqEvtCallTypDiscrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FAX                          /* package ID 18 */
   &mgMgcoReqEvtFaxDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_IPFAX                        /* package ID 19 */
   &mgMgcoReqEvtIpFaxDef,
#else
   NULLP,
#endif

   NULLP,                                        /* no events in pkg ID 20 */

#ifdef GCP_PKG_MGCO_KEY                          /* package ID 21 */
   &mgMgcoReqEvtKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_KEYPAD                       /* package ID 22 */
   &mgMgcoReqEvtKeyPadDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_LABELKEY                     /* package ID 23 */
   &mgMgcoReqEvtLabelKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FUNCKEY                      /* package ID 24 */
   &mgMgcoReqEvtFuncKeyDef,
#else
   NULLP,
#endif

   NULLP,                                        /* no events in pkg ID 25 */

#ifdef GCP_PKG_MGCO_SOFTKEY                      /* package ID 26 */
   &mgMgcoReqEvtSoftKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_ANCILLARYINPUT               /* package ID 27 */
   &mgMgcoReqEvtAncillaryInputDef,
#else
   NULLP,
#endif

/* package IDs 28-32 */
   NULLP, NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_GEN_BRR_CON                  /* package ID 33 */
   &mgMgcoReqEvt_gen_brr_conDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BRR_CTL_TN                   /* package ID 34 */
   &mgMgcoReqEvt_brr_ctl_tnDef,
#else
   NULLP,
#endif
 
   NULLP,                                        /* package ID 35 */
   NULLP,                                        /* package ID 36 */

   NULLP,                                        /* package ID 37 */ 
   NULLP,                                        /* package ID 38 */
   NULLP,                                        /* package ID 39 */
   NULLP,                                        /* package ID 40 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_CHP                          /* package ID 41 */
   &mgMgcoReqEvt_CHPDef,
#else
   NULLP,
#endif

     /* package IDs 42-47 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCSD                     /* package ID 48 */
   &mgMgcoReqEvt_tri_gcsdDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GTFO                     /* package ID 49 */
   &mgMgcoReqEvt_tri_gtfoDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 50 */ 

#ifdef GCP_PKG_MGCO_ADVAUSRVRBASE                /* package ID 51 */
   &mgMgcoReqEvtAdvAuSrvrBaseDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASDIGCOLLECT                /* package ID 52 */
   &mgMgcoReqEvtAasDigCollectDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASRECODING                  /* package ID 53 */
   &mgMgcoReqEvtAasRecodingDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 54 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_QTY_ALT                       /* package ID 55 */
   &mgMgcoReqEvt_Qty_AltDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 56 - 61 */
   NULLP,

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MFQ_TN_DET                    /* package ID 62 */
   &mgMgcoReqEvt_MFq_tn_detDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BCAS                         /* package ID 63 */
   &mgMgcoReqEvt_bcasDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_RBS                          /* package ID 64 */
   &mgMgcoReqEvt_rbsDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OSES                         /* package ID 65 */
   &mgMgcoReqEvt_osesDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OSEXT                        /* package ID 66 */
   &mgMgcoReqEvt_osextDef,
#else
   NULLP,
#endif
 
   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_EXT_ALG                      /* package ID 67 */
   &mgMgcoReqEvt_Ext_AlgDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_AUT_MET                      /* package ID 68 */
   &mgMgcoReqEvt_Aut_MetDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_INACTTIMER                   /* package ID 69 */
   &mgMgcoReqEvt_inacttimerDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GMLC                     /* package ID 70 */
   &mgMgcoReqEvt_tri_gmlcDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 71 - 74 */

   /*
    * [TEL]: Moved from location 37-41 
    */
#ifdef GCP_PKG_MGCO_NAS_SUPPORT                  /* package IDs 75 - 79 */ 
   &mgMgcoReqEvtNasDef,
   &mgMgcoReqEvtNasInDef,
   &mgMgcoReqEvtNasDef, /* for nasout */
   &mgMgcoReqEvtNasCtlDef,
   NULLP, /* !mgMgcoReqEvtNasRootDef */
#else /* !GCP_PKG_MGCO_NAS_SUPPORT */
   NULLP, NULLP, NULLP, NULLP, NULLP,
#endif /* GCP_PKG_MGCO_NAS_SUPPORT */

   NULLP,                                        /* package ID 80 */ 
   
   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OCP
   &mgMgcoReqEvt_OcpDef,                         /* package ID 81 */
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_EXT_DTMF
   &mgMgcoReqEvt_Ext_DtmfDef,                    /* package ID 82 */
#else
   NULLP,
#endif
   
   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 83 - 101 */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP,

#ifdef GCP_PKG_MGCO_ENH_DTMF                     /* package ID 102 */
   &mgMgcoReqEvt_Enh_DtmfDef, 
#else
   NULLP,
#endif
   
   NULLP,                                        /* package ID 103 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCTM                     /* package ID 104 */
   &mgMgcoReqEvt_tri_gctmDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 105 - 108 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BCASADDR                     /* package ID 109 */
   &mgMgcoReqEvt_bcasaddrDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 110 - 113 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_VOL_DET
   &mgMgcoReqEvt_Vol_DetDef,                     /* package ID 114 */
#else
   NULLP,
#endif
  
   NULLP,                                        /* package ID 115 */
   NULLP,                                        /* package ID 116 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_VOI_ACT_VID_SW              /* package ID 117 */
   &mgMgcoReqEvt_Voi_Act_Vid_SwDef,
#else
   NULLP,
#endif
   
   NULLP, NULLP,                                 /* package ID 118 - 119 */
 
   NULLP, NULLP,                                 /* package ID 120 - 121 */
   
   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_AD_JIT_BUFF                  /* package ID 122 */
   &mgMgcoReqEvt_Ad_Jit_BuffDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ICAS                         /* package ID 123 */
   &mgMgcoReqEvt_IcasDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_CAS_BLK                      /* package ID 124 */
   &mgMgcoReqEvt_Cas_BlkDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 125 -129 */

   /*
    * Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCSDEN                   /* package ID 130 */
   &mgMgcoReqEvt_tri_gcsdenDef,
#else
   NULLP,
#endif
   
   NULLP, NULLP,                                 /* package IDs 131 -132 */
   
   /* [TEL]: Moved from location 36 */
   &mgMgcoReqEvtAllDef,                          /* package ID 133 */

   NULLP, NULLP,                                 /* package IDs 134 -135 */

   /*
    * [TEL3]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MSF_UK_ALG                   /* package ID 136 */
   &mgMgcoReqEvt_Msf_Uk_AlgDef,
#else
   NULLP,
#endif

   /*
    * [TEL3]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MSF_UK_AUTOMET               /* package ID 137 */
   &mgMgcoReqEvt_Msf_Uk_AutometDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 138 -146 */
   NULLP, NULLP, NULLP, NULLP, 

#ifdef GCP_PKG_MGCO_STIM_AL                      /* package ID 147 */
   &mgMgcoReqEvt_Stim_AlDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP,                         /* package ID 148 - 150 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 151 - 160 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 161 - 170 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 171 - 180 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 181 - 190 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 191 - 200 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 201 - 210 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 211 - 220 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 221 - 230 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 231 - 124 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 241 - 250 */
   NULLP, NULLP, NULLP,                         /* package ID 250 - 253 */
   &mgMgcoReqEvtUnknownPkgDef,
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtKnownPkgDefChc = 
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtKnownPkgDefChc = 
#endif
{
   MGT_PKG_MAX,
   0,
   NULLP,
   mgMgcoReqEvtKnownPkgDefChcElmnts,
   mgMgcoPkgNameEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtKnownPkgDef =
{
#ifdef CM_ABNF_DBG
   "Event - known package",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 347,
   sizeof(MgMgcoReqEvt),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoReqEvtKnownPkgDefChc,
   mgMgcoRegExpPackageName
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtDefChcElmnts[] =
{
   &mgMgcoReqEvtUnknownPkgDef,
   &mgMgcoReqEvtKnownPkgDef
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoReqEvtDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtDefChc =
#endif
{
   2,
   MGT_PKG_MAX,
   mgMgcoPkgChcIdx,
   mgMgcoReqEvtDefChcElmnts,
   mgMgcoPkgChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtDef =
{
#ifdef CM_ABNF_DBG
   "Event",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 348,
   sizeof(MgMgcoReqEvt),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoReqEvtDefChc,
   mgMgcoRegExpPackageName
};

/************************************************************************/

/* Events array */
PUBLIC CmAbnfElmDef *mgMgcoEvtArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTS,
   2,
   mgMgcoEvtArrayDefSeqOfElmnts,
   sizeof(MgMgcoReqEvt)
};

/* *( COMMA requestedEvent ) */
PUBLIC CmAbnfElmDef mgMgcoEvtArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Events array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 349,
   sizeof(MgMgcoEvtLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Events list */
PUBLIC CmAbnfElmDef *mgMgcoEvtLstDefSeqElmnts[]   =
{
   &mgMgcoReqEvtDef,
   &mgMgcoEvtArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtLstDefSeq =
{
   2,
   mgMgcoEvtLstDefSeqElmnts
};

/* requestedEvent *( COMMA requestedEvent ) */
PUBLIC CmAbnfElmDef mgMgcoEvtLstDef   =
{
#ifdef CM_ABNF_DBG
   "Events list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 350,
   sizeof(MgMgcoEvtLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF, 
   (U8 *)&mgMgcoEvtLstDefSeq,
   NULLP
};

/************************************************************************/

/* Signal - other */

/************************************************************************/

/* Signal - stream */

/* sigStream            = StreamToken EQUAL StreamID */

/************************************************************************/

/* Signal type */
/* mg005.105: Changed the order according to ASN values */
PUBLIC CmAbnfElmDef *mgMgcoSigSigTypeDefChcEnum[]   =
{
   &mgMgcoBriefEnum,
   &mgMgcoOnOffEnum,
   &mgMgcoSigTimeOutEnum
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigSigTypeDefChc =
{
   3,
   0,
   NULLP,
   NULLP,
   mgMgcoSigSigTypeDefChcEnum
};

/* signalType           = (OnOffToken / TimeOutToken / BriefToken) */
PUBLIC CmAbnfElmDef mgMgcoSigSigTypeDef   =
{
#ifdef CM_ABNF_DBG
   "Signal type",
   "SignalType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 351,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigSigTypeDefChc,
   mgMgcoRegExpSignalType
};

/************************************************************************/

/* Signal - signal type */
PUBLIC CmAbnfElmDef *mgMgcoSigTypeDefSeqElmnts[]   =
{
   &mgMgcoSignalTypeTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoSigSigTypeDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigTypeDefSeq =
{
   3,
   mgMgcoSigTypeDefSeqElmnts
};

/* sigSignalType        = SignalTypeToken EQUAL signalType */
PUBLIC CmAbnfElmDef mgMgcoSigTypeDef   =
{
#ifdef CM_ABNF_DBG
   "Signal - signal type",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 352,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigTypeDefSeq,
   NULLP
};

/************************************************************************/

/* Signal - signal duration */
PUBLIC CmAbnfElmDef *mgMgcoSigDurationDefSeqElmnts[]   =
{
   &mgMgcoDurationTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoSigSigDurationDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigDurationDefSeq =
{
   3,
   mgMgcoSigDurationDefSeqElmnts
};

/* sigDuration          = DurationToken EQUAL UINT16 */
PUBLIC CmAbnfElmDef mgMgcoSigDurationDef   =
{
#ifdef CM_ABNF_DBG
   "Signal - signal duration",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 353,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigDurationDefSeq,
   NULLP
};

/************************************************************************/

/* Notification reason */
PUBLIC CmAbnfElmDef *mgMgcoNtfyReasonDefChcEnum[]   =
{
   &mgMgcoNtfyTimeOutEnum,
   &mgMgcoInterruptByEventEnum,
   &mgMgcoInterruptByNewSignalsDescrEnum,
   &mgMgcoOtherReasonEnum
};

PUBLIC CmAbnfElmTypeChoice mgMgcoNtfyReasonDefChc =
{
   4,
   0,
   NULLP,
   NULLP,
   mgMgcoNtfyReasonDefChcEnum
};

/* notificationReason   = (TimeOutToken / InterruptByEventToken /
 *                         InterruptByNewSignalsDescrToken / OtherReasonToken)
 */
PUBLIC CmAbnfElmDef mgMgcoNtfyReasonDef   =
{
#ifdef CM_ABNF_DBG
   "Notification reason",
   "NtfyReason",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 354,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoNtfyReasonDefChc,
   mgMgcoRegExpNtfyReason
};

/************************************************************************/

/* Notification reason array */
PUBLIC CmAbnfElmDef *mgMgcoNtfyReasonArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoNtfyReasonDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoNtfyReasonArrayDefSeqOf =
{
   1,
   MGT_MAX_NTFYREASONS,
   2,
   mgMgcoNtfyReasonArrayDefSeqOfElmnts,
   sizeof(TknU8)
};

/* *(COMMA notificationReason) */
PUBLIC CmAbnfElmDef mgMgcoNtfyReasonArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Notification reason array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 355,
   sizeof(MgMgcoNtfyCmpl),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoNtfyReasonArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Notification reason list */
PUBLIC CmAbnfElmDef *mgMgcoNtfyReasonLstDefSeqElmnts[]   =
{
   &mgMgcoNtfyReasonDef,
   &mgMgcoNtfyReasonArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoNtfyReasonLstDefSeq =
{
   2,
   mgMgcoNtfyReasonLstDefSeqElmnts
};

/* notificationReason *(COMMA notificationReason) */
PUBLIC CmAbnfElmDef mgMgcoNtfyReasonLstDef   =
{
#ifdef CM_ABNF_DBG
   "Notification reason list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 356,
   sizeof(MgMgcoNtfyCmpl),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,  
   (U8 *)&mgMgcoNtfyReasonLstDefSeq,
   NULLP
};

/************************************************************************/

/* Notify completion */
PUBLIC CmAbnfElmDef *mgMgcoSigNtfyCmplDefSeqElmnts[]   =
{
   &mgMgcoNotifyCompletionTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoNtfyReasonLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigNtfyCmplDefSeq =
{
   5,
   mgMgcoSigNtfyCmplDefSeqElmnts
};

/* notifyCompletion     = NotifyCompletionToken EQUAL LBRKT notificationReason
 *                        *(COMMA notificationReason) RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoSigNtfyCmplDef   =
{
#ifdef CM_ABNF_DBG
   "Notify completion",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 357,
   sizeof(MgMgcoNtfyCmpl),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigNtfyCmplDefSeq,
   NULLP
};

/************************************************************************/

/* Signal parameter */
PUBLIC CmAbnfElmDef *mgMgcoSigParDefChcEnum[]   =
{
   &mgMgcoEvtOtherDefEnumDef,
   &mgMgcoEvtStreamDefEnumDef,
   &mgMgcoSigTypeDefEnumDef,
   &mgMgcoSigDurationDefEnumDef,
   &mgMgcoSigNtfyCmplDefEnumDef,
   &mgMgcoKeepActiveDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoSigParDefChcElmnts[]   =
{
   &mgMgcoEvtOtherDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoSigTypeDef,
   &mgMgcoSigDurationDef,
   &mgMgcoSigNtfyCmplDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigParDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoSigParDefChcElmnts,
   mgMgcoSigParDefChcEnum
};

/* sigParameter    = sigStream / sigSignalType / sigDuration / sigOther /
 *                   notifyCompletion / KeepActiveToken
 */
PUBLIC CmAbnfElmDef mgMgcoSigParDef   =
{
#ifdef CM_ABNF_DBG
   "Signal parameter",
   "SigPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 358,
   sizeof(MgMgcoSigPar),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigParDefChc,
   mgMgcoRegExpSigPar
};

/************************************************************************/

/* optional timestamp */
PUBLIC CmAbnfElmDef *mgMgcoOptTimeStampDefSeqElmnts[]   =
{
   &mgMgcoTimeStampDef,
   &mgMgcoLWSPDef,
   &cmMsgDefMetaColon
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptTimeStampDefSeq =
{
   3,
   mgMgcoOptTimeStampDefSeqElmnts
};

/* [TimeStamp LWSP COLON] */
PUBLIC CmAbnfElmDef mgMgcoOptTimeStampDef   =
{
#ifdef CM_ABNF_DBG
   "optional timestamp",
   "TimeStamp",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 359,
   sizeof(MgMgcoTimeStamp),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptTimeStampDefSeq,
   mgMgcoRegExpTimeStamp
};

/************************************************************************/

/* Observed event parameter */

/* observedEventParameter = eventStream / eventOther */

/************************************************************************/

/* Observed event parameter array */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtParArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSpecParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoObsEvtParArrayDefSeqOf =
{
   1,
   MGT_MAX_OBSEVTPARMS,
   2,
   mgMgcoObsEvtParArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

/* *(COMMA observedEventParameter) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtParArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Observed event parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 360,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoObsEvtParArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Observed event parameter list */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtParLstDefSeqElmnts[]   =
{
   &mgMgcoEvtSpecParmDef,
   &mgMgcoObsEvtParArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtParLstDefSeq =
{
   2,
   mgMgcoObsEvtParLstDefSeqElmnts
};

/* observedEventParameter *(COMMA observedEventParameter) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtParLstDef   =
{
#ifdef CM_ABNF_DBG
   "Observed event parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 361,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoObsEvtParLstDefSeq,
   NULLP
};

/************************************************************************/

/* Observed event parameter queue */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtParQDefSeqElmnts[]   =
{
   &mgMgcoLBRKTDef,
   &mgMgcoObsEvtParLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtParQDefSeq =
{
   3,
   mgMgcoObsEvtParQDefSeqElmnts
};

/* [LBRKT observedEventParameter *(COMMA observedEventParameter) RBRKT] */
PUBLIC CmAbnfElmDef mgMgcoObsEvtParQDef   =
{
#ifdef CM_ABNF_DBG
   "Observed event parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 362,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoObsEvtParQDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoObsEvtUnknownPkgDefSeqElmnts[] =
{
   &mgMgcoPkgdNameDef,
   &mgMgcoObsEvtParQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtUnknownPkgDefSeq =
{
   2,
   mgMgcoObsEvtUnknownPkgDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtUnknownPkgDef =
{
#ifdef CM_ABNF_DBG
   "Observed event - unknown package",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 363,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtUnknownPkgDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtAllDefSeqElmnts[] =
{
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSLASHDef,
   &mgMgcoNAMEDef,
   &mgMgcoObsEvtParQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtAllDefSeq =
{
   4,
   mgMgcoObsEvtAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtAllDef =
{
#ifdef CM_ABNF_DBG
   "Observed event - all",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 364,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtAllDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoObsEvtKnownPkgDefChcElmnts[] =
{
   NULLP,
   /* mg005.105: changed unknown package id from 0 to 255
    *         ASN Annex C uses package id 0
    *         &mgMgcoObsEvtUnknownPkgDef,            */
#ifdef GCP_PKG_MGCO_GENERIC
   &mgMgcoObsEvtGenericDef,
#else /* !GCP_PKG_MGCO_GENERIC */
   NULLP,
#endif /* GCP_PKG_MGCO_GENERIC */
   NULLP,                           /* !mgMgcoObsEvtRootDef */
   NULLP,                           /* !mgMgcoObsEvtToneGenDef */
#ifdef GCP_PKG_MGCO_TONEDET
   &mgMgcoObsEvtToneDetDef,
#else /* !GCP_PKG_MGCO_TONEDET */
   NULLP,
#endif /* GCP_PKG_MGCO_TONEDET */
   NULLP,                           /* !mgMgcoObsEvtDtmfGenDef */
#ifdef GCP_PKG_MGCO_DTMFDET
   &mgMgcoObsEvtDtmfDetDef,
#else /* !GCP_PKG_MGCO_DTMFDET */
   NULLP,
#endif /* GCP_PKG_MGCO_DTMFDET */
   NULLP,                           /* !mgMgcoObsEvtCpGenDef */
#ifdef GCP_PKG_MGCO_CPDET
   &mgMgcoObsEvtCpDetDef,
#else /* !GCP_PKG_MGCO_CPDET */
   NULLP,
#endif /* GCP_PKG_MGCO_CPDET */
#ifdef GCP_PKG_MGCO_ANALOG
   &mgMgcoObsEvtAnalogDef,
#else /* !GCP_PKG_MGCO_ANALOG */
   NULLP,
#endif /* GCP_PKG_MGCO_ANALOG */
#ifdef GCP_PKG_MGCO_CONT
   &mgMgcoObsEvtContDef,
#else /* !GCP_PKG_MGCO_CONT */
   NULLP,
#endif /* GCP_PKG_MGCO_CONT */
#ifdef GCP_PKG_MGCO_NETWORK
   &mgMgcoObsEvtNetworkDef,
#else /* !GCP_PKG_MGCO_NETWORK */
   NULLP,
#endif /* GCP_PKG_MGCO_NETWORK */
#ifdef GCP_PKG_MGCO_RTP
   &mgMgcoObsEvtRtpDef,
#else /* !GCP_PKG_MGCO_RTP */
   NULLP,
#endif /* GCP_PKG_MGCO_RTP */
#ifdef GCP_PKG_MGCO_TDMC
   &mgMgcoObsEvtNetworkDef,
#else /* !GCP_PKG_MGCO_TDMC */
   NULLP,
#endif /* GCP_PKG_MGCO_TDMC */


#ifdef GCP_PKG_MGCO_FAXTONEDET                   /* package ID 14 */
   &mgMgcoObsEvtFaxToneDetDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTCNVR                      /* package ID 15 */
   &mgMgcoObsEvtTxtCnvrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTTELPHONE                  /* package ID 16 */
   &mgMgcoObsEvtTxtTelPhoneDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_CALLTYPDISCR                 /* package ID 17 */
   &mgMgcoObsEvtCallTypDiscrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FAX                          /* package ID 18 */
   &mgMgcoObsEvtFaxDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_IPFAX                        /* package ID 19 */
   &mgMgcoObsEvtIpFaxDef,
#else
   NULLP,
#endif

   NULLP,                                        /* No Obs Evt in pkg ID 20 */

#ifdef GCP_PKG_MGCO_KEY                          /* package ID 21 */
   &mgMgcoObsEvtKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_KEYPAD                       /* package ID 22 */
   &mgMgcoObsEvtKeyPadDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_LABELKEY                     /* package ID 23 */
   &mgMgcoObsEvtLabelKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FUNCKEY                      /* package ID 24 */
   &mgMgcoObsEvtFuncKeyDef,
#else
   NULLP,
#endif

   NULLP,                                        /* No Obs Evt in pkg ID 25 */

#ifdef GCP_PKG_MGCO_SOFTKEY                      /* package ID 26 */
   &mgMgcoObsEvtSoftKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_ANCILLARYINPUT               /* package ID 27 */
   &mgMgcoObsEvtAncillaryInputDef,
#else
   NULLP,
#endif

   /* ---------- package IDs 28-32 ----------- */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   
   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_GEN_BRR_CON                  /* package ID 33 */
   &mgMgcoObsEvt_gen_brr_conDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BRR_CTL_TN                   /* package ID 34 */
   &mgMgcoObsEvt_brr_ctl_tnDef,
#else
   NULLP,
#endif
 
   NULLP,                                        /* package ID 35 */
   NULLP,                                        /* package ID 36 */

   NULLP,                                        /* package ID 37 */ 
   NULLP,                                        /* package ID 38 */
   NULLP,                                        /* package ID 39 */
   NULLP,                                        /* package ID 40 */

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_CHP                          /* package ID 41 */
   &mgMgcoObsEvt_CHPDef,
#else
   NULLP,
#endif

     /* package IDs 42-47 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_TRI_GCSD                     /* package ID 48 */
   &mgMgcoObsEvt_tri_gcsdDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GTFO                     /* package ID 49 */
   &mgMgcoObsEvt_tri_gtfoDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 50 */

#ifdef GCP_PKG_MGCO_ADVAUSRVRBASE                /* package ID 51 */
   &mgMgcoObsEvtAdvAuSrvrBaseDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASDIGCOLLECT                /* package ID 52 */
   &mgMgcoObsEvtAasDigCollectDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASRECODING                  /* package ID 53 */
   &mgMgcoObsEvtAasRecodingDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 54 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_QTY_ALT                       /* package ID 55 */
   &mgMgcoObsEvt_Qty_AltDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 56 - 61 */
   NULLP,

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MFQ_TN_DET                    /* package ID 62 */
   &mgMgcoObsEvt_MFq_tn_detDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_BCAS                         /* package ID 63 */
   &mgMgcoObsEvt_bcasDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_RBS                          /* package ID 64 */
   &mgMgcoObsEvt_rbsDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OSES                         /* package ID 65 */
   &mgMgcoObsEvt_osesDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OSEXT                        /* package ID 66 */
   &mgMgcoObsEvt_osextDef,
#else
   NULLP,
#endif
 
   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_EXT_ALG                      /* package ID 67 */
   &mgMgcoObsEvt_Ext_AlgDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_AUT_MET                      /* package ID 68 */
   &mgMgcoObsEvt_Aut_MetDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_INACTTIMER                   /* package ID 69 */
   &mgMgcoObsEvt_inacttimerDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GMLC                     /* package ID 70 */
   &mgMgcoObsEvt_tri_gmlcDef,
#else
   NULLP,
#endif
 
   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 71 - 74 */

   /*
    * [TEL]: Moved from location 37-41
    */  
#ifdef GCP_PKG_MGCO_NAS_SUPPORT                  /* package IDs 75 - 79 */ 
   &mgMgcoObsEvtNasDef,
   &mgMgcoObsEvtNasInDef,
   &mgMgcoObsEvtNasDef, /* for nasout */
   &mgMgcoObsEvtNasCtlDef,
   NULLP, /* !mgMgcoObsEvtNasRootDef */
#else /* !GCP_PKG_MGCO_NAS_SUPPORT */
   NULLP, NULLP, NULLP, NULLP, NULLP,
#endif /* GCP_PKG_MGCO_NAS_SUPPORT */

   NULLP,                                        /* package ID 80 */

   /*
    * [TEL2]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_OCP                          /* package ID 81 */
   &mgMgcoObsEvt_OcpDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_EXT_DTMF                     /* package ID 82 */
   &mgMgcoObsEvt_Ext_DtmfDef,
#else
   NULLP,
#endif
   
   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 83 - 101 */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP,

#ifdef GCP_PKG_MGCO_ENH_DTMF                     /* package ID 102 */
   &mgMgcoObsEvt_Enh_DtmfDef, 
#else
   NULLP,
#endif
   
   NULLP,                                        /* package ID 103 */

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_TRI_GCTM                     /* package ID 104 */
   &mgMgcoObsEvt_tri_gctmDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 105 - 108 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BCASADDR                     /* package ID 109 */
   &mgMgcoObsEvt_bcasaddrDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 110 - 113 */

   /*
    * [TEL2]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_VOL_DET                      /* package ID 114 */
   &mgMgcoObsEvt_Vol_DetDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 115 */
   NULLP,                                        /* package ID 116 */
 
   /*
    * [TEL2]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_VOI_ACT_VID_SW              /* package ID 117 */
   &mgMgcoObsEvt_Voi_Act_Vid_SwDef,
#else
   NULLP,
#endif
   
   NULLP, NULLP,                                 /* package ID 118 - 119 */
   NULLP, NULLP,                                 /* package ID 120 - 121 */
   
   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_AD_JIT_BUFF                  /* package ID 122 */
   &mgMgcoObsEvt_Ad_Jit_BuffDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ICAS                         /* package ID 123 */
   &mgMgcoObsEvt_IcasDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_CAS_BLK                      /* package ID 124 */
   &mgMgcoObsEvt_Cas_BlkDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 125 -129 */
 
   /*
    * Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCSDEN                   /* package ID 130 */
   &mgMgcoObsEvt_tri_gcsdenDef,
#else
   NULLP,
#endif
   
   NULLP, NULLP,                                 /* package IDs 131 -132 */
   
   /* [TEL]: Moved from location 36 */
   &mgMgcoObsEvtAllDef,                          /* package ID 133 */

   NULLP, NULLP,                                 /* package IDs 134 -135 */

   /*
    * [TEL3]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MSF_UK_ALG                   /* package ID 136 */
   &mgMgcoObsEvt_Msf_Uk_AlgDef,
#else
   NULLP,
#endif

   /*
    * [TEL3]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MSF_UK_AUTOMET               /* package ID 137 */
   &mgMgcoObsEvt_Msf_Uk_AutometDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 138 -146 */
   NULLP, NULLP, NULLP, NULLP, 

#ifdef GCP_PKG_MGCO_STIM_AL                      /* package ID 147 */
   &mgMgcoObsEvt_Stim_AlDef,
#else
   NULLP,
#endif
   
   NULLP, NULLP, NULLP,                         /* package ID 148 - 150 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 151 - 160 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 161 - 170 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 171 - 180 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 181 - 190 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 191 - 200 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 201 - 210 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 211 - 220 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 221 - 230 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 231 - 124 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 241 - 250 */
   NULLP, NULLP, NULLP,                         /* package ID 250 - 253 */
   &mgMgcoObsEvtUnknownPkgDef,
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoObsEvtKnownPkgDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtKnownPkgDefChc =
#endif
{
   MGT_PKG_MAX,
   0,
   NULLP,
   mgMgcoObsEvtKnownPkgDefChcElmnts,
   mgMgcoPkgNameEnum
};

/* Observed event - pkgName+params */

PUBLIC CmAbnfElmDef mgMgcoObsEvtKnownPkgDef =
{
#ifdef CM_ABNF_DBG
   "Observed event - known package",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 365,
   sizeof(TknPkgId) + sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoObsEvtKnownPkgDefChc,
   mgMgcoRegExpPackageName
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoObsEvtChcDefChcElmnts[] =
{
   &mgMgcoObsEvtUnknownPkgDef,
   &mgMgcoObsEvtKnownPkgDef
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoObsEvtChcDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtChcDefChc =
#endif
{
   2,
   MGT_PKG_MAX,
   mgMgcoPkgChcIdx,
   mgMgcoObsEvtChcDefChcElmnts,
   mgMgcoPkgChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtChcDef =
{
#ifdef CM_ABNF_DBG
   "Observed event - choice",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 366,
   sizeof(TknPkgId) + sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoObsEvtChcDefChc,
   mgMgcoRegExpPackageName
};


/************************************************************************/

/* Observed event */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtDefSeqElmnts[]   =
{
   &mgMgcoOptTimeStampDef,
   &mgMgcoLWSPDef,
   &mgMgcoObsEvtChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtDefSeq =
{
   3,
   mgMgcoObsEvtDefSeqElmnts
};

/* observedEvent        = [TimeStamp LWSP COLON] LWSP pkgdName 
 *                        [LBRKT observedEventParameter 
 *                        *(COMMA observedEventParameter) RBRKT]
 */
PUBLIC CmAbnfElmDef mgMgcoObsEvtDef   =
{
#ifdef CM_ABNF_DBG
   "Observed event",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 367,
   sizeof(MgMgcoObsEvt),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoObsEvtDefSeq,
   NULLP
};

/************************************************************************/

/* Observed event array */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoObsEvtDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoObsEvtArrayDefSeqOf =
{
   1,
   MGT_MAX_OBSEVTS,
   2,
   mgMgcoObsEvtArrayDefSeqOfElmnts,
   sizeof(MgMgcoObsEvt)
};

/* *(COMMA observedEvent) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Observed event array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 368,
   sizeof(MgMgcoObsEvtLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoObsEvtArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Observed event list */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtLstDefSeqElmnts[]   =
{
   &mgMgcoObsEvtDef,
   &mgMgcoObsEvtArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtLstDefSeq =
{
   2,
   mgMgcoObsEvtLstDefSeqElmnts
};

/* observedEvent *(COMMA observedEvent) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtLstDef   =
{
#ifdef CM_ABNF_DBG
   "Observed event list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 369,
   sizeof(MgMgcoObsEvtLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoObsEvtLstDefSeq,
   NULLP
};

/************************************************************************/

/* Descriptors */

/************************************************************************/

/* Optional error text */
PUBLIC CmAbnfElmDef *mgMgcoOptErrorTextDefSeqElmnts[]   =
{
   &mgMgcoQuotedStringDef /* Different from MGCP: no "" escape */
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptErrorTextDefSeq =
{
   1,
   mgMgcoOptErrorTextDefSeqElmnts
};

/* [quotedString] */
PUBLIC CmAbnfElmDef mgMgcoOptErrorTextDef   =
{
#ifdef CM_ABNF_DBG
   "Optional error text",
   "Dqoute",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 370,
   sizeof(TknStrOSXL),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptErrorTextDefSeq,
   cmAbnfRegExpDquote
};

/************************************************************************/

/* Error descriptor */
PUBLIC CmAbnfElmDef *mgMgcoErrDescDefSeqElmnts[]   =
{
   &mgMgcoErrorTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoErrorCodeDef,
   &mgMgcoLBRKTDef,
   &mgMgcoOptErrorTextDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoErrDescDefSeq =
{
   6,
   mgMgcoErrDescDefSeqElmnts
};

/* errorDescriptor = ErrorToken EQUAL ErrorCode LBRKT [quotedString] RBRKT */
PUBLIC CmAbnfElmDef mgMgcoErrDescDef   =
{
#ifdef CM_ABNF_DBG
   "MgMgcoErrDesc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 371,
   sizeof(MgMgcoErrDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoErrDescDefSeq,
   NULLP
};

/************************************************************************/

/* Local descriptor */
PUBLIC CmAbnfElmDef *mgMgcoLocalDescDefSeqElmnts[]   =
{
   &mgMgcoLocalTokenDef,
   &mgMgcoLBRKTDef,
#ifdef CM_SDP_OPAQUE
   &cmMsgDefSdpTknBuf,
   &cmMsgDefSkipSdpInfo,
#else /* not CM_SDP_OPAQUE */
   &cmMsgDefSkipSdpTknBuf,
   &cmMsgDefSdpBegin,
   &cmMsgDefSdpInfoSet,
   &cmMsgDefSdpEnd,
#endif /* CM_SDP_OPAQUE */
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoLocalDescDefSeq =
{
#ifdef CM_SDP_OPAQUE
   5,
#else /* not CM_SDP_OPAQUE */
   7,
#endif /* CM_SDP_OPAQUE */
   mgMgcoLocalDescDefSeqElmnts
};

/* localDescriptor      = LocalToken LBRKT octetString RBRKT */
PUBLIC CmAbnfElmDef mgMgcoLocalDescDef   =
{
#ifdef CM_ABNF_DBG
   "Local descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 372,
   sizeof(MgMgcoLocalDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoLocalDescDefSeq,
   NULLP
};

/************************************************************************/

/* Remote descriptor */
PUBLIC CmAbnfElmDef *mgMgcoRemoteDescDefSeqElmnts[]   =
{
   &mgMgcoRemoteTokenDef,
   &mgMgcoLBRKTDef,
#ifdef CM_SDP_OPAQUE
   &cmMsgDefSdpTknBuf,
   &cmMsgDefSkipSdpInfo,
#else /* not CM_SDP_OPAQUE */
   &cmMsgDefSkipSdpTknBuf,
   &cmMsgDefSdpBegin,
   &cmMsgDefSdpInfoSet,
   &cmMsgDefSdpEnd,
#endif /* CM_SDP_OPAQUE */
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoRemoteDescDefSeq =
{
#ifdef CM_SDP_OPAQUE
   5,
#else /* not CM_SDP_OPAQUE */
   7,
#endif /* CM_SDP_OPAQUE */
   mgMgcoRemoteDescDefSeqElmnts
};

/* remoteDescriptor      = RemoteToken LBRKT octetString RBRKT */
PUBLIC CmAbnfElmDef mgMgcoRemoteDescDef   =
{
#ifdef CM_ABNF_DBG
   "Remote descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 373,
   sizeof(MgMgcoRemoteDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoRemoteDescDefSeq,
   NULLP
};

/************************************************************************/

/* Signal parameter array */
PUBLIC CmAbnfElmDef *mgMgcoSigParArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoSigParDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoSigParArrayDefSeqOf =
{
   1,
   MGT_MAX_SIGPARS,
   2,
   mgMgcoSigParArrayDefSeqOfElmnts,
   sizeof(MgMgcoSigPar)
};

/* *(COMMA sigParameter) */
PUBLIC CmAbnfElmDef mgMgcoSigParArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Signal parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 374,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoSigParArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Signal parameter list */
PUBLIC CmAbnfElmDef *mgMgcoSigParLstDefSeqElmnts[]   =
{
   &mgMgcoSigParDef,
   &mgMgcoSigParArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigParLstDefSeq =
{
   2,
   mgMgcoSigParLstDefSeqElmnts
};

/* sigParameter  *(COMMA sigParameter) */
PUBLIC CmAbnfElmDef mgMgcoSigParLstDef   =
{
#ifdef CM_ABNF_DBG
   "Signal parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 375,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoSigParLstDefSeq,
   NULLP
};

/************************************************************************/

/* Signal parameter queue */
PUBLIC CmAbnfElmDef *mgMgcoSigParQDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoSigParLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigParQDefSeq =
{
   3,
   mgMgcoSigParQDefSeqElmnts
};

/* [LBRKT sigParameter  *(COMMA sigParameter) RBRKT] */
PUBLIC CmAbnfElmDef mgMgcoSigParQDef   =
{
#ifdef CM_ABNF_DBG
   "Signal parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 376,
   sizeof(MgMgcoSigParLst),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoSigParQDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

/* Signal request */
PUBLIC CmAbnfElmDef *mgMgcoSignalUnknownPkgDefSeqElmnts[]   =
{
   &mgMgcoPkgdNameDef,
   &mgMgcoSigParQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalUnknownPkgDefSeq =
{
   2,
   mgMgcoSignalUnknownPkgDefSeqElmnts
};

/* signalRequest        = signalName [LBRKT sigParameter  
 *                        *(COMMA sigParameter) RBRKT]
 */
PUBLIC CmAbnfElmDef mgMgcoSignalUnknownPkgDef   =
{
#ifdef CM_ABNF_DBG
   "Signal request - unknown",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 377,
   sizeof(MgMgcoSignalsReq) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSignalUnknownPkgDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSignalAllDefSeqElmnts[] =
{
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSLASHDef,
   &mgMgcoNAMEDef,
   &mgMgcoSigParQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalAllDefSeq =
{
   4,
   mgMgcoSignalAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalAllDef =
{
#ifdef CM_ABNF_DBG
   "Signal request - all",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 378,
   sizeof(MgMgcoSignalsReq) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSignalAllDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoSignalKnownPkgDefChcElmnts[] =
{
   /* mg005.105: Changed unknown package id from 0 to 254
    *         because ASN Annex C uses package id 0
    *         so Unknown package id is changed to 254 */
   /*&mgMgcoSignalUnknownPkgDef,*/
   NULLP,   /* Not Available */
   NULLP,   /* Generic */
   NULLP,   /* Root */
#ifdef GCP_PKG_MGCO_TONEGEN
   &mgMgcoSignalToneGenDef,
#else /* !GCP_PKG_MGCO_TONEGEN */
   NULLP,
#endif /* GCP_PKG_MGCO_TONEGEN */
   NULLP,   /* ToneDet */
#ifdef GCP_PKG_MGCO_DTMFGEN
   &mgMgcoSignalDtmfGenDef,
#else /* !GCP_PKG_MGCO_DTMFGEN */
   NULLP,
#endif /* GCP_PKG_MGCO_DTMFGEN */
   NULLP,   /* DtmfDet */
#ifdef GCP_PKG_MGCO_CPGEN
   &mgMgcoSignalCpGenDef,
#else /* !GCP_PKG_MGCO_CPGEN */
   NULLP,
#endif /* GCP_PKG_MGCO_CPGEN */
   NULLP,   /* CpDet */
#ifdef GCP_PKG_MGCO_ANALOG
   &mgMgcoSignalAnalogDef,
#else /* !GCP_PKG_MGCO_ANALOG */
   NULLP,
#endif /* GCP_PKG_MGCO_ANALOG */
#ifdef GCP_PKG_MGCO_CONT
   &mgMgcoSignalContDef,
#else /* !GCP_PKG_MGCO_CONT */
   NULLP,
#endif /* GCP_PKG_MGCO_CONT */
   NULLP,   /* Network */
   NULLP,   /* Rtp */
   NULLP,   /* Tdmc */




   NULLP, NULLP, NULLP,                          /* package IDs 14-16 */


#ifdef GCP_PKG_MGCO_CALLTYPDISCR                 /* package ID 17 */
   &mgMgcoSignalCallTypDiscrDef,
#else
   NULLP,
#endif

   NULLP, NULLP,                                 /* package IDs 18-19 */

#ifdef GCP_PKG_MGCO_DISPLAY                      /* package ID 20 */
   &mgMgcoSignalDisplayDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 21-24 */

#ifdef GCP_PKG_MGCO_INDICATOR                    /* package ID 25 */
   &mgMgcoSignalIndicatorDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_SOFTKEY                      /* package ID 26 */
   &mgMgcoSignalSoftKeyDef,
#else
   NULLP,
#endif

   /* package IDs 27-28 */
   NULLP, NULLP,
   
#ifdef GCP_PKG_MGCO_GENANNC                      /* package ID 29 */
   &mgMgcoSignalGenAnncDef,
#else
   NULLP,
#endif

   /* package IDs 30-32 */
   NULLP, NULLP, NULLP,
   
   /*
    * [TEL]: Changed from NULLP
    */   
#ifdef GCP_PKG_MGCO_GEN_BRR_CON                  /* package ID 33 */
   &mgMgcoSignal_gen_brr_conDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BRR_CTL_TN                   /* package ID 34 */
   &mgMgcoSignal_brr_ctl_tnDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BSC_CAL_TN                   /* package ID 35 */
   &mgMgcoSignal_bsc_cal_tnDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_XD_CALPG_TNGN                /* package ID 36 */
   &mgMgcoSignal_xd_calpg_tngnDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BSC_SRV_TN                   /* package ID 37 */
   &mgMgcoSignal_bsc_srv_tnDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_XD_SRV_TNGN                  /* package ID 38 */
   &mgMgcoSignal_xd_srv_tngnDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_INT_TNGN                     /* package ID 39 */
   &mgMgcoSignal_int_tngnDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BSNS_TNGN                    /* package ID 40 */
   &mgMgcoSignal_bsns_tngnDef,
#else
   NULLP,
#endif

   /* package IDs 41-47 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */   
#ifdef GCP_PKG_MGCO_TRI_GCSD                     /* package ID 48 */
   &mgMgcoSignal_tri_gcsdDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 49 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRIG_XD_CALPG_TNGN           /* package ID 50 */
   &mgMgcoSignal_trig_xd_calpg_tngnDef,
#else
   NULLP,
#endif                               

#ifdef GCP_PKG_MGCO_ADVAUSRVRBASE                /* package ID 51 */
   &mgMgcoSignalAdvAuSrvrBaseDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASDIGCOLLECT                /* package ID 52 */
   &mgMgcoSignalAasDigCollectDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASRECODING                  /* package ID 53 */
   &mgMgcoSignalAasRecodingDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT            /* package ID 54 */
   &mgMgcoSignalAdvAuSrvrSegMngmtDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 55 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_CONF_TN                      /* package ID 56 */
   &mgMgcoSignal_Conf_TnDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TEST                         /* package ID 57 */
   &mgMgcoSignal_TestDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_CARR_TN                      /* package ID 58 */
   &mgMgcoSignal_Carr_TnDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_EN_ALERT                    /* package ID 59 */
   &mgMgcoSignal_En_AlertDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_AN_DISP                     /* package ID 60 */
   &mgMgcoSignal_An_DispDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MFQ_TN_GEN                  /* package ID 61 */
   &mgMgcoSignal_MFq_tn_genDef,
#else
   NULLP,
#endif

   /* package IDs 62 */
   NULLP,

   /*
    * [TEL]: Changed from NULLP
    */   
#ifdef GCP_PKG_MGCO_BCAS                         /* package ID 63 */
       &mgMgcoSignal_bcasDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_RBS                          /* package ID 64 */
   &mgMgcoSignal_rbsDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OSES                         /* package ID 65 */
   &mgMgcoSignal_osesDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OSEXT                        /* package ID 66 */
   &mgMgcoSignal_osextDef,
#else
   NULLP,
#endif 

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_EXT_ALG                      /* package ID 67 */
   &mgMgcoSignal_Ext_AlgDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_AUT_MET                      /* package ID 68 */
   &mgMgcoSignal_Aut_MetDef,
#else
   NULLP,
#endif

   /* package IDs 69 - 74 */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP,

   /*
    * [TEL]: Moved from location 37-41
    * package IDs 75 - 79
    */   
   NULLP, NULLP, NULLP, NULLP, NULLP, /* NAS - no signals for
                                         GCP_PKG_MGCO_NAS_SUPPORT */

   /* package IDs 80 - 82 */
   NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */   
#ifdef GCP_PKG_MGCO_QT_TM_LTC                    /* package ID 83 */
   &mgMgcoSignal_qt_tm_ltcDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_LP_BK_LTR                    /* package ID 84 */
   &mgMgcoSignal_lp_bk_ltrDef,
#else 
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_404                   /* Package ID 85 */
   &mgMgcoSignal_itu_lt_404Def,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_816                   /* Package ID 86 */
   &mgMgcoSignal_itu_lt_816Def,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_1020                  /* Package ID 87 */
   &mgMgcoSignal_itu_lt_1020Def,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_DIST                  /* package ID 88 */ 
   &mgMgcoSignal_itu_lt_distDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_DSEC                  /* package ID 89 */ 
   &mgMgcoSignal_itu_lt_dsecDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_2804                  /* package ID 90 */
   &mgMgcoSignal_itu_lt_2804Def,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_NTT                   /* package ID 91 */ 
   &mgMgcoSignal_itu_lt_nttDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_DPRT                  /* package ID 92 */ 
   &mgMgcoSignal_itu_lt_dprtDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_ATME2                 /* package ID 93 */
   &mgMgcoSignal_itu_lt_atme2Def,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_1004                 /* package IDs 94 */
   &mgMgcoSignal_ansi_lt_1004Def,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_TR                   /* package ID 95 */ 
   &mgMgcoSignal_ansi_lt_trDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_2225                 /* package ID 96 */
   &mgMgcoSignal_ansi_lt_2225Def,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_DTS                  /* package ID 97 */
   &mgMgcoSignal_ansi_lt_dtsDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ANSI_IN_LTR                  /* package ID 98 */ 
   &mgMgcoSignal_ansi_in_ltrDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 99 - 108 */
   NULLP, NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BCASADDR                     /* package ID 109 */
   &mgMgcoSignal_bcasaddrDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package IDs 110 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_IND_VIEW                     /* package ID 111 */ 
   &mgMgcoSignal_Ind_ViewDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package ID 112 - 115 */
   NULLP, NULLP, NULLP, NULLP,                   /* package ID 116 - 119 */
   NULLP, NULLP, NULLP,                          /* package ID 120 - 122 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ICAS                         /* package ID 123 */
   &mgMgcoSignal_IcasDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_CAS_BLK                      /* package ID 124 */
   &mgMgcoSignal_Cas_BlkDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 125 -129 */
   
   /*
    * Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCSDEN                   /* package ID 130 */       
   &mgMgcoSignal_tri_gcsdenDef,  
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 131 */

   /*
    * [TEL]: Changed from NULLP
    */   
#ifdef GCP_PKG_MGCO_TRIG_FLEX_TN                 /* package ID 132 */
   &mgMgcoSignal_trig_flex_tnDef,
#else
   NULLP,
#endif

   /* [TEL]: Moved from location 36 */
   &mgMgcoSignalAllDef,                          /* package ID 133 */

   /*
    * [TEL3]: Changed from NULLP
    */   
#ifdef GCP_PKG_MGCO_MSF_UK_CG                    /* package ID 134 */
   &mgMgcoSignal_Msf_Uk_CgDef,
#else
   NULLP,
#endif

   /*
    * [TEL3]: Changed from NULLP
    */   
#ifdef GCP_PKG_MGCO_MSF_UK_AN                    /* package ID 135 */
   &mgMgcoSignal_Msf_Uk_AnDef,
#else
   NULLP,
#endif

   /*
    * [TEL3]: Changed from NULLP
    */   
#ifdef GCP_PKG_MGCO_MSF_UK_ALG                   /* package ID 136 */
   &mgMgcoSignal_Msf_Uk_AlgDef,
#else
   NULLP,
#endif

   /*
    * [TEL3]: Changed from NULLP
    */   
#ifdef GCP_PKG_MGCO_MSF_UK_AUTOMET               /* package ID 137 */
   &mgMgcoSignal_Msf_Uk_AutometDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package ID 138 - 141 */
   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package ID 142 - 146 */

#ifdef GCP_PKG_MGCO_STIM_AL
   &mgMgcoSignal_Stim_AlDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP,                         /* package ID 148 - 150 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 151 - 160 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 161 - 170 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 171 - 180 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 181 - 190 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 191 - 200 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 201 - 210 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 211 - 220 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 221 - 230 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 231 - 124 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 241 - 250 */
   NULLP, NULLP, NULLP,                         /* package ID 250 - 253 */
   &mgMgcoSignalUnknownPkgDef,                  /* package ID 254 */
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoSignalKnownPkgDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoSignalKnownPkgDefChc =
#endif
{
   MGT_PKG_MAX,
   0,
   NULLP,
   mgMgcoSignalKnownPkgDefChcElmnts,
   mgMgcoPkgNameEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalKnownPkgDef =
{
#ifdef CM_ABNF_DBG
   "Signal - known package",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 379,
   sizeof(MgMgcoSignalsReq),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoSignalKnownPkgDefChc,
   mgMgcoRegExpPackageName
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoSigDescParmSigReqDefChcElmnts[] =
{
   &mgMgcoSignalUnknownPkgDef,
   &mgMgcoSignalKnownPkgDef
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoSigDescParmSigReqDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoSigDescParmSigReqDefChc =
#endif
{
   2,
   MGT_PKG_MAX,
   mgMgcoPkgChcIdx,
   mgMgcoSigDescParmSigReqDefChcElmnts,
   mgMgcoPkgChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigDescParmSigReqDef =
{
#ifdef CM_ABNF_DBG
   "Signal request",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 380,
   sizeof(MgMgcoSignalsReq),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoSigDescParmSigReqDefChc,
   mgMgcoRegExpPackageName
};

/************************************************************************/

/* Signal list paramater array */
PUBLIC CmAbnfElmDef *mgMgcoSigLstParArrayDefElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoSigDescParmSigReqDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoSigLstParArrayDefSeqOf =
{
   1,
   MGT_MAX_SIGREQS,
   2,
   mgMgcoSigLstParArrayDefElmnts,
   sizeof(MgMgcoSignalsReq)
};

/* *(COMMA signalListParm) */
PUBLIC CmAbnfElmDef mgMgcoSigLstParArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Signal list paramater array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 381,
   sizeof(MgMgcoSignalsReqLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoSigLstParArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Signal list paramater list */
PUBLIC CmAbnfElmDef *mgMgcoSigLstParLstDefSeqElmnts[]   =
{
   &mgMgcoSigDescParmSigReqDef,
   &mgMgcoSigLstParArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigLstParLstDefSeq =
{
   2,
   mgMgcoSigLstParLstDefSeqElmnts
};

/* signalListParm *(COMMA signalListParm) */
PUBLIC CmAbnfElmDef mgMgcoSigLstParLstDef   =
{
#ifdef CM_ABNF_DBG
   "Signal list paramater list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 382,
   sizeof(MgMgcoSignalsReqLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoSigLstParLstDefSeq,
   NULLP
};

/************************************************************************/

/* Signal list */
PUBLIC CmAbnfElmDef *mgMgcoSigDescParmSigLstDefSeqElmnts[]   =
{
   &mgMgcoSignalListTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoSigLstIdDef,
   &mgMgcoLBRKTDef,
   &mgMgcoSigLstParLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigDescParmSigLstDefSeq =
{
   6,
   mgMgcoSigDescParmSigLstDefSeqElmnts
};

/* signalList           = SignalListToken EQUAL signalListId LBRKT
 *                        signalListParm *(COMMA signalListParm) RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoSigDescParmSigLstDef   =
{
#ifdef CM_ABNF_DBG
   "Signal list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 383,
   sizeof(MgMgcoSignalsLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoSigDescParmSigLstDefSeq,
   NULLP
};

/************************************************************************/

/* Signal descriptor parameter */
PUBLIC CmAbnfElmDef *mgMgcoSigDescParmDefChcEnum[]   =
{
   &mgMgcoSigDescParmSigLstDefEnumDef,
   &mgMgcoSigDescParmSigReqDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoSigDescParmDefChcElmnts[]   =
{
   &mgMgcoSigDescParmSigLstDef,
   &mgMgcoSigDescParmSigReqDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigDescParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoSigDescParmDefChcElmnts,
   mgMgcoSigDescParmDefChcEnum
};

/* signalParm           = signalList / signalRequest */
PUBLIC CmAbnfElmDef mgMgcoSigDescParmDef   =
{
#ifdef CM_ABNF_DBG
   "Signal descriptor parameter",
   "SigDescParm",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 384,
   sizeof(MgMgcoSignalsParm),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigDescParmDefChc,
   mgMgcoRegExpSigDescParm
};

/************************************************************************/

/* Signal descriptor parameter array */
PUBLIC CmAbnfElmDef *mgMgcoSigDescParmArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoSigDescParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoSigDescParmArrayDefSeqOf =
{
   1,
   MGT_MAX_SIGDESCPARMS - 1,
   2,
   mgMgcoSigDescParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoSignalsParm)
};

/* *(COMMA signalParm) */
PUBLIC CmAbnfElmDef mgMgcoSigDescParmArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Signal descriptor parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 385,
   sizeof(MgMgcoSignalsDesc)  - sizeof(TknPres),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoSigDescParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Signal descriptor parameter list */
PUBLIC CmAbnfElmDef *mgMgcoSigDescParmLstDefSeqElmnts[]   =
{
   &mgMgcoSigDescParmDef,
   &mgMgcoSigDescParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigDescParmLstDefSeq =
{
   2,
   mgMgcoSigDescParmLstDefSeqElmnts
};

/* [signalParm  *(COMMA signalParm)] */
PUBLIC CmAbnfElmDef mgMgcoSigDescParmLstDef   =
{
#ifdef CM_ABNF_DBG
   "Signal descriptor parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 386,
   sizeof(MgMgcoSignalsDesc)  - sizeof(TknPres),
   /* mg002.105:[RA]: Changed following to OPTIONAL; also added TKN_NOT_CONSUMED */
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoSigDescParmLstDefSeq,
   /* mg002.105:[RA]: added RE to enable interoperability with earlier
    * implementations which still send empty signalsDesc as "SG{ }" */
   mgMgcoRegExpSigDescParm
};

PUBLIC CmAbnfElmDef *mgMgcoSigDescParmLstOptDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoSigDescParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigDescParmLstOptDefSeq =
{
   3,
   mgMgcoSigDescParmLstOptDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigDescParmLstOptDef =
{
#ifdef CM_ABNF_DBG
   "Signal descriptor parameter list - optional",
   "SigDescParm",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 387,
   sizeof(MgMgcoSignalsDesc)  - sizeof(TknPres),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigDescParmLstOptDefSeq,
   mgMgcoRegExpLBRKT          /* IG changes */
};

/************************************************************************/

/* Signals descriptor */
PUBLIC CmAbnfElmDef *mgMgcoSignalsDescDefSeqElmnts[]   =
{
   &mgMgcoSignalsTokenDef,
   &mgMgcoSigDescParmLstOptDef,
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalsDescDefSeq =
{
   2,
   mgMgcoSignalsDescDefSeqElmnts
};

/* signalsDescriptor    = SignalsToken LBRKT [signalParm  *(COMMA signalParm)]
 *                        RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoSignalsDescDef   =
{
#ifdef CM_ABNF_DBG
   "Signals descriptor",
   "SignalsToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 388,
   sizeof(MgMgcoSignalsDesc),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoSignalsDescDefSeq,
   mgMgcoRegExpSignalsToken
};

/************************************************************************/

/* Event spec array */
PUBLIC CmAbnfElmDef *mgMgcoEvSpecArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecArrayDefSeqOf =
{
   1,
   MGT_MAX_EVSPECS,
   2,
   mgMgcoEvSpecArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvSpec)
};

/* *(COMMA eventSpec) */
PUBLIC CmAbnfElmDef mgMgcoEvSpecArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Event spec array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 389,
   sizeof(MgMgcoEvBufDesc),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Event spec list */
PUBLIC CmAbnfElmDef *mgMgcoEvSpecLstDefSeqElmnts[]   =
{
   &mgMgcoEvSpecDef,
   &mgMgcoEvSpecArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecLstDefSeq =
{
   2,
   mgMgcoEvSpecLstDefSeqElmnts
};

/* eventSpec *(COMMA eventSpec) */
PUBLIC CmAbnfElmDef mgMgcoEvSpecLstDef   =
{
#ifdef CM_ABNF_DBG
   "Event spec list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 390,
   sizeof(MgMgcoEvBufDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecLstDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoOptRealEvBufDescDefSeqElmnts[]   =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptRealEvBufDescDefSeq =
{
   3,
   mgMgcoOptRealEvBufDescDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoOptRealEvBufDescDef =
{
#ifdef CM_ABNF_DBG
   "eventBufferDescriptor Real Def",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 468,
   sizeof(MgMgcoEvBufDesc),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptRealEvBufDescDefSeq ,
   mgMgcoRegExpLBRKT
};

/* Event buffer descriptor */
PUBLIC CmAbnfElmDef *mgMgcoEvBufDescDefSeqElmnts[]   =
{
   &mgMgcoEventBufferTokenDef,
   &mgMgcoOptRealEvBufDescDef,

};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvBufDescDefSeq =
{
   2,
   mgMgcoEvBufDescDefSeqElmnts
};

/* eventBufferDescriptor = EventBufferToken LBRKT eventSpec *(COMMA eventSpec)
 *                         RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoEvBufDescDef   =
{
#ifdef CM_ABNF_DBG
   "Event buffer descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 391,
   sizeof(MgMgcoEvBufDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvBufDescDefSeq,
   NULLP
};

/************************************************************************/

/* Observed events descriptor */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtDescDefSeqElmnts[]   =
{
   &mgMgcoObservedEventsTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoRequestIdDef,
   &mgMgcoLBRKTDef,
   &mgMgcoObsEvtLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtDescDefSeq =
{
   6,
   mgMgcoObsEvtDescDefSeqElmnts
};

/* observedEventsDescriptor = ObservedEventsToken EQUAL RequestID LBRKT
 *                            observedEvent *(COMMA observedEvent) RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoObsEvtDescDef   =
{
#ifdef CM_ABNF_DBG
   "Observed events descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 392,
   sizeof(MgMgcoObsEvtDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoObsEvtDescDefSeq,
   NULLP
};

/************************************************************************/

/* Service state value */
PUBLIC CmAbnfElmDef *mgMgcoSvcStValDefChcEnum[]   =
{
   &mgMgcoTestEnum,
   &mgMgcoOutOfSvcEnum,
   &mgMgcoInSvcEnum
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSvcStValDefChc =
{
   3,
   0,
   NULLP,
   NULLP,
   mgMgcoSvcStValDefChcEnum
};

/* TestToken / OutOfSvcToken / InSvcToken */
PUBLIC CmAbnfElmDef mgMgcoSvcStValDef   =
{
#ifdef CM_ABNF_DBG
   "Service state value",
   "SvcStVal",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 393,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSvcStValDefChc,
   mgMgcoRegExpSvcStVal
};

/************************************************************************/

/* Service state */
PUBLIC CmAbnfElmDef *mgMgcoSvcStDefSeqElmnts[]   =
{
   &mgMgcoServiceStatesTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoSvcStValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSvcStDefSeq =
{
   3,
   mgMgcoSvcStDefSeqElmnts
};

/* serviceStates        = ServiceStatesToken EQUAL
 *                        (TestToken / OutOfSvcToken / InSvcToken)
 */
PUBLIC CmAbnfElmDef mgMgcoSvcStDef   =
{
#ifdef CM_ABNF_DBG
   "Service state",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 394,
   sizeof(MgMgcoSvcState),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSvcStDefSeq,
   NULLP
};

/************************************************************************/


PUBLIC CmAbnfElmTypeEnum  mgMgcoTermStEvBufCtlDefEnum =
{
    NULLP ,
    MGT_TERMST_EVTBUFCTL
};

PUBLIC CmAbnfElmDef  mgMgcoTermStEvBufCtlDefEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCO: TERMST BUF CTL DEF ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MGCO_BASE  +  550 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMgcoTermStEvBufCtlDefEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  mgMgcoTermStSvcStDefEnum =
{
    NULLP ,
    MGT_TERMST_SVCST
};

PUBLIC CmAbnfElmDef  mgMgcoTermStSvcStDefEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCO: TERMST SVCST DEF ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MGCO_BASE  +  551 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMgcoTermStSvcStDefEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  mgMgcoTermStPropParmDefEnum =
{
    NULLP ,
    MGT_TERMST_PROPLST
};

PUBLIC CmAbnfElmDef  mgMgcoTermStPropParmDefEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCO: TERMST PROPPARM DEF ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MGCO_BASE  +  552 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMgcoTermStPropParmDefEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMgcoTermStParmChcEnum[] =
{
&mgMgcoTermStEvBufCtlDefEnumDef ,
&mgMgcoTermStSvcStDefEnumDef ,
&mgMgcoTermStPropParmDefEnumDef ,

};

PUBLIC CmAbnfElmDef  *mgMgcoTermStParmChcElmnt[] =
{
    &mgMgcoEvBufCtlDef ,
    &mgMgcoSvcStDef ,
    &mgMgcoPropParmDef ,
};

PUBLIC CmAbnfElmTypeChoice  mgMgcoTermStParmChc =
{
    3 ,
    0 ,
    NULLP ,
    mgMgcoTermStParmChcElmnt ,
    mgMgcoTermStParmChcEnum
};

PUBLIC CmAbnfElmDef  mgMgcoTermStParm =
{
#ifdef  CM_ABNF_DBG
    "MGCO: TERMST PARM " ,
    "mgMgcoRegExpPropSvcEvtbufctl" ,
#endif
    CM_ABNF_ELMNID_MGCO_BASE + 553 ,
    sizeof(MgMgcoTermStateParm) ,
     (( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED )<< CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED )<< CM_ABNF_PROT_MEGACO_V2_OFFSET) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMgcoTermStParmChc ,
    mgMgcoRegExpPropSvcEvtbufctl
};

PUBLIC CmAbnfElmDef  *mgMgcoTermStParmListSeqOfElmnts[] =
{
    &mgMgcoCOMMADef ,
    &mgMgcoTermStParm
};

PUBLIC CmAbnfElmTypeSeqOf  mgMgcoTermStParmListSeqOf =
{
    1 ,
    MGT_MAX_TERM_STATE_PARMS ,
    2 ,
    mgMgcoTermStParmListSeqOfElmnts ,
    sizeof (MgMgcoTermStateParm)
};

PUBLIC CmAbnfElmDef  mgMgcoTermStParmList =
{
#ifdef  CM_ABNF_DBG
    "MGCO: TERMST PARM LIST " ,
    "mgMgcoRegExpCOMMA" ,
#endif
    CM_ABNF_ELMNID_MGCO_BASE + 554 ,
    sizeof(MgMgcoTermStateDesc) ,
     (( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED )<< CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED )<< CM_ABNF_PROT_MEGACO_V2_OFFSET) ,
    CM_ABNF_TYPE_SEQOF ,
    (U8 *) &mgMgcoTermStParmListSeqOf ,
    mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef  *mgMgcoTermStParmSetDefSeqElmnts[] =
{
    &mgMgcoTermStParm ,
    &mgMgcoTermStParmList
};

PUBLIC CmAbnfElmTypeSeq  mgMgcoTermStParmSetDefSeq =
{
    2 ,
    mgMgcoTermStParmSetDefSeqElmnts
};

/* changed this defination to make it OPTSEQOF from SET */
PUBLIC CmAbnfElmDef  mgMgcoTermStParmSetDef =
{
#ifdef  CM_ABNF_DBG
    "MGCO: TERMST PARM SET DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MGCO_BASE + 555 ,
    sizeof(MgMgcoTermStateDesc) ,
     (( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED )<< CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED )<< CM_ABNF_PROT_MEGACO_V2_OFFSET) ,
    CM_ABNF_TYPE_OPTSEQOF ,
    (U8 *) &mgMgcoTermStParmSetDefSeq ,
    NULLP
};



/************************************************************************/

/* Termination state descriptor */
PUBLIC CmAbnfElmDef *mgMgcoTermStDescDefSeqElmnts[]   =
{
   &mgMgcoTerminationStateTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoTermStParmSetDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoTermStDescDefSeq =
{
   4,
   mgMgcoTermStDescDefSeqElmnts
};

/* terminationStateDescriptor = TerminationStateToken LBRKT
 *                              terminationStateParm
 *                              *(COMMA terminationStateParm) RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoTermStDescDef   =
{
#ifdef CM_ABNF_DBG
   "Termination state descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */ 
   CM_ABNF_ELMNID_MGCO_BASE + 396,
   sizeof(MgMgcoTermStateDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoTermStDescDefSeq,
   NULLP
};

/************************************************************************/




#ifdef    MGT_MGCO_V2

/* milton eventbuffer */

PUBLIC CmAbnfElmDef *mgMgcoIndAudEvSpecUnknownPkgDefSeqElmnts[]   =
{
   &mgMgcoPkgdNameDef,
   &mgMgcoIndAudEvtSpecParmQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudEvSpecUnknownPkgDefSeq=
{
   2,
   mgMgcoIndAudEvSpecUnknownPkgDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoIndAudEvSpecUnknownPkgDef=
{
#ifdef CM_ABNF_DBG
   "IndAudEvent spec - unknown",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 999,
   sizeof(MgMgcoIndAudEventBuffer) - sizeof(TknU8),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudEvSpecUnknownPkgDefSeq,
   NULLP
};



PUBLIC CmAbnfElmDef *mgMgcoIndAudEvtSpecParmQDefSeqElmnts[]   =
{
   &mgMgcoLBRKTDef,
   &mgMgcoIndAudEvtSpecParmDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudEvtSpecParmQDefSeq =
{
   3,
   mgMgcoIndAudEvtSpecParmQDefSeqElmnts
};

/* [LBRKT indAudeventSpecParameter RBRKT] */
PUBLIC CmAbnfElmDef mgMgcoIndAudEvtSpecParmQDef=
{
#ifdef CM_ABNF_DBG
   "Individual Audit Event spec parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 999,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoIndAudEvtSpecParmQDefSeq,
   mgMgcoRegExpLBRKT
};


/* mgMgcoIndAudEvtSpecParmQDef */


PUBLIC CmAbnfElmTypeEnum mgMgcoIndAudEvtStreamDefEnum =
{
   NULLP,
   MGT_INDAUDEVTPAR_STREAMID
};

PUBLIC CmAbnfElmDef mgMgcoIndAudEvtStreamDefEnumDef   =
{
#ifdef CM_ABNF_DBG
   "IndAudEvent - stream enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 999,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoIndAudEvtStreamDefEnum,
   NULLP
};



PUBLIC CmAbnfElmTypeEnum mgMgcoIndAudEvtEventParamNameEnum=
{
   NULLP,
   MGT_INDAUDEVTPAR_EVTPARMNAME
};

PUBLIC CmAbnfElmDef mgMgcoIndAudEvtEventParamNameEnumDef=
{
#ifdef CM_ABNF_DBG
   "IndAudEvent - stream enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 101,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoIndAudEvtEventParamNameEnum,
   NULLP
};

/*Individual Audit Event spec parameter */
PUBLIC CmAbnfElmDef *mgMgcoIndAudEvtSpecParmDefChcEnum[]   =
{
   &mgMgcoIndAudEvtEventParamNameEnumDef,
   &mgMgcoIndAudEvtStreamDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoIndAudEvtSpecParmDefChcElmnts[]   =
{
   &mgMgcoNAMEDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudEvtSpecParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoIndAudEvtSpecParmDefChcElmnts,
   mgMgcoIndAudEvtSpecParmDefChcEnum
};

/* indAudeventSpecParameter   = (eventStream / eventParameterName) */
PUBLIC CmAbnfElmDef mgMgcoIndAudEvtSpecParmDef   =
{
#ifdef CM_ABNF_DBG
   "Individual Audit Event spec parameter",
   "IndAudEvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 999,
   sizeof(MgMgcoIndAudEventSpecParm),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoIndAudEvtSpecParmDefChc,
   mgMgcoRegExpEvtPar
};

/* milton end indaudevspecunknown */

/************************************************************************/
/*           BEGIN: indAud items                                        */


/*-----------BEGIN: indAudEventBufferDescriptor-------------------------*/

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoIndAudEvSpecKnownPkgDefChcElmnts[] =
{
   NULLP,
   /* mg005.105: changed unknown package id from 0 to 255
    *         ASN Annex C uses package id 0
    *         &mgMgcoIndAudEvSpecUnknownPkgDef,      */
#ifdef GCP_PKG_MGCO_GENERIC
   &mgMgcoIndAudEvSpecGenericDef,
#else /* !GCP_PKG_MGCO_GENERIC */
   NULLP,
#endif /* GCP_PKG_MGCO_GENERIC */
   NULLP,
   NULLP,
#ifdef GCP_PKG_MGCO_TONEDET
   &mgMgcoIndAudEvSpecToneDetDef,
#else /* !GCP_PKG_MGCO_TONEDET */
   NULLP,
#endif /* GCP_PKG_MGCO_TONEDET */
   NULLP,
#ifdef GCP_PKG_MGCO_DTMFDET
   &mgMgcoIndAudEvSpecDtmfDetDef,
#else /* !GCP_PKG_MGCO_DTMFDET */
   NULLP,
#endif /* GCP_PKG_MGCO_DTMFDET */
   NULLP,
#ifdef GCP_PKG_MGCO_CPDET
   &mgMgcoIndAudEvSpecCpDetDef,
#else /* !GCP_PKG_MGCO_CPDET */
   NULLP,
#endif /* GCP_PKG_MGCO_CPDET */
#ifdef GCP_PKG_MGCO_ANALOG
   &mgMgcoIndAudEvSpecAnalogDef,
#else /* !GCP_PKG_MGCO_ANALOG */
   NULLP,
#endif /* GCP_PKG_MGCO_ANALOG */
#ifdef GCP_PKG_MGCO_CONT
   &mgMgcoIndAudEvSpecContDef,
#else /* !GCP_PKG_MGCO_CONT */
   NULLP,
#endif /* GCP_PKG_MGCO_CONT */
#ifdef GCP_PKG_MGCO_NETWORK
   &mgMgcoIndAudEvSpecNetworkDef,
#else /* !GCP_PKG_MGCO_NETWORK */
   NULLP,
#endif /* GCP_PKG_MGCO_NETWORK */
#ifdef GCP_PKG_MGCO_RTP
   &mgMgcoIndAudEvSpecRtpDef,
#else /* !GCP_PKG_MGCO_RTP */
   NULLP,
#endif /* GCP_PKG_MGCO_RTP */
#ifdef GCP_PKG_MGCO_TDMC
   &mgMgcoIndAudEvSpecNetworkDef,
#else /* !GCP_PKG_MGCO_TDMC */
   NULLP,
#endif /* GCP_PKG_MGCO_TDMC */


#ifdef GCP_PKG_MGCO_FAXTONEDET                   /* package ID 14 */
   &mgMgcoIndAudEvSpecFaxToneDetDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTCNVR                      /* package ID 15 */
   &mgMgcoIndAudEvSpecTxtCnvrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTTELPHONE                  /* package ID 16 */
   &mgMgcoIndAudEvSpecTxtTelPhoneDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_CALLTYPDISCR                 /* package ID 17 */
   &mgMgcoIndAudEvSpecCallTypDiscrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FAX                          /* package ID 18 */
   &mgMgcoIndAudEvSpecFaxDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_IPFAX                        /* package ID 19 */
   &mgMgcoIndAudEvSpecIpFaxDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 20 */

#ifdef GCP_PKG_MGCO_KEY                          /* package ID 21 */
   &mgMgcoIndAudEvSpecKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_KEYPAD                       /* package ID 22 */
   &mgMgcoIndAudEvSpecKeyPadDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_LABELKEY                     /* package ID 23 */
   &mgMgcoIndAudEvSpecLabelKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FUNCKEY                      /* package ID 24 */
   &mgMgcoIndAudEvSpecFuncKeyDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 25 */

#ifdef GCP_PKG_MGCO_SOFTKEY                      /* package ID 26 */
   &mgMgcoIndAudEvSpecSoftKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_ANCILLARYINPUT               /* package ID 27 */
   &mgMgcoIndAudEvSpecAncillaryInputDef,
#else
   NULLP,
#endif

   /* package IDs 28-32 */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   
   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_GEN_BRR_CON                  /* package ID 33 */
   &mgMgcoIndAudEvSpec_gen_brr_conDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BRR_CTL_TN                   /* package ID 34 */
   &mgMgcoIndAudEvSpec_brr_ctl_tnDef,
#else
   NULLP,
#endif
 
   NULLP,                                        /* package ID 35 */
   NULLP,                                        /* package ID 36 */ 
   NULLP,                                        /* package ID 37 */ 
   NULLP,                                        /* package ID 38 */
   NULLP,                                        /* package ID 39 */
   NULLP,                                        /* package ID 40 */

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_CHP                          /* package ID 41 */
   &mgMgcoIndAudEvSpec_CHPDef,
#else
   NULLP,
#endif

     /* package IDs 42-47 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_TRI_GCSD                     /* package ID 48 */
   &mgMgcoIndAudEvSpec_tri_gcsdDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_TRI_GTFO                     /* package ID 49 */
   &mgMgcoIndAudEvSpec_tri_gtfoDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 50 */

#ifdef GCP_PKG_MGCO_ADVAUSRVRBASE                /* package ID 51 */
   &mgMgcoIndAudEvSpecAdvAuSrvrBaseDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASDIGCOLLECT                /* package ID 52 */
   &mgMgcoIndAudEvSpecAasDigCollectDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASRECODING                  /* package ID 53 */
   &mgMgcoIndAudEvSpecAasRecodingDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 54 */
   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 55 - 62 */ 
   NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_BCAS                         /* package ID 63 */
   &mgMgcoIndAudEvSpec_bcasDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_RBS                          /* package ID 64 */
   &mgMgcoIndAudEvSpec_rbsDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_OSES                         /* package ID 65 */
   &mgMgcoIndAudEvSpec_osesDef,
#else
    NULLP,
#endif  

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_OSEXT                        /* package ID 66 */
   &mgMgcoIndAudEvSpec_osextDef,
#else
   NULLP,
#endif 

   NULLP,                                        /* package ID 67 */

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_BCASADDR                     /* package ID 68 */
   &mgMgcoIndAudEvSpec_bcasaddrDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_INACTTIMER                   /* package ID 69 */
   &mgMgcoIndAudEvSpec_inacttimerDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_TRI_GMLC                     /* package ID 70 */
   &mgMgcoIndAudEvSpec_tri_gmlcDef,
#else
   NULLP,
#endif
 
   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 71 - 74 */

   /*
    * [TEL]: Moved from location 37-41
    */  
#ifdef GCP_PKG_MGCO_NAS_SUPPORT                  /* package IDs 75 - 79 */ 
   &mgMgcoIndAudEvSpecNasDef,
   &mgMgcoIndAudEvSpecNasInDef,
   &mgMgcoIndAudEvSpecNasDef, /* for nasout */
   &mgMgcoIndAudEvSpecNasCtlDef,
   NULLP, /* !mgMgcoIndAudEvSpecNasRootDef */
#else /* !GCP_PKG_MGCO_NAS_SUPPORT */
   NULLP, NULLP, NULLP, NULLP, NULLP,
#endif /* GCP_PKG_MGCO_NAS_SUPPORT */
   
   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 80 - 103 */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */  
#ifdef GCP_PKG_MGCO_TRI_GCTM                     /* package ID 104 */
   &mgMgcoIndAudEvSpec_tri_gctmDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* Package IDs 105 - 113 */
   NULLP, NULLP, NULLP, NULLP,

   /* [TEL]: Moved from location 36 */
   &mgMgcoIndAudEvSpecAllDef,                          /* package ID 114 */

   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,           /* package ID 115 - 120 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 121 - 130 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 131 - 140 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 141 - 150 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 151 - 160 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 161 - 170 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 171 - 180 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 181 - 190 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 191 - 200 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 201 - 210 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 211 - 220 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 221 - 230 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 231 - 124 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 241 - 250 */
   NULLP, NULLP, NULLP,                         /* package ID 250 - 253 */
   &mgMgcoIndAudEvSpecUnknownPkgDef,      
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoIndAudEvSpecKnownPkgDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudEvSpecKnownPkgDefChc =
#endif
{
   MGT_PKG_MAX,
   0,
   NULLP,
   mgMgcoIndAudEvSpecKnownPkgDefChcElmnts,
   mgMgcoPkgNameEnum      /* Fills TknU8 with known pkg Id */
};

PUBLIC CmAbnfElmDef mgMgcoIndAudEvSpecKnownPkgDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - known package",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 340,
   sizeof(MgMgcoIndAudEventBuffer),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoIndAudEvSpecKnownPkgDefChc,
   mgMgcoRegExpPackageName
};

/************************************************************************/

/*milton now event buffer ALLLLLLLLLLL **************/

PUBLIC CmAbnfElmDef *mgMgcoIndAudEvSpecAllDefSeqElmnts[] =
{
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSLASHDef,
   &mgMgcoNAMEDef,
   &mgMgcoIndAudEvtSpecParmQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudEvSpecAllDefSeq =
{
   4,
   mgMgcoIndAudEvSpecAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoIndAudEvSpecAllDef =
{
#ifdef CM_ABNF_DBG
   "IndAudEvent spec - all",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 999,
   sizeof(MgMgcoIndAudEventBuffer) - sizeof(TknU8),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudEvSpecAllDefSeq,
   NULLP
};
/*milton end all eventbuffer*/




PUBLIC CmAbnfElmDef *mgMgcoIndAudEvSpecDefChcElmnts[] =
{
   &mgMgcoIndAudEvSpecUnknownPkgDef, /* milton */
   &mgMgcoIndAudEvSpecKnownPkgDef
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoIndAudEvSpecDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudEvSpecDefChc =
#endif
{
   2,
   MGT_PKG_MAX,
   mgMgcoPkgChcIdx,
   mgMgcoIndAudEvSpecDefChcElmnts,
   mgMgcoPkgChcEnum      /* This doesn't consume TknU8 for known pkgs */
};

PUBLIC CmAbnfElmDef mgMgcoIndAudEvSpecDef =
{
#ifdef CM_ABNF_DBG
   "Event spec",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 341,
   sizeof(MgMgcoIndAudEventBuffer),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoIndAudEvSpecDefChc,
   mgMgcoRegExpPackageName
};


/************************************************************************/

/* Event buffer descriptor */
PUBLIC CmAbnfElmDef *mgMgcoIndAudEvBufDescDefSeqElmnts[]   =
{
   /*&mgMgcoEventBufferTokenDef,*/
   &mgMgcoLBRKTDef,
   &mgMgcoIndAudEvSpecDef,
   &mgMgcoRBRKTDef

};

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudEvBufDescDefSeq =
{
   3,
   mgMgcoIndAudEvBufDescDefSeqElmnts
};

/*
 *   indAudeventBufferDescriptor = EventBufferToken  
 *                                 LBRKT indAudeventSpec RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoIndAudEvBufDescDef   =
{
#ifdef CM_ABNF_DBG
   "Event buffer descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 391,
   sizeof(MgMgcoIndAudEventBuffer),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudEvBufDescDefSeq,
   NULLP
};

/*-----------END: indAudEventBufferDescriptor---------------------------*/


/*-----------BEGIN: indAudmediaDescriptor-------------------------------*/

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoIndAudPropParmKnownPkgDefChcElmnts[] =
{
   NULLP,
   /* mg005.105: changed unknown package id from 0 to 255
    *         ASN Annex C uses package id 0
    *         &mgMgcoIndAudPropParmUnknownPkgDef,     */
   NULLP, /* !mgMgcoIndAudPropParmGenericDef - no properties def for generic pkg */
#ifdef GCP_PKG_MGCO_ROOT
   &mgMgcoIndAudPropParmRootDef,
#else /* !GCP_PKG_MGCO_ROOT */
   NULLP,
#endif /* GCP_PKG_MGCO_ROOT */
   NULLP, /* !mgMgcoIndAudPropParmToneGenDef - no properties def for tonegen pkg */
   NULLP, /* !mgMgcoIndAudPropParmToneDetDef - no properties def for tonedet pkg */
   NULLP, /* !mgMgcoIndAudPropParmDtmfGenDef - no properties def for dtmfgen pkg */
   NULLP, /* !mgMgcoIndAudPropParmDtmfDetDef - no properties def for dtmfdet pkg */
   NULLP, /* !mgMgcoIndAudPropParmCpGenDef - no properties def for cpgen  pkg */
   NULLP, /* !mgMgcoIndAudPropParmCpDetDef - no properties def for cpdet pkg */
   NULLP, /* !mgMgcoIndAudPropParmAnalogDef - no properties def for analog pkg */
   NULLP, /* !mgMgcoIndAudPropParmContDef - no properties def for cont pkg */
#ifdef GCP_PKG_MGCO_NETWORK
   &mgMgcoIndAudPropParmNetworkDef,
#else /* !GCP_PKG_MGCO_NETWORK */
   NULLP,
#endif /* GCP_PKG_MGCO_NETWORK */
#ifdef GCP_PKG_MGCO_RTP
   &mgMgcoIndAudPropParmNetworkDef,
#else /* !GCP_PKG_MGCO_RTP */
   NULLP,
#endif /* GCP_PKG_MGCO_RTP */
#ifdef GCP_PKG_MGCO_TDMC
   &mgMgcoIndAudPropParmTdmcDef,
#else /* !GCP_PKG_MGCO_TDMC */
   NULLP,
#endif /* GCP_PKG_MGCO_TDMC */



   NULLP,                                        /* package ID 14 */


#ifdef GCP_PKG_MGCO_TXTCNVR                      /* package ID 15 */
   &mgMgcoIndAudPropParmTxtCnvrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTTELPHONE                  /* package ID 16 */
   &mgMgcoIndAudPropParmTxtTelPhoneDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_CALLTYPDISCR                 /* package ID 17 */
   &mgMgcoIndAudPropParmCallTypDiscrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FAX                          /* package ID 18 */
   &mgMgcoIndAudPropParmFaxDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_IPFAX                        /* package ID 19 */
   &mgMgcoIndAudPropParmIpFaxDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_DISPLAY                      /* package ID 20 */
   &mgMgcoIndAudPropParmDisplayDef,
#else
   NULLP,
#endif

   NULLP, NULLP,                                 /* package IDs 21-22 */

#ifdef GCP_PKG_MGCO_LABELKEY                     /* package ID 23 */
   &mgMgcoIndAudPropParmLabelKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FUNCKEY                      /* package ID 24 */
   &mgMgcoIndAudPropParmFuncKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_INDICATOR                    /* package ID 25 */
   &mgMgcoIndAudPropParmIndicatorDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_SOFTKEY                      /* package ID 26 */
   &mgMgcoIndAudPropParmSoftKeyDef,
#else
   NULLP,
#endif

   /* package IDs 27-29 */
   NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BRR_CHAR                     /* package ID 30 */
   &mgMgcoIndAudPropParm_brr_charDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BNCT                         /* package ID 31 */
   &mgMgcoIndAudPropParm_bnctDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_RI                           /* package ID 32 */
   &mgMgcoIndAudPropParm_riDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package IDs 33 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BRR_CTL_TN                   /* package ID 34 */
   &mgMgcoIndAudPropParm_brr_ctl_tnDef,
#else
   NULLP,
#endif
 
   NULLP,                                        /* package ID 35 */
   NULLP,                                        /* package ID 36 */

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package ID 37 - 41 */
   
   NULLP, NULLP, NULLP,                          /* package IDs  42-44 */

   /* package IDs 45-46 */
   NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GUP
   &mgMgcoIndAudPropParm_tri_gupDef,
#else                                            /* package ID 47 */
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCSD                     /* package ID 48 */
   &mgMgcoIndAudPropParm_tri_gcsdDef,
#else
   NULLP,
#endif                                         

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GTFO                     /* package ID 49 */
   &mgMgcoIndAudPropParm_tri_gtfoDef,
#else
   NULLP,
#endif

   /* package IDs 50 - 52 */   
   NULLP, NULLP, NULLP,

#ifdef GCP_PKG_MGCO_AASRECODING                  /* package ID 53 */
   &mgMgcoIndAudPropParmAasRecodingDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT            /* package ID 54 */
   &mgMgcoIndAudPropParmAdvAuSrvrSegMngmtDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 55 - 63 */
   NULLP, NULLP, NULLP, NULLP,
 
   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_RBS                          /* package ID 64 */
   &mgMgcoIndAudPropParm_rbsDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 65 - 74 */
   NULLP, NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Moved from location 37-41
    */
#ifdef GCP_PKG_MGCO_NAS_SUPPORT                  /* package IDs 75 - 79 */
   &mgMgcoIndAudPropParmNasDef,
   &mgMgcoIndAudPropParmNasInDef,
   &mgMgcoIndAudPropParmNasOutDef,
   NULLP, /* !&mgMgcoIndAudPropParmNasCtlDef, */
   &mgMgcoIndAudPropParmNasRootDef,
#else /* !GCP_PKG_MGCO_NAS_SUPPORT */
   NULLP, NULLP, NULLP, NULLP, NULLP,
#endif /* GCP_PKG_MGCO_NAS_SUPPORT */

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 80 - 103 */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCTM                     /* package ID 104 */
   &mgMgcoIndAudPropParm_tri_gctmDef,                 
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 105 - 112 */
   NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GIPTRA                   /* package ID 113 */
   &mgMgcoIndAudPropParm_tri_giptraDef,
#else
   NULLP,
#endif

   /* [TEL]: Moved from location 36 */
   &mgMgcoIndAudPropParmAllPkgDef,                     /* package ID 114 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,           /* package ID 115 - 120 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 121 - 130 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 131 - 140 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 141 - 150 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 151 - 160 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 161 - 170 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 171 - 180 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 181 - 190 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 191 - 200 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 201 - 210 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 211 - 220 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 221 - 230 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 231 - 124 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 241 - 250 */
   NULLP, NULLP, NULLP,                         /* package ID 250 - 253 */
   &mgMgcoIndAudPropParmUnknownPkgDef,      /* needs to be defined */
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoIndAudPropParmKnownPkgDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudPropParmKnownPkgDefChc =
#endif
{
   MGT_PKG_MAX,
   0,
   NULLP,
   mgMgcoIndAudPropParmKnownPkgDefChcElmnts,
   mgMgcoPkgNameEnum      /* Fills TknU8 with known pkg Id */
};

/* Property parameter  - known package */
PUBLIC CmAbnfElmDef mgMgcoIndAudPropParmKnownPkgDef =
{
#ifdef CM_ABNF_DBG
   "Property parameter - known package",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 285,
   sizeof(TknPkgId) + sizeof(MgMgcoPkgdName),
   ((CM_ABNF_OPTIONAL) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoIndAudPropParmKnownPkgDefChc,
   mgMgcoRegExpPackageName
};

/* Property parameter */
PUBLIC CmAbnfElmDef *mgMgcoIndAudPropParmDefChcElmnts[] =
{
   &mgMgcoPkgdNameDef,/* milton &mgMgcoIndAudPropParmUnknownPkgDef,*/
   &mgMgcoIndAudPropParmKnownPkgDef
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoIndAudPropParmDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudPropParmDefChc =
#endif
{
   2,
   MGT_PKG_MAX,
   mgMgcoPkgChcIdx,
   mgMgcoIndAudPropParmDefChcElmnts,
   mgMgcoPkgChcEnum      /* This doesn't consume TknU8 for known pkgs */
};

PUBLIC CmAbnfElmDef mgMgcoIndAudPropParmDef =
{
#ifdef CM_ABNF_DBG
   "Property parameter",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 286,
   sizeof(TknPkgId) + sizeof(MgMgcoPkgdName),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoIndAudPropParmDefChc,
   mgMgcoRegExpPackageName
};


PUBLIC CmAbnfElmDef *mgMgcoIndAudLclParmDefChcElmnts[] =
{
   NULLP,
   NULLP,
   NULLP,
   &mgMgcoIndAudPropParmDef
};



/*milton PROP PARM ALLLLLLLLLLLLLLLLLLLL*********/

/* IndAudProperty parameter - package "*" */
PUBLIC CmAbnfElmDef *mgMgcoIndAudPropParmAllPkgDefSeqElmnts[]   =
{
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSLASHDef,
   &mgMgcoNAMEDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudPropParmAllPkgDefSeq =
{
   3,
   mgMgcoIndAudPropParmAllPkgDefSeqElmnts
};

/* propertyParm         = pkgdName */
PUBLIC CmAbnfElmDef mgMgcoIndAudPropParmAllPkgDef   =
{
#ifdef CM_ABNF_DBG
   "IndAudProperty parameter - all",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 999,
   sizeof(MgMgcoIndAudStreamParm) - sizeof(TknU8),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudPropParmAllPkgDefSeq,
   NULLP
};

/*milton end of all*/


/************************************************************************/


/************************************************************************/

/************************************************************************/
  /* mg002.105: Added New AudTemStEvtBuf */

PUBLIC CmAbnfElmTypeEnum  mgMgcoIndAudTermStEvBufCtlDefEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
    (Data *)"BF",
#else  /* !GCP_MGCO_SHORT_TOKEN */
    (Data *)"BUFFER",
#endif /* !GCP_MGCO_SHORT_TOKEN */
    MGT_TERMST_EVTBUFCTL
};

PUBLIC CmAbnfElmDef  mgMgcoIndAudTermStEvBufCtlDefEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCO: TERMST BUF CTL DEF ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MGCO_BASE  +  550 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMgcoIndAudTermStEvBufCtlDefEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  mgMgcoIndAudTermStSvcStDefEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
    (Data *)"SI",
#else  /* !GCP_MGCO_SHORT_TOKEN */
    (Data *)"SERVICESTATES",
#endif /* !GCP_MGCO_SHORT_TOKEN */
    MGT_TERMST_SVCST
};

PUBLIC CmAbnfElmDef  mgMgcoIndAudTermStSvcStDefEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCO: TERMST SVCST DEF ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MGCO_BASE  +  551 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMgcoIndAudTermStSvcStDefEnum ,
    NULLP
};


PUBLIC CmAbnfElmDef *mgMgcoIndAudTermStParmChcEnum[] =
{
   &mgMgcoIndAudTermStEvBufCtlDefEnumDef,  /* mg002.105:[RA]: changed */
   &mgMgcoIndAudTermStSvcStDefEnumDef,     /* mg002.105:[RA]: changed */
   &mgMgcoTermStPropParmDefEnumDef,
};

PUBLIC CmAbnfElmDef *mgMgcoIndAudTermStParmChcElmnt[] =
{
    NULLP,
    NULLP,
    &mgMgcoIndAudPropParmDef,      /* event struct is MgMgcoPkgdName */
};

PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudTermStParmChc =
{
    3,
    0,
    NULLP,
    mgMgcoIndAudTermStParmChcElmnt,
    mgMgcoIndAudTermStParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoIndAudTermStParm =
{
#ifdef  CM_ABNF_DBG
    "MGCO: TERMST PARM ",
    "mgMgcoRegExpIndAudTermStParmChoice",
#endif
    CM_ABNF_ELMNID_MGCO_BASE + 553,
    sizeof(MgMgcoIndAudTermStateDesc),
    /* mg002.105:[RA]: removed TKN_NOT_CONSUMED */
    (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET) |
    (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &mgMgcoIndAudTermStParmChc,
    /* mg002.105:[RA]: changed the RE */
    mgMgcoRegExpIndAudTermStParmChoice
};

/* IndAudTermination state descriptor */
PUBLIC CmAbnfElmDef *mgMgcoIndAudTermStDescDefSeqElmnts[]   =
{
   &mgMgcoTerminationStateTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoIndAudTermStParm,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudTermStDescDefSeq =
{
   4,
   mgMgcoIndAudTermStDescDefSeqElmnts
};

/*
 *   indAudterminationStateDescriptor =
 *         TerminationStateToken  LBRKT indAudterminationStateParm RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoIndAudTermStDescDef   =
{
#ifdef CM_ABNF_DBG
   "Termination state descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */ 
   CM_ABNF_ELMNID_MGCO_BASE + 396,
   sizeof(MgMgcoIndAudTermStateDesc),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudTermStDescDefSeq,
   NULLP
};



/************************************************************************/

/* IndAudMedia parameter */

PUBLIC CmAbnfElmDef *mgMgcoIndAudMediaParDefChcEnum[] =
{
   &mgMgcoMediaParLclCtlDescDefEnumDef,
   NULLP,      /* no such thing as indAudLocalDescriptor */
   NULLP,      /* no such thing as indAudRemoteDescriptor */
   &mgMgcoMediaParStreamDescDefEnumDef,
   &mgMgcoMediaParTermStDescDefEnumDef
};


/************************************************************************/



/*-----------END: indAudmediaDescriptor---------------------------------*/


/*-----------BEGIN: indAudSignalsDescriptor-----------------------------*/

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoIndAudSignalKnownPkgDefChcElmnts[] =
{
   NULLP,
   /* mg005.105: changed unknown package id from 0 to 255
    *         ASN Annex C uses package id 0
    *         &mgMgcoIndAudSignalUnknownPkgDef,      */
   NULLP,   /* Generic */
   NULLP,   /* Root */
#ifdef GCP_PKG_MGCO_TONEGEN
   &mgMgcoIndAudSignalToneGenDef,
#else /* !GCP_PKG_MGCO_TONEGEN */
   NULLP,
#endif /* GCP_PKG_MGCO_TONEGEN */
   NULLP,   /* ToneDet */
#ifdef GCP_PKG_MGCO_DTMFGEN
   &mgMgcoIndAudSignalDtmfGenDef,
#else /* !GCP_PKG_MGCO_DTMFGEN */
   NULLP,
#endif /* GCP_PKG_MGCO_DTMFGEN */
   NULLP,   /* DtmfDet */
#ifdef GCP_PKG_MGCO_CPGEN
   &mgMgcoIndAudSignalCpGenDef,
#else /* !GCP_PKG_MGCO_CPGEN */
   NULLP,
#endif /* GCP_PKG_MGCO_CPGEN */
   NULLP,   /* CpDet */
#ifdef GCP_PKG_MGCO_ANALOG
   &mgMgcoIndAudSignalAnalogDef,
#else /* !GCP_PKG_MGCO_ANALOG */
   NULLP,
#endif /* GCP_PKG_MGCO_ANALOG */
#ifdef GCP_PKG_MGCO_CONT
   &mgMgcoIndAudSignalContDef,
#else /* !GCP_PKG_MGCO_CONT */
   NULLP,
#endif /* GCP_PKG_MGCO_CONT */
   NULLP,   /* Network */
   NULLP,   /* Rtp */
   NULLP,   /* Tdmc */




   NULLP, NULLP, NULLP,                          /* package IDs 14-16 */


#ifdef GCP_PKG_MGCO_CALLTYPDISCR                 /* package ID 17 */
   &mgMgcoIndAudSignalCallTypDiscrDef,
#else
   NULLP,
#endif

   NULLP, NULLP,                                 /* package IDs 18-19 */

#ifdef GCP_PKG_MGCO_DISPLAY                      /* package ID 20 */
   &mgMgcoIndAudSignalDisplayDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 21-24 */

#ifdef GCP_PKG_MGCO_INDICATOR                    /* package ID 25 */
   &mgMgcoIndAudSignalIndicatorDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_SOFTKEY                      /* package ID 26 */
   &mgMgcoIndAudSignalSoftKeyDef,
#else
   NULLP,
#endif

   /* package IDs 27-28 */
   NULLP, NULLP,

#ifdef GCP_PKG_MGCO_GENANNC                      /* package ID 29 */
   &mgMgcoIndAudSignalGenAnncDef,
#else
   NULLP,
#endif

   /* package IDs 30-32 */
   NULLP, NULLP, NULLP,
   
   /*
    * [TEL]: Changed from NULLP
    */   
#ifdef GCP_PKG_MGCO_GEN_BRR_CON                  /* package ID 33 */
   &mgMgcoIndAudSignal_gen_brr_conDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BRR_CTL_TN                   /* package ID 34 */
   &mgMgcoIndAudSignal_brr_ctl_tnDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BSC_CAL_TN                   /* package ID 35 */
   &mgMgcoIndAudSignal_bsc_cal_tnDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_XD_CALPG_TNGN                /* package ID 36 */
   &mgMgcoIndAudSignal_xd_calpg_tngnDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BSC_SRV_TN                   /* package ID 37 */
   &mgMgcoIndAudSignal_bsc_srv_tnDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_XD_SRV_TNGN                  /* package ID 38 */
   &mgMgcoIndAudSignal_xd_srv_tngnDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_INT_TNGN                     /* package ID 39 */
   &mgMgcoIndAudSignal_int_tngnDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BSNS_TNGN                    /* package ID 40 */
   &mgMgcoIndAudSignal_bsns_tngnDef,
#else
   NULLP,
#endif

   /* package IDs 41-47 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */   
#ifdef GCP_PKG_MGCO_TRI_GCSD                     /* package ID 48 */
   &mgMgcoIndAudSignal_tri_gcsdDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 49 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRIG_XD_CALPG_TNGN           /* package ID 50 */
   &mgMgcoIndAudSignal_trig_xd_calpg_tngnDef,
#else
   NULLP,
#endif                               

#ifdef GCP_PKG_MGCO_ADVAUSRVRBASE                /* package ID 51 */
   &mgMgcoIndAudSignalAdvAuSrvrBaseDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASDIGCOLLECT                /* package ID 52 */
   &mgMgcoIndAudSignalAasDigCollectDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASRECODING                  /* package ID 53 */
   &mgMgcoIndAudSignalAasRecodingDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT            /* package ID 54 */
   &mgMgcoIndAudSignalAdvAuSrvrSegMngmtDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 55 */
   
   /*
    * [TEL]: Changed from NULLP
    */   
#ifdef GCP_PKG_MGCO_TRIG_FLEX_TN                 /* package ID 56 */
   &mgMgcoIndAudSignal_trig_flex_tnDef,
#else
   NULLP,
#endif

   /* package IDs 57 - 62 */
   NULLP, NULLP, NULLP, 
   NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */   
#ifdef GCP_PKG_MGCO_BCAS                         /* package ID 63 */
       &mgMgcoIndAudSignal_bcasDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_RBS                          /* package ID 64 */
   &mgMgcoIndAudSignal_rbsDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OSES                         /* package ID 65 */
   &mgMgcoIndAudSignal_osesDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OSEXT                        /* package ID 66 */
   &mgMgcoIndAudSignal_osextDef,
#else
   NULLP,
#endif 

   NULLP,                                        /* package ID 67 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BCASADDR                     /* package ID 68 */
   &mgMgcoIndAudSignal_bcasaddrDef,
#else
   NULLP,
#endif

   /* package IDs 69 - 74 */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP,

   /*
    * [TEL]: Moved from location 37-41
    * package IDs 75 - 79
    */   
   NULLP, NULLP, NULLP, NULLP, NULLP, /* NAS - no signals for
                                         GCP_PKG_MGCO_NAS_SUPPORT */

   /* package IDs 80 - 82 */
   NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */   
#ifdef GCP_PKG_MGCO_QT_TM_LTC                    /* package ID 83 */
   &mgMgcoIndAudSignal_qt_tm_ltcDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_LP_BK_LTR                    /* package ID 84 */
   &mgMgcoIndAudSignal_lp_bk_ltrDef,
#else 
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_404                   /* Package ID 85 */
   &mgMgcoIndAudSignal_itu_lt_404Def,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_816                   /* Package ID 86 */
   &mgMgcoIndAudSignal_itu_lt_816Def,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_1020                  /* Package ID 87 */
   &mgMgcoIndAudSignal_itu_lt_1020Def,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_DIST                  /* package ID 88 */ 
   &mgMgcoIndAudSignal_itu_lt_distDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_DSEC                  /* package ID 89 */ 
   &mgMgcoIndAudSignal_itu_lt_dsecDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_2804                  /* package ID 90 */
   &mgMgcoIndAudSignal_itu_lt_2804Def,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_NTT                   /* package ID 91 */ 
   &mgMgcoIndAudSignal_itu_lt_nttDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_DPRT                  /* package ID 92 */ 
   &mgMgcoIndAudSignal_itu_lt_dprtDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_ATME2                 /* package ID 93 */
   &mgMgcoIndAudSignal_itu_lt_atme2Def,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_1004                 /* package IDs 94 */
   &mgMgcoIndAudSignal_ansi_lt_1004Def,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_TR                   /* package ID 95 */ 
   &mgMgcoIndAudSignal_ansi_lt_trDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_2225                 /* package ID 96 */
   &mgMgcoIndAudSignal_ansi_lt_2225Def,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_DTS                  /* package ID 97 */
   &mgMgcoIndAudSignal_ansi_lt_dtsDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ANSI_IN_LTR                  /* package ID 98 */ 
   &mgMgcoIndAudSignal_ansi_in_ltrDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 99 - 113 */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   
   /* [TEL]: Moved from location 36 */
   &mgMgcoIndAudSignalAllDef,                          /* package ID 114 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,           /* package ID 115 - 120 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 121 - 130 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 131 - 140 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 141 - 150 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 151 - 160 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 161 - 170 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 171 - 180 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 181 - 190 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 191 - 200 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 201 - 210 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 211 - 220 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 221 - 230 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 231 - 124 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 241 - 250 */
   NULLP, NULLP, NULLP,                         /* package ID 250 - 253 */
   &mgMgcoIndAudSignalUnknownPkgDef,      
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoIndAudSignalKnownPkgDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudSignalKnownPkgDefChc =
#endif
{
   MGT_PKG_MAX,
   0,
   NULLP,
   mgMgcoIndAudSignalKnownPkgDefChcElmnts,
   mgMgcoPkgNameEnum      /* Fills TknU8 with known pkg Id */
};

PUBLIC CmAbnfElmDef mgMgcoIndAudSignalKnownPkgDef =
{
#ifdef CM_ABNF_DBG
   "Signal - known package",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 379,
   sizeof(MgMgcoSigName),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoIndAudSignalKnownPkgDefChc,
   mgMgcoRegExpPackageName
};

/************************************************************************/

/* milton signal ALLLLLLLLLLLLLLLLLLLLLLLL************/

PUBLIC CmAbnfElmDef *mgMgcoIndAudSignalAllDefSeqElmnts[] =
{
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSLASHDef,
   &mgMgcoNAMEDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudSignalAllDefSeq =
{
   3,
   mgMgcoIndAudSignalAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoIndAudSignalAllDef =
{
#ifdef CM_ABNF_DBG
   "IndAudSignal - all",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 999,
   sizeof(MgMgcoSigName) - sizeof(TknU8),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudSignalAllDefSeq,
   NULLP
};
/* milton - end of alll */

PUBLIC CmAbnfElmDef *mgMgcoIndAudSigDescParmSigReqDefChcElmnts[] =
{
   &mgMgcoPkgdNameDef,/* milton &mgMgcoIndAudSignalUnknownPkgDef, */
   &mgMgcoIndAudSignalKnownPkgDef
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoIndAudSigDescParmSigReqDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudSigDescParmSigReqDefChc =
#endif
{
   2,
   MGT_PKG_MAX,
   mgMgcoPkgChcIdx,
   mgMgcoIndAudSigDescParmSigReqDefChcElmnts,
   mgMgcoPkgChcEnum      /* This doesn't consume TknU8 for known pkgs */
};

PUBLIC CmAbnfElmDef mgMgcoIndAudSigDescParmSigReqDef =
{
#ifdef CM_ABNF_DBG
   "Signal request",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 380,
   sizeof(MgMgcoSigName),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoIndAudSigDescParmSigReqDefChc,
   mgMgcoRegExpPackageName
};


/* Signal list */
PUBLIC CmAbnfElmDef *mgMgcoIndAudSigDescParmSigLstDefSeqElmnts[]   =
{
   &mgMgcoSignalListTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoSigLstIdDef,
   &mgMgcoLBRKTDef,
   &mgMgcoIndAudSigDescParmSigReqDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudSigDescParmSigLstDefSeq =
{
   6,
   mgMgcoIndAudSigDescParmSigLstDefSeqElmnts
};

/*
 *   indAudsignalList = SignalListToken EQUAL signalListId  
 *                      LBRKT indAudsignalListParm RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoIndAudSigDescParmSigLstDef   =
{
#ifdef CM_ABNF_DBG
   "Signal list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 383,
   sizeof(MgMgcoIndAudSigLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudSigDescParmSigLstDefSeq,
   NULLP
};

/************************************************************************/

/* Signal descriptor parameter */
PUBLIC CmAbnfElmDef *mgMgcoIndAudSigDescParmDefChcEnum[]   =
{
   &mgMgcoSigDescParmSigLstDefEnumDef,
   &mgMgcoSigDescParmSigReqDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoIndAudSigDescParmDefChcElmnts[]   =
{
   &mgMgcoIndAudSigDescParmSigLstDef,
   &mgMgcoIndAudSigDescParmSigReqDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudSigDescParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoIndAudSigDescParmDefChcElmnts,
   mgMgcoIndAudSigDescParmDefChcEnum
};

/* indAudsignalParm = indAudsignalList / indAudsignalRequest  */
PUBLIC CmAbnfElmDef mgMgcoIndAudSigDescParmDef   =
{
#ifdef CM_ABNF_DBG
   "Signal descriptor parameter",
   "SigDescParm",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 384,
   sizeof(MgMgcoIndAudSignals),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoIndAudSigDescParmDefChc,
   mgMgcoRegExpSigDescParm
};


/* IndAudSignals descriptor */
PUBLIC CmAbnfElmDef *mgMgcoIndAudSignalsDescDefSeqElmnts[]   =
{
   /*milton &mgMgcoSignalsTokenDef,*/
   &mgMgcoLBRKTDef,
   &mgMgcoIndAudSigDescParmDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudSignalsDescDefSeq =
{
   3,
   mgMgcoIndAudSignalsDescDefSeqElmnts
};

/*
 *   indAudsignalsDescriptor = SignalsToken  
 *                             LBRKT [ indAudsignalParm ] RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoIndAudSignalsDescDef   =
{
#ifdef CM_ABNF_DBG
   "IndAudSignals descriptor",
   "SignalsToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 388,
   sizeof(MgMgcoIndAudSignals),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudSignalsDescDefSeq,
   NULLP /* milton mgMgcoRegExpSignalsToken */
};

/*-----------END: indAudSignalsDescriptor-------------------------------*/



/*-----------BEGIN: indAudStatisticsDescriptor--------------------------*/

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoIndAudStatsParKnownPkgDefChcElmnts[] =
{
   NULLP,
   /* mg005.105: changed unknown package id from 0 to 255
    *         ASN Annex C uses package id 0
    *         &mgMgcoIndAudStatsParUnknownPkgDef,    */
   NULLP,   /* Generic */
   NULLP,   /* Root */
   NULLP,   /* ToneGen */
   NULLP,   /* ToneDet */
   NULLP,   /* DtmfGen */
   NULLP,   /* DtmfDet */
   NULLP,   /* CpGen */
   NULLP,   /* CpDet */
   NULLP,   /* Analog */
   NULLP,   /* Cont */
#ifdef GCP_PKG_MGCO_NETWORK
   &mgMgcoIndAudStatsParNetworkDef,
#else /* !GCP_PKG_MGCO_NETWORK */
   NULLP,
#endif /* GCP_PKG_MGCO_NETWORK */
#ifdef GCP_PKG_MGCO_RTP
   &mgMgcoIndAudStatsParRtpDef,
#else /* !GCP_PKG_MGCO_RTP */
   NULLP,
#endif /* GCP_PKG_MGCO_RTP */
#ifdef GCP_PKG_MGCO_TDMC
   &mgMgcoIndAudStatsParNetworkDef,
#else /* !GCP_PKG_MGCO_TDMC */
   NULLP,
#endif /* GCP_PKG_MGCO_TDMC */


   NULLP,                                        /* package ID 14 */

#ifdef GCP_PKG_MGCO_TXTCNVR                      /* package ID 15 */
   &mgMgcoIndAudStatParmTxtCnvrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTTELPHONE                  /* package ID 16 */
   &mgMgcoIndAudStatParmTxtTelPhoneDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 17 */

#ifdef GCP_PKG_MGCO_FAX                          /* package ID 18 */
   &mgMgcoIndAudStatParmFaxDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_IPFAX                        /* package ID 19 */
   &mgMgcoIndAudStatParmIpFaxDef,
#else
   NULLP,
#endif


   /* package IDs 20-35 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
 
   NULLP,                                        /* package ID 36 */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP,                          /* package IDs 42-103 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCTM                     /* package ID 104 */
   &mgMgcoIndAudStatParm_tri_gctmDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 105 - 113 */
   NULLP, NULLP, NULLP, NULLP,

   /* [TEL]: Moved from location 36 */
   &mgMgcoIndAudStatsParAllDef,                        /* package ID 114 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,           /* package ID 115 - 120 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 121 - 130 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 131 - 140 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 141 - 150 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 151 - 160 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 161 - 170 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 171 - 180 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 181 - 190 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 191 - 200 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 201 - 210 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 211 - 220 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 221 - 230 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 231 - 124 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 241 - 250 */
   NULLP, NULLP, NULLP,                         /* package ID 250 - 253 */
   &mgMgcoIndAudStatsParUnknownPkgDef,   
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoIndAudStatsParKnownPkgDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudStatsParKnownPkgDefChc =
#endif
{
   MGT_PKG_MAX,
   0,
   NULLP,
   mgMgcoIndAudStatsParKnownPkgDefChcElmnts,
   mgMgcoPkgNameEnum      /* Fills TknU8 with known pkg Id */
};

PUBLIC CmAbnfElmDef mgMgcoIndAudStatsParKnownPkgDef =
{
#ifdef CM_ABNF_DBG
   "IndAudStatistics parameter",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 408,
   sizeof(MgMgcoSigName),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoIndAudStatsParKnownPkgDefChc,
   mgMgcoRegExpPackageName
};

/************************************************************************/

/* milton indaudstatspar all def **********************/


PUBLIC CmAbnfElmDef *mgMgcoIndAudStatsParAllDefSeqElmnts[] =
{
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSLASHDef,
   &mgMgcoNAMEDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudStatsParAllDefSeq =
{
   3,
   mgMgcoIndAudStatsParAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoIndAudStatsParAllDef =
{
#ifdef CM_ABNF_DBG
   "IndAudStatistics parameter - all",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 999,
   sizeof(MgMgcoSigName) - sizeof(TknU8),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudStatsParAllDefSeq,
   NULLP
};

/* milton end all stats */



PUBLIC CmAbnfElmDef *mgMgcoIndAudStatsParDefChcElmnts[] =
{
   &mgMgcoPkgdNameDef,/* milton &mgMgcoIndAudStatsParUnknownPkgDef,*/   
   &mgMgcoIndAudStatsParKnownPkgDef
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoIndAudStatsParDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudStatsParDefChc =
#endif
{
   2,
   MGT_PKG_MAX,
   mgMgcoPkgChcIdx,
   mgMgcoIndAudStatsParDefChcElmnts,
   mgMgcoPkgChcEnum      /* This doesn't consume TknU8 for known pkgs */
};

PUBLIC CmAbnfElmDef mgMgcoIndAudStatsParDef =
{
#ifdef CM_ABNF_DBG
   "IndAudStatistics parameter",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 409,
   sizeof(MgMgcoSigName),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoIndAudStatsParDefChc,
   mgMgcoRegExpPackageName
};


/* Statistics descriptor */
PUBLIC CmAbnfElmDef *mgMgcoIndAudStatsDescDefSeqElmnts[]   =
{
   /*milton &mgMgcoStatsTokenDef, */
   &mgMgcoLBRKTDef,
   &mgMgcoIndAudStatsParDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudStatsDescDefSeq =
{
   3,
   mgMgcoIndAudStatsDescDefSeqElmnts
};

/*
 *   indAudstatisticsDescriptor = StatsToken LBRKT pkgdName RBRKT 
 */
PUBLIC CmAbnfElmDef mgMgcoIndAudStatsDescDef   =
{
#ifdef CM_ABNF_DBG
   "IndAudStatistics descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 412,
   sizeof(MgMgcoSigName),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudStatsDescDefSeq,
   NULLP
};

/*-----------END: indAudStatisticsDescriptor----------------------------*/



/*-----------BEGIN: indAudDigitMapDescriptor----------------------------*/

/* IndAud Digit map descriptor */
PUBLIC CmAbnfElmDef *mgMgcoIndAudDigMapDescDefSeqElmnts[] =
{
   /* milton &mgMgcoDigitMapTokenDef, */
   &mgMgcoEQUALDef,
   &mgMgcoNAMEDef,
};

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudDigMapDescDefSeq =
{
   2,
   mgMgcoIndAudDigMapDescDefSeqElmnts
};

/*
 *   indAuddigitMapDescriptor = DigitMapToken EQUAL (digitMapName ) 
 */
PUBLIC CmAbnfElmDef mgMgcoIndAudDigMapDescDef =
{
#ifdef CM_ABNF_DBG
   "IndAud Digit map descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 443,
   sizeof(MgMgcoName),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudDigMapDescDefSeq,
   NULLP
};

/*-----------END: indAudDigitMapDescriptor------------------------------*/


/*-----------BEGIN: indAudEventsDescriptor------------------------------*/

PUBLIC CmAbnfElmDef *mgMgcoIndAudReqEvtKnownPkgDefChcElmnts[] =
{
   NULLP,
   /* mg005.105: changed unknown package id from 0 to 255
    *         ASN Annex C uses package id 0
    *         &mgMgcoIndAudReqEvtUnknownPkgDef,      */
#ifdef GCP_PKG_MGCO_GENERIC
   &mgMgcoIndAudReqEvtGenericDef,
#else /* !GCP_PKG_MGCO_GENERIC */
   NULLP,
#endif /* GCP_PKG_MGCO_GENERIC */
   NULLP,
   NULLP,
#ifdef GCP_PKG_MGCO_TONEDET
   &mgMgcoIndAudReqEvtToneDetDef,
#else /* !GCP_PKG_MGCO_TONEDET */
   NULLP,
#endif /* GCP_PKG_MGCO_TONEDET */
   NULLP,
#ifdef GCP_PKG_MGCO_DTMFDET
   &mgMgcoIndAudReqEvtDtmfDetDef,
#else /* !GCP_PKG_MGCO_DTMFDET */
   NULLP,
#endif /* GCP_PKG_MGCO_DTMFDET */
   NULLP,
#ifdef GCP_PKG_MGCO_CPDET 
   &mgMgcoIndAudReqEvtCpDetDef,
#else /* !GCP_PKG_MGCO_CPDET */
   NULLP,
#endif /* GCP_PKG_MGCO_CPDET */
#ifdef GCP_PKG_MGCO_ANALOG
   &mgMgcoIndAudReqEvtAnalogDef,
#else /* !GCP_PKG_MGCO_ANALOG */
   NULLP,
#endif /* GCP_PKG_MGCO_ANALOG */
#ifdef GCP_PKG_MGCO_CONT
   &mgMgcoIndAudReqEvtContDef,
#else /* !GCP_PKG_MGCO_CONT */
   NULLP,
#endif /* GCP_PKG_MGCO_CONT */
#ifdef GCP_PKG_MGCO_NETWORK
   &mgMgcoIndAudReqEvtNetworkDef,
#else /* !GCP_PKG_MGCO_NETWORK */
   NULLP,
#endif /* GCP_PKG_MGCO_NETWORK */
#ifdef GCP_PKG_MGCO_RTP
   &mgMgcoIndAudReqEvtRtpDef,
#else /* !GCP_PKG_MGCO_RTP */
   NULLP,
#endif /* GCP_PKG_MGCO_RTP */
#ifdef GCP_PKG_MGCO_TDMC
   &mgMgcoIndAudReqEvtNetworkDef,
#else /* !GCP_PKG_MGCO_TDMC */
   NULLP,
#endif /* GCP_PKG_MGCO_TDMC */


#ifdef GCP_PKG_MGCO_FAXTONEDET                   /* package ID 14 */
   &mgMgcoIndAudReqEvtFaxToneDetDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTCNVR                      /* package ID 15 */
   &mgMgcoIndAudReqEvtTxtCnvrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTTELPHONE                  /* package ID 16 */
   &mgMgcoIndAudReqEvtTxtTelPhoneDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_CALLTYPDISCR                 /* package ID 17 */
   &mgMgcoIndAudReqEvtCallTypDiscrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FAX                          /* package ID 18 */
   &mgMgcoIndAudReqEvtFaxDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_IPFAX                        /* package ID 19 */
   &mgMgcoIndAudReqEvtIpFaxDef,
#else
   NULLP,
#endif

   NULLP,                                        /* no events in pkg ID 20 */

#ifdef GCP_PKG_MGCO_KEY                          /* package ID 21 */
   &mgMgcoIndAudReqEvtKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_KEYPAD                       /* package ID 22 */
   &mgMgcoIndAudReqEvtKeyPadDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_LABELKEY                     /* package ID 23 */
   &mgMgcoIndAudReqEvtLabelKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_FUNCKEY                      /* package ID 24 */
   &mgMgcoIndAudReqEvtFuncKeyDef,
#else
   NULLP,
#endif

   NULLP,                                        /* no events in pkg ID 25 */

#ifdef GCP_PKG_MGCO_SOFTKEY                      /* package ID 26 */
   &mgMgcoIndAudReqEvtSoftKeyDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_ANCILLARYINPUT               /* package ID 27 */
   &mgMgcoIndAudReqEvtAncillaryInputDef,
#else
   NULLP,
#endif

/* package IDs 28-32 */
   NULLP, NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_GEN_BRR_CON                  /* package ID 33 */
   &mgMgcoIndAudReqEvt_gen_brr_conDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BRR_CTL_TN                   /* package ID 34 */
   &mgMgcoIndAudReqEvt_brr_ctl_tnDef,
#else
   NULLP,
#endif
 
   NULLP,                                        /* package ID 35 */
   NULLP,                                        /* package ID 36 */

   NULLP,                                        /* package ID 37 */ 
   NULLP,                                        /* package ID 38 */
   NULLP,                                        /* package ID 39 */
   NULLP,                                        /* package ID 40 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_CHP                          /* package ID 41 */
   &mgMgcoIndAudReqEvt_CHPDef,
#else
   NULLP,
#endif

     /* package IDs 42-47 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCSD                     /* package ID 48 */
   &mgMgcoIndAudReqEvt_tri_gcsdDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GTFO                     /* package ID 49 */
   &mgMgcoIndAudReqEvt_tri_gtfoDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 50 */ 

#ifdef GCP_PKG_MGCO_ADVAUSRVRBASE                /* package ID 51 */
   &mgMgcoIndAudReqEvtAdvAuSrvrBaseDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASDIGCOLLECT                /* package ID 52 */
   &mgMgcoIndAudReqEvtAasDigCollectDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_AASRECODING                  /* package ID 53 */
   &mgMgcoIndAudReqEvtAasRecodingDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 54 */
   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 55 - 62 */
   NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BCAS                         /* package ID 63 */
   &mgMgcoIndAudReqEvt_bcasDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_RBS                          /* package ID 64 */
   &mgMgcoIndAudReqEvt_rbsDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OSES                         /* package ID 65 */
   &mgMgcoIndAudReqEvt_osesDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OSEXT                        /* package ID 66 */
   &mgMgcoIndAudReqEvt_osextDef,
#else
   NULLP,
#endif
 
   NULLP,                                        /* package ID 67 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BCASADDR                     /* package ID 68 */
   &mgMgcoIndAudReqEvt_bcasaddrDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_INACTTIMER                   /* package ID 69 */
   &mgMgcoIndAudReqEvt_inacttimerDef,
#else
   NULLP,
#endif

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GMLC                     /* package ID 70 */
   &mgMgcoIndAudReqEvt_tri_gmlcDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 71 - 74 */

   /*
    * [TEL]: Moved from location 37-41 
    */
#ifdef GCP_PKG_MGCO_NAS_SUPPORT                  /* package IDs 75 - 79 */ 
   &mgMgcoIndAudReqEvtNasDef,
   &mgMgcoIndAudReqEvtNasInDef,
   &mgMgcoIndAudReqEvtNasDef, /* for nasout */
   &mgMgcoIndAudReqEvtNasCtlDef,
   NULLP, /* !mgMgcoIndAudReqEvtNasRootDef */
#else /* !GCP_PKG_MGCO_NAS_SUPPORT */
   NULLP, NULLP, NULLP, NULLP, NULLP,
#endif /* GCP_PKG_MGCO_NAS_SUPPORT */

 
   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 80 - 103 */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCTM                     /* package ID 104 */
   &mgMgcoIndAudReqEvt_tri_gctmDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* Package IDs 105 - 113 */
   NULLP, NULLP, NULLP, NULLP,

   /* [TEL]: Moved from location 36 */
   &mgMgcoIndAudReqEvtAllDef,                    /* package ID 114 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,           /* package ID 115 - 120 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 121 - 130 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 131 - 140 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 141 - 150 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 151 - 160 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 161 - 170 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 171 - 180 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 181 - 190 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 191 - 200 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 201 - 210 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 211 - 220 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 221 - 230 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 231 - 124 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 241 - 250 */
   NULLP, NULLP, NULLP,                         /* package ID 250 - 253 */
   &mgMgcoIndAudReqEvtUnknownPkgDef,
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoIndAudReqEvtKnownPkgDefChc = 
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudReqEvtKnownPkgDefChc = 
#endif
{
   MGT_PKG_MAX,
   0,
   NULLP,
   mgMgcoIndAudReqEvtKnownPkgDefChcElmnts,
   mgMgcoPkgNameEnum      /* Fills TknU8 with known pkg Id */
};

PUBLIC CmAbnfElmDef mgMgcoIndAudReqEvtKnownPkgDef =
{
#ifdef CM_ABNF_DBG
   "IndAudEvent - known package",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 347,
   sizeof(TknPkgId) + sizeof(MgMgcoPkgdName),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoIndAudReqEvtKnownPkgDefChc,
   mgMgcoRegExpPackageName
};

/************************************************************************/

/* milton - indaudeventrequests for ALLLLLLLLL **************/
/* mgMgcoIndAudReqEvtAllDef */
PUBLIC CmAbnfElmDef *mgMgcoIndAudReqEvtAllDefSeqElmnts[] =
{
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSLASHDef,
   &mgMgcoNAMEDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudReqEvtAllDefSeq =
{
   3,
   mgMgcoIndAudReqEvtAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoIndAudReqEvtAllDef =
{
#ifdef CM_ABNF_DBG
   "Event - all",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 999,
   sizeof(MgMgcoIndAudEvents) - sizeof(TknU8),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudReqEvtAllDefSeq,
   NULLP
};
/*milton - end of allll */

PUBLIC CmAbnfElmDef *mgMgcoIndAudReqEvtDefChcElmnts[] =
{
   &mgMgcoPkgdNameDef,/* milton &mgMgcoIndAudReqEvtUnknownPkgDef,*/ 
   &mgMgcoIndAudReqEvtKnownPkgDef
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoIndAudReqEvtDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudReqEvtDefChc =
#endif
{
   2,
   MGT_PKG_MAX,
   mgMgcoPkgChcIdx,
   mgMgcoIndAudReqEvtDefChcElmnts,
   mgMgcoPkgChcEnum      /* This doesn't consume TknU8 for known pkgs */
};

PUBLIC CmAbnfElmDef mgMgcoIndAudReqEvtDef =
{
#ifdef CM_ABNF_DBG
   "IndAudEvent",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 348,
   sizeof(TknPkgId) + sizeof(MgMgcoPkgdName),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoIndAudReqEvtDefChc,
   mgMgcoRegExpPackageName
};


PUBLIC CmAbnfElmDef *mgMgcoIndAudReqEvtDescDefSeqElmnts[]   =
{
   /*milton6 &mgMgcoEventsTokenDef,*/
   &mgMgcoEQUALDef,
   &mgMgcoRequestIdDef,
   &mgMgcoLBRKTDef,
   &mgMgcoIndAudReqEvtDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudReqEvtDescDefSeq =
{
   5,/*milton6 */
   mgMgcoIndAudReqEvtDescDefSeqElmnts
};

/*
 * indAudeventsDescriptor = EventsToken EQUAL RequestID
 *                          LBRKT indAudrequestedEvent RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoIndAudReqEvtDescDef   =
{
#ifdef CM_ABNF_DBG
   "IndAudEvents descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 457,
   sizeof(MgMgcoIndAudEvents),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoIndAudReqEvtDescDefSeq,
   NULLP
};

/*-----------END: indAudEventsDescriptor--------------------------------*/


/*           END:   indAud items                                        */
/************************************************************************/

#endif /* MGT_MGCO_V2 */





/************************************************************************/

/* Audit item */
PUBLIC CmAbnfElmDef *mgMgcoAuditItemDefChcEnum[]   =
{
   NULLP, /* No error token */
   &mgMgcoMediaDescEnum,
   &mgMgcoModemDescEnum,
   &mgMgcoMuxDescEnum,
   &mgMgcoReqEvtDescEnum,
   &mgMgcoEvBufDescEnum,
   &mgMgcoSignalsDescEnum,
   &mgMgcoDigMapDescEnum,
   &mgMgcoObsEvtDescEnum,
   &mgMgcoStatsDescEnum,
   &mgMgcoPkgsDescEnum,
   NULLP, /* No audit either */
#ifdef    MGT_MGCO_V2
   &mgMgcoIndAudTermAuditDescEnum
#endif /* MGT_MGCO_V2 */
};


#ifdef    MGT_MGCO_V2

PUBLIC CmAbnfElmDef *mgMgcoAuditItemDefChcElmnts[] =
{
   NULLP,
   &mgMgcoAuditItemIndAudTermDef
};

PUBLIC U8 mgMgcoAuditItemDefChcIdx[] = { 0, 0, 0, 0, 0,
                                         0, 0, 0, 0, 0,
                                         0, 0, 1 };

PUBLIC CmAbnfElmTypeChoice mgMgcoAuditItemDefChc =
{
   2,
   13,
   mgMgcoAuditItemDefChcIdx,
   mgMgcoAuditItemDefChcElmnts,
   mgMgcoAuditItemDefChcEnum
};

#else  /* MGT_MGCO_V2 */

PUBLIC CmAbnfElmTypeChoice mgMgcoAuditItemDefChc =
{
   12,
   0,
   NULLP,
   NULLP,
   mgMgcoAuditItemDefChcEnum
};

#endif /* MGT_MGCO_V2 */



/* auditItem            = (MuxToken / ModemToken / MediaToken /  SignalsToken /
 *                         EventBufferToken / DigitMapToken / StatsToken / 
 *                         EventsToken / ObservedEventsToken / PackagesToken /
 *                         indAudterminationAudit (for V2 only))
 */
PUBLIC CmAbnfElmDef mgMgcoAuditItemDef   =
{
#ifdef CM_ABNF_DBG
   "Audit item",
   "Desc",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 397,
   sizeof(MgMgcoAuditItem),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoAuditItemDefChc,
/* mg003.105: Modify - Change for the backward compatibility */
#ifdef MGT_MGCO_V2   
   mgMgcoRegExpDescTermAud /* Milton - new regex function*/
#else   
   mgMgcoRegExpDesc
#endif /* MGT_MGCO_V2 */
};

/************************************************************************/

/* Audit item array */
PUBLIC CmAbnfElmDef *mgMgcoAuditItemArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoAuditItemDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoAuditItemArrayDefSeqOf =
{
   1,
   MGT_MAX_AUDS,
   2,
   mgMgcoAuditItemArrayDefSeqOfElmnts,
   /* mg002.105: [RA]: changed from sizeof(TknU8) */
   sizeof(MgMgcoAuditItem)
};

/* *(COMMA auditItem) */
PUBLIC CmAbnfElmDef mgMgcoAuditItemArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Audit item array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 398,
   sizeof(MgMgcoAuditDesc) - sizeof(TknPres),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoAuditItemArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Audit item list */
PUBLIC CmAbnfElmDef *mgMgcoAuditItemLstDefSeqElmnts[]   =
{
   &mgMgcoAuditItemDef,
   &mgMgcoAuditItemArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoAuditItemLstDefSeq =
{
   2,
   mgMgcoAuditItemLstDefSeqElmnts
};

/* [ auditItem *(COMMA auditItem) ] */
PUBLIC CmAbnfElmDef mgMgcoAuditItemLstDef   =
{
#ifdef CM_ABNF_DBG
   "Audit item list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 399,
   sizeof(MgMgcoAuditDesc) - sizeof(TknPres),
   /* mg002.105: TKN_NOT_CONSUMED added so that the RE does not eat up stuff */
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED)
                  << CM_ABNF_PROT_MEGACO_DEF_OFFSET) |
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED)
                  << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoAuditItemLstDefSeq,
   mgMgcoRegExpAlphaNum      /* mg002.105: added RE to see if elm pres? */
};


/************************************************************************/

/* Audit descriptor */
PUBLIC CmAbnfElmDef *mgMgcoAuditDescDefSeqElmnts[]   =
{
   &mgMgcoAuditTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoAuditItemLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoAuditDescDefSeq =
{
   4,
   mgMgcoAuditDescDefSeqElmnts
};

/* auditDescriptor = AuditToken LBRKT [ auditItem *(COMMA auditItem) ] RBRKT */
PUBLIC CmAbnfElmDef mgMgcoAuditDescDef   =
{
#ifdef CM_ABNF_DBG
   "Audit descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 400,
   sizeof(MgMgcoAuditDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,     /* Changed;it was CM_ABNF_TYPE_OPTSEQ */
   (U8 *)&mgMgcoAuditDescDefSeq,
   NULLP
};

/************************************************************************/
/* Name in package item can be known or unknown package */
/* Packages item */

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoPkgItmKnownPkgDefChc = 
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoPkgItmKnownPkgDefChc = 
#endif
{
   MGT_PKG_MAX,
   0,
   NULLP,
   NULLP,
   mgMgcoPkgNameEnum
};

PUBLIC CmAbnfElmDef mgMgcoPkgItmKnownPkgDef =
{
#ifdef CM_ABNF_DBG
   "Pkg Itm - known package",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 541,
   sizeof(TknPkgId),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoPkgItmKnownPkgDefChc,
   mgMgcoRegExpPackageName
};


PUBLIC CmAbnfElmDef *mgMgcoPkgNameTypeDefChcElmnts[] =
{
   &mgMgcoUnknownNameDef,
   &mgMgcoSkipStarDef,
   &mgMgcoPkgItmKnownPkgDef
};

/* NAME */
PUBLIC CmAbnfElmTypeChoice mgMgcoPkgNameTypeDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoPkgNameTypeDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameTypeDef   =
{
#ifdef CM_ABNF_DBG
   "Pkg NAME",
   "Name",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 542,
   sizeof(MgMgcoName),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPkgNameTypeDefChc,
   mgMgcoRegExpPackageType
};

PUBLIC CmAbnfElmDef *mgMgcoPkgsItemDefSeqElmnts[]   =
{
   &mgMgcoPkgNameTypeDef,  
   &cmMsgDefMetaHyphen,
   &mgMgcoPkgsItemValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPkgsItemDefSeq =
{
   3,
   mgMgcoPkgsItemDefSeqElmnts
};

/* packagesItem         = NAME "-" UINT16 */
PUBLIC CmAbnfElmDef mgMgcoPkgsItemDef   =
{
#ifdef CM_ABNF_DBG
   "Packages item",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 401,
   sizeof(MgMgcoPkgsItem),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPkgsItemDefSeq,
   NULLP
};
/* mg003.105: Modify - Change for the backward compatibility */
#ifdef MGT_MGCO_V2   
/* IndAudPackages descriptor */
PUBLIC CmAbnfElmDef *mgMgcoIndAudPkgsDescDefSeqElmnts[]   =
{
   /*milton &mgMgcoPackagesTokenDef,*/
   &mgMgcoLBRKTDef,
   &mgMgcoPkgsItemDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudPkgsDescDefSeq =
{
   3,
   mgMgcoIndAudPkgsDescDefSeqElmnts
};
/*-----------BEGIN: indAudPackagesDescriptor----------------------------*/

/*
 *   indAudpackagesDescriptor = PackagesToken LBRKT packagesItem RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoIndAudPkgsDescDef   =
{
#ifdef CM_ABNF_DBG
   "IndAudPackages descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 404,
   sizeof(MgMgcoPkgsItem),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudPkgsDescDefSeq,
   NULLP
};

/*-----------END: indAudPackagesDescriptor------------------------------*/

#endif /* MGT_MGCO_V2 */

/************************************************************************/

/* Packages item array */
PUBLIC CmAbnfElmDef *mgMgcoPkgsItemArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoPkgsItemDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPkgsItemArrayDefSeqOf =
{
   1,
   MGT_MAX_PKGSITEMS,
   2,
   mgMgcoPkgsItemArrayDefSeqOfElmnts,
   sizeof(MgMgcoPkgsItem)
};

/* *(COMMA packagesItem) */
PUBLIC CmAbnfElmDef mgMgcoPkgsItemArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Packages item array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 402,
   sizeof(MgMgcoPkgsDesc),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPkgsItemArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Packages item list */
PUBLIC CmAbnfElmDef *mgMgcoPkgsItemLstDefSeqElmnts[]   =
{
   &mgMgcoPkgsItemDef,
   &mgMgcoPkgsItemArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPkgsItemLstDefSeq =
{
   2,
   mgMgcoPkgsItemLstDefSeqElmnts
};

/* packagesItem *(COMMA packagesItem) */
PUBLIC CmAbnfElmDef mgMgcoPkgsItemLstDef   =
{
#ifdef CM_ABNF_DBG
   "Packages item list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 403,
   sizeof(MgMgcoPkgsDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPkgsItemLstDefSeq,
   NULLP
};

/************************************************************************/

/* Packages descriptor */
PUBLIC CmAbnfElmDef *mgMgcoPkgsDescDefSeqElmnts[]   =
{
   &mgMgcoPackagesTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoPkgsItemLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPkgsDescDefSeq =
{
   4,
   mgMgcoPkgsDescDefSeqElmnts
};

/* packagesDescriptor   = PackagesToken LBRKT packagesItem *(COMMA
 *                        packagesItem) RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoPkgsDescDef   =
{
#ifdef CM_ABNF_DBG
   "Packages descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 404,
   sizeof(MgMgcoPkgsDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPkgsDescDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoOptStatsValDefSeqElmnts[] =
{
   &mgMgcoEQUALDef,
   &mgMgcoValueDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptStatsValDefSeq =
{
   2,
   mgMgcoOptStatsValDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoOptStatsValDef =
{
#ifdef CM_ABNF_DBG
   "Statistics parameter value if present",
   "EQUAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 405,
   sizeof(MgMgcoValue),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptStatsValDefSeq,
   mgMgcoRegExpEQUAL
};

/************************************************************************/

/* Statistics parameter */
PUBLIC CmAbnfElmDef *mgMgcoStatsParUnknownPkgDefSeqElmnts[]   =
{
   &mgMgcoPkgdNameDef,
   &mgMgcoOptStatsValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoStatsParUnknownPkgDefSeq =
{
   2,
   mgMgcoStatsParUnknownPkgDefSeqElmnts
};

/* statisticsParameter  = pkgdName EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoStatsParUnknownPkgDef   =
{
#ifdef CM_ABNF_DBG
   "Statistics parameter - unknown package",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 406,
   sizeof(MgMgcoStatsPar) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoStatsParUnknownPkgDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoStatsParAllDefSeqElmnts[] =
{
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSLASHDef,
   &mgMgcoNAMEDef,
   &mgMgcoOptStatsValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoStatsParAllDefSeq =
{
   4,
   mgMgcoStatsParAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoStatsParAllDef =
{
#ifdef CM_ABNF_DBG
   "Statistics parameter - all",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 407,
   sizeof(MgMgcoStatsPar) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoStatsParAllDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoStatsParKnownPkgDefChcElmnts[] =
{
   NULLP,
   /* mg005.105: changed unknown package id from 0 to 255
    *         ASN Annex C uses package id 0
    *         &mgMgcoStatsParUnknownPkgDef,          */
   NULLP,   /* Generic */
   NULLP,   /* Root */
   NULLP,   /* ToneGen */
   NULLP,   /* ToneDet */
   NULLP,   /* DtmfGen */
   NULLP,   /* DtmfDet */
   NULLP,   /* CpGen */
   NULLP,   /* CpDet */
   NULLP,   /* Analog */
   NULLP,   /* Cont */
#ifdef GCP_PKG_MGCO_NETWORK
   &mgMgcoStatsParNetworkDef,
#else /* !GCP_PKG_MGCO_NETWORK */
   NULLP,
#endif /* GCP_PKG_MGCO_NETWORK */
#ifdef GCP_PKG_MGCO_RTP
   &mgMgcoStatsParRtpDef,
#else /* !GCP_PKG_MGCO_RTP */
   NULLP,
#endif /* GCP_PKG_MGCO_RTP */
#ifdef GCP_PKG_MGCO_TDMC
   &mgMgcoStatsParNetworkDef,
#else /* !GCP_PKG_MGCO_TDMC */
   NULLP,
#endif /* GCP_PKG_MGCO_TDMC */


   NULLP,                                        /* package ID 14 */

#ifdef GCP_PKG_MGCO_TXTCNVR                      /* package ID 15 */
   &mgMgcoStatParmTxtCnvrDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_TXTTELPHONE                  /* package ID 16 */
   &mgMgcoStatParmTxtTelPhoneDef,
#else
   NULLP,
#endif

   NULLP,                                        /* package ID 17 */

#ifdef GCP_PKG_MGCO_FAX                          /* package ID 18 */
   &mgMgcoStatParmFaxDef,
#else
   NULLP,
#endif

#ifdef GCP_PKG_MGCO_IPFAX                        /* package ID 19 */
   &mgMgcoStatParmIpFaxDef,
#else
   NULLP,
#endif


   /* package IDs 20-35 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
 
   NULLP,                                        /* package ID 36 */
   
   /* package IDs 37-43 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 
   
   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_H_324                        /* package ID 44 */
   &mgMgcoStatParm_H_324Def,
#else
   NULLP,
#endif

   /* package IDs 45-54 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_QTY_ALT                      /* package ID 55 */
   &mgMgcoStatParm_Qty_AltDef,
#else
   NULLP,
#endif

   /* package IDs 56-67 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 
   NULLP, NULLP, 

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_AUT_MET                      /* package ID 68 */
   &mgMgcoStatParm_Aut_MetDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,     /* package IDs 69 - 98 */ 
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 
   NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_H324_EXT                     /* package ID 99 */
   &mgMgcoStatParm_H324_ExtDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 100 - 103 */ 

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCTM                     /* package ID 104 */
   &mgMgcoStatParm_tri_gctmDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 105 - 113 */
   NULLP, NULLP, NULLP, NULLP,

   NULLP, NULLP,                                 /* package IDs 114 - 115 */

   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 116 - 119 */

   NULLP, NULLP,                                 /* package IDs 120 - 121 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_AD_JIT_BUFF                  /* package ID 122 */
   &mgMgcoStatParm_Ad_Jit_BuffDef,
#else
   NULLP,
#endif

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ICAS                         /* package ID 123 */
   &mgMgcoStatParm_IcasDef,
#else
   NULLP,
#endif

   NULLP, NULLP, NULLP, NULLP, NULLP,            /* package IDs 124 -132 */
   NULLP, NULLP, NULLP, NULLP,
   
   /* [TEL]: Moved from location 36 */
   &mgMgcoStatsParAllDef,                        /* package ID 133 */
   
   NULLP, NULLP, NULLP, NULLP,                   /* package IDs 134 -137 */
   NULLP, NULLP, NULLP,                         /* package ID 138 - 140 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 141 - 150 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 151 - 160 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 161 - 170 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 171 - 180 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 181 - 190 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 191 - 200 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 201 - 210 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 211 - 220 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 221 - 230 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 231 - 124 */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,    /* package ID 241 - 250 */
   NULLP, NULLP, NULLP,                         /* package ID 250 - 253 */
   &mgMgcoStatsParUnknownPkgDef,
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoStatsParKnownPkgDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoStatsParKnownPkgDefChc =
#endif
{
   MGT_PKG_MAX,
   0,
   NULLP,
   mgMgcoStatsParKnownPkgDefChcElmnts,
   mgMgcoPkgNameEnum
};

PUBLIC CmAbnfElmDef mgMgcoStatsParKnownPkgDef =
{
#ifdef CM_ABNF_DBG
   "Statistics parameter",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 408,
   sizeof(MgMgcoStatsPar),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoStatsParKnownPkgDefChc,
   mgMgcoRegExpPackageName
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoStatsParDefChcElmnts[] =
{
   &mgMgcoStatsParUnknownPkgDef,
   &mgMgcoStatsParKnownPkgDef
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoStatsParDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoStatsParDefChc =
#endif
{
   2,
   MGT_PKG_MAX,
   mgMgcoPkgChcIdx,
   mgMgcoStatsParDefChcElmnts,
   mgMgcoPkgChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoStatsParDef =
{
#ifdef CM_ABNF_DBG
   "Statistics parameter",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 409,
   sizeof(MgMgcoStatsPar),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoStatsParDefChc,
   mgMgcoRegExpPackageName
};


/************************************************************************/

/* Statistics parameter array */
PUBLIC CmAbnfElmDef *mgMgcoStatsParArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoStatsParDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoStatsParArrayDefSeqOf =
{
   1,
   MGT_MAX_STATSPARS,
   2,
   mgMgcoStatsParArrayDefSeqOfElmnts,
   sizeof(MgMgcoStatsPar)
};

/* *(COMMA statisticsParameter) */
PUBLIC CmAbnfElmDef mgMgcoStatsParArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Statistics parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 410,
   sizeof(MgMgcoStatsDesc),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoStatsParArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Statistics parameter list */
PUBLIC CmAbnfElmDef *mgMgcoStatsParLstDefSeqElmnts[]   =
{
   &mgMgcoStatsParDef,
   &mgMgcoStatsParArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoStatsParLstDefSeq =
{
   2,
   mgMgcoStatsParLstDefSeqElmnts
};

/* statisticsParameter *(COMMA statisticsParameter) */
PUBLIC CmAbnfElmDef mgMgcoStatsParLstDef   =
{
#ifdef CM_ABNF_DBG
   "Statistics parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 411,
   sizeof(MgMgcoStatsDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,  
   (U8 *)&mgMgcoStatsParLstDefSeq,
   NULLP
};

/************************************************************************/

/* Statistics descriptor */
PUBLIC CmAbnfElmDef *mgMgcoStatsDescDefSeqElmnts[]   =
{
   &mgMgcoStatsTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoStatsParLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoStatsDescDefSeq =
{
   4,
   mgMgcoStatsDescDefSeqElmnts
};

/* statisticsDescriptor = StatsToken LBRKT statisticsParameter *(COMMA
 *                        statisticsParameter) RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoStatsDescDef   =
{
#ifdef CM_ABNF_DBG
   "Statistics descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 412,
   sizeof(MgMgcoStatsDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoStatsDescDefSeq,
   NULLP
};

/************************************************************************/

/* Topology direction */
PUBLIC CmAbnfElmDef *mgMgcoTopologyDirDefChcEnum[]   =
{
   &mgMgcoBothwayEnum,
   &mgMgcoIsolateEnum,
   &mgMgcoOnewayEnum
};

PUBLIC CmAbnfElmTypeChoice mgMgcoTopologyDirDefChc =
{
   3,
   0,
   NULLP,
   NULLP,
   mgMgcoTopologyDirDefChcEnum
};

/* topologyDirection    = BothwayToken / IsolateToken / OnewayToken */
PUBLIC CmAbnfElmDef mgMgcoTopologyDirDef   =
{
#ifdef CM_ABNF_DBG
   "Topology direction",
   "TopoDir",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 413,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoTopologyDirDefChc,
   mgMgcoRegExpTopoDir
};

/* Optional stream descriptor */
/* mg003.105: Bug fix for Topology Descriptor, Stream ID Parameter */
PUBLIC CmAbnfElmDef *mgMgcoOptCommaStreamDefSeqElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptCommaStreamDefSeq =
{
   2,
   mgMgcoOptCommaStreamDefSeqElmnts
};

/* [ COMMA Stream Definition ] */
PUBLIC CmAbnfElmDef mgMgcoOptCommaStreamDef   =
{
#ifdef CM_ABNF_DBG
   "Optional Stream descriptor",
   "COMMAStreamID",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 998,
   sizeof(MgMgcoStreamId),
   ((CM_ABNF_TKN_NOT_CONSUMED| CM_ABNF_OPTIONAL) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_TKN_NOT_CONSUMED| CM_ABNF_OPTIONAL) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptCommaStreamDefSeq,
   /* mg007.105: if optional stream id is not present skip it */
/*   mgMgcoRegExpCOMMA*/
   mgMgcoRegExpOptTopStreamId
};

/************************************************************************/

/* Topology descriptor */
#ifdef MGT_MGCO_V2
PUBLIC CmAbnfElmDef *mgMgcoTopologyDescDefSeqElmnts[]   =
{
   &mgMgcoTermIdDef,
   &mgMgcoCOMMADef,
   &mgMgcoTermIdDef,
   &mgMgcoCOMMADef,
   &mgMgcoTopologyDirDef,
   /*&mgMgcoStreamIdDef    milton-14    Ganesh - 001 */
   &mgMgcoOptCommaStreamDef
};
#else

PUBLIC CmAbnfElmDef *mgMgcoTopologyDescDefSeqElmnts[]   =
{
   &mgMgcoTermIdDef,
   &mgMgcoCOMMADef,
   &mgMgcoTermIdDef,
   &mgMgcoCOMMADef,
   &mgMgcoTopologyDirDef
};

#endif /* MGT_MGCO_V2 */

PUBLIC CmAbnfElmTypeSeq mgMgcoTopologyDescDefSeq =
{
   #ifdef MGT_MGCO_V2
   6,
   #else
   5,
   #endif /* MGT_MGCO_V2 */
   mgMgcoTopologyDescDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoTopologyDescDef   =
{
#ifdef CM_ABNF_DBG
   "Topology descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 414,
   sizeof(MgMgcoTopoDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoTopologyDescDefSeq,
   NULLP
};

/************************************************************************/

/* Priority */
PUBLIC CmAbnfElmDef *mgMgcoPriorityDefSeqElmnts[]   =
{
   &mgMgcoPriorityTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoPriorityValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPriorityDefSeq =
{
   3,
   mgMgcoPriorityDefSeqElmnts
};

/* priority             = PriorityToken EQUAL UINT16 */
PUBLIC CmAbnfElmDef mgMgcoPriorityDef   =
{
#ifdef CM_ABNF_DBG
   "Priority",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 415,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPriorityDefSeq,
   NULLP
};

/************************************************************************/

/* Skip for service change method */

PUBLIC CmAbnfElmDef mgMgcoSvcChgMethodTypeSkipDef   =
{
#ifdef CM_ABNF_DBG
   "Skip NonStdId",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 416,
   sizeof(MgMgcoNonStdId),
   (CM_ABNF_OPTIONAL  << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL  << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

/************************************************************************/

/* Extension parameter */
PUBLIC CmAbnfElmDef *mgMgcoExtnParmDefChcEnum[]   =
{
   &mgMgcoExtnParmOptEnum,
   &mgMgcoExtnParmMandEnum
};

PUBLIC CmAbnfElmDef *mgMgcoExtnParmDefChcElmnts[]   =
{
   &mgMgcoExtnParmValDef
};

PUBLIC U8 mgMgcoExtnParmDefChcIdx[] = {0, 0};

PUBLIC CmAbnfElmTypeChoice mgMgcoExtnParmDefChc =
{
   1,
   2,
   mgMgcoExtnParmDefChcIdx,
   mgMgcoExtnParmDefChcElmnts,
   mgMgcoExtnParmDefChcEnum
};

/* extensionParameter   = "X"  ("-" / "+") 1*6(ALPHA / DIGIT) */
PUBLIC CmAbnfElmDef mgMgcoExtnParmDef   =
{
#ifdef CM_ABNF_DBG
   "Extension parameter",
   "OptMand",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 417,
   sizeof(MgMgcoNonStdId),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET), /* consume - or + */
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoExtnParmDefChc,
   mgMgcoRegExpOptMand
};

/************************************************************************/

/* Service change method type */
PUBLIC CmAbnfElmDef *mgMgcoSvcChgMethodTypeDefChcEnum[]   =
{
   &mgMgcoExtnParmEnum,
   &mgMgcoFailoverEnum,
   &mgMgcoForcedEnum,
   &mgMgcoGracefulEnum,
   &mgMgcoRestartEnum,
   &mgMgcoDisconnectedEnum,
   &mgMgcoHandOffEnum
};

PUBLIC CmAbnfElmDef *mgMgcoSvcChgMethodTypeDefChcElmnts[]   =
{
   &mgMgcoExtnParmDef,
   &mgMgcoSvcChgMethodTypeSkipDef
};

PUBLIC U8 mgMgcoSvcChgMethodTypeDefChcIdx[] = {0, 1, 1, 1, 1, 1, 1};

PUBLIC CmAbnfElmTypeChoice mgMgcoSvcChgMethodTypeDefChc =
{
   2,
   7,
   mgMgcoSvcChgMethodTypeDefChcIdx,
   mgMgcoSvcChgMethodTypeDefChcElmnts,
   mgMgcoSvcChgMethodTypeDefChcEnum
};

/* FailoverToken /  ForcedToken / GracefulToken / RestartToken /
 * DisconnectedToken / HandOffToken /
 * extensionParameter
 */
PUBLIC CmAbnfElmDef mgMgcoSvcChgMethodTypeDef   =
{
#ifdef CM_ABNF_DBG
   "Service change method type",
   "SvcChgMethod",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 418,
   sizeof(MgMgcoNonStdId) + sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSvcChgMethodTypeDefChc,
   mgMgcoRegExpSvcChgMethod
};

/************************************************************************/

/* Service change method */
PUBLIC CmAbnfElmDef *mgMgcoSvcChgMethodDefSeqElmnts[]   =
{
   &mgMgcoMethodTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoSvcChgMethodTypeDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSvcChgMethodDefSeq =
{
   3,
   mgMgcoSvcChgMethodDefSeqElmnts
};

/* serviceChangeMethod  = MethodToken EQUAL (FailoverToken /  ForcedToken /
 * GracefulToken / RestartToken /  DisconnectedToken / HandOffToken /
 * extensionParameter)
 */
PUBLIC CmAbnfElmDef mgMgcoSvcChgMethodDef   =
{
#ifdef CM_ABNF_DBG
   "Service change method",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 419,
   sizeof(MgMgcoSvcChgMethod),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoSvcChgMethodDefSeq,
   NULLP
};

/************************************************************************/

/* Service change reason */

PUBLIC CmAbnfElmDef *mgMgcoSvcChgReasonDefSeqElmnts[]   =
{
   &mgMgcoReasonTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoValueValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSvcChgReasonDefSeq =
{
   3,
   mgMgcoSvcChgReasonDefSeqElmnts
};

/* serviceChangeReason  = ReasonToken  EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoSvcChgReasonDef   =
{
#ifdef CM_ABNF_DBG
   "Service change reason",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 420,
   sizeof(MgMgcoSvcChgReason),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSvcChgReasonDefSeq,
   NULLP
};

/************************************************************************/

/* Service change delay */
PUBLIC CmAbnfElmDef *mgMgcoSvcChgDelayDefSeqElmnts[]   =
{
   &mgMgcoDelayTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoSvcChgDelayValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSvcChgDelayDefSeq =
{
   3,
   mgMgcoSvcChgDelayDefSeqElmnts
};

/* serviceChangeDelay   = DelayToken   EQUAL UINT32 */
PUBLIC CmAbnfElmDef mgMgcoSvcChgDelayDef   =
{
#ifdef CM_ABNF_DBG
   "Service change delay",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 421,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSvcChgDelayDefSeq,
   NULLP
};

/************************************************************************/

/* Service change address */
PUBLIC CmAbnfElmDef *mgMgcoSvcChgAddrDefSeqElmnts[] =
{
   &mgMgcoServiceChangeAddressTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoMIDDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSvcChgAddrDefSeq =
{
   3,
   mgMgcoSvcChgAddrDefSeqElmnts
};

/* serviceChangeAddress = ServiceChangeAddressToken EQUAL VALUE */
/* Note: We will interpret the service change address to be in MID format */
PUBLIC CmAbnfElmDef mgMgcoSvcChgAddrDef   =
{
#ifdef CM_ABNF_DBG
   "Service change address",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 422,
   sizeof(MgMgcoSvcChgAddr),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ, 
   (U8 *)&mgMgcoSvcChgAddrDefSeq,
   NULLP
};

/************************************************************************/

/* Service change MGC ID */
PUBLIC CmAbnfElmDef *mgMgcoSvcChgMgcIdDefSeqElmnts[]   =
{
   &mgMgcoMgcIdTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoMIDDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSvcChgMgcIdDefSeq =
{
   3,
   mgMgcoSvcChgMgcIdDefSeqElmnts
};

/* serviceChangeMgcId   = MgcIdToken   EQUAL mId */
PUBLIC CmAbnfElmDef mgMgcoSvcChgMgcIdDef   =
{
#ifdef CM_ABNF_DBG
   "Service change MGC ID",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 423,
   sizeof(MgMgcoMid),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSvcChgMgcIdDefSeq,
   NULLP
};

/************************************************************************/

/* Service change profile */
PUBLIC CmAbnfElmDef *mgMgcoSvcChgProfDefSeqElmnts[]   =
{
   &mgMgcoProfileTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoNAMEDef,
   &mgMgcoSLASHDef,
   &mgMgcoVersionDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSvcChgProfDefSeq =
{
   5,
   mgMgcoSvcChgProfDefSeqElmnts
};

/* serviceChangeProfile = ProfileToken EQUAL NAME SLASH Version */
PUBLIC CmAbnfElmDef mgMgcoSvcChgProfDef   =
{
#ifdef CM_ABNF_DBG
   "Service change profile",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 424,
   sizeof(MgMgcoSvcChgProf),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoSvcChgProfDefSeq,
   NULLP
};

/************************************************************************/

/* Service change version */
PUBLIC CmAbnfElmDef *mgMgcoSvcChgVersionDefSeqElmnts[]   =
{
   &mgMgcoVersionTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoVersionDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSvcChgVersionDefSeq =
{
   3,
   mgMgcoSvcChgVersionDefSeqElmnts
};

/* serviceChangeVersion = VersionToken EQUAL Version */
PUBLIC CmAbnfElmDef mgMgcoSvcChgVersionDef   =
{
#ifdef CM_ABNF_DBG
   "Service change version",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 425,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSvcChgVersionDefSeq,
   NULLP
};

/************************************************************************/

/* Service change parameter set in reply */
PUBLIC CmAbnfElmDef *mgMgcoSvcChgReplySetDefSetElmnts[]   =
{
   &mgMgcoSvcChgAddrDef,
   &mgMgcoSvcChgVersionDef,
   &mgMgcoSvcChgProfDef,
   &mgMgcoSvcChgMgcIdDef,
   &mgMgcoTimeStampDef,
};

PUBLIC CmAbnfElmTypeSet mgMgcoSvcChgReplySetDefSet =
{
   5,
   mgMgcoSvcChgReplySetDefSetElmnts,
   &mgMgcoCOMMADef
};

/* servChgReplyParm *(COMMA servChgReplyParm)
 * servChgReplyParm     = (serviceChangeAddress / serviceChangeMgcId /
 * serviceChangeProfile / serviceChangeVersion / TimeStamp ) 
 */
PUBLIC CmAbnfElmDef mgMgcoSvcChgReplySetDef   =
{
#ifdef CM_ABNF_DBG
   "Service change parameter set in reply",
   "SvcChgParReply",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 426,
   sizeof(MgMgcoSvcChgResPar),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SET,
   (U8 *)&mgMgcoSvcChgReplySetDefSet,
   mgMgcoRegExpSvcChgParReply
};

/************************************************************************/

/* Service change descriptor in reply */
PUBLIC CmAbnfElmDef *mgMgcoSvcChgReplyDescDefSeqElmnts[]   =
{
   &mgMgcoServicesTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoSvcChgReplySetDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSvcChgReplyDescDefSeq =
{
   4,
   mgMgcoSvcChgReplyDescDefSeqElmnts
};

/* serviceChangeReplyDescriptor = ServicesToken LBRKT servChgReplyParm *(COMMA
 *                                servChgReplyParm) RBRKT 
 */
PUBLIC CmAbnfElmDef mgMgcoSvcChgReplyDescDef   =
{
#ifdef CM_ABNF_DBG
   "Service change descriptor in reply",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 427,
   sizeof(MgMgcoSvcChgResPar),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSvcChgReplyDescDefSeq,
   NULLP
};

/************************************************************************/

/* Extension */
PUBLIC CmAbnfElmDef *mgMgcoExtnDefSeqElmnts[]   =
{
   &mgMgcoExtnParmMetaDef,
   &mgMgcoExtnParmDef,
   &mgMgcoParmValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoExtnDefSeq =
{
   3,
   mgMgcoExtnDefSeqElmnts
};

/* extension            = extensionParameter parmValue */
PUBLIC CmAbnfElmDef mgMgcoExtnDef   =
{
#ifdef CM_ABNF_DBG
   "Extension",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 428,
   sizeof(MgMgcoNonStdExtn),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoExtnDefSeq,
   NULLP
};

/************************************************************************/

/* Service change parameter set in request */
#ifdef MGT_MGCO_V2
PUBLIC CmAbnfElmDef *mgMgcoSvcChgReqSetDefSetElmnts[]   =
{
   &mgMgcoExtnDef,
   &mgMgcoSvcChgMethodDef,
   &mgMgcoSvcChgAddrDef,
   &mgMgcoSvcChgVersionDef,
   &mgMgcoSvcChgProfDef,
   &mgMgcoSvcChgReasonDef,
   &mgMgcoSvcChgDelayDef,
   &mgMgcoSvcChgMgcIdDef,
   &mgMgcoTimeStampDef,
   &mgMgcoAuditItemDef 
};
#else

PUBLIC CmAbnfElmDef *mgMgcoSvcChgReqSetDefSetElmnts[]   =
{
   &mgMgcoExtnDef,
   &mgMgcoSvcChgMethodDef,
   &mgMgcoSvcChgAddrDef,
   &mgMgcoSvcChgVersionDef,
   &mgMgcoSvcChgProfDef,
   &mgMgcoSvcChgReasonDef,
   &mgMgcoSvcChgDelayDef,
   &mgMgcoSvcChgMgcIdDef,
   &mgMgcoTimeStampDef
};
#endif /*MGT_MGCO_V2*/
/*milton-14*/

#ifdef MGT_MGCO_V2
PUBLIC CmAbnfElmTypeSet mgMgcoSvcChgReqSetDefSet =
{
   10,
   mgMgcoSvcChgReqSetDefSetElmnts,
   &mgMgcoCOMMADef
};
#else
PUBLIC CmAbnfElmTypeSet mgMgcoSvcChgReqSetDefSet =
{
   9,
   mgMgcoSvcChgReqSetDefSetElmnts,
   &mgMgcoCOMMADef
};
#endif /* MGT_MGCO_V2 */
/*milton-14*/

/* serviceChangeParm  *(COMMA serviceChangeParm) 
 * serviceChangeParm    = (serviceChangeMethod / serviceChangeReason /
 * serviceChangeDelay / serviceChangeAddress / serviceChangeProfile /
 * extension / TimeStamp / serviceChangeMgcId / serviceChangeVersion)
 */
PUBLIC CmAbnfElmDef mgMgcoSvcChgReqSetDef   =
{
#ifdef CM_ABNF_DBG
   "Service change parameter set in request",
   "SvcChgParReq",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 429,
   sizeof(MgMgcoSvcChgPar),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SET,
   (U8 *)&mgMgcoSvcChgReqSetDefSet,
#ifdef MGT_MGCO_V2
   mgMgcoRegExpSvcChgParReqV2 /*milton-14*/
#else
   mgMgcoRegExpSvcChgParReq
#endif /* MGT_MGCO_V2 */
};

/* mg003.105: Add - Added new function for checking the presence of 
   method and reason of service change request */
PUBLIC CmAbnfElmTypeMarker mgMgcoSvcChgReqDescMarker =
{
   CM_ABNF_MARKER_ESC_FUNC,
   (U8 *)mgMgcoEscFuncSvcChgReqDesc
};

PUBLIC CmAbnfElmDef mgMgcoSvcChgReqDescMarkerDef =
{
#ifdef CM_ABNF_DBG
   "Marker PkgName",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 125,
   0,
   0,
   CM_ABNF_TYPE_MARKER,
   (U8 *)&mgMgcoSvcChgReqDescMarker,
   NULLP
};

/************************************************************************/

/* Service change descriptor in request */
PUBLIC CmAbnfElmDef *mgMgcoSvcChgReqDescDefSeqElmnts[]   =
{
   &mgMgcoServicesTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoSvcChgReqSetDef,
   &mgMgcoSvcChgReqDescMarkerDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSvcChgReqDescDefSeq =
{
   /* mg003.105: Modify - changed from 4 */
   5,
   mgMgcoSvcChgReqDescDefSeqElmnts
};

/* serviceChangeDescriptor = ServicesToken LBRKT serviceChangeParm  *(COMMA
 *                           serviceChangeParm) RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoSvcChgReqDescDef   =
{
#ifdef CM_ABNF_DBG
   "Service change descriptor in request",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 430,
   sizeof(MgMgcoSvcChgPar),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSvcChgReqDescDefSeq,
   NULLP
};

/************************************************************************/

/* Modem type */
PUBLIC CmAbnfElmDef *mgMgcoModemTypeDefChcEnum[] =
{
   &mgMgcoExtnParmEnum,
   &mgMgcoV32bisEnum,
   &mgMgcoV22bisEnum,
   &mgMgcoV18Enum,
   &mgMgcoV22Enum,
   &mgMgcoV32Enum,
   &mgMgcoV34Enum,
   &mgMgcoV90Enum,
   &mgMgcoV91Enum,
   &mgMgcoSynchISDNEnum
};

PUBLIC CmAbnfElmDef *mgMgcoModemTypeDefChcElmnts[]   =
{
   &mgMgcoExtnParmDef,
   &mgMgcoSvcChgMethodTypeSkipDef
};

PUBLIC U8 mgMgcoModemTypeDefChcIdx[] = {0, 1, 1, 1, 1, 1, 1, 1, 1, 1};

PUBLIC CmAbnfElmTypeChoice mgMgcoModemTypeDefChc =
{
   2,
   10,
   mgMgcoModemTypeDefChcIdx,
   mgMgcoModemTypeDefChcElmnts,
   mgMgcoModemTypeDefChcEnum
};

/* modemType            = (V32bisToken / V22bisToken / V18Token /  V22Token /
 *                         V32Token / V34Token / V90Token /  V91Token / 
 *                         SynchISDNToken / extensionParameter)
 */
PUBLIC CmAbnfElmDef mgMgcoModemTypeDef   =
{
#ifdef CM_ABNF_DBG
   "Modem type",
   "ModemType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 431,
   sizeof(MgMgcoModemType),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoModemTypeDefChc,
   mgMgcoRegExpModemType
};

/************************************************************************/

/* Single modem type */
PUBLIC CmAbnfElmDef *mgMgcoModemTypeSingleDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoModemTypeDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoModemTypeSingleDefSeq =
{
   2,
   mgMgcoModemTypeSingleDefSeqElmnts
};

/* EQUAL modemType */
PUBLIC CmAbnfElmDef mgMgcoModemTypeSingleDef   =
{
#ifdef CM_ABNF_DBG
   "Single modem type",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 432,
   sizeof(MgMgcoModemType),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoModemTypeSingleDefSeq,
   NULLP
};

/************************************************************************/

/* Modem type array */
PUBLIC CmAbnfElmDef *mgMgcoModemTypeArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoModemTypeDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoModemTypeArrayDefSeqOf =
{
   1,
   MGT_MAX_MODEMTYPES,
   2,
   mgMgcoModemTypeArrayDefSeqOfElmnts,
   sizeof(MgMgcoModemType)
};

/* *(COMMA modemType) */
PUBLIC CmAbnfElmDef mgMgcoModemTypeArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Modem type array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 433,
   sizeof(MgMgcoModemTypeLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoModemTypeArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Modem type list */
PUBLIC CmAbnfElmDef *mgMgcoModemTypeLstDefSeqElmnts[]   =
{
   &mgMgcoModemTypeDef,
   &mgMgcoModemTypeArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoModemTypeLstDefSeq =
{
   2,
   mgMgcoModemTypeLstDefSeqElmnts
};

/* modemType *(COMMA modemType) */
PUBLIC CmAbnfElmDef mgMgcoModemTypeLstDef   =
{
#ifdef CM_ABNF_DBG
   "Modem type list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 434,
   sizeof(MgMgcoModemTypeLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoModemTypeLstDefSeq,
   NULLP
};

/************************************************************************/

/* Modem type queue */
PUBLIC CmAbnfElmDef *mgMgcoModemTypeQDefSeqElmnts[]   =
{
   &mgMgcoLSBRKTDef,
   &mgMgcoModemTypeLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoModemTypeQDefSeq =
{
   3,
   mgMgcoModemTypeQDefSeqElmnts
};

/* LSBRKT modemType *(COMMA modemType) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoModemTypeQDef   =
{
#ifdef CM_ABNF_DBG
   "Modem type queue",
   "LSBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 435,
   sizeof(MgMgcoModemTypeLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoModemTypeQDefSeq,
   mgMgcoRegExpLSBRKT
};

/************************************************************************/

/* Modem types choice seqOf */
PUBLIC CmAbnfElmDef *mgMgcoModemTypeChSeqOfDefSeqElmnts[]   =
{
   &mgMgcoModemTypeSingleDef,
   &mgMgcoModemTypeQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoModemTypeChSeqOfDefSeq =
{
   2,
   mgMgcoModemTypeChSeqOfDefSeqElmnts
};

/* (EQUAL modemType) /  (LSBRKT modemType *(COMMA modemType) RSBRKT) */
PUBLIC CmAbnfElmDef mgMgcoModemTypeChSeqOfDef   =
{
#ifdef CM_ABNF_DBG
   "Modem types choice seqOf",
   "EqualOrLSBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 436,
   sizeof(MgMgcoModemTypeLst),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHSEQOF,
   (U8 *)&mgMgcoModemTypeChSeqOfDefSeq,
   mgMgcoRegExpEqualOrLSBRKT
};

/************************************************************************/

/* Modem property */
PUBLIC CmAbnfElmDef *mgMgcoPropsDefSeqElmnts[] =
{
   &mgMgcoPkgNameUnknownEnumDef,
   &mgMgcoPropParmUnknownPkgDef,
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropsDefSeq =
{
   2,
   mgMgcoPropsDefSeqElmnts
};

/* NAME parmValue */
PUBLIC CmAbnfElmDef mgMgcoPropsDef =
{
#ifdef CM_ABNF_DBG
   "Property",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 437,
   sizeof(MgMgcoPropParm),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropsDefSeq,
   NULLP
};

/************************************************************************/

/* Modem properties array */
PUBLIC CmAbnfElmDef *mgMgcoPropsArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoPropsDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPropsArrayDefSeqOf =
{
   1,
   MGT_MAX_PROPPARMS,
   2,
   mgMgcoPropsArrayDefSeqOfElmnts,
   sizeof(MgMgcoPropParm)
};

/* *(COMMA NAME parmValue) */
PUBLIC CmAbnfElmDef mgMgcoPropsArrayDef =
{
#ifdef CM_ABNF_DBG
   "Properties array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 438,
   sizeof(MgMgcoPropParmLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPropsArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Modem properties list */
PUBLIC CmAbnfElmDef *mgMgcoPropsLstDefSeqElmnts[] =
{
   &mgMgcoPropsDef,
   &mgMgcoPropsArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropsLstDefSeq =
{
   2,
   mgMgcoPropsLstDefSeqElmnts
};

/* NAME parmValue *(COMMA NAME parmValue) */
PUBLIC CmAbnfElmDef mgMgcoPropsLstDef =
{
#ifdef CM_ABNF_DBG
   "Properties list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 439,
   sizeof(MgMgcoPropParmLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPropsLstDefSeq,
   NULLP
};

/************************************************************************/

/* Modem properties queue */
PUBLIC CmAbnfElmDef *mgMgcoModemPropsQDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoPropsLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoModemPropsQDefSeq =
{
   3,
   mgMgcoModemPropsQDefSeqElmnts
};

/* [LBRKT NAME parmValue *(COMMA NAME parmValue) RBRKT] */
PUBLIC CmAbnfElmDef mgMgcoModemPropsQDef =
{
#ifdef CM_ABNF_DBG
   "Modem properties queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 440,
   sizeof(MgMgcoPropParmLst),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoModemPropsQDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

/* Modem descriptor */
PUBLIC CmAbnfElmDef *mgMgcoModemDescDefSeqElmnts[]   =
{
   &mgMgcoModemTokenDef,
   &mgMgcoModemTypeChSeqOfDef,
   &mgMgcoModemPropsQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoModemDescDefSeq =
{
   3,
   mgMgcoModemDescDefSeqElmnts
};

/* modemDescriptor      = ModemToken ( (EQUAL modemType) /  (LSBRKT modemType
 *                                     *(COMMA modemType) RSBRKT)
 *                                   ) [LBRKT NAME parmValue  *(COMMA NAME
 *                                   parmValue) RBRKT]
 */
PUBLIC CmAbnfElmDef mgMgcoModemDescDef   =
{
#ifdef CM_ABNF_DBG
   "Modem descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 441,
   sizeof(MgMgcoModemDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoModemDescDefSeq,
   NULLP
};

/************************************************************************/

/* Digit map name and/or value */
PUBLIC CmAbnfElmDef *mgMgcoDigMapSetDefSetElmnts[]   =
{
   &mgMgcoNAMEDef,
   &mgMgcoEvtDigMapValDef
};

PUBLIC CmAbnfElmTypeSet mgMgcoDigMapSetDefSet =
{
   2,
   mgMgcoDigMapSetDefSetElmnts,
   NULLP
};

/* (LBRKT digitMapValue RBRKT) / digitMapName [LBRKT digitMapValue RBRKT]) */
PUBLIC CmAbnfElmDef mgMgcoDigMapSetDef =
{
#ifdef CM_ABNF_DBG
   "Digit map name and/or value",
   "DigMapNameValInDesc",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 442,
   sizeof(MgMgcoDigMapDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SET,
   (U8 *)&mgMgcoDigMapSetDefSet,
   mgMgcoRegExpDigMapNameValInDesc
};

/************************************************************************/

/* Digit map descriptor */
PUBLIC CmAbnfElmDef *mgMgcoDigMapDescDefSeqElmnts[] =
{
   &mgMgcoDigitMapTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoDigMapSetDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoDigMapDescDefSeq =
{
   3,
   mgMgcoDigMapDescDefSeqElmnts
};

/* digitMapDescriptor   = DigitMapToken EQUAL ( 
 *                        (LBRKT digitMapValue RBRKT) / 
 *                        (digitMapName [LBRKT digitMapValue RBRKT]) 
 *                                            )
 */
PUBLIC CmAbnfElmDef mgMgcoDigMapDescDef =
{
#ifdef CM_ABNF_DBG
   "Digit map descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 443,
   sizeof(MgMgcoDigMapDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoDigMapDescDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoStreamModeDefEnum =
{
   (Data *)NULLP,
   MGT_LCLCTL_MODE
};

PUBLIC CmAbnfElmDef mgMgcoStreamModeDefEnumDef =
{
#ifdef CM_ABNF_DBG
   "StreamMode Enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 444,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoStreamModeDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoResValDefEnum =
{
   (Data *)NULLP,
   MGT_LCLCTL_RESVAL
};

PUBLIC CmAbnfElmDef mgMgcoResValDefEnumDef =
{
#ifdef CM_ABNF_DBG
   "ResVal Enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 445,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoResValDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoResGrpDefEnum =
{
   (Data *)NULLP,
   MGT_LCLCTL_RESGRP
};

PUBLIC CmAbnfElmDef mgMgcoResGrpDefEnumDef =
{
#ifdef CM_ABNF_DBG
   "ResGrp Enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 446,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoResGrpDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmDefEnum =
{
   (Data *)NULLP,
   MGT_LCLCTL_PROPPARM
};

PUBLIC CmAbnfElmDef mgMgcoPropParmDefEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParm Enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 447,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmDefEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMgcoStreamModeStrDefEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"MO",
#else  /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"Mode",
#endif /* !GCP_MGCO_SHORT_TOKEN */
   MGT_LCLCTL_MODE
};

PUBLIC CmAbnfElmDef mgMgcoStreamModeStrDefEnumDef =
{
#ifdef CM_ABNF_DBG
   "StreamMode Enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 444,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoStreamModeStrDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoResValStrDefEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"RV",
#else  /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"ReservedValue",
#endif /* !GCP_MGCO_SHORT_TOKEN */
   MGT_LCLCTL_RESVAL
};

PUBLIC CmAbnfElmDef mgMgcoResValStrDefEnumDef =
{
#ifdef CM_ABNF_DBG
   "ResVal Enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 445,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoResValStrDefEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoResGrpStrDefEnum =
{
#ifdef GCP_MGCO_SHORT_TOKEN
   (Data *)"RG",
#else  /* !GCP_MGCO_SHORT_TOKEN */
   (Data *)"ReservedGroup",
#endif /* !GCP_MGCO_SHORT_TOKEN */
   MGT_LCLCTL_RESGRP
};

PUBLIC CmAbnfElmDef mgMgcoResGrpStrDefEnumDef =
{
#ifdef CM_ABNF_DBG
   "ResGrp Enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 446,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoResGrpStrDefEnum,
   NULLP
};




PUBLIC CmAbnfElmDef *mgMgcoLclParmDefChcEnum[] =
{
   &mgMgcoStreamModeDefEnumDef,
   &mgMgcoResValDefEnumDef,
   &mgMgcoResGrpDefEnumDef,
   &mgMgcoPropParmDefEnumDef
};


PUBLIC CmAbnfElmDef *mgMgcoIndAudLclParmDefChcEnum[] =
{
   &mgMgcoStreamModeStrDefEnumDef,   /* mg002.105: changed to a diff def */
   &mgMgcoResValStrDefEnumDef,       /* mg002.105: changed to a diff def */
   &mgMgcoResGrpStrDefEnumDef,       /* mg002.105: changed to a diff def */
   &mgMgcoPropParmDefEnumDef
};
#ifdef MGT_MGCO_V2
PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudLclParmDefChc =
{
   4,
   0,
   NULLP,
   mgMgcoIndAudLclParmDefChcElmnts,
   mgMgcoIndAudLclParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoIndAudLclParmDef =
{
#ifdef CM_ABNF_DBG
   "Local control parm",
   "ModeResvalResgrpProppars",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 448,
   sizeof(MgMgcoIndAudStreamParm),
   /* mg002.105: removed TKN_NOT_CONSUMED */
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET) |
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoIndAudLclParmDefChc,
   mgMgcoRegExpIndAudLclParm      /* mg002.105: bug fix */
};

PUBLIC CmAbnfElmDef *mgMgcoIndAudLclCtlDescDefSeqElmnts[]   =
{
   &mgMgcoLocalControlTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoIndAudLclParmDef,
   &mgMgcoRBRKTDef
};

/* Local control descriptor */

PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudLclCtlDescDefSeq =
{
   4,
   mgMgcoIndAudLclCtlDescDefSeqElmnts
};

/*
 *   indAudlocalControlDescriptor = LocalControlToken  
 *                                  LBRKT indAudlocalParm RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoIndAudLclCtlDescDef   =
{
#ifdef CM_ABNF_DBG
   "Local control descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 451,
   sizeof(MgMgcoIndAudStreamParm),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudLclCtlDescDefSeq,
   NULLP
};

/* IndAudStream descriptor */
PUBLIC CmAbnfElmDef *mgMgcoIndAudStreamDescDefSeqElmnts[]   =
{
   &mgMgcoStreamTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoStreamIdDef,
   &mgMgcoLBRKTDef,
   &mgMgcoIndAudLclCtlDescDef,
   &mgMgcoRBRKTDef
};


PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudStreamDescDefSeq =
{
   6,
   mgMgcoIndAudStreamDescDefSeqElmnts
};

/*
 *   indAudstreamDescriptor = StreamToken EQUAL StreamID
 *                            LBRKT indAudstreamParm RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoIndAudStreamDescDef   =
{
#ifdef CM_ABNF_DBG
   "Stream descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 456,
   sizeof(MgMgcoIndAudStreamDesc),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudStreamDescDefSeq,
   NULLP
};


PUBLIC CmAbnfElmDef *mgMgcoIndAudMediaParDefChcElmnts[]   =
{
   &mgMgcoIndAudLclCtlDescDef,
   NULLP,
   NULLP,
   &mgMgcoIndAudStreamDescDef,
   &mgMgcoIndAudTermStDescDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudMediaParDefChc =
{
   5,
   0,
   NULLP,
   mgMgcoIndAudMediaParDefChcElmnts,
   mgMgcoIndAudMediaParDefChcEnum
};

/* mediaParm = (streamParm / streamDescriptor / localControlDescriptor) */
PUBLIC CmAbnfElmDef mgMgcoIndAudMediaParDef   =
{
#ifdef CM_ABNF_DBG
   "Media parameter",
   "LrcOrStrmOrTermSt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 458,
   sizeof(MgMgcoIndAudMediaParm),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoIndAudMediaParDefChc,
   mgMgcoRegExpLrcOrStrmOrTermSt
};

/* Media descriptor */
PUBLIC CmAbnfElmDef *mgMgcoIndAudMediaDescDefSeqElmnts[]   =
{
   /* milton &mgMgcoMediaTokenDef,*/
   &mgMgcoLBRKTDef,
   &mgMgcoIndAudMediaParDef,
   &mgMgcoRBRKTDef
};


PUBLIC CmAbnfElmTypeSeq mgMgcoIndAudMediaDescDefSeq =
{
   3,/*milton*/
   mgMgcoIndAudMediaDescDefSeqElmnts
};
/* mediaDescriptor = MediaToken LBRKT mediaParm *(COMMA mediaParm) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoIndAudMediaDescDef   =
{
#ifdef CM_ABNF_DBG
   "Media descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 461,
   sizeof(MgMgcoIndAudMediaParm),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoIndAudMediaDescDefSeq,
   NULLP
};

/* milton element def of mgMgcoAuditItemIndAudTermDef */
/************************************************************************/

PUBLIC CmAbnfElmTypeChoice mgMgcoIndAudauditRetParmDefChc =
{
   12,
   0,
   NULLP,
   mgMgcoIndAudauditRetParmDefChcElmnts,
   mgMgcoIndAudauditRetParmDefChcEnum
};

PUBLIC CmAbnfElmDef *mgMgcoIndAudauditRetParmDefChcEnum[]   =
{
   NULLP, /* No error token */
   &mgMgcoMediaDescEnum,
   NULLP, /* &mgMgcoModemDescEnum,*/
   NULLP, /* &mgMgcoMuxDescEnum, nullp or something like -1 to indicate error */
   &mgMgcoReqEvtDescEnum,
   &mgMgcoEvBufDescEnum,
   &mgMgcoSignalsDescEnum,
   &mgMgcoDigMapDescEnum,
   &mgMgcoObsEvtDescEnum,
   &mgMgcoStatsDescEnum,
   &mgMgcoPkgsDescEnum,
   NULLP /* No audit either */
};

PUBLIC CmAbnfElmDef *mgMgcoIndAudauditRetParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoIndAudMediaDescDef,   
   NULLP,
   NULLP,
   &mgMgcoIndAudReqEvtDescDef, 
   &mgMgcoIndAudEvBufDescDef,   
   &mgMgcoIndAudSignalsDescDef,   
   &mgMgcoIndAudDigMapDescDef, 
   NULLP,
   &mgMgcoIndAudStatsDescDef,   
   &mgMgcoIndAudPkgsDescDef,
   NULLP
};



PUBLIC CmAbnfElmDef mgMgcoIndAudauditRetParmDef=
{
#ifdef CM_ABNF_DBG
   "indAudauditReturnParameter",
   "Desc",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 999,
   sizeof(MgMgcoIndAudAuditRetParm),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoIndAudauditRetParmDefChc,
   mgMgcoRegExpDesc
};



PUBLIC CmAbnfElmTypeSeqOf mgMgcoIndAudauditRetParmArrayDefSeqOf=
{
   1,
   MGT_MAX_IND_AUDIT_RET_PARM,
   2,
   mgMgcoIndAudauditRetParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoIndAudAuditRetParm)
};

PUBLIC CmAbnfElmDef *mgMgcoIndAudauditRetParmArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoIndAudauditRetParmDef
};


PUBLIC CmAbnfElmDef mgMgcoIndAudauditRetParmArrayDef   =
{
#ifdef CM_ABNF_DBG
   "indAudauditReturnParameter array",
   "COMMA WITH TRAILING CHARS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 999,
   sizeof(MgMgcoIndAudTermAudit),
   ((CM_ABNF_OPTIONAL| CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL| CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoIndAudauditRetParmArrayDefSeqOf,
   mgMgcoRegExpCommaTrail
};



PUBLIC CmAbnfElmTypeSeq mgMgcoAuditItemIndAudTermDefSeq =
{
   2,
   mgMgcoAuditItemIndAudTermDefSeqElmnts
};

PUBLIC CmAbnfElmDef *mgMgcoAuditItemIndAudTermDefSeqElmnts[]   =
{
   &mgMgcoIndAudauditRetParmDef,
   &mgMgcoIndAudauditRetParmArrayDef
};



/*indAudterminationAudit   = indAudauditReturnParameter  
                              *(COMMA indAudauditReturnParameter) */ 
PUBLIC CmAbnfElmDef mgMgcoAuditItemIndAudTermDef=
{
#ifdef CM_ABNF_DBG
   "indAudauditReturnParameter",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 999,
   sizeof(MgMgcoIndAudTermAudit),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoAuditItemIndAudTermDefSeq,
   NULLP
};


/************************************************************************/
/* milton end of def*/

#endif /* MGT_MGCO_V2 */

PUBLIC CmAbnfElmDef *mgMgcoLclParmDefChcElmnts[] =
{
   &mgMgcoStreamModeDef,
   &mgMgcoResValDef,
   &mgMgcoResGrpDef,
   &mgMgcoPropParmDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoLclParmDefChc =
{
   4,
   0,
   NULLP,
   mgMgcoLclParmDefChcElmnts,
   mgMgcoLclParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoLclParmDef =
{
#ifdef CM_ABNF_DBG
   "Local control parm",
   "ModeResvalResgrpProppars",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 448,
   sizeof(MgMgcoLocalParm),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoLclParmDefChc,
   mgMgcoRegExpModeResvalResgrpProppars
};

PUBLIC CmAbnfElmDef *mgMgcoLclParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoLclParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoLclParmArrayDefSeqOf =
{
   1,
   MGT_MAX_LCLPARMS,
   2,
   mgMgcoLclParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoLocalParm)
};

PUBLIC CmAbnfElmDef mgMgcoLclParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "Local control parameters array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 449,
   sizeof(MgMgcoLclCtlDesc),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoLclParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA 
};

PUBLIC CmAbnfElmDef *mgMgcoLclCtlDescSetDefSeqElmnts[] =
{
   &mgMgcoLclParmDef,
   &mgMgcoLclParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoLclCtlDescSetDefSeq =
{
   2,
   mgMgcoLclCtlDescSetDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoLclCtlDescSetDef   =
{
#ifdef CM_ABNF_DBG
   "Local control descriptor list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 450,
   sizeof(MgMgcoLclCtlDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoLclCtlDescSetDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoLclCtlDescOptDefSeqElmnts[] =
{
   &mgMgcoLclCtlDescSetDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoLclCtlDescOptDefSeq =
{
   1,
   mgMgcoLclCtlDescOptDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoLclCtlDescOptDef =
{
#ifdef CM_ABNF_DBG
   "Local control descriptor list - opt",
   "ModeResvalResgrpProppars",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 450,
   sizeof(MgMgcoLclCtlDesc),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoLclCtlDescOptDefSeq,
   mgMgcoRegExpModeResvalResgrpProppars
};

/************************************************************************/

/* Local control descriptor */

PUBLIC CmAbnfElmDef *mgMgcoLclCtlDescDefSeqElmnts[]   =
{
   &mgMgcoLocalControlTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoLclCtlDescSetDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoLclCtlDescDefSeq =
{
   4,
   mgMgcoLclCtlDescDefSeqElmnts
};

/* localControlDescriptor = LocalControlToken LBRKT localParm *(COMMA localParm)
 *                          RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoLclCtlDescDef   =
{
#ifdef CM_ABNF_DBG
   "Local control descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 451,
   sizeof(MgMgcoLclCtlDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoLclCtlDescDefSeq,
   NULLP
};

/************************************************************************/

/* Stream parameter */
PUBLIC CmAbnfElmDef *mgMgcoStreamParDefSetElmnts[]   =
{
   &mgMgcoLclCtlDescDef,
   &mgMgcoLocalDescDef,
   &mgMgcoRemoteDescDef
};

PUBLIC CmAbnfElmTypeSet mgMgcoStreamParDefSet =
{
   3,
   mgMgcoStreamParDefSetElmnts,
   &mgMgcoCOMMADef
};

/* streamParm *(COMMA streamParm) from streamDescriptor rule */
PUBLIC CmAbnfElmDef mgMgcoStreamParDef   =
{
#ifdef CM_ABNF_DBG
   "Stream parameter set",
   "LrcOrStrmOrTermSt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 452,
   sizeof(MgMgcoStreamParm),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SET,
   (U8 *)&mgMgcoStreamParDefSet,
   mgMgcoRegExpLrcOrStrmOrTermSt
};

/************************************************************************/

/* Skip nonstd in muxtype */

PUBLIC CmAbnfElmDef mgMgcoMuxTypeSkipDef =
{
#ifdef CM_ABNF_DBG
   "Skip nonstd in muxtype",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 453,
   sizeof(MgMgcoNonStdId),
   (CM_ABNF_OPTIONAL  << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL  << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoMuxTypeDefChcEnum[]   =
{
   &mgMgcoExtnParmEnum,
   &mgMgcoH221Enum,
   &mgMgcoH223Enum,
   &mgMgcoH226Enum,
   &mgMgcoV76Enum,
   &mgMgcoN64Enum
};

PUBLIC CmAbnfElmDef *mgMgcoMuxTypeDefChcElmnts[]   =
{
   &mgMgcoExtnParmDef,
   &mgMgcoMuxTypeSkipDef
};

PUBLIC U8 mgMgcoMuxTypeDefChcIdx[] = {0, 1, 1, 1, 1, 1};

/* Mux type */
PUBLIC CmAbnfElmTypeChoice mgMgcoMuxTypeDefChc =
{
   2,
   6,
   mgMgcoMuxTypeDefChcIdx,
   mgMgcoMuxTypeDefChcElmnts,
   mgMgcoMuxTypeDefChcEnum
};

/* mg004.105: Added support for Nx64 */
/* MuxType              = (H221Token / H223Token / H226Token /  V76Token /
 *                         N64Token /extensionParameter)
 */
PUBLIC CmAbnfElmDef mgMgcoMuxTypeDef   =
{
#ifdef CM_ABNF_DBG
   "Mux type",
   "MuxType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 454,
   sizeof(TknU8) + sizeof(MgMgcoNonStdId),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoMuxTypeDefChc,
   mgMgcoRegExpMuxType
};

/************************************************************************/

/* Mux descriptor */
PUBLIC CmAbnfElmDef *mgMgcoMuxDescDefSeqElmnts[]   =
{
   &mgMgcoMuxTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoMuxTypeDef,
   &mgMgcoTermIdLstDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoMuxDescDefSeq =
{
   4,
   mgMgcoMuxDescDefSeqElmnts
};

/* muxDescriptor        = MuxToken EQUAL MuxType  terminationIDList */
PUBLIC CmAbnfElmDef mgMgcoMuxDescDef   =
{
#ifdef CM_ABNF_DBG
   "Mux descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 455,
   sizeof(MgMgcoMuxDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoMuxDescDefSeq,
   NULLP
};

/************************************************************************/

/* Stream descriptor */
PUBLIC CmAbnfElmDef *mgMgcoStreamDescDefSeqElmnts[]   =
{
   &mgMgcoStreamTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoStreamIdDef,
   &mgMgcoLBRKTDef,
   &mgMgcoStreamParDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoStreamDescDefSeq =
{
   6,
   mgMgcoStreamDescDefSeqElmnts
};

/* streamDescriptor     = StreamToken EQUAL StreamID LBRKT streamParm  
 *                        *(COMMA streamParm) RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoStreamDescDef   =
{
#ifdef CM_ABNF_DBG
   "Stream descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 456,
   sizeof(MgMgcoStreamDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoStreamDescDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoOptRealReqEvtDescDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoRequestIdDef,
   &mgMgcoLBRKTDef,
   &mgMgcoEvtLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptRealReqEvtDescDefSeq =
{
   5,
   mgMgcoOptRealReqEvtDescDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoOptRealReqEvtDescDef =
{
#ifdef CM_ABNF_DBG
   "eventsDescriptor Real Def",
   "EQUAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 468,
   sizeof(MgMgcoReqEvtDesc) - sizeof(TknPres),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptRealReqEvtDescDefSeq,
   mgMgcoRegExpEQUAL
};

/* Events descriptor */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtDescDefSeqElmnts[]   =
{
   &mgMgcoEventsTokenDef,
   &mgMgcoOptRealReqEvtDescDef,
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtDescDefSeq =
{
   2,
   mgMgcoReqEvtDescDefSeqElmnts
};

/* eventsDescriptor     = EventsToken EQUAL RequestID LBRKT
 *                        requestedEvent *( COMMA requestedEvent ) RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoReqEvtDescDef   =
{
#ifdef CM_ABNF_DBG
   "Events descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 457,
   sizeof(MgMgcoReqEvtDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoReqEvtDescDefSeq,
   NULLP
};

/************************************************************************/

/* Media parameter */

PUBLIC CmAbnfElmDef *mgMgcoMediaParDefChcEnum[] =
{
   &mgMgcoMediaParLclCtlDescDefEnumDef,
   &mgMgcoMediaParLocalDescDefEnumDef,
   &mgMgcoMediaParRemoteDescDefEnumDef,
   &mgMgcoMediaParStreamDescDefEnumDef,
   &mgMgcoMediaParTermStDescDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoMediaParDefChcElmnts[]   =
{
   &mgMgcoLclCtlDescDef,
   &mgMgcoLocalDescDef,
   &mgMgcoRemoteDescDef,
   &mgMgcoStreamDescDef,
   &mgMgcoTermStDescDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoMediaParDefChc =
{
   5,
   0,
   NULLP,
   mgMgcoMediaParDefChcElmnts,
   mgMgcoMediaParDefChcEnum
};

/* mediaParm = (streamParm / streamDescriptor / localControlDescriptor) */
PUBLIC CmAbnfElmDef mgMgcoMediaParDef   =
{
#ifdef CM_ABNF_DBG
   "Media parameter",
   "LrcOrStrmOrTermSt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 458,
   sizeof(MgMgcoMediaPar),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoMediaParDefChc,
   mgMgcoRegExpLrcOrStrmOrTermSt
};

/************************************************************************/

/* Media par array */
PUBLIC CmAbnfElmDef *mgMgcoMediaParArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoMediaParDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoMediaParArrayDefSeqOf =
{
   1,
   MGT_MAX_MEDIAPARS,
   2,
   mgMgcoMediaParArrayDefSeqOfElmnts,
   sizeof(MgMgcoMediaPar)
};

/* *(COMMA mediaParm) */
PUBLIC CmAbnfElmDef mgMgcoMediaParArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Media par array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 459,
   sizeof(MgMgcoMediaDesc),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoMediaParArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Media par list */
PUBLIC CmAbnfElmDef *mgMgcoMediaParLstDefSeqElmnts[]   =
{
   &mgMgcoMediaParDef,
   &mgMgcoMediaParArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoMediaParLstDefSeq =
{
   2,
   mgMgcoMediaParLstDefSeqElmnts
};

/* mediaParm *(COMMA mediaParm) */
PUBLIC CmAbnfElmDef mgMgcoMediaParLstDef   =
{
#ifdef CM_ABNF_DBG
   "Media par list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 460,
   sizeof(MgMgcoMediaDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoMediaParLstDefSeq,
   NULLP
};

/************************************************************************/

/* Media descriptor */
PUBLIC CmAbnfElmDef *mgMgcoMediaDescDefSeqElmnts[]   =
{
   &mgMgcoMediaTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoMediaParLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoMediaDescDefSeq =
{
   4,
   mgMgcoMediaDescDefSeqElmnts
};

/* mediaDescriptor = MediaToken LBRKT mediaParm *(COMMA mediaParm) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoMediaDescDef   =
{
#ifdef CM_ABNF_DBG
   "Media descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 461,
   sizeof(MgMgcoMediaDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoMediaDescDefSeq,
   NULLP
};

/************************************************************************/

/* Audit return parm */
/* NOTE: assumes auditItem will be replaced by auditDescriptor */
PUBLIC CmAbnfElmDef *mgMgcoAudRetParmChcEnum[]   =
{
   &mgMgcoErrDescDefEnumDef,
   &mgMgcoMediaDescDefEnumDef,
   &mgMgcoModemDescDefEnumDef,
   &mgMgcoMuxDescDefEnumDef,
   &mgMgcoReqEvtDescDefEnumDef,
   &mgMgcoEvBufDescDefEnumDef,
   &mgMgcoSignalsDescDefEnumDef,
   &mgMgcoDigMapDescDefEnumDef,
   &mgMgcoObsEvtDescDefEnumDef,
   &mgMgcoStatsDescDefEnumDef,
   &mgMgcoPkgsDescDefEnumDef,
   &mgMgcoAuditDescDefEnumDef,
};

PUBLIC CmAbnfElmDef *mgMgcoAudRetParmChcElmnts[]   =
{
   &mgMgcoErrDescDef,
   &mgMgcoMediaDescDef,
   &mgMgcoModemDescDef,
   &mgMgcoMuxDescDef,
   &mgMgcoReqEvtDescDef,
   &mgMgcoEvBufDescDef,
   &mgMgcoSignalsDescDef,
   &mgMgcoDigMapDescDef,
   &mgMgcoObsEvtDescDef,
   &mgMgcoStatsDescDef,
   &mgMgcoPkgsDescDef,
   &mgMgcoAuditItemDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoAudRetParmChc =
{
   12,
   0,
   NULLP,
   mgMgcoAudRetParmChcElmnts,
   mgMgcoAudRetParmChcEnum
};


/*
 *   As per the IG, auditReturnParameter now has auditReturnItem
 *   instead of auditItem. We are not changing this database for
 *   supporting this change. However, the test database is being
 *   changed. AuditReturnItem has less items than auditItem,
 *   specifically, these items are absent - eventBufferDescriptor,
 *   eventsDescriptor, signalsDescriptor since these introduce
 *   ambiguities.
 */

PUBLIC CmAbnfElmDef mgMgcoAudRetParmDef   =
{
#ifdef CM_ABNF_DBG
   "Audit return parameter",
   "AudRet",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 462,
   sizeof(MgMgcoAudRetParm),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoAudRetParmChc,
   mgMgcoRegExpAudRet /* Unnecessary but for auditItem */
};

/************************************************************************/

/* Audit return parm array */
PUBLIC CmAbnfElmDef *mgMgcoAudRetParmArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoAudRetParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoAudRetParmArrayDefSeqOf =
{
   1,
   MGT_MAX_AUDRETPARMS,
   2,
   mgMgcoAudRetParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoAudRetParm)
};

/* *(COMMA  auditReturnParameter) */
PUBLIC CmAbnfElmDef mgMgcoAudRetParmArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Audit return parm array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 463,
   sizeof(MgMgcoTermAuditRes),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoAudRetParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};
/************************************************************************/

/* Termination audit */
PUBLIC CmAbnfElmDef *mgMgcoTermAuditResDefSeqElmnts[]   =
{
   &mgMgcoAudRetParmDef,
   &mgMgcoAudRetParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoTermAuditResDefSeq =
{
   2,
   mgMgcoTermAuditResDefSeqElmnts
};

/* terminationAudit = auditReturnParameter *(COMMA  auditReturnParameter) */
PUBLIC CmAbnfElmDef mgMgcoTermAuditResDef   =
{
#ifdef CM_ABNF_DBG
   "Termination audit",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 464,
   sizeof(MgMgcoTermAuditRes),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoTermAuditResDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoOptTermAuditResSetSeqElmnts[]   =
{
   &mgMgcoLBRKTDef,
   &mgMgcoTermAuditResDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptTermAuditResSetSeq =
{
   3,
   mgMgcoOptTermAuditResSetSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoOptTermAuditResSet =
{
#ifdef CM_ABNF_DBG
   "TerminationAudit in auditOther 2",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 468,
   sizeof(MgMgcoTermAuditRes),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptTermAuditResSetSeq ,
   mgMgcoRegExpLBRKT
};

/* Audit - other */
PUBLIC CmAbnfElmDef *mgMgcoAuditOtherDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoTermIdDef,
   &mgMgcoOptTermAuditResSet,
};

PUBLIC CmAbnfElmTypeSeq mgMgcoAuditOtherDefSeq =
{
   3,
   mgMgcoAuditOtherDefSeqElmnts
};

/* auditOther  = EQUAL TerminationID [ LBRKT  terminationAudit RBRKT ] */
PUBLIC CmAbnfElmDef mgMgcoAuditOtherDef   =
{
#ifdef CM_ABNF_DBG
   "Audit - other",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 465,
   sizeof(MgMgcoAuditOther),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoAuditOtherDefSeq,
   NULLP
};

/************************************************************************/

/* Audit error */
PUBLIC CmAbnfElmDef *mgMgcoCxtErrDescDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoCtxTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoErrDescDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoCxtErrDescDefSeq =
{
   5,
   mgMgcoCxtErrDescDefSeqElmnts
};

/* EQUAL CtxToken LBRKT errorDescriptor RBRKT */
PUBLIC CmAbnfElmDef mgMgcoCxtErrDescDef   =
{
#ifdef CM_ABNF_DBG
   "Audit error",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 466,
   sizeof(MgMgcoErrDesc),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoCxtErrDescDefSeq,
   NULLP
};

/************************************************************************/

/* Context audit */
PUBLIC CmAbnfElmDef *mgMgcoCxtAuditDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoCtxTokenDef,
   &mgMgcoTermIdLstDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoCxtAuditDefSeq =
{
   3,
   mgMgcoCxtAuditDefSeqElmnts
};

/* EQUAL CtxToken terminationIDList */
PUBLIC CmAbnfElmDef mgMgcoCxtAuditDef   =
{
#ifdef CM_ABNF_DBG
   "Context audit",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 467,
   sizeof(MgMgcoTermIdLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoCxtAuditDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoAuditReplyErrDescDefSeqElmnts[] =
{
   &mgMgcoEQUALDef,
   &mgMgcoCtxTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoErrDescDef,
   &mgMgcoRBRKTDef,
};

PUBLIC CmAbnfElmTypeSeq mgMgcoAuditReplyErrDescDefSeq =
{
   5,
   mgMgcoAuditReplyErrDescDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoAuditReplyErrDescDef =
{
#ifdef CM_ABNF_DBG
   "ErrDesc in AuditReply",
   "EQUAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 468,
   sizeof(MgMgcoErrDesc),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoAuditReplyErrDescDefSeq,
   mgMgcoRegExpEQUAL
};



/* Audit reply */

PUBLIC CmAbnfElmDef *mgMgcoAuditReplyDefChcEnum[]   =
{
   &mgMgcoErrDescDefEnumDef,
   &mgMgcoCxtAuditDefEnumDef,
   &mgMgcoAuditOtherDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoAuditReplyDefChcElmnts[]   =
{
   &mgMgcoAuditReplyErrDescDef,
   &mgMgcoCxtAuditDef,
   &mgMgcoAuditOtherDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoAuditReplyDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoAuditReplyDefChcElmnts,
   mgMgcoAuditReplyDefChcEnum
};

/* auditReply           = (AuditValueToken / AuditCapToken)
 *                        (contextTerminationAudit  / auditOther)
 * auditOther           = EQUAL TerminationID LBRKT terminationAudit RBRKT
 * contextTerminationAudit = EQUAL CtxToken 
 *                            (terminationIDList /  
 *                             LBRKT errorDescriptor RBRKT)
 */
PUBLIC CmAbnfElmDef mgMgcoAuditReplyDef   =
{
#ifdef CM_ABNF_DBG
   "Audit reply",
   "ErrCxtTerm",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 469,
   sizeof(MgMgcoAuditReply),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoAuditReplyDefChc,
   mgMgcoRegExpErrCxtTerm
};

/************************************************************************/

/* Audit request */
PUBLIC CmAbnfElmDef *mgMgcoAuditReqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoTermIdDef,
   &mgMgcoLBRKTDef,
   &mgMgcoAuditDescDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoAuditReqDefSeq =
{
   5,
   mgMgcoAuditReqDefSeqElmnts
};

/* auditRequest         = ["W-"] (AuditValueToken / AuditCapToken) EQUAL
 *                        TerminationID LBRKT auditDescriptor RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoAuditReqDef   =
{
#ifdef CM_ABNF_DBG
   "Audit request",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 470,
   sizeof(MgMgcoSubAudReq),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoAuditReqDefSeq,
   NULLP
};

/************************************************************************/

/* Optional error descriptor */
PUBLIC CmAbnfElmDef *mgMgcoOptCommaErrDescDefSeqElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoErrDescDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptCommaErrDescDefSeq =
{
   2,
   mgMgcoOptCommaErrDescDefSeqElmnts
};

/* [ COMMA errorDescriptor ] */
PUBLIC CmAbnfElmDef mgMgcoOptCommaErrDescDef   =
{
#ifdef CM_ABNF_DBG
   "Optional error descriptor",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 471,
   sizeof(MgMgcoErrDesc),
   ((CM_ABNF_TKN_NOT_CONSUMED| CM_ABNF_OPTIONAL) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_TKN_NOT_CONSUMED| CM_ABNF_OPTIONAL) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptCommaErrDescDefSeq,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Notify request */
PUBLIC CmAbnfElmDef *mgMgcoNtfyReqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoTermIdDef,
   &mgMgcoLBRKTDef,
   &mgMgcoObsEvtDescDef,
   &mgMgcoOptCommaErrDescDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoNtfyReqDefSeq =
{
   6,
   mgMgcoNtfyReqDefSeqElmnts
};

/* notifyRequest        = NotifyToken EQUAL TerminationID  LBRKT
 *                        observedEventsDescriptor  [COMMA errorDescriptor]
 *                        RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoNtfyReqDef   =
{
#ifdef CM_ABNF_DBG
   "Notify request",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 472,
   sizeof(MgMgcoNtfyReq),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoNtfyReqDefSeq,
   NULLP
};

/************************************************************************/

/* Bracketed error descriptor */
PUBLIC CmAbnfElmDef *mgMgcoOptBracErrDescDefSeqElmnts[]   =
{
   &mgMgcoLBRKTDef,
   &mgMgcoErrDescDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptBracErrDescDefSeq =
{
   3,
   mgMgcoOptBracErrDescDefSeqElmnts
};

/* [LBRKT errorDescriptor RBRKT] */
PUBLIC CmAbnfElmDef mgMgcoOptBracErrDescDef   =
{
#ifdef CM_ABNF_DBG
   "Bracketed error descriptor",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 473,
   sizeof(MgMgcoErrDesc),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptBracErrDescDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

/* Notify reply */
PUBLIC CmAbnfElmDef *mgMgcoNtfyReplyDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoTermIdDef,
   &mgMgcoOptBracErrDescDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoNtfyReplyDefSeq =
{
   3,
   mgMgcoNtfyReplyDefSeqElmnts
};

/* notifyReply          = NotifyToken EQUAL TerminationID  
 *                        [LBRKT errorDescriptor RBRKT]
 */
PUBLIC CmAbnfElmDef mgMgcoNtfyReplyDef   =
{
#ifdef CM_ABNF_DBG
   "Notify reply",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 474,
   sizeof(MgMgcoNtfyReply),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoNtfyReplyDefSeq,
   NULLP
};

/************************************************************************/

/* Service change request */
PUBLIC CmAbnfElmDef *mgMgcoSvcChgReqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoTermIdDef,
   &mgMgcoLBRKTDef,
   &mgMgcoSvcChgReqDescDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSvcChgReqDefSeq =
{
   5,
   mgMgcoSvcChgReqDefSeqElmnts
};

/* serviceChangeRequest = ServiceChangeToken EQUAL TerminationID LBRKT
 *                        serviceChangeDescriptor RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoSvcChgReqDef   =
{
#ifdef CM_ABNF_DBG
   "Service change request",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 475,
   sizeof(MgMgcoSvcChgReq),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoSvcChgReqDefSeq,
   NULLP
};

/************************************************************************/

/* Error or Service change result */
PUBLIC CmAbnfElmDef *mgMgcoErrOrSvcResDefChcEnum[]   =
{
   &mgMgcoErrDescDefEnumDef,
   &mgMgcoSvcChgDescDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoErrOrSvcResDefChcElmnts[]   =
{
   &mgMgcoErrDescDef,
   &mgMgcoSvcChgReplyDescDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoErrOrSvcResDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoErrOrSvcResDefChcElmnts,
   mgMgcoErrOrSvcResDefChcEnum
};

/* (errorDescriptor / serviceChangeReplyDescriptor) */
PUBLIC CmAbnfElmDef mgMgcoErrOrSvcResDef   =
{
#ifdef CM_ABNF_DBG
   "Error or Service change result",
   "ErrOrSvc",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 476,
   sizeof(MgMgcoSvcChgRes),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoErrOrSvcResDefChc,
   mgMgcoRegExpErrOrSvc
};

/************************************************************************/

/* (Opt) Error or Service change result */

PUBLIC CmAbnfElmDef *mgMgcoOptErrOrSvcResDefSeqElmnts[]   =
{
   &mgMgcoLBRKTDef,
   &mgMgcoErrOrSvcResDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptErrOrSvcResDefSeq =
{
   3,
   mgMgcoOptErrOrSvcResDefSeqElmnts
};

/* [LBRKT (errorDescriptor / serviceChangeReplyDescriptor) RBRKT] */
PUBLIC CmAbnfElmDef mgMgcoOptErrOrSvcResDef   =
{
#ifdef CM_ABNF_DBG
   "(Opt) Error or Service change result",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 477,
   sizeof(MgMgcoSvcChgRes),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptErrOrSvcResDefSeq,
   mgMgcoRegExpLBRKT
};


/************************************************************************/

/* Service change reply */
PUBLIC CmAbnfElmDef *mgMgcoSvcChgReplyDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoTermIdDef,
   &mgMgcoOptErrOrSvcResDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSvcChgReplyDefSeq =
{
   3,
   mgMgcoSvcChgReplyDefSeqElmnts
};

/* serviceChangeReply   = ServiceChangeToken EQUAL TerminationID
 *                        [LBRKT (errorDescriptor /
 *                        serviceChangeReplyDescriptor) RBRKT]
 */
PUBLIC CmAbnfElmDef mgMgcoSvcChgReplyDef   =
{
#ifdef CM_ABNF_DBG
   "Service change reply",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 478,
   sizeof(MgMgcoSvcChgReply),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoSvcChgReplyDefSeq,
   NULLP
};

/************************************************************************/

/* Optional audit descriptor */
PUBLIC CmAbnfElmDef *mgMgcoOptAuditDescDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoAuditDescDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptAuditDescDefSeq =
{
   3,
   mgMgcoOptAuditDescDefSeqElmnts
};

/* [LBRKT auditDescriptor RBRKT] */
PUBLIC CmAbnfElmDef mgMgcoOptAuditDescDef =
{
#ifdef CM_ABNF_DBG
   "Optional audit descriptor",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 479,
   sizeof(MgMgcoAuditDesc),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptAuditDescDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

/* Subtract request */
PUBLIC CmAbnfElmDef *mgMgcoSubReqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoTermIdDef,
   &mgMgcoOptAuditDescDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSubReqDefSeq =
{
   3,
   mgMgcoSubReqDefSeqElmnts
};

/* subtractRequest      =  ["W-"] SubtractToken EQUAL TerminationID
 *                         [LBRKT auditDescriptor RBRKT]
 */
PUBLIC CmAbnfElmDef mgMgcoSubReqDef   =
{
#ifdef CM_ABNF_DBG
   "Subtract request",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 480,
   sizeof(MgMgcoSubAudReq),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoSubReqDefSeq,
   NULLP
};
/************************************************************************/

/* Optional termination audit */
PUBLIC CmAbnfElmDef *mgMgcoOptTermAuditDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoTermAuditResDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptTermAuditDefSeq =
{
   3,
   mgMgcoOptTermAuditDefSeqElmnts
};

/* [LBRKT terminationAudit RBRKT] */
PUBLIC CmAbnfElmDef mgMgcoOptTermAuditDef =
{
#ifdef CM_ABNF_DBG
   "Optional termination audit",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 481,
   sizeof(MgMgcoTermAuditRes),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptTermAuditDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

/* AMMS reply */
PUBLIC CmAbnfElmDef *mgMgcoAmmsReplyDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoTermIdDef,
   &mgMgcoOptTermAuditDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoAmmsReplyDefSeq =
{
   3,
   mgMgcoAmmsReplyDefSeqElmnts
};

/* ammsReply  = (AddToken / MoveToken / ModifyToken / SubtractToken)
 *              EQUAL TerminationID [LBRKT terminationAudit RBRKT]
 */
PUBLIC CmAbnfElmDef mgMgcoAmmsReplyDef   =
{
#ifdef CM_ABNF_DBG
   "AMMS reply",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 482,
   sizeof(MgMgcoAmmsReply),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoAmmsReplyDefSeq,
   NULLP
};

/************************************************************************/

/* AMM parameter */

PUBLIC CmAbnfElmDef *mgMgcoAmmParmDefChcEnum[]   =
{
   &mgMgcoErrDescDefEnumDef,
   &mgMgcoMediaDescDefEnumDef,
   &mgMgcoModemDescDefEnumDef,
   &mgMgcoMuxDescDefEnumDef,
   &mgMgcoReqEvtDescDefEnumDef,
   &mgMgcoEvBufDescDefEnumDef,
   &mgMgcoSignalsDescDefEnumDef,
   &mgMgcoDigMapDescDefEnumDef,
   &mgMgcoObsEvtDescDefEnumDef,
   &mgMgcoStatsDescDefEnumDef,
   &mgMgcoPkgsDescDefEnumDef,
   &mgMgcoAuditDescDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoAmmParmDefChcElmnts[]   =
{
   &mgMgcoErrDescDef,
   &mgMgcoMediaDescDef,
   &mgMgcoModemDescDef,
   &mgMgcoMuxDescDef,
   &mgMgcoReqEvtDescDef,
   &mgMgcoEvBufDescDef,
   &mgMgcoSignalsDescDef,
   &mgMgcoDigMapDescDef,
   NULLP,
   NULLP,
   NULLP,
   &mgMgcoAuditDescDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoAmmParmDefChc =
{
   12,
   0,
   NULLP,
   mgMgcoAmmParmDefChcElmnts,
   mgMgcoAmmParmDefChcEnum
};

/* ammParameter         = (mediaDescriptor / modemDescriptor /  muxDescriptor
 *                         / eventsDescriptor /  signalsDescriptor /
 *                         digitMapDescriptor / eventBufferDescriptor /
 *                         auditDescriptor)
 */
PUBLIC CmAbnfElmDef mgMgcoAmmParmDef   =
{
#ifdef CM_ABNF_DBG
   "AMM parameter",
   "Desc",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 483,
   sizeof(MgMgcoAmmDesc),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoAmmParmDefChc,
   mgMgcoRegExpDesc
};

/************************************************************************/

/* AMM parameter array */
PUBLIC CmAbnfElmDef *mgMgcoAmmParmArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoAmmParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoAmmParmArrayDefSeqOf =
{
   1,
   MGT_MAX_AMMPARMS,
   2,
   mgMgcoAmmParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoAmmDesc)
};

/* *(COMMA ammParameter) */
PUBLIC CmAbnfElmDef mgMgcoAmmParmArrayDef   =
{
#ifdef CM_ABNF_DBG
   "AMM parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 484,
   sizeof(MgMgcoAmmDescLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoAmmParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* AMM parameter list */
PUBLIC CmAbnfElmDef *mgMgcoAmmParmLstDefSeqElmnts[]   =
{
   &mgMgcoAmmParmDef,
   &mgMgcoAmmParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoAmmParmLstDefSeq =
{
   2,
   mgMgcoAmmParmLstDefSeqElmnts
};

/* ammParameter *(COMMA ammParameter) */
PUBLIC CmAbnfElmDef mgMgcoAmmParmLstDef   =
{
#ifdef CM_ABNF_DBG
   "AMM parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 485,
   sizeof(MgMgcoAmmDescLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoAmmParmLstDefSeq,
   NULLP
};

/************************************************************************/

/* Optional AMM parameter list */
PUBLIC CmAbnfElmDef *mgMgcoOptAmmParmLstDefSeqElmnts[]   =
{
   &mgMgcoLBRKTDef,
   &mgMgcoAmmParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptAmmParmLstDefSeq =
{
   3,
   mgMgcoOptAmmParmLstDefSeqElmnts
};

/* [LBRKT ammParameter *(COMMA ammParameter) RBRKT] */
PUBLIC CmAbnfElmDef mgMgcoOptAmmParmLstDef   =
{
#ifdef CM_ABNF_DBG
   "Optional AMM parameter list",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 486,
   sizeof(MgMgcoAmmDescLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoOptAmmParmLstDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

/* Add/Move/Modify request */
PUBLIC CmAbnfElmDef *mgMgcoAmmReqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoTermIdDef,
   &mgMgcoOptAmmParmLstDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoAmmReqDefSeq =
{
   3,
   mgMgcoAmmReqDefSeqElmnts
};

/* ammRequest           = (AddToken / MoveToken / ModifyToken ) EQUAL
 *       TerminationID [LBRKT ammParameter *(COMMA ammParameter) RBRKT]
 */
PUBLIC CmAbnfElmDef mgMgcoAmmReqDef   =
{
#ifdef CM_ABNF_DBG
   "Add/Move/Modify request",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 487,
   sizeof(MgMgcoAmmReq),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoAmmReqDefSeq,
   NULLP
};
/************************************************************************/

/* Command reply */
PUBLIC CmAbnfElmDef *mgMgcoCmdReplyDefChcEnum[]   =
{
   &mgMgcoAddEnum,
   &mgMgcoMoveEnum,
   &mgMgcoModEnum,
   &mgMgcoSubEnum,
   &mgMgcoAudCapEnum,
   &mgMgcoAudValEnum,
   &mgMgcoNtfyEnum,
   &mgMgcoSvcChgEnum
};

PUBLIC CmAbnfElmDef *mgMgcoCmdReplyDefChcElmnts[]   =
{
   &mgMgcoAmmsReplyDef,
   &mgMgcoAuditReplyDef,
   &mgMgcoNtfyReplyDef,
   &mgMgcoSvcChgReplyDef
};

PUBLIC U8 mgMgcoCmdReplyDefChcIdx[] = {0, 0, 0, 0, 1, 1, 2, 3};

PUBLIC CmAbnfElmTypeChoice mgMgcoCmdReplyDefChc =
{
   4,
   8,
   mgMgcoCmdReplyDefChcIdx,
   mgMgcoCmdReplyDefChcElmnts,
   mgMgcoCmdReplyDefChcEnum
};

/* commandReplys        = (serviceChangeReply / auditReply / ammsReply  /
 *                         notifyReply)
 */
PUBLIC CmAbnfElmDef mgMgcoCmdReplyDef   =
{
#ifdef CM_ABNF_DBG
   "Command reply",
   "CmdReply",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 488,
   sizeof(MgMgcoCmdReply) - sizeof(TknPres) * 2,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoCmdReplyDefChc,
   mgMgcoRegExpCmdReply
};

PUBLIC CmAbnfElmDef *mgMgcoWildCmdReplyDefSeqElmnts[] =
{
   &mgMgcoOptWHyphenDef,
   &mgMgcoCmdReplyDef,
};

PUBLIC CmAbnfElmTypeSeq mgMgcoWildCmdReplyDefSeq =
{
   2,
   mgMgcoWildCmdReplyDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoWildCmdReplyDef =
{
#ifdef CM_ABNF_DBG
   "CmdReply with opt W-",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 489,
   sizeof(MgMgcoCmdReply),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoWildCmdReplyDefSeq,
   NULLP
};

/************************************************************************/

/* Command reply array */
PUBLIC CmAbnfElmDef *mgMgcoCmdReplyArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoWildCmdReplyDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoCmdReplyArrayDefSeqOf =
{
   1,
   MGT_MAX_CMDREPLYS,
   2,
   mgMgcoCmdReplyArrayDefSeqOfElmnts,
   sizeof(MgMgcoCmdReply)
};

/* *(COMMA commandReplys) */
PUBLIC CmAbnfElmDef mgMgcoCmdReplyArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Command reply array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 490,
   sizeof(MgMgcoCmdReplyLst),
   ((CM_ABNF_OPTIONAL  | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL  | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoCmdReplyArrayDefSeqOf,
   mgMgcoRegExpCommaCmdReplys
   /* mgMgcoRegExpCOMMA */
};

#ifdef GCP_CH
 /* Escape function for command reply */
PUBLIC CmAbnfElmTypeMarker mgMgcoCmdRepArrayMarker =
{
   CM_ABNF_MARKER_ESC_FUNC,
   (U8 *)mgMgcoEscFuncCmdRepArray
};

PUBLIC CmAbnfElmDef mgMgcoCHCmdRepArrayDef =
{
#ifdef CM_ABNF_DBG
   "Marker PkgName",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 125,
   0,
   0,
   CM_ABNF_TYPE_MARKER,
   (U8 *)&mgMgcoCmdRepArrayMarker,
   NULLP
};

#endif /* GCP_CH  */


/************************************************************************/

/* Command reply list */
PUBLIC CmAbnfElmDef *mgMgcoOptCmdReplyLstDefSeqElmnts[]   =
{
   &mgMgcoWildCmdReplyDef,
#ifdef GCP_CH
   &mgMgcoCHCmdRepArrayDef
#else
   &mgMgcoCmdReplyArrayDef
#endif
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptCmdReplyLstDefSeq =
{
   2,
   mgMgcoOptCmdReplyLstDefSeqElmnts
};

/* commandReplyList     = commandReplys *(COMMA commandReplys) */
PUBLIC CmAbnfElmDef mgMgcoOptCmdReplyLstDef   =
{
#ifdef CM_ABNF_DBG
   "Command reply list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 491,
   sizeof(MgMgcoCmdReplyLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoOptCmdReplyLstDefSeq,
   NULLP /* comes here through mgMgcoRegExpCxtPropsOrCmdReply */
};

#ifdef GCP_CH

PUBLIC CmAbnfElmTypeMarker mgMgcoCmdRepLstMarker =
{
   CM_ABNF_MARKER_ESC_FUNC,
   (U8 *)mgMgcoEscFuncCmdRepLst
};

PUBLIC CmAbnfElmDef mgMgcoCHOptCmdRepLstDef  =
{
#ifdef CM_ABNF_DBG
   "Marker PkgName",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 125,
   0,
   0,
   CM_ABNF_TYPE_MARKER,
   (U8 *)&mgMgcoCmdRepLstMarker,
   NULLP
};

#endif /* GCP_CH  */

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoCommaCmdReplysDefSeqElmnts[]   =
{
   &mgMgcoCOMMADef,
};

PUBLIC CmAbnfElmTypeSeq mgMgcoCommaCmdReplysDefSeq =
{
   1,
   mgMgcoCommaCmdReplysDefSeqElmnts
};


PUBLIC CmAbnfElmDef mgMgcoCommaCmdReplysDef   =
{
#ifdef CM_ABNF_DBG
   "Command reply list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 491,
   0,
   ((CM_ABNF_OPTIONAL  | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL  | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoCommaCmdReplysDefSeq,
   mgMgcoRegExpCommaCmdReplys
};

/************************************************************************/

/* Context command reply - called "commandReply" in text */
PUBLIC CmAbnfElmDef *mgMgcoCxtCmdReplyDefSetElmnts[]   =
{
   &mgMgcoOptContextPropsDef,
#ifdef GCP_CH
   &mgMgcoCHOptCmdRepLstDef
#else
   &mgMgcoOptCmdReplyLstDef
#endif
};

PUBLIC CmAbnfElmTypeSet mgMgcoCxtCmdReplyDefSet =
{
   2,
   mgMgcoCxtCmdReplyDefSetElmnts,
   &mgMgcoCommaCmdReplysDef /* NULLP ,[RA] &mgMgcoCOMMADef */
};

/* commandReply       = (
 *    (contextProperties [COMMA commandReplyList]) / commandReplyList 
 *                      )
 */
PUBLIC CmAbnfElmDef mgMgcoCxtCmdReplyDef   =
{
#ifdef CM_ABNF_DBG
   "Context command reply",
   "CxtPropsOrCmdReply",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 492,
   sizeof(MgMgcoCxtCmdReply),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SET,
   (U8 *)&mgMgcoCxtCmdReplyDefSet,
   mgMgcoRegExpCxtPropsOrCmdReply
};


/************************************************************************/


#ifdef MGT_GCP_VER_1_4

/* ErrorOrCmdReply */
PUBLIC CmAbnfElmDef *mgMgcoErrorCmdReplyDefSetElmnts[]   =
{
   &mgMgcoErrDescDef,
   &mgMgcoCxtCmdReplyDef
};

PUBLIC CmAbnfElmTypeSet mgMgcoErrorCmdReplyDefSet =
{
   2,
   mgMgcoErrorCmdReplyDefSetElmnts,
   &mgMgcoCOMMADef
};

/* (errorDescriptor / commandReply) / (commandReply COMMA errorDescriptor) */
PUBLIC CmAbnfElmDef mgMgcoErrorCmdReplySetDef   =
{
#ifdef CM_ABNF_DBG
   "ErrorCmdReplySet",
   "ErrorOrCmdReplyFirst", 
   /* CmdReplyFirst = TopologyToken / EmergencyToken /  PriorityToken /
    * AddToken / MoveToken / ModifyToken / ServiceChangeToken /
    * NotifyToken / SubtractToken / AuditValueToken / AuditCapToken
    */
#endif /* CM_ABNF_DBG */
    CM_ABNF_ELMNID_MGCO_BASE + 493,
    sizeof (MgMgcoErrCmdRepSet),
    ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
    CM_ABNF_TYPE_SET,
    (U8 *)&mgMgcoErrorCmdReplyDefSet,
    mgMgcoRegExpErrorOrCmdReplyFirst
};

#else /* MGT_GCP_VER_1_4 */

/* ErrorOrCmdReply */
PUBLIC CmAbnfElmDef *mgMgcoErrorOrCmdReplyDefChcEnum[]   =
{
   &mgMgcoErrDescDefEnumDef,
   &mgMgcoCxtCmdReplyDefEnumDef 
};

PUBLIC CmAbnfElmDef *mgMgcoErrorOrCmdReplyDefChcElmnts[]   =
{
   &mgMgcoErrDescDef,
   &mgMgcoCxtCmdReplyDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoErrorOrCmdReplyDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoErrorOrCmdReplyDefChcElmnts,
   mgMgcoErrorOrCmdReplyDefChcEnum
};

/* errorDescriptor / commandReply */
PUBLIC CmAbnfElmDef mgMgcoErrorOrCmdReplyDef   =
{
#ifdef CM_ABNF_DBG
   "ErrorOrCmdReply",
   "ErrorOrCmdReplyFirst", 
   /* CmdReplyFirst = TopologyToken / EmergencyToken /  PriorityToken /
    * AddToken / MoveToken / ModifyToken / ServiceChangeToken /
    * NotifyToken / SubtractToken / AuditValueToken / AuditCapToken
    */
#endif /* CM_ABNF_DBG */
    CM_ABNF_ELMNID_MGCO_BASE + 493,
    sizeof(((MgMgcoActnReply *)0)->u) + sizeof(TknU8),
    ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
    CM_ABNF_TYPE_CHOICE,
    (U8 *)&mgMgcoErrorOrCmdReplyDefChc,
    mgMgcoRegExpErrorOrCmdReplyFirst
};

#endif /* MGT_GCP_VER_1_4 */



/************************************************************************/

/* Action reply */
PUBLIC CmAbnfElmDef *mgMgcoActionReplyDefSeqElmnts[]   =
{
   &mgMgcoCtxTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoContextIdDef,
   &mgMgcoLBRKTDef,
#ifdef MGT_GCP_VER_1_4
   &mgMgcoErrorCmdReplySetDef,
#else
   &mgMgcoErrorOrCmdReplyDef,
#endif /* MGT_GCP_VER_1_4 */
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoActionReplyDefSeq =
{
   6,
   mgMgcoActionReplyDefSeqElmnts
};

/* actionReply          = CtxToken EQUAL ContextID LBRKT
 * (errorDescriptor / commandReply) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoActionReplyDef   =
{
#ifdef CM_ABNF_DBG
   "Action reply",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 494,
   sizeof(MgMgcoActnReply),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoActionReplyDefSeq,
   NULLP
};

/************************************************************************/

/* Action reply array */
PUBLIC CmAbnfElmDef *mgMgcoActionReplyArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoActionReplyDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoActionReplyArrayDefSeqOf =
{
   1,
   MGT_MAX_ACTIONREPLYS,
   2,
   mgMgcoActionReplyArrayDefSeqOfElmnts,
   sizeof(MgMgcoActnReply)
};

/* *(COMMA actionReply) */
PUBLIC CmAbnfElmDef mgMgcoActionReplyArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Action reply array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 495,
   sizeof(MgMgcoActnReplyLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoActionReplyArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Action reply list */
PUBLIC CmAbnfElmDef *mgMgcoActionReplyLstDefSeqElmnts[]   =
{
   &mgMgcoActionReplyDef,
   &mgMgcoActionReplyArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoActionReplyLstDefSeq =
{
   2,
   mgMgcoActionReplyLstDefSeqElmnts
};

/* actionReplyList      = actionReply *(COMMA actionReply) */
PUBLIC CmAbnfElmDef mgMgcoActionReplyLstDef   =
{
#ifdef CM_ABNF_DBG
   "Action reply list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 496,
   sizeof(MgMgcoActnReplyLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoActionReplyLstDefSeq,
   NULLP,
};

/************************************************************************/

/* ErrorDescOrReplyList */
PUBLIC CmAbnfElmDef *mgMgcoErrorOrReplyDefChcEnum[]   =
{
   &mgMgcoErrDescDefEnumDef,
   &mgMgcoCtxTokenDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoErrorOrReplyDefChcElmnts[]   =
{
   &mgMgcoErrDescDef,
   &mgMgcoActionReplyLstDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoErrorOrReplyDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoErrorOrReplyDefChcElmnts,
   mgMgcoErrorOrReplyDefChcEnum
};

/* errorDescriptor / actionReplyList */
PUBLIC CmAbnfElmDef mgMgcoErrorOrReplyDef   =
{
#ifdef CM_ABNF_DBG
   "ErrorDescOrReplyList",
   "ErrorOrCtx",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 497,
   sizeof(((MgMgcoTxnReply *)0)->u) + sizeof(TknU8),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoErrorOrReplyDefChc,
   mgMgcoRegExpErrorOrCtx 
};

/************************************************************************/

/* Immediate ack required */
PUBLIC CmAbnfElmDef *mgMgcoOptImmAckDefSeqElmnts[]   =
{
   &mgMgcoImmAckTokenDef,
   &mgMgcoCOMMADef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptImmAckDefSeq =
{
   2,
   mgMgcoOptImmAckDefSeqElmnts
};

/* [ImmAckRequiredToken COMMA] */
PUBLIC CmAbnfElmDef mgMgcoOptImmAckDef   =
{
#ifdef CM_ABNF_DBG
   "Immediate ack required",
   "ImmAckToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 498,
   sizeof(TknPres),  /* BOOL */
   ((CM_ABNF_TKN_NOT_CONSUMED| CM_ABNF_OPTIONAL) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_TKN_NOT_CONSUMED| CM_ABNF_OPTIONAL) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoOptImmAckDefSeq,
   mgMgcoRegExpImmAckToken
};

/************************************************************************/

/* Transaction reply */
PUBLIC CmAbnfElmDef *mgMgcoTxnReplyDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoTransIdDef,
   &mgMgcoLBRKTDef,
   &mgMgcoOptImmAckDef,
   &mgMgcoErrorOrReplyDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoTxnReplyDefSeq =
{
   6,
   mgMgcoTxnReplyDefSeqElmnts
};

/* transactionReply     = ReplyToken EQUAL TransactionID LBRKT  
 * [ImmAckRequiredToken COMMA] ( errorDescriptor / actionReplyList ) RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoTxnReplyDef   =
{
#ifdef CM_ABNF_DBG
   "Transaction reply",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 499,
   sizeof(MgMgcoTxnReply),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoTxnReplyDefSeq,
   NULLP
};

/************************************************************************/

/* Command */

PUBLIC CmAbnfElmDef *mgMgcoCmdDefChcEnum[]   =
{
   &mgMgcoAddEnum,
   &mgMgcoMoveEnum,
   &mgMgcoModEnum,
   &mgMgcoSubEnum,
   &mgMgcoAudCapEnum,
   &mgMgcoAudValEnum,
   &mgMgcoNtfyEnum,
   &mgMgcoSvcChgEnum
};

PUBLIC CmAbnfElmDef *mgMgcoCmdDefChcElmnt[]   =
{
   &mgMgcoAmmReqDef,
   &mgMgcoSubReqDef,
   &mgMgcoAuditReqDef,
   &mgMgcoNtfyReqDef,
   &mgMgcoSvcChgReqDef
};

PUBLIC U8 mgMgcoCmdDefChcIdx[] = {0, 0, 0, 1, 2, 2, 3, 4};

PUBLIC CmAbnfElmTypeChoice mgMgcoCmdDefChc =
{
   5,
   8,
   mgMgcoCmdDefChcIdx,
   mgMgcoCmdDefChcElmnt,
   mgMgcoCmdDefChcEnum
};

/* commandRequest     = ( ammRequest / subtractRequest / auditRequest
 *                        / notifyRequest / serviceChangeRequest )
 */
PUBLIC CmAbnfElmDef mgMgcoCmdDef   =
{
#ifdef CM_ABNF_DBG
   "Command",
   "CmdReply",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 500,
   sizeof(MgMgcoCmd),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoCmdDefChc,
   mgMgcoRegExpCmdReply
};

/************************************************************************/

/* Optional W- */
PUBLIC CmAbnfElmDef *mgMgcoOptWHyphenDefSeqElmnts[] =
{
   &mgMgcoWHyphenDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptWHyphenDefSeq =
{
   1,
   mgMgcoOptWHyphenDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoOptWHyphenDef =
{
#ifdef CM_ABNF_DBG
   "Optional W-",
   "WHyphen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 501,
   sizeof(TknPres),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoOptWHyphenDefSeq,
   mgMgcoRegExpWHyphen
};

/************************************************************************/

/* Optional O- */
PUBLIC CmAbnfElmDef *mgMgcoOptOHyphenDefSeqElmnts[] =
{
   &mgMgcoOHyphenDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptOHyphenDefSeq =
{
   1,
   mgMgcoOptOHyphenDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoOptOHyphenDef =
{
#ifdef CM_ABNF_DBG
   "Optional O-",
   "OHyphen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 502,
   sizeof(TknPres),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoOptOHyphenDefSeq,
   mgMgcoRegExpOHyphen
};

/************************************************************************/

/* Command request */

PUBLIC CmAbnfElmDef *mgMgcoCmdReqDefSeqElmnts[] =
{
   &mgMgcoOptOHyphenDef,
   &mgMgcoOptWHyphenDef,
   &mgMgcoCmdDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoCmdReqDefSeq =
{
   3,
   mgMgcoCmdReqDefSeqElmnts
};

/* ["O-"] ["W-"] commandRequest */
PUBLIC CmAbnfElmDef mgMgcoCmdReqDef   =
{
#ifdef CM_ABNF_DBG
   "Command request",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 503,
   sizeof(MgMgcoCommandReq),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoCmdReqDefSeq,
   NULLP
};

/* Command request array */
PUBLIC CmAbnfElmDef *mgMgcoCmdReqArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoCmdReqDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoCmdReqArrayDefSeqOf =
{
   1,
   MGT_MAX_CMDREQS,
   2,
   mgMgcoCmdReqArrayDefSeqOfElmnts,
   sizeof(MgMgcoCommandReq)
};

/* *(COMMA ["O-"] commandRequest) */
PUBLIC CmAbnfElmDef mgMgcoCmdReqArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Command request array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 504,
   sizeof(MgMgcoCmdReqLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoCmdReqArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

#ifdef GCP_CH

PUBLIC CmAbnfElmTypeMarker mgMgcoCmdReqArrayMarker =
{
   CM_ABNF_MARKER_ESC_FUNC,
   (U8 *)mgMgcoEscFuncCmdReqArray
};

PUBLIC CmAbnfElmDef mgMgcoCHCmdReqArrayDef =
{
#ifdef CM_ABNF_DBG
   "Marker PkgName",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 125,
   0,
   0,
   CM_ABNF_TYPE_MARKER,
   (U8 *)&mgMgcoCmdReqArrayMarker,
   NULLP
};

#endif /* GCP_CH  */




/************************************************************************/

/* Command request list */

PUBLIC CmAbnfElmDef *mgMgcoOptCmdReqLstDefSeqElmnts[]   =
{
   &mgMgcoCmdReqDef,
#ifdef GCP_CH
   &mgMgcoCHCmdReqArrayDef
#else
   &mgMgcoCmdReqArrayDef
#endif /* GCP_CH  */
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptCmdReqLstDefSeq =
{
   2,
   mgMgcoOptCmdReqLstDefSeqElmnts
};

/* commandRequestList = ["O-"] commandRequest *(COMMA ["O-"] commandRequest) */
PUBLIC CmAbnfElmDef mgMgcoOptCmdReqLstDef   =
{
#ifdef CM_ABNF_DBG
   "Command request list",
   "CxtPropsOrCxtAudOrCmdReq",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 505,
   sizeof(MgMgcoCmdReqLst),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoOptCmdReqLstDefSeq,
   mgMgcoRegExpCxtPropsOrCxtAudOrCmdReq
};

#ifdef GCP_CH

PUBLIC CmAbnfElmTypeMarker mgMgcoCmdReqLstMarker =
{
   CM_ABNF_MARKER_ESC_FUNC,
   (U8 *)mgMgcoEscFuncCmdReqLst
};

PUBLIC CmAbnfElmDef mgMgcoCHOptCmdReqLstDef  =
{
#ifdef CM_ABNF_DBG
   "Marker PkgName",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 125,
   0,
   0,
   CM_ABNF_TYPE_MARKER,
   (U8 *)&mgMgcoCmdReqLstMarker,
   NULLP
};

#endif /* GCP_CH  */



/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoPriorityTokenSeqDefSeqElmnts[] =
{
   &mgMgcoPriorityTokenDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPriorityTokenSeqDefSeq =
{
   1,
   mgMgcoPriorityTokenSeqDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoPriorityTokenSeqDef =
{
#ifdef CM_ABNF_DBG
   "PriorityTokenSeq",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 506,
   sizeof(TknPres),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPriorityTokenSeqDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoTopologyTokenSeqDefSeqElmnts[] =
{
   &mgMgcoTopologyTokenDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoTopologyTokenSeqDefSeq =
{
   1,
   mgMgcoTopologyTokenSeqDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoTopologyTokenSeqDef =
{
#ifdef CM_ABNF_DBG
   "TopologyTokenSeq",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 507,
   sizeof(TknPres),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoTopologyTokenSeqDefSeq,
   NULLP
};

/* Context audit set */
PUBLIC CmAbnfElmDef *mgMgcoContextAuditDefSetElmnts[]   =
{
   &mgMgcoPriorityTokenSeqDef,
   &mgMgcoEmergencyDef,
   &mgMgcoTopologyTokenSeqDef
};

PUBLIC CmAbnfElmTypeSet mgMgcoContextAuditDefSet =
{
   3,
   mgMgcoContextAuditDefSetElmnts,
   &mgMgcoCOMMADef
};

/* contextAuditProperties *(COMMA  contextAuditProperties) RBRKT
 *; at-most-once
 * contextAuditProperties = (TopologyToken / EmergencyToken / PriorityToken)
 */
PUBLIC CmAbnfElmDef mgMgcoContextAuditDef   =
{
#ifdef CM_ABNF_DBG
   "Context audit set",
   "PriEmergTopo",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 508,
   sizeof(MgMgcoContextAudit),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SET,
   (U8 *)&mgMgcoContextAuditDefSet,
   mgMgcoRegExpPriEmergTopo
};

/************************************************************************/

/* Context audit */
PUBLIC CmAbnfElmDef *mgMgcoOptContextAuditDefSeqElmnts[]   =
{
   &mgMgcoContextAuditTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoContextAuditDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoOptContextAuditDefSeq =
{
   4,
   mgMgcoOptContextAuditDefSeqElmnts
};

/* contextAudit    = ContextAuditToken LBRKT  contextAuditProperties *(COMMA
 * contextAuditProperties) RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoOptContextAuditDef   =
{
#ifdef CM_ABNF_DBG
   "Context audit",
   "ContextAuditToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 509,
   sizeof(MgMgcoContextAudit),
   ((CM_ABNF_OPTIONAL  | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL  | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoOptContextAuditDefSeq,
   mgMgcoRegExpContextAuditToken
};

/************************************************************************/

/* Emergency */
PUBLIC CmAbnfElmDef *mgMgcoEmergencyDefSeqElmnts[] =
{
   &mgMgcoEmergencyTokenDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEmergencyDefSeq =
{
   1,
   mgMgcoEmergencyDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEmergencyDef =
{
#ifdef CM_ABNF_DBG
   "Emergency",
   "EmergencyToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 510,
   sizeof(TknPres),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoEmergencyDefSeq,
   mgMgcoRegExpEmergencyToken
};

/************************************************************************/

/* EmergencyOff */
PUBLIC CmAbnfElmDef *mgMgcoEmergencyOffDefSeqElmnts[] =
{
   &mgMgcoEmergencyOffTokenDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEmergencyOffDefSeq =
{
   1,
   mgMgcoEmergencyOffDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEmergencyOffDef =
{
#ifdef CM_ABNF_DBG
   "EmergencyOff",
   "EmergencyOffToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 510,
   sizeof(TknPres),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoEmergencyOffDefSeq,
   mgMgcoRegExpEmergencyOffToken
};


/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoTopologyDescArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoTopologyDescDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoTopologyDescArrayDefSeqOf =
{
   1,
   MGT_MAX_TOPODESCS,
   2,
   mgMgcoTopologyDescArrayDefSeqOfElmnts,
   sizeof(MgMgcoTopoDesc)
};

PUBLIC CmAbnfElmDef mgMgcoTopologyDescArrayDef =
{
#ifdef CM_ABNF_DBG
   "TopologyDesc array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 511,
   sizeof(MgMgcoTopoDescLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoTopologyDescArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoTopologyDescLstDefSeqElmnts[] =
{
   &mgMgcoTopologyDescDef,
   &mgMgcoTopologyDescArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoTopologyDescLstDefSeq =
{
   2,
   mgMgcoTopologyDescLstDefSeqElmnts
};

/* List of topology descriptors */
PUBLIC CmAbnfElmDef mgMgcoTopologyDescLstDef =
{
#ifdef CM_ABNF_DBG
   "List of topology descriptors",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 512,
   sizeof(MgMgcoTopoDescLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoTopologyDescLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoTopologyDescQueueDefSeqElmnts[] =
{
   &mgMgcoTopologyTokenDef,
   &mgMgcoLBRKTDef,
   &mgMgcoTopologyDescLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoTopologyDescQueueDefSeq =
{
   4,
   mgMgcoTopologyDescQueueDefSeqElmnts
};

/* topologyDescriptor   = TopologyToken LBRKT terminationA COMMA  terminationB
 *                        COMMA topologyDirection *(COMMA terminationA COMMA
 *                        terminationB COMMA topologyDirection) RBRKT
 */
PUBLIC CmAbnfElmDef mgMgcoTopologyDescQueueDef =
{
#ifdef CM_ABNF_DBG
   "Queue of topology descriptors",
   "TopologyToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 513,
   sizeof(MgMgcoTopoDescLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoTopologyDescQueueDefSeq,
   mgMgcoRegExpTopologyToken
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoCommaContextPropsDefSeqElmnts[]   =
{
   &mgMgcoCOMMADef,
};

PUBLIC CmAbnfElmTypeSeq mgMgcoCommaContextPropsDefSeq =
{
   1,
   mgMgcoCommaContextPropsDefSeqElmnts
};


PUBLIC CmAbnfElmDef mgMgcoCommaContextPropsDef   =
{
#ifdef CM_ABNF_DBG
   "Command reply list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 491,
   0,
   ((CM_ABNF_OPTIONAL  | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL  | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoCommaContextPropsDefSeq,
   mgMgcoRegExpCommaContextProps
};


/************************************************************************/

/* Context properties */
PUBLIC CmAbnfElmDef *mgMgcoOptContextPropsDefSetElmnts[]   =
{
   &mgMgcoPriorityDef,
   &mgMgcoEmergencyDef,
   &mgMgcoTopologyDescQueueDef,
#ifdef    MGT_GCP_VER_1_4
   &mgMgcoEmergencyOffDef
#endif /* MGT_GCP_VER_1_4 */
};

PUBLIC CmAbnfElmTypeSet mgMgcoOptContextPropsDefSet =
{
#ifdef    MGT_GCP_VER_1_4
   4,
#else  /* MGT_GCP_VER_1_4 */
   3,
#endif /* MGT_GCP_VER_1_4 */
   mgMgcoOptContextPropsDefSetElmnts,
   &mgMgcoCommaContextPropsDef /* &mgMgcoCOMMADef */
};

/* contextProperties    = contextProperty *(COMMA contextProperty)
 *; at-most-once
 * contextProperty  =
 *     (topologyDescriptor / priority / EmergencyToken / EmergencyOffToken)
 */
PUBLIC CmAbnfElmDef mgMgcoOptContextPropsDef   =
{
#ifdef CM_ABNF_DBG
   "Context properties",
   "PriEmergTopo",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 514,
   sizeof(MgMgcoContextProps),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SET,
   (U8 *)&mgMgcoOptContextPropsDefSet,
#ifdef    MGT_GCP_VER_1_4
   mgMgcoRegExpPriEmergTopoEmergOff
#else  /* MGT_GCP_VER_1_4 */
   mgMgcoRegExpPriEmergTopo
#endif /* MGT_GCP_VER_1_4 */
};
/************************************************************************/

/* Action request set */
PUBLIC CmAbnfElmDef *mgMgcoActionReqSetDefSetElmnts[] =
{
   &mgMgcoOptContextPropsDef,
   &mgMgcoOptContextAuditDef,
#ifdef GCP_CH
   &mgMgcoCHOptCmdReqLstDef
#else
   &mgMgcoOptCmdReqLstDef
#endif /* GCP_CH  */
};

PUBLIC CmAbnfElmTypeSet mgMgcoActionReqSetDefSet =
{
   3,
   mgMgcoActionReqSetDefSetElmnts,
   &mgMgcoCOMMADef
};

/* (contextRequest [COMMA commandRequestList]) / 
 *    commandRequestList
 * contextRequest = ((contextProperties [COMMA contextAudit]) / contextAudit) 
 */
PUBLIC CmAbnfElmDef mgMgcoActionReqSetDef =
{
#ifdef CM_ABNF_DBG
   "Action request set",
   "CxtPropsOrCxtAudOrCmdReq",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 515,
   sizeof(MgMgcoActionReq) - sizeof(MgMgcoContextId),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SET,
   (U8 *)&mgMgcoActionReqSetDefSet,
   mgMgcoRegExpCxtPropsOrCxtAudOrCmdReq
};
/************************************************************************/

/* Action request */
PUBLIC CmAbnfElmDef *mgMgcoActionReqDefSeqElmnts[]   =
{
   &mgMgcoCtxTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoContextIdDef,
   &mgMgcoLBRKTDef,
   &mgMgcoActionReqSetDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoActionReqDefSeq =
{
   6,
   mgMgcoActionReqDefSeqElmnts
};

/* actionRequest = CtxToken EQUAL ContextID LBRKT (
 * (contextRequest [COMMA commandRequestList]) / commandRequestList
 *                                                ) RBRKT
 * contextRequest = (
 * (contextProperties [COMMA contextAudit]) / contextAudit
 *                  ) 
 */
PUBLIC CmAbnfElmDef mgMgcoActionReqDef   =
{
#ifdef CM_ABNF_DBG
   "Action request",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 516,
   sizeof(MgMgcoActionReq),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoActionReqDefSeq,
   NULLP,
};

/************************************************************************/

/* Action requests array */
PUBLIC CmAbnfElmDef *mgMgcoActionReqArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoActionReqDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoActionReqArrayDefSeqOf =
{
   1,
   MGT_MAX_ACTIONREQS,
   2,
   mgMgcoActionReqArrayDefSeqOfElmnts,
   sizeof(MgMgcoActionReq)
};

/* *(COMMA actionRequest) */
PUBLIC CmAbnfElmDef mgMgcoActionReqArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Action requests array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 517,
   sizeof(MgMgcoActionLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoActionReqArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Action requests list */
PUBLIC CmAbnfElmDef *mgMgcoActionReqLstDefSeqElmnts[]   =
{
   &mgMgcoActionReqDef,
   &mgMgcoActionReqArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoActionReqLstDefSeq =
{
   2,
   mgMgcoActionReqLstDefSeqElmnts
};

/* actionRequest *(COMMA actionRequest) */
PUBLIC CmAbnfElmDef mgMgcoActionReqLstDef   =
{
#ifdef CM_ABNF_DBG
   "Action requests list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 518,
   sizeof(MgMgcoActionLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoActionReqLstDefSeq,
   NULLP
};

/************************************************************************/

/* Action requests queue */
PUBLIC CmAbnfElmDef *mgMgcoActionReqQDefSeqElmnts[]   =
{
   &mgMgcoLBRKTDef,
   &mgMgcoActionReqLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoActionReqQDefSeq =
{
   3,
   mgMgcoActionReqQDefSeqElmnts
};

/* LBRKT actionRequest *(COMMA actionRequest) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoActionReqQDef   =
{
#ifdef CM_ABNF_DBG
   "Action requests queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 519,
   sizeof(MgMgcoActionLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoActionReqQDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

/* Transaction request */
PUBLIC CmAbnfElmDef *mgMgcoTxnReqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoTransIdDef,
   &mgMgcoActionReqQDef,
};

PUBLIC CmAbnfElmTypeSeq mgMgcoTxnReqDefSeq =
{
   3,
   mgMgcoTxnReqDefSeqElmnts
};

/* transactionRequest   = TransToken EQUAL TransactionID LBRKT
 * actionRequest *(COMMA actionRequest) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoTxnReqDef   =
{
#ifdef CM_ABNF_DBG
   "Transaction request",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 520,
   sizeof(MgMgcoTxnReq),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoTxnReqDefSeq,
   NULLP
};

/************************************************************************/

/* "-" transactionID */
PUBLIC CmAbnfElmDef *mgMgcoHyphenTransIdDefSeqElmnts[]   =
{
   &cmMsgDefMetaHyphen,
   &mgMgcoTransIdDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoHyphenTransIdDefSeq =
{
   2,
   mgMgcoHyphenTransIdDefSeqElmnts
};

/* "-" transactionID */
PUBLIC CmAbnfElmDef mgMgcoHyphenTransIdDef   =
{
#ifdef CM_ABNF_DBG
   "- transactionID",
   "cmAbnfRegExpHyphen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 521,
   sizeof(MgMgcoTransId),
   ((CM_ABNF_TKN_NOT_CONSUMED| CM_ABNF_OPTIONAL) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_TKN_NOT_CONSUMED| CM_ABNF_OPTIONAL) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoHyphenTransIdDefSeq,
   cmAbnfRegExpHyphen
};
/************************************************************************/

/* Transaction ack */
PUBLIC CmAbnfElmDef *mgMgcoTxnAckDefSeqElmnts[]   =
{
   &mgMgcoTransIdDef,
   &mgMgcoHyphenTransIdDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoTxnAckDefSeq =
{
   2,
   mgMgcoTxnAckDefSeqElmnts
};

/* transactionAck = transactionID / (transactionID "-" transactionID) */
PUBLIC CmAbnfElmDef mgMgcoTxnAckDef   =
{
#ifdef CM_ABNF_DBG
   "Transaction ack",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 522,
   sizeof(MgMgcoTxnAck),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoTxnAckDefSeq,
   NULLP
};

/************************************************************************/

/* Transaction ack array - SEQOF type */
PUBLIC CmAbnfElmDef *mgMgcoTxnAckArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoTxnAckDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoTxnAckArrayDefSeqOf =
{
   1,
   MGT_MAX_TXNACKS,
   2,
   mgMgcoTxnAckArrayDefSeqOfElmnts,
   sizeof(MgMgcoTxnAck)
};

/* *(COMMA transactionAck) */
PUBLIC CmAbnfElmDef mgMgcoTxnAckArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Transaction ack array - SEQOF",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 523,
   sizeof(MgMgcoTxnRspAck),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoTxnAckArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};


/************************************************************************/

/* Transaction ack list - OPTSEQOF type */
PUBLIC CmAbnfElmDef *mgMgcoTxnAckLstDefSeqElmnts[]   =
{
   &mgMgcoTxnAckDef,
   &mgMgcoTxnAckArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoTxnAckLstDefSeq =
{
   2,
   mgMgcoTxnAckLstDefSeqElmnts
};

/* transactionAck *(COMMA transactionAck) */
PUBLIC CmAbnfElmDef mgMgcoTxnAckLstDef   =
{
#ifdef CM_ABNF_DBG
   "Transaction ack list - OPTSEQOF",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 524,
   sizeof(MgMgcoTxnRspAck),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoTxnAckLstDefSeq,
   NULLP
};

/************************************************************************/

/* Transaction response ack */
PUBLIC CmAbnfElmDef *mgMgcoTxnRspAckDefSeqElmnts[]   =
{
   &mgMgcoLBRKTDef,
   &mgMgcoTxnAckLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoTxnRspAckDefSeq =
{
   3,
   mgMgcoTxnRspAckDefSeqElmnts
};

/* transactionResponseAck = ResponseAckToken LBRKT transactionAck
 * *(COMMA transactionAck) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoTxnRspAckDef   =
{
#ifdef CM_ABNF_DBG
   "Transaction response ack",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 525,
   sizeof(MgMgcoTxnRspAck),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoTxnRspAckDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

/* Transaction pending */
PUBLIC CmAbnfElmDef *mgMgcoTxnPendDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoTransIdDef,
   &mgMgcoLBRKTDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoTxnPendDefSeq =
{
   4,
   mgMgcoTxnPendDefSeqElmnts
};

/* transactionPending   = PendingToken EQUAL TransactionID LBRKT RBRKT */
PUBLIC CmAbnfElmDef mgMgcoTxnPendDef   =
{
#ifdef CM_ABNF_DBG
   "Transaction pending",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 526,
   sizeof(MgMgcoTxnPend),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoTxnPendDefSeq,
   NULLP
};

/************************************************************************/

/* Transaction */
PUBLIC CmAbnfElmDef *mgMgcoTxnDefChcEnum[]   =
{
   &mgMgcoErrDescDefEnumDef,
   &mgMgcoTxnReqDefEnumDef,
   &mgMgcoTxnReplyDefEnumDef,
   &mgMgcoTxnPendDefEnumDef,
   &mgMgcoTxnRspAckDefEnumDef,
};

PUBLIC CmAbnfElmDef *mgMgcoTxnDefChcElmnt[]   =
{
   &mgMgcoErrDescDef,
   &mgMgcoTxnReqDef,
   &mgMgcoTxnReplyDef,
   &mgMgcoTxnPendDef,
   &mgMgcoTxnRspAckDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoTxnDefChc =
{
   5,
   0,
   NULLP,
   mgMgcoTxnDefChcElmnt,
   mgMgcoTxnDefChcEnum
};

/* transaction = transactionRequest / transactionReply /
 * transactionPending / transactionResponseAck */
PUBLIC CmAbnfElmDef mgMgcoTxnDef   =
{
#ifdef CM_ABNF_DBG
   "mgMgcoTxnDef",
   "ErrorOrTransaction",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 527,
#ifdef GCP_VER_1_3
   sizeof(MgMgcoTxn) - sizeof(CmMemListCp),
#else
   sizeof(MgMgcoTxn),
#endif
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoTxnDefChc,
   mgMgcoRegExpErrorOrTransaction
};

/************************************************************************/

/* Transaction list */
PUBLIC CmAbnfElmDef *mgMgcoTxnLstDefSeqOfElmnts[]   =
{
   &mgMgcoTxnDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoTxnLstDefSeqOf =
{
   1,
   MGT_MAX_TXNS,
   1,
   mgMgcoTxnLstDefSeqOfElmnts,
   sizeof(MgMgcoTxn)
};

/* transactionList      = 1*(transaction) */
PUBLIC CmAbnfElmDef mgMgcoTxnLstDef   =
{
#ifdef CM_ABNF_DBG
   "mgMgcoTxnLstDef",
   "ErrorOrTransaction",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 528,
   sizeof(MgMgcoTxnLst),
   ((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET) |((CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET) ,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoTxnLstDefSeqOf,
   mgMgcoRegExpErrorOrTransaction
};

/************************************************************************/

/* message body */
#ifdef GCP_VER_1_3
PUBLIC CmAbnfElmDef *mgMgcoMsgBodyDefChcEnum[]   =
{
/* added support for errorDescriptor in messageBody */
   &mgMgcoErrDescDefEnumDef,
   &mgMgcoTxnLstDefEnumDef,
   &mgMgcoTxnLstDefEnumDef,
   &mgMgcoTxnLstDefEnumDef,
   &mgMgcoTxnLstDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoMsgBodyDefChcElmnt[]   =
{
/* added support for errorDescriptor in messageBody */
   &mgMgcoErrDescDef,
   NULLP 
};

/* added support for errorDescriptor in messageBody */
PUBLIC U8 mgMgcoMsgBodyDefChcIdx[] = {0, 1, 1, 1, 1};

#else
PUBLIC CmAbnfElmDef *mgMgcoMsgBodyDefChcEnum[]   =
{
   &mgMgcoErrDescDefEnumDef,
   &mgMgcoTxnLstDefEnumDef,
   &mgMgcoTxnLstDefEnumDef,
   &mgMgcoTxnLstDefEnumDef,
   &mgMgcoTxnLstDefEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoMsgBodyDefChcElmnt[]   =
{
   &mgMgcoErrDescDef,
   &mgMgcoTxnLstDef
};

PUBLIC U8 mgMgcoMsgBodyDefChcIdx[] = {0, 1, 1, 1, 1};

#endif

PUBLIC CmAbnfElmTypeChoice mgMgcoMsgBodyDefChc =
{
/* added support for errorDescriptor in messageBody */
   2,
   5,
   mgMgcoMsgBodyDefChcIdx,
   mgMgcoMsgBodyDefChcElmnt,
   mgMgcoMsgBodyDefChcEnum
};

/* messageBody          = ( errorDescriptor / transactionList ) */
PUBLIC CmAbnfElmDef mgMgcoMsgBodyDef =
{
#ifdef CM_ABNF_DBG
   "mgMgcoMsgBodyDef",
   "ErrorOrTransaction",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 529,
   sizeof(MgMgcoMsgBody),
   ((CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_MANDATORY) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_MANDATORY) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoMsgBodyDefChc,
   mgMgcoRegExpErrorOrTransaction
};

/************************************************************************/

/* message header */
PUBLIC CmAbnfElmDef *mgMgcoMsgHdrDefSeqElmnts[]   =
{
   &mgMgcoLWSPDef,
   &mgMgcoMegacopTokenDef,
   &cmMsgDefMetaSlash,
   &mgMgcoVersionDef,
   &mgMgcoSEPDef,
   &mgMgcoMIDStrDef ,     /* element changed for MID as string */
   &mgMgcoSEPDef,
};
   
PUBLIC CmAbnfElmTypeSeq mgMgcoMsgHdrDefSeq =
{
   7,
   mgMgcoMsgHdrDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoMsgHdrDef =
{
#ifdef CM_ABNF_DBG
   "MEGACO Message header",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 530,
   sizeof(MgMgcoVersion) + sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoMsgHdrDefSeq,
   NULLP
};

/************************************************************************/

/* message */
PUBLIC CmAbnfElmDef *mgMgcoMsgDefSeqElmnts[]   =
{
   &mgMgcoLWSPDef,
   &mgMgcoMsgHdrDef,
   &mgMgcoMsgBodyDef
};
   
PUBLIC CmAbnfElmTypeSeq mgMgcoMsgDefSeq =
{
   3,
   mgMgcoMsgDefSeqElmnts
};

/* message    = MegacopToken SLASH Version SEP mId SEP messageBody */
PUBLIC CmAbnfElmDef mgMgcoMsgDef   =
{
#ifdef CM_ABNF_DBG
   "MEGACO Message",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 531,
   sizeof(MgMgcoVersion) + sizeof(TknStrOSXL) + sizeof(MgMgcoMsgBody),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoMsgDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmTypeMeta mgMgcoZeroXDefMeta = {(Data *)"0x"};

/* 0x */
PUBLIC CmAbnfElmDef mgMgcoZeroXDef =
{
#ifdef CM_ABNF_DBG
   "0x",
   "ZeroX",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 532,
   0,
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_META,
   (U8 *)&mgMgcoZeroXDefMeta,
   mgMgcoRegExpZeroX
};

/************************************************************************/

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMgcoSecParmIndexRng = {8, 8, 0, (U32)~0};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMgcoSecParmIndexRng = {8, 8};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMgcoSecParmIndexRngDef =
{
#ifdef CM_ABNF_DBG
   "Sec parm index int",
   "XDgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 533,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_HEXUINT32, /* Note: have to change to HEXUINT32 */
   (U8 *)&mgMgcoSecParmIndexRng,
   cmAbnfRegExpXDgt
};

PUBLIC CmAbnfElmDef *mgMgcoSecParmIndexDefSeqElmnts[] =
{
   &mgMgcoZeroXDef,
   &mgMgcoSecParmIndexRngDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSecParmIndexDefSeq =
{
   2,
   mgMgcoSecParmIndexDefSeqElmnts
};

/* SecurityParmIndex    = "0x" 8(HEXDIG) */
PUBLIC CmAbnfElmDef mgMgcoSecParmIndexDef =
{
#ifdef CM_ABNF_DBG
   "security parameter index",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 534,
   sizeof(MgMgcoSecParmIndex),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSecParmIndexDefSeq,
   NULLP
};

/************************************************************************/

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMgcoSequenceNumRng = {8, 8, 0, (U32)~0};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMgcoSequenceNumRng = {8, 8};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMgcoSequenceNumRngDef =
{
#ifdef CM_ABNF_DBG
   "Seq num int",
   "XDgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 535,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_HEXUINT32,
   (U8 *)&mgMgcoSequenceNumRng,
   cmAbnfRegExpXDgt
};

PUBLIC CmAbnfElmDef *mgMgcoSequenceNumDefSeqElmnts[] =
{
   &mgMgcoZeroXDef,
   &mgMgcoSequenceNumRngDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSequenceNumDefSeq =
{
   2,
   mgMgcoSequenceNumDefSeqElmnts
};

/* SequenceNum          = "0x" 8(HEXDIG) */
PUBLIC CmAbnfElmDef mgMgcoSequenceNumDef =
{
#ifdef CM_ABNF_DBG
   "sequence number",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 536,
   sizeof(MgMgcoSequenceNum),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSequenceNumDefSeq, 
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmTypeRange mgMgcoAuthDataRng = {32, 64};

PUBLIC CmAbnfElmDef mgMgcoAuthDataRngDef =
{
#ifdef CM_ABNF_DBG
   "Auth data without 0x",
   "XDgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 537,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoAuthDataRng,
   cmAbnfRegExpXDgt
};

PUBLIC CmAbnfElmDef *mgMgcoAuthDataDefSeqElmnts[] =
{
   &mgMgcoZeroXDef,
   &mgMgcoAuthDataRngDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoAuthDataDefSeq =
{
   2,
   mgMgcoAuthDataDefSeqElmnts
};

/* AuthData             = "0x" 24*64(HEXDIG) */
PUBLIC CmAbnfElmDef mgMgcoAuthDataDef =
{
#ifdef CM_ABNF_DBG
   "authentication data",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 538,
   sizeof(MgMgcoAuthData),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoAuthDataDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoAuthHdrDefSeqElmnts[] =
{
   &mgMgcoLWSPDef,
   &mgMgcoAuthTokenDef,
   &mgMgcoEQUALDef,
   &mgMgcoSecParmIndexDef,
   &cmMsgDefMetaColon,
   &mgMgcoSequenceNumDef,
   &cmMsgDefMetaColon,
   &mgMgcoAuthDataDef,
   &mgMgcoSEPDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoAuthHdrDefSeq =
{
   9,
   mgMgcoAuthHdrDefSeqElmnts
};

/* Authentication header */

/* LWSP [authenticationHeader SEP]
 * authenticationHeader = AuthToken EQUAL SecurityParmIndex COLON
 *                        SequenceNum COLON AuthData
 */

PUBLIC CmAbnfElmDef mgMgcoAuthHdrDef =
{
#ifdef CM_ABNF_DBG
   "MEGACO Authentication header",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 539,
   sizeof(MgMgcoAuthHdr),
   ((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|((CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoAuthHdrDefSeq,
   mgMgcoRegExpLWSPAuthToken
};

PUBLIC CmAbnfElmDef *mgMgcoAuthHdrMsgDefSeqElmnts[] =
{
   &mgMgcoAuthHdrDef,
   &mgMgcoMsgDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoAuthHdrMsgDefSeq =
{
   2,
   mgMgcoAuthHdrMsgDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoAuthHdrMsgDef =
{
#ifdef CM_ABNF_DBG
   "Complete Megaco message",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_BASE + 540,
   sizeof(TknPres) + sizeof(MgMgcoAuthHdr) + sizeof(MgMgcoVersion) +
   sizeof(TknStrOSXL) + sizeof(MgMgcoMsgBody),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoAuthHdrMsgDefSeq,
   NULLP
};

#endif /* GCP_MGCO */

/********************************************************************30**

         End of file:     mgco_db.c@@/main/mgcp_rel_1.5_mnt/3 - Fri Jun 24 18:38:59 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      nct  1. Initial version
            mg001.102 nct  1. Changed some SEQs to OPTSEQs.
                           2. Changed order in TermStDesc.
            mg002.102  sk  1. Changed mgMgcoAuditDescDef , OPTSEQ to SEQ 
                           2. Added new elements, and changed some of the
                              elements.
            mg011.102  vj  1. Added a new element mgMgcoMIDStrDef to treat MID 
                              as a string. 
/main/2      ---       ra  1. GCP 1.3 release
/main/2     mg004.103  ra  1. Changes for allowing multiple property parms
                              in termination state descriptor.
            mg013.103  ra  1. Added support for errorDesc in messageBody
                              if the flag GCP_VER_1_3 is defined.
/main/3      ---      TEL  String database code is added for:
                           1. Bearer Characteristic Package
                           2. Bearer Network Connection Cut Through Package
                           3. Reuse Idle Package
                           4. Generic Bearer Connection Package
                           5. Bearer Control Tunneling Package 
                           6. Basic Call Progress Tones Generator with 
                              Directionality Package
                           7. Expanded Call Progress Tones Generator Package
                           8. Basic Services Tone Generator Package
                           9. Expanded Services Tone Generation Package
                           10. Intrusion Tone Generation Package
                           11. Business Tone Generation Package
                           12. 3GUP User Plane Package
                           13. Circuit Switched Data Package
                           14. TFO Package
                           15. 3G Expanded Call Progress Tones Generator Package
                           16. Modification of Link characteristics Bearer 
                               Capability Package
                           17. Cellular Text Telephone Modem Text Transport 
                               Package
                           18. IP Transport Package
                           19. Flexible Tone Generator Package
                           20. Media Gateway Resource Congestion Handling 
                               Package
                           21. Quiet Termination Line Test Component Package
                           22. Loop back Line Test Response Package
                           23. ITU-T 404Hz Line Test Package
                           24. ITU-T 816Hz Line Test Package
                           25. ITU-T 1020Hz Line Test Package
                           26. ITU-T 2100Hz Disable Tone Line Test Package
                           27. ITU-T 2100Hz Disable Echo Chancellor Tone Line 
                               Test Package
                           28. ITU-T 2804Hz Tone Line Test Package
                           29. ITU-T Noise Test Tone Line Test Package
                           30. ITU-T Digital Pseudo Random Test Tone Line Test 
                               Package
                           31. ITU-T ATME No.2 Test Line Response Package
                           32. ANSI 1004Hz Test Tone Line Test Package
                           33. ANSI Test Responder Line Test Package
                           34. ANSI 2225Hz Test Progress Tone Line Test Package
                           35. ANSI Digital Test Signal line Test Package
                           36. ANSI Inverting Loop Back Line Test Response 
                               Package
                           37. Basic CAS Package
                           38. Basic CAS Addressing Package
                           39. Robbed Bit Signaling Package
                           40. Operator Service and Emergency Services Package
                           41. Operator Service and Extension Package
                           42. Inactivity Timer Package
                           43. Feature Key Package
                           44. Business Phone Package
                           45. Display XML Package
                           46. Base Package  
                           Root definitions are added for above packages
/main/4      ---      TEL2  String database code is added for:
                          1. Media Gateway Overload Control package 
                          2. Floor Control package
                          3. Indication of being viewed package
                          4. Volume Control package
                          5. Volume Detection package
                          6. Volume Level Mixing package
                          7. Voice Activated Video Switch package
                          8. Lecture Video Mode package
                          9. Contributing Video Source package
                          10. Profile package
                          11. Semi-permanent connection package
                          12. Video Window package
                          13. Tiled Window package
                          14. Enhanced Alerting package
                          15. Shared Risk Group package
                          16. Mixing Volume Level Control package
                          17. CAS Blocking package
                          18. Conferencing Tones Generation package
                          19. Diagnostic Tones Generation package
                          20. Carrier Tones Generation package
                          21. Analog Display Signalling package
                          22. Extended Analog Line Supervision package
                          23. Automatic Metering package
                          24. H.324 package
                          25. H.245 Command package
                          26. H.245 Indication package
                          27. Extended H.245 Command package
                          28. Extended H.245 Indication package
                          29. Quality Alert Ceasing package
                          30. Extended H.324 package
                          31. Adaptive Jitter Buffer package
                          32. International CAS package
                          33. Multi-Frequency Tone Generation package
                          34. Multi-Frequency Tone Detection package
                          35. Extended DTMF Detection package
                          36. Enhanced DTMF Detection package
                           Root definitions are added for above packages
/main/4      ---      TEL3  String database code is added for:
                           1. MSF UK Call Progess Tones Generator package
                           2. MSF UK Announcement package
                           3. MSF UK Analogue Line package
                           4. MSF UK Automatic Metering package
                           Root definitions are added for above packages
/main/3      ---     ka    1. Changes for Release v 1.4
/main/4      ---      pk    1. GCP 1.5 release
           mg002.105  ra   1. TKN_NOT_CONSUMED added so that the RE does 
                              not eat up stuff
                           2. changed from sizeof(TknU8)
                           3. Removed patch reference for 1.3
           mg003.105  gk   1. Bug fix for Topology Descriptor, Stream ID Parameter
                      ps   2. Enhanced Circuit Switched Data Package Added
                      ps   3. Stimulus Lines Analogue Package added 
                           4. Added new function for checking the presence of 
                              method and reason of service change request 
                           5. Change for the backward compatibility
           mg004.105  gk   1. Added support for Nx64
           mg005.105  gk   1. Changed the order according to ASN values
           mg006.105  gk   1. Corrected from MGT_SIGTYPE_TIMEOUT to MGT_NTFYRES_TIMEOUT
           mg007.105  gk   1. Modified Timeout element definition for Signal Type and 
                              Notify Completion seperate
*********************************************************************91*/
