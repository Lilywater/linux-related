/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
 
     Name:     MEGACO - AH module
 
     Type:     C source file
  
     Desc:     C Source Code for Co-ordinator Module
 
     File:     mgco_ah.c
  
     Sid:      mgco_ah.c@@/main/4 - Wed Mar 30 07:53:37 2005
  
     Prg:      pk
  
*********************************************************************21*/
 
/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*
*/
 
/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*    
*   
*
*/

 
/*
 * The core of MGC product is implemented in following files:
 *
 *    mg_dns.c      DNS Interaction functions 
 *    mg_tmr.c      Timer Management/Maintenance functions
 *    mg_tpt.c      Transport Layer Interaction functions
 *    mg_trans.c    Transaction Management functions
 *    mg_cord.c     Co-ordinator Module functions
 *    mg_ui.c       MGCP Upper Interface Functions
 *    mg_mi.c       MGCP Layer Management Interface
 *    mg_li.c       MGCP Lower Layer (TUCL) Interface
 *    cm_tenc.c     Common Text Based Encode Engine for MGCP messages
 *    cm_tdec.c     Common Text Based Decode Engine for MGCP messages
 */

/* header include files (.h) */
#include "envopt.h"        /* Environment options */  
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */

#ifdef MG

#include "gen.h"           /* General layer */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common Timer Library */
#include "cm_hash.h"       /* Hash library */
#include "cm_llist.h"      /* Doubly Linked List library */
#include "cm_inet.h"       /* Common Sockets Library */
#include "cm_tpt.h"        /* Common Transport Defines */
#include "cm_tkns.h"       /* Common Tokens Defines */
#include "cm_sdp.h"        /* Session Description Protocol Defines */
#include "cm_mblk.h"       /* Common Memory Manager Defines */
#include "cm_abnf.h"       /* Common ABNF  Defines */
#include "cm_dns.h"        /* common DNS library */
#ifdef ZG
#include "cm_ftha.h"        /* common FTHA defines */
#include "cm_psfft.h"       /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"             /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#include "mgt.h"           /* MGT Interface Defines */
#include "lmg.h"           /* MGCP Layer Management */
#include "mg_err.h"        /* MGCP Error Codes */
#include "mg.h"            /* MGCP Defines */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer */
#include "ssi.x"           /* System services */
#include "cm5.x"           /* Common Timer Library */
#include "cm_hash.x"       /* Hash library */
#include "cm_llist.x"      /* Doubly Linked List library */
#include "cm_inet.x"       /* Common Sockets Library */
#include "cm_tpt.x"        /* Common Transport Definitions */
#include "cm_tkns.x"       /* Common Tokens Defines */
#include "cm_lib.x"        /* Common library functions */
#include "cm_sdp.x"        /* Session Description Protocol Defines */
#include "cm_mblk.x"       /* Common Memory Manager Defines */
#include "cm_abnf.x"       /* Common ABNF  Defines */
#include "cm_dns.x"        /* common dns library */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"             /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#include "mgt.x"           /* MGT Interface Structures */
#ifdef GCP_PROV_MTP3
#include "cm_ss7.x"           /* MGCP Layer Management */
#endif
#include "lmg.x"           /* MGCP Layer Management */
#include "mg.x"            /* MGCP Data Structures */
#include "mg_db.x"         /* MGCP ABNF Datbase */

#ifdef GCP_MGCO
#include "mgco_db.x"       /* MEGACO ABNF Database */
#endif /* GCP_MGCO */



/* local defines, if any */

/* local typedefs, if any */
 
/* local externs, if any */

/* forward references */

/* public variable declaration */

/* private variable declaration */

#ifdef GCP_USE_AH

/*
*
*       Fun:    mgCreateAH
*
*       Desc:  Create AH header for the mBuf 
*       Ret:   
*
*       Notes:
*
*       File:  mgco_ah.c
*
*/
#ifdef ANSI
PUBLIC S16 mgCreateAH
(
MgMgcoAuthHdr *ah,         /* Authentication Header */
Buffer        *mBuf,       /* Outgoing Buffer */
CmTptAddr     *remAddr,    /* Remote Address */
CmTptAddr     *srcAddr     /* Source Address */
)
#else
PUBLIC S16 mgCreateAH(ah, mBuf, remAddr, srcAddr)
MgMgcoAuthHdr *ah;         /* Authentication Header */
Buffer        *mBuf;       /* Outgoing Buffer */
CmTptAddr     *remAddr;    /* Remote Address */
CmTptAddr     *srcAddr;     /* Source Address */
#endif
{
  TRC2(mgCreateAH);
  RETVALUE(ROK);
}



/*
*
*       Fun:   mgValidateAH
*
*       Desc:  Validate the authentication header in an incoming message
*       Ret:   
*
*       Notes:
*
*       File:  mgco_ah.c
*
*/
#ifdef ANSI
PUBLIC S16 mgValidateAH
(
MgMgcoAuthHdr *ah,         /* Authentication Header */
Buffer        *mBuf        /* Incoming Buffer */
)
#else
PUBLIC S16 mgValidateAH (ah, mBuf)
MgMgcoAuthHdr *ah;         /* Authentication Header */
Buffer        *mBuf;       /* Incoming Buffer */
#endif
{ 
  TRC2(mgValidateAH);
  RETVALUE(ROK);
}


#endif /* GCP_USE_AH */

#endif /* MG */

/********************************************************************30**
 
         End of file:     mgco_ah.c@@/main/4 - Wed Mar 30 07:53:37 2005
 
*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---      pk   1. Initial release.
/main/2      ---      ra   1. GCP 1.3 release
/main/3      ---      ka   1. Changes for Release v 1.4
/main/4      ---      pk   1. GCP 1.5 release
*********************************************************************91*/
