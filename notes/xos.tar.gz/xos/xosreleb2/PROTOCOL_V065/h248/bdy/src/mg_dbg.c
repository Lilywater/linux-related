/**********************************************************************

        Name:   mgco_dbg.c - Debug print for the GCP

        Type:   C source file

        Desc:   C code for the GCP layer debug print

        File:   mgco_dbg.c

        Sid:    mgco_dbg.c - 2006/04/25

        Created by:     changdawei

**********************************************************************/
/* header include files (.h) */

//------------------- changdawei ---------------
// #include "sysInsidePub.h"	/* Command line interface*/
//CLI

//---------------------------------------------

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */


#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timers defines */
#include "cm_hash.h"       /* common hash list defines */
#include "cm_inet.h"       /* common INET defines */
#include "cm_llist.h"      /* common linked list defines */
#include "cm_mblk.h"       /* memory management */
#include "cm_tkns.h"       /* common tokens */
#include "cm_abnf.h"
#include "cm_tpt.h"        /* common transport defines */
#include "hit.h"           /* HI layer */
#include "cm_sdp.h"        /* SDP related constants */
#include "cm_dns.h"         /* common DNS libraru defines */

#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */ 
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#include "mgt.h"           /* MGT defines */

#ifdef    GCP_PROV_SCTP
#include "lsb.h"           /* layer management defines for SCTP */
#endif    /* GCP_PROV_SCTP */

#include "lmg.h"           /* layer management defines for MGCP */
#include "lhi.h"
#include "mg.h"            /* defines and macros for MGCP */
#include "mg_err.h"        /* MG error defines */
#ifdef ZG_ACC_TEST
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#include "zg_acc.h"        /* PSF Acceptance test defines */
#endif /* ZG_ACC_TEST */
/*#include "mg_acc.h" */       /* defines for MGCP acceptance tests */
#include "mg_macro.h"      /* defines for MGT-related macros */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer typedefs */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_inet.x"       /* common INET */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_abnf.x"
#include "cm_tpt.x"        /* common transport types */
#include "hit.x"           /* HI layer */
#include "cm_sdp.x"        /* SDP related types */
#include "cm_dns.x"         /* common DNS libraru defines */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#include "mgt.x"           /* MGT types */

#ifdef    GCP_PROV_SCTP
#include "lsb.x"           /* layer management defines for SCTP */
#endif    /* GCP_PROV_SCTP */

#ifdef GCP_PROV_MTP3
#include "cm_ss7.x"           /* layer management typedefs for MGCP */
#endif
#include "lmg.x"           /* layer management typedefs for MGCP */
#include "lhi.x"
#include "mg.x"            /* typedefs for MGCP */
#ifdef ZG_ACC_TEST
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#include "zg_acc.x"        /* PSF Acceptance test typedefs */
#endif /* ZG_ACC_TEST */
#if 0
#include "l4.x"            /* typedefs for MGCP provider */
#include "mu.x"            /* typedefs for MGCP user */
#include "mg_acc.x"        /* typedefs for MGCP acceptance tests */
#include "mg_act.x"        /* function declarations */
#endif
#ifdef MEM_DEBUG
#include "mem_dbg.x"
#endif

#ifndef GCP_SIMULATION
/*#include "dm.x"*/
#endif

#ifdef SSI_WITH_CLI_ENABLED

#include "xosshell.h"      /* XOS header */


/* local defines */

/* local externs */
/*EXTERN  MgAccCb      mgAccCb;   MGCO Acceptance Test control block */
/*             */

EXTERN  MgCb         mgCb;

#ifdef TDS_ROLL_UPGRADE_SUPPORT
PRIVATE VOID mgcoPrintShtVerInfo(CLI_ENV *pCliEnv, ShtVerInfo *shtVerInfo);
#endif  /* TDS_ROLL_UPGRADE_SUPPORT */
#ifdef MG_RUG
PRIVATE VOID mgcoPrintIntVerInfo(CLI_ENV *pCliEnv, MgIntVerInfo *intVerInfo);
#endif /* MG_RUG */
PRIVATE VOID mgcoPrintElmntId(CLI_ENV *pCliEnv, ElmntId *elmntId);
PRIVATE VOID mgcoPrintMem(CLI_ENV *pCliEnv, Mem *mem);
PRIVATE VOID mgcoPrintResp(CLI_ENV *pCliEnv, Resp *resp);
PRIVATE VOID mgcoPrintHeader(CLI_ENV *pCliEnv, Header *header);
#ifdef CM_ABNF_MT_LIB
PRIVATE VOID mgcoPrintDfrCfm(CLI_ENV *pCliEnv, MgDfrCfm *dfrCfm);
#endif /* CM_ABNF_MT_LIB */
PRIVATE VOID mgcoPrintStoreList(CLI_ENV *pCliEnv, MgStoreList *storeList);
PRIVATE VOID mgcoPrintPostInfo(CLI_ENV *pCliEnv, Pst *pPst);
PRIVATE VOID mgcoPrintSSAPReCfg(CLI_ENV *pCliEnv, MgSSAPReCfg *cfg);
PRIVATE VOID mgcoPrintPeerInfo(CLI_ENV *pCliEnv, MgPeerInfo *peerInfo);
PRIVATE VOID mgcoPrintSSAPCfg(CLI_ENV *pCliEnv, MgSSAPCfg *cfg);
PRIVATE VOID mgcoPrintCmTptAddr(CLI_ENV *pCliEnv, CmTptAddr *cmTptAddr);
PRIVATE VOID mgcoPrintCmNetAddr(CLI_ENV *pCliEnv, CmNetAddr *cmNetAddr);
PRIVATE VOID mgcoPrintCmTptParam(CLI_ENV *pCliEnv, CmTptParam *cmTptParam);
PRIVATE VOID mgcoPrintCmTimer(CLI_ENV *pCliEnv, CmTimer *cmTimer);
PRIVATE VOID mgcoPrintTptSrvr(CLI_ENV *pCliEnv, MgTptSrvr *tptSrvr);
PRIVATE VOID mgcoPrintCmLListCp(CLI_ENV *pCliEnv, CmLListCp *cmLListCp);
PRIVATE VOID mgcoPrintTptSrvrInfo(CLI_ENV *pCliEnv, MgTptSrvrInfo *tptSrvrInfo);
PRIVATE VOID mgcoPrintCmListEnt(CLI_ENV *pCliEnv, CmListEnt *cmListCp);
PRIVATE VOID mgcoPrintCmHashListCp(CLI_ENV *pCliEnv, CmHashListCp *cmHashListCp);
PRIVATE VOID mgcoPrintCmHashListEnt(CLI_ENV *pCliEnv, CmHashListEnt *cmHashListEnt);
PRIVATE VOID mgcoPrintCmLList(CLI_ENV *pCliEnv, CmLList *cmLList);
PRIVATE VOID mgcoPrintNetAddrTbl(CLI_ENV *pCliEnv, MgNetAddrTbl *peerAddrTbl);
PRIVATE VOID mgcoPrintMidStr(CLI_ENV *pCliEnv, MgMgcoMidStr *midStr);
PRIVATE VOID mgcoPrintPeerAccess(CLI_ENV *pCliEnv, MgPeerAccess *mgPeerAccess);
PRIVATE VOID mgcoPrintPeerMntInfo(CLI_ENV *pCliEnv, MgPeerMntInfo *peerMntInfo);
PRIVATE VOID mgcoPrintTxnAck(CLI_ENV *pCliEnv, MgTxnAck *txnAck);
PRIVATE VOID mgcoPrintTxnAckList(CLI_ENV *pCliEnv, MgTxnAckList *txnAckList);
PRIVATE VOID mgcoPrintMgcoPeerInfo(CLI_ENV *pCliEnv, MgMgcoPeerInfo *mgcoPeerInfo);
PRIVATE VOID mgcoPrintPeerSts(CLI_ENV *pCliEnv, MgPeerSts *peerSts);
PRIVATE VOID mgcoPrintRvUpdQNode(CLI_ENV *pCliEnv, MgRvUpdQNode *rvUpdQNode);
/*PRIVATE VOID mgcoPrintPengingLimit(CLI_ENV *pCliEnv, MgMgcoPendingLimit *pendingLimit);*/
/*PRIVATE VOID mgcoPrintProvRspTmrVal(CLI_ENV *pCliEnv, MgMgcoProvRspTmrVal *provRspTmrVal);*/
PRIVATE VOID mgcoPrintPeerCb(CLI_ENV *pCliEnv, MgPeerCb *peerCb);
PRIVATE VOID mgcoPrintTmrCfg(CLI_ENV *pCliEnv, TmrCfg *tmrCfg);
PRIVATE VOID mgcoPrintDnsCfg(CLI_ENV *pCliEnv, MgDnsCfg *dnsCfg);
PRIVATE VOID mgcoPrintTSAPReCfg(CLI_ENV *pCliEnv, MgTSAPReCfg *tsapReCfg);
PRIVATE VOID mgcoPrintTSAPCfg(CLI_ENV *pCliEnv, MgTSAPCfg *tsapCfg);
PRIVATE VOID mgcoPrintLstnrLst(CLI_ENV *pCliEnv, MgLstnrLst *lstnrLst);
PRIVATE VOID mgcoPrintDnsSts(CLI_ENV *pCliEnv, MgDnsSts *dnsSts);
PRIVATE VOID mgcoPrintTSAPSts(CLI_ENV *pCliEnv, MgTSAPSts *tsapSts);
PRIVATE VOID mgcoPrintDnsInfo(CLI_ENV *pCliEnv, MgDnsInfo *dnsInfo);
PRIVATE VOID mgcoPrintCmTqCp(CLI_ENV *pCliEnv, CmTqCp *tqCp);
PRIVATE VOID mgcoPrintCmTqType(CLI_ENV *pCliEnv, CmTqType *cmTqType);
PRIVATE VOID mgcoPrintSSAPCb(CLI_ENV * pCliEnv, MgSSAPCb *mgSSapCb);
PRIVATE VOID mgcoPrintTskInit(CLI_ENV *pCliEnv, TskInit *tskInit);
PRIVATE VOID mgcoPrintBndCfg(CLI_ENV *pCliEnv, BndCfg *bndCfg);
PRIVATE VOID mgcoPrintTSAPCb(CLI_ENV *pCliEnv, MgTSAPCb *tsapCb);
PRIVATE VOID X8ToIP(U32 x8);

extern VOID mgcoPrintMgCb(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern VOID mgcoPrintGenCfg(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern VOID mgcoPrintSSAPLst(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern VOID mgcoPrintTSAPLst(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern VOID mgcoPrintPeerLst(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern VOID mgcoPrintPeerLstSts(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern VOID showTraceLevel(CLI_ENV *pCliEnv);
extern VOID mgSetTraceLevel(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
EXTERN U16 g_PortNum; /* cdw add on 2006.10.10*/

/************************************************************/
/*****  Functions: Print all Control Block of GCP layer  ******/
/************************************************************/

/*************************************************************
 * Print MgCb info
 */
 
VOID mgcoPrintMgCb(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{	

	MgGenCfg *pGenCfg = (MgGenCfg *)&mgCb.genCfg;
//	int idx;
	XOS_CliExtPrintf(pCliEnv, "--------------------   Print MgCb   -------------------\r\n");
#ifdef GCP_MGC
#ifdef GCP_MGCO
	XOS_CliExtPrintf(pCliEnv, "nxtMgcoSsapId		:%d\r\n", mgCb.nxtMgcoSsapId);
#endif /* GCP_MGCO */
#endif /* GCP_MGC */	
#ifdef GCP_USE_PEERID
	XOS_CliExtPrintf(pCliEnv, "freePeerIdx		:%d\r\n", mgCb.freePeerIdx);
	XOS_CliExtPrintf(pCliEnv, "lastFreePeerIdx		:%d\r\n", mgCb.lastFreePeerIdx);
#endif /* GCP_USE_PEERID */
//	XOS_CliExtPrintf(pCliEnv, "dnsTsap			:%d\r\n", mgCb.dnsTsap);
	XOS_CliExtPrintf(pCliEnv, "curNumPeer		:%d\r\n", mgCb.curNumPeer);
	XOS_CliExtPrintf(pCliEnv, "suppVersion		:%d\r\n", mgCb.suppVersion);	
/*#ifdef CM_ABNF_MT_LIB
	mgcoPrintPostInfo(pCliEnv, &(mgCb.edPst));
	XOS_CliExtPrintf(pCliEnv, "MgCbInfo: intfVer(%d)\r\n", mgCb.intfVer);	
	XOS_CliExtPrintf(pCliEnv, "MgCbInfo: nxtEDInst(%d), lastEDInst(%d)\r\n", 
		mgCb.nxtEDInst, mgCb.lastEDInst);
	XOS_CliExtPrintf(pCliEnv, "MgCbInfo: tskIdAr(%d)\r\n", *(mgCb.tskIdAr)); 
	XOS_CliExtPrintf(pCliEnv, "MgCbInfo: decCntr(%d), encCntr(%d)\r\n", 
		mgCb.decCntr, mgCb.encCntr);	
	mgcoPrintStoreList(pCliEnv, &(mgCb.decList));
	mgcoPrintStoreList(pCliEnv, &(mgCb.encList));
	mgcoPrintDfrCfm(pCliEnv, &(mgCb.shutDwnCfm));
#endif /* CM_ABNF_MT_LIB */
#ifdef MG_RUG 
	mgcoPrintIntVerInfo(pCliEnv, &(mgCb.verInfo));
#endif /* MG_RUG */
	/*Task init for this instance*/
	XOS_CliExtPrintf(pCliEnv, "--------------------   member \"init\"  -----------------\r\n");
	mgcoPrintTskInit(pCliEnv, &(mgCb.init));
	/*print GenCfg information*/
	mgcoPrintGenCfg(pCliEnv,1,"mgcoPrintGenCfg");
	/*print all TSAP information*/
	mgcoPrintTSAPLst(pCliEnv,1,"mgcoPrintTSAPLst");
	/*Print all SSAP inforamtion*/
	mgcoPrintSSAPLst(pCliEnv,1,"mgcoPrintSSAPLst");
#ifdef GCP_USE_PEERID
	/*print all peer information*/
	mgcoPrintPeerLst(pCliEnv,1,"mgcoPrintPeerLst");
#endif
	XOS_CliExtPrintf(pCliEnv, "---------------------   Print End   --------------------\r\n");
}

/*****************************************************************
 * Print One SSAPCb
 */

VOID mgcoPrintSSAPCb(CLI_ENV * pCliEnv, MgSSAPCb *mgSSapCb)
{	
	XOS_CliExtPrintf(pCliEnv, "suId			:%d\r\n", mgSSapCb->suId);
	switch(mgSSapCb->state)
		{
			case 1 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_UBND_DIS(1)\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_BND_ENB(2)\r\n");break;
			case 3 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_BND_DIS(3)\r\n");break;
			case 4 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_WAIT_BNDENB(4)\r\n");break;
			case 5 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_WAIT_BNDDIS(5)\r\n");break;
			case 6 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_UBND_ENB(6)\r\n");break;
			case 7 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_WAIT_UBNDENB(7)\r\n");break;
			case 8 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_DELETED(8)\r\n");break;
			default : break;
		}
//	XOS_CliExtPrintf(pCliEnv, "state 			:%d\r\n", mgSSapCb->state);
	XOS_CliExtPrintf(pCliEnv, "enbIndSent		:%d\r\n", mgSSapCb->enbIndSent);	
	XOS_CliExtPrintf(pCliEnv, "numPeerRslvd		:%d\r\n", mgSSapCb->numPeerRslvd);
	XOS_CliExtPrintf(pCliEnv, "nxtTransId		:%d\r\n", mgSSapCb->nxtTransId);
	XOS_CliExtPrintf(pCliEnv, "numActvLstnrs		:%d\r\n", mgSSapCb->numActvLstnrs);	
	XOS_CliExtPrintf(pCliEnv, "peerLst.count		:%d\r\n", mgSSapCb->peerLst.count);
	switch(mgSSapCb->resCong)
		{
			case 0 : XOS_CliExtPrintf(pCliEnv, "resCong			:FALSE\r\n");break;
			case 1 : XOS_CliExtPrintf(pCliEnv, "resCong			:TRUE\r\n");break;
			default :break;
		}
//	XOS_CliExtPrintf(pCliEnv, "resCong			:%d\r\n", mgSSapCb->resCong);
//	XOS_CliExtPrintf(pCliEnv, "numTcpLosses		:%d\r\n", mgSSapCb->numTcpLosses);
#ifdef GCP_MG
	switch(mgSSapCb->mgType)
		{
			case 0 : XOS_CliExtPrintf(pCliEnv, "mgType			:MG_NONE(0)\r\n");break;
			case 1 : XOS_CliExtPrintf(pCliEnv, "mgType			:MG_ACTIVE(1)\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv, "mgType			:MG_STANDBY(2)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv, "mgType			:Invalid mgType\r\n");break;
		}
//	XOS_CliExtPrintf(pCliEnv, "mgType			:%d\r\n", mgSSapCb->mgType);
#endif
	XOS_CliExtPrintf(pCliEnv, "-----------------   member \"ssapCfg\"  ----------------\r\n");
	mgcoPrintSSAPCfg(pCliEnv, &(mgSSapCb->ssapCfg));	
#ifdef GCP_MGCO
#ifdef GCP_MG
	mgcoPrintTptSrvrInfo(pCliEnv, &(mgSSapCb->mgcoUDPSrvrLst));  
	/*	mgcoPrintTptSrvr(pCliEnv, sSapCb->nxtUseMgcoSrvr);   */
//	XOS_CliExtPrintf(pCliEnv, "    crntMgc = %x\r\n", mgSSapCb->crntMgc);
/*
	XOS_CliExtPrintf(pCliEnv, "---------------   some info of pointer \"crntMgc\" is  --------------\r\n");
	XOS_CliExtPrintf(pCliEnv, "state				:%d\r\n",	mgSSapCb->crntMgc->state);
	XOS_CliExtPrintf(pCliEnv, "regReqTxnId			:%d\r\n",	mgSSapCb->crntMgc->regReqTxnId);

	XOS_CliExtPrintf(pCliEnv, "accessInfo.namePres		:%d\r\n", mgSSapCb->crntMgc->accessInfo.namePres);
	if(NULL != mgSSapCb->crntMgc->accessInfo.name)	
		XOS_CliExtPrintf(pCliEnv, "accessInfo.name			:%s\r\n", mgSSapCb->crntMgc->accessInfo.name);
#ifdef GCP_USE_PEERID
     	XOS_CliExtPrintf(pCliEnv, "accessInfo.peerId		:%d\r\n", mgSSapCb->crntMgc->accessInfo.peerId);
#endif 
	XOS_CliExtPrintf(pCliEnv, "accessInfo.remotePort		:%d\r\n", mgSSapCb->crntMgc->accessInfo.remotePort);
     	XOS_CliExtPrintf(pCliEnv, "accessInfo.transportType	:%d\r\n", mgSSapCb->crntMgc->accessInfo.transportType);
	XOS_CliExtPrintf(pCliEnv, "accessInfo.peerflg		:%d\r\n", mgSSapCb->crntMgc->accessInfo.peerflg);   
	XOS_CliExtPrintf(pCliEnv, "accessInfo.mid.val		:%s\r\n", mgSSapCb->crntMgc->accessInfo.mid.val); 
	XOS_CliExtPrintf(pCliEnv, "accessInfo.peerAddrTbl.count	:%d\r\n", mgSSapCb->crntMgc->accessInfo.peerAddrTbl.count);
	for(idx=0;idx<mgSSapCb->crntMgc->accessInfo.peerAddrTbl.count;idx++)	
		{
		XOS_CliExtPrintf(pCliEnv,"accessInfo.peerAddrTbl->netAddr[%d].u.ipv4NetAddr :",idx);
		
		X8ToIP(mgSSapCb->crntMgc->accessInfo.peerAddrTbl.netAddr[idx].u.ipv4NetAddr);
		}
*/
#endif /* GCP_MG */
#endif /* GCP_MGCO */

}

/*****************************************************************
 * Print SSAPLst
 */

VOID mgcoPrintSSAPLst(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	MgSSAPCb *sSapCb=NULLP;
	MgGenCfg *pGenCfg = (MgGenCfg *)&mgCb.genCfg;
	U16 idx;
	U16 input;
	if(1 == siArgc)
		{
			for(idx=0; idx<pGenCfg->maxSSaps; idx++)
				{
					sSapCb = mgCb.sSAPLst[idx];
					if ((MgSSAPCb*)NULLP == sSapCb)
						continue;
					XOS_CliExtPrintf(pCliEnv, "---------------   Print SSAPCb (id=%d)  ---------------\r\n",idx);
					mgcoPrintSSAPCb(pCliEnv, sSapCb);
				}
		}
	else if(2 == siArgc)
		{
			if(strlen(ppArgv[1]) != 1 || ppArgv[1][0] > '9' ||ppArgv[1][0] < '0')
				XOS_CliExtPrintf(pCliEnv, "		You Input Wrong Argument!!!		\r\n");
			else
				{
					input = (U32)ppArgv[1][0] - (U32)'0';
					if((MgSSAPCb*)NULLP == mgCb.sSAPLst[input])
						XOS_CliExtPrintf(pCliEnv, "		SSAP index(%d) is NULL!!!		\r\n",input);
					else
						{
							XOS_CliExtPrintf(pCliEnv, "---------------   Print SSAPCb (id=%d)  ---------------\r\n",input);
							mgcoPrintSSAPCb(pCliEnv, mgCb.sSAPLst[input]);
						}
				}	
		}
	else
		XOS_CliExtPrintf(pCliEnv, "		You Input Wrong Argument!!!		\r\n");
}

/*****************************************************************
 * Print TSAPLst
 */

VOID mgcoPrintTSAPLst(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	MgTSAPCb *tSapCb=NULLP;
	MgGenCfg *pGenCfg = (MgGenCfg *)&mgCb.genCfg;
	U16 idx;
	U16 input;
	if(1 == siArgc)
		{
			for(idx=0; idx<pGenCfg->maxTSaps; idx++)
				{
					tSapCb = mgCb.tSAPLst[idx];
					if ((MgTSAPCb*)NULLP == tSapCb)
						continue;	
					XOS_CliExtPrintf(pCliEnv, "---------------   Print TSAPCb (id=%d)  ---------------\r\n",idx);
					mgcoPrintTSAPCb(pCliEnv, tSapCb);
				}
		}
	else if(2 == siArgc)
		{
			if(strlen(ppArgv[1]) != 1 || ppArgv[1][0] > '9' || ppArgv[1][0] < '0')
				XOS_CliExtPrintf(pCliEnv, "		You Input Wrong Argument!!!		\r\n");
			else
				{
					input = (U32)ppArgv[1][0] - (U32)'0';
					if((MgTSAPCb*)NULLP == mgCb.tSAPLst[input])
						XOS_CliExtPrintf(pCliEnv, "		TSAP index(%d) is NULL!!!		\r\n",input);
					else
						{
							XOS_CliExtPrintf(pCliEnv, "---------------   Print TSAPCb (id=%d)  ---------------\r\n",input);
							mgcoPrintTSAPCb(pCliEnv, mgCb.tSAPLst[input]);
						}
				}	
		}
	else
		XOS_CliExtPrintf(pCliEnv, "		You Input Wrong Argument!!!		\r\n");
}

/*****************************************************************
 * Print mgPeerLst
 */
 
VOID mgcoPrintPeerLst(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	MgPeerLst *peerLst=NULLP;
	U16 idx,peerNum=0;
	U16 input;
	MgGenCfg *pGenCfg = (MgGenCfg *)&mgCb.genCfg;
	
//	XOS_CliExtPrintf(pCliEnv, "valid Peer id is(0 to %d)\r\n",pGenCfg->maxPeer);
	if(1 == siArgc)
		{
			for(idx=0; idx < pGenCfg->maxPeer;idx++)
				{
					peerLst=mgCb.peerLst[idx];
					if((MgPeerLst*)NULLP == peerLst || peerLst->peer == NULL)
						{
							continue;
						}
//		XOS_CliExtPrintf(pCliEnv, "[GCP]PeerLst: index(%d)\r\n", peerLst->index);
				peerNum++;
				XOS_CliExtPrintf(pCliEnv, "---------------   Print PeerCb (id=%d)   ---------------\r\n",idx);
				mgcoPrintPeerCb(pCliEnv, peerLst->peer);
				}
			if(0 == peerNum)
			printf("------  there is no peer for this entity   -------\r\n");
		}
	else if(2 == siArgc)
		{
			if(strlen(ppArgv[1]) != 1 || ppArgv[1][0] > '9' ||ppArgv[1][0] < '0')
				XOS_CliExtPrintf(pCliEnv, "		You Input Wrong Argument!!!		\r\n");
			else
				{
					input = (U32)ppArgv[1][0] - (U32)'0';
					if((MgPeerLst*)NULLP == mgCb.peerLst[input] || mgCb.peerLst[input]->peer == NULL)
						XOS_CliExtPrintf(pCliEnv, "		Peer index(%d) is NULL!!!		\r\n",input);
					else
						{
							XOS_CliExtPrintf(pCliEnv, "---------------   Print PeerCb (id=%d)   ---------------\r\n",input);
							mgcoPrintPeerCb(pCliEnv, mgCb.peerLst[input]->peer);
						}
				}	
		}
	else 
		XOS_CliExtPrintf(pCliEnv, "		You Input Wrong Argument!!!		\r\n");
}

/*****************************************************************
 * Print TSAP Cb
 */
VOID mgcoPrintTSAPCb(CLI_ENV *pCliEnv, MgTSAPCb *tsapCb)
{
	U16 i;
	XOS_CliExtPrintf(pCliEnv, "nxtFreeIdx		:%d\r\n", tsapCb->nxtFreeIdx);
	XOS_CliExtPrintf(pCliEnv, "nxtConnIdx		:%d\r\n", tsapCb->nxtConnIdx);
	XOS_CliExtPrintf(pCliEnv, "connIdxWrapArnd		:%d\r\n", tsapCb->connIdxWrapArnd);
	XOS_CliExtPrintf(pCliEnv, "bndRetxCnt		:%d\r\n", tsapCb->bndRetxCnt);
	switch(tsapCb->contEnt)
		{	
			case 0x75 : XOS_CliExtPrintf(pCliEnv, "ent			:ENTHI(0x75)\r\n");break;
			case 0x32 : XOS_CliExtPrintf(pCliEnv, "ent			:ENTMU(0x32)\r\n");break;
			case 0x7e : XOS_CliExtPrintf(pCliEnv, "ent			:ENTMG(0x7E)\r\n");break;
			case 0xe : XOS_CliExtPrintf(pCliEnv, "ent			:ENTSM(0xE)\r\n");break;
			case 0xff : XOS_CliExtPrintf(pCliEnv, "ent			:ENTNC(0xFF)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv, "ent			:0x%x\r\n", tsapCb->contEnt);break;
		}
//	XOS_CliExtPrintf(pCliEnv, "contEnt			:%d\r\n", tsapCb->contEnt);
	XOS_CliExtPrintf(pCliEnv, "crntActvSsap		:%d\r\n", tsapCb->crntActvSsap);
	switch(tsapCb->state)
		{
			case 1 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_UBND_DIS(1)\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_BND_ENB(2)\r\n");break;
			case 3 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_BND_DIS(3)\r\n");break;
			case 4 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_WAIT_BNDENB(4)\r\n");break;
			case 5 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_WAIT_BNDDIS(5)\r\n");break;
			case 6 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_UBND_ENB(6)\r\n");break;
			case 7 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_WAIT_UBNDENB(7)\r\n");break;
			case 8 : XOS_CliExtPrintf(pCliEnv, "state 			:LMG_SAP_DELETED(8)\r\n");break;
			default : break;
		}
//	XOS_CliExtPrintf(pCliEnv, "state			:%d\r\n", tsapCb->state);
	switch(tsapCb->cfgDone)
		{
			case 0 : XOS_CliExtPrintf(pCliEnv, "cfgDone			:FALSE\r\n");break;
			case 1 : XOS_CliExtPrintf(pCliEnv, "cfgDone			:TRUE\r\n");break;
			default : break;
		}
//      	XOS_CliExtPrintf(pCliEnv, "cfgDone			:%d\r\n", tsapCb->cfgDone);
	switch(tsapCb->resCong)
		{
			case 0 : XOS_CliExtPrintf(pCliEnv, "resCong			:FALSE\r\n");break;
			case 1 : XOS_CliExtPrintf(pCliEnv, "resCong			:TRUE\r\n");break;
			default : break;
		}
//      	XOS_CliExtPrintf(pCliEnv, "resCong			:%d\r\n", tsapCb->resCong);
	XOS_CliExtPrintf(pCliEnv, "trcLen			:%d\r\n", tsapCb->trcLen);			
	XOS_CliExtPrintf(pCliEnv, "-----------------   member \"tsapCfg\"  ----------------\r\n");
	mgcoPrintTSAPCfg(pCliEnv, &(tsapCb->tsapCfg));				
	//	for(i=0;NULL != tsapCb->lstnrLst[i];i++)
	//		{
	//			XOS_CliExtPrintf(pCliEnv, "[GCP]TSAPCb: **********No.%d lstnrLst is:\r\n");
	// 				mgcoPrintLstnrLst(pCliEnv, tsapCb->lstnrLst[i]);
	// 				XOS_CliExtPrintf(pCliEnv, "[GCP]TSAPCb: **********End of No.%d lstnrLst\r\n");	  
	//			}

	//*		XOS_CliExtPrintf(pCliEnv, "  ----------------------   member \"dnsInfo\"  ---------------------\r\n");
	//*		mgcoPrintDnsInfo(pCliEnv, &(tsapCb->dnsInfo));
//#ifdef GCP_MGCO
//	mgcoPrintTptSrvrInfo(pCliEnv, &(tsapCb->mgcoUDPSrvrLst));				
//	XOS_CliExtPrintf(pCliEnv, "---------------   member \"nxtUseMgcoSrvr\"  --------------\r\n");
//	mgcoPrintTptSrvr(pCliEnv, tsapCb->nxtUseMgcoSrvr);
#ifdef GCP_MGC   /* cdw mod for printing more than 1 server on 2006.10.10*/
	for(i=0;i<g_PortNum;i++)
		{
		    if(NULL != tsapCb->lstnrLst[i]->lstnrCb)
		    	{
					XOS_CliExtPrintf(pCliEnv, "----------------   tpt server %d info  ---------------\r\n",i+1);	
					mgcoPrintTptSrvr(pCliEnv, tsapCb->lstnrLst[i]->lstnrCb);
				}
			}
//      	XOS_CliExtPrintf(pCliEnv, "---------------   member \"tcpSrvrInfo\"  -------------\r\n");
//	mgcoPrintTptSrvrInfo(pCliEnv, &(tsapCb->tcpSrvrInfo));	
#endif /* GCP_MGC */
#ifdef GCP_MG   /*cdw add for printing MG server info on 2006.10.10*/
	if(NULL != tsapCb->lstnrLst[0]->lstnrCb)
		{
			XOS_CliExtPrintf(pCliEnv, "----------------   tpt server %d info  ---------------\r\n",1);	
			mgcoPrintTptSrvr(pCliEnv, tsapCb->lstnrLst[0]->lstnrCb);
		}
#endif
//#endif /* GCP_MGCO */	
       XOS_CliExtPrintf(pCliEnv, "------------------   member \"spPst\"  -----------------\r\n");
	mgcoPrintPostInfo(pCliEnv, &(tsapCb->spPst));
    	XOS_CliExtPrintf(pCliEnv, "-------------------   member \"sts\"  ------------------\r\n");
	mgcoPrintTSAPSts(pCliEnv, &(tsapCb->sts));						
}

/*****************************************************************
 * Print ShtVerInfo
 */

#ifdef TDS_ROLL_UPGRADE_SUPPORT
PRIVATE VOID mgcoPrintShtVerInfo(CLI_ENV *pCliEnv, ShtVerInfo *shtVerInfo)
{
	XOS_CliExtPrintf(pCliEnv, "ShtVerInfo: grpType(%d)\r\n", shtVerInfo->grpType);
       XOS_CliExtPrintf(pCliEnv, "ShtVerInfo: **********intfInfo(Interface version info store) is: \r\n");   
	mgcoPrintIntVerInfo(pCliEnv, shtVerInfo->intfInfo);
	XOS_CliExtPrintf(pCliEnv, "ShtVerInfo: **********End of intfInfo\r\n");
}	
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
/*****************************************************************
 * Print MgIntVerInfo
 */
#ifdef MG_RUG
PRIVATE VOID mgcoPrintIntVerInfo(CLI_ENV *pCliEnv, MgIntVerInfo *intVerInfo)
{
	XOS_CliExtPrintf(pCliEnv, "MgIntVerInfo: numIntfInfo(%d)\r\n", intVerInfo->numIntfInfo);
	XOS_CliExtPrintf(pCliEnv, "MgIntVerInfo: dstProcId(%d)\r\n", intVerInfo->dstProcId);
	XOS_CliExtPrintf(pCliEnv, "MgIntVerInfo: dstEnt.ent(%d), dstEnt.inst(%d)\r\n", 
		intVerInfo->dstEnt.ent, intVerInfo->dstEnt.inst);
	XOS_CliExtPrintf(pCliEnv, "MgIntVerInfo: intf.intfId(%d), intf.intfVer(%d)\r\n", 
		intVerInfo->intf.intfId, intVerInfo->intf.intfVer);	  
}
#endif /* MG_RUG */
/*****************************************************************
 * Print ElmntId
 */
PRIVATE VOID mgcoPrintElmntId(CLI_ENV *pCliEnv, ElmntId *elmntId)
{
	XOS_CliExtPrintf(pCliEnv, "ElmntId: elmnt(%d)\r\n", elmntId->elmnt);
      	XOS_CliExtPrintf(pCliEnv, "ElmntId: elmntInst1(%d)\r\n", elmntId->elmntInst1);
      	XOS_CliExtPrintf(pCliEnv, "ElmntId: elmntInst2(%d)\r\n", elmntId->elmntInst2);
      	XOS_CliExtPrintf(pCliEnv, "ElmntId: elmntInst3(%d)\r\n", elmntId->elmntInst3);	      
}

/*****************************************************************
 * Print BndCfg
 */
PRIVATE VOID mgcoPrintBndCfg(CLI_ENV *pCliEnv, BndCfg *bndCfg)
{	
   	XOS_CliExtPrintf(pCliEnv, "usrId			:%s\r\n", bndCfg->usrId);
	XOS_CliExtPrintf(pCliEnv, "bufOwnshp		:%d\r\n", bndCfg->bufOwnshp);
	XOS_CliExtPrintf(pCliEnv, "flcTyp			:%d\r\n", bndCfg->flcTyp);
	XOS_CliExtPrintf(pCliEnv, "wdw			:%d\r\n", bndCfg->wdw);
	XOS_CliExtPrintf(pCliEnv, "ent			:%d\r\n", bndCfg->ent);
	XOS_CliExtPrintf(pCliEnv, "inst			:%d\r\n", bndCfg->inst);
	XOS_CliExtPrintf(pCliEnv, "region			:%d\r\n", bndCfg->region);
	XOS_CliExtPrintf(pCliEnv, "pool			:%d\r\n", bndCfg->pool);
	XOS_CliExtPrintf(pCliEnv, "prior			:%d\r\n", bndCfg->prior);
	XOS_CliExtPrintf(pCliEnv, "route			:%d\r\n", bndCfg->route);
	XOS_CliExtPrintf(pCliEnv, "sapAdr.length		:%d\r\n", bndCfg->sapAdr.length);
	if(NULL != bndCfg->sapAdr.strg)
		XOS_CliExtPrintf(pCliEnv, "sapAdr.strg[]		:%s\r\n", bndCfg->sapAdr.strg);
	XOS_CliExtPrintf(pCliEnv, "selector		:%d\r\n", bndCfg->selector);	
}


/*****************************************************************
 * Print TskInit
 */
PRIVATE VOID mgcoPrintTskInit(CLI_ENV *pCliEnv, TskInit *tskInit)
{

#ifdef SS_MULTIPLE_PROCS
	XOS_CliExtPrintf(pCliEnv, "proc			:%d\r\n", tskInit->proc);
#endif /* SS_MULTIPLE_PROCS */
	switch(tskInit->ent)
		{	
			case 0x75 : XOS_CliExtPrintf(pCliEnv, "ent			:ENTHI(0x75)\r\n");break;
			case 0x32 : XOS_CliExtPrintf(pCliEnv, "ent			:ENTMU(0x32)\r\n");break;
			case 0x7e : XOS_CliExtPrintf(pCliEnv, "ent			:ENTMG(0x7E)\r\n");break;
			case 0xe : XOS_CliExtPrintf(pCliEnv, "ent			:ENTSM(0xE)\r\n");break;
			case 0xff : XOS_CliExtPrintf(pCliEnv, "ent			:ENTNC(0xFF)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv, "ent			:0x%x\r\n", tskInit->ent);break;
		}
//	XOS_CliExtPrintf(pCliEnv, "ent			:%d\r\n", tskInit->ent);
	XOS_CliExtPrintf(pCliEnv, "inst			:%d\r\n", tskInit->inst);
	XOS_CliExtPrintf(pCliEnv, "region			:%d\r\n", tskInit->region);
	XOS_CliExtPrintf(pCliEnv, "pool			:%d\r\n", tskInit->pool);
	XOS_CliExtPrintf(pCliEnv, "reason			:%d\r\n", tskInit->reason);
	switch(tskInit->cfgDone)
		{
			case 0 : XOS_CliExtPrintf(pCliEnv, "cfgDone			:FALSE\r\n");break;
			case 1 : XOS_CliExtPrintf(pCliEnv, "cfgDone			:TRUE\r\n");break;
			default : break;
		}
//	XOS_CliExtPrintf(pCliEnv, "cfgDone			:%d\r\n", tskInit->cfgDone);
	XOS_CliExtPrintf(pCliEnv, "acnt			:%d\r\n", tskInit->acnt);
	XOS_CliExtPrintf(pCliEnv, "usta			:%d\r\n", tskInit->usta);
	XOS_CliExtPrintf(pCliEnv, "trc			:%d\r\n", tskInit->trc);  
#ifdef DEBUGP
   	XOS_CliExtPrintf(pCliEnv, "dbgMask			:%d(0x%x)\r\n", tskInit->dbgMask,tskInit->dbgMask);
//	if(NULL != tskInit->prntBuf) 
//		XOS_CliExtPrintf(pCliEnv, "prntBuf			:%s\r\n", tskInit->prntBuf); 
#endif
   	XOS_CliExtPrintf(pCliEnv, "procId			:%d\r\n", tskInit->procId);
//	XOS_CliExtPrintf(pCliEnv, "---------------   member \"init.lmBnd\"  --------------\r\n");
//     	mgcoPrintBndCfg(pCliEnv,&(tskInit->lmBnd));
//	XOS_CliExtPrintf(pCliEnv, "---------------   member \"init.lmPst\"  --------------\r\n");
//	mgcoPrintPostInfo(pCliEnv, &(tskInit->lmPst));
}

/*****************************************************************
 * Print Resp
 */
PRIVATE VOID mgcoPrintMem(CLI_ENV *pCliEnv, Mem *mem)
{
	XOS_CliExtPrintf(pCliEnv, "Mem: region(%d)\r\n", mem->region);
       XOS_CliExtPrintf(pCliEnv, "Mem: pool(%d)\r\n", mem->pool);
       XOS_CliExtPrintf(pCliEnv, "Mem: spare(%d)\r\n", mem->spare);	      
}

/*****************************************************************
 * Print Resp
 */
PRIVATE VOID mgcoPrintResp(CLI_ENV *pCliEnv, Resp *resp)
{
	XOS_CliExtPrintf(pCliEnv, "Resp: selector(%d)\r\n", resp->selector);
       XOS_CliExtPrintf(pCliEnv, "Resp: prior(%d)\r\n", resp->prior);
       XOS_CliExtPrintf(pCliEnv, "Resp: route(%d)\r\n", resp->route);
       XOS_CliExtPrintf(pCliEnv, "Resp: **********memory is:\r\n");
	mgcoPrintMem(pCliEnv, &resp->mem);
	XOS_CliExtPrintf(pCliEnv, "Resp: **********End of memory\r\n");
}

/*****************************************************************
 * Print Header
 */
PRIVATE VOID mgcoPrintHeader(CLI_ENV *pCliEnv, Header *header)
{
	XOS_CliExtPrintf(pCliEnv, "Header: msgLen(%d)\r\n", header->msgLen);
       XOS_CliExtPrintf(pCliEnv, "Header: msgType(%d)\r\n", header->msgType);
       XOS_CliExtPrintf(pCliEnv, "Header: version(%d)\r\n", header->version);
       XOS_CliExtPrintf(pCliEnv, "Header: seqNmb(%d)\r\n", header->seqNmb);	
       XOS_CliExtPrintf(pCliEnv, "Header: entId.ent(%d), entId.inst(%d)\r\n", 
	   	header->entId.ent, header->entId.inst);
	XOS_CliExtPrintf(pCliEnv, "Header: **********elmId is:\r\n");
	mgcoPrintElmntId(pCliEnv, &(header->elmId));
	XOS_CliExtPrintf(pCliEnv, "Header: **********End of elmId\r\n");
#ifdef LMINT3
       XOS_CliExtPrintf(pCliEnv, "Header: transId(%d)\r\n", header->transId);	
       XOS_CliExtPrintf(pCliEnv, "Header: **********response is:\r\n");
	mgcoPrintResp(pCliEnv, &(header->response));
	XOS_CliExtPrintf(pCliEnv, "Header: **********End of response\r\n");
#endif /* LMINT3 */		
}

/*****************************************************************
 * Print MgDfrCfm
 */
#ifdef CM_ABNF_MT_LIB
PRIVATE VOID mgcoPrintDfrCfm(CLI_ENV *pCliEnv, MgDfrCfm *dfrCfm)
{
	XOS_CliExtPrintf(pCliEnv, "MgDfrCfm: dfrdCfm(%d)\r\n", dfrCfm->dfrdCfm);
	XOS_CliExtPrintf(pCliEnv, "MgDfrCfm: **********dfrdPst(Cmf Post structure) is:\r\n");
	mgcoPrintPostInfo(pCliEnv, &(dfrCfm->dfrdPst));
	XOS_CliExtPrintf(pCliEnv, "MgDfrCfm: **********End of dfrdPst\r\n");
	XOS_CliExtPrintf(pCliEnv, "MgDfrCfm: **********dfrdHdr(deffered header) is:\r\n");
	mgcoPrintHeader(pCliEnv, &(dfrCfm->dfrdHdr));	
	XOS_CliExtPrintf(pCliEnv, "MgDfrCfm: **********End of dfrdHdr\r\n");
}
#endif /* CM_ABNF_MT_LIB */
/*****************************************************************
 * Print MgStoreList
 */
PRIVATE VOID mgcoPrintStoreList(CLI_ENV *pCliEnv, MgStoreList *storeList)
{
	XOS_CliExtPrintf(pCliEnv, "StoreList: nodeIndx(%d)\r\n", storeList->nodeIndx);
	if((MgStoreList*)NULLP!=storeList->next)
		{
	            XOS_CliExtPrintf(pCliEnv, "StoreList: **********next(next node's pointer) is:\r\n");
		     mgcoPrintStoreList(pCliEnv, storeList->next);
		     XOS_CliExtPrintf(pCliEnv, "StoreList: **********End of next(next node's pointer)\r\n");	 
		}
	else
		{
		     XOS_CliExtPrintf(pCliEnv, "StoreList: next node's pointer is NULLP\r\n");
		}
	XOS_CliExtPrintf(pCliEnv, "StoreList: info(%s)\r\n", storeList->info);
}

/*****************************************************************
 * Print post information
 */
PRIVATE VOID mgcoPrintPostInfo(CLI_ENV *pCliEnv, Pst *pPst)
{
//	XOS_CliExtPrintf(pCliEnv, "dstProcId		:%d\r\n", pPst->dstProcId );
//	XOS_CliExtPrintf(pCliEnv, "srcProcId		:%d\r\n", pPst->srcProcId);
	switch(pPst->dstEnt)
		{	
			case 0x75 : XOS_CliExtPrintf(pCliEnv, "dstEnt			:ENTHI(0x75)\r\n");break;
			case 0x32 : XOS_CliExtPrintf(pCliEnv, "dstEnt			:ENTMU(0x32)\r\n");break;
			case 0x7e : XOS_CliExtPrintf(pCliEnv, "dstEnt			:ENTMG(0x7E)\r\n");break;
			case 0xe : XOS_CliExtPrintf(pCliEnv, "dstEnt				:ENTSM(0xE)\r\n");break;
			case 0xff : XOS_CliExtPrintf(pCliEnv, "dstEnt				:ENTNC(0xFF)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv, "dstEnt			:0x%x\r\n", pPst->dstEnt);break;
		}
//	XOS_CliExtPrintf(pCliEnv, "dstEnt			:0x%x\r\n", pPst->dstEnt);
		
	switch(pPst->srcEnt)
		{	
			case 0x75 : XOS_CliExtPrintf(pCliEnv, "srcEnt			:ENTHI(0x75)\r\n");break;
			case 0x32 : XOS_CliExtPrintf(pCliEnv, "srcEnt			:ENTMU(0x32)\r\n");break;
			case 0x7e : XOS_CliExtPrintf(pCliEnv, "srcEnt			:ENTMG(0x7E)\r\n");break;
			case 0xe : XOS_CliExtPrintf(pCliEnv, "srcEnt				:ENTSM(0xE)\r\n");break;
			case 0xff : XOS_CliExtPrintf(pCliEnv, "srcEnt				:ENTNC(0xFF)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv, "srcEnt			:0x%x\r\n", pPst->srcEnt);break;
		}
//	XOS_CliExtPrintf(pCliEnv, "srcEnt			:0x%x\r\n", pPst->srcEnt );
//	XOS_CliExtPrintf(pCliEnv, "dstInst			:%d\r\n", pPst->dstInst);
//	XOS_CliExtPrintf(pCliEnv, "srcInst			:%d\r\n", pPst->srcInst);
//	XOS_CliExtPrintf(pCliEnv, "prior			:%d\r\n", pPst->prior);
//	XOS_CliExtPrintf(pCliEnv, "route			:%d\r\n", pPst->route);
	switch(pPst->event)
		{
			case 1 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITBNDREQ(1)\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITBNDCFM(2)\r\n");break;
			case 3 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITUBNDREQ(3)\r\n");break;
			case 4 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITSRVOPENREQ(4)\r\n");break;
			case 5 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITCONREQ(5)\r\n");break;
			case 6 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITCONIND(6)\r\n");break;
			case 7 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITCONRSP(7)\r\n");break;
			case 8 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITCONCFM(8)\r\n");break;
			case 9 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITDATREQ(9)\r\n");break;
			case 10 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITDATIND(10)\r\n");break;
			case 11 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITUDATREQ(11)\r\n");break;
			case 12 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITUDATIND(12)\r\n");break;
			case 13 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITDISCREQ(13)\r\n");break;
			case 14 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITDISCIND(14)\r\n");break;
			case 15 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITDISCCFM(15)\r\n");break;
			case 16 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITFLCIND(16)\r\n");break;
			case 17 : XOS_CliExtPrintf(pCliEnv, "event			:EVTHITPDULENRNGREQ(17)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv, "event			:(%d)Invalid event\r\n",pPst->event);break;		
		}
//	XOS_CliExtPrintf(pCliEnv, "event			:%d\r\n", pPst->event);
//	XOS_CliExtPrintf(pCliEnv, "region			:%d\r\n", pPst->region);		
//	XOS_CliExtPrintf(pCliEnv, "pool			:%d\r\n", pPst->pool );
	XOS_CliExtPrintf(pCliEnv, "selector		:%d\r\n", pPst->selector);		
	XOS_CliExtPrintf(pCliEnv, "intfVer			:%d\r\n", pPst->intfVer);
}


/*****************************************************************
 * Print General configuration
 */
 
VOID mgcoPrintGenCfg(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{ 
     	MgGenCfg *cfg;
      	cfg = &(mgCb.genCfg);
	XOS_CliExtPrintf(pCliEnv, "------------------   member \"GenCfg\"  -----------------\r\n");
	XOS_CliExtPrintf(pCliEnv, "maxSSaps		:%d\r\n", cfg->maxSSaps);
	XOS_CliExtPrintf(pCliEnv, "maxTSaps		:%d\r\n", cfg->maxTSaps);
	XOS_CliExtPrintf(pCliEnv, "maxServers		:%d\r\n", cfg->maxServers);
	XOS_CliExtPrintf(pCliEnv, "maxConn			:%d\r\n", cfg->maxConn);	
	XOS_CliExtPrintf(pCliEnv, "maxTxn			:%d\r\n", cfg->maxTxn);
	XOS_CliExtPrintf(pCliEnv, "maxPeer			:%d\r\n", cfg->maxPeer);	
	XOS_CliExtPrintf(pCliEnv, "resThUpper		:%d\r\n", cfg->resThUpper);
	XOS_CliExtPrintf(pCliEnv, "resThLower		:%d\r\n", cfg->resThLower);   	
	XOS_CliExtPrintf(pCliEnv, "timeRes			:%d\r\n", cfg->timeRes);
#ifdef GCP_VER_1_3
      	XOS_CliExtPrintf(pCliEnv, "reCfg.rspAckEnb		:%d\r\n", cfg->reCfg.rspAckEnb);
#endif /* GCP_VER_1_3 */
     	XOS_CliExtPrintf(pCliEnv, "numBlks			:%d\r\n", cfg->numBlks);
     	XOS_CliExtPrintf(pCliEnv, "maxBlkSize		:%d\r\n", cfg->maxBlkSize);
     	XOS_CliExtPrintf(pCliEnv, "numBinsTxnIdHl		:%d\r\n", cfg->numBinsTxnIdHl);
	XOS_CliExtPrintf(pCliEnv, "numBinsNameHl		:%d\r\n", cfg->numBinsNameHl);		
     	XOS_CliExtPrintf(pCliEnv, "numBinsTptSrvrHl	:%d\r\n", cfg->numBinsTptSrvrHl);
	switch(cfg->entType)	
		{
			case 1 : XOS_CliExtPrintf(pCliEnv, "entType			:MGC\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv, "entType			:MG\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv, "entType			:Invalid Type\r\n");break;	
		}
//	XOS_CliExtPrintf(pCliEnv, "entType			:%d\r\n", cfg->entType);		
     	XOS_CliExtPrintf(pCliEnv, "indicateRetx		:%d\r\n",cfg->indicateRetx);
	XOS_CliExtPrintf(pCliEnv, "resOrder		:%d\r\n", cfg->resOrder);
#ifdef CM_ABNF_MT_LIB
     	XOS_CliExtPrintf(pCliEnv, "noEDInst	:%d\r\n", cfg->noEDInst);
     	XOS_CliExtPrintf(pCliEnv, "firstInst		:%d\r\n", cfg->firstInst);
     	mgcoPrintTmrCfg(pCliEnv, &(cfg->edEncTmr));	  
      	mgcoPrintTmrCfg(pCliEnv, &(cfg->edDecTmr));
#endif /* CM_ABNF_MT_LIB */
#if (defined(GCP_CH) && defined(GCP_VER_1_5))
      	XOS_CliExtPrintf(pCliEnv, "numBinsPeerCmdHl	:%d\r\n", cfg->numBinsPeerCmdHl);
      	XOS_CliExtPrintf(pCliEnv, "numBinsTransReqHl	:%d\r\n", cfg->numBinsTransReqHl);  
      	XOS_CliExtPrintf(pCliEnv, "numBinsTransIndRspCmdHl	:%d\r\n", cfg->numBinsTransIndRspCmdHl);
#endif /* GCP_CH && GCP_VER_1_5 */
#ifdef GCP_MG
 //     	mgcoPrintTmrCfg(pCliEnv, &(cfg->maxMgCmdTimeOut));
 	if(0 == cfg->maxMgCmdTimeOut.enb)
		XOS_CliExtPrintf(pCliEnv, "maxMgCmdTimeOut.enb	:%d\r\n", cfg->maxMgCmdTimeOut.enb);
	else
		XOS_CliExtPrintf(pCliEnv, "maxMgCmdTimeOut.val	:%d(Unit:100ms)\r\n", cfg->maxMgCmdTimeOut.val);
#endif /* GCP_MG */	
#ifdef GCP_MGC
//      	mgcoPrintTmrCfg(pCliEnv, &(cfg->maxMgcCmdTimeOut));
	if(0 == cfg->maxMgcCmdTimeOut.enb)
		XOS_CliExtPrintf(pCliEnv, "maxMgcCmdTimeOut.enb	:%d\r\n", cfg->maxMgcCmdTimeOut.enb);
	else
		XOS_CliExtPrintf(pCliEnv, "maxMgcCmdTimeOut.val	:%d(Unit:100ms)\r\n", cfg->maxMgcCmdTimeOut.val);
#endif /* GCP_MGC */
#if (defined(GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))
       /*mgcoPrintPengingLimit(pCliEnv, &(cfg->limit));*/
#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */	
//	XOS_CliExtPrintf(pCliEnv, "---------------   member \"genCfg.lmPst\"  --------------\r\n");
//	mgcoPrintPostInfo(pCliEnv, &(cfg->lmPst));
}

/*****************************************************************
	Print SSAP ReConfig
*/

PRIVATE VOID mgcoPrintSSAPReCfg(CLI_ENV *pCliEnv, MgSSAPReCfg *cfg)
{
	if(0 == cfg->initRetxTmr.enb)
    		XOS_CliExtPrintf(pCliEnv, "reCfg.initRetxTmr.enb	:%d\r\n", cfg->initRetxTmr.enb);
	else
		XOS_CliExtPrintf(pCliEnv, "reCfg.initRetxTmr.val	:%d(Unit:100ms)\r\n", cfg->initRetxTmr.val);
	if(0 == cfg->provRspTmr.enb)
		XOS_CliExtPrintf(pCliEnv, "reCfg.provRspTmr.enb	:%d\r\n", cfg->provRspTmr.enb);
	else	
		XOS_CliExtPrintf(pCliEnv, "reCfg.provRspTmr.val	:%d(Unit:100ms)\r\n", cfg->provRspTmr.val);
	if(0 == cfg->atMostOnceTmr.enb)
		XOS_CliExtPrintf(pCliEnv, "reCfg.atMostOnceTmr.enb	:%d\r\n", cfg->atMostOnceTmr.enb);
	else 
		XOS_CliExtPrintf(pCliEnv, "reCfg.atMostOnceTmr.val	:%d(Unit:100ms)\r\n", cfg->atMostOnceTmr.val);
	XOS_CliExtPrintf(pCliEnv, "reCfg.provRspDelay	:%d\r\n", cfg->provRspDelay);
}

/*****************************************************************
	Print  Peer Info
*/

PRIVATE VOID mgcoPrintPeerInfo(CLI_ENV *pCliEnv, MgPeerInfo *peerInfo)
{
	XOS_CliExtPrintf(pCliEnv,"userInfo.pres.pres	:%d\r\n", peerInfo->pres.pres);
	XOS_CliExtPrintf(pCliEnv,"userInfo.pres.val	:%d\r\n", peerInfo->pres.val);
	XOS_CliExtPrintf(pCliEnv,"userInfo.id.pres	:%d\r\n", peerInfo->id.pres);
	if(1 == peerInfo->id.pres)
	XOS_CliExtPrintf(pCliEnv,"userInfo.id.val		:%d\r\n", peerInfo->id.val);	
if(peerInfo->dname.namePres.pres!=0)
{
	XOS_CliExtPrintf(pCliEnv,"userInfo.dname.name	:%s\r\n", peerInfo->dname.name);
}
	if(0 == peerInfo->port.pres)
		XOS_CliExtPrintf(pCliEnv,"userInfo.port.pres	:%d\r\n", peerInfo->port.pres);
	else
		XOS_CliExtPrintf(pCliEnv,"userInfo.port.val	:%d\r\n", peerInfo->port.val);
//	XOS_CliExtPrintf(pCliEnv,"userInfo.dname.netAddr.ipv4NetAdd	:%x\r\n", peerInfo->dname.netAddr.u.ipv4NetAddr);
	XOS_CliExtPrintf(pCliEnv,"userInfo ipAddr		:");
	X8ToIP(peerInfo->dname.netAddr.u.ipv4NetAddr);
}

/*****************************************************************
	Print SSAP Config
*/

PRIVATE VOID mgcoPrintSSAPCfg(CLI_ENV *pCliEnv, MgSSAPCfg *cfg)
{
	XOS_CliExtPrintf(pCliEnv, "sSAPId			:%d\r\n", cfg->sSAPId);
	XOS_CliExtPrintf(pCliEnv, "sel			:%d\r\n", cfg->sel);
//	XOS_CliExtPrintf(pCliEnv, "prior			:%d\r\n", cfg->prior);
//	XOS_CliExtPrintf(pCliEnv, "route			:%d\r\n", cfg->route);
	switch(cfg->protocol)
		{
			case 1 : XOS_CliExtPrintf(pCliEnv,"protocol		:MGCP(1)\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv,"protocol		:MEGACO/H.248(2)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv,"protocol		:Invalid Protocol Type\r\n");break;
		}
//	XOS_CliExtPrintf(pCliEnv, "protocol		:%d\r\n", cfg->protocol);
	XOS_CliExtPrintf(pCliEnv, "startTxnNum		:%d\r\n", cfg->startTxnNum);
	XOS_CliExtPrintf(pCliEnv, "endTxnNum		:%d\r\n", cfg->endTxnNum);     			   
#ifdef GCP_MG
     	XOS_CliExtPrintf(pCliEnv, "initReg			:%d\r\n", cfg->initReg);
      	XOS_CliExtPrintf(pCliEnv, "mwdTimer		:%d\r\n", cfg->mwdTimer);	
#endif /* GCP_MG */
#if (defined(GCP_MGCO) || defined(TDS_ROLL_UPGRADE_SUPPORT))
	switch(cfg->maxMgcoVersion)
		{
			case 1 : XOS_CliExtPrintf(pCliEnv,"maxMgcoVersion		:LMG_VER_PROF_MGCO_H248_1_0(1)\r\n");break;
			case 2 :	XOS_CliExtPrintf(pCliEnv,"maxMgcoVersion		:LMG_VER_PROF_MGCO_H248_2_0(2)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv,"maxMgcoVersion		:Invalid maxMgcoVersion\r\n");break;
		}
	switch(cfg->minMgcoVersion)
		{
			case 1 : XOS_CliExtPrintf(pCliEnv,"minMgcoVersion		:LMG_VER_PROF_MGCO_H248_1_0(1)\r\n");break;
			case 2 :	XOS_CliExtPrintf(pCliEnv,"minMgcoVersion		:LMG_VER_PROF_MGCO_H248_2_0(2)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv,"minMgcoVersion		:Invalid minMgcoVersion\r\n");break;
		}
//  	XOS_CliExtPrintf(pCliEnv,"maxMgcoVersion		:%d\r\n", cfg->maxMgcoVersion); 
//	XOS_CliExtPrintf(pCliEnv,"minMgcoVersion		:%d\r\n", cfg->minMgcoVersion); 
#endif /* GCP_MGCO || TDS_ROLL_UPGRADE_SUPPORT */
#if (defined(GCP_CH) && defined(GCP_VER_1_5))     
     	XOS_CliExtPrintf(pCliEnv,"chEnabled		:%d\r\n", cfg->chEnabled);
#endif /* GCP_CH && GCP_VER_1_5 */
      	mgcoPrintSSAPReCfg(pCliEnv, &(cfg->reCfg)); 
	mgcoPrintPeerInfo(pCliEnv, &(cfg->userInfo));
#ifdef GCP_ALLOW_LIMIT_CFG
      	XOS_CliExtPrintf(pCliEnv,"maxNoOfTxnsPerMsg.pres	:%d\r\n", cfg->maxNoOfTxnsPerMsg.pres); 
	XOS_CliExtPrintf(pCliEnv,"maxNoOfTxnsPerMsg.val	:%d\r\n", cfg->maxNoOfTxnsPerMsg.val);
	XOS_CliExtPrintf(pCliEnv,"maxNoOfActnsPerTxn.pres	:%d\r\n", cfg->maxNoOfActnsPerTxn.pres); 
	XOS_CliExtPrintf(pCliEnv,"maxNoOfActnsPerTxn.val	:%d\r\n", cfg->maxNoOfActnsPerTxn.val);
	XOS_CliExtPrintf(pCliEnv,"maxNoOfCmdsPerActn.pres	:%d\r\n", cfg->maxNoOfCmdsPerActn.pres); 
	XOS_CliExtPrintf(pCliEnv,"maxNoOfCmdsPerActn.val	:%d\r\n", cfg->maxNoOfCmdsPerActn.val);
#endif /* GCP_ALLOW_LIMIT_CFG  */   
}

/*****************************************************************
	Print  Cm Tpt Addr
*/

PRIVATE VOID mgcoPrintCmTptAddr(CLI_ENV *pCliEnv, CmTptAddr *cmTptAddr)
{
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmTptAddr: u.ipv4TptAddr.port(%d), u.ipv4TptAddr.address(%x)\r\n", 
		cmTptAddr->u.ipv4TptAddr.port, cmTptAddr->u.ipv4TptAddr.address);	
}

/*****************************************************************
	Print  Cm Net Addr
*/

PRIVATE VOID mgcoPrintCmNetAddr(CLI_ENV *pCliEnv, CmNetAddr *cmNetAddr)
{
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmNetAddr: u.ipv4NetAddr(%x)\r\n", 
		cmNetAddr->u.ipv4NetAddr);	
}

/*****************************************************************
	Print  Cm Tpt Param
*/

PRIVATE VOID mgcoPrintCmTptParam(CLI_ENV *pCliEnv, CmTptParam *cmTptParam)
{
     	XOS_CliExtPrintf(pCliEnv,"    type			:%d\r\n", cmTptParam->type);	
#ifdef CM_TLS
    	XOS_CliExtPrintf(pCliEnv,"    tlsParam.certificateId	:%d\r\n", cmTptParam->certificateId);
     	XOS_CliExtPrintf(pCliEnv,"    tlsParam.privateKeyId	:%d\r\n", cmTptParam->privateKeyId);
	XOS_CliExtPrintf(pCliEnv,"    tlsParam.cipherSpecs		:%d\r\n", cmTptParam->cipherSpecs);	  
	XOS_CliExtPrintf(pCliEnv,"    tlsParam.compMethod	:%d\r\n", cmTptParam->compMethod);
	XOS_CliExtPrintf(pCliEnv,"    tlsParam.sessionIdLen	:%d\r\n", cmTptParam->sessionIdLen);	
	XOS_CliExtPrintf(pCliEnv,"    tlsParam.sessionId		:%d\r\n", cmTptParam->sessionId);
#endif	
       XOS_CliExtPrintf(pCliEnv,"    u.sockParam.listenQSize	:%d\r\n", cmTptParam->u.sockParam.listenQSize);	
       XOS_CliExtPrintf(pCliEnv,"    u.sockParam.numOpts	:%d\r\n", cmTptParam->u.sockParam.numOpts);
//       for(i=0;i<CM_MAX_SOCK_OPTS;i++)
//       {
//              if(&(cmTptParam->u.sockParam.sockOpts[i])==NULLP)
//                     {
//                           RETVOID;
//              	}
//	       XOS_CliExtPrintf(pCliEnv,"[GCP]CmTptParam: u.sockParam.sockOpts[i].level(%d)\r\n", 
//	   	cmTptParam->u.sockParam.sockOpts[i].level);
//		XOS_CliExtPrintf(pCliEnv,"[GCP]CmTptParam: u.sockParam.sockOpts[i].option(%d)\r\n", 
//	   	cmTptParam->u.sockParam.sockOpts[i].option);
//		#ifdef CM_INET2
//		XOS_CliExtPrintf(pCliEnv,"[GCP]CmTptParam: **********multicast information is: \r\n");
//		XOS_CliExtPrintf(pCliEnv,"[GCP]CmTptParam: **********Multicast adddress is: \r\n");
//		mgcoPrintCmNetAddr(pCliEnv, &(cmTptParam->u.sockParam.sockOpts[i].optVal.mCastInfo.mCastAddr));
//		XOS_CliExtPrintf(pCliEnv,"[GCP]CmTptParam: **********Local address is: \r\n");
//		mgcoPrintCmNetAddr(pCliEnv, &(cmTptParam->u.sockParam.sockOpts[i].optVal.mCastInfo.localAddr));
//		XOS_CliExtPrintf(pCliEnv,"[GCP]CmTptParam: **********End of multicast information \r\n");
//              #else
//		XOS_CliExtPrintf(pCliEnv,"[GCP]CmTptParam: **********multicast information is: \r\n");	  
//              mgcoPrintCmNetAddr(pCliEnv, &(cmTptParam->u.sockParam.sockOpts[i].optVal.mCastAddr));
//		XOS_CliExtPrintf(pCliEnv,"[GCP]CmTptParam: **********End of multicast information \r\n");	  
//              #endif /* CM_INET2 */
//		XOS_CliExtPrintf(pCliEnv,"[GCP]CmTptParam: **********local outgoing interface is: \r\n");	  
//		mgcoPrintCmNetAddr(pCliEnv, &(cmTptParam->u.sockParam.sockOpts[i].optVal.lclAddr));
//		XOS_CliExtPrintf(pCliEnv,"[GCP]CmTptParam: **********End of local outgoing interface \r\n");
//		XOS_CliExtPrintf(pCliEnv,"[GCP]CmTptParam: u.sockParam.sockOpts[i].optVal.value(%d)\r\n", 
//	   	cmTptParam->u.sockParam.sockOpts[i].optVal.value);	  
//      	}
}

/*****************************************************************
	Print  Cm Timer
*/

PRIVATE VOID mgcoPrintCmTimer(CLI_ENV *pCliEnv, CmTimer *cmTimer)
{
	if(cmTimer == NULL)
		return ;

	XOS_CliExtPrintf(pCliEnv,"[GCP]CmTimer: tmrEvnt(%d)\r\n", 
		cmTimer->tmrEvnt);
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmTimer: tqExpire(%d)\r\n", 
		cmTimer->tqExpire);
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmTimer: cb poiter(Pointer to start of control block list) is (%x)\r\n", 
		cmTimer->cb);
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmTimer: next timer pointer is(%x)\r\n", 
		cmTimer->next);	
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmTimer: prev timer pointer is(%x)\r\n", 
		cmTimer->prev);
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmTimer: ent2bUpd(%d)\r\n", 
		cmTimer->ent2bUpd);
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmTimer: entIdx(%d)\r\n", cmTimer->entIdx);
}

/*****************************************************************
	Print  UDP Server
*/

PRIVATE VOID mgcoPrintTptSrvr(CLI_ENV *pCliEnv, MgTptSrvr *tptSrvr)
{
	switch(tptSrvr->transportType)
		{
			case 0 : XOS_CliExtPrintf(pCliEnv,"transportType		:LMG_TPT_NONE(0)\r\n");break;
			case 1 : XOS_CliExtPrintf(pCliEnv,"transportType		:LMG_TPT_UDP(1)\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv,"transportType		:LMG_TPT_TCP(2)\r\n");break;
			case 3 : XOS_CliExtPrintf(pCliEnv,"transportType		:LMG_TPT_SCTP(3)\r\n");break;
			case 4 : XOS_CliExtPrintf(pCliEnv,"transportType		:LMG_TPT_MTP3(4)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv,"transportType		:Invalid transportType\r\n");break;
		}
//	XOS_CliExtPrintf(pCliEnv,"transportType		:%d\r\n", tptSrvr->transportType);
	XOS_CliExtPrintf(pCliEnv,"suConnId		:%d\r\n", tptSrvr->suConnId);
	XOS_CliExtPrintf(pCliEnv,"spConnId		:%d\r\n", tptSrvr->spConnId);
	switch(tptSrvr->state)
		{
			case 0 : XOS_CliExtPrintf(pCliEnv,"state			:LMG_LSTNR_STATE_NULL(0)\r\n");break;
			case 1 : XOS_CliExtPrintf(pCliEnv,"state			:LMG_LSTNR_STATE_CONNECTING(1)\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv,"state			:LMG_LSTNR_STATE_CONNECTED(2)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv,"state			:Invalid state\r\n");break;
		}
//	XOS_CliExtPrintf(pCliEnv,"state			:%d\r\n", tptSrvr->state);
	switch(tptSrvr->protocol)
		{
			case 1 : XOS_CliExtPrintf(pCliEnv,"protocol		:MGCP(1)\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv,"protocol		:MEGACO/H.248(2)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv,"protocol		:Invalid Protocol Type\r\n");break;
		}
//	XOS_CliExtPrintf(pCliEnv,"protocol		:%d\r\n", tptSrvr->protocol);
	switch(tptSrvr->encodingScheme)
		{
			case 0 : XOS_CliExtPrintf(pCliEnv,"encodingScheme		:LMG_ENCODE_NONE(0)\r\n");break;
			case 1 : XOS_CliExtPrintf(pCliEnv,"encodingScheme		:LMG_ENCODE_BIN(1)\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv,"encodingScheme		:LMG_ENCODE_TXT(2)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv,"encodingScheme		:Invalid encodingScheme\r\n");break;
		}
//	XOS_CliExtPrintf(pCliEnv,"encodingScheme		:%d\r\n", tptSrvr->encodingScheme);
	switch(tptSrvr->srvrType)
		{
			case 1 : XOS_CliExtPrintf(pCliEnv,"srvrType		:MG_MGCP_DEFLT_SRVR(1)\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv,"srvrType		:MG_MGCO_DEFLT_SRVR(2)\r\n");break;
			case 3 : XOS_CliExtPrintf(pCliEnv,"srvrType		:MG_ROUND_ROBIN_SRVR_MGCP(3)\r\n");break;
			case 4 : XOS_CliExtPrintf(pCliEnv,"srvrType		:MG_ROUND_ROBIN_SRVR_MGCO(4)\r\n");break;
			case 5 : XOS_CliExtPrintf(pCliEnv,"srvrType		:MG_TCP_CLIENT_CONNECTION(5)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv,"srvrType		:Invalid srvrType\r\n");break;	
		}
//	XOS_CliExtPrintf(pCliEnv,"srvrType		:%d\r\n", tptSrvr->srvrType);	
//	XOS_CliExtPrintf(pCliEnv,"tptAddr.u.ipv4TptAddr.address		:%x\r\n", tptSrvr->tptAddr.u.ipv4TptAddr.address);
	XOS_CliExtPrintf(pCliEnv,"tpt address    		:");
	X8ToIP(tptSrvr->tptAddr.u.ipv4TptAddr.address);	
	XOS_CliExtPrintf(pCliEnv,"tpt port	 	:%d\r\n", tptSrvr->tptAddr.u.ipv4TptAddr.port);

//	XOS_CliExtPrintf(pCliEnv,"cfgTptAddr.u.ipv4TptAddr.address	:%x\r\n", tptSrvr->cfgTptAddr.u.ipv4TptAddr.address);
//	XOS_CliExtPrintf(pCliEnv,"cfgTpt address 		:");
//	X8ToIP(tptSrvr->cfgTptAddr.u.ipv4TptAddr.address);
//	XOS_CliExtPrintf(pCliEnv,"cfgTptAddr port	 	:%d\r\n", tptSrvr->cfgTptAddr.u.ipv4TptAddr.port);

//*	mgcoPrintCmTptParam(pCliEnv, &(tptSrvr->tptParam));

//*	XOS_CliExtPrintf(pCliEnv,"[GCP]TptSrvr: u.peer/u.ssap(pointer:%d)\r\n", tptSrvr->t.peer);
//#ifndef POINTER_PRINT
//	XOS_CliExtPrintf(pCliEnv,"[GCP]TptSrvr: TSAP to which this srvr is linked(%x)\r\n", tptSrvr->tsap);
//#else    
//       mgcoPrintTSAPCb(pCliEnv, tptSrvr->tsap);
//#endif /* POINTER_PRINT */	
}

/*****************************************************************
	Print  Cm LList Cp
*/

PRIVATE VOID mgcoPrintCmLListCp(CLI_ENV *pCliEnv, CmLListCp *cmLListCp)
{
#ifndef POINTER_PRINT
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmLListCp: first (first entry in list) is:(%x)\r\n", cmLListCp->first);	
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmLListCp: last (last entry in list) is:(%x)\r\n", cmLListCp->last);
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmLListCp: crnt (entry last accessed) is:(%x)\r\n", cmLListCp->crnt);
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmLListCp: count (number of entries) is: (%d)\r\n", cmLListCp->count);
#else
       XOS_CliExtPrintf(pCliEnv,"[GCP]CmLListCp: ***********first (first entry in list) is: \r\n");
       mgcoPrintCmLList(pCliEnv, cmLListCp->first);
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmLListCp: ***********End of first \r\n");   
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmLListCp: ***********last (last entry in list) is: \r\n");
	mgcoPrintCmLList(pCliEnv, cmLListCp->last);
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmLListCp: ***********End of last \r\n"); 
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmLListCp: ***********crnt (entry last accessed) is: \r\n");
	mgcoPrintCmLList(pCliEnv, cmLListCp->crnt);
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmLListCp: ***********End of crnt \r\n"); 
	XOS_CliExtPrintf(pCliEnv,"[GCP]CmLListCp: count (number of entries) is: (%d)\r\n", cmLListCp->count);	
#endif
}

/*****************************************************************
	Print  Tpt Server Info
*/

PRIVATE VOID mgcoPrintTptSrvrInfo(CLI_ENV *pCliEnv, MgTptSrvrInfo *tptSrvrInfo)
{       
#ifdef GCP_MGCO
#ifdef GCP_MGC
	if(NULL != tptSrvrInfo->nxtSrvr2Use)
		{
		XOS_CliExtPrintf(pCliEnv, "-------------   member \"mgcoUDPSrvrLst\"  -------------\r\n");
      	 	mgcoPrintTptSrvr(pCliEnv, tptSrvrInfo->nxtSrvr2Use);
		}
//	else
//		XOS_CliExtPrintf(pCliEnv, "        this member is empty!!!  \r\n");	
#endif /* GCP_MGC */
#endif /* GCP_MGCO */	
}


/*****************************************************************
 * Print CmListEnt
 */
 
PRIVATE VOID mgcoPrintCmListEnt(CLI_ENV *pCliEnv, CmListEnt *cmListCp)
{
	XOS_CliExtPrintf(pCliEnv, "[GCP]CmListCp: next(Pointer:%x), prev(Pointer:%x)\r\n",
		cmListCp->next, cmListCp->prev);	
}

/*****************************************************************
 * Print hash list control point
 */
 
PRIVATE VOID mgcoPrintCmHashListCp(CLI_ENV *pCliEnv, CmHashListCp *cmHashListCp)
{
#ifndef POINTER_PRINT
       XOS_CliExtPrintf(pCliEnv, "[GCP]SSAPCb: hl(pointer to hash list bins) is: (%x)\r\n", cmHashListCp->hl);
#else
       XOS_CliExtPrintf(pCliEnv, "[GCP]SSAPCb: ***********hl(pointer to hash list bins) is:\r\n");
       mgcoPrintCmListEnt(pCliEnv, cmHashListCp->hl);
	XOS_CliExtPrintf(pCliEnv, "[GCP]SSAPCb: ***********End of hl \r\n");   
#endif /* POINTER_PRINT */	
	XOS_CliExtPrintf(pCliEnv, "[GCP]SSAPCb: region(%d), pool(%d)\r\n",
		cmHashListCp->region, cmHashListCp->pool);	
	XOS_CliExtPrintf(pCliEnv, "[GCP]SSAPCb: nmbBins(%d), binBitMask(%d)\r\n",
		cmHashListCp->nmbBins, cmHashListCp->binBitMask);
	XOS_CliExtPrintf(pCliEnv, "[GCP]SSAPCb: nmbBinBits(%d), nmbEnt(%d)\r\n",
		cmHashListCp->nmbBinBits, cmHashListCp->nmbEnt);
	XOS_CliExtPrintf(pCliEnv, "[GCP]SSAPCb: offset(%d), dupFlg(%d)\r\n",
		cmHashListCp->offset, cmHashListCp->dupFlg);
	XOS_CliExtPrintf(pCliEnv, "[GCP]SSAPCb: keyType(%d)\r\n",
		cmHashListCp->keyType);
}

/*****************************************************************
 * Print CmHashListEnt
 */
 
PRIVATE VOID mgcoPrintCmHashListEnt(CLI_ENV *pCliEnv, CmHashListEnt *cmHashListEnt)
{
	XOS_CliExtPrintf(pCliEnv, "[GCP]CmHashListEnt: list.next(poiter:%x)\r\n", cmHashListEnt->list.next);
	XOS_CliExtPrintf(pCliEnv, "[GCP]CmHashListEnt: list.prev(poiter:%x)\r\n", cmHashListEnt->list.prev);
	XOS_CliExtPrintf(pCliEnv, "[GCP]SSAPCb: key(%d)\r\n", *(cmHashListEnt->key));	
	XOS_CliExtPrintf(pCliEnv, "[GCP]SSAPCb: keyLen(%d)\r\n", cmHashListEnt->keyLen);
	XOS_CliExtPrintf(pCliEnv, "[GCP]SSAPCb: hashVal(%d)\r\n", cmHashListEnt->hashVal);
}

/*****************************************************************
 * Print CmLList
 */
 
PRIVATE VOID mgcoPrintCmLList(CLI_ENV *pCliEnv, CmLList *cmLList)
{
	XOS_CliExtPrintf(pCliEnv, "[GCP]CmLList: next(poiter:%x)\r\n", cmLList->next);
	XOS_CliExtPrintf(pCliEnv, "[GCP]CmLList: prev(poiter:%x)\r\n", cmLList->prev);
	XOS_CliExtPrintf(pCliEnv, "[GCP]CmLList: node(%d)\r\n", cmLList->node);
}

/*****************************************************************
 * Print Mg Net Addr Tbl
 */
 
PRIVATE VOID mgcoPrintNetAddrTbl(CLI_ENV *pCliEnv, MgNetAddrTbl *peerAddrTbl)
{
       int i;
       XOS_CliExtPrintf(pCliEnv, "peerAddrTbl.count	:%d\r\n", peerAddrTbl->count);
	for(i=0;i<peerAddrTbl->count;i++)
	{	
//		mgcoPrintCmNetAddr(pCliEnv, &(peerAddrTbl->netAddr[i]));
//		XOS_CliExtPrintf(pCliEnv,"peerAddrTbl->netAddr[i].u.ipv4NetAddr	:%x\r\n", peerAddrTbl->netAddr[i].u.ipv4NetAddr);	
		XOS_CliExtPrintf(pCliEnv,"peerAddrTbl ipAddr 	:");
		X8ToIP(peerAddrTbl->netAddr[i].u.ipv4NetAddr);
	}
}

/*****************************************************************
 * Print Mgco Mid Str
 */
 
PRIVATE VOID mgcoPrintMidStr(CLI_ENV *pCliEnv, MgMgcoMidStr *midStr)
{  
	XOS_CliExtPrintf(pCliEnv, "[GCP]MidStr: val(%s)\r\n", midStr->val);	
}

/*****************************************************************
 * Print Mg Peer Access
 */
 
PRIVATE VOID mgcoPrintPeerAccess(CLI_ENV *pCliEnv, MgPeerAccess *mgPeerAccess)
{
	if(0 == mgPeerAccess->namePres)
     		XOS_CliExtPrintf(pCliEnv, "namePres		:%d(no name exist)\r\n", mgPeerAccess->namePres);
	else	
		XOS_CliExtPrintf(pCliEnv, "name			:%s\r\n", mgPeerAccess->name);
#ifdef GCP_USE_PEERID
     	XOS_CliExtPrintf(pCliEnv, "peerId			:%d\r\n", mgPeerAccess->peerId);
#endif /* GCP_USE_PEERID */
	XOS_CliExtPrintf(pCliEnv, "remotePort		:%d\r\n", mgPeerAccess->remotePort);
	switch(mgPeerAccess->transportType)
		{
			case 0 : XOS_CliExtPrintf(pCliEnv,"transportType		:LMG_TPT_NONE(0)\r\n");break;
			case 1 : XOS_CliExtPrintf(pCliEnv,"transportType		:LMG_TPT_UDP(1)\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv,"transportType		:LMG_TPT_TCP(2)\r\n");break;
			case 3 : XOS_CliExtPrintf(pCliEnv,"transportType		:LMG_TPT_SCTP(3)\r\n");break;
			case 4 : XOS_CliExtPrintf(pCliEnv,"transportType		:LMG_TPT_MTP3(4)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv,"transportType		:Invalid transportType\r\n");break;
		}
//  	XOS_CliExtPrintf(pCliEnv, "transportType		:%d\r\n", mgPeerAccess->transportType);
	switch(mgPeerAccess->peerflg)
		{
			case 0x01 : XOS_CliExtPrintf(pCliEnv, "peerflg			:MG_ASSOC_SUCC(0x01)\r\n");break;
			case 0x02 : XOS_CliExtPrintf(pCliEnv, "peerflg			:MG_HANDOFF_RQSTD(0x02)\r\n");break;
			case 0x04 : XOS_CliExtPrintf(pCliEnv, "peerflg			:MG_REDIRECTED_BY_MGC(0x04)\r\n");break;
			case 0x08 : XOS_CliExtPrintf(pCliEnv, "peerflg			:MG_USER_INITIATED_REG(0x08)\r\n");break;
			case 0x10 : XOS_CliExtPrintf(pCliEnv, "peerflg			:MG_HANDOFF_RQSTD_NO_MGCID(0x10)\r\n");break;
			case 0x20 : XOS_CliExtPrintf(pCliEnv, "peerflg			:MG_DISCONNECTED_TO_MGC(0x20)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv, "peerflg			:%d........Invalid peerflg\r\n",mgPeerAccess->peerflg);break;
		}
//	XOS_CliExtPrintf(pCliEnv, "peerflg			:%d\r\n", mgPeerAccess->peerflg);   
#ifdef GCP_MGCO
//   mgcoPrintMidStr(pCliEnv, &(mgPeerAccess->mid)); 
	XOS_CliExtPrintf(pCliEnv, "mid.val			:%s\r\n", mgPeerAccess->mid.val); 
	mgcoPrintNetAddrTbl(pCliEnv, &(mgPeerAccess->peerAddrTbl));
#endif
}

/*****************************************************************
 * Print Information Required for peer maintenance
 */
 
PRIVATE VOID mgcoPrintPeerMntInfo(CLI_ENV *pCliEnv, MgPeerMntInfo *peerMntInfo)
{
       int i;
       XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: protocolType(%d)\r\n", peerMntInfo->protocolType);
       XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: byCfg(%d)\r\n", peerMntInfo->byCfg);   
	XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: usrKnows(%d)\r\n", peerMntInfo->usrKnows);
	XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: rtoCap(%d)\r\n", peerMntInfo->rtoCap);
	XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: rto(%d)\r\n", peerMntInfo->rto);
	XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: aad(%d)\r\n", peerMntInfo->aad);
	XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: adev(%d)\r\n", peerMntInfo->adev);
	XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: variant(%d)\r\n", peerMntInfo->variant);
	XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: mtuSize(%d)\r\n", peerMntInfo->mtuSize);
	XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: trcLen(%d)\r\n", peerMntInfo->trcLen);
	XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: resOrder(%d)\r\n", peerMntInfo->resOrder);
	for(i=0;i<MG_MAXPEER_TMR;i++)
	{	
	       if(&(peerMntInfo->tmr[i])==NULLP)
	       	{
		             RETVOID;
	       	}
		
	}
}

/*****************************************************************
 * Print MgTxnAck
 */
 
PRIVATE VOID mgcoPrintTxnAck(CLI_ENV *pCliEnv, MgTxnAck *txnAck)
{
       XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: trId(%d)\r\n", txnAck->trId);
	XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: peer(pointer:%x)\r\n", txnAck->peer);   	
}

/*****************************************************************
 * Print MgTxnAckList
 */
 
PRIVATE VOID mgcoPrintTxnAckList(CLI_ENV *pCliEnv, MgTxnAckList *txnAckList)
{
       XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: ***********info(node information) is:\r\n"); 
       mgcoPrintTxnAck(pCliEnv, &(txnAckList->info));	
	XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: ***********End of info \r\n"); 
#ifndef POINTER_PRINT
	XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: next(next node in the list) is (%x)\r\n", txnAckList->next);
#else
       XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: ***********next(next node in the list ) is:\r\n");
       mgcoPrintTxnAckList(pCliEnv, txnAckList->next);
       XOS_CliExtPrintf(pCliEnv, "[GCP]PeerMntInfo: ***********End of next \r\n");	
#endif /* POINTER_PRINT  */
}

/*****************************************************************
 * Print MgMgcoPeerInfo
 */

PRIVATE VOID mgcoPrintMgcoPeerInfo(CLI_ENV *pCliEnv, MgMgcoPeerInfo *mgcoPeerInfo)
{
#ifdef GCP_MG
     	XOS_CliExtPrintf(pCliEnv, "dupPeerPrsnt		:%d\r\n", mgcoPeerInfo->dupPeerPrsnt);
	switch(mgcoPeerInfo->mgcPriority)
		{
			case 1 : XOS_CliExtPrintf(pCliEnv, "mgcPriority		:1........Primary MGC\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv, "mgcPriority		:2........Standby MGC\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv, "mgcPriority		:Invalid mgcPriority\r\n");break;
		}
//   	XOS_CliExtPrintf(pCliEnv, "mgcPriority		:%d\r\n", mgcoPeerInfo->mgcPriority);
	XOS_CliExtPrintf(pCliEnv, "cfgPort			:%d\r\n", mgcoPeerInfo->cfgPort);	
#ifdef    GCP_PROV_SCTP
     	XOS_CliExtPrintf(pCliEnv, "tos			:%d\r\n", mgcoPeerInfo->tos);
#endif /* GCP_PROV_SCTP */
#endif /* GCP_MG */
	switch(mgcoPeerInfo->encodingScheme)
		{
			case 0 : XOS_CliExtPrintf(pCliEnv,"encodingScheme		:LMG_ENCODE_NONE(0)\r\n");break;
			case 1 : XOS_CliExtPrintf(pCliEnv,"encodingScheme		:LMG_ENCODE_BIN(1)\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv,"encodingScheme		:LMG_ENCODE_TXT(2)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv,"encodingScheme		:Invalid encodingScheme\r\n");break;
		}
//     	XOS_CliExtPrintf(pCliEnv, "encodingScheme		:%d\r\n", mgcoPeerInfo->encodingScheme);
	switch(mgcoPeerInfo->negotiatedVersion)
		{
			case 1 : XOS_CliExtPrintf(pCliEnv, "negotiatedVersion	:MG_MGCOVER_1_0(1)\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv, "negotiatedVersion	:MG_MGCOVER_2_0(2)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv, "negotiatedVersion	:Invalid negotiatedVersion\r\n");break;
		}
//     	XOS_CliExtPrintf(pCliEnv, "negotiatedVersion	:%d\r\n", mgcoPeerInfo->negotiatedVersion);
	switch(mgcoPeerInfo->useAHScheme)
		{
			case 0 : XOS_CliExtPrintf(pCliEnv, "useAHScheme		:FALSE\r\n");break;
			case 1 : XOS_CliExtPrintf(pCliEnv, "useAHScheme		:TRUE\r\n");break;
			default :	break;
		}
//	XOS_CliExtPrintf(pCliEnv, "useAHScheme		:%d\r\n", mgcoPeerInfo->useAHScheme);
	XOS_CliExtPrintf(pCliEnv, "numActvConn		:%d\r\n", mgcoPeerInfo->numActvConn);
#ifdef GCP_MGC
    	XOS_CliExtPrintf(pCliEnv, "origSrvcChngPort	:%d\r\n", mgcoPeerInfo->origSrvcChngPort);
     	XOS_CliExtPrintf(pCliEnv, "lclSrvcChngPort		:%d\r\n", mgcoPeerInfo->lclSrvcChngPort);
	XOS_CliExtPrintf(pCliEnv, "hndOffInProg		:%d\r\n", mgcoPeerInfo->hndOffInProg);   
#endif /* GCP_MGC */
	switch(mgcoPeerInfo->peerType)
		{
			case 0 : XOS_CliExtPrintf(pCliEnv, "peerType		:MG_NONE(0)\r\n");break;
			case 1 : XOS_CliExtPrintf(pCliEnv, "peerType		:MG_ACTIVE(1)\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv, "peerType		:MG_STANDBY(2)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv, "peerType		:Invalid mgType\r\n");break;
		}
//	XOS_CliExtPrintf(pCliEnv, "peerType		:%d\r\n", mgcoPeerInfo->peerType);
	if(NULL != mgcoPeerInfo->nxtUseConn)
		{
			XOS_CliExtPrintf(pCliEnv, "----------------   member \"nxtUseConn\"  ---------------\r\n");
     			mgcoPrintTptSrvr(pCliEnv, mgcoPeerInfo->nxtUseConn);
		}       
}

/*****************************************************************
 * Print MgPeerSts
 */
 
PRIVATE VOID mgcoPrintPeerSts(CLI_ENV *pCliEnv, MgPeerSts *peerSts)
{
	XOS_CliExtPrintf(pCliEnv, "sSAPId			:%d\r\n", peerSts->sSAPId);
	XOS_CliExtPrintf(pCliEnv, "numMsgTx		:%d\r\n", peerSts->numMsgTx);
	XOS_CliExtPrintf(pCliEnv, "numMsgRx		:%d\r\n", peerSts->numMsgRx);
	XOS_CliExtPrintf(pCliEnv, "numRespTx		:%d\r\n", peerSts->numRespTx);	
	XOS_CliExtPrintf(pCliEnv, "numRespRx		:%d\r\n", peerSts->numRespRx);
	XOS_CliExtPrintf(pCliEnv, "numRespFailedRx		:%d\r\n", peerSts->numRespFailedRx);
	XOS_CliExtPrintf(pCliEnv, "numErrors		:%d\r\n", peerSts->numErrors);
	XOS_CliExtPrintf(pCliEnv, "numReTx			:%d\r\n", peerSts->numReTx);
	XOS_CliExtPrintf(pCliEnv, "numReRx			:%d\r\n", peerSts->numReRx);
#if (defined(GCP_MGCP) || defined(TDS_ROLL_UPGRADE_SUPPORT))
	XOS_CliExtPrintf(pCliEnv, "numNonStdTx	:%d\r\n", peerSts->numNonStdTx);
	XOS_CliExtPrintf(pCliEnv, "numNonStdRx	:%d\r\n", peerSts->numNonStdRx);
	XOS_CliExtPrintf(pCliEnv, "numEpcfTx		:%d\r\n", peerSts->numEpcfTx);
	XOS_CliExtPrintf(pCliEnv, "numCreateTx	:%d\r\n", peerSts->numCreateTx);
	XOS_CliExtPrintf(pCliEnv, "numModifyTx	:%d\r\n", peerSts->numModifyTx);	
	XOS_CliExtPrintf(pCliEnv, "numDeleteTx	:%d\r\n", peerSts->numDeleteTx);
	XOS_CliExtPrintf(pCliEnv, "numRqntTx		:%d\r\n", peerSts->numRqntTx);   
	XOS_CliExtPrintf(pCliEnv, "numNotifyTx	:%d\r\n", peerSts->numNotifyTx);
	XOS_CliExtPrintf(pCliEnv, "numAuditEndPtTx	:%d\r\n", peerSts->numAuditEndPtTx);
	XOS_CliExtPrintf(pCliEnv, "numAuditConnTx	:%d\r\n", peerSts->numAuditConnTx);
	XOS_CliExtPrintf(pCliEnv, "numRsipTx		:%d\r\n", peerSts->numRsipTx);
	XOS_CliExtPrintf(pCliEnv, "numEpcfRx		:%d\r\n", peerSts->numEpcfRx);
	XOS_CliExtPrintf(pCliEnv, "numCreateRx	:%d\r\n", peerSts->numCreateRx);
	XOS_CliExtPrintf(pCliEnv, "numModifyRx	:%d\r\n", peerSts->numModifyRx);
	XOS_CliExtPrintf(pCliEnv, "numDeleteRx	:%d\r\n", peerSts->numDeleteRx);
	XOS_CliExtPrintf(pCliEnv, "numRqntRx		:%d\r\n", peerSts->numRqntRx);
	XOS_CliExtPrintf(pCliEnv, "numNotifyRx	:%d\r\n", peerSts->numNotifyRx);
	XOS_CliExtPrintf(pCliEnv, "numAuditEndPtRx	:%d\r\n", peerSts->numAuditEndPtRx);
	XOS_CliExtPrintf(pCliEnv, "numAuditConnRx	:%d\r\n", peerSts->numAuditConnRx);
	XOS_CliExtPrintf(pCliEnv, "numRsipRx		:%d\r\n", peerSts->numRsipRx);
#endif /* GCP_MGCP || TDS_ROLL_UPGRADE_SUPPORT */
#if (defined(GCP_MGCO) || defined(TDS_ROLL_UPGRADE_SUPPORT)) 
	/* Transmit Related Statistics */
	XOS_CliExtPrintf(pCliEnv, "numTransTx		:%d\r\n", peerSts->numTransTx);   
	XOS_CliExtPrintf(pCliEnv, "numServiceChgTx		:%d\r\n", peerSts->numServiceChgTx);
	XOS_CliExtPrintf(pCliEnv, "numRespAckTx		:%d\r\n", peerSts->numRespAckTx);
	XOS_CliExtPrintf(pCliEnv, "numTransPendTx		:%d\r\n", peerSts->numTransPendTx);
	/* Transmit Related Statistics */
	XOS_CliExtPrintf(pCliEnv, "numTransRx		:%d\r\n", peerSts->numTransRx);
	XOS_CliExtPrintf(pCliEnv, "numServiceChgRx		:%d\r\n", peerSts->numServiceChgRx);
	XOS_CliExtPrintf(pCliEnv, "numRespAckRx		:%d\r\n", peerSts->numRespAckRx);
	XOS_CliExtPrintf(pCliEnv, "numTransPendRx		:%d\r\n", peerSts->numTransPendRx);	 
	/* lmg_x_005.main_1: Added error code counter */
	XOS_CliExtPrintf(pCliEnv, "numErrorsMgcoBadReq	:%d\r\n", peerSts->numErrorsMgcoBadReq);
	XOS_CliExtPrintf(pCliEnv, "numErrorsMgcoProtErr	:%d\r\n", peerSts->numErrorsMgcoProtErr);   
	XOS_CliExtPrintf(pCliEnv, "numErrorsMgcoVerUnSupp	:%d\r\n", peerSts->numErrorsMgcoVerUnSupp);
	XOS_CliExtPrintf(pCliEnv, "numErrorsMgcoNotReady	:%d\r\n", peerSts->numErrorsMgcoNotReady);
	
#if (defined(MGT_UNKNOWN_PKG_REJ) && defined(GCP_ASN)) 
	XOS_CliExtPrintf(pCliEnv, "numErrorsMgcoPkgUnsupp	:%d\r\n", peerSts->numErrorsMgcoPkgUnsupp);
#endif /* MGT_UNKNOWN_PKG_REJ && GCP_ASN */
#if (defined (GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))                                           
	XOS_CliExtPrintf(pCliEnv, "numErrorsMgcoTxnPendEx	:%d\r\n", peerSts->numErrorsMgcoTxnPendEx);
#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */
	XOS_CliExtPrintf(pCliEnv, "numErrorsMgcoRsrcErr	:%d\r\n", peerSts->numErrorsMgcoRsrcErr);
	XOS_CliExtPrintf(pCliEnv, "numErrorsMgcoPduSize	:%d\r\n", peerSts->numErrorsMgcoPduSize);
	XOS_CliExtPrintf(pCliEnv, "numErrorsMgcoReqRvBefReg:%d\r\n", peerSts->numErrorsMgcoReqRcvdBefReg);
#endif /* GCP_MGCO || TDS_ROLL_UPGRADE_SUPPORT */ 
}

/*****************************************************************
 * Print MgPeerLstSts
 */
 
VOID mgcoPrintPeerLstSts(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	MgPeerSts *peerSts = NULL;
	int idx;
	for(idx=0;idx<mgCb.genCfg.maxPeer;idx++)
		{
			if((NULL == mgCb.peerLst[idx])||(NULL == mgCb.peerLst[idx]->peer))
				continue;
			peerSts = &(mgCb.peerLst[idx]->peer->peerSts);
			XOS_CliExtPrintf(pCliEnv, "---------------   Print PeerSts (id=%d)   ---------------\r\n",idx);
			mgcoPrintPeerSts(pCliEnv, peerSts);
		}
}



/*****************************************************************
 * Print mgRvUpdQNode
 */
 
PRIVATE VOID mgcoPrintRvUpdQNode(CLI_ENV *pCliEnv, MgRvUpdQNode *rvUpdQNode)
{
       XOS_CliExtPrintf(pCliEnv, "[GCP]RvUpdQNode: qType(%d)\r\n", rvUpdQNode->qType);
	XOS_CliExtPrintf(pCliEnv, "[GCP]RvUpdQNode: prot(%d)\r\n", rvUpdQNode->prot);	
	XOS_CliExtPrintf(pCliEnv, "[GCP]RvUpdQNode: rvSeqNum(%d)\r\n", rvUpdQNode->rvSeqNum);
	XOS_CliExtPrintf(pCliEnv, "[GCP]RvUpdQNode: peerId(%d)\r\n", rvUpdQNode->peerId);
	XOS_CliExtPrintf(pCliEnv, "[GCP]RvUpdQNode: info(%s)\r\n", rvUpdQNode->info);	
	if(rvUpdQNode->next!=NULLP)
	      XOS_CliExtPrintf(pCliEnv, "[GCP]RvUpdQNode: next(next node pointer is:%x)\r\n", rvUpdQNode->next);
       else
	      XOS_CliExtPrintf(pCliEnv, "[GCP]RvUpdQNode: this node is the last node!\r\n");
	if(rvUpdQNode->prev!=NULLP)
	      XOS_CliExtPrintf(pCliEnv, "[GCP]RvUpdQNode: prev(prev node pointer is:%x)\r\n", rvUpdQNode->prev);
	else
	      XOS_CliExtPrintf(pCliEnv, "[GCP]RvUpdQNode: this node is the first node!\r\n");
}

/*****************************************************************
 * Print mgMgcoPendingLimit
 
 
PRIVATE VOID mgcoPrintPengingLimit(CLI_ENV *pCliEnv, MgMgcoPendingLimit *pendingLimit)
{
        if(pendingLimit->pres.pres!=0)
	{
	       XOS_CliExtPrintf(pCliEnv, "[GCP]MgMGcoPendingLimit: mgOriginatedPendingLimit(%d)\r\n", 
	   	      pendingLimit->mgOriginatedPendingLimit);
		XOS_CliExtPrintf(pCliEnv, "[GCP]MgMGcoPendingLimit: mgcOriginatedPendingLimit(%d)\r\n", 
	   	      pendingLimit->mgcOriginatedPendingLimit);
        }
}
*/

/*****************************************************************
 * Print mgMgcoProvRspTmrVal
 
 
PRIVATE VOID mgcoPrintProvRspTmrVal(CLI_ENV *pCliEnv, MgMgcoProvRspTmrVal *provRspTmrVal)
{
        XOS_CliExtPrintf(pCliEnv, "[GCP]MgMgcoProvRspTmrVal: pres.pres(%d), pres.val(%d)\r\n", 
	   	provRspTmrVal->pres.pres, provRspTmrVal->pres.val);
        if(provRspTmrVal->pres.pres!=0)
	       {
	              XOS_CliExtPrintf(pCliEnv, "[GCP]MgMGcoPendingLimit: mgProvRespTmrVal(%d)\r\n", 
	   	             provRspTmrVal->mgProvRespTmrVal);
		       XOS_CliExtPrintf(pCliEnv, "[GCP]MgMGcoPendingLimit: mgcProvRspTmrVal(%d)\r\n", 
	   	             provRspTmrVal->mgcProvRspTmrVal);
              }
	else
		{
		      XOS_CliExtPrintf(pCliEnv, "[GCP]MgMGcoPendingLimit: mgProvRspTmrVal and mgcProvRspTmrVal are not present!\r\n");
		}
}	
*/

/*****************************************************************
 * Print Peer Cb
 */
PRIVATE VOID mgcoPrintPeerCb(CLI_ENV *pCliEnv, MgPeerCb *peerCb)
{
	switch(peerCb->state)
		{	
			case 0 : XOS_CliExtPrintf(pCliEnv, "state			:LMG_PEER_STATE_NULL(0)\r\n");break;
			case 1 : XOS_CliExtPrintf(pCliEnv, "state			:LMG_PEER_STATE_RESOLVING(1)\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv, "state			:LMG_PEER_STATE_AWAIT_REG(2)\r\n");break;
			case 3 : XOS_CliExtPrintf(pCliEnv, "state			:LMG_PEER_STATE_CONNECT(3)\r\n");break;
			case 4 : XOS_CliExtPrintf(pCliEnv, "state			:LMG_PEER_STATE_REGISTER(4)\r\n");break;
			case 5 : XOS_CliExtPrintf(pCliEnv, "state			:LMG_PEER_STATE_ACTIVE(5)\r\n");break;
			case 6 : XOS_CliExtPrintf(pCliEnv, "state			:LMG_PEER_STATE_DISCONNECTED(6)\r\n");break;
			case 7 : XOS_CliExtPrintf(pCliEnv, "state			:LMG_PEER_STATE_UNDR_HNDOFF(7)\r\n");break;
			case 8 : XOS_CliExtPrintf(pCliEnv, "state			:LMG_PEER_STATE_FAILOVER(8)\r\n");break;
			default : break;
		}
//	XOS_CliExtPrintf(pCliEnv, "state			:%d\r\n", peerCb->state);	
//#ifdef GCP_MG
//      XOS_CliExtPrintf(pCliEnv, "regReqTxnId		:%d\r\n", peerCb->regReqTxnId); 
//#endif /* GCP_MG */
#ifdef CM_DNS_LIB
     	XOS_CliExtPrintf(pCliEnv, "dnsRetxCnt	:%d\r\n", peerCb->dnsRetxCnt);
     	XOS_CliExtPrintf(pCliEnv, "dnsReqId		:%d\r\n", peerCb->dnsReqId);
	XOS_CliExtPrintf(pCliEnv, "hashVal		:%d\r\n", peerCb->hashVal);   
	XOS_CliExtPrintf(pCliEnv, "dnsReq(Pointer:%d)\r\n", peerCb->dnsReq);
#endif /* CM_DNS_LIB */   
#ifdef ZG
#ifdef ZG_DFTHA
     	mgcoPrintRvUpdQNode(pCliEnv, &(peerCb->peerTxnQ));
     	mgcoPrintRvUpdQNode(pCliEnv, &(peerCb->usrTxnQ));    
#endif /* ZG_DFTHA */
	XOS_CliExtPrintf(pCliEnv, "removeAllTxns:%d\r\n", peerCb->removeAllTxns);
     	XOS_CliExtPrintf(pCliEnv, "bringToCfg:%d\r\n", peerCb->bringToCfg);
	XOS_CliExtPrintf(pCliEnv, "delPeerTmr:%d\r\n", peerCb->delPeerTmr);   
#endif /* ZG */

#if (defined(GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))
       /*mgcoPrintPengingLimit(pCliEnv, &(peerCb->limit));*/         
#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */
	XOS_CliExtPrintf(pCliEnv, "---------------   member \"accessInfo\"  ----------------\r\n");
	mgcoPrintPeerAccess(pCliEnv, &(peerCb->accessInfo)); 
#ifdef GCP_MGCO
	XOS_CliExtPrintf(pCliEnv, "----------------   member \"mgcoInfo\"  -----------------\r\n");
     	mgcoPrintMgcoPeerInfo(pCliEnv, &(peerCb->mgcoInfo));
//	XOS_CliExtPrintf(pCliEnv, "-------------------   member \"ssap\"  ------------------\r\n");
//	XOS_CliExtPrintf(pCliEnv, "   Input command \"ssaplst\" to display ssap info	\r\n");
//	mgcoPrintSSAPCb(pCliEnv, peerCb->ssap); 
#endif /* GCP_MGCO */
}

/*****************************************************************
 * Print Tmr Cfg
 */
 
PRIVATE VOID mgcoPrintTmrCfg(CLI_ENV *pCliEnv, TmrCfg *tmrCfg)
{
	XOS_CliExtPrintf(pCliEnv, "enb:(%d)\r\n", tmrCfg->enb);
	XOS_CliExtPrintf(pCliEnv, "val:(%d)\r\n", tmrCfg->val);
}

/*****************************************************************
 * Print MgDnsCfg
 */
 
PRIVATE VOID mgcoPrintDnsCfg(CLI_ENV *pCliEnv, MgDnsCfg *dnsCfg)
{
	XOS_CliExtPrintf(pCliEnv, "tsapCfg.reCfg.dnsCfg.dnsAccess	:%d\r\n", dnsCfg->dnsAccess);
      	XOS_CliExtPrintf(pCliEnv, "tsapCfg.reCfg.dnsCfg.dnsAddr.u.ipv4TptAddr.port		:%d\r\n",dnsCfg->dnsAddr.u.ipv4TptAddr.port); 
	XOS_CliExtPrintf(pCliEnv, "tsapCfg.reCfg.dnsCfg.dnsAddr.u.ipv4TptAddr.address	:%x\r\n",dnsCfg->dnsAddr.u.ipv4TptAddr.address); 	
	XOS_CliExtPrintf(pCliEnv, "tsapCfg.reCfg.dnsCfg.dnsRslvTmr.enb	:%d\r\n",dnsCfg->dnsRslvTmr.enb); 
	XOS_CliExtPrintf(pCliEnv, "tsapCfg.reCfg.dnsCfg.dnsRslvTmr.val	:%d\r\n",dnsCfg->dnsRslvTmr.val);
	XOS_CliExtPrintf(pCliEnv, "tsapCfg.reCfg.dnsCfg.maxRetxCnt		:%d\r\n", dnsCfg->maxRetxCnt);	
}

/*****************************************************************
 * Print TSAPReCfg
 */
 
PRIVATE VOID mgcoPrintTSAPReCfg(CLI_ENV *pCliEnv, MgTSAPReCfg *tsapReCfg)
{ 
//*	mgcoPrintDnsCfg(pCliEnv, &(tsapReCfg->dnsCfg));
	XOS_CliExtPrintf(pCliEnv, "reCfg.tMax		:%d\r\n", tsapReCfg->tMax);
//*	mgcoPrintCmTptParam(pCliEnv, &(tsapReCfg->tptParam));
#if (defined(GCP_MGCO) || defined(TDS_ROLL_UPGRADE_SUPPORT)) 
	if(0 == tsapReCfg->idleTmr.enb)
      		XOS_CliExtPrintf(pCliEnv, "reCfg.idleTmr.enb	:%d\r\n", tsapReCfg->idleTmr.enb);
	else
		XOS_CliExtPrintf(pCliEnv, "reCfg.idleTmr.val	:%d\r\n", tsapReCfg->idleTmr.val);
#endif /* GCP_MGCO || TDS_ROLL_UPGRADE_SUPPORT */	
#ifdef ZG
     	XOS_CliExtPrintf(pCliEnv, "reCfg.changeOver:%d\r\n", &(tsapReCfg->changeOver));
	mgcoPrintPostInfo(pCliEnv, &(tsapReCfg->dstPst));
	XOS_CliExtPrintf(pCliEnv, "reCfg.spId		:%d\r\n", &(tsapReCfg->spId));
#endif /* ZG */ 

}


/*****************************************************************
 * Print TSAP Cfg
 */
 
PRIVATE VOID mgcoPrintTSAPCfg(CLI_ENV *pCliEnv, MgTSAPCfg *tsapCfg)
{
	XOS_CliExtPrintf(pCliEnv, "tSAPId			:%d\r\n", tsapCfg->tSAPId);
	XOS_CliExtPrintf(pCliEnv, "nmbDlgs			:%d\r\n", tsapCfg->spId);
	switch(tsapCfg->provType)
		{
			case 1 : XOS_CliExtPrintf(pCliEnv, "provType		:LMG_PROV_TYPE_TUCL\r\n");break;
			case 2 : XOS_CliExtPrintf(pCliEnv, "provType		:LMG_PROV_TYPE_SCTP\r\n");break;
			case 3 : XOS_CliExtPrintf(pCliEnv, "provType		:LMG_PROV_TYPE_MTP3\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv, "provType		:Invalid provType\r\n");break;
		}
//	XOS_CliExtPrintf(pCliEnv, "provType		:%d\r\n", tsapCfg->provType);
	XOS_CliExtPrintf(pCliEnv, "dstProcId		:%d\r\n",	tsapCfg->dstProcId);
//	XOS_CliExtPrintf(pCliEnv, "memId.region		:%d\r\n", tsapCfg->memId.region);
//	XOS_CliExtPrintf(pCliEnv, "memId.pool		:%d\r\n", tsapCfg->memId.pool);
	switch(tsapCfg->dstEnt)
		{	
			case 0x75 : XOS_CliExtPrintf(pCliEnv, "dstEnt			:ENTHI(0x75)\r\n");break;
			case 0x32 : XOS_CliExtPrintf(pCliEnv, "dstEnt			:ENTMU(0x32)\r\n");break;
			case 0x7e : XOS_CliExtPrintf(pCliEnv, "dstEnt			:ENTMG(0x7E)\r\n");break;
			case 0xe : XOS_CliExtPrintf(pCliEnv, "dstEnt			:ENTSM(0xE)\r\n");break;
			case 0xff : XOS_CliExtPrintf(pCliEnv, "dstEnt			:ENTNC(0xFF)\r\n");break;
			default : XOS_CliExtPrintf(pCliEnv, "dstEnt			:0x%x\r\n", tsapCfg->dstEnt);break;
		}
//	XOS_CliExtPrintf(pCliEnv, "dstEnt			:0x%x\r\n", tsapCfg->dstEnt);
	XOS_CliExtPrintf(pCliEnv, "dstInst			:%d\r\n", tsapCfg->dstInst);
//	XOS_CliExtPrintf(pCliEnv, "dstPrior		:%d\r\n", tsapCfg->dstPrior);
//	XOS_CliExtPrintf(pCliEnv, "dstRoute		:%d\r\n", tsapCfg->dstRoute);
	XOS_CliExtPrintf(pCliEnv, "dstSel			:%d\r\n", tsapCfg->dstSel);
	if(0 == tsapCfg->bndTmrCfg.enb)
      		XOS_CliExtPrintf(pCliEnv, "bndTmrCfg.enb		:%d\r\n",tsapCfg->bndTmrCfg.enb);
	else
		XOS_CliExtPrintf(pCliEnv, "bndTmrCfg.val		:%d(Unit:100ms)\r\n",tsapCfg->bndTmrCfg.val);
	mgcoPrintTSAPReCfg(pCliEnv, &(tsapCfg->reCfg));
#ifdef TDS_ROLL_UPGRADE_SUPPORT
       XOS_CliExtPrintf(pCliEnv, "remIntfValid	:%d\r\n", tsapCfg->remIntfValid);
       XOS_CliExtPrintf(pCliEnv, "remIntfVer		:%d\r\n", tsapCfg->remIntfVer);
#endif	
		
}

/*****************************************************************
 * Print List of Listeners
 */
 
PRIVATE VOID mgcoPrintLstnrLst(CLI_ENV *pCliEnv, MgLstnrLst *lstnrLst)
{
	XOS_CliExtPrintf(pCliEnv, "[GCP]LstnrLst: index(%d)\r\n", lstnrLst->index);
       XOS_CliExtPrintf(pCliEnv, "[GCP]LstnrLst: **********lstnrCb is:\r\n");
	mgcoPrintTptSrvr(pCliEnv, lstnrLst->lstnrCb);
	XOS_CliExtPrintf(pCliEnv, "[GCP]LstnrLst: **********End of lstnrCb \r\n");
}

/*****************************************************************
 * Print MgDnsSts
 */
 
PRIVATE VOID mgcoPrintDnsSts(CLI_ENV *pCliEnv, MgDnsSts *dnsSts)
{
	XOS_CliExtPrintf(pCliEnv, "dnsSts.numAQueryTx	:%d\r\n", dnsSts->numAQueryTx);
	XOS_CliExtPrintf(pCliEnv, "dnsSts.numAQueryFailed	:%d\r\n", dnsSts->numAQueryFailed);
}

/*****************************************************************
 * Print MgTSAPSts
 */
 
PRIVATE VOID mgcoPrintTSAPSts(CLI_ENV *pCliEnv, MgTSAPSts *tsapSts)
{
	XOS_CliExtPrintf(pCliEnv, "tSapId			:%d\r\n", tsapSts->tSapId);
	mgcoPrintDnsSts(pCliEnv, &(tsapSts->dnsSts));
}

/*****************************************************************
 * Print DNS Information
 */
 
PRIVATE VOID mgcoPrintDnsInfo(CLI_ENV *pCliEnv, MgDnsInfo *dnsInfo)
{
	XOS_CliExtPrintf(pCliEnv, "dnsInfo.dnsState	:%d\r\n", dnsInfo->dnsState);
#ifndef POINTER_PRINT
       XOS_CliExtPrintf(pCliEnv, "dnsInfo.dnsLstnr	:%x\r\n", dnsInfo->dnsLstnr);
#else
       XOS_CliExtPrintf(pCliEnv, "[GCP]DNSInfo: **********dnsLstnr is:\r\n");
	mgcoPrintTptSrvr(pCliEnv, dnsInfo->dnsLstnr);
	XOS_CliExtPrintf(pCliEnv, "[GCP]DNSInfo: **********End of dnsLstnr \r\n");
#endif /* POINTER_PRINT */	
#ifdef CM_DNS_LIB
       XOS_CliExtPrintf(pCliEnv, "dnsInfo.dnsCbr		:%x\r\n", dnsInfo->dnsCb);
#endif /* CM_DNS_LIB */
}	


/*****************************************************************
 * Print timing queue control point
 */
 
PRIVATE VOID mgcoPrintCmTqCp(CLI_ENV *pCliEnv, CmTqCp *tqCp)
{
	if(tqCp == NULL)
		return ;

	XOS_CliExtPrintf(pCliEnv, "[GCP]CmTqCp: nxtEnt(%d)\r\n", tqCp->nxtEnt);
	XOS_CliExtPrintf(pCliEnv, "[GCP]CmTqCp: tmrLen(%d)\r\n", tqCp->tmrLen);	
}


/*****************************************************************
 * Print CmTqType
 */
 
PRIVATE VOID mgcoPrintCmTqType(CLI_ENV *pCliEnv, CmTqType *cmTqType)
{
	if((CmTimer*)NULLP==cmTqType->first)
		XOS_CliExtPrintf(pCliEnv, "[GCP]CmTqType: This node is the first node!\r\n");
	else
		XOS_CliExtPrintf(pCliEnv, "[GCP]CmTqType: first(%x)\r\n", cmTqType->first);
	if((CmTimer*)NULLP==cmTqType->tail)
		XOS_CliExtPrintf(pCliEnv, "[GCP]CmTqType: This node is the tail node!\r\n");
	else
		XOS_CliExtPrintf(pCliEnv, "[GCP]CmTqType: tail(%x)\r\n", cmTqType->tail);
}

/*****************************************************************
 * Print TraceLevel
 */

VOID mgSetTraceLevel(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
	U32 dbgMask;
	S8 *empty;
    	if(siArgc == 2)
    	{
        	if(cmStrncmp(ppArgv[1], "help", 4) == 0)
        	{
           		XOS_CliExtPrintf(pCliEnv, 
					  "SetdbgMask\r\n"
					  "����Э��ջ���Լ���\r\n"
					  "һ������:dbgMask\r\n\r\n"
				"DBGMASK_SI  		1		0x1\r\n"      
				"DBGMASK_MI    		2		0x2\r\n"      
				"DBGMASK_UI    		4		0x4\r\n"      
				"DBGMASK_LI    		8		0x8\r\n"      
				"DBGMASK_PI   		16		0x10\r\n"      
				"DBGMASK_PLI  		32		0x20\r\n"      
				"DBGMASK_LYR  		256		0x100\r\n"      
				"DBGMASK_ALL  		319		0xFFFF\r\n"
				"DBGMASK_NONE		0		0x0\r\n");      
        }
        else
        {
           	dbgMask = (U32)strtoul(ppArgv[1] ,&empty, 0);
           	mgCb.init.dbgMask = dbgMask;		
           	XOS_CliExtPrintf(pCliEnv, "[H.248] Set dbgMask: dbgMask=%u(0x%x)\r\n",
                               dbgMask,dbgMask);
		showTraceLevel(pCliEnv);
        }
    }
   else if (siArgc == 1)
	{
		XOS_CliExtPrintf(pCliEnv, "[H.248] Set dbgMask: no input param\r\n");
	}
	else
   {
        XOS_CliExtPrintf(pCliEnv, "[H.248] Set dbgMask: the input param number is too much\r\n");
   }
}

/*****************************************************************
 * show dbgMask
 */

VOID showTraceLevel(CLI_ENV *pCliEnv)
{
	XOS_CliExtPrintf(pCliEnv, "-------------------------\r\n");
	XOS_CliExtPrintf(pCliEnv, "dbgMask 	: %d(0x%x)\r\n", mgCb.init.dbgMask,mgCb.init.dbgMask);
	XOS_CliExtPrintf(pCliEnv, "-------------------------\r\n");
	{
		if(1&mgCb.init.dbgMask)
			XOS_CliExtPrintf(pCliEnv, "DBGMASK_SI 	: ON\r\n");
		else
			XOS_CliExtPrintf(pCliEnv, "DBGMASK_SI 	: OFF\r\n");

		if(2&mgCb.init.dbgMask)
			XOS_CliExtPrintf(pCliEnv, "DBGMASK_MI 	: ON\r\n");
		else
			XOS_CliExtPrintf(pCliEnv, "DBGMASK_MI 	: OFF\r\n");

		if(4&mgCb.init.dbgMask)
			XOS_CliExtPrintf(pCliEnv, "DBGMASK_UI 	: ON\r\n");
		else
			XOS_CliExtPrintf(pCliEnv, "DBGMASK_UI 	: OFF\r\n");

		if(8&mgCb.init.dbgMask)
			XOS_CliExtPrintf(pCliEnv, "DBGMASK_LI 	: ON\r\n");
		else
			XOS_CliExtPrintf(pCliEnv, "DBGMASK_LI 	: OFF\r\n");

		if(16&mgCb.init.dbgMask)
			XOS_CliExtPrintf(pCliEnv, "DBGMASK_PI 	: ON\r\n");
		else
			XOS_CliExtPrintf(pCliEnv, "DBGMASK_PI 	: OFF\r\n");

		if(32&mgCb.init.dbgMask)
			XOS_CliExtPrintf(pCliEnv, "DBGMASK_PLI 	: ON\r\n");
		else
			XOS_CliExtPrintf(pCliEnv, "DBGMASK_PLI 	: OFF\r\n");

		if(256&mgCb.init.dbgMask)
			XOS_CliExtPrintf(pCliEnv, "DBGMASK_LYR 	: ON\r\n");
		else
			XOS_CliExtPrintf(pCliEnv, "DBGMASK_LYR 	: OFF\r\n");
		
	}
}

PRIVATE VOID X8ToIP(U32 x8)
{
	int ip[4];
	ip[0] = x8>>24;
	ip[1] = (x8&0xff0000)>>16;
	ip[2] = (x8&0xff00)>>8;
	ip[3] =x8&0xff;
	printf("%d.%d.%d.%d\r\n",ip[0],ip[1],ip[2],ip[3]);
}

#endif /*SSI_WITH_CLI_ENABLED*/

/*added by wanglijun for set dbgmask from shell*/
#ifdef MG_DEBUG
U32 g_mgDbgMask = DBGMASK_LI|DBGMASK_UI|DBGMASK_MI;
#else
U32 g_mgDbgMask = 0;
#endif

Void mgSetDbgMaskFromShell(U32 dbgMask)
{
  g_mgDbgMask = dbgMask;
#ifdef DEBUGP
  mgCb.init.dbgMask = g_mgDbgMask;
#endif
  RETVOID;
}



