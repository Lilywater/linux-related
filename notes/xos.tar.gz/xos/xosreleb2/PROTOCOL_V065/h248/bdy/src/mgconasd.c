/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Megaco NAS database file

     Type:     C source file

     Desc:     global database definition elements for Megaco NAS packages

     File:     mgconasd.c

     Sid:      mgconasd.c@@/main/4 - Wed Mar 30 07:55:48 2005

     Prg:      nct

*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#ifdef GCP_MGCO

#ifdef GCP_PKG_MGCO_NAS_SUPPORT

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tkns.h"       /* common token structures */
#include "cm_mblk.h"       /* common event memory management */
#include "cm_abnf.h"       /* ABNF header file */
#include "cm_inet.h"       /* Inet header file */
#include "cm_tpt.h"        /* Transport  header file */
#include "cm_sdp.h"
#include "cm_dns.h"
#ifdef ZG
#include "cm_ftha.h"
#include "cm_psfft.h"
#endif /* ZG */
#include "mgt.h"

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* common event memory management */
#include "cm_abnf.x"       /* ABNF header file */
#include "cm_lib.x"        /* common library file */
#include "cm_inet.x"       /* Inet header file */
#include "cm_tpt.x"        /* Transport  header file */
#include "cm_sdp.x"
#ifdef ZG
#include "cm_ftha.x"
#include "cm_psfft.x"
#endif /* ZG */
#include "mgt.x"
#include "cm_abndb.x"
#include "cm_sdpdb.x"
#include "mgco_db.x"
#include "mgconasd.x"



/*****************************************************************************
                        Base NAS package (nas)
*****************************************************************************/

/*****************************************************************************
                           nas - properties 
*****************************************************************************/

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMgcoPropParmNasSessIdValueRng = 
   {1, 8, 0, (U32)~0};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMgcoPropParmNasSessIdValueRng = {1, 8};
#endif /* CM_ABNF_V_1_2 */

/* NOTE: Sloppy ABNF says use Acct-Session-Id from RFC2866 which defines it
 * as UTF-8 encoded 10646 charstring but says SHOULD use uppercase HEX digits 
 * (and gives rules to calculate sessId as a number, not a string) so treating 
 * SessId as a number seems more useful.
 */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasSessIdValue =
{
#ifdef CM_ABNF_DBG
   "PropParmNasSessIdValue",
   "XDgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 1,
   sizeof(TknU32),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_HEXUINT32,
   (U8 *)&mgMgcoPropParmNasSessIdValueRng,
   cmAbnfRegExpXDgt
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasSessIdValDefChcElmnts[] =
{
   NULLP, NULLP, 
   &mgMgcoPropParmNasSessIdValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

EXTERN CmAbnfElmDef *mgMgcoParmValueTypeEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasSessIdValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoPropParmNasSessIdValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasSessIdValDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasSessIdVal",
   "ParmValHexUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 2,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasSessIdValDefChc,
   mgMgcoRegExpParmValHexUint
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoEQUALDef;

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasSessIdValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoPropParmNasSessIdValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasSessIdValEqDefSeq =
{
   2,
   mgMgcoPropParmNasSessIdValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasSessIdValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 3,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasSessIdValEqDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoGREATERTHANDef;

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasSessIdValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoPropParmNasSessIdValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasSessIdValGtDefSeq =
{
   2,
   mgMgcoPropParmNasSessIdValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasSessIdValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 4,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoPropParmNasSessIdValGtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLESSTHANDef;

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasSessIdValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoPropParmNasSessIdValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasSessIdValLtDefSeq =
{
   2,
   mgMgcoPropParmNasSessIdValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasSessIdValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 5,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasSessIdValLtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoNOTEQUALDef;

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasSessIdValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoPropParmNasSessIdValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasSessIdValNeDefSeq =
{
   2,
   mgMgcoPropParmNasSessIdValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasSessIdValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 6,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasSessIdValNeDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoCOMMADef;

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasSessIdValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoPropParmNasSessIdValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPropParmNasSessIdValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoPropParmNasSessIdValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasSessIdValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 7,
   sizeof(MgMgcoValLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPropParmNasSessIdValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasSessIdValLstDefSeqElmnts[]   =
{
   &mgMgcoPropParmNasSessIdValDef,
   &mgMgcoPropParmNasSessIdValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasSessIdValLstDefSeq =
{
   2,
   mgMgcoPropParmNasSessIdValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasSessIdValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 8,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPropParmNasSessIdValLstDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLSBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRSBRKTDef;

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasSessIdValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasSessIdValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasSessIdValAndDefSeq =
{
   4,
   mgMgcoPropParmNasSessIdValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasSessIdValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 9,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasSessIdValAndDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRBRKTDef;

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasSessIdValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoPropParmNasSessIdValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasSessIdValOrDefSeq =
{
   4,
   mgMgcoPropParmNasSessIdValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasSessIdValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 10,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasSessIdValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasSessIdValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasSessIdValDef,
   &cmMsgDefMetaColon,
   &mgMgcoPropParmNasSessIdValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasSessIdValRngDefSeq =
{
   6,
   mgMgcoPropParmNasSessIdValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasSessIdValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 11,
   sizeof(MgMgcoValRng),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPropParmNasSessIdValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasSessIdDefChcElmnts[] =
{
   &mgMgcoPropParmNasSessIdValEqDef,
   &mgMgcoPropParmNasSessIdValGtDef,
   &mgMgcoPropParmNasSessIdValLtDef,
   &mgMgcoPropParmNasSessIdValNeDef,
   &mgMgcoPropParmNasSessIdValAndDef,
   &mgMgcoPropParmNasSessIdValOrDef,
   &mgMgcoPropParmNasSessIdValRngDef
};

EXTERN CmAbnfElmDef *mgMgcoParmValDefChcEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasSessIdDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoPropParmNasSessIdDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasSessIdDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasSessId",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 12,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasSessIdDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMgco0To99Rng = {1, 2, 0, 99};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMgco0To99Rng = {1, 2};
#endif /* CM_ABNF_V_1_2 */

#ifdef CM_ABNF_V_1_2
EXTERN CmAbnfElmTypeIntRange mgMgcoU32DefRng;
#else /* !CM_ABNF_V_1_2 */
EXTERN CmAbnfElmTypeRange mgMgcoU32DefRng;
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMgcoPropParmNasConnTypValDecUintDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasConnTypValDecUint",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 13,
   sizeof(TknU32),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgco0To99Rng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasConnTypValDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmNasConnTypValDecUintDef,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasConnTypValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoPropParmNasConnTypValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasConnTypValDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasConnTypVal",
   "ParmValDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 14,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasConnTypValDefChc,
   mgMgcoRegExpParmValDecUint
};


/* = value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasConnTypValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoPropParmNasConnTypValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasConnTypValEqDefSeq =
{
   2,
   mgMgcoPropParmNasConnTypValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasConnTypValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 15,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasConnTypValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasConnTypValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoPropParmNasConnTypValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasConnTypValGtDefSeq =
{
   2,
   mgMgcoPropParmNasConnTypValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasConnTypValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 16,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoPropParmNasConnTypValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasConnTypValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoPropParmNasConnTypValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasConnTypValLtDefSeq =
{
   2,
   mgMgcoPropParmNasConnTypValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasConnTypValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 17,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasConnTypValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasConnTypValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoPropParmNasConnTypValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasConnTypValNeDefSeq =
{
   2,
   mgMgcoPropParmNasConnTypValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasConnTypValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 18,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasConnTypValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasConnTypValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoPropParmNasConnTypValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPropParmNasConnTypValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoPropParmNasConnTypValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasConnTypValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 19,
   sizeof(MgMgcoValLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPropParmNasConnTypValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasConnTypValLstDefSeqElmnts[]   =
{
   &mgMgcoPropParmNasConnTypValDef,
   &mgMgcoPropParmNasConnTypValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasConnTypValLstDefSeq =
{
   2,
   mgMgcoPropParmNasConnTypValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasConnTypValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 20,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPropParmNasConnTypValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasConnTypValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasConnTypValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasConnTypValAndDefSeq =
{
   4,
   mgMgcoPropParmNasConnTypValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasConnTypValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 21,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasConnTypValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasConnTypValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoPropParmNasConnTypValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasConnTypValOrDefSeq =
{
   4,
   mgMgcoPropParmNasConnTypValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasConnTypValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 22,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasConnTypValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasConnTypValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasConnTypValDef,
   &cmMsgDefMetaColon,
   &mgMgcoPropParmNasConnTypValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasConnTypValRngDefSeq =
{
   6,
   mgMgcoPropParmNasConnTypValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasConnTypValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 23,
   sizeof(MgMgcoValRng),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPropParmNasConnTypValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasConnTypDefChcElmnts[] =
{
   &mgMgcoPropParmNasConnTypValEqDef,
   &mgMgcoPropParmNasConnTypValGtDef,
   &mgMgcoPropParmNasConnTypValLtDef,
   &mgMgcoPropParmNasConnTypValNeDef,
   &mgMgcoPropParmNasConnTypValAndDef,
   &mgMgcoPropParmNasConnTypValOrDef,
   &mgMgcoPropParmNasConnTypValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasConnTypDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoPropParmNasConnTypDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasConnTypDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasConnTyp",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 24,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasConnTypDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmNasSessIdEnum =
{
   (Data *)"sessid",
   MGT_PKG_NAS_PROP_SESSID
};
PUBLIC CmAbnfElmDef mgMgcoPropParmNasSessIdEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasSessIdEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 25,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmNasSessIdEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmNasConnTypEnum =
{
   (Data *)"conntyp",
   MGT_PKG_NAS_PROP_CONNTYP
};
PUBLIC CmAbnfElmDef mgMgcoPropParmNasConnTypEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasConnTypEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 26,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmNasConnTypEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRealDefChcEnum[] =
{
   NULLP,
   &mgMgcoPropParmNasSessIdEnumDef,
   &mgMgcoPropParmNasConnTypEnumDef,
};
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmNasSessIdDef,
   &mgMgcoPropParmNasConnTypDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasRealDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoPropParmNasRealDefChcElmnts,
   mgMgcoPropParmNasRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRealDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNas",
   "PropParmNas",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 27,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasRealDefChc,
   mgMgcoRegExpPropParmNas
};

EXTERN CmAbnfElmDef mgMgcoPropParmSkipAllDef;

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmSkipAllDef,
   &mgMgcoPropParmNasRealDef
};

EXTERN CmAbnfElmDef *mgMgcoGenTypeEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoPropParmNasChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of property parameter in package Nas",
   "PkgNasPropType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 28,
   sizeof(MgMgcoName) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasChcDefChc,
   mgMgcoRegExpPkgNasPropType 
};

EXTERN CmAbnfElmDef mgMgcoSkipPkgNameDef;

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoPropParmNasChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasDefSeq =
{
   3,
   mgMgcoPropParmNasDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasDef =
{
#ifdef CM_ABNF_DBG
   "Property parameter - package Nas",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 29,
   sizeof(MgMgcoPropParm) - sizeof(TknU8),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasDefSeq,
   NULLP
};

/*****************************************************************************
                               nas - Events
*****************************************************************************/

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasFailEcValue =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasFailEcValue",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 30,
   sizeof(TknU32),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgco0To99Rng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasFailEcValDefChcElmnts[] =
{
   NULLP,
   &mgMgcoObsEvtOtherNasFailEcValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasFailEcValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasFailEcValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasFailEcValDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasFailEcVal",
   "ParmValueDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 31,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasFailEcValDefChc,
   mgMgcoRegExpParmValDecUint
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoEQUALDef;

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasFailEcValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoObsEvtOtherNasFailEcValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasFailEcValEqDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasFailEcValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasFailEcValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 32,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasFailEcValEqDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoGREATERTHANDef;

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasFailEcValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoObsEvtOtherNasFailEcValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasFailEcValGtDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasFailEcValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasFailEcValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 33,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoObsEvtOtherNasFailEcValGtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLESSTHANDef;

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasFailEcValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoObsEvtOtherNasFailEcValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasFailEcValLtDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasFailEcValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasFailEcValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 34,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasFailEcValLtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoNOTEQUALDef;

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasFailEcValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoObsEvtOtherNasFailEcValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasFailEcValNeDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasFailEcValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasFailEcValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 35,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasFailEcValNeDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoCOMMADef;

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasFailEcValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoObsEvtOtherNasFailEcValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoObsEvtOtherNasFailEcValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoObsEvtOtherNasFailEcValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasFailEcValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 36,
   sizeof(MgMgcoValLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoObsEvtOtherNasFailEcValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasFailEcValLstDefSeqElmnts[]   =
{
   &mgMgcoObsEvtOtherNasFailEcValDef,
   &mgMgcoObsEvtOtherNasFailEcValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasFailEcValLstDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasFailEcValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasFailEcValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 37,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoObsEvtOtherNasFailEcValLstDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLSBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRSBRKTDef;

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasFailEcValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherNasFailEcValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasFailEcValAndDefSeq =
{
   4,
   mgMgcoObsEvtOtherNasFailEcValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasFailEcValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 38,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasFailEcValAndDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRBRKTDef;

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasFailEcValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoObsEvtOtherNasFailEcValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasFailEcValOrDefSeq =
{
   4,
   mgMgcoObsEvtOtherNasFailEcValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasFailEcValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 39,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasFailEcValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasFailEcValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherNasFailEcValDef,
   &cmMsgDefMetaColon,
   &mgMgcoObsEvtOtherNasFailEcValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasFailEcValRngDefSeq =
{
   6,
   mgMgcoObsEvtOtherNasFailEcValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasFailEcValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 40,
   sizeof(MgMgcoValRng),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoObsEvtOtherNasFailEcValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasFailEcDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherNasFailEcValEqDef,
   &mgMgcoObsEvtOtherNasFailEcValGtDef,
   &mgMgcoObsEvtOtherNasFailEcValLtDef,
   &mgMgcoObsEvtOtherNasFailEcValNeDef,
   &mgMgcoObsEvtOtherNasFailEcValAndDef,
   &mgMgcoObsEvtOtherNasFailEcValOrDef,
   &mgMgcoObsEvtOtherNasFailEcValRngDef
};

EXTERN CmAbnfElmDef *mgMgcoParmValDefChcEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasFailEcDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasFailEcDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasFailEcDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasFailEc",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 41,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasFailEcDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtOtherNasFailEcEnum =
{
   (Data *)"ec",
   MGT_PKG_NAS_EVT_NASFAIL_EC
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherNasFailEcEnumDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherNasFailEcEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 42,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtOtherNasFailEcEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasFailParDefChcEnum[] =
{
   NULLP,
   &mgMgcoEvtOtherNasFailEcEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasFailParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoObsEvtOtherNasFailEcDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasFailParDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasFailParDefChcElmnts,
   mgMgcoObsEvtOtherNasFailParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasFailParDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasFailPar",
   "ObsEvtOtherNasFailPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 43,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasFailParDefChc,
   mgMgcoRegExpObsEvtOtherNasFailPar
};

EXTERN CmAbnfElmDef mgMgcoEvtOtherSkipAllDef;

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasFailDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoObsEvtOtherNasFailParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasFailDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasFailDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasFailDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasFail",
   "ObsEvtOtherNasFailType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 44,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasFailDefChc,
   mgMgcoRegExpObsEvtOtherNasFailType
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoEvtStreamDef;
EXTERN CmAbnfElmDef mgMgcoEvtEmbWithSigDef;
EXTERN CmAbnfElmDef mgMgcoEvtEmbNoSigDef;
EXTERN CmAbnfElmDef mgMgcoEvtDigMapDef;
EXTERN CmAbnfElmDef mgMgcoEvtKAConsumeSkipDef;

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasFailParmDefChcElmnts[] =
{
   NULLP, /* No ReqEvtOtherNasFail */
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

EXTERN CmAbnfElmDef *mgMgcoEvtParmDefChcEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtNasFailParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtNasFailParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasFailParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasFail - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 45,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtNasFailParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasFailParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtNasFailParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtNasFailParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtNasFailParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasFailParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasFail - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 46,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtNasFailParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasFailParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtNasFailParmDef,
   &mgMgcoReqEvtNasFailParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNasFailParmLstDefSeq =
{
   2,
   mgMgcoReqEvtNasFailParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasFailParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasFail - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 47,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtNasFailParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasFailDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtNasFailParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNasFailDefSeq =
{
   3,
   mgMgcoReqEvtNasFailDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasFailDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasFail - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 48,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtNasFailDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoEvtEmbSigDef;

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasFailParmDefChcElmnts[] =
{
   NULLP, /* No ReqEvtOtherNasFail */
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

EXTERN U8 mgMgcoEvtSecParmChcIdx[];
EXTERN CmAbnfElmDef *mgMgcoEvtSecParmChcEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecNasFailParmDefChc =
{
   5,
   7,
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecNasFailParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasFailParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasFail - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 49,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecNasFailParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasFailParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecNasFailParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecNasFailParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecNasFailParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasFailParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasFail - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 50,
   sizeof(MgMgcoEvtParSecLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecNasFailParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasFailParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecNasFailParmDef,
   &mgMgcoEvtSecNasFailParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNasFailParmLstDefSeq =
{
   2,
   mgMgcoEvtSecNasFailParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasFailParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasFail - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 51,
   sizeof(MgMgcoEvtParSecLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecNasFailParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasFailDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecNasFailParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNasFailDefSeq =
{
   3,
   mgMgcoEvtSecNasFailDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasFailDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasFail - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 52,
   sizeof(MgMgcoEvtParSecLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecNasFailDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasFailParmDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherNasFailDef,
   &mgMgcoEvtStreamDef
};

EXTERN CmAbnfElmDef *mgMgcoEvtSpecParmDefChcEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecNasFailParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecNasFailParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasFailParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasFail - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 53,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecNasFailParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasFailParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecNasFailParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecNasFailParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecNasFailParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasFailParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasFail - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 54,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecNasFailParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasFailParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecNasFailParmDef,
   &mgMgcoEvSpecNasFailParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNasFailParmLstDefSeq =
{
   2,
   mgMgcoEvSpecNasFailParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasFailParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasFail - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 55,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecNasFailParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasFailDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecNasFailParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNasFailDefSeq =
{
   3,
   mgMgcoEvSpecNasFailDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasFailDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasFail - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 56,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecNasFailDefSeq,
   mgMgcoRegExpLBRKT
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasRelReasonValue =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasRelReasonValue",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 57,
   sizeof(TknU32),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgco0To99Rng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasRelReasonValDefChcElmnts[] =
{
   NULLP,
   &mgMgcoObsEvtOtherNasRelReasonValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasRelReasonValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasRelReasonValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasRelReasonValDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasRelReasonVal",
   "ParmValueDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 58,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasRelReasonValDefChc,
   mgMgcoRegExpParmValDecUint
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoEQUALDef;

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasRelReasonValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoObsEvtOtherNasRelReasonValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasRelReasonValEqDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasRelReasonValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasRelReasonValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 59,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasRelReasonValEqDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoGREATERTHANDef;

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasRelReasonValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoObsEvtOtherNasRelReasonValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasRelReasonValGtDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasRelReasonValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasRelReasonValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 60,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoObsEvtOtherNasRelReasonValGtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLESSTHANDef;

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasRelReasonValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoObsEvtOtherNasRelReasonValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasRelReasonValLtDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasRelReasonValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasRelReasonValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 61,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasRelReasonValLtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoNOTEQUALDef;

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasRelReasonValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoObsEvtOtherNasRelReasonValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasRelReasonValNeDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasRelReasonValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasRelReasonValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 62,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasRelReasonValNeDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoCOMMADef;

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasRelReasonValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoObsEvtOtherNasRelReasonValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoObsEvtOtherNasRelReasonValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoObsEvtOtherNasRelReasonValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasRelReasonValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 63,
   sizeof(MgMgcoValLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoObsEvtOtherNasRelReasonValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasRelReasonValLstDefSeqElmnts[]   =
{
   &mgMgcoObsEvtOtherNasRelReasonValDef,
   &mgMgcoObsEvtOtherNasRelReasonValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasRelReasonValLstDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasRelReasonValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasRelReasonValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 64,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoObsEvtOtherNasRelReasonValLstDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLSBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRSBRKTDef;

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasRelReasonValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherNasRelReasonValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasRelReasonValAndDefSeq =
{
   4,
   mgMgcoObsEvtOtherNasRelReasonValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasRelReasonValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 65,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasRelReasonValAndDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRBRKTDef;

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasRelReasonValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoObsEvtOtherNasRelReasonValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasRelReasonValOrDefSeq =
{
   4,
   mgMgcoObsEvtOtherNasRelReasonValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasRelReasonValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 66,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasRelReasonValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasRelReasonValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherNasRelReasonValDef,
   &cmMsgDefMetaColon,
   &mgMgcoObsEvtOtherNasRelReasonValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasRelReasonValRngDefSeq =
{
   6,
   mgMgcoObsEvtOtherNasRelReasonValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasRelReasonValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 67,
   sizeof(MgMgcoValRng),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoObsEvtOtherNasRelReasonValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasRelReasonDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherNasRelReasonValEqDef,
   &mgMgcoObsEvtOtherNasRelReasonValGtDef,
   &mgMgcoObsEvtOtherNasRelReasonValLtDef,
   &mgMgcoObsEvtOtherNasRelReasonValNeDef,
   &mgMgcoObsEvtOtherNasRelReasonValAndDef,
   &mgMgcoObsEvtOtherNasRelReasonValOrDef,
   &mgMgcoObsEvtOtherNasRelReasonValRngDef
};

EXTERN CmAbnfElmDef *mgMgcoParmValDefChcEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasRelReasonDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasRelReasonDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasRelReasonDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasRelReason",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 68,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasRelReasonDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtOtherNasRelReasonEnum =
{
   (Data *)"reason",
   MGT_PKG_NAS_EVT_NASREL_REASON
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherNasRelReasonEnumDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherNasRelReasonEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 69,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtOtherNasRelReasonEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasRelParDefChcEnum[] =
{
   NULLP,
   &mgMgcoEvtOtherNasRelReasonEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasRelParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoObsEvtOtherNasRelReasonDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasRelParDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasRelParDefChcElmnts,
   mgMgcoObsEvtOtherNasRelParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasRelParDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasRelPar",
   "ObsEvtOtherNasRelPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 70,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasRelParDefChc,
   mgMgcoRegExpObsEvtOtherNasRelPar
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasRelDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoObsEvtOtherNasRelParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasRelDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasRelDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasRelDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasRel",
   "ObsEvtOtherNasRelType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 71,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasRelDefChc,
   mgMgcoRegExpObsEvtOtherNasRelType
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasRelParmDefChcElmnts[] =
{
   NULLP, /* No ReqEvtOtherNasRel */
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtNasRelParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtNasRelParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasRelParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasRel - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 72,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtNasRelParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasRelParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtNasRelParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtNasRelParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtNasRelParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasRelParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasRel - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 73,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtNasRelParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasRelParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtNasRelParmDef,
   &mgMgcoReqEvtNasRelParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNasRelParmLstDefSeq =
{
   2,
   mgMgcoReqEvtNasRelParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasRelParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasRel - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 74,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtNasRelParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasRelDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtNasRelParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNasRelDefSeq =
{
   3,
   mgMgcoReqEvtNasRelDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasRelDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasRel - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 75,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtNasRelDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasRelParmDefChcElmnts[] =
{
   NULLP, /* No ReqEvtOtherNasRel */
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecNasRelParmDefChc =
{
   5,
   7,
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecNasRelParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasRelParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasRel - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 76,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecNasRelParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasRelParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecNasRelParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecNasRelParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecNasRelParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasRelParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasRel - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 77,
   sizeof(MgMgcoEvtParSecLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecNasRelParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasRelParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecNasRelParmDef,
   &mgMgcoEvtSecNasRelParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNasRelParmLstDefSeq =
{
   2,
   mgMgcoEvtSecNasRelParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasRelParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasRel - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 78,
   sizeof(MgMgcoEvtParSecLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecNasRelParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasRelDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecNasRelParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNasRelDefSeq =
{
   3,
   mgMgcoEvtSecNasRelDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasRelDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasRel - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 79,
   sizeof(MgMgcoEvtParSecLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecNasRelDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasRelParmDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherNasRelDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecNasRelParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecNasRelParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasRelParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasRel - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 80,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecNasRelParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasRelParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecNasRelParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecNasRelParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecNasRelParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasRelParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasRel - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 81,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecNasRelParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasRelParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecNasRelParmDef,
   &mgMgcoEvSpecNasRelParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNasRelParmLstDefSeq =
{
   2,
   mgMgcoEvSpecNasRelParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasRelParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasRel - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 82,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecNasRelParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasRelDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecNasRelParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNasRelDefSeq =
{
   3,
   mgMgcoEvSpecNasRelDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasRelDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasRel - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 83,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecNasRelDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEventNasFailEnum =
{
   (Data *)"nasfail",
   MGT_PKG_NAS_EVT_NASFAIL
};

PUBLIC CmAbnfElmDef mgMgcoEventNasFailEnumDef =
{
#ifdef CM_ABNF_DBG
   "EventNasFailEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 84,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventNasFailEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEventNasRelEnum =
{
   (Data *)"nasrel",
   MGT_PKG_NAS_EVT_NASREL
};

PUBLIC CmAbnfElmDef mgMgcoEventNasRelEnumDef =
{
#ifdef CM_ABNF_DBG
   "EventNasRelEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 85,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventNasRelEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEventNasRealDefChcEnum[] =
{
   NULLP,
   &mgMgcoEventNasFailEnumDef,
   &mgMgcoEventNasRelEnumDef,
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoReqEvtNasFailDef,
   &mgMgcoReqEvtNasRelDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtNasRealDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtNasRealDefChcElmnts,
   mgMgcoEventNasRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasRealDef =
{
#ifdef CM_ABNF_DBG
   "Real requested event - package Nas",
   "EvtNameNas",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 86,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtNasRealDefChc,
   mgMgcoRegExpEvtNameNas
};

EXTERN CmAbnfElmDef mgMgcoEvSpecSkipAllDef;

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoReqEvtNasRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtNasChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtNasChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of requested event in package Nas",
   "PkgNasEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 87,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtNasChcDefChc,
   mgMgcoRegExpPkgNasEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoReqEvtNasChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNasDefSeq =
{
   3,
   mgMgcoReqEvtNasDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasDef =
{
#ifdef CM_ABNF_DBG
   "Requested event - package Nas",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 88,
   sizeof(MgMgcoReqEvt) - sizeof(TknU8),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtNasDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtSecNasFailDef,
   &mgMgcoEvtSecNasRelDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecNasRealDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtSecNasRealDefChcElmnts,
   mgMgcoEventNasRealDefChcEnum
};


PUBLIC CmAbnfElmDef mgMgcoEvtSecNasRealDef =
{
#ifdef CM_ABNF_DBG
   "Real second requested event - package Nas",
   "EvtNameNas",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 89,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParSecLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecNasRealDefChc,
   mgMgcoRegExpEvtNameNas
};

EXTERN CmAbnfElmDef mgMgcoEvtSecSkipAllDef;

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtSecSkipAllDef,
   &mgMgcoEvtSecNasRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecNasChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtSecNasChcDefChcElmnts,
   mgMgcoGenTypeEnum 
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of second req event in package Nas",
   "PkgNasEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 90,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecNasChcDefChc,
   mgMgcoRegExpPkgNasEvtType
};

/* Second requested event */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvtSecNasChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNasDefSeq =
{
   3,
   mgMgcoEvtSecNasDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - package Nas",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 91,
   sizeof(MgMgcoEvtSec) - sizeof(TknU8),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtSecNasDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecNasFailDef,
   &mgMgcoEvSpecNasRelDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecNasRealDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvSpecNasRealDefChcElmnts,
   mgMgcoEventNasRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasRealDef =
{
#ifdef CM_ABNF_DBG
   "Real event spec -  package Nas",
   "EvtNameNas",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 92,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecNasRealDefChc,
   mgMgcoRegExpEvtNameNas
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoEvSpecNasRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecNasChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvSpecNasChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of event spec in package Nas",
   "PkgNasEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 93,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecNasChcDefChc,
   mgMgcoRegExpPkgNasEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvSpecNasChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNasDefSeq =
{
   3,
   mgMgcoEvSpecNasDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - package Nas",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 94,
   sizeof(MgMgcoEvSpec) - sizeof(TknU8),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvSpecNasDefSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtNasRealDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvSpecNasRealDefChcElmnts,
   mgMgcoEventNasRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtNasRealDef =
{
#ifdef CM_ABNF_DBG
   "Real observed event - package Nas",
   "EvtNameNas",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 95,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtNasRealDefChc,
   mgMgcoRegExpEvtNameNas
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtNasChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoObsEvtNasRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtNasChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtNasChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtNasChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of observed event in package Nas",
   "PkgNasEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 96,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtNasChcDefChc,
   mgMgcoRegExpPkgNasEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtNasDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoObsEvtNasChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtNasDefSeq =
{
   3,
   mgMgcoObsEvtNasDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtNasDef =
{
#ifdef CM_ABNF_DBG
   "Observed event - package Nas",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 97,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtNasDefSeq,
   NULLP
};

/*****************************************************************************
                        nas - no signals 
*****************************************************************************/

/*****************************************************************************
                        nas - no statistics
*****************************************************************************/

/*****************************************************************************
                        NAS Incoming package (nasin)
*****************************************************************************/

/*****************************************************************************
                           nasin - properties 
*****************************************************************************/

PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClgStatValDecUintDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasInClgStatValDecUint",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 98,
   sizeof(TknU32),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgco0To99Rng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClgStatValDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmNasInClgStatValDecUintDef,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasInClgStatValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoPropParmNasInClgStatValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClgStatValDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasInClgStatVal",
   "ParmValDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 99,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasInClgStatValDefChc,
   mgMgcoRegExpParmValDecUint
};


/* = value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClgStatValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoPropParmNasInClgStatValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClgStatValEqDefSeq =
{
   2,
   mgMgcoPropParmNasInClgStatValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClgStatValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 100,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasInClgStatValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClgStatValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoPropParmNasInClgStatValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClgStatValGtDefSeq =
{
   2,
   mgMgcoPropParmNasInClgStatValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClgStatValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 101,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,   
   (U8 *)&mgMgcoPropParmNasInClgStatValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClgStatValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoPropParmNasInClgStatValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClgStatValLtDefSeq =
{
   2,
   mgMgcoPropParmNasInClgStatValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClgStatValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 102,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasInClgStatValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClgStatValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoPropParmNasInClgStatValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClgStatValNeDefSeq =
{
   2,
   mgMgcoPropParmNasInClgStatValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClgStatValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 103,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasInClgStatValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClgStatValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoPropParmNasInClgStatValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPropParmNasInClgStatValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoPropParmNasInClgStatValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClgStatValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 104,
   sizeof(MgMgcoValLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPropParmNasInClgStatValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClgStatValLstDefSeqElmnts[]   =
{
   &mgMgcoPropParmNasInClgStatValDef,
   &mgMgcoPropParmNasInClgStatValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClgStatValLstDefSeq =
{
   2,
   mgMgcoPropParmNasInClgStatValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClgStatValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 105,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPropParmNasInClgStatValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClgStatValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasInClgStatValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClgStatValAndDefSeq =
{
   4,
   mgMgcoPropParmNasInClgStatValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClgStatValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 106,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasInClgStatValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClgStatValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoPropParmNasInClgStatValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClgStatValOrDefSeq =
{
   4,
   mgMgcoPropParmNasInClgStatValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClgStatValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 107,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasInClgStatValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClgStatValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasInClgStatValDef,
   &cmMsgDefMetaColon,
   &mgMgcoPropParmNasInClgStatValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClgStatValRngDefSeq =
{
   6,
   mgMgcoPropParmNasInClgStatValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClgStatValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 108,
   sizeof(MgMgcoValRng),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPropParmNasInClgStatValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClgStatDefChcElmnts[] =
{
   &mgMgcoPropParmNasInClgStatValEqDef,
   &mgMgcoPropParmNasInClgStatValGtDef,
   &mgMgcoPropParmNasInClgStatValLtDef,
   &mgMgcoPropParmNasInClgStatValNeDef,
   &mgMgcoPropParmNasInClgStatValAndDef,
   &mgMgcoPropParmNasInClgStatValOrDef,
   &mgMgcoPropParmNasInClgStatValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasInClgStatDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoPropParmNasInClgStatDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClgStatDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasInClgStat",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 109,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasInClgStatDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

PUBLIC CmAbnfElmTypeRange mgMgcoPropParmNasInClXNumValueRng = {1, 0xFFFF};
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClXNumValue =
{
#ifdef CM_ABNF_DBG
   "PropParmNasInClXNumValue",
   "PropParmNasInClXNumValue",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 110,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoPropParmNasInClXNumValueRng,
   cmAbnfRegExpXDgt
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClXNumValDefChcElmnts[] =
{
   NULLP, NULLP, NULLP,
   &mgMgcoPropParmNasInClXNumValue,
   NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasInClXNumValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoPropParmNasInClXNumValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClXNumValDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasInClXNumVal",
   "ParmValOctStrXL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 111,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasInClXNumValDefChc,
   mgMgcoRegExpParmValOctStrXL
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoEQUALDef;

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClXNumValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoPropParmNasInClXNumValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClXNumValEqDefSeq =
{
   2,
   mgMgcoPropParmNasInClXNumValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClXNumValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 112,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasInClXNumValEqDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoGREATERTHANDef;

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClXNumValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoPropParmNasInClXNumValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClXNumValGtDefSeq =
{
   2,
   mgMgcoPropParmNasInClXNumValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClXNumValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 113,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,   
   (U8 *)&mgMgcoPropParmNasInClXNumValGtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLESSTHANDef;

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClXNumValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoPropParmNasInClXNumValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClXNumValLtDefSeq =
{
   2,
   mgMgcoPropParmNasInClXNumValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClXNumValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 114,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasInClXNumValLtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoNOTEQUALDef;

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClXNumValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoPropParmNasInClXNumValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClXNumValNeDefSeq =
{
   2,
   mgMgcoPropParmNasInClXNumValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClXNumValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 115,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasInClXNumValNeDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoCOMMADef;

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClXNumValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoPropParmNasInClXNumValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPropParmNasInClXNumValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoPropParmNasInClXNumValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClXNumValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 116,
   sizeof(MgMgcoValLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPropParmNasInClXNumValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClXNumValLstDefSeqElmnts[]   =
{
   &mgMgcoPropParmNasInClXNumValDef,
   &mgMgcoPropParmNasInClXNumValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClXNumValLstDefSeq =
{
   2,
   mgMgcoPropParmNasInClXNumValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClXNumValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 117,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPropParmNasInClXNumValLstDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLSBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRSBRKTDef;

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClXNumValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasInClXNumValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClXNumValAndDefSeq =
{
   4,
   mgMgcoPropParmNasInClXNumValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClXNumValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 118,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasInClXNumValAndDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRBRKTDef;

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClXNumValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoPropParmNasInClXNumValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClXNumValOrDefSeq =
{
   4,
   mgMgcoPropParmNasInClXNumValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClXNumValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 119,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasInClXNumValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClXNumValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasInClXNumValDef,
   &cmMsgDefMetaColon,
   &mgMgcoPropParmNasInClXNumValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInClXNumValRngDefSeq =
{
   6,
   mgMgcoPropParmNasInClXNumValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClXNumValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 120,
   sizeof(MgMgcoValRng),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPropParmNasInClXNumValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInClXNumDefChcElmnts[] =
{
   &mgMgcoPropParmNasInClXNumValEqDef,
   &mgMgcoPropParmNasInClXNumValGtDef,
   &mgMgcoPropParmNasInClXNumValLtDef,
   &mgMgcoPropParmNasInClXNumValNeDef,
   &mgMgcoPropParmNasInClXNumValAndDef,
   &mgMgcoPropParmNasInClXNumValOrDef,
   &mgMgcoPropParmNasInClXNumValRngDef
};

EXTERN CmAbnfElmDef *mgMgcoParmValDefChcEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasInClXNumDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoPropParmNasInClXNumDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClXNumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasInClXNum",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 121,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasInClXNumDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmNasInClgStatEnum =
{
   (Data *)"clgstat",
   MGT_PKG_NASIN_PROP_CLGSTAT
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClgStatEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasInClgStatEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 122,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmNasInClgStatEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmNasInClgNumEnum =
{
   (Data *)"clgnum",
   MGT_PKG_NASIN_PROP_CLGNUM
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasInClgNumEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasInClgNumEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 123,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmNasInClgNumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmNasInCldNumEnum =
{
   (Data *)"cldnum",
   MGT_PKG_NASIN_PROP_CLDNUM
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasInCldNumEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasInCldNumEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 124,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmNasInCldNumEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInRealDefChcEnum[] =
{
   NULLP,
   &mgMgcoPropParmNasSessIdEnumDef, /* NOTE: not sure where to put these */
   &mgMgcoPropParmNasConnTypEnumDef,
   &mgMgcoPropParmNasInClgStatEnumDef,
   &mgMgcoPropParmNasInClgNumEnumDef,
   &mgMgcoPropParmNasInCldNumEnumDef,
};
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmNasSessIdDef,
   &mgMgcoPropParmNasConnTypDef,
   &mgMgcoPropParmNasInClgStatDef,
   &mgMgcoPropParmNasInClXNumDef,
   &mgMgcoPropParmNasInClXNumDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasInRealDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoPropParmNasInRealDefChcElmnts,
   mgMgcoPropParmNasInRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasInRealDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasIn",
   "PropParmNasIn",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 125,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasInRealDefChc,
   mgMgcoRegExpPropParmNasIn
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmSkipAllDef,
   &mgMgcoPropParmNasInRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasInChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoPropParmNasInChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasInChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of property parameter in package NasIn",
   "PkgNasInPropType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 126,
   sizeof(MgMgcoName) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasInChcDefChc,
   mgMgcoRegExpPkgNasInPropType 
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasInDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoPropParmNasInChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasInDefSeq =
{
   3,
   mgMgcoPropParmNasInDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasInDef =
{
#ifdef CM_ABNF_DBG
   "Property parameter - package NasIn",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 127,
   sizeof(MgMgcoPropParm) - sizeof(TknU8),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasInDefSeq,
   NULLP
};

/*****************************************************************************
                               nasin - Events
*****************************************************************************/

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResResValue =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasInAuthResResValue",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 128,
   sizeof(TknU32),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgco0To99Rng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResResValDefChcElmnts[] =
{
   NULLP,
   &mgMgcoObsEvtOtherNasInAuthResResValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasInAuthResResValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasInAuthResResValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResResValDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasInAuthResResVal",
   "ParmValueDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 129,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResResValDefChc,
   mgMgcoRegExpParmValDecUint
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoEQUALDef;

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResResValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoObsEvtOtherNasInAuthResResValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResResValEqDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasInAuthResResValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResResValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 130,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResResValEqDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoGREATERTHANDef;

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResResValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoObsEvtOtherNasInAuthResResValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResResValGtDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasInAuthResResValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResResValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 131,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResResValGtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLESSTHANDef;

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResResValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoObsEvtOtherNasInAuthResResValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResResValLtDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasInAuthResResValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResResValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 132,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResResValLtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoNOTEQUALDef;

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResResValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoObsEvtOtherNasInAuthResResValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResResValNeDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasInAuthResResValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResResValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 133,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResResValNeDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoCOMMADef;

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResResValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoObsEvtOtherNasInAuthResResValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoObsEvtOtherNasInAuthResResValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoObsEvtOtherNasInAuthResResValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResResValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 134,
   sizeof(MgMgcoValLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResResValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResResValLstDefSeqElmnts[]   =
{
   &mgMgcoObsEvtOtherNasInAuthResResValDef,
   &mgMgcoObsEvtOtherNasInAuthResResValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResResValLstDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasInAuthResResValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResResValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 135,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResResValLstDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLSBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRSBRKTDef;

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResResValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherNasInAuthResResValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResResValAndDefSeq =
{
   4,
   mgMgcoObsEvtOtherNasInAuthResResValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResResValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 136,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResResValAndDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRBRKTDef;

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResResValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoObsEvtOtherNasInAuthResResValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResResValOrDefSeq =
{
   4,
   mgMgcoObsEvtOtherNasInAuthResResValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResResValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 137,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResResValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResResValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherNasInAuthResResValDef,
   &cmMsgDefMetaColon,
   &mgMgcoObsEvtOtherNasInAuthResResValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResResValRngDefSeq =
{
   6,
   mgMgcoObsEvtOtherNasInAuthResResValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResResValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 138,
   sizeof(MgMgcoValRng),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResResValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResResDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherNasInAuthResResValEqDef,
   &mgMgcoObsEvtOtherNasInAuthResResValGtDef,
   &mgMgcoObsEvtOtherNasInAuthResResValLtDef,
   &mgMgcoObsEvtOtherNasInAuthResResValNeDef,
   &mgMgcoObsEvtOtherNasInAuthResResValAndDef,
   &mgMgcoObsEvtOtherNasInAuthResResValOrDef,
   &mgMgcoObsEvtOtherNasInAuthResResValRngDef
};

EXTERN CmAbnfElmDef *mgMgcoParmValDefChcEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasInAuthResResDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasInAuthResResDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResResDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasInAuthResRes",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 139,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResResDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

PUBLIC CmAbnfElmTypeRange mgMgcoObsEvtOtherNasInAuthResDialNumValueRng =
   {1, 0xFFFF};
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResDialNumValue =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasInAuthResDialNumValue",
   "XDgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 140,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResDialNumValueRng,
   cmAbnfRegExpXDgt
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResDialNumValDefChcElmnts[] =
{
   NULLP, NULLP, NULLP, 
   &mgMgcoObsEvtOtherNasInAuthResDialNumValue,
   NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasInAuthResDialNumValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasInAuthResDialNumValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResDialNumValDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasInAuthResDialNumVal",
   "ParmValueOctStrXL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 141,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResDialNumValDefChc,
   mgMgcoRegExpParmValOctStrXL
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoEQUALDef;

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResDialNumValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResDialNumValEqDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasInAuthResDialNumValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResDialNumValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 142,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResDialNumValEqDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoGREATERTHANDef;

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResDialNumValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResDialNumValGtDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasInAuthResDialNumValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResDialNumValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 143,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,   
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResDialNumValGtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLESSTHANDef;

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResDialNumValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResDialNumValLtDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasInAuthResDialNumValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResDialNumValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 144,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResDialNumValLtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoNOTEQUALDef;

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResDialNumValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResDialNumValNeDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasInAuthResDialNumValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResDialNumValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 145,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResDialNumValNeDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoCOMMADef;

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResDialNumValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoObsEvtOtherNasInAuthResDialNumValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoObsEvtOtherNasInAuthResDialNumValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResDialNumValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 146,
   sizeof(MgMgcoValLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResDialNumValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResDialNumValLstDefSeqElmnts[]   =
{
   &mgMgcoObsEvtOtherNasInAuthResDialNumValDef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResDialNumValLstDefSeq =
{
   2,
   mgMgcoObsEvtOtherNasInAuthResDialNumValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResDialNumValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 147,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResDialNumValLstDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLSBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRSBRKTDef;

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResDialNumValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResDialNumValAndDefSeq =
{
   4,
   mgMgcoObsEvtOtherNasInAuthResDialNumValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResDialNumValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 148,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResDialNumValAndDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRBRKTDef;

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResDialNumValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResDialNumValOrDefSeq =
{
   4,
   mgMgcoObsEvtOtherNasInAuthResDialNumValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResDialNumValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 149,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResDialNumValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResDialNumValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValDef,
   &cmMsgDefMetaColon,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNasInAuthResDialNumValRngDefSeq =
{
   6,
   mgMgcoObsEvtOtherNasInAuthResDialNumValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResDialNumValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 150,
   sizeof(MgMgcoValRng),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResDialNumValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResDialNumDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherNasInAuthResDialNumValEqDef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValGtDef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValLtDef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValNeDef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValAndDef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValOrDef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumValRngDef
};

EXTERN CmAbnfElmDef *mgMgcoParmValDefChcEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasInAuthResDialNumDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasInAuthResDialNumDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResDialNumDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasInAuthResDialNum",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 151,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResDialNumDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtOtherNasInAuthResResEnum =
{
   (Data *)"res",
   MGT_PKG_NASIN_EVT_AUTHRES_RES
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherNasInAuthResResEnumDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherNasInAuthResResEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 152,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtOtherNasInAuthResResEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtOtherNasInAuthResDialNumEnum =
{
   (Data *)"dialnum",
   MGT_PKG_NASIN_EVT_AUTHRES_DIALNUM
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherNasInAuthResDialNumEnumDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherNasInAuthResDialNumEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 153,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtOtherNasInAuthResDialNumEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResParDefChcEnum[] =
{
   NULLP,
   &mgMgcoEvtOtherNasInAuthResResEnumDef,
   &mgMgcoEvtOtherNasInAuthResDialNumEnumDef,
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoObsEvtOtherNasInAuthResResDef,
   &mgMgcoObsEvtOtherNasInAuthResDialNumDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasInAuthResParDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasInAuthResParDefChcElmnts,
   mgMgcoObsEvtOtherNasInAuthResParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResParDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasInAuthResPar",
   "ObsEvtOtherNasInAuthResPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 154,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResParDefChc,
   mgMgcoRegExpObsEvtOtherNasInAuthResPar
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasInAuthResDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoObsEvtOtherNasInAuthResParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasInAuthResDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasInAuthResDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasInAuthResDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasInAuthRes",
   "ObsEvtOtherNasInAuthResType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 155,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasInAuthResDefChc,
   mgMgcoRegExpObsEvtOtherNasInAuthResType
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasInAuthResParmDefChcElmnts[] =
{
   NULLP, /* No ReqEvtOtherNasInAuthRes */
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtNasInAuthResParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtNasInAuthResParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasInAuthResParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasInAuthRes - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 156,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtNasInAuthResParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasInAuthResParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtNasInAuthResParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtNasInAuthResParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtNasInAuthResParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasInAuthResParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasInAuthRes - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 157,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtNasInAuthResParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasInAuthResParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtNasInAuthResParmDef,
   &mgMgcoReqEvtNasInAuthResParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNasInAuthResParmLstDefSeq =
{
   2,
   mgMgcoReqEvtNasInAuthResParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasInAuthResParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasInAuthRes - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 158,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtNasInAuthResParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasInAuthResDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtNasInAuthResParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNasInAuthResDefSeq =
{
   3,
   mgMgcoReqEvtNasInAuthResDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasInAuthResDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasInAuthRes - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 159,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtNasInAuthResDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasInAuthResParmDefChcElmnts[] =
{
   NULLP, /* No ReqEvtOtherNasInAuthRes */
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecNasInAuthResParmDefChc =
{
   5,
   7,
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecNasInAuthResParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasInAuthResParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasInAuthRes - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 160,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecNasInAuthResParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasInAuthResParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecNasInAuthResParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecNasInAuthResParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecNasInAuthResParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasInAuthResParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasInAuthRes - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 161,
   sizeof(MgMgcoEvtParSecLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecNasInAuthResParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasInAuthResParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecNasInAuthResParmDef,
   &mgMgcoEvtSecNasInAuthResParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNasInAuthResParmLstDefSeq =
{
   2,
   mgMgcoEvtSecNasInAuthResParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasInAuthResParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasInAuthRes - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 162,
   sizeof(MgMgcoEvtParSecLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecNasInAuthResParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasInAuthResDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecNasInAuthResParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNasInAuthResDefSeq =
{
   3,
   mgMgcoEvtSecNasInAuthResDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasInAuthResDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasInAuthRes - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 163,
   sizeof(MgMgcoEvtParSecLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecNasInAuthResDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasInAuthResParmDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherNasInAuthResDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecNasInAuthResParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecNasInAuthResParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasInAuthResParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasInAuthRes - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 164,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecNasInAuthResParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasInAuthResParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecNasInAuthResParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecNasInAuthResParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecNasInAuthResParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasInAuthResParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasInAuthRes - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 165,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecNasInAuthResParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasInAuthResParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecNasInAuthResParmDef,
   &mgMgcoEvSpecNasInAuthResParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNasInAuthResParmLstDefSeq =
{
   2,
   mgMgcoEvSpecNasInAuthResParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasInAuthResParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasInAuthRes - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 166,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecNasInAuthResParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasInAuthResDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecNasInAuthResParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNasInAuthResDefSeq =
{
   3,
   mgMgcoEvSpecNasInAuthResDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasInAuthResDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasInAuthRes - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 167,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecNasInAuthResDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEventNasInAuthResEnum =
{
   (Data *)"authres",
   MGT_PKG_NASIN_EVT_AUTHRES
};

PUBLIC CmAbnfElmDef mgMgcoEventNasInAuthResEnumDef =
{
#ifdef CM_ABNF_DBG
   "EventNasInAuthResEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 168,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventNasInAuthResEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEventNasInRealDefChcEnum[] =
{
   NULLP,
   &mgMgcoEventNasFailEnumDef,
   &mgMgcoEventNasRelEnumDef,
   &mgMgcoEventNasInAuthResEnumDef,
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasInRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoReqEvtNasFailDef,
   &mgMgcoReqEvtNasRelDef,
   &mgMgcoReqEvtNasInAuthResDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtNasInRealDefChc =
{
   4,
   0,
   NULLP,
   mgMgcoReqEvtNasInRealDefChcElmnts,
   mgMgcoEventNasInRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasInRealDef =
{
#ifdef CM_ABNF_DBG
   "Real requested event - package NasIn",
   "EvtNameNasIn",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 169,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtNasInRealDefChc,
   mgMgcoRegExpEvtNameNasIn
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasInChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoReqEvtNasInRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtNasInChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtNasInChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasInChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of requested event in package NasIn",
   "PkgNasInEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 170,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtNasInChcDefChc,
   mgMgcoRegExpPkgNasInEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasInDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoReqEvtNasInChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNasInDefSeq =
{
   3,
   mgMgcoReqEvtNasInDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasInDef =
{
#ifdef CM_ABNF_DBG
   "Requested event - package Nas",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 171,
   sizeof(MgMgcoReqEvt) - sizeof(TknU8),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtNasInDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasInRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtSecNasInAuthResDef,
   &mgMgcoEvtSecNasFailDef,
   &mgMgcoEvtSecNasRelDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecNasInRealDefChc =
{
   4,
   0,
   NULLP,
   mgMgcoEvtSecNasInRealDefChcElmnts,
   mgMgcoEventNasInRealDefChcEnum
};


PUBLIC CmAbnfElmDef mgMgcoEvtSecNasInRealDef =
{
#ifdef CM_ABNF_DBG
   "Real second requested event - package NasIn",
   "EvtNameNasIn",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 172,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParSecLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecNasInRealDefChc,
   mgMgcoRegExpEvtNameNasIn
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasInChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtSecSkipAllDef,
   &mgMgcoEvtSecNasInRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecNasInChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtSecNasInChcDefChcElmnts,
   mgMgcoGenTypeEnum 
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasInChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of second req event in package NasIn",
   "PkgNasInEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 173,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecNasInChcDefChc,
   mgMgcoRegExpPkgNasInEvtType
};

/* Second requested event */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasInDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvtSecNasInChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNasInDefSeq =
{
   3,
   mgMgcoEvtSecNasInDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasInDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - package Nas",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 174,
   sizeof(MgMgcoEvtSec) - sizeof(TknU8),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtSecNasInDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasInRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecNasFailDef,  /* NOTE: not sure where to put these */
   &mgMgcoEvSpecNasRelDef,
   &mgMgcoEvSpecNasInAuthResDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecNasInRealDefChc =
{
   4,
   0,
   NULLP,
   mgMgcoEvSpecNasInRealDefChcElmnts,
   mgMgcoEventNasInRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasInRealDef =
{
#ifdef CM_ABNF_DBG
   "Real event spec -  package NasIn",
   "EvtNameNasIn",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 175,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecNasInRealDefChc,
   mgMgcoRegExpEvtNameNasIn
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasInChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoEvSpecNasInRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecNasInChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvSpecNasInChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasInChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of event spec in package NasIn",
   "PkgNasInEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 176,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecNasInChcDefChc,
   mgMgcoRegExpPkgNasInEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasInDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvSpecNasInChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNasInDefSeq =
{
   3,
   mgMgcoEvSpecNasInDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasInDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - package Nas",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 177,
   sizeof(MgMgcoEvSpec) - sizeof(TknU8),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvSpecNasInDefSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtNasInRealDefChc =
{
   4,
   0,
   NULLP,
   mgMgcoEvSpecNasInRealDefChcElmnts,
   mgMgcoEventNasInRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtNasInRealDef =
{
#ifdef CM_ABNF_DBG
   "Real observed event - package NasIn",
   "EvtNameNasIn",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 178,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtNasInRealDefChc,
   mgMgcoRegExpEvtNameNasIn
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtNasInChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoObsEvtNasInRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtNasInChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtNasInChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtNasInChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of observed event in package Nas",
   "PkgNasInEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 179,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtNasInChcDefChc,
   mgMgcoRegExpPkgNasInEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtNasInDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoObsEvtNasInChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtNasInDefSeq =
{
   3,
   mgMgcoObsEvtNasInDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtNasInDef =
{
#ifdef CM_ABNF_DBG
   "Observed event - package Nas",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 180,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtNasInDefSeq,
   NULLP
};

/*****************************************************************************
                        nasin - no signals 
*****************************************************************************/

/*****************************************************************************
                        nasin - no statistics
*****************************************************************************/

/*****************************************************************************
                        NAS Outgoing package (nasout)
*****************************************************************************/

/*****************************************************************************
                           nasout - properties 
*****************************************************************************/
PUBLIC CmAbnfElmTypeRange mgMgcoPropParmNasOutDialNumValueRng = {1, 0xFFFF};
PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutDialNumValue =
{
#ifdef CM_ABNF_DBG
   "PropParmNasOutDialNumValue",
   "XDgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 181,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoPropParmNasOutDialNumValueRng,
   cmAbnfRegExpXDgt
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasOutDialNumValDefChcElmnts[] =
{
   NULLP, NULLP, NULLP,
   &mgMgcoPropParmNasOutDialNumValue,
   NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasOutDialNumValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoPropParmNasOutDialNumValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutDialNumValDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasOutDialNumVal",
   "ParmValOctStrXL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 182,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasOutDialNumValDefChc,
   mgMgcoRegExpParmValOctStrXL
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoEQUALDef;

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasOutDialNumValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoPropParmNasOutDialNumValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasOutDialNumValEqDefSeq =
{
   2,
   mgMgcoPropParmNasOutDialNumValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutDialNumValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 183,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasOutDialNumValEqDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoGREATERTHANDef;

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasOutDialNumValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoPropParmNasOutDialNumValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasOutDialNumValGtDefSeq =
{
   2,
   mgMgcoPropParmNasOutDialNumValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutDialNumValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 184,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoPropParmNasOutDialNumValGtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLESSTHANDef;

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasOutDialNumValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoPropParmNasOutDialNumValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasOutDialNumValLtDefSeq =
{
   2,
   mgMgcoPropParmNasOutDialNumValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutDialNumValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 185,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasOutDialNumValLtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoNOTEQUALDef;

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasOutDialNumValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoPropParmNasOutDialNumValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasOutDialNumValNeDefSeq =
{
   2,
   mgMgcoPropParmNasOutDialNumValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutDialNumValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 186,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasOutDialNumValNeDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoCOMMADef;

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasOutDialNumValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoPropParmNasOutDialNumValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPropParmNasOutDialNumValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoPropParmNasOutDialNumValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutDialNumValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 187,
   sizeof(MgMgcoValLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPropParmNasOutDialNumValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasOutDialNumValLstDefSeqElmnts[]   =
{
   &mgMgcoPropParmNasOutDialNumValDef,
   &mgMgcoPropParmNasOutDialNumValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasOutDialNumValLstDefSeq =
{
   2,
   mgMgcoPropParmNasOutDialNumValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutDialNumValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 188,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPropParmNasOutDialNumValLstDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLSBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRSBRKTDef;

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasOutDialNumValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasOutDialNumValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasOutDialNumValAndDefSeq =
{
   4,
   mgMgcoPropParmNasOutDialNumValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutDialNumValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 189,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasOutDialNumValAndDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRBRKTDef;

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasOutDialNumValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoPropParmNasOutDialNumValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasOutDialNumValOrDefSeq =
{
   4,
   mgMgcoPropParmNasOutDialNumValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutDialNumValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 190,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasOutDialNumValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasOutDialNumValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasOutDialNumValDef,
   &cmMsgDefMetaColon,
   &mgMgcoPropParmNasOutDialNumValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasOutDialNumValRngDefSeq =
{
   6,
   mgMgcoPropParmNasOutDialNumValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutDialNumValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 191,
   sizeof(MgMgcoValRng),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPropParmNasOutDialNumValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasOutDialNumDefChcElmnts[] =
{
   &mgMgcoPropParmNasOutDialNumValEqDef,
   &mgMgcoPropParmNasOutDialNumValGtDef,
   &mgMgcoPropParmNasOutDialNumValLtDef,
   &mgMgcoPropParmNasOutDialNumValNeDef,
   &mgMgcoPropParmNasOutDialNumValAndDef,
   &mgMgcoPropParmNasOutDialNumValOrDef,
   &mgMgcoPropParmNasOutDialNumValRngDef
};

EXTERN CmAbnfElmDef *mgMgcoParmValDefChcEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasOutDialNumDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoPropParmNasOutDialNumDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutDialNumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasOutDialNum",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 192,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasOutDialNumDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmNasOutDialNumEnum =
{
   (Data *)"dialnum",
   MGT_PKG_NASOUT_PROP_DIALNUM
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutDialNumEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasOutDialNumEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 193,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmNasOutDialNumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmNasOutHandleEnum =
{
   (Data *)"handle",
   MGT_PKG_NASOUT_PROP_HANDLE
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutHandleEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasOutHandleEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 194,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmNasOutHandleEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasOutRealDefChcEnum[] =
{
   NULLP,
   &mgMgcoPropParmNasSessIdEnumDef, /* NOTE: not sure where to put these */
   &mgMgcoPropParmNasConnTypEnumDef,
   &mgMgcoPropParmNasOutDialNumEnumDef,
   &mgMgcoPropParmNasOutHandleEnumDef,
};

EXTERN CmAbnfElmDef mgMgcoParmValDef;

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasOutRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmNasSessIdDef,
   &mgMgcoPropParmNasConnTypDef,
   &mgMgcoPropParmNasOutDialNumDef,
   &mgMgcoParmValDef,   /* NOTE: handle is exactly the same as parmValue */
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasOutRealDefChc =
{
   5,
   0,
   NULLP,
   mgMgcoPropParmNasOutRealDefChcElmnts,
   mgMgcoPropParmNasOutRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutRealDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasOut",
   "PropParmNasOut",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 195,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasOutRealDefChc,
   mgMgcoRegExpPropParmNasOut
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasOutChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmSkipAllDef,
   &mgMgcoPropParmNasOutRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasOutChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoPropParmNasOutChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of property parameter in package NasOut",
   "PkgNasOutPropType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 196,
   sizeof(MgMgcoName) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasOutChcDefChc,
   mgMgcoRegExpPkgNasOutPropType 
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasOutDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoPropParmNasOutChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasOutDefSeq =
{
   3,
   mgMgcoPropParmNasOutDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasOutDef =
{
#ifdef CM_ABNF_DBG
   "Property parameter - package NasOut",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 197,
   sizeof(MgMgcoPropParm) - sizeof(TknU8),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasOutDefSeq,
   NULLP
};

/*****************************************************************************
                        nasout - no events
*****************************************************************************/

/*****************************************************************************
                        nasout - no signals 
*****************************************************************************/

/*****************************************************************************
                        nasout - no statistics
*****************************************************************************/

/*****************************************************************************
                        NAS Control Package (nasctl)
*****************************************************************************/

/*****************************************************************************
                        nasctl - no properties
*****************************************************************************/

/*****************************************************************************
                        nasctl - events
*****************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtOtherNasCtlCallReqDialNumEnum =
{
   (Data *)"dialnum",
   MGT_PKG_NASCTL_EVT_CALLREQ_DIALNUM
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherNasCtlCallReqDialNumEnumDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherNasCtlCallReqDialNumEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 198,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtOtherNasCtlCallReqDialNumEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtOtherNasCtlCallReqHandleEnum =
{
   (Data *)"handle",
   MGT_PKG_NASCTL_EVT_CALLREQ_HANDLE
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherNasCtlCallReqHandleEnumDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherNasCtlCallReqHandleEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 199,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtOtherNasCtlCallReqHandleEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasCtlCallReqParDefChcEnum[] =
{
   NULLP,
   &mgMgcoEvtOtherNasCtlCallReqDialNumEnumDef,
   &mgMgcoEvtOtherNasCtlCallReqHandleEnumDef,
};

EXTERN CmAbnfElmDef mgMgcoParmValDef;

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasCtlCallReqParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmNasOutDialNumDef,
   &mgMgcoParmValDef,   /* NOTE: handle is exactly the same as parmValue */
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasCtlCallReqParDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasCtlCallReqParDefChcElmnts,
   mgMgcoObsEvtOtherNasCtlCallReqParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasCtlCallReqParDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasCtlCallReqPar",
   "ObsEvtOtherNasCtlCallReqPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 200,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasCtlCallReqParDefChc,
   mgMgcoRegExpObsEvtOtherNasCtlCallReqPar
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNasCtlCallReqDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoObsEvtOtherNasCtlCallReqParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNasCtlCallReqDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtOtherNasCtlCallReqDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNasCtlCallReqDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNasCtlCallReq",
   "ObsEvtOtherNasCtlCallReqType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 201,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNasCtlCallReqDefChc,
   mgMgcoRegExpObsEvtOtherNasCtlCallReqType
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasCtlCallReqParmDefChcElmnts[] =
{
   NULLP, /* No ReqEvtOtherNasCtlCallReq */
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtNasCtlCallReqParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtNasCtlCallReqParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasCtlCallReqParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasCtlCallReq - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 202,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtNasCtlCallReqParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasCtlCallReqParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtNasCtlCallReqParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtNasCtlCallReqParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtNasCtlCallReqParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasCtlCallReqParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasCtlCallReq - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 203,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtNasCtlCallReqParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasCtlCallReqParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtNasCtlCallReqParmDef,
   &mgMgcoReqEvtNasCtlCallReqParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNasCtlCallReqParmLstDefSeq =
{
   2,
   mgMgcoReqEvtNasCtlCallReqParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasCtlCallReqParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasCtlCallReq - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 204,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtNasCtlCallReqParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasCtlCallReqDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtNasCtlCallReqParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNasCtlCallReqDefSeq =
{
   3,
   mgMgcoReqEvtNasCtlCallReqDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasCtlCallReqDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNasCtlCallReq - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 205,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtNasCtlCallReqDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasCtlCallReqParmDefChcElmnts[] =
{
   NULLP, /* No ReqEvtOtherNasCtlCallReq */
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecNasCtlCallReqParmDefChc =
{
   5,
   7,
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecNasCtlCallReqParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasCtlCallReqParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasCtlCallReq - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 206,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecNasCtlCallReqParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasCtlCallReqParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecNasCtlCallReqParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecNasCtlCallReqParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecNasCtlCallReqParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasCtlCallReqParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasCtlCallReq - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 207,
   sizeof(MgMgcoEvtParSecLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecNasCtlCallReqParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasCtlCallReqParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecNasCtlCallReqParmDef,
   &mgMgcoEvtSecNasCtlCallReqParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNasCtlCallReqParmLstDefSeq =
{
   2,
   mgMgcoEvtSecNasCtlCallReqParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasCtlCallReqParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasCtlCallReq - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 208,
   sizeof(MgMgcoEvtParSecLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecNasCtlCallReqParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasCtlCallReqDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecNasCtlCallReqParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNasCtlCallReqDefSeq =
{
   3,
   mgMgcoEvtSecNasCtlCallReqDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasCtlCallReqDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNasCtlCallReq - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 209,
   sizeof(MgMgcoEvtParSecLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecNasCtlCallReqDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasCtlCallReqParmDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherNasCtlCallReqDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecNasCtlCallReqParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecNasCtlCallReqParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasCtlCallReqParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasCtlCallReq - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 210,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecNasCtlCallReqParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasCtlCallReqParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecNasCtlCallReqParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecNasCtlCallReqParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecNasCtlCallReqParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasCtlCallReqParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasCtlCallReq - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 211,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecNasCtlCallReqParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasCtlCallReqParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecNasCtlCallReqParmDef,
   &mgMgcoEvSpecNasCtlCallReqParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNasCtlCallReqParmLstDefSeq =
{
   2,
   mgMgcoEvSpecNasCtlCallReqParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasCtlCallReqParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasCtlCallReq - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 212,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecNasCtlCallReqParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasCtlCallReqDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecNasCtlCallReqParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNasCtlCallReqDefSeq =
{
   3,
   mgMgcoEvSpecNasCtlCallReqDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasCtlCallReqDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNasCtlCallReq - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 213,
   sizeof(MgMgcoEvtParLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecNasCtlCallReqDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEventNasCtlCallReqEnum =
{
   (Data *)"callreq",
   MGT_PKG_NASCTL_EVT_CALLREQ
};

PUBLIC CmAbnfElmDef mgMgcoEventNasCtlCallReqEnumDef =
{
#ifdef CM_ABNF_DBG
   "EventNasCtlCallReqEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 214,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventNasCtlCallReqEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEventNasCtlRealDefChcEnum[] =
{
   NULLP,
   &mgMgcoEventNasCtlCallReqEnumDef,
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasCtlRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoReqEvtNasCtlCallReqDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtNasCtlRealDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoReqEvtNasCtlRealDefChcElmnts,
   mgMgcoEventNasCtlRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasCtlRealDef =
{
#ifdef CM_ABNF_DBG
   "Real requested event - package NasCtl",
   "EvtNameNasCtl",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 215,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtNasCtlRealDefChc,
   mgMgcoRegExpEvtNameNasCtl
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasCtlChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoReqEvtNasCtlRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtNasCtlChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtNasCtlChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasCtlChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of requested event in package NasCtl",
   "PkgNasCtlEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 216,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtNasCtlChcDefChc,
   mgMgcoRegExpPkgNasCtlEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNasCtlDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoReqEvtNasCtlChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNasCtlDefSeq =
{
   3,
   mgMgcoReqEvtNasCtlDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNasCtlDef =
{
#ifdef CM_ABNF_DBG
   "Requested event - package Nas",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 217,
   sizeof(MgMgcoReqEvt) - sizeof(TknU8),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtNasCtlDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasCtlRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtSecNasCtlCallReqDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecNasCtlRealDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvtSecNasCtlRealDefChcElmnts,
   mgMgcoEventNasCtlRealDefChcEnum
};


PUBLIC CmAbnfElmDef mgMgcoEvtSecNasCtlRealDef =
{
#ifdef CM_ABNF_DBG
   "Real second requested event - package NasCtl",
   "EvtNameNasCtl",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 218,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParSecLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecNasCtlRealDefChc,
   mgMgcoRegExpEvtNameNasCtl
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasCtlChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtSecSkipAllDef,
   &mgMgcoEvtSecNasCtlRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecNasCtlChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtSecNasCtlChcDefChcElmnts,
   mgMgcoGenTypeEnum 
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasCtlChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of second req event in package NasCtl",
   "PkgNasCtlEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 219,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecNasCtlChcDefChc,
   mgMgcoRegExpPkgNasCtlEvtType
};

/* Second requested event */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecNasCtlDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvtSecNasCtlChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNasCtlDefSeq =
{
   3,
   mgMgcoEvtSecNasCtlDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNasCtlDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - package Nas",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 220,
   sizeof(MgMgcoEvtSec) - sizeof(TknU8),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtSecNasCtlDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasCtlRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecNasCtlCallReqDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecNasCtlRealDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecNasCtlRealDefChcElmnts,
   mgMgcoEventNasCtlRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasCtlRealDef =
{
#ifdef CM_ABNF_DBG
   "Real event spec -  package NasCtl",
   "EvtNameNasCtl",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 221,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecNasCtlRealDefChc,
   mgMgcoRegExpEvtNameNasCtl
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasCtlChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoEvSpecNasCtlRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecNasCtlChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvSpecNasCtlChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasCtlChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of event spec in package NasCtl",
   "PkgNasCtlEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 222,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecNasCtlChcDefChc,
   mgMgcoRegExpPkgNasCtlEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNasCtlDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvSpecNasCtlChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNasCtlDefSeq =
{
   3,
   mgMgcoEvSpecNasCtlDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNasCtlDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - package Nas",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 223,
   sizeof(MgMgcoEvSpec) - sizeof(TknU8),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvSpecNasCtlDefSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtNasCtlRealDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecNasCtlRealDefChcElmnts,
   mgMgcoEventNasCtlRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtNasCtlRealDef =
{
#ifdef CM_ABNF_DBG
   "Real observed event - package NasCtl",
   "EvtNameNasCtl",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 224,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtNasCtlRealDefChc,
   mgMgcoRegExpEvtNameNasCtl
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtNasCtlChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoObsEvtNasCtlRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtNasCtlChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtNasCtlChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtNasCtlChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of observed event in package Nas",
   "PkgNasEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 225,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtNasCtlChcDefChc,
   mgMgcoRegExpPkgNasCtlEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtNasCtlDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoObsEvtNasCtlChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtNasCtlDefSeq =
{
   3,
   mgMgcoObsEvtNasCtlDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtNasCtlDef =
{
#ifdef CM_ABNF_DBG
   "Observed event - package Nas",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 226,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtNasCtlDefSeq,
   NULLP
};

/*****************************************************************************
                        nasctl - no signals 
*****************************************************************************/

/*****************************************************************************
                        nasctl - no statistics
*****************************************************************************/

/*****************************************************************************
                        NAS Root Package (nasroot)
*****************************************************************************/

/*****************************************************************************
                        nasroot - properties
*****************************************************************************/

EXTERN CmAbnfElmDef mgMgcoTermIdDef;

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNamPatValDefChcElmnts[] =
{
   NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP,
   &mgMgcoTermIdDef, NULLP,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasRootNamPatValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoPropParmNasRootNamPatValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNamPatValDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasRootNamPatVal",
   "ParmValTermId",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 227,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasRootNamPatValDefChc,
   mgMgcoRegExpParmValTermId
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoEQUALDef;

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNamPatValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoPropParmNasRootNamPatValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNamPatValEqDefSeq =
{
   2,
   mgMgcoPropParmNasRootNamPatValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNamPatValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 228,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootNamPatValEqDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoGREATERTHANDef;

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNamPatValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoPropParmNasRootNamPatValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNamPatValGtDefSeq =
{
   2,
   mgMgcoPropParmNasRootNamPatValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNamPatValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 229,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ, 
   (U8 *)&mgMgcoPropParmNasRootNamPatValGtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLESSTHANDef;

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNamPatValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoPropParmNasRootNamPatValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNamPatValLtDefSeq =
{
   2,
   mgMgcoPropParmNasRootNamPatValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNamPatValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 230,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootNamPatValLtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoNOTEQUALDef;

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNamPatValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoPropParmNasRootNamPatValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNamPatValNeDefSeq =
{
   2,
   mgMgcoPropParmNasRootNamPatValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNamPatValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 231,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootNamPatValNeDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoCOMMADef;

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNamPatValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoPropParmNasRootNamPatValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPropParmNasRootNamPatValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoPropParmNasRootNamPatValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNamPatValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 232,
   sizeof(MgMgcoValLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPropParmNasRootNamPatValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNamPatValLstDefSeqElmnts[]   =
{
   &mgMgcoPropParmNasRootNamPatValDef,
   &mgMgcoPropParmNasRootNamPatValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNamPatValLstDefSeq =
{
   2,
   mgMgcoPropParmNasRootNamPatValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNamPatValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 233,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPropParmNasRootNamPatValLstDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLSBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRSBRKTDef;

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNamPatValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasRootNamPatValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNamPatValAndDefSeq =
{
   4,
   mgMgcoPropParmNasRootNamPatValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNamPatValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 234,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootNamPatValAndDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRBRKTDef;

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNamPatValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoPropParmNasRootNamPatValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNamPatValOrDefSeq =
{
   4,
   mgMgcoPropParmNasRootNamPatValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNamPatValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 235,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootNamPatValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNamPatValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasRootNamPatValDef,
   &cmMsgDefMetaColon,
   &mgMgcoPropParmNasRootNamPatValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNamPatValRngDefSeq =
{
   6,
   mgMgcoPropParmNasRootNamPatValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNamPatValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 236,
   sizeof(MgMgcoValRng),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPropParmNasRootNamPatValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNamPatDefChcElmnts[] =
{
   &mgMgcoPropParmNasRootNamPatValEqDef,
   &mgMgcoPropParmNasRootNamPatValGtDef,
   &mgMgcoPropParmNasRootNamPatValLtDef,
   &mgMgcoPropParmNasRootNamPatValNeDef,
   &mgMgcoPropParmNasRootNamPatValAndDef,
   &mgMgcoPropParmNasRootNamPatValOrDef,
   &mgMgcoPropParmNasRootNamPatValRngDef
};

EXTERN CmAbnfElmDef *mgMgcoParmValDefChcEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasRootNamPatDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoPropParmNasRootNamPatDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNamPatDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasRootNamPat",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 237,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasRootNamPatDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootCtlNamValDefChcElmnts[] =
{
   NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, 
   &mgMgcoTermIdDef,
   NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasRootCtlNamValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoPropParmNasRootCtlNamValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootCtlNamValDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasRootCtlNamVal",
   "ParmValTermId",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 238,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasRootCtlNamValDefChc,
   mgMgcoRegExpParmValTermId
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoEQUALDef;

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootCtlNamValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoPropParmNasRootCtlNamValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootCtlNamValEqDefSeq =
{
   2,
   mgMgcoPropParmNasRootCtlNamValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootCtlNamValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 239,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootCtlNamValEqDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoGREATERTHANDef;

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootCtlNamValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoPropParmNasRootCtlNamValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootCtlNamValGtDefSeq =
{
   2,
   mgMgcoPropParmNasRootCtlNamValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootCtlNamValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 240,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoPropParmNasRootCtlNamValGtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLESSTHANDef;

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootCtlNamValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoPropParmNasRootCtlNamValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootCtlNamValLtDefSeq =
{
   2,
   mgMgcoPropParmNasRootCtlNamValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootCtlNamValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 241,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootCtlNamValLtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoNOTEQUALDef;

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootCtlNamValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoPropParmNasRootCtlNamValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootCtlNamValNeDefSeq =
{
   2,
   mgMgcoPropParmNasRootCtlNamValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootCtlNamValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 242,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootCtlNamValNeDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoCOMMADef;

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootCtlNamValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoPropParmNasRootCtlNamValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPropParmNasRootCtlNamValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoPropParmNasRootCtlNamValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootCtlNamValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 243,
   sizeof(MgMgcoValLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPropParmNasRootCtlNamValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootCtlNamValLstDefSeqElmnts[]   =
{
   &mgMgcoPropParmNasRootCtlNamValDef,
   &mgMgcoPropParmNasRootCtlNamValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootCtlNamValLstDefSeq =
{
   2,
   mgMgcoPropParmNasRootCtlNamValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootCtlNamValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 244,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPropParmNasRootCtlNamValLstDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLSBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRSBRKTDef;

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootCtlNamValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasRootCtlNamValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootCtlNamValAndDefSeq =
{
   4,
   mgMgcoPropParmNasRootCtlNamValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootCtlNamValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 245,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootCtlNamValAndDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRBRKTDef;

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootCtlNamValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoPropParmNasRootCtlNamValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootCtlNamValOrDefSeq =
{
   4,
   mgMgcoPropParmNasRootCtlNamValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootCtlNamValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 246,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootCtlNamValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootCtlNamValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasRootCtlNamValDef,
   &cmMsgDefMetaColon,
   &mgMgcoPropParmNasRootCtlNamValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootCtlNamValRngDefSeq =
{
   6,
   mgMgcoPropParmNasRootCtlNamValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootCtlNamValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 247,
   sizeof(MgMgcoValRng),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPropParmNasRootCtlNamValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootCtlNamDefChcElmnts[] =
{
   &mgMgcoPropParmNasRootCtlNamValEqDef,
   &mgMgcoPropParmNasRootCtlNamValGtDef,
   &mgMgcoPropParmNasRootCtlNamValLtDef,
   &mgMgcoPropParmNasRootCtlNamValNeDef,
   &mgMgcoPropParmNasRootCtlNamValAndDef,
   &mgMgcoPropParmNasRootCtlNamValOrDef,
   &mgMgcoPropParmNasRootCtlNamValRngDef
};

EXTERN CmAbnfElmDef *mgMgcoParmValDefChcEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasRootCtlNamDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoPropParmNasRootCtlNamDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootCtlNamDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasRootCtlNam",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 248,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasRootCtlNamDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMgcoPropParmNasRootAvalModemsValueRng =
   {1, 7, 0, (U32)9999999};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMgcoPropParmNasRootAvalModemsValueRng =
   {1, 7};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootAvalModemsValue =
{
#ifdef CM_ABNF_DBG
   "PropParmNasRootAvalModemsValue",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 249,
   sizeof(TknU32),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgcoPropParmNasRootAvalModemsValueRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootAvalModemsValDefChcElmnts[] =
{
   NULLP, 
   &mgMgcoPropParmNasRootAvalModemsValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasRootAvalModemsValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoPropParmNasRootAvalModemsValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootAvalModemsValDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasRootAvalModemsVal",
   "ParmValDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 250,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasRootAvalModemsValDefChc,
   mgMgcoRegExpParmValDecUint
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoEQUALDef;

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootAvalModemsValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoPropParmNasRootAvalModemsValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootAvalModemsValEqDefSeq =
{
   2,
   mgMgcoPropParmNasRootAvalModemsValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootAvalModemsValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 251,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootAvalModemsValEqDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoGREATERTHANDef;

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootAvalModemsValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoPropParmNasRootAvalModemsValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootAvalModemsValGtDefSeq =
{
   2,
   mgMgcoPropParmNasRootAvalModemsValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootAvalModemsValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 252,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoPropParmNasRootAvalModemsValGtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLESSTHANDef;

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootAvalModemsValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoPropParmNasRootAvalModemsValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootAvalModemsValLtDefSeq =
{
   2,
   mgMgcoPropParmNasRootAvalModemsValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootAvalModemsValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 253,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootAvalModemsValLtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoNOTEQUALDef;

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootAvalModemsValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoPropParmNasRootAvalModemsValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootAvalModemsValNeDefSeq =
{
   2,
   mgMgcoPropParmNasRootAvalModemsValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootAvalModemsValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 254,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootAvalModemsValNeDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoCOMMADef;

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootAvalModemsValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoPropParmNasRootAvalModemsValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPropParmNasRootAvalModemsValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoPropParmNasRootAvalModemsValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootAvalModemsValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 255,
   sizeof(MgMgcoValLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPropParmNasRootAvalModemsValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootAvalModemsValLstDefSeqElmnts[]   =
{
   &mgMgcoPropParmNasRootAvalModemsValDef,
   &mgMgcoPropParmNasRootAvalModemsValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootAvalModemsValLstDefSeq =
{
   2,
   mgMgcoPropParmNasRootAvalModemsValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootAvalModemsValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 256,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPropParmNasRootAvalModemsValLstDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLSBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRSBRKTDef;

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootAvalModemsValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasRootAvalModemsValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootAvalModemsValAndDefSeq =
{
   4,
   mgMgcoPropParmNasRootAvalModemsValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootAvalModemsValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 257,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootAvalModemsValAndDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRBRKTDef;

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootAvalModemsValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoPropParmNasRootAvalModemsValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootAvalModemsValOrDefSeq =
{
   4,
   mgMgcoPropParmNasRootAvalModemsValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootAvalModemsValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 258,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootAvalModemsValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootAvalModemsValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasRootAvalModemsValDef,
   &cmMsgDefMetaColon,
   &mgMgcoPropParmNasRootAvalModemsValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootAvalModemsValRngDefSeq =
{
   6,
   mgMgcoPropParmNasRootAvalModemsValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootAvalModemsValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 259,
   sizeof(MgMgcoValRng),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPropParmNasRootAvalModemsValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootAvalModemsDefChcElmnts[] =
{
   &mgMgcoPropParmNasRootAvalModemsValEqDef,
   &mgMgcoPropParmNasRootAvalModemsValGtDef,
   &mgMgcoPropParmNasRootAvalModemsValLtDef,
   &mgMgcoPropParmNasRootAvalModemsValNeDef,
   &mgMgcoPropParmNasRootAvalModemsValAndDef,
   &mgMgcoPropParmNasRootAvalModemsValOrDef,
   &mgMgcoPropParmNasRootAvalModemsValRngDef
};

EXTERN CmAbnfElmDef *mgMgcoParmValDefChcEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasRootAvalModemsDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoPropParmNasRootAvalModemsDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootAvalModemsDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasRootAvalModems",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 260,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasRootAvalModemsDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNasAddTimeValueDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasRootNasAddTimeValue",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 261,
   sizeof(TknU32),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgcoU32DefRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNasAddTimeValDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmNasRootNasAddTimeValueDef,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasRootNasAddTimeValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoPropParmNasRootNasAddTimeValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNasAddTimeValDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasRootNasAddTimeVal",
   "ParmValDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 262,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasRootNasAddTimeValDefChc,
   mgMgcoRegExpParmValDecUint
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoEQUALDef;

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNasAddTimeValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoPropParmNasRootNasAddTimeValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNasAddTimeValEqDefSeq =
{
   2,
   mgMgcoPropParmNasRootNasAddTimeValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNasAddTimeValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 263,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootNasAddTimeValEqDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoGREATERTHANDef;

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNasAddTimeValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoPropParmNasRootNasAddTimeValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNasAddTimeValGtDefSeq =
{
   2,
   mgMgcoPropParmNasRootNasAddTimeValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNasAddTimeValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 264,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,   
   (U8 *)&mgMgcoPropParmNasRootNasAddTimeValGtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLESSTHANDef;

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNasAddTimeValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoPropParmNasRootNasAddTimeValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNasAddTimeValLtDefSeq =
{
   2,
   mgMgcoPropParmNasRootNasAddTimeValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNasAddTimeValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 265,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootNasAddTimeValLtDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoNOTEQUALDef;

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNasAddTimeValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoPropParmNasRootNasAddTimeValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNasAddTimeValNeDefSeq =
{
   2,
   mgMgcoPropParmNasRootNasAddTimeValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNasAddTimeValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 266,
   sizeof(MgMgcoValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootNasAddTimeValNeDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoCOMMADef;

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNasAddTimeValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoPropParmNasRootNasAddTimeValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPropParmNasRootNasAddTimeValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoPropParmNasRootNasAddTimeValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNasAddTimeValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 267,
   sizeof(MgMgcoValLst),
   CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPropParmNasRootNasAddTimeValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNasAddTimeValLstDefSeqElmnts[]   =
{
   &mgMgcoPropParmNasRootNasAddTimeValDef,
   &mgMgcoPropParmNasRootNasAddTimeValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNasAddTimeValLstDefSeq =
{
   2,
   mgMgcoPropParmNasRootNasAddTimeValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNasAddTimeValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 268,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPropParmNasRootNasAddTimeValLstDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLSBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRSBRKTDef;

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNasAddTimeValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasRootNasAddTimeValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNasAddTimeValAndDefSeq =
{
   4,
   mgMgcoPropParmNasRootNasAddTimeValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNasAddTimeValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 269,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootNasAddTimeValAndDefSeq,
   NULLP
};

/************************************************************************/

EXTERN CmAbnfElmDef mgMgcoLBRKTDef;
EXTERN CmAbnfElmDef mgMgcoRBRKTDef;

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNasAddTimeValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoPropParmNasRootNasAddTimeValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNasAddTimeValOrDefSeq =
{
   4,
   mgMgcoPropParmNasRootNasAddTimeValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNasAddTimeValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 270,
   sizeof(MgMgcoValLst),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootNasAddTimeValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNasAddTimeValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNasRootNasAddTimeValDef,
   &cmMsgDefMetaColon,
   &mgMgcoPropParmNasRootNasAddTimeValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootNasAddTimeValRngDefSeq =
{
   6,
   mgMgcoPropParmNasRootNasAddTimeValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNasAddTimeValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 271,
   sizeof(MgMgcoValRng),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPropParmNasRootNasAddTimeValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootNasAddTimeDefChcElmnts[] =
{
   &mgMgcoPropParmNasRootNasAddTimeValEqDef,
   &mgMgcoPropParmNasRootNasAddTimeValGtDef,
   &mgMgcoPropParmNasRootNasAddTimeValLtDef,
   &mgMgcoPropParmNasRootNasAddTimeValNeDef,
   &mgMgcoPropParmNasRootNasAddTimeValAndDef,
   &mgMgcoPropParmNasRootNasAddTimeValOrDef,
   &mgMgcoPropParmNasRootNasAddTimeValRngDef
};

EXTERN CmAbnfElmDef *mgMgcoParmValDefChcEnum[];

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasRootNasAddTimeDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoPropParmNasRootNasAddTimeDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNasAddTimeDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasRootNasAddTime",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 272,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasRootNasAddTimeDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmNasRootNamPatEnum =
{
   (Data *)"nampat",
   MGT_PKG_NASROOT_PROP_NAMPAT
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNamPatEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasRootNamPatEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 273,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmNasRootNamPatEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmNasRootCtlNamEnum =
{
   (Data *)"ctlnam",
   MGT_PKG_NASROOT_PROP_CTLNAM
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootCtlNamEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasRootCtlNamEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 274,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmNasRootCtlNamEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmNasRootAvalModemsEnum =
{
   (Data *)"avalmodems",
   MGT_PKG_NASROOT_PROP_AVALMODEMS
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootAvalModemsEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasRootAvalModemsEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 275,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmNasRootAvalModemsEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmNasRootNasAddTimeEnum =
{
   (Data *)"nasaddtime",
   MGT_PKG_NASROOT_PROP_NASADDTIME
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootNasAddTimeEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasRootNasAddTimeEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 276,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmNasRootNasAddTimeEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootRealDefChcEnum[] =
{
   NULLP,
   &mgMgcoPropParmNasRootNamPatEnumDef,
   &mgMgcoPropParmNasRootCtlNamEnumDef,
   &mgMgcoPropParmNasRootAvalModemsEnumDef,
   &mgMgcoPropParmNasRootNasAddTimeEnumDef,
};
PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmNasRootNamPatDef,
   &mgMgcoPropParmNasRootCtlNamDef,
   &mgMgcoPropParmNasRootAvalModemsDef,
   &mgMgcoPropParmNasRootNasAddTimeDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasRootRealDefChc =
{
   5,
   0,
   NULLP,
   mgMgcoPropParmNasRootRealDefChcElmnts,
   mgMgcoPropParmNasRootRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootRealDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNasRoot",
   "PropParmNasRoot",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 277,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasRootRealDefChc,
   mgMgcoRegExpPropParmNasRoot
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootChcDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmSkipAllDef,
   &mgMgcoPropParmNasRootRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNasRootChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoPropParmNasRootChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of property parameter in package NasRoot",
   "PkgNasRootPropType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 278,
   sizeof(MgMgcoName) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNasRootChcDefChc,
   mgMgcoRegExpPkgNasRootPropType 
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNasRootDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoPropParmNasRootChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNasRootDefSeq =
{
   3,
   mgMgcoPropParmNasRootDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNasRootDef =
{
#ifdef CM_ABNF_DBG
   "Property parameter - package NasRoot",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1000 + 279,
   sizeof(MgMgcoPropParm) - sizeof(TknU8),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNasRootDefSeq,
   NULLP
};

/*****************************************************************************
                        nasroot - no events
*****************************************************************************/

/*****************************************************************************
                        nasroot - no signals 
*****************************************************************************/

/*****************************************************************************
                        nasroot - no statistics
*****************************************************************************/

#endif /* GCP_PKG_MGCO_NAS_SUPPORT */

#endif /* GCP_MGCO */

/********************************************************************30**

         End of file:     mgconasd.c@@/main/4 - Wed Mar 30 07:55:48 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      nct  1. Initial version
            mg001.102 nct  1. Changed GtDef type from SEQ to OPTSEQ.
/main/2      ---      ra   1. GCP 1.3 release
/main/3      ---      ka   1. Changes for Release v 1.4
/main/4      ---      pk   1. GCP 1.5 release
*********************************************************************91*/
