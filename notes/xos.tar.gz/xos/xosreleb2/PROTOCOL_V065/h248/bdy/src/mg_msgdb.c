/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
 
     Name:     MGCP - Message Paramter Database module
 
     Type:     C source file
  
     Desc:     C Source Code for Co-ordinator Module
 
     File:     mg_msgdb.c
  
     Sid:      mg_msgdb.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:51:47 2005
  
     Prg:      bbk
  
*********************************************************************21*/
 
/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*
*/
 
/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*    
*   
*
*/

 
/*
 * The core of MGC product is implemented in following files:
 *
 *    mg_dns.c      DNS Interaction functions 
 *    mg_tmr.c      Timer Management/Maintenance functions
 *    mg_tpt.c      Transport Layer Interaction functions
 *    mg_trans.c    Transaction Management functions
 *    mg_cord.c     Co-ordinator Module functions
 *    mg_ui.c       MGCP Upper Interface Functions
 *    mg_mi.c       MGCP Layer Management Interface
 *    mg_li.c       MGCP Lower Layer (TUCL) Interface
 *    cm_tenc.c     Common Text Based Encode Engine for MGCP messages
 *    cm_tdec.c     Common Text Based Decode Engine for MGCP messages
 */


/* header include files (.h) */
#include "envopt.h"        /* Environment options */  
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */

#ifdef MG

#include "gen.h"           /* General layer */
#include "ssi.h"           /* System services */
#include "mgt.h"           /* MGT Interface Defines */
#include "mg.h"            /* MGCP Defines */

/* header/extern include files (.x) */


/* local defines, if any */
 
/* local typedefs, if any */
 
/* local externs, if any */

/* forward references */

/* public variable declaration */

/* private variable declaration */

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

PUBLIC U8 mgNmbMandPerCmd[MG_MAX_MGCP_PROFILES][MG_MAX_MGCP_MSGS]= 
{
   /* Profile RFC 2705 */
   {
      0,              /* Non Standard Message */
      /* EPCF has no mandatory params according to BIS */
      0,              /* EPCF Command */
      2,              /* CRCX Command */
      2,              /* MDCX Command */
      0,              /* DLCX Command */
      1,              /* RQNT Command */
      2,              /* NTFY Command */
      /* AUEP has no mandatory parameters */
      0,              /* AUEP Command */
      2,              /* AUCX Command */
      1,              /* RSIP Command */
#ifdef GCP_PKG_MGCP_BASE
      0,              /* MESG Command */
#endif /* GCP_PKG_MGCP_BASE */
   },

   /* Profile NCS 1.0 */
   {
      0,              /* Non Standard Message */
      0,              /* EPCF Command */
      3,              /* CRCX Command */
      2,              /* MDCX Command */
      0,              /* DLCX Command */
      1,              /* RQNT Command */
      2,              /* NTFY Command */
      0,              /* AUEP Command */
      1,              /* AUCX Command */
      1,              /* RSIP Command */
#ifdef GCP_PKG_MGCP_BASE
      0,              /* MESG Command */
#endif /* GCP_PKG_MGCP_BASE */
   },

   /* Profile TGCP 1.0 */
   {
      0,              /* Non Standard Message */
      0,              /* EPCF Command */
      3,              /* CRCX Command */
      2,              /* MDCX Command */
      0,              /* DLCX Command */
      1,              /* RQNT Command */
      2,              /* NTFY Command */
      0,              /* AUEP Command */
      1,              /* AUCX Command */
      1,              /* RSIP Command */
#ifdef GCP_PKG_MGCP_BASE
      0,              /* MESG Command */
#endif /* GCP_PKG_MGCP_BASE */
   },
};

PUBLIC U8 mgCmdDb[MG_MAX_MGCP_PROFILES][MG_MAX_MGCP_MSGS][MG_MAX_MGCP_PARAMS]=
{
   /* Profile RFC 2705 */
   {
      /* Non Standard Message - NONSTD */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X     */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K     */
         MG_OPTIONAL_PARM,                /* Bearer Information      - B     */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C     */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I     */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N     */
         MG_OPTIONAL_PARM,                /* Request Identifier      - X     */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L     */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M     */
         MG_OPTIONAL_PARM,                /* Requested Events        - R     */
         MG_OPTIONAL_PARM,                /* Signal Request          - S     */
         MG_OPTIONAL_PARM,                /* Digit Map               - D     */
         MG_OPTIONAL_PARM,                /* Observed Events         - O     */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P     */
         MG_OPTIONAL_PARM,                /* Reason Code             - E     */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z     */
         MG_OPTIONAL_PARM,                /* Second Endpoint Id      - Z2    */
         MG_OPTIONAL_PARM,                /* Second Connection Id    - I2    */
         MG_OPTIONAL_PARM,                /* Requested Information   - F     */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q     */
         MG_OPTIONAL_PARM,                /* Restart Method          - RM    */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD    */
         MG_OPTIONAL_PARM,                /* Detect Events           - T     */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A     */
         MG_FORBIDDEN_PARM,               /* Event States            - ES    */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Endpoint Configuration Message - EPCF */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         /* 
          * BearerInfo is optional for EPCF acording to BIS 
          */
         MG_OPTIONAL_PARM,                /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Create Connection Message - CRCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_OPTIONAL_PARM,                /* Bearer Information      - B  */
         MG_MANDATORY_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_CONDITIONAL_PARM,             /* Request Identifier      - X  */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L  */
         MG_MANDATORY_PARM,               /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_OPTIONAL_PARM,                /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_OPTIONAL_PARM,                /* Second Endpoint Id      - Z2 */
         MG_OPTIONAL_PARM,                /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Modify Connection Message - MDCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_OPTIONAL_PARM,                /* Bearer Information      - B  */
         MG_MANDATORY_PARM,               /* Call Identifier         - C  */
         MG_MANDATORY_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_CONDITIONAL_PARM,             /* Request Identifier      - X  */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L  */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_OPTIONAL_PARM,                /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Delete Connection Message - DLCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_OPTIONAL_PARM,                /* Bearer Information      - B  */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C  */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_CONDITIONAL_PARM,             /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_OPTIONAL_PARM,                /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P  */
         MG_OPTIONAL_PARM,                /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Notify Request Message - RQNT */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_OPTIONAL_PARM,                /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_MANDATORY_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_OPTIONAL_PARM,                /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Notify Message - NTFY */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_MANDATORY_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_MANDATORY_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Audit Endpoint Message - AUEP */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_OPTIONAL_PARM,                /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Audit Connection Message - AUCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_MANDATORY_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_MANDATORY_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Restart In Progress Message - RSIP */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_OPTIONAL_PARM,                /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_MANDATORY_PARM,               /* Restart Method          - RM */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

#ifdef GCP_PKG_MGCP_BASE
      /* Message - MESG */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X     */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K     */
         MG_OPTIONAL_PARM,                /* Bearer Information      - B     */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C     */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I     */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N     */
         MG_OPTIONAL_PARM,                /* Request Identifier      - X     */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L     */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M     */
         MG_OPTIONAL_PARM,                /* Requested Events        - R     */
         MG_OPTIONAL_PARM,                /* Signal Request          - S     */
         MG_OPTIONAL_PARM,                /* Digit Map               - D     */
         MG_OPTIONAL_PARM,                /* Observed Events         - O     */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P     */
         MG_OPTIONAL_PARM,                /* Reason Code             - E     */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z     */
         MG_OPTIONAL_PARM,                /* Second Endpoint Id      - Z2    */
         MG_OPTIONAL_PARM,                /* Second Connection Id    - I2    */
         MG_OPTIONAL_PARM,                /* Requested Information   - F     */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q     */
         MG_OPTIONAL_PARM,                /* Restart Method          - RM    */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD    */
         MG_OPTIONAL_PARM,                /* Detect Events           - T     */
         MG_OPTIONAL_PARM,                /* Capabilities            - A     */
         MG_OPTIONAL_PARM,                /* Event States            - ES    */
         MG_OPTIONAL_PARM,                /* Maximum EndpointIds     - ZM    */
         MG_OPTIONAL_PARM,                /* Number of EndpointIds   - ZN    */
         MG_OPTIONAL_PARM,                /* Resource Id             - DQ-RI */
         MG_OPTIONAL_PARM,                /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_OPTIONAL_PARM,                /* Max MGCP Datagram       - MD    */
#endif
      },
#endif /* GCP_PKG_MGCP_BASE */

   },

   /* Profile NCS 1.0 */
   {
      /* Non Standard Message - NONSTD */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X     */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K     */
         MG_OPTIONAL_PARM,                /* Bearer Information      - B     */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C     */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I     */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N     */
         MG_OPTIONAL_PARM,                /* Request Identifier      - X     */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L     */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M     */
         MG_OPTIONAL_PARM,                /* Requested Events        - R     */
         MG_OPTIONAL_PARM,                /* Signal Request          - S     */
         MG_OPTIONAL_PARM,                /* Digit Map               - D     */
         MG_OPTIONAL_PARM,                /* Observed Events         - O     */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P     */
         MG_OPTIONAL_PARM,                /* Reason Code             - E     */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z     */
         MG_OPTIONAL_PARM,                /* Second Endpoint Id      - Z2    */
         MG_OPTIONAL_PARM,                /* Second Connection Id    - I2    */
         MG_OPTIONAL_PARM,                /* Requested Information   - F     */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q     */
         MG_OPTIONAL_PARM,                /* Restart Method          - RM    */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD    */
         MG_OPTIONAL_PARM,                /* Detect Events           - T     */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A     */
         MG_FORBIDDEN_PARM,               /* Event States            - ES    */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Endpoint Configuration Message - EPCF */
      {
         MG_FORBIDDEN_PARM,               /* Non Standard Parameter  - X  */
         MG_FORBIDDEN_PARM,               /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Create Connection Message - CRCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_MANDATORY_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_CONDITIONAL_PARM,             /* Request Identifier      - X  */
         MG_MANDATORY_PARM,               /* Local Connection Option - L  */
         MG_MANDATORY_PARM,               /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_OPTIONAL_PARM,                /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Modify Connection Message - MDCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_MANDATORY_PARM,               /* Call Identifier         - C  */
         MG_MANDATORY_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_CONDITIONAL_PARM,             /* Request Identifier      - X  */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L  */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_OPTIONAL_PARM,                /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Delete Connection Message - DLCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C  */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_CONDITIONAL_PARM,             /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_OPTIONAL_PARM,                /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P  */
         MG_OPTIONAL_PARM,                /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Notify Request Message - RQNT */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_MANDATORY_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_OPTIONAL_PARM,                /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Notify Message - NTFY */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_MANDATORY_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_MANDATORY_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Audit Endpoint Message - AUEP */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_OPTIONAL_PARM,                /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_OPTIONAL_PARM,                /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Audit Connection Message - AUCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_MANDATORY_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_OPTIONAL_PARM,                /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Restart In Progress Message - RSIP */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_MANDATORY_PARM,               /* Restart Method          - RM */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

#ifdef GCP_PKG_MGCP_BASE
      /* Message - MESG */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X     */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K     */
         MG_OPTIONAL_PARM,                /* Bearer Information      - B     */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C     */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I     */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N     */
         MG_OPTIONAL_PARM,                /* Request Identifier      - X     */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L     */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M     */
         MG_OPTIONAL_PARM,                /* Requested Events        - R     */
         MG_OPTIONAL_PARM,                /* Signal Request          - S     */
         MG_OPTIONAL_PARM,                /* Digit Map               - D     */
         MG_OPTIONAL_PARM,                /* Observed Events         - O     */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P     */
         MG_OPTIONAL_PARM,                /* Reason Code             - E     */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z     */
         MG_OPTIONAL_PARM,                /* Second Endpoint Id      - Z2    */
         MG_OPTIONAL_PARM,                /* Second Connection Id    - I2    */
         MG_OPTIONAL_PARM,                /* Requested Information   - F     */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q     */
         MG_OPTIONAL_PARM,                /* Restart Method          - RM    */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD    */
         MG_OPTIONAL_PARM,                /* Detect Events           - T     */
         MG_OPTIONAL_PARM,                /* Capabilities            - A     */
         MG_OPTIONAL_PARM,                /* Event States            - ES    */
         MG_OPTIONAL_PARM,                /* Maximum EndpointIds     - ZM    */
         MG_OPTIONAL_PARM,                /* Number of EndpointIds   - ZN    */
         MG_OPTIONAL_PARM,                /* Resource Id             - DQ-RI */
         MG_OPTIONAL_PARM,                /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_OPTIONAL_PARM,                /* Max MGCP Datagram       - MD    */
#endif
      },
#endif /* GCP_PKG_MGCP_BASE */

   },

   /* Profile TGCP 1.0 */
   {
      /* Non Standard Message - NONSTD */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X     */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K     */
         MG_OPTIONAL_PARM,                /* Bearer Information      - B     */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C     */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I     */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N     */
         MG_OPTIONAL_PARM,                /* Request Identifier      - X     */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L     */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M     */
         MG_OPTIONAL_PARM,                /* Requested Events        - R     */
         MG_OPTIONAL_PARM,                /* Signal Request          - S     */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D     */
         MG_OPTIONAL_PARM,                /* Observed Events         - O     */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P     */
         MG_OPTIONAL_PARM,                /* Reason Code             - E     */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z     */
         MG_OPTIONAL_PARM,                /* Second Endpoint Id      - Z2    */
         MG_OPTIONAL_PARM,                /* Second Connection Id    - I2    */
         MG_OPTIONAL_PARM,                /* Requested Information   - F     */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q     */
         MG_OPTIONAL_PARM,                /* Restart Method          - RM    */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD    */
         MG_OPTIONAL_PARM,                /* Detect Events           - T     */
         MG_OPTIONAL_PARM,                /* Capabilities            - A     */
         MG_OPTIONAL_PARM,                /* Event States            - ES    */
         MG_OPTIONAL_PARM,                /* Maximum EndpointIds     - ZM    */
         MG_OPTIONAL_PARM,                /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_OPTIONAL_PARM,                /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Endpoint Configuration Message - EPCF */
      {
         MG_FORBIDDEN_PARM,               /* Non Standard Parameter  - X  */
         MG_FORBIDDEN_PARM,               /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Create Connection Message - CRCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_MANDATORY_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_CONDITIONAL_PARM,             /* Request Identifier      - X  */
         MG_MANDATORY_PARM,               /* Local Connection Option - L  */
         MG_MANDATORY_PARM,               /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Modify Connection Message - MDCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_MANDATORY_PARM,               /* Call Identifier         - C  */
         MG_MANDATORY_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_CONDITIONAL_PARM,             /* Request Identifier      - X  */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L  */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Delete Connection Message - DLCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C  */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_CONDITIONAL_PARM,             /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P  */
         MG_OPTIONAL_PARM,                /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Notify Request Message - RQNT */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_MANDATORY_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Notify Message - NTFY */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_MANDATORY_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_MANDATORY_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Audit Endpoint Message - AUEP */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_OPTIONAL_PARM,                /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_OPTIONAL_PARM,                /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Audit Connection Message - AUCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_MANDATORY_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_OPTIONAL_PARM,                /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Restart In Progress Message - RSIP */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_MANDATORY_PARM,               /* Restart Method          - RM */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_FORBIDDEN_PARM,               /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

#ifdef GCP_PKG_MGCP_BASE
      /* Message - MESG */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X     */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K     */
         MG_OPTIONAL_PARM,                /* Bearer Information      - B     */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C     */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I     */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N     */
         MG_OPTIONAL_PARM,                /* Request Identifier      - X     */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L     */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M     */
         MG_OPTIONAL_PARM,                /* Requested Events        - R     */
         MG_OPTIONAL_PARM,                /* Signal Request          - S     */
         MG_OPTIONAL_PARM,                /* Digit Map               - D     */
         MG_OPTIONAL_PARM,                /* Observed Events         - O     */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P     */
         MG_OPTIONAL_PARM,                /* Reason Code             - E     */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z     */
         MG_OPTIONAL_PARM,                /* Second Endpoint Id      - Z2    */
         MG_OPTIONAL_PARM,                /* Second Connection Id    - I2    */
         MG_OPTIONAL_PARM,                /* Requested Information   - F     */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q     */
         MG_OPTIONAL_PARM,                /* Restart Method          - RM    */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD    */
         MG_OPTIONAL_PARM,                /* Detect Events           - T     */
         MG_OPTIONAL_PARM,                /* Capabilities            - A     */
         MG_OPTIONAL_PARM,                /* Event States            - ES    */
         MG_OPTIONAL_PARM,                /* Maximum EndpointIds     - ZM    */
         MG_OPTIONAL_PARM,                /* Number of EndpointIds   - ZN    */
         MG_OPTIONAL_PARM,                /* Resource Id             - DQ-RI */
         MG_OPTIONAL_PARM,                /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_OPTIONAL_PARM,                /* Max MGCP Datagram       - MD    */
#endif
      },
#endif /* GCP_PKG_MGCP_BASE */

   },
};

PUBLIC U8 mgRspDb[MG_MAX_MGCP_PROFILES][MG_MAX_MGCP_MSGS][MG_MAX_MGCP_PARAMS]=
{
   /* Profile RFC 2705 */
   {
      /* Non Standard Message Respone  - NONSTD */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_OPTIONAL_PARM,                /* Bearer Information      - B  */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C  */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_OPTIONAL_PARM,                /* Request Identifier      - X  */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L  */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_OPTIONAL_PARM,                /* Digit Map               - D  */
         MG_OPTIONAL_PARM,                /* Observed Events         - O  */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P  */
         MG_OPTIONAL_PARM,                /* Reason Code             - E  */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z  */
         MG_OPTIONAL_PARM,                /* Second Endpoint Id      - Z2 */
         MG_OPTIONAL_PARM,                /* Second Connection Id    - I2 */
         MG_OPTIONAL_PARM,                /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_OPTIONAL_PARM,                /* Restart Method          - RM */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_OPTIONAL_PARM,                /* Capabilities            - A  */
         MG_OPTIONAL_PARM,                /* Event States            - ES  */
         MG_OPTIONAL_PARM,                /* Maximum EndpointIds     - ZM    */
         MG_OPTIONAL_PARM,                /* Number of EndpointIds   - ZN    */
         MG_OPTIONAL_PARM,                /* Resource Id             - DQ-RI */
         MG_OPTIONAL_PARM,                /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Endpoint Configuration Message - EPCF */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
/*
 * changed
 */
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
#else         
         MG_FORBIDDEN_PARM,               /* Response Acknowledement - K  */
#endif
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Create Connection Message - CRCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
/*
 * changed
 */
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
#else         
         MG_FORBIDDEN_PARM,               /* Response Acknowledement - K  */
#endif
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_CONDITIONAL_PARM,             /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z  */
         MG_OPTIONAL_PARM,                /* Second Endpoint Id      - Z2 */
         MG_OPTIONAL_PARM,                /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Modify Connection Message - MDCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
/*
 * changed
 */
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
#else         
         MG_FORBIDDEN_PARM,               /* Response Acknowledement - K  */
#endif
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Delete Connection Message - DLCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
/*
 * changed
 */
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
#else         
         MG_FORBIDDEN_PARM,               /* Response Acknowledement - K  */
#endif
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_CONDITIONAL_PARM,             /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Requested Notify Message - RQNT */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
/*
 * changed
 */
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
#else         
         MG_FORBIDDEN_PARM,               /* Response Acknowledement - K  */
#endif
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Notify Message - NTFY */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
/*
 * changed
 */
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
#else         
         MG_FORBIDDEN_PARM,               /* Response Acknowledement - K  */
#endif
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Audit Endpoint Message - AUEP */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
/*
 * changed
 */
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
#else         
         MG_FORBIDDEN_PARM,               /* Response Acknowledement - K  */
#endif
         MG_OPTIONAL_PARM,                /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I  */
         /*
          * NotifiedEntity has been made optional parameter in RFC 2705 BIS
          */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_OPTIONAL_PARM,                /* Request Identifier      - X  */
         /*
          * LocalConnectionOptions are forbidden according to BIS 
          */
         MG_FORBIDDEN_PARM,                /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_OPTIONAL_PARM,                /* Digit Map               - D  */
         MG_OPTIONAL_PARM,                /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_OPTIONAL_PARM,                /* Reason Code             - E  */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_OPTIONAL_PARM,                /* Restart Method          - RM */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_OPTIONAL_PARM,                /* Capabilities            - A  */
         MG_OPTIONAL_PARM,                /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_OPTIONAL_PARM,                /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Audit Connection Message - AUCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
/*
 * changed
 */
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
#else         
         MG_FORBIDDEN_PARM,               /* Response Acknowledement - K  */
#endif
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         /*
          * NotifiedEntity has been made optional parameter in RFC 2705 BIS
          */
         MG_OPTIONAL_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L  */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to RSIP Message - RSIP */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
/*
 * changed
 */
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
#else         
         MG_FORBIDDEN_PARM,               /* Response Acknowledement - K  */
#endif
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

#ifdef GCP_PKG_MGCP_BASE
      /* Message - MESG */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X     */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K     */
         MG_OPTIONAL_PARM,                /* Bearer Information      - B     */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C     */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I     */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N     */
         MG_OPTIONAL_PARM,                /* Request Identifier      - X     */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L     */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M     */
         MG_OPTIONAL_PARM,                /* Requested Events        - R     */
         MG_OPTIONAL_PARM,                /* Signal Request          - S     */
         MG_OPTIONAL_PARM,                /* Digit Map               - D     */
         MG_OPTIONAL_PARM,                /* Observed Events         - O     */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P     */
         MG_OPTIONAL_PARM,                /* Reason Code             - E     */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z     */
         MG_OPTIONAL_PARM,                /* Second Endpoint Id      - Z2    */
         MG_OPTIONAL_PARM,                /* Second Connection Id    - I2    */
         MG_OPTIONAL_PARM,                /* Requested Information   - F     */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q     */
         MG_OPTIONAL_PARM,                /* Restart Method          - RM    */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD    */
         MG_OPTIONAL_PARM,                /* Detect Events           - T     */
         MG_OPTIONAL_PARM,                /* Capabilities            - A     */
         MG_OPTIONAL_PARM,                /* Event States            - ES    */
         MG_OPTIONAL_PARM,                /* Maximum EndpointIds     - ZM    */
         MG_OPTIONAL_PARM,                /* Number of EndpointIds   - ZN    */
         MG_OPTIONAL_PARM,                /* Resource Id             - DQ-RI */
         MG_OPTIONAL_PARM,                /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_OPTIONAL_PARM,                /* Max MGCP Datagram       - MD    */
#endif
      },
#endif /* GCP_PKG_MGCP_BASE */

   },

   /* Profile NCS 1.0 */
   {
      /* Non Standard Message Respone  - NONSTD */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C  */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_OPTIONAL_PARM,                /* Request Identifier      - X  */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L  */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_OPTIONAL_PARM,                /* Digit Map               - D  */
         MG_OPTIONAL_PARM,                /* Observed Events         - O  */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P  */
         MG_OPTIONAL_PARM,                /* Reason Code             - E  */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z  */
         MG_OPTIONAL_PARM,                /* Second Endpoint Id      - Z2 */
         MG_OPTIONAL_PARM,                /* Second Connection Id    - I2 */
         MG_OPTIONAL_PARM,                /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_OPTIONAL_PARM,                /* Restart Method          - RM */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_OPTIONAL_PARM,                /* Capabilities            - A  */
         MG_OPTIONAL_PARM,                /* Event States            - ES  */
         MG_OPTIONAL_PARM,                /* Maximum EndpointIds     - ZM    */
         MG_OPTIONAL_PARM,                /* Number of EndpointIds   - ZN    */
         MG_OPTIONAL_PARM,                /* Resource Id             - DQ-RI */
         MG_OPTIONAL_PARM,                /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Endpoint Configuration Message - EPCF */
      {
         MG_FORBIDDEN_PARM,               /* Non Standard Parameter  - X  */
         MG_FORBIDDEN_PARM,               /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Create Connection Message - CRCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_CONDITIONAL_PARM,             /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_OPTIONAL_PARM,                /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Modify Connection Message - MDCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_OPTIONAL_PARM,                /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Delete Connection Message - DLCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_CONDITIONAL_PARM,             /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Requested Notify Message - RQNT */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Notify Message - NTFY */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Audit Endpoint Message - AUEP */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_OPTIONAL_PARM,                /* Request Identifier      - X  */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_OPTIONAL_PARM,                /* Digit Map               - D  */
         MG_OPTIONAL_PARM,                /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_OPTIONAL_PARM,                /* Capabilities            - A  */
         MG_OPTIONAL_PARM,                /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_OPTIONAL_PARM,                /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_OPTIONAL_PARM,                /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_OPTIONAL_PARM,                /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Audit Connection Message - AUCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L  */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to RSIP Message - RSIP */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_OPTIONAL_PARM,                /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

#ifdef GCP_PKG_MGCP_BASE
      /* Message - MESG */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X     */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K     */
         MG_OPTIONAL_PARM,                /* Bearer Information      - B     */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C     */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I     */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N     */
         MG_OPTIONAL_PARM,                /* Request Identifier      - X     */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L     */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M     */
         MG_OPTIONAL_PARM,                /* Requested Events        - R     */
         MG_OPTIONAL_PARM,                /* Signal Request          - S     */
         MG_OPTIONAL_PARM,                /* Digit Map               - D     */
         MG_OPTIONAL_PARM,                /* Observed Events         - O     */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P     */
         MG_OPTIONAL_PARM,                /* Reason Code             - E     */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z     */
         MG_OPTIONAL_PARM,                /* Second Endpoint Id      - Z2    */
         MG_OPTIONAL_PARM,                /* Second Connection Id    - I2    */
         MG_OPTIONAL_PARM,                /* Requested Information   - F     */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q     */
         MG_OPTIONAL_PARM,                /* Restart Method          - RM    */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD    */
         MG_OPTIONAL_PARM,                /* Detect Events           - T     */
         MG_OPTIONAL_PARM,                /* Capabilities            - A     */
         MG_OPTIONAL_PARM,                /* Event States            - ES    */
         MG_OPTIONAL_PARM,                /* Maximum EndpointIds     - ZM    */
         MG_OPTIONAL_PARM,                /* Number of EndpointIds   - ZN    */
         MG_OPTIONAL_PARM,                /* Resource Id             - DQ-RI */
         MG_OPTIONAL_PARM,                /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_OPTIONAL_PARM,                /* Max MGCP Datagram       - MD    */
#endif
      },
#endif /* GCP_PKG_MGCP_BASE */

   },

   /* Profile TGCP 1.0 */
   {
      /* Non Standard Message Respone  - NONSTD */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C  */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_OPTIONAL_PARM,                /* Request Identifier      - X  */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L  */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_OPTIONAL_PARM,                /* Observed Events         - O  */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P  */
         MG_OPTIONAL_PARM,                /* Reason Code             - E  */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z  */
         MG_OPTIONAL_PARM,                /* Second Endpoint Id      - Z2 */
         MG_OPTIONAL_PARM,                /* Second Connection Id    - I2 */
         MG_OPTIONAL_PARM,                /* Requested Information   - F  */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q  */
         MG_OPTIONAL_PARM,                /* Restart Method          - RM */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_OPTIONAL_PARM,                /* Capabilities            - A  */
         MG_OPTIONAL_PARM,                /* Event States            - ES  */
         MG_OPTIONAL_PARM,                /* Maximum EndpointIds     - ZM    */
         MG_OPTIONAL_PARM,                /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_OPTIONAL_PARM,                /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Endpoint Configuration Message - EPCF */
      {
         MG_FORBIDDEN_PARM,               /* Non Standard Parameter  - X  */
         MG_FORBIDDEN_PARM,               /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Create Connection Message - CRCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_CONDITIONAL_PARM,             /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Modify Connection Message - MDCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Delete Connection Message - DLCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_CONDITIONAL_PARM,             /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Requested Notify Message - RQNT */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Notify Message - NTFY */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_FORBIDDEN_PARM,               /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Audit Endpoint Message - AUEP */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_OPTIONAL_PARM,                /* Request Identifier      - X  */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_OPTIONAL_PARM,                /* Requested Events        - R  */
         MG_OPTIONAL_PARM,                /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_OPTIONAL_PARM,                /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_OPTIONAL_PARM,                /* Detect Events           - T  */
         MG_OPTIONAL_PARM,                /* Capabilities            - A  */
         MG_OPTIONAL_PARM,                /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_OPTIONAL_PARM,                /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_OPTIONAL_PARM,                /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_OPTIONAL_PARM,                /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to Audit Connection Message - AUCX */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L  */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_FORBIDDEN_PARM,               /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

      /* Response to RSIP Message - RSIP */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X  */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K  */
         MG_FORBIDDEN_PARM,               /* Bearer Information      - B  */
         MG_FORBIDDEN_PARM,               /* Call Identifier         - C  */
         MG_FORBIDDEN_PARM,               /* Connection Identifier   - I  */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N  */
         MG_FORBIDDEN_PARM,               /* Request Identifier      - X  */
         MG_FORBIDDEN_PARM,               /* Local Connection Option - L  */
         MG_FORBIDDEN_PARM,               /* Connection Mode         - M  */
         MG_FORBIDDEN_PARM,               /* Requested Events        - R  */
         MG_FORBIDDEN_PARM,               /* Signal Request          - S  */
         MG_FORBIDDEN_PARM,               /* Digit Map               - D  */
         MG_FORBIDDEN_PARM,               /* Observed Events         - O  */
         MG_FORBIDDEN_PARM,               /* Connection Parameters   - P  */
         MG_FORBIDDEN_PARM,               /* Reason Code             - E  */
         MG_FORBIDDEN_PARM,               /* Specific Endpoint Id    - Z  */
         MG_FORBIDDEN_PARM,               /* Second Endpoint Id      - Z2 */
         MG_FORBIDDEN_PARM,               /* Second Connection Id    - I2 */
         MG_FORBIDDEN_PARM,               /* Requested Information   - F  */
         MG_FORBIDDEN_PARM,               /* Quarantine Handling     - Q  */
         MG_FORBIDDEN_PARM,               /* Restart Method          - RM */
         MG_FORBIDDEN_PARM,               /* Restart Delay           - RD */
         MG_FORBIDDEN_PARM,               /* Detect Events           - T  */
         MG_FORBIDDEN_PARM,               /* Capabilities            - A  */
         MG_FORBIDDEN_PARM,               /* Event States            - ES  */
         MG_FORBIDDEN_PARM,               /* Maximum EndpointIds     - ZM    */
         MG_FORBIDDEN_PARM,               /* Number of EndpointIds   - ZN    */
         MG_FORBIDDEN_PARM,               /* Resource Id             - DQ-RI */
         MG_OPTIONAL_PARM,                /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_FORBIDDEN_PARM,               /* Max MGCP Datagram       - MD    */
#endif
      },

#ifdef GCP_PKG_MGCP_BASE
      /* Message - MESG */
      {
         MG_OPTIONAL_PARM,                /* Non Standard Parameter  - X     */
         MG_OPTIONAL_PARM,                /* Response Acknowledement - K     */
         MG_OPTIONAL_PARM,                /* Bearer Information      - B     */
         MG_OPTIONAL_PARM,                /* Call Identifier         - C     */
         MG_OPTIONAL_PARM,                /* Connection Identifier   - I     */
         MG_OPTIONAL_PARM,                /* Notified Entity         - N     */
         MG_OPTIONAL_PARM,                /* Request Identifier      - X     */
         MG_OPTIONAL_PARM,                /* Local Connection Option - L     */
         MG_OPTIONAL_PARM,                /* Connection Mode         - M     */
         MG_OPTIONAL_PARM,                /* Requested Events        - R     */
         MG_OPTIONAL_PARM,                /* Signal Request          - S     */
         MG_OPTIONAL_PARM,                /* Digit Map               - D     */
         MG_OPTIONAL_PARM,                /* Observed Events         - O     */
         MG_OPTIONAL_PARM,                /* Connection Parameters   - P     */
         MG_OPTIONAL_PARM,                /* Reason Code             - E     */
         MG_OPTIONAL_PARM,                /* Specific Endpoint Id    - Z     */
         MG_OPTIONAL_PARM,                /* Second Endpoint Id      - Z2    */
         MG_OPTIONAL_PARM,                /* Second Connection Id    - I2    */
         MG_OPTIONAL_PARM,                /* Requested Information   - F     */
         MG_OPTIONAL_PARM,                /* Quarantine Handling     - Q     */
         MG_OPTIONAL_PARM,                /* Restart Method          - RM    */
         MG_OPTIONAL_PARM,                /* Restart Delay           - RD    */
         MG_OPTIONAL_PARM,                /* Detect Events           - T     */
         MG_OPTIONAL_PARM,                /* Capabilities            - A     */
         MG_OPTIONAL_PARM,                /* Event States            - ES    */
         MG_OPTIONAL_PARM,                /* Maximum EndpointIds     - ZM    */
         MG_OPTIONAL_PARM,                /* Number of EndpointIds   - ZN    */
         MG_OPTIONAL_PARM,                /* Resource Id             - DQ-RI */
         MG_OPTIONAL_PARM,                /* Version Supported       - VS    */
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         MG_OPTIONAL_PARM,                /* Package List            - PL    */
         MG_OPTIONAL_PARM,                /* Max MGCP Datagram       - MD    */
#endif
      },
#endif /* GCP_PKG_MGCP_BASE */

   },
};

#ifdef __cplusplus
}
#endif /* _cplusplus */

#endif /* ifdef MG */

/********************************************************************30**
 
         End of file:     mg_msgdb.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:51:47 2005
 
*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      bbk  1. Initial release.
1.2          ---      bbk  1. Fixed C++ compilation warnings
1.2+         mg006.101bbk  1. In response to a DLCX command, the 
                              connection parameters are conditionally
                              optional as they are mandatory only on
                              MG side sending a response
/main/3      ---      dw   1. Release 1.2
             mg004.102bbk  1. Changed paramter matrices to reflect that
                              AUEP Command has no mandatory parameters
                           2. AUEP Response for RFC 2705 had specific 
                              endpointId and connectionId as forbidden. It 
                              should be optional. The table in specs has error
             mg006.102 vj  1. Changed parameter matrices to reflect that EPCF 
                              has no mandatory parameters.
                           2. BearerInfo is optional for EPCF acording to BIS 
                           3. NotifiedEntity is optional in AUEP response 
                              & AUCX response
                           4. LocalConnectionOptions are forbidden for AUEP 
                              response
/main/4      ---      ra   1. GCP 1.3 release
            mg011.103 ra   1. Bug fixes. Changed the following -
                              -----------------------------------
                              #ifdef GCP_VER_1_3
                              #ifdef GCP_2705BIS
                                          MG_OPTIONAL_PARM,
                              #else
                                          MG_FORBIDDEN_PARM,
                              #endif
                              #endif
                              -----------------------------------
                              to the following -
                              -----------------------------------
                              #if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
                                          MG_OPTIONAL_PARM,
                              #else         
                                          MG_FORBIDDEN_PARM,
                              #endif
                              -----------------------------------
                              The old style left holes in the database
                              in case neither of the flags - GCP_VER_1_3
                              and GCP_2705BIS was defined.
/main/5      ---      ka   1. Changes for Release v 1.4 
/main/6      ---      pk   1. GCP 1.5 release
            mg002.105 ps   1. Removed patch reference for 1.3 
*********************************************************************91*/
