/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     Mg encode decode wrapper
  
     Type:     C Source file
  
     Desc:     C source code for Mg encode decode wrapper
  
     File:     mwrap.c
  
     Sid:      mgasnwrp.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 20 13:46:36 2005
  
     Prg:      
  
*********************************************************************21*/


/************************************************************************
 

************************************************************************/
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#ifdef GCP_ASN

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tkns.h"       /* common token structures */
#include "cm_mblk.h"       /* common event memory management */
#include "cm_tpt.h"        /* TPT header file */
#include "cm_dns.h"        /* DNS header file */

#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */

#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#include "cm_abnf.h"       /* ABNF header file */
#include "cm_sdp.h"        /* SDP header file */
#include "mgt.h"           /* ABNF events header file */
#include "mg_asn.h"        /* ABNF header file */
#include "mgasndb1.h"       /* ASN.1 database */
#include "mgasndb2.h"      /* ASN.1 database tree */
#include "mgasnwrp.h"         /* Encode/Decode wrappers */
#include "cm_hash.h"
#include "cm_llist.h"
#include "lmg.h"           /* layer management defines for MGCP */
#include "lhi.h"
#include "mg.h"

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"          /* system services */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* common event memory management */
#include "cm_lib.x"        /* common structures */
#include "cm_tpt.x"        /* TPT structures */
#include "cm_dns.x"        /* DNS structures */

#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */

#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#include "cm_sdp.x"        /* SDP structures */
#include "cm_abnf.x"       /* ABNF structures */
#include "mg_asn.x"        /* ASN.1 structures */
#include "mg_db.x"
#include "mgco_db.x"       /* ABNF database */
#include "mgasnev.x"       /* ASN.1 events */
#include "mgasndb1.x"       /* ASN.1 database */
#include "mgasndb2.x"      /* ASN.1 database tree */
#include "mgt.x"           /* ABNF events */
#include "mgasnwrp.x"         /* Encode/Decode wrappers */
#include "cm_hash.x"
#include "cm_llist.x"
#ifdef GCP_PROV_MTP3
#include "cm_ss7.x"    
#endif
#ifdef GCP_PROV_SCTP
#include "sct.h"           /* layer management typedefs for MGCP */
#include "sct.x"           /* layer management typedefs for MGCP */
#endif
#include "lmg.x"           /* layer management typedefs for MGCP */
#include "lhi.x"
#include "mg.x"
#include "ssi.x"

#ifdef MG_ASN_DBTEST
PRIVATE S16 mgTest ARGS ((U32 protVar, U8 *event, S32 txnIndx, S32 elmDef, Mem* memReg, CmMemListCp *memCp));
#endif
PUBLIC Void mwrapErrMap ARGS((CmAbnfErr *err, MgAsnErr *asnErr));
PUBLIC S16 mgGetLen ARGS((U32 *lenVal, Buffer *mBuf, U32 indx, MsgLen totLen));
PUBLIC S16 mgUpdateLen ARGS((U32 len, MgAsnMsgCp *msgCp, U32 indx));



EXTERN  CmAbnfElmDef  mgMgcoMsgBodyDef;
EXTERN  CmAbnfElmDef  mgMgcoAuthHdrMsgDef;
PRIVATE CmAbnfElmDef *abnfDefs [] = {
#ifdef GCP_MGCP  
   &mgMsgDef,               /* MGED_MGCP */
#endif
   &mgMgcoAuthHdrMsgDef,    /* MGED_MEGACO */
   &mgMgcoAuthHdrDef,       /* MGED_AUTHHDR */
   &mgMgcoTxnDef,           /* MGED_TXN_ENC */
   &mgMgcoTxnDef,           /* MGED_TXN0_ENC */
   &mgMgcoTxnDef,           /* MGED_TXN_DEC */
   &mgMgcoTxnDef,           /* MGED_TXN0_DEC */
   &mgMgcoMsgHdrDef,        /* MGED_HDR_ENC */
   &mgMgcoMsgHdrDef,        /* MGED_HDR_DEC */
   &mgMgcoErrDescDef,       /* MGED_ERRDESC */
   &mgMgcoMsgBodyDef        /* MGED_BODY */
};
PRIVATE MgAsnElmntDef **asnDefs [] = {
   NULLP,                   /* MGED_MGCP */
   mgaMegaco,               /* MGED_MEGACO */
   mgaAuthenticationHeader, /* MGED_AUTHHDR */
   mgaTransaction,          /* MGED_TXN_ENC */
   mgaTransaction0,         /* MGED_TXN0_ENC */
   mgaTransaction,          /* MGED_TXN_DEC */
   mgaTransaction,          /* MGED_TXN0_DEC */
   mgaHeaderEncode,         /* MGED_HDR_ENC */
   mgaHeaderDecode,         /* MGED_HDR_DEC */
   mgaErrDesc,              /* MGED_ERRDESC */
   mgaMessageBody           /* MGED_BODY */
};



/*
*
*       Fun:   mgInitMsgDb 
*
*       Desc:  Initialize message database
*
*       Ret:   ROK  (encoding successful)
*              RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  mwrap.c
*
*/
#ifdef ANSI
PUBLIC S16 mgInitMsgDb (void)
#else
PUBLIC S16 mgInitMsgDb ()
#endif
{
   static S16 first = 1;
   S16           ret;
 

   TRC2(mgInitMsgDb)

   /* Run once */
   if (!first) { RETVALUE(ROK); }
   first = 0;

   /* initialize */
   if ((ret = mgAsnInitMsgDb(mgaMegaco)) != ROK) { RETVALUE(ret); }
   if ((ret = mgAsnInitMsgDb(mgaAuthenticationHeader)) != ROK) { RETVALUE(ret); }
   if ((ret = mgAsnInitMsgDb(mgaMessageBody)) != ROK) { RETVALUE(ret); }
   mgaMessageBody[0]->tag = MG_ASN_CONSTRUCTOR_TAG_BASE + 2; /* MessageBody */
   mgaMessageBody[5]->tag = MG_ASN_CONSTRUCTOR_TAG_BASE + 1; /* NullSpecial */
   if ((ret = mgAsnInitMsgDb(mgaHeaderDecode)) != ROK) { RETVALUE(ret); }
   mgaHeaderDecode[0]->tag = MG_ASN_CONSTRUCTOR_TAG_BASE + 1; /* Message */
   if ((ret = mgAsnInitMsgDb(mgaHeaderEncode)) != ROK) { RETVALUE(ret); }
   if ((ret = mgAsnInitMsgDb(mgaTransaction0)) != ROK) { RETVALUE(ret); }
   mgaTransaction0[0]->tag = MG_ASN_CONSTRUCTOR_TAG_BASE + 2; /* MessageBody */
   if ((ret = mgAsnInitMsgDb(mgaTransaction)) != ROK) { RETVALUE(ret); }
   mgaTransaction[0]->tag = MG_ASN_UCHOICE; /* Transaction */
   if ((ret = mgAsnInitMsgDb(mgaErrDesc)) != ROK) { RETVALUE(ret); }
   mgaErrDesc[0]->tag = MG_ASN_CONSTRUCTOR_TAG_BASE + 2; /* MessageBody */

   RETVALUE(ret);
}


/*
*
*       Fun:   mgEncPduMsg 
*
*       Desc:  Encode message wrapper
*
*       Ret:   CM_ABNF_ROK  (encoding successful)
*              CM_ABNF_RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  mwrap.c
*
*/
#ifdef ANSI
PUBLIC S16 mgEncPduMsg 
(
U32           protVar,    /* protocol and variant */
U8            *event,     /* pointer to the event structure */
U32           txnIndx,    /* transaction index to encode or 0 for all*/
Buffer        *mBuf,      /* Message buffer */
S32           elmDef,     /* message defintion */
Mem           *memReg,    /* Memory: region/pool */
CmAbnfErr     *err        /* error to be returned back to the caller */ 
)
#else
PUBLIC S16 mgEncPduMsg (protVar, event, txnIndx, mBuf, elmDef, memReg,  err)
U32           protVar;    /* protocol and variant */
U8            *event;     /* pointer to the event structure */
U32           txnIndx;    /* transaction index to encode or 0 for all */
Buffer        *mBuf;      /* Message buffer */
S32           elmDef;     /* message defintion */
Mem           *memReg;    /* Memory: region/pool */
CmAbnfErr     *err;       /* error to be returned back to the caller */ 
#endif
{
   S16          ret;     /* return value */
   CmMemListCp  *memCp;
#ifdef MG_WRAP_ASN1_ENCDEC
   MgAsnErr      asnErr;
#endif
   U8*           saveEvent;


   TRC2(mgEncPduMsg)
   saveEvent = event;
   memCp = (CmMemListCp*)event;
   (void)cmMemset((U8*)err, 0, sizeof(CmAbnfErr));

   /* Reset event pointer to part of message to encode */
   /* mg002.105: Removed compilation warning */
   event = (U8*)mwrapEvntGet((PTR)event, MG_WRAP_ENC_TYPE, (U16)elmDef, txnIndx);

   /* Encode */

#ifdef MG_ASN_DBTEST
   if (mgTest(protVar, saveEvent, txnIndx, elmDef, memReg, memCp) != ROK)
   {
      RETVALUE(RFAILED);
   }
#endif

   /* Initialize and call encoder */
#ifdef MG_WRAP_ASN1_ENCDEC
   (void)mgInitMsgDb();
   (void)cmMemset((U8*)&asnErr, 0, sizeof(MgAsnErr));
   /* mg002.105: Removed compilation warning */
   if ((ret = mgAsnEncMsg((TknU8*)event, mBuf, protVar, (MgAsnElmntDef**)mwrapElmDefGet(MG_WRAP_ASN, (U16)elmDef, txnIndx), memReg->region, memReg->pool, &asnErr)) != ROK) {
      mwrapErrMap(err, &asnErr);
   }
#else
   ret = cmAbnfEncPduMsg(protVar, event, mBuf, (CmAbnfElmDef*)mwrapElmDefGet(MG_WRAP_ABNF, elmDef, txnIndx), memReg, err);
#endif

   RETVALUE(ret);
} /* mgEncPduMsg */



/*
*
*       Fun:   mwrapErrMap 
*
*       Desc:  Get the element definition
*
*       Ret:   ROK  (encoding successful)
*              RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  mwrap.c
*
*/
#ifdef ANSI
PUBLIC Void mwrapErrMap 
(
CmAbnfErr          *err,    /* ABNF error */
MgAsnErr           *asnErr  /* ASN.1 error */
)
#else
PUBLIC Void mwrapErrMap (err, asnErr)
CmAbnfErr          *err;    /* ABNF error */
MgAsnErr           *asnErr; /* ASN.1 error */
#endif
{
   TRC2(mwrapErrMap)

   err->code = asnErr->code;
   err->idNum = asnErr->idNum;
#ifdef MG_ASN_DBG
   if (err->code != ROK) {
      S8 errorString[1024];
      S8 errorBuf[1024];
      mwrapErrPrint((CmAbnfErr*)asnErr, errorString);
      (void)sprintf(errorBuf, "ERROR: %s on %s at %s:%d\n", errorString, asnErr->strPtr, asnErr->file, (int)asnErr->line);
      SPrint(errorBuf);
   }
#endif
   RETVOID;
}


/*
*
*       Fun:   mwrapEvntGet 
*
*       Desc:  Get the element definition
*
*       Ret:   ROK  (encoding successful)
*              RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  mwrap.c
*
*/
#ifdef ANSI
PUBLIC PTR mwrapEvntGet 
(
PTR           event,      /* event */
U16           encType,    /* encoding type */
U16           elmDef,     /* message defintion */
U32           txnIndx     /* transaction index */
)
#else
PUBLIC PTR mwrapEvntGet (event, encType, elmDef, txnIndx)
PTR           event;      /* event */
U16           encType;    /* encoding type */
U16           elmDef;     /* message defintion */
U32           txnIndx;    /* transaction index */
#endif
{
   TRC2(mwrapEvntGet)
   /* switch for first transaction */
   if ((txnIndx == 0) && (elmDef == MGED_TXN_ENC)) {
      elmDef = MGED_TXN0_ENC;
   }
   if ((txnIndx == 0) && (elmDef == MGED_TXN_DEC)) {
      elmDef = MGED_TXN0_DEC;
   }

   switch (elmDef) {
#ifdef GCP_MGCP     
   case MGED_MGCP:
      RETVALUE((PTR)&(((MgMgcpMsg*)event)->msgType));
      break;
#endif      
   case MGED_AUTHHDR:
      if (encType == MG_WRAP_ASN) {
         RETVALUE((PTR)&(((MgMgcoMsg*)event)->pres));
      } else {
         RETVALUE((PTR)&(((MgMgcoMsg*)event)->ah));
      }
      break;
   case MGED_TXN_ENC:
      if (encType == MG_WRAP_ASN) {
         RETVALUE((PTR) (((MgMgcoMsg*)event)->body.u.tl.txns[txnIndx]));
      } else {
         RETVALUE((PTR) &(((MgMgcoMsg*)event)->body.u.tl.txns[txnIndx]->type));
      }
      break;
   case MGED_TXN0_ENC:
      if (encType == MG_WRAP_ASN) {
         RETVALUE((PTR) &( ((MgMgcoMsg*)event)->body));
      } else {
         RETVALUE((PTR) &(((MgMgcoMsg*)event)->body.u.tl.txns[txnIndx]->type));
      }
      break;
   case MGED_TXN_DEC:
      if (encType == MG_WRAP_ASN) {
         RETVALUE((PTR) (((MgMgcoMsg*)event)->body.u.tl.txns[txnIndx]));
      } else {
         RETVALUE((PTR) &(((MgMgcoMsg*)event)->body.u.tl.txns[txnIndx]->type));
      }
      break;
   case MGED_TXN0_DEC:
      if (encType == MG_WRAP_ASN) {
         RETVALUE((PTR) (((MgMgcoMsg*)event)->body.u.tl.txns[txnIndx]));
      } else {
         RETVALUE((PTR) &(((MgMgcoMsg*)event)->body.u.tl.txns[txnIndx]->type));
      }
      break;
   case MGED_BODY:
      RETVALUE((PTR) &(((MgMgcoMsg*) event)->body));
      break;
   case MGED_HDR_ENC:
      if (encType == MG_WRAP_ASN) {
         RETVALUE((PTR) &(((MgMgcoMsg*) event)->pres));
      } else {
         RETVALUE((PTR) &(((MgMgcoMsg*) event)->ver));
      }
      break;
   case MGED_HDR_DEC:
      RETVALUE((PTR) &(((MgMgcoMsg*) event)->ver));
      break;
   case MGED_MEGACO:
      RETVALUE((PTR) &(((MgMgcoMsg*) event)->pres));
      break;
   case MGED_ERRDESC:
      if (encType == MG_WRAP_ASN) {
         RETVALUE((PTR) &( ((MgMgcoMsg*)event)->body));
      } else {
         RETVALUE((PTR) &( ((MgMgcoMsg*)event)->body.u.err));
      }
      break;
   }
   RETVALUE(NULLP);
}


/*
*
*       Fun:   mwrapElmDefGet 
*
*       Desc:  Get the element definition
*
*       Ret:   ROK  (encoding successful)
*              RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  mwrap.c
*
*/
#ifdef ANSI
PUBLIC PTR mwrapElmDefGet 
(
U16           encType,    /* encoding type */
U16           elmDef,     /* message defintion */
U32           txnIndx     /* transaction index */
)
#else
PUBLIC PTR mwrapElmDefGet (encType, elmDef, txnIndx)
U16           encType;    /* encoding type */
U16           elmDef;     /* message defintion */
U32           txnIndx;    /* transaction index */
#endif
{
   TRC2(mwrapElmDefGet)

   if ((txnIndx == 0) && (elmDef == MGED_TXN_ENC)) {
      elmDef = MGED_TXN0_ENC;
   }
   if ((txnIndx == 0) && (elmDef == MGED_TXN_DEC)) {
      elmDef = MGED_TXN0_DEC;
   }
   if (encType == MG_WRAP_ABNF) {
      RETVALUE((PTR)(abnfDefs[elmDef]));
   }
   RETVALUE((PTR)(asnDefs[elmDef]));
}

#ifdef MG_ASN_TEST

/*
*
*       Fun:   mwrapElmDefPrint 
*
*       Desc:  Do mapping for event
*
*       Ret:   ROK  (encoding successful)
*              RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  mwrap.c
*
*/
#ifdef ANSI
PUBLIC S8* mwrapElmDefPrint 
(
U16           elmDef      /* message defintion */
)
#else
PUBLIC S8* mwrapElmDefPrint (elmDef)
U16           elmDef;     /* message defintion */
#endif
{
   static S8 *elmDefNames[] = {"MGED_MGCP", "MGED_MEGACO", "MGED_AUTHHDR", "MGED_TXN_ENC", "MGED_TXN0_ENC", "MGED_TXN_DEC", "MGED_TXN0_DEC", "MGED_HDR_ENC", "MGED_HDR_DEC", "MGED_ERRDESC", "MGED_BODY"};

   TRC2(mwrapElmDefPrint)
   RETVALUE(elmDefNames[elmDef]);
}
#endif



/*
*
*       Fun:   mgGetLen 
*
*       Desc:  Get length field starting at index in mbuf
*
*       Ret:   Number of bytes that length is
*
*       Notes: None 
*
*       File:  mwrap.c
*
*/
#ifdef ANSI
PUBLIC S16 mgGetLen 
(
U32           *lenVal,   /* length to be populated */
Buffer        *mBuf,     /* Message buffer */
U32           indx,      /* protocol and variant */
MsgLen        totLen     /* totalLength of mbuf */
)
#else
PUBLIC S16 mgGetLen (lenVal, mBuf, indx, totLen)
U32           *lenVal;
Buffer        *mBuf;      /* Message buffer */
U32           indx;    /* protocol and variant */
MsgLen        totLen;
#endif
{
   S16 retSizeLen = 0;
   Data  tmpOctet;
   short j;

   *lenVal = 0;
   /* mg002.105: Removed compilation warning */
   if(indx >= (U32)totLen) {
      return(-1);
   }
   /* mg002.105: Removed compilation warning */
   if( SExamMsg(&tmpOctet, mBuf, (MsgLen)indx) != ROK ){ return(-1); }
   if(tmpOctet < EOC_FLAG) {
      /* Single byte length */
      retSizeLen = 1;
      *lenVal = tmpOctet;
   } else {
      retSizeLen = (U8)(tmpOctet & ~EOC_FLAG);
      if(retSizeLen > MAX_LEN_BYTES || retSizeLen > sizeof(U32)) { 
         return(-1); 
      }
      /* length is contained in the next "retsizeLen" octets" */
      for(j = 1; j <= retSizeLen; ++j) {
         /* mg002.105: Removed compilation warning */
         if(SExamMsg(&tmpOctet, mBuf, (MsgLen)(indx + j)) != ROK) {return(-1);}
         *lenVal = *lenVal << 8 | tmpOctet;
      }
      ++retSizeLen;  /* add one for the lenlen */
   }

   return(retSizeLen);
}

/*
*
*       Fun:   mgUpdateLen
*
*       Desc:  Update lenfield at index with value.  Shift
*              data if needed
*
*       Ret:   Number of octets that were added due to
*              shifting
*
*       Notes: None 
*
*       File:  mwrap.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUpdateLen
(
U32             len,    /* length to be populated */
MgAsnMsgCp      *msgCp,         /* message control point */
U32             indx      /* protocol and variant */
)
#else
PUBLIC S16 mgUpdateLen (len, msgCp, indx)
U32            len;
MgAsnMsgCp     *msgCp;         /* message control point */
U32            indx;      /* protocol and variant */
#endif
{
   S16 retAdded = 0;
   U32 curLen = 0;
   U32 curLenLen = 0;
   U8  lenLen = 0;
   U8 tmpOctet;
   /* mg005.105: fix for the Big endian */
   MsgLen tmpIndex;
   /* mg002.105: Removed compilation warning */
   U32 j;
   
   /* figure out current length attributes */
   /* mg002.105: Removed compilation warning */
   if(SExamMsg(&tmpOctet, msgCp->mBuf, (MsgLen)indx) != ROK) { return(-1); }
   
   if(tmpOctet < EOC_FLAG) {
      curLen = tmpOctet;
      curLenLen = 1;
   } else {
      curLenLen = (U8)(tmpOctet & ~EOC_FLAG);
      for(j = 1; j <= curLenLen; ++j) {
         /* mg002.105: Removed compilation warning */
         if(SExamMsg(&tmpOctet, msgCp->mBuf, (MsgLen)(indx + j)) != ROK) { return(-1);}
         curLen = curLen << 8 | tmpOctet;
      }
      ++curLenLen;  /* add one for lenlen */
   }

   if((lenLen = mgAsnFindNumOctets(len)) <= 0) { return(-1); }
   if(lenLen == curLenLen) {
      if(lenLen == 1) {
         tmpOctet = 0xff & len;
         /* mg002.105: Removed compilation warning */
         if(SRepMsg(tmpOctet, msgCp->mBuf, (MsgLen)indx) != ROK) {return(-1);}
      } else {
         tmpOctet = (lenLen - 1) | EOC_FLAG;
         if(SRepMsg(tmpOctet, msgCp->mBuf, (MsgLen)indx) != ROK) { return(-1); }
         for(j = lenLen - 1; j > 0; --j) {
            tmpOctet = 0xff & len;
            if(SRepMsg(tmpOctet, msgCp->mBuf, (MsgLen)(indx+j)) != ROK) { return(-1); }
            len = len >> 8;
         }
      }
   } else if(lenLen > curLenLen) {
      retAdded = lenLen - curLenLen;
      /* add space and slide data down */
      tmpIndex = indx;
      if(mgAsnEncSlide(msgCp, (MsgLen*)&tmpIndex, retAdded) != ROK) { 
         return(-1);
      }
      /* put the new length in */
      tmpOctet = (lenLen - 1) | EOC_FLAG;
      /* mg002.105: Removed compilation warning */
      if(SRepMsg(tmpOctet, msgCp->mBuf, (MsgLen)indx) != ROK) { return(-1); }
      for(j = lenLen - 1; j > 0; --j) {
         tmpOctet = 0xff & len;
         if(SRepMsg(tmpOctet, msgCp->mBuf, (MsgLen)(indx + j)) != ROK) { return(-1); }
         len = len >> 8;
      }
   } else {
      /* no support of shrinkage */
      return(-1);
   } 

   return(retAdded);
}


/*
*
*       Fun:   mgPrepSend 
*
*       Desc:  Testing function
*
*       Ret:   ROK  (encoding successful)
*              RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  mwrap.c
*
*/
#ifdef ANSI
PUBLIC S16 mgPrepSend 
(
U32           protVar,    /* protocol and variant */
Buffer        *mBuf,      /* Message buffer */
CmMemListCp   *memCp      /* memory list control block */
)
#else
PUBLIC S16 mgPrepSend (protVar, mBuf, memCp)
U32           protVar;    /* protocol and variant */
Buffer        *mBuf;      /* Message buffer */
CmMemListCp   *memCp;     /* memory list control block */
#endif
{
   MgAsnMsgCp   msgCp;         /* message control point */
   MgAsnErr     err;           /* error to be returned back to the caller */
   U32          mgcoMsgLen = 0;     
   S16          mgcoMsgLenLen = 0;
   U32          newMgcoMsgLen = 0;
   U32          authHdrLen = 0;
   S16          authHdrLenLen = 0;
   U32          msgLen = 0;   
   U32          msgLenIndex = 0;
   S16          msgLenLen = 0;
   U32          newMsgLen = 0;
   U32          msgBodyLen = 0;  
   U32          msgBodyLenIndex = 0;
   S16          msgBodyLenLen = 0;
   U32      newMsgBodyLen = 0;
   U32      versionLen = 0;
   U32          mIdLen = 0;
   MsgLen       mbufLen = 0;
   S16          tmpLenLen = 0;        /* length length */
   U32          tmpIndex = 0;
   U8           tmpTag = 0;        /* temp tag */
   S16      shiftAmount1;
   S16      shiftAmount2;


   TRC2(mgPrepSend)

   /* check protocol variant */
   if ((protVar != CM_ABNF_PROT_MEGACO_H248) && (protVar != CM_ABNF_PROT_MEGACO_H248_V2))
   {
      RETVALUE(ROK);
   }
#ifndef MG_WRAP_ASN1_ENCDEC
   if (1) { RETVALUE(ROK); }
#endif

   /* initialize */
   (Void) mgAsnInitAsnMsgCp(&msgCp);
   (Void)cmMemset((U8*)&err, 0, sizeof(err));
   msgCp.mBuf    = mBuf;   /* pointer to the allocated message buffer */
   msgCp.elmntDef = mgaHeaderEncode;      /* message defintion */
   msgCp.memCp   = memCp;       /* mem region/pool */
   msgCp.region  = memCp->memCb.sMem.region; /* region for the memory */
   msgCp.pool    = memCp->memCb.sMem.pool;   /* pool for the memory */
   msgCp.err     = &err;         /* switch for unrecoggnized elements */

   mbufLen = mgAsnFindLen(&msgCp);

   /* check for message tag */
   if ( SExamMsg (&tmpTag, msgCp.mBuf, 0) != ROK)
   {
      MG_ASN_ERR((&msgCp), MG_ASN_TAG_ERR);
      RETVALUE(RFAILED); 
   }
          
   /* compare tag */
   if (tmpTag != gcMsgMegacoMessage.tag)
   {
      /* mg008.105: Corrected the return value if tags are not same */
      RETVALUE(RFAILED);
   }

   /* read megaco message length */
   mgcoMsgLenLen = mgGetLen(&mgcoMsgLen, msgCp.mBuf, 1, mbufLen);
   if(mgcoMsgLenLen == -1) {
      RETVALUE(RFAILED);
   }
   if (mgcoMsgLenLen == mbufLen) {
      RETVALUE(ROK);
   }

   /* see if there's an auth header and adjust where msg is*/
   tmpIndex = mgcoMsgLenLen + 1;
   if (mgcoMsgLen > tmpIndex) {
      /* mg002.105: Removed compilation warning */
      if ( SExamMsg (&tmpTag, msgCp.mBuf, (MsgLen)tmpIndex) != ROK)
      {
         MG_ASN_ERR((&msgCp), MG_ASN_TAG_ERR);
         RETVALUE(RFAILED);
      }
      if(tmpTag == gcMsgAuthenticationHeaderO.tag) {
         authHdrLenLen = mgGetLen(&authHdrLen, msgCp.mBuf, tmpIndex + 1, mbufLen);
         if(authHdrLenLen == -1) {
            RETVALUE(RFAILED);
         }
         msgLenIndex = authHdrLenLen + authHdrLen + mgcoMsgLenLen + 3;
      } else {
        msgLenIndex = mgcoMsgLenLen + 2;
      }
   } else {
      MG_ASN_ERR((&msgCp), MG_ASN_TAG_ERR);
      RETVALUE(RFAILED);
   }

   /* Get lenght of Message part */
   /* mg002.105: Removed compilation warning */
   if(msgLenIndex >= (U32)mbufLen ) {
      MG_ASN_ERR((&msgCp), MG_ASN_TAG_ERR);
      RETVALUE(RFAILED);
   } else {
      msgLenLen = mgGetLen(&msgLen, msgCp.mBuf, msgLenIndex, mbufLen);
      if(msgLenLen == -1) {
         RETVALUE(RFAILED);
      }
   }

   /* Message Body  - skip past version and mId*/
   tmpIndex = msgLenIndex  + msgLenLen  + 1;    /* version len index*/
   tmpLenLen = mgGetLen(&versionLen, msgCp.mBuf, tmpIndex, mbufLen);
   if(tmpLenLen == -1) {
      RETVALUE(RFAILED);
   }

   tmpIndex = tmpIndex + tmpLenLen + versionLen + 1;  /* mId len index*/
   tmpLenLen = mgGetLen(&mIdLen, msgCp.mBuf, tmpIndex, mbufLen);
   if(tmpLenLen == -1) {
      RETVALUE(RFAILED);
   }
   
   msgBodyLenIndex = tmpIndex + tmpLenLen + mIdLen + 1;
   tmpIndex = msgBodyLenIndex - 1;
   /* mg002.105: Removed compilation warning */
   if(tmpIndex < (U32)mbufLen) {
      /* one quick sanity */
      /* mg002.105: Removed compilation warning */
      if ( SExamMsg (&tmpTag, msgCp.mBuf, (MsgLen)tmpIndex) != ROK)
      {     
         MG_ASN_ERR((&msgCp), MG_ASN_TAG_ERR);
         RETVALUE(RFAILED); 
      }
      if (tmpTag != gcMsgMessageBody.tag) {
         MG_ASN_ERR((&msgCp), MG_ASN_TAG_ERR);
         RETVALUE(RFAILED);
      } 
   }
   msgBodyLenLen = mgGetLen(&msgBodyLen, msgCp.mBuf, msgBodyLenIndex, mbufLen);
   if(msgBodyLenLen == -1) {
      RETVALUE(RFAILED);
   }

   /* Calculate length changes */
   newMsgBodyLen = mbufLen - msgBodyLenIndex - msgBodyLenLen;
   shiftAmount1 = mgUpdateLen(newMsgBodyLen, &msgCp, msgBodyLenIndex);
   if(shiftAmount1 < 0) {
      RETVALUE(RFAILED);
   }

   newMsgLen = (mbufLen + shiftAmount1) - msgLenIndex - msgLenLen;
   shiftAmount2 = mgUpdateLen(newMsgLen, &msgCp, msgLenIndex);
   if(shiftAmount2 < 0) {
      RETVALUE(RFAILED);
   }

   newMgcoMsgLen = (mbufLen + shiftAmount1 + shiftAmount2) - 1 - mgcoMsgLenLen;
   
   shiftAmount1 = mgUpdateLen(newMgcoMsgLen, &msgCp, 1);

   RETVALUE(ROK);
}
#ifdef MG_ASN_DBTEST

/*
*
*       Fun:   mgTest 
*
*       Desc:  Testing function
*
*       Ret:   ROK  (encoding successful)
*              RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  mwrap.c
*
*/
#ifdef ANSI
PUBLIC S16 mgTest 
(
U32           protVar,    /* protocol and variant */
U8            *event,     /* pointer to the event structure */
S32           txnIndx,    /* transaction index */
S32           elmDef,     /* message defintion */
Mem           *memReg,    /* memory: region/pool */
CmMemListCp   *memCp      /* memory list control block */
)
#else
PUBLIC S16 mgTest (protVar, event, txnIndx, elmDef, memReg, memCp)
U32           protVar;    /* protocol and variant */
U8            *event;     /* pointer to the event structure */
S32           txnIndx;    /* transaction index */
S32           elmDef;     /* message defintion */
Mem           *memReg;    /* memory: region/pool */
CmMemListCp   *memCp;     /* memory list control block */
#endif
{
   S16          ret;     /* return value */
   S16          myret;     /* return value */
   MsgLen       numDecBytes;
   MgAsnErr     asnErr;
   Buffer       *asnBuf;
   MgMgcoMsg    abnfEventsBack;
   S8         errorString[1024];
   U8           *myEvent = event;
   U8           *saveEvent = event;
   CmMemListCp  tmpMemCp;


   TRC2(mgTest)
   (void)cmMemset((U8*)&tmpMemCp, 0, sizeof(tmpMemCp));
   cmInitMemCp(&tmpMemCp, 1024, memReg);
   if (elmDef == MGED_MGCP) { RETVALUE(ROK); }
   memCp = (CmMemListCp*)*event;

   /* Reset event pointer to part of message to encode */
   myEvent = (U8*)mwrapEvntGet((PTR)myEvent, MG_WRAP_ASN, elmDef, txnIndx);

   /* Encode */
   (void)mgInitMsgDb();
   (void)cmMemset((U8*)&asnErr, 0, sizeof(MgAsnErr));
   ret = SGetMsg(memReg->region, memReg->pool, &asnBuf);
   if ((myret = mgAsnEncMsg((TknU8*)myEvent, asnBuf, protVar, (MgAsnElmntDef**)mwrapElmDefGet(MG_WRAP_ASN, elmDef, txnIndx), memReg->region, memReg->pool, &asnErr)) != ROK) {
      S8 errorBuf[1024];
      mwrapErrPrint((CmAbnfErr*)&asnErr, errorString);
      (void)sprintf(errorBuf, "FAILURE mgAsnEncMsg=%d errString=<%s>\n\n", ret, errorString);
   }
   else {
      /* Decode */
      if ((myret = mgAsnDecMsg((TknU8*)&abnfEventsBack, asnBuf, protVar, (MgAsnElmntDef**)mwrapElmDefGet(MG_WRAP_ASN, elmDef, txnIndx), &tmpMemCp, &asnErr, &numDecBytes)) != ROK) {
         S8 errorBuf[1024];
         mwrapErrPrint((CmAbnfErr*)&asnErr, errorString);
         (void)sprintf(errorBuf, "FAILURE mgAsnDecMsg=%d errString=<%s>\n\n", ret, errorString);
      }
   }

   /* give it back */
   cmFreeMem(&tmpMemCp);
   if ((ret = SPutMsg(asnBuf)) != ROK) { }

   RETVALUE(ret);
} /* mgTest */
#endif


/*
*
*       Fun:   mgDecPduMsg 
*
*       Desc:  Decoding interface function.
*
*       Ret:   CM_ABNF_ROK  (encoding successful)
*              CM_ABNF_RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  mwrap.c
*
*/
  
#ifdef ANSI
PUBLIC S16 mgDecPduMsg 
(
U32           protVar,      /* protocol and variant */
U8            *event,       /* pointer to the event structure */
U32           txnIndx,      /* transaction index */
Buffer        *mBuf,        /* Message buffer */
S32           elmDef,       /* message defintion */
MsgLen        *numDecBytes, /* Number of message bytes decoded */
CmAbnfDecOff  *offset,      /* Decode buffer offset info */
CmAbnfErr     *err          /* error to be returned back to the caller */ 
)
#else
PUBLIC S16 mgDecPduMsg (protVar, event, txnIndx, mBuf, elmDef, numDecBytes, offset, err)
U32           protVar;      /* protocol and variant */
U8            *event;       /* pointer to the event structure */
U32           txnIndx;      /* transaction index */
Buffer        *mBuf;        /* Message buffer */
S32           elmDef;      /* message defintion */
MsgLen        *numDecBytes; /* Number of message bytes decoded */
CmAbnfDecOff  *offset;      /* Decode buffer offset info */
CmAbnfErr     *err;         /* error to be returned back to the caller */ 
#endif
{
   S16           ret;
   CmMemListCp   *memCp;     /* memory list control block */
   U8*           saveEvent;
#ifdef MG_ASN_DBTEST
   Mem      memReg;
#endif
#ifdef MG_WRAP_ASN1_ENCDEC
   MgAsnErr      asnErr;
#endif


   TRC2(mgDecPduMsg)
   saveEvent = event;
   memCp = (CmMemListCp*)event;

   /* Reset event pointer to part of message to encode */
   /* mg002.105: Removed compilation warning */
   event = (U8*)mwrapEvntGet((PTR)event, MG_WRAP_ENC_TYPE, (U16)elmDef, txnIndx);

   /* Decode */
   (void)cmMemset((U8*)err, 0, sizeof(CmAbnfErr));
#ifdef MG_WRAP_ASN1_ENCDEC
   (void)mgInitMsgDb();
   (void)cmMemset((U8*)&asnErr, 0, sizeof(MgAsnErr));
   /* mg002.105: Removed compilation warning */
   if ((ret = mgAsnDecMsg((TknU8*)event, mBuf, protVar, (MgAsnElmntDef**)mwrapElmDefGet(MG_WRAP_ASN, (U16)elmDef, txnIndx), memCp, &asnErr, numDecBytes)) != ROK) {
      mwrapErrMap(err, &asnErr);
   }
#else
   ret = cmAbnfDecPduMsg (protVar, memCp, event, mBuf, (CmAbnfElmDef*)mwrapElmDefGet(MG_WRAP_ABNF, elmDef, txnIndx), numDecBytes, offset, err);
#endif
   if (ret == ROK) {
#ifdef MG_ASN_DBTEST
      if (elmDef != MGED_BODY) {
         (void)cmMemset((U8*)&memReg, 0, sizeof(memReg));
         memReg.pool = 0;
         memReg.region = 0;
         if (mgTest(protVar, saveEvent, txnIndx, elmDef, &memReg, memCp) != ROK)
         {
            RETVALUE(RFAILED);
         }
      }
#endif
   }

   RETVALUE(ret);
} /* mgDecPduMsg */


/*
*
*       Fun:   mgEncOut2Buf
*
*       Desc:  Encode the string in the message buffer for transmission
*
*       Ret:   CM_ABNF_ROK  (encoding successful)
*              CM_ABNF_RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  mwrap.c
*
*/
  
#ifdef ANSI
PUBLIC S16 mgEncOut2Buf 
(
CmAbnfEncCp   *encCp,       /* Encode control point */
U8            *str,         /* string to be encoded in the buffer */
U16           len           /* length of the string */
)
#else
PUBLIC S16 mgEncOut2Buf (encCp, str, len)
CmAbnfEncCp   *encCp;       /* Encode control point */
U8            *str;         /* string to be encoded in the buffer */
U16           len;          /* length of the string */
#endif
{
   S16           ret;
   TRC2(mgEncOut2Buf)
   ret = cmAbnfEncOut2Buf (encCp, str, len);
   RETVALUE(ret);
} /* mgEncOut2Buf */


/*
*
*       Fun:   mgDecOffset
*
*       Desc:  Decrement the offset to the decoded offset.
*
*       Ret:   ROK  
*              RFAILED 
*
*       Notes: None 
*
*       File:  mwrap.c
*
*/
  
#ifdef ANSI
PUBLIC S16 mgDecOffset 
(
CmAbnfDecCp   *decCp,       /* Decode control point */
U16           numDecode     /* number of decode bytes */
)
#else
PUBLIC S16 mgDecOffset(decCp, numDecode)
CmAbnfDecCp   *decCp;       /* Decode control point */
U16           numDecode;    /* number of decode bytes */
#endif
{
   S16           ret;     /* return value */
   TRC2(mgDecOffset)
   ret = cmAbnfDecOffset(decCp, numDecode);
   RETVALUE(ret);
} /* mgDecOffset */


/*
*
*       Fun:   mwrapErrPrint 
*
*       Desc:  Print an error
*
*       Ret:   void
*
*       Notes: None 
*
*       File:  mwrap.c
*
*/
  
#ifdef ANSI
PUBLIC Void mwrapErrPrint 
(
CmAbnfErr    *abnfErr,   /* Error pointer */
S8         *buf        /* Return buffer */
)
#else
PUBLIC Void mwrapErrPrint (abnfErr, buf)
CmAbnfErr    *abnfErr;   /* Error pointer */
S8         *buf;       /* Return buffer */
#endif
{
   S8 *sPtr;
   TRC2(mwrapErrPrint)
   switch (abnfErr->code) {
   case CM_ABNF_ERR_NONE:
      (void)sprintf(buf, "SUCCESS!");
      return;
   case MG_ASN_MAND_MIS:
      sPtr = "Mandatory information is missing";
      break;
   case MG_ASN_TAG_ERR:
      sPtr = "Error in the tag";
      break;
   case MG_ASN_LEN_ERR:
      sPtr = "Error in the length field";
      break;
   case MG_ASN_UNEXP_VAL:
      sPtr = "Unexpected value (for enum's)";
      break;
   case MG_ASN_RES_ERR:
      sPtr = "resources error";
      break;
   case MG_ASN_OUT_RANGE:
      sPtr = "Out of database defined range";
      break;
   case MG_ASN_UNDEF_PARAM:
      sPtr = "Parameter undefined for the protocol";
      break;
   case MG_ASN_NO_FUNC:
      sPtr = "No user function";
      break;
   case MG_ASN_EXTRA_PARAM:
      sPtr = "extra parameters at the end of the msg";
      break;
   case MG_ASN_DUP_ELMNT:
      sPtr = "Duplicate element";
      break;
   case MG_ASN_BAD_IDX:
      sPtr = "Element index is bad for choice";
      break;
   case MG_ASN_INV_IA5STR:
      sPtr = "Invalid IA5String";
      break;
   case MG_ASN_MEM_ALRDY_ALLOCD:
      sPtr = "Memory already allocated";
      break;
   case MG_ASN_INVLD_ELMNT:
      sPtr = "Invalid element type";
      break;
   case MG_ASN_INVLD_EVNT:
      sPtr = "Invalid event structure";
      break;
   case MG_ASN_INVLD_MSG:
      sPtr = "Invalid message data";
      break;
   case MG_ASN_INVLD_PKG:
      sPtr = "Invalid package data";
      break;
   case CM_ABNF_ERR_TKN_NOTPRST:
      sPtr = "Manditory token not present";
      break;
   case CM_ABNF_ERR_INV_CHOICE:
      sPtr = "Invalid choice";
      break;
   case CM_ABNF_ERR_DBELMNT:
      sPtr = "Invalid database element";
      break;
   case CM_ABNF_ERR_INV_UINTRNG:
      sPtr = "Range error (int)";
      break;
   case CM_ABNF_ERR_INV_STRRNG:
      sPtr = "Range error (str)";
      break;
   case CM_ABNF_ERR_ENCPARAM:
      sPtr = "Encode parameters error";
      break;
   case CM_ABNF_ERR_PARSE:
      sPtr = "Parse error";
      break;
   case CM_ABNF_ERR_RESFAIL:
      sPtr = "Resource failure";
      break;
   case CM_ABNF_ERR_SEQEMPTY:
      sPtr = "Sequence empty";
      break;
   case CM_ABNF_ERR_SEQOFELM_MORE:
      sPtr = "Sequence over maximum";
      break;
   case CM_ABNF_ERR_SEQOFELM_LESS:
      sPtr = "Sequence less than minimum";
      break;
   case CM_ABNF_ERR_REGEXP:
      sPtr = "Regular expression error";
      break;
   case CM_ABNF_ERR_DUPLICATE:
      sPtr = "Duplicate";
      break;
   default:
      sPtr = "Unknown error";
      break;
   }
   (void)sprintf(buf, "%s", sPtr);
   RETVOID;
}

#ifdef CM_ABNF_MT_LIB

/*
*
*       Fun:    Activation task
*
*       Desc:   Processes events received for Encode or Decode req.
*
*       Ret:    ROK
*
*       Notes:  None
*
*       File:   mwrap.c
*
*/
#ifdef ANSI
PUBLIC S16 mwrapActvTsk
(
Pst            *post,           /* post structure */
Buffer         *mBuf            /* message buffer */
)
#else
PUBLIC S16 mwrapActvTsk(post, mBuf)
Pst            *post;           /* post structure */
Buffer         *mBuf;           /* message buffer */
#endif
{
   S16 ret = ROK;

   TRC3(mwrapActvTsk)

   switch(post->event)
   {
      case MG_WRAP_ABNF_ENCREQ:
         ret = cmUnpkMedEncReq(cmAbnfEncReq, post, mBuf);
         break;
      case MG_WRAP_ABNF_DECREQ:
         ret = cmUnpkMedDecReq(cmAbnfDecReq, post, mBuf);
         break;
#ifdef GCP_ASN
      case MG_WRAP_ASN_ENCREQ:
         ret = mgAsnUnpkMedEncReq(mgAsnEncReq, post, mBuf);
         break;
      case MG_WRAP_ASN_DECREQ:
         ret = mgAsnUnpkMedDecReq(mgAsnDecReq, post, mBuf);
         break;
#endif
      default:
#if  (ERRCLASS & ERRCLS_DEBUG)
         CMABNFLOGERROR(ERRCLS_INT_PAR, ECMABNFXXX, 0,
            "mwrapActvTsk() failed, Invalid event");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         (Void) SPutMsg(mBuf);
         ret = RFAILED;
         break;
   }
   SExitTsk();

   RETVALUE(ret);
}
#endif
#endif

  
/********************************************************************30**
  
         End of file:     mgasnwrp.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 20 13:46:36 2005
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************80**
 
 
*********************************************************************81*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      tlh  1. initial release.
/main/1      ---      pk   1. GCP 1.5 release
          mg002.105   ps   1. Removed compilation warning
          mg005.105   gk   1. Fix for the Big endian
          mg008.105   gk   1. Corrected the return value if tags are not same
*********************************************************************91*/
