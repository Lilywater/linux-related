/**********************************************************************

    Name:   mg_nms.c 

    Type:   C source file

    Desc:   

    File:   mg_nms.c

    Sid:    

    Created by: 

**********************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timers defines */
#include "cm_hash.h"       /* common hash list defines */
#include "cm_inet.h"       /* common INET defines */
#include "cm_llist.h"      /* common linked list defines */
#include "cm_mblk.h"       /* memory management */
#include "cm_tkns.h"       /* common tokens */
#include "cm_abnf.h"
#include "cm_tpt.h"        /* common transport defines */
#include "cm_sdp.h"        /* SDP related constants */
#include "cm_dns.h"         /* common DNS libraru defines */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include  "cm_ss7.h"       /* Common SS7 Defines */
#include  "snt.h"          /* MTP3 Interface Defines */
#endif   /* GCP_PROV_MTP3 */


#include "mgt.h"           /* MGT defines */

#ifdef    GCP_PROV_SCTP
#include "lsb.h"           /* layer management defines for SCTP */
#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3
#ifdef   SD
#include "lsd.h"           /* layer management defines for MTP2 */
#include "sd.h"            
#endif   /* SD */

#include "lsn.h"           /* layer management defines for MTP3 */
#include "sn.h"           /* defines for MTP3 */

/*mg002.105: Include few more files for MTP3 SIMULATION testing*/
#ifdef GCP_SIMULATION
#include "cm_sock.h"       /* common socket */
#include "mac.h"           /* mac layer */
#include "lmc.h"           /* layer management */
#include "mc.h"            /* MSOC header */
#include "mc_err.h"        /* MSOC error codes */
#endif /* GCP_SIMULATION */

#endif    /* GCP_PROV_MTP3 */

#include "lmg.h"           /* layer management defines for MGCP */
#ifdef HI
#include "lhi.h"
#include "hit.h"           /* HI layer */
#include "hi.h"
#endif

#ifdef    GCP_PROV_SCTP
#ifdef    SB
#include "lsb.h"
#include "sct.h"           /* SB (SCTP) layer */
#include "sb_mtu.h"
#include "sb.h"
#endif    /* SB */
#endif    /* GCP_PROV_SCTP */

#include "mg.h"            /* defines and macros for MGCP */
#include "mg_err.h"        /* MG error defines */
#ifdef ZG_ACC_TEST
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
/*mg002.105: Move lgd.h in ZG_DFTHA flag*/
#ifdef ZG_DFTHA
#include "ldg.h"            /* PSF Defines */
#endif /* ZG_DFTHA */
#include "zg_acc.h"        /* PSF Acceptance test defines */
#endif /* ZG_ACC_TEST */
/*#include "mg_acc.h"        / * defines for MGCP acceptance tests */
#include "mg_macro.h"      /* defines for MGT-related macros */
#if (defined(GCP_PERF) || defined(GCP_PERF_ACC))
#include "ss_task.h"
#include "mg_perf.h"
#endif

/* header/extern include files (.x) */

#include "gen.x"           /* general layer typedefs */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_inet.x"       /* common INET */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_abnf.x"
#include "cm_tpt.x"        /* common transport types */
#include "cm_sdp.x"        /* SDP related types */
#include "cm_dns.x"         /* common DNS libraru defines */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3 
#include  "cm_ss7.x"       /* Common SS7 Structure */
#include  "snt.x"          /* MTP3 Interface Structure */
#include "lsd.x"           /* layer management defines for MTP2 */
#include "lsn.x"           /* layer management defines for MTP3 */
#include "mgsnse1.x"         /* layer1 define */

#ifdef   SD
#include "sd.x"            /* MTP2 defines */
#endif   /* SD */
#ifdef   SN
#include "sn.x"            /* MTP3 defines */
#endif   /* SN */

#ifdef GCP_SIMULATION
#include "cm_sock.x"       /* common socket */
#include "mac.x"           /* mac layer */
#include "lmc.x"           /* layer management */
#include "mc.x"            /* MSOC header */
#endif /* GCP_SIMULATION */
#endif    /* GCP_PROV_MTP3 */


#include "mgt.x"           /* MGT types */

#ifdef    GCP_PROV_SCTP
#include "lsb.x"           /* layer management defines for SCTP */
#endif    /* GCP_PROV_SCTP */

#include "lmg.x"           /* layer management typedefs for MGCP */
#ifdef HI
#include "lhi.x"
#include "hit.x"           /* HI layer */
#include "hi.x"
#endif

#ifdef    GCP_PROV_SCTP
#ifdef    SB
#include "lsb.x"
#include "sct.x"           /* SB (SCTP) layer */
#include "sb_mtu.x"
#include "sb.x"
#endif    /* SB */
#endif    /* GCP_PROV_SCTP */

#include "mg.x"            /* typedefs for MGCP */
#ifdef ZG_ACC_TEST
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#include "zg_acc.x"        /* PSF Acceptance test typedefs */
#endif /* ZG_ACC_TEST */
/*#include "l4.x"            / * typedefs for MGCP provider */
/*#include "mu.x"            / * typedefs for MGCP user */
/*#include "mg_acc.x"        / * typedefs for MGCP acceptance tests */
/*#include "mg_act.x"        / * Test function declarations */
#include "mg_msg.x"        /* Message function declarations */
/*#include "dm.x"*/

#ifdef MEM_DEBUG
#include "mem_dbg.x"
#endif


#include "ss_err.h"        /* errors */
#include "ss_dep.h"        /* implementation-specific */
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */



/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */

#include "ss_dep.x"        /* implementation-specific */
#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */

/*#include "sm.h"*/
#include "oam_interface.h"  
#include "mg_nms.h"
#include "mg_cfg.h"
#include "sm.x"
#include "xosshell.h"
#include "cp_tab_def.h" /*cdw mod */
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"
#include "h248_oam.x"
#include "mg_cfg.x"

extern int getTblRec (int iTbId, int iRecId, char *szBuf);
extern int parseFile() ;
extern void mgNmsGenCfgReq();
extern void mgNmsTSapCfgReq(SpId spId, SuId suId);
extern void mgNmsSSapCfgReq(SpId spId);
extern void mgNmsPeerEntCfgReq(SpId spId);
extern void mgNmsSrvrCfgReq(SpId spId, SuId suId);
extern void	freeOamTblRow(tb_record *prow);
extern Void MGSapEnbCtrl();
U16 g_PortNum;   /* cdw add this for print tpt server on 2006.10.10*/
//void TestPrintPeerEnt();
//void TestPrintSrvr();
void mgResetCfgData(void);

EXTERN   MgCb      mgCb;

#ifdef CP_OAM_DATA_SHOW
#ifdef GCP_MGC
void mgPrintMGCServerCfged()
{
	int startPort;
	int endPort;
	int listenPort;
	U8 ipAddr[20];
	MgTSAPCb *tsap = NULL;
	tsap = mgCb.tSAPLst[0];
	startPort = g_MgNmsCfgData.mgMGCSrvrCfgTab.startport;
	endPort = g_MgNmsCfgData.mgMGCSrvrCfgTab.endport;
	listenPort = g_MgNmsCfgData.mgMGCSrvrCfgTab.listenport;
	if((startPort==0)||(endPort==0)||(startPort>endPort)||((startPort==endPort)&&(startPort==listenPort)))
		{
			g_PortNum = 1;
			if(NULL != tsap->lstnrLst[0]->lstnrCb) /* when (tsap->lstnrLst[0]->lstnrCb == NULL) , config is wrong  */
				{
					printf("\n--------------- MGC Server Cfged Info ---------------\n");
					XOS_IptoStr(mgCb.tSAPLst[0]->lstnrLst[0]->lstnrCb->tptAddr.u.ipv4TptAddr.address, ipAddr);
					printf("address		: %s\n",ipAddr);
			//		printf("address : %x\n",mgCb.tSAPLst[0]->lstnrLst[0]->lstnrCb->tptAddr.u.ipv4TptAddr.address);
					printf("listenport	: %d\n",mgCb.tSAPLst[0]->lstnrLst[0]->lstnrCb->tptAddr.u.ipv4TptAddr.port);
			//		printf("there is only 1 port,so startPort and endPort are useless\n");
					printf("startport	: %d\n",startPort);
					printf("endport		: %d\n",endPort);
					printf("------------- MGC Server Cfged Info end --------------\n");
				}
			else
				printf("\n----------  Your Cfg info have some Error(s)!!!  ---------- \n\n");
			RETVOID;
		}
	else 
		{
			if((startPort<=listenPort)&&(endPort>=listenPort))
				{
					g_PortNum = 1 + endPort - startPort;
					if(g_PortNum > MGCO_MAX_SERVER)
						g_PortNum = MGCO_MAX_SERVER;
					if(NULL != tsap->lstnrLst[0]->lstnrCb)
						{	
							printf("\n--------------- MGC Server Cfged Info ---------------\n");
							XOS_IptoStr(mgCb.tSAPLst[0]->lstnrLst[0]->lstnrCb->tptAddr.u.ipv4TptAddr.address, ipAddr);
							printf("address 	: %s\n",ipAddr);
					//		printf("address : %x\n",mgCb.tSAPLst[0]->lstnrLst[0]->lstnrCb->tptAddr.u.ipv4TptAddr.address);
							printf("listenport 	: %d\n",mgCb.tSAPLst[0]->lstnrLst[0]->lstnrCb->tptAddr.u.ipv4TptAddr.port);
								
							if(startPort==listenPort)
								printf("startport 	: %d\n",mgCb.tSAPLst[0]->lstnrLst[0]->lstnrCb->tptAddr.u.ipv4TptAddr.port);  
							else
								printf("startport 	: %d\n",mgCb.tSAPLst[0]->lstnrLst[1]->lstnrCb->tptAddr.u.ipv4TptAddr.port);
							if(endPort==listenPort)
								printf("endport 	: %d\n",mgCb.tSAPLst[0]->lstnrLst[0]->lstnrCb->tptAddr.u.ipv4TptAddr.port);
							else
								{
								if(endPort-startPort < MGCO_MAX_SERVER - 1)
									printf("endport 	: %d\n",mgCb.tSAPLst[0]->lstnrLst[endPort-startPort]->lstnrCb->tptAddr.u.ipv4TptAddr.port);
								else
									printf("endport 	: %d\n",mgCb.tSAPLst[0]->lstnrLst[MGCO_MAX_SERVER-1]->lstnrCb->tptAddr.u.ipv4TptAddr.port);
								}
							printf("------------- MGC Server Cfged Info end --------------\n");
						}
					else
						printf("\n----------  Your Cfg info have some Error(s)!!!  ---------- \n\n");
					RETVOID;
				}
	else
		{
			g_PortNum = 2 + endPort - startPort;
			if(g_PortNum > MGCO_MAX_SERVER)
				g_PortNum = MGCO_MAX_SERVER;
			if(NULL != tsap->lstnrLst[0]->lstnrCb)
				{
					printf("\n--------------- MGC Server Cfged Info ---------------\n");
					XOS_IptoStr(mgCb.tSAPLst[0]->lstnrLst[0]->lstnrCb->tptAddr.u.ipv4TptAddr.address, ipAddr);
					printf("address 	: %s\n",ipAddr);
			//		printf("address : %x\n",mgCb.tSAPLst[0]->lstnrLst[0]->lstnrCb->tptAddr.u.ipv4TptAddr.address);
					printf("listenport 	: %d\n",mgCb.tSAPLst[0]->lstnrLst[0]->lstnrCb->tptAddr.u.ipv4TptAddr.port);
					printf("startport 	: %d\n",mgCb.tSAPLst[0]->lstnrLst[1]->lstnrCb->tptAddr.u.ipv4TptAddr.port);
					if((endPort-startPort+1)<=8)
						printf("endport 	: %d\n",mgCb.tSAPLst[0]->lstnrLst[endPort-startPort+1]->lstnrCb->tptAddr.u.ipv4TptAddr.port);
					else
						printf("endport 	: %d\n",mgCb.tSAPLst[0]->lstnrLst[9]->lstnrCb->tptAddr.u.ipv4TptAddr.port);
					printf("------------- MGC Server Cfged Info end --------------\n");
				}
			else
				printf("\n----------  Your Cfg info have some Error(s)!!!  ---------- \n\n");
			RETVOID;
		}
	}

}


void mgPrintMGCPeerEntCfged()
{
#if 0
printf("\n***********************MGC Peer Entity Cfged Info**************************\n");
if(NULL==mgCb.peerLst[0])
    printf("cfg is wrong\n");
else
{
      printf("mgId : %d\n",mgCb.peerLst[0]->index-1);
      printf("ipAddr : %x\n",mgCb.peerLst[0]->peer->accessInfo.peerAddrTbl.netAddr[0].u.ipv4NetAddr);
      printf("name : %s\n",mgCb.peerLst[0]->peer->accessInfo.name);
      printf("port : %d\n", mgCb.peerLst[0]->peer->accessInfo.remotePort);
printf("\n***********************MGC Peer Entity Cfged Info end**************************\n");
}
#endif
      RETVOID;
}

#endif
#ifdef GCP_MG
void mgPrintMGServerCfged()
{
	U8 ipAddr[20];
	MgTSAPCb *tsap =NULL;
	tsap = mgCb.tSAPLst[0];
	if(NULL != tsap->lstnrLst[0]->lstnrCb)
		{
    			printf("\n--------------- MG Server Cfged Info ---------------\n");
			XOS_IptoStr(mgCb.tSAPLst[0]->lstnrLst[0]->lstnrCb->tptAddr.u.ipv4TptAddr.address, ipAddr);
			if(mgCb.tSAPLst[0]->lstnrLst[0]->lstnrCb->srvrType == MG_MGCO_DEFLT_SRVR)
        			printf("isDefault 	: TRUE(1)\n"); 
    			else
        			printf("isDefault 	: FALSE(0)\n");
    	//		printf("address 	: %x\n",mgCb.tSAPLst[0]->lstnrLst[0]->lstnrCb->tptAddr.u.ipv4TptAddr.address);  
			printf("address		: %s\n",ipAddr);
			printf("port 		: %d\n",mgCb.tSAPLst[0]->lstnrLst[0]->lstnrCb->tptAddr.u.ipv4TptAddr.port);
    			printf("------------- MG Server Cfged Info end --------------\n");
		}
	else
		printf("\n----------  Your Cfg info have some Error(s)!!!  ---------- \n\n");
	RETVOID;
}

void mgPrintMGPeerEntCfged()
{
	U8 ipAddr[20];
	MgTSAPCb *tsap =NULL;
	tsap = mgCb.tSAPLst[0];
	if(NULL != tsap->lstnrLst[0]->lstnrCb)
		{    
			printf("\n--------------- MG Server Cfged Info ---------------\n");
			XOS_IptoStr(mgCb.peerLst[0]->peer->accessInfo.peerAddrTbl.netAddr[0].u.ipv4NetAddr, ipAddr);
   		 	printf("mgcId 		: %d\n",mgCb.peerLst[0]->index-1);
    			printf("address	:%s\n",ipAddr);		
    		// 	printf("ipAddr : %x\n",mgCb.peerLst[0]->peer->accessInfo.peerAddrTbl.netAddr[0].u.ipv4NetAddr);
    			printf("name 		: %s\n",mgCb.peerLst[0]->peer->accessInfo.name);
    			printf("port 		: %d\n", mgCb.peerLst[0]->peer->accessInfo.remotePort);
    			printf("mgcPriority 	: %d\n",mgCb.peerLst[0]->peer->mgcoInfo.mgcPriority);
    			printf("------------- MG Server Cfged Info end --------------\n");
		}
	else
		printf("\n----------  Your Cfg info have some Error(s)!!!  ---------- \n\n");
    	RETVOID;
}
#endif
#endif /*CP_OAM_DATA_SHOW*/

#if 0
int mgTestPrint()
{
	printf("\n----------Test Begin----------------!\n");

	/*GCP peer entity print*/
    TestPrintPeerEnt();

	/*GCP transport server print*/
    TestPrintSrvr();
	
	printf("\n----------Test End----------------!\n");

	return 0;
}

void TestPrintPeerEnt()
{
#ifdef GCP_MGC
    printf("\n MGC peer entity config :");
	printf("\n i1 (mgId)   = %d",g_MgNmsCfgData.mgMGCPeerEntCfgTab.mgId);
	printf("\n i2 (ipAddr) = %x",g_MgNmsCfgData.mgMGCPeerEntCfgTab.ipAddr);
	printf("\n i3 (name)  = %s",g_MgNmsCfgData.mgMGCPeerEntCfgTab.name);
	printf("\n i4 (port)    = %d",g_MgNmsCfgData.mgMGCPeerEntCfgTab.port);
    RETVOID;
#endif
#ifdef GCP_MG
    printf("\n MG peer entity config :");
	printf("\n i1 (mgcId)   = %d",g_MgNmsCfgData.mgMGPeerEntCfgTab.mgcId);
	printf("\n i2 (ipAddr)  = %x",g_MgNmsCfgData.mgMGPeerEntCfgTab.ipAddr);
	printf("\n i3 (name)    = %s",g_MgNmsCfgData.mgMGPeerEntCfgTab.name);
	printf("\n i4 (port)      = %d",g_MgNmsCfgData.mgMGPeerEntCfgTab.port);
    printf("\n i5(mgcPriority)= %d",g_MgNmsCfgData.mgMGPeerEntCfgTab.mgcPriority);
    RETVOID;
#endif
}

void TestPrintSrvr()
{
#ifdef GCP_MGC
    printf("\n MGC transport server config :");
	printf("\n i1 (address)   = %x",g_MgNmsCfgData.mgMGCSrvrCfgTab.address);
	printf("\n i2 (listenport) = %d",g_MgNmsCfgData.mgMGCSrvrCfgTab.listenport);
	printf("\n i3 (startport)  = %d",g_MgNmsCfgData.mgMGCSrvrCfgTab.startport);
	printf("\n i4 (endport)   = %d",g_MgNmsCfgData.mgMGCSrvrCfgTab.endport);
 /*   printf("\n i5= %d",g_MgNmsCfgData.mgMGCSrvrCfgTab.transportType);*/
    RETVOID;
#endif
#ifdef GCP_MG
    printf("\n MG transport server config :");
	printf("\n i1 (isDefault) = %d",g_MgNmsCfgData.mgMGSrvrCfgTab.isDefault);
	printf("\n i2 (address)  = %x",g_MgNmsCfgData.mgMGSrvrCfgTab.address);
	printf("\n i3 (port)        = %d",g_MgNmsCfgData.mgMGSrvrCfgTab.port);
  /*  printf("\n i4= %d",g_MgNmsCfgData.mgMGSrvrCfgTab.transportType);*/
    RETVOID;
#endif    
}
#endif


S16 mgRecvInitCfg(tb_record* prow)
{
	CP_OAM_COM_IP_TAB 	*mgIPAddrTab;
#ifdef GCP_MGC
    	MgMGCPeerEntCfgTab   *mgMGCPeerEntCfgTab;
	MgMGCSrvrCfgTab      	*mgMGCSrvrCfgTab;
#elif GCP_MG
    	MgMGPeerEntCfgTab   	*mgMGPeerEntCfgTab;    
    	MgMGSrvrCfgTab       	*mgMGSrvrCfgTab;  
#endif
    	U16 	len;	
   
	while(prow)
	{
		switch(prow->tableid)
		{
			#ifdef GCP_MGC
			case APP_TABLE_ID_VOIP_H248_MGCENT:
				mgMGCPeerEntCfgTab = (MgMGCPeerEntCfgTab *) prow->panytbrow;
				g_MgNmsCfgData.mgMGCPeerEntCfgTab.mgId   	= mgMGCPeerEntCfgTab->mgId;
			    	g_MgNmsCfgData.mgMGCPeerEntCfgTab.IpIndex	= mgMGCPeerEntCfgTab->IpIndex; //mgMGCPeerEntCfgTab->ipAddr;
                		g_MgNmsCfgData.mgMGCPeerEntCfgTab.port   	= mgMGCPeerEntCfgTab->port;
                		len = (U8)cmStrlen((CONSTANT U8 *)mgMGCPeerEntCfgTab->name);
                		cmMemcpy((U8 *)g_MgNmsCfgData.mgMGCPeerEntCfgTab.name,
                    		(CONSTANT U8 *)mgMGCPeerEntCfgTab->name,len);
               	 	g_MgNmsCfgData.mgMGCPeerEntCfgTab.name[len] = '\0';
				break;

			case APP_TABLE_ID_VOIP_H248_MGCSRVR:
               		mgMGCSrvrCfgTab= (MgMGCSrvrCfgTab *) prow->panytbrow;
                		g_MgNmsCfgData.mgMGCSrvrCfgTab.IpIndex		= mgMGCSrvrCfgTab->IpIndex; //mgMGCSrvrCfgTab->address;
                		g_MgNmsCfgData.mgMGCSrvrCfgTab.listenport    	= mgMGCSrvrCfgTab->listenport;
                		g_MgNmsCfgData.mgMGCSrvrCfgTab.startport     	= mgMGCSrvrCfgTab->startport;
                		g_MgNmsCfgData.mgMGCSrvrCfgTab.endport      	= mgMGCSrvrCfgTab->endport;
         		/*    g_MgNmsCfgData.mgMGCSrvrCfgTab.transportType = mgMGCSrvrCfgTab->transportType; */
                		break;

			#elif GCP_MG
			case APP_TABLE_ID_VOIP_H248_MGENT:
				mgMGPeerEntCfgTab = (MgMGPeerEntCfgTab *) prow->panytbrow;
				g_MgNmsCfgData.mgMGPeerEntCfgTab.mgcId  	= mgMGPeerEntCfgTab->mgcId;
			    	g_MgNmsCfgData.mgMGPeerEntCfgTab.IpIndex 	= mgMGPeerEntCfgTab->IpIndex; //mgMGPeerEntCfgTab->ipAddr;
                		g_MgNmsCfgData.mgMGPeerEntCfgTab.port   		= mgMGPeerEntCfgTab->port;
                		g_MgNmsCfgData.mgMGPeerEntCfgTab.mgcPriority 	= mgMGPeerEntCfgTab->mgcPriority;
                		len = (U8)cmStrlen((CONSTANT U8 *)mgMGPeerEntCfgTab->name);
                		cmMemcpy((U8 *)g_MgNmsCfgData.mgMGPeerEntCfgTab.name,
                    		(CONSTANT U8 *)mgMGPeerEntCfgTab->name,len);
                		g_MgNmsCfgData.mgMGPeerEntCfgTab.name[len] = '\0';
				break;
             
            		case APP_TABLE_ID_VOIP_H248_MGSRVR:  
                		mgMGSrvrCfgTab= (MgMGSrvrCfgTab *) prow->panytbrow;
                		g_MgNmsCfgData.mgMGSrvrCfgTab.IpIndex       	= mgMGSrvrCfgTab->IpIndex; // mgMGSrvrCfgTab->address;
                		g_MgNmsCfgData.mgMGSrvrCfgTab.isDefault     	= mgMGSrvrCfgTab->isDefault;
                		g_MgNmsCfgData.mgMGSrvrCfgTab.port          	= mgMGSrvrCfgTab->port;
       		/*      g_MgNmsCfgData.mgMGSrvrCfgTab.transportType = mgMGSrvrCfgTab->transportType; */
                		break;
            		#endif
			case APP_TABLE_ID_COM_IP:
				mgIPAddrTab = (CP_OAM_COM_IP_TAB *) prow->panytbrow;

                		if ( ROK !=  CpComSetOneIpTab(EN_CP_OPR_ADD,  mgIPAddrTab) )
                			{
                    		//	ITCFGDBGP(DBGMASK_MI, (itGlobalTabCfg.CfgInit.prntBuf, \
                    		//		"itRecvInitCfg(CpComSetOneIpTab is RFAILED)\n"));
                    			RETVALUE(RFAILED);
                			}
				break;
			default:
				break;
		}

		prow = prow->next;
	}

	RETVALUE(ROK);
}


S16 mgCfgMsg()
{
#ifdef CP_OAM_DATA_SHOW
	/*mgTestPrint();*/
#endif
    /* static config data only be done in config start phase, and it would not change after system started*/
    if( gSmCb[ENTMG].smStatus == SM_INIT_CFG_STATE)
    {
        mgNmsConfigure();
    }

	RETVALUE(ROK);
}



unsigned char mgNmSyncCallback(unsigned short msgtype, unsigned int sepuense, unsigned char pack_end, tb_record* prow)
{

	if(ROK != mgRecvInitCfg(prow))
	{
		RETVALUE(RFAILED);
	} 	

	if(TRUE == pack_end)
	{
		if(ROK != mgCfgMsg())
		{
		  RETVALUE(RFAILED);
		} 	

		/* send out a config req message to sm*/
		if( ROK != smSendCfgReq(ENTMG, SM_INIT_CFG_STATE))
		{
		    RETVALUE(RFAILED);                         
		}

		/* wait initial cofiguration finished*/
		ssWaitSema(&gSmCb[ENTMG].sema);

		/* send response to subagent*/
		if(SM_SUCCESS_STATE ==  gSmCb[ENTMG].smStatus)
		{
			/* All the initialization configuration data is processed successfully */
			opt_response_batch(sepuense, OAM_RESPONSE_OK);
			MGSapEnbCtrl();                        
		}
		else 
		{
			opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
		}
	smReset(ENTMG);
	
	}
#ifdef CP_OAM_DATA_SHOW
#ifdef GCP_MGC
mgPrintMGCServerCfged();
//mgPrintMGCPeerEntCfged();
#endif
#ifdef GCP_MG
mgPrintMGServerCfged();
//mgPrintMGPeerEntCfged();
#endif
#endif /*CP_OAM_DATA_SHOW*/
	printf("test in mgNmSyncCallback()\n");
	RETVALUE(ROK);
}

void mgResetCfgData(void)
{
    RETVOID;
}



