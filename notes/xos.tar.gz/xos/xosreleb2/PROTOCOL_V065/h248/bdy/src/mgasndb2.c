/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Megaco ASN.1 database tree file

     Type:     C source file

     Desc:     global database tree for ASN.1 Megaco

     File:     mgca_dbt.c

     Sid:      mgasndb2.c@@/main/1 - Wed Mar 30 08:08:48 2005

     Prg:      nct

*********************************************************************21*/

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#ifdef GCP_ASN

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tkns.h"       /* common token structures */
#include "cm_mblk.h"       /* common event memory management */
#include "cm_abnf.h"       /* ABNF header file */
#include "cm_inet.h"       /* Inet header file */
#include "cm_tpt.h"        /* Transport  header file */
#include "cm_sdp.h"
#include "cm_dns.h"
#ifdef ZG
#include "cm_ftha.h"
#include "cm_psfft.h"
#endif /* ZG */

#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#include "mgt.h"
#include "mg_asn.h"
#include "mgasndb1.h"
#include "mgasndb2.h"

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* common event memory management */
#include "cm_abnf.x"       /* ABNF header file */
#include "cm_lib.x"        /* common library file */
#include "cm_inet.x"       /* Inet header file */
#include "cm_tpt.x"        /* Transport  header file */
#include "cm_sdp.x"
#include "cm_dns.x"

#ifdef ZG
#include "cm_ftha.x"
#include "cm_psfft.x"
#endif /* ZG */

#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#include "cm_abndb.x"
#include "cm_sdpdb.x"
#include "mgt.x"
#include "mg_asn.x"
#include "mgasndb1.x"
#include "mgasndb2.x"

/*
 * Array
 */
PUBLIC MgAsnElmntDef *mgaMegaco[] =
{
   /* gcMsgMegacoMessage SEQUENCE/SET */
   &gcMsgMegacoMessage,
   /* gcMsgAuthenticationHeaderO SEQUENCE/SET */
   &gcMsgAuthenticationHeaderO,
   &gcMsgSecurityParmIndex,
   &gcMsgSequenceNum,
   &gcMsgAuthData,
   &gcMsgTheTerminator,
   /* gcMsgAuthenticationHeaderO End */
   /* gcMsgMessage SEQUENCE/SET */
   &gcMsgMessage,
   &gcMsgVersion,
   /* gcMsgMId CHOICE */
   &gcMsgMId,
   /* gcMsgIP4Address SEQUENCE/SET */
   &gcMsgIP4Address0,
   &gcMsgAddressIp4,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP4Address End */
   /* gcMsgIP6Address SEQUENCE/SET */
   &gcMsgIP6Address1,
   &gcMsgAddressIp6,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP6Address End */
   /* gcMsgDomainName SEQUENCE/SET */
   &gcMsgDomainName2,
   &gcMsgDomName,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgDomainName End */
   &gcMsgPathName3,
   &gcMsgMtpAddress4,
   &gcMsgTheTerminator,
   /* gcMsgMId End */
   /* gcMsgMessageBody CHOICE */
   &gcMsgMessageBody,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgTransactions SEQUENCE OF */
   &gcMsgTransactions,
   /* gcMsgTransaction CHOICE */
   &gcMsgTransaction,
   /* gcMsgTransactionRequest SEQUENCE/SET */
   &gcMsgTransactionRequest,
   &gcMsgTransactionId,
   /* gcMsgActions SEQUENCE OF */
   &gcMsgActions,
   /* gcMsgActionRequest SEQUENCE/SET */
   &gcMsgActionRequest,
   &gcMsgContextID,
   /* gcMsgContextRequestO SEQUENCE/SET */
   &gcMsgContextRequestO1,
   &gcMsgPriorityO,
   &gcMsgEmergencyO,
   /* gcMsgTopologyReqO SEQUENCE OF */
   &gcMsgTopologyReqO,
   /* gcMsgTopologyRequest SEQUENCE/SET */
   &gcMsgTopologyRequest,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID1,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTopologyDirection,
#ifdef MGT_MGCO_V2
   &gcMsgStreamIDOV2,
#endif
   &gcMsgTheTerminator,
   /* gcMsgTopologyRequest End */
   &gcMsgTheTerminator,
   /* gcMsgTopologyReqO End */
   &gcMsgTheTerminator,
   /* gcMsgContextRequestO End */
   /* gcMsgContextAttrAuditRequestO SEQUENCE/SET */
   &gcMsgContextAttrAuditRequestO,
   &gcMsgTopologyO,
   &gcMsgEmergencyReqO,
   &gcMsgPriorityReqO,
   &gcMsgTheTerminator,
   /* gcMsgContextAttrAuditRequestO End */
   /* gcMsgCommandRequests SEQUENCE OF */
   &gcMsgCommandRequests,
   /* gcMsgCommandRequest SEQUENCE/SET */
   &gcMsgCommandRequest,
   /* gcMsgCommand CHOICE */
   &gcMsgCommand,
   /* gcMsgAmmRequest SEQUENCE/SET */
   &gcMsgAmmRequest0,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgDescriptors SEQUENCE OF */
   &gcMsgDescriptors,
   /* gcMsgAmmDescriptor CHOICE */
   &gcMsgAmmDescriptor,
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor0,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor1,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor2,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor3,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor4,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor5,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor6,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptor7,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAmmDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgDescriptors End */
   &gcMsgTheTerminator,
   /* gcMsgAmmRequest End */
   /* gcMsgAmmRequest SEQUENCE/SET */
   &gcMsgAmmRequest1,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgDescriptors SEQUENCE OF */
   &gcMsgDescriptors,
   /* gcMsgAmmDescriptor CHOICE */
   &gcMsgAmmDescriptor,
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor0,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor1,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor2,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor3,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor4,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor5,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor6,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptor7,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAmmDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgDescriptors End */
   &gcMsgTheTerminator,
   /* gcMsgAmmRequest End */
   /* gcMsgAmmRequest SEQUENCE/SET */
   &gcMsgAmmRequest2,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgDescriptors SEQUENCE OF */
   &gcMsgDescriptors,
   /* gcMsgAmmDescriptor CHOICE */
   &gcMsgAmmDescriptor,
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor0,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor1,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor2,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor3,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor4,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor5,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor6,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptor7,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAmmDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgDescriptors End */
   &gcMsgTheTerminator,
   /* gcMsgAmmRequest End */
   /* gcMsgSubtractRequest SEQUENCE/SET */
   &gcMsgSubtractRequest,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgAuditDescriptorO SEQUENCE/SET */
   &gcMsgAuditDescriptorO,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSubtractRequest End */
   /* gcMsgAuditRequest SEQUENCE/SET */
   &gcMsgAuditRequest4,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptor1,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditRequest End */
   /* gcMsgAuditRequest SEQUENCE/SET */
   &gcMsgAuditRequest5,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptor1,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditRequest End */
   /* gcMsgNotifyRequest SEQUENCE/SET */
   &gcMsgNotifyRequest,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor1,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgErrorDescriptorO SEQUENCE/SET */
   &gcMsgErrorDescriptorO2,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgNotifyRequest End */
   /* gcMsgServiceChangeRequest SEQUENCE/SET */
   &gcMsgServiceChangeRequest,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgServiceChangeParm SEQUENCE/SET */
   &gcMsgServiceChangeParm,
   &gcMsgServiceChangeMethod,
   /* gcMsgServiceChangeAddressO CHOICE */
   &gcMsgServiceChangeAddressO,
   &gcMsgPortNumber,
   /* gcMsgIP4Address SEQUENCE/SET */
   &gcMsgIP4Address1,
   &gcMsgAddressIp4,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP4Address End */
   /* gcMsgIP6Address SEQUENCE/SET */
   &gcMsgIP6Address2,
   &gcMsgAddressIp6,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP6Address End */
   /* gcMsgDomainName SEQUENCE/SET */
   &gcMsgDomainName3,
   &gcMsgDomName,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgDomainName End */
   &gcMsgPathName4,
   &gcMsgMtpAddress5,
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeAddressO End */
   &gcMsgServiceChangeVersionO,
   /* gcMsgServiceChangeProfileO SEQUENCE/SET */
   &gcMsgServiceChangeProfileO,
   &gcMsgProfileName,
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeProfileO End */
   &gcMsgServiceChangeReason,
   &gcMsgServiceChangeDelayO,
   /* gcMsgMIdO CHOICE */
   &gcMsgMIdO6,
   /* gcMsgIP4Address SEQUENCE/SET */
   &gcMsgIP4Address0,
   &gcMsgAddressIp4,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP4Address End */
   /* gcMsgIP6Address SEQUENCE/SET */
   &gcMsgIP6Address1,
   &gcMsgAddressIp6,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP6Address End */
   /* gcMsgDomainName SEQUENCE/SET */
   &gcMsgDomainName2,
   &gcMsgDomName,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgDomainName End */
   &gcMsgPathName3,
   &gcMsgMtpAddress4,
   &gcMsgTheTerminator,
   /* gcMsgMIdO End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO7,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO8,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
#ifdef    MGT_MGCO_V2
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorOV2,
   &gcMsgAuditTokenO,
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeParm End */
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeRequest End */
   &gcMsgTheTerminator,
   /* gcMsgCommand End */
   &gcMsgOptionalO,
   &gcMsgWildcardReturnO,
   &gcMsgTheTerminator,
   /* gcMsgCommandRequest End */
   &gcMsgTheTerminator,
   /* gcMsgCommandRequests End */
   &gcMsgTheTerminator,
   /* gcMsgActionRequest End */
   &gcMsgTheTerminator,
   /* gcMsgActions End */
   &gcMsgTheTerminator,
   /* gcMsgTransactionRequest End */
   /* gcMsgTransactionPending SEQUENCE/SET */
   &gcMsgTransactionPending,
   &gcMsgTransactionId,
   &gcMsgTheTerminator,
   /* gcMsgTransactionPending End */
   /* gcMsgTransactionReply SEQUENCE/SET */
   &gcMsgTransactionReply,
   &gcMsgTransactionId,
   &gcMsgImmAckRequiredO,
   /* gcMsgTransactionResult CHOICE */
   &gcMsgTransactionResult,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgActionReplies SEQUENCE OF */
   &gcMsgActionReplies,
   /* gcMsgActionReply SEQUENCE/SET */
   &gcMsgActionReply,
   &gcMsgContextID,
   /* gcMsgErrorDescriptorO SEQUENCE/SET */
   &gcMsgErrorDescriptorO1,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptorO End */
   /* gcMsgContextRequestO SEQUENCE/SET */
   &gcMsgContextRequestO2,
   &gcMsgPriorityO,
   &gcMsgEmergencyO,
   /* gcMsgTopologyReqO SEQUENCE OF */
   &gcMsgTopologyReqO,
   /* gcMsgTopologyRequest SEQUENCE/SET */
   &gcMsgTopologyRequest,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID1,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTopologyDirection,
#ifdef MGT_MGCO_V2
   &gcMsgStreamIDOV2,
#endif
   &gcMsgTheTerminator,
   /* gcMsgTopologyRequest End */
   &gcMsgTheTerminator,
   /* gcMsgTopologyReqO End */
   &gcMsgTheTerminator,
   /* gcMsgContextRequestO End */
   /* gcMsgCommandReplyList SEQUENCE OF */
   &gcMsgCommandReplyList,
   /* gcMsgCommandReply CHOICE */
   &gcMsgCommandReply,
   /* gcMsgAmmsReply SEQUENCE/SET */
   &gcMsgAmmsReply0,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgTerminationAuditO SEQUENCE OF */
   &gcMsgTerminationAuditO,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAuditO End */
   &gcMsgTheTerminator,
   /* gcMsgAmmsReply End */
   /* gcMsgAmmsReply SEQUENCE/SET */
   &gcMsgAmmsReply1,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgTerminationAuditO SEQUENCE OF */
   &gcMsgTerminationAuditO,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAuditO End */
   &gcMsgTheTerminator,
   /* gcMsgAmmsReply End */
   /* gcMsgAmmsReply SEQUENCE/SET */
   &gcMsgAmmsReply2,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgTerminationAuditO SEQUENCE OF */
   &gcMsgTerminationAuditO,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAuditO End */
   &gcMsgTheTerminator,
   /* gcMsgAmmsReply End */
   /* gcMsgAmmsReply SEQUENCE/SET */
   &gcMsgAmmsReply3,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgTerminationAuditO SEQUENCE OF */
   &gcMsgTerminationAuditO,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAuditO End */
   &gcMsgTheTerminator,
   /* gcMsgAmmsReply End */
   /* gcMsgAuditReply CHOICE */
   &gcMsgAuditReply4,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor1,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgAuditResult SEQUENCE/SET */
   &gcMsgAuditResult,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgTerminationAudit SEQUENCE OF */
   &gcMsgTerminationAudit,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAudit End */
   &gcMsgTheTerminator,
   /* gcMsgAuditResult End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReply End */
   /* gcMsgAuditReply CHOICE */
   &gcMsgAuditReply5,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor1,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgAuditResult SEQUENCE/SET */
   &gcMsgAuditResult,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgTerminationAudit SEQUENCE OF */
   &gcMsgTerminationAudit,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAudit End */
   &gcMsgTheTerminator,
   /* gcMsgAuditResult End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReply End */
   /* gcMsgNotifyReply SEQUENCE/SET */
   &gcMsgNotifyReply,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgErrorDescriptorO SEQUENCE/SET */
   &gcMsgErrorDescriptorO1,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgNotifyReply End */
   /* gcMsgServiceChangeReply SEQUENCE/SET */
   &gcMsgServiceChangeReply,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgServiceChangeResult CHOICE */
   &gcMsgServiceChangeResult,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgServiceChangeResParm SEQUENCE/SET */
   &gcMsgServiceChangeResParm,
   /* gcMsgMIdO CHOICE */
   &gcMsgMIdO0,
   /* gcMsgIP4Address SEQUENCE/SET */
   &gcMsgIP4Address0,
   &gcMsgAddressIp4,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP4Address End */
   /* gcMsgIP6Address SEQUENCE/SET */
   &gcMsgIP6Address1,
   &gcMsgAddressIp6,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP6Address End */
   /* gcMsgDomainName SEQUENCE/SET */
   &gcMsgDomainName2,
   &gcMsgDomName,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgDomainName End */
   &gcMsgPathName3,
   &gcMsgMtpAddress4,
   &gcMsgTheTerminator,
   /* gcMsgMIdO End */
   /* gcMsgServiceChangeAddressO CHOICE */
   &gcMsgServiceChangeAddressO,
   &gcMsgPortNumber,
   /* gcMsgIP4Address SEQUENCE/SET */
   &gcMsgIP4Address1,
   &gcMsgAddressIp4,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP4Address End */
   /* gcMsgIP6Address SEQUENCE/SET */
   &gcMsgIP6Address2,
   &gcMsgAddressIp6,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP6Address End */
   /* gcMsgDomainName SEQUENCE/SET */
   &gcMsgDomainName3,
   &gcMsgDomName,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgDomainName End */
   &gcMsgPathName4,
   &gcMsgMtpAddress5,
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeAddressO End */
   &gcMsgServiceChangeVersionO,
   /* gcMsgServiceChangeProfileO SEQUENCE/SET */
   &gcMsgServiceChangeProfileO,
   &gcMsgProfileName,
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeProfileO End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO4,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeResParm End */
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeResult End */
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeReply End */
   &gcMsgTheTerminator,
   /* gcMsgCommandReply End */
   &gcMsgTheTerminator,
   /* gcMsgCommandReplyList End */
   &gcMsgTheTerminator,
   /* gcMsgActionReply End */
   &gcMsgTheTerminator,
   /* gcMsgActionReplies End */
   &gcMsgTheTerminator,
   /* gcMsgTransactionResult End */
   &gcMsgTheTerminator,
   /* gcMsgTransactionReply End */
   /* gcMsgTransactionResponseAck SEQUENCE OF */
   &gcMsgTransactionResponseAck,
   /* gcMsgTransactionAck SEQUENCE/SET */
   &gcMsgTransactionAck,
   &gcMsgTransactionId,
   &gcMsgTransactionIdO,
   &gcMsgTheTerminator,
   /* gcMsgTransactionAck End */
   &gcMsgTheTerminator,
   /* gcMsgTransactionResponseAck End */
   &gcMsgTheTerminator,
   /* gcMsgTransaction End */
   &gcMsgTheTerminator,
   /* gcMsgTransactions End */
   &gcMsgTheTerminator,
   /* gcMsgMessageBody End */
   &gcMsgTheTerminator,
   /* gcMsgMessage End */
   &gcMsgTheTerminator,
   /* gcMsgMegacoMessage End */
   NULLP
};

PUBLIC MgAsnElmntDef *mgaMessageBody[] =
{
   /* gcMsgMessageBody CHOICE */
   &gcMsgMessageBodySpecial0,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   &gcMsgNullSpecial1,
   &gcMsgTheTerminator,
   /* gcMsgMessageBody End */
   NULLP
};

PUBLIC MgAsnElmntDef *mgaAuthenticationHeader[] =
{
   /* gcMsgMegacoMessage SEQUENCE/SET */
   &gcMsgMegacoMessageAH,
   /* gcMsgAuthenticationHeaderO SEQUENCE/SET */
   &gcMsgAuthenticationHeaderO,
   &gcMsgSecurityParmIndex,
   &gcMsgSequenceNum,
   &gcMsgAuthData,
   &gcMsgTheTerminator,
   /* gcMsgAuthenticationHeaderO End */
   &gcMsgTheTerminator,
   /* gcMsgMegacoMessage End */
   NULLP
};

PUBLIC MgAsnElmntDef *mgaTransaction[] =
{
   /* gcMsgTransaction CHOICE */
   &gcMsgTransaction32,
   /* gcMsgTransactionRequest SEQUENCE/SET */
   &gcMsgTransactionRequest,
   &gcMsgTransactionId,
   /* gcMsgActions SEQUENCE OF */
   &gcMsgActions,
   /* gcMsgActionRequest SEQUENCE/SET */
   &gcMsgActionRequest,
   &gcMsgContextID,
   /* gcMsgContextRequestO SEQUENCE/SET */
   &gcMsgContextRequestO1,
   &gcMsgPriorityO,
   &gcMsgEmergencyO,
   /* gcMsgTopologyReqO SEQUENCE OF */
   &gcMsgTopologyReqO,
   /* gcMsgTopologyRequest SEQUENCE/SET */
   &gcMsgTopologyRequest,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID1,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTopologyDirection,
#ifdef MGT_MGCO_V2
   &gcMsgStreamIDOV2,
#endif
   &gcMsgTheTerminator,
   /* gcMsgTopologyRequest End */
   &gcMsgTheTerminator,
   /* gcMsgTopologyReqO End */
   &gcMsgTheTerminator,
   /* gcMsgContextRequestO End */
   /* gcMsgContextAttrAuditRequestO SEQUENCE/SET */
   &gcMsgContextAttrAuditRequestO,
   &gcMsgTopologyO,
   &gcMsgEmergencyReqO,
   &gcMsgPriorityReqO,
   &gcMsgTheTerminator,
   /* gcMsgContextAttrAuditRequestO End */
   /* gcMsgCommandRequests SEQUENCE OF */
   &gcMsgCommandRequests,
   /* gcMsgCommandRequest SEQUENCE/SET */
   &gcMsgCommandRequest,
   /* gcMsgCommand CHOICE */
   &gcMsgCommand,
   /* gcMsgAmmRequest SEQUENCE/SET */
   &gcMsgAmmRequest0,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgDescriptors SEQUENCE OF */
   &gcMsgDescriptors,
   /* gcMsgAmmDescriptor CHOICE */
   &gcMsgAmmDescriptor,
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor0,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor1,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor2,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor3,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor4,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor5,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor6,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptor7,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAmmDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgDescriptors End */
   &gcMsgTheTerminator,
   /* gcMsgAmmRequest End */
   /* gcMsgAmmRequest SEQUENCE/SET */
   &gcMsgAmmRequest1,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgDescriptors SEQUENCE OF */
   &gcMsgDescriptors,
   /* gcMsgAmmDescriptor CHOICE */
   &gcMsgAmmDescriptor,
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor0,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor1,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor2,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor3,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor4,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor5,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor6,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptor7,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAmmDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgDescriptors End */
   &gcMsgTheTerminator,
   /* gcMsgAmmRequest End */
   /* gcMsgAmmRequest SEQUENCE/SET */
   &gcMsgAmmRequest2,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgDescriptors SEQUENCE OF */
   &gcMsgDescriptors,
   /* gcMsgAmmDescriptor CHOICE */
   &gcMsgAmmDescriptor,
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor0,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor1,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor2,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor3,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor4,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor5,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor6,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptor7,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAmmDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgDescriptors End */
   &gcMsgTheTerminator,
   /* gcMsgAmmRequest End */
   /* gcMsgSubtractRequest SEQUENCE/SET */
   &gcMsgSubtractRequest,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgAuditDescriptorO SEQUENCE/SET */
   &gcMsgAuditDescriptorO,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSubtractRequest End */
   /* gcMsgAuditRequest SEQUENCE/SET */
   &gcMsgAuditRequest4,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptor1,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditRequest End */
   /* gcMsgAuditRequest SEQUENCE/SET */
   &gcMsgAuditRequest5,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptor1,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditRequest End */
   /* gcMsgNotifyRequest SEQUENCE/SET */
   &gcMsgNotifyRequest,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor1,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgErrorDescriptorO SEQUENCE/SET */
   &gcMsgErrorDescriptorO2,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgNotifyRequest End */
   /* gcMsgServiceChangeRequest SEQUENCE/SET */
   &gcMsgServiceChangeRequest,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgServiceChangeParm SEQUENCE/SET */
   &gcMsgServiceChangeParm,
   &gcMsgServiceChangeMethod,
   /* gcMsgServiceChangeAddressO CHOICE */
   &gcMsgServiceChangeAddressO,
   &gcMsgPortNumber,
   /* gcMsgIP4Address SEQUENCE/SET */
   &gcMsgIP4Address1,
   &gcMsgAddressIp4,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP4Address End */
   /* gcMsgIP6Address SEQUENCE/SET */
   &gcMsgIP6Address2,
   &gcMsgAddressIp6,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP6Address End */
   /* gcMsgDomainName SEQUENCE/SET */
   &gcMsgDomainName3,
   &gcMsgDomName,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgDomainName End */
   &gcMsgPathName4,
   &gcMsgMtpAddress5,
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeAddressO End */
   &gcMsgServiceChangeVersionO,
   /* gcMsgServiceChangeProfileO SEQUENCE/SET */
   &gcMsgServiceChangeProfileO,
   &gcMsgProfileName,
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeProfileO End */
   &gcMsgServiceChangeReason,
   &gcMsgServiceChangeDelayO,
   /* gcMsgMIdO CHOICE */
   &gcMsgMIdO6,
   /* gcMsgIP4Address SEQUENCE/SET */
   &gcMsgIP4Address0,
   &gcMsgAddressIp4,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP4Address End */
   /* gcMsgIP6Address SEQUENCE/SET */
   &gcMsgIP6Address1,
   &gcMsgAddressIp6,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP6Address End */
   /* gcMsgDomainName SEQUENCE/SET */
   &gcMsgDomainName2,
   &gcMsgDomName,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgDomainName End */
   &gcMsgPathName3,
   &gcMsgMtpAddress4,
   &gcMsgTheTerminator,
   /* gcMsgMIdO End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO7,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO8,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
#ifdef    MGT_MGCO_V2
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorOV2,
   &gcMsgAuditTokenO,
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeParm End */
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeRequest End */
   &gcMsgTheTerminator,
   /* gcMsgCommand End */
   &gcMsgOptionalO,
   &gcMsgWildcardReturnO,
   &gcMsgTheTerminator,
   /* gcMsgCommandRequest End */
   &gcMsgTheTerminator,
   /* gcMsgCommandRequests End */
   &gcMsgTheTerminator,
   /* gcMsgActionRequest End */
   &gcMsgTheTerminator,
   /* gcMsgActions End */
   &gcMsgTheTerminator,
   /* gcMsgTransactionRequest End */
   /* gcMsgTransactionPending SEQUENCE/SET */
   &gcMsgTransactionPending,
   &gcMsgTransactionId,
   &gcMsgTheTerminator,
   /* gcMsgTransactionPending End */
   /* gcMsgTransactionReply SEQUENCE/SET */
   &gcMsgTransactionReply,
   &gcMsgTransactionId,
   &gcMsgImmAckRequiredO,
   /* gcMsgTransactionResult CHOICE */
   &gcMsgTransactionResult,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgActionReplies SEQUENCE OF */
   &gcMsgActionReplies,
   /* gcMsgActionReply SEQUENCE/SET */
   &gcMsgActionReply,
   &gcMsgContextID,
   /* gcMsgErrorDescriptorO SEQUENCE/SET */
   &gcMsgErrorDescriptorO1,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptorO End */
   /* gcMsgContextRequestO SEQUENCE/SET */
   &gcMsgContextRequestO2,
   &gcMsgPriorityO,
   &gcMsgEmergencyO,
   /* gcMsgTopologyReqO SEQUENCE OF */
   &gcMsgTopologyReqO,
   /* gcMsgTopologyRequest SEQUENCE/SET */
   &gcMsgTopologyRequest,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID1,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTopologyDirection,
#ifdef MGT_MGCO_V2
   &gcMsgStreamIDOV2,
#endif
   &gcMsgTheTerminator,
   /* gcMsgTopologyRequest End */
   &gcMsgTheTerminator,
   /* gcMsgTopologyReqO End */
   &gcMsgTheTerminator,
   /* gcMsgContextRequestO End */
   /* gcMsgCommandReplyList SEQUENCE OF */
   &gcMsgCommandReplyList,
   /* gcMsgCommandReply CHOICE */
   &gcMsgCommandReply,
   /* gcMsgAmmsReply SEQUENCE/SET */
   &gcMsgAmmsReply0,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgTerminationAuditO SEQUENCE OF */
   &gcMsgTerminationAuditO,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAuditO End */
   &gcMsgTheTerminator,
   /* gcMsgAmmsReply End */
   /* gcMsgAmmsReply SEQUENCE/SET */
   &gcMsgAmmsReply1,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgTerminationAuditO SEQUENCE OF */
   &gcMsgTerminationAuditO,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAuditO End */
   &gcMsgTheTerminator,
   /* gcMsgAmmsReply End */
   /* gcMsgAmmsReply SEQUENCE/SET */
   &gcMsgAmmsReply2,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgTerminationAuditO SEQUENCE OF */
   &gcMsgTerminationAuditO,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAuditO End */
   &gcMsgTheTerminator,
   /* gcMsgAmmsReply End */
   /* gcMsgAmmsReply SEQUENCE/SET */
   &gcMsgAmmsReply3,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgTerminationAuditO SEQUENCE OF */
   &gcMsgTerminationAuditO,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAuditO End */
   &gcMsgTheTerminator,
   /* gcMsgAmmsReply End */
   /* gcMsgAuditReply CHOICE */
   &gcMsgAuditReply4,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor1,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgAuditResult SEQUENCE/SET */
   &gcMsgAuditResult,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgTerminationAudit SEQUENCE OF */
   &gcMsgTerminationAudit,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAudit End */
   &gcMsgTheTerminator,
   /* gcMsgAuditResult End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReply End */
   /* gcMsgAuditReply CHOICE */
   &gcMsgAuditReply5,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor1,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgAuditResult SEQUENCE/SET */
   &gcMsgAuditResult,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgTerminationAudit SEQUENCE OF */
   &gcMsgTerminationAudit,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAudit End */
   &gcMsgTheTerminator,
   /* gcMsgAuditResult End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReply End */
   /* gcMsgNotifyReply SEQUENCE/SET */
   &gcMsgNotifyReply,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgErrorDescriptorO SEQUENCE/SET */
   &gcMsgErrorDescriptorO1,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgNotifyReply End */
   /* gcMsgServiceChangeReply SEQUENCE/SET */
   &gcMsgServiceChangeReply,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgServiceChangeResult CHOICE */
   &gcMsgServiceChangeResult,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgServiceChangeResParm SEQUENCE/SET */
   &gcMsgServiceChangeResParm,
   /* gcMsgMIdO CHOICE */
   &gcMsgMIdO0,
   /* gcMsgIP4Address SEQUENCE/SET */
   &gcMsgIP4Address0,
   &gcMsgAddressIp4,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP4Address End */
   /* gcMsgIP6Address SEQUENCE/SET */
   &gcMsgIP6Address1,
   &gcMsgAddressIp6,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP6Address End */
   /* gcMsgDomainName SEQUENCE/SET */
   &gcMsgDomainName2,
   &gcMsgDomName,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgDomainName End */
   &gcMsgPathName3,
   &gcMsgMtpAddress4,
   &gcMsgTheTerminator,
   /* gcMsgMIdO End */
   /* gcMsgServiceChangeAddressO CHOICE */
   &gcMsgServiceChangeAddressO,
   &gcMsgPortNumber,
   /* gcMsgIP4Address SEQUENCE/SET */
   &gcMsgIP4Address1,
   &gcMsgAddressIp4,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP4Address End */
   /* gcMsgIP6Address SEQUENCE/SET */
   &gcMsgIP6Address2,
   &gcMsgAddressIp6,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP6Address End */
   /* gcMsgDomainName SEQUENCE/SET */
   &gcMsgDomainName3,
   &gcMsgDomName,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgDomainName End */
   &gcMsgPathName4,
   &gcMsgMtpAddress5,
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeAddressO End */
   &gcMsgServiceChangeVersionO,
   /* gcMsgServiceChangeProfileO SEQUENCE/SET */
   &gcMsgServiceChangeProfileO,
   &gcMsgProfileName,
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeProfileO End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO4,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeResParm End */
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeResult End */
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeReply End */
   &gcMsgTheTerminator,
   /* gcMsgCommandReply End */
   &gcMsgTheTerminator,
   /* gcMsgCommandReplyList End */
   &gcMsgTheTerminator,
   /* gcMsgActionReply End */
   &gcMsgTheTerminator,
   /* gcMsgActionReplies End */
   &gcMsgTheTerminator,
   /* gcMsgTransactionResult End */
   &gcMsgTheTerminator,
   /* gcMsgTransactionReply End */
   /* gcMsgTransactionResponseAck SEQUENCE OF */
   &gcMsgTransactionResponseAck,
   /* gcMsgTransactionAck SEQUENCE/SET */
   &gcMsgTransactionAck,
   &gcMsgTransactionId,
   &gcMsgTransactionIdO,
   &gcMsgTheTerminator,
   /* gcMsgTransactionAck End */
   &gcMsgTheTerminator,
   /* gcMsgTransactionResponseAck End */
   &gcMsgTheTerminator,
   /* gcMsgTransaction End */
   NULLP
};

PUBLIC MgAsnElmntDef *mgaTransaction0[] =
{
   /* gcMsgMessageBody CHOICE */
   &gcMsgMessageBodySpecial2,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgTransactions SEQUENCE OF */
   &gcMsgTransactionsSpecial,
   /* gcMsgTransaction CHOICE */
   &gcMsgTransaction,
   /* gcMsgTransactionRequest SEQUENCE/SET */
   &gcMsgTransactionRequest,
   &gcMsgTransactionId,
   /* gcMsgActions SEQUENCE OF */
   &gcMsgActions,
   /* gcMsgActionRequest SEQUENCE/SET */
   &gcMsgActionRequest,
   &gcMsgContextID,
   /* gcMsgContextRequestO SEQUENCE/SET */
   &gcMsgContextRequestO1,
   &gcMsgPriorityO,
   &gcMsgEmergencyO,
   /* gcMsgTopologyReqO SEQUENCE OF */
   &gcMsgTopologyReqO,
   /* gcMsgTopologyRequest SEQUENCE/SET */
   &gcMsgTopologyRequest,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID1,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTopologyDirection,
#ifdef MGT_MGCO_V2
   &gcMsgStreamIDOV2,
#endif
   &gcMsgTheTerminator,
   /* gcMsgTopologyRequest End */
   &gcMsgTheTerminator,
   /* gcMsgTopologyReqO End */
   &gcMsgTheTerminator,
   /* gcMsgContextRequestO End */
   /* gcMsgContextAttrAuditRequestO SEQUENCE/SET */
   &gcMsgContextAttrAuditRequestO,
   &gcMsgTopologyO,
   &gcMsgEmergencyReqO,
   &gcMsgPriorityReqO,
   &gcMsgTheTerminator,
   /* gcMsgContextAttrAuditRequestO End */
   /* gcMsgCommandRequests SEQUENCE OF */
   &gcMsgCommandRequests,
   /* gcMsgCommandRequest SEQUENCE/SET */
   &gcMsgCommandRequest,
   /* gcMsgCommand CHOICE */
   &gcMsgCommand,
   /* gcMsgAmmRequest SEQUENCE/SET */
   &gcMsgAmmRequest0,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgDescriptors SEQUENCE OF */
   &gcMsgDescriptors,
   /* gcMsgAmmDescriptor CHOICE */
   &gcMsgAmmDescriptor,
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor0,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor1,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor2,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor3,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor4,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor5,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor6,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptor7,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAmmDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgDescriptors End */
   &gcMsgTheTerminator,
   /* gcMsgAmmRequest End */
   /* gcMsgAmmRequest SEQUENCE/SET */
   &gcMsgAmmRequest1,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgDescriptors SEQUENCE OF */
   &gcMsgDescriptors,
   /* gcMsgAmmDescriptor CHOICE */
   &gcMsgAmmDescriptor,
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor0,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor1,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor2,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor3,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor4,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor5,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor6,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptor7,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAmmDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgDescriptors End */
   &gcMsgTheTerminator,
   /* gcMsgAmmRequest End */
   /* gcMsgAmmRequest SEQUENCE/SET */
   &gcMsgAmmRequest2,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgDescriptors SEQUENCE OF */
   &gcMsgDescriptors,
   /* gcMsgAmmDescriptor CHOICE */
   &gcMsgAmmDescriptor,
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor0,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor1,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor2,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor3,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor4,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor5,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor6,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptor7,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAmmDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgDescriptors End */
   &gcMsgTheTerminator,
   /* gcMsgAmmRequest End */
   /* gcMsgSubtractRequest SEQUENCE/SET */
   &gcMsgSubtractRequest,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgAuditDescriptorO SEQUENCE/SET */
   &gcMsgAuditDescriptorO,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSubtractRequest End */
   /* gcMsgAuditRequest SEQUENCE/SET */
   &gcMsgAuditRequest4,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptor1,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditRequest End */
   /* gcMsgAuditRequest SEQUENCE/SET */
   &gcMsgAuditRequest5,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptor1,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditRequest End */
   /* gcMsgNotifyRequest SEQUENCE/SET */
   &gcMsgNotifyRequest,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor1,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgErrorDescriptorO SEQUENCE/SET */
   &gcMsgErrorDescriptorO2,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgNotifyRequest End */
   /* gcMsgServiceChangeRequest SEQUENCE/SET */
   &gcMsgServiceChangeRequest,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgServiceChangeParm SEQUENCE/SET */
   &gcMsgServiceChangeParm,
   &gcMsgServiceChangeMethod,
   /* gcMsgServiceChangeAddressO CHOICE */
   &gcMsgServiceChangeAddressO,
   &gcMsgPortNumber,
   /* gcMsgIP4Address SEQUENCE/SET */
   &gcMsgIP4Address1,
   &gcMsgAddressIp4,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP4Address End */
   /* gcMsgIP6Address SEQUENCE/SET */
   &gcMsgIP6Address2,
   &gcMsgAddressIp6,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP6Address End */
   /* gcMsgDomainName SEQUENCE/SET */
   &gcMsgDomainName3,
   &gcMsgDomName,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgDomainName End */
   &gcMsgPathName4,
   &gcMsgMtpAddress5,
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeAddressO End */
   &gcMsgServiceChangeVersionO,
   /* gcMsgServiceChangeProfileO SEQUENCE/SET */
   &gcMsgServiceChangeProfileO,
   &gcMsgProfileName,
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeProfileO End */
   &gcMsgServiceChangeReason,
   &gcMsgServiceChangeDelayO,
   /* gcMsgMIdO CHOICE */
   &gcMsgMIdO6,
   /* gcMsgIP4Address SEQUENCE/SET */
   &gcMsgIP4Address0,
   &gcMsgAddressIp4,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP4Address End */
   /* gcMsgIP6Address SEQUENCE/SET */
   &gcMsgIP6Address1,
   &gcMsgAddressIp6,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP6Address End */
   /* gcMsgDomainName SEQUENCE/SET */
   &gcMsgDomainName2,
   &gcMsgDomName,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgDomainName End */
   &gcMsgPathName3,
   &gcMsgMtpAddress4,
   &gcMsgTheTerminator,
   /* gcMsgMIdO End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO7,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO8,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
#ifdef    MGT_MGCO_V2
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorOV2,
   &gcMsgAuditTokenO,
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeParm End */
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeRequest End */
   &gcMsgTheTerminator,
   /* gcMsgCommand End */
   &gcMsgOptionalO,
   &gcMsgWildcardReturnO,
   &gcMsgTheTerminator,
   /* gcMsgCommandRequest End */
   &gcMsgTheTerminator,
   /* gcMsgCommandRequests End */
   &gcMsgTheTerminator,
   /* gcMsgActionRequest End */
   &gcMsgTheTerminator,
   /* gcMsgActions End */
   &gcMsgTheTerminator,
   /* gcMsgTransactionRequest End */
   /* gcMsgTransactionPending SEQUENCE/SET */
   &gcMsgTransactionPending,
   &gcMsgTransactionId,
   &gcMsgTheTerminator,
   /* gcMsgTransactionPending End */
   /* gcMsgTransactionReply SEQUENCE/SET */
   &gcMsgTransactionReply,
   &gcMsgTransactionId,
   &gcMsgImmAckRequiredO,
   /* gcMsgTransactionResult CHOICE */
   &gcMsgTransactionResult,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgActionReplies SEQUENCE OF */
   &gcMsgActionReplies,
   /* gcMsgActionReply SEQUENCE/SET */
   &gcMsgActionReply,
   &gcMsgContextID,
   /* gcMsgErrorDescriptorO SEQUENCE/SET */
   &gcMsgErrorDescriptorO1,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptorO End */
   /* gcMsgContextRequestO SEQUENCE/SET */
   &gcMsgContextRequestO2,
   &gcMsgPriorityO,
   &gcMsgEmergencyO,
   /* gcMsgTopologyReqO SEQUENCE OF */
   &gcMsgTopologyReqO,
   /* gcMsgTopologyRequest SEQUENCE/SET */
   &gcMsgTopologyRequest,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID1,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTopologyDirection,
#ifdef MGT_MGCO_V2
   &gcMsgStreamIDOV2,
#endif
   &gcMsgTheTerminator,
   /* gcMsgTopologyRequest End */
   &gcMsgTheTerminator,
   /* gcMsgTopologyReqO End */
   &gcMsgTheTerminator,
   /* gcMsgContextRequestO End */
   /* gcMsgCommandReplyList SEQUENCE OF */
   &gcMsgCommandReplyList,
   /* gcMsgCommandReply CHOICE */
   &gcMsgCommandReply,
   /* gcMsgAmmsReply SEQUENCE/SET */
   &gcMsgAmmsReply0,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgTerminationAuditO SEQUENCE OF */
   &gcMsgTerminationAuditO,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAuditO End */
   &gcMsgTheTerminator,
   /* gcMsgAmmsReply End */
   /* gcMsgAmmsReply SEQUENCE/SET */
   &gcMsgAmmsReply1,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgTerminationAuditO SEQUENCE OF */
   &gcMsgTerminationAuditO,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAuditO End */
   &gcMsgTheTerminator,
   /* gcMsgAmmsReply End */
   /* gcMsgAmmsReply SEQUENCE/SET */
   &gcMsgAmmsReply2,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgTerminationAuditO SEQUENCE OF */
   &gcMsgTerminationAuditO,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAuditO End */
   &gcMsgTheTerminator,
   /* gcMsgAmmsReply End */
   /* gcMsgAmmsReply SEQUENCE/SET */
   &gcMsgAmmsReply3,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgTerminationAuditO SEQUENCE OF */
   &gcMsgTerminationAuditO,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAuditO End */
   &gcMsgTheTerminator,
   /* gcMsgAmmsReply End */
   /* gcMsgAuditReply CHOICE */
   &gcMsgAuditReply4,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor1,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgAuditResult SEQUENCE/SET */
   &gcMsgAuditResult,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgTerminationAudit SEQUENCE OF */
   &gcMsgTerminationAudit,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAudit End */
   &gcMsgTheTerminator,
   /* gcMsgAuditResult End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReply End */
   /* gcMsgAuditReply CHOICE */
   &gcMsgAuditReply5,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor1,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgAuditResult SEQUENCE/SET */
   &gcMsgAuditResult,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID0,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   /* gcMsgTerminationAudit SEQUENCE OF */
   &gcMsgTerminationAudit,
   /* gcMsgAuditReturnParameter CHOICE */
   &gcMsgAuditReturnParameter,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgMediaDescriptor SEQUENCE/SET */
   &gcMsgMediaDescriptor1,
   /* gcMsgTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgTerminationStateDescriptorO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms0,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgEventBufferControlO,
   &gcMsgServiceStateO,
   &gcMsgTheTerminator,
   /* gcMsgTerminationStateDescriptorO End */
   /* gcMsgStreamsO CHOICE */
   &gcMsgStreamsO,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParmsSpecial,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   /* gcMsgMultiStream SEQUENCE OF */
   &gcMsgMultiStream,
   /* gcMsgStreamDescriptor SEQUENCE/SET */
   &gcMsgStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgStreamParms SEQUENCE/SET */
   &gcMsgStreamParms,
   /* gcMsgLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgLocalControlDescriptorO,
   &gcMsgStreamModeO,
   &gcMsgReserveValueO,
   &gcMsgReserveGroupO,
   /* gcMsgPropertyParms SEQUENCE OF */
   &gcMsgPropertyParms3,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParms End */
   &gcMsgTheTerminator,
   /* gcMsgLocalControlDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO1,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   /* gcMsgLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgLocalRemoteDescriptorO2,
   /* gcMsgPropGrps SEQUENCE OF */
   &gcMsgPropGrps,
   /* gcMsgPropertyGroup SEQUENCE OF */
   &gcMsgPropertyGroup,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdNameSpecial,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOfSpecial,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgPropGrps End */
   &gcMsgTheTerminator,
   /* gcMsgLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStream End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsO End */
   &gcMsgTheTerminator,
   /* gcMsgMediaDescriptor End */
   /* gcMsgModemDescriptor SEQUENCE/SET */
   &gcMsgModemDescriptor2,
   /* gcMsgMtl SEQUENCE OF */
   &gcMsgMtl,
   &gcMsgModemType,
   &gcMsgTheTerminator,
   /* gcMsgMtl End */
   /* gcMsgMpl SEQUENCE OF */
   &gcMsgMpl,
   /* gcMsgPropertyParm SEQUENCE/SET */
   &gcMsgPropertyParm,
   &gcMsgPkgdName0,
   /* gcMsgPropParmValue SEQUENCE OF */
   &gcMsgPropParmValue,
   &gcMsgPropParmValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgPropParmValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgMpl End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgModemDescriptor End */
   /* gcMsgMuxDescriptor SEQUENCE/SET */
   &gcMsgMuxDescriptor3,
   &gcMsgMuxType,
   /* gcMsgTermList SEQUENCE OF */
   &gcMsgTermList,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTermList End */
   /* gcMsgNonStandardDataO SEQUENCE/SET */
   &gcMsgNonStandardDataO2,
   /* gcMsgNonStandardIdentifier CHOICE */
   &gcMsgNonStandardIdentifier,
   &gcMsgObject,
   /* gcMsgH221NonStandard SEQUENCE/SET */
   &gcMsgH221NonStandard,
   &gcMsgT35CountryCode1,
   &gcMsgT35CountryCode2,
   &gcMsgT35Extension,
   &gcMsgManufacturerCode,
   &gcMsgTheTerminator,
   /* gcMsgH221NonStandard End */
   &gcMsgExperimental,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardIdentifier End */
   &gcMsgData,
   &gcMsgTheTerminator,
   /* gcMsgNonStandardDataO End */
   &gcMsgTheTerminator,
   /* gcMsgMuxDescriptor End */
   /* gcMsgEventsDescriptor SEQUENCE/SET */
   &gcMsgEventsDescriptor4,
   &gcMsgRequestIDO,
   /* gcMsgEventList SEQUENCE OF */
   &gcMsgEventList,
   /* gcMsgRequestedEvent SEQUENCE/SET */
   &gcMsgRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgRequestedActionsO SEQUENCE/SET */
   &gcMsgRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSecondEventsDescriptorO SEQUENCE/SET */
   &gcMsgSecondEventsDescriptorO,
   &gcMsgRequestIDO,
   /* gcMsgSecondEventList SEQUENCE OF */
   &gcMsgSecondEventList,
   /* gcMsgSecondRequestedEvent SEQUENCE/SET */
   &gcMsgSecondRequestedEvent,
   &gcMsgPkgdNameO0,
   &gcMsgStreamIDO1,
   /* gcMsgSecondRequestedActionsO SEQUENCE/SET */
   &gcMsgSecondRequestedActionsO,
   &gcMsgKeepActiveO0,
   /* gcMsgEventDMO CHOICE */
   &gcMsgEventDMO,
   &gcMsgName,
   /* gcMsgDigitMapValue SEQUENCE/SET */
   &gcMsgDigitMapValue,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValue End */
   &gcMsgTheTerminator,
   /* gcMsgEventDMO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO2,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventList End */
   &gcMsgTheTerminator,
   /* gcMsgSecondEventsDescriptorO End */
   /* gcMsgSignalsDescriptorO SEQUENCE OF */
   &gcMsgSignalsDescriptorO3,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedActionsO End */
   /* gcMsgEvParList SEQUENCE OF */
   &gcMsgEvParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEvParList End */
   &gcMsgTheTerminator,
   /* gcMsgRequestedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgEventList End */
   &gcMsgTheTerminator,
   /* gcMsgEventsDescriptor End */
   /* gcMsgEventBufferDescriptor SEQUENCE OF */
   &gcMsgEventBufferDescriptor5,
   /* gcMsgEventSpec SEQUENCE/SET */
   &gcMsgEventSpec,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   &gcMsgTheTerminator,
   /* gcMsgEventSpec End */
   &gcMsgTheTerminator,
   /* gcMsgEventBufferDescriptor End */
   /* gcMsgSignalsDescriptor SEQUENCE OF */
   &gcMsgSignalsDescriptor6,
   /* gcMsgSignalRequest CHOICE */
   &gcMsgSignalRequest,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   /* gcMsgSeqSigList SEQUENCE/SET */
   &gcMsgSeqSigList,
   &gcMsgIdSeqSig,
   /* gcMsgSignalList SEQUENCE OF */
   &gcMsgSignalList,
   /* gcMsgSignal SEQUENCE/SET */
   &gcMsgSignal30,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgSignalTypeO,
   &gcMsgDurationO,
   &gcMsgNotifyCompletionO,
   &gcMsgKeepActiveO5,
   /* gcMsgSigParList SEQUENCE OF */
   &gcMsgSigParList,
   /* gcMsgSigParameter SEQUENCE/SET */
   &gcMsgSigParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgSigParameter End */
   &gcMsgTheTerminator,
   /* gcMsgSigParList End */
   &gcMsgTheTerminator,
   /* gcMsgSignal End */
   &gcMsgTheTerminator,
   /* gcMsgSignalList End */
   &gcMsgTheTerminator,
   /* gcMsgSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgSignalRequest End */
   &gcMsgTheTerminator,
   /* gcMsgSignalsDescriptor End */
   /* gcMsgDigitMapDescriptor SEQUENCE/SET */
   &gcMsgDigitMapDescriptor7,
   &gcMsgNameO,
   /* gcMsgDigitMapValueO SEQUENCE/SET */
   &gcMsgDigitMapValueO,
   &gcMsgStartTimerO,
   &gcMsgShortTimerO,
   &gcMsgLongTimerO,
   &gcMsgDigitMapBody,
#ifdef MGT_MGCO_V2
   &gcMsgDurationTimerO,
#endif
   &gcMsgTheTerminator,
   /* gcMsgDigitMapValueO End */
   &gcMsgTheTerminator,
   /* gcMsgDigitMapDescriptor End */
   /* gcMsgObservedEventsDescriptor SEQUENCE/SET */
   &gcMsgObservedEventsDescriptor8,
   &gcMsgRequestID,
   /* gcMsgObservedEventLst SEQUENCE OF */
   &gcMsgObservedEventLst,
   /* gcMsgObservedEvent SEQUENCE/SET */
   &gcMsgObservedEvent,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   /* gcMsgEventParList SEQUENCE OF */
   &gcMsgEventParList,
   /* gcMsgEventParameter SEQUENCE/SET */
   &gcMsgEventParameter,
   &gcMsgNameSpecial,
   /* gcMsgValue SEQUENCE OF */
   &gcMsgValue,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValue End */
   /* gcMsgExtraInfoO CHOICE */
   &gcMsgExtraInfoO,
   &gcMsgRelation,
   &gcMsgRange,
   &gcMsgSublist,
   &gcMsgTheTerminator,
   /* gcMsgExtraInfoO End */
   &gcMsgTheTerminator,
   /* gcMsgEventParameter End */
   &gcMsgTheTerminator,
   /* gcMsgEventParList End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO3,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEvent End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventLst End */
   &gcMsgTheTerminator,
   /* gcMsgObservedEventsDescriptor End */
   /* gcMsgStatisticsDescriptor SEQUENCE OF */
   &gcMsgStatisticsDescriptor,
   /* gcMsgStatisticsParameter SEQUENCE/SET */
   &gcMsgStatisticsParameter,
   &gcMsgPkgdName0,
   /* gcMsgValueO SEQUENCE OF */
   &gcMsgValueO,
   &gcMsgValueSeqOf,
   &gcMsgTheTerminator,
   /* gcMsgValueO End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsParameter End */
   &gcMsgTheTerminator,
   /* gcMsgStatisticsDescriptor End */
   /* gcMsgPackagesDescriptor SEQUENCE OF */
   &gcMsgPackagesDescriptor,
   /* gcMsgPackagesItem SEQUENCE/SET */
   &gcMsgPackagesItem,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgPackagesItem End */
   &gcMsgTheTerminator,
   /* gcMsgPackagesDescriptor End */
   /* gcMsgAuditDescriptor SEQUENCE/SET */
   &gcMsgAuditDescriptorB,
   &gcMsgAuditTokenO,
#ifdef    MGT_MGCO_V2
   /* gcMsgIndAuditParametersO SEQUENCE OF */
   &gcMsgIndAuditParametersO, 
   /* gcMsgIndAuditParameter CHOICE */
   &gcMsgIndAuditParameter,
   /* gcMsgIndAudMediaDescriptor SEQUENCE/SET */
   &gcMsgIndAudMediaDescriptor,
   /* gcMsgIndAudTerminationStateDescriptorO SEQUENCE/SET */
   &gcMsgIndAudTerminationStateDescriptorO,
   /* gcMsgPropertyParmsIndAud SEQUENCE OF */
   &gcMsgPropertyParmsIndAud,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAud End */
   &gcMsgEventBufferControlIndAudO,
   &gcMsgServiceStateIndAudO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudTerminationStateDescriptorO End */
   /* gcMsgStreamsIndAudO CHOICE */
   &gcMsgStreamsIndAudO,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms0,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   /* gcMsgMultiStreamIndAud SEQUENCE OF */
   &gcMsgMultiStreamIndAud,
   /* gcMsgIndAudStreamDescriptor SEQUENCE/SET */
   &gcMsgIndAudStreamDescriptor,
   &gcMsgStreamID,
   /* gcMsgIndAudStreamParms SEQUENCE/SET */
   &gcMsgIndAudStreamParms1,
   /* gcMsgIndAudLocalControlDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalControlDescriptorO,
   &gcMsgStreamModeIndAudO,
   &gcMsgReserveValueIndAudO,
   &gcMsgReserveGroupIndAudO,
   /* gcMsgPropertyParmsIndAudO SEQUENCE OF */
   &gcMsgPropertyParmsIndAudO,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgPropertyParmsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalControlDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO1,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   /* gcMsgIndAudLocalRemoteDescriptorO SEQUENCE/SET */
   &gcMsgIndAudLocalRemoteDescriptorO2,
   &gcMsgPropGroupIDO,
   /* gcMsgIndAudPropertyGroup SEQUENCE OF */
   &gcMsgIndAudPropertyGroup,
   /* gcMsgIndAudPropertyParm SEQUENCE/SET */
   &gcMsgIndAudPropertyParm,
   &gcMsgPkgdNameSpecial,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyParm End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudPropertyGroup End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudLocalRemoteDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamParms End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudStreamDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMultiStreamIndAud End */
   &gcMsgTheTerminator,
   /* gcMsgStreamsIndAudO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudMediaDescriptor End */
   /* gcMsgIndAudEventsDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventsDescriptor,
   &gcMsgRequestIDO,
   &gcMsgPkgdName1,
   &gcMsgStreamIDO2,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventsDescriptor End */
   /* gcMsgIndAudEventBufferDescriptor SEQUENCE/SET */
   &gcMsgIndAudEventBufferDescriptor,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudEventBufferDescriptor End */
   /* gcMsgIndAudSignalsDescriptor CHOICE */
   &gcMsgIndAudSignalsDescriptor,
   /* gcMsgIndAudSignal SEQUENCE/SET */
   &gcMsgIndAudSignal,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignal End */
   /* gcMsgIndAudSeqSigList SEQUENCE/SET */
   &gcMsgIndAudSeqSigList,
   &gcMsgIdNum,
   /* gcMsgIndAudSignalO SEQUENCE/SET */
   &gcMsgIndAudSignalO,
   &gcMsgPkgdName0,
   &gcMsgStreamIDO1,
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalO End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSeqSigList End */
   &gcMsgTheTerminator,
   /* gcMsgIndAudSignalsDescriptor End */
   /* gcMsgIndAudDigitMapDescriptor SEQUENCE/SET */
   &gcMsgIndAudDigitMapDescriptor,
   &gcMsgDigitMapNameO,
   &gcMsgTheTerminator,
   /* gcMsgIndAudDigitMapDescriptor End */
   /* gcMsgIndAudStatisticsDescriptor SEQUENCE/SET */
   &gcMsgIndAudStatisticsDescriptor,
   &gcMsgPkgdName0,
   &gcMsgTheTerminator,
   /* gcMsgIndAudStatisticsDescriptor End */
   /* gcMsgIndAudPackagesDescriptor SEQUENCE/SET */
   &gcMsgIndAudPackagesDescriptor,
   &gcMsgName,
   &gcMsgPackageVersion,
   &gcMsgTheTerminator,
   /* gcMsgIndAudPackagesDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParameter End */
   &gcMsgTheTerminator,
   /* gcMsgIndAuditParametersO End */
#endif
   &gcMsgTheTerminator,
   /* gcMsgAuditDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReturnParameter End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationAudit End */
   &gcMsgTheTerminator,
   /* gcMsgAuditResult End */
   &gcMsgTheTerminator,
   /* gcMsgAuditReply End */
   /* gcMsgNotifyReply SEQUENCE/SET */
   &gcMsgNotifyReply,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgErrorDescriptorO SEQUENCE/SET */
   &gcMsgErrorDescriptorO1,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptorO End */
   &gcMsgTheTerminator,
   /* gcMsgNotifyReply End */
   /* gcMsgServiceChangeReply SEQUENCE/SET */
   &gcMsgServiceChangeReply,
   /* gcMsgTerminationIDList SEQUENCE OF */
   &gcMsgTerminationIDListSpecial,
   /* gcMsgTerminationID SEQUENCE/SET */
   &gcMsgTerminationID30,
   /* gcMsgWildcard SEQUENCE OF */
   &gcMsgWildcard,
   &gcMsgWildcardField,
   &gcMsgTheTerminator,
   /* gcMsgWildcard End */
   &gcMsgId,
   &gcMsgTheTerminator,
   /* gcMsgTerminationID End */
   &gcMsgTheTerminator,
   /* gcMsgTerminationIDList End */
   /* gcMsgServiceChangeResult CHOICE */
   &gcMsgServiceChangeResult,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   /* gcMsgServiceChangeResParm SEQUENCE/SET */
   &gcMsgServiceChangeResParm,
   /* gcMsgMIdO CHOICE */
   &gcMsgMIdO0,
   /* gcMsgIP4Address SEQUENCE/SET */
   &gcMsgIP4Address0,
   &gcMsgAddressIp4,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP4Address End */
   /* gcMsgIP6Address SEQUENCE/SET */
   &gcMsgIP6Address1,
   &gcMsgAddressIp6,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP6Address End */
   /* gcMsgDomainName SEQUENCE/SET */
   &gcMsgDomainName2,
   &gcMsgDomName,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgDomainName End */
   &gcMsgPathName3,
   &gcMsgMtpAddress4,
   &gcMsgTheTerminator,
   /* gcMsgMIdO End */
   /* gcMsgServiceChangeAddressO CHOICE */
   &gcMsgServiceChangeAddressO,
   &gcMsgPortNumber,
   /* gcMsgIP4Address SEQUENCE/SET */
   &gcMsgIP4Address1,
   &gcMsgAddressIp4,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP4Address End */
   /* gcMsgIP6Address SEQUENCE/SET */
   &gcMsgIP6Address2,
   &gcMsgAddressIp6,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP6Address End */
   /* gcMsgDomainName SEQUENCE/SET */
   &gcMsgDomainName3,
   &gcMsgDomName,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgDomainName End */
   &gcMsgPathName4,
   &gcMsgMtpAddress5,
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeAddressO End */
   &gcMsgServiceChangeVersionO,
   /* gcMsgServiceChangeProfileO SEQUENCE/SET */
   &gcMsgServiceChangeProfileO,
   &gcMsgProfileName,
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeProfileO End */
   /* gcMsgTimeNotationO SEQUENCE/SET */
   &gcMsgTimeNotationO4,
   &gcMsgDate,
   &gcMsgTime,
   &gcMsgTheTerminator,
   /* gcMsgTimeNotationO End */
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeResParm End */
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeResult End */
   &gcMsgTheTerminator,
   /* gcMsgServiceChangeReply End */
   &gcMsgTheTerminator,
   /* gcMsgCommandReply End */
   &gcMsgTheTerminator,
   /* gcMsgCommandReplyList End */
   &gcMsgTheTerminator,
   /* gcMsgActionReply End */
   &gcMsgTheTerminator,
   /* gcMsgActionReplies End */
   &gcMsgTheTerminator,
   /* gcMsgTransactionResult End */
   &gcMsgTheTerminator,
   /* gcMsgTransactionReply End */
   /* gcMsgTransactionResponseAck SEQUENCE OF */
   &gcMsgTransactionResponseAck,
   /* gcMsgTransactionAck SEQUENCE/SET */
   &gcMsgTransactionAck,
   &gcMsgTransactionId,
   &gcMsgTransactionIdO,
   &gcMsgTheTerminator,
   /* gcMsgTransactionAck End */
   &gcMsgTheTerminator,
   /* gcMsgTransactionResponseAck End */
   &gcMsgTheTerminator,
   /* gcMsgTransaction End */
   &gcMsgTheTerminator,
   /* gcMsgTransactions End */
   &gcMsgTheTerminator,
   /* gcMsgMessageBody End */
   NULLP
};

PUBLIC MgAsnElmntDef *mgaHeaderEncode[] =
{
   /* gcMsgMegacoMessage SEQUENCE/SET */
   &gcMsgMegacoMessageHE,
   /* gcMsgAuthenticationHeaderO SEQUENCE/SET */
   &gcMsgAuthenticationHeaderO,
   &gcMsgSecurityParmIndex,
   &gcMsgSequenceNum,
   &gcMsgAuthData,
   &gcMsgTheTerminator,
   /* gcMsgAuthenticationHeaderO End */
   /* gcMsgMessage SEQUENCE/SET */
   &gcMsgMessageHE,
   &gcMsgVersion,
   /* gcMsgMId CHOICE */
   &gcMsgMId,
   /* gcMsgIP4Address SEQUENCE/SET */
   &gcMsgIP4Address0,
   &gcMsgAddressIp4,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP4Address End */
   /* gcMsgIP6Address SEQUENCE/SET */
   &gcMsgIP6Address1,
   &gcMsgAddressIp6,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP6Address End */
   /* gcMsgDomainName SEQUENCE/SET */
   &gcMsgDomainName2,
   &gcMsgDomName,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgDomainName End */
   &gcMsgPathName3,
   &gcMsgMtpAddress4,
   &gcMsgTheTerminator,
   /* gcMsgMId End */
   &gcMsgTheTerminator,
   /* gcMsgMessage End */
   &gcMsgTheTerminator,
   NULLP
};

PUBLIC MgAsnElmntDef *mgaHeaderDecode[] =
{
   /* gcMsgMessage SEQUENCE/SET */
   &gcMsgMessageHD,
   &gcMsgVersion,
   /* gcMsgMId CHOICE */
   &gcMsgMId,
   /* gcMsgIP4Address SEQUENCE/SET */
   &gcMsgIP4Address0,
   &gcMsgAddressIp4,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP4Address End */
   /* gcMsgIP6Address SEQUENCE/SET */
   &gcMsgIP6Address1,
   &gcMsgAddressIp6,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgIP6Address End */
   /* gcMsgDomainName SEQUENCE/SET */
   &gcMsgDomainName2,
   &gcMsgDomName,
   &gcMsgPortNumberO,
   &gcMsgTheTerminator,
   /* gcMsgDomainName End */
   &gcMsgPathName3,
   &gcMsgMtpAddress4,
   &gcMsgTheTerminator,
   /* gcMsgMId End */
   &gcMsgTheTerminator,
   /* gcMsgMessage End */
   NULLP
};

PUBLIC MgAsnElmntDef *mgaErrDesc[] =
{
   /* gcMsgMessageBody CHOICE */
   &gcMsgMessageBodySpecial1,
   /* gcMsgErrorDescriptor SEQUENCE/SET */
   &gcMsgErrorDescriptor0,
   &gcMsgErrorCode,
   &gcMsgErrorTextO,
   &gcMsgTheTerminator,
   /* gcMsgErrorDescriptor End */
   &gcMsgTheTerminator,
   /* gcMsgMessageBody End */
   NULLP
};
#endif
  
/********************************************************************30**
  
         End of file:     mgasndb2.c@@/main/1 - Wed Mar 30 08:08:48 2005
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************80**
 
 
*********************************************************************81*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      tlh  1. initial release.
/main/1      ---      pk   1. GCP 1.5 release
*********************************************************************91*/
