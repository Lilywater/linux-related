/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/
/********************************************************************20**

     Name:     Megaco ASN.1 database tree file

     Type:     C source file

     Desc:     global database definition elements for ASN.1 Megaco

     File:     mgca_db.c

     Sid:      mgasndb1.c@@/main/1 - Wed Mar 30 08:07:43 2005

     Prg:      nct

*********************************************************************21*/

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#ifdef GCP_ASN

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tkns.h"       /* common token structures */
#include "cm_mblk.h"       /* common event memory management */
#include "cm_tpt.h"        /* TPT header file */
#include "cm_dns.h"        /* DNS header file */

#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */

#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#include "cm_abnf.h"       /* ABNF header file */
#include "cm_sdp.h"        /* SDP header file */
#include "mgt.h"           /* ABNF events header file */
#include "mg_asn.h"        /* ABNF header file */
#include "mgasndb1.h"       /* ASN.1 database */
#include "mgasnutl.h"        /* ASN.1 mapping */

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* common event memory management */
#include "cm_lib.x"        /* common structures */
#include "cm_tpt.x"        /* TPT structures */
#include "cm_dns.x"        /* DNS structures */

#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */

#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#include "cm_sdp.x"        /* SDP structures */
#include "cm_abnf.x"       /* ABNF structures */
#include "mg_asn.x"        /* ASN.1 structures */
#include "mgasnev.x"       /* ASN.1 events */
#include "mgasndb1.x"       /* ASN.1 database */
#include "mgt.x"           /* ABNF events */
#include "mgasnutl.x"        /* ASN.1 mapping */
#include "cm_sdpdb.x"      /* SDP structures */


PUBLIC U32 gcManditoryIgnorePres = ((TYPE_TO_FLAG(MEGACO_V1, (ELMNT_MAND|ELMNT_IGN_PRES)))|(TYPE_TO_FLAG(MEGACO_V2, (ELMNT_MAND|ELMNT_IGN_PRES))));
PUBLIC U32 gcManditoryIgnoreBytes = ((TYPE_TO_FLAG(MEGACO_V1, (ELMNT_MAND|ELMNT_IGN_EXTRA)))|(TYPE_TO_FLAG(MEGACO_V2, (ELMNT_MAND|ELMNT_IGN_EXTRA))));
PUBLIC U32 gcManditoryIgnoreBytesPres = ((TYPE_TO_FLAG(MEGACO_V1, (ELMNT_MAND|ELMNT_IGN_EXTRA|ELMNT_IGN_PRES)))|(TYPE_TO_FLAG(MEGACO_V2, (ELMNT_MAND|ELMNT_IGN_EXTRA|ELMNT_IGN_PRES))));
PUBLIC U32 gcManditory =           ((TYPE_TO_FLAG(MEGACO_V1, (ELMNT_MAND)))|(TYPE_TO_FLAG(MEGACO_V2, (ELMNT_MAND))));
PUBLIC U32 gcOptional =  ((TYPE_TO_FLAG(MEGACO_V1, ELMNT_OPT))|(TYPE_TO_FLAG(MEGACO_V2, ELMNT_OPT)));
PUBLIC U32 gcManditoryv2 = (TYPE_TO_FLAG(MEGACO_V2, ELMNT_MAND));
PUBLIC U32 gcOptionalv2 = (TYPE_TO_FLAG(MEGACO_V2, ELMNT_OPT));

/*
 * Tips for idNum: 1) Special members, make them 500 + normal idNum e.g.
 *                    171 becomres 671, 54 becomes 554
 *                 2) Start V2 Megaco at 200+
 *                 2) Start V3 Megaco at 300+ ...
 *
 * There are some available id numbers in there: 142, 151, and 155, 190-199
 * plus many others using higher numbers.
 */

/*
 * gcMsgTheTerminator
 */
PUBLIC MgAsnElmntDef gcMsgTheTerminator =
{
#ifdef MG_ASN_DBG
  "TheTerminator",  /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 1,  /* idNum */ 
  TET_SETSEQ_TERM,   /* element type */
  0xFF,              /* tag value */
  MIN_LEN_NA,        /* minimum length */
  MAX_LEN_NA,        /* maximum length */
  sizeof(PTR),       /* database definition size */
  0,                 /* event structure size */
  REP_CNTR_NA,      /* counter for repeat element */
  NULLP,      /* protocol flag */
  NULLP,      /* enumbered values list */
  NULLP,      /* user function */
  NULLP,      /* user function */
};

/*
 * gcMsgMegacoMessage
 * MegacoMessage ::= SEQUENCE {
 *           authHeader AuthenticationHeader   OPTIONAL
 *           mess Message
 * }
 */
PUBLIC MgAsnElmntDef gcMsgMegacoMessage =
{
#ifdef MG_ASN_DBG
  "gcMsgMegacoMessage", /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 2,  /* idNum */ 
  TET_SEQ,       /* element type */
  /* mg003.105: Changes for Universal Tag */
  MG_ASN_USEQ,          /* tag value */
  MIN_LEN_NA,    /* minimum length */
  MAX_LEN_NA,    /* maximum length */
  0,             /* database definition size */
  sizeof(MgMgcoMsg), /* event structure size */
  REP_CNTR_NA,       /* counter for repeat element */
  &gcManditoryIgnoreBytes,    /* protocol flag */
  NULLP,             /* enumbered values list */
  mgAsnEncSetSeq,    /* user function */
  mgAsnDecSeq,       /* user function */
};
PUBLIC MgAsnElmntDef gcMsgMegacoMessageAH =
{
#ifdef MG_ASN_DBG
  "gcMsgMegacoMessage",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 2,  /* idNum */ 
  TET_SEQ,                /* element type */
  /* mg003.105: Changes for Universal Tag */
  MG_ASN_USEQ,              /* tag value */
  MIN_LEN_NA,        /* minimum length */
  MAX_LEN_NA,        /* maximum length */
  0,                 /* database definition size */
  sizeof(MgMgcoMsg), /* event structure size */
  REP_CNTR_NA,       /* counter for repeat element */
  &gcManditoryIgnoreBytesPres,      /* protocol flag */
  NULLP,     /* enumbered values list */
  mgAsnEncSetSeq,    /* user function */
  mgAsnDecSeq,       /* user function */
};
PUBLIC MgAsnElmntDef gcMsgMegacoMessageHE =
{
#ifdef MG_ASN_DBG
  "gcMsgMegacoMessage", /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 2,  /* idNum */ 
  TET_SEQ,           /* element type */
  /* mg003.105: Changes for Universal Tag */
  MG_ASN_USEQ,              /* tag value */
  MIN_LEN_NA,        /* minimum length */
  MAX_LEN_NA,        /* maximum length */
  0,                 /* database definition size */
  sizeof(MgMgcoMsg), /* event structure size */
  REP_CNTR_NA,       /* counter for repeat element */
  &gcManditoryIgnoreBytes,    /* protocol flag */
  NULLP,             /* enumbered values list */
  mgAsnEncSetSeq,    /* user function */
  mgAsnDecSeq,       /* user function */
};

/*
 * gcMsgAuthenticationHeaderO
 * AuthenticationHeader ::= SEQUENCE {
 *               secParmIndex SecurityParmIndex
 *               seqNum SequenceNum
 *               ad AuthData
 * }
 */
PUBLIC MgAsnElmntDef gcMsgAuthenticationHeaderO =
{
#ifdef MG_ASN_DBG
  "gcMsgAuthenticationHeaderO",  /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 2,  /* idNum */ 
  TET_SEQ,             /* element type */
  0xFF,                /* tag value */
  MIN_LEN_NA,          /* minimum length */
  MAX_LEN_NA,          /* maximum length */
  0,                   /* database definition size */
  sizeof(MgMgcoAuthHdr),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,               /* enumbered values list */
  mgAsnEncSetSeq,      /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgSecurityParmIndex
 * SecurityParmIndex ::= OCTET STRING       4  
 */
PUBLIC MgAsnElmntDef gcMsgSecurityParmIndex =
{
#ifdef MG_ASN_DBG
  "gcMsgSecurityParmIndex",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 4,  /* idNum */ 
  TET_STR4,        /* element type */
  0xFF,            /* tag value */
  MIN_LEN_NA,      /* minimum length */
  4,               /* maximum length */
  sizeof(PTR),     /* database definition size */
  sizeof(MgMgcoSecParmIndex),  /* event structure size */
  REP_CNTR_NA,     /* counter for repeat element */
  &gcManditory,    /* protocol flag */
  NULLP,           /* enumbered values list */
  mgaFuncU32Str4Enc,   /* user function */
  mgaFuncU32Str4Dec,   /* user function */
};


/*
 * gcMsgSequenceNum
 * SequenceNum ::= OCTET STRING       4  
 */
PUBLIC MgAsnElmntDef gcMsgSequenceNum =
{
#ifdef MG_ASN_DBG
  "gcMsgSequenceNum",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 5,  /* idNum */ 
  TET_STR4,          /* element type */
  0xFF,              /* tag value */
  MIN_LEN_NA,        /* minimum length */
  4,                 /* maximum length */
  sizeof(PTR),       /* database definition size */
  sizeof(MgMgcoSequenceNum),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncU32Str4Enc,         /* user function */
  mgaFuncU32Str4Dec,         /* user function */
};


/*
 * gcMsgAuthData
 * AuthData ::= OCTET STRING       (12..32)  
 */
PUBLIC MgAsnElmntDef gcMsgAuthData =
{
#ifdef MG_ASN_DBG
  "gcMsgAuthData",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 6,  /* idNum */ 
  TET_STROSXL_MEM,         /* element type */
  0xFF,                            /* tag value */
  12,         /* minimum length */
  32,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoAuthData),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};


/*
 * gcMsgMessage
 * Message ::= SEQUENCE {
 *               version INTEGER
 *               mId MId
 *               messageBody CHOICE
 * }
 */
PUBLIC MgAsnElmntDef gcMsgMessage =
{
#ifdef MG_ASN_DBG
  "gcMsgMessage",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 7,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  0,   
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncMessageEnc,         /* user function */
  mgaFuncMessageDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgMessageHD =
{
#ifdef MG_ASN_DBG
  "gcMsgMessage",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 7,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  0,   
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncMessageEnc,         /* user function */
  mgaFuncMessageDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgMessageHE =
{
#ifdef MG_ASN_DBG
  "gcMsgMessage",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 7,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  0,   
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncMessageEnc,         /* user function */
  mgaFuncMessageDec,         /* user function */
};

/*
 * gcMsgVersion
 *    Version ::= INTEGER    (0..99) 
 */
PUBLIC MgAsnElmntDef gcMsgVersion =
{
#ifdef MG_ASN_DBG
  "gcMsgVersion",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 8,  /* idNum */ 
  TET_INT8,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  1,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoVersion),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgaFuncVersionDec,         /* user function */
};


/*
 * gcMsgIP4Address
 * IP4Address ::= SEQUENCE {
 *               addressIp4 OCTET STRING
 *               portNumber PortNumber   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIP4Address0 =
{
#ifdef MG_ASN_DBG
  "gcMsgIP4Address0",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 9,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcaIP4Address),   /* Do not map event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgIP4Address1 =
{
#ifdef MG_ASN_DBG
  "gcMsgIP4Address1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 9,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcaIP4Address),   /* Do not map event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgAddressIp4
 * AddressIp4 ::= OCTET STRING       4  
 */
PUBLIC MgAsnElmntDef gcMsgAddressIp4 =
{
#ifdef MG_ASN_DBG
  "gcMsgAddressIp4",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 10,  /* idNum */ 
  TET_STR4,         /* element type */
  0xFF,                            /* tag value */
  /* mg008.105: min and max length for ip4 address is 4 only */
  4,         /* minimum length */
  4,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcaAddressIp4),   /* Do not map event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};


/*
 * gcMsgPortNumberO
 *    PortNumber ::= INTEGER    (0..65535) 
 */
PUBLIC MgAsnElmntDef gcMsgPortNumberO =
{
#ifdef MG_ASN_DBG
  "gcMsgPortNumberO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 11,  /* idNum */ 
  TET_INT16,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcaPortNumber),   /* Do not map event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgIP6Address
 * IP6Address ::= SEQUENCE {
 *               addressIp6 OCTET STRING
 *               portNumber PortNumber   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIP6Address1 =
{
#ifdef MG_ASN_DBG
  "gcMsgIP6Address1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 12,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcaIP6Address),   /* Do not map event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgIP6Address2 =
{
#ifdef MG_ASN_DBG
  "gcMsgIP6Address2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 12,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcaIP6Address),   /* Do not map event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgAddressIp6
 * AddressIp6 ::= OCTET STRING       16  
 */
PUBLIC MgAsnElmntDef gcMsgAddressIp6 =
{
#ifdef MG_ASN_DBG
  "gcMsgAddressIp6",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 13,  /* idNum */ 
  TET_STR32,         /* element type */
  0xFF,                            /* tag value */
  /* mg008.105: min and max length for ip6 address is 16 only */
  16,         /* minimum length */
  16,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcaAddressIp6),   /* Do not map event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};


/*
 * gcMsgDomainName
 * DomainName ::= SEQUENCE {
 *               domName CHARACTER STRING
 *               portNumber PortNumber   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgDomainName2 =
{
#ifdef MG_ASN_DBG
  "gcMsgDomainName2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 14,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcaDomainName),   /* Do not map event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgDomainName3 =
{
#ifdef MG_ASN_DBG
  "gcMsgDomainName3",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 14,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcaDomainName),   /* Do not map event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgDomName
 * DomName ::= IA5String
 */
PUBLIC MgAsnElmntDef gcMsgDomName =
{
#ifdef MG_ASN_DBG
  "gcMsgDomName",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 15,  /* idNum */ 
  TET_IA5STRXL_MEM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcaDomName),   /* Do not map event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};


/*
 * gcMsgPathName
 * PathName ::= IA5String       (1..64)  
 */
PUBLIC MgAsnElmntDef gcMsgPathName3 =
{
#ifdef MG_ASN_DBG
  "gcMsgPathName3",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 16,  /* idNum */ 
  TET_IA5STR64,         /* element type */
  0xFF,                            /* tag value */
  1,         /* minimum length */
  64,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcaPathName),   /* Do not map event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgPathName4 =
{
#ifdef MG_ASN_DBG
  "gcMsgPathName4",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 16,  /* idNum */ 
  TET_IA5STR64,         /* element type */
  0xFF,                            /* tag value */
  1,         /* minimum length */
  64,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcaPathName),   /* Do not map event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};


/*
 * gcMsgMtpAddress
 * MtpAddress ::= OCTET STRING       (2..4)  
 */
PUBLIC MgAsnElmntDef gcMsgMtpAddress4 =
{
#ifdef MG_ASN_DBG
  "gcMsgMtpAddress4",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 17,  /* idNum */ 
  TET_STR4,         /* element type */
  0xFF,                            /* tag value */
  2,         /* minimum length */
  4,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcaMtpAddress),   /* Do not map event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgMtpAddress5 =
{
#ifdef MG_ASN_DBG
  "gcMsgMtpAddress5",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 17,  /* idNum */ 
  TET_STR4,         /* element type */
  0xFF,                            /* tag value */
  2,         /* minimum length */
  4,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcaMtpAddress),   /* Do not map event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};


/*
 * gcMsgMId
 * MId ::= CHOICE {
 *               ip4Address IP4Address
 *               ip6Address IP6Address
 *               domainName DomainName
 *               deviceName PathName
 *               mtpAddress MtpAddress
 * }
 */
PUBLIC MgAsnElmntDef gcMsgMId =
{
#ifdef MG_ASN_DBG
  "gcMsgMId",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 18,  /* idNum */ 
  TET_CHOICE,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,         /* database definition size */
  sizeof(TknStrOSXL),      /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncMIdSpecialEnc,         /* user function */
  mgaFuncMIdSpecialDec,         /* user function */
};

/*
 * gcMsgErrorDescriptor
 * ErrorDescriptor ::= SEQUENCE {
 *               errorCode ErrorCode
 *               errorText ErrorText   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgErrorDescriptor0 =
{
#ifdef MG_ASN_DBG
  "gcMsgErrorDescriptor0",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 19,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoErrDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgErrorDescriptor1 =
{
#ifdef MG_ASN_DBG
  "gcMsgErrorDescriptor1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 19,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoErrDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgErrorCode
 *    ErrorCode ::= INTEGER    (0..65535) 
 */
PUBLIC MgAsnElmntDef gcMsgErrorCode =
{
#ifdef MG_ASN_DBG
  "gcMsgErrorCode",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 20,  /* idNum */ 
  TET_INT16,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU16),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgErrorTextO
 * ErrorText ::= IA5String
 */
PUBLIC MgAsnElmntDef gcMsgErrorTextO =
{
#ifdef MG_ASN_DBG
  "gcMsgErrorTextO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 21,  /* idNum */ 
  TET_IA5STROSXL_MEM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknStrOSXL),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};


/*
 * gcMsgTransactions
 * Transactions ::= SEQUENCE  OF Transaction
 */
PUBLIC MgAsnElmntDef gcMsgTransactions =
{
#ifdef MG_ASN_DBG
  "gcMsgTransactions",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 22,  /* idNum */ 
  TET_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  1,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTxnLst),   /* event structure size */
  MGAMAX_Transactions,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeqOf,         /* user function */
  mgAsnDecSetSeqOf,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgTransactionsSpecial =
{
#ifdef MG_ASN_DBG
  "gcMsgTransactionsSpecial",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 22,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  1,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTxnLst),   /* event structure size */
  MGAMAX_Transactions,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncTransactionsSpecialEnc,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};

/*
 * gcMsgTransactionRequest
 * TransactionRequest ::= SEQUENCE {
 *               transactionId TransactionId
 *               actions SEQUENCE OF
 * }
 */
PUBLIC MgAsnElmntDef gcMsgTransactionRequest =
{
#ifdef MG_ASN_DBG
  "gcMsgTransactionRequest",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 23,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTxnReq),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgTransactionId
 *    TransactionId ::= INTEGER    (0..4294967295) 
 */
PUBLIC MgAsnElmntDef gcMsgTransactionId =
{
#ifdef MG_ASN_DBG
  "gcMsgTransactionId",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 24,  /* idNum */ 
  TET_INT32,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  4,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoTransId),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgActions
 * Actions ::= SEQUENCE  OF ActionRequest
 */
PUBLIC MgAsnElmntDef gcMsgActions =
{
#ifdef MG_ASN_DBG
  "gcMsgActions",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 25,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  1,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoActionLst),   /* event structure size */
  MGAMAX_Actions,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgActionRequest
 * ActionRequest ::= SEQUENCE {
 *               contextId ContextID
 *               contextRequest ContextRequest   OPTIONAL
 *               contextAttrAuditReq ContextAttrAuditRequest   OPTIONAL
 *               commandRequests SEQUENCE OF
 * }
 */
PUBLIC MgAsnElmntDef gcMsgActionRequest =
{
#ifdef MG_ASN_DBG
  "gcMsgActionRequest",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 26,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoActionReq),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncActionRequestEnc,         /* user function */
  mgaFuncActionRequestDec,         /* user function */
};


/*
 * gcMsgContextID
 *    ContextID ::= INTEGER    (0..4294967295) 
 */
PUBLIC MgAsnElmntDef gcMsgContextID =
{
#ifdef MG_ASN_DBG
  "gcMsgContextID",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 27,  /* idNum */ 
  TET_INT32,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  4,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoContextId),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncContextIDEnc,         /* user function */
  mgaFuncContextIDDec,         /* user function */
};

/*
 * gcMsgContextRequestO
 * ContextRequest ::= SEQUENCE {
 *               priority INTEGER   OPTIONAL
 *               emergency BOOLEAN   OPTIONAL
 *               topologyReq SEQUENCE OF   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgContextRequestO1 =
{
#ifdef MG_ASN_DBG
  "gcMsgContextRequestO1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 28,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoContextProps),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncContextRequestEnc,         /* user function */
  mgaFuncContextRequestDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgContextRequestO2 =
{
#ifdef MG_ASN_DBG
  "gcMsgContextRequestO2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 28,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoContextProps),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncContextRequestEnc,         /* user function */
  mgaFuncContextRequestDec,         /* user function */
};


/*
 * gcMsgPriorityO
 *    Priority ::= INTEGER    (0..15) 
 */
PUBLIC MgAsnElmntDef gcMsgPriorityO =
{
#ifdef MG_ASN_DBG
  "gcMsgPriorityO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 29,  /* idNum */ 
  TET_INT16,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  /* mg008.105: maximum length of 1 is sufficient */
  1,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU16),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncPriorityEnc,         /* user function */
  mgaFuncPriorityDec,         /* user function */
};


/*
 * gcMsgEmergencyO
 * Emergency ::= BOOLEAN
 */
PUBLIC MgAsnElmntDef gcMsgEmergencyO =
{
#ifdef MG_ASN_DBG
  "gcMsgEmergencyO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 30,  /* idNum */ 
  TET_BOOL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknPres),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncBool,         /* user function */
  mgAsnDecBool,         /* user function */
};


/*
 * gcMsgTopologyReqO
 * TopologyReq ::= SEQUENCE  OF TopologyRequest
 */
PUBLIC MgAsnElmntDef gcMsgTopologyReqO =
{
#ifdef MG_ASN_DBG
  "gcMsgTopologyReqO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 31,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTopoDescLst),   /* event structure size */
  MGAMAX_TopologyReq,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgTopologyRequest
 * TopologyRequest ::= SEQUENCE {
 *               terminationFrom TerminationID
 *               terminationTo TerminationID
 *               topologyDirection ENUMERATED
 *               streamID StreamID OPTIONAL (added for V2)
 * }
 */
PUBLIC MgAsnElmntDef gcMsgTopologyRequest =
{
#ifdef MG_ASN_DBG
  "gcMsgTopologyRequest",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 32,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTopoDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgTerminationID
 * TerminationID ::= SEQUENCE {
 *               wildcard SEQUENCE OF
 *               id OCTET STRING
 * }
 */
PUBLIC MgAsnElmntDef gcMsgTerminationID0 =
{
#ifdef MG_ASN_DBG
  "gcMsgTerminationID0",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 33,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTermId),         /* ABNF event */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncTerminationIDEnc,         /* user function */
  mgaFuncTerminationIDDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgTerminationID1 =
{
#ifdef MG_ASN_DBG
  "gcMsgTerminationID1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 33,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTermId),         /* ABNF event */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncTerminationIDEnc,         /* user function */
  mgaFuncTerminationIDDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgTerminationID30 =
{
#ifdef MG_ASN_DBG
  "gcMsgTerminationID30",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 33,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTermId),         /* ABNF event */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncTerminationIDEnc,         /* user function */
  mgaFuncTerminationIDDec,         /* user function */
};


/*
 * gcMsgWildcard
 * Wildcard ::= SEQUENCE  OF WildcardField
 */
PUBLIC MgAsnElmntDef gcMsgWildcard =
{
#ifdef MG_ASN_DBG
  "gcMsgWildcard",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 34,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  /* mg003.105: Changes for minimum elemnts to encode */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcaWildcard),   /* Use ASN.1 event */
  MGAMAX_Wildcard,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgWildcardField
 * WildcardField ::= OCTET STRING       1  
 */
PUBLIC MgAsnElmntDef gcMsgWildcardField =
{
#ifdef MG_ASN_DBG
  "gcMsgWildcardField",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 35,  /* idNum */ 
  TET_STR4,         /* element type */
  0xFF,                            /* tag value */
  /* mg008.105: min length should be 1 */
  1,         /* minimum length */
  1,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcaWildcardField),   /* Use ASN.1 event */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};


/*
 * gcMsgId
 * Id ::= OCTET STRING       (1..8)  
 */
PUBLIC MgAsnElmntDef gcMsgId =
{
#ifdef MG_ASN_DBG
  "gcMsgId",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 36,  /* idNum */ 
/* mg003.105: Changes done for 3GPP specification */
#ifdef MG_ASN_TEST   
  TET_STR256,         /* element type */
  0xFF,                            /* tag value */
  1,         /* minimum length */
#ifdef MGCO_3G_TERMINATION
  4,         /* maximum length */
#else
  128,         /* maximum length */
#endif

#else
  TET_STR12,         /* element type */
  0xFF,                            /* tag value */
  1,         /* minimum length */
#ifdef MGCO_3G_TERMINATION
  4,         /* maximum length */
#else
  8,         /* maximum length */
#endif
#endif

  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcaId),   /* Use ASN.1 event */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};


/*
 * gcMsgTopologyDirection
 * TopologyDirection ::= ENUMERATED {
 *       bothway   (0)
 *       isolate   (1)
 *       oneway   (2)
 * }
 */
PRIVATE U8 TopologyDirectionEnumLst[] = {3, 0, 1, 2};
PUBLIC MgAsnElmntDef gcMsgTopologyDirection =
{
#ifdef MG_ASN_DBG
  "gcMsgTopologyDirection",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 37,  /* idNum */ 
  TET_ENUM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  TopologyDirectionEnumLst,         /* enumbered values list */
  mgAsnEncOctetEnum,         /* user function */
  mgAsnDecOctetEnum,         /* user function */
};


/*
 * gcMsgContextAttrAuditRequestO
 * ContextAttrAuditRequest ::= SEQUENCE {
 *               topology NULL   OPTIONAL
 *               emergencyReq NULL   OPTIONAL
 *               priorityReq NULL   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgContextAttrAuditRequestO =
{
#ifdef MG_ASN_DBG
  "gcMsgContextAttrAuditRequestO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 38,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoContextAudit),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgTopologyO
 *   Topology ::= NULL
 *
 */
PUBLIC MgAsnElmntDef gcMsgTopologyO =
{
#ifdef MG_ASN_DBG
  "gcMsgTopologyO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 39,  /* idNum */ 
  TET_NULL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknPres),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncNull,         /* user function */
  mgAsnDecNull,         /* user function */
};


/*
 * gcMsgEmergencyReqO
 *   EmergencyReq ::= NULL
 *
 */
PUBLIC MgAsnElmntDef gcMsgEmergencyReqO =
{
#ifdef MG_ASN_DBG
  "gcMsgEmergencyReqO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 40,  /* idNum */ 
  TET_NULL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknPres),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncNull,         /* user function */
  mgAsnDecNull,         /* user function */
};


/*
 * gcMsgPriorityReqO
 *   PriorityReq ::= NULL
 *
 */
PUBLIC MgAsnElmntDef gcMsgPriorityReqO =
{
#ifdef MG_ASN_DBG
  "gcMsgPriorityReqO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 41,  /* idNum */ 
  TET_NULL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknPres),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncNull,         /* user function */
  mgAsnDecNull,         /* user function */
};


/*
 * gcMsgCommandRequests
 * CommandRequests ::= SEQUENCE  OF CommandRequest
 */
PUBLIC MgAsnElmntDef gcMsgCommandRequests =
{
#ifdef MG_ASN_DBG
  "gcMsgCommandRequests",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 42,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  /* mg005.105: Changed to support empty commands in the action */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoCmdReqLst),   /* event structure size */
  MGAMAX_CommandRequests,         /* counter for repeat element */
  /* mg008.105: It is mandatory field, but can be empty */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
/* 
 *  mg003.105: called different Function to encode/decode if CH is used  
 *  CH will use new MemCp ( Allocated using mgAllocEventMem ) while non CH path
 *  will use Txn[] MemCp
 */
#ifdef GCP_CH
  mgAsnEncUnconsCmdSetSeqOf,         /* user function */
#else               
  mgAsnEncUnconsSetSeqOf,         /* user function */
#endif /* GCP_CH */
#ifdef GCP_CH
    mgAsnDecUnconsCmdSetSeqOf,   
#else               
  mgAsnDecUnconsSetSeqOf,         /* user function */
#endif /* GCP_CH */
};


/*
 * gcMsgCommandRequest
 * CommandRequest ::= SEQUENCE {
 *               command Command
 *               optional NULL   OPTIONAL
 *               wildcardReturn NULL   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgCommandRequest =
{
#ifdef MG_ASN_DBG
  "gcMsgCommandRequest",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 43,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoCommandReq),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  /* mg003.105: Changes for GCP_CH */
#ifdef GCP_CH
  &gcManditoryIgnorePres,         /* protocol flag */
#else
  &gcManditory,         /* protocol flag */
#endif
  NULLP,         /* enumbered values list */
  mgaFuncCommandRequestEnc,         /* user function */
  mgaFuncCommandRequestDec,         /* user function */
};


/*
 * gcMsgAmmRequest
 * AmmRequest ::= SEQUENCE {
 *               terminationID TerminationIDList
 *               descriptors SEQUENCE OF
 * }
 */
PUBLIC MgAsnElmntDef gcMsgAmmRequest0 =
{
#ifdef MG_ASN_DBG
  "gcMsgAmmRequest0",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 44,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAmmReq),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  /* mg008.105: Added new Encoding function for support of empty descriptors */
  mgaFuncAmmRequestEnc,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgAmmRequest1 =
{
#ifdef MG_ASN_DBG
  "gcMsgAmmRequest1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 44,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAmmReq),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  /* mg008.105: Added new Encoding function for support of empty descriptors */
  mgaFuncAmmRequestEnc,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgAmmRequest2 =
{
#ifdef MG_ASN_DBG
  "gcMsgAmmRequest2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 44,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAmmReq),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  /* mg008.105: Added new Encoding function for support of empty descriptors */
  mgaFuncAmmRequestEnc,         /* user function */
  mgAsnDecSeq,         /* user function */
};

/*
 * gcMsgTerminationIDList
 * TerminationIDList ::= SEQUENCE  OF TerminationID
 */
PUBLIC MgAsnElmntDef gcMsgTerminationIDList =
{
#ifdef MG_ASN_DBG
  "gcMsgTerminationIDList",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 45,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTermIdLst),   /* event structure size */
  MGAMAX_TerminationIDList,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgTerminationIDListSpecial =
{
#ifdef MG_ASN_DBG
  "gcMsgTerminationIDListSpecial",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 46,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTermId),      /* event structure size */
  MGAMAX_TerminationIDList,   /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncTerminationIDListSpecialEnc,         /* user function */
  mgaFuncTerminationIDListSpecialDec,         /* user function */
};

/*
 * gcMsgDescriptors
 * Descriptors ::= SEQUENCE  OF AmmDescriptor
 */
PUBLIC MgAsnElmntDef gcMsgDescriptors =
{
#ifdef MG_ASN_DBG
  "gcMsgDescriptors",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 47,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* mg003.105: Modify - chagened minimum length from 1 */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAmmDescLst),   /* event structure size */
  MGAMAX_Descriptors,         /* counter for repeat element */
  /* mg008.105: Modified for the empty descriptors */
  &gcManditory,    /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgMediaDescriptor
 * MediaDescriptor ::= SEQUENCE {
 *               termStateDescr TerminationStateDescriptor   OPTIONAL
 *               streams CHOICE   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgMediaDescriptor0 =
{
#ifdef MG_ASN_DBG
  "gcMsgMediaDescriptor0",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 48,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoMediaDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncMediaDescriptorEnc,         /* user function */
  mgaFuncMediaDescriptorDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgMediaDescriptor1 =
{
#ifdef MG_ASN_DBG
  "gcMsgMediaDescriptor1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 48,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoMediaDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncMediaDescriptorEnc,         /* user function */
  mgaFuncMediaDescriptorDec,         /* user function */
};


/*
 * gcMsgTerminationStateDescriptorO
 * TerminationStateDescriptor ::= SEQUENCE {
 *               propertyParms SEQUENCE OF PropertyParms
 *               eventBufferControl EventBufferControl   OPTIONAL
 *               serviceState ServiceState   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgTerminationStateDescriptorO =
{
#ifdef MG_ASN_DBG
  "gcMsgTerminationStateDescriptorO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 49,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTermStateDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncTerminationStateDescriptorEnc,         /* user function */
  mgaFuncTerminationStateDescriptorDec,         /* user function */
};


/*
 * gcMsgPropertyParms
 * propertyParms ::= SEQUENCE  OF PropertyParm
 */
PUBLIC MgAsnElmntDef gcMsgPropertyParms0 =
{
#ifdef MG_ASN_DBG
  "gcMsgPropertyParms0",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 50,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  /* mg004.105: Modified minimum length of number of parameters */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoPropParmLst),   /* event structure size */
  MGAMAX_PropertyParms,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgPropertyParms3 =
{
#ifdef MG_ASN_DBG
  "gcMsgPropertyParms3",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 50,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  /* mg004.105: Modified minimum length of number of parameters */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoPropParmLst),   /* event structure size */
  MGAMAX_PropertyParms,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};

/*
 * gcMsgPropertyParm
 * PropertyParm ::= SEQUENCE {
 *               name PkgdName
 *               propParmValue SEQUENCE OF
 *               extraInfo ExtraInfo   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgPropertyParm =
{
#ifdef MG_ASN_DBG
  "gcMsgPropertyParm",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 51,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoPropParm),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncPropertyParmEnc,         /* user function */
  mgaFuncPropertyParmDec,         /* user function */
};


/*
 * gcMsgPkgdName
 * PkgdName ::= OCTET STRING       4  
 */
PUBLIC MgAsnElmntDef gcMsgPkgdName0 =
{
#ifdef MG_ASN_DBG
  "gcMsgPkgdName0",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 52,  /* idNum */ 
  TET_STR4,         /* element type */
  0xFF,                            /* tag value */
  /* mg008.105: min length should be 4 */
  4,         /* minimum length */
  4,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  (sizeof(TknU8) + sizeof(MgMgcoPkgdName)), /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncPkgdNameEnc,         /* user function */
  mgaFuncPkgdNameDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgPkgdName1 =
{
#ifdef MG_ASN_DBG
  "gcMsgPkgdName1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 52,  /* idNum */ 
  TET_STR4,         /* element type */
  0xFF,                            /* tag value */
  4,         /* minimum length */
  4,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  (sizeof(TknU8) + sizeof(MgMgcoPkgdName)),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncPkgdNameEnc,         /* user function */
  mgaFuncPkgdNameDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgPkgdNameSpecial =
{
#ifdef MG_ASN_DBG
  "gcMsgPkgdName0",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 52,  /* idNum */ 
  TET_STR4,         /* element type */
  0xFF,                            /* tag value */
  4,         /* minimum length */
  4,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  (sizeof(TknU8) + sizeof(MgMgcoPkgdName)),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncPkgdNameEnc,         /* user function */
  mgaFuncPkgdNameSpecialDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgPkgdNameO0 =
{
#ifdef MG_ASN_DBG
  "gcMsgPkgdNameO0",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 52,  /* idNum */ 
  TET_STR4,         /* element type */
  0xFF,                            /* tag value */
  4,         /* minimum length */
  4,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  (sizeof(TknU8) + sizeof(MgMgcoPkgdName)),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryIgnorePres,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncPkgdNameEnc,         /* user function */
  mgaFuncPkgdNameDec,         /* user function */
};


/*
 * gcMsgPropParmValue
 * PropParmValue ::= SEQUENCE  OF 
 */
PUBLIC MgAsnElmntDef gcMsgPropParmValue =
{
#ifdef MG_ASN_DBG
  "gcMsgPropParmValue",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 53,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  /* mg004.105: Modified minimum length of param value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoParmValue),   /* event structure size */
  MGAMAX_PropParmValue,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncPropParmValueEnc,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgPropParmValueSeqOf
 * PropParmValueSeqOf ::= OCTET STRING
 */
PUBLIC MgAsnElmntDef gcMsgPropParmValueSeqOf =
{
#ifdef MG_ASN_DBG
  "gcMsgPropParmValueSeqOf",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 54,  /* idNum */ 
  /* TET_STRXL_MEM,          element type */
  TET_STROSXL_MEM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoValue),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryIgnorePres,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncValueSeqOfEnc,         /* user function */
  mgaFuncValueSeqOfDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgPropParmValueSeqOfSpecial =
{
#ifdef MG_ASN_DBG
  "gcMsgPropParmValueSeqOfSpecial",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 554,  /* idNum */ 
  /* TET_STRXL_MEM,          element type */
  TET_STROSXL_MEM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoValue),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryIgnorePres,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncValueSeqOfEnc,         /* user function */
  mgaFuncValueSeqOfDec,         /* user function */
};

/*
 * gcMsgRelation
 * Relation ::= ENUMERATED {
 *       greaterThan   (0)
 *       smallerThan   (1)
 *       unequalTo   (2)
 * }
 */
PRIVATE U8 RelationEnumLst[] = {3, 0, 1, 2};
PUBLIC MgAsnElmntDef gcMsgRelation =
{
#ifdef MG_ASN_DBG
  "gcMsgRelation",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 55,  /* idNum */ 
  TET_ENUM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  RelationEnumLst,         /* enumbered values list */
  mgAsnEncOctetEnum,         /* user function */
  mgAsnDecOctetEnum,         /* user function */
};


/*
 * gcMsgRange
 * Range ::= BOOLEAN
 */
PUBLIC MgAsnElmntDef gcMsgRange =
{
#ifdef MG_ASN_DBG
  "gcMsgRange",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 56,  /* idNum */ 
  TET_BOOL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncBool,         /* user function */
  mgAsnDecBool,         /* user function */
};


/*
 * gcMsgSublist
 * Sublist ::= BOOLEAN
 */
PUBLIC MgAsnElmntDef gcMsgSublist =
{
#ifdef MG_ASN_DBG
  "gcMsgSublist",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 57,  /* idNum */ 
  TET_BOOL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncBool,         /* user function */
  mgAsnDecBool,         /* user function */
};


/*
 * gcMsgExtraInfoO
 * ExtraInfo ::= CHOICE {
 *               relation Relation
 *               range BOOLEAN
 *               sublist BOOLEAN
 * }
 */
PUBLIC MgAsnElmntDef gcMsgExtraInfoO =
{
#ifdef MG_ASN_DBG
  "gcMsgExtraInfoO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 58,  /* idNum */ 
  TET_CHOICE,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoParmValue),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncExtraInfoEnc,         /* user function */
  mgaFuncExtraInfoDec,         /* user function */
};


/*
 * gcMsgEventBufferControlO
 * EventBufferControl ::= ENUMERATED {
 *       off   (0)
 *       lockStep   (1)
 * }
 */
PRIVATE U8 EventBufferControlEnumLst[] = {2, 0, 1};
PUBLIC MgAsnElmntDef gcMsgEventBufferControlO =
{
#ifdef MG_ASN_DBG
  "gcMsgEventBufferControlO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 59,  /* idNum */ 
  TET_ENUM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoEvtBufCtl),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  EventBufferControlEnumLst,         /* enumbered values list */
  mgAsnEncOctetEnum,         /* user function */
  mgAsnDecOctetEnum,         /* user function */
};


/*
 * gcMsgServiceStateO
 * ServiceState ::= ENUMERATED {
 *       test   (0)
 *       outOfSvc   (1)
 *       inSvc   (2)
 * }
 */
PRIVATE U8 ServiceStateEnumLst[] = {3, 0, 1, 2};
PUBLIC MgAsnElmntDef gcMsgServiceStateO =
{
#ifdef MG_ASN_DBG
  "gcMsgServiceStateO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 60,  /* idNum */ 
  TET_ENUM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoSvcState),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  ServiceStateEnumLst,         /* enumbered values list */
  mgAsnEncOctetEnum,         /* user function */
  mgAsnDecOctetEnum,         /* user function */
};


/*
 * gcMsgStreamParms
 * StreamParms ::= SEQUENCE {
 *               localControlDescriptor LocalControlDescriptor   OPTIONAL
 *               localDescriptor LocalRemoteDescriptor   OPTIONAL
 *               remoteDescriptor LocalRemoteDescriptor   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgStreamParms =
{
#ifdef MG_ASN_DBG
  "gcMsgStreamParms",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 61,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoStreamParm),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgStreamParmsSpecial =
{
#ifdef MG_ASN_DBG
  "gcMsgStreamParmsSpecial",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 561,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoMediaDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryIgnorePres,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncStreamParmsSpecialEnc,         /* user function */
  mgaFuncStreamParmsSpecialDec,         /* user function */
};


/*
 * gcMsgLocalControlDescriptorO
 * LocalControlDescriptor ::= SEQUENCE {
 *               streamMode StreamMode   OPTIONAL
 *               reserveValue BOOLEAN   OPTIONAL
 *               reserveGroup BOOLEAN   OPTIONAL
 *               propertyParms PropertyParms
 * }
 */
PUBLIC MgAsnElmntDef gcMsgLocalControlDescriptorO =
{
#ifdef MG_ASN_DBG
  "gcMsgLocalControlDescriptorO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 62,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoLclCtlDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncLocalControlDescriptorEnc,      /* user function */
  mgaFuncLocalControlDescriptorDec,      /* user function */
};


/*
 * gcMsgStreamModeO
 * StreamMode ::= ENUMERATED {
 *       sendOnly   (0)
 *       recvOnly   (1)
 *       sendRecv   (2)
 *       inactive   (3)
 *       loopBack   (4)
 * }
 */
PRIVATE U8 StreamModeEnumLst[] = {5, 0, 1, 2, 3, 4};
PUBLIC MgAsnElmntDef gcMsgStreamModeO =
{
#ifdef MG_ASN_DBG
  "gcMsgStreamModeO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 63,  /* idNum */ 
  TET_ENUM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  StreamModeEnumLst,         /* enumbered values list */
  mgAsnEncOctetEnum,         /* user function */
  mgAsnDecOctetEnum,         /* user function */
};


/*
 * gcMsgReserveValueO
 * ReserveValue ::= BOOLEAN
 */
PUBLIC MgAsnElmntDef gcMsgReserveValueO =
{
#ifdef MG_ASN_DBG
  "gcMsgReserveValueO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 64,  /* idNum */ 
  TET_BOOL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncBool,         /* user function */
  mgAsnDecBool,         /* user function */
};


/*
 * gcMsgReserveGroupO
 * ReserveGroup ::= BOOLEAN
 */
PUBLIC MgAsnElmntDef gcMsgReserveGroupO =
{
#ifdef MG_ASN_DBG
  "gcMsgReserveGroupO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 65,  /* idNum */ 
  TET_BOOL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncBool,         /* user function */
  mgAsnDecBool,         /* user function */
};


/*
 * gcMsgLocalRemoteDescriptorO
 * LocalRemoteDescriptor ::= SEQUENCE {
 *               propGrps SEQUENCE OF
 * }
 */
PUBLIC MgAsnElmntDef gcMsgLocalRemoteDescriptorO1 =
{
#ifdef MG_ASN_DBG
  "gcMsgLocalRemoteDescriptorO1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 66,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoLocalDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncLocalRemoteDescriptorEnc,      /* user function */
  mgaFuncLocalRemoteDescriptorDec,      /* user function */
};
PUBLIC MgAsnElmntDef gcMsgLocalRemoteDescriptorO2 =
{
#ifdef MG_ASN_DBG
  "gcMsgLocalRemoteDescriptorO2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 66,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoLocalDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncLocalRemoteDescriptorEnc,      /* user function */
  mgaFuncLocalRemoteDescriptorDec,      /* user function */
};


/*
 * gcMsgPropGrps
 * PropGrps ::= SEQUENCE  OF PropertyGroup
 */
PUBLIC MgAsnElmntDef gcMsgPropGrps =
{
#ifdef MG_ASN_DBG
  "gcMsgPropGrps",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 67,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoPropGrpLst),   /* event structure size */
  MGAMAX_PropGrps,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncPropGrpsEnc,         /* user function */
  mgaFuncPropGrpsDec,         /* user function */
};


/*
 * gcMsgPropertyGroup
 * PropertyGroup ::= SEQUENCE  OF PropertyParm
 */
PUBLIC MgAsnElmntDef gcMsgPropertyGroup =
{
#ifdef MG_ASN_DBG
  "gcMsgPropertyGroup",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 68,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  /* mg004.105: Modifed from CmSdpInfo to MgMgcoPropParmLst 
   * to support Annex C */  
  sizeof(MgMgcoPropParmLst),    /* event structure size */
  MGAMAX_PropertyGroup,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncPropertyGroupEnc,         /* user function */
  mgaFuncPropertyGroupDec,         /* user function */
};


/*
 * gcMsgMultiStream
 * MultiStream ::= SEQUENCE  OF StreamDescriptor
 */
PUBLIC MgAsnElmntDef gcMsgMultiStream =
{
#ifdef MG_ASN_DBG
  "gcMsgMultiStream",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 69,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoMediaDesc),   /* event structure size */
  MGAMAX_MultiStream,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncMultiStreamEnc,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgStreamDescriptor
 * StreamDescriptor ::= SEQUENCE {
 *               streamID StreamID
 *               streamParms StreamParms
 * }
 */
PUBLIC MgAsnElmntDef gcMsgStreamDescriptor =
{
#ifdef MG_ASN_DBG
  "gcMsgStreamDescriptor",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 70,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoStreamDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgStreamID
 *    StreamID ::= INTEGER    (0..65535) 
 */
PUBLIC MgAsnElmntDef gcMsgStreamID =
{
#ifdef MG_ASN_DBG
  "gcMsgStreamID",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 71,  /* idNum */ 
  TET_INT16,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoStreamId),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};

/*
 * gcMsgStreamsO
 * Streams ::= CHOICE {
 *               oneStream StreamParms
 *               multiStream SEQUENCE OF
 * } OPTIONAL
 */
PUBLIC MgAsnElmntDef gcMsgStreamsO =
{
#ifdef MG_ASN_DBG
  "gcMsgStreamsO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 72,  /* idNum */ 
  TET_CHOICE,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoMediaDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncStreamsEnc,         /* user function */
  mgAsnDecChoice,         /* user function (default works) */
};


/*
 * gcMsgModemDescriptor
 * ModemDescriptor ::= SEQUENCE {
 *               mtl SEQUENCE OF
 *               mpl SEQUENCE OF
 *               nonStandardData NonStandardData   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgModemDescriptor1 =
{
#ifdef MG_ASN_DBG
  "gcMsgModemDescriptor1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 73,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoModemDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgModemDescriptor2 =
{
#ifdef MG_ASN_DBG
  "gcMsgModemDescriptor2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 73,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoModemDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgMtl
 * Mtl ::= SEQUENCE  OF ModemType
 */
PUBLIC MgAsnElmntDef gcMsgMtl =
{
#ifdef MG_ASN_DBG
  "gcMsgMtl",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 74,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoModemTypeLst),   /* event structure size */
  MGAMAX_Mtl,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgModemType
 * ModemType ::= ENUMERATED {
 *       v18   (0)
 *       v22   (1)
 *       v22bis   (2)
 *       v32   (3)
 *       v32bis   (4)
 *       v34   (5)
 *       v90   (6)
 *       v91   (7)
 *       synchISDN   (8)
 * }
 */
PRIVATE U8 ModemTypeEnumLst[] = {10, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
PUBLIC MgAsnElmntDef gcMsgModemType =
{
#ifdef MG_ASN_DBG
  "gcMsgModemType",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 75,  /* idNum */ 
  TET_ENUM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoModemType),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  ModemTypeEnumLst,         /* enumbered values list */
  mgaFuncModemTypeEnc,         /* user function */
  mgaFuncModemTypeDec,         /* user function */
};


/*
 * gcMsgMpl
 * Mpl ::= SEQUENCE  OF PropertyParm
 */
PUBLIC MgAsnElmntDef gcMsgMpl =
{
#ifdef MG_ASN_DBG
  "gcMsgMpl",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 76,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoPropParmLst),   /* event structure size */
  MGAMAX_Mpl,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgNonStandardDataO
 * NonStandardData ::= SEQUENCE {
 *               nonStandardIdentifier NonStandardIdentifier
 *               data OCTET STRING
 * }
 */
PUBLIC MgAsnElmntDef gcMsgNonStandardDataO2 =
{
#ifdef MG_ASN_DBG
  "gcMsgNonStandardDataO2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 77,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoNonStdExtn),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncNonStandardDataEnc,         /* user function */
  mgaFuncNonStandardDataDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgNonStandardDataO8 =
{
#ifdef MG_ASN_DBG
  "gcMsgNonStandardDataO8",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 77,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoNonStdExtn),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncNonStandardDataEnc,         /* user function */
  mgaFuncNonStandardDataDec,         /* user function */
};


/*
 * gcMsgObject
 * Object ::= OBJECT IDENTIFIER
 */
PUBLIC MgAsnElmntDef gcMsgObject =
{
#ifdef MG_ASN_DBG
  "gcMsgObject",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 78,  /* idNum */ 
  TET_OID,         /* element type */
  0xFF,                            /* tag value */
  /* mg008.105: There is no max and min check for the length */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
/*  1,             minimum length */
/*  1,             maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknStrOSXL),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncObjectEnc,         /* user function */
  mgaFuncObjectDec,         /* user function */
};


/*
 * gcMsgH221NonStandard
 * H221NonStandard ::= SEQUENCE {
 *               t35CountryCode1 INTEGER
 *               t35CountryCode2 INTEGER
 *               t35Extension INTEGER
 *               manufacturerCode INTEGER
 * }
 */
PUBLIC MgAsnElmntDef gcMsgH221NonStandard =
{
#ifdef MG_ASN_DBG
  "gcMsgH221NonStandard",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 79,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoH221NonStd),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgT35CountryCode1
 *    T35CountryCode1 ::= INTEGER    (0..255) 
 */
PUBLIC MgAsnElmntDef gcMsgT35CountryCode1 =
{
#ifdef MG_ASN_DBG
  "gcMsgT35CountryCode1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 80,  /* idNum */ 
  TET_INT8,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  1,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgT35CountryCode2
 *    T35CountryCode2 ::= INTEGER    (0..255) 
 */
PUBLIC MgAsnElmntDef gcMsgT35CountryCode2 =
{
#ifdef MG_ASN_DBG
  "gcMsgT35CountryCode2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 81,  /* idNum */ 
  TET_INT8,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  1,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgT35Extension
 *    T35Extension ::= INTEGER    (0..255) 
 */
PUBLIC MgAsnElmntDef gcMsgT35Extension =
{
#ifdef MG_ASN_DBG
  "gcMsgT35Extension",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 82,  /* idNum */ 
  TET_INT8,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  1,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgManufacturerCode
 *    ManufacturerCode ::= INTEGER    (0..65535) 
 */
PUBLIC MgAsnElmntDef gcMsgManufacturerCode =
{
#ifdef MG_ASN_DBG
  "gcMsgManufacturerCode",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 83,  /* idNum */ 
  TET_INT16,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU16),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgExperimental
 * Experimental ::= IA5String       8  
 *    -- first two characters SHOULD be "X-" or "X+"
 */
PUBLIC MgAsnElmntDef gcMsgExperimental =
{
#ifdef MG_ASN_DBG
  "gcMsgExperimental",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 84,  /* idNum */ 
  TET_IA5STR12,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  8,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknStr8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};


/*
 * gcMsgNonStandardIdentifier
 * NonStandardIdentifier ::= CHOICE {
 *               object OBJECT IDENTIFIER
 *               h221NonStandard H221NonStandard
 *               experimental CHARACTER STRING
 * }
 */
PUBLIC MgAsnElmntDef gcMsgNonStandardIdentifier =
{
#ifdef MG_ASN_DBG
  "gcMsgNonStandardIdentifier",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 85,  /* idNum */ 
  TET_CHOICE,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoNonStdId),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncNonStandardIdEnc,         /* user function */
  mgaFuncNonStandardIdDec,         /* user function */
};


/*
 * gcMsgData
 * Data ::= OCTET STRING
 */
PUBLIC MgAsnElmntDef gcMsgData =
{
#ifdef MG_ASN_DBG
  "gcMsgData",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 86,  /* idNum */ 
  /* mg007.105: Corrected the Data type correctly */
/*  TET_STRXL_MEM,          element type */
  TET_STROSXL_MEM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  0,   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  /* mg008.105: Data is Mandatory */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};


/*
 * gcMsgMuxDescriptor
 * MuxDescriptor ::= SEQUENCE {
 *               muxType MuxType
 *               termList SEQUENCE OF
 *               nonStandardData NonStandardData   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgMuxDescriptor2 =
{
#ifdef MG_ASN_DBG
  "gcMsgMuxDescriptor2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 87,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoMuxDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncMuxDescriptorEnc,         /* user function */
  mgaFuncMuxDescriptorDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgMuxDescriptor3 =
{
#ifdef MG_ASN_DBG
  "gcMsgMuxDescriptor3",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 87,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoMuxDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncMuxDescriptorEnc,         /* user function */
  mgaFuncMuxDescriptorDec,         /* user function */
};


/*
 * gcMsgMuxType
 * MuxType ::= ENUMERATED {
 *       h221   (0)
 *       h223   (1)
 *       h226   (2)
 *       v76   (3)
 *       nx64k   (4) (added for V2)
 * }
 */
#ifdef MGT_MGCO_V2
PRIVATE U8 MuxTypeEnumLst[] = {6, 0, 1, 2, 3, 4, 5};
#else
PRIVATE U8 MuxTypeEnumLst[] = {5, 0, 1, 2, 3, 4};
#endif
PUBLIC MgAsnElmntDef gcMsgMuxType =
{
#ifdef MG_ASN_DBG
  "gcMsgMuxType",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 88,  /* idNum */ 
  TET_ENUM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  MuxTypeEnumLst,         /* enumbered values list */
  mgaFuncMuxTypeEnc,         /* user function */
  mgaFuncMuxTypeDec,         /* user function */
};


/*
 * gcMsgTermList
 * TermList ::= SEQUENCE  OF TerminationID
 */
PUBLIC MgAsnElmntDef gcMsgTermList =
{
#ifdef MG_ASN_DBG
  "gcMsgTermList",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 89,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTermIdLst),   /* event structure size */
  MGAMAX_TermList,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgEventsDescriptor
 * EventsDescriptor ::= SEQUENCE {
 *               requestID RequestID   OPTIONAL
 *               eventList SEQUENCE OF
 * }
 */
PUBLIC MgAsnElmntDef gcMsgEventsDescriptor3 =
{
#ifdef MG_ASN_DBG
  "gcMsgEventsDescriptor3",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 90,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,              /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoReqEvtDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  /* mg003.105: Modify - Changed the encoding/decoding functions */
  mgaFuncEventsDescriptorEnc,
  mgaFuncEventsDescriptorDec,
};
PUBLIC MgAsnElmntDef gcMsgEventsDescriptor4 =
{
#ifdef MG_ASN_DBG
  "gcMsgEventsDescriptor4",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 90,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoReqEvtDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  /* mg003.105: Modify - Changed the encoding/decoding functions */
  mgaFuncEventsDescriptorEnc,
  mgaFuncEventsDescriptorDec,
};


/*
 * gcMsgRequestIDO
 *    RequestID ::= INTEGER    (0..4294967295) 
 */
PUBLIC MgAsnElmntDef gcMsgRequestIDO =
{
#ifdef MG_ASN_DBG
  "gcMsgRequestIDO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 91,  /* idNum */ 
  TET_INT32,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  4,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoRequestId),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncRequestIDEnc,         /* user function */
  mgaFuncRequestIDDec,         /* user function */
};


/*
 * gcMsgEventList
 * EventList ::= SEQUENCE  OF RequestedEvent
 */
PUBLIC MgAsnElmntDef gcMsgEventList =
{
#ifdef MG_ASN_DBG
  "gcMsgEventList",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 92,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* mg003.105: Change minimum length from 1 */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoEvtLst),      /* event structure size */
  MGAMAX_EventList,      /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgRequestedEvent
 * RequestedEvent ::= SEQUENCE {
 *               pkgdName PkgdName
 *               streamID StreamID   OPTIONAL
 *               eventAction RequestedActions   OPTIONAL
 *               evParList EvParList
 * }
 */
PUBLIC MgAsnElmntDef gcMsgRequestedEvent =
{
#ifdef MG_ASN_DBG
  "gcMsgRequestedEvent",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 93,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoReqEvt),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncRequestedEventEnc,         /* user function */
  mgaFuncRequestedEventDec,         /* user function */
};


/*
 * gcMsgStreamIDO
 *    StreamID ::= INTEGER    (0..65535) 
 */
PUBLIC MgAsnElmntDef gcMsgStreamIDO1 =
{
#ifdef MG_ASN_DBG
  "gcMsgStreamIDO1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 94,  /* idNum */ 
  TET_INT16,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU16),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgStreamIDO2 =
{
#ifdef MG_ASN_DBG
  "gcMsgStreamIDO2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 94,  /* idNum */ 
  TET_INT16,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU16),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgStreamIDOV2 =
{
#ifdef MG_ASN_DBG
  "gcMsgStreamIDOV2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 94,  /* idNum */ 
  TET_INT16,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU16),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgRequestedActionsO
 * RequestedActions ::= SEQUENCE {
 *               keepActive KeepActive   OPTIONAL
 *               eventDM EventDM   OPTIONAL
 *               secondEvent SecondEventsDescriptor   OPTIONAL
 *               signalsDescriptor SignalsDescriptor   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgRequestedActionsO =
{
#ifdef MG_ASN_DBG
  "gcMsgRequestedActionsO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 95,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoEvtParLst),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncRequestedActionsEnc,         /* user function */
  mgaFuncRequestedActionsDec,         /* user function */
};


/*
 * gcMsgKeepActiveO
 * KeepActive ::= BOOLEAN
 */
PUBLIC MgAsnElmntDef gcMsgKeepActiveO0 =
{
#ifdef MG_ASN_DBG
  "gcMsgKeepActiveO0",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 96,  /* idNum */ 
  TET_BOOL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncBool,         /* user function */
  mgAsnDecBool,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgKeepActiveO5 =
{
#ifdef MG_ASN_DBG
  "gcMsgKeepActiveO5",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 96,  /* idNum */ 
  TET_BOOL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncBool,         /* user function */
  mgAsnDecBool,         /* user function */
};


/*
 * gcMsgName
 * Name ::= OCTET STRING       2  
 */
PUBLIC MgAsnElmntDef gcMsgName =
{
#ifdef MG_ASN_DBG
  "gcMsgName",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 97,  /* idNum */ 
  TET_STR4,         /* element type */
  0xFF,                            /* tag value */
  2,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoName),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncNameSpecialEnc,   /* user function */
  mgaFuncNameSpecialDec,   /* user function */
};
/* Special is used for packages name/value pairs */
PUBLIC MgAsnElmntDef gcMsgNameSpecial =
{
#ifdef MG_ASN_DBG
  "gcMsgNameSpecial",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 597,  /* idNum */ 
  TET_STR4,         /* element type */
  0xFF,                            /* tag value */
  2,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoName),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncNameSpecialEnc,   /* user function */
  mgaFuncNameSpecialDec,   /* user function */
};


/*
 * gcMsgDigitMapValue
 * DigitMapValue ::= SEQUENCE {
 *               startTimer INTEGER   OPTIONAL
 *               shortTimer INTEGER   OPTIONAL
 *               longTimer INTEGER   OPTIONAL
 *               digitMapBody CHARACTER STRING
 *               durationTimer INTEGER   OPTIONAL (added for V2)
 * }
 */
PUBLIC MgAsnElmntDef gcMsgDigitMapValue =
{
#ifdef MG_ASN_DBG
  "gcMsgDigitMapValue",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 98,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoDigMapVal),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgStartTimerO
 *    StartTimer ::= INTEGER    (0..99) 
 */
PUBLIC MgAsnElmntDef gcMsgStartTimerO =
{
#ifdef MG_ASN_DBG
  "gcMsgStartTimerO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 99,  /* idNum */ 
  TET_INT8,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  1,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgShortTimerO
 *    ShortTimer ::= INTEGER    (0..99) 
 */
PUBLIC MgAsnElmntDef gcMsgShortTimerO =
{
#ifdef MG_ASN_DBG
  "gcMsgShortTimerO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 100,  /* idNum */ 
  TET_INT8,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  1,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgLongTimerO
 *    LongTimer ::= INTEGER    (0..99) 
 */
PUBLIC MgAsnElmntDef gcMsgLongTimerO =
{
#ifdef MG_ASN_DBG
  "gcMsgLongTimerO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 101,  /* idNum */ 
  TET_INT8,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  1,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgDigitMapBody
 * DigitMapBody ::= IA5String
 */
PUBLIC MgAsnElmntDef gcMsgDigitMapBody =
{
#ifdef MG_ASN_DBG
  "gcMsgDigitMapBody",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 102,  /* idNum */ 
  TET_IA5STRXL_MEM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
#if defined (GCP_VER_1_3) && defined (GCP_MGCO_PARSE_DIG_MAP)
  sizeof(TknStrOSXL),          /* event structure size */
#else 
  sizeof(MgMgcoDigMap),          /* event structure size */
#endif
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
#if defined (GCP_VER_1_3) && defined (GCP_MGCO_PARSE_DIG_MAP)
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
#else 
  mgaFuncDigitMapBodyEnc,         /* user function */
  mgaFuncDigitMapBodyDec,         /* user function */
#endif
};


/*
 * gcMsgEventDMO
 * EventDM ::= CHOICE {
 *               digitMapName DigitMapName
 *               digitMapValue DigitMapValue
 * }
 */
PUBLIC MgAsnElmntDef gcMsgEventDMO =
{
#ifdef MG_ASN_DBG
  "gcMsgEventDMO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 103,  /* idNum */ 
  TET_CHOICE0,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoEvtDM),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncChoice,         /* user function */
  mgAsnDecChoice,         /* user function */
};


/*
 * gcMsgSecondEventsDescriptorO
 * SecondEventsDescriptor ::= SEQUENCE {
 *               requestID RequestID   OPTIONAL
 *               secondEventList SEQUENCE OF
 * }
 */
PUBLIC MgAsnElmntDef gcMsgSecondEventsDescriptorO =
{
#ifdef MG_ASN_DBG
  "gcMsgSecondEventsDescriptorO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 104,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoEmbedFirst),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgSecondEventList
 * SecondEventList ::= SEQUENCE  OF SecondRequestedEvent
 */
PUBLIC MgAsnElmntDef gcMsgSecondEventList =
{
#ifdef MG_ASN_DBG
  "gcMsgSecondEventList",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 105,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoEvtSecLst),   /* event structure size */
  MGAMAX_SecondEventList,   /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgSecondRequestedEvent
 * SecondRequestedEvent ::= SEQUENCE {
 *               pkgdName PkgdName
 *               streamID StreamID   OPTIONAL
 *               eventAction SecondRequestedActions   OPTIONAL
 *               evParList EvParList
 * }
 */
PUBLIC MgAsnElmntDef gcMsgSecondRequestedEvent =
{
#ifdef MG_ASN_DBG
  "gcMsgSecondRequestedEvent",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 106,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoEvtSec),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncSecondRequestedEventEnc,         /* user function */
  mgaFuncSecondRequestedEventDec,         /* user function */
};


/*
 * gcMsgSecondRequestedActionsO
 * SecondRequestedActions ::= SEQUENCE {
 *               keepActive KeepActive   OPTIONAL
 *               eventDM EventDM   OPTIONAL
 *               signalsDescriptor SignalsDescriptor   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgSecondRequestedActionsO =
{
#ifdef MG_ASN_DBG
  "gcMsgSecondRequestedActionsO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 107,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoEvtParSecLst),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncSecondRequestedActionsEnc,         /* user function */
  mgaFuncSecondRequestedActionsDec,         /* user function */
};


/*
 * gcMsgSignalsDescriptorO
 * SignalsDescriptor ::= SEQUENCE  OF SignalRequest
 */
PUBLIC MgAsnElmntDef gcMsgSignalsDescriptorO2 =
{
#ifdef MG_ASN_DBG
  "gcMsgSignalsDescriptorO2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 108,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSignalsDesc),   /* event structure size */
  MGAMAX_SignalsDescriptor,   /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncSignalsDescriptorEnc,         /* user function */
  mgaFuncSignalsDescriptorDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgSignalsDescriptorO3 =
{
#ifdef MG_ASN_DBG
  "gcMsgSignalsDescriptorO3",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 108,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSignalsDesc),   /* event structure size */
  MGAMAX_SignalsDescriptor,   /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncSignalsDescriptorEnc,         /* user function */
  mgaFuncSignalsDescriptorDec,         /* user function */
};


/*
 * gcMsgSignal
 * Signal ::= SEQUENCE {
 *               signalName SignalName
 *               streamID StreamID   OPTIONAL
 *               sigType SignalType   OPTIONAL
 *               duration INTEGER   OPTIONAL
 *               notifyCompletion NotifyCompletion   OPTIONAL
 *               keepActive KeepActive   OPTIONAL
 *               sigParList SEQUENCE OF
 * }
 */
PUBLIC MgAsnElmntDef gcMsgSignal =
{
#ifdef MG_ASN_DBG
  "gcMsgSignal",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 109,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSignalsReq),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncSignalEnc,         /* user function */
  mgaFuncSignalDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgSignal30 =
{
#ifdef MG_ASN_DBG
  "gcMsgSignal30",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 109,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSignalsReq),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncSignalEnc,         /* user function */
  mgaFuncSignalDec,         /* user function */
};


/*
 * gcMsgSignalTypeO
 * SignalType ::= ENUMERATED {
 *       brief   (0)
 *       onOff   (1)
 *       timeOut   (2)
 * }
 */
PRIVATE U8 SignalTypeEnumLst[] = {3, 0, 1, 2};
PUBLIC MgAsnElmntDef gcMsgSignalTypeO =
{
#ifdef MG_ASN_DBG
  "gcMsgSignalTypeO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 110,  /* idNum */ 
  TET_ENUM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  SignalTypeEnumLst,         /* enumbered values list */
  mgAsnEncOctetEnum,         /* user function */
  mgAsnDecOctetEnum,         /* user function */
};


/*
 * gcMsgDurationO
 *    Duration ::= INTEGER    (0..65535) 
 */
PUBLIC MgAsnElmntDef gcMsgDurationO =
{
#ifdef MG_ASN_DBG
  "gcMsgDurationO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 111,  /* idNum */ 
  TET_INT16,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU16),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgNotifyCompletionO
 * NotifyCompletion ::= BIT STRING {
 *                  onTimeOut   (0)
 *                  onInterruptByEvent   (1)
 *                  onInterruptByNewSignalDescr   (2)
 *                  otherReason   (3)
 * }
 */
PUBLIC MgAsnElmntDef gcMsgNotifyCompletionO =
{
#ifdef MG_ASN_DBG
  "gcMsgNotifyCompletionO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 112,  /* idNum */ 
  TET_BITSTR,         /* element type */
  0xFF,                            /* tag value */
  1,         /* minimum length */
  4,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoNtfyCmpl),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncNotifyCompletionEnc,         /* user function */
  mgaFuncNotifyCompletionDec,         /* user function */
};


/*
 * gcMsgSigParList
 * SigParList ::= SEQUENCE  OF SigParameter
 */
PUBLIC MgAsnElmntDef gcMsgSigParList =
{
#ifdef MG_ASN_DBG
  "gcMsgSigParList",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 113,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* mg003.105: Change minimum length from 1 */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSigParLst),   /* event structure size */
  MGAMAX_SigParList,         /* counter for repeat element */
  &gcManditory,               /* mg003.105: gcOptional,         protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgSigParameter
 * SigParameter ::= SEQUENCE {
 *               sigParameterName Name
 *               value Value
 *               extraInfo ExtraInfo   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgSigParameter =
{
#ifdef MG_ASN_DBG
  "gcMsgSigParameter",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 114,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSigPar),      /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncSigParameterEnc,         /* user function */
  mgaFuncSigParameterDec,         /* user function */
};


/*
 * gcMsgValue
 * Value ::= SEQUENCE  OF OCTET STRING
 */
PUBLIC MgAsnElmntDef gcMsgValue =
{
#ifdef MG_ASN_DBG
  "gcMsgValue",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 115,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoValLst),   /* event structure size */
  MGAMAX_Value,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncPropParmValueEnc,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgValueSeqOf
 * ValueSeqOf ::= OCTET STRING
 */
PUBLIC MgAsnElmntDef gcMsgValueSeqOf =
{
#ifdef MG_ASN_DBG
  "gcMsgValueSeqOf",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 116,  /* idNum */ 
  TET_STRXL_MEM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoValue),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryIgnorePres,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncValueSeqOfEnc,         /* user function */
  mgaFuncValueSeqOfDec,         /* user function */
};


/*
 * gcMsgSeqSigList
 * SeqSigList ::= SEQUENCE {
 *               idSeqSig INTEGER
 *               signalList SEQUENCE OF
 * }
 */
PUBLIC MgAsnElmntDef gcMsgSeqSigList =
{
#ifdef MG_ASN_DBG
  "gcMsgSeqSigList",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 117,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSignalsLst),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgIdSeqSig
 *    IdSeqSig ::= INTEGER    (0..65535) 
 */
PUBLIC MgAsnElmntDef gcMsgIdSeqSig =
{
#ifdef MG_ASN_DBG
  "gcMsgIdSeqSig",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 118,  /* idNum */ 
  TET_INT16,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU16),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgSignalList
 * SignalList ::= SEQUENCE  OF Signal
 */
PUBLIC MgAsnElmntDef gcMsgSignalList =
{
#ifdef MG_ASN_DBG
  "gcMsgSignalList",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 119,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSignalsReqLst),   /* event structure size */
  MGAMAX_SignalList,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgSignalRequest
 * SignalRequest ::= CHOICE {
 *               signal Signal
 *               seqSigList SeqSigList
 * }
 */
PUBLIC MgAsnElmntDef gcMsgSignalRequest =
{
#ifdef MG_ASN_DBG
  "gcMsgSignalRequest",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 120,  /* idNum */ 
  TET_CHOICE,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSignalsParm),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncSignalRequestEnc,         /* user function */
  mgaFuncSignalRequestDec,         /* user function */
};


/*
 * gcMsgEvParList
 * EvParList ::= SEQUENCE  OF EventParameter
 */
PUBLIC MgAsnElmntDef gcMsgEvParList =
{
#ifdef MG_ASN_DBG
  "gcMsgEvParList",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 121,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  /* mg003.105: Changes for minimum elements to encode */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoEvtParLst),   /* event structure size */
  MGAMAX_EvParList,      /* counter for repeat element */
  &gcManditory,   /* mg003.105: gcOptional,          protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgEventParameter
 * EventParameter ::= SEQUENCE {
 *               eventParameterName Name
 *               value Value
 *               extraInfo ExtraInfo   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgEventParameter =
{
#ifdef MG_ASN_DBG
  "gcMsgEventParameter",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 122,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoEvtPar),      /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncEventParameterEnc,         /* user function */
  mgaFuncEventParameterDec,         /* user function */
};


/*
 * gcMsgEventBufferDescriptor
 * EventBufferDescriptor ::= SEQUENCE  OF EventSpec
 */
PUBLIC MgAsnElmntDef gcMsgEventBufferDescriptor4 =
{
#ifdef MG_ASN_DBG
  "gcMsgEventBufferDescriptor4",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 123,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoEvBufDesc),   /* event structure size */
  MGAMAX_EventBufferDescriptor,   /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgEventBufferDescriptor5 =
{
#ifdef MG_ASN_DBG
  "gcMsgEventBufferDescriptor5",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 123,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoEvBufDesc),   /* event structure size */
  MGAMAX_EventBufferDescriptor,   /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgEventSpec
 * EventSpec ::= SEQUENCE {
 *               eventName EventName
 *               streamID StreamID   OPTIONAL
 *               eventParList EventParList
 * }
 */
PUBLIC MgAsnElmntDef gcMsgEventSpec =
{
#ifdef MG_ASN_DBG
  "gcMsgEventSpec",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 124,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoEvSpec),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncEventSpecEnc,         /* user function */
  mgaFuncEventSpecDec,         /* user function */
};


/*
 * gcMsgEventParList
 * EventParList ::= SEQUENCE  OF EventParameter
 */
PUBLIC MgAsnElmntDef gcMsgEventParList =
{
#ifdef MG_ASN_DBG
  "gcMsgEventParList",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 125,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  /* mg003.105: Changes for minimum elements to encode */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgEvntParamTypeSet),   /* event structure size */
  MGAMAX_EventParList,         /* counter for repeat element */
  &gcOptional,                  /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgSignalsDescriptor
 * SignalsDescriptor ::= SEQUENCE  OF SignalRequest
 */
PUBLIC MgAsnElmntDef gcMsgSignalsDescriptor5 =
{
#ifdef MG_ASN_DBG
  "gcMsgSignalsDescriptor5",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 126,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSignalsDesc),   /* event structure size */
  MGAMAX_SignalsDescriptor,   /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncSignalsDescriptorEnc,         /* user function */
  mgaFuncSignalsDescriptorDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgSignalsDescriptor6 =
{
#ifdef MG_ASN_DBG
  "gcMsgSignalsDescriptor6",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 126,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSignalsDesc),   /* event structure size */
  MGAMAX_SignalsDescriptor,   /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncSignalsDescriptorEnc,         /* user function */
  mgaFuncSignalsDescriptorDec,         /* user function */
};


/*
 * gcMsgDigitMapDescriptor
 * DigitMapDescriptor ::= SEQUENCE {
 *               digitMapName DigitMapName   OPTIONAL
 *               digitMapValue DigitMapValue   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgDigitMapDescriptor6 =
{
#ifdef MG_ASN_DBG
  "gcMsgDigitMapDescriptor6",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 127,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoDigMapDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgDigitMapDescriptor7 =
{
#ifdef MG_ASN_DBG
  "gcMsgDigitMapDescriptor7",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 127,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoDigMapDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgNameO
 * Name ::= OCTET STRING       2  
 */
PUBLIC MgAsnElmntDef gcMsgNameO =
{
#ifdef MG_ASN_DBG
  "gcMsgNameO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 128,  /* idNum */ 
  TET_STR4,         /* element type */
  0xFF,                            /* tag value */
  2,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoName),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncMsgNameEnc,         /* user function */
  mgaFuncMsgNameDec,         /* user function */
};


/*
 * gcMsgDurationTimerO
 *    DurationTimer ::= INTEGER    (0..99) 
 */
PUBLIC MgAsnElmntDef gcMsgDurationTimerO =
{
#ifdef MG_ASN_DBG
  "gcMsgDurationTimerO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 777,  /* idNum */ 
  TET_INT8,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  1,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgDigitMapValueO
 * DigitMapValue ::= SEQUENCE {
 *               startTimer INTEGER   OPTIONAL
 *               shortTimer INTEGER   OPTIONAL
 *               longTimer INTEGER   OPTIONAL
 *               digitMapBody CHARACTER STRING
 *               durationTimer INTEGER   OPTIONAL (added for V2)
 * }
 */
PUBLIC MgAsnElmntDef gcMsgDigitMapValueO =
{
#ifdef MG_ASN_DBG
  "gcMsgDigitMapValueO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 129,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoDigMapVal),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgAuditDescriptor
 * AuditDescriptor ::= SEQUENCE {
 *               auditToken BIT STRING   OPTIONAL
 *               auditPropertyToken ::= SEQUENCE OF IndAuditParameter OPTIONAL  (added for V2)
 * 
 */
PUBLIC MgAsnElmntDef gcMsgAuditDescriptor1 =
{
#ifdef MG_ASN_DBG
  "gcMsgAuditDescriptor1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 130,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAuditDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncAuditDescriptorEnc,         /* user function */
  mgaFuncAuditDescriptorDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgAuditDescriptor7 =
{
#ifdef MG_ASN_DBG
  "gcMsgAuditDescriptor7",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 130,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAuditDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncAuditDescriptorEnc,         /* user function */
  mgaFuncAuditDescriptorDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgAuditDescriptorB =
{
#ifdef MG_ASN_DBG
  "gcMsgAuditDescriptorB",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 130,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAuditDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncAuditDescriptorEnc,         /* user function */
  mgaFuncAuditDescriptorDec,         /* user function */
};


/*
 * gcMsgAuditTokenO
 * AuditToken ::= BIT STRING {
 *                  muxToken   (0)
 *                  modemToken   (1)
 *                  mediaToken   (2)
 *                  eventsToken   (3)
 *                  signalsToken   (4)
 *                  digitMapToken   (5)
 *                  statsToken   (6)
 *                  observedEventsToken   (7)
 *                  packagesToken   (8)
 *                  eventBufferToken   (9)
 * }
 */
PUBLIC MgAsnElmntDef gcMsgAuditTokenO =
{
#ifdef MG_ASN_DBG
  "gcMsgAuditTokenO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 131,  /* idNum */ 
  TET_BITSTR,         /* element type */
  0xFF,                            /* tag value */
  1,         /* minimum length */
  10,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknStr12),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncBitStr,         /* user function */
  mgAsnDecBitStr,         /* user function */
};


/*
 * gcMsgAmmDescriptor
 * AmmDescriptor ::= CHOICE {
 *               mediaDescriptor MediaDescriptor
 *               modemDescriptor ModemDescriptor
 *               muxDescriptor MuxDescriptor
 *               eventsDescriptor EventsDescriptor
 *               eventBufferDescriptor EventBufferDescriptor
 *               signalsDescriptor SignalsDescriptor
 *               digitMapDescriptor DigitMapDescriptor
 *               auditDescriptor AuditDescriptor
 * }
 */
PUBLIC MgAsnElmntDef gcMsgAmmDescriptor =
{
#ifdef MG_ASN_DBG
  "gcMsgAmmDescriptor",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 132,  /* idNum */ 
  TET_CHOICE,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAmmDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncAmmDescriptorEnc,         /* user function */
  mgaFuncAmmDescriptorDec,         /* user function */
};


/*
 * gcMsgSubtractRequest
 * SubtractRequest ::= SEQUENCE {
 *               terminationID TerminationIDList
 *               auditDescriptor AuditDescriptor   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgSubtractRequest =
{
#ifdef MG_ASN_DBG
  "gcMsgSubtractRequest",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 133,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSubAudReq),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgAuditDescriptorO
 * AuditDescriptor ::= SEQUENCE {
 *               auditToken BIT STRING   OPTIONAL
 *               IndAuditParameters  OPTIONAL  (added for V2)
 * }
 */
PUBLIC MgAsnElmntDef gcMsgAuditDescriptorO =
{
#ifdef MG_ASN_DBG
  "gcMsgAuditDescriptorO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 134,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAuditDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncAuditDescriptorEnc,         /* user function */
  mgaFuncAuditDescriptorDec,         /* user function */
};
#ifdef MGT_MGCO_V2
PUBLIC MgAsnElmntDef gcMsgAuditDescriptorOV2 =
{
  /* This AuditDescriptor is intended for the ServiceChangeParm
   * use only (or anywhere it may map to ABNF's AuditItem
   */
#ifdef MG_ASN_DBG
  "gcMsgAuditDescriptorO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 134,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAuditDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncAuditDescriptorOV2Enc,      /* user function */
  mgaFuncAuditDescriptorOV2Dec,      /* user function */
};
#endif

/*
 * gcMsgAuditRequest
 * AuditRequest ::= SEQUENCE {
 *               terminationID TerminationID
 *               auditDescriptor AuditDescriptor
 * }
 */
PUBLIC MgAsnElmntDef gcMsgAuditRequest4 =
{
#ifdef MG_ASN_DBG
  "gcMsgAuditRequest4",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 135,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSubAudReq),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgAuditRequest5 =
{
#ifdef MG_ASN_DBG
  "gcMsgAuditRequest5",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 135,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSubAudReq),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgNotifyRequest
 * NotifyRequest ::= SEQUENCE {
 *               terminationID TerminationIDList
 *               observedEventsDescriptor ObservedEventsDescriptor
 *               errorDescriptor ErrorDescriptor   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgNotifyRequest =
{
#ifdef MG_ASN_DBG
  "gcMsgNotifyRequest",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 136,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoNtfyReq),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgObservedEventsDescriptor
 * ObservedEventsDescriptor ::= SEQUENCE {
 *               requestId RequestID
 *               observedEventLst SEQUENCE OF
 * }
 */
PUBLIC MgAsnElmntDef gcMsgObservedEventsDescriptor1 =
{
#ifdef MG_ASN_DBG
  "gcMsgObservedEventsDescriptor1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 137,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoObsEvtDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgObservedEventsDescriptor8 =
{
#ifdef MG_ASN_DBG
  "gcMsgObservedEventsDescriptor8",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 137,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoObsEvtDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgRequestID
 *    RequestID ::= INTEGER    (0..4294967295) 
 */
PUBLIC MgAsnElmntDef gcMsgRequestID =
{
#ifdef MG_ASN_DBG
  "gcMsgRequestID",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 138,  /* idNum */ 
  TET_INT32,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  4,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoRequestId),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,        /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncRequestIDEnc,         /* user function */
  mgaFuncRequestIDDec,         /* user function */
};


/*
 * gcMsgObservedEventLst
 * ObservedEventLst ::= SEQUENCE  OF ObservedEvent
 */
PUBLIC MgAsnElmntDef gcMsgObservedEventLst =
{
#ifdef MG_ASN_DBG
  "gcMsgObservedEventLst",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 139,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoObsEvtLst),   /* event structure size */
  MGAMAX_ObservedEventLst,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgObservedEvent
 * ObservedEvent ::= SEQUENCE {
 *               eventName EventName
 *               streamID StreamID   OPTIONAL
 *               eventParList EventParList
 *               timeNotation TimeNotation   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgObservedEvent =
{
#ifdef MG_ASN_DBG
  "gcMsgObservedEvent",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 140,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoObsEvt),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncObservedEventEnc,         /* user function */
  mgaFuncObservedEventDec,         /* user function */
};


/*
 * gcMsgTimeNotationO
 * TimeNotation ::= SEQUENCE {
 *               date CHARACTER STRING
 *               time CHARACTER STRING
 * }
 */
PUBLIC MgAsnElmntDef gcMsgTimeNotationO3 =
{
#ifdef MG_ASN_DBG
  "gcMsgTimeNotationO3",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 141,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTimeStamp),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgTimeNotationO4 =
{
#ifdef MG_ASN_DBG
  "gcMsgTimeNotationO4",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 141,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTimeStamp),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgTimeNotationO7 =
{
#ifdef MG_ASN_DBG
  "gcMsgTimeNotationO7",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 141,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTimeStamp),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};

/*
 * gcMsgDate
 * Date ::= IA5String       8  
 */
PUBLIC MgAsnElmntDef gcMsgDate =
{
#ifdef MG_ASN_DBG
  "gcMsgDate",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 143,  /* idNum */ 
  TET_IA5STR12,         /* element type */
  0xFF,                            /* tag value */
  8,         /* minimum length */
  8,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknStr8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};


/*
 * gcMsgTime
 * Time ::= IA5String       8  
 */
PUBLIC MgAsnElmntDef gcMsgTime =
{
#ifdef MG_ASN_DBG
  "gcMsgTime",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 144,  /* idNum */ 
  TET_IA5STR12,         /* element type */
  0xFF,                            /* tag value */
  8,         /* minimum length */
  8,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknStr8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};


/*
 * gcMsgErrorDescriptorO
 * ErrorDescriptor ::= SEQUENCE {
 *               errorCode ErrorCode
 *               errorText ErrorText   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgErrorDescriptorO1 =
{
#ifdef MG_ASN_DBG
  "gcMsgErrorDescriptorO1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 145,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoErrDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgErrorDescriptorO2 =
{
#ifdef MG_ASN_DBG
  "gcMsgErrorDescriptorO2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 145,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoErrDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgServiceChangeRequest
 * ServiceChangeRequest ::= SEQUENCE {
 *               terminationID TerminationIDList
 *               serviceChangeParms ServiceChangeParm
 * }
 */
PUBLIC MgAsnElmntDef gcMsgServiceChangeRequest =
{
#ifdef MG_ASN_DBG
  "gcMsgServiceChangeRequest",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 146,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSvcChgReq),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgServiceChangeParm
 * ServiceChangeParm ::= SEQUENCE {
 *               serviceChangeMethod ServiceChangeMethod
 *               serviceChangeAddress ServiceChangeAddress   OPTIONAL
 *               serviceChangeVersion ServiceChangeVersion   OPTIONAL
 *               serviceChangeProfile ServiceChangeProfile   OPTIONAL
 *               serviceChangeReason Value
 *               serviceChangeDelay INTEGER   OPTIONAL
 *               serviceChangeMgcId MId   OPTIONAL
 *               timeStamp TimeNotation   OPTIONAL
 *               nonStandardData NonStandardData   OPTIONAL
 *               serviceChangeInfo AuditDescriptor   OPTIONAL (added for V2)
 * }
 */
PUBLIC MgAsnElmntDef gcMsgServiceChangeParm =
{
#ifdef MG_ASN_DBG
  "gcMsgServiceChangeParm",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 147,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSvcChgPar),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncServiceChangeParmEnc,         /* user function */
  mgaFuncServiceChangeParmDec,         /* user function */
};


/*
 * gcMsgServiceChangeMethod
 * ServiceChangeMethod ::= ENUMERATED {
 *       failover   (0)
 *       forced   (1)
 *       graceful   (2)
 *       restart   (3)
 *       disconnected   (4)
 *       handOff   (5)
 * }
 */
PRIVATE U8 ServiceChangeMethodEnumLst[] = {7, 0, 1, 2, 3, 4, 5, 6};
PUBLIC MgAsnElmntDef gcMsgServiceChangeMethod =
{
#ifdef MG_ASN_DBG
  "gcMsgServiceChangeMethod",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 148,  /* idNum */ 
  TET_ENUM,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoSvcChgMethod),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  ServiceChangeMethodEnumLst,         /* enumbered values list */
  mgaFuncServiceChangeMethodEnc,         /* user function */
  mgaFuncServiceChangeMethodDec,         /* user function */
};


/*
 * gcMsgPortNumber
 *    PortNumber ::= INTEGER    (0..65535) 
 */
PUBLIC MgAsnElmntDef gcMsgPortNumber =
{
#ifdef MG_ASN_DBG
  "gcMsgPortNumber",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 149,  /* idNum */ 
  TET_INT16,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknS32),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  /* Port Number is mandatory for ServiceChangeAddress */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgServiceChangeAddressO
 * ServiceChangeAddress ::= CHOICE {
 *               portNumber PortNumber
 *               ip4Address IP4Address
 *               ip6Address IP6Address
 *               domainName DomainName
 *               deviceName PathName
 *               mtpAddress MtpAddress
 * }
 */
PUBLIC MgAsnElmntDef gcMsgServiceChangeAddressO =
{
#ifdef MG_ASN_DBG
  "gcMsgServiceChangeAddressO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 150,  /* idNum */ 
  TET_CHOICE,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSvcChgAddr),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncServiceChangeAddressEnc,         /* user function */
  mgaFuncServiceChangeAddressDec,         /* user function */
};

/*
 * gcMsgServiceChangeVersionO
 *    ServiceChangeVersion ::= INTEGER    (0..99) 
 */
PUBLIC MgAsnElmntDef gcMsgServiceChangeVersionO =
{
#ifdef MG_ASN_DBG
  "gcMsgServiceChangeVersionO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 152,  /* idNum */ 
  TET_INT8,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  1,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgServiceChangeProfileO
 * ServiceChangeProfile ::= SEQUENCE {
 *               profileName CHARACTER STRING
 * }
 */
PUBLIC MgAsnElmntDef gcMsgServiceChangeProfileO =
{
#ifdef MG_ASN_DBG
  "gcMsgServiceChangeProfileO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 153,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSvcChgProf),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncServiceChangeProfileEnc,         /* user function */
  mgaFuncServiceChangeProfileDec,         /* user function */
};


/*
 * gcMsgProfileName
 * ProfileName ::= IA5String       (1..67)  
 */
PUBLIC MgAsnElmntDef gcMsgProfileName =
{
#ifdef MG_ASN_DBG
  "gcMsgProfileName",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 154,  /* idNum */ 
  TET_IA5STR256,      
  0xFF,                            /* tag value */
  1,         /* minimum length */
  67,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoName),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncOctetStr,         /* user function */
  mgAsnDecOctetStr,         /* user function */
};

/*
 * gcMsgServiceChangeDelayO
 *    ServiceChangeDelay ::= INTEGER    (0..4294967295) 
 */
PUBLIC MgAsnElmntDef gcMsgServiceChangeDelayO =
{
#ifdef MG_ASN_DBG
  "gcMsgServiceChangeDelayO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 155,  /* idNum */ 
  TET_INT32,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  4,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU32),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgMIdO
 * MId ::= CHOICE {
 *               ip4Address IP4Address
 *               ip6Address IP6Address
 *               domainName DomainName
 *               deviceName PathName
 *               mtpAddress MtpAddress
 * }
 */
PUBLIC MgAsnElmntDef gcMsgMIdO0 =
{
#ifdef MG_ASN_DBG
  "gcMsgMIdO0",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 156,  /* idNum */ 
  TET_CHOICE,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoMid),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncMIdEnc,         /* user function */
  mgaFuncMIdDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgMIdO6 =
{
#ifdef MG_ASN_DBG
  "gcMsgMIdO6",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 156,  /* idNum */ 
  TET_CHOICE,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoMid),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncMIdEnc,         /* user function */
  mgaFuncMIdDec,         /* user function */
};

/*
 * gcMsgCommand
 * Command ::= CHOICE {
 *               addReq AmmRequest
 *               moveReq AmmRequest
 *               modReq AmmRequest
 *               subtractReq SubtractRequest
 *               auditCapRequest AuditRequest
 *               auditValueRequest AuditRequest
 *               notifyReq NotifyRequest
 *               serviceChangeReq ServiceChangeRequest
 * }
 */
PUBLIC MgAsnElmntDef gcMsgCommand =
{
#ifdef MG_ASN_DBG
  "gcMsgCommand",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 158,  /* idNum */ 
  TET_CHOICE0,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoCmd),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncChoice,         /* user function */
  mgAsnDecChoice,         /* user function */
};


/*
 * gcMsgOptionalO
 *   Optional ::= NULL
 *
 */
PUBLIC MgAsnElmntDef gcMsgOptionalO =
{
#ifdef MG_ASN_DBG
  "gcMsgOptionalO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 159,  /* idNum */ 
  TET_NULL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknPres),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncNull,         /* user function */
  mgAsnDecNull,         /* user function */
};


/*
 * gcMsgWildcardReturnO
 *   WildcardReturn ::= NULL
 *
 */
PUBLIC MgAsnElmntDef gcMsgWildcardReturnO =
{
#ifdef MG_ASN_DBG
  "gcMsgWildcardReturnO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 160,  /* idNum */ 
  TET_NULL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknPres),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncNull,         /* user function */
  mgAsnDecNull,         /* user function */
};


/*
 * gcMsgTransactionPending
 * TransactionPending ::= SEQUENCE {
 *               transactionId TransactionId
 * }
 */
PUBLIC MgAsnElmntDef gcMsgTransactionPending =
{
#ifdef MG_ASN_DBG
  "gcMsgTransactionPending",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 161,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTxnPend),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgTransactionReply
 * TransactionReply ::= SEQUENCE {
 *               transactionId TransactionId
 *               immAckRequired NULL   OPTIONAL
 *               transactionResult CHOICE
 * }
 */
PUBLIC MgAsnElmntDef gcMsgTransactionReply =
{
#ifdef MG_ASN_DBG
  "gcMsgTransactionReply",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 162,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTxnReply),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgImmAckRequiredO
 *   ImmAckRequired ::= NULL
 *
 */
PUBLIC MgAsnElmntDef gcMsgImmAckRequiredO =
{
#ifdef MG_ASN_DBG
  "gcMsgImmAckRequiredO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 163,  /* idNum */ 
  TET_NULL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknPres),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncNull,         /* user function */
  mgAsnDecNull,         /* user function */
};


/*
 * gcMsgActionReplies
 * ActionReplies ::= SEQUENCE  OF ActionReply
 */
PUBLIC MgAsnElmntDef gcMsgActionReplies =
{
#ifdef MG_ASN_DBG
  "gcMsgActionReplies",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 164,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  1,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoActnReplyLst),   /* event structure size */
  MGAMAX_ActionReplies,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgActionReply
 * ActionReply ::= SEQUENCE {
 *               contextId ContextID
 *               errorDescriptor ErrorDescriptor   OPTIONAL
 *               contextReply ContextRequest   OPTIONAL
 *               commandReplyList SEQUENCE OF
 * }
 */
PUBLIC MgAsnElmntDef gcMsgActionReply =
{
#ifdef MG_ASN_DBG
  "gcMsgActionReply",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 165,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoActnReply),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncActionReplyEnc,         /* user function */
  mgaFuncActionReplyDec,         /* user function */
};


/*
 * gcMsgCommandReplyList
 * CommandReplyList ::= SEQUENCE  OF CommandReply
 */
PUBLIC MgAsnElmntDef gcMsgCommandReplyList =
{
#ifdef MG_ASN_DBG
  "gcMsgCommandReplyList",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 166,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoCmdReplyLst),   /* event structure size */
  MGAMAX_CommandReplyList,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
/* 
 *  mg003.105: called different Function to encode/decode if CH is used  
 *  CH will use new MemCp ( Allocated using mgAllocEventMem ) while non CH path
 *  will use Txn[] MemCp
 */
#ifdef GCP_CH
  mgAsnEncUnconsCmdSetSeqOf,         /* user function */
#else               
  mgAsnEncUnconsSetSeqOf,         /* user function */
#endif /* GCP_CH */
#ifdef GCP_CH
     mgAsnDecUnconsCmdRepSetSeqOf,    
#else               
  mgAsnDecUnconsSetSeqOf,         /* user function */
#endif /* GCP_CH */
};


/*
 * gcMsgAmmsReply
 * AmmsReply ::= SEQUENCE {
 *               terminationID TerminationIDList
 *               terminationAudit TerminationAudit   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgAmmsReply0 =
{
#ifdef MG_ASN_DBG
  "gcMsgAmmsReply0",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 167,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAmmsReply),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgAmmsReply1 =
{
#ifdef MG_ASN_DBG
  "gcMsgAmmsReply1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 167,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAmmsReply),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgAmmsReply2 =
{
#ifdef MG_ASN_DBG
  "gcMsgAmmsReply2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 167,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAmmsReply),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgAmmsReply3 =
{
#ifdef MG_ASN_DBG
  "gcMsgAmmsReply3",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 167,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAmmsReply),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};

/*
 * gcMsgTerminationAuditO
 * TerminationAudit ::= SEQUENCE  OF AuditReturnParameter
 */
PUBLIC MgAsnElmntDef gcMsgTerminationAuditO =
{
#ifdef MG_ASN_DBG
  "gcMsgTerminationAuditO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 168,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  /* mg007.105: changed for the empty AuditReturnParameter */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTermAuditRes),   /* event structure size */
  MGAMAX_TerminationAudit,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgStatisticsDescriptor
 * StatisticsDescriptor ::= SEQUENCE  OF StatisticsParameter
 */
PUBLIC MgAsnElmntDef gcMsgStatisticsDescriptor =
{
#ifdef MG_ASN_DBG
  "gcMsgStatisticsDescriptor",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 169,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoStatsDesc),   /* event structure size */
  MGAMAX_StatisticsDescriptor,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgStatisticsParameter
 * StatisticsParameter ::= SEQUENCE {
 *               statName PkgdName
 *               statValue Value   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgStatisticsParameter =
{
#ifdef MG_ASN_DBG
  "gcMsgStatisticsParameter",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 170,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoStatsPar),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncStatisticsParameterEnc,   /* user function */
  mgaFuncStatisticsParameterDec,   /* user function */
};


/*
 * gcMsgValueO
 * Value ::= SEQUENCE  OF 
 */
PUBLIC MgAsnElmntDef gcMsgValueO =
{
#ifdef MG_ASN_DBG
  "gcMsgValueO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 171,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoValue),   /* event structure size */
  MGAMAX_Value,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgServiceChangeReason =
{
#ifdef MG_ASN_DBG
  "gcMsgServiceChangeReason",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 671,  /* idNum */ 
  TET_STROSXL_MEM,         /* element type */
   /* mg003.105: Changes for ServiceChangeReason Tag */
  0xA4,                            /* tag value */
  1,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknStrOSXL),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncServiceChangeReasonEnc,         /* user function */
  mgaFuncServiceChangeReasonDec,         /* user function */
};

/*
 * gcMsgPackagesDescriptor
 * PackagesDescriptor ::= SEQUENCE  OF PackagesItem
 */
PUBLIC MgAsnElmntDef gcMsgPackagesDescriptor =
{
#ifdef MG_ASN_DBG
  "gcMsgPackagesDescriptor",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 172,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoPkgsDesc),   /* event structure size */
  MGAMAX_PackagesDescriptor,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgPackagesItem
 * PackagesItem ::= SEQUENCE {
 *               packageName Name
 *               packageVersion INTEGER
 * }
 */
PUBLIC MgAsnElmntDef gcMsgPackagesItem =
{
#ifdef MG_ASN_DBG
  "gcMsgPackagesItem",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 173,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoPkgsItem),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgPackageVersion
 *    PackageVersion ::= INTEGER    (0..99) 
 */
PUBLIC MgAsnElmntDef gcMsgPackageVersion =
{
#ifdef MG_ASN_DBG
  "gcMsgPackageVersion",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 174,  /* idNum */ 
  TET_INT16,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  /* mg008.105: maximum length of 1 only */
  1,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU16),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgAuditReturnParameter
 * AuditReturnParameter ::= CHOICE {
 *               errorDescriptor ErrorDescriptor
 *               mediaDescriptor MediaDescriptor
 *               modemDescriptor ModemDescriptor
 *               muxDescriptor MuxDescriptor
 *               eventsDescriptor EventsDescriptor
 *               eventBufferDescriptor EventBufferDescriptor
 *               signalsDescriptor SignalsDescriptor
 *               digitMapDescriptor DigitMapDescriptor
 *               observedEventsDescriptor ObservedEventsDescriptor
 *               statisticsDescriptor StatisticsDescriptor
 *               packagesDescriptor PackagesDescriptor
 *               emptyDescriptors AuditDescriptor
 * }
 */
PUBLIC MgAsnElmntDef gcMsgAuditReturnParameter =
{
#ifdef MG_ASN_DBG
  "gcMsgAuditReturnParameter",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 175,  /* idNum */ 
  TET_CHOICE0,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAudRetParm),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncChoice,         /* user function */
  mgAsnDecChoice,         /* user function */
};


/*
 * gcMsgAuditResult
 * AuditResult ::= SEQUENCE {
 *               terminationID TerminationID
 *               terminationAuditResult TerminationAudit
 * }
 */
PUBLIC MgAsnElmntDef gcMsgAuditResult =
{
#ifdef MG_ASN_DBG
  "gcMsgAuditResult",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 176,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAuditOther),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgTerminationAudit
 * TerminationAudit ::= SEQUENCE  OF AuditReturnParameter
 */
PUBLIC MgAsnElmntDef gcMsgTerminationAudit =
{
#ifdef MG_ASN_DBG
  "gcMsgTerminationAudit",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 177,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  /* mg007.105: changed for the empty AuditReturnParameter */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTermAuditRes),   /* event structure size */
  MGAMAX_TerminationAudit,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgAuditReply
 * AuditReply ::= CHOICE {
 *               contextAuditResult TerminationIDList
 *               error ErrorDescriptor
 *               auditResult AuditResult
 * }
 */
PUBLIC MgAsnElmntDef gcMsgAuditReply4 =
{
#ifdef MG_ASN_DBG
  "gcMsgAuditReply4",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 178,  /* idNum */ 
  TET_CHOICE,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAuditReply),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncAuditReplyEnc,         /* user function */
  mgaFuncAuditReplyDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgAuditReply5 =
{
#ifdef MG_ASN_DBG
  "gcMsgAuditReply5",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 178,  /* idNum */ 
  TET_CHOICE,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoAuditReply),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncAuditReplyEnc,         /* user function */
  mgaFuncAuditReplyDec,         /* user function */
};


/*
 * gcMsgNotifyReply
 * NotifyReply ::= SEQUENCE {
 *               terminationID TerminationIDList
 *               errorDescriptor ErrorDescriptor   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgNotifyReply =
{
#ifdef MG_ASN_DBG
  "gcMsgNotifyReply",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 179,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoNtfyReply),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgServiceChangeReply
 * ServiceChangeReply ::= SEQUENCE {
 *               terminationID TerminationIDList
 *               serviceChangeResult ServiceChangeResult
 * }
 */
PUBLIC MgAsnElmntDef gcMsgServiceChangeReply =
{
#ifdef MG_ASN_DBG
  "gcMsgServiceChangeReply",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 180,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSvcChgReply),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgServiceChangeResParm
 * ServiceChangeResParm ::= SEQUENCE {
 *               serviceChangeMgcId MId   OPTIONAL
 *               serviceChangeAddress ServiceChangeAddress   OPTIONAL
 *               serviceChangeVersion ServiceChangeVersion   OPTIONAL
 *               serviceChangeProfile ServiceChangeProfile   OPTIONAL
 *               timestamp TimeNotation   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgServiceChangeResParm =
{
#ifdef MG_ASN_DBG
  "gcMsgServiceChangeResParm",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 181,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSvcChgResPar),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncServiceChangeResParmEnc,         /* user function */
  mgaFuncServiceChangeResParmDec,         /* user function */
};


/*
 * gcMsgServiceChangeResult
 * ServiceChangeResult ::= CHOICE {
 *               errorDescriptor ErrorDescriptor
 *               serviceChangeResParms ServiceChangeResParm
 * }
 */
PUBLIC MgAsnElmntDef gcMsgServiceChangeResult =
{
#ifdef MG_ASN_DBG
  "gcMsgServiceChangeResult",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 182,  /* idNum */ 
  TET_CHOICE0,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSvcChgRes),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  /* mg008.105: ServiceChangeResult is mandatory field in ASN */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncChoice,         /* user function */
  mgAsnDecChoice,         /* user function */
};


/*
 * gcMsgCommandReply
 * CommandReply ::= CHOICE {
 *               addReply AmmsReply
 *               moveReply AmmsReply
 *               modReply AmmsReply
 *               subtractReply AmmsReply
 *               auditCapReply AuditReply
 *               auditValueReply AuditReply
 *               notifyReply NotifyReply
 *               serviceChangeReply ServiceChangeReply
 * }
 */
PUBLIC MgAsnElmntDef gcMsgCommandReply =
{
#ifdef MG_ASN_DBG
  "gcMsgCommandReply",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 183,  /* idNum */ 
  TET_CHOICE0,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoCmdReply),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  /* mg003.105: Changes for GCP_CH  */
#ifdef GCP_CH
  &gcManditoryIgnorePres,         /* protocol flag */
#else
  &gcManditory,         /* protocol flag */
#endif
  NULLP,         /* enumbered values list */
  mgaFuncCommandReplyEnc,         /* user function */
  mgaFuncCommandReplyDec,         /* user function */
};


/*
 * gcMsgTransactionResult
 * TransactionResult ::= CHOICE {
 *               transactionError ErrorDescriptor
 *               actionReplies SEQUENCE OF
 * }
 */
PUBLIC MgAsnElmntDef gcMsgTransactionResult =
{
#ifdef MG_ASN_DBG
  "gcMsgTransactionResult",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 184,  /* idNum */ 
  TET_CHOICE0,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  0,   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncChoice,         /* user function */
  mgAsnDecChoice,         /* user function */
};


/*
 * gcMsgTransactionResponseAck
 * TransactionResponseAck ::= SEQUENCE  OF TransactionAck
 */
PUBLIC MgAsnElmntDef gcMsgTransactionResponseAck =
{
#ifdef MG_ASN_DBG
  "gcMsgTransactionResponseAck",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 185,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  1,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTxnRspAck),   /* event structure size */
  MGAMAX_TransactionResponseAck,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgTransactionAck
 * TransactionAck ::= SEQUENCE {
 *               firstAck TransactionId
 *               lastAck TransactionId   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgTransactionAck =
{
#ifdef MG_ASN_DBG
  "gcMsgTransactionAck",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 186,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTxnAck),         /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgTransactionIdO
 *    TransactionId ::= INTEGER    (0..4294967295) 
 */
PUBLIC MgAsnElmntDef gcMsgTransactionIdO =
{
#ifdef MG_ASN_DBG
  "gcMsgTransactionIdO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 187,  /* idNum */ 
  TET_INT32,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  4,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoTransId),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgTransaction
 * Transaction ::= CHOICE {
 *               transactionRequest TransactionRequest
 *               transactionPending TransactionPending
 *               transactionReply TransactionReply
 *               transactionResponseAck TransactionResponseAck
 * }
 */
PUBLIC MgAsnElmntDef gcMsgTransaction =
{
#ifdef MG_ASN_DBG
  "gcMsgTransaction",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 188,  /* idNum */ 
  TET_CHOICE,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTxn),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryIgnorePres,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncTransactionEnc,         /* user function */
  mgaFuncTransactionDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgTransaction32 =
{
#ifdef MG_ASN_DBG
  "gcMsgTransaction",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 188,  /* idNum */ 
  TET_CHOICE,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoTxn),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryIgnorePres,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncTransactionEnc,         /* user function */
  mgaFuncTransactionDec,         /* user function */
};


/*
 * gcMsgMessageBody
 * MessageBody ::= CHOICE {
 *               messageError ErrorDescriptor
 *               transactions SEQUENCE OF
 * }
 */
PUBLIC MgAsnElmntDef gcMsgMessageBody =
{
#ifdef MG_ASN_DBG
  "gcMsgMessageBody",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 189,  /* idNum */ 
  TET_CHOICE0,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoMsgBody),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncChoice,         /* user function */
  mgAsnDecChoice,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgMessageBodySpecial0 =
{
#ifdef MG_ASN_DBG
  "gcMsgMessageBodySpecial0",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 689,  /* idNum */ 
  TET_CHOICE0,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoMsgBody),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncChoice,         /* user function */
  mgAsnDecChoice,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgMessageBodySpecial1 =
{
#ifdef MG_ASN_DBG
  "gcMsgMessageBodySpecial1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 689,  /* idNum */ 
  TET_CHOICE0,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoMsgBody),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncChoice,         /* user function */
  mgAsnDecChoice,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgMessageBodySpecial2 =
{
#ifdef MG_ASN_DBG
  "gcMsgMessageBodySpecial2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 689,  /* idNum */ 
  TET_CHOICE0,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoMsgBody),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditory,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncChoice,         /* user function */
  mgAsnDecChoice,         /* user function */
};


/* V2 Messages Here */

#ifdef MGT_MGCO_V2
/*
 * gcMsgIndAudMediaDescriptor
 * IndAudMediaDescriptor ::= SEQUENCE {
 *      termStateDescr IndAudTerminationStateDescriptor   OPTIONAL
 *      streamsIndAud CHOICE   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudMediaDescriptor =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudMediaDescriptor",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 201,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudMediaParm),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncIndAudMediaDescriptorEnc,         /* user function */
  mgaFuncIndAudMediaDescriptorDec,         /* user function */
};


/*
 * gcMsgIndAudTerminationStateDescriptorO
 * IndAudTerminationStateDescriptor ::= SEQUENCE {
 *                propertyParmsIndAud SEQUENCE OF
 *                eventBufferControlIndAud NULL   OPTIONAL
 *                serviceStateIndAud NULL   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudTerminationStateDescriptorO =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudTerminationStateDescriptorO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 202,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudTermStateDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncIndAudTerminationStateDescriptorEnc,         /* user function */
  mgaFuncIndAudTerminationStateDescriptorDec,         /* user function */
};


/*
 * gcMsgPropertyParmsIndAud
 * PropertyParmsIndAud ::= SEQUENCE  OF IndAudPropertyParm
 */
PUBLIC MgAsnElmntDef gcMsgPropertyParmsIndAud =
{
#ifdef MG_ASN_DBG
  "gcMsgPropertyParmsIndAud",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 203,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudStreamParm),   /* event structure size */
  MGAMAX_PropertyParmsIndAud,      /* counter for repeat element */
  &gcManditoryv2,        /*  protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncPropertyParmsIndAudEnc,         /* user function */
  mgaFuncPropertyParmsIndAudDec,         /* user function */
};


/*
 * gcMsgIndAudPropertyParm
 * IndAudPropertyParm ::= SEQUENCE {
 *                name PkgdName
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudPropertyParm =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudPropertyParm",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 204,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudStreamParm),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncIndAudPropertyParmEnc,         /* user function */
  mgaFuncIndAudPropertyParmDec,         /* user function */
};


/*
 * gcMsgEventBufferControlIndAudO
 *   EventBufferControlIndAud ::= NULL
 *
 */
PUBLIC MgAsnElmntDef gcMsgEventBufferControlIndAudO =
{
#ifdef MG_ASN_DBG
  "gcMsgEventBufferControlIndAudO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 205,  /* idNum */ 
  TET_NULL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncNull,         /* user function */
  mgAsnDecNull,         /* user function */
};


/*
 * gcMsgServiceStateIndAudO
 *   ServiceStateIndAud ::= NULL
 *
 */
PUBLIC MgAsnElmntDef gcMsgServiceStateIndAudO =
{
#ifdef MG_ASN_DBG
  "gcMsgServiceStateIndAudO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 206,  /* idNum */ 
  TET_NULL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncNull,         /* user function */
  mgAsnDecNull,         /* user function */
};


/*
 * gcMsgIndAudStreamParms
 * IndAudStreamParms ::= SEQUENCE {
 *      localControlDescriptor IndAudLocalControlDescriptor   OPTIONAL
 *      localDescriptor IndAudLocalRemoteDescriptor   OPTIONAL
 *      remoteDescriptor IndAudLocalRemoteDescriptor   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudStreamParms0 =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudStreamParms0",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 207,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudStreamParm),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncIndAudStreamParmsEnc,         /* user function */
  mgaFuncIndAudStreamParmsDec,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgIndAudStreamParms1 =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudStreamParms1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 207,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudStreamParm),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncIndAudStreamParmsEnc,         /* user function */
  mgaFuncIndAudStreamParmsDec,         /* user function */
};


/*
 * gcMsgIndAudLocalControlDescriptorO
 * IndAudLocalControlDescriptor ::= SEQUENCE {
 *      streamModeIndAud NULL   OPTIONAL
 *      reserveValueIndAud NULL   OPTIONAL
 *      reserveGroupIndAud NULL   OPTIONAL
 *      propertyParmsIndAud SEQUENCE OF   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudLocalControlDescriptorO =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudLocalControlDescriptorO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 208,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudStreamParm),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncIndAudLocalControlDescriptorEnc, /* user function */
  mgaFuncIndAudLocalControlDescriptorDec, /* user function */
};


/*
 * gcMsgStreamModeIndAudO
 *   StreamModeIndAud ::= NULL
 *
 */
PUBLIC MgAsnElmntDef gcMsgStreamModeIndAudO =
{
#ifdef MG_ASN_DBG
  "gcMsgStreamModeIndAudO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 209,  /* idNum */ 
  TET_NULL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncNull,         /* user function */
  mgAsnDecNull,         /* user function */
};


/*
 * gcMsgReserveValueIndAudO
 *   ReserveValueIndAud ::= NULL
 *
 */
PUBLIC MgAsnElmntDef gcMsgReserveValueIndAudO =
{
#ifdef MG_ASN_DBG
  "gcMsgReserveValueIndAudO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 210,  /* idNum */ 
  TET_NULL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncNull,         /* user function */
  mgAsnDecNull,         /* user function */
};


/*
 * gcMsgReserveGroupIndAudO
 *   ReserveGroupIndAud ::= NULL
 *
 */
PUBLIC MgAsnElmntDef gcMsgReserveGroupIndAudO =
{
#ifdef MG_ASN_DBG
  "gcMsgReserveGroupIndAudO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 211,  /* idNum */ 
  TET_NULL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU8),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncNull,         /* user function */
  mgAsnDecNull,         /* user function */
};


/*
 * gcMsgPropertyParmsIndAudO
 * PropertyParmsIndAud ::= SEQUENCE  OF IndAudPropertyParm
 */
PUBLIC MgAsnElmntDef gcMsgPropertyParmsIndAudO =
{
#ifdef MG_ASN_DBG
  "gcMsgPropertyParmsIndAudO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 212,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudStreamParm),   /* event structure size */
  MGAMAX_PropertyParmsIndAud,   /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncPropertyParmsIndAudEnc,         /* user function */
  mgaFuncPropertyParmsIndAudDec,         /* user function */
};


/*
 * gcMsgIndAudLocalRemoteDescriptorO
 * IndAudLocalRemoteDescriptor ::= SEQUENCE {
 *                propGroupID INTEGER   OPTIONAL
 *                propGrps IndAudPropertyGroup
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudLocalRemoteDescriptorO1 =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudLocalRemoteDescriptorO1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 213,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  0,   /* event structure size - this shouldn't occur in V1/V2 */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};
PUBLIC MgAsnElmntDef gcMsgIndAudLocalRemoteDescriptorO2 =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudLocalRemoteDescriptorO2",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 213,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  0,   /* event structure size - this shouldn't occur in V1/V2 */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgPropGroupIDO
 *    PropGroupID ::= INTEGER    (0..65535) 
 */
PUBLIC MgAsnElmntDef gcMsgPropGroupIDO =
{
#ifdef MG_ASN_DBG
  "gcMsgPropGroupIDO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 214,  /* idNum */ 
  TET_INT,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU32),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgIndAudPropertyGroup
 * IndAudPropertyGroup ::= SEQUENCE  OF IndAudPropertyParm
 */
PUBLIC MgAsnElmntDef gcMsgIndAudPropertyGroup =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudPropertyGroup",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 215,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  0,   /* event structure size - this shouldn't occur in V1/V2 */
  MGAMAX_IndAudPropertyGroup,         /* counter for repeat element */
  &gcManditoryv2,        /*  protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};


/*
 * gcMsgMultiStreamIndAud
 * MultiStreamIndAud ::= SEQUENCE  OF IndAudStreamDescriptor
 */
PUBLIC MgAsnElmntDef gcMsgMultiStreamIndAud =
{
#ifdef MG_ASN_DBG
  "gcMsgMultiStreamIndAud",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 216,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudStreamDesc),   /* event structure size */
  MGAMAX_MultiStreamIndAud,         /* counter for repeat element */
  &gcManditoryv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncMultiStreamIndAudEnc,         /* user function */
  mgaFuncMultiStreamIndAudDec,         /* user function */
};


/*
 * gcMsgIndAudStreamDescriptor
 * IndAudStreamDescriptor ::= SEQUENCE {
 *                streamID StreamID
 *                streamParms IndAudStreamParms
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudStreamDescriptor =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudStreamDescriptor",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 217,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudStreamDesc),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryv2,        /*  protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncIndAudStreamDescriptorEnc,         /* user function */
  mgaFuncIndAudStreamDescriptorDec,         /* user function */
};


/*
 * gcMsgStreamsIndAudO
 * StreamsIndAud ::= CHOICE {
 *                oneStream IndAudStreamParms
 *                multiStream SEQUENCE OF
 * }
 */
PUBLIC MgAsnElmntDef gcMsgStreamsIndAudO =
{
#ifdef MG_ASN_DBG
  "gcMsgStreamsIndAudO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 219,  /* idNum */ 
  TET_CHOICE0,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudMediaParm),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncChoice,         /* user function */
  mgAsnDecChoice,         /* user function */
};


/*
 * gcMsgIndAudEventsDescriptor
 * IndAudEventsDescriptor ::= SEQUENCE {
 *                requestID RequestID   OPTIONAL
 *                pkgdName PkgdName
 *                streamID StreamID   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudEventsDescriptor =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudEventsDescriptor",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 220,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudEvents),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncIndAudEventsDescriptorEnc,         /* user function */
  mgaFuncIndAudEventsDescriptorDec,         /* user function */
};

/*
 * gcMsgIndAudEventBufferDescriptor
 * IndAudEventBufferDescriptor ::= SEQUENCE {
 *                eventName PkgdName
 *                streamID StreamID   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudEventBufferDescriptor =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudEventBufferDescriptor",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 221,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudEventBuffer),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncIndAudEventBufferDescriptorEnc, /* user function */
  mgaFuncIndAudEventBufferDescriptorDec, /* user function */
};


/*
 * gcMsgIndAudSignal
 * IndAudSignal ::= SEQUENCE {
 *                signalName PkgdName
 *                streamID StreamID   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudSignal =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudSignal",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 222,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSigName),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncIndAudSignalEnc,         /* user function */
  mgaFuncIndAudSignalDec,         /* user function */
};


/*
 * gcMsgIndAudSeqSigList
 * IndAudSeqSigList ::= SEQUENCE {
 *                idNum INTEGER
 *                signalList IndAudSignal   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudSeqSigList =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudSeqSigList",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 223,  /* idNum */ 
  TET_SEQ_SPECIAL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudSigLst),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncIndAudSeqSigListEnc,         /* user function */
  mgaFuncIndAudSeqSigListDec,         /* user function */
};


/*
 * gcMsgIdNum
 *    IdNum::= INTEGER    (0..65535) 
 */
PUBLIC MgAsnElmntDef gcMsgIdNum =
{
#ifdef MG_ASN_DBG
  "gcMsgIdNum",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 224,  /* idNum */ 
  TET_INT16,         /* element type */
  0xFF,                            /* tag value */
  0,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknU16),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncInteger,         /* user function */
  mgAsnDecInteger,         /* user function */
};


/*
 * gcMsgIndAudSignalO
 * IndAudSignal ::= SEQUENCE {
 *                signalName PkgdName
 *                streamID StreamID   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudSignalO =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudSignalO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 225,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoSigName),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncIndAudSignalEnc,         /* user function */
  mgaFuncIndAudSignalDec,         /* user function */
};


/*
 * gcMsgIndAudSignalsDescriptor
 * IndAudSignalsDescriptor ::= CHOICE {
 *                signal IndAudSignal
 *                seqSigList IndAudSeqSigList
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudSignalsDescriptor =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudSignalsDescriptor",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 226,  /* idNum */ 
  TET_CHOICE0,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudSignals),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncChoice,         /* user function */
  mgAsnDecChoice,         /* user function */
};


/*
 * gcMsgIndAudDigitMapDescriptor
 * IndAudDigitMapDescriptor ::= SEQUENCE {
 *                digitMapName DigitMapName   OPTIONAL
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudDigitMapDescriptor =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudDigitMapDescriptor",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 227,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoName),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};

/*
 * gcMsgIndAudStatisticsDescriptor
 * IndAudStatisticsDescriptor ::= SEQUENCE {
 *                statName PkgdName
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudStatisticsDescriptor =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudStatisticsDescriptor",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 228,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudStatistics),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncIndAudStatisticsDescriptorEnc,         /* user function */
  mgaFuncIndAudStatisticsDescriptorDec,         /* user function */
};


/*
 * gcMsgIndAudPackagesDescriptor
 * IndAudPackagesDescriptor ::= SEQUENCE {
 *                packageName Name
 *                packageVersion INTEGER
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAudPackagesDescriptor =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAudPackagesDescriptor",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 229,  /* idNum */ 
  TET_SEQ,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudPackages),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncSetSeq,         /* user function */
  mgAsnDecSeq,         /* user function */
};


/*
 * gcMsgIndAuditParameter
 * IndAuditParameter ::= CHOICE {
 *      indaudmediaDescriptor IndAudMediaDescriptor
 *      indaudeventsDescriptor IndAudEventsDescriptor
 *      indaudeventBufferDescriptor IndAudEventBufferDescriptor
 *      indaudsignalsDescriptor IndAudSignalsDescriptor
 *      indauddigitMapDescriptor IndAudDigitMapDescriptor
 *      indaudstatisticsDescriptor IndAudStatisticsDescriptor
 *      indaudpackagesDescriptor IndAudPackagesDescriptor
 * }
 */
PUBLIC MgAsnElmntDef gcMsgIndAuditParameter =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAuditParameter",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 231,  /* idNum */ 
  TET_CHOICE0,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudAuditRetParm),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcManditoryv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncChoice,         /* user function */
  mgAsnDecChoice,         /* user function */
};

/*
 * gcMsgIndAuditParametersO
 * auditPropertyToken ::= SEQUENCE OF IndAuditParameter
 */
PUBLIC MgAsnElmntDef gcMsgIndAuditParametersO =
{
#ifdef MG_ASN_DBG
  "gcMsgIndAuditParametersO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 232,  /* idNum */ 
  TET_UNCONS_SEQ_OF,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  0,            /* database definition size */
  sizeof(MgMgcoIndAudTermAudit),   /* event structure size */
  MGAMAX_IndAuditParameters,      /* counter for repeat element */
  &gcOptionalv2,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncUnconsSetSeqOf,         /* user function */
  mgAsnDecUnconsSetSeqOf,         /* user function */
};

#endif /* MgT_MGCO_V2 */

/*
 * gcMsgDigitMapNameO
 * DigitMapName ::= OCTET STRING       2  
 */
PUBLIC MgAsnElmntDef gcMsgDigitMapNameO =
{
#ifdef MG_ASN_DBG
  "gcMsgDigitMapNameO",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 233,  /* idNum */ 
  TET_STR4,         /* element type */
  0xFF,                            /* tag value */
  2,         /* minimum length */
  2,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(MgMgcoName),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgaFuncNameSpecialEnc,   /* user function */
  mgaFuncNameSpecialDec,   /* user function */
};

/* for special partial decodes */
PUBLIC MgAsnElmntDef gcMsgNullSpecial1 =
{
#ifdef MG_ASN_DBG
  "gcMsgNullSpecial1",   /* description */
#endif
  MG_ASN_ELMNID_MEGACO_BASE + 939,  /* idNum */ 
  TET_NULL,         /* element type */
  0xFF,                            /* tag value */
  MIN_LEN_NA,         /* minimum length */
  MAX_LEN_NA,         /* maximum length */
  sizeof(PTR),         /* database definition size */
  sizeof(TknPres),   /* event structure size */
  REP_CNTR_NA,         /* counter for repeat element */
  &gcOptional,         /* protocol flag */
  NULLP,         /* enumbered values list */
  mgAsnEncNull,         /* user function */
  mgAsnDecNull,         /* user function */
};


/* Value encodings */
PUBLIC MgAsnElmntDef gcMsgValue_TknStrOSXL =
{
#ifdef MG_ASN_DBG
  "gcMsgValue_TknStrOSXL",      /* description */
#endif
  MG_ASN_ELMNID_MGCO_BASE + 502,/* idNum */
  TET_STROSXL_MEM,              /* element type */
  MG_ASN_UOCTSTR,               /* tag value */
  MIN_LEN_NA,                   /* minimum length */
  MAX_LEN_NA,                   /* maximum length */
  sizeof(PTR),                  /* database definition size */
  sizeof(TknStrOSXL),           /* event structure size */
  REP_CNTR_NA,                  /* counter for repeat element */
  &gcOptional,                  /* protocol flag */
  NULLP,                        /* enumbered values list */
  mgAsnEncOctetStr,                /* user function */
  mgAsnDecOctetStr,                /* user function */
};
PUBLIC MgAsnElmntDef *mgaValue_TknStrOSXL[] = { &gcMsgValue_TknStrOSXL, NULLP };

PUBLIC MgAsnElmntDef gcMsgValue_Enumeration =
{
#ifdef MG_ASN_DBG
  "gcMsgValue_Enumeration",     /* description */
#endif
  MG_ASN_ELMNID_MGCO_BASE + 501,/* idNum */
#ifdef GCP_ENUM_U32
  TET_ENUM32,
#else
  TET_ENUM,                     /* element type */
#endif 
  MG_ASN_UENUM,                 /* tag value */
  MIN_LEN_NA,                   /* minimum length */
  MAX_LEN_NA,                   /* maximum length */
  sizeof(PTR),                  /* database definition size */
#ifdef GCP_ENUM_U32
  sizeof(TknU32),                /* event structure size */
#else
  sizeof(TknU8),                /* event structure size */
#endif
  REP_CNTR_NA,                  /* counter for repeat element */
  &gcOptional,                  /* protocol flag */
  NULL,                         /* enumbered values list */
  mgAsnEncOctetEnum,                       /* user function */
  mgAsnDecOctetEnum,                       /* user function */
};
PUBLIC MgAsnElmntDef *mgaValue_Enumeration[] = { &gcMsgValue_Enumeration, NULLP };

PUBLIC MgAsnElmntDef gcMsgValue_TknU32 =
{
#ifdef MG_ASN_DBG
  "gcMsgValue_TknU32",           /* description */
#endif
  MG_ASN_ELMNID_MGCO_BASE + 500,/* idNum */
  TET_INT32,                    /* element type */
  MG_ASN_UINT,                  /* tag value */
  0,                            /* minimum length */
  2147483647,                   /* maximum length */
  sizeof(PTR),                  /* database definition size */
  sizeof(TknU32),               /* event structure size */
  REP_CNTR_NA,                  /* counter for repeat element */
  &gcOptional,                  /* protocol flag */
  NULLP,                        /* enumbered values list */
  mgAsnEncInteger,                 /* user function */
  mgAsnDecInteger,                 /* user function */
};
PUBLIC MgAsnElmntDef *mgaValue_TknU32[] = { &gcMsgValue_TknU32, NULLP };

/* mg005.105: Added Bool type at the decoding side */
PUBLIC MgAsnElmntDef gcMsgValue_Boolean =
{
#ifdef MG_ASN_DBG
  "gcMsgValue_Boolean",     /* description */
#endif
  MG_ASN_ELMNID_MGCO_BASE + 501,/* idNum */
  TET_BOOL,                     /* element type */
  MG_ASN_UBOOL,                 /* tag value */
  MIN_LEN_NA,                   /* minimum length */
  MAX_LEN_NA,                   /* maximum length */
  sizeof(PTR),                  /* database definition size */
  sizeof(TknU8),                /* event structure size */
  REP_CNTR_NA,                  /* counter for repeat element */
  &gcOptional,                  /* protocol flag */
  NULL,                         /* enumbered values list */
  mgAsnEncBool,                       /* user function */
  mgAsnDecBool,                       /* user function */
};
PUBLIC MgAsnElmntDef *mgaValue_Boolean[] = { &gcMsgValue_Boolean, NULLP };

#endif

  
/********************************************************************30**
  
         End of file:     mgasndb1.c@@/main/1 - Wed Mar 30 08:07:43 2005
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************80**
 
 
*********************************************************************81*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      tlh  1. initial release.
/main/1      ---      pk   1. GCP 1.5 release
          mg003.105   dp   1. Fixing ASN Encoding problem with GCP_CH
                      gk   2. Changes for Universal Tag 
                      gk   3. Changes for minimum elemnts to encode 
                      gk   4. Changes done for 3GPP specification
                      gk   5. Changed max length according to X.690
                      gk   6. Changed the encoding/decoding functions
                      gk   7. Changed the flag to optional for RequestID
                      gk   8. Changed the flag to mandatory for parameter list
                              and length to 0
          mg004.105   gk   1. Modifed from CmSdpInfo to MgMgcoPropParmLst 
                              to support Annex C 
                           2. Modified minimum length of param value
                           3. Modified minimum length of number of parameters
         mg005.105    gk   1. Modified to the optional descriptors
                           2. Added Bool type at the decoding side
                           3. Changed to support empty commands in the action
         mg007.105    gk   1. changed for the empty AuditReturnParameter
                           2. Corrected the Data type correctly
         mg008.105    gk   1. There is no max and min check for the length
                           2. Data is of type octet string only, so no need of double
                              wrapping of data
                           3. ServiceChangeResult is mandatory field in ASN
*********************************************************************91*/
